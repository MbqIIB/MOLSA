define(
({
	summary: 'Σύνολο: ${0}',
	summaryWithSelection: 'Σύνολο: ${0} Επιλεγμένα: ${1}'
})
);

