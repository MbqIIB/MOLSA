define(
({
	summary: 'Celkovo: ${0}',
	summaryWithSelection: 'Celkovo: ${0}, vybratých: ${1}'
})
);

