define(
//begin v1.x content
({
   titleTemplate: "${workspaceTypeName}",

   errorTooManyOpen: "最多可以同时打开 ${maxOpen} 个“${workspaceTypeName}”工作空间。请先关闭一个或多个工作空间。",

   loadingMessage: "正在装入，请等待..."

})
//end v1.x content
);
