define(
({
	filterLabel: 'Filter',
	clearButtonTitle: 'Filter löschen',
	buildFilterMenuLabel: 'Filter erstellen&hellip;',
	apply: 'Filter anwenden'
})
);

