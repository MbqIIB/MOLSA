define(
({
	filterLabel: 'フィルター',
	clearButtonTitle: 'フィルターのクリア',
	buildFilterMenuLabel: 'フィルターのビルド&hellip;',
	apply: 'フィルターの適用'
})
);

