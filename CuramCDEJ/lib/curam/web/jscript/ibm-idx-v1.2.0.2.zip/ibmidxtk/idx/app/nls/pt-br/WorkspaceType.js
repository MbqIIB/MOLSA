define(
//begin v1.x content
({
   titleTemplate: "${workspaceTypeName}",

   errorTooManyOpen: "É possível abrir no máximo ${maxOpen} \"${workspaceTypeName}\" áreas de trabalho de uma vez. Feche uma ou mais áreas de trabalho primeiro.",

   loadingMessage: "Carregando. Aguarde..."

})
//end v1.x content
);
