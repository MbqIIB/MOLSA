define(
({
	summary: 'Skupaj: ${0}',
	summaryWithSelection: 'Skupaj: ${0} Izbrano: ${1}'
})
);

