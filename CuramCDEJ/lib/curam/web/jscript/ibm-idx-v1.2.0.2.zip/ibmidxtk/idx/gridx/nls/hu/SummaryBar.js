define(
({
	summary: 'Összesen: ${0}',
	summaryWithSelection: 'Összesen: ${0} Kijelölve: ${1}'
})
);

