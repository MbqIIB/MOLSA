define(
({
	loadingInfo: "Nalaganje ...",
	emptyInfo: "Ni postavk za prikaz",
	loadFailInfo: "Nalaganje podatkov ni uspelo!"
})
);

