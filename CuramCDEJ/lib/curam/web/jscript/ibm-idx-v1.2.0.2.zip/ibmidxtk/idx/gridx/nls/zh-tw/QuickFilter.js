define(
({
	filterLabel: '過濾',
	clearButtonTitle: '清除過濾器',
	buildFilterMenuLabel: '建置過濾器&hellip;',
	apply: '套用過濾器'
})
);

