define(
({
	filterLabel: 'Filtrer',
	clearButtonTitle: 'Effacer le filtre',
	buildFilterMenuLabel: 'Construire le filtre&hellip;',
	apply: 'Appliquer le filtre'
})
);

