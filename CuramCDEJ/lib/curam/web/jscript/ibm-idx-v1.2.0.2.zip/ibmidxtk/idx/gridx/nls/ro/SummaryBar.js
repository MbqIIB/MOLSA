define(
({
	summary: 'Total: ${0}',
	summaryWithSelection: 'Total: ${0} Selectate: ${1}'
})
);

