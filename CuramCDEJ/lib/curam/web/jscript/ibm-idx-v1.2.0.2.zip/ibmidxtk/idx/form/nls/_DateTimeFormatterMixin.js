define({root:
//begin v1.x content
({
	/* date time format */
	"dateFormat": "mm/dd/yyyy",
	"timeFormat": "hh:mm",
	
	/* idx.form.TimePicker */
	idxTimePicker_iconTitle: "Click to open time picker",
	
	/* idx.form.DatePicker */
	idxDatePicker_iconTitle: "Click to open date picker"		
})
//end v1.x content
,
"ar": true,
"fr": true,
"ja": true,
"ko": true,
"pt-br": true,
"zh-cn": true,
"zh-tw": true
});
