define(
//begin v1.x content
({
    unknownWorkspaceTypeError: "لا يمكن فتح مساحة العمل.  نوع مساحة العمل غير معروف: ${workspaceTypeID}",

    tooManyOpenWorkspaces: "لا يمكن فتح أكثر من ${maxOpen} \"${workspaceTypeName}\" مساحة عمل.  ان أمكن، قم باغلاق مساحات عمل \"${workspaceTypeName}\" المفتوحة بالفعل.  "
})
//end v1.x content
);


