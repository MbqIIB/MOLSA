define(
({
	filterLabel: '过滤器',
	clearButtonTitle: '清除过滤器',
	buildFilterMenuLabel: '构建过滤器&hellip;',
	apply: '应用过滤器'
})
);

