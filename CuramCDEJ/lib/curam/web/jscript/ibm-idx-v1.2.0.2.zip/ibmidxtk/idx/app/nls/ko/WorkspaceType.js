define(
//begin v1.x content
({
   titleTemplate: "${workspaceTypeName}",

   errorTooManyOpen: "한 번에 최대 ${maxOpen} \"${workspaceTypeName}\"개의 작업공간을 열수 있습니다. 먼저 하나 이상의 작업공간을 닫으십시오.",

   loadingMessage: "로드 중입니다. 기다려 주십시오...."

})
//end v1.x content
);
