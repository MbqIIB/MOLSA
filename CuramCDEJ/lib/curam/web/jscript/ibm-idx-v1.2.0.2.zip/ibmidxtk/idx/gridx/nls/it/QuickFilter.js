define(
({
	filterLabel: 'Filtro',
	clearButtonTitle: 'Cancella filtro',
	buildFilterMenuLabel: 'Crea filtro&hellip;',
	apply: 'Applica filtro'
})
);

