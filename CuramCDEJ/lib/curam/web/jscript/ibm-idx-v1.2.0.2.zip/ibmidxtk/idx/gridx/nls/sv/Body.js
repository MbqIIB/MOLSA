define(
({
	loadingInfo: "Läser in...",
	emptyInfo: "Det finns inga objekt att visa",
	loadFailInfo: "Det gick inte att läsa in data!"
})
);

