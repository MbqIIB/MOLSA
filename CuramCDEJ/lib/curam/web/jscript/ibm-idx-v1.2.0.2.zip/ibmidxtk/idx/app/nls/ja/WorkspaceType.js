define(
//begin v1.x content
({
   titleTemplate: "${workspaceTypeName}",

   errorTooManyOpen: "同時に開くことができる \"${workspaceTypeName}\" ワークスペースの数は、最大で ${maxOpen} 個までです。まず 1 つ以上のワークスペースを閉じてください。",

   loadingMessage: "ロード中です。しばらくお待ちください..."

})
//end v1.x content
);
