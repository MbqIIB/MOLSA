define(
({
	singleSort: "單一排序",
	nestedSort: "巢狀排序",
	ascending: "按一下以遞增排序",
	descending: "按一下以遞減排序",
	sortingState: "${0} - ${1}",
	unsorted: "無法排序此直欄",
	waiSingleSortLabel: "已排序 ${0}（依照 ${1} 進行排序）。 選擇依照 ${2} 進行排序",
	waiNestedSortLabel:"已巢狀排序 ${0}（依照 ${1} 進行排序）。 選擇依照 ${2} 進行巢狀排序"
})
);

