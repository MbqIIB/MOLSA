define(
({
	loadingInfo: "ロード中...",
	emptyInfo: "表示する項目がありません",
	loadFailInfo: "データのロードに失敗しました!"
})
);

