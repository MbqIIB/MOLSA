define(
({
	filterLabel: 'Filter',
	clearButtonTitle: 'Filter wissen',
	buildFilterMenuLabel: 'Filter bouwen&hellip;',
	apply: 'Filter toepassen'
})
);

