define(
({
	summary: '合計: ${0}',
	summaryWithSelection: '合計: ${0} 選択済み: ${1}'
})
);

