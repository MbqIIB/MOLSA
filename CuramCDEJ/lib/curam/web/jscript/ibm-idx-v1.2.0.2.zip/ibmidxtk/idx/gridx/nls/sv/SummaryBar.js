define(
({
	summary: 'Totalt: ${0}',
	summaryWithSelection: 'Totalt: ${0} Valda: ${1}'
})
);

