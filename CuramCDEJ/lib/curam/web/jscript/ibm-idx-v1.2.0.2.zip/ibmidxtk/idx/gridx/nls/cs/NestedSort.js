define(
({
	singleSort: "Jednoduché řazení",
	nestedSort: "Vnořené řazení",
	ascending: "Po klepnutí bude řazeno vzestupně",
	descending: "Po klepnutí bude řazeno sestupně",
	sortingState: "${0} - ${1}",
	unsorted: "Tento sloupec neřadit",
	waiSingleSortLabel: "${0} - řazeno podle ${1}. Zvolit řazení podle ${2}",
	waiNestedSortLabel:"${0} - vnořeně řazeno podle ${1}. Zvolit vnořené řazení podle ${2}"
})
);

