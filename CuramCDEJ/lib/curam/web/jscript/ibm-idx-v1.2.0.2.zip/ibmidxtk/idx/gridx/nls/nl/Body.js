define(
({
	loadingInfo: "Bezig met laden...",
	emptyInfo: "Geen items om af te beelden",
	loadFailInfo: "Gegevens kunnen niet worden geladen!"
})
);

