define(
({
	summary: 'Total: ${0}',
	summaryWithSelection: 'Total: ${0} Seleccionados: ${1}'
})
);

