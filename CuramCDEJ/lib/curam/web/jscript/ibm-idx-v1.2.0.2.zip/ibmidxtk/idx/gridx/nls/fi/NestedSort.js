define(
({
	singleSort: "Yksinkertainen lajittelu",
	nestedSort: "Sisäkkäinen lajittelu",
	ascending: "Lajittele nousevaan järjestykseen napsauttamalla",
	descending: "Lajittele laskevaan järjestykseen napsauttamalla",
	sortingState: "${0} - ${1}",
	unsorted: "Älä lajittele tätä saraketta",
	waiSingleSortLabel: "${0} - on lajiteltu sarakkeen ${1} mukaan. Lajittele sarakkeen ${2} perusteella",
	waiNestedSortLabel:"${0} - on lajiteltu sisäkkäisesti sarakkeen ${1} mukaan. Lajittele sisäisesti sarakkeen ${2} perusteella"
})
);

