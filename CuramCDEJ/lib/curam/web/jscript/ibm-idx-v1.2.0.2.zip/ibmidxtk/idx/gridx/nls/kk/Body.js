define(
({
	loadingInfo: "Жүктелуде...",
	emptyInfo: "Көрсетілетін элементтер жоқ",
	loadFailInfo: "Деректер жүктелмеді!"
})
);

