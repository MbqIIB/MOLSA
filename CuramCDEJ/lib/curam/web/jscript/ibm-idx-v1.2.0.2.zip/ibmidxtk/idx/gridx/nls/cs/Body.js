define(
({
	loadingInfo: "Probíhá načítání...",
	emptyInfo: "Nejsou žádné položky k zobrazení.",
	loadFailInfo: "Načtení dat se nezdařilo!"
})
);

