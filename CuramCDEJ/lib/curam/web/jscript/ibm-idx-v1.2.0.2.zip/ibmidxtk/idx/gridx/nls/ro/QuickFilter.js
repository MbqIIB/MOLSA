define(
({
	filterLabel: 'Filtru',
	clearButtonTitle: 'Ştergere filtru',
	buildFilterMenuLabel: 'Construire filtru&hellip;',
	apply: 'Aplicare filtru'
})
);

