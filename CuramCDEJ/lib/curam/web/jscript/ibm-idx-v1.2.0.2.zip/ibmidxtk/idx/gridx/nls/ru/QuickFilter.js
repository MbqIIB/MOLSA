define(
({
	filterLabel: 'Фильтр',
	clearButtonTitle: 'Очистить фильтр',
	buildFilterMenuLabel: 'Составить фильтр&hellip;',
	apply: 'Применить фильтр'
})
);

