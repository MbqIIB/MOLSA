define(
({
	singleSort: "单层排序",
	nestedSort: "嵌套排序",
	ascending: "单击以按升序排序",
	descending: "单击以按降序排序",
	sortingState: "${0} - ${1}",
	unsorted: "请勿对此列排序",
	waiSingleSortLabel: "${0} - 按照 ${1} 排序。选择此选项可按照 ${2} 排序",
	waiNestedSortLabel:"${0} - 按照 ${1} 嵌套排序。选择此选项可按照 ${2} 嵌套排序"
})
);

