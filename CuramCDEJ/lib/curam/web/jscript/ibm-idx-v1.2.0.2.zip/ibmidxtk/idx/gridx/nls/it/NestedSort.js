define(
({
	singleSort: "Ordinamento singolo",
	nestedSort: "Ordinamento nidificato",
	ascending: "Fare clic per ordinare in modo crescente",
	descending: "Fare clic per ordinare in modo decrescente",
	sortingState: "${0} - ${1}",
	unsorted: "Non ordinare questa colonna",
	waiSingleSortLabel: "${0} - ordinamento per ${1}. Scegliere l'ordinamento per ${2}",
	waiNestedSortLabel:"${0} - ordinamento nidificato per ${1}. Scegliere l'ordinamento nidificato per ${2}"
})
);

