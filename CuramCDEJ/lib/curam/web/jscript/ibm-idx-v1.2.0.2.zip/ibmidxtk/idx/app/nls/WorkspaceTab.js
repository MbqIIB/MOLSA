define({root:
//begin v1.x content
({
   	altTitle: "Workspace Tab for ${title}",
    	
   	eof: ""
})
//end v1.x content
,
"ar": true,
"fr": true,
"ja": true,
"ko": true,
"pt-br": true,
"zh-cn": true,
"zh-tw": true
});
