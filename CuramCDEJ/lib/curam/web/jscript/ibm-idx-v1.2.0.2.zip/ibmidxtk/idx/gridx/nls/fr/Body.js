define(
({
	loadingInfo: "Chargement...",
	emptyInfo: "Aucun élément à afficher",
	loadFailInfo: "Echec du chargement des données"
})
);

