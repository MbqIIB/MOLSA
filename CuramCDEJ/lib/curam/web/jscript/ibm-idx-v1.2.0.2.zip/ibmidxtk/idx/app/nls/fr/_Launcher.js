define(
//begin v1.x content
({
    unknownWorkspaceTypeError: "Impossible d'ouvrir l'espace de travail.  Son type est inconnu : ${workspaceTypeID}",

    tooManyOpenWorkspaces: "Impossible d'ouvrir plus de ${maxOpen} espaces de travail \"${workspaceTypeName}\".  Si possible, fermez les espaces de travail \"${workspaceTypeName}\" déjà ouverts."
})
//end v1.x content
);
