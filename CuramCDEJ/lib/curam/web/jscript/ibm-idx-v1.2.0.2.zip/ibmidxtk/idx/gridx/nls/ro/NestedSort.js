define(
({
	singleSort: "Sortare unică",
	nestedSort: "Sortare imbricată",
	ascending: "Faceţi clic pentru sortare Crescătoare",
	descending: "Faceţi clic pentru sortare Descrescătoare",
	sortingState: "${0} - ${1}",
	unsorted: "Să nu fie sortară această coloană",
	waiSingleSortLabel: "${0} - este sortată după ${1}. Alegeţi sortarea după ${2}",
	waiNestedSortLabel:"${0} - este sortată imbricat după ${1}. Alegeţi sortarea imbricată după ${2}"
})
);

