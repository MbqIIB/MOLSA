define(
({
	singleSort: "Sortowanie pojedyncze",
	nestedSort: "Sortowanie zagnieżdżone",
	ascending: "Kliknij, aby posortować rosnąco",
	descending: "Kliknij, aby posortować malejąco",
	sortingState: "${0} - ${1}",
	unsorted: "Nie sortuj tej kolumny",
	waiSingleSortLabel: "${0} - sortowanie wg wartości ${1}. Wybierz sortowanie wg wartości ${2}.",
	waiNestedSortLabel:"${0} - sortowanie zagnieżdżone wg wartości ${1}. Wybierz sortowanie zagnieżdżone wg wartości ${2}."
})
);

