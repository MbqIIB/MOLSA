define(
({
	summary: '총계: ${0}',
	summaryWithSelection: '총계: ${0} 선택됨: ${1}'
})
);

