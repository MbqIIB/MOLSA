define(
//begin v1.x content
({
    unknownWorkspaceTypeError: "ワークスペースを開けませんでした。ワークスペースのタイプが不明です: ${workspaceTypeID}",

    tooManyOpenWorkspaces: "${maxOpen} 個を超える数の \"${workspaceTypeName}\" ワークスペースを開くことはできません。可能であれば、既に開いている \"${workspaceTypeName}\" ワークスペースを閉じてください。"
})
//end v1.x content
);
