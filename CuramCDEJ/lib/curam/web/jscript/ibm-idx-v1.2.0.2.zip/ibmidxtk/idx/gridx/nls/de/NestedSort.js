define(
({
	singleSort: "Einfache Sortierung",
	nestedSort: "Verschachtelte Sortierung",
	ascending: "Für aufsteigende Sortierung hier klicken",
	descending: "Für absteigende Sortierung hier klicken",
	sortingState: "${0} - ${1}",
	unsorted: "Diese Spalte nicht sortieren",
	waiSingleSortLabel: "${0} ist sortiert nach ${1}. Wählen Sie die Sortierung nach ${2} aus.",
	waiNestedSortLabel:"${0} ist verschachtelt nach ${1} sortiert. Wählen Sie die verschachtelte Sortierung nach ${2} aus."
})
);

