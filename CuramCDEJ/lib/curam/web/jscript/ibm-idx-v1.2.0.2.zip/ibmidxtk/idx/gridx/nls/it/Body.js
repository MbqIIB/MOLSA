define(
({
	loadingInfo: "Caricamento in corso...",
	emptyInfo: "Nessun elemento da visualizzare",
	loadFailInfo: "Impossibile caricare i dati."
})
);

