define(
({
	loadingInfo: "正在載入...",
	emptyInfo: "無顯示項目",
	loadFailInfo: "無法載入資料！"
})
);

