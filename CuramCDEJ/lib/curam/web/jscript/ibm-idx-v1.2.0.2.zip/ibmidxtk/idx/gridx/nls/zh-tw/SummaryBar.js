define(
({
	summary: '總計︰${0}',
	summaryWithSelection: '總計︰${0} 選取︰${1}'
})
);

