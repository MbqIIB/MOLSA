define(
//begin v1.x content
({
    unknownWorkspaceTypeError: "无法打开工作空间。工作空间类型未知：${workspaceTypeID}",

    tooManyOpenWorkspaces: "无法打开超过 ${maxOpen} 个“${workspaceTypeName}”工作空间。如有可能，请关闭已打开的“${workspaceTypeName}”工作空间。"
})
//end v1.x content
);
