define(
({
	filterLabel: 'ตัวกรอง',
	clearButtonTitle: 'ลบตัวกรอง',
	buildFilterMenuLabel: 'ตัวกรองบิลด์&hellip;',
	apply: 'ใช้ตัวกรอง'
})
);

