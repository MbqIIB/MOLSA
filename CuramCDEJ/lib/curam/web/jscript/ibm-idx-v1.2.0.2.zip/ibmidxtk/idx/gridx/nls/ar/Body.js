define(
({
	loadingInfo: "تحميل...",
	emptyInfo: "لا يوجد بنود ليتم عرضها",
	loadFailInfo: "لم يتم تحميل البيانات بنجاح!"
})
);

