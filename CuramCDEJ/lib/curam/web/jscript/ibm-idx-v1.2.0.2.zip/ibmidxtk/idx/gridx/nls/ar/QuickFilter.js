define(
({
	filterLabel: '‏ترشيح البيانات‏',
	clearButtonTitle: 'محو ترشيح البيانات',
	buildFilterMenuLabel: 'بناء مرشح البيانات&hellip;',
	apply: 'تطبيق ترشيح البيانات'
})
);

