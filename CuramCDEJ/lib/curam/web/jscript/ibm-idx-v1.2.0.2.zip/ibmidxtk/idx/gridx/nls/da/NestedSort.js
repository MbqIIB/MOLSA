define(
({
	singleSort: "Enkelt sortering",
	nestedSort: "Indlejret sortering",
	ascending: "Klik for at sortere stigende",
	descending: "Klik for at sortere faldende",
	sortingState: "${0} - ${1}",
	unsorted: "Sortér ikke denne kolonne",
	waiSingleSortLabel: "${0} - er sorteret efter ${1}. Vælg for sortering efter ${2}",
	waiNestedSortLabel:"${0} - er indlejret sorteret efter ${1}. Vælg for indlejret sortering efter ${2}"
})
);

