define(
({
	summary: 'Celkem: ${0}',
	summaryWithSelection: 'Celkem: ${0}, vybráno: ${1}'
})
);

