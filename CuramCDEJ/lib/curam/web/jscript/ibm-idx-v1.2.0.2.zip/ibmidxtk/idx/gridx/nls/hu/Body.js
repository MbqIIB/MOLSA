define(
({
	loadingInfo: "Betöltés...",
	emptyInfo: "Nincsenek megjeleníthető elemek. ",
	loadFailInfo: "Nem sikerült az adatok betöltése!"
})
);

