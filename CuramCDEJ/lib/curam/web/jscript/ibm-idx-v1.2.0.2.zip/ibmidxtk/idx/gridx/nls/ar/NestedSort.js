define(
({
	singleSort: "فرز منفرد",
	nestedSort: "فرز متداخل",
	ascending: "اضغط ليتم الفرز تصاعديا",
	descending: "اضغط ليتم الفرز تنازليا",
	sortingState: "${0} - ${1}",
	unsorted: "عدم فرز هذا العمود",
	waiSingleSortLabel: "تم فرز ${0} - بواسطة ${1}. اختر ليتم الفرز بواسطة ${2}",
	waiNestedSortLabel:"${0} - متداخل وتم فرزه بواسطة ${1}. اختر ليتم التداخل والفرز بواسطة ${2}"
})
);

