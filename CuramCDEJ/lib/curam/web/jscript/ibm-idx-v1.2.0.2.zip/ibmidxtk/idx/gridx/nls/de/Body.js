define(
({
	loadingInfo: "Ladevorgang läuft...",
	emptyInfo: "Es sind keine anzuzeigenden Elemente vorhanden.",
	loadFailInfo: "Fehler beim Laden der Daten!"
})
);

