define(
({
	filterLabel: 'Φίλτρο',
	clearButtonTitle: 'Εκκαθάριση φίλτρου',
	buildFilterMenuLabel: 'Δημιουργία φίλτρου&hellip;',
	apply: 'Εφαρμογή φίλτρου'
})
);

