define(
({
	singleSort: "Jednoduché triedenie",
	nestedSort: "Vnorené triedenie",
	ascending: "Kliknutím aktivujete vzostupné zoradenie",
	descending: "Kliknutím aktivujete zostupné zoradenie",
	sortingState: "${0} - ${1}",
	unsorted: "Netriediť tento stĺpec",
	waiSingleSortLabel: "${0} - je zoradené podľa ${1}. Vyberte zoradenie podľa ${2}",
	waiNestedSortLabel:"${0} - je vnorené podľa ${1}. Vyberte vnorené zoradenie podľa ${2}"
})
);

