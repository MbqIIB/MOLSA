define(
//begin v1.x content
({
   titleTemplate: "${workspaceTypeName}",

   errorTooManyOpen: "يمكن فتح ${maxOpen} \"${workspaceTypeName}\" مساحة عمل في نفس الوقت.  برجاء اغلاق مساحة عمل أو أكثر.  ",

   loadingMessage: "جاري التحميل.  برجاء الانتظار...."

})
//end v1.x content
);

