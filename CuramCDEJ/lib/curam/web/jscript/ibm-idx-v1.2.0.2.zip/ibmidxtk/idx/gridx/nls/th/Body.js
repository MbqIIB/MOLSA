define(
({
	loadingInfo: "กำลังโหลด...",
	emptyInfo: "ไม่มีไอเท็มแสดง",
	loadFailInfo: "ล้มเหลวในการโหลดข้อมูล!"
})
);

