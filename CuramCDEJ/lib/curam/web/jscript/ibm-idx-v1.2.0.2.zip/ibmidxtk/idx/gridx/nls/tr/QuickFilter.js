define(
({
	filterLabel: 'Süzgeç',
	clearButtonTitle: 'Süzgeci Kaldır',
	buildFilterMenuLabel: 'Süzgeç Oluştur&hellip;',
	apply: 'Süzgeci Uygula'
})
);

