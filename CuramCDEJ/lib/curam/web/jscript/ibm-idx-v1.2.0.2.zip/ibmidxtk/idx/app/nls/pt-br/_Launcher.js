define(
//begin v1.x content
({
    unknownWorkspaceTypeError: "Não foi possível abrir a área de trabalho. O tipo de área de trabalho não é conhecido: ${workspaceTypeID}",

    tooManyOpenWorkspaces: "Não é possível abrir mais de ${maxOpen} \"${workspaceTypeName}\" áreas de trabalho. Se possível, feche \"${workspaceTypeName}\" áreas de trabalho que já estão abertas."
})
//end v1.x content
);
