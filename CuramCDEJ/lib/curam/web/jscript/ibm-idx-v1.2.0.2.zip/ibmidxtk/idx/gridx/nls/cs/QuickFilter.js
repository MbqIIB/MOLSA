define(
({
	filterLabel: 'Filtr',
	clearButtonTitle: 'Vymazat filtr',
	buildFilterMenuLabel: 'Sestavit filtr&hellip;',
	apply: 'Použít filtr'
})
);

