define(
({
	singleSort: "단일 정렬",
	nestedSort: "중첩된 정렬",
	ascending: "오름차순으로 정렬하려면 클릭",
	descending: "내림차순으로 정렬하려면 클릭",
	sortingState: "${0} - ${1}",
	unsorted: "이 컬럼을 정렬하지 않음",
	waiSingleSortLabel: "${0} - ${1}별로 정렬합니다. ${2}별로 정렬하려면 선택하십시오.",
	waiNestedSortLabel:"${0} - ${1}별로 중첩 정렬합니다. ${2}별로 중첩 정렬하려면 선택하십시오."
})
);

