define(
({
	summary: 'Total : ${0}',
	summaryWithSelection: 'Total : ${0} Sélectionnés : ${1}'
})
);

