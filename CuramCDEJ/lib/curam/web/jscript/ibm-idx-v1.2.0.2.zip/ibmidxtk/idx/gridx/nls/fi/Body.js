define(
({
	loadingInfo: "Lataus on meneillään...",
	emptyInfo: "Näytettäviä tietoja ei ole",
	loadFailInfo: "Tietojen lataus ei onnistunut."
})
);

