define(
({
	summary: 'Totale: ${0}',
	summaryWithSelection: 'Totale: ${0} Selezionati: ${1}'
})
);

