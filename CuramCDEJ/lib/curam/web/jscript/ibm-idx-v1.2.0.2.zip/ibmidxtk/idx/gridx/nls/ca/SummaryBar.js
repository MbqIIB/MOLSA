define(
({
	summary: 'Total: ${0}',
	summaryWithSelection: 'Total: ${0} Seleccionat: ${1}'
})
);

