define(
({
	loadingInfo: "A carregar...",
	emptyInfo: "Sem artigos a apresentar",
	loadFailInfo: "Falha ao carregar dados!"
})
);

