define(
({
	loadingInfo: "로드 중...",
	emptyInfo: "표시할 항목 없음",
	loadFailInfo: "데이터 로드에 실패했음!"
})
);

