define(
({
	loadingInfo: "Laster inn...",
	emptyInfo: "Ingen elementer å vise",
	loadFailInfo: "Kunne ikke laste inn data!"
})
);

