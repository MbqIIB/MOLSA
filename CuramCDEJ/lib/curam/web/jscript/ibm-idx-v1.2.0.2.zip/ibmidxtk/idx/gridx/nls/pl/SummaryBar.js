define(
({
	summary: 'Łącznie: ${0}',
	summaryWithSelection: 'Łącznie: ${0}. Wybrane: ${1}.'
})
);

