({
   titleTemplate: "${workspaceTypeName}",

   errorTooManyOpen: "Un maximum de ${maxOpen} espaces de travail \"${workspaceTypeName}\" peuvent être ouverts simultanément. Fermez un ou plusieurs espaces de travail pour continuer.",

   loadingMessage: "Chargement en cours. Veuillez patienter...."

})

