define(
({
	singleSort: "Egyszerű rendezés",
	nestedSort: "Beágyazott rendezés",
	ascending: "Kattintson ide a növekvő rendezéshez",
	descending: "Kattintson ide a csökkenő rendezéshez",
	sortingState: "${0} - ${1}",
	unsorted: "Ne rendezze ezt az oszlopot",
	waiSingleSortLabel: "${0} rendezve ${1} alapján. Válassza ki ${2} alapján történő rendezéshez. ",
	waiNestedSortLabel:"${0} egymásba ágyazottan rendezve ${1} alapján. Válassza ki ${2} alapján történő egymásba ágyazott rendezéshez. "
})
);

