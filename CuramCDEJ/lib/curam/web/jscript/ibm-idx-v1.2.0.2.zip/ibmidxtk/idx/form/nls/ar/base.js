define(
//begin v1.x content
({

})
//end v1.x content
);
