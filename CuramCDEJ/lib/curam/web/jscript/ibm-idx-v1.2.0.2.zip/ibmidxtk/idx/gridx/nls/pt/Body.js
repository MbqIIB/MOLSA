define(
({
	loadingInfo: "Carregando...",
	emptyInfo: "Nenhum item a exibir",
	loadFailInfo: "Falha ao carregar dados!"
})
);

