define(
({
	summary: 'ทั้งหมด: ${0}',
	summaryWithSelection: 'ทั้งหมด: ${0} ที่เลือก: ${1}'
})
);

