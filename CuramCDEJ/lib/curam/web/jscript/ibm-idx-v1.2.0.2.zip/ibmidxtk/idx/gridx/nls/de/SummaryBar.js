define(
({
	summary: 'Insgesamt: ${0}',
	summaryWithSelection: 'Insgesamt: ${0} Ausgewählt: ${1}'
})
);

