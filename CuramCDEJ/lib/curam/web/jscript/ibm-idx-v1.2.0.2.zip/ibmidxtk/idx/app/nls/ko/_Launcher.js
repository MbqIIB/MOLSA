define(
//begin v1.x content
({
    unknownWorkspaceTypeError: "작업공간을 열 수 없습니다. 알 수 없는 작업공간입니다. ${workspaceTypeID}",

    tooManyOpenWorkspaces: "${maxOpen} \"${workspaceTypeName}\" 보다 많은 작업공간을 열 수 없습니다. 가능하면 이미 열려 있는 \"${workspaceTypeName}\" 작업공간을 닫으십시오."
})
//end v1.x content
);
