define(
({
	summary: 'Totaal: ${0}',
	summaryWithSelection: 'Totaal: ${0} Geselecteerd: ${1}'
})
);

