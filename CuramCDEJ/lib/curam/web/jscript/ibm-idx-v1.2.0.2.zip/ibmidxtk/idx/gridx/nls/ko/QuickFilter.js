define(
({
	filterLabel: '필터',
	clearButtonTitle: '필터 지우기',
	buildFilterMenuLabel: '필터 빌드&hellip;',
	apply: '필터 적용'
})
);

