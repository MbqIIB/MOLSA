define(
//begin v1.x content
({
	// TODO: translate
})
//end v1.x content
);
