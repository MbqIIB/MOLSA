define(
({
	loadingInfo: "S'està carregant...",
	emptyInfo: "No hi ha cap element per visualitzar",
	loadFailInfo: "No s'han pogut carregar les dades"
})
);

