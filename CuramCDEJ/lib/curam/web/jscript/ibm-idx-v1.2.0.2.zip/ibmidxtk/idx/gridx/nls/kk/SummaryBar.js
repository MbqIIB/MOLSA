define(
({
	summary: 'Барлығы: ${0}',
	summaryWithSelection: 'Барлығы: ${0} Таңдалды: ${1}'
})
);

