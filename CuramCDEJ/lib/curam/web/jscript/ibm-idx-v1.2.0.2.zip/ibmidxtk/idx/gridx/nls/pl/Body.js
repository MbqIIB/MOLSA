define(
({
	loadingInfo: "Ładowanie...",
	emptyInfo: "Brak pozycji do wyświetlenia",
	loadFailInfo: "Nie powiodła się próba załadowania danych."
})
);

