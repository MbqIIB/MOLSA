define({root:
//begin v1.x content
({		
	unknownWorkspaceTypeError: "Workspace could not be opened.  Workspace type is not known: ${workspaceTypeID}",

    tooManyOpenWorkspaces: "Cannot open more than ${maxOpen} \"${workspaceTypeName}\"\u200e workspaces.  If possible, close \"${workspaceTypeName}\"\u200e workspaces that are already open.",
    
    eof: ""
})
//end v1.x content
,
"ar": true,
"fr": true,
"ja": true,
"ko": true,
"pt-br": true,
"zh-cn": true,
"zh-tw": true
});
