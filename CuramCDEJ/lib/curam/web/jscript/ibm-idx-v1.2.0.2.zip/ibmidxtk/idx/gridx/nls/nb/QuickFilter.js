define(
({
	filterLabel: 'Filter',
	clearButtonTitle: 'Tøm filter',
	buildFilterMenuLabel: 'Bygg filter&hellip;',
	apply: 'Bruk filter'
})
);

