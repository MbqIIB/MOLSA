define(
({
	loadingInfo: "Φόρτωση...",
	emptyInfo: "Δεν υπάρχουν στοιχεία για παρουσίαση",
	loadFailInfo: "Απέτυχε η φόρτωση δεδομένων!"
})
);

