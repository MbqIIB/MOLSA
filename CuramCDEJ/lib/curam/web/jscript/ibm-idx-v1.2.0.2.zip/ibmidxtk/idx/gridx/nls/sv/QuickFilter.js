define(
({
	filterLabel: 'Filter',
	clearButtonTitle: 'Rensa filter',
	buildFilterMenuLabel: 'Bygg filter&hellip;',
	apply: 'Använd filter'
})
);

