define(
({
	singleSort: "Enkeltsortering",
	nestedSort: "Nestet sortering",
	ascending: "Klikk for å sortere stigende",
	descending: "Klikk for å sortere synkende",
	sortingState: "${0} - ${1}",
	unsorted: "Ikke sorter denne kolonnen",
	waiSingleSortLabel: "${0} - er sortert etter ${1}. Velg å sortere etter ${2}",
	waiNestedSortLabel:"${0} - er sortert med nestet sortering etter ${1}. Velg å sortere med nestet sortering etter ${2}"
})
);

