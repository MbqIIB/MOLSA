define(
({
	filterLabel: 'Filtro',
	clearButtonTitle: 'Limpar Filtro',
	buildFilterMenuLabel: 'Construir Filtro&hellip;',
	apply: 'Aplicar Filtro'
})
);

