define(
//begin v1.x content
({
   titleTemplate: "${workspaceTypeName}",

   errorTooManyOpen: "一次最多可以開啟 ${maxOpen} \"${workspaceTypeName}\" 個工作區。請先關閉一個以上工作區。",

   loadingMessage: "載入中。請稍候...."

})
//end v1.x content
);
