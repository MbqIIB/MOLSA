define(
({
	filterLabel: 'Suodata',
	clearButtonTitle: 'Tyhjennä suodatin',
	buildFilterMenuLabel: 'Muodosta suodatin&hellip;',
	apply: 'Käytä suodatinta'
})
);

