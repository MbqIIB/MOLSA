define(
({
	filterLabel: 'Filter',
	clearButtonTitle: 'Ryd filter',
	buildFilterMenuLabel: 'Byg filter&hellip;',
	apply: 'Anvend filter'
})
);

