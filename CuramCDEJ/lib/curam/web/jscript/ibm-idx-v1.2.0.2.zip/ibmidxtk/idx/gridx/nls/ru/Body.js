define(
({
	loadingInfo: "Загрузка...",
	emptyInfo: "Нет ни одного элемента",
	loadFailInfo: "Не удалось загрузить данные!"
})
);

