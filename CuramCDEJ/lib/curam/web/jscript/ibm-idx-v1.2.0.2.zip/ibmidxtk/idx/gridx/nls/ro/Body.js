define(
({
	loadingInfo: "Încărcare...",
	emptyInfo: "Nu există articole de afişat",
	loadFailInfo: "Încărcarea datelor a eşuat!"
})
);

