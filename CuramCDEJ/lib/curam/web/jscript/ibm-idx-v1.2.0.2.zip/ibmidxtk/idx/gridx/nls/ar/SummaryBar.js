define(
({
	summary: 'الاجمالي: ${0}',
	summaryWithSelection: 'الاجمالي: ${0} المحدد: ${1}'
})
);

