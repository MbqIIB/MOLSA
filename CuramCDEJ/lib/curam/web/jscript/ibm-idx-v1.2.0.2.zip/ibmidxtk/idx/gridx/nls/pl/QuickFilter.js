define(
({
	filterLabel: 'Filtr',
	clearButtonTitle: 'Wyczyść filtr',
	buildFilterMenuLabel: 'Utwórz filtr&hellip;',
	apply: 'Zastosuj filtr'
})
);

