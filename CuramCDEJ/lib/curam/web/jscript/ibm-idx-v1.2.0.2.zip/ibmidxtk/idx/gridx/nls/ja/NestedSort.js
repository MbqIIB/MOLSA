define(
({
	singleSort: "単一ソート",
	nestedSort: "入れ子ソート",
	ascending: "クリックすると昇順でソート",
	descending: "クリックすると降順でソート",
	sortingState: "${0} - ${1}",
	unsorted: "この列をソートしない",
	waiSingleSortLabel: "${0} - ${1} でソートされています。${2} でソートを選択",
	waiNestedSortLabel:"${0} - ${1} でソートされ、ネストされています。${2} でソートしてネストすることを選択"
})
);

