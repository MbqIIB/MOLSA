define(
({
	summary: '总数：${0}',
	summaryWithSelection: '总数：${0} 已选择：${1}'
})
);

