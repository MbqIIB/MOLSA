define(
({
	singleSort: "Enkel sortering",
	nestedSort: "Nästlad sortering",
	ascending: "Klicka för att sortera i stigande ordning",
	descending: "Klicka för att sortera i fallande ordning",
	sortingState: "${0} - ${1}",
	unsorted: "Sortera inte den här kolumnen",
	waiSingleSortLabel: "${0} - sorteras efter ${1}. Välj för att sortera efter ${2}",
	waiNestedSortLabel:"${0} - är nästlat sorterat efter ${1}. Välj för nästlad sortering efter ${2}"
})
);

