define(
({
	summary: 'I alt: ${0}',
	summaryWithSelection: 'I alt: ${0} Valgt: ${1}'
})
);

