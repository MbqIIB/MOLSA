define(
({
	loadingInfo: "Načítavanie...",
	emptyInfo: "Žiadne položky na zobrazenie",
	loadFailInfo: "Zlyhalo načítavanie údajov!"
})
);

