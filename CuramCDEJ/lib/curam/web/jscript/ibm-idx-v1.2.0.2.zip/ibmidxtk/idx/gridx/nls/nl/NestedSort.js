define(
({
	singleSort: "Enkelvoudig sorteren",
	nestedSort: "Genest sorteren",
	ascending: "Klik hier voor oplopend sorteren",
	descending: "Klik hier voor aflopend sorteren",
	sortingState: "${0} - ${1}",
	unsorted: "Deze kolom niet sorteren",
	waiSingleSortLabel: "${0} - is gesorteerd op ${1}. Kies om te sorteren op ${2}",
	waiNestedSortLabel:"${0} - is genest gesorteerd op ${1}. Kies om genest te sorteren op ${2}"
})
);

