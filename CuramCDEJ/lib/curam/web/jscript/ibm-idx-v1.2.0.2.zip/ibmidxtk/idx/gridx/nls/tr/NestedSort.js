define(
({
	singleSort: "Tekli Sıralama",
	nestedSort: "İç İçe Sıralama",
	ascending: "Artan Sırada sıralamak için tıklatın",
	descending: "Azalan Sırada sıralamak için tıklatın",
	sortingState: "${0} - ${1}",
	unsorted: "Bu sütunu sıralama",
	waiSingleSortLabel: "${0} - ${1} öğesine göre sıralanmış. ${2} öğesine göre sıralamak için bu seçeneği belirleyin",
	waiNestedSortLabel:"${0} - ${1} öğesine göre sıralanmış olarak iç içe düzenlenmiş. ${2} öğesine göre sıralanmış olarak iç içe düzenlemek için bu seçeneği belirleyin"
})
);

