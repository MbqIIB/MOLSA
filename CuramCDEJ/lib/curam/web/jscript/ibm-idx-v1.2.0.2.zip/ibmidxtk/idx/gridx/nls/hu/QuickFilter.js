define(
({
	filterLabel: 'Szűrő',
	clearButtonTitle: 'Szűrő törlése',
	buildFilterMenuLabel: 'Szűrő összeállítása&hellip;',
	apply: 'Szűrő alkalmazása'
})
);

