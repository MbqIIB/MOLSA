define(
({
	loadingInfo: "正在装入...",
	emptyInfo: "没有要显示的项",
	loadFailInfo: "装入数据失败！"
})
);

