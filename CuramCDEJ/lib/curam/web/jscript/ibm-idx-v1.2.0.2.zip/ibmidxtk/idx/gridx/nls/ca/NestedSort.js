define(
({
	singleSort: "Ordre únic",
	nestedSort: "Ordre imbricat",
	ascending: "Feu clic per ordenar de forma ascendent",
	descending: "Feu clic per ordenar de forma descendent",
	sortingState: "${0} - ${1}",
	unsorted: "No ordenis aquesta finestra",
	waiSingleSortLabel: "${0} - s'ha ordenat per ${1}. Trieu que s'ordeni per ${2}",
	waiNestedSortLabel:"${0} - s'ha ordenat de forma imbricada per ${1}. Trieu que s'ordeni de forma imbricada per ${2}"
})
);

