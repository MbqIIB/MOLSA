define(
({
	loadingInfo: "Indlæser...",
	emptyInfo: "Der er ingen elementer at vise",
	loadFailInfo: "Kan ikke indlæse data."
})
);

