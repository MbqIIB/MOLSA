define(
({
	singleSort: "Ordenação única",
	nestedSort: "Ordenação imbricada",
	ascending: "Faça clique para ordenar Ascendente",
	descending: "Faça clique para ordenar Descendente",
	sortingState: "${0} - ${1}",
	unsorted: "Não ordenar esta coluna",
	waiSingleSortLabel: "${0} - está ordenado por ${1}. Seleccionar ordenar por ${2}",
	waiNestedSortLabel:"${0} - é ordenação imbricada por ${1}. Seleccionar ordenação imbricada por ${2}"
})
);

