define(
({
	filterLabel: 'Сүзгі',
	clearButtonTitle: 'Сүзгіні тазалау',
	buildFilterMenuLabel: 'Сүзгі жасау&hellip;',
	apply: 'Сүзгі қолдану'
})
);

