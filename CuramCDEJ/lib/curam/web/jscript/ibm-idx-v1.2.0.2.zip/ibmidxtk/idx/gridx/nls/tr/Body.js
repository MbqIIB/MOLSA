define(
({
	loadingInfo: "Yükleniyor...",
	emptyInfo: "Görüntülenecek öğe yok",
	loadFailInfo: "Veriler yüklenemedi!"
})
);

