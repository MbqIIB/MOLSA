define(
({
	filterLabel: 'Filter',
	clearButtonTitle: 'Počisti filter',
	buildFilterMenuLabel: 'Zgradi filter&hellip;',
	apply: 'Uveljavi filter'
})
);

