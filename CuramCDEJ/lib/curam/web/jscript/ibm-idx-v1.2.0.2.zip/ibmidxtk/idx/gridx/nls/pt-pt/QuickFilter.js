define(
({
	filterLabel: 'Filtro',
	clearButtonTitle: 'Limpar filtro',
	buildFilterMenuLabel: 'Construir filtro&hellip;',
	apply: 'Aplicar filtro'
})
);

