define(
({
	filterLabel: 'Filter',
	clearButtonTitle: 'Zrušiť filter',
	buildFilterMenuLabel: 'Vytvoriť filter&hellip;',
	apply: 'Použiť filter'
})
);

