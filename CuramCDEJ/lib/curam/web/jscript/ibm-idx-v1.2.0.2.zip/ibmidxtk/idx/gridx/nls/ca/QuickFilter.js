define(
({
	filterLabel: 'Filtre',
	clearButtonTitle: 'Netejar el filtre',
	buildFilterMenuLabel: 'Muntar el filtre&hellip;',
	apply: 'Aplicar el filtre'
})
);

