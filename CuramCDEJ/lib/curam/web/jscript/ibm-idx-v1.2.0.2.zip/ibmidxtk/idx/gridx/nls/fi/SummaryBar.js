define(
({
	summary: 'Kokonaismäärä: ${0}',
	summaryWithSelection: 'Kokonaismäärä: ${0} Valitut: ${1}'
})
);

