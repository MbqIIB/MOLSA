define(
({
	summary: 'Toplam: ${0}',
	summaryWithSelection: 'Toplam: ${0} Seçilen: ${1}'
})
);

