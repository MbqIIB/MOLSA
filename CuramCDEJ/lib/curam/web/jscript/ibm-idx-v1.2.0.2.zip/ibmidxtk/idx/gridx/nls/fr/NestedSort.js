define(
({
	singleSort: "Tri unique",
	nestedSort: "Tri imbriqué",
	ascending: "Cliquer pour trier par ordre croissant",
	descending: "Cliquer pour trier par ordre décroissant",
	sortingState: "${0} - ${1}",
	unsorted: "Ne pas trier cette colonne",
	waiSingleSortLabel: "${0} - est trié par ${1}. Choisir de trier par ${2}",
	waiNestedSortLabel:"${0} - est trié imbriqué par ${1}. Choisir de trier imbriqué par ${2}"
})
);

