define(
({
	singleSort: "Classificação Única",
	nestedSort: "Classificação Aninhada",
	ascending: "Clique para classificar de modo Crescente",
	descending: "Clique para classificar de modo Decrescente",
	sortingState: "${0} - ${1}",
	unsorted: "Não classificar esta coluna",
	waiSingleSortLabel: "${0} - é classificado por ${1}. Escolha classificar por ${2}",
	waiNestedSortLabel:"${0} - é classificado aninhado por ${1}. Escolha classificar aninhado por ${2}"
})
);

