define(
//begin v1.x content
({
    unknownWorkspaceTypeError: "無法開啟工作區。工作區類型不明：${workspaceTypeID}",

    tooManyOpenWorkspaces: "無法開啟超過 ${maxOpen} 個 \"${workspaceTypeName}\" 工作區。如果可能的話，請關閉已開啟的 \"${workspaceTypeName}\" 工作區。"
})
//end v1.x content
);
