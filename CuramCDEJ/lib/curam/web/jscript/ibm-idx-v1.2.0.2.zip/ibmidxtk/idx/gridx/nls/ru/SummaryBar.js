define(
({
	summary: 'Всего: ${0}',
	summaryWithSelection: 'Всего: ${0} Выбрано: ${1}'
})
);

