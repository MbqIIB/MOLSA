define(
({
	singleSort: "Enostavno razvrščanje",
	nestedSort: "Ugnezdeno razvrščanje",
	ascending: "Kliknite za naraščajoče razvrščanje",
	descending: "Kliknite za padajoče razvrščanje",
	sortingState: "${0} - ${1}",
	unsorted: "Ne razvrščaj tega stolpca",
	waiSingleSortLabel: "${0} - je razvrščeno po ${1}. Izberite za razvrščanje po ${2}",
	waiNestedSortLabel:"${0} - je ugnezdeno razvrščeno po ${1}. Izberite za ugnezdeno razvrščanje po ${2}"
})
);

