define(
"dijit/nls/th/common", //begin v1.x content
({
	buttonOk: "ตกลง",
	buttonCancel: "ยกเลิก",
	buttonSave: "บันทึก",
	itemClose: "ปิด"
})

//end v1.x content
);
