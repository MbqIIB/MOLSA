define(
"dijit/form/nls/ro/validate", //begin v1.x content
({
	invalidMessage: "Valoarea introdusă nu este validă.",
	missingMessage: "Această valoare este necesară.",
	rangeMessage: "Această valoare este în afara intervalului. "
})

//end v1.x content
);
