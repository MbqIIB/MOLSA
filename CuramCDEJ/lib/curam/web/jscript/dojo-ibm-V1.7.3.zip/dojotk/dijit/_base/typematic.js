define("dijit/_base/typematic", ["../typematic"], function(){
	// for back-compat, just loads top level module
});
