define(
"dijit/form/nls/tr/ComboBox", //begin v1.x content
({
		previousMessage: "Önceki seçenekler",
		nextMessage: "Diğer seçenekler"
})
//end v1.x content
);
