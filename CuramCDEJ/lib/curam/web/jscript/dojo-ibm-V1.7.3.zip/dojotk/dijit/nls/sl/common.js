define(
"dijit/nls/sl/common", //begin v1.x content
({
	buttonOk: "V redu",
	buttonCancel: "Prekliči",
	buttonSave: "Shrani",
	itemClose: "Zapri"
})

//end v1.x content
);
