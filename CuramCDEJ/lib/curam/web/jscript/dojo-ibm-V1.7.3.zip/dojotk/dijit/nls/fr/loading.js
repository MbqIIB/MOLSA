define(
"dijit/nls/fr/loading", //begin v1.x content
({
	loadingState: "Chargement...",
	errorState: "Une erreur est survenue"
})
//end v1.x content
);
