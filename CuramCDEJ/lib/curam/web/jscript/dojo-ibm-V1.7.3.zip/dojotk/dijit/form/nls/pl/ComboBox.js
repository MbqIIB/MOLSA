define(
"dijit/form/nls/pl/ComboBox", //begin v1.x content
({
		previousMessage: "Poprzednie wybory",
		nextMessage: "Więcej wyborów"
})
//end v1.x content
);
