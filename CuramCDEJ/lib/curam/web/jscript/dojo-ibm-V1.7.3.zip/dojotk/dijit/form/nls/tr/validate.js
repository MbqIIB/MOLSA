define(
"dijit/form/nls/tr/validate", //begin v1.x content
({
	invalidMessage: "Girilen değer geçersiz.",
	missingMessage: "Bu değer gerekli.",
	rangeMessage: "Bu değer aralık dışında."
})
//end v1.x content
);
