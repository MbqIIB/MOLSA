define(
"dijit/form/nls/it/ComboBox", //begin v1.x content
({
		previousMessage: "Scelte precedenti",
		nextMessage: "Altre scelte"
})
//end v1.x content
);
