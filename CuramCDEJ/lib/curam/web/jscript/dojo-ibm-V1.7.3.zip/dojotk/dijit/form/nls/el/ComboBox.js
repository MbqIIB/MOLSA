define(
"dijit/form/nls/el/ComboBox", //begin v1.x content
({
		previousMessage: "Προηγούμενες επιλογές",
		nextMessage: "Περισσότερες επιλογές"
})
//end v1.x content
);
