//>>built
define("dijit/place",["dojo/_base/array","dojo/dom-geometry","dojo/dom-style","dojo/_base/kernel","dojo/_base/window","dojo/window",".","dojo/_base/lang"],function(_1,_2,_3,_4,_5,_6,_7,_8){
function _9(_a,_b,_c,_d){
var _e=_6.getBox();
if(!_a.parentNode||String(_a.parentNode.tagName).toLowerCase()!="body"){
_5.body().appendChild(_a);
}
var _f=null;
_1.some(_b,function(_10){
var _11=_10.corner;
var pos=_10.pos;
var _12=0;
var _13={w:{"L":_e.l+_e.w-pos.x,"R":pos.x-_e.l,"M":_e.w}[_11.charAt(1)],h:{"T":_e.t+_e.h-pos.y,"B":pos.y-_e.t,"M":_e.h}[_11.charAt(0)]};
if(_c){
var res=_c(_a,_10.aroundCorner,_11,_13,_d);
_12=typeof res=="undefined"?0:res;
}
var _14=_a.style;
var _15=_14.display;
var _16=_14.visibility;
if(_14.display=="none"){
_14.visibility="hidden";
_14.display="";
}
var mb=_2.getMarginBox(_a);
_14.display=_15;
_14.visibility=_16;
var _17={"L":pos.x,"R":pos.x-mb.w,"M":Math.max(_e.l,Math.min(_e.l+_e.w,pos.x+(mb.w>>1))-mb.w)}[_11.charAt(1)],_18={"T":pos.y,"B":pos.y-mb.h,"M":Math.max(_e.t,Math.min(_e.t+_e.h,pos.y+(mb.h>>1))-mb.h)}[_11.charAt(0)],_19=Math.max(_e.l,_17),_1a=Math.max(_e.t,_18),_1b=Math.min(_e.l+_e.w,_17+mb.w),_1c=Math.min(_e.t+_e.h,_18+mb.h),_1d=_1b-_19,_1e=_1c-_1a;
_12+=(mb.w-_1d)+(mb.h-_1e);
var l=_2.isBodyLtr();
if(_8.exists("curam.widget.DeferredDropDownButton.prototype.useCustomPlaceAlgorithm")&&curam.widget.DeferredDropDownButton.prototype.useCustomPlaceAlgorithm==true){
if((_11.charAt(0)=="T"||(_11.charAt(1)=="L"&&l)||(_11.charAt(1)=="R"&&!l))&&_12>0){
_12=mb.w+mb.h;
}
}
if(_f==null||_12<_f.overflow){
_f={corner:_11,aroundCorner:_10.aroundCorner,x:_19,y:_1a,w:_1d,h:_1e,overflow:_12,spaceAvailable:_13};
}
return !_12;
});
if(_f.overflow&&_c){
_c(_a,_f.aroundCorner,_f.corner,_f.spaceAvailable,_d);
}
var l=_2.isBodyLtr(),s=_a.style;
s.top=_f.y+"px";
s[l?"left":"right"]=(l?_f.x:_e.w-_f.x-_f.w)+"px";
s[l?"right":"left"]="auto";
return _f;
};
return (_7.place={at:function(_1f,pos,_20,_21){
var _22=_1.map(_20,function(_23){
var c={corner:_23,pos:{x:pos.x,y:pos.y}};
if(_21){
c.pos.x+=_23.charAt(1)=="L"?_21.x:-_21.x;
c.pos.y+=_23.charAt(0)=="T"?_21.y:-_21.y;
}
return c;
});
return _9(_1f,_22);
},around:function(_24,_25,_26,_27,_28){
var _29=(typeof _25=="string"||"offsetWidth" in _25)?_2.position(_25,true):_25;
if(_25.parentNode){
var _2a=_3.getComputedStyle(_25).position=="absolute";
var _2b=_25.parentNode;
while(_2b&&_2b.nodeType==1&&_2b.nodeName!="BODY"){
var _2c=_2.position(_2b,true),pcs=_3.getComputedStyle(_2b);
if(/relative|absolute/.test(pcs.position)){
_2a=false;
}
if(!_2a&&/hidden|auto|scroll/.test(pcs.overflow)){
var _2d=Math.min(_29.y+_29.h,_2c.y+_2c.h);
var _2e=Math.min(_29.x+_29.w,_2c.x+_2c.w);
_29.x=Math.max(_29.x,_2c.x);
_29.y=Math.max(_29.y,_2c.y);
_29.h=_2d-_29.y;
_29.w=_2e-_29.x;
}
if(pcs.position=="absolute"){
_2a=true;
}
_2b=_2b.parentNode;
}
}
var x=_29.x,y=_29.y,_2f="w" in _29?_29.w:(_29.w=_29.width),_30="h" in _29?_29.h:(_4.deprecated("place.around: dijit.place.__Rectangle: { x:"+x+", y:"+y+", height:"+_29.height+", width:"+_2f+" } has been deprecated.  Please use { x:"+x+", y:"+y+", h:"+_29.height+", w:"+_2f+" }","","2.0"),_29.h=_29.height);
var _31=[];
function _32(_33,_34){
_31.push({aroundCorner:_33,corner:_34,pos:{x:{"L":x,"R":x+_2f,"M":x+(_2f>>1)}[_33.charAt(1)],y:{"T":y,"B":y+_30,"M":y+(_30>>1)}[_33.charAt(0)]}});
};
_1.forEach(_26,function(pos){
var ltr=_27;
switch(pos){
case "above-centered":
_32("TM","BM");
break;
case "below-centered":
_32("BM","TM");
break;
case "after-centered":
ltr=!ltr;
case "before-centered":
_32(ltr?"ML":"MR",ltr?"MR":"ML");
break;
case "after":
ltr=!ltr;
case "before":
_32(ltr?"TL":"TR",ltr?"TR":"TL");
_32(ltr?"BL":"BR",ltr?"BR":"BL");
break;
case "below-alt":
ltr=!ltr;
case "below":
_32(ltr?"BL":"BR",ltr?"TL":"TR");
_32(ltr?"BR":"BL",ltr?"TR":"TL");
break;
case "above-alt":
ltr=!ltr;
case "above":
_32(ltr?"TL":"TR",ltr?"BL":"BR");
_32(ltr?"TR":"TL",ltr?"BR":"BL");
break;
default:
_32(pos.aroundCorner,pos.corner);
}
});
var _35=_9(_24,_31,_28,{w:_2f,h:_30});
_35.aroundNodePos=_29;
return _35;
}});
});
