//>>built
define("dijit/form/nls/sk/ComboBox",({previousMessage:"Predchádzajúce voľby",nextMessage:"Ďalšie voľby"}));
