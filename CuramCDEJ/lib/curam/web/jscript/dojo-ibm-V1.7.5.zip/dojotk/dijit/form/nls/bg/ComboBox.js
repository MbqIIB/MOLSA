//>>built
define("dijit/form/nls/bg/ComboBox",({previousMessage:"Предишни избори",nextMessage:"Повече избори"}));
