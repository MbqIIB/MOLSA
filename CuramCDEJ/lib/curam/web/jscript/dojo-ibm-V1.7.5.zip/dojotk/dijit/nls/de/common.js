//>>built
define("dijit/nls/de/common",({buttonOk:"OK",buttonCancel:"Abbrechen",buttonSave:"Speichern",itemClose:"Schließen"}));
