//>>built
define("dijit/nls/sv/loading",({loadingState:"Läser in...",errorState:"Det uppstod ett fel."}));
