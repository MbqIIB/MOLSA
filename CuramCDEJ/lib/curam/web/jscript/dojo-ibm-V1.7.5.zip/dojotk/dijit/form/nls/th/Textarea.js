//>>built
define("dijit/form/nls/th/Textarea",({iframeEditTitle:"แก้ไขพื้นที่",iframeFocusTitle:"แก้ไขกรอบพื้นที่"}));
