//>>built
define("dijit/nls/sk/loading",({loadingState:"Zavádzanie...",errorState:"Nastala chyba"}));
