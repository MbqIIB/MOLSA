/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidencebroker.ws.publiclayer.bs.impl;


import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.text.ParseException;
import java.util.Map;

import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.google.inject.Inject;

import curam.codetable.CASETYPECODE;
import curam.codetable.CONCERNROLESTATUS;
import curam.codetable.OPERATIONNAME;
import curam.codetable.impl.TARGETSYSTEMSTATUSEntry;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ExternalCaseHeaderFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRole;
import curam.core.intf.ExternalCaseHeader;
import curam.core.intf.UniqueID;
import curam.core.sl.impl.CaseTypeEvidence;
import curam.core.sl.infrastructure.impl.WSConvertBSConst;
import curam.core.sl.struct.KeyValuePair;
import curam.core.sl.struct.SharedEvidenceDescriptorDetails;
import curam.core.struct.ConcernRoleAlternateReadKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ExternalCaseHeaderDtls;
import curam.core.ws.convert.utils.impl.ConversionUtil;
import curam.core.ws.convert.utils.impl.ResponseManager;
import curam.ctm.targetsystem.impl.TargetSystem;
import curam.ctm.targetsystem.impl.TargetSystemDAO;
import curam.evidencebroker.impl.EvidenceBrokerConst;
import curam.evidencebroker.sl.fact.EvidenceBrokerFactory;
import curam.evidencebroker.sl.intf.EvidenceBroker;
import curam.message.BPOEVIDENCEBROKER;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;


/**
 * Sharing of evidence from the source system is received in the destination
 * system through the web service.
 *
 */

public abstract class EvdBrokerWebService extends curam.evidencebroker.ws.publiclayer.bs.base.EvdBrokerWebService {

  @Inject
  protected TargetSystemDAO targetSystemDAO;

  @Inject
  protected Map<String, CaseTypeEvidence> caseTypeEvidenceMap;

  public static final String kWebServiceCategory = Trace.kDefaultTraceCategory
    + CuramConst.gkWebServiceCategory;

  public static final Logger kWebServiceLogger = Logger.getLogger(
    kWebServiceCategory);

  /**
   * Default constructor for the class.
   */
  public EvdBrokerWebService() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Receives the inbound evidence share document from the source system.
   *
   * @param document Contains the Inbound DOM document.
   *
   * @return The Outbound response DOM document.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public Document receiveChangeNotification(Document xmlMessage)
    throws AppException, InformationalException {

    validateDocument(xmlMessage);

    // Retrieve the case type code from the document and pass it to get the
    // case type specific object instance
    Document responseDocument = processChangeNotification(xmlMessage);

    return responseDocument;
  }

  /**
   * Process the evidence details received from a remote system to a source
   * system.
   *
   * @param document Contains the inbound document
   *
   * @return The response document
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public Document processChangeNotification(final Document document)
    throws AppException, InformationalException {

    // Create the response manager to control the response to each result
    ResponseManager responseManager = new ResponseManager();

    // Iterate through the document to populate the structs
    final Element root = document.getDocumentElement();

    if ((root.getNodeType() == Node.ELEMENT_NODE)
      && (nodeName(root).equalsIgnoreCase(WSConvertBSConst.kEvidence))) {

      SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails = null;
      ExternalCaseHeaderDtls externalCaseHeaderDtls = null;
      ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

      responseManager.setup(WSConvertBSConst.kEvidenceShare);

      // Iterate through all the details found within the documents list node
      for (Node child = root.getFirstChild(); child != null; child = child.getNextSibling()) {

        if ((child.getNodeType() == Node.ELEMENT_NODE)
          && (nodeName(child).equalsIgnoreCase(WSConvertBSConst.kEvidenceData))) {

          // Set the exception catEntry value, before the try block
          responseManager.addSection();
          try {
            for (Node evidenceDataChild = child.getFirstChild(); evidenceDataChild
              != null; evidenceDataChild = evidenceDataChild.getNextSibling()) {

              if (evidenceDataChild.getNodeType() == Node.ELEMENT_NODE) {

                // Check, if the sub element is evidenceDetails
                if (nodeName(evidenceDataChild).equalsIgnoreCase(
                  WSConvertBSConst.kEvidenceDetails)) {

                  // read the participant details from the document.
                  concernRoleDtls = readParticipantDetails(evidenceDataChild);

                  // BEGIN, CR00295214, ELG
                  // Nothing needs to be done if we do not find the participant.
                  if (concernRoleDtls == null) {
                    break;
                  }
                  // END, CR00295214

                  // Populate the attributes details from the document to
                  // sharedEvidenceDescriptorDetails.
                  sharedEvidenceDescriptorDetails = readSharedEvidenceDescriptorDetails(
                    evidenceDataChild);
                  sharedEvidenceDescriptorDetails.details.participantID = concernRoleDtls.concernRoleID;
                  sharedEvidenceDescriptorDetails.details.externalSourceCaseInd = true;

                  // Populate the details to externalCaseHeaderDtls from the
                  // document and insert the details into externalCaseHeader.
                  externalCaseHeaderDtls = createExternalCaseDetails(
                    evidenceDataChild);
                  sharedEvidenceDescriptorDetails.details.caseID = externalCaseHeaderDtls.externalCaseID;

                  // Set the source system ID
                  sharedEvidenceDescriptorDetails.sourceSystemID = externalCaseHeaderDtls.sourceSystemID;

                } else if (nodeName(evidenceDataChild).equalsIgnoreCase(
                  WSConvertBSConst.kDataObjects)) {

                  // Populate the attributes details from the document.
                  readDataObjectDetails(evidenceDataChild,
                    sharedEvidenceDescriptorDetails);
                }
              }
            }

            EvidenceBroker evidenceBroker = EvidenceBrokerFactory.newInstance();

            if (sharedEvidenceDescriptorDetails.operation.equals(
              OPERATIONNAME.CREATE)) {
              evidenceBroker.shareExternalEvidence(
                sharedEvidenceDescriptorDetails);
            } else if (sharedEvidenceDescriptorDetails.operation.equals(
              OPERATIONNAME.REMOVE)) {
              evidenceBroker.shareExternalEvidenceRemoval(
                sharedEvidenceDescriptorDetails);

            }
            // Set the success attribute.
            responseManager.setSuccess(true);
          } catch (Exception e) {
            kWebServiceLogger.error(e.getLocalizedMessage(), e); // Logger
          }
        }
      }
    }
    return responseManager.getResponseDocument();
  }

  /**
   * Read the local node name where possible. Otherwise read the node name (i.e.
   * local node name excludes any namespace prefix).
   *
   * @param node Contains the node
   *
   * @return The local node name, the node name or an empty string
   */
  protected String nodeName(Node node) {
    String result = CuramConst.gkEmpty;

    if (node.getLocalName() != null) {
      result = node.getLocalName();
    } else {
      result = node.getNodeName();
    }
    return result;
  }

  /**
   * Read the details from the document node and assign it to shared evidence
   * descriptor details for evidence sharing.
   *
   * @param evidenceDetailsNode Contains the inbound document node.
   *
   * @return The evidence details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected SharedEvidenceDescriptorDetails readSharedEvidenceDescriptorDetails(
    Node evidenceDetailsNode) throws AppException, InformationalException {
    SharedEvidenceDescriptorDetails sharedEvidenceDescriptorReturnDetails = new SharedEvidenceDescriptorDetails();

    if (evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE) {
      Element evidenceDetailsElement = (Element) evidenceDetailsNode;

      // Iterate through the document node and get the required details.
      for (Node evidenceDetailChildNode = evidenceDetailsElement.getFirstChild(); evidenceDetailChildNode
        != null; evidenceDetailChildNode = evidenceDetailChildNode.getNextSibling()) {

        if ((evidenceDetailsNode != null)
          && (evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE)) {
          Element eDetailChildElement = (Element) evidenceDetailChildNode;
          String eDetailChildValue = eDetailChildElement.getFirstChild().getNodeValue().trim();

          if (nodeName(eDetailChildElement).equalsIgnoreCase(
            WSConvertBSConst.kCaseType)) {
            sharedEvidenceDescriptorReturnDetails.sourceType = eDetailChildValue;
          } else if (nodeName(eDetailChildElement).equalsIgnoreCase(
            WSConvertBSConst.kReceivedDate)) {
            sharedEvidenceDescriptorReturnDetails.details.effectiveFrom = convertToDateFormat(
              eDetailChildValue);
          } else if (nodeName(eDetailChildElement).equalsIgnoreCase(
            WSConvertBSConst.kEffectiveDate)) {
            sharedEvidenceDescriptorReturnDetails.details.effectiveFrom = convertToDateFormat(
              eDetailChildValue);
          } else if (nodeName(eDetailChildElement).equalsIgnoreCase(
            WSConvertBSConst.kSharedinstanceID)) {
            sharedEvidenceDescriptorReturnDetails.details.sharedInstanceID = Long.parseLong(
              eDetailChildValue.trim());
          } else if (nodeName(eDetailChildElement).equalsIgnoreCase(
            WSConvertBSConst.kEvidenceType)) {
            sharedEvidenceDescriptorReturnDetails.details.evidenceType = eDetailChildValue;
          } else if (nodeName(eDetailChildElement).equalsIgnoreCase(
            WSConvertBSConst.kOperation)) {
            sharedEvidenceDescriptorReturnDetails.operation = eDetailChildValue;
          } else if (nodeName(eDetailChildElement).equalsIgnoreCase(
            WSConvertBSConst.kCaseSubType)) {

            CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
              sharedEvidenceDescriptorReturnDetails.sourceType);

            if (null == caseTypeEvidence) {
              AppException e = new AppException(
                BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

              e.arg(
                CodeTable.getOneItem(CASETYPECODE.TABLENAME,
                sharedEvidenceDescriptorReturnDetails.sourceType,
                TransactionInfo.getProgramLocale()));
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
                e,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                35);

            }
            sharedEvidenceDescriptorReturnDetails.sourceID = caseTypeEvidence.getSubTypeID(
              eDetailChildValue);

          }
        }
      }
    }
    return sharedEvidenceDescriptorReturnDetails;
  }

  /**
   * Create an external case header record by reading the details from the
   * document received from an external system.
   *
   * @param evidenceDetailsNode Contains the inbound document node.
   *
   * @return The external case details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected ExternalCaseHeaderDtls createExternalCaseDetails(
    Node evidenceDetailsNode) throws AppException, InformationalException {
    ExternalCaseHeaderDtls externalCaseHeaderDtls = new ExternalCaseHeaderDtls();

    if (evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE) {
      Element evidenceDetailsElement = (Element) evidenceDetailsNode;

      // Iterate through the document node and get the required details.
      for (Node evidenceDetailChildNode = evidenceDetailsElement.getFirstChild(); evidenceDetailChildNode
        != null; evidenceDetailChildNode = evidenceDetailChildNode.getNextSibling()) {

        if ((evidenceDetailsNode != null)
          && (evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE)) {
          Element eDetailChildElement = (Element) evidenceDetailChildNode;
          String eDetailChildValue = eDetailChildElement.getFirstChild().getNodeValue().trim();

          if (nodeName(eDetailChildElement).equalsIgnoreCase(
            WSConvertBSConst.kCaseID)) {
            externalCaseHeaderDtls.caseNumber = eDetailChildValue;
          } else if (nodeName(eDetailChildElement).equalsIgnoreCase(
            WSConvertBSConst.kCaseType)) {
            externalCaseHeaderDtls.caseType = eDetailChildValue;
          } else if (nodeName(eDetailChildElement).equalsIgnoreCase(
            WSConvertBSConst.kCaseSubType)) {
            externalCaseHeaderDtls.caseSubType = eDetailChildValue;
          } else if (nodeName(eDetailChildElement).equalsIgnoreCase(
            WSConvertBSConst.kSourceSystemName)) {
            String targetSystemName = eDetailChildValue;

            final TargetSystem targetSystem = targetSystemDAO.readByTargetSystemNameAndStatus(
              TARGETSYSTEMSTATUSEntry.ACTIVE, targetSystemName);

            externalCaseHeaderDtls.sourceSystemID = targetSystem.getID();
          }
        }
      }
    }
    ExternalCaseHeader externalCaseHeaderObj = ExternalCaseHeaderFactory.newInstance();
    UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    externalCaseHeaderDtls.externalCaseID = uniqueIDObj.getNextID();
    externalCaseHeaderObj.insert(externalCaseHeaderDtls);

    return externalCaseHeaderDtls;
  }

  /**
   * Read the participant details from the document node received from a remote
   * system.
   *
   * @param evidenceDetailsNode Contains the inbound document node.
   *
   * @return The participant details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected ConcernRoleDtls readParticipantDetails(Node evidenceDetailsNode)
    throws AppException, InformationalException {

    if (evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE) {
      Element evidenceDetailsElement = (Element) evidenceDetailsNode;

      NodeList nodes = evidenceDetailsElement.getElementsByTagName(
        WSConvertBSConst.kParticipantNumber);
      String participantNumber = nodes.item(0).getFirstChild().getNodeValue().trim();

      ConcernRoleAlternateReadKey concernRoleAlternateReadKey = new ConcernRoleAlternateReadKey();

      concernRoleAlternateReadKey.primaryAlternateID = participantNumber;
      concernRoleAlternateReadKey.statusCode = CONCERNROLESTATUS.CURRENT;
      ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

      try {
        return concernRoleObj.readByAlternateID(concernRoleAlternateReadKey);
      } catch (RecordNotFoundException rnfe) {
        return null;
      }

    }
    return null;
  }

  /**
   * Read the evidence data item details from the document node and assign it to
   * shared evidence descriptor details for evidence sharing.
   *
   * @param evidenceDetailsNode Contains the inbound document node.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected void readDataObjectDetails(Node evidenceDetailsNode,
    SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails) {

    if (evidenceDetailsNode.getNodeType() == Node.ELEMENT_NODE) {

      Element dataObjectsElement = (Element) evidenceDetailsNode;

      for (Node dataItemNode = dataObjectsElement.getFirstChild(); dataItemNode
        != null; dataItemNode = dataItemNode.getNextSibling()) {
        if (dataItemNode.getNodeType() == Node.ELEMENT_NODE) {
          KeyValuePair keyValuePair = new KeyValuePair();

          // Cast the dataItem element from the node.
          final Element dataItemElement = (Element) dataItemNode;

          if (nodeName(dataItemElement).equalsIgnoreCase(
            WSConvertBSConst.kDataItem)) {

            // Set the data item name.
            keyValuePair.name = dataItemElement.getAttribute(
              WSConvertBSConst.kName);

            if (dataItemElement.getFirstChild() != null
              && dataItemNode.getFirstChild().getNodeType() == Node.TEXT_NODE) {
              // Set the data item value.
              keyValuePair.value = dataItemElement.getFirstChild().getNodeValue().trim();
            }
            sharedEvidenceDescriptorDetails.keyList.addRef(keyValuePair);

          }
        }
      }
    }
  }

  /**
   * Convert the string value to curam date format.
   *
   * @param eDetailChildValue Contains the string date format.
   *
   * @return the curam date format
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected Date convertToDateFormat(String eDetailChildValue)
    throws AppException, InformationalException {
    ConversionUtil conversionUtil = new ConversionUtil();
    Date date = new Date();

    try {
      date = conversionUtil.toCuramDate(eDetailChildValue);
    } catch (ParseException pe) {
      AppException appException = new AppException(
        BPOEVIDENCEBROKER.ERR_EVIDENCE_BROKER_INCORRECT_DATE_FORMAT);

      throw appException;
    }
    return date;
  }

  /**
   * Validates the evidence sharing xml document with the schema provided
   * for the inbound web service.
   *
   * @param xmlMessage Contains the inbound DOM document.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void validateDocument(Document xmlMessage) throws AppException,
      InformationalException {
    try {
      final Schema schema = getSchema(EvidenceBrokerConst.kSchemaFile);
      final Validator validator = schema.newValidator();

      validator.validate(new DOMSource(xmlMessage));
    } catch (SAXException e) {
      AppException appException = new AppException(
        BPOEVIDENCEBROKER.ERR_EVIDENCE_SHARING_XML_DOCUMENT_INVALID_WITH_SCHEMA,
        e);

      throw appException;
    } catch (IOException e) {// Ignore this error as schema file will always be present.
    }
  }

  /**
   * Gets the schema file from the file disk for the initial access and stores
   * it in a collection for future access.
   *
   * @param fileName
   * Contains the name of the schema file that needs to be loaded.
   *
   * @return the schema against which the change set xml document would be
   * validated.
   *
   * @throws SAXException
   * Generic Exception Signature.
   */
  protected Schema getSchema(final String fileName) throws SAXException {

    // Create a SchemaFactory capable of understanding WXS schema.
    final SchemaFactory factory = SchemaFactory.newInstance(
      XMLConstants.W3C_XML_SCHEMA_NS_URI);
    final Source schemaContentsAsSource;

    String schemaStr = getResource(fileName);

    schemaContentsAsSource = new StreamSource(new StringReader(schemaStr));

    final Schema schema = factory.newSchema(schemaContentsAsSource);

    return schema;
  }

  /**
   * Gets a resource from the class path as a string reader.
   *
   * @param resourceName
   * The name of the resource to retrieve.
   * @return The file contents as a string.
   */
  protected String getResource(final String resourceName) {

    String resource = null;

    try {
      final InputStream inputStream = EvdBrokerWebService.class.getResourceAsStream(
        resourceName);
      final ByteArrayOutputStream out = new ByteArrayOutputStream(
        EvidenceBrokerConst.kByteOutputStreamSize);
      final byte[] buffer = new byte[EvidenceBrokerConst.kByteBufferSize];
      int k = 0;

      while ((k = inputStream.read(buffer)) != -1) {
        out.write(buffer, 0, k);
      }
      resource = out.toString(GeneralConstants.kUTF8);
      inputStream.close();
    } catch (final IOException e) {
      throw new AppRuntimeException(e);
    }

    return resource;
  }

}
