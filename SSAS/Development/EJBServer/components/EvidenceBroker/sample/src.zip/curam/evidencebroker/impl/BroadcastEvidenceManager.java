/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidencebroker.impl;


import java.lang.reflect.Method;

import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.evidencebroker.sl.fact.BroadcastEvidenceFactory;
import curam.evidencebroker.sl.intf.BroadcastEvidence;
import curam.message.BPOBROADCASTEVIDENCEREGISTRAR;
import curam.util.exception.AppException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;


/**
 * Central class to handle the creation of broadcast evidence hook based on a
 * particular product type.
 */
public final class BroadcastEvidenceManager {

  /**
   * Retrieves the map containing a subclass of the BroadcastEvidence class
   * for each case type.
   *
   * @return The map containing a subclass of the BroadcastEvidence class
   * for each case type.
   */
  public static BroadcastEvidenceRegistrar.HookMap get() {
    return broadcastEvidenceMap;
  }

  /**
   * The map containing a subclass of the BroadcastEvidence class for each
   * case type.
   */
  // BEGIN, CR00198200, GYH
  protected static BroadcastEvidenceRegistrar.HookMap broadcastEvidenceMap = GuiceWrapper.getInjector().getInstance(
    BroadcastEvidenceRegistrar.HookMap.class);
  // END, CR00198200


  // Static initialization of the Evidence Broadcast Hook Map
  static {

    // Get the value of the evidence broadcast registrars environment
    // variable
    String registrarsString = (Configuration.getProperty(
      EnvVars.ENV_BROADCASTEVIDENCE_REGISTRARS_LIST));

    if (null != registrarsString) {

      // Get comma-separated list of registrar factory class names
      String registrarFactoryNames[] = registrarsString.split(
        CuramConst.gkComma);

      for (int i = 0; i < registrarFactoryNames.length; i++) {

        String registrarFactoryName = registrarFactoryNames[i];

        try {
          Class registrarFactoryClass = Class.forName(registrarFactoryName);

          Method newInstance = registrarFactoryClass.getMethod(
            ReflectionConst.kNewInstance, new Class[0]);

          Object registrar = newInstance.invoke(null, new Object[0]);

          if (registrar instanceof BroadcastEvidenceRegistrar) {

            BroadcastEvidenceRegistrar evidenceBroadcastRegistrar = (BroadcastEvidenceRegistrar) registrar;

            // Register the Broadcast Evidence Classes
            evidenceBroadcastRegistrar.register();
          }
        } catch (Exception e) {

          AppException ae = new AppException(
            BPOBROADCASTEVIDENCEREGISTRAR.ERR_REGISTRAR_ISSUE);

          throw new RuntimeException(ae);
        }
      } // end for i
    }
  }

  /**
   * Gets the implementation subclass of the BroadcastEvidence class for the
   * specified case type.
   *
   * @param type The type of the case
   *
   * @return The implementation subclass of the BroadcastEvidence class for
   * the specified product type.
   *
   * @throws AppException Generic Exception Signature.
   */
  public static BroadcastEvidence getHook(final String type)
    throws AppException {

    BroadcastEvidence result = (BroadcastEvidence) broadcastEvidenceMap.createHookInstance(
      type, BroadcastEvidence.class);

    if (null == result) {
      result = BroadcastEvidenceFactory.newInstance();
    }

    return result;
  }
}
