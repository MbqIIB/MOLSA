/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008, 2012-2013, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidencebroker.sl.impl;


import java.io.IOException;
import java.io.StringReader;

import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.codetable.CONCERNROLETYPE;
import curam.core.intf.ConcernRole;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.message.PDCEVIDENCEDESCRIPTION;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASETYPECODE;
import curam.codetable.EVIDENCECHANGETYPE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.EVIDENCESHARINGTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SYNCHRONIZATIONACTION;
import curam.codetable.VERIFICATIONSHAREOPTION;
import curam.codetable.impl.CASEEVIDENCEEntry;
import curam.codetable.impl.EVIDENCEBROKEREVENTTYPEEntry;
import curam.codetable.impl.EVIDENCEDESCRIPTORSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.events.EVIDENCEBROKER;
import curam.core.facade.infrastructure.struct.EvidenceParticipantDtls;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ExternalCaseHeaderFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.DateValueList;
import curam.core.impl.EvidenceUpdatesAllowed;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.MaintainCase;
import curam.core.sl.entity.struct.CaseIDAndStatusKey;
import curam.core.sl.impl.CaseTypeEvidence;
import curam.core.sl.impl.LocalizableXMLStringHelper;
import curam.core.sl.impl.VerificationInterface;
import curam.core.sl.infrastructure.entity.fact.EvidenceChangeHistoryFactory;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceChangeHistoryDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKeyList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorStatusDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.PendingRemovalIndAndVersionNo;
import curam.core.sl.infrastructure.entity.struct.PendingUpdateIndAndVersionNo;
import curam.core.sl.infrastructure.entity.struct.SharedInstanceIDCaseIDStatusCodes;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EvidenceController;
import curam.core.sl.infrastructure.impl.EvidenceMap;
import curam.core.sl.infrastructure.impl.EvidenceVerification;
import curam.core.sl.infrastructure.impl.StandardEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.EvidencePeriod;
import curam.core.sl.infrastructure.struct.EvidenceTypeAndDesc;
import curam.core.sl.infrastructure.struct.EvidenceTypeAndDescList;
import curam.core.sl.infrastructure.struct.EvidenceVerificationDetailsList;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.EvidenceCaseKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.ExternalCaseHeaderDtls;
import curam.core.struct.ExternalCaseHeaderKey;
import curam.evidence.impl.EvidenceTypeNature;
import curam.evidencebroker.facade.struct.SynchronizeEvidenceDetails;
import curam.evidencebroker.impl.EvidenceBrokerConst;
import curam.evidencebroker.impl.EvidenceBrokerUtils;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerConfigDtls;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerConfigDtlsList;
import curam.evidencebroker.sl.entity.struct.EvidenceSharingConfigKey;
import curam.evidencebroker.sl.fact.EvidenceBrokerConfigAdminFactory;
import curam.evidencebroker.sl.struct.EvidenceDescriptorIDAndSynchronizeAction;
import curam.evidencebroker.sl.struct.EvidenceDescriptorIDAndSynchronizeActionList;
import curam.evidencebroker.sl.struct.IdenticalEvidenceDetailsAndAction;
import curam.evidencebroker.sl.struct.IdenticalEvidenceDetailsAndActionList;
import curam.evidencebroker.sl.struct.IdenticalSharedEvidenceDetails;
import curam.evidencebroker.sl.struct.IdenticalSharedEvidenceDetailsList;
import curam.evidencebroker.sl.struct.IncomingEvidenceAndSourceCaseDetails;
import curam.evidencebroker.sl.struct.IncomingEvidenceAndSourceCaseDetailsList;
import curam.evidencebroker.sl.struct.IncomingEvidenceDetails;
import curam.evidencebroker.sl.struct.IncomingEvidenceDetailsList;
import curam.evidencebroker.sl.struct.SharedEvidenceSourceTypeAndSourceIDDetails;
import curam.evidencebroker.sl.struct.SynchronizeIdenticalEvidenceDetails;
import curam.evidencebroker.sl.struct.SynchronizeNonIdenticalEvidenceDetails;
import curam.message.BPOADDRESS;
import curam.message.BPOEVIDENCEBROKER;
import curam.message.BPOEVIDENCEBROKERSYNCHRONIZATION;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.message.GENERALCASE;
import curam.util.dataaccess.KeyRepository;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.StringList;
import curam.verification.sl.infrastructure.entity.fact.VDIEDLinkFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationItemProvidedFactory;
import curam.verification.sl.infrastructure.entity.intf.VDIEDLink;
import curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkAndDataItemIDDetails;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkAndDataItemIDDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDAndStatusKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey;
import curam.verification.sl.infrastructure.fact.CurrentPostponedVerificationFactory;
import curam.verification.sl.infrastructure.impl.DeferredVerificationProcessBehaviour;
import curam.verification.sl.infrastructure.impl.VerificationConst;
import curam.verification.sl.infrastructure.struct.CurrentPostponedVerificationDtlsList;
import curam.verification.sl.infrastructure.struct.TargetEvidenceDescriptorKey;


/**
 * This process class provides the functionality for the evidence sharing
 * synchronization service layer. The synchronization functionality is used to
 * synchronize shared evidence records onto a case.
 */
public abstract class EvidenceBrokerSynchronization extends curam.evidencebroker.sl.base.EvidenceBrokerSynchronization {

  /**
   * This list will hold all the <code>effective from</code> dates that we
   * accept onto the case. We do not allow multiple in edit records with the
   * same effective from date to be accepted at the same time. It is a
   * handcrafted struct and therefore cannot be modeled as a parameter or return
   * value.
   */
  protected DateValueList effectiveDateList = new DateValueList();

  /**
   * A hash map reference of the case evidence type module which is registered
   * in the registry.
   */
  @Inject
  protected Map<String, CaseTypeEvidence> caseTypeEvidenceMap;

  // BEGIN, CR00341649, GYH
  /**
   * Reference to a helper class {@link ProcessEvidenceHelper}.
   */
  @Inject
  protected ProcessEvidenceHelper processEvidenceHelper;

  // END, CR00341649

  // BEGIN, CR00343380, RPB
  /**
   * A reference for {@link EvidenceVerification}.
   */
  @Inject
  protected EvidenceVerification evidenceVerification;

  // END, CR00343380

  /**
   * Default constructor for the class.
   */
  public EvidenceBrokerSynchronization() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00120268, KH
  // BEGIN, CR00236468, GYH
  /**
   * @param synchronizeEvidenceDetails
   * Contains the details for synchronization.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#processIdenticalIncomingEvidence(EvidenceDescriptorIDAndSynchronizeActionList)}
   * and
   * {@link EvidenceBrokerSynchronization#processNonIdenticalIncomingEvidence(EvidenceDescriptorKeyList)}
   * . This method has been deprecated because as part of evidence
   * broker usability changes the list evidence synchronization
   * screen has been enhanced to simple identical and non identical
   * incoming evidence list screens and hence now identical, non
   * identical incoming evidence are processed separately. Also,
   * there is no widget processing is involved. See release
   * note:CR00236468.
   *
   * This method synchronizes the identical and non identical shared
   * evidence records. The identical evidence records may be
   * accepted, rejected or ignored. The non identical evidence
   * records may be resolved or ignored. When synchronization is
   * fully complete any outstanding synchronization tasks will be
   * closed.
   */
  @Deprecated
  public void synchronizeEvidence(
    final SynchronizeEvidenceDetails synchronizeEvidenceDetails)
    throws AppException, InformationalException {

    // Synchronize the identical evidence records
    SynchronizeIdenticalEvidenceDetails identicalEvidenceDetails = new SynchronizeIdenticalEvidenceDetails();

    identicalEvidenceDetails.identicalEvidenceList = synchronizeEvidenceDetails.identicalEvidenceList;

    CaseHeaderKey identicalCaseHeaderKey = synchronizeIdenticalEvidence(
      identicalEvidenceDetails);

    // Synchronize the non identical evidence records
    SynchronizeNonIdenticalEvidenceDetails nonIdenticalEvidenceDetails = new SynchronizeNonIdenticalEvidenceDetails();

    nonIdenticalEvidenceDetails.nonIdenticalEvidenceList = synchronizeEvidenceDetails.nonIdenticalEvidenceList;

    CaseHeaderKey nonIdenticalCaseHeaderKey = synchronizeNonIdenticalEvidence(
      nonIdenticalEvidenceDetails);

    // Close case participant creation task if it exists and all evidence on
    // the
    // case has been synchronized. Use the case id from either case header
    // key
    if (identicalCaseHeaderKey.caseID != 0) {
      closeCaseParticipantCreationSynchronizationTask(identicalCaseHeaderKey);
    } else if (nonIdenticalCaseHeaderKey.caseID != 0) {
      closeCaseParticipantCreationSynchronizationTask(nonIdenticalCaseHeaderKey);
    }
  }

  // BEGIN, CR00119649, CR00120556, KH, CW
  /**
   * @param identicalEvidenceDetails
   * Contains the identical shared evidence details to be synchronized.
   *
   * @return The ID of the case being synchronized.
   *
   * @throws AppException
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  // END, CR00236468
  public CaseHeaderKey synchronizeIdenticalEvidence(
    final SynchronizeIdenticalEvidenceDetails identicalEvidenceDetails)
    throws AppException, InformationalException {

    // Initialize return object
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Extract the evidence ID and the associated action from the XML
    // string.
    // This method only returns evidence which has been actioned.
    EvidenceDescriptorIDAndSynchronizeActionList evidenceIDAndActionList = extractEvidenceIDAndActionList(
      identicalEvidenceDetails);

    validateIdenticalEvidenceSynchronization(evidenceIDAndActionList);

    IdenticalSharedEvidenceDetailsList sortedEvidenceList = groupEvidenceBySharedInstanceID(
      evidenceIDAndActionList);

    for (int i = 0; i < sortedEvidenceList.dtlsList.size(); i++) {
      processIdenticalEvidenceGroup(sortedEvidenceList.dtlsList.item(i));
    }

    // Raise any errors reported during the synchronization
    TransactionInfo.getInformationalManager().failOperation();

    // Determine the case id of the case being synchronized. This will be
    // used
    // to close any outstanding synchronize task if all evidence is
    // synchronized
    if (!sortedEvidenceList.dtlsList.isEmpty()) {

      // Retrieve the case id from the first evidence group in the list
      caseHeaderKey.caseID = sortedEvidenceList.dtlsList.item(0).caseID;
    }

    return caseHeaderKey;
  }

  // END, CR00236468

  // ___________________________________________________________________________
  /**
   * This method parses the identical evidence XML details into an XML document
   * and then extracts each evidence id / action pair from the XML into a list.
   * Any evidence which is neither accepted or rejected is ignored.
   *
   * @param identicalEvidenceDetails
   * Contains the identical evidence details to be extracted.
   *
   * @return A list of evidence IDs with the associated synchronize action.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected EvidenceDescriptorIDAndSynchronizeActionList extractEvidenceIDAndActionList(
    final SynchronizeIdenticalEvidenceDetails identicalEvidenceDetails)
    throws AppException, InformationalException {

    EvidenceDescriptorIDAndSynchronizeActionList evidenceIDAndActionList = new EvidenceDescriptorIDAndSynchronizeActionList();

    // Get the evidence synchronization information in XML format for
    // parsing
    Document calendarXMLDocument = buildXMLDocumentFromString(
      identicalEvidenceDetails.identicalEvidenceList);

    if (calendarXMLDocument != null) {
      Element docElement = calendarXMLDocument.getDocumentElement();

      for (Node childNode = docElement.getFirstChild(); childNode != null; childNode = childNode.getNextSibling()) {

        if (childNode.getNodeName().trim().equalsIgnoreCase(
          EvidenceBrokerConst.kEvidenceID)) {

          Element idElement = (Element) childNode;

          EvidenceDescriptorIDAndSynchronizeAction evidenceIDAndAction = new EvidenceDescriptorIDAndSynchronizeAction();

          evidenceIDAndAction.evidenceDescriptorID = Long.parseLong(
            idElement.getAttribute(EvidenceBrokerConst.kID).trim());
          evidenceIDAndAction.action = idElement.getAttribute(EvidenceBrokerConst.kValue).trim();

          // We are only interested in evidence for which there is an
          // action
          if (!evidenceIDAndAction.action.equals(EvidenceBrokerConst.kNull)) {

            // Add the evidence ID and synchronize action to our
            // list
            evidenceIDAndActionList.dtlsList.addRef(evidenceIDAndAction);
          }
        }
      } // end for childNode
    }

    return evidenceIDAndActionList;
  }

  // ___________________________________________________________________________
  /**
   * This method performs validation on the list of identical shared evidence.
   * The validation checks that the evidence has not been both accepted and
   * rejected.
   *
   * @param evidenceIDAndActionList
   * A list of evidence IDs with the associated synchronize action.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected void validateIdenticalEvidenceSynchronization(
    final EvidenceDescriptorIDAndSynchronizeActionList evidenceIDAndActionList)
    throws AppException, InformationalException {

    // Use a temp list in this method since we are removing entries
    EvidenceDescriptorIDAndSynchronizeActionList tempEvidenceIDAndActionList = new EvidenceDescriptorIDAndSynchronizeActionList();

    tempEvidenceIDAndActionList.assign(evidenceIDAndActionList);

    // Create an informational manager
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    // If the same ID appears twice in the list it means that both the
    // accepted
    // and the rejected options were selected. This is not allowed.
    for (int i = 0; i < tempEvidenceIDAndActionList.dtlsList.size(); i++) {

      // Get the first evidence ID
      long firstEvidenceDescriptorID = tempEvidenceIDAndActionList.dtlsList.item(0).evidenceDescriptorID;

      // Loop through the rest of the list
      for (int j = 1; j < tempEvidenceIDAndActionList.dtlsList.size(); j++) {

        // If the same ID occurs again - throw error
        if (firstEvidenceDescriptorID
          == tempEvidenceIDAndActionList.dtlsList.item(j).evidenceDescriptorID) {

          evidenceDescriptorKey.evidenceDescriptorID = firstEvidenceDescriptorID;

          EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj.read(
            evidenceDescriptorKey);

          AppException e = new AppException(
            BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_IDENTICAL_EVIDENCE_XFV_ACCEPT_REJECT);

          // Add the evidence type to the error message
          // BEGIN, CR00163098, JC
          e.arg(
            CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
            evidenceDescriptorDtls.evidenceType,
            TransactionInfo.getProgramLocale()));
          // END, CR00163098, JC

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            e.arg(true), CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
        }
      } // end for j

      // Remove the first evidence ID from the list
      tempEvidenceIDAndActionList.dtlsList.remove(i);
      i--; // When (i) is removed the rest of the list drops down one -
      // this
      // decrement ensures we don't skip any evidence
    } // end for i

    // informationalManager.failOperation();
  }

  // ___________________________________________________________________________
  /**
   * This method sorts the identical shared evidence into groups with the same
   * shared instance ID. Within each group there will be sub-lists of 'new',
   * 'updated' and 'removed' shared evidence.
   *
   * @param evidenceIDAndActionList
   * A list of evidence IDs with the associated synchronize action.
   *
   * @return A sorted list of identical shared evidence, grouped by shared
   * instance ID.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected IdenticalSharedEvidenceDetailsList groupEvidenceBySharedInstanceID(
    final EvidenceDescriptorIDAndSynchronizeActionList evidenceIDAndActionList)
    throws AppException, InformationalException {

    IdenticalSharedEvidenceDetailsList sortedEvidenceList = new IdenticalSharedEvidenceDetailsList();

    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    // Add each piece of evidence to our list, grouped by shared instance ID
    for (int i = 0; i < evidenceIDAndActionList.dtlsList.size(); i++) {

      IdenticalSharedEvidenceDetails evidenceGroup = new IdenticalSharedEvidenceDetails();

      // Read the evidence details
      EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = evidenceIDAndActionList.dtlsList.item(i).evidenceDescriptorID;
      EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj.read(
        evidenceDescriptorKey);

      boolean newSharedInstanceID = true;

      // Can we match this shared instance ID with one already in our
      // list?
      for (int j = 0; j < sortedEvidenceList.dtlsList.size(); j++) {

        if (sortedEvidenceList.dtlsList.item(j).sharedInstanceID
          == evidenceDescriptorDtls.sharedInstanceID) {

          newSharedInstanceID = false;
          evidenceGroup = sortedEvidenceList.dtlsList.item(j);
        }
      } // end for j

      // This is a new shared instance ID, add a new group
      if (newSharedInstanceID) {

        evidenceGroup.sharedInstanceID = evidenceDescriptorDtls.sharedInstanceID;
        evidenceGroup.caseID = evidenceDescriptorDtls.caseID;
        sortedEvidenceList.dtlsList.addRef(evidenceGroup);
      }

      IdenticalEvidenceDetailsAndAction evidenceAndAction = new IdenticalEvidenceDetailsAndAction();

      evidenceAndAction.dtls = evidenceDescriptorDtls;
      evidenceAndAction.action.synchronizeAction = evidenceIDAndActionList.dtlsList.item(i).action;

      // File this piece of evidence and it's sync action as appropriate
      if (evidenceDescriptorDtls.pendingRemovalInd) {
        evidenceGroup.removeList.dtlsList.addRef(evidenceAndAction);
      } else if (evidenceDescriptorDtls.newInd) {
        evidenceGroup.newList.dtlsList.addRef(evidenceAndAction);
      } else {
        evidenceGroup.updateList.dtlsList.addRef(evidenceAndAction);
      }
    } // end for i

    return sortedEvidenceList;
  }

  // BEGIN, CR00122108, KH
  // ___________________________________________________________________________
  /**
   * This method processes a group of identical shared evidence records which
   * are being synchronized onto the case. Each piece of evidence in the group
   * has the same <code>shared instance ID</code>. Within each group the
   * evidence removals are processed first followed by the new evidence and
   * finally the updated evidence.
   *
   * @param details
   * The identical shared evidence group to be processed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void processIdenticalEvidenceGroup(
    final IdenticalSharedEvidenceDetails details) throws AppException,
      InformationalException {

    // Clear the list of effective from dates so there are no clashes with
    // the
    // current shared evidence group
    effectiveDateList.clear();

    processIdenticalEvidenceRemovalList(details);

    processIdenticalEvidenceNewList(details.newList);

    processIdenticalEvidenceUpdateList(details.updateList);
  }

  // ___________________________________________________________________________
  /**
   * This method processes a list of identical shared evidence 'removal' records
   * which are being synchronized onto the case.
   *
   * @param details
   * Contains the identical shared removal evidence to be processed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected void processIdenticalEvidenceRemovalList(
    final IdenticalSharedEvidenceDetails details) throws AppException,
      InformationalException {

    // Create an informational manager
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // BEGIN, CR00128112, ELG
    // Evidence descriptor object
    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    // Evidence descriptor key
    EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    // Evidence descriptor details
    EvidenceDescriptorDtls evidenceDescriptorDtls;

    // Used to update the evidence status after processing
    EvidenceDescriptorStatusDtls evidenceDescriptorStatusDtls = new EvidenceDescriptorStatusDtls();

    // END, CR00128112

    // Process evidence removals first
    for (int r = 0; r < details.removeList.dtlsList.size(); r++) {

      SharedInstanceIDCaseIDStatusCodes sharedInstanceCaseIDKey = new SharedInstanceIDCaseIDStatusCodes();

      sharedInstanceCaseIDKey.caseID = details.caseID;
      sharedInstanceCaseIDKey.sharedInstanceID = details.sharedInstanceID;

      // BEGIN, CR00128822, CW
      // Flag to indicate there is an active shared record already on the
      // case
      boolean isSharedActiveRecordOnCase = false;

      EvidenceDescriptorDtlsList identicalEvidenceList = evidenceDescriptorObj.searchBySharedInstanceIDCaseIDStatusCodes(
        sharedInstanceCaseIDKey);

      // Drop the non accepted records as they will be in the other lists
      for (int i = 0; i < identicalEvidenceList.dtls.size(); i++) {

        if (identicalEvidenceList.dtls.item(i).statusCode.equals(
          EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT)) {

          identicalEvidenceList.dtls.remove(i);
          i--; // When (i) is removed the rest of the list drops down
          // one - this
          // decrement ensures we don't skip any evidence
        } else if (identicalEvidenceList.dtls.item(i).statusCode.equals(
          EVIDENCEDESCRIPTORSTATUS.ACTIVE)) {

          // There is an active shared record already on the case
          isSharedActiveRecordOnCase = true;
        }
        // END, CR00128822
      } // end for i

      if (details.removeList.dtlsList.item(r).action.synchronizeAction.equals(
        SYNCHRONIZATIONACTION.ACCEPT)) {

        // If there are no records on the case and the 'new' and
        // 'update' lists
        // are empty then we can't accept any removals
        if (identicalEvidenceList.dtls.size() == 0
          && details.newList.dtlsList.size() == 0
          && details.updateList.dtlsList.size() == 0) {

          AppException e = new AppException(
            BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_IDENTICAL_EVIDENCE_ACCEPT_XRV_REMOVAL_NOT_VALID);

          // Add the evidence type to the error message
          // BEGIN, CR00163098, JC
          e.arg(
            CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
            details.removeList.dtlsList.item(r).dtls.evidenceType,
            TransactionInfo.getProgramLocale()));
          // END, CR00163098, JC

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            e.arg(true), CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

        } else {

          // BEGIN, CR00128112, ELG
          // Process related actioned 'new' and 'update' records first
          for (int j = 0; j < details.newList.dtlsList.size(); j++) {

            // Removal of the record was accepted, so earlier (than
            // removal)
            // additions must be put 'in edit' and then cancelled.
            // There is no need to process effective date list since
            // accepted
            // evidence will be cancelled straight away.
            if (details.newList.dtlsList.item(j).action.synchronizeAction.equals(
              SYNCHRONIZATIONACTION.ACCEPT)) {

              // BEGIN, CR00128822, CW
              // Accept the evidence record if applicable:
              // We cannot accept more than one evidence record of
              // the same type
              // and effective date when there is a shared active
              // record already
              // on the case.
              acceptEvidenceIfApplicable(isSharedActiveRecordOnCase,
                details.newList.dtlsList.item(j).dtls);
              // END, CR00128822

              // cancel the accepted evidence
              evidenceDescriptorKey.evidenceDescriptorID = details.newList.dtlsList.item(j).dtls.evidenceDescriptorID;

              evidenceDescriptorDtls = evidenceDescriptorObj.read(
                evidenceDescriptorKey);

              evidenceDescriptorStatusDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.CANCELED;

              modifyEvidenceDescriptorStatus(evidenceDescriptorDtls,
                evidenceDescriptorStatusDtls);

              // remove processed 'new' evidence from the list
              details.newList.dtlsList.remove(j);
              j--; // When (j) is removed the rest of the list
              // drops down one - this
              // decrement ensures we don't skip any evidence

            } else if (details.newList.dtlsList.item(j).action.synchronizeAction.equals(
              SYNCHRONIZATIONACTION.REJECT)) {

              // BEGIN, CR00128822, CW
              EvidenceDescriptorDtls rejectedEvidence = details.newList.dtlsList.item(j).dtls;

              // if this is a new evidence record then discard any
              // related
              // evidence records that are pending removal
              if (rejectedEvidence.newInd) {
                discardRelatedPendingRemovalRecords(rejectedEvidence);
              }
              // reject evidence
              rejectEvidence(rejectedEvidence);
              // END, CR00128822

              // remove processed 'new' evidence from the list
              details.newList.dtlsList.remove(j);
              j--; // When (j) is removed the rest of the list
              // drops down one - this
              // decrement ensures we don't skip any evidence

            }

          }

          for (int k = 0; k < details.updateList.dtlsList.size(); k++) {

            // Removal of the record was accepted, so earlier (than
            // removal)
            // modifications must be put 'in edit', then cancelled.
            // There is no need to process effective date list since
            // accepted
            // evidence will be cancelled straight away.
            if (details.updateList.dtlsList.item(k).action.synchronizeAction.equals(
              SYNCHRONIZATIONACTION.ACCEPT)) {

              // BEGIN, CR00128822, CW
              // Accept the evidence record if applicable:
              // We cannot accept more than one evidence record of
              // the same type
              // and effective date when there is a shared active
              // record already
              // on the case.
              acceptEvidenceIfApplicable(isSharedActiveRecordOnCase,
                details.updateList.dtlsList.item(k).dtls);
              // END, CR00128822

              // cancel the accepted evidence
              evidenceDescriptorKey.evidenceDescriptorID = details.updateList.dtlsList.item(k).dtls.evidenceDescriptorID;

              evidenceDescriptorDtls = evidenceDescriptorObj.read(
                evidenceDescriptorKey);

              evidenceDescriptorStatusDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.CANCELED;

              modifyEvidenceDescriptorStatus(evidenceDescriptorDtls,
                evidenceDescriptorStatusDtls);

              // remove processed 'update' evidence from the list
              details.updateList.dtlsList.remove(k);
              k--; // When (k) is removed the rest of the list
              // drops down one - this
              // decrement ensures we don't skip any evidence

            } else if (details.updateList.dtlsList.item(k).action.synchronizeAction.equals(
              SYNCHRONIZATIONACTION.REJECT)) {

              rejectEvidence(details.updateList.dtlsList.item(k).dtls);

              // remove processed 'update' evidence from the list
              details.updateList.dtlsList.remove(k);
              k--; // When (k) is removed the rest of the list
              // drops down one - this
              // decrement ensures we don't skip any evidence

            }

          }

          // Accept removal after processing actioned 'new' and
          // 'update'
          // records. By accepting removal un-actioned and 'in-edit'
          // records
          // will be discarded

          // BEGIN, CR00128822,CW
          // Accept the evidence record if applicable:
          // We cannot accept more than one evidence record of the
          // same type
          // and effective date when there is a shared active record
          // already
          // on the case.
          acceptEvidenceIfApplicable(isSharedActiveRecordOnCase,
            details.removeList.dtlsList.item(r).dtls);
          // END, CR00128112

        }

      } else {
        rejectEvidence(details.removeList.dtlsList.item(r).dtls);
      }
    } // end for r
  }

  // ___________________________________________________________________________
  /**
   * This method processes a list of identical shared evidence 'new' records
   * which are being synchronized onto the case.
   *
   * @param newList
   * Contains the identical shared new evidence to be processed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void processIdenticalEvidenceNewList(
    final IdenticalEvidenceDetailsAndActionList newList) throws AppException,
      InformationalException {

    // Create an informational manager
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Process new evidence next
    for (int n = 0; n < newList.dtlsList.size(); n++) {

      if (newList.dtlsList.item(n).action.synchronizeAction.equals(
        SYNCHRONIZATIONACTION.ACCEPT)) {

        // Have we already accepted a record with the same effective
        // date?
        if (effectiveDateListContainsDate(
          newList.dtlsList.item(n).dtls.effectiveFrom)) {

          AppException e = new AppException(
            BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_IDENTICAL_EVIDENCE_ACCEPT_XRV_MULTIPLE_INEDIT);

          // Add the evidence type to the error message
          // BEGIN, CR00163098, JC
          e.arg(
            CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
            newList.dtlsList.item(n).dtls.evidenceType,
            TransactionInfo.getProgramLocale()));
          // END, CR00163098, JC

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            e.arg(true), CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

        } else {
          
          acceptEvidence(newList.dtlsList.item(n).dtls);
          effectiveDateList.addRef(newList.dtlsList.item(n).dtls.effectiveFrom);
        }

      } else {
        // BEGIN, CR00128822, CW
        EvidenceDescriptorDtls rejectedEvidence = newList.dtlsList.item(n).dtls;

        // If this is a new evidence record then discard any related
        // evidence records that are pending removal
        if (rejectedEvidence.newInd) {
          discardRelatedPendingRemovalRecords(rejectedEvidence);
        }
        rejectEvidence(rejectedEvidence);
        // END, CR00128822
      }
    } // end for n
  }

  // ___________________________________________________________________________
  /**
   * This method processes a list of identical shared evidence 'update' records
   * which are being synchronized onto the case.
   *
   * @param updateList
   * Contains the identical shared update evidence to be processed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected void processIdenticalEvidenceUpdateList(
    final IdenticalEvidenceDetailsAndActionList updateList)
    throws AppException, InformationalException {

    // Delegate to the 'new' method as the functionality is the same
    // for both new and updates
    processIdenticalEvidenceNewList(updateList);
  }

  // END, CR00122108

  // BEGIN, CR00121705, KH
  // ___________________________________________________________________________
  /**
   * This method is used to mark identical evidence which has been accepted.
   * This involves creating any parent / child relationships, creating the
   * evidence change history, setting any pending indicators on the appropriate
   * evidence (i.e. pending update or pending removal), updating the evidence
   * status and closing any synchronize tasks associated with the accepted
   * evidence.
   *
   * @param acceptedEvidenceDtls
   * The evidence being accepted onto the case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void acceptEvidence(EvidenceDescriptorDtls acceptedEvidenceDtls)
    throws AppException, InformationalException {

    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    // Used to update the evidence status after being accepted
    EvidenceDescriptorStatusDtls evidenceDescriptorStatusDtls = new EvidenceDescriptorStatusDtls();
    
    SharedInstanceIDCaseIDStatusCodes sharedInstanceIDCaseIDStatusCodes = new SharedInstanceIDCaseIDStatusCodes();   
    
    Provider<DeferredVerificationProcessBehaviour> provider = GuiceWrapper.getInjector().getProvider(
      DeferredVerificationProcessBehaviour.class);

    DeferredVerificationProcessBehaviour deferredVerificationProcessBehaviourObj = provider.get();   
        
    EvidenceDescriptorKey acceptedKey = new EvidenceDescriptorKey();

    acceptedKey.evidenceDescriptorID = acceptedEvidenceDtls.evidenceDescriptorID;    
    
    // BEGIN, CR00427114, KRK
    CurrentPostponedVerificationDtlsList currentPostponedVerificationDtlsList = CurrentPostponedVerificationFactory.newInstance().searchByEvidenceDescriptorID(
      acceptedKey);
    
    Boolean params[] = EvidenceBrokerUtils.getCachedEvidenceBrokerParams();
    
    Boolean considerAutoAcceptance = params[0];  
    
    if ((!currentPostponedVerificationDtlsList.dtls.isEmpty()) 
      || (null
        != TransactionInfo.getFacadeScopeObject(
          VerificationConst.kPostponeVerification) 
            && TransactionInfo.getFacadeScopeObject(VerificationConst.kPostponeVerification).equals(
              true && considerAutoAcceptance))) {       

      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = acceptedEvidenceDtls.relatedID;
      eiEvidenceKey.evidenceType = acceptedEvidenceDtls.evidenceType;
      
      final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = EvidenceControllerFactory.newInstance().getEvidenceSummaryDetails(
        eiEvidenceKey);

      final AppException ae = new AppException(
        BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_EVIDENCE_ACCEPT_ON_UNEVALUATED_STATE);    
       
      ae.arg(
        LocalizableXMLStringHelper.toPlainText(eiFieldsForListDisplayDtls.summary).replace(CuramConst.gkDotChar, CuramConst.gkSpaceChar).trim()); 
         
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0); 
      // END, CR00427114
    } else {       

      // Find any identical shared records affected by the accept
      SharedInstanceIDCaseIDStatusCodes sharedInstanceCaseIDKey = new SharedInstanceIDCaseIDStatusCodes();

      sharedInstanceCaseIDKey.caseID = acceptedEvidenceDtls.caseID;
      sharedInstanceCaseIDKey.sharedInstanceID = acceptedEvidenceDtls.sharedInstanceID; 
       
      EvidenceDescriptorDtlsList identicalEvidenceList = evidenceDescriptorObj.searchBySharedInstanceIDCaseIDStatusCodes(
        sharedInstanceCaseIDKey);

      for (int i = 0; i < identicalEvidenceList.dtls.size(); i++) {

        EvidenceDescriptorDtls currentEvidenceDtls = identicalEvidenceList.dtls.item(
          i);

        // Drop the accepted evidence record from the list
        if (currentEvidenceDtls.evidenceDescriptorID
          == acceptedEvidenceDtls.evidenceDescriptorID) {

          identicalEvidenceList.dtls.remove(i);
          i--; // When (i) is removed the rest of the list drops down one
          // - this
          // decrement ensures we don't skip any evidence
          continue;
        }

        if (currentEvidenceDtls.statusCode.equals(
          EVIDENCEDESCRIPTORSTATUS.ACTIVE)
            && currentEvidenceDtls.correctionSetID.equals(
              acceptedEvidenceDtls.correctionSetID)) {

          // This evidence will be directly effected when we accept the
          // shared
          updateActiveTargetEvidence(acceptedEvidenceDtls, currentEvidenceDtls);

        } else if (currentEvidenceDtls.effectiveFrom.equals(
          acceptedEvidenceDtls.effectiveFrom)) {

          // Target evidence with the same effective date may also need
          // updated
          updateTargetEvidenceWithSameEffectiveDate(acceptedEvidenceDtls,
            currentEvidenceDtls);

        } // All other records with same shared instance ID are ok
      } // end for i

      // BEGIN, CR00341649, GYH
      if (!processEvidenceHelper.checkForInformationals().failed) {
        // Set the appropriate evidence status
        if (acceptedEvidenceDtls.pendingRemovalInd) {
          evidenceDescriptorStatusDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALREMOVALACCEPTED;

        } else {
          // BEGIN, CR00362746, ZV
          // BEGIN, CR00365143, ZV
          final CaseKey caseKey = new CaseKey();

          caseKey.caseID = acceptedEvidenceDtls.caseID;
          // Do not auto activate evidence for PDC where evidence is already created as 'Active'
          CaseTypeCode caseTypeCode = CachedCaseHeaderFactory.newInstance().readCaseTypeCode(
            caseKey);

          // Evidence is created as 'Active' for PDC, do not move it to in 'InEdit' state
          if (!caseTypeCode.caseTypeCode.equals(
            CASETYPECODE.PARTICIPANTDATACASE)) {
            evidenceDescriptorStatusDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.INEDIT;
          } else {
            evidenceDescriptorStatusDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.ACTIVE;
          }
          // END, CR00365143
          // END, CR00362746
          createAcceptedChangeHistory(acceptedEvidenceDtls);
        }

        // BEGIN, CR00128580, CW
        // Re read the evidence record prior to modify

        acceptedKey.evidenceDescriptorID = acceptedEvidenceDtls.evidenceDescriptorID;

        acceptedEvidenceDtls = evidenceDescriptorObj.read(acceptedKey);
        // END, CR00128580

        modifyEvidenceDescriptorStatus(acceptedEvidenceDtls,
          evidenceDescriptorStatusDtls);

        // BEGIN, CR00127181, KH
        // Re read the accepted evidence details
        acceptedEvidenceDtls = evidenceDescriptorObj.read(acceptedKey);

        // Accepted evidence should be marked as unchanged until it is
        // either
        // modified or applied
        acceptedEvidenceDtls.sharedUnchangedInd = true;
        evidenceDescriptorObj.modify(acceptedKey, acceptedEvidenceDtls);
        // END, CR00127181

        // Raise the event to close the synchronize task for the evidence
        // accepted
        Event event = new Event();

        event.eventKey = EVIDENCEBROKER.IDENTICAL_EVIDENCE_SYNCHRONIZED;
        event.primaryEventData = acceptedEvidenceDtls.evidenceDescriptorID;
        EventService.raiseEvent(event);
      }
      // END, CR00341649
      // BEGIN, CR00343623, RPB
      if (!processEvidenceHelper.checkForInformationals().failed) {
        if (null != acceptedEvidenceDtls) {

          EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

          evidenceDescriptorKey.evidenceDescriptorID = acceptedEvidenceDtls.evidenceDescriptorID;
          EvidenceDescriptorDtls targetEvidenceDescriptorDtls = evidenceDescriptorObj.read(
            evidenceDescriptorKey);
          // Get target case details
          CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

          caseHeaderKey.caseID = targetEvidenceDescriptorDtls.caseID;
          CaseHeaderDtls targetCaseHeaderDtls = CaseHeaderFactory.newInstance().read(
            caseHeaderKey);

          // Get source evidence descriptor details        

          sharedInstanceIDCaseIDStatusCodes.caseID = targetEvidenceDescriptorDtls.sourceCaseID;
          sharedInstanceIDCaseIDStatusCodes.sharedInstanceID = targetEvidenceDescriptorDtls.sharedInstanceID;
          sharedInstanceIDCaseIDStatusCodes.statusCode1 = EVIDENCEDESCRIPTORSTATUSEntry.ACTIVE.getCode();
          EvidenceDescriptorDtlsList sourceEvidenceDescriptorDtlsList = evidenceDescriptorObj.searchBySharedInstanceIDCaseIDStatusCodes(
            sharedInstanceIDCaseIDStatusCodes);
          EvidenceDescriptorDtls sourceEvidenceDescriptor = null;

          // There can be only one source evidence descriptor.
          if (sourceEvidenceDescriptorDtlsList.dtls.size() > 0) {
            for (EvidenceDescriptorDtls evidenceDescriptorDtls : sourceEvidenceDescriptorDtlsList.dtls.items()) {
              if (evidenceDescriptorDtls.sharedInstanceID
                == targetEvidenceDescriptorDtls.sharedInstanceID) {
                sourceEvidenceDescriptor = evidenceDescriptorDtls;
              }

              // Check for the evidence broker configuration to share
              // verification if needed.
              if (!deferredVerificationProcessBehaviourObj.isVerificationDeferred()) {
                if (null != sourceEvidenceDescriptor
                  && getEvidenceBrokerConfigForVerificationSharing(
                    sourceEvidenceDescriptor, targetCaseHeaderDtls)) {
                  final VerificationInterface verificationObj = getVerificationImpl();

                  verificationObj.shareVerificationItems(
                    targetEvidenceDescriptorDtls);
                }

                // END HCR Patch
              }
            }
          }
        }
      }

      // END, CR00343623
    }
   
  }

  // END, CR00121705

  // ___________________________________________________________________________
  /**
   * This method is used to mark identical evidence which has been rejected. The
   * status of the evidence record is updated to <code>Identical Shared Rejected
   * </code> and the 'synchronize evidence' task related to the evidence record
   * being rejected is closed.
   *
   * @param evidenceDescriptorDtls
   * The evidence to be rejected.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void rejectEvidence(
    final EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {

    // Update the evidence status of the rejected record
    EvidenceDescriptorStatusDtls evidenceDescriptorStatusDtls = new EvidenceDescriptorStatusDtls();

    evidenceDescriptorStatusDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALREJECTED;

    modifyEvidenceDescriptorStatus(evidenceDescriptorDtls,
      evidenceDescriptorStatusDtls);

    // Raise the event to close the synchronize task for the evidence
    // rejected
    Event event = new Event();

    event.eventKey = EVIDENCEBROKER.IDENTICAL_EVIDENCE_SYNCHRONIZED;
    event.primaryEventData = evidenceDescriptorDtls.evidenceDescriptorID;
    EventService.raiseEvent(event);
  }

  // BEGIN, CR00128822, CW
  // ___________________________________________________________________________
  /**
   * This method will discard any evidence records that are pending removal and
   * are related to a given evidence descriptor record. This method takes an
   * evidence descriptor record and searches for other evidence descriptor
   * records which have the same shared instance id, are pending removal, and
   * are in the same correction set. The method then updates the status of the
   * returned evidence descriptor records to <CODE>Identical Discarded</CODE>
   *
   * @param evidenceDescriptorDtls
   * The evidence for which related evidence records are to be
   * discarded.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void discardRelatedPendingRemovalRecords(
    final EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {
    // BEGIN, CR00128580, CW
    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    // Find any shared records affected by the reject
    SharedInstanceIDCaseIDStatusCodes sharedInstanceCaseIDKey = new SharedInstanceIDCaseIDStatusCodes();

    sharedInstanceCaseIDKey.caseID = evidenceDescriptorDtls.caseID;
    sharedInstanceCaseIDKey.sharedInstanceID = evidenceDescriptorDtls.sharedInstanceID;

    EvidenceDescriptorDtlsList identicalEvidenceList = evidenceDescriptorObj.searchBySharedInstanceIDCaseIDStatusCodes(
      sharedInstanceCaseIDKey);

    for (int i = 0; i < identicalEvidenceList.dtls.size(); i++) {

      EvidenceDescriptorDtls currentEvidenceDtls = identicalEvidenceList.dtls.item(
        i);

      // Drop the rejected evidence record from the list
      if (currentEvidenceDtls.evidenceDescriptorID
        == evidenceDescriptorDtls.evidenceDescriptorID) {

        identicalEvidenceList.dtls.remove(i);
        i--; // When (i) is removed the rest of the list drops down one
        // - this
        // decrement ensures we don't skip any evidence
        continue;
      }

      // Check if there is a record pending removal that has yet
      // to be synchronized
      if (currentEvidenceDtls.pendingRemovalInd
        && currentEvidenceDtls.statusCode.equals(
          EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT)
          && currentEvidenceDtls.correctionSetID.equals(
            evidenceDescriptorDtls.correctionSetID)) {

        // Update status of the removed record to 'Identical Shared
        // Discarded'
        EvidenceDescriptorStatusDtls discardedEvidenceStatusDtls = new EvidenceDescriptorStatusDtls();

        discardedEvidenceStatusDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALDISCARDED;

        modifyEvidenceDescriptorStatus(currentEvidenceDtls,
          discardedEvidenceStatusDtls);

      }
    }
    // END, CR00128580
  }

  // END, CR00128822

  // BEGIN, CR00121705, KH
  // ___________________________________________________________________________
  /**
   * This method updates the active target evidence on the case which will be
   * affected by accepting the shared evidence.
   *
   * @param acceptedEvidenceDtls
   * The evidence being accepted onto the case.
   * @param targetEvidenceDtls
   * The target evidence already on the case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void updateActiveTargetEvidence(
    EvidenceDescriptorDtls acceptedEvidenceDtls,
    EvidenceDescriptorDtls targetEvidenceDtls) throws AppException,
      InformationalException {

    // Find any identical shared records affected by the update
    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    // Key used when modifying the target evidence descriptor
    EvidenceDescriptorKey key = new EvidenceDescriptorKey();

    key.evidenceDescriptorID = targetEvidenceDtls.evidenceDescriptorID;

    // We can not update evidence which is pending removal
    if (targetEvidenceDtls.pendingRemovalInd) {

      AppException e = new AppException(
        BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_IDENTICAL_EVIDENCE_ACCEPT_XRV_PENDING_REMOVAL);

      // Add the evidence type to the error message
      // BEGIN, CR00163098, JC
      e.arg(
        CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
        targetEvidenceDtls.evidenceType, TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    } else if (acceptedEvidenceDtls.pendingRemovalInd) {

      // BEGIN, CR00121852, KH
      EIEvidenceKey evidenceKey = new EIEvidenceKey();

      evidenceKey.evidenceID = targetEvidenceDtls.relatedID;
      evidenceKey.evidenceType = targetEvidenceDtls.evidenceType;

      // If this is a parent it can only be removed if it has no
      // dependents
      if (EvidenceControllerFactory.newInstance().isEvidenceAParent(evidenceKey)) {

        AppException e = new AppException(
          BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_IDENTICAL_EVIDENCE_ACCEPT_XRV_REMOVAL_HAS_DEPENDANTS);

        // Add the evidence type to the error message
        // BEGIN, CR00163098, JC
        e.arg(
          CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
          targetEvidenceDtls.evidenceType, TransactionInfo.getProgramLocale()));
        // END, CR00163098, JC

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          e, CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

        // BEGIN, CR00121732, KH
        // We can not remove evidence which is pending update
      } else if (targetEvidenceDtls.pendingUpdateInd) {

        AppException e = new AppException(
          BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_IDENTICAL_EVIDENCE_ACCEPT_XRV_REMOVAL_PENDING_UPDATE);

        // Add the evidence type to the error message
        // BEGIN, CR00163098, JC
        e.arg(
          CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
          targetEvidenceDtls.evidenceType, TransactionInfo.getProgramLocale()));
        // END, CR00163098, JC

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          e, CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

        // END, CR00121732
      } else {

        // Mark as pending removal
        PendingRemovalIndAndVersionNo pendingRemovalDtls = new PendingRemovalIndAndVersionNo();

        pendingRemovalDtls.pendingRemovalInd = true;
        pendingRemovalDtls.versionNo = targetEvidenceDtls.versionNo;

        evidenceDescriptorObj.modifyPendingRemoval(key, pendingRemovalDtls);
      }
      // END, CR00121852

    } else { // This is an update to the case

      // Mark as pending update
      PendingUpdateIndAndVersionNo pendingUpdateDtls = new PendingUpdateIndAndVersionNo();

      pendingUpdateDtls.pendingUpdateInd = true;
      pendingUpdateDtls.versionNo = targetEvidenceDtls.versionNo;

      evidenceDescriptorObj.modifyPendingUpdate(key, pendingUpdateDtls);

      // BEGIN, CR00122158, KH
      // We are updating evidence on the target case, so this shared
      // evidence
      // cannot be considered new
      key.evidenceDescriptorID = acceptedEvidenceDtls.evidenceDescriptorID;

      acceptedEvidenceDtls.newInd = false;
      EvidenceDescriptorFactory.newInstance().modify(key, acceptedEvidenceDtls);

      // Refresh the accepted evidence details (get changed version
      // number)
      acceptedEvidenceDtls = EvidenceDescriptorFactory.newInstance().read(key);
      // END, CR00122158
    }
  }

  // ___________________________________________________________________________
  /**
   * This method updates any target evidence on the case which has the same
   * <code>effective from</code> date as the shared evidence being accepted.
   *
   * @param acceptedEvidenceDtls
   * The evidence being accepted onto the case.
   * @param targetEvidenceDtls
   * The target evidence already on the case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void updateTargetEvidenceWithSameEffectiveDate(
    final EvidenceDescriptorDtls acceptedEvidenceDtls,
    final EvidenceDescriptorDtls targetEvidenceDtls) throws AppException,
      InformationalException {

    if (acceptedEvidenceDtls.pendingRemovalInd) {

      // BEGIN, CR00128112, ELG
      if (targetEvidenceDtls.statusCode.equals(
        EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT)
          || targetEvidenceDtls.statusCode.equals(
            EVIDENCEDESCRIPTORSTATUS.INEDIT)) {

        // If we are accepting a 'removal', any in edit or not accepted
        // records with the same effective from date are discarded
        EvidenceDescriptorStatusDtls discardedEvidenceStatusDtls = new EvidenceDescriptorStatusDtls();

        discardedEvidenceStatusDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALDISCARDED;

        modifyEvidenceDescriptorStatus(targetEvidenceDtls,
          discardedEvidenceStatusDtls);
      }
      // END, CR00128112

    } else if (targetEvidenceDtls.statusCode.equals(
      EVIDENCEDESCRIPTORSTATUS.INEDIT)) {

      // We are accepting a 'new' or 'update' and there is an In Edit
      // record
      // with the same shared instance ID already on the case
      AppException e = new AppException(
        BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_IDENTICAL_EVIDENCE_ACCEPT_XRV_ALREADY_INEDIT);

      // Add the evidence type to the error message
      // BEGIN, CR00163098, JC
      e.arg(
        CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
        targetEvidenceDtls.evidenceType, TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // END, CR00121705

  // BEGIN, CR00236468, GYH
  /**
   * @param synchronizeDetails
   * Contains the non identical shared evidence details to be
   * synchronized.
   *
   * @return the case id of the case being synchronized
   *
   * @throws AppException
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Deprecated
  // END, CR00236468
  public CaseHeaderKey synchronizeNonIdenticalEvidence(
    final SynchronizeNonIdenticalEvidenceDetails synchronizeDetails)
    throws AppException, InformationalException {

    // Initialize return object
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    // Holds the list of evidence descriptor IDs which have been resolved
    EvidenceDescriptorKeyList evidenceDescriptorKeyList = new EvidenceDescriptorKeyList();

    StringList nonIdenticalEvidenceList = StringUtil.tabText2StringList(
      synchronizeDetails.nonIdenticalEvidenceList);

    for (int i = 0; i < nonIdenticalEvidenceList.size(); i++) {

      EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = new Long(
        nonIdenticalEvidenceList.item(i).toString());

      evidenceDescriptorKeyList.dtls.addRef(evidenceDescriptorKey);
    }

    processNonIdenticalEvidenceGroup(evidenceDescriptorKeyList);

    // Determine the case id of the case being synchronized.
    // This will be used to close any synchronize task
    // outstanding against the case if all evidence is synchronized
    if (!evidenceDescriptorKeyList.dtls.isEmpty()) {

      // Retrieve the case id from the first evidence record in the list
      EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

      EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorKeyList.dtls.item(0).evidenceDescriptorID;
      EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj.read(
        evidenceDescriptorKey);

      // All evidence records in the list will have the same case id so
      // Case
      // Header key can take case id from the first evidence record in the
      // list
      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
    }
    // END, CR00120856
    return caseHeaderKey;
    // END, CR00120556
  }

  // ___________________________________________________________________________
  /**
   * This method is used to mark non identical evidence which has been actioned.
   * It updates the status of each piece of non identical evidence in the list
   * to <code>Non Identical Shared Resolved</code> and closes any associated
   * evidence synchronization task.
   *
   * @param evidenceDescriptorKeyList
   * The list of evidence records which have been actioned.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  protected void processNonIdenticalEvidenceGroup(
    final EvidenceDescriptorKeyList evidenceDescriptorKeyList)
    throws AppException, InformationalException {

    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    EvidenceDescriptorStatusDtls evidenceDescriptorStatusDtls = new EvidenceDescriptorStatusDtls();

    evidenceDescriptorStatusDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALRESOLVED;

    // BEGIN, CR00114568, CW
    // Raise an event to close the synchronize task for any evidence
    // resolved
    for (int i = 0; i < evidenceDescriptorKeyList.dtls.size(); i++) {

      Event event = new Event();

      event.eventKey = EVIDENCEBROKER.NONIDENTICAL_EVIDENCE_SYNCHRONIZED;
      event.primaryEventData = evidenceDescriptorKeyList.dtls.item(i).evidenceDescriptorID;
      EventService.raiseEvent(event);

      EvidenceDescriptorKey key = new EvidenceDescriptorKey();

      key.evidenceDescriptorID = evidenceDescriptorKeyList.dtls.item(i).evidenceDescriptorID;
      EvidenceDescriptorDtls details = evidenceDescriptorObj.read(key);

      modifyEvidenceDescriptorStatus(details, evidenceDescriptorStatusDtls);
    }
    // END, CR00114568
  }

  // BEGIN, CR00119773, KH
  // ___________________________________________________________________________
  /**
   * This method creates an 'Accepted' evidence change history record.
   *
   * @param details
   * Evidence descriptor entity details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void createAcceptedChangeHistory(
    final EvidenceDescriptorDtls details) throws AppException,
      InformationalException {

    EvidenceChangeHistoryDtls changeHistoryDtls = new EvidenceChangeHistoryDtls();

    // Set details to create the change history record
    changeHistoryDtls.evidenceDescriptorID = details.evidenceDescriptorID;
    changeHistoryDtls.changeType = EVIDENCECHANGETYPE.SHAREDACCEPTED;

    EvidenceChangeHistoryFactory.newInstance().insert(changeHistoryDtls);
  }

  // END, CR00119773

  // ___________________________________________________________________________
  /**
   * This method updates the status of the evidence to the value specified.
   *
   * @param evidenceDescriptorDtls
   * The evidence record to be updated with the new status.
   * @param evidenceDescriptorStatusDtls
   * The new status of the evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void modifyEvidenceDescriptorStatus(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EvidenceDescriptorStatusDtls evidenceDescriptorStatusDtls)
    throws AppException, InformationalException {

    EvidenceDescriptorKey key = new EvidenceDescriptorKey();

    key.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;

    // BEGIN, CR00122158, KH
    evidenceDescriptorStatusDtls.versionNo = evidenceDescriptorDtls.versionNo;

    EvidenceDescriptorFactory.newInstance().modifyStatus(key,
      evidenceDescriptorStatusDtls);
    // END, CR00122158
  }

  // ___________________________________________________________________________
  /**
   * This method takes XML data in string format and parses it into an XML
   * document.
   *
   * @param xmlString
   * Contains the XML evidence data as a string.
   *
   * @return XML document containing the evidence data.
   */
  protected Document buildXMLDocumentFromString(final String xmlString) {

    Document calendarXMLDocument = null;

    if (xmlString.length() > 0) {

      DocumentBuilder builder = null;

      try {
        builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
      } catch (ParserConfigurationException e) {// Do nothing
      }

      try {
        calendarXMLDocument = builder.parse(
          new InputSource(new StringReader(xmlString)));
      } catch (SAXException e) {
        AppException ae = new AppException(
          BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_XML_PARSING_EXCEPTION);

        throw new AppRuntimeException(ae);
      } catch (IOException e) {
        AppException ae = new AppException(
          BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_XML_PARSING_EXCEPTION);

        throw new AppRuntimeException(ae);
      }
    }

    return calendarXMLDocument;
  }

  // END, CR00120268

  // BEGIN, CR00114568, CW
  // ___________________________________________________________________________
  /**
   * This method will close the case participant creation evidence
   * synchronization task for the case if all evidence on the case has been
   * synchronized.
   *
   * @param caseHeaderKey
   * Contains the case id which is the unique identifier of the task.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void closeCaseParticipantCreationSynchronizationTask(
    final CaseHeaderKey caseHeaderKey) throws AppException,
      InformationalException {

    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    CaseIDAndStatusKey caseIDAndStatusKey = new CaseIDAndStatusKey();

    caseIDAndStatusKey.caseID = caseHeaderKey.caseID;
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;

    EvidenceDescriptorDtlsList identicalInEditDtlsList = evidenceDescriptorObj.searchByCaseIDAndStatus(
      caseIDAndStatusKey);

    if (identicalInEditDtlsList.dtls.isEmpty()) {

      // There are no identical in-edit records, now check for
      // non identical in-edit records
      caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;

      EvidenceDescriptorDtlsList nonIdenticalInEditDtlsList = evidenceDescriptorObj.searchByCaseIDAndStatus(
        caseIDAndStatusKey);

      if (nonIdenticalInEditDtlsList.dtls.isEmpty()) {
        // There are no records left to be synchronized on the case
        // so raise an event to close the case participant creation
        // evidence
        // synchronization task if there is one for the case.
        Event event = new Event();

        event.eventKey = EVIDENCEBROKER.CASE_CREATION_EVIDENCE_SYNCHRONIZED;
        event.primaryEventData = caseIDAndStatusKey.caseID;

        EventService.raiseEvent(event);
      }
    }
  }

  // END, CR00114658

  // BEGIN, CR00128822, CW
  // ___________________________________________________________________________
  /**
   * Helper method to determine whether the local list of
   * <code>effective from</code> dates contains the given
   * <code>effective from</code> date.
   *
   * @param effectiveFrom
   * The <code>effective from</code> date to check.
   * @return True if the local list contains the given date.
   */
  protected boolean effectiveDateListContainsDate(final Date effectiveFrom) {
    return !effectiveDateList.isEmpty()
      && effectiveDateList.contains(effectiveFrom);
  }

  // END, CR00128822

  // BEGIN, CR00128822
  // ___________________________________________________________________________
  /**
   * This method ensures that we cannot accept more than one evidence record of
   * the same type and effective date when there is a shared active record
   * already on the case. If there is a shared active evidence record on the
   * case and we have already accepted a record with the same effective date
   * then an error will be thrown. Otherwise the evidence record will be
   * accepted onto the target case and the local list of
   * <code>effective from</code> dates will be updated to include the
   * <code>effective from</code> date of the accepted record.
   *
   * @param isSharedActiveRecordOnCase
   * Indicates whether there is a shared active record already on the
   * case with the same shared instance id as the given evidence record
   * @param evidenceDescriptorDtls
   * the evidence record for acceptance
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void acceptEvidenceIfApplicable(
    final boolean isSharedActiveRecordOnCase,
    final EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {

    if (isSharedActiveRecordOnCase
      && effectiveDateListContainsDate(evidenceDescriptorDtls.effectiveFrom)) {

      // Throw an error as we cannot accept more than one evidence record
      // of the same type and effective date when there is a
      // shared active record already on the case.

      AppException e = new AppException(
        BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_IDENTICAL_EVIDENCE_MULTIPLE_SYNCHRONIZATION_NOT_VALID);

      // Add the evidence type to the error message
      // BEGIN, CR00163098, JC
      e.arg(
        CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
        evidenceDescriptorDtls.evidenceType, TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    } else {

      acceptEvidence(evidenceDescriptorDtls);
      // Add the effective from date of the accepted record to the local
      // list
      effectiveDateList.addRef(evidenceDescriptorDtls.effectiveFrom);
    }
  }

  // END, CR00128822

  // BEGIN, CR00236468, GYH
  /**
   * Returns list of incoming evidence for a given case and incoming evidence
   * status. If the status being passed is 'Identical Shared In Edit' then
   * identical incoming evidence would be returned. If the status being passed
   * is 'Non Identical Shared In Edit' then non identical incoming evidence
   * would be returned.
   *
   * @param key
   * Contains case identifier.
   *
   * @return List of identical incoming evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public IncomingEvidenceDetailsList listIncomingEvidence(
    final CaseIDAndStatusKey key) throws AppException, InformationalException {

    // BEGIN, CR00301053, ZV
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        informationalManager.addInformationalMsg(
          new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS).arg(
            true),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
      } else if (dataBasedSecurityResult.restricted) {
        informationalManager.addInformationalMsg(
          new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS).arg(true),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      } else {
        informationalManager.addInformationalMsg(
          new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS).arg(
            true),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
      }
      informationalManager.failOperation();
    }
    // END, CR00301053

    return populateIncomingEvidenceDetails(
      EvidenceDescriptorFactory.newInstance().searchByCaseIDAndStatusForEvidenceBrokerSynchronization(
        key));
  }

  public IncomingEvidenceAndSourceCaseDetailsList listIncomingEvidenceWithVerificationDetails(
    CaseIDAndStatusKey key) throws AppException, InformationalException {
    // BEGIN, CR00301053, ZV
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        informationalManager.addInformationalMsg(
          new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS).arg(
            true),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
      } else if (dataBasedSecurityResult.restricted) {
        informationalManager.addInformationalMsg(
          new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS).arg(true),
          CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      } else {
        informationalManager.addInformationalMsg(
          new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS).arg(
            true),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError);
      }
      informationalManager.failOperation();
    }
    // END, CR00301053

    return populateIncomingEvidenceWithVerificationDetails(
      EvidenceDescriptorFactory.newInstance().searchByCaseIDAndStatusForEvidenceBrokerSynchronization(
        key));
  }

  /**
   * Populates incoming evidence details by processing the given evidence
   * descriptor records.
   *
   * @param evidenceDescriptorDtlsList
   * Contains an evidence descriptor records.
   *
   * @return List of incoming evidence details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected IncomingEvidenceAndSourceCaseDetailsList populateIncomingEvidenceWithVerificationDetails(
    EvidenceDescriptorDtlsList evidenceDescriptorDtlsList)
    throws AppException, InformationalException {

    IncomingEvidenceAndSourceCaseDetailsList incomingEvidenceAndSourceCaseDetailsList = new IncomingEvidenceAndSourceCaseDetailsList();
    // BEGIN, CR00426702, GK
    int unevaluatedEvidenceCounter = 0;

    // END, CR00426702
    for (EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorDtlsList.dtls.items()) {

      IncomingEvidenceAndSourceCaseDetails incomingEvidenceAndSourceCaseDetails = new IncomingEvidenceAndSourceCaseDetails();
      SharedInstanceIDCaseIDStatusCodes sharedInstanceIDCaseIDStatusCodes = new SharedInstanceIDCaseIDStatusCodes();

      // BEGIN, CR00348300, RPB
      EvidenceCaseKey evidenceCaseKey = new EvidenceCaseKey();

      evidenceCaseKey.caseIDKey.caseID = evidenceDescriptorDtls.caseID;
      evidenceCaseKey.evidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
      evidenceCaseKey.evidenceKey.evType = evidenceDescriptorDtls.evidenceType;
      EIEvidenceKey[] eiEvidenceKeyList = processEvidenceHelper.getRecordsToCompare(evidenceCaseKey, null, true).dtls.items();

      // BEGIN, CR00367374, CSH
      // Compare the list size (minus the incoming record) to set the indicator
      if ((eiEvidenceKeyList.length - 1)
        > EvidenceBrokerConst.kMaxNumberOfIdenticalEvidencesForComparison) {
        incomingEvidenceAndSourceCaseDetails.selectEvdnceToCompareInd = true;
      } else {
        incomingEvidenceAndSourceCaseDetails.selectEvdnceToCompareInd = false;
      }
      // END, CR00367374
      // END, CR00348300

      sharedInstanceIDCaseIDStatusCodes.caseID = evidenceDescriptorDtls.sourceCaseID;
      sharedInstanceIDCaseIDStatusCodes.sharedInstanceID = evidenceDescriptorDtls.sharedInstanceID;
      EvidenceDescriptorDtls sourceEvidenceDescriptorDtls = null;
      EvidenceDescriptorDtlsList evidenceDtlsList = EvidenceDescriptorFactory.newInstance().searchBySharedInstanceIDCaseIDStatusCodes(
        sharedInstanceIDCaseIDStatusCodes);

      for (EvidenceDescriptorDtls evidenceDtls : evidenceDtlsList.dtls) {
        if (evidenceDtls.sharedInstanceID
          == evidenceDescriptorDtls.sharedInstanceID) {
          sourceEvidenceDescriptorDtls = evidenceDtls;
          break;
        }
      }
      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      CaseHeaderDtls targetCaseHeaderDtls = CaseHeaderFactory.newInstance().read(
        caseHeaderKey);

      if ((null != sourceEvidenceDescriptorDtls)
        && (getEvidenceBrokerConfigForVerificationSharing(
          sourceEvidenceDescriptorDtls, targetCaseHeaderDtls))) {
        CaseIDAndEvidenceTypeKey sourceCaseIDAndEvidenceTypeKey = new CaseIDAndEvidenceTypeKey();

        sourceCaseIDAndEvidenceTypeKey.caseID = evidenceDescriptorDtls.sourceCaseID;
        sourceCaseIDAndEvidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;
        boolean verificationsExistForSourceCase = checkIfVerificationsExistsForCase(
          sourceCaseIDAndEvidenceTypeKey);

        CaseIDAndEvidenceTypeKey targetCaseIDAndEvidenceTypeKey = new CaseIDAndEvidenceTypeKey();

        targetCaseIDAndEvidenceTypeKey.caseID = evidenceDescriptorDtls.caseID;
        targetCaseIDAndEvidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;
        EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

        evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;

        // BEGIN, CR00427012, KRK
        if (verificationsExistForSourceCase
          && CurrentPostponedVerificationFactory.newInstance().searchByEvidenceDescriptorID(evidenceDescriptorKey).dtls.isEmpty()) {
          incomingEvidenceAndSourceCaseDetails.isVerificationShared = true;
        }
        // END, CR00427012
      }
      incomingEvidenceAndSourceCaseDetails.sourceCaseID = evidenceDescriptorDtls.sourceCaseID;
      incomingEvidenceAndSourceCaseDetails.incomingEvidenceDetails.evidenceType = evidenceDescriptorDtls.evidenceType;
      incomingEvidenceAndSourceCaseDetails.incomingEvidenceDetails.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;

      // Get the participant name and populate to return structure
      if (evidenceDescriptorDtls.participantID != 0) {
        ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = evidenceDescriptorDtls.participantID;
        incomingEvidenceAndSourceCaseDetails.incomingEvidenceDetails.participantName = ConcernRoleFactory.newInstance().readConcernRoleName(concernRoleKey).concernRoleName;
        incomingEvidenceAndSourceCaseDetails.incomingEvidenceDetails.participantRoleID = evidenceDescriptorDtls.participantID;
      }

      // Get the evidence description for the given evidence type and ID.
      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceType = evidenceDescriptorDtls.evidenceType;
      eiEvidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
      // BEGIN, CR00244064, CD
      String plainTextSummary = EvidenceControllerFactory.newInstance().getEvidenceSummaryDetails(eiEvidenceKey).summary;

      incomingEvidenceAndSourceCaseDetails.incomingEvidenceDetails.summary = LocalizableXMLStringHelper.toClientFormattedText(
        plainTextSummary);
      // END, CR00244064

      // Get the evidence period.
      EvidencePeriod evidencePeriod = getEvidencePeriod(evidenceDescriptorDtls);

      incomingEvidenceAndSourceCaseDetails.incomingEvidenceDetails.period = getPeriodAsLocalizedString(
        evidencePeriod);

      // Get the event type of the incoming evidence.

      EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;
      incomingEvidenceAndSourceCaseDetails.incomingEvidenceDetails.eventType = getEventType(evidenceDescriptorKey).getCode();
      // BEGIN, CR00426702, GK 
      final CurrentPostponedVerificationDtlsList currentPostponedVerificationDtlsListObj = CurrentPostponedVerificationFactory.newInstance().searchByEvidenceDescriptorID(
        evidenceDescriptorKey);
      final int numUnevaluatedEvidences = currentPostponedVerificationDtlsListObj.dtls.size();

      if (numUnevaluatedEvidences > 0) {
        incomingEvidenceAndSourceCaseDetails.isUnevaluatedEvidence = true;
        unevaluatedEvidenceCounter++;
      }
      // END, CR00426702

      // Get the source case details
      if (evidenceDescriptorDtls.sourceCaseID != 0) {

        // If the evidence details is received from remote system, set
        // the
        // source details from external case header.
        if (evidenceDescriptorDtls.externalSourceCaseInd) {
          ExternalCaseHeaderKey externalCaseHeaderKey = new ExternalCaseHeaderKey();

          externalCaseHeaderKey.externalCaseID = evidenceDescriptorDtls.sourceCaseID;
          ExternalCaseHeaderDtls externalCaseHeaderDtls = ExternalCaseHeaderFactory.newInstance().read(
            externalCaseHeaderKey);

          if (CuramConst.gkEmpty != externalCaseHeaderDtls.caseType) {
            CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
              externalCaseHeaderDtls.caseType);

            if (null == caseTypeEvidence) {
              AppException e = new AppException(
                BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

              e.arg(
                CodeTable.getOneItem(CASETYPECODE.TABLENAME,
                externalCaseHeaderDtls.caseType,
                TransactionInfo.getProgramLocale()));
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
                e,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                18);
            }
            String caseSubType = caseTypeEvidence.getCaseTypeDescriptionDetails(
              externalCaseHeaderDtls.caseSubType);
            StringBuffer sourceCaseBuffer = new StringBuffer();

            sourceCaseBuffer.append(caseSubType);
            sourceCaseBuffer.append(CuramConst.gkSpace);
            sourceCaseBuffer.append(CuramConst.gkDash);
            sourceCaseBuffer.append(CuramConst.gkSpace);
            sourceCaseBuffer.append(externalCaseHeaderDtls.caseNumber);
            incomingEvidenceAndSourceCaseDetails.incomingEvidenceDetails.sourceCase = sourceCaseBuffer.toString();
          }
        } else {
          // BEGIN, CR00367374, CSH
          // Get the case type of the source case
          CaseKey sourceCaseKey = new CaseKey();

          sourceCaseKey.caseID = evidenceDescriptorDtls.sourceCaseID;

          CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance().readCaseTypeCode(
            sourceCaseKey);

          if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PARTICIPANTDATACASE)) {

            ConcernRoleKey participantKey = new ConcernRoleKey();

            participantKey.concernRoleID = evidenceDescriptorDtls.participantID;

            // Create a place holder for the source of the evidence
            String tempSource = CuramConst.gkEmpty;

            // Check the concern role type
            final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

            final ConcernRoleTypeDetails concernRoleTypeDetails = concernRoleObj.readConcernRoleType(
              participantKey);

            if (concernRoleTypeDetails.concernRoleType.equals(
              CONCERNROLETYPE.PERSON)) {

              tempSource = PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PERSON.toString();
            } else if (concernRoleTypeDetails.concernRoleType.equals(
              CONCERNROLETYPE.PROSPECTPERSON)) {

              tempSource = PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PROSPECT.toString();
            }

            incomingEvidenceAndSourceCaseDetails.incomingEvidenceDetails.sourceCase = tempSource;
          } else {
            // END, CR00367374

            // Read the product name and case reference
            MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();
            CaseIDKey caseIDKey = new CaseIDKey();

            caseIDKey.caseID = evidenceDescriptorDtls.sourceCaseID;
            CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
              caseIDKey);

            // Source case details are the Product Name and Case
            // reference
            StringBuffer sourceCaseBuffer = new StringBuffer();

            sourceCaseBuffer.append(
              caseReferenceProductNameConcernRoleName.productName);
            sourceCaseBuffer.append(CuramConst.gkSpace);
            sourceCaseBuffer.append(CuramConst.gkDash);
            sourceCaseBuffer.append(CuramConst.gkSpace);
            sourceCaseBuffer.append(
              caseReferenceProductNameConcernRoleName.caseReference);
            incomingEvidenceAndSourceCaseDetails.incomingEvidenceDetails.sourceCase = sourceCaseBuffer.toString();
          }
        }
      }
      
      // Check if there are any In-Edit evidence records created for the
      // case in
      // process.
      if (evidenceDescriptorDtls.statusCode.equals(
        EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT)) {
        EvidenceTypeAndDescList evidenceTypeAndDescList = getAffectedList(
          evidenceDescriptorDtls);

        if (!evidenceTypeAndDescList.dtls.isEmpty()) {
          for (EvidenceTypeAndDesc evidenceTypeAndDesc : evidenceTypeAndDescList.dtls.items()) {
            IncomingEvidenceAndSourceCaseDetails evidenceDetails = new IncomingEvidenceAndSourceCaseDetails();

            evidenceDetails.assign(incomingEvidenceAndSourceCaseDetails);
            evidenceDetails.incomingEvidenceDetails.affectedEvidence = evidenceTypeAndDesc.evidenceType;
            incomingEvidenceAndSourceCaseDetailsList.dtls.addRef(
              evidenceDetails);
          }
        } else {

          // If there are no In-Edit evidence records then the target
          // evidence
          // would be empty.
          incomingEvidenceAndSourceCaseDetailsList.dtls.addRef(
            incomingEvidenceAndSourceCaseDetails);
        }
      } else {
        incomingEvidenceAndSourceCaseDetailsList.dtls.addRef(
          incomingEvidenceAndSourceCaseDetails);
      }
    }
    
    // BEGIN, CR00424202, JD
    
    // Create a new instance of interface EvidenceUpdatesAllowed.
    // And determine whether a case, depending on it's status will allow for
    // Enabling/Disabling page-level actions.
    final EvidenceUpdatesAllowed evidenceUpdatesAllowed = new EvidenceUpdatesAllowed();
    CaseKey key = new CaseKey();
    boolean evidenceUpdatesAllowedInd = true;

    if (evidenceDescriptorDtlsList.dtls.isEmpty() == false) {
      key.caseID = evidenceDescriptorDtlsList.dtls.item(0).caseID;
      evidenceUpdatesAllowedInd = evidenceUpdatesAllowed.isUpdatesAllowed(key);
    }
    
    // Set the appropriate indicator in return struct
    if (evidenceUpdatesAllowedInd == false) {
      incomingEvidenceAndSourceCaseDetailsList.caseUpdatesAllowed = false;
      for (int i = 0; i
        < incomingEvidenceAndSourceCaseDetailsList.dtls.items().length; i++) {
        if (incomingEvidenceAndSourceCaseDetailsList.dtls.item(i).isVerificationShared
          == true) {
          // Set the isVerificationShared indicator to false, to disable that row-level action
          incomingEvidenceAndSourceCaseDetailsList.dtls.item(i).isVerificationShared = false;
        }
        // Set the readOnlyInd to true for each evidence item, to disable the row-level actions
        incomingEvidenceAndSourceCaseDetailsList.dtls.item(i).readOnlyInd = true;
      }
    } else {
      incomingEvidenceAndSourceCaseDetailsList.caseUpdatesAllowed = true;
    }
   
    // END, CR00424202, JD
    // BEGIN, CR00426702, GK
    incomingEvidenceAndSourceCaseDetailsList.isUnevaluatedEvidencePresent = unevaluatedEvidenceCounter
      > 0;
    // END, CR00426702
    return incomingEvidenceAndSourceCaseDetailsList;
  }

  /**
   * Populates incoming evidence details by processing the given evidence
   * descriptor records.
   *
   * @param evidenceDescriptorDtlsList
   * Contains an evidence descriptor records.
   *
   * @return List of incoming evidence details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected IncomingEvidenceDetailsList populateIncomingEvidenceDetails(
    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList)
    throws AppException, InformationalException {

    IncomingEvidenceDetailsList incomingEvidenceDetailsList = new IncomingEvidenceDetailsList();

    for (EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorDtlsList.dtls.items()) {

      IncomingEvidenceDetails incomingEvidenceDetails = new IncomingEvidenceDetails();

      incomingEvidenceDetails.evidenceType = evidenceDescriptorDtls.evidenceType;
      incomingEvidenceDetails.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;

      // Get the participant name and populate to return structure
      if (evidenceDescriptorDtls.participantID != 0) {
        ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = evidenceDescriptorDtls.participantID;
        incomingEvidenceDetails.participantName = ConcernRoleFactory.newInstance().readConcernRoleName(concernRoleKey).concernRoleName;
        incomingEvidenceDetails.participantRoleID = evidenceDescriptorDtls.participantID;
      }

      // Get the evidence description for the given evidence type and ID.
      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceType = evidenceDescriptorDtls.evidenceType;
      eiEvidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
      // BEGIN, CR00244064, CD
      String plainTextSummary = EvidenceControllerFactory.newInstance().getEvidenceSummaryDetails(eiEvidenceKey).summary;

      incomingEvidenceDetails.summary = LocalizableXMLStringHelper.toClientFormattedText(
        plainTextSummary);
      // END, CR00244064

      // Get the evidence period.
      EvidencePeriod evidencePeriod = getEvidencePeriod(evidenceDescriptorDtls);

      incomingEvidenceDetails.period = getPeriodAsLocalizedString(
        evidencePeriod);

      // Get the event type of the incoming evidence.

      EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;
      incomingEvidenceDetails.eventType = getEventType(evidenceDescriptorKey).getCode();

      // Get the source case details
      if (evidenceDescriptorDtls.sourceCaseID != 0) {

        // If the evidence details is received from remote system, set
        // the
        // source details from external case header.
        if (evidenceDescriptorDtls.externalSourceCaseInd) {
          ExternalCaseHeaderKey externalCaseHeaderKey = new ExternalCaseHeaderKey();

          externalCaseHeaderKey.externalCaseID = evidenceDescriptorDtls.sourceCaseID;
          ExternalCaseHeaderDtls externalCaseHeaderDtls = ExternalCaseHeaderFactory.newInstance().read(
            externalCaseHeaderKey);

          if (CuramConst.gkEmpty != externalCaseHeaderDtls.caseType) {
            CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
              externalCaseHeaderDtls.caseType);

            if (null == caseTypeEvidence) {
              AppException e = new AppException(
                BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

              e.arg(
                CodeTable.getOneItem(CASETYPECODE.TABLENAME,
                externalCaseHeaderDtls.caseType,
                TransactionInfo.getProgramLocale()));
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
                e,
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                18);
            }
            String caseSubType = caseTypeEvidence.getCaseTypeDescriptionDetails(
              externalCaseHeaderDtls.caseSubType);
            StringBuffer sourceCaseBuffer = new StringBuffer();

            sourceCaseBuffer.append(caseSubType);
            sourceCaseBuffer.append(CuramConst.gkSpace);
            sourceCaseBuffer.append(CuramConst.gkDash);
            sourceCaseBuffer.append(CuramConst.gkSpace);
            sourceCaseBuffer.append(externalCaseHeaderDtls.caseNumber);
            incomingEvidenceDetails.sourceCase = sourceCaseBuffer.toString();
          }
        } else {
          // BEGIN, CR00406635, SSK            
          CaseKey sourceCaseKey = new CaseKey();          

          sourceCaseKey.caseID = evidenceDescriptorDtls.sourceCaseID;

          CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance().readCaseTypeCode(
            sourceCaseKey);
              
          if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.PARTICIPANTDATACASE)) {
                
            ConcernRoleKey participantKey = new ConcernRoleKey();

            participantKey.concernRoleID = evidenceDescriptorDtls.participantID;
                
            // Create a place holder for the source of the evidence
            String tempSource = CuramConst.gkEmpty;
                
            // Check the concern role type
            final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

            final ConcernRoleTypeDetails concernRoleTypeDetails = concernRoleObj.readConcernRoleType(
              participantKey);
                
            if (concernRoleTypeDetails.concernRoleType.equals(
              CONCERNROLETYPE.PERSON)) {
                  
              tempSource = PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PERSON.toString();
            } else if (concernRoleTypeDetails.concernRoleType.equals(
              CONCERNROLETYPE.PROSPECTPERSON)) {
                  
              tempSource = PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PROSPECT.toString();
            }
              
            incomingEvidenceDetails.sourceCase = tempSource;
          } else {
            // BEGIN, CR00414242 GK    
              
            if (caseTypeCode.caseTypeCode.equals(
              CASETYPECODE.PARTICIPANTDATACASE)) {
                
              ConcernRoleKey participantKey = new ConcernRoleKey();

              participantKey.concernRoleID = evidenceDescriptorDtls.participantID;
                
              // Create a place holder for the source of the evidence
              String tempSource = CuramConst.gkEmpty;
                
              // Check the concern role type
              final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

              final ConcernRoleTypeDetails concernRoleTypeDetails = concernRoleObj.readConcernRoleType(
                participantKey);
                
              if (concernRoleTypeDetails.concernRoleType.equals(
                CONCERNROLETYPE.PERSON)) {
                  
                tempSource = PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PERSON.toString();
              } else if (concernRoleTypeDetails.concernRoleType.equals(
                CONCERNROLETYPE.PROSPECTPERSON)) {
                  
                tempSource = PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PROSPECT.toString();
              }
              
              incomingEvidenceDetails.sourceCase = tempSource;
            } else {
               
              // Read the product name and case reference
              MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();
              CaseIDKey caseIDKey = new CaseIDKey();

              caseIDKey.caseID = evidenceDescriptorDtls.sourceCaseID;
              CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
                caseIDKey);

              // Source case details are the Product Name and Case
              // reference
              StringBuffer sourceCaseBuffer = new StringBuffer();

              sourceCaseBuffer.append(
                caseReferenceProductNameConcernRoleName.productName);
              sourceCaseBuffer.append(CuramConst.gkSpace);
              sourceCaseBuffer.append(CuramConst.gkDash);
              sourceCaseBuffer.append(CuramConst.gkSpace);
              sourceCaseBuffer.append(
                caseReferenceProductNameConcernRoleName.caseReference);
              incomingEvidenceDetails.sourceCase = sourceCaseBuffer.toString();            
            }
          }
          // END, CR00414242
        }        
        // END, CR00406635
      }
      // Check if there are any In-Edit evidence records created for the
      // case in
      // process.
      if (evidenceDescriptorDtls.statusCode.equals(
        EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT)) {
        EvidenceTypeAndDescList evidenceTypeAndDescList = getAffectedList(
          evidenceDescriptorDtls);

        if (!evidenceTypeAndDescList.dtls.isEmpty()) {
          for (EvidenceTypeAndDesc evidenceTypeAndDesc : evidenceTypeAndDescList.dtls.items()) {
            IncomingEvidenceDetails evidenceDetails = new IncomingEvidenceDetails();

            evidenceDetails.assign(incomingEvidenceDetails);
            evidenceDetails.affectedEvidence = evidenceTypeAndDesc.evidenceType;
            incomingEvidenceDetailsList.details.addRef(evidenceDetails);
          }
        } else {

          // If there are no In-Edit evidence records then the target
          // evidence
          // would be empty.
          incomingEvidenceDetailsList.details.addRef(incomingEvidenceDetails);
        }
      } else {
        incomingEvidenceDetailsList.details.addRef(incomingEvidenceDetails);
      }
    }
    return incomingEvidenceDetailsList;
  }

  protected boolean checkIfVerificationsExistsForCase(
    CaseIDAndEvidenceTypeKey sourceCaseIDAndEvidenceTypeKey)
    throws AppException, InformationalException {

    EvidenceVerificationDetailsList evidenceVerificationDetailsList = evidenceVerification.getVerificationImpl().listVerificationForEvidenceWorkspace(
      sourceCaseIDAndEvidenceTypeKey);

    if (evidenceVerificationDetailsList.verificationDtls.size() > 0) {
      return true;
    }

    return false;

  }

  /**
   * Processes the identical and non identical shared evidence records. The
   * identical evidence records may be accepted, rejected or ignored. The non
   * identical evidence records may be resolved or ignored. When evidence
   * processing is fully complete any outstanding synchronization tasks will be
   * closed.
   *
   * @param key
   * Contains evidence descriptor identifiers and action identifier.
   * @return The ID of the case being processed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processIncomingEvidence(
    final EvidenceDescriptorIDAndSynchronizeActionList key)
    throws AppException, InformationalException {
    EvidenceDescriptorIDAndSynchronizeActionList identicalEvidenceDescIDActionList = new EvidenceDescriptorIDAndSynchronizeActionList();
    EvidenceDescriptorKeyList evidenceDescriptorKeyList = new EvidenceDescriptorKeyList();

    for (EvidenceDescriptorIDAndSynchronizeAction evidenceDescriptorIDAndAction : key.dtlsList.items()) {
      if (evidenceDescriptorIDAndAction.action.equals(
        SYNCHRONIZATIONACTION.ACCEPT)
          || evidenceDescriptorIDAndAction.action.equals(
            SYNCHRONIZATIONACTION.REJECT)) {
        identicalEvidenceDescIDActionList.dtlsList.addRef(
          evidenceDescriptorIDAndAction);
      } else {
        // Action is not either of accept or reject then it is for non
        // identical
        // resolve action.
        EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

        evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorIDAndAction.evidenceDescriptorID;
        evidenceDescriptorKeyList.dtls.addRef(evidenceDescriptorKey);
      }
    }

    // Identical incoming evidence processing
    if (!identicalEvidenceDescIDActionList.dtlsList.isEmpty()) {
      CaseHeaderKey identicalCaseHeaderKey = processIdenticalIncomingEvidence(
        identicalEvidenceDescIDActionList);

      // Close case participant creation task if it exists and all
      // evidence on
      // the case has been processed.
      if (0 != identicalCaseHeaderKey.caseID) {
        closeCaseParticipantCreationSynchronizationTask(identicalCaseHeaderKey);
      }
    }

    // Non-Identical incoming evidence processing
    if (!evidenceDescriptorKeyList.dtls.isEmpty()) {
      CaseHeaderKey nonIdenticalCaseHeaderKey = processNonIdenticalIncomingEvidence(
        evidenceDescriptorKeyList);

      // Close case participant creation task if it exists and all
      // evidence on
      // the case has been processed.
      if (0 != nonIdenticalCaseHeaderKey.caseID) {
        closeCaseParticipantCreationSynchronizationTask(
          nonIdenticalCaseHeaderKey);
      }
    }
  }

  /**
   * Processes identical incoming evidence records. Each piece of identical
   * evidence may be either accepted, rejected, or ignored. The case ID of the
   * case on which the evidence is being processed is returned.
   *
   * @param key
   * Contains evidence descriptor identifiers and action identifier.
   * @return The ID of the case being processed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CaseHeaderKey processIdenticalIncomingEvidence(
    final EvidenceDescriptorIDAndSynchronizeActionList key)
    throws AppException, InformationalException {

    // Extract the evidence descriptor keys which have set the 'ACCEPT' or
    // 'REJECT' action.
    EvidenceDescriptorIDAndSynchronizeActionList evidenceDescriptorIDAndActionList = new EvidenceDescriptorIDAndSynchronizeActionList();

    for (EvidenceDescriptorIDAndSynchronizeAction evidenceDescriptorIDAndAction : key.dtlsList.items()) {
      if (evidenceDescriptorIDAndAction.action.equals(
        SYNCHRONIZATIONACTION.ACCEPT)
          || evidenceDescriptorIDAndAction.action.equals(
            SYNCHRONIZATIONACTION.REJECT)) {
        evidenceDescriptorIDAndActionList.dtlsList.addRef(
          evidenceDescriptorIDAndAction);
      }
    }

    // Validate incoming evidence details and then either acceptance/reject
    // based on the incoming action.
    validateIdenticalEvidenceSynchronization(evidenceDescriptorIDAndActionList);

    IdenticalSharedEvidenceDetailsList sortedEvidenceList = groupEvidenceBySharedInstanceID(
      evidenceDescriptorIDAndActionList);

    for (int i = 0; i < sortedEvidenceList.dtlsList.size(); i++) {
      processIdenticalEvidenceGroup(sortedEvidenceList.dtlsList.item(i));
    }

    // Raise any errors reported during the synchronization
    TransactionInfo.getInformationalManager().failOperation();

    // Determine the case id of the case being synchronized. This will be
    // used
    // to close any outstanding synchronize task if all evidence is
    // synchronized
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (!sortedEvidenceList.dtlsList.isEmpty()) {
      // Retrieve the case id from the first evidence group in the list
      caseHeaderKey.caseID = sortedEvidenceList.dtlsList.item(0).caseID;
    }
    return caseHeaderKey;
  }

  /**
   * Processes non identical incoming evidence records. Each piece of non
   * identical evidence may be either resolved or ignored. The case ID of the
   * case on which the evidence is being synchronized is returned.
   *
   * @param key
   * Contains evidence descriptor identifiers and action identifier.
   * @return The ID of the case being processed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CaseHeaderKey processNonIdenticalIncomingEvidence(
    final EvidenceDescriptorKeyList key) throws AppException,
      InformationalException {

    processNonIdenticalEvidenceGroup(key);
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Determine the case id of the case being synchronized.
    // This will be used to close any synchronize task
    // outstanding against the case if all evidence is synchronized
    if (!key.dtls.isEmpty()) {

      // Retrieve the case id from the first evidence record in the list
      EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
      EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = key.dtls.item(0).evidenceDescriptorID;
      EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj.read(
        evidenceDescriptorKey);

      // All evidence records in the list will have the same case id so
      // Case
      // Header key can take case id from the first evidence record in the
      // list
      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
    }
    return caseHeaderKey;
  }

  /**
   * Returns an event type for the given evidence descriptor identifier.
   *
   * @param key
   * Contains evidence descriptor identifiers and action identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected EVIDENCEBROKEREVENTTYPEEntry getEventType(
    final EvidenceDescriptorKey key) throws AppException,
      InformationalException {
    EvidenceDescriptorDtls evidenceDescriptorDtls = EvidenceDescriptorFactory.newInstance().read(
      key);
    
    if (evidenceDescriptorDtls.pendingRemovalInd) {
      return EVIDENCEBROKEREVENTTYPEEntry.REMOVAL;
    } else if (evidenceDescriptorDtls.newInd) {
      return EVIDENCEBROKEREVENTTYPEEntry.NEW;
    } else {
      return EVIDENCEBROKEREVENTTYPEEntry.UPDATED;
    }
  }

  /**
   * Returns evidence period for the given evidence descriptor record.
   *
   * @param evidenceDescriptorDtls
   * Contains evidence descriptor record.
   *
   * @return The evidence period for the evidence descriptor record.
   *
   * @throws AppException
   * Generic AppException Signature
   * @throws InformationalException
   * Generic InformationalException Signature
   */
  protected EvidencePeriod getEvidencePeriod(
    final EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {
    EvidencePeriod evidencePeriod = new EvidencePeriod();

    // Set evidence type to access relevant evidence interface
    EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;
    EvidenceMap map = EvidenceController.getEvidenceMap();
    StandardEvidenceInterface standardEvidenceInterface = map.getEvidenceType(
      evidenceTypeKey.evidenceType);

    // get the start date from the standard evidence interface
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceType = evidenceDescriptorDtls.evidenceType;
    eiEvidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
    evidencePeriod.startDate = standardEvidenceInterface.getStartDate(
      eiEvidenceKey);

    // If the start date is null or the zero date, get the case start date
    if (evidencePeriod.startDate == null || evidencePeriod.startDate.isZero()) {
      CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      evidencePeriod.startDate = caseHeaderObj.readStartDate(caseHeaderKey).startDate;

    }

    // Retrieve end date from the standard evidence interface
    evidencePeriod.endDate = standardEvidenceInterface.getEndDate(eiEvidenceKey);

    // If the end date is null, set it to be the zero date
    if (evidencePeriod.endDate == null) {
      evidencePeriod.endDate = new Date();
    }

    return evidencePeriod;
  }

  /**
   * Convert the supplied EvidencePeriod to a String suitable for rendering via
   * a LOCALIZED_MESSAGE
   *
   * @param evidencePeriod
   * The EvidencePeriod to convert
   * @return The period as a string suitable for rendering via a
   * LOCALIZED_MESSAGE
   */
  protected String getPeriodAsLocalizedString(
    final EvidencePeriod evidencePeriod) {

    LocalisableString period = null;

    if (evidencePeriod.endDate.isZero()) {
      period = new LocalisableString(
        BPOEVIDENCECONTROLLER.INF_PERIOD_NO_END_DATE);
      period.arg(evidencePeriod.startDate);
    } else {
      period = new LocalisableString(BPOEVIDENCECONTROLLER.INF_PERIOD);
      period.arg(evidencePeriod.startDate);
      period.arg(evidencePeriod.endDate);
    }
    return period.toClientFormattedText();
  }

  /**
   * Helper function to find the affected evidence types on the target case.
   *
   * @param evidenceDescriptorDtls
   * The non identical evidence which could affect evidence on the
   * target case.
   *
   * @return List of affected evidence types on the target case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected EvidenceTypeAndDescList getAffectedList(
    EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {

    // Get the affected evidence details
    EvidenceSharingConfigKey sourceTargetEvidenceAndStatusKey = new EvidenceSharingConfigKey();

    // Get the source and target parameters
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // get the source parameter
    if (evidenceDescriptorDtls.sourceCaseID != 0) {
      if (evidenceDescriptorDtls.externalSourceCaseInd) {
        CaseKey sourcecaseKey = new CaseKey();

        sourcecaseKey.caseID = evidenceDescriptorDtls.sourceCaseID;
        ExternalCaseHeaderDtls externalCaseHeaderDtls = getExternalCaseHeaderDetails(
          sourcecaseKey);

        sourceTargetEvidenceAndStatusKey.sourceType = externalCaseHeaderDtls.caseType;
        sourceTargetEvidenceAndStatusKey.sourceSystemID = externalCaseHeaderDtls.sourceSystemID;

        // Retrieve the corresponding source ID
        CaseTypeEvidence caseTypeEvidence = getCaseTypeEvidence(
          externalCaseHeaderDtls.caseType);
        CaseKey caseKey = new CaseKey();

        caseKey.caseID = externalCaseHeaderDtls.externalCaseID;
        sourceTargetEvidenceAndStatusKey.sourceID = caseTypeEvidence.getSubTypeID(
          externalCaseHeaderDtls.caseSubType);
      } else {
        caseHeaderKey.caseID = evidenceDescriptorDtls.sourceCaseID;
        CaseHeaderDtls caseHeaderDtls = CachedCaseHeaderFactory.newInstance().read(
          caseHeaderKey);

        sourceTargetEvidenceAndStatusKey.sourceType = caseHeaderDtls.caseTypeCode;

        // Retrieve the corresponding source ID
        CaseTypeEvidence caseTypeEvidence = getCaseTypeEvidence(
          caseHeaderDtls.caseTypeCode);
        CaseKey caseKey = new CaseKey();

        caseKey.caseID = caseHeaderDtls.caseID;
        sourceTargetEvidenceAndStatusKey.sourceID = caseTypeEvidence.readEvidenceBrokerSourceIDByCaseID(
          caseKey);
      }
    }

    // get the target parameter
    if (evidenceDescriptorDtls.caseID != 0) {

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      CaseHeaderDtls caseHeaderDtls = CachedCaseHeaderFactory.newInstance().read(
        caseHeaderKey);

      sourceTargetEvidenceAndStatusKey.targetType = caseHeaderDtls.caseTypeCode;

      // Retrieve the corresponding target ID
      CaseTypeEvidence caseTypeEvidence = getCaseTypeEvidence(
        caseHeaderDtls.caseTypeCode);
      CaseKey caseKey = new CaseKey();

      caseKey.caseID = caseHeaderDtls.caseID;

      sourceTargetEvidenceAndStatusKey.targetID = caseTypeEvidence.readEvidenceBrokerSourceIDByCaseID(
        caseKey);
    }

    // Get the evidence broker configuration for the given sharing details
    sourceTargetEvidenceAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
    sourceTargetEvidenceAndStatusKey.sourceEvidenceType = evidenceDescriptorDtls.evidenceType;
    sourceTargetEvidenceAndStatusKey.sharedType = EVIDENCESHARINGTYPE.NONIDENTICAL;

    EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList = EvidenceBrokerConfigAdminFactory.newInstance().listSharedSourceAndTargetEvidences(
      sourceTargetEvidenceAndStatusKey);

    // If the broker configuration list is empty, the broadcaseEvidence
    // functionality might be used to create an evidence of type different
    // than
    // specified by the configuration. Creating a configuration record using
    // the evidence type present in the shared evidence for listing of
    // non-identical evidence
    if (evidenceBrokerConfigDtlsList.dtls.isEmpty()) {
      EvidenceBrokerConfigDtls evidenceBrokerConfigDtls = new EvidenceBrokerConfigDtls();

      evidenceBrokerConfigDtls.targetEvidenceType = evidenceDescriptorDtls.evidenceType;
      evidenceBrokerConfigDtlsList.dtls.addRef(evidenceBrokerConfigDtls);
    }

    EvidenceTypeAndDescList targetEvidenceTypeList = new EvidenceTypeAndDescList();

    // Check if there are any In-Edit evidence been created for the case.
    CaseIDAndStatusKey caseIDAndStatusKey = new CaseIDAndStatusKey();

    caseIDAndStatusKey.caseID = evidenceDescriptorDtls.caseID;
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.INEDIT;
    EvidenceDescriptorDtlsList inEditEvidenceList = EvidenceDescriptorFactory.newInstance().searchByCaseIDAndStatus(
      caseIDAndStatusKey);

    for (EvidenceDescriptorDtls inEditEvidence : inEditEvidenceList.dtls.items()) {
      for (EvidenceBrokerConfigDtls evidenceBrokerConfigDtls : evidenceBrokerConfigDtlsList.dtls.items()) {
        if (inEditEvidence.evidenceType.equals(
          evidenceBrokerConfigDtls.targetEvidenceType)) {
          EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();

          evidenceTypeAndDesc.evidenceType = evidenceBrokerConfigDtls.targetEvidenceType;

          // BEGIN, CR00395933, ELG
          if (!listContainsItem(targetEvidenceTypeList, evidenceTypeAndDesc)) {
            targetEvidenceTypeList.dtls.add(evidenceTypeAndDesc);
          }
          // END, CR00395933

          break;

        }
      }
    }

    // Check if there are any Active evidence been created for the case.
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.ACTIVE;
    EvidenceDescriptorDtlsList inActiveEvidenceList = EvidenceDescriptorFactory.newInstance().searchByCaseIDAndStatus(
      caseIDAndStatusKey);

    for (EvidenceDescriptorDtls inActiveEvidence : inActiveEvidenceList.dtls.items()) {
      for (EvidenceBrokerConfigDtls evidenceBrokerConfigDtls : evidenceBrokerConfigDtlsList.dtls.items()) {
        if (inActiveEvidence.evidenceType.equals(
          evidenceBrokerConfigDtls.targetEvidenceType)) {
          EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();

          evidenceTypeAndDesc.evidenceType = evidenceBrokerConfigDtls.targetEvidenceType;

          // BEGIN, CR00395933, ELG
          if (!listContainsItem(targetEvidenceTypeList, evidenceTypeAndDesc)) {
            targetEvidenceTypeList.dtls.add(evidenceTypeAndDesc);
          }
          // END, CR00395933

          break;
        }
      }
    }

    return targetEvidenceTypeList;
  }

  // BEGIN, CR00395933, ELG
  /**
   * Checks if the EvidenceTypeAndDesc list contains the item. Returns true if item is present in the list.
   *
   * @param list Contains a list of EvidenceTypeAndDesc items.
   * @param item Contains EvidenceTypeAndDesc item to check.
   *
   * @return boolean indicating if item is present in the list.
   */
  private boolean listContainsItem(final EvidenceTypeAndDescList list, final EvidenceTypeAndDesc item) {

    boolean retVal = false;

    for (final EvidenceTypeAndDesc listItem:list.dtls) {

      if (listItem.evidenceType.equals(item.evidenceType)) {
        retVal = true;
        break;
      }

    }

    return retVal;

  }

  // END, CR00395933

  /**
   * Gets the external case details.
   *
   * @param caseKey
   * Contains the caseID.
   *
   * @return External case details..
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ExternalCaseHeaderDtls getExternalCaseHeaderDetails(
    final CaseKey caseKey) throws AppException, InformationalException {

    ExternalCaseHeaderKey externalCaseHeaderKey = new ExternalCaseHeaderKey();

    externalCaseHeaderKey.externalCaseID = caseKey.caseID;
    ExternalCaseHeaderDtls externalCaseHeaderDtls = ExternalCaseHeaderFactory.newInstance().read(
      externalCaseHeaderKey);

    return externalCaseHeaderDtls;
  }

  /**
   * Gets the case type specific object by case type code.
   *
   * @param caseTypeCode
   * The case type code for the case.
   *
   * @return case type specific object.
   *
   * @throws AppException
   * {@link BPOEVIDENCECONTROLLER #ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED}
   * if the case type is not supported.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected CaseTypeEvidence getCaseTypeEvidence(final String caseTypeCode)
    throws AppException, InformationalException {

    CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(caseTypeCode);

    if (null == caseTypeEvidence) {
      AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, caseTypeCode,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 17);
    }
    return caseTypeEvidence;
  }

  // END, CR00236468

  protected boolean checkIfVerificationRequirementsExistsForCase(
    CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey,
    EvidenceDescriptorKey evidenceDescriptorKey) throws AppException,
      InformationalException {

    return evidenceVerification.getVerificationImpl().checkIfVerificationRequirementsExistsForCase(
      caseIDAndEvidenceTypeKey, evidenceDescriptorKey);

  }

  protected boolean getEvidenceBrokerConfigForVerificationSharing(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final CaseHeaderDtls identicalCaseHeaderDtls) throws AppException,
      InformationalException {

    // Get target type and target ID
    SharedEvidenceSourceTypeAndSourceIDDetails targetTypeAndTargetID = processEvidenceHelper.getSharingTargetTypeAndTargetID(
      identicalCaseHeaderDtls);

    // Get source type and source ID
    SharedEvidenceSourceTypeAndSourceIDDetails sourceTypeAndSourceID = processEvidenceHelper.getSharingSourceTypeAndSourceID(
      evidenceDescriptorDtls);
    EvidenceSharingConfigKey key = new EvidenceSharingConfigKey();

    // BEGIN, CR00349439, VR
    String targetEvidenceType = processEvidenceHelper.getTargetEvidenceType(
      evidenceDescriptorDtls, identicalCaseHeaderDtls);

    if (isSameSourceAndTargetType(evidenceDescriptorDtls.evidenceType,
      targetEvidenceType)
      || targetEvidenceType == null) {
      key.sharedType = EVIDENCESHARINGTYPE.IDENTICAL;
      key.targetEvidenceType = evidenceDescriptorDtls.evidenceType;

    } else {
      key.sharedType = EVIDENCESHARINGTYPE.NONIDENTICAL;
      key.targetEvidenceType = targetEvidenceType;

    }

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.sourceEvidenceType = evidenceDescriptorDtls.evidenceType;
    key.sourceID = sourceTypeAndSourceID.sourceID;
    key.sourceType = sourceTypeAndSourceID.sourceType;
    key.targetID = targetTypeAndTargetID.sourceID;
    key.targetType = targetTypeAndTargetID.sourceType;

    // BEGIN, CR00357600, SSK
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlslist = EvidenceBrokerConfigAdminFactory.newInstance().listSharedSourceAndTargetEvidences(
      key);

    boolean allowsSharing = false;

    // If we find the corresponding configuration and auto accept is set
    if (1 == evidenceBrokerConfigDtlslist.dtls.size()) {
      final String shareVerificationOption = evidenceBrokerConfigDtlslist.dtls.item(0).shareVerificationsOption;

      if (!VERIFICATIONSHAREOPTION.NEVER.equals(shareVerificationOption)) {
        if (VERIFICATIONSHAREOPTION.ALWAYS.equals(shareVerificationOption)) {

          allowsSharing = true;
        } else {

          final CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey = new CaseIDAndEvidenceTypeKey();

          caseIDAndEvidenceTypeKey.caseID = identicalCaseHeaderDtls.caseID;
          caseIDAndEvidenceTypeKey.evidenceType = key.targetEvidenceType;
          final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

          evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;
          allowsSharing = checkIfVerificationRequirementsExistsForCase(
            caseIDAndEvidenceTypeKey, evidenceDescriptorKey);
        }
      }
    } // END, CR00357600
    else {

      // Multiple matching configuration records exist
      AppException e = new AppException(
        BPOEVIDENCEBROKER.ERR_EVIDENCEBROKER_IDENTICAL_CONFIG_RECORDS_EXIST);

      e.arg(
        CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
        evidenceDescriptorDtls.evidenceType, TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    return allowsSharing;
  }

  // BEGIN, CR00343380, RPB
  /**
   * Creates and returns an instance of the Verification implementation.
   *
   * @return An instance of the Verification implementation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected VerificationInterface getVerificationImpl() throws AppException,
      InformationalException {
    return evidenceVerification.getVerificationImpl();
  }

  // END, CR00343380

  private boolean isSameSourceAndTargetType(String sourceType, String targetType) {
    return sourceType.equals(targetType);
  } 
  
}
