/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26

 * Copyright IBM Corporation 2010, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.evidencebroker.sl.impl;


import com.google.inject.Inject;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.EVIDENCECHANGETYPE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.EVIDENCESHARELASTOPTION;
import curam.codetable.EVIDENCESHARINGLIMITTYPE;
import curam.codetable.EVIDENCESHARINGTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SYNCHRONIZATIONACTION;
import curam.codetable.impl.CASEEVIDENCEEntry;
import curam.codetable.impl.EVIDENCECHANGETYPEEntry;
import curam.codetable.impl.EVIDENCEDESCRIPTORSTATUSEntry;
import curam.codetable.impl.EVIDENCENATUREEntry;
import curam.core.events.EVIDENCEBROKER;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ExternalCaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CachedCaseHeader;
import curam.core.intf.CaseHeader;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.ParticipantRoleIDAndTypeCodesKey;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.impl.CaseTypeEvidence;
import curam.core.sl.impl.LocalizableXMLStringHelper;
import curam.core.sl.infrastructure.entity.fact.EvidenceChangeHistoryFactory;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceChangeHistory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.CaseIDParticipantIDStatusCode;
import curam.core.sl.infrastructure.entity.struct.CaseIDStatusAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceChangeHistoryDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceChangeHistoryDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKeyList;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.MostRecentBusinessObjectChangesDetails;
import curam.core.sl.infrastructure.entity.struct.MostRecentBusinessObjectChangesDetailsList;
import curam.core.sl.infrastructure.entity.struct.ParticipantIDStatusCode;
import curam.core.sl.infrastructure.entity.struct.RelatedIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.RelatedIDAndEvidenceTypeKeyList;
import curam.core.sl.infrastructure.entity.struct.SharedInstanceIDCaseIDStatusCodes;
import curam.core.sl.infrastructure.entity.struct.SuccessionID;
import curam.core.sl.infrastructure.entity.struct.SuccessionIDAndStatusCodes;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EvidenceController;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.EvidenceMap;
import curam.core.sl.infrastructure.impl.StandardEvidenceInterface;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.infrastructure.struct.ApplyChangesEvidenceLists;
import curam.core.sl.infrastructure.struct.BusinessObjectKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.EvdUpdatesPeriodLastActDetails;
import curam.core.sl.infrastructure.struct.EvidenceKey;
import curam.core.sl.infrastructure.struct.EvidencePeriod;
import curam.core.sl.infrastructure.struct.EvidenceTypeAndDesc;
import curam.core.sl.infrastructure.struct.EvidenceTypeDtls;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.EvidenceCaseKey;
import curam.core.sl.struct.SharedEvidenceDescriptorDetails;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderDtlsList;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHeaderKeyList;
import curam.core.struct.CaseIDConcernRoleID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ExternalCaseHeaderDtls;
import curam.core.struct.ExternalCaseHeaderKey;
import curam.core.struct.UserFullname;
import curam.core.struct.UserNameKey;
import curam.core.struct.UserNameKeyList;
import curam.core.struct.UsersKey;
import curam.datastore.impl.Datastore;
import curam.datastore.impl.DatastoreFactory;
import curam.datastore.impl.Entity;
import curam.datastore.impl.NoSuchSchemaException;
import curam.evidence.impl.EvidenceNature;
import curam.evidencebroker.impl.BroadcastEvidenceManager;
import curam.evidencebroker.impl.EvidenceBrokerConst;
import curam.evidencebroker.impl.EvidenceBrokerUtils;
import curam.evidencebroker.sl.entity.fact.EvidenceBrokerAttributeConfigFactory;
import curam.evidencebroker.sl.entity.fact.EvidenceBrokerConfigFactory;
import curam.evidencebroker.sl.entity.intf.EvidenceBrokerAttributeConfig;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerAttributeConfigDtlsList;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerConfigDtls;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerConfigDtlsList;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerConfigKey;
import curam.evidencebroker.sl.entity.struct.EvidenceSharingConfigKey;
import curam.evidencebroker.sl.entity.struct.EvidenceTypeCodeKey;
import curam.evidencebroker.sl.entity.struct.SharedSourceEvidenceAndStatusKey;
import curam.evidencebroker.sl.fact.EvidenceBrokerConfigAdminFactory;
import curam.evidencebroker.sl.fact.EvidenceBrokerSynchronizationFactory;
import curam.evidencebroker.sl.infrastructure.impl.EvidenceBrokerHooks;
import curam.evidencebroker.sl.intf.BroadcastEvidence;
import curam.evidencebroker.sl.struct.AutoAcceptEvidenceFailureInd;
import curam.evidencebroker.sl.struct.AutoAcceptEvidenceFailureNotificationDetails;
import curam.evidencebroker.sl.struct.EvidenceAutoAcceptanceInd;
import curam.evidencebroker.sl.struct.EvidenceAutoActionFailureNotificationDetails;
import curam.evidencebroker.sl.struct.EvidenceDescriptorIDAndSynchronizeAction;
import curam.evidencebroker.sl.struct.EvidenceDescriptorIDAndSynchronizeActionList;
import curam.evidencebroker.sl.struct.SharedEvidenceSourceTypeAndSourceIDDetails;
import curam.message.BPOEVIDENCEBROKER;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.util.cache.Cache;
import curam.util.cache.CacheManagerEjb;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;
import curam.util.workflow.impl.EnactmentService;
import curam.verification.sl.infrastructure.entity.fact.VDIEDLinkFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationItemProvidedFactory;
import curam.verification.sl.infrastructure.entity.intf.VDIEDLink;
import curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkAndDataItemIDDetails;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkAndDataItemIDDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDAndStatusKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtlsList;
import curam.verification.sl.infrastructure.fact.SharedVERItemProvidedFactory;
import curam.verification.sl.infrastructure.impl.VerificationConst;
import curam.verification.sl.infrastructure.intf.SharedVERItemProvided;
import curam.verification.sl.infrastructure.struct.SharedVERItemProvidedDtls;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;


/**
 * An helper class to process an identical or non identical sharing of evidence
 * which is configured for case types.
 */
public class ProcessEvidenceHelper {

  /**
   * A hash map reference of the case evidence type module which is registered
   * in the registry.
   */
  @Inject
  protected Map<String, CaseTypeEvidence> caseTypeEvidenceMap;

  @Inject
  protected EvidenceBrokerHooks evidenceBrokerHooks;

  // BEGIN, CR00388582, RPB
  @Inject
  protected EvidenceBrokerTaskGenerationStrategy evidenceBrokerTaskGenerationStrategy;
  // END, CR00388582

  // END-VM
  
  // BEGIN, CR00427301, RPB
  /**
   * A reference for {@link RestrictEBHook}.
   */
  @Inject(optional = true)
  protected RestrictEBHook restrictEBHook;

  // END, CR00427301

  /**
   * A reference for {@link EvidenceNature}.
   */
  @Inject
  protected EvidenceNature evidenceNature;

  /**
   * Default constructor for the class.
   */
  public ProcessEvidenceHelper() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Processes evidence which is configured for identical sharing. Puts the new
   * evidence on the case for which evidence should be shared with. A task will
   * be sent to the relevant case owners informing them that evidence has been
   * shared with their case.
   *
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor details for the evidence to be
   * shared.
   * @param identicalCaseHeaderDtls
   * Contains the case details with which this evidence could be
   * shared.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOEVIDENCEBROKER#ERR_EVIDENCEBROKER_IDENTICAL_CONFIG_RECORDS_EXIST}
   * - if an evidence type is configured for multiple identical
   * sharing.
   */
  public void processIdenticalEvidenceSharingForCaseWithAutoAcceptOnly(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final CaseHeaderDtls identicalCaseHeaderDtls) throws AppException,
      InformationalException {
    processIdenticalEvidenceSharingForCase(evidenceDescriptorDtls,
      identicalCaseHeaderDtls, Boolean.TRUE, Boolean.FALSE);
  }

  /**
   * Processes evidence which is configured for identical sharing. Puts the new
   * evidence on the case for which evidence should be shared with. A task will
   * be sent to the relevant case owners informing them that evidence has been
   * shared with their case.
   *
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor details for the evidence to be
   * shared.
   * @param identicalCaseHeaderDtls
   * Contains the case details with which this evidence could be
   * shared.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOEVIDENCEBROKER#ERR_EVIDENCEBROKER_IDENTICAL_CONFIG_RECORDS_EXIST}
   * - if an evidence type is configured for multiple identical
   * sharing.
   */
  public void processIdenticalEvidenceSharingForCase(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final CaseHeaderDtls identicalCaseHeaderDtls) throws AppException,
      InformationalException {
    processIdenticalEvidenceSharingForCase(evidenceDescriptorDtls,
      identicalCaseHeaderDtls, Boolean.TRUE, Boolean.TRUE);
  }

  /**
   * Processes evidence which is configured for identical sharing. Puts the new
   * evidence on the case for which evidence should be shared with. A task will
   * be sent to the relevant case owners informing them that evidence has been
   * shared with their case.
   *
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor details for the evidence to be
   * shared.
   * @param identicalCaseHeaderDtls
   * Contains the case details with which this evidence could be
   * shared.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOEVIDENCEBROKER#ERR_EVIDENCEBROKER_IDENTICAL_CONFIG_RECORDS_EXIST}
   * - if an evidence type is configured for multiple identical
   * sharing.
   */

  public void processIdenticalEvidenceSharingForCase(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final CaseHeaderDtls identicalCaseHeaderDtls,
    Boolean considerAutoAcceptance, Boolean considerAutoActivation)
    throws AppException, InformationalException {

    final EvidenceDescriptorDtls targetEvidenceDescriptorDtls = broadcastEvidence(
      evidenceDescriptorDtls, identicalCaseHeaderDtls);
  
    // BEGIN, CR00388582, RPB
    boolean autoActivateInd = false;

    // END, CR00388582

    // BEGIN, CR00358618, GYH
    if (null != targetEvidenceDescriptorDtls) {
      // Get target type and target ID
      final SharedEvidenceSourceTypeAndSourceIDDetails targetTypeAndTargetID = getSharingTargetTypeAndTargetID(
        identicalCaseHeaderDtls);

      // Get source type and source ID
      final SharedEvidenceSourceTypeAndSourceIDDetails sourceTypeAndSourceID = getSharingSourceTypeAndSourceID(
        evidenceDescriptorDtls);
      final EvidenceSharingConfigKey key = new EvidenceSharingConfigKey();

      key.recordStatus = RECORDSTATUS.NORMAL;
      key.sharedType = EVIDENCESHARINGTYPE.IDENTICAL;
      key.sourceEvidenceType = evidenceDescriptorDtls.evidenceType;
      key.sourceID = sourceTypeAndSourceID.sourceID;
      key.sourceType = sourceTypeAndSourceID.sourceType;
      key.targetID = targetTypeAndTargetID.sourceID;
      key.targetType = targetTypeAndTargetID.sourceType;
      key.targetEvidenceType = evidenceDescriptorDtls.evidenceType;
      final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlslist = EvidenceBrokerConfigAdminFactory.newInstance().listSharedSourceAndTargetEvidences(
        key);
      
      // BEGIN, CR00426922, KRK
      if (null
        != TransactionInfo.getFacadeScopeObject(
          VerificationConst.kPostponeVerification) 
            && TransactionInfo.getFacadeScopeObject(VerificationConst.kPostponeVerification).equals(
              true)) {
        
        if (null != targetEvidenceDescriptorDtls) {
          createSourceVerificationItemProvidedDetails(
            targetEvidenceDescriptorDtls, evidenceBrokerConfigDtlslist);
        }      
      }        
      // END, CR00426922

      // If we find the corresponding configuration and auto accept is set
      if (1 == evidenceBrokerConfigDtlslist.dtls.size()) {
        if (evidenceBrokerConfigDtlslist.dtls.item(0).autoAcceptInd) {

          if (considerAutoAcceptance) {

            // Add the target evidence to the auto accept list
            EvidenceDescriptorIDAndSynchronizeAction evidenceIDAndAction = new EvidenceDescriptorIDAndSynchronizeAction();

            evidenceIDAndAction.action = SYNCHRONIZATIONACTION.ACCEPT;
            evidenceIDAndAction.evidenceDescriptorID = targetEvidenceDescriptorDtls.evidenceDescriptorID;

            EvidenceDescriptorIDAndSynchronizeActionList evidenceIDAndActionList = new EvidenceDescriptorIDAndSynchronizeActionList();

            evidenceIDAndActionList.dtlsList.addRef(evidenceIDAndAction);

            autoAcceptEvidenceOnTargetCase(evidenceIDAndActionList);

            if (evidenceBrokerConfigDtlslist.dtls.item(0).autoActivateInd
              && !checkForInformationals().failed) {

              if (considerAutoActivation) {
                processEvidenceAutoActivation(evidenceDescriptorDtls,
                  targetEvidenceDescriptorDtls);
                // BEGIN, CR00388582, RPB
                autoActivateInd = true;
                // END, CR00388582
              }
            }
          }
        }
      } else {

        // Multiple matching configuration records exist
        final AppException e = new AppException(
          BPOEVIDENCEBROKER.ERR_EVIDENCEBROKER_IDENTICAL_CONFIG_RECORDS_EXIST);

        e.arg(
          CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
          evidenceDescriptorDtls.evidenceType,
          TransactionInfo.getProgramLocale()));
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }

      // BEGIN, CR00407540, SSK
      final Cache<String, String> evidenceDataCache = CacheManagerEjb.getTransactionLocalCacheGroup().getCache(
        EvidenceBrokerConst.kEvidenceTransactionCacheDatastoreKey);
      final String value = evidenceDataCache.get(
        String.valueOf(evidenceDescriptorDtls.caseID));

      // Create a workflow task for each evidence record which has been
      // shared
      // BEGIN, CR00388582, RPB
      if (value == null) {
        if (evidenceBrokerTaskGenerationStrategy.determineTaskGenerationForIdenticalEvdSharing(
          targetEvidenceDescriptorDtls, autoActivateInd)) {
          // END, CR00388582
          createEvidenceSynchronizationTask(identicalCaseHeaderDtls,
            targetEvidenceDescriptorDtls, true);

        }
      } else {
        if (!autoActivateInd) {
          populateDataSource(targetEvidenceDescriptorDtls,
            evidenceDescriptorDtls);
        }
      }
    }
    // END, CR00407540
    // END, CR00358618

  }

  // BEGIN, CR00388582, SSK
  /**
   * Populates the data store.
   *
   * @param targetEvidenceDescriptorDtls
   * Contains the details of target evidence descriptor.
   *
   * @param sourceEvidenceDescriptorDtls
   * Contains the details of source evidence descriptor.
   */
  protected void populateDataSource(final EvidenceDescriptorDtls targetEvidenceDescriptorDtls, final EvidenceDescriptorDtls sourceEvidenceDescriptorDtls)throws AppException, InformationalException {

    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = targetEvidenceDescriptorDtls.evidenceDescriptorID;
    final EvidenceDescriptorDtls updatedEvidenceDescriptorDtls = evidenceDescriptorObj.read(
      evidenceDescriptorKey);

    Datastore sourceEvidenceDatastore = null;
    final Cache<String, String> evidenceDataCache;

    if (EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT.equals(
      updatedEvidenceDescriptorDtls.statusCode)
        || EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT.equals(
          updatedEvidenceDescriptorDtls.statusCode)) {

      evidenceDataCache = CacheManagerEjb.getTransactionLocalCacheGroup().getCache(
        EvidenceBrokerConst.kIncomingEvidenceTransactionCacheDatastoreKey);
      final String incomingEvidenceCacheValue = evidenceDataCache.get(
        String.valueOf(sourceEvidenceDescriptorDtls.caseID));

      if (null != incomingEvidenceCacheValue) {
        try {
          sourceEvidenceDatastore = DatastoreFactory.newInstance().openDatastore(
            EvidenceBrokerConst.kTargetIncomingEvidenceDataStore);
        } catch (final NoSuchSchemaException e) {// do nothing.
        }

        final Entity incomingEvidenceEntity = sourceEvidenceDatastore.readEntity(
          Long.valueOf(incomingEvidenceCacheValue));
        final StringBuffer sharedEvidences = new StringBuffer();

        sharedEvidences.append(
          incomingEvidenceEntity.getAttribute(EvidenceBrokerConst.kTargetIncomingEvidenceList).toString());
        if (0 == sharedEvidences.length()) {
          sharedEvidences.append(
            updatedEvidenceDescriptorDtls.evidenceDescriptorID);
        } else {
          sharedEvidences.append(
            CuramConst.gkPipeDelimiter
              + updatedEvidenceDescriptorDtls.evidenceDescriptorID);
        }
        incomingEvidenceEntity.setAttribute(
          EvidenceBrokerConst.kTargetIncomingEvidenceList,
          sharedEvidences.toString());
        incomingEvidenceEntity.update();
      }
    } else if (EVIDENCEDESCRIPTORSTATUS.INEDIT.equals(
      updatedEvidenceDescriptorDtls.statusCode)) {

      evidenceDataCache = CacheManagerEjb.getTransactionLocalCacheGroup().getCache(
        EvidenceBrokerConst.kInEditEvidenceTransactionCacheDatastoreKey);
      final String incomingEvidenceCacheValue = evidenceDataCache.get(
        String.valueOf(sourceEvidenceDescriptorDtls.caseID));

      try {
        sourceEvidenceDatastore = DatastoreFactory.newInstance().openDatastore(
          EvidenceBrokerConst.kTargetInEditEvidenceDataStore);
      } catch (final NoSuchSchemaException e) {// do nothing.
      }

      final Entity inEditEvidenceEntity = sourceEvidenceDatastore.readEntity(
        Long.valueOf(incomingEvidenceCacheValue));
      final StringBuffer sharedEvidences = new StringBuffer();

      sharedEvidences.append(
        inEditEvidenceEntity.getAttribute(EvidenceBrokerConst.kTargetInEditEvidenceList).toString());
      if (0 == sharedEvidences.length()) {
        sharedEvidences.append(
          updatedEvidenceDescriptorDtls.evidenceDescriptorID);
      } else {
        sharedEvidences.append(
          CuramConst.gkPipeDelimiter
            + updatedEvidenceDescriptorDtls.evidenceDescriptorID);
      }
      inEditEvidenceEntity.setAttribute(
        EvidenceBrokerConst.kTargetInEditEvidenceList,
        sharedEvidences.toString());
      inEditEvidenceEntity.update();

    }
  }

  // END, CR00388582
  /**
   * Processes evidence which is configured for non identical sharing. It
   * determines which of the given list of cases the evidence could be relevant
   * to and then sends a notification to each case owner informing them that
   * evidence relevant to their case has been modified and should be examined.
   *
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor details for the evidence to be
   * shared.
   * @param nonIdenticalCaseHeaderDtls
   * Contains the list of cases with which this evidence could be
   * shared.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public EvidenceDescriptorDtls processNonIdenticalEvidenceSharingForCase(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final CaseHeaderDtls nonIdenticalCaseHeaderDtls) throws AppException,
      InformationalException {
    // BEGIN, CR00199018, PB

    // @TODO:Venkat
    // Need to check whether this is configured with new admin functionality
    // Get the target evidence type and source evidence type
    // Check against new configuration.

    // BEGIN, CR00349439, VR

    final String targetEvidenceType = getTargetEvidenceType(
      evidenceDescriptorDtls, nonIdenticalCaseHeaderDtls);
    final EvidenceBrokerAttributeConfig evidenceBrokerAttributeConfig = EvidenceBrokerAttributeConfigFactory.newInstance();
    final EvidenceTypeCodeKey evidenceTypeCodeKey = new EvidenceTypeCodeKey();
    
    evidenceTypeCodeKey.sourceEvidenceType = evidenceDescriptorDtls.evidenceType;
    evidenceTypeCodeKey.targetEvidenceType = targetEvidenceType;
    final EvidenceBrokerAttributeConfigDtlsList attributeConfigDtlsList = evidenceBrokerAttributeConfig.searchBySourceAndTargetEvidenceType(
      evidenceTypeCodeKey);

    final boolean isConfigured = attributeConfigDtlsList.dtls.size() > 0;
    EvidenceDescriptorDtls targetEvidenceDescriptorDtls;

    if (!isConfigured) {
      targetEvidenceDescriptorDtls = broadcastEvidence(evidenceDescriptorDtls,
        nonIdenticalCaseHeaderDtls);
    } else {
      targetEvidenceDescriptorDtls = broadcastNonIdenticalEvidence(
        evidenceDescriptorDtls, nonIdenticalCaseHeaderDtls, targetEvidenceType);
    }
    // END, CR00349439
    // END, CR00199018

    // BEGIN, CR00359976, GYH
    if (null != targetEvidenceDescriptorDtls) {
      // BEGIN, CR00237356, GYH
      // Check if non identical evidence has already been auto accepted
      // onto
      // target case, if not then create a workflow task to resolve the
      // evidence.

      // BEGIN, CR00388582, SSK

      final Cache<String, String> evidenceDataCache = CacheManagerEjb.getTransactionLocalCacheGroup().getCache(
        EvidenceBrokerConst.kEvidenceTransactionCacheDatastoreKey);
      final String value = evidenceDataCache.get(
        String.valueOf(evidenceDescriptorDtls.caseID));

      if (!isNonIdenticalEvidenceAutoAccepted(evidenceDescriptorDtls,
        nonIdenticalCaseHeaderDtls)) {
        // BEGIN, CR00398056, RD
        // BEGIN, CR00428386, SS
        if (value == null) {
          if (evidenceBrokerTaskGenerationStrategy.determineTaskGenerationForNonIdenticalEvdSharing(
            targetEvidenceDescriptorDtls)) {
            // END, CR00398056
            // BEGIN, CR00426588, SS
            if (null
              == TransactionInfo.getFacadeScopeObject(
                EVIDENCEBROKER.BULKEVIDENCEACTIVATED.toString())) {
              // END, CR00426588
              createEvidenceSynchronizationTask(nonIdenticalCaseHeaderDtls,
                targetEvidenceDescriptorDtls, false);
            }          
          } 
        } else {
          populateDataSource(targetEvidenceDescriptorDtls,
            evidenceDescriptorDtls);
        }
        // END, CR00428386
      }
    }
    // END, CR00388582
    // END, CR00359976
   
    return targetEvidenceDescriptorDtls;
    // END, CR00237356
  }

  /**
   * Sorts through the given list of evidence broker configurations and splits
   * them into lists of identical and non identical configurations.
   *
   * @param fullEvidenceBrokerConfigDtlsList
   * Contains the full list of shared evidence configurations that are
   * applicable to this piece of evidence.
   * @param identicalEvidenceBrokerConfigList
   * Contains the list of identical shared evidence configurations that
   * are applicable to this piece of evidence.
   * @param nonIdenticalEvidenceBrokerConfigList
   * Contains the list of non identical shared evidence configurations
   * that are applicable to this piece of evidence.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void sortEvidenceBrokerConfiguration(
    final EvidenceBrokerConfigDtlsList fullEvidenceBrokerConfigDtlsList,
    final EvidenceBrokerConfigDtlsList identicalEvidenceBrokerConfigList,
    final EvidenceBrokerConfigDtlsList nonIdenticalEvidenceBrokerConfigList)
    throws AppException, InformationalException {

    // Sort the shared evidence configurations
    for (final EvidenceBrokerConfigDtls currentEvidenceBrokerConfig : fullEvidenceBrokerConfigDtlsList.dtls.items()) {

      // Split into identical and non identical sharing lists
      if (currentEvidenceBrokerConfig.sharedType.equalsIgnoreCase(
        EVIDENCESHARINGTYPE.NONIDENTICAL)) {
        nonIdenticalEvidenceBrokerConfigList.dtls.addRef(
          currentEvidenceBrokerConfig);
      } else if (currentEvidenceBrokerConfig.sharedType.equalsIgnoreCase(
        EVIDENCESHARINGTYPE.IDENTICAL)) {
        identicalEvidenceBrokerConfigList.dtls.addRef(
          currentEvidenceBrokerConfig);
      }
    }
  }

  /**
   * Retrieves any cases on which the given participant has active evidence,
   * excluding the original case from which the participant was identified. Any
   * cases which have a status of <code>CLOSED</code> or <code>CANCELED</code>
   * are not considered.
   *
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor details for the piece of evidence
   * to be shared.
   *
   * @return The list of cases on which the given participant has some active
   * evidence.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public CaseHeaderDtlsList getCasesForEvidenceActivation(
    final EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {

    // Find all relevant cases for this participant
    final ParticipantRoleIDAndTypeCodesKey key = new ParticipantRoleIDAndTypeCodesKey();

    key.participantRoleID = evidenceDescriptorDtls.participantID;
    key.typeCode1 = CASEPARTICIPANTROLETYPE.MEMBER;
    key.typeCode2 = CASEPARTICIPANTROLETYPE.PRIMARY;
    final CaseHeaderKeyList caseHeaderKeyList = CaseParticipantRoleFactory.newInstance().searchCaseIDByParticipantRoleIDAndTypeCodes(
      key);
    final CaseHeaderKey originatingCaseID = new CaseHeaderKey();

    originatingCaseID.caseID = evidenceDescriptorDtls.caseID;

    return getCaseHeaderDetails(originatingCaseID, caseHeaderKeyList, false);
  }

  /**
   * Retrieves the case header details for the given list of cases. Any cases
   * with a status of <code>CLOSED</code> or <code>CANCELED</code> are excluded,
   * as is the originating case specified.
   *
   * @param originatingCaseID
   * Contains the originating case which should not be included.
   * @param caseHeaderKeyList
   * Contains the list of potential cases.
   * @param cprInd
   * Indicates if the function is called as part of adding a CPR to a
   * case.
   *
   * @return The list of case header details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected CaseHeaderDtlsList getCaseHeaderDetails(
    final CaseHeaderKey originatingCaseID,
    final CaseHeaderKeyList caseHeaderKeyList, final boolean cprInd)
    throws AppException, InformationalException {

    final CaseHeaderDtlsList caseHeaderDtlsList = new CaseHeaderDtlsList();
    final CachedCaseHeader cachedCaseHeaderObj = CachedCaseHeaderFactory.newInstance();

    // BEGIN, CR00381723, JMA
    // The originating case is not included
    // BEGIN, CR00409197, GK
    CaseHeaderDtls originatingCase = new  CaseHeaderDtls();

    if (originatingCaseID.caseID != 0) {
      originatingCase = CachedCaseHeaderFactory.newInstance().read(
        originatingCaseID);
    }

    // END, CR00409197


    // Check each case to decide if it is relevant
    for (final CaseHeaderKey caseHeaderKey : caseHeaderKeyList.dtls.items()) {

      // BEGIN, CR00409197, GK
      if (caseHeaderKey.caseID != 0) {
        // END, CR00409197

        final CaseHeaderDtls caseHeaderDtls = cachedCaseHeaderObj.read(
          caseHeaderKey);

        // BEGIN, CR00409197, GK 
        // In general, Closed or Canceled cases are not considered, but an
        // additional check is performed to see if certain closed cases
        // should be included.
        if (!caseHeaderDtls.statusCode.equalsIgnoreCase(CASESTATUS.CANCELED)
          && !caseHeaderDtls.statusCode.equalsIgnoreCase(CASESTATUS.CLOSED)
            || (originatingCaseID.caseID != 0
              && evidenceBrokerHooks.canClosedCaseBeIncluded(originatingCase,
              caseHeaderDtls, cprInd))) {
          // END, CR00409197
          if (caseHeaderDtls.caseID != originatingCaseID.caseID) {
            caseHeaderDtlsList.dtls.addRef(caseHeaderDtls);
          }
        }
      }
    }
    // END, CR00381723

    return caseHeaderDtlsList;
  }

  /**
   * Iterates through a given list of target cases and checks if any of the
   * evidence broker configurations specified are applicable to the case. If
   * none of the evidence sharing configurations are applicable, that case is
   * removed from the list.
   *
   * @param nonIdenticalInd
   * The Flag to indicate if the filtering is taking place for
   * non-identical sharing. If so, further filtering is required.
   *
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor details for the evidence to be
   * shared.
   * @param evidenceBrokerConfigDtlsList
   * Contains the evidence sharing configuration information relevant
   * to this piece of evidence.
   * @param targetCaseHeaderList
   * Contains the list of target cases to be filtered.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOEVIDENCECONTROLLER#ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED}
   * - if a particular case type is not supported to access the
   * required functionality.
   */
  public void filterTargetCaseList(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final CaseHeaderDtlsList targetCaseHeaderList) throws AppException,
      InformationalException {
    for (int i = 0; i < targetCaseHeaderList.dtls.size(); i++) {
      boolean isConfigurationFound = false;
      final CaseHeaderDtls caseHeaderDtls = targetCaseHeaderList.dtls.item(i);

      for (final EvidenceBrokerConfigDtls evidenceBrokerConfigDtls : evidenceBrokerConfigDtlsList.dtls.items()) {

        // Check if this a case type that we are sharing evidence with
        if (caseHeaderDtls.caseTypeCode.equalsIgnoreCase(
          evidenceBrokerConfigDtls.targetType)) {
          final CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
            caseHeaderDtls.caseTypeCode);

          if (null == caseTypeEvidence) {
            final AppException e = new AppException(
              BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

            e.arg(
              CodeTable.getOneItem(CASETYPECODE.TABLENAME,
              caseHeaderDtls.caseTypeCode, TransactionInfo.getProgramLocale()));
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              e,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              10);
          }
          final CaseKey caseKey = new CaseKey();

          caseKey.caseID = caseHeaderDtls.caseID;

          // Retrieve the corresponding target ID
          if (evidenceBrokerConfigDtls.targetID
            == caseTypeEvidence.readEvidenceBrokerSourceIDByCaseID(caseKey)) {
            isConfigurationFound = true;
            break;
          }
        }
      }

      // If none of the configurations are applicable then remove this
      // case
      if (!isConfigurationFound) {
        targetCaseHeaderList.dtls.remove(i);
        i--; // When (i) is removed the rest of the list drops down one
        // - this
        // decrement ensures we don't skip any cases
      }
    }
  }

  /**
   * Adds the source evidence to the target case. It adds the evidence via the
   * broadcast service layer hook for the corresponding evidence type if
   * available, otherwise the evidence is added directly via the evidence
   * controller.
   *
   * @param sourceEvidenceDescriptorDtls
   * Contains the evidence to be broadcast.
   * @param targetCaseHeaderDtls
   * Contains the target case that the evidence is being broadcast to.
   *
   * @return The evidence which has been added to the target case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00237356, GYH
  public EvidenceDescriptorDtls broadcastEvidence(
    final EvidenceDescriptorDtls sourceEvidenceDescriptorDtls,
    final CaseHeaderDtls targetCaseHeaderDtls) throws AppException,
      InformationalException {
    // END, CR00237356
    final CaseKey caseKey = new CaseKey();

    // BEGIN, CR00199018, PB
    caseKey.caseID = targetCaseHeaderDtls.caseID;
    final CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
      targetCaseHeaderDtls.caseTypeCode);

    if (null == caseTypeEvidence) {
      final AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME,
        targetCaseHeaderDtls.caseTypeCode, TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 15);
    }
    final BroadcastEvidence broadcastEvidenceObj = BroadcastEvidenceManager.getHook(
      caseTypeEvidence.getCaseTypeCode(caseKey));

    // Try to share the evidence using the evidence specific broadcast
    EvidenceDescriptorDtls targetEvidenceDescriptorDtls = broadcastEvidenceObj.processBroadcast(
      sourceEvidenceDescriptorDtls, targetCaseHeaderDtls);

    // If the evidence specific broadcast is not configured share the
    // evidence
    // directly via the evidence controller
    // BEGIN, CR00358146, GYH
    if (null == targetEvidenceDescriptorDtls) {
      // If the same version of the evidence object is already there on
      // target case then don't share the evidence again.
      boolean shareEvidence = true;

      // BEGIN, CR00365143, ZV
      // Don't share evidence into PDC case for non primary participant.
      if (targetCaseHeaderDtls.caseTypeCode.equals(
        CASETYPECODE.PARTICIPANTDATACASE)) {

        if (targetCaseHeaderDtls.concernRoleID
          != sourceEvidenceDescriptorDtls.participantID) {
          shareEvidence = false;
        }

        if (shareEvidence) {
          // As we are sharing the evidence, it is not modified yet, so
          // set the indicator.

          final EvidenceDescriptorDtls shareEvidenceDescriptorDtls = new EvidenceDescriptorDtls();

          shareEvidenceDescriptorDtls.assign(sourceEvidenceDescriptorDtls);
          shareEvidenceDescriptorDtls.sharedUnchangedInd = true;
          targetEvidenceDescriptorDtls = EvidenceControllerFactory.newInstance().shareEvidence(
            shareEvidenceDescriptorDtls, targetCaseHeaderDtls);
        }
        // END, CR00365143
        // BEGIN, CR00379197, SSK
      } else if (!isDynamicEvidence(sourceEvidenceDescriptorDtls.evidenceType)) {
        // BEGIN, CR00385308, SSK
        targetEvidenceDescriptorDtls = shareStaticEvidence(
          sourceEvidenceDescriptorDtls, targetCaseHeaderDtls);
      } else {

        targetEvidenceDescriptorDtls = shareDynamicEvidence(
          sourceEvidenceDescriptorDtls, targetCaseHeaderDtls);
        // END, CR00385308
      }
    }
    // END, CR00358146
    return targetEvidenceDescriptorDtls;
  }

  /**
   * Creates a workflow task for each shared evidence record. The task is
   * assigned to the target case owner and informs them that there is evidence
   * on their case that requires synchronization.
   *
   * @param targetCaseHeaderDtls
   * Contains the target case details.
   * @param targetEvidenceDescriptorDtls
   * Contains the evidence on the target case which requires
   * synchronization.
   * @param identicalEvidenceInd
   * This indicates whether the task is in relation to identical or
   * non-identical shared evidence.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void createEvidenceSynchronizationTask(
    final CaseHeaderDtls targetCaseHeaderDtls,
    final EvidenceDescriptorDtls targetEvidenceDescriptorDtls,
    final boolean identicalEvidenceInd) throws AppException,
      InformationalException {
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = targetCaseHeaderDtls.caseID;
    final CaseReference caseReference = new CaseReference();

    caseReference.caseReference = targetCaseHeaderDtls.caseReference;
    final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = targetEvidenceDescriptorDtls.evidenceDescriptorID;

    // Retrieve the evidence type as a localisable string
    final EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();

    evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
      CASEEVIDENCE.TABLENAME, targetEvidenceDescriptorDtls.evidenceType,
      TransactionInfo.getProgramLocale());
    evidenceTypeAndDesc.evidenceType = targetEvidenceDescriptorDtls.evidenceType;

    // Create a task and assign to the target case owner
    final List enactmentDataList = new ArrayList();

    enactmentDataList.add(caseReference);
    enactmentDataList.add(caseHeaderKey);
    enactmentDataList.add(evidenceDescriptorKey);
    enactmentDataList.add(evidenceTypeAndDesc);

    String kProcessName = CuramConst.gkNull;

    // BEGIN, CR00398084, SSK
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    evidenceDescriptorKey.evidenceDescriptorID = targetEvidenceDescriptorDtls.evidenceDescriptorID;
    final EvidenceDescriptorDtls updatedEvidenceDescriptorDtls = evidenceDescriptorObj.read(
      evidenceDescriptorKey);
    
    if (identicalEvidenceInd) {
      // BEGIN, CR00389115, SSK
      if (EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALINEDIT.equals(
        EVIDENCEDESCRIPTORSTATUSEntry.get(
          updatedEvidenceDescriptorDtls.statusCode))) {
        if (updatedEvidenceDescriptorDtls.newInd) {

          kProcessName = CuramConst.kCaseParticipantCreationEvidenceSharing;
        } else {
          // END, CR00389115
          kProcessName = CuramConst.kIdenticalSharingEvidenceUpdate;
        }
        // BEGIN, CR00398462, SSK
      } else if (EVIDENCEDESCRIPTORSTATUSEntry.INEDIT.equals(
        EVIDENCEDESCRIPTORSTATUSEntry.get(
          updatedEvidenceDescriptorDtls.statusCode))
            || updatedEvidenceDescriptorDtls.pendingRemovalInd) {

        if (updatedEvidenceDescriptorDtls.newInd) {

          kProcessName = CuramConst.kCaseParticipantCreationEvidenceInEditSharing;
        } else {
          // END, CR00389115
          kProcessName = CuramConst.kIdenticalInEditSharingEvidenceUpdate;
        }
      }
      // END, CR00398084
    } else {

      if (updatedEvidenceDescriptorDtls.newInd) {

        // BEGIN, CR00399418, SSK
        kProcessName = CuramConst.kCaseParticipantCreationEvidenceSharing;
        // END, CR00399418
      } else {

        kProcessName = CuramConst.kNonIdenticalSharingEvidenceUpdate;
      }
    }
    if (kProcessName != CuramConst.gkNull) {
      EnactmentService.startProcess(kProcessName, enactmentDataList);
    }
    // END, CR00398462
  }

  /**
   * Attempts to automatically accept the specified evidence onto the target
   * case. If the evidence could not be accepted automatically a notification is
   * sent to the case owner to notify them of this, so that manual
   * synchronization can be performed.
   *
   * @param evidenceIDAndActionList
   * Contains the evidence to be accepted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void autoAcceptEvidenceOnTargetCase(
    final EvidenceDescriptorIDAndSynchronizeActionList evidenceIDAndActionList)
    throws AppException, InformationalException {

    EvidenceBrokerSynchronizationFactory.newInstance().processIdenticalIncomingEvidence(
      evidenceIDAndActionList);

  }

  private void handleErrorDuringAutoAccept(
    final EvidenceDescriptorIDAndSynchronizeActionList evidenceIDAndActionList)
    throws AppException, InformationalException {

    // If the evidence could not be accepted flush out the informational
    // manager and send a notification to each case owner,
    // it will have to be accepted manually

    if (checkForInformationals().failed) {

      // Get the target case id
      if (!evidenceIDAndActionList.dtlsList.isEmpty()) {

        final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
        final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

        evidenceDescriptorKey.evidenceDescriptorID = evidenceIDAndActionList.dtlsList.item(0).evidenceDescriptorID;
        final EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj.read(
          evidenceDescriptorKey);

        // send notification to each case owner
        notifyCaseOwnersEvidenceAutoActionFailure(evidenceDescriptorDtls,
          EvidenceBrokerConst.evidenceAutoAcceptFailiedWorkflowName);
      }
      TransactionInfo.setInformationalManager();
    }
  }

  // END, CR00370875

  /**
   * Creates an XML string representing the identical evidence and associated
   * action to be performed during synchronization.
   *
   * @param evidenceIDAndActionList
   * Contains the identical shared evidence list to be synchronized.
   *
   * @return An XML string representing the identical evidence and associated
   * action to be performed during synchronization.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected String getIdenticalEvidenceXMLString(
    final EvidenceDescriptorIDAndSynchronizeActionList evidenceIDAndActionList)
    throws AppException, InformationalException {

    // Add opening root element
    String xmlString = CuramConst.kLessThan + EvidenceBrokerConst.kEvidence
      + CuramConst.kGreaterThan;

    // Add a child element for each piece of evidence to be synchronized
    for (final EvidenceDescriptorIDAndSynchronizeAction edIDAndSynchronizeAction : evidenceIDAndActionList.dtlsList.items()) {
      xmlString = xmlString + CuramConst.kLessThan
        + EvidenceBrokerConst.kEvidenceID + CuramConst.gkSpace
        + EvidenceBrokerConst.kID + CuramConst.gkEquals.trim()
        + CuramConst.kQuoteChar + edIDAndSynchronizeAction.evidenceDescriptorID
        + CuramConst.kQuoteChar + CuramConst.gkSpace
        + EvidenceBrokerConst.kValue + CuramConst.gkEquals.trim()
        + CuramConst.kQuoteChar + edIDAndSynchronizeAction.action
        + CuramConst.kQuoteChar + CuramConst.gkSlash.trim()
        + CuramConst.kGreaterThan;
    }

    // Add closing root tag
    xmlString = xmlString + CuramConst.kLessThan + CuramConst.gkSlash.trim()
      + EvidenceBrokerConst.kEvidence + CuramConst.kGreaterThan;

    return xmlString;
  }

  /**
   * Localized function for checking if the <code>InformationalManager<code>
   * contains errors and / or fatal errors.
   *
   * @return An indicator representing whether or not the
   * <code>InformationalManager</code> contains any errors.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected AutoAcceptEvidenceFailureInd checkForInformationals()
    throws AppException, InformationalException {
    final AutoAcceptEvidenceFailureInd autoAcceptEvidenceFailureInd = new AutoAcceptEvidenceFailureInd();

    // Retrieve the list of messages from the Informational Manager
    final LinkedList list = TransactionInfo.getInformationalManager().getMessagesForField(
      CuramConst.gkEmpty);

    for (int i = 0; i < list.size(); i++) {
      final InformationalElement element = (InformationalElement) list.get(i);

      if (element.getInformationalType().equals(
        InformationalElement.InformationalType.kError)
          || element.getInformationalType().equals(
            InformationalElement.InformationalType.kFatalError)) {
        autoAcceptEvidenceFailureInd.failed = true;
        break;
      }
    }
    return autoAcceptEvidenceFailureInd;
  }

  // BEGIN, CR00341649, GYH
  /**
   * Sends a notification to all case owners outlining that the auto acceptance
   * of evidence onto the specified target case has failed, it must be manually
   * accepted.
   *
   * @param key
   * Contains the identifier of the target case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.4.0, replaced with
   * {@link ProcessEvidenceHelper#notifyCaseOwnersEvidenceAutoAcceptFailure(EvidenceDescriptorDtls)}
   * because the workflow enacted for auto accept evidence failure
   * notification was not having the exact reason for the evidence
   * auto acceptance failure. To pass the exact reason for the
   * evidence auto acceptance failure additional enactment
   * parameters are required, so a new method and workflow has been
   * introduced. See release CR00341649.
   */
  @Deprecated
  // END, CR00341649
  protected void notifyCaseOwnersOfAutoAcceptFailure(final CaseHeaderKey key)
    throws AppException, InformationalException {
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = key.caseID;

    // Get the case reference
    final CaseReference caseRef = caseHeaderObj.readCaseReferenceByCaseID(
      caseSearchKey);

    // Get the list of owners for the case
    final UserNameKeyList userNameKeyList = caseUserRoleObj.listOwnerForCase(
      key);

    // send notification to each case owner
    for (final UserNameKey userNameKey : userNameKeyList.dtls.items()) {
      final AutoAcceptEvidenceFailureNotificationDetails notificationDetails = new AutoAcceptEvidenceFailureNotificationDetails();

      notificationDetails.caseReference = caseRef.caseReference;
      notificationDetails.caseOwner = userNameKey.userName;
      notificationDetails.caseID = key.caseID;
      sendAutoAcceptEvidenceFailureNotification(notificationDetails);

    }
  }

  // BEGIN, CR00341649, GYH
  /**
   * Sends a notification to the specified case owner outlining that the auto
   * acceptance of evidence onto the specified target case has failed, it must
   * be manually accepted.
   *
   * @param details
   * Contains notification details to be sent the case owner.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.4.0, replaced with
   * {@link ProcessEvidenceHelper#sendEvidenceAutoAcceptFailureNotification(EvidenceAutoActionFailureNotificationDetails)}
   * because the workflow enacted for auto accept evidence failure
   * notification was not having the exact reason for the evidence
   * auto acceptance failure. To pass the exact reason for the
   * evidence auto acceptance failure additional enactment
   * parameters are required, so a new method and workflow has been
   * introduced. See release CR00341649.
   */
  @Deprecated
  // END, CR00341649
  protected void sendAutoAcceptEvidenceFailureNotification(
    final AutoAcceptEvidenceFailureNotificationDetails details)
    throws AppException, InformationalException {
    final List enactmentStructs = new ArrayList();

    enactmentStructs.add(details);
    EnactmentService.startProcess(
      TaskDefinitionIDConst.autoAcceptEvidenceFailedTaskDefinitionID,
      enactmentStructs);
  }

  /**
   * Finds all cases to which the given evidence has previously been shared,
   * excluding the original case from which the evidence is being removed. Any
   * cases which have a status of <code>CLOSED</code> or <code>CANCELED</code>
   * are not considered.
   *
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor details for the piece of evidence
   * being removed.
   *
   * @return The list of cases to which the given evidence has previously been
   * shared.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public CaseHeaderDtlsList getCasesForEvidenceRemoval(
    final EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {
    final SharedInstanceIDCaseIDStatusCodes key = new SharedInstanceIDCaseIDStatusCodes();

    key.sharedInstanceID = evidenceDescriptorDtls.sharedInstanceID;
    final CaseHeaderKeyList caseHeaderKeyList = EvidenceDescriptorFactory.newInstance().searchDistinctCaseIDBySharedInstanceIDStatusCodes(
      key);
    final CaseHeaderKey originatingCaseID = new CaseHeaderKey();

    originatingCaseID.caseID = evidenceDescriptorDtls.caseID;

    return getCaseHeaderDetails(originatingCaseID, caseHeaderKeyList, false);
  }

  /**
   * Retrieves the shared evidence target type and target ID for the case
   * referred to by the given case header.
   *
   * @param caseHeaderDtls
   * Contains the case ID and case type code.
   *
   * @return The shared evidence target type and ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOEVIDENCECONTROLLER#ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED}
   * - if a particular case type is not supported to access the
   * required functionality.
   */
  public SharedEvidenceSourceTypeAndSourceIDDetails getSharingTargetTypeAndTargetID(
    final CaseHeaderDtls caseHeaderDtls) throws AppException,
      InformationalException {
    final SharedEvidenceSourceTypeAndSourceIDDetails sharedEvidenceTargetDetails = new SharedEvidenceSourceTypeAndSourceIDDetails();

    // The case type is our shared evidence target type
    sharedEvidenceTargetDetails.sourceType = caseHeaderDtls.caseTypeCode;

    // Retrieve the corresponding target ID
    final CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
      caseHeaderDtls.caseTypeCode);

    if (null == caseTypeEvidence) {
      final AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME,
        caseHeaderDtls.caseTypeCode, TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 12);
    }
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseHeaderDtls.caseID;
    sharedEvidenceTargetDetails.sourceID = caseTypeEvidence.readEvidenceBrokerSourceIDByCaseID(
      caseKey);

    return sharedEvidenceTargetDetails;
  }

  /**
   * Retrieves the shared evidence source ID and source type for the case
   * referred to by the given evidence descriptor.
   *
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor ID.
   *
   * @return The shared evidence source ID and type.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOEVIDENCECONTROLLER#ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED}
   * - if a particular case type is not supported to access the
   * required functionality.
   */
  public SharedEvidenceSourceTypeAndSourceIDDetails getSharingSourceTypeAndSourceID(
    final EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = evidenceDescriptorDtls.caseID;
    final CaseTypeCode caseTypeCode = CachedCaseHeaderFactory.newInstance().readCaseTypeCode(
      caseKey);

    final SharedEvidenceSourceTypeAndSourceIDDetails sharedEvidenceSourceTypeAndSourceIDDetails = new SharedEvidenceSourceTypeAndSourceIDDetails();

    // The case type is our shared evidence source type
    sharedEvidenceSourceTypeAndSourceIDDetails.sourceType = caseTypeCode.caseTypeCode;
    final CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
      caseTypeCode.caseTypeCode);

    if (null == caseTypeEvidence) {
      final AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, caseTypeCode.caseTypeCode,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 13);
    }
    sharedEvidenceSourceTypeAndSourceIDDetails.sourceID = caseTypeEvidence.readEvidenceBrokerSourceIDByCaseID(
      caseKey);

    return sharedEvidenceSourceTypeAndSourceIDDetails;
  }

  /**
   * Finds all the evidence that must be shared with the new case. It identifies
   * all existing cases for this participant and then examines each case in turn
   * and extracts any evidence that is relevant for the new case.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the evidence broker configuration information relevant to
   * the new case.
   * @param caseParticipantRoleDtls
   * Contains the case participant role who's evidence should be
   * examined.
   *
   * @return The list of evidence that must be shared with the new case
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public EvidenceDescriptorDtlsList getSharedEvidenceForCaseParticipantCreation(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final CaseParticipantRoleDtls caseParticipantRoleDtls)
    throws AppException, InformationalException {

    // Check if there are any cases which might have relevant evidence
    final CaseIDConcernRoleID key = new CaseIDConcernRoleID();

    key.caseID = caseParticipantRoleDtls.caseID;
    key.concernRoleID = caseParticipantRoleDtls.participantRoleID;
    final CaseHeaderDtlsList sourceCaseHeaderList = getCasesWithActiveParticipantEvidence(
      key);

    // Filter the list of source cases. Any cases which are not applicable
    // to our list of evidence sharing configurations will be removed.
    filterSourceCaseList(evidenceBrokerConfigDtlsList, sourceCaseHeaderList);

    EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = new EvidenceDescriptorDtlsList();

    if (!sourceCaseHeaderList.dtls.isEmpty()) {

      // Retrieve all evidence that must be shared with the new case
      evidenceDescriptorDtlsList = getCaseParticipantEvidence(
        evidenceBrokerConfigDtlsList, sourceCaseHeaderList,
        caseParticipantRoleDtls);
    }
    
    // BEGIN, CR00414383, RPB
    if (evidenceDescriptorDtlsList.dtls.size() > 0) {
      TransactionInfo.setFacadeScopeObject(
        EvidenceBrokerConst.gkShareEvidenceForCPErrorHandlerEvds,
        evidenceDescriptorDtlsList);
    }
    if (sourceCaseHeaderList.dtls.size() > 0) {
      TransactionInfo.setFacadeScopeObject(
        EvidenceBrokerConst.gkShareEvidenceForCPErrorHandlerSource,
        sourceCaseHeaderList.dtls.get(0));
    }
    // END, CR00414383
    return evidenceDescriptorDtlsList;
  }

  /**
   * Creates a workflow task for the case. The task is assigned to the target
   * case owner of the target case and informs them that there is evidence on
   * their case that requires synchronization.
   *
   * @param targetCaseHeaderDtls
   * Contains the target case details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void createCaseParticipantCreationSynchronizationTask(
    final CaseHeaderDtls targetCaseHeaderDtls) throws AppException,
      InformationalException {
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = targetCaseHeaderDtls.caseID;
    final CaseReference caseReference = new CaseReference();

    caseReference.caseReference = targetCaseHeaderDtls.caseReference;

    // Create a task and assign to the target case owner
    final List enactmentDataList = new ArrayList();

    enactmentDataList.add(caseReference);
    enactmentDataList.add(caseHeaderKey);
    EnactmentService.startProcess(
      CuramConst.kCaseParticipantCreationEvidenceSharing, enactmentDataList);
  }

  /**
   * Iterates through a given list of source cases and checks if any of the
   * evidence broker configurations specified are applicable to the case. If
   * none of the evidence broker configurations are applicable, that case is
   * removed from the list.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the evidence broker configuration information relevant to
   * the new case.
   * @param sourceCaseHeaderList
   * Contains the list of source cases to be filtered.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOEVIDENCECONTROLLER#ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED}
   * - if a particular case type is not supported to access the
   * required functionality.
   */
  protected void filterSourceCaseList(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final CaseHeaderDtlsList sourceCaseHeaderList) throws AppException,
      InformationalException {
    for (int i = 0; i < sourceCaseHeaderList.dtls.size(); i++) {
      boolean isConfigurationFound = false;
      final CaseHeaderDtls sourceCaseHeaderDtls = sourceCaseHeaderList.dtls.item(
        i);

      // Check each evidence broker configuration against this case
      for (final EvidenceBrokerConfigDtls evidenceBrokerConfigDtls : evidenceBrokerConfigDtlsList.dtls.items()) {

        // Check if this configuration is applicable to the case
        if (sourceCaseHeaderDtls.caseTypeCode.equalsIgnoreCase(
          evidenceBrokerConfigDtls.sourceType)) {

          final CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
            sourceCaseHeaderDtls.caseTypeCode);

          if (null == caseTypeEvidence) {
            final AppException e = new AppException(
              BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

            e.arg(
              CodeTable.getOneItem(CASETYPECODE.TABLENAME,
              sourceCaseHeaderDtls.caseTypeCode,
              TransactionInfo.getProgramLocale()));
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              e,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              11);
          }
          // BEGIN, CR00237356, GYH
          final CaseKey caseKey = new CaseKey();

          caseKey.caseID = sourceCaseHeaderDtls.caseID;

          // Retrieve the corresponding source ID
          if (evidenceBrokerConfigDtls.sourceID
            == caseTypeEvidence.readEvidenceBrokerSourceIDByCaseID(caseKey)) {
            isConfigurationFound = true;
            break;
          }
          // END, CR00237356
        }
      }

      // If none of the configurations are applicable remove this case
      if (!isConfigurationFound) {
        sourceCaseHeaderList.dtls.remove(i);
        i--; // When (i) is removed the rest of the list drops down one
        // - this
        // decrement ensures we don't skip any cases
      }
    }
  }

  /**
   * Retrieves any cases on which the given participant has active evidence,
   * excluding the case to which the participant is being added. Any cases which
   * have a status of <CLOSED> or <CANCELLED> are not considered.
   *
   * @param caseIDConcernRoleID
   * Contains the ID of the participant who's cases we are looking for
   * and the ID of the new case to which the participant is being
   * added.
   *
   * @return The list of cases on which the given participant has some active
   * evidence.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected CaseHeaderDtlsList getCasesWithActiveParticipantEvidence(
    final CaseIDConcernRoleID caseIDConcernRoleID) throws AppException,
      InformationalException {
    final ParticipantIDStatusCode key = new ParticipantIDStatusCode();

    key.participantID = caseIDConcernRoleID.concernRoleID;
    final CaseHeaderKeyList caseHeaderKeyList = EvidenceDescriptorFactory.newInstance().searchActiveForDistinctCaseIDByParticipantID(
      key);

    final CaseHeaderKey originatingCaseID = new CaseHeaderKey();

    originatingCaseID.caseID = caseIDConcernRoleID.caseID;

    return getCaseHeaderDetails(originatingCaseID, caseHeaderKeyList, true);
  }

  /**
   * Identifies all the pieces of evidence from the given list of cases that are
   * related to the specified case participant and must be shared with the new
   * case.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the evidence broker configuration information relevant to
   * the new case.
   * @param sourceCaseHeaderList
   * Contains the list of cases which may contain evidence that is
   * relevant to the new case.
   * @param caseParticipantRoleDtls
   * Contains the ID of the participant who's evidence should be
   * examined.
   *
   * @return The list of evidence that must be shared with the new case
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  protected EvidenceDescriptorDtlsList getCaseParticipantEvidence(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final CaseHeaderDtlsList sourceCaseHeaderList,
    final CaseParticipantRoleDtls caseParticipantRoleDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00369351, SSK
    final EvidenceDescriptorDtlsList sourceEvidenceDescriptorDtlsList = new EvidenceDescriptorDtlsList();
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    EvidenceDescriptorDtlsList activeCaseParticipantEvidenceList;

    final Set<Long> includedActiveEvidenceIDs = new HashSet<Long>();
    final Map<String, List<EvidenceDescriptorDtls>> updatedEvidenceList = new HashMap<String, List<EvidenceDescriptorDtls>>();
    List<EvidenceDescriptorDtls> evidenceDescriptorList;

    for (final CaseHeaderDtls sourceCaseHeaderDtls : sourceCaseHeaderList.dtls.items()) {

      activeCaseParticipantEvidenceList = new EvidenceDescriptorDtlsList();
      // Find all the active evidence for the participant on this case
      final CaseIDParticipantIDStatusCode key = new CaseIDParticipantIDStatusCode();

      key.caseID = sourceCaseHeaderDtls.caseID;
      key.participantID = caseParticipantRoleDtls.participantRoleID;
      activeCaseParticipantEvidenceList.dtls.addAll(
        evidenceDescriptorObj.searchActiveByCaseIDParticipantID(key).dtls);

      final Map<String, List<EvidenceDescriptorDtls>> filteredEvidenceList = filterEvidenceDescriptorDtlsListBasedOnEvidenceType(
        activeCaseParticipantEvidenceList);

      EvidenceBrokerConfigDtls evidenceBrokerConfigDtls;

      for (final List<EvidenceDescriptorDtls> list : filteredEvidenceList.values()) {
        if (list.size() > 0) {
          evidenceDescriptorList = new ArrayList<EvidenceDescriptorDtls>();
          evidenceBrokerConfigDtls = getApplicableEvidenceBrokerConfig(
            evidenceBrokerConfigDtlsList, list.get(0));
          // BEGIN, CR00356862, SSK
          if (evidenceBrokerConfigDtls != null) {
            // END, CR00356862
            if (EVIDENCESHARINGLIMITTYPE.SHARELATEST.equals(
              evidenceBrokerConfigDtls.shareLimitType)) {
              evidenceDescriptorList.add(getLatestEvidence(list));

            } else if (EVIDENCESHARINGLIMITTYPE.SHARELAST.equals(
              evidenceBrokerConfigDtls.shareLimitType)) {
              if (EVIDENCESHARELASTOPTION.UPDATES.equals(
                evidenceBrokerConfigDtls.shareLastOption)) {
                final EvidenceDescriptorDtls activeRecordOnCase = getLatestEvidence(
                  list);

                evidenceDescriptorList.add(activeRecordOnCase);
                includedActiveEvidenceIDs.add(
                  activeRecordOnCase.evidenceDescriptorID);
                if (updatedEvidenceList.containsKey(
                  activeRecordOnCase.evidenceType)) {
                  updatedEvidenceList.get(activeRecordOnCase.evidenceType).addAll(
                    list);
                } else {
                  updatedEvidenceList.put(activeRecordOnCase.evidenceType, list);
                }
              } else {
                final java.util.Date applicableDateTime = getApplicableDateTime(
                  evidenceBrokerConfigDtls);
                final List<EvidenceDescriptorDtls> lastEvidenceList = filterActivatedEvidencesByDateTime(
                  list, applicableDateTime);

                evidenceDescriptorList.addAll(lastEvidenceList);
              }

            } else {
              evidenceDescriptorList.addAll(list);
            }
            for (final EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorList) {
              if (evidenceBrokerConfigDtls.sharedType.equals(
                EVIDENCESHARINGTYPE.IDENTICAL)) {

                evidenceDescriptorDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
              } else {
                evidenceDescriptorDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;
              }
              sourceEvidenceDescriptorDtlsList.dtls.add(evidenceDescriptorDtls);
            }
          }
        }
      }
      // END, CR00351925
    }

    // BEGIN, CR00406334, SSK
    if (!updatedEvidenceList.isEmpty()) {

      final EvidenceDescriptorDtlsList sourceUpdatedEvidenceDescriptorDtlsList = filterActiveUpdatedEvidences(
        updatedEvidenceList, includedActiveEvidenceIDs,
        evidenceBrokerConfigDtlsList);

      sourceEvidenceDescriptorDtlsList.dtls.addAll(
        sourceUpdatedEvidenceDescriptorDtlsList.dtls);
    }
    // END, CR00406334

    // CR00369351, END
    return sourceEvidenceDescriptorDtlsList;
  }

  // BEGIN, CR00369351, SSK
  /**
   * Filters the active updated evidences based on already included active
   * evidences.
   *
   * @param updatedEvidenceList
   * List of updated evidences.
   * @param includedActiveEvidenceIDsList
   * List of already included evidence ID to be shared.
   * @param evidenceBrokerConfigDtlsList
   * List of evidence broker configuration.
   *
   * @return The list of filtered evidences.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected EvidenceDescriptorDtlsList filterActiveUpdatedEvidences(
    final Map<String, List<EvidenceDescriptorDtls>> updatedEvidenceList,
    final Set<Long> includedActiveEvidenceIDsList,
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList)
    throws AppException, InformationalException {
    final EvidenceDescriptorDtlsList sourceEvidenceDescriptorDtlsList = new EvidenceDescriptorDtlsList();
    List<EvidenceDescriptorDtls> evidenceDescriptorList;
    EvidenceBrokerConfigDtls evidenceBrokerConfigDtls;

    for (final List<EvidenceDescriptorDtls> list : updatedEvidenceList.values()) {
      if (list.size() > 0) {
        evidenceDescriptorList = new ArrayList<EvidenceDescriptorDtls>();

        evidenceBrokerConfigDtls = getApplicableEvidenceBrokerConfig(
          evidenceBrokerConfigDtlsList, list.get(0));

        if (evidenceBrokerConfigDtls != null) {
          evidenceDescriptorList.addAll(
            getUpdatedEvidence(list, includedActiveEvidenceIDsList,
            evidenceBrokerConfigDtls.shareLastNumber));
          for (final EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorList) {
            if (evidenceBrokerConfigDtls.sharedType.equals(
              EVIDENCESHARINGTYPE.IDENTICAL)) {

              evidenceDescriptorDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
            } else {
              evidenceDescriptorDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;
            }
            sourceEvidenceDescriptorDtlsList.dtls.add(evidenceDescriptorDtls);

          }

        }
      }

    }

    return sourceEvidenceDescriptorDtlsList;

  }

  // END, CR00369351

  // BEGIN, CR00206415, PB
  /**
   * Processes evidence which is configured for identical sharing. Puts the new
   * evidence received from a remote system on the case for which evidence
   * should be shared with. A task will be sent to the relevant case owners
   * informing them that evidence has been shared with their case.
   *
   * @param sharedEvidenceDescriptorDetails
   * Contains the evidence details received from a remote system to be
   * shared.
   * @param identicalCaseHeaderDtls
   * Contains the case details with which this evidence could be
   * shared.
   *
   * @throws AppException
   * {@link BPOEVIDENCEBROKER#ERR_EVIDENCEBROKER_IDENTICAL_CONFIG_RECORDS_EXIST}
   * - if an evidence type is configured for multiple identical
   * sharing.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processExternalIdenticalEvidenceSharingForCase(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails,
    final CaseHeaderDtls identicalCaseHeaderDtls) throws AppException,
      InformationalException {

    processExternalIdenticalEvidenceSharingForCase(
      sharedEvidenceDescriptorDetails, identicalCaseHeaderDtls, Boolean.TRUE,
      Boolean.TRUE);
  }

  /**
   * Processes evidence which is configured for identical sharing. Puts the new
   * evidence received from a remote system on the case for which evidence
   * should be shared with. A task will be sent to the relevant case owners
   * informing them that evidence has been shared with their case.
   *
   * @param sharedEvidenceDescriptorDetails
   * Contains the evidence details received from a remote system to be
   * shared.
   * @param identicalCaseHeaderDtls
   * Contains the case details with which this evidence could be
   * shared.
   *
   * @throws AppException
   * {@link BPOEVIDENCEBROKER#ERR_EVIDENCEBROKER_IDENTICAL_CONFIG_RECORDS_EXIST}
   * - if an evidence type is configured for multiple identical
   * sharing.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processExternalIdenticalEvidenceSharingForCase(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails,
    final CaseHeaderDtls identicalCaseHeaderDtls,
    Boolean considerAutoAcceptance, Boolean considerAutoActivation)
    throws AppException, InformationalException {

    // BEGIN, CR00388582, RPB
    boolean autoActivateInd = false;
    // END, CR00388582
    final EvidenceDescriptorDtls targetEvidenceDescriptorDtls = broadcastExternalEvidence(
      sharedEvidenceDescriptorDetails, identicalCaseHeaderDtls);
   
    // Get target type and target ID
    final SharedEvidenceSourceTypeAndSourceIDDetails targetTypeAndTargetID = getSharingTargetTypeAndTargetID(
      identicalCaseHeaderDtls);

    // Get source type and source ID
    final EvidenceSharingConfigKey key = new EvidenceSharingConfigKey();

    key.recordStatus = RECORDSTATUS.NORMAL;
    key.sharedType = EVIDENCESHARINGTYPE.IDENTICAL;
    key.sourceEvidenceType = sharedEvidenceDescriptorDetails.details.evidenceType;
    key.sourceID = sharedEvidenceDescriptorDetails.sourceID;
    key.sourceType = sharedEvidenceDescriptorDetails.sourceType;
    key.targetID = targetTypeAndTargetID.sourceID;
    key.targetType = targetTypeAndTargetID.sourceType;
    key.sourceSystemID = sharedEvidenceDescriptorDetails.sourceSystemID;
    key.targetEvidenceType = sharedEvidenceDescriptorDetails.details.evidenceType;
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlslist = EvidenceBrokerConfigAdminFactory.newInstance().listSharedSourceAndTargetEvidences(
      key);
    
    // BEGIN, CR00426922, KRK
    if (null
      != TransactionInfo.getFacadeScopeObject(
        VerificationConst.kPostponeVerification) 
          && TransactionInfo.getFacadeScopeObject(VerificationConst.kPostponeVerification).equals(
            true)) {
      
      if (null != targetEvidenceDescriptorDtls) {
        createSourceVerificationItemProvidedDetails(
          targetEvidenceDescriptorDtls, evidenceBrokerConfigDtlslist);
      }          
    }        
    // END, CR00426922

    // If we find the corresponding configuration and auto accept is set
    if (1 == evidenceBrokerConfigDtlslist.dtls.size()) {
      if (evidenceBrokerConfigDtlslist.dtls.item(0).autoAcceptInd) {

        // Add the target evidence to the auto accept list
        final EvidenceDescriptorIDAndSynchronizeAction evidenceIDAndAction = new EvidenceDescriptorIDAndSynchronizeAction();

        evidenceIDAndAction.action = SYNCHRONIZATIONACTION.ACCEPT;
        evidenceIDAndAction.evidenceDescriptorID = targetEvidenceDescriptorDtls.evidenceDescriptorID;

        final EvidenceDescriptorIDAndSynchronizeActionList evidenceIDAndActionList = new EvidenceDescriptorIDAndSynchronizeActionList();

        evidenceIDAndActionList.dtlsList.addRef(evidenceIDAndAction);

        if (considerAutoAcceptance) {
          autoAcceptEvidenceOnTargetCase(evidenceIDAndActionList);
        }

        // BEGIN, CR00342079, GYH
        if (evidenceBrokerConfigDtlslist.dtls.item(0).autoActivateInd) {

          final CaseKey caseKey = new CaseKey();

          caseKey.caseID = targetEvidenceDescriptorDtls.caseID;
          final EvidenceDescriptorKeyList evidenceDescriptorKeyList = new EvidenceDescriptorKeyList();
          final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

          evidenceDescriptorKey.evidenceDescriptorID = targetEvidenceDescriptorDtls.evidenceDescriptorID;
          evidenceDescriptorKeyList.dtls.add(evidenceDescriptorKey);

          if (considerAutoActivation) {
            autoActivateEvidenceOnTargetCase(caseKey, evidenceDescriptorKeyList);
            // BEGIN, CR00388582, RPB
            autoActivateInd = true;
            // END, CR00388582
          }
        }
        // END, CR00342079
      }
    } // BEGIN, CR00377908, RPB
    else if (1 < evidenceBrokerConfigDtlslist.dtls.size()) {
      // END, CR00377908
      // Multiple matching configuration records exist
      final AppException e = new AppException(
        BPOEVIDENCEBROKER.ERR_EVIDENCEBROKER_IDENTICAL_CONFIG_RECORDS_EXIST);

      e.arg(
        CodeTable.getOneItem(CASEEVIDENCE.TABLENAME,
        sharedEvidenceDescriptorDetails.details.evidenceType,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // BEGIN, CR00388582, RPB
    if (evidenceBrokerTaskGenerationStrategy.determineTaskGenerationForIdenticalEvdSharing(
      targetEvidenceDescriptorDtls, autoActivateInd)) {
      // END, CR00388582

      // Create a workflow task for each evidence record which has been shared
      createEvidenceSynchronizationTask(identicalCaseHeaderDtls,
        targetEvidenceDescriptorDtls, true);
    }
  }

  /**
   * Processes evidence received from a remote system which is configured for
   * non identical sharing. It determines which of the given list of cases the
   * evidence could be relevant to and then sends a notification to each case
   * owner informing them that evidence relevant to their case has been modified
   * and should be examined.
   *
   * @param sharedEvidenceDescriptorDetails
   * Contains the evidence details received from a remote system to be
   * shared.
   * @param nonIdenticalCaseHeaderDtls
   * Contains the list of cases with which this evidence could be
   * shared.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * @throws AppException
   * Generic Exception Signature.
   */
  public void processExternalNonIdenticalEvidenceSharingForCase(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails,
    final CaseHeaderDtls nonIdenticalCaseHeaderDtls) throws AppException,
      InformationalException {

    final EvidenceDescriptorDtls targetEvidenceDescriptorDtls = broadcastExternalEvidence(
      sharedEvidenceDescriptorDetails, nonIdenticalCaseHeaderDtls);

    // BEGIN, CR00237356, GYH
    // Check if non identical evidence has already been auto accepted onto
    // target case, if not then create a workflow task to resolve the
    // evidence.
    if (!isNonIdenticalEvidenceAutoAccepted(
      sharedEvidenceDescriptorDetails.details, nonIdenticalCaseHeaderDtls)) {
      // BEGIN, CR00398056, RD
      if (evidenceBrokerTaskGenerationStrategy.determineTaskGenerationForNonIdenticalEvdSharing(
        targetEvidenceDescriptorDtls)) {
        // END, CR00398056
        createEvidenceSynchronizationTask(nonIdenticalCaseHeaderDtls,
          targetEvidenceDescriptorDtls, false);
      }
    }
    // END, CR00237356
  }

  /**
   * Adds the source evidence to the target case. It adds the evidence received
   * from a remote system via the broadcast service layer hook for the
   * corresponding evidence type if available, otherwise the evidence is added
   * directly via the evidence controller.
   *
   * @param sharedEvidenceDescriptorDetails
   * Contains the evidence details to be broadcast.
   * @param targetCaseHeaderDtls
   * Contains the target case that the evidence is being broadcast to.
   *
   * @return The evidence which has been added to the target case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException
   * @throws InformationalException
   */
  protected EvidenceDescriptorDtls broadcastExternalEvidence(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails,
    final CaseHeaderDtls targetCaseHeaderDtls) throws AppException,
      InformationalException {

    final CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
      targetCaseHeaderDtls.caseTypeCode);

    if (null == caseTypeEvidence) {
      final AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME,
        targetCaseHeaderDtls.caseTypeCode, TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 16);
    }
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = targetCaseHeaderDtls.caseID;
    final BroadcastEvidence broadcastEvidenceObj = BroadcastEvidenceManager.getHook(
      caseTypeEvidence.getCaseTypeCode(caseKey));

    // Try to share the evidence using the evidence specific broadcast
    EvidenceDescriptorDtls targetEvidenceDescriptorDtls = broadcastEvidenceObj.processExternalBroadcast(
      sharedEvidenceDescriptorDetails, targetCaseHeaderDtls);

    // If the evidence specific broadcast is not configured share the
    // evidence
    // directly via the evidence controller
    if (null == targetEvidenceDescriptorDtls) {
      targetEvidenceDescriptorDtls = EvidenceControllerFactory.newInstance().shareExternalEvidence(
        sharedEvidenceDescriptorDetails, targetCaseHeaderDtls);
    }
    return targetEvidenceDescriptorDtls;
  }

  // END, CR00206415

  // BEGIN, CR00237356, GYH
  /**
   * Returns true or false based on whether evidence being passed is auto
   * accepted or not. Returns true if evidence being passed is auto accepted
   * else false.
   *
   * @param targetCaseHeaderDtls
   * Contains the target case that the evidence is being broadcast to.
   *
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor record to be checked for auto
   * acceptance.
   * @return Returns true if evidence being passed is auto accepted else false.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public boolean isNonIdenticalEvidenceAutoAccepted(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final CaseHeaderDtls caseHeaderDtls) throws AppException,
      InformationalException {

    // Check if BroadcastEvidence implementation has been provided for the
    // case
    // type in process.
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseHeaderDtls.caseID;
    final CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
      caseHeaderDtls.caseTypeCode);

    if (null == caseTypeEvidence) {
      final AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME,
        caseHeaderDtls.caseTypeCode, TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 14);
    }
    final BroadcastEvidence broadcastEvidenceObj = BroadcastEvidenceManager.getHook(
      caseTypeEvidence.getCaseTypeCode(caseKey));
    final EvidenceAutoAcceptanceInd evidenceAutoAcceptanceInd = broadcastEvidenceObj.isAutoAccepted(
      evidenceDescriptorDtls, caseHeaderDtls);

    // If 'evidenceAutoAcceptanceInd' is set to 'true' then it means that
    // evidence has already been auto accepted onto target case. If it is
    // set to
    // 'false' or null is returned, then it means that evidence has not been
    // auto accepted onto target case.
    if (null != evidenceAutoAcceptanceInd
      && evidenceAutoAcceptanceInd.evidenceAutoAcceptanceInd) {
      return true;
    } else {
      return false;
    }
  }

  // END, CR00237356

  // BEGIN, CR00342079, GYH
  // BEGIN, CR00341649, GYH
  /**
   * Constructs evidence auto action (the auto action could be auto accept or
   * auto activate) failure notification message and sends this notification to
   * all case owners outlining the failure reason.
   *
   * @param evidenceDescriptorDtls
   * Contains evidence descriptor details.
   *
   * @param workflowName
   * The name of the workflow used for sending notification.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void notifyCaseOwnersEvidenceAutoActionFailure(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final String workflowName) throws AppException, InformationalException {

    // Get the list of owners for the case
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
    final UserNameKeyList userNameKeyList = CaseUserRoleFactory.newInstance().listOwnerForCase(
      caseHeaderKey);

    final EvidenceAutoActionFailureNotificationDetails EvidenceAutoActionFailureNotificationDetails = populateEvidenceAutoActionFailureNotificationDetails(
      evidenceDescriptorDtls);

    // send notification to each case owner
    for (final UserNameKey userNameKey : userNameKeyList.dtls.items()) {
      EvidenceAutoActionFailureNotificationDetails.details.caseOwner = userNameKey.userName;
      sendEvidenceAutoActionFailureNotification(
        EvidenceAutoActionFailureNotificationDetails, workflowName);
    }
  }

  /**
   * Populates evidence auto action (the auto action could be auto accept or
   * auto activate) failure details.
   *
   * @param evidenceDescriptorDtls
   * Contains evidence descriptor details.
   *
   * @return The evidence auto action failure details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected EvidenceAutoActionFailureNotificationDetails populateEvidenceAutoActionFailureNotificationDetails(
    final EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {
    final EvidenceAutoActionFailureNotificationDetails EvidenceAutoActionFailureNotificationDetails = new EvidenceAutoActionFailureNotificationDetails();

    // Get the case reference
    final CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = evidenceDescriptorDtls.caseID;

    EvidenceAutoActionFailureNotificationDetails.details.caseReference = CaseHeaderFactory.newInstance().readCaseReferenceByCaseID(caseSearchKey).caseReference;

    EvidenceAutoActionFailureNotificationDetails.details.caseID = evidenceDescriptorDtls.caseID;
    EvidenceAutoActionFailureNotificationDetails.evidenceType = CodeTable.getOneItem(
      CASEEVIDENCE.TABLENAME, evidenceDescriptorDtls.evidenceType,
      TransactionInfo.getProgramLocale());

    // Get evidence description
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
    eiEvidenceKey.evidenceType = evidenceDescriptorDtls.evidenceType;
    final String evidenceDescription = LocalizableXMLStringHelper.toPlainText(
      EvidenceControllerFactory.newInstance().getEvidenceSummaryDetails(eiEvidenceKey).summary);

    if (evidenceDescription.endsWith(CuramConst.gkFullStop)) {
      EvidenceAutoActionFailureNotificationDetails.description = evidenceDescription.substring(
        0, evidenceDescription.length() - 1);
    } else {
      EvidenceAutoActionFailureNotificationDetails.description = evidenceDescription;
    }

    // Get the evidence period.
    final EvidencePeriod evidencePeriod = getEvidencePeriod(
      evidenceDescriptorDtls);

    final String period = getPeriodAsLocalizedString(evidencePeriod).getMessage();

    if (period.endsWith(CuramConst.gkDash)) {
      EvidenceAutoActionFailureNotificationDetails.period = period.substring(0,
        period.length() - 1);
    } else {
      EvidenceAutoActionFailureNotificationDetails.period = period;
    }

    // Get the participant name and populate to return structure
    if (evidenceDescriptorDtls.participantID != 0) {
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = evidenceDescriptorDtls.participantID;
      EvidenceAutoActionFailureNotificationDetails.clientName = ConcernRoleFactory.newInstance().readConcernRoleName(concernRoleKey).concernRoleName;
    }

    // Evidence auto accept failure reason
    final String reason = TransactionInfo.getInformationalManager().obtainInformationalAsException().getLocalizedMessage();
    final StringBuffer evidenceAutoAcceptFailureReason = new StringBuffer();

    evidenceAutoAcceptFailureReason.append(reason.substring(0, 1).toLowerCase()).append(
      reason.substring(1, reason.length()));
    EvidenceAutoActionFailureNotificationDetails.reason = evidenceAutoAcceptFailureReason.toString();
    return EvidenceAutoActionFailureNotificationDetails;
  }

  /**
   * Sends a auto action (the auto action could be auto accept or auto activate)
   * failure notification to the specified case owner outlining the failure
   * reason.
   *
   * @param EvidenceAutoActionFailureNotificationDetails
   * Contains notification details to be sent to the case owner.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void sendEvidenceAutoActionFailureNotification(
    final EvidenceAutoActionFailureNotificationDetails EvidenceAutoActionFailureNotificationDetails,
    final String workflowName) throws AppException, InformationalException {
    final List enactmentStructs = new ArrayList();

    enactmentStructs.add(EvidenceAutoActionFailureNotificationDetails);
    EnactmentService.startProcess(workflowName, enactmentStructs);
  }

  /**
   * Returns evidence period for the given evidence descriptor record.
   *
   * @param evidenceDescriptorDtls
   * Contains evidence descriptor record.
   *
   * @return The evidence period for the evidence descriptor record.
   *
   * @throws AppException
   * Generic AppException Signature
   * @throws InformationalException
   * Generic InformationalException Signature
   */
  protected EvidencePeriod getEvidencePeriod(
    final EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {
    final EvidencePeriod evidencePeriod = new EvidencePeriod();

    // Set evidence type to access relevant evidence interface
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = evidenceDescriptorDtls.evidenceType;
    final EvidenceMap map = EvidenceController.getEvidenceMap();
    final StandardEvidenceInterface standardEvidenceInterface = map.getEvidenceType(
      evidenceTypeKey.evidenceType);

    // get the start date from the standard evidence interface
    final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceType = evidenceDescriptorDtls.evidenceType;
    eiEvidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
    evidencePeriod.startDate = standardEvidenceInterface.getStartDate(
      eiEvidenceKey);

    // If the start date is null or the zero date, get the case start date
    if (null == evidencePeriod.startDate || evidencePeriod.startDate.isZero()) {
      final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
      evidencePeriod.startDate = caseHeaderObj.readStartDate(caseHeaderKey).startDate;

    }

    // Retrieve end date from the standard evidence interface
    evidencePeriod.endDate = standardEvidenceInterface.getEndDate(eiEvidenceKey);

    // If the end date is null, set it to be the zero date
    if (null == evidencePeriod.endDate) {
      evidencePeriod.endDate = new Date();
    }

    return evidencePeriod;
  }

  /**
   * Convert the supplied evidence period to a localisable string.
   *
   * @param evidencePeriod
   * The evidence period to be convert into localisable string.
   * @return The localisable evidence period string.
   */
  protected LocalisableString getPeriodAsLocalizedString(
    final EvidencePeriod evidencePeriod) {

    LocalisableString period = null;

    if (evidencePeriod.endDate.isZero()) {
      period = new LocalisableString(
        BPOEVIDENCECONTROLLER.INF_PERIOD_NO_END_DATE);
      period.arg(evidencePeriod.startDate);
    } else {
      period = new LocalisableString(BPOEVIDENCECONTROLLER.INF_PERIOD);
      period.arg(evidencePeriod.startDate);
      period.arg(evidencePeriod.endDate);
    }
    return period;
  }

  // END, CR00341649

  // BEGIN, CR00343580, GYH
  /**
   * Processes the evidence to be auto activated. Attempts to automatically
   * activate the specified evidences onto the target case if the shared
   * evidence does not require bulk activation, if bulk activation is required
   * then store the evidence in data store so that this evidence is available
   * for bulk activation process.
   *
   * @param sourceEvidenceDescriptorDtls
   * Contains the source evidence details.
   * @param targetEvidenceDescriptorDtls
   * Contains the target evidence to be activated.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void processEvidenceAutoActivation(
    final EvidenceDescriptorDtls sourceEvidenceDescriptorDtls,
    final EvidenceDescriptorDtls targetEvidenceDescriptorDtls)
    throws AppException, InformationalException {
    // If the shared evidence is for evidence removal, then we need to
    // activate the corresponding evidence to be removed on target case.
    if (targetEvidenceDescriptorDtls.pendingRemovalInd) {

      // Find any identical shared records affected by the accept
      final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
      final SharedInstanceIDCaseIDStatusCodes sharedInstanceCaseIDKey = new SharedInstanceIDCaseIDStatusCodes();

      sharedInstanceCaseIDKey.caseID = targetEvidenceDescriptorDtls.caseID;
      sharedInstanceCaseIDKey.sharedInstanceID = targetEvidenceDescriptorDtls.sharedInstanceID;

      final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = evidenceDescriptorObj.searchBySharedInstanceIDCaseIDStatusCodes(
        sharedInstanceCaseIDKey);

      for (final EvidenceDescriptorDtls evidenceDescriptorDetails : evidenceDescriptorDtlsList.dtls.items()) {

        if (evidenceDescriptorDetails.pendingRemovalInd
          && EVIDENCEDESCRIPTORSTATUSEntry.ACTIVE.equals(
            EVIDENCEDESCRIPTORSTATUSEntry.get(
              evidenceDescriptorDetails.statusCode))) {
          targetEvidenceDescriptorDtls.assign(evidenceDescriptorDetails);
          break;
        }
      }
    }

    // Read the data store key from cache and then read the data store
    // entity to add the shared target evidence details.
    Datastore sourceEvidenceDatastore = null;

    try {
      sourceEvidenceDatastore = DatastoreFactory.newInstance().openDatastore(
        EvidenceBrokerConst.kTargetEvidenceData);
    } catch (final NoSuchSchemaException e) {// do nothing.
    }
    // BEGIN, CR00387550, SSK
    final Cache<String, String> evidenceDataCache = CacheManagerEjb.getTransactionLocalCacheGroup().getCache(
      EvidenceBrokerConst.kEvidenceTransactionCacheDatastoreKey);
    final String value = evidenceDataCache.get(
      String.valueOf(sourceEvidenceDescriptorDtls.caseID));

    // END, CR00387550
    if (null != value) {
      final Entity targetEvidenceDetails = sourceEvidenceDatastore.readEntity(
        Long.valueOf(value));
      final StringBuffer sharedEvidences = new StringBuffer();

      sharedEvidences.append(
        targetEvidenceDetails.getAttribute(EvidenceBrokerConst.kTargetEvidenceList).toString());
      if (0 == sharedEvidences.length()) {
        sharedEvidences.append(
          targetEvidenceDescriptorDtls.evidenceDescriptorID);
      } else {
        sharedEvidences.append(
          CuramConst.gkPipeDelimiter
            + targetEvidenceDescriptorDtls.evidenceDescriptorID);
      }
      targetEvidenceDetails.setAttribute(
        EvidenceBrokerConst.kTargetEvidenceList, sharedEvidences.toString());
      targetEvidenceDetails.update();
    } else {
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = targetEvidenceDescriptorDtls.caseID;
      // BEGIN, CR00362746, ZV
      // Do not auto activate evidence for PDC where evidence is already
      // created as 'Active'
      final CaseTypeCode caseTypeCode = CachedCaseHeaderFactory.newInstance().readCaseTypeCode(
        caseKey);

      if (!caseTypeCode.caseTypeCode.equals(CASETYPECODE.PARTICIPANTDATACASE)) {
        final EvidenceDescriptorKeyList evidenceDescriptorKeyList = new EvidenceDescriptorKeyList();
        final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

        evidenceDescriptorKey.evidenceDescriptorID = targetEvidenceDescriptorDtls.evidenceDescriptorID;
        evidenceDescriptorKeyList.dtls.add(evidenceDescriptorKey);
        autoActivateEvidenceOnTargetCase(caseKey, evidenceDescriptorKeyList);
      }
      // END, CR00362746
    }
  }

  // END, CR00343580

  /**
   * Attempts to automatically activate the specified evidences onto the target
   * case. If the evidence could not be activated automatically a notification
   * is sent to the case owner to notify them of this along with the auto
   * activation failure reason, so that manual activation can be performed.
   *
   * @param evidenceIDAndActionList
   * Contains the evidence to be accepted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void autoActivateEvidenceOnTargetCase(final CaseKey caseKey,
    final EvidenceDescriptorKeyList evidenceDescriptorKeyList)
    throws AppException, InformationalException {

    final ApplyChangesEvidenceLists evidenceLists = sortEvidence(
      evidenceDescriptorKeyList);

    final EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    evidenceControllerObj.applyEvidenceChanges(caseKey, evidenceLists);

  }

  private void handleErrorDuringAutoActivate(
    final EvidenceDescriptorKeyList evidenceDescriptorKeyList)
    throws AppException, InformationalException {

    // If the evidence could not be auto activated flush out the
    // informational
    // manager and send a notification to each case owner, it will have
    // to be
    // activated manually

    if (checkForInformationals().failed) {

      // Get the target case id
      if (!evidenceDescriptorKeyList.dtls.isEmpty()) {
        final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

        for (final EvidenceDescriptorKey evidenceDescriptorKey : evidenceDescriptorKeyList.dtls.items()) {

          final EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj.read(
            evidenceDescriptorKey);

          if (EVIDENCEDESCRIPTORSTATUSEntry.INEDIT.getCode().equals(
            evidenceDescriptorDtls.statusCode)) {

            // send notification to each case owner
            notifyCaseOwnersEvidenceAutoActionFailure(evidenceDescriptorDtls,
              EvidenceBrokerConst.evidenceAutoActivateFailedWorkflowName);
            break;
          }
        }
      }
      TransactionInfo.setInformationalManager();
    }
  }

  // END, CR00370875

  /**
   * Separates evidence list into two lists, one for removed evidences and
   * another for the new and updated evidences.
   *
   * @param evidenceDescriptorKeyList
   * Contains the list of evidences.
   *
   * @return The sorted evidence lists, one for removed evidences and another
   * for the new and updated evidences.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected ApplyChangesEvidenceLists sortEvidence(
    final EvidenceDescriptorKeyList evidenceDescriptorKeyList)
    throws AppException, InformationalException {

    final ApplyChangesEvidenceLists sortedEvidenceList = new ApplyChangesEvidenceLists();
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    EvidenceDescriptorDtls evidenceDescriptorDtls;
    EvidenceKey evidenceKey;

    for (final EvidenceDescriptorKey evidenceDescriptorKey : evidenceDescriptorKeyList.dtls.items()) {

      evidenceDescriptorDtls = evidenceDescriptorObj.read(evidenceDescriptorKey);

      evidenceKey = new EvidenceKey();
      evidenceKey.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;
      evidenceKey.correctionSetID = evidenceDescriptorDtls.correctionSetID;
      evidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
      evidenceKey.evidenceType = evidenceDescriptorDtls.evidenceType;

      if (evidenceDescriptorDtls.pendingRemovalInd) {
        sortedEvidenceList.removeList.dtls.add(evidenceKey);
      } else {
        sortedEvidenceList.newAndUpdateList.dtls.add(evidenceKey);
      }
    }
    return sortedEvidenceList;
  }

  // END, CR00342079

  // BEGIN, CR00348300, RPB
  /**
   * This method takes in an evidence id and type for a shared evidence record
   * and retrieves a list of existing case evidence to compare the record with.
   *
   * @param key
   * Contains the case id, evidence id and type.
   * @param targetType
   * The type of evidence affected by the shared evidence record.
   * @param identical
   * Indicator to determine whether to display the record identified by
   * the key.
   *
   * @return List of evidenceID / type pairs.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public EIEvidenceKeyList getRecordsToCompare(final EvidenceCaseKey key,
    final EvidenceTypeKey targetType, final boolean identical)
    throws AppException, InformationalException {

    // Return object
    final EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    // If identical widget, add the shared record to the start of the list
    if (identical) {
      final EIEvidenceKey sharedKey = new EIEvidenceKey();

      sharedKey.evidenceID = key.evidenceKey.evidenceID;
      sharedKey.evidenceType = key.evidenceKey.evType;
      eiEvidenceKeyList.dtls.addRef(sharedKey);
    }
    final RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey = new RelatedIDAndEvidenceTypeKey();

    relatedIDAndEvidenceTypeKey.relatedID = key.evidenceKey.evidenceID;
    relatedIDAndEvidenceTypeKey.evidenceType = key.evidenceKey.evType;
    // Get the correctionSetID for this shared evidence record
    String sharedCorrectionSetID = CuramConst.gkEmpty;

    if (identical) {
      sharedCorrectionSetID = evidenceDescriptorObj.readByRelatedIDAndType(relatedIDAndEvidenceTypeKey).correctionSetID;
    }
    // Get a list of active and in edit records
    final CaseIDStatusAndEvidenceTypeKey caseIDStatusAndEvidenceTypeKey = new CaseIDStatusAndEvidenceTypeKey();

    caseIDStatusAndEvidenceTypeKey.caseID = key.caseIDKey.caseID;
    if (identical) {
      caseIDStatusAndEvidenceTypeKey.evidenceType = key.evidenceKey.evType;
    } else {
      caseIDStatusAndEvidenceTypeKey.evidenceType = targetType.evidenceType;
    }
    caseIDStatusAndEvidenceTypeKey.statusCode = EVIDENCEDESCRIPTORSTATUS.ACTIVE;
    final RelatedIDAndEvidenceTypeKeyList activeList = evidenceDescriptorObj.searchByCaseIDTypeAndStatus(
      caseIDStatusAndEvidenceTypeKey);

    caseIDStatusAndEvidenceTypeKey.statusCode = EVIDENCEDESCRIPTORSTATUS.INEDIT;
    final RelatedIDAndEvidenceTypeKeyList inEditList = evidenceDescriptorObj.searchByCaseIDTypeAndStatus(
      caseIDStatusAndEvidenceTypeKey);
    // Add the active record whose correctionSetID matches the shared record
    RelatedIDAndEvidenceTypeKey relatedKey = null;

    if (identical) {
      relatedKey = new RelatedIDAndEvidenceTypeKey();
      relatedKey.evidenceType = key.evidenceKey.evType;
      for (final Object currentObj : activeList.dtls) {
        final RelatedIDAndEvidenceTypeKey currentRecord = (RelatedIDAndEvidenceTypeKey) currentObj;

        // Get the descriptor for this evidence record
        relatedKey.relatedID = currentRecord.relatedID;
        final String activeCorrectionSetID = evidenceDescriptorObj.readByRelatedIDAndType(relatedKey).correctionSetID;

        if (activeCorrectionSetID.equals(sharedCorrectionSetID)) {
          final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

          eiEvidenceKey.evidenceType = key.evidenceKey.evType;
          eiEvidenceKey.evidenceID = currentRecord.relatedID;
          eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
          activeList.dtls.remove(currentRecord);
          break;
        }
      }
    }
    // Add the in edit record whose correctionSetID matches the shared
    // record
    if (identical) {
      for (final Object currentObj : inEditList.dtls) {
        final RelatedIDAndEvidenceTypeKey currentRecord = (RelatedIDAndEvidenceTypeKey) currentObj;

        // Get the descriptor for this evidence record
        relatedKey.relatedID = currentRecord.relatedID;
        final String inEditCorrectionSetID = evidenceDescriptorObj.readByRelatedIDAndType(relatedKey).correctionSetID;

        if (inEditCorrectionSetID.equals(sharedCorrectionSetID)) {
          final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

          eiEvidenceKey.evidenceType = key.evidenceKey.evType;
          eiEvidenceKey.evidenceID = currentRecord.relatedID;
          eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
          inEditList.dtls.remove(currentRecord);
          break;
        }
      }
    }
    // Add all remaining active records
    for (final Object currentObj : activeList.dtls) {
      final RelatedIDAndEvidenceTypeKey currentRecord = (RelatedIDAndEvidenceTypeKey) currentObj;
      final EIEvidenceKey activeKey = new EIEvidenceKey();

      activeKey.evidenceType = key.evidenceKey.evType;
      activeKey.evidenceID = currentRecord.relatedID;
      eiEvidenceKeyList.dtls.addRef(activeKey);
    }
    // Add all remaining in edit records
    for (final Object currentObj : inEditList.dtls) {
      final RelatedIDAndEvidenceTypeKey currentRecord = (RelatedIDAndEvidenceTypeKey) currentObj;
      final EIEvidenceKey inEditKey = new EIEvidenceKey();

      inEditKey.evidenceType = key.evidenceKey.evType;
      inEditKey.evidenceID = currentRecord.relatedID;
      eiEvidenceKeyList.dtls.addRef(inEditKey);
    }
    return eiEvidenceKeyList;
  }

  /**
   * Gets the latest activity and update count of the evidence for the given
   * successionID.
   *
   * @param successionID
   * Succession id of the evidence.
   *
   * @return The number of updates, period and latest activity for the business
   * object.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public EvdUpdatesPeriodLastActDetails getEvidencePeriodUpdateCountAndLatestAct(
    final SuccessionID successionID) throws AppException,
      InformationalException {

    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    final EvdUpdatesPeriodLastActDetails evdUpdatesPeriodLastActDetails = new EvdUpdatesPeriodLastActDetails();

    evdUpdatesPeriodLastActDetails.period = CuramConst.gkEmpty;
    evdUpdatesPeriodLastActDetails.updateCount = evidenceDescriptorObj.countActiveUpdates(successionID).updateCount;
    final MostRecentBusinessObjectChangesDetailsList mostRecentBusinessObjectChangesDetailsList = evidenceDescriptorObj.searchMostRecentBusinessObjectChanges(
      successionID);
    final int listSize = mostRecentBusinessObjectChangesDetailsList.dtls.size();
    MostRecentBusinessObjectChangesDetails listDetails = new MostRecentBusinessObjectChangesDetails();

    if (listSize > 0) {
      listDetails = mostRecentBusinessObjectChangesDetailsList.dtls.iterator().next();
    }
    LocalisableString latestActivity = null;

    if (listDetails.pendingRemovalInd) {
      latestActivity = new LocalisableString(
        BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY_PENDING_DELETION);

    } else if (listDetails.statusCode.equals(EVIDENCEDESCRIPTORSTATUS.INEDIT)) {
      // is there any active records in the succession
      // if so then activity is in edit, else its created.
      final SuccessionIDAndStatusCodes successionIDAndStatusCodes = new SuccessionIDAndStatusCodes();

      successionIDAndStatusCodes.successionID = successionID.successionID;
      successionIDAndStatusCodes.statusCode1 = EVIDENCEDESCRIPTORSTATUS.ACTIVE;
      successionIDAndStatusCodes.statusCode2 = EVIDENCEDESCRIPTORSTATUS.ACTIVE;

      final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = evidenceDescriptorObj.searchBySuccessionIDAndStatusCodes(
        successionIDAndStatusCodes);

      if (evidenceDescriptorDtlsList.dtls.size() == 0) {
        latestActivity = new LocalisableString(
          BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY_CREATED);
      } else {
        latestActivity = new LocalisableString(
          BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY_IN_EDIT);
      }
    } else if (listDetails.statusCode.equals(EVIDENCEDESCRIPTORSTATUS.CANCELED)) {

      // is there any other non cancelled records in the succession
      // if so then activity is applied, else its cancelled.
      final SuccessionIDAndStatusCodes successionIDAndStatusCodes = new SuccessionIDAndStatusCodes();

      successionIDAndStatusCodes.successionID = successionID.successionID;
      successionIDAndStatusCodes.statusCode1 = EVIDENCEDESCRIPTORSTATUS.ACTIVE;
      successionIDAndStatusCodes.statusCode2 = EVIDENCEDESCRIPTORSTATUS.INEDIT;
      final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = evidenceDescriptorObj.searchBySuccessionIDAndStatusCodes(
        successionIDAndStatusCodes);

      if (evidenceDescriptorDtlsList.dtls.size() == 0) {
        latestActivity = new LocalisableString(
          BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY_CANCELED);
      } else {
        latestActivity = new LocalisableString(
          BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY_APPLIED);
      }

    } else if (listDetails.statusCode.equals(EVIDENCEDESCRIPTORSTATUS.ACTIVE)) {
      latestActivity = new LocalisableString(
        BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY_APPLIED);
    } else {
      // default to applied
      latestActivity = new LocalisableString(
        BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY_APPLIED);
    }

    final UserAccess userAccessObj = UserAccessFactory.newInstance();

    if (listDetails.changeUser == null
      || listDetails.changeUser.equals(CuramConst.gkEmpty)) {
      latestActivity.arg(CuramConst.gkEmpty);
    } else {
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = listDetails.changeUser;
      final UserFullname userFullname = userAccessObj.getFullName(usersKey);

      latestActivity.arg(userFullname.fullname);
    }
    latestActivity.arg(listDetails.changeDateTime);
    evdUpdatesPeriodLastActDetails.latestActivity = latestActivity.toClientFormattedText();
    final BusinessObjectKey businessObjectKey = new BusinessObjectKey();

    businessObjectKey.caseID = evidenceDescriptorObj.readCaseIDForBusinessObject(successionID).caseID;
    businessObjectKey.evidenceSuccessionID = successionID.successionID;
    return evdUpdatesPeriodLastActDetails;
  }

  /**
   * Retrieves evidence summary details which can be used to populate an
   * evidence list page.
   *
   * @param eiEvidenceKey
   * Key containing evidenceID / evidenceType.
   *
   * @return Evidence summary details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public EIFieldsForListDisplayDtls getEvidenceSummaryDetails(
    final EIEvidenceKey eiEvidenceKey) throws AppException,
      InformationalException {

    // Set evidence type to access relevant evidence interface
    final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceTypeKey.evidenceType = eiEvidenceKey.evidenceType;
    final EvidenceMap map = EvidenceController.getEvidenceMap();
    final StandardEvidenceInterface standardEvidenceInterface = map.getEvidenceType(
      evidenceTypeKey.evidenceType);
    // Retrieve evidence details for list display
    final EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = standardEvidenceInterface.getDetailsForListDisplay(
      eiEvidenceKey);

    return eiFieldsForListDisplayDtls;
  }

  // END, CR00348300

  // BEGIN, CR00349439, VR

  /**
   * Gets the target evidence type code based on the source evidence details and
   * target case.
   *
   * @param sourceDescriptorDtls
   * Details of source evidence.
   *
   * @param targetCaseDtls
   * Target case header details.
   * @return Target evidence type code.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public String getTargetEvidenceType(
    final EvidenceDescriptorDtls sourceDescriptorDtls,
    final CaseHeaderDtls targetCaseDtls) throws AppException,
      InformationalException {

    // Get the affected evidence details
    final EvidenceSharingConfigKey sourceTargetEvidenceAndStatusKey = new EvidenceSharingConfigKey();

    // Get the source and target parameters
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // get the source parameter
    if (sourceDescriptorDtls.sourceCaseID != 0) {
      if (sourceDescriptorDtls.externalSourceCaseInd) {
        final CaseKey sourcecaseKey = new CaseKey();

        sourcecaseKey.caseID = sourceDescriptorDtls.sourceCaseID;
        final ExternalCaseHeaderDtls externalCaseHeaderDtls = getExternalCaseHeaderDetails(
          sourcecaseKey);

        sourceTargetEvidenceAndStatusKey.sourceType = externalCaseHeaderDtls.caseType;
        sourceTargetEvidenceAndStatusKey.sourceSystemID = externalCaseHeaderDtls.sourceSystemID;

        // Retrieve the corresponding source ID
        final CaseTypeEvidence caseTypeEvidence = getCaseTypeEvidence(
          externalCaseHeaderDtls.caseType);
        final CaseKey caseKey = new CaseKey();

        caseKey.caseID = externalCaseHeaderDtls.externalCaseID;
        sourceTargetEvidenceAndStatusKey.sourceID = caseTypeEvidence.getSubTypeID(
          externalCaseHeaderDtls.caseSubType);
      } else {
        caseHeaderKey.caseID = sourceDescriptorDtls.sourceCaseID;
        final CaseHeaderDtls caseHeaderDtls = CachedCaseHeaderFactory.newInstance().read(
          caseHeaderKey);

        sourceTargetEvidenceAndStatusKey.sourceType = caseHeaderDtls.caseTypeCode;

        // Retrieve the corresponding source ID
        final CaseTypeEvidence caseTypeEvidence = getCaseTypeEvidence(
          caseHeaderDtls.caseTypeCode);
        final CaseKey caseKey = new CaseKey();

        caseKey.caseID = caseHeaderDtls.caseID;
        sourceTargetEvidenceAndStatusKey.sourceID = caseTypeEvidence.readEvidenceBrokerSourceIDByCaseID(
          caseKey);
      }
    }

    // get the target parameter
    if (sourceDescriptorDtls.caseID != 0) {

      caseHeaderKey.caseID = sourceDescriptorDtls.caseID;
      final CaseHeaderDtls caseHeaderDtls = CachedCaseHeaderFactory.newInstance().read(
        caseHeaderKey);

      sourceTargetEvidenceAndStatusKey.sourceType = caseHeaderDtls.caseTypeCode;

      // Retrieve the corresponding target ID
      final CaseTypeEvidence caseTypeEvidence = getCaseTypeEvidence(
        caseHeaderDtls.caseTypeCode);
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = caseHeaderDtls.caseID;

      sourceTargetEvidenceAndStatusKey.sourceID = caseTypeEvidence.readEvidenceBrokerSourceIDByCaseID(
        caseKey);
    }

    if (targetCaseDtls.caseID != 0) {
      sourceTargetEvidenceAndStatusKey.targetType = targetCaseDtls.caseTypeCode;

      final CaseTypeEvidence caseTypeEvidence = getCaseTypeEvidence(
        targetCaseDtls.caseTypeCode);
      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = targetCaseDtls.caseID;
      sourceTargetEvidenceAndStatusKey.targetID = caseTypeEvidence.readEvidenceBrokerSourceIDByCaseID(
        caseKey);

    }

    // Get the evidence broker configuration for the given sharing details
    sourceTargetEvidenceAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
    sourceTargetEvidenceAndStatusKey.sourceEvidenceType = sourceDescriptorDtls.evidenceType;
    sourceTargetEvidenceAndStatusKey.sharedType = EVIDENCESHARINGTYPE.NONIDENTICAL;

    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList = EvidenceBrokerConfigAdminFactory.newInstance().listSharedSourceAndTargetEvidences(
      sourceTargetEvidenceAndStatusKey);

    if (evidenceBrokerConfigDtlsList.dtls.size() > 0) {
      return evidenceBrokerConfigDtlsList.dtls.get(0).targetEvidenceType;
    }
    return null;

  }

  /**
   * Gets the case type specific object by case type code.
   *
   * @param caseTypeCode
   * The case type code for the case.
   *
   * @return case type specific object.
   *
   * @throws AppException
   * {@link BPOEVIDENCECONTROLLER #ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED}
   * if the case type is not supported.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected CaseTypeEvidence getCaseTypeEvidence(final String caseTypeCode)
    throws AppException, InformationalException {

    final CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
      caseTypeCode);

    if (null == caseTypeEvidence) {
      final AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, caseTypeCode,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 17);
    }
    return caseTypeEvidence;
  }

  /**
   * Gets the external case details.
   *
   * @param caseKey
   * Contains the caseID.
   *
   * @return External case details..
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ExternalCaseHeaderDtls getExternalCaseHeaderDetails(
    final CaseKey caseKey) throws AppException, InformationalException {

    final ExternalCaseHeaderKey externalCaseHeaderKey = new ExternalCaseHeaderKey();

    externalCaseHeaderKey.externalCaseID = caseKey.caseID;
    final ExternalCaseHeaderDtls externalCaseHeaderDtls = ExternalCaseHeaderFactory.newInstance().read(
      externalCaseHeaderKey);

    return externalCaseHeaderDtls;
  }

  /**
   * Broadcasts non-identical evidences. Reads source evidence details, creates
   * target evidence and propagate identical attribute values form source to
   * target evidence.
   *
   * @param sourceEvidenceDescriptorDtls
   * Source evidence details
   * @param targetCaseHeaderDtls
   * Details Target case
   * @return Target Evidence details
   * @throws AppException
   * Generic Exception signature
   * @throws InformationalException
   * Generic Exception signature
   */
  protected EvidenceDescriptorDtls broadcastNonIdenticalEvidence(
    final EvidenceDescriptorDtls sourceEvidenceDescriptorDtls,
    final CaseHeaderDtls targetCaseHeaderDtls, final String targetEvidenceType)
    throws AppException, InformationalException {

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = targetCaseHeaderDtls.caseID;
    final CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
      targetCaseHeaderDtls.caseTypeCode);

    if (null == caseTypeEvidence) {
      final AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME,
        targetCaseHeaderDtls.caseTypeCode, TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 15);
    }
    final BroadcastEvidence broadcastEvidenceObj = BroadcastEvidenceManager.getHook(
      caseTypeEvidence.getCaseTypeCode(caseKey));

    // Try to share the evidence using the evidence specific broadcast
    EvidenceDescriptorDtls targetEvidenceDescriptorDtls = broadcastEvidenceObj.processBroadcast(
      sourceEvidenceDescriptorDtls, targetCaseHeaderDtls);

    // If the evidence specific broadcast is not configured share the
    // evidence directly via the evidence controller
    if (null == targetEvidenceDescriptorDtls) {

      // BEGIN, CR00359976, GYH
      // If the same version of the evidence object is already there on
      // target case then don't share the evidence again.
      boolean shareEvidence = true;

      // BEGIN, CR00365143, ZV
      // Don't share evidence into PDC case for non primary participant.
      if (targetCaseHeaderDtls.caseTypeCode.equals(
        CASETYPECODE.PARTICIPANTDATACASE)
          && targetCaseHeaderDtls.concernRoleID
            != sourceEvidenceDescriptorDtls.participantID) {
        shareEvidence = false;
        // END, CR00365143
      } else if (sourceEvidenceDescriptorDtls.sharedInd
        && sourceEvidenceDescriptorDtls.sharedUnchangedInd) {
        final SharedInstanceIDCaseIDStatusCodes sharedInstanceCaseIDKey = new SharedInstanceIDCaseIDStatusCodes();

        sharedInstanceCaseIDKey.caseID = targetCaseHeaderDtls.caseID;
        sharedInstanceCaseIDKey.sharedInstanceID = sourceEvidenceDescriptorDtls.sharedInstanceID;
        final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = EvidenceDescriptorFactory.newInstance().searchBySharedInstanceIDCaseIDStatusCodes(
          sharedInstanceCaseIDKey);

        for (final EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorDtlsList.dtls.items()) {

          if (!evidenceDescriptorDtls.sharedInd
            || (evidenceDescriptorDtls.sharedInd
              && evidenceDescriptorDtls.sharedUnchangedInd)) {
            shareEvidence = false;
          }
        }
      }
      if (shareEvidence) {
        // As we are sharing the evidence, it is not modified yet, so
        // set the indicator.

        final EvidenceDescriptorDtls shareEvidenceDescriptorDtls = new EvidenceDescriptorDtls();

        shareEvidenceDescriptorDtls.assign(sourceEvidenceDescriptorDtls);
        shareEvidenceDescriptorDtls.sharedUnchangedInd = true;

        final EvidenceTypeDtls evidenceTypeDtls = new EvidenceTypeDtls();

        evidenceTypeDtls.evidenceType = targetEvidenceType;
        targetEvidenceDescriptorDtls = EvidenceControllerFactory.newInstance().shareNonIdenticalEvidence(
          shareEvidenceDescriptorDtls, targetCaseHeaderDtls, evidenceTypeDtls);
      }
      // END, CR00359976
    }
    return targetEvidenceDescriptorDtls;
  }

  /**
   * Gets the target evidence type code from the evidence broker configuration
   * based on source evidence details
   *
   * @param evidenceBrokerConfigDtlsList
   * List of Evidence Broker Configurations.
   * @param descriptorDtls
   * Source evidence details.
   * @return Target evidence type code.
   */
  public String getTargetEvidenceByBrokerConfig(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final EvidenceDescriptorDtls descriptorDtls) {
    String targetEvidenceType = null;

    for (final EvidenceBrokerConfigDtls evidenceBrokerConfigDtls : evidenceBrokerConfigDtlsList.dtls.items()) {

      // Does this evidence match the configuration?
      if (descriptorDtls.evidenceType.equals(
        evidenceBrokerConfigDtls.sourceEvidenceType)) {
        targetEvidenceType = evidenceBrokerConfigDtls.targetEvidenceType;
        break;
      }

    }
    return targetEvidenceType;
  }

  // END, CR00349439

  // BEGIN, CR00351925, SSK
  /**
   * Retrieves the evidence broker configuration applicable to evidence
   * descriptor.
   *
   * @param evidenceDescriptorDtls
   * Contains evidence descriptor details.
   *
   * @return The list of evidence broker configuration applicable to evidence
   * descriptor.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public EvidenceBrokerConfigDtlsList retrieveEvidenceBrokerConfigurationList(
    final EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {
    final SharedEvidenceSourceTypeAndSourceIDDetails sharedEvidenceSourceTypeAndSourceIDDetails = getSharingSourceTypeAndSourceID(
      evidenceDescriptorDtls);

    final SharedSourceEvidenceAndStatusKey key = new SharedSourceEvidenceAndStatusKey();

    key.sourceID = sharedEvidenceSourceTypeAndSourceIDDetails.sourceID;
    key.sourceType = sharedEvidenceSourceTypeAndSourceIDDetails.sourceType;
    key.sourceEvidenceType = evidenceDescriptorDtls.evidenceType;
    key.recordStatus = RECORDSTATUS.NORMAL;

    final EvidenceBrokerConfigDtlsList sharedEvidenceConfigDtlsList = EvidenceBrokerConfigAdminFactory.newInstance().listSharedTargetEvidences(
      key);

    return sharedEvidenceConfigDtlsList;
  }

  /**
   * Filters the list of evidence descriptor based on evidence type.
   *
   * @param evidenceDescriptorDtlsList
   * Contains list of evidence descriptor.
   *
   * @return filtered list of evidence descriptor based on evidence type.
   */
  protected Map<String, List<EvidenceDescriptorDtls>> filterEvidenceDescriptorDtlsListBasedOnEvidenceType(
    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList) {

    final Map<String, List<EvidenceDescriptorDtls>> filteredEvidenceList = new HashMap<String, List<EvidenceDescriptorDtls>>();
    List<EvidenceDescriptorDtls> evidenceRespectiveList;

    for (final EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorDtlsList.dtls.items()) {
      if (filteredEvidenceList.containsKey(evidenceDescriptorDtls.evidenceType)) {
        evidenceRespectiveList = filteredEvidenceList.get(
          evidenceDescriptorDtls.evidenceType);
        evidenceRespectiveList.add(evidenceDescriptorDtls);
      } else {
        evidenceRespectiveList = new ArrayList<EvidenceDescriptorDtls>();
        evidenceRespectiveList.add(evidenceDescriptorDtls);
        filteredEvidenceList.put(evidenceDescriptorDtls.evidenceType,
          evidenceRespectiveList);
      }
    }
    return filteredEvidenceList;

  }

  /**
   * Fetches evidence broker configuration applicable date.
   *
   * @param evidenceBrokerConfigDtls
   * Contains the details of evidence broker configuration.
   *
   * @return The applicable date time.
   */
  protected java.util.Date getApplicableDateTime(
    final EvidenceBrokerConfigDtls evidenceBrokerConfigDtls) {
    final DateTime applicableDateTime = DateTime.getCurrentDateTime();
    final Calendar calendar = applicableDateTime.getCalendar();

    if (EVIDENCESHARELASTOPTION.MONTHS.equals(
      evidenceBrokerConfigDtls.shareLastOption)) {

      calendar.add(Calendar.MONTH, -evidenceBrokerConfigDtls.shareLastNumber);

    } else if (EVIDENCESHARELASTOPTION.YEARS.equals(
      evidenceBrokerConfigDtls.shareLastOption)) {
      calendar.add(Calendar.YEAR, -evidenceBrokerConfigDtls.shareLastNumber);
    } else if (EVIDENCESHARELASTOPTION.WEEKS.equals(
      evidenceBrokerConfigDtls.shareLastOption)) {

      calendar.add(Calendar.WEEK_OF_YEAR,
        -(evidenceBrokerConfigDtls.shareLastNumber));
    }
    final java.util.Date applicabelDate = calendar.getTime();

    return applicabelDate;
  }

  /**
   * Filters evidence descriptor list based on evidence type and applicable
   * evidence broker configuration.
   *
   * @param evidenceDescriptorDtlsList
   * Contains list of evidence descriptor.
   *
   * @return The filtered list.
   *
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected EvidenceDescriptorDtlsList filterEvidenceDescriptorDtlsList(
    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList)
    throws AppException, InformationalException {
    final EvidenceDescriptorDtlsList sourceEvidenceDescriptorDtlsList = new EvidenceDescriptorDtlsList();
    final Map<String, List<EvidenceDescriptorDtls>> filteredEvidenceList = filterEvidenceDescriptorDtlsListBasedOnEvidenceType(
      evidenceDescriptorDtlsList);
    List<EvidenceDescriptorDtls> evidenceDescriptorList;
    List<EvidenceDescriptorDtls> lastEvidenceList;

    for (final List<EvidenceDescriptorDtls> list : filteredEvidenceList.values()) {
      if (list.size() > 0) {
        evidenceDescriptorList = new ArrayList<EvidenceDescriptorDtls>();
        final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList = retrieveEvidenceBrokerConfigurationList(
          list.get(0));
        final EvidenceBrokerConfigDtls evidenceBrokerConfigDtls = getApplicableEvidenceBrokerConfig(
          evidenceBrokerConfigDtlsList, list.get(0));

        // BEGIN, CR00356862, SSK
        if (evidenceBrokerConfigDtls != null) {
          // END, CR00356862
          if (EVIDENCESHARINGLIMITTYPE.SHARELATEST.equals(
            evidenceBrokerConfigDtls.shareLimitType)) {
            evidenceDescriptorList.add(getLatestEvidence(list));

          } else if (EVIDENCESHARINGLIMITTYPE.SHARELAST.equals(
            evidenceBrokerConfigDtls.shareLimitType)) {
            if (EVIDENCESHARELASTOPTION.UPDATES.equals(
              evidenceBrokerConfigDtls.shareLastOption)) {
              evidenceDescriptorList.addAll(
                getLastUpdatedEvidence(list,
                evidenceBrokerConfigDtls.shareLastNumber));

            } else {
              final java.util.Date applicableDate = getApplicableDateTime(
                evidenceBrokerConfigDtls);

              lastEvidenceList = filterActivatedEvidencesByDateTime(list,
                applicableDate);
              evidenceDescriptorList.addAll(lastEvidenceList);
            }

          } else {
            evidenceDescriptorList.addAll(list);
          }

          for (final EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorList) {
            if (EVIDENCESHARINGTYPE.IDENTICAL.equals(
              evidenceBrokerConfigDtls.sharedType)) {

              evidenceDescriptorDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
            } else {
              evidenceDescriptorDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;
            }
            sourceEvidenceDescriptorDtlsList.dtls.add(evidenceDescriptorDtls);

          }
        }
      }

    }
    return sourceEvidenceDescriptorDtlsList;
  }

  /**
   * Fetches latest evidence descriptor.
   *
   * @param evidenceDescriptorDtlsList
   * Contains the list of evidence descriptor.
   *
   * @return Latest evidence descriptor.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected EvidenceDescriptorDtls getLatestEvidence(
    final List<EvidenceDescriptorDtls> evidenceDescriptorDtlsList)
    throws AppException, InformationalException {
    EvidenceDescriptorDtls lastestEvidenceDescriptorDtls = evidenceDescriptorDtlsList.get(
      0);

    DateTime lastestEvidenceDate;
    final EvidenceChangeHistory evidenceChangeHistory = EvidenceChangeHistoryFactory.newInstance();
    final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = lastestEvidenceDescriptorDtls.evidenceDescriptorID;
    EvidenceChangeHistoryDtls latestEvidenceChangeHistoryDtls = evidenceChangeHistory.searchByEvidenceDescriptorID(evidenceDescriptorKey).dtls.item(
      0);
    EvidenceDescriptorKey descriptorKey = null;
    EvidenceChangeHistoryDtlsList evidenceChangeHistoryDtlsList;

    lastestEvidenceDate = latestEvidenceChangeHistoryDtls.changeDateTime;

    for (final EvidenceDescriptorDtls activeCaseParticipantEvidence : evidenceDescriptorDtlsList) {

      descriptorKey = new EvidenceDescriptorKey();
      descriptorKey.evidenceDescriptorID = activeCaseParticipantEvidence.evidenceDescriptorID;
      evidenceChangeHistoryDtlsList = EvidenceChangeHistoryFactory.newInstance().searchByEvidenceDescriptorID(
        descriptorKey);

      for (final EvidenceChangeHistoryDtls evidenceChangeHistoryDtls : evidenceChangeHistoryDtlsList.dtls) {
        if (EVIDENCECHANGETYPE.ACTIVATED.equals(
          evidenceChangeHistoryDtls.changeType)
            || EVIDENCECHANGETYPE.UPDATED.equals(
              evidenceChangeHistoryDtls.changeType)) {
          if (lastestEvidenceDate.before(
            evidenceChangeHistoryDtls.changeDateTime)) {
            lastestEvidenceDate = evidenceChangeHistoryDtls.changeDateTime;
            lastestEvidenceDescriptorDtls = activeCaseParticipantEvidence;
            latestEvidenceChangeHistoryDtls = evidenceChangeHistoryDtls;
          }

        }
      }

    }
    return lastestEvidenceDescriptorDtls;
  }

  /**
   * Sorts evidence change history by change date.
   *
   * @param evidenceDescriptorKey
   * Contains the evidence descriptor key.
   *
   * @return Sorted list of evidence change histories.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected List<EvidenceChangeHistoryDtls> sortEvidenceChangeHistory(
    final EvidenceDescriptorKey evidenceDescriptorKey) throws AppException,
      InformationalException {
    final EvidenceChangeHistoryDtlsList evidenceChangeHistoryDtlsList = EvidenceChangeHistoryFactory.newInstance().searchByEvidenceDescriptorID(
      evidenceDescriptorKey);

    final List<EvidenceChangeHistoryDtls> sortedList = new ArrayList<EvidenceChangeHistoryDtls>();

    for (final EvidenceChangeHistoryDtls evidenceChangeHistoryDtls : evidenceChangeHistoryDtlsList.dtls) {
      sortedList.add(evidenceChangeHistoryDtls);

    }

    Collections.sort(sortedList, new Comparator<EvidenceChangeHistoryDtls>() {
      public int compare(final EvidenceChangeHistoryDtls lhs,
        final EvidenceChangeHistoryDtls rhs) {
        return lhs.changeDateTime.compareTo(rhs.changeDateTime);
      }

    });

    return sortedList;
  }

  /**
   * Fetches the last specified number of updated evidences.
   *
   * @param evidenceDescriptorDtlsList
   * Contains the list of evidence descriptor.
   *
   * @param shareLimitNumber
   * Contains the share limit number;
   * @return The list of evidence descriptors.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected List<EvidenceDescriptorDtls> getUpdatedEvidence(
    final List<EvidenceDescriptorDtls> evidenceDescriptorDtlsList,
    final Set<Long> activeRecords, final short shareLimitNumber)
    throws AppException, InformationalException {
    final List<EvidenceDescriptorDtls> lastUpdatedEvidenceDescriptorDtls = new ArrayList<EvidenceDescriptorDtls>();
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    final EvidenceDescriptorKey descriptorKey = new EvidenceDescriptorKey();

    final List<EvidenceChangeHistoryDtls> sortedList = new ArrayList<EvidenceChangeHistoryDtls>();

    for (final EvidenceDescriptorDtls activeCaseParticipantEvidence : evidenceDescriptorDtlsList) {
      descriptorKey.evidenceDescriptorID = activeCaseParticipantEvidence.evidenceDescriptorID;
      final EvidenceChangeHistoryDtlsList evidenceChangeHistoryDtlsList = EvidenceChangeHistoryFactory.newInstance().searchByEvidenceDescriptorID(
        descriptorKey);

      for (final EvidenceChangeHistoryDtls evidenceChangeHistoryDtls : evidenceChangeHistoryDtlsList.dtls.items()) {
        if (EVIDENCECHANGETYPE.ACTIVATED.equals(
          evidenceChangeHistoryDtls.changeType)) {
          sortedList.add(evidenceChangeHistoryDtls);
        }
      }

    }

    Collections.sort(sortedList, new Comparator<EvidenceChangeHistoryDtls>() {
      public int compare(final EvidenceChangeHistoryDtls lhs,
        final EvidenceChangeHistoryDtls rhs) {
        return rhs.changeDateTime.compareTo(lhs.changeDateTime);
      }
    });

    int countNumberOfUpdate = 0;

    for (final EvidenceChangeHistoryDtls evidenceChangeHistoryDtls : sortedList) {
      if (countNumberOfUpdate < shareLimitNumber) {
        if (activeRecords.add(evidenceChangeHistoryDtls.evidenceDescriptorID)) {
          descriptorKey.evidenceDescriptorID = evidenceChangeHistoryDtls.evidenceDescriptorID;
          lastUpdatedEvidenceDescriptorDtls.add(
            evidenceDescriptorObj.read(descriptorKey));
          countNumberOfUpdate++;
        }
      }
    }

    return lastUpdatedEvidenceDescriptorDtls;
  }

  /**
   * Fetches the last specified number of updated evidences.
   *
   * @param evidenceDescriptorDtlsList
   * Contains the list of evidence descriptor.
   *
   * @param shareLimitNumber
   * Contains the share limit number;
   * @return The list of evidence descriptors.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected List<EvidenceDescriptorDtls> getLastUpdatedEvidence(
    final List<EvidenceDescriptorDtls> evidenceDescriptorDtlsList,
    final short shareLimitNumber) throws AppException, InformationalException {
    final List<EvidenceDescriptorDtls> lastUpdatedEvidenceDescriptorDtls = new ArrayList<EvidenceDescriptorDtls>();
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    final EvidenceDescriptorKey descriptorKey = new EvidenceDescriptorKey();

    final List<EvidenceChangeHistoryDtls> sortedList = new ArrayList<EvidenceChangeHistoryDtls>();

    for (final EvidenceDescriptorDtls activeCaseParticipantEvidence : evidenceDescriptorDtlsList) {
      descriptorKey.evidenceDescriptorID = activeCaseParticipantEvidence.evidenceDescriptorID;
      final EvidenceChangeHistoryDtlsList evidenceChangeHistoryDtlsList = EvidenceChangeHistoryFactory.newInstance().searchByEvidenceDescriptorID(
        descriptorKey);

      for (final EvidenceChangeHistoryDtls evidenceChangeHistoryDtls : evidenceChangeHistoryDtlsList.dtls.items()) {
        // BEGIN, CR00426751, SS
        if (EVIDENCECHANGETYPEEntry.INPUT.getCode().equals(
          evidenceChangeHistoryDtls.changeType)) {
          // END, CR00426751
          sortedList.add(evidenceChangeHistoryDtls);
        }
      }
    }

    Collections.sort(sortedList, new Comparator<EvidenceChangeHistoryDtls>() {
      public int compare(final EvidenceChangeHistoryDtls lhs,
        final EvidenceChangeHistoryDtls rhs) {
        return rhs.changeDateTime.compareTo(lhs.changeDateTime);
      }
    });

    final Set<Long> evidenceDescriptorIDS = new HashSet<Long>();
    int countNumberOfUpdate = 0;

    for (final EvidenceChangeHistoryDtls evidenceChangeHistoryDtls : sortedList) {
      // BEGIN, CR00426751, SS
      if (countNumberOfUpdate <= shareLimitNumber) {
        // END, CR00426751
        if (evidenceDescriptorIDS.add(
          evidenceChangeHistoryDtls.evidenceDescriptorID)) {
          descriptorKey.evidenceDescriptorID = evidenceChangeHistoryDtls.evidenceDescriptorID;
          lastUpdatedEvidenceDescriptorDtls.add(
            evidenceDescriptorObj.read(descriptorKey));
          countNumberOfUpdate++;
        }
      }
    }

    return lastUpdatedEvidenceDescriptorDtls;
  }

  /**
   * Filers activated evidence based on the specified date time.
   *
   * @param validDateTime
   * Contains date time details.
   *
   * @param evidenceDescriptorDtlsList
   * Contains the list of evidence descriptors.
   *
   * @return The filtered list of evidence descriptors.
   *
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected List<EvidenceDescriptorDtls> filterActivatedEvidencesByDateTime(
    final List<EvidenceDescriptorDtls> evidenceDescriptorDtlsList,
    final java.util.Date validDate) throws AppException,
      InformationalException {
    final List<EvidenceDescriptorDtls> lastestEvidenceDescriptorDtls = new ArrayList<EvidenceDescriptorDtls>();
    EvidenceDescriptorKey descriptorKey;

    for (final EvidenceDescriptorDtls activeCaseParticipantEvidence : evidenceDescriptorDtlsList) {

      descriptorKey = new EvidenceDescriptorKey();
      descriptorKey.evidenceDescriptorID = activeCaseParticipantEvidence.evidenceDescriptorID;
      EvidencePeriod evidencPeriod = getEvidencePeriod(
        activeCaseParticipantEvidence);

      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = activeCaseParticipantEvidence.relatedID;
      eiEvidenceKey.evidenceType = activeCaseParticipantEvidence.evidenceType;
      evidencPeriod = EvidenceControllerFactory.newInstance().getPeriodForEvidenceRecord(
        eiEvidenceKey);
      final DateRange dateRange = new DateRange(evidencPeriod.startDate,
        evidencPeriod.endDate);
      final Date configuredDate = new Date(validDate.getTime());

      if (dateRange.contains(configuredDate)
        || (dateRange.startsAfter(configuredDate)
          && dateRange.startsBefore(Date.getCurrentDate().addDays(1)))) {
        lastestEvidenceDescriptorDtls.add(activeCaseParticipantEvidence);
      }
    }
    return lastestEvidenceDescriptorDtls;
  }

  /**
   * Gets applicable evidence broker configuration for a evidence descriptor.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the list of evidence broker configurations.
   *
   * @param evidenceDescriptor
   * Contains evidence descriptor details.
   *
   * @return The applicable evidence broker configurations.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected EvidenceBrokerConfigDtls getApplicableEvidenceBrokerConfig(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final EvidenceDescriptorDtls evidenceDescriptor) throws AppException,
      InformationalException {

    EvidenceBrokerConfigDtls applicableEvidenceBrokerConfigDtls = null;
    EvidenceBrokerConfigKey evidenceBrokerConfigKey;

    for (final EvidenceBrokerConfigDtls evidenceBrokerConfigDtls : evidenceBrokerConfigDtlsList.dtls.items()) {

      // Does this evidence match the configuration?
      if (evidenceDescriptor.evidenceType.equals(
        evidenceBrokerConfigDtls.sourceEvidenceType)) {

        evidenceBrokerConfigKey = new EvidenceBrokerConfigKey();
        evidenceBrokerConfigKey.evidenceBrokerConfigID = evidenceBrokerConfigDtls.evidenceBrokerConfigID;

        applicableEvidenceBrokerConfigDtls = EvidenceBrokerConfigFactory.newInstance().read(
          evidenceBrokerConfigKey);
        break;
      }
    }

    return applicableEvidenceBrokerConfigDtls;
  }

  // END, CR00351925

  // BEGIN, CR00379197, SSK
  /**
   * Checks if the evidence is dynamic evidence.
   *
   * @param evidenceType
   * Contains the evidence type.
   *
   * @return True if the evidence is Dynamic evidence, false otherwise.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected boolean isDynamicEvidence(final String evidenceType)
    throws AppException, InformationalException {
    boolean isDynamicEvidence = false;
    EVIDENCENATUREEntry evidenceTypeNature = evidenceNature.getEvidenceNatureCode(
      CASEEVIDENCEEntry.get(evidenceType));

    if (EVIDENCENATUREEntry.DYNAMIC.getCode().equals(
      evidenceTypeNature.getCode())) {
      isDynamicEvidence = true;
    }

    return isDynamicEvidence;
  }

  /**
   * Filters the active and In-Edit evidences.
   *
   * @param evidenceDescriptorDtlsList
   * Contains the list of evidence descriptors.
   *
   * @return The list of active and In-Edit evidences.
   */
  protected EvidenceDescriptorDtlsList filterActiveAndEditEvidences(
    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList) {
    final EvidenceDescriptorDtlsList activeAndEditEvidenceDescriptorDtlsList = new EvidenceDescriptorDtlsList();

    for (final EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorDtlsList.dtls) {
      if (EVIDENCEDESCRIPTORSTATUS.ACTIVE.equals(
        evidenceDescriptorDtls.statusCode)
          || EVIDENCEDESCRIPTORSTATUS.INEDIT.equals(
            evidenceDescriptorDtls.statusCode)) {

        activeAndEditEvidenceDescriptorDtlsList.dtls.add(evidenceDescriptorDtls);
      }

    }
    return activeAndEditEvidenceDescriptorDtlsList;
  }

  // END, CR00379197

  // BEGIN, CR00385308, SSK
  /**
   * Shares the source static evidence to the target case.
   *
   * @param sourceEvidenceDescriptorDtls
   * Contains the evidence to be broadcast.
   * @param targetCaseHeaderDtls
   * Contains the target case that the evidence is being broadcast to.
   *
   * @return The evidence which has been added to the target case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected EvidenceDescriptorDtls shareStaticEvidence(
    final EvidenceDescriptorDtls sourceEvidenceDescriptorDtls,
    final CaseHeaderDtls targetCaseHeaderDtls) throws AppException,
      InformationalException {

    boolean shareEvidence = true;

    if (sourceEvidenceDescriptorDtls.sharedInd
      && sourceEvidenceDescriptorDtls.sharedUnchangedInd) {
      SharedInstanceIDCaseIDStatusCodes sharedInstanceCaseIDKey = new SharedInstanceIDCaseIDStatusCodes();

      sharedInstanceCaseIDKey.caseID = targetCaseHeaderDtls.caseID;
      sharedInstanceCaseIDKey.sharedInstanceID = sourceEvidenceDescriptorDtls.sharedInstanceID;
      EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = EvidenceDescriptorFactory.newInstance().searchBySharedInstanceIDCaseIDStatusCodes(
        sharedInstanceCaseIDKey);

      for (final EvidenceDescriptorDtls evidenceDescriptorDtls : evidenceDescriptorDtlsList.dtls.items()) {

        if (!evidenceDescriptorDtls.sharedInd
          || (evidenceDescriptorDtls.sharedInd
            && evidenceDescriptorDtls.sharedUnchangedInd)) {
          shareEvidence = false;
        }
      }
    }

    EvidenceDescriptorDtls targetEvidenceDescriptorDtls = null;

    if (shareEvidence) {
      // As we are sharing the evidence, it is not modified yet, so
      // set the indicator.

      final EvidenceDescriptorDtls shareEvidenceDescriptorDtls = new EvidenceDescriptorDtls();

      shareEvidenceDescriptorDtls.assign(sourceEvidenceDescriptorDtls);
      shareEvidenceDescriptorDtls.sharedUnchangedInd = true;
      targetEvidenceDescriptorDtls = EvidenceControllerFactory.newInstance().shareEvidence(
        shareEvidenceDescriptorDtls, targetCaseHeaderDtls);
    }

    return targetEvidenceDescriptorDtls;

  }

  /**
   * Shares the dynamic source evidence to the target case.
   *
   * @param sourceEvidenceDescriptorDtls
   * Contains the evidence to be broadcast.
   * @param targetCaseHeaderDtls
   * Contains the target case that the evidence is being broadcast to.
   *
   * @return The evidence which has been added to the target case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected EvidenceDescriptorDtls shareDynamicEvidence(
    final EvidenceDescriptorDtls sourceEvidenceDescriptorDtls,
    final CaseHeaderDtls targetCaseHeaderDtls) throws AppException,
      InformationalException {
    boolean shareEvidence = true;

    // BEGIN, CR00427301, RPB
    boolean preventBrokering = false;

    if (null != restrictEBHook) {
      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = sourceEvidenceDescriptorDtls.caseID;
      CaseHeaderDtls caseHeaderDtls = CaseHeaderFactory.newInstance().read(
        caseHeaderKey);

      // If the brokering is from PDC(source) to IC(target), check if it needs
      // to be stopped.
      if (CASETYPECODE.PARTICIPANTDATACASE.equalsIgnoreCase(
        caseHeaderDtls.caseTypeCode)) {
        if (CASETYPECODE.INTEGRATEDCASE.equalsIgnoreCase(
          targetCaseHeaderDtls.caseTypeCode)) {
          preventBrokering = restrictEBHook.preventEBProcessing(
            sourceEvidenceDescriptorDtls, targetCaseHeaderDtls);
        }
      }
    }
    // END, CR00427301

    
    if (sourceEvidenceDescriptorDtls.pendingRemovalInd) {

      final SharedInstanceIDCaseIDStatusCodes sharedInstanceCaseIDKey = new SharedInstanceIDCaseIDStatusCodes();

      sharedInstanceCaseIDKey.caseID = targetCaseHeaderDtls.caseID;
      sharedInstanceCaseIDKey.sharedInstanceID = sourceEvidenceDescriptorDtls.sharedInstanceID;

      final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = filterActiveAndEditEvidences(
        EvidenceDescriptorFactory.newInstance().searchBySharedInstanceIDCaseIDStatusCodes(
          sharedInstanceCaseIDKey));

      if (0 == evidenceDescriptorDtlsList.dtls.size()) {
        shareEvidence = false;
      }

    }

    EvidenceDescriptorDtls targetEvidenceDescriptorDtls = null;

    // BEGIN, CR00427301, RPB
    if (shareEvidence && !preventBrokering) {
      // END, CR00427301

      // As we are sharing the evidence, it is not modified yet, so
      // set the indicator.

      final EvidenceDescriptorDtls shareEvidenceDescriptorDtls = new EvidenceDescriptorDtls();

      shareEvidenceDescriptorDtls.assign(sourceEvidenceDescriptorDtls);
      shareEvidenceDescriptorDtls.sharedUnchangedInd = true;

      final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList = retrieveEvidenceBrokerConfigurationList(
        shareEvidenceDescriptorDtls);
      final EvidenceBrokerConfigDtls evidenceBrokerConfigDtls = getApplicableEvidenceBrokerConfig(
        evidenceBrokerConfigDtlsList, shareEvidenceDescriptorDtls);

      Boolean params[] = EvidenceBrokerUtils.getCachedEvidenceBrokerParams();

      Boolean considerAutoAcceptance = params[0];
      Boolean considerAutoActivation = params[1];

      if (false == evidenceBrokerConfigDtls.autoAcceptInd
        && false == evidenceBrokerConfigDtls.autoActivateInd) {
        targetEvidenceDescriptorDtls = EvidenceControllerFactory.newInstance().shareEvidence(
          shareEvidenceDescriptorDtls, targetCaseHeaderDtls);
      } else {
        if (!considerAutoAcceptance && !considerAutoActivation) {
          targetEvidenceDescriptorDtls = EvidenceControllerFactory.newInstance().shareEvidence(
            shareEvidenceDescriptorDtls, targetCaseHeaderDtls);
        } else {
          targetEvidenceDescriptorDtls = EvidenceControllerFactory.newInstance().shareEvidenceAndApplyChanges(
            shareEvidenceDescriptorDtls, targetCaseHeaderDtls);
        }
      }
    }
    return targetEvidenceDescriptorDtls;
  }

  // END, CR00385308
  
  // BEGIN, CR00398084, SSK
  /**
   * Creates a workflow task for the case for evidences in In-Edit due to auto accept. The task is assigned to the target
   * case owner of the target case and informs them that there is evidence on
   * their case that requires synchronization.
   *
   * @param targetCaseHeaderDtls
   * Contains the target case details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createCaseParticipantCreationSynchronizationInEditTask(
    final CaseHeaderDtls targetCaseHeaderDtls) throws AppException,
      InformationalException {
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = targetCaseHeaderDtls.caseID;
    final CaseReference caseReference = new CaseReference();

    caseReference.caseReference = targetCaseHeaderDtls.caseReference;

    // Create a task and assign to the target case owner
    final List enactmentDataList = new ArrayList();

    enactmentDataList.add(caseReference);
    enactmentDataList.add(caseHeaderKey);
    EnactmentService.startProcess(
      CuramConst.kCaseParticipantCreationEvidenceInEditSharing,
      enactmentDataList);
  }

  // END, CR00398084
  
  // BEGIN, CR00427012, KRK
  /**
   * Inserts the source verification item provided details into the SharedVItemProvided table.
   *
   * @param targetevidenceDescriptorDtls Target evidence descriptor details
   * @param evidenceBrokerConfigDtlsList evidence broker configuration details
   *
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  protected void createSourceVerificationItemProvidedDetails(EvidenceDescriptorDtls targetSharedDescriptorDtls, 
    EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList) throws AppException, InformationalException {
        
    final SharedInstanceIDCaseIDStatusCodes sharedInstanceIDCaseIDStatusCodes = new SharedInstanceIDCaseIDStatusCodes();
    
    final SharedVERItemProvided sharedVERItemProvidedObj = SharedVERItemProvidedFactory.newInstance();
    final VerificationItemProvided verificationItemProvidedObj = VerificationItemProvidedFactory.newInstance();
    final VDIEDLink vDIEDLinkObj = VDIEDLinkFactory.newInstance();

    sharedInstanceIDCaseIDStatusCodes.caseID = targetSharedDescriptorDtls.sourceCaseID;
    sharedInstanceIDCaseIDStatusCodes.sharedInstanceID = targetSharedDescriptorDtls.sharedInstanceID;
    sharedInstanceIDCaseIDStatusCodes.statusCode1 = EVIDENCEDESCRIPTORSTATUSEntry.ACTIVE.getCode();
    
    final EvidenceDescriptorDtlsList sourceEvidenceDescriptorDetailsList = EvidenceDescriptorFactory.newInstance().searchBySharedInstanceIDCaseIDStatusCodes(
      sharedInstanceIDCaseIDStatusCodes);

    for (EvidenceDescriptorDtls sourceevidenceDescriptorDtls : sourceEvidenceDescriptorDetailsList.dtls.items()) {
        
      final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = sourceevidenceDescriptorDtls.evidenceDescriptorID;   

      final VDIEDLinkAndDataItemIDDetailsList vdiedLinkAndDataItemIDDetailsList = vDIEDLinkObj.readByEvidenceDescriptor(
        evidenceDescriptorKey);
      
      for (final VDIEDLinkAndDataItemIDDetails vdiedLinkAndDataItemIDDetails : vdiedLinkAndDataItemIDDetailsList.dtls.items()) {       

        VDIEDLinkIDAndStatusKey vdiedLinkIDAndStatusKey = new VDIEDLinkIDAndStatusKey();

        vdiedLinkIDAndStatusKey.recordStatus = RECORDSTATUSEntry.NORMAL.getCode();             
        vdiedLinkIDAndStatusKey.VDIEDLinkID = vdiedLinkAndDataItemIDDetails.vdIEDLinkID;
          
        VerificationItemProvidedDtlsList verificationItemProvidedDtlsList = verificationItemProvidedObj.searchByVDIEDLinkIDAndStatus(
          vdiedLinkIDAndStatusKey);

        for (final VerificationItemProvidedDtls verificationItemProvidedDtls : verificationItemProvidedDtlsList.dtls.items()) {

          SharedVERItemProvidedDtls sharedVItemProvidedDtls = new SharedVERItemProvidedDtls();
            
          sharedVItemProvidedDtls.assign(verificationItemProvidedDtls);
          sharedVItemProvidedDtls.sourceVDIEDLinkID = verificationItemProvidedDtls.VDIEDLinkID;
          sharedVItemProvidedDtls.targetEvidenceDescriptorID = targetSharedDescriptorDtls.evidenceDescriptorID;
          
          if (!evidenceBrokerConfigDtlsList.dtls.isEmpty()
            && 1 == evidenceBrokerConfigDtlsList.dtls.size()) {
            
            sharedVItemProvidedDtls.shareVerificationsOption = evidenceBrokerConfigDtlsList.dtls.item(0).shareVerificationsOption;
          }
          sharedVERItemProvidedObj.insert(sharedVItemProvidedDtls);       
        }
      }     
    }   
  }
  // END, CR00427012
}
