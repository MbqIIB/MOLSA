/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidencebroker.sl.infrastructure.impl;


import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Map;

import com.google.inject.Inject;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASETYPECODE;
import curam.codetable.EVIDENCEBROKEREVENTTYPE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.EVIDENCESHARINGTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.struct.CaseContextDescription;
import curam.core.facade.struct.CaseContextDescriptionKey;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ExternalCaseHeaderFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.MaintainCase;
import curam.core.sl.entity.struct.CaseIDAndStatusKey;
import curam.core.sl.impl.CaseTypeEvidence;
import curam.core.sl.impl.LocalizableXMLStringHelper;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.impl.EvidenceController;
import curam.core.sl.infrastructure.impl.EvidenceMap;
import curam.core.sl.infrastructure.impl.StandardEvidenceInterface;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.sl.infrastructure.struct.Colspec;
import curam.core.sl.infrastructure.struct.Data;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.Entry;
import curam.core.sl.infrastructure.struct.Evidence;
import curam.core.sl.infrastructure.struct.Link;
import curam.core.sl.infrastructure.struct.List;
import curam.core.sl.infrastructure.struct.Param;
import curam.core.sl.infrastructure.struct.Resource;
import curam.core.sl.infrastructure.struct.Row;
import curam.core.sl.infrastructure.struct.TBody;
import curam.core.sl.infrastructure.struct.TextValue;
import curam.core.sl.infrastructure.widgetUtility.impl.StructToXML;
import curam.core.sl.struct.CaseIDKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ExternalCaseHeaderDtls;
import curam.core.struct.ExternalCaseHeaderKey;
import curam.evidencebroker.facade.struct.IdenticalEvidenceSearchKey;
import curam.evidencebroker.impl.EvidenceBrokerConst;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerConfigDtls;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerConfigDtlsList;
import curam.evidencebroker.sl.entity.struct.EvidenceSharingConfigKey;
import curam.evidencebroker.sl.fact.EvidenceBrokerConfigAdminFactory;
import curam.evidencebroker.sl.struct.NonIdenticalEvidenceSynchronizationDetails;
import curam.evidencebroker.sl.struct.NonIdenticalEvidenceSynchronizationDetailsList;
import curam.message.BPOEVIDENCEBROKERSYNCHRONIZATION;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * This process class provides the functionality for the evidence broker
 * synchronization widget. It supplies the information that is displayed.
 */
public class EvidenceSynchronizationWidget extends curam.evidencebroker.sl.infrastructure.base.EvidenceSynchronizationWidget {

  // BEGIN, CR00188098, GYH
  /**
   * A hash map reference of the case evidence type module which is registered
   * in the registry.
   */
  @Inject
  protected Map<String, CaseTypeEvidence> caseTypeEvidenceMap;

  /**
   * Default constructor for the class.
   */
  public EvidenceSynchronizationWidget() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00188098

  // BEGIN, CR00236468, GYH
  /**
   * @param identicalEvidenceSearchKey
   * Contains the case ID of the case being synchronized.
   *
   * @return List containing an XML representation of the identical shared
   * evidence records for use by the synchronization view.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method returns evidence records in an XML list form for
   * use by the identical evidence sharing synchronization view.
   * The returned list contains all identical shared evidence
   * records to be synchronized onto the case.
   */
  @Deprecated
  public List getIdenticalEvidenceSynchronizationList(
    IdenticalEvidenceSearchKey identicalEvidenceSearchKey)
    throws AppException, InformationalException {

    // Retrieve the evidenceDescriptor records that are relevant to this case
    CaseIDAndStatusKey key = new CaseIDAndStatusKey();

    key.caseID = identicalEvidenceSearchKey.caseID;
    key.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;

    // Retrieve records by case id and status code ordered for
    // evidence broker synchronize screen display
    EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = EvidenceDescriptorFactory.newInstance().searchByCaseIDAndStatusForEvidenceBrokerSynchronization(
      key);

    // Set up the XML List
    List list = new List();

    list.attr__style = EvidenceBrokerConst.kStyleList;

    StructToXML converter = new StructToXML();

    // Property(Type)
    Resource resourceType = new Resource();

    resourceType.attr__file = EvidenceBrokerConst.kPropertyFile;
    resourceType.attr__property = EvidenceBrokerConst.kIdenticalEvidenceClusterTitleProperty;
    String resourceTypeStr = CuramConst.gkEmpty;

    try {
      resourceTypeStr = converter.convert(resourceType,
        EvidenceBrokerConst.kResource);
    } catch (Exception e) {// do nothing
    }

    // Data (Type)
    Data typeData = new Data();

    typeData.escapeContent = false;
    typeData.attr__domain = CuramConst.kDomainRESOURCE_PROPERTY;
    typeData.value__data = resourceTypeStr;
    list.title.data = typeData;

    // Set up the column information and column headers for the list
    // This populates <thead> portion of the List XML
    processColumnsForList(list);

    // Set up the <tbody> portion of the List XML
    list.tbody = new TBody();

    // Iterate through the list of evidence records and populate the XML
    // with the evidence data
    for (int i = 0; i < evidenceDescriptorDtlsList.dtls.size(); i++) {

      // Retrieve the evidence details as a row
      Row evidenceRow = processEvidenceRecordAsRow(
        evidenceDescriptorDtlsList.dtls.item(i));

      list.tbody.row.addRef(evidenceRow);
    } // end for i

    return list;
  }

  /**
   * @param key Contains the case ID of the current case.
   *
   * @return A list of non identical evidence details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method returns a list of all non identical shared evidence records to
   * be synchronized onto the case.
   */
  @Deprecated
  public NonIdenticalEvidenceSynchronizationDetailsList getNonIdenticalEvidenceSynchronizationList(
    CaseID key) throws AppException, InformationalException {

    NonIdenticalEvidenceSynchronizationDetailsList nonIdenticalEvidenceDetailsList = new NonIdenticalEvidenceSynchronizationDetailsList();

    // Get the list of non identical evidence to be synchronized for this case
    CaseIDAndStatusKey caseIDAndStatusKey = new CaseIDAndStatusKey();

    caseIDAndStatusKey.caseID = key.caseID;
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;

    // Retrieve records by case id and status code ordered for
    // evidence broker synchronize screen display
    EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = EvidenceDescriptorFactory.newInstance().searchByCaseIDAndStatusForEvidenceBrokerSynchronization(
      caseIDAndStatusKey);

    for (int i = 0; i < evidenceDescriptorDtlsList.dtls.size(); i++) {

      NonIdenticalEvidenceSynchronizationDetails nonIdenticalEvidenceDetails = processNonIdenticalEvidence(
        evidenceDescriptorDtlsList.dtls.item(i));

      ArrayList<String> list = getAffectedList(
        evidenceDescriptorDtlsList.dtls.item(i));

      for (int j = 0; j < list.size(); j++) {

        NonIdenticalEvidenceSynchronizationDetails evidenceDetails = new NonIdenticalEvidenceSynchronizationDetails();

        nonIdenticalEvidenceDetails.affectedEvidence = list.get(j).toString();

        Entry entry = getDescriptionEntryForRow(
          evidenceDescriptorDtlsList.dtls.item(i));

        if (entry.data.size() > 0) {
          nonIdenticalEvidenceDetails.summary = entry.data.item(0).value__data;
        }

        // Add details to the return list object
        evidenceDetails.assign(nonIdenticalEvidenceDetails);
        nonIdenticalEvidenceDetailsList.dtls.addRef(evidenceDetails);
      } // end for j
    } // end for i

    return nonIdenticalEvidenceDetailsList;
  }

  /**
   * @param evidenceDescriptorDtls The non identical evidence details.
   *
   * @return The non identical evidence details for display.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method returns the details for the specified non identical shared
   * evidence record to be synchronized onto the case.
   */
  @Deprecated
  protected NonIdenticalEvidenceSynchronizationDetails processNonIdenticalEvidence(
    EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    NonIdenticalEvidenceSynchronizationDetails tempEvidenceDetails = new NonIdenticalEvidenceSynchronizationDetails();

    // Set the evidence descriptor id
    tempEvidenceDetails.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;

    // Set the participant details
    if (evidenceDescriptorDtls.participantID != 0) {

      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = evidenceDescriptorDtls.participantID;
      tempEvidenceDetails.participantName = ConcernRoleFactory.newInstance().readConcernRoleName(concernRoleKey).concernRoleName;
      tempEvidenceDetails.participantRoleID = evidenceDescriptorDtls.participantID;
    }

    // Set the event type
    // The event will be determined from the evidence descriptor details. For
    // 'Removal', the pendingRemovalInd will always be set. If the newInd is
    // set then this is 'New' evidence, otherwise it is considered 'Updated'
    // evidence. The pendingUpdateInd is never set for shared evidence so it
    // should not be examined here.
    if (evidenceDescriptorDtls.pendingRemovalInd) {
      tempEvidenceDetails.eventType = EVIDENCEBROKEREVENTTYPE.REMOVAL;
    } else if (evidenceDescriptorDtls.newInd) {
      tempEvidenceDetails.eventType = EVIDENCEBROKEREVENTTYPE.NEW;
    } else {
      tempEvidenceDetails.eventType = EVIDENCEBROKEREVENTTYPE.UPDATED;
    }

    // Set the evidence type
    tempEvidenceDetails.evidenceType = evidenceDescriptorDtls.evidenceType;

    // Set the source case details
    if (evidenceDescriptorDtls.sourceCaseID != 0) {

      // BEGIN, CR00205373, PB
      // If the evidence details is received from remote system, set the
      // source details from external case header.
      if (evidenceDescriptorDtls.externalSourceCaseInd) {
        ExternalCaseHeaderKey externalCaseHeaderKey = new ExternalCaseHeaderKey();

        externalCaseHeaderKey.externalCaseID = evidenceDescriptorDtls.sourceCaseID;
        ExternalCaseHeaderDtls externalCaseHeaderDtls = ExternalCaseHeaderFactory.newInstance().read(
          externalCaseHeaderKey);

        if (CuramConst.gkEmpty != externalCaseHeaderDtls.caseType) {

          CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
            externalCaseHeaderDtls.caseType);

          if (null == caseTypeEvidence) {
            AppException e = new AppException(
              BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

            e.arg(
              CodeTable.getOneItem(CASETYPECODE.TABLENAME,
              externalCaseHeaderDtls.caseType,
              TransactionInfo.getProgramLocale()));
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              e,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              31);
          }
          String caseSubType = caseTypeEvidence.getCaseTypeDescriptionDetails(
            externalCaseHeaderDtls.caseSubType);

          StringBuffer sourceCaseBuffer = new StringBuffer();

          sourceCaseBuffer.append(caseSubType);
          sourceCaseBuffer.append(CuramConst.gkSpace);
          sourceCaseBuffer.append(CuramConst.gkDash);
          sourceCaseBuffer.append(CuramConst.gkSpace);
          sourceCaseBuffer.append(externalCaseHeaderDtls.caseNumber);

          tempEvidenceDetails.sourceCase = sourceCaseBuffer.toString();
        }
      } else {
        // END, CR00205373

        // Call MaintainCase to read the product name and case reference
        MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();

        CaseIDKey caseIDKey = new CaseIDKey();

        caseIDKey.caseID = evidenceDescriptorDtls.sourceCaseID;

        CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
          caseIDKey);

        // Source case details are the Product Name and Case reference
        StringBuffer sourceCaseBuffer = new StringBuffer();

        sourceCaseBuffer.append(
          caseReferenceProductNameConcernRoleName.productName);
        sourceCaseBuffer.append(CuramConst.gkSpace);
        sourceCaseBuffer.append(CuramConst.gkDash);
        sourceCaseBuffer.append(CuramConst.gkSpace);
        sourceCaseBuffer.append(
          caseReferenceProductNameConcernRoleName.caseReference);

        tempEvidenceDetails.sourceCase = sourceCaseBuffer.toString();
      }
    }

    return tempEvidenceDetails;
  }

  /**
   * @param list The list for which columns are being processed.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method processes the columns for the given list.
   * The method sets the column sizing information and then reads
   * the column headers from a comma-separated message string.
   * These column headers are set on the <thead> portion of the List XML.
   */
  @Deprecated
  protected void processColumnsForList(List list)
    throws AppException, InformationalException {

    // Retrieve column headers as a comma-separated list from message file
    LocalisableString headingsString = new LocalisableString(
      BPOEVIDENCEBROKERSYNCHRONIZATION.INF_IDENTICAL_EVIDENCE_SYNCHRONIZATION_HEADING_LIST);

    // BEGIN, CR00163659, CL
    // Turn the headings list into a string array
    String columnHeaders[] = headingsString.getMessage(TransactionInfo.getProgramLocale()).split(
      CuramConst.gkComma);
    // END, CR00163659

    // Set up column headers as a row
    Row headerRow = new Row();

    // Populate the header row with the column headings
    for (int i = 0; i < columnHeaders.length; i++) {

      // Initialize the column spec
      Colspec colspec = new Colspec();

      colspec.attr__colwidth = CuramConst.gkEmpty + 10
        + EvidenceBrokerConst.kPercent;
      list.colspec.addRef(colspec);

      // Data (Heading)
      Data headingColData = new Data();

      headingColData.attr__domain = CuramConst.kDomainSVR_STRING;
      headingColData.value__data = columnHeaders[i];

      // Entry (Heading)
      Entry headerEntry = new Entry();

      headerEntry.data.addRef(headingColData);

      // Add the Entry to the row
      headerRow.entry.addRef(headerEntry);
    } // end for i

    // Add the row to the list
    list.thead.row.addRef(headerRow);
  }

  /**
   * @param evidenceDescriptorDtls The evidence record to process.
   *
   * @return A row of evidence data for display on the synchronize list.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method processes an evidence record as an XML row.
   * The relevant evidence data is retrieved and the row populated
   * with the information.
   */
  @Deprecated
  protected Row processEvidenceRecordAsRow(
    EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    // Initialize the return object
    Row row = new Row();

    // Column entry field
    Entry entry = new Entry();

    // Column 1 in the row: 'Option' field
    entry = getOptionEntryForRow(evidenceDescriptorDtls);
    row.entry.addRef(entry);

    // Column 2 in the row: 'Event' field
    entry = getEventEntryForRow(evidenceDescriptorDtls);
    row.entry.addRef(entry);

    // Column 3 in the row: 'Evidence' field
    entry = getEvidenceEntryForRow(evidenceDescriptorDtls);
    row.entry.addRef(entry);

    // Column 4 in the row: 'Name' field
    entry = getNameEntryForRow(evidenceDescriptorDtls);
    row.entry.addRef(entry);

    // Column 5 in the row: 'Description' field
    entry = getDescriptionEntryForRow(evidenceDescriptorDtls);
    row.entry.addRef(entry);

    // Column 6 in the row: 'Source' field
    entry = getSourceEntryForRow(evidenceDescriptorDtls);
    row.entry.addRef(entry);

    // Column 7 in the row: 'Action' field
    entry = getActionEntryForRow(evidenceDescriptorDtls);
    row.entry.addRef(entry);

    return row;
  }

  /**
   * @param dtls The evidence associated with this row.
   *
   * @return The column entry.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method retrieves the 'Action' column entry for a row.
   * The Action value is always 'Compare' link.
   */
  @Deprecated
  protected Entry getActionEntryForRow(EvidenceDescriptorDtls dtls)
    throws AppException, InformationalException {

    // Initialize fields to populate the Row Entry
    Entry entry = new Entry();
    Data data = new Data();

    data.attr__domain = EvidenceBrokerConst.kUCLink;
    data.escapeContent = false;
    StructToXML converter = new StructToXML();

    // Populate data: Action is always 'compare' link
    LocalisableString actionString = new LocalisableString(
      BPOEVIDENCEBROKERSYNCHRONIZATION.INF_COMPARE_LINK);

    Link link = new Link();

    link.attr__pageID = EvidenceBrokerConst.kCompareIdenticalLink;

    // BEGIN, CR00161875, BD
    Param param = new Param();

    param.attr__name = EvidenceBrokerConst.kCaseID;
    param.value__value = Long.valueOf(dtls.caseID).toString();
    link.params.param.addRef(param);

    Param param2 = new Param();

    param2.attr__name = EvidenceBrokerConst.kEvidenceDescriptorID;
    param2.value__value = Long.valueOf(dtls.evidenceDescriptorID).toString();
    link.params.param.addRef(param2);
    // END, CR00161875
    Param param3 = new Param();

    // Retrieve the context description
    CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = dtls.caseID;

    CaseContextDescription contextDescription = CaseFactory.newInstance().readCaseContextDescription(
      caseContextDescriptionKey);

    param3.attr__name = EvidenceBrokerConst.kContextDescription;
    param3.value__value = contextDescription.description;
    // BEGIN, CR00161875, BD
    link.params.param.addRef(param3);
    // END, CR00161875
    Param param4 = new Param();

    param4.attr__name = EvidenceBrokerConst.ko3rpu;
    try {
      param4.value__value = URLEncoder.encode(
        EvidenceBrokerConst.kSynchronizingPage.trim()
          + EvidenceBrokerConst.kQuestionMark.trim()
          + EvidenceBrokerConst.kCaseID.trim() + CuramConst.gkEquals.trim()
          + Long.valueOf(dtls.caseID).toString()
          + EvidenceBrokerConst.kAmpersand.trim()
          + EvidenceBrokerConst.ko3rpu.trim() + CuramConst.gkEquals.trim()
          + URLEncoder.encode(
            EvidenceBrokerConst.kHighLevelInEditWorkspace.trim()
              + EvidenceBrokerConst.kQuestionMark.trim()
              + EvidenceBrokerConst.kCaseID.trim() + CuramConst.gkEquals.trim()
              + Long.valueOf(dtls.caseID).toString()
              + EvidenceBrokerConst.kAmpersand.trim()
              + EvidenceBrokerConst.kParticipantID.trim()
              + CuramConst.gkEquals.trim()
              + EvidenceBrokerConst.kZeroString.trim()
              + EvidenceBrokerConst.kAmpersand.trim()
              + EvidenceBrokerConst.kEvidenceType.trim()
              + CuramConst.gkEquals.trim(),
              EvidenceBrokerConst.kUTF8),
              EvidenceBrokerConst.kUTF8);
    } catch (UnsupportedEncodingException e) {
      AppException ae = new AppException(
        BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_URL_ENCODING_ERROR);

      throw new AppRuntimeException(ae);
    }
    // BEGIN, CR00161875, BD
    link.params.param.addRef(param4);
    // END, CR00161875
    TextValue displayText = new TextValue();

    // BEGIN, CR00163659, CL
    displayText.value__textValue = actionString.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163659
    link.displayText = displayText;

    String linkDataStr = CuramConst.gkNull;

    try {
      linkDataStr = converter.convert(link, EvidenceBrokerConst.kLCLink);
    } catch (Exception e) {
      AppException ae = new AppException(
        BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_CONVERSION_TO_DOM_ERROR);

      throw new AppRuntimeException(ae);
    }
    data.value__data = linkDataStr;
    entry.data.addRef(data);
    return entry;
  }

  /**
   * @param evidenceDescriptorDtls the Evidence Row
   *
   * @return the column entry.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method retrieves the 'Source' column entry for a row.
   * The Source value is a description for the sharing source case
   * that is 'Product Name - Case Reference'.
   */
  @Deprecated
  protected Entry getSourceEntryForRow(
    EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    // Initialize fields to populate the Row Entry
    Entry entry = new Entry();
    Data data = new Data();
    String dataString = new String();

    data.attr__domain = CuramConst.kDomainSVR_STRING;

    // Populate data: retrieve Source Case details
    if (evidenceDescriptorDtls.sourceCaseID != 0) {

      // BEGIN, CR00205373, PB
      if (evidenceDescriptorDtls.externalSourceCaseInd) {
        ExternalCaseHeaderKey externalCaseHeaderKey = new ExternalCaseHeaderKey();

        externalCaseHeaderKey.externalCaseID = evidenceDescriptorDtls.sourceCaseID;
        ExternalCaseHeaderDtls externalCaseHeaderDtls = ExternalCaseHeaderFactory.newInstance().read(
          externalCaseHeaderKey);

        if (CuramConst.gkEmpty != externalCaseHeaderDtls.caseType) {

          CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
            externalCaseHeaderDtls.caseType);

          if (null == caseTypeEvidence) {
            AppException e = new AppException(
              BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

            e.arg(
              CodeTable.getOneItem(CASETYPECODE.TABLENAME,
              externalCaseHeaderDtls.caseType,
              TransactionInfo.getProgramLocale()));
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              e,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              30);
          }
          String caseSubType = caseTypeEvidence.getCaseTypeDescriptionDetails(
            externalCaseHeaderDtls.caseSubType);

          StringBuffer dataStringBuffer = new StringBuffer();

          dataStringBuffer.append(caseSubType);
          dataStringBuffer.append(CuramConst.gkSpace);
          dataStringBuffer.append(CuramConst.gkDash);
          dataStringBuffer.append(CuramConst.gkSpace);
          dataStringBuffer.append(externalCaseHeaderDtls.caseNumber);

          dataString = dataStringBuffer.toString();
        }
      } else {
        // END, CR00205373
        // Read the product name and case reference
        CaseIDKey caseIDKey = new CaseIDKey();

        caseIDKey.caseID = evidenceDescriptorDtls.sourceCaseID;

        CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = MaintainCaseFactory.newInstance().readCaseReferenceConcernRoleNameProductNameByCaseID(
          caseIDKey);

        // Source case details are Product Name and Case reference
        // BEGIN, CR00205373, PB
        StringBuffer dataStringBuffer = new StringBuffer();

        dataStringBuffer.append(
          caseReferenceProductNameConcernRoleName.productName);
        dataStringBuffer.append(CuramConst.gkSpace);
        dataStringBuffer.append(CuramConst.gkDash);
        dataStringBuffer.append(CuramConst.gkSpace);
        dataStringBuffer.append(
          caseReferenceProductNameConcernRoleName.caseReference);

        dataString = dataStringBuffer.toString();
      }
      // END, CR00205373
    }
    data.value__data = dataString;
    entry.data.addRef(data);
    return entry;
  }

  /**
   * @param evidenceDescriptorDtls the Evidence Row
   *
   * @return the column entry.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method retrieves the 'Description' column entry for a row.
   * The Description value is a summary of information regarding
   * the evidence record.
   */
  @Deprecated
  protected Entry getDescriptionEntryForRow(
    EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    // Initialize fields to populate the Row Entry
    Entry entry = new Entry();
    Data data = new Data();

    data.attr__domain = CuramConst.kDomainSVR_STRING;

    // Get the evidence map through the EvidenceController
    EvidenceMap evidenceMap = EvidenceController.getEvidenceMap();

    StandardEvidenceInterface standardEvidenceInterface = evidenceMap.getEvidenceType(
      evidenceDescriptorDtls.evidenceType);

    // Call relevant evidence interface to retrieve Description
    // for the evidence record
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    eiEvidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;

    // Populate data: Retrieve the description field from
    // the relevant evidence entity
    String dataString = standardEvidenceInterface.getDetailsForListDisplay(eiEvidenceKey).summary;

    // BEGIN, CR00244064, CD
    // Summary may now be marked up as client formatted text.
    // Ensure that this assignment keeps to it's original contract.
    data.value__data = LocalizableXMLStringHelper.toPlainText(dataString);
    // END, CR00244064

    entry.data.addRef(data);
    return entry;
  }

  /**
   * @param evidenceDescriptorDtls the Evidence Row
   *
   * @return the column entry.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method retrieves the 'Name' column entry for a row.
   * The Name value is determined from the Concern Role entity.
   * This value is displayed as a Link to the <Person_homePage> uim file.
   */
  @Deprecated
  protected Entry getNameEntryForRow(
    EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    // Initialize fields to populate the Row Entry
    Entry entry = new Entry();
    Data data = new Data();

    data.attr__domain = EvidenceBrokerConst.kUCLink;
    data.escapeContent = false;
    StructToXML converter = new StructToXML();

    // Populate data: retrieve the name from the Concern Role entity
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = evidenceDescriptorDtls.participantID;
    ConcernRoleDtls concernRoleDtls = ConcernRoleFactory.newInstance().read(
      concernRoleKey);

    // Set up the Link to point to the Person_homePage uim
    Link link = new Link();

    link.attr__pageID = UimConst.PersonHomePage;

    Param param = new Param();

    param.attr__name = EvidenceBrokerConst.kConcernRoleID;
    param.value__value = String.valueOf(evidenceDescriptorDtls.participantID);
    // BEGIN, CR00161875, BD
    link.params.param.addRef(param);
    // END, CR00161875, BD
    TextValue displayText = new TextValue();

    displayText.value__textValue = concernRoleDtls.concernRoleName;
    link.displayText = displayText;

    String linkDataStr = CuramConst.gkNull;

    try {
      linkDataStr = converter.convert(link, EvidenceBrokerConst.kLCLink);
    } catch (Exception e) {
      AppException ae = new AppException(
        BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_CONVERSION_TO_DOM_ERROR);

      throw new AppRuntimeException(ae);
    }
    data.value__data = linkDataStr;
    entry.data.addRef(data);

    return entry;
  }

  /**
   * @param evidenceDescriptorDtls the Evidence Row
   *
   * @return the column entry.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method retrieves the 'Evidence' column entry for a row.
   * The Evidence value is determined from the EvidenceDescriptor
   * Evidence Type.
   */
  @Deprecated
  protected Entry getEvidenceEntryForRow(
    EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    // Initialize fields to populate the Row Entry
    Entry entry = new Entry();
    Data data = new Data();

    data.attr__domain = CuramConst.kDomainSVR_STRING;

    // Populate data: retrieve the Evidence Type as a localized string
    String dataString = CodeTable.getOneItem(// BEGIN, CR00163098, JC
      CASEEVIDENCE.TABLENAME, evidenceDescriptorDtls.evidenceType,
      TransactionInfo.getProgramLocale());

    // END, CR00163098, JC
    data.value__data = dataString;
    entry.data.addRef(data);
    return entry;
  }

  /**
   * @param evidenceDescriptorDtls the Evidence Row
   *
   * @return the column entry.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method retrieves the 'Event' column entry for a row.
   * The Event value is determined from the EvidenceDescriptor
   * newInd indicator value.
   */
  @Deprecated
  protected Entry getEventEntryForRow(
    EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    // Initialize fields to populate the Row Entry
    Entry entry = new Entry();
    String dataString = new String();
    Data data = new Data();

    data.attr__domain = EvidenceBrokerConst.kDomainEVIDENCEEVENTDESC;

    // Populate data: retrieve the Event as a localized string
    // The event will be determined from the evidence descriptor details. For
    // 'Removal', the pendingRemovalInd will always be set. If the newInd is set
    // then this is 'New' evidence, otherwise it is considered 'Updated'
    // evidence. The pendingUpdateInd is never set for shared evidence so it
    // should not be examined here.
    if (evidenceDescriptorDtls.pendingRemovalInd) {
      dataString = EVIDENCEBROKEREVENTTYPE.REMOVAL;
    } else if (evidenceDescriptorDtls.newInd) {
      dataString = EVIDENCEBROKEREVENTTYPE.NEW;
    } else {
      dataString = EVIDENCEBROKEREVENTTYPE.UPDATED;
    }

    data.value__data = dataString;
    entry.data.addRef(data);

    return entry;
  }

  /**
   * @param evidenceDescriptorDtls The evidence relevant to this row.
   *
   * @return The column entry.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * This method retrieves the 'Option' column entry for a row. The Option value
   * is defaulted to an empty string. This entry also includes the evidence
   * descriptor ID as a hidden field. This ID is needed by the client
   * infrastructure.
   */
  @Deprecated
  protected Entry getOptionEntryForRow(
    EvidenceDescriptorDtls evidenceDescriptorDtls)
    throws AppException, InformationalException {

    // Initialize fields to populate the Row Entry
    Entry entry = new Entry();
    Data data = new Data();

    data.escapeContent = false;
    StructToXML converter = new StructToXML();

    // Populate the entry with the domain definition and an empty value
    data.attr__domain = EvidenceBrokerConst.kSyncSelectBox;
    String dataString = CuramConst.gkEmpty;

    data.value__data = dataString;
    entry.data.addRef(data);

    // Include the evidence ID as part of the Option entry as it is required
    // by the client for the <ACTION> bean
    data = new Data();
    Evidence evidence = new Evidence();

    evidence.attr__evidenceID = String.valueOf(
      evidenceDescriptorDtls.evidenceDescriptorID);

    String evidenceStr = CuramConst.gkNull;

    try {
      evidenceStr = converter.convert(evidence, EvidenceBrokerConst.kEvidence);
    } catch (Exception e) {
      AppException ae = new AppException(
        BPOEVIDENCEBROKERSYNCHRONIZATION.ERR_CONVERSION_TO_DOM_ERROR);

      throw new AppRuntimeException(ae);
    }
    data.value__data = evidenceStr;
    entry.data.addRef(data);

    return entry;
  }

  /**
   * @param evidenceDescriptorDtls
   * The non identical evidence which could affect evidence on the
   * target case.
   *
   * @return List of affected evidence types on the target case
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * Helper function to find the affected evidence types on the target case.
   */
  @Deprecated
  protected ArrayList<String> getAffectedList(
    EvidenceDescriptorDtls evidenceDescriptorDtls) throws AppException,
      InformationalException {

    // Get the affected evidence details
    // BEGIN, CR00208096, GYH
    EvidenceSharingConfigKey sourceTargetEvidenceAndStatusKey = new EvidenceSharingConfigKey();

    // Get the source and target parameters
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (evidenceDescriptorDtls.sourceCaseID != 0) {

      // BEGIN CR00205373, PB
      if (evidenceDescriptorDtls.externalSourceCaseInd) {
        CaseKey sourcecaseKey = new CaseKey();

        sourcecaseKey.caseID = evidenceDescriptorDtls.sourceCaseID;
        ExternalCaseHeaderDtls externalCaseHeaderDtls = getExternalCaseHeaderDetails(
          sourcecaseKey);

        sourceTargetEvidenceAndStatusKey.sourceType = externalCaseHeaderDtls.caseType;
        sourceTargetEvidenceAndStatusKey.sourceSystemID = externalCaseHeaderDtls.sourceSystemID;

        // Retrieve the corresponding source ID
        CaseTypeEvidence caseTypeEvidence = getCaseTypeEvidence(
          externalCaseHeaderDtls.caseType);

        CaseKey caseKey = new CaseKey();

        caseKey.caseID = externalCaseHeaderDtls.externalCaseID;
        sourceTargetEvidenceAndStatusKey.sourceID = caseTypeEvidence.getSubTypeID(
          externalCaseHeaderDtls.caseSubType);

      } else {
        // END, CR00205373
        caseHeaderKey.caseID = evidenceDescriptorDtls.sourceCaseID;
        CaseHeaderDtls caseHeaderDtls = CachedCaseHeaderFactory.newInstance().read(
          caseHeaderKey);

        sourceTargetEvidenceAndStatusKey.sourceType = caseHeaderDtls.caseTypeCode;

        // Retrieve the corresponding source ID
        // BEGIN, CR00188098, GYH
        // BEGIN, CR00205373, PB
        CaseTypeEvidence caseTypeEvidence = getCaseTypeEvidence(
          caseHeaderDtls.caseTypeCode);
        // END, CR00205373
        CaseKey caseKey = new CaseKey();

        caseKey.caseID = caseHeaderDtls.caseID;
        sourceTargetEvidenceAndStatusKey.sourceID = caseTypeEvidence.readEvidenceBrokerSourceIDByCaseID(
          caseKey);
        // END, CR00188098
      }
    }
    if (evidenceDescriptorDtls.caseID != 0) {

      // BEGIN, CR00205373, PB
      if (evidenceDescriptorDtls.externalSourceCaseInd) {

        CaseKey sourcecaseKey = new CaseKey();

        sourcecaseKey.caseID = evidenceDescriptorDtls.caseID;
        ExternalCaseHeaderDtls externalCaseHeaderDtls = getExternalCaseHeaderDetails(
          sourcecaseKey);

        sourceTargetEvidenceAndStatusKey.targetType = externalCaseHeaderDtls.caseType;
        sourceTargetEvidenceAndStatusKey.sourceSystemID = externalCaseHeaderDtls.sourceSystemID;

        // Retrieve the corresponding source ID
        CaseTypeEvidence caseTypeEvidence = getCaseTypeEvidence(
          externalCaseHeaderDtls.caseType);

        CaseKey caseKey = new CaseKey();

        caseKey.caseID = externalCaseHeaderDtls.externalCaseID;
        sourceTargetEvidenceAndStatusKey.targetID = caseTypeEvidence.getSubTypeID(
          externalCaseHeaderDtls.caseSubType);
      } else {
        // END, CR00205373
        caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
        CaseHeaderDtls caseHeaderDtls = CachedCaseHeaderFactory.newInstance().read(
          caseHeaderKey);

        sourceTargetEvidenceAndStatusKey.targetType = caseHeaderDtls.caseTypeCode;

        // Retrieve the corresponding target ID
        // BEGIN, CR00188098, GYH
        // BEGIN, CR00205373, PB
        CaseTypeEvidence caseTypeEvidence = getCaseTypeEvidence(
          caseHeaderDtls.caseTypeCode);
        // END, PB
        CaseKey caseKey = new CaseKey();

        caseKey.caseID = caseHeaderDtls.caseID;

        sourceTargetEvidenceAndStatusKey.targetID = caseTypeEvidence.readEvidenceBrokerSourceIDByCaseID(
          caseKey);
        // END, CR00188098
      }
    }
    // Return object
    ArrayList<String> targetEvidenceTypeList = new ArrayList<String>();

    sourceTargetEvidenceAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
    sourceTargetEvidenceAndStatusKey.sourceEvidenceType = evidenceDescriptorDtls.evidenceType;
    sourceTargetEvidenceAndStatusKey.sharedType = EVIDENCESHARINGTYPE.NONIDENTICAL;

    EvidenceBrokerConfigDtlsList tempList = EvidenceBrokerConfigAdminFactory.newInstance().listSharedSourceAndTargetEvidences(
      sourceTargetEvidenceAndStatusKey);

    // If the broker configuration list is empty, the broadcaseEvidence functionality
    // might be used to create an evidence of type different than specified by
    // the configuration.  Creating a configuration record using the evidence
    // type present in the shared evidence for listing of non-identical evidence
    if (tempList.dtls.isEmpty()) {
      EvidenceBrokerConfigDtls evidenceBrokerConfigDtls = new EvidenceBrokerConfigDtls();

      evidenceBrokerConfigDtls.targetEvidenceType = evidenceDescriptorDtls.evidenceType;
      tempList.dtls.addRef(evidenceBrokerConfigDtls);
    }

    // END, CR00208096

    for (int i = 0; i < tempList.dtls.size(); i++) {
      if (!targetEvidenceTypeList.contains(
        tempList.dtls.item(i).targetEvidenceType)) {
        targetEvidenceTypeList.add(tempList.dtls.item(i).targetEvidenceType);
      }
    } // end for i

    return targetEvidenceTypeList;
  }

  // BEGIN, CR00205373, PB
  /**
   * @param caseTypeCode The case type code for the case.
   *
   * @return case type specific object.
   *
   * @throws AppException
   * {@link BPOEVIDENCECONTROLLER #ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED}
   * if the case type is not supported.
   *
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * Gets the case type specific object by case type code.
   */
  @Deprecated
  protected CaseTypeEvidence getCaseTypeEvidence(final String caseTypeCode)
    throws AppException, InformationalException {

    CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(caseTypeCode);

    if (null == caseTypeEvidence) {
      AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, caseTypeCode,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 29);
    }
    return caseTypeEvidence;
  }

  /**
   * @param caseKey Contains the caseID.
   *
   * @return case details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link EvidenceBrokerSynchronization#listIncomingEvidence(
   * CaseIDAndStatusKey)} . This method has been deprecated because
   * as part of evidence broker usability changes the list evidence
   * synchronization screen has been enhanced to simple identical
   * and non identical incoming evidence list screens and hence
   * there is no need for widget processing.
   * See release note: CR00236468.
   *
   * Gets the remote system case details.
   */
  @Deprecated
  protected ExternalCaseHeaderDtls getExternalCaseHeaderDetails(
    final CaseKey caseKey) throws AppException, InformationalException {

    ExternalCaseHeaderKey externalCaseHeaderKey = new ExternalCaseHeaderKey();

    externalCaseHeaderKey.externalCaseID = caseKey.caseID;
    ExternalCaseHeaderDtls externalCaseHeaderDtls = ExternalCaseHeaderFactory.newInstance().read(
      externalCaseHeaderKey);

    return externalCaseHeaderDtls;
  }
  // END, CR00205373
  // END, CR00236468
}
