/*
 * IBM Confidential 
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2013, 2014
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office
 *
 */

package curam.evidencebroker.sl.impl;


import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * Provides the functionality for evidence sharing through the deferred process.
 */

public abstract class EvidenceBrokerDP extends curam.evidencebroker.sl.base.EvidenceBrokerDP {

  private EvidenceBrokerDPTemplate evidenceBrokerDPTemplate = new EvidenceBrokerDPTemplate();

  /**
   * Default constructor for the class.
   */
  public EvidenceBrokerDP() {

    // BEGIN, CR00400002, SSK
    GuiceWrapper.getInjector().injectMembers(this);
    // BEGIN, CR00427655, RPB
    evidenceBrokerDPTemplate.init(ReflectionConst.evidenceBrokerDPClassName,
      Boolean.TRUE, Boolean.TRUE);
    // END, CR00427655
    // END, CR00400002
  }

  /**
   * Determines whether a given evidence is configured for evidence sharing, if
   * configured, then shares this evidence with the relevant cases.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The taxonomy version instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void shareEvidence(long ticketID, long instDataID, boolean flag)
    throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareEvidence(ticketID, instDataID, flag);
  }

  /**
   * Identifies the case that this participant role has been set up on. It then
   * finds any evidence sharing configurations that are applicable to this new
   * case and shares all of the evidence relevant to this participant role with
   * the new case.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The taxonomy version instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void shareEvdForCaseParticipant(long ticketID, long instDataID,
    boolean flag) throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareEvdForCaseParticipant(ticketID, instDataID,
      flag);
  }

  /**
   * Determines whether a given piece of evidence is configured for evidence
   * removal sharing, if configured, then shares the evidence with the relevant
   * cases.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The taxonomy version instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void shareEvidenceRemoval(long ticketID, long instDataID, boolean flag)
    throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareEvidenceRemoval(ticketID, instDataID, flag);
  }

  /**
   * Determines whether a given piece of evidence received from a remote system
   * is configured for evidence sharing, if configured, then shares the evidence
   * with the relevant cases.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The taxonomy version instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void shareExternalEvidence(long ticketID, long instDataID, boolean flag)
    throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareExternalEvidence(ticketID, instDataID, flag);
  }

  /**
   * Determines whether a given piece of evidence received from a remote system
   * is configured for evidence removal sharing, if configured, then shares the
   * evidence with the relevant cases.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The taxonomy version instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void shareExternalEvidenceRemoval(long ticketID, long instDataID,
    boolean flag) throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareExternalEvidenceRemoval(ticketID, instDataID,
      flag);
  }
 
  // BEGIN, CR00397427, RPB
  /**
   * Determines whether a given set of evidences is configured for evidence
   * sharing, if configured, then shares the evidences with the relevant cases
   * after reading the list of evidences stored in the data store.
   *
   * @param ticketID
   * Deferred process ticket ID.
   * @param instDataID
   * The data store instance ID.
   * @param flag
   * Required for deferred process.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void shareBulkEvidence(long ticketID, long instDataID, boolean flag)
    throws AppException, InformationalException {

    evidenceBrokerDPTemplate.shareBulkEvidence(ticketID, instDataID, flag);
  }
  // END, CR00397427
}
