/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2010,2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.evidencebroker.sl.infrastructure.impl;


import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.axiom.om.OMAbstractFactory;
import org.apache.axiom.om.OMElement;
import org.apache.axiom.om.OMFactory;
import org.apache.axiom.om.OMNamespace;
import org.apache.axiom.om.OMNode;
import org.apache.axiom.soap.SOAPFactory;
import org.apache.axiom.soap.SOAPHeaderBlock;
import org.apache.axis2.addressing.EndpointReference;
import org.apache.axis2.client.ServiceClient;
import org.apache.axis2.context.ConfigurationContext;
import org.apache.axis2.description.AxisService;
import org.apache.axis2.engine.AxisConfiguration;
import org.apache.axis2.rpc.client.RPCServiceClient;
import org.apache.axis2.util.XMLUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.google.inject.Inject;

import curam.codetable.CASETYPECODE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.EVIDENCESHARINGTYPE;
import curam.codetable.OPERATIONNAME;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SYNCHRONIZATIONACTION;
import curam.codetable.impl.EVIDENCEDESCRIPTORSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SYSTEMSERVICENAMEEntry;
import curam.codetable.impl.TARGETSYSTEMSTATUSEntry;
import curam.core.events.EVIDENCEBROKER;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ExternalCaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.ConcernRole;
import curam.core.security.util.impl.SymmetricEncryption;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.impl.CaseTypeEvidence;
import curam.core.sl.impl.EvidenceBrokerSharingStrategy;
import curam.core.sl.infrastructure.entity.fact.EvidenceChangeHistoryFactory;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceChangeHistory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceAddedDateDetails;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKeyList;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EIEvidenceReadDtls;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.WSConvertBSConst;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.struct.SharedEvidenceDescriptorDetails;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderDtlsList;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ExternalCaseHeaderDtls;
import curam.core.struct.ExternalCaseHeaderKey;
import curam.core.ws.convert.utils.impl.ConversionUtil;
import curam.ctm.sl.entity.base.TargetSystemService;
import curam.ctm.sl.entity.fact.TargetSystemServiceFactory;
import curam.ctm.sl.entity.struct.NameSystemIDAndStatusKey;
import curam.ctm.sl.entity.struct.TargetSystemServiceDtls;
import curam.ctm.targetsystem.impl.TargetSystem;
import curam.ctm.targetsystem.impl.TargetSystemDAO;
import curam.evidence.impl.EvidenceTypeFactory;
import curam.evidencebroker.impl.EvidenceBrokerConst;
import curam.evidencebroker.impl.EvidenceBrokerUtils;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerConfigDtls;
import curam.evidencebroker.sl.entity.struct.EvidenceBrokerConfigDtlsList;
import curam.evidencebroker.sl.entity.struct.EvidenceSharingConfigKey;
import curam.evidencebroker.sl.entity.struct.SharedSourceEvidenceAndStatusKey;
import curam.evidencebroker.sl.entity.struct.SharedTargetEvidenceAndStatusKey;
import curam.evidencebroker.sl.fact.EvidenceBrokerConfigAdminFactory;
import curam.evidencebroker.sl.impl.EvidenceBrokerFilters;
import curam.evidencebroker.sl.impl.EvidenceBrokerTaskGenerationStrategy;
import curam.evidencebroker.sl.impl.ProcessEvidenceHelper;
import curam.evidencebroker.sl.struct.EvidenceDescriptorIDAndSynchronizeAction;
import curam.evidencebroker.sl.struct.EvidenceDescriptorIDAndSynchronizeActionList;
import curam.evidencebroker.sl.struct.SharedEvidenceSourceTypeAndSourceIDDetails;
import curam.evidencebroker.sl.struct.SharingPartyKey;
import curam.evidencebroker.ws.publiclayer.bs.remote.EvdBrokerWebServiceStub;
import curam.message.BPOEVIDENCEBROKER;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.message.impl.WSRESPONSESExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.NotFoundIndicator;
import curam.verification.sl.infrastructure.entity.fact.VDIEDLinkFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationItemProvidedFactory;
import curam.verification.sl.infrastructure.entity.intf.VDIEDLink;
import curam.verification.sl.infrastructure.entity.intf.VerificationItemProvided;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkAndDataItemIDDetails;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkAndDataItemIDDetailsList;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDAndStatusKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedDtlsList;
import curam.verification.sl.infrastructure.fact.SharedVERItemProvidedFactory;
import curam.verification.sl.infrastructure.impl.VerificationConst;
import curam.verification.sl.infrastructure.intf.SharedVERItemProvided;
import curam.verification.sl.infrastructure.struct.SharedVERItemProvidedDtls;


/**
 * Default implementation of evidence sharing strategy. This default
 * implementation provides facility for identical/non-identical sharing of
 * evidence with the relevant cases.
 */
public class EvidenceBrokerSharingStrategyImpl implements
  EvidenceBrokerSharingStrategy {

  /**
   * Reference to a helper class {@link ProcessEvidenceHelper}.
   */
  @Inject
  protected ProcessEvidenceHelper processEvidenceHelper;

  // BEGIN, CR00206415, PB.
  @Inject
  protected Map<String, CaseTypeEvidence> caseTypeEvidenceMap;

  // BEGIN, CR00389115, SSK
  @Inject
  protected EvidenceBrokerTaskGenerationStrategy evidenceBrokerTaskGenerationStrategy;

  // END, CR00389115
  
  @Inject
  protected TargetSystemDAO targetSystemDAO;

  // END, CR00206415.

  // BEGIN, CR00241358, EC
  /**
   * Reference to {@link curam.core.security.util.impl.SymmetricEncryption}
   */
  @Inject
  protected SymmetricEncryption codec;

  // END, CR00241358

  /**
   * Default constructor for the class.
   */
  public EvidenceBrokerSharingStrategyImpl() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00379320, SR
  /**
   * {@inheritDoc}
   */
  public void shareEvidenceWithBrokeringOnly(
    final EvidenceDescriptorKey evidenceDescriptorKey)
    throws AppException, InformationalException {

    shareEvidence(evidenceDescriptorKey, Boolean.FALSE, Boolean.FALSE);
  }

  /**
   * {@inheritDoc}
   */
  public void shareEvidenceWithAutoAcceptOnly(
    final EvidenceDescriptorKey evidenceDescriptorKey)
    throws AppException, InformationalException {

    shareEvidence(evidenceDescriptorKey, Boolean.TRUE, Boolean.FALSE);
  }
    
  /**
   * {@inheritDoc}
   */
  public void shareEvidence(final EvidenceDescriptorKey evidenceDescriptorKey)
    throws AppException, InformationalException {
    
    Boolean params[] = EvidenceBrokerUtils.getCachedEvidenceBrokerParams();
    
    Boolean considerAutoAcceptance = params[0];    
    Boolean considerAutoActivation = params[1];
    
    shareEvidence(evidenceDescriptorKey, considerAutoAcceptance,
      considerAutoActivation);
  }

  /**
   * {@inheritDoc}
   */
  public void shareEvidence(
    final EvidenceDescriptorKey evidenceDescriptorKey,
    Boolean considerAutoAcceptance, Boolean considerAutoActivation)
    throws AppException, InformationalException {

    EvidenceDescriptorDtls evidenceDescriptorDtls = EvidenceDescriptorFactory.newInstance().read(
      evidenceDescriptorKey);

    // Retrieve the source type and source ID for the originating case.
    SharedEvidenceSourceTypeAndSourceIDDetails sharedEvidenceSourceTypeAndSourceIDDetails = processEvidenceHelper.getSharingSourceTypeAndSourceID(
      evidenceDescriptorDtls);

    // Find any shared evidence configurations for this piece of evidence.
    SharedSourceEvidenceAndStatusKey key = new SharedSourceEvidenceAndStatusKey();

    key.sourceID = sharedEvidenceSourceTypeAndSourceIDDetails.sourceID;
    key.sourceType = sharedEvidenceSourceTypeAndSourceIDDetails.sourceType;
    key.sourceEvidenceType = evidenceDescriptorDtls.evidenceType;
    key.recordStatus = RECORDSTATUS.NORMAL;

    EvidenceBrokerConfigDtlsList sharedEvidenceConfigDtlsList = EvidenceBrokerConfigAdminFactory.newInstance().listSharedTargetEvidences(
      key);

    // If evidence sharing id configured for the original evidence record,
    // then
    // process the evidence to share.
    if (!sharedEvidenceConfigDtlsList.dtls.isEmpty()) {
      processEvidence(evidenceDescriptorDtls, sharedEvidenceConfigDtlsList,
        considerAutoAcceptance, considerAutoActivation);
    }
  }

  // END, SR

  /**
   * {@inheritDoc}
   */
  public void shareEvidenceRemoval(
    final EvidenceDescriptorKey evidenceDescriptorKey)
    throws AppException, InformationalException {
    EvidenceDescriptorDtls evidenceDescriptorDtls = EvidenceDescriptorFactory.newInstance().read(
      evidenceDescriptorKey);

    Boolean params[] = EvidenceBrokerUtils.getCachedEvidenceBrokerParams();
    
    Boolean considerAutoAcceptance = params[0];    
    Boolean considerAutoActivation = params[1];
        
    // Retrieve the source type and source ID for the originating case.
    SharedEvidenceSourceTypeAndSourceIDDetails sharedEvidenceSourceTypeAndSourceIDDetails = processEvidenceHelper.getSharingSourceTypeAndSourceID(
      evidenceDescriptorDtls);

    // Find any shared evidence configurations for this piece of evidence.
    SharedSourceEvidenceAndStatusKey key = new SharedSourceEvidenceAndStatusKey();

    key.sourceID = sharedEvidenceSourceTypeAndSourceIDDetails.sourceID;
    key.sourceType = sharedEvidenceSourceTypeAndSourceIDDetails.sourceType;
    key.sourceEvidenceType = evidenceDescriptorDtls.evidenceType;
    key.recordStatus = RECORDSTATUS.NORMAL;

    EvidenceBrokerConfigDtlsList sharedEvidenceConfigDtlsList = EvidenceBrokerConfigAdminFactory.newInstance().listSharedTargetEvidences(
      key);

    // Is sharing configured for the original evidence record?
    if (!sharedEvidenceConfigDtlsList.dtls.isEmpty()) {
      processEvidenceForRemoval(evidenceDescriptorDtls,
        sharedEvidenceConfigDtlsList, considerAutoAcceptance,
        considerAutoActivation);
    }
  }
  
  /**
   * {@inheritDoc}
   */
  public void shareEvidenceForCaseParticipantCreation(
    final CaseParticipantRoleKey caseParticipantRoleKey)
    throws AppException, InformationalException {
    CaseParticipantRoleDtls caseParticipantRoleDtls = CaseParticipantRoleFactory.newInstance().read(
      caseParticipantRoleKey);

    Boolean params[] = EvidenceBrokerUtils.getCachedEvidenceBrokerParams();
    
    Boolean considerAutoAcceptance = params[0];    
    Boolean considerAutoActivation = params[1];    
    
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseParticipantRoleDtls.caseID;
    CaseHeaderDtls caseHeaderDtls = CaseHeaderFactory.newInstance().read(
      caseHeaderKey);

    // Retrieve the target type and target ID for the new case.
    SharedEvidenceSourceTypeAndSourceIDDetails sharedEvidenceTypeAndIDDetails = processEvidenceHelper.getSharingTargetTypeAndTargetID(
      caseHeaderDtls);

    // BEGIN, CR00349226, GYH
    // Find any shared evidence configurations relevant to our target case.
    SharedTargetEvidenceAndStatusKey sharedTargetEvidenceAndStatusKey = new SharedTargetEvidenceAndStatusKey();

    sharedTargetEvidenceAndStatusKey.targetID = sharedEvidenceTypeAndIDDetails.sourceID;
    sharedTargetEvidenceAndStatusKey.targetType = sharedEvidenceTypeAndIDDetails.sourceType;
    sharedTargetEvidenceAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
    EvidenceBrokerConfigDtlsList sharedEvidenceConfigDtlsList = EvidenceBrokerConfigAdminFactory.newInstance().listSharedSourceEvidences(
      sharedTargetEvidenceAndStatusKey);

    // END, CR00349226

    // If evidence sharing is configured for the new case, then process the
    // evidence to be shared of the case participant.
    if (!sharedEvidenceConfigDtlsList.dtls.isEmpty()) {
      processEvidenceForCaseParticipantCreation(sharedEvidenceConfigDtlsList,
        caseHeaderDtls, caseParticipantRoleDtls, considerAutoAcceptance,
        considerAutoActivation);
    }
  }

  /**
   * Processes the given list of evidence broker configurations into separate
   * lists of identical and non identical configurations. It then finds all
   * cases that the given evidence must be shared with and then shares this
   * evidence with the relevant cases for each identical and non identical
   * evidence broker configuration.
   *
   * @param evidenceDescriptorDtls
   * Contains evidence descriptor details for the piece of evidence
   * to be shared.
   * @param fullEvidenceBrokerConfigDtlsList
   * Contains the list of evidence broker configurations that are
   * applicable to this piece of evidence.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void processEvidenceWithAutoAcceptOnly(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EvidenceBrokerConfigDtlsList fullEvidenceBrokerConfigDtlsList)
    throws AppException, InformationalException {
    processEvidence(evidenceDescriptorDtls, fullEvidenceBrokerConfigDtlsList,
      Boolean.TRUE, Boolean.FALSE);
  }

  /**
   * Processes the given list of evidence broker configurations into separate
   * lists of identical and non identical configurations. It then finds all
   * cases that the given evidence must be shared with and then shares this
   * evidence with the relevant cases for each identical and non identical
   * evidence broker configuration.
   *
   * @param evidenceDescriptorDtls
   * Contains evidence descriptor details for the piece of evidence
   * to be shared.
   * @param fullEvidenceBrokerConfigDtlsList
   * Contains the list of evidence broker configurations that are
   * applicable to this piece of evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processEvidence(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EvidenceBrokerConfigDtlsList fullEvidenceBrokerConfigDtlsList)
    throws AppException, InformationalException {
    processEvidence(evidenceDescriptorDtls, fullEvidenceBrokerConfigDtlsList,
      Boolean.TRUE, Boolean.TRUE);
  }

  // BEGIN, CR00379320, SR
  /**
   * Processes the given list of evidence broker configurations into separate
   * lists of identical and non identical configurations. It then finds all
   * cases that the given evidence must be shared with and then shares this
   * evidence with the relevant cases for each identical and non identical
   * evidence broker configuration.
   *
   * @param evidenceDescriptorDtls
   * Contains evidence descriptor details for the piece of evidence
   * to be shared.
   * @param fullEvidenceBrokerConfigDtlsList
   * Contains the list of evidence broker configurations that are
   * applicable to this piece of evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processEvidence(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EvidenceBrokerConfigDtlsList fullEvidenceBrokerConfigDtlsList,
    Boolean considerAutoAcceptance, Boolean considerAutoActivation)
    throws AppException, InformationalException {
    EvidenceBrokerConfigDtlsList identicalEvidenceBrokerConfigList = new EvidenceBrokerConfigDtlsList();
    EvidenceBrokerConfigDtlsList nonIdenticalEvidenceBrokerConfigList = new EvidenceBrokerConfigDtlsList();

    int fullEvidenceBrokerConfigDtlsListSize = fullEvidenceBrokerConfigDtlsList.dtls.size();
    EvidenceBrokerConfigDtlsList externalConfigDtlsList = new EvidenceBrokerConfigDtlsList();

    for (int i = fullEvidenceBrokerConfigDtlsListSize; i > 0; i--) {

      if (fullEvidenceBrokerConfigDtlsList.dtls.item(i - 1).externalSystem != 0) {
        externalConfigDtlsList.dtls.addRef(
          fullEvidenceBrokerConfigDtlsList.dtls.item(i - 1));

        fullEvidenceBrokerConfigDtlsList.dtls.remove(i - 1);

      }
    }
    // If the evidence sharing is for remote case, it invokes the web
    // service
    // outbound process.
    if (externalConfigDtlsList.dtls.size() > 0) {
      sendSharedEvidence(externalConfigDtlsList, evidenceDescriptorDtls,
        OPERATIONNAME.CREATE);

    }

    // Sort the evidence broker configurations into identical and non
    // identical
    // evidence broker configurations.
    processEvidenceHelper.sortEvidenceBrokerConfiguration(
      fullEvidenceBrokerConfigDtlsList, identicalEvidenceBrokerConfigList,
      nonIdenticalEvidenceBrokerConfigList);

    // Get a list of cases that we must share this evidence with
    CaseHeaderDtlsList targetCaseHeaderList = processEvidenceHelper.getCasesForEvidenceActivation(
      evidenceDescriptorDtls);

    if (!targetCaseHeaderList.dtls.isEmpty()) {

      // Process the list of identical evidence sharing configurations
      if (!identicalEvidenceBrokerConfigList.dtls.isEmpty()) {
        processEvidenceForIdenticalSharing(identicalEvidenceBrokerConfigList,
          evidenceDescriptorDtls, targetCaseHeaderList, considerAutoAcceptance,
          considerAutoActivation);
      }

      // Process the list of non identical evidence sharing configurations
      if (!nonIdenticalEvidenceBrokerConfigList.dtls.isEmpty()) {
        processEvidenceForNonIdenticalSharing(
          nonIdenticalEvidenceBrokerConfigList, evidenceDescriptorDtls,
          targetCaseHeaderList);

      }
    }
  }

  /**
   * Processes evidence which is configured for identical sharing. It
   * determines which of the given list of cases the evidence should be shared
   * with and then puts the new evidence on those cases. A task will be sent
   * to the relevant case owners informing them that evidence has been shared
   * with their case.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the relevant evidence broker configuration
   * information for this piece of evidence.
   * @param evidenceDescriptorDtls
   * Contains evidence descriptor details for the evidence to be
   * shared.
   * @param caseHeaderDtlsList
   * Contains the list of cases with which this evidence could be
   * shared.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processEvidenceForIdenticalSharingWithAutoAcceptOnly(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final CaseHeaderDtlsList caseHeaderDtlsList) throws AppException,
      InformationalException {

    processEvidenceForIdenticalSharing(evidenceBrokerConfigDtlsList,
      evidenceDescriptorDtls, caseHeaderDtlsList, Boolean.TRUE, Boolean.FALSE);
  }

  /**
   * Processes evidence which is configured for identical sharing. It
   * determines which of the given list of cases the evidence should be shared
   * with and then puts the new evidence on those cases. A task will be sent
   * to the relevant case owners informing them that evidence has been shared
   * with their case.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the relevant evidence broker configuration
   * information for this piece of evidence.
   * @param evidenceDescriptorDtls
   * Contains evidence descriptor details for the evidence to be
   * shared.
   * @param caseHeaderDtlsList
   * Contains the list of cases with which this evidence could be
   * shared.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processEvidenceForIdenticalSharing(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final CaseHeaderDtlsList caseHeaderDtlsList) throws AppException,
      InformationalException {

    processEvidenceForIdenticalSharing(evidenceBrokerConfigDtlsList,
      evidenceDescriptorDtls, caseHeaderDtlsList, Boolean.TRUE, Boolean.TRUE);
  }

  /**
   * Processes evidence which is configured for identical sharing. It
   * determines which of the given list of cases the evidence should be shared
   * with and then puts the new evidence on those cases. A task will be sent
   * to the relevant case owners informing them that evidence has been shared
   * with their case.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the relevant evidence broker configuration
   * information for this piece of evidence.
   * @param evidenceDescriptorDtls
   * Contains evidence descriptor details for the evidence to be
   * shared.
   * @param caseHeaderDtlsList
   * Contains the list of cases with which this evidence could be
   * shared.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processEvidenceForIdenticalSharing(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final CaseHeaderDtlsList caseHeaderDtlsList,
    Boolean considerAutoAcceptance, Boolean considerAutoActivation)
    throws AppException, InformationalException {
    CaseHeaderDtlsList identicalCaseHeaderDtlsList = new CaseHeaderDtlsList();

    identicalCaseHeaderDtlsList.assign(caseHeaderDtlsList);

    // Filter the list of target cases. Any cases which are not applicable
    // to
    // our list of identical evidence broker configurations will be removed.
    processEvidenceHelper.filterTargetCaseList(evidenceBrokerConfigDtlsList,
      identicalCaseHeaderDtlsList);

    // BEGIN, CR00377908, RPB
    // Check if the source evidence which is intended to be shared is there
    // in the obtained
    // list of identical evidence broker configurations.
    boolean isConfigurationPresentForSourceEvidence = checkConfigurationWithSourceEvidenceDescriptor(
      evidenceBrokerConfigDtlsList, evidenceDescriptorDtls);

    // The evidence being shared should be marked as 'Identical In-Edit'
    evidenceDescriptorDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
    if (isConfigurationPresentForSourceEvidence) {
      // END, CR00377908
      for (CaseHeaderDtls identicalCaseHeaderDtls : identicalCaseHeaderDtlsList.dtls.items()) {

        // Don't re-send unchanged evidence back to the case from which
        // it was first shared. So skip such record from processing.
        // BEGIN, CR00379197, SSK
        if (identicalCaseHeaderDtls.caseID
          != evidenceDescriptorDtls.sourceCaseID
            || !evidenceDescriptorDtls.sharedUnchangedInd
            || evidenceDescriptorDtls.pendingRemovalInd) {
          // END, CR00379197     
          processEvidenceHelper.processIdenticalEvidenceSharingForCase(
            evidenceDescriptorDtls, identicalCaseHeaderDtls,
            considerAutoAcceptance, considerAutoActivation);
        }
      }
    }
  }

  // END, SR
  /**
   * Processes evidence which is configured for non identical sharing. It
   * determines which of the given list of cases the evidence could be
   * relevant to and then sends a notification to each case owner informing
   * them that evidence relevant to their case has been modified and should be
   * examined.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the relevant evidence broker configuration
   * information for this piece of evidence.
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor details for the evidence to
   * be shared.
   * @param caseHeaderDtlsList
   * Contains the list of cases with which this evidence could be
   * shared.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processEvidenceForNonIdenticalSharing(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final CaseHeaderDtlsList caseHeaderDtlsList) throws AppException,
      InformationalException {

    CaseHeaderDtlsList nonIdenticalCaseHeaderDtlsList = new CaseHeaderDtlsList();

    nonIdenticalCaseHeaderDtlsList.assign(caseHeaderDtlsList);

    // Filter the list of target cases. Any cases which are not applicable
    // to
    // our list of non identical evidence sharing configurations will be
    // removed
    processEvidenceHelper.filterTargetCaseList(evidenceBrokerConfigDtlsList,
      nonIdenticalCaseHeaderDtlsList);

    // The evidence being shared should be marked as 'Non Identical In-Edit'
    evidenceDescriptorDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;
    for (CaseHeaderDtls nonIdenticalCaseHeaderDtls : nonIdenticalCaseHeaderDtlsList.dtls.items()) {

      processEvidenceHelper.processNonIdenticalEvidenceSharingForCase(
        evidenceDescriptorDtls, nonIdenticalCaseHeaderDtls);
    }
  }

  /**
   * Sorts the given list of evidence broker configurations into separate
   * lists of identical and non identical configurations. It then finds all
   * cases that the given evidence must be shared with and then shares this
   * evidence with the relevant cases for each identical and non identical
   * evidence broker configuration.
   *
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor details for the piece of
   * evidence to be shared.
   * @param fullEvidenceBrokerConfigDtlsList
   * Contains the list of evidence broker configurations that are
   * applicable to this piece of evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processEvidenceForRemoval(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EvidenceBrokerConfigDtlsList fullEvidenceBrokerConfigDtlsList)
    throws AppException, InformationalException {
    
    processEvidenceForRemoval(evidenceDescriptorDtls,
      fullEvidenceBrokerConfigDtlsList, Boolean.TRUE, Boolean.TRUE);
  }

  public void processEvidenceForRemoval(
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    final EvidenceBrokerConfigDtlsList fullEvidenceBrokerConfigDtlsList,
    Boolean considerAutoAcceptance, Boolean considerAutoActivation)
    throws AppException, InformationalException {

    EvidenceBrokerConfigDtlsList identicalEvidenceBrokerConfigList = new EvidenceBrokerConfigDtlsList();
    EvidenceBrokerConfigDtlsList nonIdenticalEvidenceBrokerConfigList = new EvidenceBrokerConfigDtlsList();
    // BEGIN, CR00206415, PB.
    int fullEvidenceBrokerConfigDtlsListSize = fullEvidenceBrokerConfigDtlsList.dtls.size();
    EvidenceBrokerConfigDtlsList externalConfigDtlsList = new EvidenceBrokerConfigDtlsList();

    for (int i = fullEvidenceBrokerConfigDtlsListSize; i > 0; i--) {

      if (fullEvidenceBrokerConfigDtlsList.dtls.item(i - 1).externalSystem != 0) {
        externalConfigDtlsList.dtls.addRef(
          fullEvidenceBrokerConfigDtlsList.dtls.item(i - 1));
        fullEvidenceBrokerConfigDtlsList.dtls.remove(i - 1);
      }
    }
    // If the evidence sharing is for remote case, it invokes the web
    // service
    // outbound process.
    if (externalConfigDtlsList.dtls.size() > 0) {
      sendSharedEvidence(externalConfigDtlsList, evidenceDescriptorDtls,
        OPERATIONNAME.REMOVE);
    } else {
      // END, CR00206415.
      processEvidenceHelper.sortEvidenceBrokerConfiguration(
        fullEvidenceBrokerConfigDtlsList, identicalEvidenceBrokerConfigList,
        nonIdenticalEvidenceBrokerConfigList);

      // Get a list of cases that we must share this evidence with
      CaseHeaderDtlsList targetCaseHeaderList = processEvidenceHelper.getCasesForEvidenceRemoval(
        evidenceDescriptorDtls);

      if (!targetCaseHeaderList.dtls.isEmpty()) {
        evidenceDescriptorDtls.pendingRemovalInd = true;
        evidenceDescriptorDtls.newInd = false;

        // Process the list of identical evidence broker configurations
        if (!identicalEvidenceBrokerConfigList.dtls.isEmpty()) {
          processEvidenceForIdenticalSharing(identicalEvidenceBrokerConfigList,
            evidenceDescriptorDtls, targetCaseHeaderList,
            considerAutoAcceptance, considerAutoActivation);
        }
        // Process the list of non identical broker sharing
        // configurations
        if (!nonIdenticalEvidenceBrokerConfigList.dtls.isEmpty()) {
          processEvidenceForNonIdenticalSharing(
            nonIdenticalEvidenceBrokerConfigList, evidenceDescriptorDtls,
            targetCaseHeaderList);
        }
      }
    }    
  }
  
  /**
   * Finds all pieces of evidence relevant to the new case participant that
   * must be shared and adds that evidence to the new case.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the full list of evidence broker configuration
   * information relevant to the new case.
   * @param caseHeaderDtls
   * Contains the new case with which evidence will be shared.
   * @param caseParticipantRoleDtls
   * Contains the case participant role who's evidence should be
   * examined.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processEvidenceForCaseParticipantCreation(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final CaseHeaderDtls caseHeaderDtls,
    final CaseParticipantRoleDtls caseParticipantRoleDtls)
    throws AppException, InformationalException {
    
    Boolean params[] = EvidenceBrokerUtils.getCachedEvidenceBrokerParams();
    
    Boolean considerAutoAcceptance = params[0];    
    Boolean considerAutoActivation = params[1];
    
    processEvidenceForCaseParticipantCreation(evidenceBrokerConfigDtlsList,
      caseHeaderDtls, caseParticipantRoleDtls, considerAutoAcceptance,
      considerAutoActivation);
  }  

  public void processEvidenceForCaseParticipantCreation(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final CaseHeaderDtls caseHeaderDtls,
    final CaseParticipantRoleDtls caseParticipantRoleDtls, 
    Boolean considerAutoAcceptance, Boolean considerAutoActivation)
    throws AppException, InformationalException {

    // BEGIN, CR00389115, RPB
    boolean autoActivateInd = false;
    // END, CR00389115

    // BEGIN, CR00398088, SSK
    boolean anyIncomingEvidences = false;
    boolean anyAutoAcceptedEvidences = false;
    // END, CR00398088
    
    // Find all the evidence that must be shared with the new case
    // BEGIN, CR00368925, GYH
    EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = new EvidenceDescriptorDtlsList();
    EvidenceDescriptorDtlsList sourceEvidenceDescriptorDtlsList = processEvidenceHelper.getSharedEvidenceForCaseParticipantCreation(
      evidenceBrokerConfigDtlsList, caseParticipantRoleDtls);

    // BEGIN, CR00377631, SSK
    for (final EvidenceDescriptorDtls evidenceDescriptorDtls : sourceEvidenceDescriptorDtlsList.dtls.items()) {
      // END, CR00377631
      SharedEvidenceSourceTypeAndSourceIDDetails sharedEvidenceSourceTypeAndSourceIDDetails = processEvidenceHelper.getSharingSourceTypeAndSourceID(
        evidenceDescriptorDtls);
      SharedSourceEvidenceAndStatusKey sharedSourceEvidenceAndStatusKey = new SharedSourceEvidenceAndStatusKey();

      sharedSourceEvidenceAndStatusKey.sourceID = sharedEvidenceSourceTypeAndSourceIDDetails.sourceID;
      sharedSourceEvidenceAndStatusKey.sourceType = sharedEvidenceSourceTypeAndSourceIDDetails.sourceType;
      sharedSourceEvidenceAndStatusKey.sourceEvidenceType = evidenceDescriptorDtls.evidenceType;
      if (isSourceEvidenceEnabledForSharing(sharedSourceEvidenceAndStatusKey)) {
        evidenceDescriptorDtlsList.dtls.add(evidenceDescriptorDtls);
      }
    }
    // END, CR00368925

    // Get target type and target ID
    SharedEvidenceSourceTypeAndSourceIDDetails targetTypeAndTargetID = processEvidenceHelper.getSharingTargetTypeAndTargetID(
      caseHeaderDtls);
    EvidenceDescriptorIDAndSynchronizeActionList evidenceIDAndActionList = new EvidenceDescriptorIDAndSynchronizeActionList();

    List<EvidenceDescriptorDtls> incomingEvidenceList = new ArrayList<EvidenceDescriptorDtls>();
    
    // BEGIN, CR00237356, GYH
    boolean isAutoAcceptNotSet = false;

    // BEGIN, CR00342079, GYH
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseHeaderDtls.caseID;

    EvidenceDescriptorKey evidenceDescriptorKey;
    final EvidenceDescriptorKeyList evidenceDescriptorKeyList = new EvidenceDescriptorKeyList();
   
    EvidenceBrokerFilters evidenceBrokerFilters = new EvidenceBrokerFilters();
    final EvidenceDescriptorDtlsList filteredEvidenceDescriptorDtlsList = evidenceBrokerFilters.sortParentChildEvidences(
      evidenceDescriptorDtlsList);

    // END, CR00342079
    
    // BEGIN, CR00426588, SS
    if (0 != evidenceDescriptorDtlsList.dtls.size()) {
      TransactionInfo.setFacadeScopeObject(
        EVIDENCEBROKER.BULKEVIDENCEACTIVATED.toString(),
        EvidenceBrokerConst.gkNonIdenticalSharing);
    }
    // END, CR00426588
    
    for (EvidenceDescriptorDtls evidenceDescriptorDtls : filteredEvidenceDescriptorDtlsList.dtls.items()) {

      // All shared evidence pulled onto a case should be marked as new
      evidenceDescriptorDtls.newInd = true;

      // BEGIN, CR00349439, VR
      String targetEvidenceType = processEvidenceHelper.getTargetEvidenceByBrokerConfig(
        evidenceBrokerConfigDtlsList, evidenceDescriptorDtls);

      // Read evidence broker configuration to determine if the record
      // has AutoApply set
      EvidenceSharingConfigKey key = new EvidenceSharingConfigKey();

      EvidenceDescriptorDtls sharedDescriptorDtls;

      if (isSameSourceAndTargetType(evidenceDescriptorDtls.evidenceType,
        targetEvidenceType)) {
        evidenceDescriptorDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
        sharedDescriptorDtls = processEvidenceHelper.broadcastEvidence(
          evidenceDescriptorDtls, caseHeaderDtls);
        key.sharedType = EVIDENCESHARINGTYPE.IDENTICAL;

      } else {
        evidenceDescriptorDtls.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;
        sharedDescriptorDtls = processEvidenceHelper.processNonIdenticalEvidenceSharingForCase(
          evidenceDescriptorDtls, caseHeaderDtls);
        key.sharedType = EVIDENCESHARINGTYPE.NONIDENTICAL;
      }
      
      // BEGIN,
      if (null != evidenceDescriptorDtls) {

        // Get source type and source ID
        SharedEvidenceSourceTypeAndSourceIDDetails sourceTypeAndSourceID = processEvidenceHelper.getSharingSourceTypeAndSourceID(
          evidenceDescriptorDtls);

        key.recordStatus = RECORDSTATUS.NORMAL;

        key.sourceEvidenceType = evidenceDescriptorDtls.evidenceType;
        key.sourceID = sourceTypeAndSourceID.sourceID;
        key.sourceType = sourceTypeAndSourceID.sourceType;
        key.targetID = targetTypeAndTargetID.sourceID;
        key.targetType = targetTypeAndTargetID.sourceType;
        key.targetEvidenceType = targetEvidenceType;
        // END, CR00349439
        EvidenceBrokerConfigDtlsList evidenceBrokerConfigList = EvidenceBrokerConfigAdminFactory.newInstance().listSharedSourceAndTargetEvidences(
          key);

        // BEGIN, CR00426922, KRK
        // BEGIN, CR00429088, AKr
        if (null != evidenceDescriptorDtls && null != sharedDescriptorDtls) {
          createSourceVerificationItemProvidedDetails(evidenceDescriptorDtls,
            sharedDescriptorDtls, evidenceBrokerConfigList);
        }          
        // END, CR00429088
        // END, CR00426922
        
        // If we find the corresponding configuration and auto accept is
        // set
        if (!evidenceBrokerConfigList.dtls.isEmpty()) {
          if (evidenceBrokerConfigList.dtls.item(0).autoAcceptInd) {

            anyAutoAcceptedEvidences = true;
            // BEGIN, CR00378374, SSK
            if (null != sharedDescriptorDtls) {
              // END, CR00378374
              // Add the target evidence to the auto accept list
              EvidenceDescriptorIDAndSynchronizeAction evidenceIDAndAction = new EvidenceDescriptorIDAndSynchronizeAction();

              evidenceIDAndAction.action = SYNCHRONIZATIONACTION.ACCEPT;
              evidenceIDAndAction.evidenceDescriptorID = sharedDescriptorDtls.evidenceDescriptorID;
              evidenceIDAndActionList.dtlsList.addRef(evidenceIDAndAction);

              // BEGIN, CR00342079, GYH
              if (evidenceBrokerConfigList.dtls.item(0).autoActivateInd) {
                evidenceDescriptorKey = new EvidenceDescriptorKey();
                evidenceDescriptorKey.evidenceDescriptorID = sharedDescriptorDtls.evidenceDescriptorID;
                evidenceDescriptorKeyList.dtls.add(evidenceDescriptorKey);
              }
            }
            // END, CR00342079

          } else {
            isAutoAcceptNotSet = true;
            // BEGIN, CR00398088, SSK
            anyIncomingEvidences = true;
            // BEGIN, CR00399032, SSK
            incomingEvidenceList.add(sharedDescriptorDtls);
            // END, CR00399032
            // END, CR00398088
          }
        } else {
          // If we could not find identical evidence broker
          // configuration
          // for the
          // given evidence descriptor then evidence descriptor could
          // be
          // for
          // non-identical evidence sharing. So check if there are any
          // non-identical evidence sharing have auto accepted using
          // custom
          // implementation.
          if (!processEvidenceHelper.isNonIdenticalEvidenceAutoAccepted(
            evidenceDescriptorDtls, caseHeaderDtls)) {
            isAutoAcceptNotSet = true;
          }
        }
      }
    }

    // Automatically accept any necessary evidence on the target case
    if (!evidenceIDAndActionList.dtlsList.isEmpty()) {
      if (considerAutoAcceptance) {
        processEvidenceHelper.autoAcceptEvidenceOnTargetCase(
          evidenceIDAndActionList);
      }
    }

    // BEGIN, CR00342079, GYH
    // BEGIN, CR00343048, GYH
    // Automatically activate the evidence on the target case
    if (!evidenceDescriptorKeyList.dtls.isEmpty()) {
      final EvidenceDescriptorKeyList successfullyAutoAcceptedEvidences = new EvidenceDescriptorKeyList();   
      EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

      for (final EvidenceDescriptorKey descriptorKey : evidenceDescriptorKeyList.dtls.items()) {
        if (EVIDENCEDESCRIPTORSTATUSEntry.INEDIT.getCode().equals(
          evidenceDescriptorObj.read(descriptorKey).statusCode)) {
          successfullyAutoAcceptedEvidences.dtls.add(descriptorKey);
        }
      }
      if (!successfullyAutoAcceptedEvidences.dtls.isEmpty()) {
        if (considerAutoActivation) {
          processEvidenceHelper.autoActivateEvidenceOnTargetCase(caseKey,
            evidenceDescriptorKeyList);
          // BEGIN, CR00389115, SSK
          autoActivateInd = true;
          // END, CR00389115

        }
      }
    }
    // END, CR00343048
    // END, CR00342079

    // If there is any record with 'autoAcceptInd' set to false then we need
    // to create a task to handle the evidences.
    // BEGIN, CR00389115, SSK
    final CaseKey caseKeyStruct = new CaseKey();

    caseKeyStruct.caseID = caseHeaderDtls.caseID;
    final CaseTypeCode caseTypeCode = CachedCaseHeaderFactory.newInstance().readCaseTypeCode(
      caseKeyStruct);
    boolean isTargetCasePDCInd = caseTypeCode.caseTypeCode.equals(
      CASETYPECODE.PARTICIPANTDATACASE);

    // BEGIN, CR00398088, SSK
    if (anyAutoAcceptedEvidences
      && evidenceBrokerTaskGenerationStrategy.determineTaskGenerationForIdenticalEvdSharing(
        isTargetCasePDCInd, autoActivateInd)) {
      processEvidenceHelper.createCaseParticipantCreationSynchronizationInEditTask(
        caseHeaderDtls);
    }
    
    // BEGIN, CR00426588, SS
    boolean nonIdenticalIncomingEvidences = false;

    // END, CR00426588

    // BEGIN, CR00399032, SSK
    if (anyIncomingEvidences) {
      anyIncomingEvidences = checkIfAnyIdenticalEvidenceBrokered(
        incomingEvidenceList);
      // BEGIN, CR00426588, SS
      nonIdenticalIncomingEvidences = checkIfAnyNonIdenticalEvidenceBrokered(
        incomingEvidenceList);
      // END, CR00426588
    }
    // END, CR00399032    
    if (anyIncomingEvidences
      && evidenceBrokerTaskGenerationStrategy.determineTaskGenerationForIdenticalEvdSharing(
        isTargetCasePDCInd, autoActivateInd)) {
      // END, CR00389115
      processEvidenceHelper.createCaseParticipantCreationSynchronizationTask(
        caseHeaderDtls);
    }
    // BEGIN, CR00426588, SS
    if (nonIdenticalIncomingEvidences && !isTargetCasePDCInd) {
      processEvidenceHelper.createCaseParticipantCreationSynchronizationTask(
        caseHeaderDtls);
    }
    // END, CR00426588
    // END, CR00398088
    // END, CR00237356
  }
  
  // BEGIN, CR00427012, KRK
  /**
   * Inserts the source verification item provided details into the SharedVERItemProvided table.
   *
   * @param evidenceDescriptorDtls
   * Source evidence descriptor details
   *
   * @param targetevidenceDescriptorDtls Target evidence descriptor details
   *
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  protected void createSourceVerificationItemProvidedDetails(
    final EvidenceDescriptorDtls sourceevidenceDescriptorDtls,
    final EvidenceDescriptorDtls targetSharedDescriptorDtls, EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList) throws AppException, InformationalException {
        
    final SharedVERItemProvided sharedVItemProvidedObj = SharedVERItemProvidedFactory.newInstance();
    final VerificationItemProvided verificationItemProvidedObj = VerificationItemProvidedFactory.newInstance();
    final VDIEDLink vDIEDLinkObj = VDIEDLinkFactory.newInstance();
    
    final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = sourceevidenceDescriptorDtls.evidenceDescriptorID;   

    final VDIEDLinkAndDataItemIDDetailsList vdiedLinkAndDataItemIDDetailsList = vDIEDLinkObj.readByEvidenceDescriptor(
      evidenceDescriptorKey);

    for (final VDIEDLinkAndDataItemIDDetails vdiedLinkAndDataItemIDDetails : vdiedLinkAndDataItemIDDetailsList.dtls.items()) {       

      VDIEDLinkIDAndStatusKey vdiedLinkIDAndStatusKey = new VDIEDLinkIDAndStatusKey();

      vdiedLinkIDAndStatusKey.recordStatus = RECORDSTATUSEntry.NORMAL.getCode();             
      vdiedLinkIDAndStatusKey.VDIEDLinkID = vdiedLinkAndDataItemIDDetails.vdIEDLinkID;
      
      VerificationItemProvidedDtlsList verificationItemProvidedDtlsList = verificationItemProvidedObj.searchByVDIEDLinkIDAndStatus(
        vdiedLinkIDAndStatusKey);

      for (final VerificationItemProvidedDtls verificationItemProvidedDtls : verificationItemProvidedDtlsList.dtls.items()) {

        SharedVERItemProvidedDtls postponedVItemProvidedDtls = new SharedVERItemProvidedDtls();
        
        postponedVItemProvidedDtls.assign(verificationItemProvidedDtls);
        postponedVItemProvidedDtls.sourceVDIEDLinkID = verificationItemProvidedDtls.VDIEDLinkID;
        postponedVItemProvidedDtls.targetEvidenceDescriptorID = targetSharedDescriptorDtls.evidenceDescriptorID;
        
        if (!evidenceBrokerConfigDtlsList.dtls.isEmpty()
          && 1 == evidenceBrokerConfigDtlsList.dtls.size()) {
          
          postponedVItemProvidedDtls.shareVerificationsOption = evidenceBrokerConfigDtlsList.dtls.item(0).shareVerificationsOption;
        }
        sharedVItemProvidedObj.insert(postponedVItemProvidedDtls);       
      }
    }    
  }

  // END, CR00427012

  // BEGIN, CR00399032, SSK 
  /**
   * Checks if the incoming list contains any identical evidence.
   *
   * @param incomingEvidenceList
   * Contains list of incoming evidences.
   *
   * @return true if the incoming list contains any identical evidences.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected boolean checkIfAnyIdenticalEvidenceBrokered(final List<EvidenceDescriptorDtls> incomingEvidenceList) throws AppException, InformationalException {
    boolean validIncomingEvidenceExists = false;
    EvidenceDescriptorKey evidenceDescriptorKey;

    for (final EvidenceDescriptorDtls evidenceDescriptorDtls : incomingEvidenceList) {
      if (evidenceDescriptorDtls != null) {
        evidenceDescriptorKey = new EvidenceDescriptorKey();
        evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;
        if (EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT.equals(
          evidenceDescriptorDtls.statusCode)) {
          validIncomingEvidenceExists = true;
          break;
        }
      }
    }
    return validIncomingEvidenceExists;
  }

  // END, CR00399032
  
  // BEGIN, CR00426588, SS
  /**
   * Checks if the incoming list contains any non identical evidence.
   *
   * @param incomingEvidenceList
   * Contains list of incoming evidences.
   *
   * @return true if the incoming list contains any non identical evidences or else false.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected boolean checkIfAnyNonIdenticalEvidenceBrokered(final List<EvidenceDescriptorDtls> incomingEvidenceList) throws AppException, InformationalException {
    boolean validIncomingEvidenceExists = false;
    EvidenceDescriptorKey evidenceDescriptorKey;

    for (final EvidenceDescriptorDtls evidenceDescriptorDtls : incomingEvidenceList) {
      if (null != evidenceDescriptorDtls) {
        evidenceDescriptorKey = new EvidenceDescriptorKey();
        evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDtls.evidenceDescriptorID;
        if (EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT.equals(
          evidenceDescriptorDtls.statusCode)) {
          validIncomingEvidenceExists = true;
          break;
        }
      }
    }
    return validIncomingEvidenceExists;
  }

  // END, CR00426588

  // BEGIN, CR00206415, PB.
  /**
   * Determines whether a given piece of evidence received from a remote
   * system is configured for evidence sharing, if configured, then shares the
   * evidence with the relevant cases.
   *
   * @param sharedEvidenceDescriptorDetails
   * Contains evidence details received from a remote system to be
   * shared.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void shareExternalEvidence(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails)
    throws AppException, InformationalException {
    EvidenceDescriptorDtls evidenceDescriptorDtls = new EvidenceDescriptorDtls();

    Boolean params[] = EvidenceBrokerUtils.getCachedEvidenceBrokerParams();
    
    Boolean considerAutoAcceptance = params[0];    
    Boolean considerAutoActivation = params[1];

    evidenceDescriptorDtls.caseID = sharedEvidenceDescriptorDetails.details.caseID;

    // Getting the applicable list of evidence broker config details.
    SharedSourceEvidenceAndStatusKey key = new SharedSourceEvidenceAndStatusKey();

    key.sourceID = sharedEvidenceDescriptorDetails.sourceID;
    key.sourceType = sharedEvidenceDescriptorDetails.sourceType;
    key.sourceEvidenceType = sharedEvidenceDescriptorDetails.details.evidenceType;
    key.sourceSystemID = sharedEvidenceDescriptorDetails.sourceSystemID;
    key.recordStatus = RECORDSTATUS.NORMAL;

    EvidenceBrokerConfigDtlsList sharedEvidenceConfigDtlsList = EvidenceBrokerConfigAdminFactory.newInstance().listSharedTargetEvidences(
      key);

    // Get the target case and the type of sharing
    if (!sharedEvidenceConfigDtlsList.dtls.isEmpty()) {
      processExternalEvidence(sharedEvidenceDescriptorDetails,
        sharedEvidenceConfigDtlsList, considerAutoAcceptance,
        considerAutoActivation);
    }
  }

  /**
   * Send the evidence details to be shared to the target system in the form
   * of an XML document.
   *
   * @param sharedEvidenceConfigDtlsList
   * Contains the list of evidence broker configurations that are
   * applicable to the piece of evidence to be shared.
   * @param evidenceDescriptorDtls
   * Contains the evidence descriptor details for the piece of
   * evidence to be shared.
   * @param operationName
   * Contains the operation name whether to add a new record or
   * remove an existing record.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void sendSharedEvidence(
    EvidenceBrokerConfigDtlsList sharedEvidenceConfigDtlsList,
    final EvidenceDescriptorDtls evidenceDescriptorDtls,
    String operationName) throws AppException, InformationalException {
    Document sharingDocument = null;
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = evidenceDescriptorDtls.caseID;
    CaseHeaderDtls caseHeaderDtls = CaseHeaderFactory.newInstance().read(
      caseHeaderKey);
    CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
      caseHeaderDtls.caseTypeCode);

    if (null == caseTypeEvidence) {
      AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME,
        caseHeaderDtls.caseTypeCode, TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 32);

    }
    CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseHeaderDtls.caseID;
    String caseSubType = caseTypeEvidence.getCaseTypeCode(caseKey);

    // Reading the concern role details for creating the document.
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // Creating the outbound document.
    sharingDocument = createDocument(evidenceDescriptorDtls, caseHeaderDtls,
      concernRoleDtls, sharingDocument, operationName, caseSubType);

    for (EvidenceBrokerConfigDtls evidenceBrokerConfigDtls : sharedEvidenceConfigDtlsList.dtls.items()) {

      // Determines if the evidence update needs to be sent to the remote
      // system.
      // BEGIN, CR00217066, PB.
      try {
        notifyChange(sharingDocument, evidenceBrokerConfigDtls.externalSystem);
      } catch (Exception e) {
        AppException appException = new AppException(
          BPOEVIDENCEBROKER.ERR_EVIDENCE_BROKER_NOTIFY_CHANGE);

        throw appException;
        // END, CR00217066
      }
    }
  }

  /**
   * Processes the given list of evidence broker configurations received from
   * a remote system into separate lists of identical and non identical
   * configurations. It then finds all cases that the given evidence must be
   * shared with and then shares this evidence with the relevant cases for
   * each identical and non identical evidence broker configuration.
   *
   * @param sharedEvidenceDescriptorDetails
   * Contains the evidence details for the piece of evidence to be
   * shared.
   * @param fullEvidenceBrokerConfigDtlsList
   * Contains the list of evidence broker configurations that are
   * applicable to this piece of evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void processExternalEvidence(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails,
    final EvidenceBrokerConfigDtlsList fullEvidenceBrokerConfigDtlsList)
    throws AppException, InformationalException {
    
    processExternalEvidence(sharedEvidenceDescriptorDetails,
      fullEvidenceBrokerConfigDtlsList, Boolean.TRUE, Boolean.TRUE);
  }

  /**
   * Processes the given list of evidence broker configurations received from
   * a remote system into separate lists of identical and non identical
   * configurations. It then finds all cases that the given evidence must be
   * shared with and then shares this evidence with the relevant cases for
   * each identical and non identical evidence broker configuration.
   *
   * @param sharedEvidenceDescriptorDetails
   * Contains the evidence details for the piece of evidence to be
   * shared.
   * @param fullEvidenceBrokerConfigDtlsList
   * Contains the list of evidence broker configurations that are
   * applicable to this piece of evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void processExternalEvidence(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails,
    final EvidenceBrokerConfigDtlsList fullEvidenceBrokerConfigDtlsList,
    Boolean considerAutoAcceptance, Boolean considerAutoActivation)
    throws AppException, InformationalException {
    EvidenceBrokerConfigDtlsList identicalEvidenceBrokerConfigList = new EvidenceBrokerConfigDtlsList();
    EvidenceBrokerConfigDtlsList nonIdenticalEvidenceBrokerConfigList = new EvidenceBrokerConfigDtlsList();

    // Sort the evidence broker configurations into identical and non
    // identical
    // evidence broker configurations.
    processEvidenceHelper.sortEvidenceBrokerConfiguration(
      fullEvidenceBrokerConfigDtlsList, identicalEvidenceBrokerConfigList,
      nonIdenticalEvidenceBrokerConfigList);

    // Get a list of cases that we must share this evidence with
    CaseHeaderDtlsList targetCaseHeaderList = processEvidenceHelper.getCasesForEvidenceActivation(
      sharedEvidenceDescriptorDetails.details);

    if (!targetCaseHeaderList.dtls.isEmpty()) {

      // Process the list of identical evidence sharing configurations
      if (!identicalEvidenceBrokerConfigList.dtls.isEmpty()) {
        processExternalEvidenceForIdenticalSharing(
          identicalEvidenceBrokerConfigList, sharedEvidenceDescriptorDetails,
          targetCaseHeaderList, considerAutoAcceptance, considerAutoActivation);
      }

      // Process the list of non identical evidence sharing configurations
      if (!nonIdenticalEvidenceBrokerConfigList.dtls.isEmpty()) {
        processExternalEvidenceForNonIdenticalSharing(
          nonIdenticalEvidenceBrokerConfigList, sharedEvidenceDescriptorDetails,
          targetCaseHeaderList);
      }
    }
  }  
  
  /**
   * Processes evidence received from a remote system, which is configured for
   * identical sharing. It determines which of the given list of cases the
   * evidence should be shared with and then puts the new evidence on those
   * cases. A task will be sent to the relevant case owners informing them
   * that evidence has been shared with their case.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the relevant evidence broker configuration
   * information for this piece of evidence.
   * @param sharedEvidenceDescriptorDetails
   * Contains evidence descriptor details for the evidence to be
   * shared.
   * @param caseHeaderDtlsList
   * Contains the list of cases with which this evidence could be
   * shared.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void processExternalEvidenceForIdenticalSharing(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails,
    final CaseHeaderDtlsList caseHeaderDtlsList) throws AppException,
      InformationalException {

    processExternalEvidenceForIdenticalSharing(evidenceBrokerConfigDtlsList,
      sharedEvidenceDescriptorDetails, caseHeaderDtlsList, Boolean.TRUE,
      Boolean.TRUE);
  }

  /**
   * Processes evidence received from a remote system, which is configured for
   * identical sharing. It determines which of the given list of cases the
   * evidence should be shared with and then puts the new evidence on those
   * cases. A task will be sent to the relevant case owners informing them
   * that evidence has been shared with their case.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the relevant evidence broker configuration
   * information for this piece of evidence.
   * @param sharedEvidenceDescriptorDetails
   * Contains evidence descriptor details for the evidence to be
   * shared.
   * @param caseHeaderDtlsList
   * Contains the list of cases with which this evidence could be
   * shared.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void processExternalEvidenceForIdenticalSharing(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails,
    final CaseHeaderDtlsList caseHeaderDtlsList,
    Boolean considerAutoAcceptance, Boolean considerAutoActivation) 
    throws AppException, InformationalException {

    CaseHeaderDtlsList identicalCaseHeaderDtlsList = new CaseHeaderDtlsList();

    identicalCaseHeaderDtlsList.assign(caseHeaderDtlsList);

    // Filter the list of target cases. Any cases which are not applicable
    // to
    // our list of identical evidence broker configurations will be removed.
    processEvidenceHelper.filterTargetCaseList(evidenceBrokerConfigDtlsList,
      identicalCaseHeaderDtlsList);

    // The evidence being shared should be marked as 'Identical In-Edit'
    sharedEvidenceDescriptorDetails.details.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;

    for (CaseHeaderDtls identicalCaseHeaderDtls : identicalCaseHeaderDtlsList.dtls.items()) {

      // Don't re-send unchanged evidence back to the case from which
      // it was first shared. So skip such record from processing.
      if (!sharedEvidenceDescriptorDetails.details.sharedUnchangedInd) {

        processEvidenceHelper.processExternalIdenticalEvidenceSharingForCase(
          sharedEvidenceDescriptorDetails, identicalCaseHeaderDtls, 
          considerAutoAcceptance, considerAutoActivation);
      }
    }
  }
  
  /**
   * Processes evidence received from a remote system, which is configured for
   * non identical sharing. It determines which of the given list of cases the
   * evidence could be relevant to and then sends a notification to each case
   * owner informing them that evidence relevant to their case has been
   * modified and should be examined.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains the relevant evidence broker configuration
   * information for this piece of evidence.
   * @param sharedEvidenceDescriptorDetails
   * Contains the evidence details received from a remote system to
   * be shared .
   * @param caseHeaderDtlsList
   * Contains the list of cases with which this evidence could be
   * shared.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processExternalEvidenceForNonIdenticalSharing(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails,
    final CaseHeaderDtlsList caseHeaderDtlsList) throws AppException,
      InformationalException {

    // Filter the list of target cases. Any cases which are not applicable
    // to
    // our list of non identical evidence sharing configurations will be
    // removed
    processEvidenceHelper.filterTargetCaseList(evidenceBrokerConfigDtlsList,
      caseHeaderDtlsList);

    // The evidence being shared should be marked as 'Non Identical In-Edit'
    sharedEvidenceDescriptorDetails.details.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;
    for (CaseHeaderDtls caseHeaderDtls : caseHeaderDtlsList.dtls.items()) {

      processEvidenceHelper.processExternalNonIdenticalEvidenceSharingForCase(
        sharedEvidenceDescriptorDetails, caseHeaderDtls);
    }
  }

  /**
   * Determines if the evidence update needs to be sent to the remote system.
   * If such a transmission is required , it creates the required data and
   * invokes the web service on the target system.
   *
   * @param targetSystem
   * Contains target system details.
   *
   * @param document
   * Contains evidence details.
   * @throws Exception
   * Generic Exception Signature.
   */
  protected void notifyChange(final Document document,
    final long targetSystemID) throws Exception {

    // BEGIN, CR00217066, PB.
    EvdBrokerWebServiceStub stub = new EvdBrokerWebServiceStub();
    final ServiceClient serviceClient = stub._getServiceClient();
    final AxisService axisService = serviceClient.getAxisService();

    final ConfigurationContext configContext = null;

    final TargetSystem targetSystemObj = targetSystemDAO.get(targetSystemID);

    // BEGIN, CR00241358, EC
    final String targetSystemName = targetSystemObj.getSystemName();

    // Details to access target system web service.
    final TargetSystemInformation targetSystemInformation = this.getTargetSystemInformation(
      targetSystemName);
    final String targetSystemAddress = targetSystemInformation.getAddress();
    final String username = targetSystemInformation.getUsername();
    final String password = targetSystemInformation.getPlainPassword();
    // END, CR00241358, EC

    // construct an RPCServiceClient based on the generated stub.
    final RPCServiceClient rpcServiceClient = new RPCServiceClient(
      configContext, axisService);

    // BEGIN, CR00241358, EC
    this.setCuramSOAPCredentials(rpcServiceClient, username, password);
    // END, CR00241358, EC

    final EndpointReference epr = new EndpointReference(targetSystemAddress);

    // setting the endpoint address
    rpcServiceClient.setTargetEPR(epr);

    // setup the operation name and arguments
    final QName opQName = new QName(
      WSConvertBSConst.kEvidenceBrokerNamespaceURI,
      WSConvertBSConst.kWebServiceOperation);
    final Object[] params = new Object[] {
      XMLUtils.toOM(document.getDocumentElement()) };

    // invoke the service.
    final OMElement omResult = rpcServiceClient.invokeBlocking(opQName, params);

    // An Axiom element is returned, convert it to a w3c element.
    if (omResult != null) {
      Element w3cElement = XMLUtils.toDOM(omResult);

    }

    // clean up the TCP connection.
    rpcServiceClient.cleanupTransport();

    // The Axis2 service configuration has state, and doesn't always get
    // initialized correctly for second and subsequent call. Explicitly
    // removing the service works around this.
    final AxisConfiguration config = rpcServiceClient.getAxisConfiguration();

    config.removeService(rpcServiceClient.getAxisService().getName());
    // END, CR00217066

  }

  // BEGIN, CR00241358, EC
  /**
   * Set the Curam SOAP Credentials header on the supplied ServiceClient,
   * using the supplied username and password.
   *
   * @param serviceClient
   * The ServiceClient on which to set the credentials.
   * @param userName
   * The username to set
   * @param password
   * The password to set
   *
   * @throws AppException
   * If there is an issue adding the credentials header.
   * @throws InformationalException
   * If there is an issue adding the credentials header.
   */
  protected void setCuramSOAPCredentials(final ServiceClient serviceClient,
    final String userName, final String password) throws AppException,
      InformationalException {
    final SOAPFactory factory = OMAbstractFactory.getSOAP12Factory();
    final OMNamespace ns = factory.createOMNamespace(
      WSConvertBSConst.kCuramSoftwareNamespace, WSConvertBSConst.kCuramPrefix);
    final SOAPHeaderBlock header = factory.createSOAPHeaderBlock(
      WSConvertBSConst.kCuramCredentialsBlockHeader, ns);
    final OMFactory omFactory = OMAbstractFactory.getOMFactory();
    final OMNode userNameNode = omFactory.createOMElement(
      new QName(WSConvertBSConst.kCuramUsernameElement));

    ((OMElement) userNameNode).setText(userName);
    header.addChild(userNameNode);
    final OMNode passwordNode = omFactory.createOMElement(
      new QName(WSConvertBSConst.kCuramPasswordElement));

    ((OMElement) passwordNode).setText(password);
    header.addChild(passwordNode);
    serviceClient.addHeader(header);
  }

  /**
   * Get the EvidenceBroker target system address (Web Service URL), username,
   * and password for the supplied target system name.
   *
   * @param targetSystemName
   * The name of the target system
   * @return The target system address (Web Service URL), username, and
   * password
   *
   * @throws AppException
   * If there is an issue generating the target system address.
   * @throws InformationalException
   * If there is an issue generating the target system address.
   */
  protected TargetSystemInformation getTargetSystemInformation(
    final String targetSystemName) throws AppException,
      InformationalException {

    final TargetSystem targetSystem = targetSystemDAO.readByTargetSystemNameAndStatus(
      TARGETSYSTEMSTATUSEntry.ACTIVE, targetSystemName);

    final NotFoundIndicator nfIndicator = new NotFoundIndicator();
    final NameSystemIDAndStatusKey nameAndStatusKey = new NameSystemIDAndStatusKey();

    nameAndStatusKey.name = SYSTEMSERVICENAMEEntry.EVIDENCEBROKER.getCode();
    nameAndStatusKey.systemID = targetSystem.getID();
    nameAndStatusKey.status = TARGETSYSTEMSTATUSEntry.ACTIVE.getCode();

    TargetSystemServiceDtls targetSystemServiceDtls = new TargetSystemServiceDtls();
    final TargetSystemService targetSystemService = (TargetSystemService) TargetSystemServiceFactory.newInstance();

    targetSystemServiceDtls = targetSystemService.readByNameSystemIDAndStatus(
      nfIndicator, nameAndStatusKey);

    final TargetSystemInformation targetSystemInformation;

    if (!nfIndicator.isNotFound()) {
      final String targetSystemAddress = targetSystem.getRootURL()
        + targetSystemServiceDtls.extensionURL;

      final String targetSystemUsername = targetSystemServiceDtls.username;

      final String cipherPassword = targetSystemServiceDtls.password;

      final String targetSystemPlainPassword = this.codec.decrypt(
        cipherPassword);

      targetSystemInformation = new TargetSystemInformation(targetSystemAddress,
        targetSystemUsername, targetSystemPlainPassword);
    } else {
      targetSystemInformation = null;
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        WSRESPONSESExceptionCreator.ERR_EVIDENCE_SHARE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    ValidationHelper.failIfErrorsExist();

    return targetSystemInformation;
  }

  // END, CR00241358, EC

  /**
   * Determines whether a given piece of evidence received from a remote
   * system is configured for evidence removal sharing, if configured, then
   * shares the evidence with the relevant cases.
   *
   * @param sharedEvidenceDescriptorDetails
   * Contains evidence details received from a remote system to be
   * shared.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void shareExternalEvidenceRemoval(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails)
    throws AppException, InformationalException {

    Boolean params[] = EvidenceBrokerUtils.getCachedEvidenceBrokerParams();
    
    Boolean considerAutoAcceptance = params[0];    
    Boolean considerAutoActivation = params[1];
    
    CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
      sharedEvidenceDescriptorDetails.sourceType);

    if (null == caseTypeEvidence) {
      AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME,
        sharedEvidenceDescriptorDetails.sourceType,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 33);
    }

    // Find any shared evidence configurations for this piece of evidence.
    ExternalCaseHeaderKey externalCaseHeaderKey = new ExternalCaseHeaderKey();

    externalCaseHeaderKey.externalCaseID = sharedEvidenceDescriptorDetails.details.caseID;
    ExternalCaseHeaderDtls externalCaseHeaderDtls = ExternalCaseHeaderFactory.newInstance().read(
      externalCaseHeaderKey);
    SharedSourceEvidenceAndStatusKey key = new SharedSourceEvidenceAndStatusKey();

    key.sourceID = caseTypeEvidence.getSubTypeID(
      externalCaseHeaderDtls.caseSubType);
    key.sourceType = sharedEvidenceDescriptorDetails.sourceType;
    key.sourceEvidenceType = sharedEvidenceDescriptorDetails.details.evidenceType;
    key.sourceSystemID = sharedEvidenceDescriptorDetails.sourceSystemID;
    key.recordStatus = RECORDSTATUS.NORMAL;

    EvidenceBrokerConfigDtlsList sharedEvidenceConfigDtlsList = EvidenceBrokerConfigAdminFactory.newInstance().listSharedTargetEvidences(
      key);

    // If sharing is configured for this evidence record, process the
    // evidence
    // for removal.
    if (!sharedEvidenceConfigDtlsList.dtls.isEmpty()) {
      processExternalEvidenceForRemoval(sharedEvidenceDescriptorDetails,
        sharedEvidenceConfigDtlsList, considerAutoAcceptance,
        considerAutoActivation);
    }
  }

  /**
   * Sorts the given list of evidence broker configurations into separate
   * lists of identical and non identical configurations. It then finds all
   * cases that the given evidence received from the remote system must be
   * shared with and then shares this evidence with the relevant cases for
   * each identical and non identical evidence broker configuration.
   *
   * @param sharedEvidenceDescriptorDetails
   * Contains the evidence descriptor details for the piece of
   * evidence to be shared.
   * @param fullEvidenceBrokerConfigDtlsList
   * Contains the list of evidence broker configurations that are
   * applicable to this piece of evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processExternalEvidenceForRemoval(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails,
    final EvidenceBrokerConfigDtlsList fullEvidenceBrokerConfigDtlsList)
    throws AppException, InformationalException {
    
    processExternalEvidenceForRemoval(sharedEvidenceDescriptorDetails,
      fullEvidenceBrokerConfigDtlsList, Boolean.TRUE, Boolean.TRUE);
  }

  /**
   * Sorts the given list of evidence broker configurations into separate
   * lists of identical and non identical configurations. It then finds all
   * cases that the given evidence received from the remote system must be
   * shared with and then shares this evidence with the relevant cases for
   * each identical and non identical evidence broker configuration.
   *
   * @param sharedEvidenceDescriptorDetails
   * Contains the evidence descriptor details for the piece of
   * evidence to be shared.
   * @param fullEvidenceBrokerConfigDtlsList
   * Contains the list of evidence broker configurations that are
   * applicable to this piece of evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void processExternalEvidenceForRemoval(
    final SharedEvidenceDescriptorDetails sharedEvidenceDescriptorDetails,
    final EvidenceBrokerConfigDtlsList fullEvidenceBrokerConfigDtlsList,
    Boolean considerAutoAcceptance, Boolean considerAutoActivation)
    throws AppException, InformationalException {
    EvidenceBrokerConfigDtlsList identicalEvidenceBrokerConfigList = new EvidenceBrokerConfigDtlsList();
    EvidenceBrokerConfigDtlsList nonIdenticalEvidenceBrokerConfigList = new EvidenceBrokerConfigDtlsList();

    processEvidenceHelper.sortEvidenceBrokerConfiguration(
      fullEvidenceBrokerConfigDtlsList, identicalEvidenceBrokerConfigList,
      nonIdenticalEvidenceBrokerConfigList);

    // Get a list of cases that we must share this evidence with
    CaseHeaderDtlsList targetCaseHeaderList = processEvidenceHelper.getCasesForEvidenceRemoval(
      sharedEvidenceDescriptorDetails.details);

    if (!targetCaseHeaderList.dtls.isEmpty()) {
      sharedEvidenceDescriptorDetails.details.pendingRemovalInd = true;
      sharedEvidenceDescriptorDetails.details.newInd = false;

      // Process the list of identical evidence broker configurations
      if (!identicalEvidenceBrokerConfigList.dtls.isEmpty()) {
        processExternalEvidenceForIdenticalSharing(
          identicalEvidenceBrokerConfigList, sharedEvidenceDescriptorDetails,
          targetCaseHeaderList, considerAutoAcceptance, considerAutoActivation);
      }
      // Process the list of non identical broker sharing configurations
      if (!nonIdenticalEvidenceBrokerConfigList.dtls.isEmpty()) {
        processExternalEvidenceForNonIdenticalSharing(
          nonIdenticalEvidenceBrokerConfigList, sharedEvidenceDescriptorDetails,
          targetCaseHeaderList);
      }
    }
  }
  
  // END, CR00206415.

  /**
   * Creates the out bound document to be sent to the remote system.
   *
   * @param evidenceDescriptorDtls
   * Contains the fields of the evidence object passed.
   * @param caseHeaderDtls
   * Contains the case details.
   * @param concernRoleDtls
   * Contains the concern role details.
   * @param sharingDocument
   * Contains the document.
   * @param operationName
   * Contains the operation name to be performed.
   * @param caseSubType
   * Contains the case sub type.
   *
   * @return sharingDocument Contains the out bound document.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Document createDocument(
    EvidenceDescriptorDtls evidenceDescriptorDtls,
    CaseHeaderDtls caseHeaderDtls, ConcernRoleDtls concernRoleDtls,
    Document sharingDocument, String operationName, String caseSubType)
    throws AppException, InformationalException {
    ConversionUtil conversionUtils = new ConversionUtil();

    final String systemName = Configuration.getProperty(EnvVars.ENV_SYSTEM_NAME);

    try {
      DocumentBuilder documentBuilder = null;
      final DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

      documentBuilder = documentBuilderFactory.newDocumentBuilder();
      sharingDocument = documentBuilder.newDocument();
      Element evidenceElement = sharingDocument.createElement(
        WSConvertBSConst.kEvidence);

      evidenceElement.setAttribute(WSConvertBSConst.kNamespaceURLAttribute,
        WSConvertBSConst.kNamespaceURL);
      evidenceElement.setAttribute(WSConvertBSConst.kXMLSchemaAttribute,
        WSConvertBSConst.kXMLSchema);
      evidenceElement.setAttribute(WSConvertBSConst.kXMLSchemaLocationAttribute,
        WSConvertBSConst.kXMLSchemaLocation);

      Element evidenceDataElement = sharingDocument.createElement(
        WSConvertBSConst.kEvidenceData);
      Element evidenceDetailsElement = sharingDocument.createElement(
        WSConvertBSConst.kEvidenceDetails);

      evidenceDataElement.appendChild(evidenceDetailsElement);

      Element caseIDElement = sharingDocument.createElement(
        WSConvertBSConst.kCaseID);

      caseIDElement.appendChild(
        sharingDocument.createTextNode(caseHeaderDtls.caseReference));

      Element participantNumberElement = sharingDocument.createElement(
        WSConvertBSConst.kParticipantNumber);

      participantNumberElement.appendChild(
        sharingDocument.createTextNode(concernRoleDtls.primaryAlternateID));

      Element evidenceTypeElement = sharingDocument.createElement(
        WSConvertBSConst.kEvidenceType);

      evidenceTypeElement.appendChild(
        sharingDocument.createTextNode(evidenceDescriptorDtls.evidenceType));

      Element caseTypeElement = sharingDocument.createElement(
        WSConvertBSConst.kCaseType);

      caseTypeElement.appendChild(
        sharingDocument.createTextNode(caseHeaderDtls.caseTypeCode));

      Element caseSubTypeElement = sharingDocument.createElement(
        WSConvertBSConst.kCaseSubType);

      caseSubTypeElement.appendChild(
        sharingDocument.createTextNode(caseSubType));

      Element sourceSystemElement = sharingDocument.createElement(
        WSConvertBSConst.kSourceSystemName);

      sourceSystemElement.appendChild(
        sharingDocument.createTextNode(systemName));

      Element sharedinstanceElement = sharingDocument.createElement(
        WSConvertBSConst.kSharedinstanceID);

      sharedinstanceElement.appendChild(
        sharingDocument.createTextNode(
          Long.toString(evidenceDescriptorDtls.sharedInstanceID)));

      Element operationElement = sharingDocument.createElement(
        WSConvertBSConst.kOperation);

      operationElement.appendChild(
        sharingDocument.createTextNode(operationName));

      Element receivedDateElement = sharingDocument.createElement(
        WSConvertBSConst.kReceivedDate);

      receivedDateElement.appendChild(
        sharingDocument.createTextNode(
          conversionUtils.fromCuramDate(caseHeaderDtls.receivedDate)));

      Element effectiveDateElement = sharingDocument.createElement(
        WSConvertBSConst.kEffectiveDate);

      effectiveDateElement.appendChild(
        sharingDocument.createTextNode(
          conversionUtils.fromCuramDate(caseHeaderDtls.effectiveDate)));

      evidenceDetailsElement.appendChild(caseIDElement);
      evidenceDetailsElement.appendChild(participantNumberElement);
      evidenceDetailsElement.appendChild(evidenceTypeElement);
      evidenceDetailsElement.appendChild(caseTypeElement);
      evidenceDetailsElement.appendChild(caseSubTypeElement);
      evidenceDetailsElement.appendChild(sourceSystemElement);
      evidenceDetailsElement.appendChild(sharedinstanceElement);
      evidenceDetailsElement.appendChild(operationElement);
      evidenceDetailsElement.appendChild(receivedDateElement);
      evidenceDetailsElement.appendChild(effectiveDateElement);

      evidenceDataElement.appendChild(evidenceDetailsElement);

      EIEvidenceReadDtls eiEvidenceReadDtls = new EIEvidenceReadDtls();
      EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();
      EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

      eiEvidenceKey.evidenceType = evidenceDescriptorDtls.evidenceType;
      eiEvidenceKey.evidenceID = evidenceDescriptorDtls.relatedID;
      eiEvidenceReadDtls = evidenceControllerObj.readEvidence(eiEvidenceKey);

      // Create the data Objects element.
      Element dataObjectsElement = sharingDocument.createElement(
        WSConvertBSConst.kDataObjects);

      // Get the class and fields of the evidence object passed
      Class objectClass = eiEvidenceReadDtls.evidenceObject.getClass();
      Field[] publicFields = objectClass.getFields();

      dataObjectsElement = checkTypes(publicFields, sharingDocument,
        dataObjectsElement, eiEvidenceReadDtls);

      evidenceDataElement.appendChild(dataObjectsElement);
      evidenceElement.appendChild(evidenceDataElement);
      sharingDocument.appendChild(evidenceElement);
    } catch (ParserConfigurationException parserexception) {
      AppException appException = new AppException(
        BPOEVIDENCEBROKER.ERR_EVIDENCE_BROKER_DOCUMENT_CREATION_FAILED);

      throw appException;
    }
    return sharingDocument;
  }

  /**
   * Check the type of class for the field found.
   *
   * @param publicFields
   * Contains the fields of the evidence object passed.
   * @param sharingDocument
   * Contains the document.
   * @param dataObjectsElement
   * Contains the data object element.
   * @param eiEvidenceReadDtls
   * Contains the evidence details.
   *
   * @return dataObjectsElement Element containing all specified evidence data
   * properties.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Element checkTypes(Field[] publicFields,
    Document sharingDocument, Element dataObjectsElement,
    EIEvidenceReadDtls eiEvidenceReadDtls) throws AppException,
      InformationalException {

    try {
      ConversionUtil conversionUtil = new ConversionUtil();

      // For each field found, create an element with a converted string
      // value
      for (int i = 0; i < publicFields.length; i++) {
        String fieldName = publicFields[i].getName();
        Class typeClass = publicFields[i].getType();

        Element dataItemElement = sharingDocument.createElement(
          WSConvertBSConst.kDataItem);
        Attr nameAttribute = sharingDocument.createAttribute(
          WSConvertBSConst.kName);

        nameAttribute.setValue(fieldName);

        // Add it to the dataItemElement
        dataItemElement.setAttributeNode(nameAttribute);
        // Create the type attribute
        Attr typeAttribute = sharingDocument.createAttribute(
          WSConvertBSConst.kType);

        if (typeClass == String.class) {
          // Set the type attribute value to "string"
          typeAttribute.setValue(WSConvertBSConst.kString);
          // Set the dataItem element's value
          dataItemElement.setTextContent(
            (String) publicFields[i].get(eiEvidenceReadDtls.evidenceObject));

        } else if (typeClass == boolean.class) {
          // Set the type attribute value to "boolean"
          typeAttribute.setValue(WSConvertBSConst.kBoolean);

          // Set the dataItem element's value
          boolean evidenceBoolean = publicFields[i].getBoolean(
            eiEvidenceReadDtls.evidenceObject);

          dataItemElement.setTextContent(
            new Boolean(evidenceBoolean).toString());

        } else if (typeClass == int.class) {
          // Set the type attribute value to "int"
          typeAttribute.setValue(WSConvertBSConst.kInt);

          // Set the dataItem element's value
          int evidenceInteger = publicFields[i].getInt(
            eiEvidenceReadDtls.evidenceObject);

          dataItemElement.setTextContent(Integer.toString(evidenceInteger));

        } else if (typeClass == short.class) {
          // Set the type attribute value to "short"
          typeAttribute.setValue(WSConvertBSConst.kShort);

          // Set the dataItem element's value
          short evidenceShort = publicFields[i].getShort(
            eiEvidenceReadDtls.evidenceObject);

          dataItemElement.setTextContent(Short.toString(evidenceShort));

        } else if (typeClass == double.class) {
          // Set the type attribute value to "double"
          typeAttribute.setValue(WSConvertBSConst.kDouble);

          // Set the dataItem element's value
          double evidenceDouble = publicFields[i].getDouble(
            eiEvidenceReadDtls.evidenceObject);

          dataItemElement.setTextContent(Double.toString(evidenceDouble));

        } else if (typeClass == float.class) {
          // Set the type attribute value to "float"
          typeAttribute.setValue(WSConvertBSConst.kFloat);

          // Set the dataItem element's value
          float evidenceFloat = publicFields[i].getFloat(
            eiEvidenceReadDtls.evidenceObject);

          dataItemElement.setTextContent(Float.toString(evidenceFloat));

        } else if (typeClass == long.class) {
          // Set the type attribute value to "string"
          typeAttribute.setValue(WSConvertBSConst.kLong);

          // Set the dataItem element's value
          long evidenceLong = publicFields[i].getLong(
            eiEvidenceReadDtls.evidenceObject);

          dataItemElement.setTextContent(Long.toString(evidenceLong));

        } else if (typeClass == curam.util.type.Money.class) {

          // Set the type attribute value to "date"
          typeAttribute.setValue(WSConvertBSConst.kMoney);

          // Set the dataItem element's value
          curam.util.type.Money evidenceMoney = (curam.util.type.Money) publicFields[i].get(
            eiEvidenceReadDtls.evidenceObject);

          dataItemElement.setTextContent(
            conversionUtil.fromCuramMoney(evidenceMoney));

        } else if (typeClass == curam.util.type.Date.class) {
          // Set the type attribute value to "date"
          typeAttribute.setValue(WSConvertBSConst.kDate);

          // Set the dataItem element's value
          curam.util.type.Date evidenceDate = (curam.util.type.Date) publicFields[i].get(
            eiEvidenceReadDtls.evidenceObject);

          dataItemElement.setTextContent(
            conversionUtil.fromCuramDate(evidenceDate));

        } else if (typeClass == curam.util.type.DateTime.class) {
          // Set the type attribute value to "date"
          typeAttribute.setValue(WSConvertBSConst.kDateTime);

          // Set the dataItem element's value
          curam.util.type.DateTime evidenceDateTime = (curam.util.type.DateTime) publicFields[i].get(

            eiEvidenceReadDtls.evidenceObject);

          dataItemElement.setTextContent(
            conversionUtil.fromCuramDateTime(evidenceDateTime));

        } else if (typeClass == curam.util.type.FrequencyPattern.class) {
          // Set the type attribute value to "date"
          typeAttribute.setValue(WSConvertBSConst.kFrequencyPattern);

          // Set the dataItem element's value
          curam.util.type.FrequencyPattern evidenceFrequencyPattern = (curam.util.type.FrequencyPattern) publicFields[i].get(
            eiEvidenceReadDtls.evidenceObject);

          dataItemElement.setTextContent(
            conversionUtil.fromFrequencyPattern(evidenceFrequencyPattern));
        }

        // Add the type attribute to the dataItemElement
        dataItemElement.setAttributeNode(typeAttribute);
        // Add the dataItemElement to the main data objects element
        dataObjectsElement.appendChild(dataItemElement);
      }
    } catch (IllegalAccessException iae) {
      AppException appException = new AppException(
        BPOEVIDENCEBROKER.ERR_EVIDENCE_BROKER_DOCUMENT_CREATION_FAILED);

      throw appException;
    }
    return dataObjectsElement;
  }

  // BEGIN, CR00241358, EC
  public static class TargetSystemInformation {
    protected String address;

    protected String username;

    protected String plainPassword;

    public TargetSystemInformation(String address, String username,
      String plainPassword) {
      this.address = address;
      this.username = username;
      this.plainPassword = plainPassword;
    }

    public String getAddress() {
      return address;
    }

    public String getUsername() {
      return username;
    }

    public String getPlainPassword() {
      return plainPassword;
    }
  }

  // END, CR00241358, EC

  private boolean isSameSourceAndTargetType(String evidenceType,
    String targetEvidenceType) {
    return evidenceType.equals(targetEvidenceType);
  }

  // BEGIN, CR00368925, GYH
  /**
   * Checks if the evidence in process is enabled for evidence sharing for the
   * target case type.
   *
   * @param evidenceBrokerConfigDtls
   * Contains evidence type to be checked for sharing.
   *
   * @param sharingPartyDetails
   * Contains target case type and target product ID.
   *
   * @return True if the given evidence type is enabled for sharing for the
   * target case type and target product otherwise false.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected boolean isSourceEvidenceEnabledForSharing(
    final SharedSourceEvidenceAndStatusKey sharedSourceEvidenceAndStatusKey)
    throws AppException, InformationalException {

    boolean isEvidenceSharable = false;

    curam.core.sl.struct.SharedEvidenceTypeDetailsList sharedSourceEvidenceTypeDetailsList = new curam.core.sl.struct.SharedEvidenceTypeDetailsList();

    if (!sharedSourceEvidenceAndStatusKey.sourceType.equals(CuramConst.gkEmpty)
      && (0 != sharedSourceEvidenceAndStatusKey.sourceID)) {

      // Get target evidence types associated with target case type.
      final SharingPartyKey sharingPartyKey = new SharingPartyKey();

      sharingPartyKey.sharingPartyCaseType = sharedSourceEvidenceAndStatusKey.sourceType;
      sharingPartyKey.sharingPartyID = sharedSourceEvidenceAndStatusKey.sourceID;
      sharedSourceEvidenceTypeDetailsList = listEvidenceTypeForSharing(
        sharingPartyKey);
    }

    for (final curam.core.sl.struct.SharedEvidenceTypeDetails sharedEvidenceTypeDetails : sharedSourceEvidenceTypeDetailsList.listDetails.items()) {

      if (sharedSourceEvidenceAndStatusKey.sourceEvidenceType.equals(
        sharedEvidenceTypeDetails.evidenceType)) {

        isEvidenceSharable = true;
        break;
      }
    }

    return isEvidenceSharable;
  }

  /**
   * Returns list of sharable evidence types for the source and target case
   * types.
   *
   * @param key
   * Contains sharing party ID and case type code.
   *
   * @return List of evidence types that are available for sharing party.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected curam.core.sl.struct.SharedEvidenceTypeDetailsList listEvidenceTypeForSharing(
    final SharingPartyKey key) throws AppException,
      InformationalException {

    curam.core.sl.struct.SharingPartyKey sharingPartyKey = new curam.core.sl.struct.SharingPartyKey();

    sharingPartyKey.sharingPartyCaseType = key.sharingPartyCaseType;
    sharingPartyKey.sharingPartyID = key.sharingPartyID;

    curam.core.sl.struct.SharedEvidenceTypeDetailsList sharedEvidenceTypeDetailsList = EvidenceTypeFactory.newInstance().listEvidenceForSharingParty(
      sharingPartyKey);

    if (null == sharedEvidenceTypeDetailsList) {
      sharedEvidenceTypeDetailsList = new curam.core.sl.struct.SharedEvidenceTypeDetailsList();
    }
    return sharedEvidenceTypeDetailsList;
  }

  // END, CR00368925

  // BEGIN, CR00377631, SSK
  /**
   * Sorts the list of evidence descriptor based on shared instance indicator.
   *
   * @param sourceEvidenceDescriptorDtlsList
   * Contains list of source evidence descriptors
   *
   * @return The list of sorted evidence descriptors.
   */
  protected EvidenceDescriptorDtlsList sortEvidenceDescriptorDtlsListBySharedInd(
    final EvidenceDescriptorDtlsList sourceEvidenceDescriptorDtlsList) {
    final EvidenceDescriptorDtlsList filteredEvidenceDescriptorDtlsList = new EvidenceDescriptorDtlsList();
    final java.util.List<EvidenceDescriptorDtls> sortedlist = new ArrayList<EvidenceDescriptorDtls>();

    for (final EvidenceDescriptorDtls evidenceDescriptorDtls : sourceEvidenceDescriptorDtlsList.dtls) {
      sortedlist.add(evidenceDescriptorDtls);
    }
    Collections.sort(sortedlist, new Comparator<EvidenceDescriptorDtls>() {
      public int compare(EvidenceDescriptorDtls lhs,
        EvidenceDescriptorDtls rhs) {
        return new Boolean(lhs.sharedInd).compareTo(rhs.sharedInd);
      }

    });

    filteredEvidenceDescriptorDtlsList.dtls.addAll(sortedlist);
    return filteredEvidenceDescriptorDtlsList;

  }

  // END, CR00377631
  

  // BEGIN, CR00377908, RPB
  /**
   * Checks if the given list of identical evidence broker configuration
   * includes the source evidence type intended to be shared.
   *
   * @param evidenceBrokerConfigDtlsList
   * Contains list of identical evidence broker configurations.
   * @param evidenceDescriptorDtls
   * Contains the of source evidence descriptor intended to be shared.
   *
   * @return Indicator to indicate if the identical broker list contains the
   * given evidence type.
   */
  protected boolean checkConfigurationWithSourceEvidenceDescriptor(
    final EvidenceBrokerConfigDtlsList evidenceBrokerConfigDtlsList,
    EvidenceDescriptorDtls evidenceDescriptorDtls) {

    // Get all identical configurations and check if any of them match with
    // the intended evidence to be shared.
    for (EvidenceBrokerConfigDtls evBrokConfigDtls : evidenceBrokerConfigDtlsList.dtls.items()) {

      // Ideally source and target should be same for the identical
      // evidence configurations, however checking again.
      if ((evBrokConfigDtls.sourceEvidenceType != null
        && evBrokConfigDtls.sourceEvidenceType.equalsIgnoreCase(
          evidenceDescriptorDtls.evidenceType))
            || (evBrokConfigDtls.targetEvidenceType != null
              && evBrokConfigDtls.targetEvidenceType.equalsIgnoreCase(
                evidenceDescriptorDtls.evidenceType))) {
        return true;
      }
    }
    return false;
  }
  // END, CR00377908  
}
