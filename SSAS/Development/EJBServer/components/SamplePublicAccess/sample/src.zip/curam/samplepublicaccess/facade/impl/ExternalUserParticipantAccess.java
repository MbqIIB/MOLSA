/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.samplepublicaccess.facade.impl;


import curam.core.sl.fact.ExternalUserParticipantLinkFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.samplepublicaccess.facade.struct.ExternalUserKey;
import curam.samplepublicaccess.facade.struct.ExternalUserParticipantLinkDetails;
import curam.samplepublicaccess.facade.struct.ExternalUserParticipantLinkDetailsList;
import curam.samplepublicaccess.facade.struct.ExternalUserParticipantLinkKey;
import curam.samplepublicaccess.facade.struct.ExternalUserParticipantLinkNames;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides both the admin maintenance functionality for
 * external user linked participants and the external application's linked
 * participant read and search functionality.
 */
public abstract class ExternalUserParticipantAccess extends
  curam.samplepublicaccess.facade.base.ExternalUserParticipantAccess {

  // ___________________________________________________________________________
  /**
   * Method to cancel the linked participant record.
   *
   * @param key Contains an External User Participant Link entity key
   *
   * @return The user name of the External User on the record.
   */
  public ExternalUserKey cancelParticipantLink(ExternalUserParticipantLinkKey key)
    throws AppException, InformationalException {

    // Return object
    ExternalUserKey externalUserKey = new ExternalUserKey();

    // Cancel a link
    curam.core.sl.struct.ExternalUserKey extUserKey =
      ExternalUserParticipantLinkFactory.newInstance().cancel(key.key);

    externalUserKey.key.userName = extUserKey.userKey.userName;

    return externalUserKey;
  }

  // ___________________________________________________________________________
  /**
   * Method to create a linked participant record.
   *
   * @param details The participant link details.
   *
   * @return The user name of the External User.
   */
  public ExternalUserKey createParticipantLink(
    ExternalUserParticipantLinkDetails details)
    throws AppException, InformationalException {

    // Insert a link
    ExternalUserKey externalUserKey = new ExternalUserKey();

    curam.core.sl.struct.ExternalUserKey extUserKey =
      ExternalUserParticipantLinkFactory.newInstance().insert(details.dtls);

    externalUserKey.key.userName = extUserKey.userKey.userName;

    return externalUserKey;
  }

  // ___________________________________________________________________________
  /**
   * Method to modify a linked participant record.
   *
   * @param details The linked participant details.
   *
   * @return The userName of the External User on the record.
   */
  public ExternalUserKey modifyParticipantLink(
    ExternalUserParticipantLinkDetails details)
    throws AppException, InformationalException {

    // Return object
    ExternalUserKey externalUserKey = new ExternalUserKey();

    // Modify a link
    curam.core.sl.struct.ExternalUserKey extUserKey =
      ExternalUserParticipantLinkFactory.newInstance().modify(details.dtls);

    externalUserKey.key.userName = extUserKey.userKey.userName;

    return externalUserKey;
  }

  // ___________________________________________________________________________
  /**
   * Method to read the names of both the External User and the linked
   * participant.
   *
   * @param key Contains an External User Participant Link entity key
   *
   * @return The names of both the external user and the linked participant (or
   * alternatively the SSN of the linked participant if no name is available)
   */
  public ExternalUserParticipantLinkNames readLinkNames(
    ExternalUserParticipantLinkKey key)
    throws AppException, InformationalException {

    // Read the names
    ExternalUserParticipantLinkNames linkNames =
      new ExternalUserParticipantLinkNames();

    linkNames.dtls =
      ExternalUserParticipantLinkFactory.newInstance().readLinkNames(key.key);

    return linkNames;
  }

  // ___________________________________________________________________________
  /**
   * Method to read the participant link details.
   *
   * @param key Contains an External User Participant Link entity key
   *
   * @return The linked participant details.
   */
  public ExternalUserParticipantLinkDetails readParticipantLink(
    ExternalUserParticipantLinkKey key)
    throws AppException, InformationalException {

    // Read a link
    ExternalUserParticipantLinkDetails externalUserParticipantAccessDetails =
      new ExternalUserParticipantLinkDetails();

    externalUserParticipantAccessDetails.dtls =
      ExternalUserParticipantLinkFactory.newInstance().read(key.key);

    return externalUserParticipantAccessDetails;
  }

  // BEGIN, CR00077558, CD
  // ___________________________________________________________________________
  /**
   * Method to list participant link details for the current user.
   *
   * @return A list of links related to the current user.
   */
  public ExternalUserParticipantLinkDetailsList searchParticipantLinksByCurrentUser()
    throws AppException, InformationalException {
    // BEGIN, CR00077558, CD
    ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.key.userName = TransactionInfo.getProgramUser();

    return searchParticipantLinksByUsername(externalUserKey);
  }

  // END, CR00077558
  // ___________________________________________________________________________
  /**
   * Method to list participant link details for the given External User.
   *
   * @param key The user name of the External User.
   *
   * @return A list of links related to the current user.
   */
  public ExternalUserParticipantLinkDetailsList searchParticipantLinksByUsername(
    ExternalUserKey key) throws AppException, InformationalException {

    // Retrieve all links with username
    ExternalUserParticipantLinkDetailsList externalUserParticipantAccessDetailsList =
      new ExternalUserParticipantLinkDetailsList();

    curam.core.sl.struct.ExternalUserKey externalUserKey =
      new curam.core.sl.struct.ExternalUserKey();

    externalUserKey.userKey.userName = key.key.userName;

    externalUserParticipantAccessDetailsList.dtls =
      ExternalUserParticipantLinkFactory.newInstance().searchLinkByUsername(
        externalUserKey);

    // Get the context details
    UsersKey usersKey = new UsersKey();

    usersKey.userName = key.key.userName;
    UserFullname userFullName =
      UserAccessFactory.newInstance().getFullName(usersKey);

    externalUserParticipantAccessDetailsList.context.userName =
      key.key.userName;
    externalUserParticipantAccessDetailsList.context.externalContext =
      userFullName.fullname;
    externalUserParticipantAccessDetailsList.context.internalContext =
      userFullName.fullname;

    return externalUserParticipantAccessDetailsList;
  }

}
