/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.samplepublicaccess.sl.impl;


import curam.core.fact.AddressFactory;
import curam.core.fact.BankAccountFactory;
import curam.core.fact.ConcernRoleAddressFactory;
import curam.core.fact.ConcernRoleEmailAddressFactory;
import curam.core.fact.ConcernRolePhoneNumberFactory;
import curam.core.fact.EmailAddressFactory;
import curam.core.fact.PhoneNumberFactory;
import curam.core.intf.Address;
import curam.core.intf.BankAccount;
import curam.core.intf.ConcernRoleAddress;
import curam.core.intf.ConcernRoleEmailAddress;
import curam.core.intf.ConcernRolePhoneNumber;
import curam.core.intf.EmailAddress;
import curam.core.intf.PhoneNumber;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressForConcernRoleKey;
import curam.core.struct.AddressKey;
import curam.core.struct.BankAccountKey;
import curam.core.struct.ConcernRoleAddressDtls;
import curam.core.struct.ConcernRoleEmailRMKey;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.EmailAddressKey;
import curam.core.struct.EmailRMDtlsList;
import curam.core.struct.LocationKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PhoneForConcernRoleKey;
import curam.core.struct.PhoneNumberKey;
import curam.samplepublicaccess.sl.struct.ReadLinkedParticipantDetails;
import curam.samplepublicaccess.sl.struct.ReadLinkedParticipantDetailsKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Process class to read / maintain data for participant linked to an External
 * User.
 */
public abstract class ExternalLinkedParticipant extends
  curam.samplepublicaccess.sl.base.ExternalLinkedParticipant {

  // ___________________________________________________________________________
  /**
   * Method to read the primary Participant details that hang off the Concern
   * Role entity.
   *
   * @param key The primary participant identifiers
   *
   * @return The primary participant details
   */
  public ReadLinkedParticipantDetails readParticipantDetails(
    ReadLinkedParticipantDetailsKey key)
    throws AppException, InformationalException {

    // Return object
    ReadLinkedParticipantDetails readLinkedParticipantDetails =
      new ReadLinkedParticipantDetails();

    // Address Entity value objects
    Address addressObj = AddressFactory.newInstance();
    AddressKey addressKey = new AddressKey();

    // PhoneNumber Entity value objects
    PhoneNumber phoneNumberObj = PhoneNumberFactory.newInstance();
    PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

    // EmailAddress Entity value objects
    EmailAddress emailAddressObj = EmailAddressFactory.newInstance();
    EmailAddressKey emailAddressKey = new EmailAddressKey();

    // BankAccount Entity value objects
    BankAccount bankAccountObj = BankAccountFactory.newInstance();
    BankAccountKey bankAccountKey = new BankAccountKey();

    // Public Office Entity value objects
    curam.core.intf.Location locationObj =
      curam.core.fact.LocationFactory.newInstance();
    LocationKey locationKey = new LocationKey();

    // ConcernRoleAddress value objects
    ConcernRoleAddress concernRoleAddressObj =
      ConcernRoleAddressFactory.newInstance();
    ConcernRoleAddressDtls concernRoleAddressDtls =
      new ConcernRoleAddressDtls();
    AddressForConcernRoleKey addressForConcernRoleKey =
      new AddressForConcernRoleKey();

    // ConcernRolePhoneNumber value objects
    ConcernRolePhoneNumber concernRolePhoneNumberObj =
      ConcernRolePhoneNumberFactory.newInstance();
    ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls =
      new ConcernRolePhoneNumberDtls();
    PhoneForConcernRoleKey phoneForConcernRoleKey =
      new PhoneForConcernRoleKey();

    // ConcernRoleEmailAddress value objects
    ConcernRoleEmailAddress concernRoleEmailAddressObj =
      ConcernRoleEmailAddressFactory.newInstance();

    // Read the participants primary address if one exists
    if (key.primaryAddressID != 0) {

      // Assign the key
      addressKey.addressID = key.primaryAddressID;

      // Read the address details
      AddressDtls addressDtls = addressObj.read(addressKey);

      // assign the addressDtls to the return object
      readLinkedParticipantDetails.addressDtls.assign(addressDtls);

      // Return the formatted address data
      OtherAddressData otherAddressData = new OtherAddressData();

      otherAddressData.addressData = addressDtls.addressData;

      // Get the formatted address
      addressObj.getAddressStrings(otherAddressData);

      // Assign the formatted address data to the output object
      readLinkedParticipantDetails.formattedAddressData =
        otherAddressData.addressData;

      // Read the ConcernRoleAddress Details
      addressForConcernRoleKey.addressID = addressDtls.addressID;
      addressForConcernRoleKey.concernRoleID = key.participantRoleID;

      // Perform a ConcernRoleAddress read
      concernRoleAddressDtls =
        concernRoleAddressObj.readAddressForConcernRole(
          addressForConcernRoleKey);

      // Assign the ConcernroleAddressID to the output object
      readLinkedParticipantDetails.concernRoleAddressID =
        concernRoleAddressDtls.concernRoleAddressID;
    } // End if (key.primaryAddressID != 0)

    // Read the participants primary phone number of one exists
    if (key.primaryPhoneNumberID != 0) {

      // Assign the key
      phoneNumberKey.phoneNumberID = key.primaryPhoneNumberID;

      // Read the phone number details
      readLinkedParticipantDetails.phoneNumberDtls =
        phoneNumberObj.read(phoneNumberKey);

      // Read the ConcernRolePhoneNumber Details
      phoneForConcernRoleKey.phoneNumberID =
        readLinkedParticipantDetails.phoneNumberDtls.phoneNumberID;
      phoneForConcernRoleKey.concernRoleID = key.participantRoleID;

      // Perform a ConcernRolePhoneNumber read
      concernRolePhoneNumberDtls =
        concernRolePhoneNumberObj.readPhoneForConcernRole(
          phoneForConcernRoleKey);

      // Assign the ConcernRolePhoneNumberID to the output object
      readLinkedParticipantDetails.concernRolePhoneNumberID =
        concernRolePhoneNumberDtls.concernRolePhoneNumberID;
    }

    // Read the participants primary email address of one exists
    if (key.primaryEmailAddressID != 0) {

      // Assign the key
      emailAddressKey.emailAddressID = key.primaryEmailAddressID;

      // assign the details to the return object
      readLinkedParticipantDetails.emailAddressDtls =
        emailAddressObj.read(emailAddressKey);

      // Read the ConcernRoleEmailAddress details
      ConcernRoleEmailRMKey concernRoleEmailRMKey = new ConcernRoleEmailRMKey();

      concernRoleEmailRMKey.concernRoleID = key.participantRoleID;

      // Perform the ConcernRoleEmailAddress Read
      EmailRMDtlsList emailRMDtlsList =
        concernRoleEmailAddressObj.searchEmailsByConcernRole(
          concernRoleEmailRMKey);

      for (int i = 0; i < emailRMDtlsList.dtls.size(); i++) {

        if (readLinkedParticipantDetails.emailAddressDtls.emailAddressID
          == emailRMDtlsList.dtls.item(i).emailAddressID) {

          // Assign the ConcernRoleEmailAddressID to the output object
          readLinkedParticipantDetails.concernRoleEmailAddressID =
            emailRMDtlsList.dtls.item(i).concernRoleEmailAddressID;
          break;
        }

      }

    }

    // Read the participants primary bank account of one exists
    if (key.primaryBankAccountID != 0) {

      // Read the bank account details
      bankAccountKey.bankAccountID = key.primaryBankAccountID;

      // assign the details to the return object
      readLinkedParticipantDetails.bankAccountDtls =
        bankAccountObj.read(bankAccountKey);
    }

    // Read the participants preferred public office of one exists
    if (key.prefPublicOfficeID != 0) {

      // Read the public office details
      locationKey.locationID = key.prefPublicOfficeID;

      // assign the details to the return object
      readLinkedParticipantDetails.publicOfficeDtls =
        locationObj.read(locationKey);
    }

    return readLinkedParticipantDetails;
  }

}
