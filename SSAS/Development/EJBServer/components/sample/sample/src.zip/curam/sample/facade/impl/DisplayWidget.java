/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.facade.impl.FinancialListHelper;
import curam.core.facade.struct.List;
import curam.core.impl.EnvVars;
import curam.core.sl.entity.fact.AnnouncementFactory;
import curam.core.sl.entity.struct.AnnouncementTextDtlsList;
import curam.core.sl.entity.struct.RecordStatusAndDateTime;
import curam.core.sl.infrastructure.struct.Colspec;
import curam.core.sl.infrastructure.struct.Data;
import curam.core.sl.infrastructure.struct.Entry;
import curam.core.sl.infrastructure.struct.FinancialChild;
import curam.core.sl.infrastructure.struct.FinancialItemDetails;
import curam.core.sl.infrastructure.struct.FinancialParent;
import curam.core.sl.infrastructure.struct.ListFinancialDisplay;
import curam.core.sl.infrastructure.struct.Lists;
import curam.core.sl.infrastructure.struct.Row;
import curam.core.sl.infrastructure.struct.TBody;
import curam.core.sl.infrastructure.struct.THead;
import curam.core.sl.infrastructure.widgetUtility.impl.StructToXML;
import curam.core.sl.infrastructure.widgetUtility.impl.XMLBuilder;
import curam.core.sl.struct.AnnouncementTickerTextWidget;
import curam.sample.facade.struct.GoogleMapXML;
import curam.sample.facade.struct.MultiList;
import curam.sample.facade.struct.PersonID;
import curam.sample.facade.struct.Pod;
import curam.sample.facade.struct.SearchContents;
import curam.sample.sl.pods.struct.AddressLatLngDetails;
import curam.sample.sl.pods.struct.AddressLatLngDetailsList;
import curam.sample.sl.pods.struct.RadiusInMiles;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.Money;


/**
 * Sample Class to exhibit the construction of DOM documents which, when passed
 * to the appropriate renderers, will be translated in to custom widgets on a
 * client page.
 *
 */
public abstract class DisplayWidget extends curam.sample.facade.base.DisplayWidget {

  StructToXML structToXML = new StructToXML();
  protected String[] positions;
  protected String[] country;
  protected String[] goldMedals;
  protected String[] silverMedals;
  protected String[] bronzeMedals;
  protected String olympicYear;

  // __________________________________________________________________________
  /**
   * Return a string representation of a document describing a list. A List
   * struct is populated and converted to an xml representation and returned as
   * a string.
   *
   * @return MultiList A string representation of the Lists xml document.
   */  
  public List getListContents() throws AppException, InformationalException {

    List list = new List();

    try {
      list.contentXML = structToXML.convert(getOlympicMedalsTable2008(), "list");
    } catch (Exception e) {// do nothing
    }

    return list;
  }

  // __________________________________________________________________________
  /**
   * Return a string representation of a document describing a multi list. A
   * Lists struct is populated and converted to an xml representation and
   * returned as a string.
   *
   * @return MultiList A string representation of the Lists xml document.
   */
  public MultiList getMultiListContents() throws AppException, InformationalException {

    Lists olympicYears = new Lists();

    olympicYears.list.addRef(getOlympicMedalsTable2008());
    olympicYears.list.addRef(getOlympicMedalsTable2004());

    MultiList multiList = new MultiList();

    try {
      multiList.contentXML = structToXML.convert(olympicYears, "lists");
    } catch (Exception e) {
      throw new AppRuntimeException(e);
    }

    return multiList;
  }

  // __________________________________________________________________________
  /**
   * Return a string representation of a document describing a Pod. The document
   * in this example is created using an XML builder utility class instead of
   * using the struct to xml converter technique, proving that the renderer is
   * not concerned how the DOM document it receives is constructed, only that it
   * conforms to the schema the renderer can translate.
   *
   * @return pod A string representation of a DOM document describing a Pod.
   */
  public Pod getPodContents() throws AppException, InformationalException {

    Pod pod = new Pod();

    String[] searchEngineNames = { "Yahoo", "Google", "Altavista", "Cuil"};
    String[] searchEngineUrls = {
      "http://www.yahoo.com", "http://www.Google.com",
      "http://www.altavista.com", "http://www.cuil.com"};

    // Instance of helper class to build the XML
    XMLBuilder xmlBuilder = new XMLBuilder("pod");

    xmlBuilder.addAttribute("domain", "POD_XML");
    xmlBuilder.addAttribute("id", "PT100");

    xmlBuilder.createTag("config");

    xmlBuilder.createTag("data");
    xmlBuilder.addAttribute("domain", "STANDARD_POD_CONFIG");

    xmlBuilder.createTag("resource");
    xmlBuilder.addAttribute("file",
      "curam.widget.render.infrastructure.i18n.Pods");
    xmlBuilder.closeTag(); // </resource>

    xmlBuilder.createTag("title");
    xmlBuilder.addAttribute("text", "Search Engines");
    xmlBuilder.closeTag(); // </title>

    xmlBuilder.closeTag(); // </data>
    xmlBuilder.closeTag(); // </config>

    xmlBuilder.createTag("data");
    xmlBuilder.addAttribute("style", "single-list");

    xmlBuilder.createTag("list");
    xmlBuilder.addAttribute("collapsed", "false");
    xmlBuilder.addAttribute("style", "list-body-layout");
    xmlBuilder.addAttribute("resource",
      "curam.widget.render.infrastructure.i18n.List");

    xmlBuilder.createTag("colspec");
    xmlBuilder.addAttribute("width", "100%");
    xmlBuilder.closeTag();

    xmlBuilder.createTag("tbody");

    for (int i = 0; i < searchEngineUrls.length; i++) {

      xmlBuilder.createTag("row");
      xmlBuilder.createTag("entry");
      xmlBuilder.createTag("data");
      xmlBuilder.addAttribute("style", "link");
      xmlBuilder.createTag("link");
      xmlBuilder.addAttribute("pageID", searchEngineUrls[i]);
      xmlBuilder.createTag("displayText");
      xmlBuilder.addTagData(searchEngineNames[i]);
      xmlBuilder.closeTag(); // </display-text>
      xmlBuilder.closeTag(); // </link>
      xmlBuilder.closeTag(); // </data>
      xmlBuilder.closeTag(); // </entry>
      xmlBuilder.closeTag(); // </row>
    }

    xmlBuilder.closeTag(); // </tbody>

    xmlBuilder.closeTag(); // </list>
    pod.contentXML = xmlBuilder.getXmlString();

    return pod;
  }

  // ___________________________________________________________________________
  /**
   * Helper Method
   *
   * @return List
   */
  private curam.core.sl.infrastructure.struct.List getOlympicMedalsTable2008() {

    positions = new String[] { "1st", "2nd", "3rd", "4th", "5", "6", "7"};
    country = new String[] {
      "China", "USA", "Russia", "Great Britain", "France", "Italy", "Austria"};
    goldMedals = new String[] { "51", "36", "23", "19", "1", "2", "2"};
    silverMedals = new String[] { "21", "38", "21", "13", "2", "4", "4"};
    bronzeMedals = new String[] { "28", "36", "28", "15", "3", "4", "4"};
    olympicYear = "2009";

    return getOlympicMedalsTable();

  }

  // ___________________________________________________________________________
  /**
   * Helper Method
   *
   * @return List
   */
  private curam.core.sl.infrastructure.struct.List getOlympicMedalsTable2004() {

    positions = new String[] { "1st", "2nd", "3rd", "4th"};
    country = new String[] { "USA", "China", "Russia", "Australia"};
    goldMedals = new String[] { "36", "32", "27", "17"};
    silverMedals = new String[] { "39", "17", "27", "16"};
    bronzeMedals = new String[] { "27", "14", "38", "16"};
    olympicYear = "2004";

    return getOlympicMedalsTable();

  }

  // __________________________________________________________________________
  /**
   * Example of loading a list struct
   *
   * @return List, a list struct populated with data.
   */
  private curam.core.sl.infrastructure.struct.List getOlympicMedalsTable() {

    curam.core.sl.infrastructure.struct.List olympicMedals = new curam.core.sl.infrastructure.struct.List();

    olympicMedals.tbody = new TBody();
    olympicMedals.attr__collapsed = "false";
    olympicMedals.attr__style = "list-body-layout";
    olympicMedals.attr__cssclass = "pod-list";

    Colspec positionColumn = new Colspec();

    positionColumn.attr__colwidth = "15%";
    olympicMedals.colspec.addRef(positionColumn);

    Colspec countryColumn = new Colspec();

    countryColumn.attr__colwidth = "40%";
    olympicMedals.colspec.addRef(countryColumn);

    Colspec goldColumn = new Colspec();

    goldColumn.attr__colwidth = "15%";
    olympicMedals.colspec.addRef(goldColumn);

    Colspec silverColumn = new Colspec();

    silverColumn.attr__colwidth = "15%";
    olympicMedals.colspec.addRef(silverColumn);

    Colspec bronzeColumn = new Colspec();

    bronzeColumn.attr__colwidth = "15%";
    olympicMedals.colspec.addRef(bronzeColumn);

    //
    // THead
    //
    olympicMedals.thead = new THead();

    //
    // Row (Heading)
    //
    Row headerRow = new Row();

    //
    // Entry (Heading)
    //
    Entry positionHeader = new Entry();
    Data positionHeaderData = new Data();

    positionHeaderData.attr__domain = "SVR_STRING";
    positionHeaderData.attr__omitTargetPath = "true";
    positionHeaderData.value__data = "Pos.";
    positionHeader.data.addRef(positionHeaderData);

    Entry countryHeader = new Entry();
    Data countryHeaderData = new Data();

    countryHeaderData.attr__domain = "SVR_STRING";
    countryHeaderData.attr__omitTargetPath = "true";
    countryHeaderData.value__data = "Country";
    countryHeader.data.addRef(countryHeaderData);

    Entry goldHeader = new Entry();
    Data goldHeaderData = new Data();

    goldHeaderData.attr__domain = "SVR_STRING";
    goldHeaderData.attr__omitTargetPath = "true";
    goldHeaderData.value__data = "Gold";
    goldHeader.data.addRef(goldHeaderData);

    Entry silverHeader = new Entry();
    Data silverHeaderData = new Data();

    silverHeaderData.attr__domain = "SVR_STRING";
    silverHeaderData.attr__omitTargetPath = "true";
    silverHeaderData.value__data = "Silver";
    silverHeader.data.addRef(silverHeaderData);

    Entry bronzeHeader = new Entry();
    Data bronzeHeaderData = new Data();

    bronzeHeaderData.attr__domain = "SVR_STRING";
    bronzeHeaderData.attr__omitTargetPath = "true";
    bronzeHeaderData.value__data = "Bronze";
    bronzeHeader.data.addRef(bronzeHeaderData);

    headerRow.entry.addRef(positionHeader);
    headerRow.entry.addRef(countryHeader);
    headerRow.entry.addRef(goldHeader);
    headerRow.entry.addRef(silverHeader);
    headerRow.entry.addRef(bronzeHeader);

    olympicMedals.thead.row.addRef(headerRow);
    olympicMedals.title.data.attr__domain = "SVR_STRING";
    olympicMedals.title.data.value__data = "Olympic Medals Table "
      + olympicYear;

    for (int i = 0; i < positions.length; i++) {

      curam.core.sl.infrastructure.struct.Row row = new curam.core.sl.infrastructure.struct.Row();

      curam.core.sl.infrastructure.struct.Entry positionEntry = new curam.core.sl.infrastructure.struct.Entry();
      Data positionData = new Data();

      if (i == 0 || i == 3) {
        positionData.attr__style = "list-body-parent";
      } else if (i == 1 || i == 4 || i == 5) {
        positionData.attr__style = "list-body-child";
      } else {
        positionData.attr__domain = "SVR_STRING"; 
      }
      positionData.attr__omitTargetPath = "true";
      positionData.value__data = positions[i];
      positionEntry.data.addRef(positionData);
      row.entry.addRef(positionEntry);

      curam.core.sl.infrastructure.struct.Entry countryEntry = new curam.core.sl.infrastructure.struct.Entry();
      Data countryData = new Data();

      countryData.attr__domain = "SVR_STRING";
      countryData.attr__omitTargetPath = "true";
      countryData.value__data = country[i];
      countryEntry.data.addRef(countryData);
      row.entry.addRef(countryEntry);

      curam.core.sl.infrastructure.struct.Entry goldMedalsEntry = new curam.core.sl.infrastructure.struct.Entry();
      Data goldMedalsData = new Data();

      goldMedalsData.attr__domain = "SVR_STRING";
      goldMedalsData.attr__omitTargetPath = "true";
      goldMedalsData.value__data = goldMedals[i];
      goldMedalsEntry.data.addRef(goldMedalsData);
      row.entry.addRef(goldMedalsEntry);

      curam.core.sl.infrastructure.struct.Entry silverMedalsEntry = new curam.core.sl.infrastructure.struct.Entry();
      Data silverMedalsData = new Data();

      silverMedalsData.attr__domain = "SVR_STRING";
      silverMedalsData.attr__omitTargetPath = "true";
      silverMedalsData.value__data = silverMedals[i];
      silverMedalsEntry.data.addRef(silverMedalsData);
      row.entry.addRef(silverMedalsEntry);

      curam.core.sl.infrastructure.struct.Entry bronzeMedalsEntry = new curam.core.sl.infrastructure.struct.Entry();
      Data bronzeMedalsData = new Data();

      bronzeMedalsData.attr__domain = "SVR_STRING";
      bronzeMedalsData.attr__omitTargetPath = "true";
      bronzeMedalsData.value__data = bronzeMedals[i];
      bronzeMedalsEntry.data.addRef(bronzeMedalsData);
      row.entry.addRef(bronzeMedalsEntry);

      olympicMedals.tbody.row.addRef(row);
    }
    return olympicMedals;
  }

  // BEGIN, CR00128964, PMD
  // TODO: PMD - Should this be moved into its own facade class?
  // __________________________________________________________________________
  /**
   * Return a string representation of a document describing organization
   * announcements.
   *
   * @return AnnouncementTickerTextWidget A string representation of the
   * announcement xml document.
   */
  public AnnouncementTickerTextWidget getAnnouncements()
    throws AppException, InformationalException {

    AnnouncementTickerTextWidget announcements = new AnnouncementTickerTextWidget();

    RecordStatusAndDateTime recordStatusAndDateTime = new RecordStatusAndDateTime();

    recordStatusAndDateTime.recordStatus = RECORDSTATUS.NORMAL;
    recordStatusAndDateTime.dateTime = DateTime.getCurrentDateTime();

    // Get the list of announcements
    AnnouncementTextDtlsList accouncementTextDtlsList = AnnouncementFactory.newInstance().searchByStatusAndDate(
      recordStatusAndDateTime);

    // Instance of helper class to build the XML
    XMLBuilder xmlBuilder = new XMLBuilder("announcements");

    xmlBuilder.addAttribute("domain", "ANNOUNCEMENT_TICKER_TEXT");

    xmlBuilder.createTag("config");
    xmlBuilder.addAttribute("cssclass", "announcement");

    xmlBuilder.createTag("resource");
    xmlBuilder.addAttribute("file",
      "curam.widget.render.infrastructure.i18n.Announcement");
    xmlBuilder.closeTag(); // </resource>

    xmlBuilder.createTag("title");
    xmlBuilder.addAttribute("text", "announcements.title");
    xmlBuilder.closeTag(); // </title>

    xmlBuilder.closeTag(); // </config>

    xmlBuilder.createTag("data");

    for (int i = 0; i < accouncementTextDtlsList.dtls.size(); i++) {

      xmlBuilder.createTag("announcement");
      xmlBuilder.addTagData(
        accouncementTextDtlsList.dtls.item(i).announcementText);
      xmlBuilder.closeTag(); // </announcement>

    }
    xmlBuilder.closeTag(); // </data>

    announcements.contentXML = xmlBuilder.getXmlString();

    return announcements;
  }

  // END, CR00128964

  // BEGIN, CR00129625, PMD
  // TODO: PMD - Should this be moved into its own facade class?
  // __________________________________________________________________________
  /**
   * Return a string representation of a document describing a list of addresses
   * that can be displayed on a google map.
   *
   * @param personID
   * unique id of the person
   *
   * @return GoogleMapXML A string representation of the google map xml
   * document.
   */
  public GoogleMapXML getGoogleMapData(PersonID personID)
    throws AppException, InformationalException {

    curam.sample.sl.pods.intf.MappingUtility mappingUtilityObj = curam.sample.sl.pods.fact.MappingUtilityFactory.newInstance();

    GoogleMapXML googleMapXML = new GoogleMapXML();

    AddressLatLngDetailsList addressLatLngDetailsList = new AddressLatLngDetailsList();

    AddressLatLngDetails addressLatLngDetails = new AddressLatLngDetails();

    addressLatLngDetails.address = "20 Foxfield Avenue, Raheny, Dublin 5";
    addressLatLngDetails.latitude = 53.3827242;
    addressLatLngDetails.longitude = -6.1611812;
    addressLatLngDetailsList.detailsList.addRef(addressLatLngDetails);

    addressLatLngDetails = new AddressLatLngDetails();
    addressLatLngDetails.address = "10 Roseglen Road, Raheny, Dublin 5";
    addressLatLngDetails.latitude = 53.384635;
    addressLatLngDetails.longitude = -6.162933;
    addressLatLngDetailsList.detailsList.addRef(addressLatLngDetails);

    addressLatLngDetails = new AddressLatLngDetails();
    addressLatLngDetails.address = "12 Foxfield Drive, Raheny, Dublin 5";
    addressLatLngDetails.latitude = 53.382985;
    addressLatLngDetails.longitude = -6.159333;
    addressLatLngDetailsList.detailsList.addRef(addressLatLngDetails);

    addressLatLngDetails = new AddressLatLngDetails();
    addressLatLngDetails.address = "23 Rock Hill, Blackrock, Co. Dublin";
    addressLatLngDetails.latitude = 53.302475;
    addressLatLngDetails.longitude = -6.180405;
    addressLatLngDetailsList.detailsList.addRef(addressLatLngDetails);

    addressLatLngDetails = new AddressLatLngDetails();
    addressLatLngDetails.address = "1 Clontarf Road, Clontarf, Dublin 3";
    addressLatLngDetails.latitude = 53.360326;
    addressLatLngDetails.longitude = -6.202682;
    addressLatLngDetailsList.detailsList.addRef(addressLatLngDetails);

    addressLatLngDetails = new AddressLatLngDetails();
    addressLatLngDetails.address = "10 St Assams Park, Raheny, Dublin 5";
    addressLatLngDetails.latitude = 53.382073;
    addressLatLngDetails.longitude = -6.169678;
    addressLatLngDetailsList.detailsList.addRef(addressLatLngDetails);

    // Source Address
    AddressLatLngDetails sourceAddress = new AddressLatLngDetails();

    sourceAddress.address = "10 St Assams Park, Raheny, Dublin 5";
    sourceAddress.latitude = 53.382073;
    sourceAddress.longitude = -6.169678;

    RadiusInMiles radiusInMiles = new RadiusInMiles();

    if (curam.util.resources.Configuration.getIntProperty(
      EnvVars.ENV_ADDRESS_LOCATOR_RADIUS)
        != null) {
      radiusInMiles.radiusInMiles = curam.util.resources.Configuration.getIntProperty(
        EnvVars.ENV_ADDRESS_LOCATOR_RADIUS);
    }

    if (radiusInMiles.radiusInMiles != 0) {

      // Get all addresses within the specified radius
      addressLatLngDetailsList = mappingUtilityObj.getAddressesWithinRadius(
        sourceAddress, addressLatLngDetailsList, radiusInMiles);
    }

    // Instance of helper class to build the XML
    XMLBuilder xmlBuilder = new XMLBuilder("map");

    xmlBuilder.addAttribute("domain", "GOOGLE_MAP_XML");

    xmlBuilder.createTag("config");
    xmlBuilder.addAttribute("zoom-level", "16");
    xmlBuilder.addAttribute("showDirections", "true");
    
    xmlBuilder.closeTag(); // </config>

    xmlBuilder.createTag("data");

    for (int i = 0; i < addressLatLngDetailsList.detailsList.size(); i++) {

      xmlBuilder.createTag("address");
      xmlBuilder.addAttribute("latitude",
        String.valueOf(addressLatLngDetailsList.detailsList.item(i).latitude));
      xmlBuilder.addAttribute("longitude",
        String.valueOf(addressLatLngDetailsList.detailsList.item(i).longitude));

      xmlBuilder.createTag("infowindow");
      xmlBuilder.createTag("link");
      xmlBuilder.addAttribute("pageID", "Person_resolveHomePagePage.do");
      xmlBuilder.createTag("displayText");
      xmlBuilder.addTagData("Participant Home Page");
      xmlBuilder.closeTag(); // </displayText>
      xmlBuilder.createTag("param");
      xmlBuilder.addAttribute("name", "concernRoleID");
      xmlBuilder.addAttribute("value", "101");
      xmlBuilder.closeTag(); // </param>
      xmlBuilder.closeTag(); // </link>
      xmlBuilder.createTag("link");
      xmlBuilder.addAttribute("pageID", "Application_homePage.do");
      xmlBuilder.createTag("displayText");
      xmlBuilder.addTagData("Application Home Page");
      xmlBuilder.closeTag(); // </displayText>
      xmlBuilder.closeTag(); // </link>
      xmlBuilder.closeTag(); // </info-window>

      xmlBuilder.createTag("icon");
      xmlBuilder.addAttribute("location",
        "../Images/recentitemsicons/person.png");
      xmlBuilder.addAttribute("width", "20");
      xmlBuilder.addAttribute("height", "20");
      xmlBuilder.closeTag(); // </icon>

      xmlBuilder.addTagData(
        addressLatLngDetailsList.detailsList.item(i).address);

      xmlBuilder.closeTag(); // </address>

    }

    xmlBuilder.closeTag(); // </data>

    googleMapXML.googleMapXML = xmlBuilder.getXmlString();

    return googleMapXML;
  }

  // END, CR00129625
  // BEGIN, CR00129355, JC
  /**
   * Return a string representation of search element of the page.
   *
   * @return AnnouncementTickerTextWidget A string representation of the
   * announcement xml document.
   * @throws AppException
   */
  public SearchContents getSearchContents() throws AppException {
    // Instance of helper class to build the XML
    XMLBuilder xmlBuilder = new XMLBuilder("search");

    xmlBuilder.addAttribute("domain", "SEARCH_XML");

    xmlBuilder.createTag("config");

    xmlBuilder.addAttribute("cssdiv", "searchdiv");
    xmlBuilder.addAttribute("csstitle", "searchtitle");
    xmlBuilder.addAttribute("cssinput", "searchinput");
    xmlBuilder.addAttribute("cssbutton", "searchbutton");

    xmlBuilder.createTag("resource");
    xmlBuilder.addAttribute("file",
      "curam.widget.render.infrastructure.i18n.Search");
    xmlBuilder.closeTag(); // </resource>

    xmlBuilder.createTag("title");
    xmlBuilder.addAttribute("text", "search.title");
    xmlBuilder.closeTag(); // </title>

    xmlBuilder.createTag("input");
    xmlBuilder.addAttribute("text", "search.input");
    xmlBuilder.closeTag(); // </input>

    xmlBuilder.createTag("button");
    xmlBuilder.addAttribute("text", "search.button");
    xmlBuilder.closeTag(); // </button>

    xmlBuilder.closeTag(); // </config>

    xmlBuilder.createTag("data");
    xmlBuilder.closeTag(); // </data>

    SearchContents searchContents = new SearchContents();

    searchContents.contentXML = xmlBuilder.getXmlString();

    return searchContents;
  }

  // END, CR00129355, JC


  // BEGIN, CR00129355, PDN
  /**
   * Return a string representation for a financial payments.
   *
   * @return List A string representation of the
   * financial details for the widget xml document.
   * @throws AppException
   */  
  public List getExpandableList() throws AppException, InformationalException {

    // Define the structure classes for financials
    ListFinancialDisplay listFinancialDisplay = new ListFinancialDisplay(); 
    FinancialListHelper financialListHelper = new FinancialListHelper();
    FinancialParent financialParent;
    FinancialChild financialChild;

    // Build 1st parent row
    financialParent = new FinancialParent();
    financialParent.dtls = createSampleFinancialItemDetails(123, "James Smith", 
      "Payment - Reissued", "CSH");
    listFinancialDisplay.parent.add(financialParent);

    // Build 1st parents 1st child
    financialChild = new FinancialChild();
    financialChild.dtls = createSampleFinancialItemDetails(312, "Linda Smith", 
      "Payment - Canceled", "CHQ");
    financialParent.child.add(financialChild);

    // Build 1st parents 2nd child
    financialChild = new FinancialChild();
    financialChild.dtls = createSampleFinancialItemDetails(666, "Julia Smith", 
      "Payment - Canceled", "CHQ");
    financialParent.child.add(financialChild);

    // Build a 2nd parent with no children
    financialParent = new FinancialParent();
    financialParent.dtls = createSampleFinancialItemDetails(555,
      "Grandpa Smith", "Payment - Issued", "EFT");
    listFinancialDisplay.parent.add(financialParent);

    // Build a 3rd parent
    financialParent = new FinancialParent();
    financialParent.dtls = createSampleFinancialItemDetails(576, "Martha Smith", 
      "Payment - Reissued", "CSH");
    listFinancialDisplay.parent.add(financialParent);    

    // Build a child for the 3'rd parent
    financialChild = new FinancialChild();
    financialChild.dtls = createSampleFinancialItemDetails(456, "Julia Smith", 
      "Payment - Canceled", "CHQ");
    financialParent.child.add(financialChild);    

    return null; // financialListHelper.buildFinancialList(listFinancialDisplay);

  }   

  // ____________________________________________________________________________
  /**
   * Populates the financial details for a particular row.
   *
   * @param amount a financial amount 
   *
   * @param nominee the nominee of the financial payment 
   *
   * @param type financial type 
   *
   * @return FinancialItemDetails financial details contained in a row
   */
  private FinancialItemDetails createSampleFinancialItemDetails(long amount, 
    String nominee, String type, String method) throws AppException {

    FinancialItemDetails financialItemDetails = new FinancialItemDetails();

    financialItemDetails.url = "Financial_resolveInstructionViewPage.do";
    financialItemDetails.urlTitle = "View";
    financialItemDetails.caseID = 1234;
    financialItemDetails.amount = new Money(amount);
    financialItemDetails.type = type;
    financialItemDetails.nominee = nominee;
    financialItemDetails.processed = Date.getCurrentDate();
    financialItemDetails.method = method;
    financialItemDetails.paymentDate = Date.getCurrentDate();

    return financialItemDetails;
  }  
  // END, CR00129355  
}
