/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.impl;

import curam.core.sl.infrastructure.impl.EvidenceControllerHookManager;
import curam.core.sl.infrastructure.impl.EvidenceControllerHookRegistrar;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.sample.sl.fact.SampleSportingGrantEvidenceControllerHookFactory;

//BEGIN, CR00199182, GYH
/**
 * This process class is used to register products with the evidence controller.
 * 
 * @deprecated Since Curam 6.0, replaced with
 *             {@link curam.sample.impl.SampleRegistrarModule}.
 *             <P>
 *             As part of registrars modernization, all type/object hook
 *             mappings of this class have been moved to an AbstractModule class
 *             SampleRegistrarModule. See release note: CFE-586.
 *             </P>
 */
@Deprecated
// END, CR00199182
public class SampleSportingGrantEvidenceControllerHookRegistrar extends
  curam.sample.sl.base.SampleSportingGrantEvidenceControllerHookRegistrar
  implements EvidenceControllerHookRegistrar {

  // ___________________________________________________________________________
  /**
   * This method registers the Sporting Grant Sample product with the evidence
   * controller.
   *
   */
  public void register() {

    EvidenceControllerHookRegistrar.HookMap map =
      EvidenceControllerHookManager.get();

    // BEGIN, CR00069996, SK
    map.addMapping(GeneralConst.gkproductType,
      SampleSportingGrantEvidenceControllerHookFactory.class);
    // END, CR00069996
  }

}
