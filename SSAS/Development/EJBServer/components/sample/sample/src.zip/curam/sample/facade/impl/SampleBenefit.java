/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2006, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;


import curam.codetable.ASSOCIATEDTYPE;
import curam.codetable.PRODUCTNAME;
import curam.core.facade.struct.CreatedCaseIDKey;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.struct.ActivateEvidenceTreeDetails;
import curam.core.sl.struct.SuspendEvidenceTreeDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.RegisterProductDeliveryDetails;
import curam.core.struct.RegisterProductDeliveryKey;
import curam.message.BPOSAMPLEBENEFIT;
import curam.message.BPOSERVICEPLANDELIVERY;
import curam.sample.facade.struct.ActivateSampleBenefitEvidence;
import curam.sample.facade.struct.CancelEvidenceDetails;
import curam.sample.facade.struct.CreateBenefitCaseKey;
import curam.sample.facade.struct.CreateSampleBenefitDetails;
import curam.sample.facade.struct.GetSampleBenefitEvidenceKey;
import curam.sample.facade.struct.MaintainSampleBenefitEvidence;
import curam.sample.facade.struct.SampleBenefitEvidence;
import curam.sample.facade.struct.SampleBenefitPlanItemKey;
import curam.sample.facade.struct.SuspendEvidenceDetails;
import curam.sample.struct.SimpleEvidenceDateAndVersionKey;
import curam.sample.struct.SimpleEvidenceDetails;
import curam.sample.struct.SimpleEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;


/**
 * Contains maintenance functions for the SampleBenefit facade layer.
 */
public abstract class SampleBenefit extends curam.sample.facade.base.SampleBenefit {

  // Default variables for automatic product delivery creation
  protected static final String kProductName = PRODUCTNAME.INTEGRATEDCASEBENEFITSAMPLE;
  // BEGIN, CR00069996, SK
  protected static final String kProductProviderName = BPOSAMPLEBENEFIT.INF_SAMPLE_BENEFIT_ORGANIZATION_NAME.toString();
  protected static final String kProductDeliveryPatternName = BPOSAMPLEBENEFIT.INF_SAMPLE_BENEFIT_DELIVERY_PATTERN.toString();
  // END, CR00069996

  // ___________________________________________________________________________
  /**
   * Creates a case for the Sample Benefit Product
   *
   * @param details Details to create the Sample Benefit Product
   */
  public CreateBenefitCaseKey createCase(CreateSampleBenefitDetails details)
    throws AppException, InformationalException {

    // Create return object
    CreateBenefitCaseKey createBenefitCaseKey = new CreateBenefitCaseKey();

    // CreateProductDelivery manipulation variables
    curam.core.intf.CreateProductDelivery createProductDeliveryObj = curam.core.fact.CreateProductDeliveryFactory.newInstance();
    CreatedCaseIDKey createdCaseIDKey = new CreatedCaseIDKey();
    RegisterProductDeliveryKey registerProductDeliveryKey = new RegisterProductDeliveryKey();

    // MaintainSampleBenefitEvidence manipulation variables
    curam.sample.intf.MaintainSimpleProductEvidence maintainSampleProductEvidenceObj = curam.sample.fact.MaintainSimpleProductEvidenceFactory.newInstance();
    SimpleEvidenceDetails simpleEvidenceDetails = new SimpleEvidenceDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Assign details to key
    registerProductDeliveryKey.assign(details);

    // Call CreateProductDelivery BPO to register the Sample Benefit Product
    createdCaseIDKey.caseID = createProductDeliveryObj.registerProductDelivery(registerProductDeliveryKey, new RegisterProductDeliveryDetails()).caseID;

    // Set caseID in output struct
    createBenefitCaseKey.caseID = createdCaseIDKey.caseID;

    // Assign details to create initial evidence on the Sample Benefit
    simpleEvidenceDetails.caseID = createdCaseIDKey.caseID;
    simpleEvidenceDetails.assign(details);

    // Call MaintainSimpleBenefitEvidence BPO to create initial evidence
    // on the Sample Benefit case that has just been created above
    maintainSampleProductEvidenceObj.createEvidence(simpleEvidenceDetails);

    return createBenefitCaseKey;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves evidence for the Sample Benefit Product
   *
   * @param key Key to retrieve the Sample Benefit evidence.
   */
  public SampleBenefitEvidence getEvidence(GetSampleBenefitEvidenceKey key)
    throws AppException, InformationalException {

    // Create return object
    SampleBenefitEvidence sampleBenefitEvidence = new SampleBenefitEvidence();

    // MaintainSampleBenefitEvidence manipulation variables
    curam.sample.intf.MaintainSimpleProductEvidence maintainSimpleProductEvidenceObj = curam.sample.fact.MaintainSimpleProductEvidenceFactory.newInstance();
    SimpleEvidenceKey simpleEvidenceKey = new SimpleEvidenceKey();
    SimpleEvidenceDetails simpleEvidenceDetails = new SimpleEvidenceDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Assign key to read the Sample Benefit Evidence
    simpleEvidenceKey.assign(key);

    // Call MaintainSampleBenefitEvidence BPO to read the Sample Benefit
    // evidence
    simpleEvidenceDetails = maintainSimpleProductEvidenceObj.getEvidence(
      simpleEvidenceKey);

    // Assign details to return object
    sampleBenefitEvidence.assign(simpleEvidenceDetails);

    return sampleBenefitEvidence;
  }

  // ___________________________________________________________________________
  /**
   * Maintains the evidence for the Sample Benefit Product
   *
   * @param details Evidence for the Sample Benefit Product.
   */
  public void maintainEvidence(MaintainSampleBenefitEvidence details)
    throws AppException, InformationalException {

    // MaintainSampleBenefitEvidence manipulation variables
    curam.sample.intf.MaintainSimpleProductEvidence maintainSimpleProductEvidenceObj = curam.sample.fact.MaintainSimpleProductEvidenceFactory.newInstance();
    SimpleEvidenceDetails simpleEvidenceDetails = new SimpleEvidenceDetails();

    SimpleEvidenceDateAndVersionKey simpleEvidenceDateAndVersionKey = new SimpleEvidenceDateAndVersionKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Assign evidence details
    simpleEvidenceDetails.assign(details);

    simpleEvidenceDateAndVersionKey.effectiveDate = details.effectiveDate;
    simpleEvidenceDateAndVersionKey.evidenceID = details.evidenceID;
    simpleEvidenceDateAndVersionKey.versionNo = details.versionNo;

    // Call MaintainSampleBenefitEvidence BPO to maintain the evidence
    maintainSimpleProductEvidenceObj.maintainEvidence(simpleEvidenceDetails,
      simpleEvidenceDateAndVersionKey);
     
  }

  // ___________________________________________________________________________
  /**
   * Activates evidence tree
   *
   * @param key Evidence tree ID for the Sample Benefit Product.
   */
  public void activateEvidenceTree(ActivateSampleBenefitEvidence key)
    throws AppException, InformationalException {

    // MaintainSampleBenefitEvidence manipulation variables
    curam.sample.intf.MaintainSimpleProductEvidence maintainSimpleProductEvidenceObj = curam.sample.fact.MaintainSimpleProductEvidenceFactory.newInstance();
    ActivateEvidenceTreeDetails activateEvidenceTreeDetails = new ActivateEvidenceTreeDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // activate case evidence tree
    activateEvidenceTreeDetails.key.caseEvidenceTreeID = key.caseEvidenceTreeID;
    activateEvidenceTreeDetails.details.versionNo = key.versionNo;

    maintainSimpleProductEvidenceObj.activateEvidence(
      activateEvidenceTreeDetails);
    
  }

  // ___________________________________________________________________________
  /**
   * Cancels an evidence tree.
   *
   * @param details Contains details to cancel the evidence tree.
   */
  public void cancelEvidence(CancelEvidenceDetails details)
    throws AppException, InformationalException {

    // MaintainSimpleProductEvidence manipulation variables
    curam.sample.intf.MaintainSimpleProductEvidence maintainSimpleProductEvidenceObj = curam.sample.fact.MaintainSimpleProductEvidenceFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Call business process to cancel evidence tree
    maintainSimpleProductEvidenceObj.cancelEvidence(details.details);

  }

  // ___________________________________________________________________________
  /**
   * Suspends an evidence tree.
   *
   * @param details Contains details to suspend an evidence tree.
   */
  public void suspendEvidence(SuspendEvidenceDetails details)
    throws AppException, InformationalException {

    // MaintainSimpleProductEvidence manipulation variables
    curam.sample.intf.MaintainSimpleProductEvidence maintainSimpleProductEvidenceObj = curam.sample.fact.MaintainSimpleProductEvidenceFactory.newInstance();
    SuspendEvidenceTreeDetails suspendEvidenceTreeDetails = new SuspendEvidenceTreeDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Set key to suspend an evidence tree
    suspendEvidenceTreeDetails.key.caseEvidenceTreeID = details.caseEvidenceTreeID;

    // Set details to suspend an evidence tree
    suspendEvidenceTreeDetails.details.reasonCode = details.reasonCode;
    suspendEvidenceTreeDetails.details.statusCode = details.statusCode;
    suspendEvidenceTreeDetails.details.versionNo = details.versionNo;

    // Call BPO method to suspend an evidence tree
    maintainSimpleProductEvidenceObj.suspendEvidence(suspendEvidenceTreeDetails);
  }

  // ___________________________________________________________________________
  /**
   * Creates associated product delivery for a planned item
   *
   * @param key Planned Item unique identifier
   *
   * @return Unique ID of the case created
   */
  public CreateBenefitCaseKey createAssociatedProductDeliveryForPlannedItem(
    SampleBenefitPlanItemKey key)
    throws AppException, InformationalException {

    // return value
    CreateBenefitCaseKey createBenefitCaseKey = new CreateBenefitCaseKey();

    // CaseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // ProductDeliveryPlanItemLink manipulation variables
    curam.core.sl.intf.ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = curam.core.sl.fact.ProductDeliveryPlanItemLinkFactory.newInstance();
    curam.core.sl.struct.ProductDeliveryPlanItemLinkDtls productDeliveryPlanItemLinkDtls = new curam.core.sl.struct.ProductDeliveryPlanItemLinkDtls();

    // Integrated Case Sample Product object and details
    curam.sample.facade.intf.IntegratedCaseSampleProduct integratedCaseSampleProductObj = curam.sample.facade.fact.IntegratedCaseSampleProductFactory.newInstance();
    curam.sample.facade.struct.CreateICProductDetails createICProductDetails = new curam.sample.facade.struct.CreateICProductDetails();

    // Product object and details
    curam.core.facade.intf.Product productObj = curam.core.facade.fact.ProductFactory.newInstance();
    curam.core.facade.struct.ListProductsForCategoryKey listProductsForCategoryKey = new curam.core.facade.struct.ListProductsForCategoryKey();
    curam.core.facade.struct.ListProviderAndLocationKey listProviderAndLocationsKey = new curam.core.facade.struct.ListProviderAndLocationKey();
    curam.core.facade.struct.ListDeliveryPatternNamesKey listDeliveryPatternNamesKey = new curam.core.facade.struct.ListDeliveryPatternNamesKey();

    // Planned Item business object
    curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();
    curam.serviceplans.sl.struct.PlannedItemProductDeliveryCreationDetails plannedItemProductDeliveryCreationDetails;

    // read details for product delivery creation
    plannedItemProductDeliveryCreationDetails = plannedItemObj.readDetailsForProductDeliveryCreation(
      key.key);

    // if associated type is product delivery and approval is required create
    // associated product delivery
    if (plannedItemProductDeliveryCreationDetails.associatedType.equals(
      ASSOCIATEDTYPE.CASEASSOCIATION)) {

      // set case header key to case ID of the product delivery
      caseHeaderKey.caseID = plannedItemProductDeliveryCreationDetails.caseID;

      // read integrated case ID and participant role ID
      curam.core.struct.ReadIntegratedCaseIDAndParticipantDetails readIntegratedCaseIDAndParticipantDetails = caseHeaderObj.readIntegratedCaseIDAndParticipantDetails(
        caseHeaderKey);

      //
      // Set the details dependent on planned item
      //

      // set createICProductDetails
      createICProductDetails.receivedDate = curam.util.type.Date.getCurrentDate();
      createICProductDetails.caseStartDate = plannedItemProductDeliveryCreationDetails.expectedStartDate;
      createICProductDetails.expectedStartDate = plannedItemProductDeliveryCreationDetails.expectedStartDate;
      createICProductDetails.expectedEndDate = plannedItemProductDeliveryCreationDetails.expectedEndDate;
      createICProductDetails.clientID = readIntegratedCaseIDAndParticipantDetails.concernRoleID;
      createICProductDetails.integratedCaseID = readIntegratedCaseIDAndParticipantDetails.integratedCaseID;
      createICProductDetails.expectedOutcome = plannedItemProductDeliveryCreationDetails.expectedOutcomeID;

      //
      // Set product type
      //

      // set the key
      listProductsForCategoryKey.caseID = readIntegratedCaseIDAndParticipantDetails.integratedCaseID;

      // list products for category and person
      curam.core.facade.struct.ListProductDetailsStruct listProductsDetailsStruct = productObj.listProductsForCategoryAndPerson(
        listProductsForCategoryKey);

      for (int i = 0; i < listProductsDetailsStruct.productDetailsStruct.size(); i++) {

        // look for integrated case benefit sample
        if (listProductsDetailsStruct.productDetailsStruct.item(i).name.equals(
          kProductName)) {
          createICProductDetails.productID = listProductsDetailsStruct.productDetailsStruct.item(i).productID;
        }
      }

      if ((listProductsDetailsStruct.productDetailsStruct.size() == 0)
        || (createICProductDetails.productID == 0)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANDELIVERY.ERR_SP_DELIVERY_FV_PRODUCT_UNDEFINED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      //
      // Set provider and location details
      //

      // set the key
      listProviderAndLocationsKey.productID = createICProductDetails.productID;

      // list providers and locations
      curam.core.facade.struct.ListProviderAndLocationDetails listProviderAndLocationDetails = productObj.listProvidersAndLocations(
        listProviderAndLocationsKey);

      for (int j = 0; j
        < listProviderAndLocationDetails.providerAndLocationDetails.size(); j++) {
        if (listProviderAndLocationDetails.providerAndLocationDetails.item(j).productProviderName.equals(
          kProductProviderName)) {
          // set product provider and provider location
          createICProductDetails.productProviderID = listProviderAndLocationDetails.providerAndLocationDetails.item(j).productProviderID;
          createICProductDetails.providerLocationID = listProviderAndLocationDetails.providerAndLocationDetails.item(j).locationID;
        }
      }

      if ((listProviderAndLocationDetails.providerAndLocationDetails.size()
        == 0)
          || (createICProductDetails.productProviderID == 0)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANDELIVERY.ERR_SP_DELIVERY_FV_PROVIDER_UNDEFINED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      //
      // Set delivery pattern details
      //

      // set the key
      listDeliveryPatternNamesKey.productID = createICProductDetails.productID;

      // list delivery patterns
      curam.core.facade.struct.ListDeliveryPatternNameDetails listDeliveryPatternNameDetails = productObj.listDeliveryPatternNames(
        listDeliveryPatternNamesKey);

      for (int k = 0; k < listDeliveryPatternNameDetails.dtls.size(); k++) {

        if (listDeliveryPatternNameDetails.dtls.item(k).name.equals(
          kProductDeliveryPatternName)) {
          // set product delivery pattern
          createICProductDetails.productDeliveryPatternID = listDeliveryPatternNameDetails.dtls.item(k).productDeliveryPatternID;
        }
      }

      if ((listDeliveryPatternNameDetails.dtls.size() == 0)
        || (createICProductDetails.productDeliveryPatternID == 0)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANDELIVERY.ERR_SP_DELIVERY_FV_DELIVERY_PATTERN_UNDEFINED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      //
      // Set currency details
      //
      // BEGIN, CR00347149, KH
      // Use the base currency specified in the application properties
      String baseCurrency = Configuration.getProperty(EnvVars.ENV_BASECURRENCY);

      if (baseCurrency == null) {
        baseCurrency = EnvVars.ENV_BASECURRENCY_DEFAULT; 
      }
      createICProductDetails.currencyType = baseCurrency;
      // END, CR00347149

      // create associated product delivery
      curam.core.facade.struct.CreatedCaseIDKey createdCaseIDKey = integratedCaseSampleProductObj.createCase(
        createICProductDetails);

      // set return value
      createBenefitCaseKey.caseID = createdCaseIDKey.caseID;

      // set link details
      productDeliveryPlanItemLinkDtls.dtls.plannedItemID = key.key.plannedItemIDKey.plannedItemID;
      productDeliveryPlanItemLinkDtls.dtls.caseID = createdCaseIDKey.caseID;

      // create product delivery plan item link
      productDeliveryPlanItemLinkObj.create(productDeliveryPlanItemLinkDtls);
    }

    // return case ID
    return createBenefitCaseKey;
  }

}
