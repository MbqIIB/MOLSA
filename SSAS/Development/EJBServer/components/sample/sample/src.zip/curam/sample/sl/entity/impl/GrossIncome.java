/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.entity.impl;


import curam.sample.sl.entity.fact.GrossIncomeFactory;


public abstract class GrossIncome extends curam.sample.sl.entity.base.GrossIncome {

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readMaximumFamilySize
   */
  public curam.sample.sl.entity.struct.FamilySize getMaximumFamilySize() throws curam.util.exception.AppException, curam.util.exception.InformationalException {
    return GrossIncomeFactory.newInstance().readMaximumFamilySize();
  }

}
