/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.facade.impl;


import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.facade.fact.IntegratedCaseFactory;
import curam.core.facade.struct.CaseParticipantRoleIDKey;
import curam.core.facade.struct.IntegratedCaseIDKey;
import curam.core.facade.struct.IntegratedCaseMenuDataDetails;
import curam.core.facade.struct.IntegratedCaseMenuDataKey;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.ProductDelivery;
import curam.core.sl.entity.struct.CaseIDAndStatusKey;
import curam.core.sl.entity.struct.CaseIDParticipantIDAndTypeDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleID;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseDetails;
import curam.core.sl.entity.struct.ReadByParticipantRoleTypeAndCaseKey;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.struct.CaseConcernRoleName;
import curam.core.struct.CaseHomePageNameAndType;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.ICHomePageNameAndType;
import curam.core.struct.ICPageNamesICTypeAndConcernDetails;
import curam.core.struct.IntegratedCaseReferenceKey;
import curam.core.struct.ParticipantCaseAndUserDetails;
import curam.core.struct.ParticipantCaseAndUserKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.message.SEPARATOR;
import curam.sample.facade.struct.ReadSampleSportingGrantSiteMapDetails;
import curam.sample.facade.struct.SampleICProductDeliveryContextDescriptionDetails;
import curam.sample.facade.struct.SampleICProductDeliveryContextDescriptionKey;
import curam.sample.facade.struct.SampleSportingGrantPrimaryClientDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;


/**
 * Maintains the details of Integrated case associated with Sample Sporting
 * Grant
 * Product Rules
 */
public class IntegratedCaseSampleSportingGrant extends curam.sample.facade.base.IntegratedCaseSampleSportingGrant {

  protected static final int kBufSize = 256;

  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by
   * {@link SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.getProgramLocale())}.
   * Constant for the separator used in the context description.
   * Replacement reason - static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note CR00219408.
   */
  @Deprecated
  // BEGIN, CR00053248, GM
  protected static final String kSeparator = // BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();
  // END, CR00163471, JC
  // END, CR00053248
  // END, CR00222190


  // BEGIN, CR00069996, SK
  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;
  protected static final String kItem = XmlMetaDataConst.kItem;
  protected static final String kDesc = XmlMetaDataConst.kDesc;
  protected static final String kType = XmlMetaDataConst.kType;
  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kParamCaseID = XmlMetaDataConst.kParamCaseID;

  protected static final String kParamCaseParticipantRoleID = XmlMetaDataConst.kParamCaseParticipantRoleID;

  protected static final String kTypeCase = XmlMetaDataConst.kTypeCase;
  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;
  protected static final String kTypeProduct = XmlMetaDataConst.kTypeProduct;
  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;
  protected static final String kValue = XmlMetaDataConst.kValue;

  // END, CR00069996
  // ___________________________________________________________________________
  /**
   * Generates the context description for a product delivery on an Integrated
   * Case
   *
   * @param key Contains the case identifier.
   *
   * @return A context description for a product delivery.
   */
  public SampleICProductDeliveryContextDescriptionDetails getSampleICProductDeliveryContextDescription(
    SampleICProductDeliveryContextDescriptionKey key) throws AppException,
      InformationalException {

    // Create the return object
    SampleICProductDeliveryContextDescriptionDetails sampleICProductDeliveryContextDescriptionDetails = new SampleICProductDeliveryContextDescriptionDetails();

    // CaseHeader manipulation variables
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseConcernRoleName caseConcernRoleName;
    CaseKey caseKey = new CaseKey();

    // ProductDelivery manipulation variables
    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Set key to read ProductDelivery
    productDeliveryKey.caseID = key.caseID;

    // Set key to read caseHeader
    caseKey.caseID = key.caseID;

    // Read caseHeader
    caseConcernRoleName = caseHeaderObj.readCaseConcernRoleName(caseKey);

    // Create the context description
    StringBuffer buffer = new StringBuffer(kBufSize);

    // BEGIN, CR00022287, TV
    // Read caseHeader
    caseKey.caseID = key.caseID;
    ICHomePageNameAndType icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(
      caseKey);

    buffer.append(
      // BEGIN, CR00163098, JC
      CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
      icHomePageNameAndType.integratedCaseType,
      TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC
    // BEGIN, CR00098942, SAI
    buffer.append(CuramConst.gkSpace);
    // END, CR00098942
    // BEGIN, CR00222190, ELG
    buffer.append(
      SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
        TransactionInfo.getProgramLocale()));
    // END, CR00222190

    buffer.append(caseConcernRoleName.caseReference);

    // END, CR00022287

    // Assign it to the return object
    sampleICProductDeliveryContextDescriptionDetails.contextDescription = buffer.toString();

    return sampleICProductDeliveryContextDescriptionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the name and case participate role identifier of the primary client
   *
   * @param key Contains the case identifier.
   *
   * @return The name and case participate role identifier of the primary
   * client.
   */
  public SampleSportingGrantPrimaryClientDetails readICPrimaryClientDetails(
    CaseKey key) throws AppException, InformationalException {

    // register the security implementation
    SecurityImplementationFactory.register();

    // Return object
    SampleSportingGrantPrimaryClientDetails sampleSportingGrantPrimaryClientDetails = new SampleSportingGrantPrimaryClientDetails();

    // CaseHeader entity object
    CaseHeader caseheaderObj = CaseHeaderFactory.newInstance();

    // Retrieve participant, case and user details
    ParticipantCaseAndUserKey participantCaseAndUserKey = new ParticipantCaseAndUserKey();

    participantCaseAndUserKey.caseID = key.caseID;
    participantCaseAndUserKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;

    ParticipantCaseAndUserDetails participantCaseAndUserDetails = caseheaderObj.readParticipanCaseAndUserDetails(
      participantCaseAndUserKey);

    sampleSportingGrantPrimaryClientDetails.caseParticipantRoleID = participantCaseAndUserDetails.caseParticipantRoleID;
    sampleSportingGrantPrimaryClientDetails.name = participantCaseAndUserDetails.concernRoleName;

    return sampleSportingGrantPrimaryClientDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the site map details for the Sample Sporting Grant product
   *
   * @param key Contains the case identifier.
   *
   * @return The site map details for the Sample Sporting Grant product
   */
  public ReadSampleSportingGrantSiteMapDetails readSiteMapDetails(CaseKey key)
    throws AppException, InformationalException {

    // register the security implementation
    SecurityImplementationFactory.register();

    // Return object
    ReadSampleSportingGrantSiteMapDetails readSampleSportingGrantSiteMapDetails = new ReadSampleSportingGrantSiteMapDetails();

    // Case menu manipulation objects
    IntegratedCaseIDKey integratedCaseIDKey = new IntegratedCaseIDKey();
    curam.core.facade.intf.IntegratedCase integratedCaseObj = IntegratedCaseFactory.newInstance();

    // EvidenceDescriptor manipulation objects
    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    CaseIDAndStatusKey caseIDAndStatusKey = new CaseIDAndStatusKey();

    // Set key retrieve list of EvidenceDescriptors
    caseIDAndStatusKey.caseID = key.caseID;
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.ACTIVE;

    EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = evidenceDescriptorObj.searchByCaseIDAndStatus(
      caseIDAndStatusKey);

    for (int i = 0; i < evidenceDescriptorDtlsList.dtls.size(); i++) {

      if (evidenceDescriptorDtlsList.dtls.item(i).evidenceType.equals(
        CASEEVIDENCE.SAMPLESPORTINGACTIVITY)) {
        readSampleSportingGrantSiteMapDetails.active = true;
      }
    }

    // Check for in edit evidence
    caseIDAndStatusKey.statusCode = EVIDENCEDESCRIPTORSTATUS.INEDIT;

    evidenceDescriptorDtlsList = evidenceDescriptorObj.searchByCaseIDAndStatus(
      caseIDAndStatusKey);

    for (int i = 0; i < evidenceDescriptorDtlsList.dtls.size(); i++) {

      if (evidenceDescriptorDtlsList.dtls.item(i).evidenceType.equals(
        CASEEVIDENCE.SAMPLESPORTINGACTIVITY)) {

        readSampleSportingGrantSiteMapDetails.inEdit = true;
      }
    }

    // Read context description
    SampleICProductDeliveryContextDescriptionKey sampleICProductDeliveryContextDescriptionKey = new SampleICProductDeliveryContextDescriptionKey();

    sampleICProductDeliveryContextDescriptionKey.caseID = key.caseID;

    readSampleSportingGrantSiteMapDetails.contextDescription = getSampleICProductDeliveryContextDescription(sampleICProductDeliveryContextDescriptionKey).contextDescription;

    // Read menu data
    integratedCaseIDKey.caseID = key.caseID;

    // BEGIN, CR00220971, ZV
    readSampleSportingGrantSiteMapDetails.menuData = integratedCaseObj.readCaseDetails1(integratedCaseIDKey).icMenuData.menuData;
    // END, CR00220971

    return readSampleSportingGrantSiteMapDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the Menu Data for the Integrated Case.
   *
   * @param key Integrated Case identifier.
   *
   * @return Menu Data for the Integrated Case.
   */
  public IntegratedCaseMenuDataDetails getIntegratedCaseMenuData(
    IntegratedCaseMenuDataKey key)
    throws AppException, InformationalException {

    // Create return object
    IntegratedCaseMenuDataDetails integratedCaseMenuDataDetails = new IntegratedCaseMenuDataDetails();

    // CaseParticipantRole entity objects
    curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleIDKey caseParticipantRoleIDKey = new CaseParticipantRoleIDKey();

    ParticipantHomePageName participantHomePageName;

    // CaseHeader manipulation variables
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    ICPageNamesICTypeAndConcernDetails icPageNamesICTypeAndConcernDetails;
    IntegratedCaseReferenceKey integratedCaseReferenceKey;
    CaseKey caseKey = new CaseKey();

    // ProductDelivery manipulation variables
    ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    // ConcernRole manipulation variables
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails;

    // register the security implementation
    SecurityImplementationFactory.register();

    // Set key to read ProductDelivery
    productDeliveryKey.caseID = key.caseID;

    // Read ProductDelivery
    productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = productDeliveryDtls.recipConcernRoleID;

    // Read concernRoleName
    concernRoleNameDetails = concernRoleObj.readConcernRoleName(concernRoleKey);

    CaseHomePageNameAndType caseHomePageNameAndType;

    // Set key to read productDelivery
    caseKey.caseID = key.caseID;

    // Read productDelivery to retrieve the case home page name and
    // product type
    caseHomePageNameAndType = productDeliveryObj.readCaseHomePageNameAndType(
      caseKey);

    // Read integratedCaseID from caseHeader
    integratedCaseReferenceKey = caseHeaderObj.readIntegratedCaseReferenceByCaseID(
      caseKey);

    // Re-set key with integratedCaseID to read caseHeader
    caseKey.caseID = integratedCaseReferenceKey.integratedCaseID;

    // Read caseHeader
    icPageNamesICTypeAndConcernDetails = caseHeaderObj.readICPageNamesICTypeAndConcernDetails(
      caseKey);

    LocalisableString description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_IC_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      icPageNamesICTypeAndConcernDetails.integratedCaseType));

    description.arg(integratedCaseReferenceKey.caseReference);

    // Create Root Node
    Element navigationMenuElement = new Element(kNavigationMenu);

    // Create Child Node
    Element linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      icPageNamesICTypeAndConcernDetails.homePageName);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    linkElement.setAttribute(kType, kTypeCase);

    navigationMenuElement.addContent(linkElement);

    Element paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // BEGIN, CR00278729, SK
    // Create person item child element and add it to the root
    // Populate the caseIDParticipantRoleKey
    // BEGIN, CR00305478, MV
    final ReadByParticipantRoleTypeAndCaseKey readByParticipantRoleTypeAndCaseKey = new ReadByParticipantRoleTypeAndCaseKey();

    readByParticipantRoleTypeAndCaseKey.caseID = integratedCaseReferenceKey.integratedCaseID;
    readByParticipantRoleTypeAndCaseKey.participantRoleID = productDeliveryDtls.recipConcernRoleID;
    readByParticipantRoleTypeAndCaseKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    readByParticipantRoleTypeAndCaseKey.recordStatus = RECORDSTATUS.NORMAL;    
   
    final ReadByParticipantRoleTypeAndCaseDetails readByParticipantRoleTypeAndCaseDetails = caseParticipantRole.readCaseParticipantRoleIDByParticipantRoleIDCaseIDTypeAndRecordStatus(
      readByParticipantRoleTypeAndCaseKey);

    // END, CR00278729  
    
    caseParticipantRoleIDKey.caseParticipantRoleID = readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID;
    // END, CR00305478
    
    // Get participant home page
    participantHomePageName = IntegratedCaseFactory.newInstance().resolveParticipantHome(
      caseParticipantRoleIDKey);

    // create link to the participant home page.
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID,
      participantHomePageName.participantHomePageName);
    description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_CR_MENU_DESCRIPTION);

    description.arg(concernRoleNameDetails.concernRoleName);

    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypePerson);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseParticipantRoleID);
    // BEGIN, CR00305478, MV
    paramElement.setAttribute(kValue,
      Long.toString(
      readByParticipantRoleTypeAndCaseDetails.caseParticipantRoleID));
    // END, CR00305478
    linkElement.addContent(paramElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);
    paramElement.setAttribute(kValue,
      String.valueOf(integratedCaseReferenceKey.integratedCaseID));

    linkElement.addContent(paramElement);

    // Create product item child element and add it to the root
    linkElement = new Element(kItem);

    linkElement.setAttribute(kPageID, caseHomePageNameAndType.caseHomePageName);

    description = new LocalisableString(
      curam.message.BPOINTEGRATEDCASE.INF_PD_MENU_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME,
      caseHomePageNameAndType.typeCode));

    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    linkElement.setAttribute(kType, kTypeProduct);

    navigationMenuElement.addContent(linkElement);

    paramElement = new Element(kParam);

    paramElement.setAttribute(kName, kParamCaseID);

    paramElement.setAttribute(kValue, Long.toString(key.caseID));

    linkElement.addContent(paramElement);

    // Output the XML as a string and assign it to the return object
    XMLOutputter outputter = new XMLOutputter();

    integratedCaseMenuDataDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return integratedCaseMenuDataDetails;
  }

}

