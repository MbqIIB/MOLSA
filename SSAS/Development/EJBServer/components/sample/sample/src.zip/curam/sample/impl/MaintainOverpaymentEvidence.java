/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.impl;


import curam.codetable.PRODUCTTYPE;
import curam.core.sl.entity.struct.BenefitOverpaymentEvidenceDetails;
import curam.core.sl.entity.struct.GetBenefitOverpaymentEvidenceResult;
import curam.core.sl.fact.ReassessmentProductFactory;
import curam.core.sl.struct.GetEvidenceKey;
import curam.core.sl.struct.OverpmtEvidenceDetails;
import curam.core.struct.InformationalMsgDtlsList;
import curam.sample.sl.entity.struct.EvidenceDateAndVersionNoKey;
import curam.sample.struct.GetOverpaymentEvidenceResult;
import curam.sample.struct.MaintainOverpaymentEvidenceDetails;
import curam.sample.struct.MaintainOverpaymentEvidenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code to maintain the details of Overpayment Evidence.
 */
public abstract class MaintainOverpaymentEvidence
  extends curam.sample.base.MaintainOverpaymentEvidence {

  // BEGIN, CR00192165, VM
  // ___________________________________________________________________________
  /**
   * Creates evidence for an Overpayment Product.
   *
   * @param details Details to create the evidence set for the overpayment case
   *
   * @deprecated since Curam 6.0, replaced with
   *  {@link curam.core.sl.impl.ReassessmentProduct#createOverpaymentEvidence(
   *    OverpmtEvidenceDetails)}
   * <P>
   * As part of the work for separating the sample and core components,
   * the maintenance functions have been for Overpayment Evidence have been
   * moved into core. See release note CR00192165.
   * </P>
   */
  public void createEvidence(MaintainOverpaymentEvidenceDetails details)
    throws AppException, InformationalException {

    OverpmtEvidenceDetails overpmtEvidenceDetails = new OverpmtEvidenceDetails();

    overpmtEvidenceDetails.amount = details.overpaymentAmount;
    overpmtEvidenceDetails.fromDate = details.fromDate;
    overpmtEvidenceDetails.toDate = details.toDate;
    overpmtEvidenceDetails.relatedCaseID = details.relatedCaseID;
    overpmtEvidenceDetails.caseID = details.caseID;
    overpmtEvidenceDetails.type = PRODUCTTYPE.BENEFITOVERPAYMENT;

    ReassessmentProductFactory.newInstance().createOverpaymentEvidence(
      overpmtEvidenceDetails);
  }

  // ___________________________________________________________________________
  /**
   * Retrieves evidence for an Overpayment Product. If the evidence ID is set
   * in the key, that evidence will be retrieved, otherwise the current
   * evidence will be retrieved.
   *
   * @param key MaintainOverpaymentEvidenceKey
   *
   * @return containing evidence details, concern role evidence details and
   *    related case details
   *
   * @deprecated since Curam 6.0, replaced with
   *  {@link curam.core.sl.impl.ReassessmentProduct#getBenefitOverpaymentEvidence(
   *    GetEvidenceKey)}
   * <P>
   * As part of the work for separating the sample and core components,
   * the maintenance functions have been for Overpayment Evidence have been
   * moved into core. See release note CR00192165.
   * </P>
   */
  public GetOverpaymentEvidenceResult getEvidence(
    MaintainOverpaymentEvidenceKey key)
    throws AppException, InformationalException {

    // GetOverpaymentEvidenceResult variable
    GetOverpaymentEvidenceResult result = new GetOverpaymentEvidenceResult();

    GetEvidenceKey getEvidenceKey = new GetEvidenceKey();

    getEvidenceKey.caseID = key.caseID;
    getEvidenceKey.date = key.date;
    getEvidenceKey.evidenceID = key.evidenceID;

    GetBenefitOverpaymentEvidenceResult getBenefitOverpaymentEvidenceResult =
      ReassessmentProductFactory.newInstance().getBenefitOverpaymentEvidence(
        getEvidenceKey);

    result.productDeliverySummaryDetails =
      getBenefitOverpaymentEvidenceResult.productDeliverySummary;
    result.maintainConcernRoleEvidenceDetails.concernRoleID =
      getBenefitOverpaymentEvidenceResult.concernDetails.concernRoleID;
    result.maintainConcernRoleEvidenceDetails.concernRoleType =
      getBenefitOverpaymentEvidenceResult.concernDetails.concernRoleType;
    result.maintainConcernRoleEvidenceDetails.concernRoleName =
      getBenefitOverpaymentEvidenceResult.concernDetails.concernRoleName;
    result.maintainConcernRoleEvidenceDetails.concernAddressData =
      getBenefitOverpaymentEvidenceResult.concernDetails.concernAddressData;

    // BEGIN, CR00192165, VM
    result.maintainOverpaymentEvidenceDetails.caseID =
      getBenefitOverpaymentEvidenceResult.details.caseID;
    result.maintainOverpaymentEvidenceDetails.caseReference =
      getBenefitOverpaymentEvidenceResult.details.caseReference;
    result.maintainOverpaymentEvidenceDetails.evidenceID =
      getBenefitOverpaymentEvidenceResult.details.evidenceID;
    result.maintainOverpaymentEvidenceDetails.effectiveFromDate =
      getBenefitOverpaymentEvidenceResult.details.effectiveFromDate;
    result.maintainOverpaymentEvidenceDetails.fromDate =
      getBenefitOverpaymentEvidenceResult.details.fromDate;
    result.maintainOverpaymentEvidenceDetails.toDate =
      getBenefitOverpaymentEvidenceResult.details.toDate;
    result.maintainOverpaymentEvidenceDetails.overpaymentAmount =
      getBenefitOverpaymentEvidenceResult.details.overpaymentAmount;
    result.maintainOverpaymentEvidenceDetails.reassessmentDate =
      getBenefitOverpaymentEvidenceResult.details.reassessmentDate;
    result.maintainOverpaymentEvidenceDetails.relatedCaseID =
      getBenefitOverpaymentEvidenceResult.details.relatedCaseID;
    result.maintainOverpaymentEvidenceDetails.relatedCaseReference =
      getBenefitOverpaymentEvidenceResult.details.relatedCaseReference;
    // END, CR00192165

    return result;
  }

  // ___________________________________________________________________________
  /**
   * Maintains evidence for an Overpayment Product. If a date-time is set in the
   * date key, the evidence closest to that date will be used, otherwise the
   * current evidence will be used.
   *
   * Maintains evidence for an Overpayment Product
   *
   * @param details details to create
   * @param evidenceDateAndVersionNoKey date from which the evidence is
   *   effective, the evidence ID and the version number.
   *
   * @return Informational messages
   *
   * @deprecated since Curam 6.0, replaced with
   *  {@link curam.core.sl.impl.ReassessmentProduct#maintainBenefitOverpaymentEvidence(
   *    BenefitOverpaymentEvidenceDetails,
   *    curam.core.sl.struct.EvidenceDateAndVersionNoKey)}
   * <P>
   * As part of the work for separating the sample and core components,
   * the maintenance functions have been for Overpayment Evidence have been
   * moved into core. See release note CR00192165.
   * </P>
   */
  public InformationalMsgDtlsList maintainEvidence(
    MaintainOverpaymentEvidenceDetails details,
    EvidenceDateAndVersionNoKey evidenceDateAndVersionNoKey)
    throws AppException, InformationalException {

    BenefitOverpaymentEvidenceDetails overpaymentDetails =
      new BenefitOverpaymentEvidenceDetails();
    curam.core.sl.struct.EvidenceDateAndVersionNoKey key =
      new curam.core.sl.struct.EvidenceDateAndVersionNoKey();

    key.effectiveFrom = evidenceDateAndVersionNoKey.effectiveFrom;
    key.evidenceID = evidenceDateAndVersionNoKey.evidenceID;
    key.versionNo = evidenceDateAndVersionNoKey.versionNo;

    overpaymentDetails.caseID = details.caseID;
    overpaymentDetails.caseReference = details.caseReference;
    overpaymentDetails.effectiveFromDate = details.effectiveFromDate;
    overpaymentDetails.fromDate = details.fromDate;
    overpaymentDetails.toDate = details.toDate;
    overpaymentDetails.evidenceID = details.evidenceID;
    overpaymentDetails.overpaymentAmount = details.overpaymentAmount;
    overpaymentDetails.reassessmentDate = details.reassessmentDate;
    overpaymentDetails.relatedCaseID = details.relatedCaseID;
    overpaymentDetails.relatedCaseReference = details.relatedCaseReference;
    overpaymentDetails.overpaymentEvidenceID = details.overpaymentEvidenceID;

    return
      ReassessmentProductFactory.newInstance().maintainBenefitOverpaymentEvidence(
        overpaymentDetails, key);
  }
  // END, CR00192165

}