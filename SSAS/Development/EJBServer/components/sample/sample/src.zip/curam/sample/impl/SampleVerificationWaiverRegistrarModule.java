/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.sample.impl;


import com.google.inject.AbstractModule;
import com.google.inject.multibindings.MapBinder;

import curam.codetable.CASEEVIDENCE;
import curam.verification.sl.infrastructure.impl.EvidenceVerificationWaiver;


/**
 * A module class which registers all the hook implementations.
 */
public class SampleVerificationWaiverRegistrarModule extends AbstractModule {

  /**
   * Registers the hook implementations to a corresponding type. The type could
   * be evidence type, product type.
   */
  @Override
  public void configure() {

    // Register all implementations for the interface EvidenceVerificationWaiver
    registerEvidenceVerificationWaiverImplementations();
  }

  /**
   * Register all implementations for the interface Evidence Verification Waiver
   * The key to bind the implementation should be of the format
   * <Case Type Code>.<Case Sub Type Code>.<Evidence Type Code>
   * where
   * - Case Type Code is code from Code Table "CaseTypeCode"
   * - Case Sub Type Code depends on type of case and the codes are from Code Tables like
   * - "ProductCategory" - Integrated Case Type, when Case Type is Intergrated Case,
   * - "ProductName" - Product Name when Case Type is Product Delivery Case,
   * - "InvestigateConfigType" - Investigation Configuration Type when Case Type is Investigation Case,
   * - "ScreeningNameCode" - Screening Name Code when Case Type is Screening Case
   * - Evidence Type Code is the code from Code Table "CaseEvidenceTypeCode"
   * - these codes should be separated by period i.e., "."
   */
  protected void registerEvidenceVerificationWaiverImplementations() {

    MapBinder<String, EvidenceVerificationWaiver> mapbinder = MapBinder.newMapBinder(
      binder(), String.class, EvidenceVerificationWaiver.class);

    String mapKey = curam.codetable.CASETYPECODE.INTEGRATEDCASE
      + curam.core.impl.CuramConst.gkDotChar
      + curam.codetable.PRODUCTCATEGORY.SPORTINGGRANT
      + curam.core.impl.CuramConst.gkDotChar
      + CASEEVIDENCE.SAMPLESPORTINGACTIVITY;

    mapbinder.addBinding(mapKey).toInstance(
      new SampleSportingGrantPaymentEvidenceVerificationWaiver());
  }
}
