/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.sample.sl.impl;


import java.util.Map;

import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.entity.struct.ClientInteractionDtls;
import curam.core.sl.entity.struct.InteractionDetails;
import curam.core.sl.entity.struct.InteractionDetailsList;
import curam.core.sl.entity.struct.ListInteractionKey;
import curam.core.sl.entity.struct.ReadInteractionHomePageKey;
import curam.core.sl.entity.struct.ReadPersonInteractionHomePageDtls;
import curam.core.sl.fact.ClientInteractionFactory;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.intf.ClientInteraction;
import curam.core.sl.struct.ClientInteractionDetails;
import curam.core.sl.struct.ClientInteractionSupplementaryDetails;
import curam.core.sl.struct.ListInteractionDetails;
import curam.core.struct.PersonAltSearchKey;
import curam.core.struct.PersonParticipantID;
import curam.core.struct.PersonSearchKey;
import curam.core.struct.ReadBasicContactDetailsKey;
import curam.core.struct.ReadBasicContactDetailsResult;
import curam.message.BPOINTERACTIONCENTRE;
import curam.sample.sl.struct.ClientInteractionPersonSearchDetails;
import curam.sample.sl.struct.ClientInteractionPersonSearchKey;
import curam.sample.sl.struct.ListHomePageInteractionKey;
import curam.sample.sl.struct.ReadPersonInteractionHomePageDetails;
import curam.sample.sl.struct.ReadPersonInteractionHomePageDetails_bo;
import curam.sample.sl.struct.ReadPersonInteractionHomePageKey_bo;
import curam.sample.sl.struct.RecordInteractionComments;
import curam.sample.sl.struct.RecordInteractionKey;
import curam.sample.sl.struct.RecordedInteractionDetails;
import curam.sample.sl.struct.VerifyInteractionCentreParametersDetails;
import curam.sample.sl.struct.VerifyInteractionCentreParametersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.CTIData;
import curam.util.resources.GeneralConstants;


/**
 * This process class provides the functionality for the Interaction Center
 * service layer.
 */
public abstract class InteractionCentre extends curam.sample.sl.base.InteractionCentre {

  // BEGIN, CR00069996, SK
  protected static final String kInteractionID = GeneralConst.gkInteractionID;

  protected static final String kInteractionDescription = GeneralConst.gkInteractionDescription;
  // END, CR00069996
  // ___________________________________________________________________________
  /**
   * Searches for a person by concern identifier.
   *
   * @param key Identifies the person concerned
   *
   * @return The details of the person read from the database.
   *
   * @deprecated Since Curam 6.0, replaced by 
   * {@link #curam.core.impl.PersonSearchRouter.search1(PersonSearchKey1)} 
   */
  @Deprecated
  public ClientInteractionPersonSearchDetails personSearch(ClientInteractionPersonSearchKey key)
    throws AppException, InformationalException {

    // details to be returned
    ClientInteractionPersonSearchDetails clientInteractionPersonSearchDetails = new ClientInteractionPersonSearchDetails();

    // person search object and key.
    curam.core.intf.PersonSearchRouter personSearchRouterObj = curam.core.fact.PersonSearchRouterFactory.newInstance();
    PersonSearchKey personSearchKey = new PersonSearchKey();

    // get the details for the search from the search key.
    personSearchKey = key.personSearchKey;

    // search for person
    clientInteractionPersonSearchDetails.personSearchResult = personSearchRouterObj.search(
      personSearchKey);

    for (int i = 0; i
      < clientInteractionPersonSearchDetails.personSearchResult.details.dtls.size(); i++) {

      clientInteractionPersonSearchDetails.personSearchResult.details.dtls.item(i).personFullName = clientInteractionPersonSearchDetails.personSearchResult.details.dtls.item(i).forename

        + CuramConst.gkSpace

        + clientInteractionPersonSearchDetails.personSearchResult.details.dtls.item(i).surname;
    }
    // return the details
    return clientInteractionPersonSearchDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads a person's interaction home page details and interaction records
   *
   * @param key Identifies the person concerned
   *
   * @return The home page details of the person.
   */
  public ReadPersonInteractionHomePageDetails_bo readPersonInteractionHomePage(ReadPersonInteractionHomePageKey_bo key)
    throws AppException, InformationalException {

    // details to be returned
    ReadPersonInteractionHomePageDetails_bo readPersonInteractionHomePageDetailsRet = new ReadPersonInteractionHomePageDetails_bo();

    ListInteractionDetails listInteractionDetails = new ListInteractionDetails();

    curam.core.sl.entity.intf.ClientInteraction clientInteractionObj = curam.core.sl.entity.fact.ClientInteractionFactory.newInstance();
    ListHomePageInteractionKey listHomePageInteractionKey = new ListHomePageInteractionKey();

    ReadPersonInteractionHomePageDetails readPersonInteractionHomePageDetails = new ReadPersonInteractionHomePageDetails();
    ReadPersonInteractionHomePageDtls readPersonInteractionHomePageDtls;
    ReadInteractionHomePageKey readInteractionHomePageKey = new ReadInteractionHomePageKey();

    readInteractionHomePageKey.participantID = key.readPersonInteractionHomePageKey.participantID;

    readPersonInteractionHomePageDtls = clientInteractionObj.readPersonInteractionHomePage(
      readInteractionHomePageKey);

    readPersonInteractionHomePageDetails.concernRoleName = readPersonInteractionHomePageDtls.concernRoleName;
    readPersonInteractionHomePageDetails.dateOfBirth = readPersonInteractionHomePageDtls.dateOfBirth;
    readPersonInteractionHomePageDetails.gender = readPersonInteractionHomePageDtls.gender;
    readPersonInteractionHomePageDetails.primaryAddressID = readPersonInteractionHomePageDtls.primaryAddressID;
    readPersonInteractionHomePageDetails.primaryAlternateID = readPersonInteractionHomePageDtls.primaryAlternateID;
    readPersonInteractionHomePageDetails.primaryPhoneNumberID = readPersonInteractionHomePageDtls.primaryPhoneNumberID;

    // assign interaction home page details to return struct
    readPersonInteractionHomePageDetailsRet.assign(
      readPersonInteractionHomePageDetails);

    listHomePageInteractionKey.concernRoleID = key.readPersonInteractionHomePageKey.participantID;

    // read the number of interactions to be included when viewing the
    // client interaction home page from the application.properties file
    String interactions = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_CLIENT_INTERACTIONS_DISPLAYED_ON_CLIENTINTERACTION_HOMEPAGE);
    int interactionsNumber = 0;

    if (interactions == null) {
      interactionsNumber = curam.core.impl.EnvVars.ENV_CLIENT_INTERACTIONS_DISPLAYED_ON_CLIENTINTERACTION_HOMEPAGE_DEFAULT;
    } else {
      interactionsNumber = Integer.parseInt(interactions);
    }

    listHomePageInteractionKey.interactions = (short) interactionsNumber;

    // read person interaction details records
    listInteractionDetails = listHomePageInteractions(
      listHomePageInteractionKey);

    // assign interaction details records to return struct
    readPersonInteractionHomePageDetailsRet.listInteractionDetails.assign(
      listInteractionDetails);

    ReadBasicContactDetailsKey readBasicContactDetailsKey = new ReadBasicContactDetailsKey();
    ReadBasicContactDetailsResult readBasicContactDetailsResult;

    // variable to read basic contract details
    curam.core.intf.MaintainContractAssistant maintainContractAssistantObj = curam.core.fact.MaintainContractAssistantFactory.newInstance();

    readBasicContactDetailsKey.concernRoleID = key.readPersonInteractionHomePageKey.participantID;
    readBasicContactDetailsKey.primaryAddressID = readPersonInteractionHomePageDetails.primaryAddressID;
    readBasicContactDetailsKey.primaryPhoneNumberID = readPersonInteractionHomePageDetails.primaryPhoneNumberID;

    // read client contact details
    readBasicContactDetailsResult = maintainContractAssistantObj.readBasicContactDetails(
      readBasicContactDetailsKey);

    readPersonInteractionHomePageDetailsRet.address = readBasicContactDetailsResult.basicContactDetails.formattedAddressData;
    readPersonInteractionHomePageDetailsRet.phoneAreaCode = readBasicContactDetailsResult.basicContactDetails.phoneAreaCode;
    readPersonInteractionHomePageDetailsRet.phoneCountryCode = readBasicContactDetailsResult.basicContactDetails.phoneCountryCode;
    readPersonInteractionHomePageDetailsRet.phoneExtension = readBasicContactDetailsResult.basicContactDetails.phoneExtension;
    readPersonInteractionHomePageDetailsRet.phoneExtension = readBasicContactDetailsResult.basicContactDetails.phoneExtension;
    readPersonInteractionHomePageDetailsRet.phoneNumber = readBasicContactDetailsResult.basicContactDetails.phoneNumber;

    // return the details
    return readPersonInteractionHomePageDetailsRet;
  }

  // ___________________________________________________________________________
  /**
   * Verifies interaction center parameters social security number
   * and interaction id
   *
   * @param key Interaction center parameter string with set of name=value
   * pairs that were attached as user data to the incoming call
   *
   * @return participant ID and verification code
   */
  public VerifyInteractionCentreParametersDetails verifyInteractionCentreParameters
    (VerifyInteractionCentreParametersKey key)
    throws AppException, InformationalException {

    // details to be returned
    VerifyInteractionCentreParametersDetails verifyInteractionCentreParametersDetails = new VerifyInteractionCentreParametersDetails();

    // person object
    curam.core.intf.Person personObj = curam.core.fact.PersonFactory.newInstance();
    PersonParticipantID personParticipantID = new PersonParticipantID();
    PersonAltSearchKey personAltSearchKey = new PersonAltSearchKey();

    Map map = CTIData.parseParameters(key.interactionCentreParamters);

    if (map.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOINTERACTIONCENTRE.ERR_INTERACTION_CENTRE_PARAMETERS_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // TODO: Check text of exception returned by parse parameters to see if we
    // should use BPOINTERACTIONCENTRE.ERR_INTERACTION_CENTRE_PARAMETERS_EMPTY

    String interactionId = kInteractionID;
    String ssn = GeneralConst.gkSSN;

    if (map.get(ssn) == null) { // parameter coming from applet may not have an "=" at the start of the string
      // BEGIN, CR00053248, GM
      ssn = GeneralConstants.kEquals + ssn; // when we enter this code by just adding data to URL already have this present
      // END, CR00053248
    }
    personAltSearchKey.primaryAlternateID = (String) map.get(ssn);
    if (map.get(kInteractionID) == null) { // same reason as check above
      // BEGIN, CR00053248, GM
      interactionId = GeneralConstants.kEquals + kInteractionID;
      // END, CR00053248
    }

    verifyInteractionCentreParametersDetails.interactionID = (String) map.get(
      interactionId);
    if (personAltSearchKey.primaryAlternateID == null) {
      verifyInteractionCentreParametersDetails.verificationCode = curam.codetable.INTCENTREVERIY.SSNNOTPROVIDED;

    } else {

      try {
        // read the participant by alternate ID
        personParticipantID = personObj.readParticipantIDbyAlternateID(
          personAltSearchKey);
        RecordInteractionKey recordInteractionKey = new RecordInteractionKey();

        recordInteractionKey.concernRoleID = personParticipantID.concernRoleID;
        recordInteractionKey.interactionID = verifyInteractionCentreParametersDetails.interactionID;

        verifyInteractionCentreParametersDetails.recordedInteractionDetails = recordInteraction(
          recordInteractionKey);

        verifyInteractionCentreParametersDetails.verificationCode = curam.codetable.INTCENTREVERIY.SSNFOUND;

        verifyInteractionCentreParametersDetails.participantID = personParticipantID.concernRoleID;

      } catch (curam.util.exception.RecordNotFoundException e) {

        verifyInteractionCentreParametersDetails.verificationCode = curam.codetable.INTCENTREVERIY.SSNNOTFOUND;
        verifyInteractionCentreParametersDetails.ctiDataReferenceNumber = personAltSearchKey.primaryAlternateID;
      }
    }

    // details to be returned
    return verifyInteractionCentreParametersDetails;
  }

  // ___________________________________________________________________________
  /**
   * Lists client interactions
   *
   * @param key identifies the client and the number of interactions to be
   * displayed on the client interaction home page.
   *
   * @return list of client interaction records
   */
  public ListInteractionDetails listHomePageInteractions(ListHomePageInteractionKey key)
    throws AppException, InformationalException {

    // details to be returned
    ListInteractionDetails listInteractionDetails = new ListInteractionDetails();

    curam.core.sl.entity.intf.ClientInteraction clientInteractionObj = curam.core.sl.entity.fact.ClientInteractionFactory.newInstance();
    InteractionDetailsList interactionDetailsList;
    InteractionDetails interactionDetails;

    ListInteractionKey listInteractionKey = new ListInteractionKey();

    listInteractionKey.concernRoleID = key.concernRoleID;

    // read the list of interaction detail records.
    interactionDetailsList = clientInteractionObj.list(listInteractionKey);

    listInteractionDetails.detailsList.dtls.ensureCapacity(
      interactionDetailsList.dtls.size());

    // list client interactions on the client interaction home page based
    // on the the interactions set in the environment variable
    for (int i = 0; i < interactionDetailsList.dtls.size(); i++) {

      if (i <= key.interactions) {
        interactionDetails = new InteractionDetails();
        interactionDetails.assign(interactionDetailsList.dtls.item(i));
        listInteractionDetails.detailsList.dtls.addRef(interactionDetails);
      }
    }
    // details to be returned
    return listInteractionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Inserts a client interaction record
   *
   * @param key identifies the client and interaction id
   */
  public RecordedInteractionDetails recordInteraction(RecordInteractionKey key)
    throws AppException, InformationalException {

    curam.core.sl.entity.intf.ClientInteraction clientInteractionObj = curam.core.sl.entity.fact.ClientInteractionFactory.newInstance();

    // client interaction details
    ClientInteractionDtls clientInteractionDtls = new ClientInteractionDtls();

    // return details
    RecordedInteractionDetails recordedInteractionDetails = new RecordedInteractionDetails();

    // check if interaction id exists
    if (key.interactionID.length() > 0) {
      clientInteractionDtls.relatedID = Integer.parseInt(key.interactionID);
    }

    clientInteractionDtls.concernRoleID = key.concernRoleID;
    clientInteractionDtls.description = kInteractionDescription;
    clientInteractionDtls.comments = key.comments;
    clientInteractionDtls.interactionTypeCode = curam.codetable.INTERACTIONTYPE.PHONERECEIVED;
    clientInteractionDtls.relatedType = curam.codetable.RELATEDINTERACTIONTYPE.CTI;
    clientInteractionDtls.interactionDateTime = curam.util.type.DateTime.getCurrentDateTime();

    // insert client interaction record
    clientInteractionObj.insert(clientInteractionDtls);
    recordedInteractionDetails.clientInteractionID = clientInteractionDtls.clientInteractionID;
    recordedInteractionDetails.versionNo = clientInteractionDtls.versionNo;
    return recordedInteractionDetails;

  }

  // ___________________________________________________________________________
  /**
   * Inserts a comment for an interaction.
   *
   * @param details contains the key and the comments entered
   */
  public void recordComments(RecordInteractionComments details)
    throws AppException, InformationalException {

    curam.core.sl.entity.intf.ClientInteraction clientInteractionObj = curam.core.sl.entity.fact.ClientInteractionFactory.newInstance();

    clientInteractionObj.insertComments(details.interactionCommentsKey,
      details.interactionCommentsDetails);
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to record a client payment interaction. Sets
   * InteractionType to 'Payment'
   *
   * @param clientInteractionDtls Contains details of payment generated
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ClientInteraction#recordClientInteractionPayment(
   * ClientInteractionDetails)}
   */
  public void recordClientInteractionPayment(
    curam.sample.sl.struct.ClientInteractionDetails clientInteractionDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00192165, VM
    ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();
    ClientInteractionDetails details = new ClientInteractionDetails();

    details.dtls.comments = clientInteractionDtls.dtls.comments;
    details.dtls.concernRoleID = clientInteractionDtls.dtls.concernRoleID;
    details.dtls.description = clientInteractionDtls.dtls.description;
    details.dtls.relatedID = clientInteractionDtls.dtls.relatedID;
    details.dtls.relatedType = clientInteractionDtls.dtls.relatedType;
    details.dtls.interactionDateTime = clientInteractionDtls.dtls.interactionDateTime;
    details.dtls.interactionTypeCode = clientInteractionDtls.dtls.interactionTypeCode;

    clientInteractionObj.recordClientInteractionPayment(details);
    // END, CR00192165
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to record a ClientInteraction.
   *
   * @param clientInteractionDtls contains details of interaction
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ClientInteraction#recordClientInteraction(
   * ClientInteractionDtls)}
   */
  public void recordClientInteraction(
    curam.sample.sl.entity.struct.ClientInteractionDtls clientInteractionDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00192165, VM
    ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();
    ClientInteractionDtls entityDtls = new ClientInteractionDtls();

    entityDtls.comments = clientInteractionDtls.comments;
    entityDtls.concernRoleID = clientInteractionDtls.relatedID;
    entityDtls.description = clientInteractionDtls.description;
    entityDtls.interactionDateTime = clientInteractionDtls.interactionDateTime;
    entityDtls.interactionTypeCode = clientInteractionDtls.interactionTypeCode;
    entityDtls.relatedType = clientInteractionDtls.relatedType;
    entityDtls.relatedID = clientInteractionDtls.relatedID;

    clientInteractionObj.recordClientInteraction(entityDtls);
    // END, CR00192165
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to record a client communication interaction. Sets
   * InteractionType according to the Communication Method + Communication
   * Direction.
   *
   * @param interactionDtls Contains details of communication including whether
   * it's an incoming or outgoing communication.
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ClientInteraction#recordClientInteractionAndCommunicationDirection(
   * ClientInteractionSupplementaryDetails)}
   */
  public void recordClientInteractionAndCommunicationDirection(
    curam.sample.sl.struct.ClientInteractionSupplementaryDetails interactionDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00192165, VM
    ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();
    ClientInteractionSupplementaryDetails supplementaryDetails = new ClientInteractionSupplementaryDetails();

    supplementaryDetails.clientDtls.dtls.concernRoleID = interactionDtls.clientDtls.dtls.concernRoleID;
    supplementaryDetails.clientDtls.dtls.comments = interactionDtls.clientDtls.dtls.comments;
    supplementaryDetails.clientDtls.dtls.description = interactionDtls.clientDtls.dtls.description;
    supplementaryDetails.clientDtls.dtls.interactionTypeCode = interactionDtls.clientDtls.dtls.interactionTypeCode;
    supplementaryDetails.clientDtls.dtls.interactionDateTime = interactionDtls.clientDtls.dtls.interactionDateTime;
    supplementaryDetails.clientDtls.dtls.relatedID = interactionDtls.clientDtls.dtls.relatedID;
    supplementaryDetails.clientDtls.dtls.relatedType = interactionDtls.clientDtls.dtls.relatedType;

    supplementaryDetails.incomingInd = interactionDtls.incomingInd;
    supplementaryDetails.communicationDirectionInd = interactionDtls.communicationDirectionInd;
    supplementaryDetails.correspondentConcernRoleID = interactionDtls.correspondentConcernRoleID;
    supplementaryDetails.methodTypeCode = interactionDtls.methodTypeCode;

    clientInteractionObj.recordClientInteractionAndCommunicationDirection(
      supplementaryDetails);
    // END, CR00192165
  }

  // ___________________________________________________________________________
  /**
   * Service layer method to record a client communication interaction.
   * If the communication was to a case participant other than the primary
   * client, a ClientInteraction is recorded for both the correspondent and the
   * primary client.
   *
   * @param interactionDtls Contains details of communication including
   * correspondent id
   *
   * @deprecated since Curam 6.0, replaced with
   * {@link curam.core.sl.impl.ClientInteraction#recordClientAndCorrespondentInteraction(
   * ClientInteractionSupplementaryDetails)}
   */
  public void recordClientAndCorrespondentInteraction(
    curam.sample.sl.struct.ClientInteractionSupplementaryDetails interactionDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00192165, VM
    ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();
    ClientInteractionSupplementaryDetails supplementaryDetails = new ClientInteractionSupplementaryDetails();

    supplementaryDetails.clientDtls.dtls.concernRoleID = interactionDtls.clientDtls.dtls.concernRoleID;
    supplementaryDetails.clientDtls.dtls.comments = interactionDtls.clientDtls.dtls.comments;
    supplementaryDetails.clientDtls.dtls.description = interactionDtls.clientDtls.dtls.description;
    supplementaryDetails.clientDtls.dtls.interactionTypeCode = interactionDtls.clientDtls.dtls.interactionTypeCode;
    supplementaryDetails.clientDtls.dtls.interactionDateTime = interactionDtls.clientDtls.dtls.interactionDateTime;
    supplementaryDetails.clientDtls.dtls.relatedID = interactionDtls.clientDtls.dtls.relatedID;
    supplementaryDetails.clientDtls.dtls.relatedType = interactionDtls.clientDtls.dtls.relatedType;

    supplementaryDetails.incomingInd = interactionDtls.incomingInd;
    supplementaryDetails.communicationDirectionInd = interactionDtls.communicationDirectionInd;
    supplementaryDetails.correspondentConcernRoleID = interactionDtls.correspondentConcernRoleID;
    supplementaryDetails.methodTypeCode = interactionDtls.methodTypeCode;

    clientInteractionObj.recordClientAndCorrespondentInteraction(
      supplementaryDetails);
    // END, CR00192165
  }
}
