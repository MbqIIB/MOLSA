/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2004, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2008, 2011 Curam Software Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam Software Inc
 * ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Curam Software Inc.
 *
 */

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.security.Principal;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.UIManager;

import curam.core.impl.CuramConst;
import curam.message.RMILOGINCLIENT;
import curam.util.security.Authentication;
import curam.util.security.EncryptionAdmin;


/**
 * RMILoginClient.java
 */

/*
 * Modification History
 * --------------------
 * 17-Apr-03  SM  Initial Version
 * 19-Nov-07  VM  Updated to support external users
 *
 */
public class RMILoginClient {

  protected JTextField username;
  protected javax.swing.JCheckBox external;
  protected JTextField password;
  protected JLabel label;
  protected JLabel counterLabel;
  protected JButton button;
  protected Authentication authentication;
  protected int loginsOK;
  protected int loginsFailed;

  /**
   * Connect in the constructor
   */
  public RMILoginClient() {
    Properties ctxProps = new Properties();

    // Setup the properties
    // BEGIN, CR00073147, GM
    ctxProps.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,
      CuramConst.kInitialContextFactory);
    ctxProps.put(javax.naming.Context.PROVIDER_URL, CuramConst.kProviderURL);
    // END, CR00073147

    // get the initial context
    Object authenicationObj = null;

    try {
      Context ctx = new InitialContext(ctxProps);

      // Look up for authentication object
      // BEGIN, CR00073147, GM
      authenicationObj = ctx.lookup(CuramConst.kAuthenticationObject);
      // END, CR00073147
    } catch (Exception e) {
      System.out.println(e);
      e.printStackTrace();

      return;
    }

    // Cast home object obtained through EJB
    authentication = (Authentication) javax.rmi.PortableRemoteObject.narrow(
      authenicationObj, curam.util.security.Authentication.class);
  }

  /**
   * create the various UI elements
   *
   * @return
   */
  protected Component createComponents() {
    // BEGIN, CR00073147, GM
    counterLabel = new JLabel(CuramConst.gkEmpty);
    // END, CR00073147

    Font existingFont = counterLabel.getFont();
    Font newFont = new Font(existingFont.getName(), existingFont.getStyle(),
      (int) (existingFont.getSize() * 0.75));

    counterLabel.setFont(newFont);

    label = new JLabel("Enter Username and Password");
    username = new JTextField();
    password = new JPasswordField();
    password.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        login(username.getText(), password.getText(), external.isSelected());
      }
    });

    // BEGIN, CR00073147, GM
    button = new JButton(RMILOGINCLIENT.INF_LOGIN_BUTTON.getMessageText());
    // END, CR00073147
    button.setMnemonic(KeyEvent.VK_L);
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        login(username.getText(), password.getText(), external.isSelected());
      }
    });

    label.setLabelFor(button);

    /**
     * Use a panel for spacing */
    JPanel pane = new JPanel();

    pane.setBorder(BorderFactory.createEmptyBorder(10, // top
      30, // left
      20, // bottom
      30)// right
      );
    pane.setLayout(new GridLayout(0, 1));
    pane.add(counterLabel);
    pane.add(label);
    pane.add(username);
    pane.add(password);

    // Add the external Check box
    JPanel externalPanel = new JPanel();

    external = new javax.swing.JCheckBox();
    // BEGIN, CR00073147, GM
    JLabel externalLabel = new JLabel(
      RMILOGINCLIENT.INF_EXTERNAL_LOGON.getMessageText());

    // END, CR00073147
    externalPanel.add(externalLabel, 0);
    externalPanel.add(external);
    pane.add(externalPanel);

    pane.add(button);

    return pane;
  }

  /**
   * Try to login
   *
   * @param name
   * @param pass
   */
  protected void login(String name, String pass, boolean externalUser) {
    // Encrypt Password
    String encrypted;   

    // BEGIN, CR00352206, SS
    Principal user;
    // BEGIN, CR00073147, GM
    String userType = CuramConst.gkInternalUser;

    // END, CR00073147
    
    try {
      if (externalUser) {
        userType = CuramConst.gkExternalUser;
        encrypted = pass;
      } else {
        encrypted = EncryptionAdmin.encryptPassword(pass);
      }
      // END, CR00352206
    } catch (Exception e) {
      // BEGIN, CR00073147, GM
      label.setText(RMILOGINCLIENT.INF_ENCRYPTION_FAILED.getMessageText());
      // END, CR00073147

      return;
    }

    try {
      user = authentication.login(name, encrypted, userType);
    } catch (Exception e) {
      user = null;
      e.printStackTrace();
    }

    if (user == null) {
      // BEGIN, CR00073147, GM
      label.setText(RMILOGINCLIENT.INF_LOG_IN_FAILED.getMessageText());

      loginsFailed++;
    } else {
      label.setText(
        RMILOGINCLIENT.INF_LOGGED_IN_AS.getMessageText() + username.getText());
      // END, CR00073147
      loginsOK++;
    }

    counterLabel.setText(
      // BEGIN, CR00073147, GM
      RMILOGINCLIENT.INF_LOGINS.getMessageText() + loginsOK
      + RMILOGINCLIENT.INF_FAILURES.getMessageText() + loginsFailed);
    // END, CR00073147
  }

  /**
   * create the LoginWindow and wait for events
   *
   * @param args List of args
   */
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
    } catch (Exception e) {// Ignore exception
    }

    // Create the top-level container and add contents to it.
    // BEGIN, CR00073147, GM
    JFrame frame = new JFrame(RMILOGINCLIENT.INF_LOGIN_BUTTON.getMessageText());
    // END, CR00073147
    RMILoginClient app = new RMILoginClient();
    Component contents = app.createComponents();

    frame.getContentPane().add(contents, BorderLayout.CENTER);

    // Finish setting up the frame, and show it.
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
    frame.pack();
    frame.setVisible(true);
  }
}
