/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * Bootstrap class to start the Curam server.
 */

import curam.util.test.ServerStartup;


public class StartServer {
  public static void main(String[] args) throws Exception {

    ServerStartup.startAll();

  }
}

