/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.QUERYTYPE;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.intf.Case;
import curam.core.facade.struct.CaseContextPanelKey;
import curam.core.facade.struct.CreateOrRunCaseQueryDetails;
import curam.core.facade.struct.CreateOrRunCaseQueryResult;
import curam.core.facade.struct.CreateOrRunCaseQueryResultStruct;
import curam.core.facade.struct.ListAndRunCaseQueryDetails;
import curam.core.facade.struct.ListAndRunCaseQueryDetailsStruct;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.QueryKey;
import curam.core.sl.entity.struct.QueryTypeKey;
import curam.core.sl.fact.CaseQueryFactory;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.struct.CaseQueryDetails;
import curam.core.sl.struct.InitialCaseQuerySearchCriteria;
import curam.core.sl.struct.ListQueriesForUserResult;
import curam.core.struct.CaseSearchAndLastTransactionDetails;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.message.BPOQUERY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for the Case Query
 * presentation layer.
 */
public abstract class CaseQuery extends curam.core.facade.base.CaseQuery {

  // _________________________________________________________________________
  /**
   * This method creates a case query.
   *
   * @param details The case query details.
   *
   * @return Created query id.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public QueryKey create(CaseQueryDetails details) throws AppException,
      InformationalException {

    curam.core.sl.intf.CaseQuery caseQueryObj = curam.core.sl.fact.CaseQueryFactory.newInstance();

    return caseQueryObj.create(details);
  }

  // _________________________________________________________________________
  /**
   * @param details The case search criteria for a query.
   *
   * @return List of cases that match the query and the query id.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by {@link #createOrRunWithMessages()}. This
   * method has been deprecated to introduce new message handling. See release note: CR00283985.
   *
   * This method creates or runs a case search query.
   *
   * If the client action was saved and a non zero queryID was supplied,
   * then that query record will be modified. If the client action was run,
   * the query will be executed and the results returned.
   */
  @Deprecated
  public CreateOrRunCaseQueryResult createOrRun(
    CreateOrRunCaseQueryDetails details)
    throws AppException, InformationalException {

    CreateOrRunCaseQueryResult result = new CreateOrRunCaseQueryResult();

    curam.core.sl.intf.CaseQuery caseQueryObj = curam.core.sl.fact.CaseQueryFactory.newInstance();

    if ((details.actionIDProperty.equals(ClientActionConst.kSave_Query))
      || (details.actionIDProperty.equals(
        ClientActionConst.kSave_Query_From_List))) {

      result.queryKey = caseQueryObj.create(details.dtls);

    } else if (details.actionIDProperty.equals(ClientActionConst.kRun_Query)) {
      result.runResult = caseQueryObj.run(details.dtls);
    } else {
      AppException e = new AppException(BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    return result;
  }
  
  // BEGIN, CR00276230, ELG
  // _________________________________________________________________________
  /**
   * This method creates or runs a case search query.
   *
   * If the client action was saved and a non zero queryID was supplied,
   * then that query record will be modified. If the client action was run,
   * the query will be executed and the results returned.
   *
   * @param details The case search criteria for a query.
   *
   * @return List of cases that match the query, the query id and the list
   * of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateOrRunCaseQueryResultStruct createOrRunWithMessages(
    final CreateOrRunCaseQueryDetails details) throws AppException,
      InformationalException {
    
    final CreateOrRunCaseQueryResultStruct createOrRunCaseQueryResultStruct = new CreateOrRunCaseQueryResultStruct();

    final curam.core.sl.intf.CaseQuery caseQueryObj = CaseQueryFactory.newInstance();

    if ((details.actionIDProperty.equals(ClientActionConst.kSave_Query))
      || (details.actionIDProperty.equals(
        ClientActionConst.kSave_Query_From_List))) {

      createOrRunCaseQueryResultStruct.queryKey = caseQueryObj.create(
        details.dtls);

    } else if (details.actionIDProperty.equals(ClientActionConst.kRun_Query)) {
      
      createOrRunCaseQueryResultStruct.runResult = caseQueryObj.run(
        details.dtls);
      
    } else {
      
      final AppException e = new AppException(
        BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      
    }

    collectInformationals(createOrRunCaseQueryResultStruct.msgList);
    
    return createOrRunCaseQueryResultStruct;
      
  }
  
  // ___________________________________________________________________________
  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   * The list to add the informational messages to
   */
  protected void collectInformationals(final InformationalMsgDtlsList msgDtlsList) {
    // Get the list of informational messages
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (String message : infos) {
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;
      msgDtlsList.dtls.addRef(informationalMsgDtls);
    }
    
  }

  // END, CR00276230

  // _________________________________________________________________________
  /**
   * Method returns initial case search criteria to populate create case
   * query search criteria.
   *
   * @return Initial create query case search criteria
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public InitialCaseQuerySearchCriteria getInitialSearchCriteria()
    throws AppException, InformationalException {

    curam.core.sl.intf.CaseQuery caseQueryObj = curam.core.sl.fact.CaseQueryFactory.newInstance();

    return caseQueryObj.getInitialSearchCriteria();
  }

  // _________________________________________________________________________
  /**
   * @param key Case query identifier to run
   *
   * @return Case query details list and selected query case search results
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by {@link #listAndRunWithMessages()}. This
   * method has been deprecated to introduce new message handling. See release note: CR00283985.
   *
   * Allows a case worker to search for active case queries by user name and
   * run selected case query.
   */
  @Deprecated
  public ListAndRunCaseQueryDetails listAndRun(QueryKey key)
    throws AppException, InformationalException {

    ListAndRunCaseQueryDetails listAndRunCaseQueryDetails = new ListAndRunCaseQueryDetails();

    listAndRunCaseQueryDetails.queryListDtls = listForUser();

    if (key.queryID != CuramConst.gkZero) {

      curam.core.sl.intf.CaseQuery caseQueryObj = curam.core.sl.fact.CaseQueryFactory.newInstance();

      listAndRunCaseQueryDetails.runResult = caseQueryObj.runSaved(key);

      listAndRunCaseQueryDetails.runResult.numberOfRecords = listAndRunCaseQueryDetails.runResult.list.searchDtls.size();

    }

    // BEGIN, CR00230649, JMA
    Case caseObj = CaseFactory.newInstance();
    CaseContextPanelKey caseContextPanelKey;

    for (CaseSearchAndLastTransactionDetails details
      : listAndRunCaseQueryDetails.runResult.list.searchDtls) {

      caseContextPanelKey = new CaseContextPanelKey();

      caseContextPanelKey.caseID = details.caseID;

      details.caseContextDetailsURL = caseObj.resolveContextPanel(caseContextPanelKey).homePageName;
    }
    // END, CR00230649
    return listAndRunCaseQueryDetails;
  }
  
  // BEGIN, CR00276230, ELG
  // _________________________________________________________________________
  /**
   * Allows a case worker to search for active case queries by user name and
   * run selected case query.
   *
   * @param key Case query identifier to run
   *
   * @return Case query details list, selected query case search results, and
   * a list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListAndRunCaseQueryDetailsStruct listAndRunWithMessages(final QueryKey key)
    throws AppException, InformationalException {
    
    final ListAndRunCaseQueryDetailsStruct listAndRunCaseQueryDetailsStruct = new ListAndRunCaseQueryDetailsStruct();

    listAndRunCaseQueryDetailsStruct.queryListDtls = listForUser();

    if (key.queryID != 0) {

      final curam.core.sl.intf.CaseQuery caseQueryObj = CaseQueryFactory.newInstance();

      listAndRunCaseQueryDetailsStruct.runResult = caseQueryObj.runSaved(key);

      listAndRunCaseQueryDetailsStruct.runResult.numberOfRecords = listAndRunCaseQueryDetailsStruct.runResult.list.searchDtls.size();

    }

    final Case caseObj = CaseFactory.newInstance();
    CaseContextPanelKey caseContextPanelKey;

    for (CaseSearchAndLastTransactionDetails details
      : listAndRunCaseQueryDetailsStruct.runResult.list.searchDtls) {

      caseContextPanelKey = new CaseContextPanelKey();

      caseContextPanelKey.caseID = details.caseID;

      details.caseContextDetailsURL = caseObj.resolveContextPanel(caseContextPanelKey).homePageName;
    }
    
    collectInformationals(listAndRunCaseQueryDetailsStruct.msgList);
    
    return listAndRunCaseQueryDetailsStruct;
    
  }  

  // END, CR00276230

  // _________________________________________________________________________
  /**
   * This method searches case queries for the logged on user.
   *
   * @return List of case query details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListQueriesForUserResult listForUser() throws AppException,
      InformationalException {

    ListQueriesForUserResult listQueriesForUserResult = new ListQueriesForUserResult();

    curam.core.sl.intf.Query queryObj = curam.core.sl.fact.QueryFactory.newInstance();

    QueryTypeKey queryTypeKey = new QueryTypeKey();

    queryTypeKey.queryType = QUERYTYPE.CASEQUERY;

    listQueriesForUserResult.dtls = queryObj.listUserQueries(queryTypeKey);

    return listQueriesForUserResult;
  }

  // _________________________________________________________________________
  /**
   * This method modifies a case query.
   *
   * @param details The case search criteria for a query.
   *
   * @return Modified case query id.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public QueryKey modify(CaseQueryDetails details) throws AppException,
      InformationalException {

    curam.core.sl.intf.CaseQuery caseQueryObj = curam.core.sl.fact.CaseQueryFactory.newInstance();

    return caseQueryObj.modify(details);
  }

  // _________________________________________________________________________
  /**
   * Reads case query name and case search criteria.
   *
   * @param key Case query identifier
   *
   * @return Case query name and saved case search criteria
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CaseQueryDetails read(QueryKey key)
    throws AppException, InformationalException {

    curam.core.sl.intf.CaseQuery caseQueryObj = curam.core.sl.fact.CaseQueryFactory.newInstance();

    return caseQueryObj.read(key);
  }

}
