/*
 * IBM Confidential
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2008, 2014
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office 
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import java.io.File;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.attachmentlink.struct.ListAttachmentLinkDetails;
import curam.codetable.ACTIONCONTROLID;
import curam.codetable.ATTACHMENTOBJECTLINKTYPE;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CONTACTLOGLINKTYPE;
import curam.codetable.CONTACTLOGPURPOSE;
import curam.codetable.CONTACTLOGTYPE;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.SENSITIVITY;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.struct.AttachmentWizardDetails;
import curam.core.facade.struct.CaseContextDescription;
import curam.core.facade.struct.CaseContextDescriptionKey;
import curam.core.facade.struct.ContactLogAttendeeByTypeList;
import curam.core.facade.struct.ContactLogCaseDetails;
import curam.core.facade.struct.ContactLogDetails;
import curam.core.facade.struct.ContactLogNarrativeDetails;
import curam.core.facade.struct.ContactLogPreviewIDKey;
import curam.core.facade.struct.ContactLogPreviewKey;
import curam.core.facade.struct.ContactLogWizardDetails;
import curam.core.facade.struct.ContactLogWizardMenuDetails;
import curam.core.facade.struct.DefaultContactLogDetails;
import curam.core.facade.struct.NarrativeTextWizardDetails;
import curam.core.facade.struct.ParticipantWizardDetails;
import curam.core.facade.struct.PreviewCaseContactLogIDKey;
import curam.core.facade.struct.PreviewCaseContactLogKey;
import curam.core.facade.struct.PreviewContactLogXMLDetails;
import curam.core.facade.struct.PurposeCode;
import curam.core.facade.struct.PurposeCodeList;
import curam.core.facade.struct.WizardDetails;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.fact.ContactLogLinkFactory;
import curam.core.sl.entity.intf.ContactLogLink;
import curam.core.sl.entity.struct.ContactLogAttendeeKey;
import curam.core.sl.entity.struct.ContactLogDtls;
import curam.core.sl.entity.struct.ContactLogIDRecordStatusKey;
import curam.core.sl.entity.struct.ContactLogKey;
import curam.core.sl.entity.struct.LinkIDAndLinkTypeDtlsList;
import curam.core.sl.fact.ContactLogAttendeeFactory;
import curam.core.sl.fact.ContactLogFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.intf.ContactLogAttendee;
import curam.core.sl.struct.CancelContactLogAttendeeDetails;
import curam.core.sl.struct.CancelContactLogDetails;
import curam.core.sl.struct.ContactLogIDLinkTypeKey;
import curam.core.sl.struct.CreateContactLogAttendeeDetails;
import curam.core.sl.struct.CreateContactLogAttendeeDetails1;
import curam.core.sl.struct.ModifyContactLogDetails;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.PreviewContactLogKey1;
import curam.core.sl.struct.PreviewContactLogWidgetDetails;
import curam.core.sl.struct.PreviewContactLogXMLData;
import curam.core.sl.struct.PrintContactLogWizardDetails;
import curam.core.sl.struct.PrintPreviewCaseContactLogKey;
import curam.core.sl.struct.PrintPreviewContactLogFileDetails;
import curam.core.sl.struct.PrintPreviewContactLogKey;
import curam.core.sl.struct.WizardStateID;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.message.BPOCASEEVENTS;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.wizardpersistence.impl.WizardPersistentState;


/**
 * This process class provides the functionality for the Contact Log facade
 * layer.
 */
public abstract class ContactLog extends curam.core.facade.base.ContactLog {

  // BEGIN, CR00119940, ZV
  // Add injection for using the new API
  protected final curam.core.sl.intf.ContactLog contactLogDatastore = ContactLogFactory.newInstance();

  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  public ContactLog() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00234804, PM
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END, CR00234804

  // ___________________________________________________________________________
  /**
   * Method to add an Attachment to a Contact Log.
   *
   * @param details
   * Contains the contact log id and attachment details
   *
   * @return The Attachment Link key
   */
  public AttachmentLinkKey addContactLogAttachment(
    AttachmentLinkDetails details) throws AppException,
      InformationalException {
    
    // BEGIN, CR00407868, SG
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = details.caseIDOpt;
    
    checkMaintainCaseSecurity(caseSecurityCheckKey);
    
    final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    participantSecurityCheckKey.participantID = details.attachmentLinkDtls.participantRoleID;
    
    checkMaintainParticipantSecurity(participantSecurityCheckKey);
    // END, CR00407868

    AttachmentLink attachmentLink = attachmentLinkDAO.newInstance();

    details.attachmentLinkDtls.relatedObjectType = ATTACHMENTOBJECTLINKTYPE.CONTACTLOG;
    details.attachmentLinkDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;

    // add contact log attachment
    attachmentLink.insert(details);

    // BEGIN, CR00241171, ZV
    // BEGIN, CR00234804, PM
    // Log Transaction Details.
    ContactLogLink contactLogLinkObj = ContactLogLinkFactory.newInstance();
    ContactLogIDRecordStatusKey contactLogIDRecordStatusKey = new ContactLogIDRecordStatusKey();

    contactLogIDRecordStatusKey.contactLogID = details.attachmentLinkDtls.relatedObjectID;
    LinkIDAndLinkTypeDtlsList linkIDAndLinkTypeDtlsList = contactLogLinkObj.searchActiveLinkIDAndTypeByContactLogID(
      contactLogIDRecordStatusKey);

    for (int i = 0; i < linkIDAndLinkTypeDtlsList.dtls.size(); i++) {

      if (linkIDAndLinkTypeDtlsList.dtls.item(i).linkType.equals(
        CONTACTLOGLINKTYPE.CASE)) {

        curam.core.sl.entity.intf.ContactLog contactLog = curam.core.sl.entity.fact.ContactLogFactory.newInstance();
        ContactLogKey contactLogKey = new ContactLogKey();

        contactLogKey.contactLogID = details.attachmentLinkDtls.relatedObjectID;
        ContactLogDtls contactLogDtls = contactLog.read(contactLogKey);

        CodeTableItemIdentifier codeTableItemIdentifier = new CodeTableItemIdentifier(
          CONTACTLOGTYPE.TABLENAME, contactLogDtls.contactLogType);

        LocalisableString description = new LocalisableString(BPOCASEEVENTS.CONTACT_ATTACHMENT_ADDED).arg(
          codeTableItemIdentifier);

        caseTransactionLogProvider.get().recordCaseTransaction(
          CASETRANSACTIONEVENTS.CONTACT_ATTACHMENT_ADDED, description,
          linkIDAndLinkTypeDtlsList.dtls.item(i).linkID,
          details.attachmentLinkDtls.attachmentLinkID);
      }

    }

    // END, CR00234804
    // END, CR00241171

    AttachmentLinkKey attachmentLinkKey = new AttachmentLinkKey();

    attachmentLinkKey.attachmentLinkID = attachmentLink.getID();

    return attachmentLinkKey;

  }

  // END, CR00119940

  // ___________________________________________________________________________
  /**
   * @param details
   * Contains the contact log id and the attendee details
   *
   * @return The Contact Log Attendee key
   * @deprecated Since Curam 6.0, replaced by
   * {@link #addContactLogAttendee1()}
   *
   * Method to add an Attendee to a Contact Log. New method passes
   * additional 'I am a Contact Participant' parameter to create
   * Contact Log Attendee.
   */
  @Deprecated
  public ContactLogAttendeeKey addContactLogAttendee(
    CreateContactLogAttendeeDetails details) throws AppException,
      InformationalException {

    // Contact Log Attendee service object and return key
    curam.core.sl.intf.ContactLogAttendee contactLogAttendeeObj = curam.core.sl.fact.ContactLogAttendeeFactory.newInstance();
    ContactLogAttendeeKey contactLogAttendeeKey = new ContactLogAttendeeKey();

    contactLogAttendeeKey = contactLogAttendeeObj.create(details);

    // return contact log attendee key
    return contactLogAttendeeKey;
  }

  // ___________________________________________________________________________
  /**
   * Method to cancel a Contact Log.
   *
   * @param details
   * Contains the Contact Log ID and version No
   */
  public void cancelContactLog(CancelContactLogDetails details)
    throws AppException, InformationalException {
    // Contact Log service object
    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    // cancel contact log
    contactLogObj.cancel(details);
  }

  // ___________________________________________________________________________
  /**
   * Method to modify the Contact Log details.
   *
   * @param details
   * Contains the contact log details to be updated
   */
  public void modifyContactLog(ModifyContactLogDetails details)
    throws AppException, InformationalException {
    // Contact Log service object
    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    // modify contact log details
    contactLogObj.modify1(details);
  }

  // BEGIN, CR00167103, SPD
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains the contact log ID
   *
   * @return The Contact Log preview notes details
   * @deprecated Since Curam 6.0, replaced by {@link #previewContactLog1()}
   *
   * Method to preview the Contact Log notes.
   */
  @Deprecated
  public curam.core.sl.struct.PreviewContactLogDetails previewContactLog(
    ContactLogKey key) throws AppException, InformationalException {

    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    return contactLogObj.preview(key);
  }

  // BEGIN, CR00120432, ZV
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains a list of contact log IDs and action control id
   *
   * @return The list of Contact Log preview notes details
   * @deprecated Since Curam 6.0, replaced by {@link #previewContactLogs1()}
   *
   * Method to preview a list of Contact Logs.
   */
  @Deprecated
  public PreviewContactLogWidgetDetails previewContactLogs(
    ContactLogPreviewKey key) throws AppException,
      InformationalException {

    // return preview details list variable
    PreviewContactLogWidgetDetails previewContactLogWidgetDetails = new PreviewContactLogWidgetDetails();

    if (key.actionControlID.equals(ACTIONCONTROLID.PREVIEW)) {

      // Contact Log service object
      curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

      // preview contact log list notes
      previewContactLogWidgetDetails = contactLogObj.getPreviewWidgetData(
        contactLogObj.previewList(key.key));

    }
    // return preview list
    return previewContactLogWidgetDetails;
  }

  // END, CR00120432

  // ___________________________________________________________________________
  /**
   * @param key
   * Contains the contact log ID
   *
   * @return The Contact Log details
   * @deprecated Since Curam 6.0, replaced by {@link #readContactLog1()}
   *
   * Method to read the Contact Log details.
   */
  @Deprecated
  public curam.core.sl.struct.ReadContactLogDetails readContactLog(
    ContactLogKey key) throws AppException, InformationalException {

    // The return struct
    curam.core.sl.struct.ReadContactLogDetails readContactLogDetailsSL = new curam.core.sl.struct.ReadContactLogDetails();

    curam.core.facade.struct.ReadContactLogDetails readContactLogDetails = new curam.core.facade.struct.ReadContactLogDetails();

    // Read contact log details
    readContactLogDetails = readContactLog1(key);

    // Populate return struct
    readContactLogDetailsSL.assign(readContactLogDetails.readDetails);

    return readContactLogDetailsSL;
    // END, CR00140531
  }

  // END, CR00167103

  // ___________________________________________________________________________
  // BEGIN, CR00140325, NP
  /**
   * Facade method to read Contact Log attachments given the specified contact
   * log identifier
   *
   * @param contactLogkey
   * contains the contact log identifier.
   * @return ListAttachmentLinkDetails list of attachments
   * @throws AppException
   * , InformationalException
   */
  public ListAttachmentLinkDetails readContactLogAttachments(
    ContactLogKey contactLogkey) throws AppException,
      InformationalException {

    ListAttachmentLinkDetails details = attachmentLinkDAO.newInstance().listAttachmentByRelatedObject(
      contactLogkey.contactLogID, ATTACHMENTOBJECTLINKTYPEEntry.CONTACTLOG);

    return details;

  }

  // END, CR00140325

  // ___________________________________________________________________________
  /**
   * Method to remove a Contact Log Attendee.
   *
   * @param key
   * Contains the Contact Log Attendee ID and version No
   */
  public void removeContactLogAttendee(CancelContactLogAttendeeDetails key)
    throws AppException, InformationalException {
    // Contact Log Attendee service object
    curam.core.sl.intf.ContactLogAttendee contactLogAttendeeObj = curam.core.sl.fact.ContactLogAttendeeFactory.newInstance();

    // cancel contact log attendee
    contactLogAttendeeObj.cancel(key);
  }

  // BEGIN, CR00167103, SPD
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains list of contact log ids
   *
   * @return The file name and document data
   * @deprecated Since Curam 6.0, replaced by
   * {@link #printPreviewContactLogs1()}
   *
   * Method to print preview list of Contact Logs.
   */
  @Deprecated
  public PrintPreviewContactLogFileDetails printPreviewContactLogs(
    PrintPreviewContactLogKey key) throws AppException,
      InformationalException {

    // return preview details variable
    PrintPreviewContactLogFileDetails previewContactLogDetailsFileList = new PrintPreviewContactLogFileDetails();

    // Contact Log service object
    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    // print preview contact log list notes
    previewContactLogDetailsFileList = contactLogObj.printPreviewList(key);

    // return preview list
    return previewContactLogDetailsFileList;
  }

  // END, CR00167103

  // BEGIN, CR00140531, CL
  // ___________________________________________________________________________
  /**
   * Method to read all enabled Contact Log Purpose codes from the code table
   *
   * @return A list of Contact Log Purpose code table codes and descriptions
   */
  public PurposeCodeList listPurpose() throws AppException,
      InformationalException {

    PurposeCodeList purposeCodeList = new PurposeCodeList();
    PurposeCode purposeCode = null;

    // Return the list of purpose codes
    LinkedHashMap purposeHashMap = CodeTable.getAllEnabledItems(
      CONTACTLOGPURPOSE.TABLENAME, TransactionInfo.getProgramLocale());

    if (!purposeHashMap.isEmpty()) {

      Set comKeys = purposeHashMap.keySet();

      Iterator itr = comKeys.iterator();

      while (itr.hasNext()) {
        String purposeCodeKey = itr.next().toString();

        purposeCode = new PurposeCode();
        purposeCode.purposeName = purposeHashMap.get(purposeCodeKey).toString();
        purposeCode.purposeCode = purposeCodeKey;
        purposeCodeList.list.add(purposeCode);

      }

    }

    return purposeCodeList;

  }

  // ___________________________________________________________________________
  /**
   * Method to read the Contact Log details for the modify screen.
   *
   * @param key
   * Contains the contact log ID
   *
   * @return The Contact Log details
   */
  public curam.core.facade.struct.ReadContactLogDetails readContactLogForModify(
    ContactLogKey key) throws AppException, InformationalException {

    // Return struct
    curam.core.facade.struct.ReadContactLogDetails readContactLogDetails = new curam.core.facade.struct.ReadContactLogDetails();

    // Contact Log service object
    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    // Read back the contact log details
    readContactLogDetails.readDetails = contactLogObj.read1(key);

    // return contact log details
    return readContactLogDetails;

  }

  // END, CR00140531

  // BEGIN, CR00161622, ZV
  // ___________________________________________________________________________
  /**
   * Method to get default Contact Log details used to create new Contact Log.
   *
   * @return The Default Contact Log details
   *
   * @deprecated Since Curam 6.0.5.0, replaced by {@link #getDefaultContactLogParticipant()
   *
   * This method is deprecated because it was used to display the current user as the contact log 
   * participant always. See release note: CR00349273
   */  
  @Deprecated
  public DefaultContactLogDetails getDefaultContactLogDetails()
    throws AppException, InformationalException {

    DefaultContactLogDetails defaultContactLogDetails = new DefaultContactLogDetails();

    defaultContactLogDetails.currentUserIsAttendeeInd = true;

    return defaultContactLogDetails;
  }

  // END, CR00161622

  // BEGIN, CR00243200, ZV
  // BEGIN, CR00167103, SPD
  // ___________________________________________________________________________
  /**
   * Method to preview the Contact Log notes.
   *
   * @param key
   * Contains the contact log ID
   *
   * @return The Contact Log preview notes details
   */
  public PreviewContactLogXMLData previewContactLog1(final ContactLogKey key)
    throws AppException, InformationalException {

    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();
    ContactLogIDLinkTypeKey contactLogIDLinkTypeKey = new ContactLogIDLinkTypeKey();

    contactLogIDLinkTypeKey.contactLogID = key.contactLogID;

    return contactLogObj.preview1(contactLogIDLinkTypeKey);

  }

  // END, CR00243200

  // ___________________________________________________________________________
  /**
   * Method to read the Contact Log details.
   *
   * @param key
   * Contains the contact log ID
   *
   * @return The Contact Log details
   */
  public curam.core.facade.struct.ReadContactLogDetails readContactLog1(
    ContactLogKey key) throws AppException, InformationalException {

    // The return struct
    curam.core.facade.struct.ReadContactLogDetails readContactLogDetails = new curam.core.facade.struct.ReadContactLogDetails();

    // Contact Log service object
    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();
    curam.core.sl.struct.ReadContactLogDetails readContactLogDetailsSL = new curam.core.sl.struct.ReadContactLogDetails();

    readContactLogDetails.readDetails = contactLogObj.read1(key);

    readContactLogDetailsSL.contactLogDetails.purpose = readContactLogDetails.readDetails.contactLogDetails.purpose;

    // Format the purpose field for display
    readContactLogDetailsSL = contactLogObj.formatContactLogPurpose(
      readContactLogDetailsSL);

    // Populate return struct with formatted purpose
    readContactLogDetails.readDetails.contactLogDetails.purpose = readContactLogDetailsSL.contactLogDetails.purpose;

    return readContactLogDetails;
  }

  // BEGIN, CR00388252, AC
  /**
   * Method to print preview list of Contact Logs.
   *
   * @param key
   * Contains list of contact log ids
   *
   * @return The file name and document data
   *
   * @deprecated and replaced by method
   * printContactLogs(PrintPreviewContactLogKey). This method
   * selects the contact log with key of fixed size so the size of
   * the key is increased. Since V6.0.4.4.see release notes of
   * CR00388252.
   */
  @Deprecated
  public curam.core.facade.struct.PrintPreviewContactLogFileDetails printPreviewContactLogs1(
    PrintPreviewContactLogKey key) throws AppException,
      InformationalException {

    // Return preview details variable
    curam.core.facade.struct.PrintPreviewContactLogFileDetails previewContactLogDetailsFileList = new curam.core.facade.struct.PrintPreviewContactLogFileDetails();

    // Contact Log service object
    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    // Print preview contact log list notes
    previewContactLogDetailsFileList.details = contactLogObj.printPreviewList1(
      key);

    return previewContactLogDetailsFileList;
  }

  // END, CR00388252
  /**
   * Method to preview a list of Contact Logs.
   *
   * @param key
   * Contains a list of contact log IDs and action control id
   *
   * @return The list of Contact Log preview notes details
   *
   * @deprecated and replaced by method previewCaseContactLogs(ContactLogPreviewIDKey).
   * This method selects the contact log with key of fixed size so the size of the key is increased.
   * since V6.0.5.0.see Release notes for CR00342633.
   */
  @Deprecated
  public PreviewContactLogXMLDetails previewContactLogs1(
    final ContactLogPreviewKey key) throws AppException,
      InformationalException {

    // return preview details list variable
    PreviewContactLogXMLDetails previewContactLogXMLDetails = new PreviewContactLogXMLDetails();

    if (key.actionControlID.equals(ACTIONCONTROLID.PREVIEW)) {

      // Contact Log service object
      curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();
      PreviewContactLogKey1 previewContactLogKey1 = new PreviewContactLogKey1();

      previewContactLogKey1.multiSelectStr = key.key.multiSelectStr;
      // BEGIN, CR00183167, ZV
      previewContactLogXMLDetails.dtls = contactLogObj.previewList1(
        previewContactLogKey1);
      // END, CR00183167

    }
    return previewContactLogXMLDetails;
  }

  // END, CR00167103
  // END, CR00243200
  // END, CR00342633
  // BEGIN, CR00175532, ZV
  // ___________________________________________________________________________
  /**
   * Method to add an Attendee to a Contact Log.
   *
   * @param details
   * Contains the contact log id and the attendee details
   *
   * @return The Contact Log Attendee key
   */
  public ContactLogAttendeeKey addContactLogAttendee1(
    CreateContactLogAttendeeDetails1 details) throws AppException,
      InformationalException {

    ContactLogAttendee contactLogAttendeeObj = ContactLogAttendeeFactory.newInstance();

    return contactLogAttendeeObj.create1(details);

  }

  // END, CR00175532

  // BEGIN, CR00226335, NRK
  // ___________________________________________________________________________
  /**
   * Stores the contact details of the contact log wizard in the Wizard
   * persistence cache.
   *
   * @param contactLogWizardDetails
   * Wizard details(contact details) to be cached in
   * WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00233604,NRK
  public WizardStateID createContact(
    ContactLogWizardDetails contactLogWizardDetails)
    throws AppException, InformationalException {

    WizardStateID wizardStateID = new WizardStateID();
    curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory.newInstance();
    WizardDetails wizardDetails = new WizardDetails();

    wizardStateID.wizardStateID = contactLogWizardDetails.wizardStateID;
    wizardDetails = readWizardDetails(wizardStateID);
    wizardDetails.wizardDetails.contactDetails.assign(
      contactLogWizardDetails.contactLogWizardDetails);
    if (CuramConst.kStoreAction.equals(contactLogWizardDetails.actionString)) {
      wizardDetails.wizardDetails.contactDetails.wizardStateID = contactLogWizardDetails.wizardStateID;
      wizardStateID = contactLogObj.storeContactDetails(
        wizardDetails.wizardDetails);
    }
    return wizardStateID;
  }

  // END, CR00233604

  // ___________________________________________________________________________
  /**
   * Retrieves Wizard details from the WizardPersistentState.
   *
   * @param wizardStateID
   * Wizard state ID.
   *
   * @return wizard details cached in the wizard persistent state.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00228358,NRK
  public WizardDetails readWizardDetails(WizardStateID wizardStateID)
    throws AppException, InformationalException {
    curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory.newInstance();
    WizardDetails wizardDetails = new WizardDetails();

    if (wizardStateID.wizardStateID != 0) {
      wizardStateID.wizardStateID = wizardStateID.wizardStateID;
      wizardDetails.wizardDetails = contactLogObj.readWizardDetails(
        wizardStateID);
    }
    
    wizardDetails.wizardMenu = CuramConst.kCreateContactLogWizard;
    return wizardDetails;
  }

  // END, CR00228358
  /**
   * Reads the wizard menu properties
   *
   * @param wizardStateID
   * WizardState ID.
   *
   * @return The wizard properties containing the wizard menu details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ContactLogWizardMenuDetails readWizardMenu(
    WizardStateID wizardStateID) throws AppException,
      InformationalException {
    ContactLogWizardMenuDetails contactLogWizardMenuDetails = new ContactLogWizardMenuDetails();

    if (wizardStateID.wizardStateID == 0) {
      contactLogWizardMenuDetails.wizardMenu = CuramConst.kCreateContactLogWizard;
    } else {
      contactLogWizardMenuDetails.wizardMenu = CuramConst.kModifyContactLogWizard;
    }
    return contactLogWizardMenuDetails;
  }

  /**
   * Stores Attachment details of the contact log wizard in the wizard
   * persistence cache.
   *
   * @param attachmentWizardDetails
   * Wizard details updated with Attachment details and cached in
   * WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ContactLogKey storeAttachmentDetails(
    AttachmentWizardDetails attachmentWizardDetails)
    throws AppException, InformationalException {
    ContactLogKey contactLogKey = new ContactLogKey();
    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = attachmentWizardDetails.attachmentWizardDetails.wizardStateID;
    curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory.newInstance();
    WizardDetails wizardDetails = readWizardDetails(wizardStateID);

    // BEGIN, CR00407842, KRK
    wizardDetails.wizardDetails.attachmentDetails.assign(
      attachmentWizardDetails.attachmentWizardDetails);
    // END, CR00407842
    
    if (CuramConst.kBackAction.equals(attachmentWizardDetails.actionString)) {

      wizardStateID = contactLogObj.storeAttachments(
        wizardDetails.wizardDetails);
    } else if (CuramConst.kSaveAction.equals(
      attachmentWizardDetails.actionString)) {
      wizardStateID = contactLogObj.storeAttachments(
        wizardDetails.wizardDetails);
      contactLogKey = contactLogObj.insertWizardDetails(wizardStateID);
      if (contactLogKey.contactLogID == 0) {
        contactLogKey.contactLogID = wizardStateID.wizardStateID;
      }
    }
    return contactLogKey;
  }

  /**
   * Stores Narrative text of the contact log wizard in the wizard persistence
   * cache.
   *
   * @param narrativeTextWizardDetails
   * Wizard details updated with narrative details and cached in
   * WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ContactLogKey storeNarrativeText(
    NarrativeTextWizardDetails narrativeTextWizardDetails)
    throws AppException, InformationalException {
    ContactLogKey contactLogKey = new ContactLogKey();
    curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory.newInstance();
    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = narrativeTextWizardDetails.narrativeTextWizardDetails.wizardStateID;
    WizardDetails wizardDetails = readWizardDetails(wizardStateID);

    wizardDetails.wizardDetails.narrativeDetails.assign(
      narrativeTextWizardDetails.narrativeTextWizardDetails);
    if ((CuramConst.kNextAction.equals(narrativeTextWizardDetails.actionString))
      || (CuramConst.kBackAction.equals(narrativeTextWizardDetails.actionString))) {
      wizardStateID = contactLogObj.storeNarrativeText(
        wizardDetails.wizardDetails);
    } else if (CuramConst.kSaveAction.equals(
      narrativeTextWizardDetails.actionString)) {
      contactLogObj.storeNarrativeText(wizardDetails.wizardDetails);
      contactLogKey = contactLogObj.insertWizardDetails(wizardStateID);
      if (contactLogKey.contactLogID == 0) {
        contactLogKey.contactLogID = wizardStateID.wizardStateID;
      }
    }
    return contactLogKey;
  }

  /**
   * Stores Participant details of the contact log wizard in the wizard
   * persistence cache.
   *
   * @param participantWizardDetails
   * Wizard details updated with Participant details and cached in
   * WizardPersistentState.
   *
   * @return Contact log reference id.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ContactLogKey storeParticipantsDetails(
    ParticipantWizardDetails participantWizardDetails)
    throws AppException, InformationalException {
    ContactLogKey contactLogKey = new ContactLogKey();
    WizardStateID wizardStateID = new WizardStateID();
    curam.core.sl.intf.ContactLog contactLogObj = ContactLogFactory.newInstance();

    wizardStateID.wizardStateID = participantWizardDetails.participantWizardDetails.wizardStateID;
    WizardDetails wizardDetails = readWizardDetails(wizardStateID);

    wizardDetails.wizardDetails.participantDetails.assign(
      participantWizardDetails.participantWizardDetails);
    if ((CuramConst.kNextAction.equals(participantWizardDetails.actionString))
      || (CuramConst.kBackAction.equals(participantWizardDetails.actionString))) {
      wizardStateID = contactLogObj.storeParticipantsDetails(
        wizardDetails.wizardDetails);
    } else if (CuramConst.kSaveAction.equals(
      participantWizardDetails.actionString)) {
      contactLogObj.storeParticipantsDetails(wizardDetails.wizardDetails);
      contactLogKey = contactLogObj.insertWizardDetails(wizardStateID);
      if (contactLogKey.contactLogID == 0) {
        contactLogKey.contactLogID = wizardStateID.wizardStateID;
      }
    }
    return contactLogKey;
  }

  // END, CR00226335

  // BEGIN, CR00119940, ZV
  // ___________________________________________________________________________
  /**
   * Method to read contact log concern role and user attendees in separate
   * lists.
   *
   * @param key
   * Contact log key
   *
   * @return The two separate lists for contact concern role and user details
   */
  public ContactLogAttendeeByTypeList listContactLogAttendee(
    final ContactLogKey key) throws AppException,
      InformationalException {

    ContactLogAttendeeByTypeList contactLogAttendeeByTypeList = new ContactLogAttendeeByTypeList();

    ContactLogAttendee contactLogAttendeeObj = ContactLogAttendeeFactory.newInstance();

    contactLogAttendeeByTypeList.userList = contactLogAttendeeObj.listUser1(key);

    contactLogAttendeeByTypeList.concernRoleList = contactLogAttendeeObj.listConcernRole(
      key);

    return contactLogAttendeeByTypeList;
  }

  // ___________________________________________________________________________
  /**
   * Method to read contact log narrative details.
   *
   * @param key
   * Contact log key
   *
   * @return The contact log narrative details
   */
  public ContactLogNarrativeDetails readContactLogNarrative(
    final ContactLogKey key) throws AppException,
      InformationalException {

    ContactLogNarrativeDetails contactLogNarrativeDetails = new ContactLogNarrativeDetails();

    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    contactLogNarrativeDetails.dtls = contactLogObj.readNarrative(key);

    return contactLogNarrativeDetails;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00348376, AC
  /**
   * Method to read contact log tab details.
   *
   * @param key
   * Contact log key
   *
   * @return The contact log tab details
   * @deprecated and replaced by method readContactLogCaseDetails(ContactLogKey).
   * The method returns contact log details with create date as date.
   * since V6.0.5.0.see Release notes for CR00348376.
   */
  @Deprecated
  public ContactLogDetails readContactLogDetails(final ContactLogKey key)
    throws AppException, InformationalException {

    ContactLogDetails contactLogDetails = new ContactLogDetails();

    curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    contactLogDetails.dtls = contactLogObj.readDetails(key);

    return contactLogDetails;
  }

  // END, CR00348376
  // BEGIN, CR00342633, AC
  /**
   * Method to preview a list of Contact Logs.
   *
   * @param key to read the preview ContactLog details.
   *
   * @return the preview Contact Log list.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public PreviewContactLogXMLDetails previewCaseContactLogs(
    final ContactLogPreviewIDKey contactLogPreviewIDKey) throws AppException,
      InformationalException {
    final PreviewContactLogXMLDetails previewContactLogXMLDetails = new PreviewContactLogXMLDetails();

    final curam.core.sl.struct.PreviewCaseContactLogKey previewContactLogKey = new
      curam.core.sl.struct.PreviewCaseContactLogKey();

    previewContactLogKey.multiSelectStr = contactLogPreviewIDKey.dtls.multiSelectStr;
    previewContactLogXMLDetails.dtls = curam.core.sl.fact.ContactLogFactory.newInstance().previewContactLogList(
      previewContactLogKey);
    return previewContactLogXMLDetails;

  }

  /**
   * Method to print preview list of Contact Logs.
   *
   * @param key
   * Contains list of contact log print key.
   *
   * @return The file name and document data.
   *
   * @throws AppException.
   * Generic  Exception Signature.
   * @throws InformatinalException.
   * Generic Exception Signature.
   */
  public curam.core.facade.struct.PrintPreviewContactLogFileDetails printContactLogs(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    curam.core.facade.struct.PrintPreviewContactLogFileDetails previewContactLogDetailsFileList = new
      curam.core.facade.struct.PrintPreviewContactLogFileDetails();
    PrintContactLogWizardDetails printContactLogWizardDetails = new PrintContactLogWizardDetails();
    WizardPersistentState wizardPersistentStateObj = new WizardPersistentState();

    printContactLogWizardDetails = (PrintContactLogWizardDetails) wizardPersistentStateObj.read(
      wizardStateID.wizardStateID);

    printContactLogWizardDetails.wizardStateID = wizardStateID.wizardStateID;
    previewContactLogDetailsFileList = setPrintContactDetails(
      printContactLogWizardDetails);
    return previewContactLogDetailsFileList;
  }

  /**
   * Gets the print log details.
   *
   * @param PreviewCaseContactLogIDKey to get the Preview list
   * @return PrintContactLogWizardDetails for the temporary storage of print log details
   *
   * @throws AppException
   * @throws InformationalException
   */
  public PrintContactLogWizardDetails getPrintContactLogDetails(
    PreviewCaseContactLogIDKey previewCaseContactLogIDkey) throws AppException,
      InformationalException {
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = previewCaseContactLogIDkey.casekey.caseID;
    WizardPersistentState wizardPersistentState = new WizardPersistentState();
    final PrintContactLogWizardDetails printContactLogWizardDetails = new PrintContactLogWizardDetails();
    CaseContextDescription caseContextDescription = CaseFactory.newInstance().readCaseContextDescription(
      caseContextDescriptionKey);

    printContactLogWizardDetails.description = caseContextDescription.description;
    printContactLogWizardDetails.multiSelectString = previewCaseContactLogIDkey.dtls.multiSelectStr;
    printContactLogWizardDetails.wizardStateID = wizardPersistentState.create(
      printContactLogWizardDetails);

    return printContactLogWizardDetails;

  }

  /**
   * Sets the print log details.
   *
   * @param PreviewCaseContactLogIDKey to get the Preview list
   * @return PrintContactLogWizardDetails for the temporary storage of print log details
   *
   * @throws AppException
   * @throws InformationalException
   */
  public curam.core.facade.struct.PrintPreviewContactLogFileDetails setPrintContactDetails(
    final PrintContactLogWizardDetails printContactLogWizardDetails) throws AppException,
      InformationalException {
    final curam.core.facade.struct.PrintPreviewContactLogFileDetails printPreviewContactLogFileDetails = new curam.core.facade.struct.PrintPreviewContactLogFileDetails();
    final WizardPersistentState wizardPersistentStateObj = new WizardPersistentState();
    final WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = printContactLogWizardDetails.wizardStateID;
    if (wizardStateID.wizardStateID != 0) {
      wizardPersistentStateObj.remove(wizardStateID.wizardStateID);
    }
    final PrintPreviewCaseContactLogKey printContactLogKey = new PrintPreviewCaseContactLogKey();

    // BEGIN, CR00348506, AC
    printContactLogKey.description = printContactLogWizardDetails.description;
    // END, CR00348506
    printContactLogKey.dtls.multiSelectStr = printContactLogWizardDetails.multiSelectString;
    printPreviewContactLogFileDetails.details = curam.core.sl.fact.ContactLogFactory.newInstance().printPreviewContactLogListDetails(
      printContactLogKey);

    return printPreviewContactLogFileDetails;

  }

  // END, CR00342633
  // BEGIN, CR00348376, AC
  /**
   * Reads contact log tab details.
   *
   * @param key Contact log key
   *
   * @return The contact log tab details
   */
  public ContactLogCaseDetails readContactLogCaseDetails(final ContactLogKey contactLogKey)
    throws AppException, InformationalException {

    final ContactLogCaseDetails contactLogCaseDetails = new ContactLogCaseDetails();

    contactLogCaseDetails.dtls = ContactLogFactory.newInstance().readContactLogDetails(
      contactLogKey);

    return contactLogCaseDetails;
  }

  // END, CR00348376

  // BEGIN, CR00349273, DJ
  /**
   * Determines if the current user is a participant for the contact log or not. For the first time
   * it will be set as true and later on wards the value is set based on the user inputs.
   *
   * @param wizardStateID contains the wizard state id.
   *
   * @return The value which indicates if the current user is the participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public DefaultContactLogDetails getDefaultContactLogParticipant(curam.core.facade.struct.WizardStateID wizardStateID) throws AppException, InformationalException {

    final DefaultContactLogDetails defaultContactLogDetails = new DefaultContactLogDetails();
    final WizardPersistentState wizardPersistentStateobj = new WizardPersistentState();
    curam.core.sl.struct.WizardDetails wizardDetails = new curam.core.sl.struct.WizardDetails();

    wizardDetails = (curam.core.sl.struct.WizardDetails) wizardPersistentStateobj.read(
      wizardStateID.wizardStateID);

    if ((wizardDetails.participantDetails.currentUserIsAttendeeInd == false
      && wizardDetails.participantDetails.caseParticipantRoleIDTabList.isEmpty()
      && wizardDetails.participantDetails.concernRoleName.isEmpty()
      && wizardDetails.participantDetails.participantName.isEmpty()
      && wizardDetails.participantDetails.userName.isEmpty())
        || (wizardDetails.participantDetails.currentUserIsAttendeeInd == true)) {
      defaultContactLogDetails.currentUserIsAttendeeInd = true;
    } else if (!(wizardDetails.participantDetails.caseParticipantRoleIDTabList.isEmpty()
      || wizardDetails.participantDetails.concernRoleName.isEmpty()
      || wizardDetails.participantDetails.participantName.isEmpty()
      || wizardDetails.participantDetails.userName.isEmpty())) {
      defaultContactLogDetails.currentUserIsAttendeeInd = false;
    }

    return defaultContactLogDetails;
  }

  // END, CR00349273

  // BEGIN, CR00407868, SG
  /**
   * Checks if the user has maintain rights on the case.
   *
   * @param key ID of the case that is being checked.
   *
   * @throws AppException
   * (GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS) if the user has read
   * only privilege.
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException
   * (GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS) if the user
   * does not have any privilege.
   */
  public void checkMaintainCaseSecurity(final CaseSecurityCheckKey key)
    throws AppException, InformationalException {
    
    if (0 != key.caseID) {
    
      final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
      
      key.type = DataBasedSecurity.kMaintainSecurityCheck;
  
      final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
        key);
  
      if (!dataBasedSecurityResult.result) {
        if (dataBasedSecurityResult.readOnly) {
          ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS), 
            ValidationManagerConst.kSetOne, 2);
        } else if (dataBasedSecurityResult.restricted) {
          ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS), 
            ValidationManagerConst.kSetOne, 2);
        } else {
          ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS), 
            ValidationManagerConst.kSetOne, 2);
        }
      }
      
    }

  }
  
  /**
   * Checks if the user has maintain rights on the participant.
   *
   * @param key ID of the participant that is being checked.
   *
   * @throws AppException
   * (GENERALCONCERN.ERR_CONCERNROLE_FV_NOMINEE_SENSITIVITY) if the user does 
   * not have the required privilege.
   * @throws InformationalException Generic Exception Signature. 
   */
  public void checkMaintainParticipantSecurity(final ParticipantSecurityCheckKey key)
    throws AppException, InformationalException {
    
    if (0 != key.participantID) {
      final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
      
      key.type = LOCATIONACCESSTYPE.MAINTAIN;
  
      final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
        key);
  
      if (!dataBasedSecurityResult.result) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            GENERALCONCERN.ERR_CONCERNROLE_FV_NOMINEE_SENSITIVITY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }
    }

  }  
  // END, CR00407868
}
