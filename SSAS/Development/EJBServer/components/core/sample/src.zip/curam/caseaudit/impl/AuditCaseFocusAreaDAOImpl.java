/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.Comparator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.google.inject.Singleton;

import curam.caseaudit.entity.impl.AuditCaseFocusAreaAdapter;
import curam.caseaudit.entity.struct.AuditCaseFocusAreaDtls;
import curam.codetable.AUDITCASEFOCUSAREA;
import curam.codetable.impl.AUDITCASEFOCUSAREAEntry;
import curam.core.impl.CuramConst;
import curam.message.BPOAUDITCASEFOCUSAREADAO;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;


/**
 * Data access Implementation for {@linkplain curam.caseaudit.impl.AuditCaseFocusArea}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditCaseFocusAreaDAO
 */
@Singleton
// BEGIN, CR00183334, PS
public class AuditCaseFocusAreaDAOImpl extends StandardDAOImpl<AuditCaseFocusArea, AuditCaseFocusAreaDtls> implements
  AuditCaseFocusAreaDAO {
  // END, CR00183334
  protected static final AuditCaseFocusAreaAdapter adapter = new AuditCaseFocusAreaAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected AuditCaseFocusAreaDAOImpl() {
    // END, CR00183334
    super(adapter, AuditCaseFocusArea.class);
  }

  // ___________________________________________________________________________
  /**
   * SortByFocusArea Comparator.
   */
  protected class SortByFocusAreaComparator 
    implements Comparator<AuditCaseFocusArea> {

    public SortByFocusAreaComparator() {// None required
    }

    // ___________________________________________________________________________
    /**
     * Sort based on focus area.
     */
    public int compare(final AuditCaseFocusArea o1, 
      final AuditCaseFocusArea o2) {
        
      String auditCaseFocusArea1 = CuramConst.gkEmpty;
      String auditCaseFocusArea2 = CuramConst.gkEmpty;

      try {
        auditCaseFocusArea1 = curam.util.type.CodeTable.getOneItem(
          AUDITCASEFOCUSAREA.TABLENAME, o1.getFocusArea().getCode());
        auditCaseFocusArea2 = curam.util.type.CodeTable.getOneItem(
          AUDITCASEFOCUSAREA.TABLENAME, o2.getFocusArea().getCode());
      } catch (AppException app) {
        
        AppException ae = new AppException(
          BPOAUDITCASEFOCUSAREADAO.ERR_SORTING_BY_FOCUS_AREAS, app);

        throw new AppRuntimeException(ae);
         
      } catch (InformationalException inf) {
         
        AppException ae = new AppException(
          BPOAUDITCASEFOCUSAREADAO.ERR_SORTING_BY_FOCUS_AREAS, inf);

        throw new AppRuntimeException(ae);         
      }

      return auditCaseFocusArea1.compareTo(auditCaseFocusArea2);          
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public SortedSet<AuditCaseFocusArea> searchBy(
    final AuditCaseConfig auditCaseConfig) {
    
    SortedSet<AuditCaseFocusArea> auditCaseFocusAreas = new TreeSet<AuditCaseFocusArea>(
      new SortByFocusAreaComparator());

    Set<AuditCaseFocusArea> focusAreas = newSet(
      adapter.searchByAuditCaseConfig(auditCaseConfig.getID()));
    
    for (AuditCaseFocusArea auditCaseFocusArea : focusAreas) {
      auditCaseFocusAreas.add(auditCaseFocusArea);
    }
        
    return auditCaseFocusAreas;
  }
  
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<AuditCaseFocusArea> searchByAuditCaseConfigAndFocusArea(
    final AuditCaseConfig auditCaseConfig, 
    final AUDITCASEFOCUSAREAEntry focusAreaCode) {
    
    return newSet(
      adapter.searchByAuditCaseConfigAndFocusArea(auditCaseConfig.getID(),
      focusAreaCode.getCode()));

  }

}
