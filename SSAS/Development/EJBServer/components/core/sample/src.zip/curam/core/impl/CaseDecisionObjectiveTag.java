/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.text.DecimalFormatSymbols;
import java.util.Locale;

import curam.codetable.RULESTAGTYPE;
import curam.core.struct.CaseDecisionObjectiveTagDtls;
import curam.core.struct.CaseDecisionObjectiveTagDtlsList;
import curam.core.struct.CaseDecisionObjectiveTagKey;
import curam.core.struct.ReadByObjIDCaseDecIDKey;
import curam.core.struct.SearchTagsByCaseDecisionKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.ProgramLocale;
import curam.util.rules.FixedNumericFormatConversion;


/**
 * Maintenance class for case decision objective tag.
 */
public abstract class CaseDecisionObjectiveTag extends curam.core.base.CaseDecisionObjectiveTag {

  // ___________________________________________________________________________
  /**
   * This method is responsible for converting a <code>MONEY</code> objective
   * tag amount from its localized format back into the EN format for storage.
   *
   * @param details Case decision objective tag entity data for insert.
   */
  protected void preinsert(final CaseDecisionObjectiveTagDtls details)
    throws AppException, InformationalException {

    /*
     * If this is a MONEY tag. The value specified will have been localized.
     * It must be stored in the EN locale format, so it may need to be
     * converted here.
     */
    if (details.type.equalsIgnoreCase(RULESTAGTYPE.MONEY)) {

      // This is the locale used by the Money class to localize the amount
      Locale defaultLocale = ProgramLocale.parseLocale(
        ProgramLocale.getDefaultServerLocale());

      DecimalFormatSymbols defaultSymbols = new DecimalFormatSymbols(
        defaultLocale);
      String defGroupingSeparator = String.valueOf(
        defaultSymbols.getGroupingSeparator());
      DecimalFormatSymbols englishSymbols = new DecimalFormatSymbols(
        Locale.ENGLISH);

      String stringValue = details.value;

      // Replace grouping separator(s) with empty string(s)
      stringValue = stringValue.replace(defGroupingSeparator,
        CuramConst.gkEmpty);
      // Replace decimal separator with EN decimal separator
      stringValue = stringValue.replace(defaultSymbols.getDecimalSeparator(),
        englishSymbols.getDecimalSeparator());

      details.value = stringValue;
    }
  }

  // ___________________________________________________________________________
  /**
   * This method is responsible for converting a <code>MONEY</code> objective
   * tag amount from the EN format back into its localized format.
   *
   * @param details Case decision objective tag entity data for insert.
   */
  protected void postinsert(CaseDecisionObjectiveTagDtls details)
    throws AppException, InformationalException {
  
    if (details.type.equals(RULESTAGTYPE.MONEY)) {
      details.value = FixedNumericFormatConversion.convertEnglishFormatToMoney(details.value).toString();
    }
  }

  // ___________________________________________________________________________
  /**
   * This method is responsible for converting a <code>MONEY</code> objective
   * tag amount from the EN format back into its localized format.
   *
   * @param key Contains the unique ID of the tag.
   * @param result Case decision objective tag entity data retrieved.
   */
  protected void postread(final CaseDecisionObjectiveTagKey key, 
    final CaseDecisionObjectiveTagDtls result) 
    throws AppException, InformationalException {
    
    if (result.type.equals(RULESTAGTYPE.MONEY)) {
      result.value = FixedNumericFormatConversion.convertEnglishFormatToMoney(result.value).toString();
    }
  }

  // ___________________________________________________________________________
  /**
   * This method is responsible for converting a <code>MONEY</code> objective
   * tag amount from the EN format back into its localized format.
   *
   * @param key Contains the unique ID of the tag.
   * @param result List of case decision objective tag entity data retrieved.
   */
  protected void postsearchByCaseDecisionID(final SearchTagsByCaseDecisionKey key,
    final CaseDecisionObjectiveTagDtlsList result)
    throws AppException, InformationalException {

    for (int i = 0; i < result.dtls.size(); i++) {
      if (result.dtls.item(i).type.equals(RULESTAGTYPE.MONEY)) {
        result.dtls.item(i).value = FixedNumericFormatConversion.convertEnglishFormatToMoney(result.dtls.item(i).value).toString();
      }
    }
  }
  
  // ___________________________________________________________________________
  /**
   * This method is responsible for converting a <code>MONEY</code> objective
   * tag amount from its localized format back into the EN format for storage.
   *
   * @param key Contains the unique ID of the tag.
   * @param details Case decision objective tag entity data for update.
   */
  protected void premodify(final CaseDecisionObjectiveTagKey key,
    final CaseDecisionObjectiveTagDtls details)
    throws AppException, InformationalException {

    /*
     * If this is a MONEY tag. The value specified will have been localized.
     * It must be stored in the EN locale format, so it may need to be
     * converted here.
     */
    if (details.type.equalsIgnoreCase(RULESTAGTYPE.MONEY)) {

      // This is the locale used by the Money class to localize the amount
      Locale defaultLocale = ProgramLocale.parseLocale(
        ProgramLocale.getDefaultServerLocale());

      DecimalFormatSymbols defaultSymbols = new DecimalFormatSymbols(
        defaultLocale);
      String defGroupingSeparator = String.valueOf(
        defaultSymbols.getGroupingSeparator());
      DecimalFormatSymbols englishSymbols = new DecimalFormatSymbols(
        Locale.ENGLISH);

      String stringValue = details.value;

      // Replace grouping separator(s) with empty string(s)
      stringValue = stringValue.replace(defGroupingSeparator,
        CuramConst.gkEmpty);
      // Replace decimal separator with EN decimal separator
      stringValue = stringValue.replace(defaultSymbols.getDecimalSeparator(),
        englishSymbols.getDecimalSeparator());

      details.value = stringValue;
    }
  }

  // ___________________________________________________________________________
  /**
   * This method is responsible for converting a <code>MONEY</code> objective
   * tag amount from the EN format back into its localized format.
   *
   * @param key Contains the unique ID of the tag.
   * @param details Case decision objective tag entity data for update.
   */
  protected void postmodify(final CaseDecisionObjectiveTagKey key,
    final CaseDecisionObjectiveTagDtls details)
    throws AppException, InformationalException {
    
    if (details.type.equals(RULESTAGTYPE.MONEY)) {
      details.value = FixedNumericFormatConversion.convertEnglishFormatToMoney(details.value).toString();
    }
  }

  // ___________________________________________________________________________
  /**
   * This method is responsible for converting a <code>MONEY</code> objective
   * tag amount from the EN format back into its localized format.
   *
   * @param key Contains the unique ID of the tag.
   * @param result List of case decision objective tag entity data retrieved.
   */
  protected void postreadByObjIDAndCaseDecisionID(
    final ReadByObjIDCaseDecIDKey key, final CaseDecisionObjectiveTagDtlsList result)
    throws AppException, InformationalException {

    for (int i = 0; i < result.dtls.size(); i++) {
      if (result.dtls.item(i).type.equals(RULESTAGTYPE.MONEY)) {
        result.dtls.item(i).value = FixedNumericFormatConversion.convertEnglishFormatToMoney(result.dtls.item(i).value).toString();
      }
    }
  }

}
