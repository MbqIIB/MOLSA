/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2003, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.bihelper.sl.impl.BIHelper;
import curam.cefwidgets.docbuilder.impl.WidgetDocumentBuilder;
import curam.codetable.ACTIONCONTROLID;
import curam.codetable.ACTIVITYATTENDEETYPE;
import curam.codetable.BUSINESSSTATUS;
import curam.codetable.CASECANCELREASON;
import curam.codetable.CASECLOSEREASON;
import curam.codetable.CASEDECISIONINITREASONCODE;
import curam.codetable.CASEDEDHISTORYSTATUS;
import curam.codetable.CASEREACTIVATEREASON;
import curam.codetable.CASESTATUS;
import curam.codetable.CASESUSPENDREASON;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUNSUSPENDREASON;
import curam.codetable.DEDUCTIONCATEGORYCODE;
import curam.codetable.DEDUCTIONITEMTYPE;
import curam.codetable.DEDUCTIONTYPECODE;
import curam.codetable.EVIDENCETREESTATUS;
import curam.codetable.ILISTATUS;
import curam.codetable.REJECTIONREASON;
import curam.codetable.RULESCOMPONENTTYPE;
import curam.codetable.impl.REASSESSMENTRESULTEntry;
import curam.core.facade.fact.FinancialFactory;
import curam.core.facade.fact.ResourceFactory;
import curam.core.facade.infrastructure.assessment.fact.CaseDeterminationFactory;
import curam.core.facade.infrastructure.assessment.struct.CaseDeterminationDecisionDetailsList;
import curam.core.facade.intf.Resource;
import curam.core.facade.struct.ActivateCaseKey_fo;
import curam.core.facade.struct.ActivityAttendeeTypeDescList;
import curam.core.facade.struct.ActivityAttendeeTypeDescription;
import curam.core.facade.struct.BIReportDetails;
import curam.core.facade.struct.BenefitOverpaymentEvidenceResult;
import curam.core.facade.struct.BenefitStatementDetails;
import curam.core.facade.struct.BenefitStatementDetailsList;
import curam.core.facade.struct.BenefitStatementKey;
import curam.core.facade.struct.BenefitUnderpmtHomePageDetails;
import curam.core.facade.struct.BenefitUnderpmtHomePageDetails1;
import curam.core.facade.struct.CancelCertificationKey;
import curam.core.facade.struct.CancelDeductionKey;
import curam.core.facade.struct.CaseAppliedDeductionHistoryDetailsList;
import curam.core.facade.struct.CaseAppliedDeductionHistoryDetailsList1;
import curam.core.facade.struct.CaseDeductionHistoryListKey;
import curam.core.facade.struct.CaseFinancialDetails;
import curam.core.facade.struct.CaseIDKey;
import curam.core.facade.struct.CaseKey_fo;
import curam.core.facade.struct.CaseStatusHistory;
import curam.core.facade.struct.CaseStatusKey;
import curam.core.facade.struct.CaseStatusReasonCode;
import curam.core.facade.struct.CaseStatusReasonDescription;
import curam.core.facade.struct.CaseThirdPartyDeductionHistoryDetailsList;
import curam.core.facade.struct.CaseThirdPartyDeductionHistoryDetailsList1;
import curam.core.facade.struct.CaseUnappliedDeductionHistoryDetailsList;
import curam.core.facade.struct.CaseUnappliedDeductionHistoryDetailsList1;
import curam.core.facade.struct.CertificationCaseIDKey;
import curam.core.facade.struct.CertificationFrequencyDetails;
import curam.core.facade.struct.CheckEligibilityCaseDeterminationDetails;
import curam.core.facade.struct.CheckEligibilityDetails;
import curam.core.facade.struct.CheckForWaiverIndicators;
import curam.core.facade.struct.CloseCaseDetails;
import curam.core.facade.struct.ClosureDetails;
import curam.core.facade.struct.CompareDecisionEvidenceKey;
import curam.core.facade.struct.CompareDecisionEvidenceResult;
import curam.core.facade.struct.CompareRuleEvidenceKey;
import curam.core.facade.struct.CompareRuleEvidenceResult;
import curam.core.facade.struct.CreateAssessmentDeliveryDetails;
import curam.core.facade.struct.CreateAssessmentDeliveryKey;
import curam.core.facade.struct.CreateCaseDetails;
import curam.core.facade.struct.CreateCertificationDetails;
import curam.core.facade.struct.CreateDeductionDetails;
import curam.core.facade.struct.CreateDeductionDetails1;
import curam.core.facade.struct.CreateUtilityPaymentDetails;
import curam.core.facade.struct.CreatedCaseIDKey;
import curam.core.facade.struct.DateDetails;
import curam.core.facade.struct.DeductionActivationDetails;
import curam.core.facade.struct.DeductionCategory;
import curam.core.facade.struct.DeductionClientDetails;
import curam.core.facade.struct.DeductionItemKeyVersionNo;
import curam.core.facade.struct.DeductionList;
import curam.core.facade.struct.DeductionListDetails;
import curam.core.facade.struct.DeductionNameCaseID;
import curam.core.facade.struct.DeductionNameList;
import curam.core.facade.struct.DeductionNameListDetails;
import curam.core.facade.struct.DefaultDeductionDetails;
import curam.core.facade.struct.DefaultDeductionKey;
import curam.core.facade.struct.EvaluateCaseResult;
import curam.core.facade.struct.EventDetails;
import curam.core.facade.struct.EvidenceDetails;
import curam.core.facade.struct.FixedDeductionDetails;
import curam.core.facade.struct.FixedDeductionDetails1;
import curam.core.facade.struct.GeneratePaymentKey;
import curam.core.facade.struct.ICInvestigationDeliveryClientRoleList;
import curam.core.facade.struct.ICProductDeliveryMenuDataDetails;
import curam.core.facade.struct.ICProductDeliveryMenuDataKey;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.LiabilityOverbillingHomePageDetails;
import curam.core.facade.struct.LiabilityOverbillingHomePageDetails1;
import curam.core.facade.struct.ListActiveLiabilitesForConcernKey;
import curam.core.facade.struct.ListActiveLiabilitesForConcernKeyStruct;
import curam.core.facade.struct.ListActiveLiabilityDetails;
import curam.core.facade.struct.ListActiveLiabilityDetails1;
import curam.core.facade.struct.ListAdminCaseRoleKey;
import curam.core.facade.struct.ListAssessmentForProductDelivery;
import curam.core.facade.struct.ListAttachmentDetails;
import curam.core.facade.struct.ListAttachmentsKey;
import curam.core.facade.struct.ListCaseDeductionsKey;
import curam.core.facade.struct.ListCaseFinancialInstruction;
import curam.core.facade.struct.ListCaseFinancials;
import curam.core.facade.struct.ListCaseFinancialsKey;
import curam.core.facade.struct.ListCaseRelationshipKey;
import curam.core.facade.struct.ListCertificationDetails;
import curam.core.facade.struct.ListCertificationDetails1;
import curam.core.facade.struct.ListClientRoleKey;
import curam.core.facade.struct.ListDecisionDetails;
import curam.core.facade.struct.ListDecisionKey;
import curam.core.facade.struct.ListDecisionsForReassessmentPeriodKey;
import curam.core.facade.struct.ListDeductableObjectivesKey;
import curam.core.facade.struct.ListDeductionDetails;
import curam.core.facade.struct.ListDeductionsForObjectiveKey;
import curam.core.facade.struct.ListEventDetails;
import curam.core.facade.struct.ListEventDetails1;
import curam.core.facade.struct.ListEventKey;
import curam.core.facade.struct.ListEvidenceKey;
import curam.core.facade.struct.ListEvidenceUsedByRuleKey;
import curam.core.facade.struct.ListEvidenceUsedByRuleResult;
import curam.core.facade.struct.ListLocationDetails;
import curam.core.facade.struct.ListLocationKey;
import curam.core.facade.struct.ListMilestoneForProductDeliveryDetails;
import curam.core.facade.struct.ListNoteDetails;
import curam.core.facade.struct.ListNoteDetails1;
import curam.core.facade.struct.ListNoteKey;
import curam.core.facade.struct.ListObjectiveDeductableDetails;
import curam.core.facade.struct.ListObjectiveDeductionDetails;
import curam.core.facade.struct.ListOutcomesKey;
import curam.core.facade.struct.ListOverUnderPaymentDetails;
import curam.core.facade.struct.ListOverUnderPaymentKey;
import curam.core.facade.struct.ListPDAdminCaseRoleDetails;
import curam.core.facade.struct.ListPDClientRoleDetails;
import curam.core.facade.struct.ListPDDeliveryPatternHistoryDetails_fo;
import curam.core.facade.struct.ListPDEvidenceDetails;
import curam.core.facade.struct.ListProductDeliveryStatusHistoryDetails;
import curam.core.facade.struct.ListProductDeliveryStatusHistoryDetails1;
import curam.core.facade.struct.ListProductDeliveryStatusHistoryKey;
import curam.core.facade.struct.ListReassessmentDecisionResult;
import curam.core.facade.struct.ListRelationshipCaseDetails;
import curam.core.facade.struct.ListUtilityPaymentKey;
import curam.core.facade.struct.ListUtilityPayments;
import curam.core.facade.struct.MaintainCertificationDetails;
import curam.core.facade.struct.MaintainCertificationKey;
import curam.core.facade.struct.ModifyCaseDeductionItemDetails;
import curam.core.facade.struct.ModifyCaseDeductionItemDetails1;
import curam.core.facade.struct.ModifyCertificationFrequencyDetails;
import curam.core.facade.struct.ModifyClosureDetailsKey;
import curam.core.facade.struct.ModifyDeliveryPatternDetails;
import curam.core.facade.struct.ModifyHeaderDetails;
import curam.core.facade.struct.ModifyThirdPartyDeductionDetails;
import curam.core.facade.struct.NoteDetails1;
import curam.core.facade.struct.ObjectiveDeductionDetails;
import curam.core.facade.struct.OverUnderPaymentBreakdownDetails;
import curam.core.facade.struct.OverUnderPaymentBreakdownDetailsList;
import curam.core.facade.struct.PDApprovalRequestDetails;
import curam.core.facade.struct.PDApprovalRequestKey;
import curam.core.facade.struct.PDModifyReasonKey;
import curam.core.facade.struct.ParticipantTypeDescList;
import curam.core.facade.struct.ParticipantTypeDescription;
import curam.core.facade.struct.ParticipantWithoutProspectTypeDescList;
import curam.core.facade.struct.ParticipantWithoutProspectTypeDescription;
import curam.core.facade.struct.ProductDeliveryApprovalKey;
import curam.core.facade.struct.ProductDeliveryContextDescription;
import curam.core.facade.struct.ProductDeliveryContextDescriptionKey;
import curam.core.facade.struct.ProductDeliveryModifyLocationDetails;
import curam.core.facade.struct.ProductDeliveryStatusHistoryDetails;
import curam.core.facade.struct.ProductDeliverySuspensionKey;
import curam.core.facade.struct.ProductDeliveryUnsuspensionKey;
import curam.core.facade.struct.PropertyDescriptionString;
import curam.core.facade.struct.ReactivationDetails;
import curam.core.facade.struct.ReadCaseDecisionDetails;
import curam.core.facade.struct.ReadCaseDecisionKey;
import curam.core.facade.struct.ReadCertificationDetails;
import curam.core.facade.struct.ReadDeductionAmount;
import curam.core.facade.struct.ReadDeductionAndHeaderDetails;
import curam.core.facade.struct.ReadDeductionDetails;
import curam.core.facade.struct.ReadDeductionDtls;
import curam.core.facade.struct.ReadDeductionKey;
import curam.core.facade.struct.ReadFinInstructionIDAndDeductionDetails;
import curam.core.facade.struct.ReadHeaderDetails;
import curam.core.facade.struct.ReadHeaderKey;
import curam.core.facade.struct.ReadHeaderResult;
import curam.core.facade.struct.ReadHomePageDetails;
import curam.core.facade.struct.ReadHomePageDetails1;
import curam.core.facade.struct.ReadHomePageKey;
import curam.core.facade.struct.ReadMilestoneDeliveryDetails;
import curam.core.facade.struct.ReadOverUnderPaymentDetails;
import curam.core.facade.struct.ReadOverUnderPaymentDetailsKey;
import curam.core.facade.struct.ReadPaymentSimulationDetails;
import curam.core.facade.struct.ReadProductDeliveryFreqKey;
import curam.core.facade.struct.ReassessBenefitDetails;
import curam.core.facade.struct.ReassessBenefitKey;
import curam.core.facade.struct.ReassessCreoleDetails;
import curam.core.facade.struct.ReassessCreoleKey;
import curam.core.facade.struct.ReassessLiabilityDetails;
import curam.core.facade.struct.ReassessLiabilityKey;
import curam.core.facade.struct.ReassessmentResultDetails;
import curam.core.facade.struct.ReassessmentResultDetailsList;
import curam.core.facade.struct.RegenerateDeductionDetails;
import curam.core.facade.struct.RejectCaseKey_fo;
import curam.core.facade.struct.RejectCaseKey_fo1;
import curam.core.facade.struct.RelatedCaseID;
import curam.core.facade.struct.RelatedCaseIDThirdPartyID;
import curam.core.facade.struct.RepresentativeID;
import curam.core.facade.struct.RepresentativeRegistrationDetails;
import curam.core.facade.struct.RepresentativeRegistrationWithTextBankAccountSortCodeDetails;
import curam.core.facade.struct.SearchTasksForConcernAndCaseDetails;
import curam.core.facade.struct.SimulationDetails;
import curam.core.facade.struct.SimulationsByCaseIDList;
import curam.core.facade.struct.SubmitForApprovalKey;
import curam.core.facade.struct.ThirdPartyDeductionActivationDetails;
import curam.core.facade.struct.ThirdPartyDeductionActivationStruct;
import curam.core.facade.struct.ThirdPartyFixedDeductionDetails;
import curam.core.facade.struct.ThirdPartyFixedDeductionDetails1;
import curam.core.facade.struct.ThirdPartyVariableDeductionDetails;
import curam.core.facade.struct.ThirdPartyVariableDeductionDetails1;
import curam.core.facade.struct.UnprocessedILIDetails;
import curam.core.facade.struct.UnprocessedILIDetailsList;
import curam.core.facade.struct.UtilityPaymentCaseKey;
import curam.core.facade.struct.UtilityPaymentDetails;
import curam.core.facade.struct.UtilityProductComponentList;
import curam.core.facade.struct.UtilityProductComponentsDetails;
import curam.core.facade.struct.ViewCaseFinancialInstructionList;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CaseDeductionItemFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.FinancialInstructionFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.MaintainCaseClosureFactory;
import curam.core.fact.MaintainCaseDecisionFactory;
import curam.core.fact.MaintainCertificationFactory;
import curam.core.fact.MaintainDeductionItemsFactory;
import curam.core.fact.MaintainFinancialComponentFactory;
import curam.core.fact.MaintainProductDeliveryFurtherDetailsFactory;
import curam.core.fact.ProcessOverUnderPaymentsFactory;
import curam.core.fact.ProductDeliveryApprovalFactory;
import curam.core.fact.ReassessmentInfoFactory;
import curam.core.fact.SimulatePaymentFactory;
import curam.core.fact.SimulationHeaderFactory;
import curam.core.fact.UsersFactory;
import curam.core.fact.ViewOverUnderPaymentResultFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.MaintainDeductionAmount;
import curam.core.impl.ProductHookManager;
import curam.core.impl.RulesResultHelper;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.ConcernRole;
import curam.core.intf.FinancialInstruction;
import curam.core.intf.MaintainCaseDecision;
import curam.core.intf.MaintainCertification;
import curam.core.intf.MaintainDeductionItems;
import curam.core.intf.MaintainFinancialComponent;
import curam.core.intf.ProductDeliveryApproval;
import curam.core.intf.ReassessmentInfo;
import curam.core.intf.SimulatePayment;
import curam.core.intf.SimulationHeader;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.MilestoneConfigurationFactory;
import curam.core.sl.entity.intf.MilestoneConfiguration;
import curam.core.sl.entity.struct.CaseNomineeKey;
import curam.core.sl.entity.struct.InvestigationDeliveryKey;
import curam.core.sl.entity.struct.MilestoneConfigurationKey;
import curam.core.sl.entity.struct.MilestoneDeliveryKey;
import curam.core.sl.entity.struct.WaiverIndicatorDetails;
import curam.core.sl.fact.AssessmentDeliveryFactory;
import curam.core.sl.fact.CaseNomineeFactory;
import curam.core.sl.fact.DeductionFactory;
import curam.core.sl.fact.InvestigationDeliveryFactory;
import curam.core.sl.fact.MilestoneDeliveryFactory;
import curam.core.sl.fact.ReassessmentProductFactory;
import curam.core.sl.fact.TabDetailFormatterFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.fact.UserRecentActionFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngine;
import curam.core.sl.infrastructure.assessment.impl.BreakdownInfo;
import curam.core.sl.infrastructure.assessment.impl.BreakdownInfoDAO;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculator;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculatorFactory;
import curam.core.sl.infrastructure.assessment.impl.EligibilityEntitlementRuleSet;
import curam.core.sl.infrastructure.assessment.impl.ObjectiveType;
import curam.core.sl.infrastructure.assessment.impl.OverUnderPaymentBreakdown;
import curam.core.sl.infrastructure.assessment.impl.OverUnderPaymentBreakdownDAO;
import curam.core.sl.infrastructure.assessment.struct.CREOLECaseDeterminationKey;
import curam.core.sl.infrastructure.entity.struct.VersionNo;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrection;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrectionEvidence;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrectionEvidenceDAO;
import curam.core.sl.intf.AssessmentDelivery;
import curam.core.sl.intf.CaseNominee;
import curam.core.sl.intf.MilestoneDelivery;
import curam.core.sl.intf.ReassessmentProduct;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.intf.UserRecentAction;
import curam.core.sl.struct.AmountDetail;
import curam.core.sl.struct.AppliedDeductionHistoryDetailsList;
import curam.core.sl.struct.CaseDeductionHistoryDetails1;
import curam.core.sl.struct.CaseDeductionHistoryDetailsList;
import curam.core.sl.struct.CaseDeductionHistoryDetailsList1;
import curam.core.sl.struct.CaseNomineeCaseIDKey;
import curam.core.sl.struct.CaseNomineeObjectiveNameDetailsList;
import curam.core.sl.struct.CaseNoteList1;
import curam.core.sl.struct.ContextDescription;
import curam.core.sl.struct.CreateAssessmentDeliveryResult;
import curam.core.sl.struct.DeductionIDAndProductID;
import curam.core.sl.struct.DeductionKey;
import curam.core.sl.struct.DeductionName;
import curam.core.sl.struct.GetBUCaseEvidenceKey;
import curam.core.sl.struct.GetEvidenceKey;
import curam.core.sl.struct.GetLiabilityOverbillingEvidenceKey;
import curam.core.sl.struct.InvestigationDeliveryDetailsList;
import curam.core.sl.struct.MilestoneDeliveryDtls;
import curam.core.sl.struct.OutcomeNameAndIDDetailsList;
import curam.core.sl.struct.Priority;
import curam.core.sl.struct.ProductDeliveryPatternByCaseIDKey;
import curam.core.sl.struct.SearchTaskForConcernOrCaseKey;
import curam.core.sl.struct.ThirdPartyDeductionHistoryDetails1;
import curam.core.sl.struct.ThirdPartyDeductionHistoryDetailsList;
import curam.core.sl.struct.UserRecentActionDetails;
import curam.core.sl.struct.ViewCaseParticipantRoleDetailsList;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.sl.struct.WizardStateID;
import curam.core.struct.ApprovalMessageList;
import curam.core.struct.AttachmentCaseID;
import curam.core.struct.CancelDeductionItemKey;
import curam.core.struct.CaseAccountIdentifier;
import curam.core.struct.CaseAttachmentDetailsList;
import curam.core.struct.CaseDecisionCaseID;
import curam.core.struct.CaseDecisionIDStruct;
import curam.core.struct.CaseDecisionKey;
import curam.core.struct.CaseDeductionHistoryDtls;
import curam.core.struct.CaseDeductionItemDtlsList;
import curam.core.struct.CaseDeductionItemID;
import curam.core.struct.CaseDeductionItemKey;
import curam.core.struct.CaseDeductionNameDetailsList;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseIDCategory;
import curam.core.struct.CaseIDCompIDNomCaseLinkID;
import curam.core.struct.CaseIdentifier;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseStatusHistoryDetailsList;
import curam.core.struct.CaseStatusHistoryDetailsList1;
import curam.core.struct.CaseStatusHistoryKey;
import curam.core.struct.CaseStatusID;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CheckEligibilityKey;
import curam.core.struct.ClosureDtls;
import curam.core.struct.ComponentNomineeDtlsList;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.CreateDeductionItemDtls;
import curam.core.struct.CuramInd;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.DateStruct;
import curam.core.struct.DecisionDifferenceDetails;
import curam.core.struct.DeductionHeaderDetails;
import curam.core.struct.DeductionItemCaseID;
import curam.core.struct.DeductionItemDetailsList;
import curam.core.struct.DeductionLiabilityAmountDetails;
import curam.core.struct.DetermineEligibilityKey;
import curam.core.struct.EligibilityMessageList;
import curam.core.struct.FCCaseID;
import curam.core.struct.FCCoverDate;
import curam.core.struct.FilteredReassessmentDecisionsDetails;
import curam.core.struct.FilteredReassessmentDecisionsDetailsList;
import curam.core.struct.FinancialInstructionDetails;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.FinancialInstructionKey;
import curam.core.struct.GetAllOverUnderPaymentsDetails;
import curam.core.struct.GetCaseReassessmentDecisionDetailsResult;
import curam.core.struct.GetExistingDeductionsResult;
import curam.core.struct.GetOverUnderPaymentDetailsByNomineeKey;
import curam.core.struct.GetProductDeliveryDetailsResult;
import curam.core.struct.GetReassessmentCoverPeriodKey;
import curam.core.struct.GetReassessmentCoverPeriodResult;
import curam.core.struct.GetRelatedCasesKey;
import curam.core.struct.GetRelatedCasesList;
import curam.core.struct.HouseholdBudgetItemCaseIDKey;
import curam.core.struct.HouseholdBudgetItemDtlsList;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.ListActiveLiabilitesForConcernKey1;
import curam.core.struct.LookupRulesForCaseDetails;
import curam.core.struct.LookupRulesForCaseKey;
import curam.core.struct.MaintainCaseDecisionCaseIDKey;
import curam.core.struct.MaintainCertificationCaseIDKey;
import curam.core.struct.MaintainDeductionItemDetails;
import curam.core.struct.MaintainProductDeliveryHeaderDtls;
import curam.core.struct.MaintainProductDeliveryKey;
import curam.core.struct.OverUnderPaymentBreakdownKey;
import curam.core.struct.ProductDeliveryFurtherDetailsKey;
import curam.core.struct.ProductDeliveryHomeKey;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliverySuspensionChangeKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.ProductIDDetails;
import curam.core.struct.ReactivationDtls;
import curam.core.struct.ReadCaseClosureKey;
import curam.core.struct.ReadCaseHeaderResult;
import curam.core.struct.ReadParticipantRoleIDDetails;
import curam.core.struct.ReadmultiByNomineeOverUnderPaymentIDKey;
import curam.core.struct.ReasonCodeDetails;
import curam.core.struct.ReassessmentAmountInfoDtls;
import curam.core.struct.ReassessmentAmountInfoDtlsList;
import curam.core.struct.ReassessmentAmountInformationKey;
import curam.core.struct.ReassessmentInfoDtls;
import curam.core.struct.ReassessmentInfoDtlsList;
import curam.core.struct.ReassessmentInfoKey;
import curam.core.struct.RegisterProductDeliveryDetails;
import curam.core.struct.RegisterProductDeliveryKey;
import curam.core.struct.SearchByCaseIDDtls;
import curam.core.struct.SearchUnprocessedByCaseIDKey;
import curam.core.struct.SimulateInd;
import curam.core.struct.SimulatePaymentILIDetails;
import curam.core.struct.SimulatePaymentILIDetails1;
import curam.core.struct.SimulatePaymentResult;
import curam.core.struct.SimulatePaymentResult1;
import curam.core.struct.SimulationHeaderID;
import curam.core.struct.SimulationHeaderKey;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UpdateCertificationFrequencyDetails;
import curam.core.struct.UpdateProductDeliveryPatternKey;
import curam.core.struct.UsersKey;
import curam.core.struct.UtilityDtls;
import curam.core.struct.UtilityKey;
import curam.core.struct.UtilityRulesComponentsKey;
import curam.core.struct.UtilityRulesComponentsList;
import curam.core.struct.ViewActiveCaseEventDetailsList1;
import curam.core.struct.ViewCaseEventsByCaseIDAndTypeKey;
import curam.core.struct.ViewCaseFinancialsResult;
import curam.core.struct.ViewCaseInstructionDetails;
import curam.core.struct.ViewCaseInstructionsResult;
import curam.core.struct.ViewReassessmentDecisionsByInfoIDKey;
import curam.message.BPOMAINTAINDEDUCTIONITEMS;
import curam.message.BPOPRODUCTDELIVERY;
import curam.message.BPOPRODUCTDELIVERYAPPROVAL;
import curam.message.BPOQUERY;
import curam.message.BPOREFLECTION;
import curam.message.GENERAL;
import curam.message.GENERALCASE;
import curam.piwrapper.casemanager.impl.NomineeOverUnderPayment;
import curam.piwrapper.casemanager.impl.NomineeOverUnderPaymentDAO;
import curam.piwrapper.casemanager.impl.OverUnderPaymentHeader;
import curam.piwrapper.casemanager.impl.OverUnderPaymentHeaderDAO;
import curam.serviceplans.facade.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.impl.ServicePlanSecurity;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.exception.UnimplementedException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.rules.EvidenceTextDecoder;
import curam.util.rules.ResultBuffer;
import curam.util.rules.ResultTextDecoder;
import curam.util.rules.RulesEngine;
import curam.util.rules.evidence.EvidenceList;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.Money;
import curam.util.type.NotFoundIndicator;


/**
 * This process class provides the functionality for the Product Delivery
 * presentation layer.
 */
public abstract class ProductDelivery extends curam.core.facade.base.ProductDelivery {

  // BEGIN CR00159202, MH
  /*
   * Setting up an array list to hold all possible codetables that can be used
   * to populate the CaseStatus entity.
   */
  protected ArrayList<String> kCodeTableList = new ArrayList<String>();

  // END CR00159202

  // END CR00159202
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // BEGIN, CR00174782, CD
  @Inject
  protected DeterminationCalculatorFactory determinationCalculatorFactory;

  // END, CR00174782

  // BEGIN, CR00192101, CSH
  @Inject
  protected OverUnderPaymentBreakdownDAO overUnderPaymentBreakdownDAO;

  @Inject
  protected BreakdownInfoDAO breakdownInfoDAO;

  @Inject
  protected NomineeOverUnderPaymentDAO nomineeOverUnderPaymentDAO;

  @Inject
  protected OverUnderPaymentHeaderDAO overUnderPaymentHeaderDAO;
  // END, CR00192101

  // BEGIN, CR00239173, CW
  /**
   * Reference to PaymentCorrectionEvidenceDAO.
   */
  @Inject
  protected PaymentCorrectionEvidenceDAO paymentCorrectionEvidenceDAO;

  /**
   * Reference to Payment Correction interface.
   */
  @Inject
  protected PaymentCorrection paymentCorrection;
  // END, CR00239173

  // BEGIN, CR00224704, CW
  /**
   * BI report retrieval class. *
   */
  @Inject
  protected BIHelper biHelper;
  // END, CR00224704

  /**
   * Add injection for using the new CaseTransactionLog API.
   */
  public ProductDelivery() {
    GuiceWrapper.getInjector().injectMembers(this);

    // BEGIN CR00159202, MH
    // Adding list of codetable names to the array list.
    kCodeTableList.clear();
    kCodeTableList.add(CASECLOSEREASON.TABLENAME);
    kCodeTableList.add(CASEREACTIVATEREASON.TABLENAME);
    kCodeTableList.add(CASESUSPENDREASON.TABLENAME);
    kCodeTableList.add(CASEUNSUSPENDREASON.TABLENAME);
    kCodeTableList.add(CASEDECISIONINITREASONCODE.TABLENAME);
    kCodeTableList.add(CASECANCELREASON.TABLENAME);
    kCodeTableList.add(REJECTIONREASON.TABLENAME);
    // END CR00159202
  }

  // BEGIN, CR00211744, VM
  @Inject
  protected AssessmentEngine assessmentEngine;
  // END, CR00211744

  // BEGIN, CR00369134, KRK
  /**
   * Instance of MaintainDeductionAmount.
   */
  @Inject
  protected MaintainDeductionAmount maintainDeductionAmount;

  // END, CR00369134

  // ___________________________________________________________________________
  /**
   * Generates the context description for the Product Delivery.
   *
   * @param key
   * Context description identifier.
   *
   * @return A context description for a Product Delivery.
   */
  @Override
  protected ProductDeliveryContextDescription getProductDeliveryContextDescription(
    final ProductDeliveryContextDescriptionKey key) throws AppException,
      InformationalException {

    ProductDeliveryContextDescription productDeliveryContextDescription = null;

    // Check the Environmental variable
    // Retrieve the Environment variable for the Appeals component installation
    // setting. If the environment variable is present and set to 'true', run
    // the Reflection code
    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {

      // Setup, instantiation and execution of alternative
      // getProductDeliveryContextDescription within AppealCase class, via
      // reflection / method.invoke()
      Class cls = null;
      // BEGIN, CR00023618, SK
      // BEGIN, CR00158377, RV
      final String className = ReflectionConst.coreToAppealDelegateWrapperClassName;
      // END, CR00158377
      final String methodName = ReflectionConst.productDeliveryMethodName;

      // END, CR00023618

      try {
        // Load the class for AppealCase
        cls = Class.forName(className);

        // Create a method for the static newInstance constructor
        // BEGIN, CR00023618, SK
        final Method constructorMethod = cls.getMethod(
          ReflectionConst.kNewInstance);
        // END, CR00023618
        final Object classObj = constructorMethod.invoke(cls);

        // Set the arguments to pass through
        final Object[] arguments = new Object[] { key };

        // Set the passed class types to the method
        // getProductDeliveryContextDescription
        final Class[] parameterTypes = new Class[] {
          ProductDeliveryContextDescriptionKey.class };

        // Define the method getProductDeliveryContextDescription
        // BEGIN, CR00142355, CD
        final Method method = classObj.getClass().getMethod(methodName,
          parameterTypes);

        // END, CR00142355

        // Now invoke the method
        productDeliveryContextDescription = (ProductDeliveryContextDescription) method.invoke(
          classObj, arguments);

      } catch (final IllegalAccessException e) {// ignore: biz methods MUST be public
      } catch (final ClassNotFoundException e) {

        final AppException ae = new AppException(
          BPOREFLECTION.ERR_REFLECTION_CLASS_NOT_FOUND);

        ae.arg(className);
        ae.arg(getClass().toString());
        // BEGIN, CR00163098, JC
        ae.arg(
          CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
          TransactionInfo.getProgramLocale()));
        // END, CR00163098, JC

        throw new RuntimeException(ae);

      } catch (final NoSuchMethodException e) {

        final AppException ae = new AppException(
          BPOREFLECTION.ERR_REFLECTION_NO_SUCH_METHOD);

        ae.arg(className);
        // BEGIN, CR00049218, GM
        ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
        // END, CR00049218
        // BEGIN, CR00163098, JC
        ae.arg(
          CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
          TransactionInfo.getProgramLocale()));
        // END, CR00163098, JC

        throw new RuntimeException(ae);

      } catch (final IllegalArgumentException e) {

        final AppException ae = new AppException(
          BPOREFLECTION.ERR_ILLEGAL_FUNCTION_ARGUMENTS);

        // BEGIN, CR00049218, GM
        ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
        // END, CR00049218
        ae.arg(className);
        // BEGIN, CR00163098, JC
        ae.arg(
          CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
          TransactionInfo.getProgramLocale()));
        // END, CR00163098, JC

        throw new RuntimeException(ae);

      } catch (final InvocationTargetException e) {

        final AppException exc = new AppException(
          BPOREFLECTION.ERR_BPO_MESSAGE_RETURNED);

        exc.arg(e.getTargetException().getMessage());
        throw exc;
      }

      return productDeliveryContextDescription;
    }

    final curam.core.facade.intf.ProductDeliveryContext productDeliveryContextObj = curam.core.facade.fact.ProductDeliveryContextFactory.newInstance();

    productDeliveryContextDescription = productDeliveryContextObj.readContextDescription(
      key);

    return productDeliveryContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void approve(final ProductDeliveryApprovalKey key)
    throws AppException, InformationalException {

    // ProductDeliveryApproval manipulation variables
    final ProductDeliveryApproval productDeliveryApprovalObj = ProductDeliveryApprovalFactory.newInstance();
    final curam.core.struct.ProductDeliveryApprovalKey productDeliveryApprovalKey = new curam.core.struct.ProductDeliveryApprovalKey();

    // Populate key to call BPO
    productDeliveryApprovalKey.assign(key);

    // BEGIN, CR00228464, PB
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    final CaseHeaderDtls caseHeaderDtls = CachedCaseHeaderFactory.newInstance().read(
      caseHeaderKey);

    if (caseHeaderDtls.statusCode.equals(CASESTATUS.DELAYEDPROC)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPRODUCTDELIVERYAPPROVAL.ERR_CASEREJECT_FV_CASESTATUS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00228464

    // Call ProductDeliveryApproval BPO to approve the product delivery
    productDeliveryApprovalObj.approve(productDeliveryApprovalKey);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void cancelCertification(final CancelCertificationKey key)
    throws AppException, InformationalException {

    // MaintainCertification manipulation variables
    final MaintainCertification maintainCertificationObj = MaintainCertificationFactory.newInstance();
    final curam.core.struct.CancelCertificationKey cancelCertificationKey = new curam.core.struct.CancelCertificationKey();

    // Assign key details to cancel certification
    cancelCertificationKey.assign(key);

    // Call MaintainCertification BPO to cancel the certification
    maintainCertificationObj.cancelCertification(cancelCertificationKey);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void close(final CloseCaseDetails details) throws AppException,
      InformationalException {

    // MaintainCaseClosure manipulation variables
    final curam.core.intf.MaintainCaseClosure maintainCaseClosureObj = curam.core.fact.MaintainCaseClosureFactory.newInstance();
    final ClosureDtls closureDtls = new ClosureDtls();

    // Assign closure details
    closureDtls.assign(details);

    // BEGIN, CR00150402, PDN
    // Set the user name that is requesting the case closure.
    // System user maintenance object
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    // Read the system user details
    final SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    // Set the user name
    closureDtls.userName = systemUserDtls.userName;
    // END, CR00150402

    // Call MaintainCaseClosure BPO to close the product delivery case
    maintainCaseClosureObj.closeCase(closureDtls);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList createCertification(
    final CreateCertificationDetails details) throws AppException,
      InformationalException {

    // create return object.
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // MaintainCertification manipulation variables
    final curam.core.intf.MaintainCertification maintainCertificationObj = curam.core.fact.MaintainCertificationFactory.newInstance();
    final curam.core.struct.MaintainCertificationDetails maintainCertificationDetails = new curam.core.struct.MaintainCertificationDetails();

    // Assign certification details
    maintainCertificationDetails.assign(details);

    // Call MaintainCertification BPO to create the certification
    maintainCertificationObj.createCertification(maintainCertificationDetails);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * Identifier for a product delivery case.
   *
   * @return A list of certification details for a Product Delivery.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #listCertification1()}
   *
   * List the certifications for a product delivery.
   */
  @Deprecated
  public ListCertificationDetails listCertification(
    final CertificationCaseIDKey key) throws AppException,
      InformationalException {

    // Create the return object
    final ListCertificationDetails listCertificationDetails = new ListCertificationDetails();

    // MaintainCertification manipulation variables
    final curam.core.intf.MaintainCertification maintainCertificationObj = curam.core.fact.MaintainCertificationFactory.newInstance();
    final MaintainCertificationCaseIDKey maintainCertificationCaseIDKey = new MaintainCertificationCaseIDKey();

    // An instance of the key for a context description read
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Assign certification key details
    maintainCertificationCaseIDKey.assign(key);

    // Call MaintainCertification BPO to retrieve certifications
    listCertificationDetails.assign(

      maintainCertificationObj.getCertifications(maintainCertificationCaseIDKey));

    // Set key to read product delivery context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Get the context description
    listCertificationDetails.productDeliveryContextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listCertificationDetails;
  }

  // BEGIN, CR00162569, PDN
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains the case identifier.
   *
   * @return Returns a list of case status history records.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #listStatusHistory1()}.
   * This process will list the status history of a case.
   */
  @Deprecated
  public ListProductDeliveryStatusHistoryDetails listStatusHistory(
    final ListProductDeliveryStatusHistoryKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListProductDeliveryStatusHistoryDetails listProductDeliveryStatusHistoryDetails = new ListProductDeliveryStatusHistoryDetails();

    // ProductDeliveryHome manipulation variables
    final curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory.newInstance();
    final CaseStatusHistoryKey caseStatusHistoryKey = new CaseStatusHistoryKey();
    CaseStatusHistoryDetailsList caseStatusHistoryDetailsList;

    // ProductDeliveryStatusHistoryDetails object
    ProductDeliveryStatusHistoryDetails productDeliveryStatusHistoryDetails;

    // Context description key object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key to retrieve case status history list
    caseStatusHistoryKey.caseID = key.caseID;

    // Read case status history list
    caseStatusHistoryDetailsList = productDeliveryHomeObj.getCaseStatusHistory(
      caseStatusHistoryKey);

    // Reserve space in list
    listProductDeliveryStatusHistoryDetails.dtls.ensureCapacity(
      caseStatusHistoryDetailsList.dtls.size());

    // BEGIN, CR00150402, PDN
    // Map the returned details for each record
    for (int i = 0; i < caseStatusHistoryDetailsList.dtls.size(); i++) {

      productDeliveryStatusHistoryDetails = new ProductDeliveryStatusHistoryDetails();

      productDeliveryStatusHistoryDetails.assign(
        caseStatusHistoryDetailsList.dtls.item(i));

      final boolean showDeferredProc = Configuration.getBooleanProperty(
        EnvVars.ENV_DPDISPLAYINSTATUSHISTORY);

      // Populate the return object with the details, if its not delayed
      // processing or if it is and the display of delayed processing are
      // allowed.
      if (productDeliveryStatusHistoryDetails.statusCode.equals(
        curam.codetable.CASESTATUS.DELAYEDPROC)
          && showDeferredProc) {
        listProductDeliveryStatusHistoryDetails.dtls.addRef(
          productDeliveryStatusHistoryDetails);
      } else if (!productDeliveryStatusHistoryDetails.statusCode.equals(
        curam.codetable.CASESTATUS.DELAYEDPROC)) {
        listProductDeliveryStatusHistoryDetails.dtls.addRef(
          productDeliveryStatusHistoryDetails);
      }
    }
    // END, CR00150402

    // Set key to retrieve context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read the context description into the return object
    listProductDeliveryStatusHistoryDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listProductDeliveryStatusHistoryDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListProductDeliveryStatusHistoryDetails1 listStatusHistory1(
    final ListProductDeliveryStatusHistoryKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListProductDeliveryStatusHistoryDetails1 listProductDeliveryStatusHistoryDetails1 = new ListProductDeliveryStatusHistoryDetails1();

    // ProductDeliveryHome manipulation variables
    final curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory.newInstance();
    final CaseStatusHistoryKey caseStatusHistoryKey = new CaseStatusHistoryKey();
    CaseStatusHistoryDetailsList1 caseStatusHistoryDetailsList1;

    // ProductDeliveryStatusHistoryDetails object
    CaseStatusHistory caseStatusHistory;

    // Context description key object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key to retrieve case status history list
    caseStatusHistoryKey.caseID = key.caseID;

    // Read case status history list
    caseStatusHistoryDetailsList1 = productDeliveryHomeObj.getCaseStatusHistory1(
      caseStatusHistoryKey);

    // Reserve space in list
    listProductDeliveryStatusHistoryDetails1.dtls.ensureCapacity(
      caseStatusHistoryDetailsList1.dtls.size());

    // Users manipulation variables
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    // Map the returned details for each record
    for (int i = 0; i < caseStatusHistoryDetailsList1.dtls.size(); i++) {

      caseStatusHistory = new CaseStatusHistory();

      caseStatusHistory.assign(caseStatusHistoryDetailsList1.dtls.item(i));

      // Set the users full name from the user name
      usersKey.userName = caseStatusHistoryDetailsList1.dtls.item(i).userName;
      caseStatusHistory.userFullName = usersObj.getFullName(usersKey).fullname;

      final boolean showDeferredProc = Configuration.getBooleanProperty(
        EnvVars.ENV_DPDISPLAYINSTATUSHISTORY);

      // For backward compatibility support, Set the start and end date time to
      // the start and end date if the start and end date times have not
      // been set.
      if (caseStatusHistory.startDateTime.isZero()) {
        caseStatusHistory.startDateTime = new DateTime(
          caseStatusHistory.startDate.getCalendar());
      }
      if (caseStatusHistory.endDateTime.isZero()) {
        caseStatusHistory.endDateTime = new DateTime(
          caseStatusHistory.endDate.getCalendar());
      }

      // Populate the return object with the details, if its not delayed
      // processing or if it is and the display of delayed processing are
      // allowed.
      if (caseStatusHistory.statusCode.equals(
        curam.codetable.CASESTATUS.DELAYEDPROC)
          && showDeferredProc) {
        listProductDeliveryStatusHistoryDetails1.dtls.addRef(caseStatusHistory);
      } else if (!caseStatusHistory.statusCode.equals(
        curam.codetable.CASESTATUS.DELAYEDPROC)) {
        listProductDeliveryStatusHistoryDetails1.dtls.addRef(caseStatusHistory);
      }
    }

    // Set key to retrieve context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read the context description into the return object
    listProductDeliveryStatusHistoryDetails1.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listProductDeliveryStatusHistoryDetails1;
  }

  // END, CR00162569

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList modifyCertification(
    final MaintainCertificationDetails details) throws AppException,
      InformationalException {

    // Return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // MaintainCertification manipulation variables
    final curam.core.intf.MaintainCertification maintainCertificationObj = curam.core.fact.MaintainCertificationFactory.newInstance();
    final curam.core.struct.MaintainCertificationDetails maintainCertificationDetails = new curam.core.struct.MaintainCertificationDetails();

    // Assign certification details
    maintainCertificationDetails.assign(details);

    // Call MaintainCertification BPO to modify the certification
    maintainCertificationObj.modifyCertification(maintainCertificationDetails);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void modifyClosureDetails(final ClosureDetails details,
    final ModifyClosureDetailsKey key) throws AppException,
      InformationalException {

    // MaintainCaseClosure manipulation variables
    final curam.core.intf.MaintainCaseClosure maintainCaseClosureObj = curam.core.fact.MaintainCaseClosureFactory.newInstance();
    final ClosureDtls closureDtls = new ClosureDtls();

    // Assign closure details
    closureDtls.assign(details);
    closureDtls.caseID = key.caseID;

    // Call MaintainCaseClosure BPO to modify closure details
    maintainCaseClosureObj.modifyCaseClosure(closureDtls);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void reactivate(final ReactivationDetails details)
    throws AppException, InformationalException {

    // MaintainCaseClosure manipulation variables
    final curam.core.intf.MaintainCaseClosure maintainCaseClosureObj = curam.core.fact.MaintainCaseClosureFactory.newInstance();
    final ReactivationDtls reactivationDtls = new ReactivationDtls();

    // Assign reactivation details
    reactivationDtls.assign(details);

    // Call MaintainCaseClosure BPO to reactivate the case
    maintainCaseClosureObj.reactivateCase(reactivationDtls);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReadCertificationDetails readCertification(
    final MaintainCertificationKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadCertificationDetails readCertificationDetails = new ReadCertificationDetails();

    // MaintainCertification manipulation variables
    final curam.core.intf.MaintainCertification maintainCertificationObj = curam.core.fact.MaintainCertificationFactory.newInstance();
    final curam.core.struct.MaintainCertificationKey maintainCertificationKey = new curam.core.struct.MaintainCertificationKey();

    // Assign key details
    maintainCertificationKey.assign(key);

    // Assign the certification details to return object
    readCertificationDetails.maintainCertificationDetails.assign(
      maintainCertificationObj.readCertification(maintainCertificationKey));

    return readCertificationDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ClosureDetails readClosureDetails(
    final curam.core.facade.struct.ReadCaseClosureKey key)
    throws AppException, InformationalException {

    // Create a return object
    final ClosureDetails closureDetails = new ClosureDetails();

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // MaintainCaseClosure manipulation variables
    final curam.core.intf.MaintainCaseClosure maintainCaseClosureObj = curam.core.fact.MaintainCaseClosureFactory.newInstance();
    ClosureDtls closureDtls = null;
    final curam.core.struct.ReadCaseClosureKey readCaseClosureKey = new curam.core.struct.ReadCaseClosureKey();

    // Set key to read closure details
    // BEGIN CR00075431, PN
    readCaseClosureKey.caseID = key.caseID;
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    caseHeaderKey.caseID = key.caseID;

    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    if (!(caseHeaderDtls.statusCode.equals(CASESTATUS.PENDINGCLOSURE)
      || caseHeaderDtls.statusCode.equals(CASESTATUS.CLOSED))) // BEGIN, CR00163236, CL
    {
      closureDetails.closureDetailsMsg = new LocalisableString(curam.message.BPOMAINTAINCASECLOSURE.ERR_CASECLOSURE_FV_NO_CLOSURE).getMessage(
        TransactionInfo.getProgramLocale());
    } else {
      // END, CR00163236

      closureDetails.closureDetailsFlag = true;
      // END CR00075431

      // Call MaintainCaseClosure BPO to read closure details
      closureDtls = maintainCaseClosureObj.readCaseClosure(readCaseClosureKey);

      // Set key to retrieve context description
      productDeliveryContextDescriptionKey.caseID = key.caseID;

      closureDetails.contextDescription = getProductDeliveryContextDescription(
        productDeliveryContextDescriptionKey);

      // Assign the case closure details to the return object
      closureDetails.assign(closureDtls);
    }
    return closureDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReadCaseDecisionDetails readDecision(final ReadCaseDecisionKey key)
    throws AppException, InformationalException {

    // MaintainCaseDecision manipulation variables
    final curam.core.intf.MaintainCaseDecision maintainCaseDecisionObj = curam.core.fact.MaintainCaseDecisionFactory.newInstance();
    final ReadCaseDecisionDetails readCaseDecisionDetails = new ReadCaseDecisionDetails();
    final CaseDecisionIDStruct caseDecisionIDStruct = new CaseDecisionIDStruct();

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key to get decision details
    if (key.caseDecisionID != 0) {

      caseDecisionIDStruct.caseDecisionID = key.caseDecisionID;

      final CaseDecisionCaseID caseDecisionCaseID = maintainCaseDecisionObj.getCaseID(
        caseDecisionIDStruct);

      // Set key to retrieve context description
      productDeliveryContextDescriptionKey.caseID = caseDecisionCaseID.dtls.caseID;

      readCaseDecisionDetails.contextDescription = getProductDeliveryContextDescription(
        productDeliveryContextDescriptionKey);

      // Populate return struct
      readCaseDecisionDetails.decisionResult = maintainCaseDecisionObj.getCaseDecisionDetails(
        caseDecisionIDStruct);
    }

    return readCaseDecisionDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ApprovalMessageList submit(final SubmitForApprovalKey key)
    throws AppException, InformationalException {

    // Create a case closure business object
    final curam.core.intf.ProductDeliveryApproval productDeliveryApprovalObj = curam.core.fact.ProductDeliveryApprovalFactory.newInstance();

    // Create a return object
    ApprovalMessageList approvalMessageList;

    // SubmitForApprovalKey object
    final curam.core.struct.SubmitForApprovalKey submitForApprovalKey = new curam.core.struct.SubmitForApprovalKey();

    // Set key to submit for approval
    submitForApprovalKey.caseID = key.caseID;

    // Call ProductDeliveryApproval to submit the case for approval
    approvalMessageList = productDeliveryApprovalObj.submitForApproval(
      submitForApprovalKey);

    return approvalMessageList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void suspend(final ProductDeliverySuspensionKey key)
    throws AppException, InformationalException {

    // MaintainProductDelivery BPO
    final curam.core.intf.MaintainProductDelivery maintainProductDeliveryObj = curam.core.fact.MaintainProductDeliveryFactory.newInstance();

    // ProductDeliverySuspensionChangeKey object
    final ProductDeliverySuspensionChangeKey productDeliverySuspensionChangeKey = new ProductDeliverySuspensionChangeKey();

    // Assign key details to suspend case
    productDeliverySuspensionChangeKey.assign(key);

    // Suspend product delivery
    maintainProductDeliveryObj.suspendProductDelivery(
      productDeliverySuspensionChangeKey);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void unsuspend(final ProductDeliveryUnsuspensionKey key)
    throws AppException, InformationalException {

    // MaintainProductDelivery BPO
    final curam.core.intf.MaintainProductDelivery maintainProductDeliveryObj = curam.core.fact.MaintainProductDeliveryFactory.newInstance();

    // ProductDeliverySuspensionChangeKey object
    final ProductDeliverySuspensionChangeKey productDeliverySuspensionChangeKey = new ProductDeliverySuspensionChangeKey();

    // Assign key details
    productDeliverySuspensionChangeKey.assign(key);

    // Unsuspend product delivery
    maintainProductDeliveryObj.unsuspendProductDelivery(
      productDeliverySuspensionChangeKey);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListDecisionDetails listDecision(final ListDecisionKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListDecisionDetails listDecisionDetails = new ListDecisionDetails();

    // MaintainCaseDecision business object
    final curam.core.intf.MaintainCaseDecision maintainCaseDecisionObj = curam.core.fact.MaintainCaseDecisionFactory.newInstance();

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // MaintainCaseDecisionCaseIDKey object
    final MaintainCaseDecisionCaseIDKey maintainCaseDecisionCaseIDKey = new MaintainCaseDecisionCaseIDKey();

    // Set key to retrieve decisions
    maintainCaseDecisionCaseIDKey.caseID = key.caseID;

    // Retrieve case decisions
    listDecisionDetails.assign(
      maintainCaseDecisionObj.getCaseDecisions(maintainCaseDecisionCaseIDKey));

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Retrieve context description
    listDecisionDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listDecisionDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CreatedCaseIDKey createCase(final CreateCaseDetails details)
    throws AppException, InformationalException {

    // Create the return object
    final CreatedCaseIDKey createdCaseIDKey = new CreatedCaseIDKey();

    // CreateProductDelivery manipulation variables
    final curam.core.intf.CreateProductDelivery createProductDeliveryObj = curam.core.fact.CreateProductDeliveryFactory.newInstance();
    final RegisterProductDeliveryKey registerProductDeliveryKey = new RegisterProductDeliveryKey();

    // Assign details to key
    registerProductDeliveryKey.assign(details);

    // Register the product delivery and assign
    // the returned caseID to the return object
    createdCaseIDKey.caseID = createProductDeliveryObj.registerProductDelivery(registerProductDeliveryKey, new RegisterProductDeliveryDetails()).caseID;

    return createdCaseIDKey;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListLocationDetails listLocation(final ListLocationKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListLocationDetails listLocationDetails = new ListLocationDetails();

    // MaintainProductDelivery manipulation variables
    final curam.core.intf.MaintainProductDelivery maintainProductDeliveryObj = curam.core.fact.MaintainProductDeliveryFactory.newInstance();
    final MaintainProductDeliveryKey maintainProductDeliveryKey = new MaintainProductDeliveryKey();

    // Assign key details to read location details
    maintainProductDeliveryKey.assign(key);

    // Get location details list and assign it to the return object
    listLocationDetails.assign(
      maintainProductDeliveryObj.getLocations(maintainProductDeliveryKey));

    return listLocationDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListOverUnderPaymentDetails listOverUnderPayment(
    final ListOverUnderPaymentKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListOverUnderPaymentDetails listOverUnderPaymentDetails = new ListOverUnderPaymentDetails();

    // ViewOverUnderPaymentResult BPO
    final curam.core.intf.ViewOverUnderPaymentResult viewOverUnderPaymentResultObj = curam.core.fact.ViewOverUnderPaymentResultFactory.newInstance();

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Get the details list and assign it to the return object
    listOverUnderPaymentDetails.getAllOverUnderPaymentsResult = viewOverUnderPaymentResultObj.getAllOverUnderPayments(
      key.getAllOverUnderPaymentsIn);

    // Set key to retrieve context description
    productDeliveryContextDescriptionKey.caseID = key.getAllOverUnderPaymentsIn.caseID;

    // Get the context description
    listOverUnderPaymentDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listOverUnderPaymentDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList modifyDeliveryPattern(
    final ModifyDeliveryPatternDetails details) throws AppException,
      InformationalException {

    // MaintainProductDelivery manipulation variables
    final curam.core.intf.MaintainProductDelivery maintainProductDeliveryObj = curam.core.fact.MaintainProductDeliveryFactory.newInstance();
    final UpdateProductDeliveryPatternKey updateProductDeliveryPatternKey = new UpdateProductDeliveryPatternKey();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign values to key
    updateProductDeliveryPatternKey.assign(details);

    // Update of product delivery pattern
    maintainProductDeliveryObj.updateProductDeliveryPattern(
      updateProductDeliveryPatternKey);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList modifyHeader(final ModifyHeaderDetails details)
    throws AppException, InformationalException {

    // create return object.
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // MaintainProductDeliveryFurtherDetails manipulation variables
    final curam.core.intf.MaintainProductDeliveryFurtherDetails maintainProductDeliveryFurtherDetailsObj = curam.core.fact.MaintainProductDeliveryFurtherDetailsFactory.newInstance();
    final MaintainProductDeliveryHeaderDtls maintainProductDeliveryHeaderDtls = new MaintainProductDeliveryHeaderDtls();

    // Assign the relevant details
    maintainProductDeliveryHeaderDtls.assign(details);

    // Modify the case header details
    maintainProductDeliveryFurtherDetailsObj.modifyCaseHeader(
      maintainProductDeliveryHeaderDtls);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * Contains the case identifier.
   *
   * @return Case header details.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.facade.impl.ProductDelivery#readHeader1(ReadHeaderKey)}
   *
   * Reads case header details.
   */
  @Deprecated
  public ReadHeaderDetails readHeader(final ReadHeaderKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00203241, VM
    return readHeader1(key).details;
    // END, CR00203241, VM
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReassessCreoleDetails reassessCaseDetermination(final ReassessCreoleKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00295965, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00295965

    // BEGIN, CR00222056, VM
    final ReassessCreoleDetails reassessCreoleDetails = new ReassessCreoleDetails();

    final DetermineEligibilityKey determineEligibilityKey = new DetermineEligibilityKey();

    determineEligibilityKey.caseID = key.caseID;

    final DeterminationCalculator determinationCalculator = determinationCalculatorFactory.newInstanceForCaseID(
      key.caseID);

    // BEGIN, CR00288712, RB
    determinationCalculator.checkAssessmentSupported(key.caseID);
    // END, CR00288712

    reassessCreoleDetails.reassessmentMessageList = determinationCalculator.reassessManually(determineEligibilityKey).msgList;
    // END, CR00222056

    return reassessCreoleDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReassessBenefitDetails reassessBenefit(final ReassessBenefitKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReassessBenefitDetails reassessBenefitDetails = new ReassessBenefitDetails();

    // BEGIN, CR00222056, VM
    final DetermineEligibilityKey determineEligibilityKey = new DetermineEligibilityKey();

    determineEligibilityKey.caseID = key.caseID;
    determineEligibilityKey.fromDate = key.fromDate;
    determineEligibilityKey.toDate = key.toDate;

    final DeterminationCalculator determinationCalculator = determinationCalculatorFactory.newInstanceForCaseID(
      key.caseID);

    reassessBenefitDetails.reassessmentMessageList = determinationCalculator.reassessManually(determineEligibilityKey).msgList;
    // END, CR00222056

    return reassessBenefitDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReassessLiabilityDetails reassessLiability(
    final ReassessLiabilityKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReassessLiabilityDetails reassessLiabilityDetails = new ReassessLiabilityDetails();

    // BEGIN, CR00222056, VM
    final DetermineEligibilityKey determineEligibilityKey = new DetermineEligibilityKey();

    determineEligibilityKey.caseID = key.determineEligibilityKey.caseID;
    determineEligibilityKey.fromDate = key.determineEligibilityKey.fromDate;
    determineEligibilityKey.toDate = key.determineEligibilityKey.toDate;
    determineEligibilityKey.reconciliationInd = key.determineEligibilityKey.reconciliationInd;

    final DeterminationCalculator determinationCalculator = determinationCalculatorFactory.newInstanceForCaseID(
      key.determineEligibilityKey.caseID);

    reassessLiabilityDetails.reassessmentMessageList = determinationCalculator.reassessManually(determineEligibilityKey).msgList;
    // END, CR00222056

    return reassessLiabilityDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void modifyLocation(final ProductDeliveryModifyLocationDetails details)
    throws AppException, InformationalException {

    MaintainProductDeliveryFurtherDetailsFactory.newInstance().modifyLocation(
      details.modifyProductProviderLocationDetails);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void createUtilityPayment(final CreateUtilityPaymentDetails details)
    throws AppException, InformationalException {

    // Utility payments objects
    final curam.core.intf.MaintainUtilityPayments maintainUtilityPaymentsObj = curam.core.fact.MaintainUtilityPaymentsFactory.newInstance();
    final curam.core.struct.MaintainUtilityPaymentDetails maintainUtilityPaymentDetails = new curam.core.struct.MaintainUtilityPaymentDetails();

    // Assign the payment details
    maintainUtilityPaymentDetails.assign(details);

    // Create the utility payment
    maintainUtilityPaymentsObj.createUtilityPayment(
      maintainUtilityPaymentDetails);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CertificationFrequencyDetails readCertificationFrequency(
    final ReadProductDeliveryFreqKey key) throws AppException,
      InformationalException {

    // Create return object
    final CertificationFrequencyDetails certificationFrequencyDetails = new CertificationFrequencyDetails();

    // MaintainProductDelivery manipulation variables
    final curam.core.intf.MaintainProductDelivery maintainProductDeliveryObj = curam.core.fact.MaintainProductDeliveryFactory.newInstance();
    final MaintainProductDeliveryKey productDeliveryKey = new MaintainProductDeliveryKey();

    // Assign key to read certification details
    productDeliveryKey.assign(key);

    // Read certification details and assign to return object
    certificationFrequencyDetails.assign(

      maintainProductDeliveryObj.readCertificationFrequency(productDeliveryKey));

    return certificationFrequencyDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void modifyCertificationFrequency(
    final ModifyCertificationFrequencyDetails details) throws AppException,
      InformationalException {

    // MaintainProductDelivery manipulation variables
    final curam.core.intf.MaintainProductDelivery maintainProductDeliveryObj = curam.core.fact.MaintainProductDeliveryFactory.newInstance();
    final UpdateCertificationFrequencyDetails certFreqDetails = new UpdateCertificationFrequencyDetails();

    // Assign certification details for modification
    certFreqDetails.assign(details);

    // Call MaintainProductDelivery BPO to modify the certification frequency
    maintainProductDeliveryObj.updateCertificationFrequency(certFreqDetails);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public curam.core.facade.struct.CaseStatusDetails readStatusHistory(
    final CaseStatusKey key) throws AppException, InformationalException {

    // Create a return object
    final curam.core.facade.struct.CaseStatusDetails caseStatusDetails = new curam.core.facade.struct.CaseStatusDetails();

    // CaseStatusRead manipulation variables
    final curam.core.intf.CaseStatusRead caseStatusReadObj = curam.core.fact.CaseStatusReadFactory.newInstance();

    final CaseStatusID caseStatusID = new CaseStatusID();

    // Create a CaseStatusReasonCode object and read in the reasonCode
    final CaseStatusReasonCode caseStatusReasonCode = new CaseStatusReasonCode();

    // CaseStatus manipulation variables
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final curam.core.struct.CaseStatusKey caseStatusKey = new curam.core.struct.CaseStatusKey();

    // Struct to hold case closure reasonCode
    ReasonCodeDetails reasonCodeDetails = new ReasonCodeDetails();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // Begin, CR00002484, CM
    // Set key to read caseID
    caseStatusKey.caseStatusID = key.caseStatusID;
    CaseStatusDtls caseStatusDtls = new CaseStatusDtls();

    caseStatusDtls = caseStatusObj.read(caseStatusKey);
    // END, CR00002484

    // set case key
    caseKey.caseID = caseStatusDtls.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // Begin, CR00002484, CM
      // set the key
      servicePlanSecurityKey.caseID = caseStatusDtls.caseID;
      // END, CR00002484
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Set key to read the caseStatus details
    caseStatusID.caseStatusID = key.caseStatusID;

    // Read the caseStatus details into the return object

    caseStatusDetails.assign(caseStatusReadObj.viewCaseStatusDtls(caseStatusID));

    // If the caseStatus is CLOSED read the reasonCode from case closure entity
    // This is due to the fact that when case closure details are modified, the
    // entity case closure is updated (not case status!)
    if (caseStatusDetails.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {

      // Set key to read case closure reasonCode
      caseStatusKey.caseStatusID = key.caseStatusID;

      // Read case closure reasonCode
      reasonCodeDetails = caseStatusObj.readCaseClosureReasonByCaseStatusID(
        caseStatusKey);

      caseStatusReasonCode.reasonCode = reasonCodeDetails.reasonCode;
    } else {

      // Set reasonCode to retrieve code description
      caseStatusReasonCode.reasonCode = caseStatusDetails.reasonCode;
    }

    // Read the caseStatus reasonCode description into the return object
    caseStatusDetails.reasonString = getCaseStatusReasonDescription(caseStatusReasonCode).reasonString;

    return caseStatusDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  protected CaseStatusReasonDescription getCaseStatusReasonDescription(
    final CaseStatusReasonCode details) throws AppException,
      InformationalException {

    // Create return object
    final CaseStatusReasonDescription caseStatusReasonDescription = new CaseStatusReasonDescription();

    String reasonCodeDesc;
    // BEGIN CR00159202, MH
    final int size = kCodeTableList.size();

    // Loop through the list of tables to find the code description
    for (int i = 0; i < size; i++) {

      // BEGIN , CR00163098, JC
      reasonCodeDesc = curam.util.type.CodeTable.getOneItem(
        kCodeTableList.get(i), details.reasonCode,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
      // END CR00159202
      if (reasonCodeDesc != null && reasonCodeDesc.length() != 0) {

        // found correct code so set return object and exit for loop
        caseStatusReasonDescription.reasonString = reasonCodeDesc;
        break;
      }

    }

    return caseStatusReasonDescription;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public EvaluateCaseResult checkEligibility(final CheckEligibilityDetails key)
    throws AppException, InformationalException {

    // BEGIN, CR00288712, RB
    final DeterminationCalculator determinationCalculator = determinationCalculatorFactory.newInstanceForCaseID(
      key.caseID);

    determinationCalculator.checkAssessmentSupported(key.caseID);
    // END, CR00288712


    // Return object
    final EvaluateCaseResult evaluateCaseResult = new EvaluateCaseResult();

    // BEGIN, CR00211744, VM
    final CheckEligibilityKey checkEligibilityKey = new CheckEligibilityKey();

    checkEligibilityKey.caseID = key.caseID;
    checkEligibilityKey.evaluationDate = key.evaluationDate;
    checkEligibilityKey.forActiveEvidenceInd = key.forActiveEvidenceInd;
    checkEligibilityKey.forCaseStartDateInd = key.forCaseStartDateInd;

    evaluateCaseResult.evaluateClaimResults = assessmentEngine.evaluateCase(
      checkEligibilityKey);
    // END, CR00211744

    return evaluateCaseResult;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00180658, CR00222056, CD, VM
  public CaseDeterminationDecisionDetailsList checkEligibilityCaseDetermination(
    final CheckEligibilityCaseDeterminationDetails key) throws AppException,
      InformationalException {

    // Check Eligibility
    final CheckEligibilityDetails checkEligibilityDetails = new CheckEligibilityDetails();

    checkEligibilityDetails.caseID = key.caseID;
    checkEligibilityDetails.forActiveEvidenceInd = key.forActiveEvidenceInd;
    checkEligibilityDetails.forCaseStartDateInd = true;
    final EvaluateCaseResult evaluateClaimResults = checkEligibility(
      checkEligibilityDetails);

    final CREOLECaseDeterminationKey creoleCaseDeterminationKey = new CREOLECaseDeterminationKey();

    creoleCaseDeterminationKey.creoleCaseDeterminationID = evaluateClaimResults.evaluateClaimResults.decisionID;

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    return
      CaseDeterminationFactory.newInstance().getMostRecentManualEligibilityCheckDecisionPeriods(
      caseHeaderKey);
  }

  // END, CR00180658, CR00222056


  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public EligibilityMessageList activate(final ActivateCaseKey_fo key)
    throws AppException, InformationalException {

    // Create return object
    EligibilityMessageList eligibilityMessageList;

    // InteractiveCaseEligibility manipulation variables
    final curam.core.intf.InteractiveCaseEligibility interactiveCaseEligibilityObj = curam.core.fact.InteractiveCaseEligibilityFactory.newInstance();
    final CaseIdentifier caseIdentifier = new CaseIdentifier();

    // Set key to activate case
    caseIdentifier.caseID = key.caseID;

    // Call InteractiveCaseEligibility BPO to activate case
    eligibilityMessageList = interactiveCaseEligibilityObj.activateBenefitCase(
      caseIdentifier);

    return eligibilityMessageList;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * Details of the case to be rejected.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #reject1()}
   *
   * Rejects a product delivery case.
   */
  @Deprecated
  public void reject(final RejectCaseKey_fo key) throws AppException,
      InformationalException {

    // ProductDeliveryApproval manipulation variables
    final curam.core.intf.ProductDeliveryApproval productDeliveryApprovalObj = curam.core.fact.ProductDeliveryApprovalFactory.newInstance();
    final curam.core.struct.ProductDeliveryApprovalKey productDeliveryApprovalKey = new curam.core.struct.ProductDeliveryApprovalKey();

    // Set key to reject product delivery
    productDeliveryApprovalKey.assign(key);

    // Call ProductDeliveryApproval BPO to reject the case
    productDeliveryApprovalObj.reject(productDeliveryApprovalKey);
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * Key to read Product Delivery details.
   *
   * @return Contains the home page details.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #readHomePageDetails1()}
   *
   * Reads details to populate a product delivery home page.
   */
  @Deprecated
  public ReadHomePageDetails readHomePageDetails(final ReadHomePageKey key)
    throws AppException, InformationalException {
    // Create return object
    final ReadHomePageDetails readHomePageDetails = new ReadHomePageDetails();

    // ProductDeliveryHome manipulation variables
    final curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory.newInstance();
    final ProductDeliveryHomeKey productDeliveryHomeKey = new ProductDeliveryHomeKey();
    GetProductDeliveryDetailsResult getProductDeliveryDetailsResult;

    // Context description key object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // BEGIN, CR00066883, SPD
    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj = UserRecentActionFactory.newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();

    // END, CR00066883

    // Set key to read Product Delivery home page details
    productDeliveryHomeKey.caseID = key.caseID;

    // Read ProductDelivery home page details
    getProductDeliveryDetailsResult = productDeliveryHomeObj.getProductDeliveryDetails(
      productDeliveryHomeKey);

    // Assign home page details to output struct
    readHomePageDetails.homePageDetails.assign(
      getProductDeliveryDetailsResult.dtls);

    // BEGIN, CR00092078, SPD
    // Populate the bookmark indicator for the case
    readHomePageDetails.caseIsUserBookmarkInd = getProductDeliveryDetailsResult.productDeliveryHomeIndicators.caseIsUserBookmarkInd;
    // END, CR00092078

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to output object
    readHomePageDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    // BEGIN, CR00022280, PL

    // Read Transaction Log Details

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = key.caseID;

    // BEGIN CR00108134, GBA
    readHomePageDetails.transactionLogDtls.assign(
      caseTransactionLogProvider.get().readNumberOfTransactions(caseIDKey));
    // END CR00108134
    // END, CR00022280

    // BEGIN, CR00066883, SPD
    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = key.caseID;

    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);
    // END, CR00066883

    return readHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void generatePayment(final GeneratePaymentKey key)
    throws AppException, InformationalException {

    // GeneratePayment manipulation variables
    final curam.core.intf.GeneratePayment generatePaymentObj = curam.core.fact.GeneratePaymentFactory.newInstance();
    final CaseIdentifier caseIdentifier = new CaseIdentifier();

    // Assign key details to generate the payment
    caseIdentifier.caseID = key.caseID;

    // Call GeneratePayment BPO to generate the payment
    generatePaymentObj.generateInteractivePayment(caseIdentifier);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListReassessmentDecisionResult listReassessmentPeriodDecision(
    final ListDecisionsForReassessmentPeriodKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListReassessmentDecisionResult listReassessmentDecisionResult = new ListReassessmentDecisionResult();

    // ViewOverUnderPaymentResult manipulation variables
    final curam.core.intf.ViewOverUnderPaymentResult viewOverUnderPaymentResultObj = curam.core.fact.ViewOverUnderPaymentResultFactory.newInstance();
    final ViewReassessmentDecisionsByInfoIDKey viewReassessmentDecisionsByInfoIDKey = new ViewReassessmentDecisionsByInfoIDKey();

    // Assign key details to read decisions for reassessment period
    viewReassessmentDecisionsByInfoIDKey.assign(key);

    // Call ViewOverUnderPaymentResult BPO to return reassessment period
    // decisions
    listReassessmentDecisionResult.result = viewOverUnderPaymentResultObj.viewDecisionsForReassessmentPeriod(
      viewReassessmentDecisionsByInfoIDKey);

    // If the decision list is empty, return an informational to the client
    // saying that there was no original decision for the period selected for
    // comparison
    if (listReassessmentDecisionResult.result.detailsList.dtls.isEmpty()) {
      final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

      final AppException e = new AppException(
        BPOPRODUCTDELIVERY.INF_CASE_DECISION_PERIOD_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // Obtain the informational(s) to be returned to the client
      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {

        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        listReassessmentDecisionResult.informationalMsgDtlsList.dtls.addRef(
          informationalMsgDtls);
      }
    }

    // Set key to read context description
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    productDeliveryContextDescriptionKey.caseID = listReassessmentDecisionResult.result.details.caseID;

    listReassessmentDecisionResult.description = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listReassessmentDecisionResult;
  }

  // BEGIN, CR00222016, KH
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException Generic Exception Signature.
   */
  public FilteredReassessmentDecisionsDetailsList listFilteredDecisionsForReassessmentPeriod(
    final ReassessmentInfoKey key) throws AppException, InformationalException {

    return ViewOverUnderPaymentResultFactory.newInstance().listFilteredDecisionsForReassessmentPeriod(
      key);
  }

  // END, CR00222016

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReadOverUnderPaymentDetails readOverUnderPayment(
    final ReadOverUnderPaymentDetailsKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadOverUnderPaymentDetails readOverUnderPaymentDetails = new ReadOverUnderPaymentDetails();

    // ViewOverUnderPaymentResult manipulation variables
    final curam.core.intf.ViewOverUnderPaymentResult viewOverUnderPaymentResultObj = curam.core.fact.ViewOverUnderPaymentResultFactory.newInstance();
    final GetOverUnderPaymentDetailsByNomineeKey getOverUnderPaymentDetailsByNomineeKey = new GetOverUnderPaymentDetailsByNomineeKey();

    // Assign key details to read over/under payment details
    getOverUnderPaymentDetailsByNomineeKey.assign(key);

    // Call ViewOverUnderPaymentResult BPO to retrieve over/under payment
    // details and assign to output object
    readOverUnderPaymentDetails.assign(
      viewOverUnderPaymentResultObj.getDetailsByNominee(
        getOverUnderPaymentDetailsByNomineeKey));

    return readOverUnderPaymentDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CompareDecisionEvidenceResult compareDecisionEvidence(
    final CompareDecisionEvidenceKey key) throws AppException,
      InformationalException {

    // Create return object
    final CompareDecisionEvidenceResult compareDecisionEvidenceResult = new CompareDecisionEvidenceResult();

    // Assign key details to read decision evidence
    final CaseDecisionIDStruct caseDecisionIDStruct = new CaseDecisionIDStruct();

    caseDecisionIDStruct.caseDecisionID = key.newCaseDecisionID;

    final CaseDecisionIDStruct oldCaseDecisionIDStruct = new CaseDecisionIDStruct();

    oldCaseDecisionIDStruct.caseDecisionID = key.caseDecisionID;

    // Get decision evidence details
    final GetCaseReassessmentDecisionDetailsResult result = MaintainCaseDecisionFactory.newInstance().getCaseReassessmentDecisionDetails(
      caseDecisionIDStruct, oldCaseDecisionIDStruct);

    compareDecisionEvidenceResult.assign(result.caseDecisionHeaderDetails);

    // Assign new evidence to output object
    compareDecisionEvidenceResult.newEvidence = result.evidenceStruct.evidence;

    // Assign old evidence to output struct
    compareDecisionEvidenceResult.originalEvidence = result.oldEvidenceStruct.evidence;

    // BEGIN, CR00238809, VM
    if (compareDecisionEvidenceResult.originalEvidence.length() == 0) {

      final AppException ae = new AppException(
        BPOPRODUCTDELIVERY.INF_CASE_DECISION_NO_ORIGINAL_DECISION);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        ae, CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

      // Retrieve list of informational messages
      final String[] messages = TransactionInfo.getInformationalManager().obtainInformationalAsString();

      // Return the informational message - there should only be the one above
      for (final String message : messages) {
        final InformationalMsgDtls msgDtls = new InformationalMsgDtls();

        msgDtls.informationMsgTxt = message;
        compareDecisionEvidenceResult.msgs.dtls.addRef(msgDtls);
        break;
      }
    }
    // END, CR00238809

    return compareDecisionEvidenceResult;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DecisionDifferenceDetails compareChangedEvidenceOnly(
    final CompareDecisionEvidenceKey key) throws AppException,
      InformationalException {

    // Assign key details to read decision evidence
    final CaseDecisionIDStruct newCaseDecisionID = new CaseDecisionIDStruct();

    newCaseDecisionID.caseDecisionID = key.newCaseDecisionID;
    final CaseDecisionIDStruct prevCaseDecisionID = new CaseDecisionIDStruct();

    prevCaseDecisionID.caseDecisionID = key.caseDecisionID;

    return MaintainCaseDecisionFactory.newInstance().getEvidenceDifferenceDetails(
      newCaseDecisionID, prevCaseDecisionID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CompareRuleEvidenceResult compareRuleEvidence(
    final CompareRuleEvidenceKey key) throws AppException,
      InformationalException {

    // Create return object
    final CompareRuleEvidenceResult compareRuleEvidenceResult = new CompareRuleEvidenceResult();

    // MaintainCaseDecision manipulation variables
    final curam.core.intf.MaintainCaseDecision maintainCaseDecisionObj = curam.core.fact.MaintainCaseDecisionFactory.newInstance();
    final CaseDecisionIDStruct oldCaseDecisionIDStruct = new CaseDecisionIDStruct();
    final CaseDecisionIDStruct caseDecisionIDStruct = new CaseDecisionIDStruct();
    GetCaseReassessmentDecisionDetailsResult getCaseReassessmentDecisionDetailsResult;

    // Assign key details to read decision evidence
    caseDecisionIDStruct.caseDecisionID = key.newCaseDecisionID;
    oldCaseDecisionIDStruct.caseDecisionID = key.caseDecisionID;

    // Call MaintainCaseDecision BPO to get decision evidence details
    getCaseReassessmentDecisionDetailsResult = maintainCaseDecisionObj.getCaseReassessmentDecisionDetails(
      caseDecisionIDStruct, oldCaseDecisionIDStruct);

    compareRuleEvidenceResult.assign(
      getCaseReassessmentDecisionDetailsResult.caseDecisionHeaderDetails);

    // Assign new evidence to output object
    compareRuleEvidenceResult.newResultText = getCaseReassessmentDecisionDetailsResult.evaluateClaimResults.resultText;

    // Assign old evidence to output struct
    compareRuleEvidenceResult.originalResultText = getCaseReassessmentDecisionDetailsResult.oldEvaluateClaimResults.resultText;

    // BEGIN, CR00238809, VM
    if (compareRuleEvidenceResult.originalResultText.length() == 0) {

      final AppException ae = new AppException(
        BPOPRODUCTDELIVERY.INF_CASE_DECISION_NO_ORIGINAL_DECISION);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        ae, CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // Retrieve list of informational messages
      final String[] messages = TransactionInfo.getInformationalManager().obtainInformationalAsString();

      // Return the informational message - there should only be the one above
      for (final String message : messages) {
        final InformationalMsgDtls msgDtls = new InformationalMsgDtls();

        msgDtls.informationMsgTxt = message;
        compareRuleEvidenceResult.msgs.dtls.addRef(msgDtls);
        break;
      }
    }
    // END, CR00238809

    return compareRuleEvidenceResult;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListCaseFinancials listCaseFinancials(final ListCaseFinancialsKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListCaseFinancials listCaseFinancials = new ListCaseFinancials();

    // ViewCaseAccount manipulation variables
    final curam.core.intf.ViewCaseAccount viewCaseAccountObj = curam.core.fact.ViewCaseAccountFactory.newInstance();
    ViewCaseFinancialsResult viewCaseFinancialsResult;
    final CaseAccountIdentifier caseAccountIdentifier = new CaseAccountIdentifier();

    // Context description key
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Assign key details to list the case financials
    caseAccountIdentifier.assign(key);

    // Call ViewCaseAccount BPO to return the list of case financials
    viewCaseFinancialsResult = viewCaseAccountObj.viewCaseFinancials(
      caseAccountIdentifier);

    // Iterate through the list if it's populated
    if (!viewCaseFinancialsResult.caseAccountSummaryList.dtls.isEmpty()) {

      // Reserve space in output object
      listCaseFinancials.caseFinancialsList.dtls.ensureCapacity(
        viewCaseFinancialsResult.caseAccountSummaryList.dtls.size());

      // CaseFinancialDetails object
      CaseFinancialDetails caseFinancialDetails;

      for (int i = 0; i
        < viewCaseFinancialsResult.caseAccountSummaryList.dtls.size(); i++) {

        caseFinancialDetails = new CaseFinancialDetails();

        caseFinancialDetails.assign(viewCaseFinancialsResult.searchResultSumm);
        caseFinancialDetails.assign(
          viewCaseFinancialsResult.caseAccountSummaryList.dtls.item(i));

        listCaseFinancials.caseFinancialsList.dtls.addRef(caseFinancialDetails);
      }

    }

    // Set key to retrieve context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to output object
    listCaseFinancials.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listCaseFinancials;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public UtilityProductComponentList listProductComponent(
    final UtilityPaymentCaseKey key) throws AppException,
      InformationalException {

    // Utility rules component objects
    final UtilityRulesComponentsKey utilityRulesComponentsKey = new UtilityRulesComponentsKey();
    UtilityRulesComponentsList utilityRulesComponentsList;

    // Utility Payments object
    final curam.core.intf.MaintainUtilityPayments maintainUtilityPaymentsObj = curam.core.fact.MaintainUtilityPaymentsFactory.newInstance();

    // Component list object
    final UtilityProductComponentList utilityProductComponentList = new UtilityProductComponentList();

    // Get list of product components
    utilityRulesComponentsKey.caseID = key.caseID;

    utilityRulesComponentsList = maintainUtilityPaymentsObj.getProductComponents(
      utilityRulesComponentsKey);

    // Iterate through the list if not empty
    if (!utilityRulesComponentsList.dtls.isEmpty()) {

      // Reserve space in output object
      utilityProductComponentList.utilityProductComponentsDetails.ensureCapacity(
        utilityRulesComponentsList.dtls.size());

      // Product component object
      UtilityProductComponentsDetails utilityProductComponentsDetails;

      for (int i = 0; i < utilityRulesComponentsList.dtls.size(); i++) {

        utilityProductComponentsDetails = new UtilityProductComponentsDetails();

        utilityProductComponentsDetails.assign(
          utilityRulesComponentsList.dtls.item(i));

        utilityProductComponentList.utilityProductComponentsDetails.addRef(
          utilityProductComponentsDetails);
      }

    }

    // Return component list
    return utilityProductComponentList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListPDAdminCaseRoleDetails listAdminCaseRole(
    final ListAdminCaseRoleKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListPDAdminCaseRoleDetails listPDAdminCaseRoleDetails = new ListPDAdminCaseRoleDetails();

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();
    final curam.core.sl.struct.CaseUserRoleCaseIDKey caseUserRoleCaseIDKey = new curam.core.sl.struct.CaseUserRoleCaseIDKey();
    curam.core.sl.struct.CaseUserRoleDetailsList caseUserRoleDetailsList;

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Assign key details to retrieve the list of Admin Case Roles
    caseUserRoleCaseIDKey.dtls.caseID = key.maintainAdminCaseRolesKey.caseID;

    // Call CaseUserRole BPO to return the list of Case User Roles
    caseUserRoleDetailsList = caseUserRoleObj.listCaseUserRoles(
      caseUserRoleCaseIDKey);

    // Reserve space in caseUserRoleList
    listPDAdminCaseRoleDetails.caseUserRoleList.ensureCapacity(
      caseUserRoleDetailsList.dtls.size());

    for (int i = 0; i < caseUserRoleDetailsList.dtls.size(); i++) {

      final curam.core.sl.entity.struct.CaseUserRoleDetails caseUserRoleDetails = new curam.core.sl.entity.struct.CaseUserRoleDetails();

      caseUserRoleDetails.assign(
        listPDAdminCaseRoleDetails.caseUserRoleList.item(i));

      listPDAdminCaseRoleDetails.caseUserRoleList.addRef(caseUserRoleDetails);
    }

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.maintainAdminCaseRolesKey.caseID;

    // Read context description and set in return object
    listPDAdminCaseRoleDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listPDAdminCaseRoleDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListAttachmentDetails listAttachment(final ListAttachmentsKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListAttachmentDetails listAttachmentDetails = new ListAttachmentDetails();

    // MaintainAttachment manipulation variables
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory.newInstance();
    final AttachmentCaseID attachmentCaseID = new AttachmentCaseID();
    CaseAttachmentDetailsList caseAttachmentDetailsList;

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Assign key to retrieve list of attachments
    attachmentCaseID.assign(key);

    // Call MaintainAttachment BPO to retrieve the list of attachments
    caseAttachmentDetailsList = maintainAttachmentObj.searchIntegCaseAttachments(
      attachmentCaseID);

    // Check to see if the list is populated
    if (!caseAttachmentDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listAttachmentDetails.attachmentDetailsList.dtls.ensureCapacity(
        caseAttachmentDetailsList.dtls.size());

      // Assign details to return object
      listAttachmentDetails.attachmentDetailsList.assign(
        caseAttachmentDetailsList);
    }

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listAttachmentDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listAttachmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListPDClientRoleDetails listClientRole(final ListClientRoleKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListPDClientRoleDetails listPDClientRoleDetails = new ListPDClientRoleDetails();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.struct.ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new curam.core.sl.struct.ViewCaseParticipantRole_boKey();
    curam.core.sl.struct.ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read the list of client roles into the return object
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj.viewCaseParticipantRoleList(
      viewCaseParticipantRole_boKey);

    // Reserve space in caseParticipantRoleList
    listPDClientRoleDetails.caseParticipantRoleList.ensureCapacity(
      viewCaseParticipantRoleDetailsList.dtls.size());

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      final curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails = new curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails();

      caseParticipantRoleFullDetails.assign(
        viewCaseParticipantRoleDetailsList.dtls.item(i));

      listPDClientRoleDetails.caseParticipantRoleList.addRef(
        caseParticipantRoleFullDetails);
    }

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listPDClientRoleDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listPDClientRoleDetails;
  }

  // BEGIN, CR00119574, MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ICInvestigationDeliveryClientRoleList listInvestigationDeliveryCaseMembers(
    final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    // Reuse the client role list struct as it contains identical values
    final ICInvestigationDeliveryClientRoleList iCInvestigationDeliveryClientRoleList = new ICInvestigationDeliveryClientRoleList();

    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Read the list of case participant roles
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj.viewCaseMemberList(
      viewCaseParticipantRole_boKey);

    // Reserve space in participantList
    iCInvestigationDeliveryClientRoleList.dtlsList.ensureCapacity(
      viewCaseParticipantRoleDetailsList.dtls.size());

    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      iCInvestigationDeliveryClientRoleList.dtlsList.addRef(
        viewCaseParticipantRoleDetailsList.dtls.item(i));
    }
    // BEGIN, CR00105225, MC
    // Set key to read context description
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    // Get the Investigation delivery context description
    iCInvestigationDeliveryClientRoleList.contextDtls = getInvestigationDeliveryContextDescription(
      caseHeaderKey);
    // END, CR00105225

    return iCInvestigationDeliveryClientRoleList;
  }

  // END, CR00119574

  // ___________________________________________________________________________
  /**
   * @param key
   * Key to read the list of Product Delivery events.
   *
   * @return List of events on the Product Delivery.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #listEvent1(ListEventKey)}.
   * The new method returns the same details but also returns indicators that
   * will be used to conditionally display list row action appropriate to the
   * event type.
   *
   * Returns a list of events for a Product Delivery.
   */
  @Deprecated
  public ListEventDetails listEvent(final ListEventKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListEventDetails listEventDetails = new ListEventDetails();
    final ListEventDetails1 listEventDetails1 = listEvent1(key);

    listEventDetails.contextDescription = listEventDetails1.contextDescription;

    EventDetails eventDetails;

    for (int i = 0; i < listEventDetails.eventDetailsList.dtls.size(); i++) {
      eventDetails = new EventDetails();

      eventDetails.assign(listEventDetails1.eventDetailsList.dtls.item(i));
      listEventDetails.eventDetailsList.dtls.addRef(eventDetails);
    }

    return listEventDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListEventDetails1 listEvent1(final ListEventKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListEventDetails1 listEventDetails = new ListEventDetails1();

    // ViewCaseEvents manipulation variables
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory.newInstance();
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();
    ViewActiveCaseEventDetailsList1 viewActiveCaseEventDetailsList;

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Assign key to retrieve list of events
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;

    // Call ViewCaseEvents BPO to retrieve the list of events
    viewActiveCaseEventDetailsList = viewCaseEventsObj.readActiveEventsByType1(
      viewCaseEventsByCaseIDAndTypeKey);

    // Check to see if the list is populated
    if (!viewActiveCaseEventDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listEventDetails.eventDetailsList.dtls.ensureCapacity(
        viewActiveCaseEventDetailsList.dtls.size());

      // If the list has case event decisions of type superseded, do not return
      // them
      // on the view list for the case

      // Create new struct to hold all case events except those of type
      // superseded case decisions.
      final ViewActiveCaseEventDetailsList1 viewFileteredCaseEventDetailsList = new ViewActiveCaseEventDetailsList1();

      for (int i = 0; i < viewActiveCaseEventDetailsList.dtls.size(); i++) {
        // Check event to see of type case decision
        final curam.core.intf.CaseDecision caseDecisionObj = curam.core.fact.CaseDecisionFactory.newInstance();
        curam.core.struct.CaseDecisionDtls caseDecisionDtls = null;
        boolean caseEventTypeDecisionInd = true;

        final curam.core.struct.CaseDecisionKey caseDecisionKey = new curam.core.struct.CaseDecisionKey();

        caseDecisionKey.caseDecisionID = viewActiveCaseEventDetailsList.dtls.item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          caseEventTypeDecisionInd = false;
        }

        // If event of type caseDecision, then only add to list if an active
        // case decision
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode.equals(
            curam.codetable.CASEDECISIONSTATUS.CURRENT)) {

            viewFileteredCaseEventDetailsList.dtls.addRef(
              viewActiveCaseEventDetailsList.dtls.item(i));
          }
        } else {

          // if not a case decision event - add to list.
          viewFileteredCaseEventDetailsList.dtls.addRef(
            viewActiveCaseEventDetailsList.dtls.item(i));
        }

      }

      // Assign details to the return object
      listEventDetails.eventDetailsList.assign(
        viewFileteredCaseEventDetailsList);

    }

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listEventDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    // Determine if CPM and Appeals are installed
    if (Configuration.getBooleanProperty(EnvVars.ENV_CPM_ISINSTALLED)) {
      listEventDetails.isCPMInstalledInd = true;
    }

    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {
      listEventDetails.isAppealsInstalledInd = true;
    }

    return listEventDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListPDEvidenceDetails listEvidence(final ListEvidenceKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListPDEvidenceDetails listPDEvidenceDetails = new ListPDEvidenceDetails();

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();

    final curam.core.sl.struct.ListEvidenceTreeLessCanceledAndSupersededKey listEvidenceTreeLessCanceledAndSupersededKey = new curam.core.sl.struct.ListEvidenceTreeLessCanceledAndSupersededKey();
    curam.core.sl.struct.ListEvidenceTreeLessCanceledAndSupersededResult listEvidenceTreeLessCanceledAndSupersededResult;

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key details to retrieve the evidence list
    // Set key to retrieve the evidence list
    listEvidenceTreeLessCanceledAndSupersededKey.key.caseID = key.caseID;
    listEvidenceTreeLessCanceledAndSupersededKey.key.statusCode = EVIDENCETREESTATUS.CANCELED;
    listEvidenceTreeLessCanceledAndSupersededKey.key.statusCode = EVIDENCETREESTATUS.SUPERSEDED;

    // Call API method to retrieve the evidence list
    listEvidenceTreeLessCanceledAndSupersededResult = caseEvidenceAPIObj.listEvidenceTreeLessCanceledAndSuperseded(
      listEvidenceTreeLessCanceledAndSupersededKey);

    // Check to see if the list is populated
    if (!listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.isEmpty()) {

      final curam.core.sl.entity.struct.CaseEvidenceTreeKeyStruct caseEvidenceTreeKeyStruct = new curam.core.sl.entity.struct.CaseEvidenceTreeKeyStruct();
      curam.core.sl.struct.ListGroupOnTreeResult listGroupOnTreeResult;

      // Set key to list groups on tree
      caseEvidenceTreeKeyStruct.caseEvidenceTreeID = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(0).caseEvidenceTreeID;

      // Call API method to list groups on tree
      listGroupOnTreeResult = caseEvidenceAPIObj.listGroupOnTree(
        caseEvidenceTreeKeyStruct);

      // Reserve space in the return object
      listPDEvidenceDetails.evidenceDetailsList.dtls.ensureCapacity(
        listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.size());

      EvidenceDetails evidenceDetails;

      // Iterate through and process the list of evidences
      for (int i = 0; i
        < listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.size(); i++) {

        evidenceDetails = new EvidenceDetails();

        // Assign details
        evidenceDetails.effectiveFrom = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).effectiveFrom;
        evidenceDetails.statusCode = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).statusCode;
        evidenceDetails.evidenceID = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).caseEvidenceTreeID;
        // Only one product exists on demo products, so select first
        // element in list
        evidenceDetails.versionNo = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).versionNo;
        evidenceDetails.evidenceGroupNameCode = listGroupOnTreeResult.dtls.item(0).evidenceGroupNameCode;

        // Check to see if the effectiveFromDate is empty
        if (listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).effectiveFrom.isZero()) {

          // Use string constant for case start date
          evidenceDetails.evidenceFromStr = // BEGIN, CR00163471, JC
            curam.message.BPOMAINTAINPRODUCTDELIVERY.INF_CASE_START_DATE.getMessageText(
            TransactionInfo.getProgramLocale());
          // END, CR00163471, JC

        } else {

          // BEGIN, CR00086110, POB
          // Set evidenceFrom date string in evidence object
          evidenceDetails.evidenceFromStr = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).effectiveFrom.getDateTime().toString();
          // END, CR00086110
        }

        // Add details to return object
        listPDEvidenceDetails.evidenceDetailsList.dtls.addRef(evidenceDetails);
      }

    }

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listPDEvidenceDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listPDEvidenceDetails;
  }

  // BEGIN, CR00231506, PDN
  // ___________________________________________________________________________
  /**
   * Returns a list of notes on a Product Delivery.
   * @param key
   * Key to read the list of notes on a Product Delivery.
   *
   * @return List of Product Delivery notes.
   *
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #listNote1()}
   */
  @Deprecated
  public ListNoteDetails listNote(final ListNoteKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListNoteDetails listNoteDetails = new ListNoteDetails();

    final ListNoteDetails1 listNoteDetails1 = listNote1(key);

    listNoteDetails.assign(listNoteDetails1);

    return listNoteDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListNoteDetails1 listNote1(final ListNoteKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListNoteDetails1 listNoteDetails = new ListNoteDetails1();

    // CaseNote manipulation variables
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();
    final curam.core.sl.struct.CaseKey caseKey = new curam.core.sl.struct.CaseKey();
    CaseNoteList1 caseNoteList;

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key to read the list of notes
    caseKey.key.caseID = key.caseID;

    // Call CaseNotes BPO to retrieve the list of notes
    caseNoteList = caseNoteObj.list1(caseKey);

    // Check to see if the list if populated
    if (!caseNoteList.details.isEmpty()) {

      // Reserve space in the return object
      listNoteDetails.noteDetailsList.dtls.ensureCapacity(
        caseNoteList.details.size());

      // NoteDetails object
      NoteDetails1 noteDetails;

      // Assign details to return object
      for (int i = 0; i < caseNoteList.details.size(); i++) {

        noteDetails = new NoteDetails1();

        // Assign note details
        noteDetails.assign(caseNoteList.details.item(i));

        // Add details to the return objects
        listNoteDetails.noteDetailsList.dtls.addRef(noteDetails);
      }

    }

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listNoteDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listNoteDetails;
  }

  // END, CR00231506

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListRelationshipCaseDetails listRelationship(
    final ListCaseRelationshipKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListRelationshipCaseDetails listRelationshipCaseDetails = new ListRelationshipCaseDetails();

    // MaintainRelatedCases manipulation variables
    final curam.core.intf.MaintainRelatedCases maintainRelatedCasesObj = curam.core.fact.MaintainRelatedCasesFactory.newInstance();
    final GetRelatedCasesKey getRelatedCasesKey = new GetRelatedCasesKey();
    GetRelatedCasesList getRelatedCasesList;

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Assign key details to retrieve list of related cases
    getRelatedCasesKey.assign(key);

    // Call MaintainRelatedCases BPO to retrieve the list of related cases
    getRelatedCasesList = maintainRelatedCasesObj.getRelatedCases(
      getRelatedCasesKey);

    // Check to see if the list is populated
    if (!getRelatedCasesList.dtls.isEmpty()) {

      // Reserve space in the return object
      listRelationshipCaseDetails.relationshipDetailsList.dtls.ensureCapacity(
        getRelatedCasesList.dtls.size());

      // Assign details to return object
      listRelationshipCaseDetails.relationshipDetailsList.assign(
        getRelatedCasesList);
    }

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description
    listRelationshipCaseDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listRelationshipCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void cancelDeduction(final CancelDeductionKey key)
    throws AppException, InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final CancelDeductionItemKey cancelDeductionItemKey = new CancelDeductionItemKey();

    // Set cancel deduction item key details
    cancelDeductionItemKey.caseDeductionItemID = key.caseDeductionItemID;
    cancelDeductionItemKey.versionNo = key.versionNo;

    // Call BPO to cancel deduction item
    maintainDeductionItemsObj.cancelDeductionItem(cancelDeductionItemKey);
  }

  // ___________________________________________________________________________
  /**
   * Creates a deduction item on a case.
   *
   * @param details
   * Details of the deduction item being created.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createDeduction1(CreateDeductionDetails)}.
   */
  @Deprecated
  public void createDeduction(final CreateDeductionDetails details)
    throws AppException, InformationalException {

    // Assign details to create deduction
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    maintainDeductionItemDetails.assign(details);

    MaintainDeductionItemsFactory.newInstance().createDeductionItem(
      maintainDeductionItemDetails);
  }

  // BEGIN, CR00232757, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void createDeduction1(final CreateDeductionDetails details)
    throws AppException, InformationalException {

    // Assign details to create deduction
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    maintainDeductionItemDetails.assign(details);

    MaintainDeductionItemsFactory.newInstance().createDeductionItem1(
      maintainDeductionItemDetails);
  }

  // END, CR00232757

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListActiveLiabilityDetails listActiveLiabilitiesForConcern(
    final ListActiveLiabilitesForConcernKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListActiveLiabilityDetails listActiveLiabilityDetails = new ListActiveLiabilityDetails();

    // BEGIN, CR00127323, KH
    // Set key to retrieve list of active liabilities for a concern
    final CreateDeductionItemDtls createDeductionItemDtls = new CreateDeductionItemDtls();

    createDeductionItemDtls.concernRoleID = key.concernRoleID;

    // Retrieve the list of active liabilities and assign to return object
    listActiveLiabilityDetails.assign(
      MaintainDeductionItemsFactory.newInstance().getActiveLiabilityCasesForConcernRole(
        createDeductionItemDtls));
    // END, CR00127323

    return listActiveLiabilityDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListObjectiveDeductableDetails listDeductableObjectives(
    final ListDeductableObjectivesKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListObjectiveDeductableDetails listObjectiveDeductableDetails = new ListObjectiveDeductableDetails();

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final CreateDeductionItemDtls createDeductionItemDtls = new CreateDeductionItemDtls();

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Assign key details to retrieve list of deductible objectives
    createDeductionItemDtls.assign(key);

    // Call MaintainDeductionItems BPO to retrieve the list of deductible
    // objectives for the case and assign to return objective
    listObjectiveDeductableDetails.assign(
      maintainDeductionItemsObj.getCaseComponents(createDeductionItemDtls));

    // Set key to read product delivery context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read the context description
    listObjectiveDeductableDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listObjectiveDeductableDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListDeductionDetails listDeduction(final ListCaseDeductionsKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListDeductionDetails listDeductionDetails = new ListDeductionDetails();

    // MaintainDeductionItemAssistant manipulation variables
    final curam.core.intf.MaintainDeductionItemsAssistant maintainDeductionItemsAssistantObj = curam.core.fact.MaintainDeductionItemsAssistantFactory.newInstance();
    final DeductionItemCaseID deductionItemCaseID = new DeductionItemCaseID();
    DeductionItemDetailsList deductionItemDetailsList;

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key to retrieve the list of existing deductions on the case
    deductionItemCaseID.caseID = key.caseID;
    MaintainDeductionItemDetails maintainDeductionItemDetails;

    // Call MaintainDeductionItemAssistant BPO to retrieve the list of
    // deductions on the case and assign to return object
    deductionItemDetailsList = maintainDeductionItemsAssistantObj.getCaseDeductionItems(
      deductionItemCaseID);

    // Check to see if the list is populated
    if (!deductionItemDetailsList.dtls.isEmpty()) {

      // Set the concernRoleID in return object
      listDeductionDetails.concernRoleKeyStruct.concernRoleID = deductionItemDetailsList.dtls.item(0).concernRoleID;

      // Reserve space in the return object
      listDeductionDetails.dtls.ensureCapacity(
        deductionItemDetailsList.dtls.size());

      curam.core.facade.struct.DeductionDetails deductionDetails;

      // Iterate through the list
      for (int i = 0; i < deductionItemDetailsList.dtls.size(); i++) {

        deductionDetails = new curam.core.facade.struct.DeductionDetails();

        maintainDeductionItemDetails = new curam.core.struct.MaintainDeductionItemDetails();

        // Assign details
        maintainDeductionItemDetails.assign(
          deductionItemDetailsList.dtls.item(i));

        // BEGIN, CR00174782, CD
        final DeterminationCalculator determinationCalculator = determinationCalculatorFactory.newInstanceForCaseID(
          deductionItemDetailsList.dtls.item(i).caseID);

        // Retrieve rule set
        final EligibilityEntitlementRuleSet ruleSet = determinationCalculator.getEligibilityEntitlementRuleSet(
          deductionItemDetailsList.dtls.item(i).startDate);

        // Retrieve an objective
        final ObjectiveType objectiveType = ruleSet.getObjectiveType(
          deductionItemDetailsList.dtls.item(i).rulesObjectiveID);

        // Set rulesObjectiveType in deductionDetails
        maintainDeductionItemDetails.rulesObjectiveType = objectiveType.getName().getCode();
        // END, CR00174782
        deductionDetails.assign(maintainDeductionItemDetails);

        // Need to check if the related rulesObjectiveID is populated
        if (deductionItemDetailsList.dtls.item(i).relatedObjectiveID.length()
          != 0) {

          // Set the appliedInd to true as the deduction was applied against
          // a liability (i.e. relatedObjectiveID != 0)
          deductionDetails.appliedInd = true;

          // BEGIN, CR00174782, CD
          final DeterminationCalculator relatedPDAssessor = determinationCalculatorFactory.newInstanceForCaseID(
            deductionItemDetailsList.dtls.item(i).relatedCaseID);

          // Retrieve rule set
          final EligibilityEntitlementRuleSet relatedRuleSet = relatedPDAssessor.getEligibilityEntitlementRuleSet(
            deductionItemDetailsList.dtls.item(i).startDate);

          // Retrieve an objective type
          final ObjectiveType relatedObjectiveType = relatedRuleSet.getObjectiveType(
            deductionItemDetailsList.dtls.item(i).relatedObjectiveID);

          // Set rulesObjectiveType in deductionDetails
          deductionDetails.relatedRulesObjectiveType = relatedObjectiveType.getName().getCode();
          // END, CR00174782
        }

        // Add to return object
        listDeductionDetails.dtls.addRef(deductionDetails);
      }

    } else {

      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      ReadParticipantRoleIDDetails readParticipantRoleIDDetails;

      // Set key to read caseHeader
      caseHeaderKey.caseID = key.caseID;

      // Read caseHeader
      readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
        caseHeaderKey);

      // Set the concernRoleID in return object
      listDeductionDetails.concernRoleKeyStruct.concernRoleID = readParticipantRoleIDDetails.concernRoleID;
    }

    // Set key to read product delivery context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read the context description
    listDeductionDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listDeductionDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListObjectiveDeductionDetails listDeductionsForObjective(
    final ListDeductionsForObjectiveKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListObjectiveDeductionDetails listObjectiveDeductionDetails = new ListObjectiveDeductionDetails();

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final CaseIDCompIDNomCaseLinkID caseIDCompIDNomCaseLinkID = new CaseIDCompIDNomCaseLinkID();
    GetExistingDeductionsResult getExistingDeductionsResult;

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key to retrieve existing deductions on an objective
    caseIDCompIDNomCaseLinkID.caseID = key.caseID;
    caseIDCompIDNomCaseLinkID.rulesObjectiveID = key.rulesObjectiveID;
    caseIDCompIDNomCaseLinkID.caseNomineeID = key.caseNomineeID;

    // Call MaintainDeductionItems BPO to retrieve the list of existing
    // deductions on an objective and assign to return object
    getExistingDeductionsResult = maintainDeductionItemsObj.getExistingDeductions(
      caseIDCompIDNomCaseLinkID);

    if (!getExistingDeductionsResult.deductionDetailsList.dtls.isEmpty()) {

      // Reserve space in return object
      listObjectiveDeductionDetails.dtls.ensureCapacity(
        getExistingDeductionsResult.deductionDetailsList.dtls.size());

      ObjectiveDeductionDetails objectiveDeductionDetails;

      for (int i = 0; i
        < getExistingDeductionsResult.deductionDetailsList.dtls.size(); i++) {

        objectiveDeductionDetails = new ObjectiveDeductionDetails();

        objectiveDeductionDetails.assign(
          getExistingDeductionsResult.deductionDetailsList.dtls.item(i));

        objectiveDeductionDetails.type = getExistingDeductionsResult.deductionDetailsList.dtls.item(i).rulesObjectiveType;

        objectiveDeductionDetails.relatedComponentType = getExistingDeductionsResult.deductionDetailsList.dtls.item(i).relatedObjectiveType;

        listObjectiveDeductionDetails.dtls.addRef(objectiveDeductionDetails);
      }

    }

    // Set key to read product delivery context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read the context description
    listObjectiveDeductionDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listObjectiveDeductionDetails;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * Key to read details of a deduction item.
   *
   * @return Deduction Item details.
   * @deprecated Since Curam 6.0, replaced by {@link #readDeduction1()}
   *
   * Reads details of a case deduction item.
   */
  @Deprecated
  public ReadDeductionDetails readDeduction(final ReadDeductionKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadDeductionDetails readDeductionDetails = new ReadDeductionDetails();

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final CaseDeductionItemID caseDeductionItemID = new CaseDeductionItemID();
    MaintainDeductionItemDetails maintainDeductionItemDetails;
    ComponentNomineeDtlsList componentNomineeDtlsList = new ComponentNomineeDtlsList();
    final CaseKey casekey = new CaseKey();

    // Assign key details to read the deduction details
    caseDeductionItemID.caseDeductionItemID = key.caseDeductionItemID;

    // Call MaintainDeductionItems BPO to read the deduction details
    maintainDeductionItemDetails = maintainDeductionItemsObj.readDeductionItem(
      caseDeductionItemID);

    // Assign details to return object
    readDeductionDetails.assign(maintainDeductionItemDetails);

    readDeductionDetails.dtls.assign(maintainDeductionItemDetails);

    // Set key for read
    casekey.caseID = maintainDeductionItemDetails.caseID;

    // Returns component and nominee details
    componentNomineeDtlsList = maintainDeductionItemsObj.listComponentNomineeDetails(
      casekey);

    readDeductionDetails.dtlsList.dtls.assign(componentNomineeDtlsList);

    // BEGIN, CR00000541, SD
    readDeductionDetails.nomineeIDPopup = maintainDeductionItemDetails.caseNomineeID;
    readDeductionDetails.rulesObjectiveIDPopup = maintainDeductionItemDetails.rulesObjectiveID;
    // END, CR00000541

    return readDeductionDetails;
  }

  // BEGIN, CR00165145, JMA
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReadDeductionAndHeaderDetails readDeduction1(final ReadDeductionKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadDeductionAndHeaderDetails readDeductionAndHeaderDetails = new ReadDeductionAndHeaderDetails();

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final CaseDeductionItemID caseDeductionItemID = new CaseDeductionItemID();
    MaintainDeductionItemDetails maintainDeductionItemDetails;
    ComponentNomineeDtlsList componentNomineeDtlsList = new ComponentNomineeDtlsList();
    final CaseKey casekey = new CaseKey();

    // Assign key details to read the deduction details
    caseDeductionItemID.caseDeductionItemID = key.caseDeductionItemID;

    // Call MaintainDeductionItems BPO to read the deduction details
    maintainDeductionItemDetails = maintainDeductionItemsObj.readDeductionItem(
      caseDeductionItemID);

    // Assign details to return object
    readDeductionAndHeaderDetails.readDeductionDetails.assign(
      maintainDeductionItemDetails);

    readDeductionAndHeaderDetails.readDeductionDetails.dtls.assign(
      maintainDeductionItemDetails);

    // Set key for read
    casekey.caseID = maintainDeductionItemDetails.caseID;

    // Returns component and nominee details
    componentNomineeDtlsList = maintainDeductionItemsObj.listComponentNomineeDetails(
      casekey);

    readDeductionAndHeaderDetails.readDeductionDetails.dtlsList.dtls.assign(
      componentNomineeDtlsList);

    readDeductionAndHeaderDetails.readDeductionDetails.nomineeIDPopup = maintainDeductionItemDetails.caseNomineeID;
    readDeductionAndHeaderDetails.readDeductionDetails.rulesObjectiveIDPopup = maintainDeductionItemDetails.rulesObjectiveID;

    if (maintainDeductionItemDetails.category.equals(
      DEDUCTIONTYPECODE.APPLIEDDEDUCTION)) {

      final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

      caseIDKey.caseID = readDeductionAndHeaderDetails.readDeductionDetails.relatedCaseID;

      readDeductionAndHeaderDetails.deductionHeaderDetails = readDeductionLiabilityDetails(
        caseIDKey);

    }

    if (readDeductionAndHeaderDetails.readDeductionDetails.dtls.businessStatus.equals(
      BUSINESSSTATUS.ACTIVE)) {

      readDeductionAndHeaderDetails.activeInd = true;
    }

    return readDeductionAndHeaderDetails;
  }

  // END, CR00165145

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListUtilityPayments listUtilityPayment(final ListUtilityPaymentKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListUtilityPayments listUtilityPayments = new ListUtilityPayments();

    // HouseholdBudgetItem manipulation variables
    final curam.core.intf.HouseholdBudgetItem householdBudgetItemObj = curam.core.fact.HouseholdBudgetItemFactory.newInstance();
    final HouseholdBudgetItemCaseIDKey householdBudgetItemCaseIDKey = new HouseholdBudgetItemCaseIDKey();
    HouseholdBudgetItemDtlsList householdBudgetItemDtlsList;

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key to read utility payments
    householdBudgetItemCaseIDKey.caseID = key.caseID;

    // Read list of utility payments
    householdBudgetItemDtlsList = householdBudgetItemObj.searchByCaseID(
      householdBudgetItemCaseIDKey);

    // Retrieve concernRoleID of the participant
    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    ReadParticipantRoleIDDetails readParticipantRoleIDDetails;

    // Set key to read caseHeader
    caseHeaderKey.caseID = key.caseID;

    // Read CaseHeader
    readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
      caseHeaderKey);

    // Map concernRoleID to return object
    listUtilityPayments.concernRoleStruct.concernRoleID = readParticipantRoleIDDetails.concernRoleID;

    // Check to see if the list is populated
    if (!householdBudgetItemDtlsList.dtls.isEmpty()) {

      // variables used to retrieve rule set for case
      final curam.core.intf.CaseRulesLink caseRulesLinkObj = curam.core.fact.CaseRulesLinkFactory.newInstance();
      final LookupRulesForCaseKey lookupRulesForCaseKey = new LookupRulesForCaseKey();
      LookupRulesForCaseDetails lookupRulesForCaseDetails;

      // Reserve space in the return object
      listUtilityPayments.utilityPaymentsList.dtls.ensureCapacity(
        householdBudgetItemDtlsList.dtls.size());

      UtilityPaymentDetails utilityPaymentDetails;

      for (int i = 0; i < householdBudgetItemDtlsList.dtls.size(); i++) {

        utilityPaymentDetails = new UtilityPaymentDetails();

        // Assign details for list item
        utilityPaymentDetails.assign(householdBudgetItemDtlsList.dtls.item(i));

        if (householdBudgetItemDtlsList.dtls.item(i).rulesObjectiveID.length()
          != 0) {

          lookupRulesForCaseKey.date = householdBudgetItemDtlsList.dtls.item(i).startDate;
          lookupRulesForCaseKey.caseID = householdBudgetItemDtlsList.dtls.item(i).caseID;

          // retrieve rule set
          lookupRulesForCaseDetails = caseRulesLinkObj.lookupRulesForCase(
            lookupRulesForCaseKey);

          final String ruleSetID = lookupRulesForCaseDetails.ruleSetID;

          // read rules objective
          final curam.util.rules.RulesObjectiveResult rulesObjectiveResult = curam.util.rules.Interrule.getDynamicObjective(
            ruleSetID,
            householdBudgetItemDtlsList.dtls.item(i).rulesObjectiveID);

          utilityPaymentDetails.rulesObjectiveType = rulesObjectiveResult.getType();
        }

        // RulesObjective manipulation variables
        final curam.core.intf.Utility utilityObj = curam.core.fact.UtilityFactory.newInstance();
        final UtilityKey utilityKey = new UtilityKey();
        UtilityDtls utilityDtls;

        // Set Key
        utilityKey.concernRoleID = utilityPaymentDetails.utilConcernRoleID;

        // read Details
        utilityDtls = utilityObj.read(utilityKey);

        utilityPaymentDetails.utilityName = utilityDtls.name;

        // Add to return object
        listUtilityPayments.utilityPaymentsList.dtls.addRef(
          utilityPaymentDetails);
      }

    }

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Retrieve context description
    listUtilityPayments.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listUtilityPayments;
  }

  // BEGIN, CR00231961, ZV
  // ___________________________________________________________________________
  /**
   * Creates a representative of type nominee.
   *
   * @param dtls
   * The nominee details
   *
   * @return The identifier for the representative
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createNomineeRepresentativeWithTextBankAccountSortCode()}.
   * See release note: CR00231961
   */
  @Deprecated
  public RepresentativeID createNomineeRepresentative(
    final RepresentativeRegistrationDetails dtls) throws AppException,
      InformationalException {

    final RepresentativeRegistrationWithTextBankAccountSortCodeDetails representativeDetails = new RepresentativeRegistrationWithTextBankAccountSortCodeDetails();

    representativeDetails.representativeRegistrationDetails.assign(
      dtls.representativeRegistrationDetails);
    representativeDetails.bankSortCode = dtls.representativeRegistrationDetails.representativeRegistrationDetails.bankSortCode;

    return createNomineeRepresentativeWithTextBankAccountSortCode(
      representativeDetails);
  }

  // END, CR00231961

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListDecisionDetails listActiveDecision(final ListDecisionKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListDecisionDetails listDecisionDetails = new curam.core.facade.struct.ListDecisionDetails();

    // MaintainCaseDecision business object
    final curam.core.intf.MaintainCaseDecision maintainCaseDecisionObj = curam.core.fact.MaintainCaseDecisionFactory.newInstance();

    // curam.core.facade.struct.ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new curam.core.facade.struct.ProductDeliveryContextDescriptionKey();

    // curam.core.struct.MaintainCaseDecisionCaseIDKey object
    final MaintainCaseDecisionCaseIDKey maintainCaseDecisionCaseIDKey = new curam.core.struct.MaintainCaseDecisionCaseIDKey();

    // Set key to retrieve decisions
    maintainCaseDecisionCaseIDKey.caseID = key.caseID;

    // Retrieve case decisions
    listDecisionDetails.assign(
      maintainCaseDecisionObj.getActiveCaseDecisions(
        maintainCaseDecisionCaseIDKey));

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Retrieve context description
    listDecisionDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listDecisionDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListPDDeliveryPatternHistoryDetails_fo listDeliveryPatternInfoDetails(
    final ProductDeliveryPatternByCaseIDKey key) throws AppException,
      InformationalException {

    // Manipulation variables
    final ListPDDeliveryPatternHistoryDetails_fo listPDDeliveryPatternHistoryDetails = new ListPDDeliveryPatternHistoryDetails_fo();

    final curam.core.sl.struct.ProductDeliveryPatternByCaseIDKey productDeliveryPatternByCaseIDKey_bo = new curam.core.sl.struct.ProductDeliveryPatternByCaseIDKey();

    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new curam.core.facade.struct.ProductDeliveryContextDescriptionKey();

    // Set the caseID
    productDeliveryPatternByCaseIDKey_bo.productDeliveryPatternByCaseIDKey.caseID = key.productDeliveryPatternByCaseIDKey.caseID;

    // Read back the list of delivery patterns.
    listPDDeliveryPatternHistoryDetails.productDeliveryPatternInfoDetailList = caseNomineeObj.listProductDeliveryPatternDetailsForCase(
      productDeliveryPatternByCaseIDKey_bo);

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.productDeliveryPatternByCaseIDKey.caseID;

    // Read the product delivery context description
    listPDDeliveryPatternHistoryDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listPDDeliveryPatternHistoryDetails;
  }

  // BEGIN, CR00201663, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListPDDeliveryPatternHistoryDetails_fo listCurrentDeliveryPattern(
    final ProductDeliveryPatternByCaseIDKey key) throws AppException,
      InformationalException {

    // Manipulation variables
    final ListPDDeliveryPatternHistoryDetails_fo listPDDeliveryPatternHistoryDetails = new ListPDDeliveryPatternHistoryDetails_fo();

    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new curam.core.facade.struct.ProductDeliveryContextDescriptionKey();

    final ProductDeliveryPatternByCaseIDKey deliveryPatternKey = new ProductDeliveryPatternByCaseIDKey();

    // Set the caseID
    deliveryPatternKey.productDeliveryPatternByCaseIDKey.caseID = key.productDeliveryPatternByCaseIDKey.caseID;

    // Read back the list of delivery patterns.
    listPDDeliveryPatternHistoryDetails.productDeliveryPatternInfoDetailList = caseNomineeObj.listCurrentDeliveryPatternForCase(
      deliveryPatternKey);

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.productDeliveryPatternByCaseIDKey.caseID;

    // Read the product delivery context description
    listPDDeliveryPatternHistoryDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listPDDeliveryPatternHistoryDetails;
  }

  // END, CR00201663

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListEvidenceUsedByRuleResult listEvidenceUsedByRule(
    final ListEvidenceUsedByRuleKey key) throws AppException,
      InformationalException {

    final ListEvidenceUsedByRuleResult listEvidenceUsedByRuleResult = new ListEvidenceUsedByRuleResult();

    final ReadCaseDecisionKey readCaseDecisionKey = new ReadCaseDecisionKey();

    readCaseDecisionKey.caseDecisionID = key.decisionID;

    final ReadCaseDecisionDetails readCaseDecisionDetails = readDecision(
      readCaseDecisionKey);

    final MaintainCaseDecision maintainCaseDecisionObj = MaintainCaseDecisionFactory.newInstance();
    final CaseDecisionIDStruct caseDecisionIDStruct = new CaseDecisionIDStruct();
    final CaseDecisionKey caseDecisionKey = new CaseDecisionKey();

    caseDecisionIDStruct.caseDecisionID = key.decisionID;

    final CaseDecisionCaseID caseDecisionCaseID = maintainCaseDecisionObj.getCaseID(
      caseDecisionIDStruct);

    // CaseRulesLink manipulation variables
    final curam.core.intf.CaseRulesLink caseRulesLinkObj = curam.core.fact.CaseRulesLinkFactory.newInstance();
    final LookupRulesForCaseKey lookupRulesForCaseKey = new LookupRulesForCaseKey();
    LookupRulesForCaseDetails lookupRulesForCaseDetails;

    // set key to look up rules for case
    lookupRulesForCaseKey.caseID = caseDecisionCaseID.dtls.caseID;
    // HARP BEGIN 55873, CC
    lookupRulesForCaseKey.date = readCaseDecisionDetails.decisionResult.caseDecisionHeaderDetails.decisionFromDate;

    // look up rules for case
    lookupRulesForCaseDetails = caseRulesLinkObj.lookupRulesForCase(
      lookupRulesForCaseKey);

    final RulesResultHelper rulesResultHelper = new RulesResultHelper();

    caseDecisionKey.caseDecisionID = key.decisionID;
    rulesResultHelper.reconstructDecisionData(caseDecisionKey);

    final EvidenceList evidenceList = EvidenceTextDecoder.getEvidenceList(
      lookupRulesForCaseDetails.ruleSetID,
      rulesResultHelper.evidenceBuf.toString());

    final ResultBuffer resultBuffer = ResultTextDecoder.decode(
      lookupRulesForCaseDetails.ruleSetID,
      rulesResultHelper.string2Blob(rulesResultHelper.flowBuf.toString(),
      caseDecisionCaseID.dtls.caseID),
      rulesResultHelper.string2Blob(rulesResultHelper.resultBuf.toString(),
      caseDecisionCaseID.dtls.caseID),
      evidenceList,
      RulesEngine.kNormal);

    listEvidenceUsedByRuleResult.evidence.evidence = evidenceList.getEvidenceXMLForSingleRule(
      resultBuffer, key.ruleID);

    // BEGIN, CR00103765, ZV
    // assign rule name to output structure
    listEvidenceUsedByRuleResult.ruleName.ruleName = resultBuffer.getResultAtPosition(
      resultBuffer.getPosition(key.ruleID));
    // END, CR00103765

    return listEvidenceUsedByRuleResult;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyDeductionItem(final MaintainDeductionItemDetails details)
    throws AppException, InformationalException {

    MaintainDeductionItemsFactory.newInstance().modifyDeduction(details);
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * Contains the benefit underpayment case identifier.
   *
   * @return Benefit underpayment home page details.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #readBenefitUnderpmtHomePageDetails1()}
   *
   * Reads benefit underpayment home page details.
   */
  @Deprecated
  public BenefitUnderpmtHomePageDetails readBenefitUnderpmtHomePageDetails(
    final ReadHomePageKey key) throws AppException, InformationalException {

    // Create return object
    final BenefitUnderpmtHomePageDetails benefitUnderpmtHomePageDetails = new BenefitUnderpmtHomePageDetails();

    // ReassessmentProduct manipulation variables
    final curam.core.sl.struct.GetUnderpmtEvidenceKey getUnderpmtEvidenceKey = new curam.core.sl.struct.GetUnderpmtEvidenceKey();

    // Call local method to retrieve home page details - this includes the
    // context description
    benefitUnderpmtHomePageDetails.details = readHomePageDetails(key);

    // Now need to retrieve the benefit underpayment evidence as this is
    // going to be shown on the home page
    getUnderpmtEvidenceKey.caseID = key.caseID;

    // BEGIN, CR00211744, VM
    final GetBUCaseEvidenceKey getBUCaseEvidenceKey = new GetBUCaseEvidenceKey();

    getBUCaseEvidenceKey.key.caseID = key.caseID;

    benefitUnderpmtHomePageDetails.evidenceDetails = assessmentEngine.getBenefitUnderpaymentCaseEvidence(getBUCaseEvidenceKey).evidenceResult;
    // END, CR00211744

    return benefitUnderpmtHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void modifyApprovalRequest(final PDModifyReasonKey pdModifyReasonKey)
    throws AppException, InformationalException {

    final UnimplementedException e = new UnimplementedException();

    throw e;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public PDApprovalRequestDetails viewApprovalRequest(
    final PDApprovalRequestKey pdApprovalRequestIDKey) throws AppException,
      InformationalException {

    // create return value
    final PDApprovalRequestDetails pdApprovalRequestDetails = new PDApprovalRequestDetails();

    // create approval request object
    final curam.core.sl.intf.ApprovalRequest approvalRequestObj = curam.core.sl.fact.ApprovalRequestFactory.newInstance();

    // read product delivery approval request details
    pdApprovalRequestDetails.pdApprovalRequestDetails = approvalRequestObj.readProductDeliveryApprovalRequestDetails(
      pdApprovalRequestIDKey.pdApprovalRequestKey);

    // return product delivery approval request details
    return pdApprovalRequestDetails;
  }

  // BEGIN, CR00192165, VM
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public OutcomeNameAndIDDetailsList listOutcomesForCase(
    final ListOutcomesKey key) throws AppException, InformationalException {

    // returned value
    final OutcomeNameAndIDDetailsList outcomeNameAndIDDetailsList = new OutcomeNameAndIDDetailsList();

    // Product Delivery Planned Item link business object
    final curam.core.sl.intf.ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = curam.core.sl.fact.ProductDeliveryPlanItemLinkFactory.newInstance();
    final curam.core.sl.struct.PlannedItemCaseIDKey plannedItemCaseIDKey = new curam.core.sl.struct.PlannedItemCaseIDKey();

    // set the key
    plannedItemCaseIDKey.key.caseID = key.caseID;

    // list outcomes
    outcomeNameAndIDDetailsList.list = productDeliveryPlanItemLinkObj.listAvailableExpectedOutcomes(plannedItemCaseIDKey).list;

    // return outcome list
    return outcomeNameAndIDDetailsList;
  }

  // END, CR00192165

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ProductDeliveryTypeDetails readProductType(
    final ProductDeliveryKey productDeliveryKey) throws AppException,
      InformationalException {

    // Return Object
    ProductDeliveryTypeDetails productDeliveryTypeDetails = new ProductDeliveryTypeDetails();

    // ProductDelivery manipulation variables
    final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();

    // do a read to get the product type
    productDeliveryTypeDetails = productDeliveryObj.readProductType(
      productDeliveryKey);

    // return the product type
    return productDeliveryTypeDetails;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * Contains the liability overbilling case identifier.
   *
   * @return Liability overbilling home page details.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #readLiabilityOverbillingHomePageDetails1()}
   *
   * Reads liability overbilling home page details.
   */
  @Deprecated
  public LiabilityOverbillingHomePageDetails readLiabilityOverbillingHomePageDetails(
    final ReadHomePageKey key) throws AppException, InformationalException {

    // Create return object
    final LiabilityOverbillingHomePageDetails liabilityOverbillingHomePageDetails = new LiabilityOverbillingHomePageDetails();

    // ReassessmentProduct manipulation variables
    final curam.core.sl.intf.ReassessmentProduct reassessmentProductObj = curam.core.sl.fact.ReassessmentProductFactory.newInstance();
    final curam.core.sl.struct.GetLiabilityOverbillingEvidenceKey getLiabilityOverbillingEvidenceKey = new curam.core.sl.struct.GetLiabilityOverbillingEvidenceKey();

    // Call local method to retrieve home page details - this includes the
    // context description
    liabilityOverbillingHomePageDetails.details = readHomePageDetails(key);

    // Now need to retrieve the liability overbilling evidence as this is
    // going to be shown on the home page
    getLiabilityOverbillingEvidenceKey.caseID = key.caseID;

    // Call BPO to get the liability overbilling evidence
    liabilityOverbillingHomePageDetails.evidenceDetails = reassessmentProductObj.getLiabilityOverbillingEvidence(
      getLiabilityOverbillingEvidenceKey);
    // BEGIN, CR00022501, RR
    // Transaction Log
    // Read Transaction Log Details

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = key.caseID;

    // BEGIN CR00108134, GBA
    liabilityOverbillingHomePageDetails.details.transactionLogDtls.assign(
      caseTransactionLogProvider.get().readNumberOfTransactions(caseIDKey));
    // END CR00108134
    // END, CR00022501

    return liabilityOverbillingHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ProductIDDetails readProductID(final curam.core.sl.struct.CaseIDKey key)
    throws AppException, InformationalException {

    // Create return object
    ProductIDDetails productIDDetails = new ProductIDDetails();

    // ProductDelivery manipulation variables
    final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    // Set key to read productDelivery entity
    productDeliveryKey.caseID = key.caseID;

    // Read productID
    productIDDetails = productDeliveryObj.readProductID(productDeliveryKey);

    return productIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DeductionList listActiveDeduction(final ListCaseDeductionsKey key)
    throws AppException, InformationalException {

    // Return struct
    final DeductionList deductionList = new DeductionList();

    // MaintainDeductionItem manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final DeductionItemCaseID deductionItemCaseID = new DeductionItemCaseID();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList = new CaseDeductionItemDtlsList();

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key for search
    deductionItemCaseID.caseID = key.caseID;

    caseDeductionItemDtlsList = maintainDeductionItemsObj.listActiveDeductions(
      deductionItemCaseID);

    // Loop through returned list to assign all values
    for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

      // Initialize details struct on every iteration
      final DeductionListDetails deductionListDetails = new DeductionListDetails();

      // Assign case deduction item details to return details struct
      deductionListDetails.assign(caseDeductionItemDtlsList.dtls.item(i));

      // Set the deduction type (category) which can be used to display the
      // deduction type as an icon on the list page
      if (caseDeductionItemDtlsList.dtls.item(i).category.equals(
        DEDUCTIONTYPECODE.APPLIEDDEDUCTION)) {
        deductionListDetails.deductionType = DEDUCTIONTYPECODE.APPLIEDDEDUCTION;
      } else if (caseDeductionItemDtlsList.dtls.item(i).category.equals(
        DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION)) {
        deductionListDetails.deductionType = DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION;
      } else {
        deductionListDetails.deductionType = DEDUCTIONTYPECODE.THIRDPARTYDEDUCTION;
      }
      // Add struct to list to be returned
      deductionList.dtls.addRef(deductionListDetails);
    }

    // Set key to read product delivery context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Get context description
    deductionList.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return deductionList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DeductionList listAppliedAndUnappliedDeduction(
    final ListCaseDeductionsKey key) throws AppException,
      InformationalException {

    // Return struct
    final DeductionList deductionList = new DeductionList();

    // MaintainDeductionItem manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final DeductionItemCaseID deductionItemCaseID = new DeductionItemCaseID();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList = new CaseDeductionItemDtlsList();

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key for search
    deductionItemCaseID.caseID = key.caseID;

    caseDeductionItemDtlsList = maintainDeductionItemsObj.listAppliedAndUnappliedDeductions(
      deductionItemCaseID);

    // Loop through returned list to assign all values
    for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

      // Initialize details struct on every iteration
      final DeductionListDetails deductionListDetails = new DeductionListDetails();

      // Assign case deduction item details to return details struct
      deductionListDetails.assign(caseDeductionItemDtlsList.dtls.item(i));

      // Set the deduction type (category) which can be used to display the
      // deduction type as an icon on the list page
      if (caseDeductionItemDtlsList.dtls.item(i).category.equals(
        DEDUCTIONTYPECODE.APPLIEDDEDUCTION)) {
        deductionListDetails.deductionType = DEDUCTIONTYPECODE.APPLIEDDEDUCTION;
      } else if (caseDeductionItemDtlsList.dtls.item(i).category.equals(
        DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION)) {
        deductionListDetails.deductionType = DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION;
      } else {
        deductionListDetails.deductionType = DEDUCTIONTYPECODE.THIRDPARTYDEDUCTION;
      }

      // Add struct to list to be returned
      deductionList.dtls.addRef(deductionListDetails);
    }

    // Set key to read product delivery context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Get context description
    deductionList.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return deductionList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DeductionList listThirdPartyDeduction(final ListCaseDeductionsKey key)
    throws AppException, InformationalException {

    // Return struct
    final DeductionList deductionList = new DeductionList();

    // MaintainDeductionItem manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final DeductionItemCaseID deductionItemCaseID = new DeductionItemCaseID();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList = new CaseDeductionItemDtlsList();

    // ProductDeliveryContextDescriptionKey object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key for search
    deductionItemCaseID.caseID = key.caseID;

    caseDeductionItemDtlsList = maintainDeductionItemsObj.listThirdPartyDeductions(
      deductionItemCaseID);

    // Loop through returned list to assign all values
    for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

      // Initialize details struct on every iteration
      final DeductionListDetails deductionListDetails = new DeductionListDetails();

      // Assign case deduction item details to return details struct
      deductionListDetails.assign(caseDeductionItemDtlsList.dtls.item(i));

      // Set the deduction type (category) which can be used to display the
      // deduction type as an icon on the list page
      if (caseDeductionItemDtlsList.dtls.item(i).category.equals(
        DEDUCTIONTYPECODE.APPLIEDDEDUCTION)) {
        deductionListDetails.deductionType = DEDUCTIONTYPECODE.APPLIEDDEDUCTION;
      } else if (caseDeductionItemDtlsList.dtls.item(i).category.equals(
        DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION)) {
        deductionListDetails.deductionType = DEDUCTIONTYPECODE.UNAPPLIEDDEDUCTION;
      } else {
        deductionListDetails.deductionType = DEDUCTIONTYPECODE.THIRDPARTYDEDUCTION;
      }
      // Add struct to list to be returned
      deductionList.dtls.addRef(deductionListDetails);
    }

    // Set key to read product delivery context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Get context description
    deductionList.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return deductionList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DeductionNameList listAppliedDeductionName(final CaseIDKey key)
    throws AppException, InformationalException {

    // MaintainDeductionItem manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final CaseIDCategory caseIDCategory = new CaseIDCategory();
    CaseDeductionNameDetailsList caseDeductionNameDetailsList = new CaseDeductionNameDetailsList();

    // Return struct
    final DeductionNameList deductionNameList = new DeductionNameList();

    // Set key for read
    caseIDCategory.caseID = key.dtls.dtls.caseID;
    caseIDCategory.category = DEDUCTIONCATEGORYCODE.APPLIEDDEDUCTION;

    // Return deduction name, priority and category for a specified
    // product delivery and category
    caseDeductionNameDetailsList = maintainDeductionItemsObj.getDeductionNameForCategory(
      caseIDCategory);

    // Populate return list with results
    for (int i = 0; i < caseDeductionNameDetailsList.dtls.size(); i++) {

      // Initialize details struct on every iteration
      final DeductionNameListDetails deductionNameListDetails = new DeductionNameListDetails();

      // Assign case deduction item details to return details struct
      deductionNameListDetails.dtls.dtls.assign(
        caseDeductionNameDetailsList.dtls.item(i).dtls);

      // Add struct to list to be returned
      deductionNameList.dtlsList.addRef(deductionNameListDetails);
    }

    // BEGIN, CR00000539, SPD
    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      deductionNameList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00000539

    return deductionNameList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DeductionNameList listThirdPartyDeductionName(final CaseIDKey key)
    throws AppException, InformationalException {

    // MaintainDeductionItem manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final CaseIDCategory caseIDCategory = new CaseIDCategory();
    CaseDeductionNameDetailsList caseDeductionNameDetailsList = new CaseDeductionNameDetailsList();

    // Return struct
    final DeductionNameList deductionNameList = new DeductionNameList();

    // Set key for read
    caseIDCategory.caseID = key.dtls.dtls.caseID;
    caseIDCategory.category = DEDUCTIONCATEGORYCODE.THIRDPARTYDEDUCTION;

    // Return deduction name, priority and category for a specified
    // product delivery and category
    caseDeductionNameDetailsList = maintainDeductionItemsObj.getDeductionNameForCategory(
      caseIDCategory);

    // Populate return list with results
    for (int i = 0; i < caseDeductionNameDetailsList.dtls.size(); i++) {

      // Initialize details struct on every iteration
      final DeductionNameListDetails deductionNameListDetails = new DeductionNameListDetails();

      // Assign case deduction item details to return details struct
      deductionNameListDetails.dtls.dtls.assign(
        caseDeductionNameDetailsList.dtls.item(i).dtls);

      // Add struct to list to be returned
      deductionNameList.dtlsList.addRef(deductionNameListDetails);
    }

    // BEGIN, CR00000539, SPD
    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      deductionNameList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00000539

    return deductionNameList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DeductionNameList listUnappliedDeductionName(final CaseIDKey key)
    throws AppException, InformationalException {

    // MaintainDeductionItem manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final CaseIDCategory caseIDCategory = new CaseIDCategory();
    CaseDeductionNameDetailsList caseDeductionNameDetailsList = new CaseDeductionNameDetailsList();

    // Return struct
    final DeductionNameList deductionNameList = new DeductionNameList();

    // Set key for read
    caseIDCategory.caseID = key.dtls.dtls.caseID;
    caseIDCategory.category = DEDUCTIONCATEGORYCODE.UNAPPLIEDDEDUCTION;

    // Return deduction name, priority and category for a specified
    // product delivery and category
    caseDeductionNameDetailsList = maintainDeductionItemsObj.getDeductionNameForCategory(
      caseIDCategory);

    // Populate return list with results
    for (int i = 0; i < caseDeductionNameDetailsList.dtls.size(); i++) {

      // Initialize details struct on every iteration
      final DeductionNameListDetails deductionNameListDetails = new DeductionNameListDetails();

      // Assign case deduction item details to return details struct
      deductionNameListDetails.dtls.dtls.assign(
        caseDeductionNameDetailsList.dtls.item(i).dtls);

      // Add struct to list to be returned
      deductionNameList.dtlsList.addRef(deductionNameListDetails);
    }

    // BEGIN, CR00000539, SPD
    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      deductionNameList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00000539

    return deductionNameList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies a case deduction item for the product delivery.
   *
   * @param details
   * Details needed to modify a case deduction item.
   *
   * @return A list of informational messages.
   */
  @Deprecated
  public InformationMsgDtlsList modifyCaseDeductionItem(
    final ModifyCaseDeductionItemDetails details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to modify deduction
    maintainDeductionItemDetails.assign(details.deductionDtls);
    maintainDeductionItemDetails.assign(details.modifyDtls);

    // BEGIN, CR00000541, SD
    maintainDeductionItemDetails.caseNomineeID = details.nomineeIDPopup;
    maintainDeductionItemDetails.rulesObjectiveID = details.rulesObjectiveIDPopup;
    // END, CR00000541

    // Call MaintainDeductionItems BPO to modify the case deduction item
    maintainDeductionItemsObj.modifyDeduction(maintainDeductionItemDetails);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseAppliedDeductionHistoryDetailsList listAppliedDeductionHistory(
    final CaseDeductionHistoryListKey key) throws AppException,
      InformationalException {

    // create object from service layer
    final curam.core.sl.intf.CaseDeductionHistory caseDeductionHistoryObj = curam.core.sl.fact.CaseDeductionHistoryFactory.newInstance();

    // Return struct to hold deduction history details.
    final CaseAppliedDeductionHistoryDetailsList caseAppliedDeductionHistoryDetailsList = new CaseAppliedDeductionHistoryDetailsList();

    // Get the deduction history details for the case deduction item.
    caseAppliedDeductionHistoryDetailsList.dtls = caseDeductionHistoryObj.listApplied(
      key.key);

    // Return the list.
    return caseAppliedDeductionHistoryDetailsList;
  }

  // BEGIN, CR00167614, JMA
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseAppliedDeductionHistoryDetailsList1 listSortedAppliedDeductionHistory(
    final CaseDeductionHistoryListKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.CaseDeductionHistory caseDeductionHistoryObj = curam.core.sl.fact.CaseDeductionHistoryFactory.newInstance();

    final CaseAppliedDeductionHistoryDetailsList1 caseAppliedDeductionHistoryDetailsList1 = new CaseAppliedDeductionHistoryDetailsList1();

    // Get the deduction history details for the case deduction item.
    final AppliedDeductionHistoryDetailsList appliedDeductionHistoryDetailsList = caseDeductionHistoryObj.listApplied(
      key.key);

    caseAppliedDeductionHistoryDetailsList1.dtls.assign(
      appliedDeductionHistoryDetailsList.appliedList);

    for (int i = 0; i
      < caseAppliedDeductionHistoryDetailsList1.dtls.dtlsList.size(); i++) {

      if (caseAppliedDeductionHistoryDetailsList1.dtls.dtlsList.item(i).instructionID
        != 0) {
        caseAppliedDeductionHistoryDetailsList1.dtls.dtlsList.item(i).instructionInd = true;
      }

      final String amount = getDeductionHistoryAmountPercentage(
        caseAppliedDeductionHistoryDetailsList1.dtls.dtlsList.item(i).dtls);

      caseAppliedDeductionHistoryDetailsList1.dtls.dtlsList.item(i).amount = amount;
    }

    sortAppliedUnappliedDeductionHistoryList(
      caseAppliedDeductionHistoryDetailsList1.dtls);

    return caseAppliedDeductionHistoryDetailsList1;
  }

  // BEGIN, CR00181383, JMA
  // ___________________________________________________________________________
  /**
   * Returns a string value representing what should be displayed in the amount
   * field on the case deduction history. It can be a money amount combined with
   * a percentage amount.
   *
   * @curam .util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
   * @param key
   * Contains caseDeductionItemID
   *
   * @return The deduction history details list.
   */
  protected String getDeductionHistoryAmountPercentage(
    final CaseDeductionHistoryDtls caseDeductionHistoryDtls) {

    String historyAmountPercentage = new String();

    final Money historyAmount = caseDeductionHistoryDtls.amount;
    Double historyPercentage = caseDeductionHistoryDtls.percentage;

    // BEGIN, CR00173137, JMA
    // Set up amount
    if (!historyAmount.isZero()
      && !(historyPercentage == CuramConst.gkDoubleZero)) {

      BigDecimal bd = new BigDecimal(Double.toString(historyPercentage));

      bd = bd.setScale(2, BigDecimal.ROUND_HALF_UP);

      historyPercentage = bd.doubleValue();

      historyAmountPercentage = historyAmount.toString() + CuramConst.gkSpace
        + CuramConst.gkRoundOpeningBracket + historyPercentage.toString()
        + CuramConst.gkPercentage + CuramConst.gkRoundClosingBracket;

    } else if (historyAmount.isZero()
      && historyPercentage != CuramConst.gkDoubleZero) {

      historyAmountPercentage = historyPercentage.toString()
        + CuramConst.gkPercentage;
    } else if (!historyAmount.isZero()
      && historyPercentage == CuramConst.gkDoubleZero) {

      historyAmountPercentage = historyAmount.toString();
    }

    return historyAmountPercentage;
    // END, CR00173137
  }

  // END, CR00181383

  // ___________________________________________________________________________
  /**
   * Returns the deduction history for the applied and un-applied case deductions
   * sorted by effective date.
   *
   * @curam .util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
   * @param key The deduction id.
   *
   * @return The deduction history.
   */
  protected void sortAppliedUnappliedDeductionHistoryList(
    final CaseDeductionHistoryDetailsList1 caseDeductionHistoryDetailsList) {

    Collections.sort(caseDeductionHistoryDetailsList.dtlsList,
      new Comparator<CaseDeductionHistoryDetails1>() {

      public int compare(final CaseDeductionHistoryDetails1 struct1,
        final CaseDeductionHistoryDetails1 struct2) {

        if (struct1.dtls.effectiveDate.after(struct2.dtls.effectiveDate)) {
          return -1;
        } else if (struct1.dtls.effectiveDate.before(struct2.dtls.effectiveDate)) {
          return 1;
          // if they are the same date time then we are looking at a created
          // and activated
          // deduction, in this case we want the created history record to
          // appear last in list
        } else if (struct1.dtls.status.equals(CASEDEDHISTORYSTATUS.CREATED)) {
          return 1;
        } else if (struct2.dtls.status.equals(CASEDEDHISTORYSTATUS.CREATED)) {
          return -1;
        } else {
          return 0;
        }
      }
    });
  }

  // END, CR00167614

  // BEGIN, CR00017311, SD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseUnappliedDeductionHistoryDetailsList listUnappliedDeductionHistory(
    final CaseDeductionHistoryListKey key) throws AppException,
      InformationalException {

    // create object from service layer
    final curam.core.sl.intf.CaseDeductionHistory caseDeductionHistoryObj = curam.core.sl.fact.CaseDeductionHistoryFactory.newInstance();

    // Return struct to hold deduction history details.
    final CaseUnappliedDeductionHistoryDetailsList caseUnappliedDeductionHistoryDetailsList = new CaseUnappliedDeductionHistoryDetailsList();

    // Get the deduction history details for the case deduction item.
    caseUnappliedDeductionHistoryDetailsList.dtls = caseDeductionHistoryObj.listUnapplied(
      key.key);

    // Return the list.
    return caseUnappliedDeductionHistoryDetailsList;
  }

  // BEGIN, CR00167614, JMA
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseUnappliedDeductionHistoryDetailsList1 listSortedUnappliedDeductionHistory(
    final CaseDeductionHistoryListKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.CaseDeductionHistory caseDeductionHistoryObj = curam.core.sl.fact.CaseDeductionHistoryFactory.newInstance();

    final CaseUnappliedDeductionHistoryDetailsList1 caseUnappliedDeductionHistoryDetailsList1 = new CaseUnappliedDeductionHistoryDetailsList1();

    // Get the deduction history details for the case deduction item.
    final CaseDeductionHistoryDetailsList caseDeductionHistoryDetailsList = caseDeductionHistoryObj.listUnapplied(
      key.key);

    caseUnappliedDeductionHistoryDetailsList1.dtls.assign(
      caseDeductionHistoryDetailsList);

    for (int i = 0; i
      < caseUnappliedDeductionHistoryDetailsList1.dtls.dtlsList.size(); i++) {

      if (caseUnappliedDeductionHistoryDetailsList1.dtls.dtlsList.item(i).instructionID
        != 0) {
        caseUnappliedDeductionHistoryDetailsList1.dtls.dtlsList.item(i).instructionInd = true;
      }

      final String amount = getDeductionHistoryAmountPercentage(
        caseUnappliedDeductionHistoryDetailsList1.dtls.dtlsList.item(i).dtls);

      caseUnappliedDeductionHistoryDetailsList1.dtls.dtlsList.item(i).amount = amount;
    }

    sortAppliedUnappliedDeductionHistoryList(
      caseUnappliedDeductionHistoryDetailsList1.dtls);

    return caseUnappliedDeductionHistoryDetailsList1;
  }

  // END, CR00167614

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseThirdPartyDeductionHistoryDetailsList listThirdPartyDeductionHistory(
    final CaseDeductionHistoryListKey key) throws AppException,
      InformationalException {

    // create object from service layer
    final curam.core.sl.intf.CaseDeductionHistory caseDeductionHistoryObj = curam.core.sl.fact.CaseDeductionHistoryFactory.newInstance();

    // Return struct to hold deduction history details.
    final CaseThirdPartyDeductionHistoryDetailsList caseThirdPartyDeductionHistoryDetailsList = new CaseThirdPartyDeductionHistoryDetailsList();

    // Get the deduction history details for the case deduction item.
    caseThirdPartyDeductionHistoryDetailsList.dtls = caseDeductionHistoryObj.listThirdParty(
      key.key);

    // Return the list.
    return caseThirdPartyDeductionHistoryDetailsList;
  }

  // END, CR00017311

  // BEGIN, CR00167614, JMA
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseThirdPartyDeductionHistoryDetailsList1 listSortedThirdPartyDeductionHistory(
    final CaseDeductionHistoryListKey key) throws AppException,
      InformationalException {

    final curam.core.sl.intf.CaseDeductionHistory caseDeductionHistoryObj = curam.core.sl.fact.CaseDeductionHistoryFactory.newInstance();

    final CaseThirdPartyDeductionHistoryDetailsList1 caseThirdPartyDeductionHistoryDetailsList1 = new CaseThirdPartyDeductionHistoryDetailsList1();

    final ThirdPartyDeductionHistoryDetailsList thirdPartyDeductionHistoryDetailsList = caseDeductionHistoryObj.listThirdParty(
      key.key);

    // Get the deduction history details for the case deduction item.
    caseThirdPartyDeductionHistoryDetailsList1.dtls.assign(
      thirdPartyDeductionHistoryDetailsList);

    for (int i = 0; i
      < caseThirdPartyDeductionHistoryDetailsList1.dtls.dtlsList.size(); i++) {

      if (caseThirdPartyDeductionHistoryDetailsList1.dtls.dtlsList.item(i).instructionID
        != 0) {
        caseThirdPartyDeductionHistoryDetailsList1.dtls.dtlsList.item(i).instructionInd = true;
      }

      final String amount = getDeductionHistoryAmountPercentage(
        caseThirdPartyDeductionHistoryDetailsList1.dtls.dtlsList.item(i).caseDeductionDtls);

      caseThirdPartyDeductionHistoryDetailsList1.dtls.dtlsList.item(i).amount = amount;
    }

    Collections.sort(caseThirdPartyDeductionHistoryDetailsList1.dtls.dtlsList,
      new Comparator<ThirdPartyDeductionHistoryDetails1>() {

      public int compare(final ThirdPartyDeductionHistoryDetails1 struct1,
        final ThirdPartyDeductionHistoryDetails1 struct2) {

        if (struct1.caseDeductionDtls.effectiveDate.after(
          struct2.caseDeductionDtls.effectiveDate)) {
          return -1;
        } else if (struct1.caseDeductionDtls.effectiveDate.before(
          struct2.caseDeductionDtls.effectiveDate)) {
          return 1;
          // if they are the same date time then we are looking at a created
          // and activated
          // deduction, in this case we want the created history record to
          // appear last in list
        } else if (struct1.caseDeductionDtls.status.equals(
          CASEDEDHISTORYSTATUS.CREATED)) {
          return 1;
        } else if (struct2.caseDeductionDtls.status.equals(
          CASEDEDHISTORYSTATUS.CREATED)) {
          return -1;
        } else {
          return 0;
        }
      }
    });

    return caseThirdPartyDeductionHistoryDetailsList1;
  }

  // END, CR00167614

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setOverrideMDRInd(final ProductDeliveryKey key,
    final CuramInd details) throws AppException, InformationalException {

    // create object from service layer
    final curam.core.intf.MaintainProductDelivery maintainProductDeliveryObj = curam.core.fact.MaintainProductDeliveryFactory.newInstance();

    details.statusInd = true;

    maintainProductDeliveryObj.modifyOverrideMDRInd(key, details);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void unsetOverrideMDRInd(final ProductDeliveryKey key,
    final CuramInd details) throws AppException, InformationalException {

    // create object from service layer
    final curam.core.intf.MaintainProductDelivery maintainProductDeliveryObj = curam.core.fact.MaintainProductDeliveryFactory.newInstance();

    details.statusInd = false;

    maintainProductDeliveryObj.modifyOverrideMDRInd(key, details);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public RelatedCaseID readRelatedCaseID(final ReadDeductionKey key)
    throws AppException, InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final CaseDeductionItemKey caseDeductionItemKey = new CaseDeductionItemKey();

    // Return struct
    final RelatedCaseID relatedCaseID = new RelatedCaseID();

    // Set key for read
    caseDeductionItemKey.caseDeductionItemID = key.caseDeductionItemID;

    // Read back relatedCaseID for a case deduction
    relatedCaseID.dtls = maintainDeductionItemsObj.readRelatedCaseID(
      caseDeductionItemKey);

    return relatedCaseID;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList activateDeduction(
    final DeductionItemKeyVersionNo key) throws AppException,
      InformationalException {

    // create return object.
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // create object from service layer
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final curam.core.struct.CaseDeductionItemIDVersionNo caseDeductionItemIDVersionNo = new curam.core.struct.CaseDeductionItemIDVersionNo();

    // Assign case deduction item key details
    caseDeductionItemIDVersionNo.caseDeductionItemID = key.caseDeductionItemID;
    caseDeductionItemIDVersionNo.versionNo = key.versionNo;

    // Activate the deduction item
    maintainDeductionItemsObj.activateDeduction(caseDeductionItemIDVersionNo);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void deactivateDeduction(final DeductionItemKeyVersionNo key)
    throws AppException, InformationalException {

    // create object from service layer
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final curam.core.struct.CaseDeductionItemIDVersionNo caseDeductionItemIDVersionNo = new curam.core.struct.CaseDeductionItemIDVersionNo();

    // Assign case deduction item key details
    caseDeductionItemIDVersionNo.caseDeductionItemID = key.caseDeductionItemID;
    caseDeductionItemIDVersionNo.versionNo = key.versionNo;

    // Deactivate the deduction item
    maintainDeductionItemsObj.deactivateDeduction(caseDeductionItemIDVersionNo);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ConcernRoleID getDeductionClient(final DeductionClientDetails details)
    throws AppException, InformationalException {

    // Deduction service layer object
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();

    // create return object
    ConcernRoleID concernRoleID = new ConcernRoleID();

    // Call service layer method to get the clients concern role ID
    concernRoleID = maintainDeductionItemsObj.getDeductionClient(details.dtls);

    // return concern role id
    return concernRoleID;
  }

  // ___________________________________________________________________________
  /**
   * @param details
   * Details needed to create a variable deduction.
   *
   * @return A list of informational messages.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createVariableDeduction1()}
   *
   * Create a variable deduction for the product delivery.
   */
  @Deprecated
  public InformationMsgDtlsList createVariableDeduction(
    final CreateDeductionDetails details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details);

    // Set deduction type to be variable
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.VARIABLE;

    // BEGIN, CR00000541, SD
    maintainDeductionItemDetails.caseNomineeID = details.nomineeIDPopup;
    maintainDeductionItemDetails.rulesObjectiveID = details.rulesObjectiveIDPopup;
    // END, CR00000541

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem(maintainDeductionItemDetails);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * @param details
   * Details needed to create a fixed deduction.
   *
   * @return A list of informational messages.
   * @deprecated Since Curam 6.0, replaced by {@link #createFixedDeduction1()}
   *
   * Create a fixed deduction for the product delivery.
   */
  @Deprecated
  public InformationMsgDtlsList createFixedDeduction(
    final FixedDeductionDetails details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details.deductionDtls);

    // BEGIN, CR00000541, SD
    maintainDeductionItemDetails.caseNomineeID = details.deductionDtls.nomineeIDPopup;
    // END, CR00000541

    // Set deduction type to be fixed
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.FIXED;

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem(maintainDeductionItemDetails);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * @param details
   * Details needed to create a third party fixed deduction.
   *
   * @return A list of informational messages.
   * @deprecated Since Curam 6.0,  replaced by
   * {@link #createThirdPartyFixedDeduction1()}
   */
  @Deprecated
  public InformationMsgDtlsList createThirdPartyFixedDeduction(
    final ThirdPartyFixedDeductionDetails details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details.deductionDtls);
    maintainDeductionItemDetails.assign(details.thirdPartyDtls);

    // BEGIN, CR00000541, SD
    maintainDeductionItemDetails.caseNomineeID = details.deductionDtls.nomineeIDPopup;
    // END, CR00000541

    // Set deduction type to be fixed
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.FIXED;

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem(maintainDeductionItemDetails);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * @param details
   * Details needed to create a third party variable deduction.
   *
   * @return A list of informational messages.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createThirdPartyVariableDeduction1()}
   *
   * Create a third party variable deduction for the product delivery.
   */
  @Deprecated
  public InformationMsgDtlsList createThirdPartyVariableDeduction(
    final ThirdPartyVariableDeductionDetails details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details.deductionDtls);
    maintainDeductionItemDetails.assign(details.thirdPartyDtls);

    // Set deduction type to be variable
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.VARIABLE;

    // BEGIN, CR00000541, SD
    maintainDeductionItemDetails.caseNomineeID = details.deductionDtls.nomineeIDPopup;
    maintainDeductionItemDetails.rulesObjectiveID = details.deductionDtls.rulesObjectiveIDPopup;
    // END, CR00000541

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem(maintainDeductionItemDetails);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList modifyThirdPartyDeductionItem(
    final ModifyThirdPartyDeductionDetails details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to modify deduction
    maintainDeductionItemDetails.assign(details.deductionDtls);
    maintainDeductionItemDetails.assign(details.modifyDtls);
    maintainDeductionItemDetails.assign(details.thirdPartyDtls);

    // BEGIN, CR00003192, KH
    maintainDeductionItemDetails.rulesObjectiveID = details.rulesObjectiveIDPopup;
    // END, CR00003192

    // BEGIN, CR00000541, SD
    maintainDeductionItemDetails.caseNomineeID = details.nomineeIDPopup;
    // END, CR00000541

    // Call MaintainDeductionItems BPO to modify the case deduction item
    maintainDeductionItemsObj.modifyDeduction(maintainDeductionItemDetails);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DefaultDeductionDetails readDefaultDeductionDetails(
    final DefaultDeductionKey key) throws AppException,
      InformationalException {

    // Resource manipulation variables
    final Resource resourceObj = ResourceFactory.newInstance();
    final DeductionNameCaseID deductionNameCaseID = new DeductionNameCaseID();
    ReadDeductionDtls readDeductionDtls = new ReadDeductionDtls();

    // BEGIN, CR00021581, SK
    // BEGIN, HARP 66322, PN
    ProductIDDetails readProductDtls = new ProductIDDetails();
    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();
    // END, HARP 66322
    // END, CR00021581

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDetails = new ConcernRoleNameDetails();

    // Return struct
    final DefaultDeductionDetails defaultDeductionDetails = new DefaultDeductionDetails();

    // set key for read
    deductionNameCaseID.caseID = key.caseID;
    // BEGIN, CR00021581, SK
    // BEGIN, HARP 66322, PN
    caseIDKey.caseID = key.caseID;
    // END, HARP 66322
    // END, CR00021581
    deductionNameCaseID.deductionName = key.deductionName;

    // Read back details
    readDeductionDtls = resourceObj.readDeductionByName(deductionNameCaseID);

    // Populate return struct
    defaultDeductionDetails.deductionDtls.assign(readDeductionDtls);
    // BEGIN, CR00021334, SK
    // BEGIN, HARP 61923, RCB
    // variables to read the priority of the DeductionProductLink as it's at
    // product level we want the priority not admin
    final curam.core.sl.intf.DeductionProductLink deductionProductLinkObj = curam.core.sl.fact.DeductionProductLinkFactory.newInstance();
    final DeductionKey deductionKey = new DeductionKey();

    // BEGIN, CR00021581, SK
    // BEGIN, HARP 66322, PN
    final DeductionIDAndProductID deductionProductKey = new DeductionIDAndProductID();

    // Execute the method to get product ID
    readProductDtls = readProductID(caseIDKey);

    // read the priority
    deductionKey.key.deductionID = readDeductionDtls.dtls.dtls.deductionID;

    deductionProductKey.key.deductionID = readDeductionDtls.dtls.dtls.deductionID;
    deductionProductKey.key.productID = readProductDtls.productID;

    // END, HARP 66322
    // END, CR00021581

    // read the priority
    deductionKey.key.deductionID = readDeductionDtls.dtls.dtls.deductionID;
    curam.core.sl.struct.Priority priority = new Priority();

    // set the priority to the DeductionProductLink priority
    // BEGIN, CR00021581, SK
    // BEGIN, HARP 66322, PN
    priority = deductionProductLinkObj.readPriorityByDeductionIDAndProductID(
      deductionProductKey);
    // END, HARP 66322
    // END, CR00021581

    defaultDeductionDetails.deductionDtls.dtls.dtls.priority = priority.dtls.priority;

    // Set key for read
    // if no liabilityConcernRoleID then we are reading for an un-applied
    // deduction so there will be no liabilityConcernRoleID
    if (key.liabilityConcernRoleID != 0) {

      concernRoleKey.concernRoleID = key.liabilityConcernRoleID;

      // Read back name for liability client
      concernRoleNameDetails = concernRoleObj.readConcernRoleName(
        concernRoleKey);

      // Populate return struct
      defaultDeductionDetails.liabilityConcernRoleName = concernRoleNameDetails.concernRoleName;
    }
    // END, HARP 61923
    // END, CR00021334
    return defaultDeductionDetails;
  }

  // BEGIN, CR00172222, MC
  // ___________________________________________________________________________
  /**
   * @param caseID
   * The case ID that we are simulating the payment for.
   * @param simulationDate
   * The date that we are simulating the payment on.
   *
   * @return SimulatePaymentResult The simulation result details.
   * @deprecated Since Curam 6.0,  replaced by {@link #simulatePayment1()}. The
   * new method displays a covers period and a requested by field.
   *
   * To simulate the payment generation process on a case for a particular date.
   */
  @Deprecated
  public SimulatePaymentResult simulatePayment(final CaseID caseID,
    final DateStruct simulationDate) throws AppException,
      InformationalException {

    // Create return object
    SimulatePaymentResult simulatePaymentResult = new SimulatePaymentResult();

    // BEGIN, CR00003765, SPD
    // Simulate payment object
    final SimulatePayment simulatePaymentObj = SimulatePaymentFactory.newInstance();

    // Flag to indicate whether the simulation is to be saved or not
    final SimulateInd saveSimulateInd = new SimulateInd();

    // Don't save the simulation
    saveSimulateInd.simulateInd = false;

    // Call the simulate payment method
    simulatePaymentResult = simulatePaymentObj.simulatePayment(caseID,
      simulationDate, saveSimulateInd);
    // END, CR00003765

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      simulatePaymentResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // The simulate payment results including any informational messages
    return simulatePaymentResult;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SimulatePaymentResult1 simulatePayment1(final SimulationDetails details)
    throws AppException, InformationalException {

    // Create return object
    final SimulatePaymentResult1 simulatePaymentResult1 = new SimulatePaymentResult1();

    SimulatePaymentResult simulatePaymentResult = new SimulatePaymentResult();

    // BEGIN, CR00003765, SPD
    // Simulate payment object
    final SimulatePayment simulatePaymentObj = SimulatePaymentFactory.newInstance();

    // Flag to indicate whether the simulation is to be saved or not
    final SimulateInd saveSimulateInd = new SimulateInd();

    // Don't save the simulation
    saveSimulateInd.simulateInd = false;

    final CaseID caseID = new CaseID();

    caseID.caseID = details.caseKey.dtls.caseID;
    final DateStruct simulationDate = new DateStruct();

    simulationDate.date = details.dateDtls.dtls.date;

    // Call the simulate payment method
    simulatePaymentResult = simulatePaymentObj.simulatePayment(caseID,
      simulationDate, saveSimulateInd);
    // END, CR00003765

    // Assign the totals
    simulatePaymentResult1.enteredDate = simulatePaymentResult.enteredDate;
    simulatePaymentResult1.totalDeduction = simulatePaymentResult.totalDeduction;
    simulatePaymentResult1.totalEntitlement = simulatePaymentResult.totalEntitlement;
    simulatePaymentResult1.totalPayment = simulatePaymentResult.totalPayment;

    // Add the cover period value to each of the ILI items
    final LocalisableString coverPeriod = new LocalisableString(
      curam.message.GENERAL.INF_DATE_TO_DATE);

    SimulatePaymentILIDetails simulatePaymentILIDetails;
    SimulatePaymentILIDetails1 simulatePaymentILIDetails1;

    for (int i = 0; i < simulatePaymentResult.deductionILIList.dtls.size(); i++) {

      simulatePaymentILIDetails1 = new SimulatePaymentILIDetails1();
      simulatePaymentILIDetails = simulatePaymentResult.deductionILIList.dtls.item(
        i);
      simulatePaymentILIDetails1.assign(simulatePaymentILIDetails);

      coverPeriod.arg(simulatePaymentILIDetails1.coverPeriodFrom);
      coverPeriod.arg(simulatePaymentILIDetails1.coverPeriodTo);
      simulatePaymentILIDetails1.coversPeriod = coverPeriod.toClientFormattedText();

      simulatePaymentResult1.deductionILIList.dtls.addRef(
        simulatePaymentILIDetails1);
    }

    for (int i = 0; i < simulatePaymentResult.paymentILIList.dtls.size(); i++) {

      simulatePaymentILIDetails1 = new SimulatePaymentILIDetails1();
      simulatePaymentILIDetails = simulatePaymentResult.paymentILIList.dtls.item(
        i);
      simulatePaymentILIDetails1.assign(simulatePaymentILIDetails);

      coverPeriod.arg(simulatePaymentILIDetails1.coverPeriodFrom);
      coverPeriod.arg(simulatePaymentILIDetails1.coverPeriodTo);
      simulatePaymentILIDetails1.coversPeriod = coverPeriod.toClientFormattedText();

      simulatePaymentResult1.paymentILIList.dtls.addRef(
        simulatePaymentILIDetails1);
    }

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      simulatePaymentResult1.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // The simulate payment results including any informational messages
    return simulatePaymentResult1;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SimulationsByCaseIDList listCasePaymentSimulations(
    final CaseKey caseKey) throws AppException, InformationalException {

    final SimulationsByCaseIDList simulationsByCaseIDList = new SimulationsByCaseIDList();

    final SimulationHeader simulationHeaderObj = SimulationHeaderFactory.newInstance();

    simulationsByCaseIDList.dtlsList = simulationHeaderObj.searchByCaseID(
      caseKey);

    // BEGIN, CR00246088, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = caseKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00246088

    // Set the covers period and requested by fields on each of the list items.
    SearchByCaseIDDtls searchByCaseIDDtls;

    for (int i = 0; i < simulationsByCaseIDList.dtlsList.dtls.size(); i++) {
      searchByCaseIDDtls = simulationsByCaseIDList.dtlsList.dtls.item(i);

      final LocalisableString coverPeriod = new LocalisableString(
        curam.message.GENERAL.INF_DATE_TO_DATE);

      coverPeriod.arg(searchByCaseIDDtls.fromDate);
      coverPeriod.arg(searchByCaseIDDtls.toDate);

      searchByCaseIDDtls.dtls.coversPeriod = coverPeriod.toClientFormattedText();

      // Set the cover period variable for the line item
      final LocalisableString requestedBy = new LocalisableString(
        curam.message.GENERAL.INF_DATETIME_BY_USERNAME);

      requestedBy.arg(searchByCaseIDDtls.creationDateTime);
      // Return the user full name not user name.
      final UserAccess userAccessObj = UserAccessFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = searchByCaseIDDtls.userName;

      requestedBy.arg(userAccessObj.getFullName(usersKey).fullname);

      searchByCaseIDDtls.dtls.requestedBy = requestedBy.toClientFormattedText();

      // BEGIN, CR00182977, MC
      // Subtract deductions amount and the remove the deduction items from the
      // simulations list.
      final SimulationsByCaseIDList deductionsList = new SimulationsByCaseIDList();
      SearchByCaseIDDtls searchByCaseIDDtls1;
      Double deductionsTotal = new Double(0);

      for (int x = 0; x < simulationsByCaseIDList.dtlsList.dtls.size(); x++) {
        searchByCaseIDDtls1 = simulationsByCaseIDList.dtlsList.dtls.item(x);

        if (searchByCaseIDDtls1.simulationHeaderID
          == searchByCaseIDDtls.simulationHeaderID
            && searchByCaseIDDtls1.deductionName.length() > 0) {

          deductionsList.dtlsList.dtls.addRef(searchByCaseIDDtls1);
          deductionsTotal = deductionsTotal
            + searchByCaseIDDtls1.amount.getValue();

          simulationsByCaseIDList.dtlsList.dtls.remove(searchByCaseIDDtls1);
          i--;
        }
      }
      searchByCaseIDDtls.amount = new Money(
        searchByCaseIDDtls.amount.getValue() - deductionsTotal);
    }
    // END, CR00182977

    // Read for the context description
    // Set key to retrieve context description
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    productDeliveryContextDescriptionKey.caseID = caseKey.caseID;

    simulationsByCaseIDList.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    icProductDeliveryMenuDataKey.caseID = caseKey.caseID;

    // BEIGN, CR00316914, KH
    try {
      simulationsByCaseIDList.icPDMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);
    } catch (final RecordNotFoundException rnfe) {
      // For a stand-alone product delivery case no IC menu data is available
      simulationsByCaseIDList.icPDMenuData = new ICProductDeliveryMenuDataDetails();
    }
    // END, CR00316914

    return simulationsByCaseIDList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadPaymentSimulationDetails readSimulationDetails(
    final SimulationHeaderKey key) throws AppException,
      InformationalException {

    final ReadPaymentSimulationDetails readPaymentSimulationDetails = new ReadPaymentSimulationDetails();

    final SimulatePaymentResult1 simulatePaymentResult = SimulatePaymentFactory.newInstance().readPaymentSimulation(
      key);

    readPaymentSimulationDetails.simulationDtls = simulatePaymentResult;

    // Set key to retrieve context description
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    productDeliveryContextDescriptionKey.caseID = simulatePaymentResult.caseID;

    // Read context description and assign to output object
    readPaymentSimulationDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return readPaymentSimulationDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void removeAllSimulations(final CaseKey caseKey) throws AppException,
      InformationalException {

    SimulatePaymentFactory.newInstance().removeAllSimulations(caseKey);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void removeSimulation(final SimulationHeaderID key)
    throws AppException, InformationalException {

    SimulatePaymentFactory.newInstance().removeSimulation(key);
  }

  // END, CR00172222

  // BEGIN, CR00167497, MC
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains a case identifier.
   *
   * @return A list of financials for the case.
   *
   * @deprecated Since Curam 6.0,  replaced by
   * {@link #listCaseFinancialInstruction()} This list is returned so that is
   * can be displayed using the expandable list widget. The payment date and
   * covers period values are also added.
   *
   *
   * Returns a list of financial instructions for a product delivery case.
   */
  @Deprecated
  public ListCaseFinancialInstruction listCaseFinInstruction(
    final ListCaseFinancialsKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListCaseFinancialInstruction listCaseFinancialInstruction = new ListCaseFinancialInstruction();

    final ViewCaseFinancialInstructionList viewCaseFinancialInstructionList = listCaseFinancialInstruction(
      key);

    listCaseFinancialInstruction.warnings = viewCaseFinancialInstructionList.warnings;

    listCaseFinancialInstruction.productDeliveryContextDescription = viewCaseFinancialInstructionList.productDeliveryContextDescription;

    ViewCaseInstructionDetails viewCaseInstructionDetails;
    ViewCaseInstructionsResult viewCaseInstructionsResult;

    for (int i = 0; i < viewCaseFinancialInstructionList.dtls.dtlsList.size(); i++) {

      viewCaseInstructionDetails = viewCaseFinancialInstructionList.dtls.dtlsList.item(
        i);
      viewCaseInstructionsResult = new ViewCaseInstructionsResult();

      viewCaseInstructionsResult.assign(viewCaseInstructionDetails);
      viewCaseInstructionsResult.finInstructDtls.assign(
        viewCaseInstructionDetails.finInstructDtls);

      listCaseFinancialInstruction.dtls.dtlsList.addRef(
        viewCaseInstructionsResult);
    }

    return listCaseFinancialInstruction;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ViewCaseFinancialInstructionList listCaseFinancialInstruction(
    final ListCaseFinancialsKey key) throws AppException,
      InformationalException {

    // Create return object
    final ViewCaseFinancialInstructionList viewCaseFinancialInstructionList = new ViewCaseFinancialInstructionList();

    // ViewCaseAccount manipulation variables
    final curam.core.intf.ViewCaseAccount viewCaseAccountObj = curam.core.fact.ViewCaseAccountFactory.newInstance();
    final CaseAccountIdentifier caseAccountIdentifier = new CaseAccountIdentifier();

    // Assign key details to list the case financials
    caseAccountIdentifier.assign(key);

    // Call ViewCaseAccount BPO to return the list of case financials
    viewCaseFinancialInstructionList.dtls = viewCaseAccountObj.viewCaseFinancialInstructions(
      caseAccountIdentifier);

    // Set the caseID to the case ID that the list applies to.
    viewCaseFinancialInstructionList.caseID = key.caseID;

    final FinancialListHelper financialListHelper = new FinancialListHelper();

    ViewCaseInstructionDetails viewCaseInstructionDetails;

    int listSize = viewCaseFinancialInstructionList.dtls.dtlsList.size() - 1;

    for (int i = listSize; i >= 0; i--) {
      viewCaseInstructionDetails = viewCaseFinancialInstructionList.dtls.dtlsList.item(
        i);

      // BEGIN, CR00328565, CSH
      // Set concern details
      FinancialInstruction financialInstructionObj = FinancialInstructionFactory.newInstance();
      FinancialInstructionKey financialInstructionKey = new FinancialInstructionKey();

      financialInstructionKey.finInstructionID = viewCaseInstructionDetails.finInstructDtls.finInstructionID;

      FinancialInstructionDtls financialInstructionDtls = financialInstructionObj.read(
        financialInstructionKey);

      viewCaseInstructionDetails.concernRoleID = financialInstructionDtls.concernRoleID;
      // END, CR00328565

      // Set instruction line item details
      FinancialInstructionDetails financialInstructionDetails = new FinancialInstructionDetails();

      financialInstructionDetails.assign(viewCaseInstructionDetails);
      financialInstructionDetails.assign(
        viewCaseInstructionDetails.finInstructDtls);

      // BEGIN, CR00317416, CSH
      financialInstructionDetails = financialListHelper.setListRowActionDisplayIndicators(
        financialInstructionDetails);

      financialInstructionDetails = financialListHelper.setTypeStatus(
        financialInstructionDetails);

      viewCaseInstructionDetails.assign(financialInstructionDetails);
      // END, CR00317416
    }

    // Context description key
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key to retrieve context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to output object
    viewCaseFinancialInstructionList.productDeliveryContextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    final ICProductDeliveryMenuDataKey icProductDeliveryMenuDataKey = new ICProductDeliveryMenuDataKey();

    icProductDeliveryMenuDataKey.caseID = key.caseID;

    // BEGIN, CR00160813, MC
    // In the case of a standalone product delivery case (A Liability Sample
    // case for example) no menu data is returned.
    try {
      viewCaseFinancialInstructionList.icPDMenuData = getICProductDeliveryMenuData(
        icProductDeliveryMenuDataKey);
    } catch (final RecordNotFoundException rnfe) {
      viewCaseFinancialInstructionList.icPDMenuData = new ICProductDeliveryMenuDataDetails();
    }
    // END, CR00160813

    // BEGIN, CR00184236, MC
    // Set the indicator used to display the unprocessed menu item
    final SearchUnprocessedByCaseIDKey searchUnprocessedKey = new SearchUnprocessedByCaseIDKey();

    searchUnprocessedKey.caseID = viewCaseFinancialInstructionList.caseID;
    searchUnprocessedKey.statusCode = ILISTATUS.UNPROCESSED;

    if (InstructionLineItemFactory.newInstance().countUnprocessedByCaseID(searchUnprocessedKey).count
      > 0) {
      viewCaseFinancialInstructionList.unprocessedILIsInd = true;
    } else {
      viewCaseFinancialInstructionList.unprocessedILIsInd = false;
    }
    // END, CR00184236

    return viewCaseFinancialInstructionList;
  }

  // BEGIN, CR00000539, SPD
  // ___________________________________________________________________________
  /**
   * Reads back the category for a specified case deduction item.
   *
   * @param key
   * caseDeductionItemID
   *
   * @return category the category of the deduction
   */
  public DeductionCategory readDeductionCategory(final ReadDeductionKey key)
    throws AppException, InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final CaseDeductionItemKey caseDeductionItemKey = new CaseDeductionItemKey();

    // Return struct
    final DeductionCategory deductionCategory = new DeductionCategory();

    // Set key for read
    caseDeductionItemKey.caseDeductionItemID = key.caseDeductionItemID;

    // Read back relatedCaseID for a case deduction
    deductionCategory.dtls = maintainDeductionItemsObj.readCategory(
      caseDeductionItemKey);

    return deductionCategory;
  }

  // END, CR00000539

  // BEGIN, CR00172222, MC
  // BEGIN, CR00003260, SPD
  // ___________________________________________________________________________
  /**
   * @param caseID
   * the ID of the case for which we are simulating payment
   * @param dateDetails
   * the date for which we are simulating payment
   *
   * @deprecated Since Curam 6.0, replaced by {@link #saveSimulationDetails1()}
   * The new method saves the simulation and passes in an action control ID.
   *
   * The method saves a copy of the simulation payment result for future use.
   */
  @Deprecated
  public void saveSimulationDetails(
    final curam.core.facade.struct.CaseID caseID,
    final DateDetails dateDetails) throws AppException,
      InformationalException {

    SimulatePaymentFactory.newInstance().saveSimulationResult(caseID.dtls,
      dateDetails.dtls);
  }

  // END, CR00003260

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void saveSimulationDetails1(final SimulationDetails details)
    throws AppException, InformationalException {

    // SimulatePayment variables
    final SimulatePayment simulatePaymentObj = SimulatePaymentFactory.newInstance();

    final CaseID caseID = new CaseID();

    caseID.caseID = details.caseKey.dtls.caseID;
    final DateStruct dateDetails = new DateStruct();

    dateDetails.date = details.dateDtls.dtls.date;

    // save the simulation results
    simulatePaymentObj.saveSimulationResult(caseID, dateDetails);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SimulatePaymentResult1 saveOrSimulatePayment(
    final SimulationDetails details) throws AppException,
      InformationalException {

    SimulatePaymentResult1 simulatePaymentResult1 = new SimulatePaymentResult1();

    if (details.actionControlID.equals(ACTIONCONTROLID.SAVESIMULATION)) {
      saveSimulationDetails1(details);
    } else {
      simulatePaymentResult1 = simulatePayment1(details);
    }
    return simulatePaymentResult1;
  }

  // END, CR00172222

  // BEGIN, CR00017311, SD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public RelatedCaseIDThirdPartyID readRelatedCaseIDAndThirdPartyID(
    final ReadDeductionKey key) throws AppException, InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final CaseDeductionItemKey caseDeductionItemKey = new CaseDeductionItemKey();

    // Return struct
    final RelatedCaseIDThirdPartyID relatedCaseIDThirdPartyID = new RelatedCaseIDThirdPartyID();

    // Set the key to read the case deduction item
    caseDeductionItemKey.caseDeductionItemID = key.caseDeductionItemID;

    // Read the related case id and third party concern role id
    relatedCaseIDThirdPartyID.dtls = maintainDeductionItemsObj.readRelatedCaseIDThirdPartyID(
      caseDeductionItemKey);

    return relatedCaseIDThirdPartyID;
  }

  // END, CR00017311
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListAssessmentForProductDelivery listAssessment(final CaseKey_fo key)
    throws AppException, InformationalException {

    // Return Object
    final ListAssessmentForProductDelivery listAssessmentForProductDelivery = new ListAssessmentForProductDelivery();
    // Assessment Delivery BPO
    final AssessmentDelivery assessmentDeliveryObj = AssessmentDeliveryFactory.newInstance();

    listAssessmentForProductDelivery.dtls = assessmentDeliveryObj.listAssessmentCasesByProductDeliveryCaseID(
      key.key);
    // An instance of the key for a context description read
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    productDeliveryContextDescriptionKey.caseID = key.key.key.caseID;
    // Get the context description
    listAssessmentForProductDelivery.description = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);
    return listAssessmentForProductDelivery;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CreateAssessmentDeliveryDetails createAssessment(
    final CreateAssessmentDeliveryKey key) throws AppException,
      InformationalException {

    // Create return object
    final CreateAssessmentDeliveryDetails createAssessmentDeliveryDetails = new CreateAssessmentDeliveryDetails();
    // Assessment Delivery manipulation variables
    final curam.core.sl.intf.AssessmentDelivery assessmentDeliveryObj = curam.core.sl.fact.AssessmentDeliveryFactory.newInstance();
    CreateAssessmentDeliveryResult createAssessmentDeliveryResult;

    // create AssessmentDelivery
    createAssessmentDeliveryResult = assessmentDeliveryObj.createAssessmentOnProductDeliveryCase(
      key.dtls);

    // assign return data
    createAssessmentDeliveryDetails.dtls.assign(createAssessmentDeliveryResult);
    return createAssessmentDeliveryDetails;
  }

  // BEGIN, CR00105225, ZV
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void cancelMilestone(final MilestoneDeliveryKey key)
    throws AppException, InformationalException {

    MilestoneDeliveryFactory.newInstance().remove(key);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public MilestoneDeliveryKey createMilestone(final MilestoneDeliveryDtls dtls)
    throws AppException, InformationalException {

    return MilestoneDeliveryFactory.newInstance().create(dtls);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListMilestoneForProductDeliveryDetails listMilestone(
    final CaseHeaderKey key) throws AppException, InformationalException {

    final ListMilestoneForProductDeliveryDetails listMilestoneForProductDeliveryDetails = new ListMilestoneForProductDeliveryDetails();

    final MilestoneDelivery milestoneDeliveryObj = MilestoneDeliveryFactory.newInstance();

    listMilestoneForProductDeliveryDetails.dtls = milestoneDeliveryObj.listAllMilestoneDeliveries(
      key);

    // BEGIN, CR00142331, SAI
    for (int i = 0; i
      < listMilestoneForProductDeliveryDetails.dtls.dtlsList.dtls.size(); i++) {

      final MilestoneDeliveryKey milestoneDeliveryKey = new MilestoneDeliveryKey();

      milestoneDeliveryKey.milestoneDeliveryID = listMilestoneForProductDeliveryDetails.dtls.dtlsList.dtls.item(i).milestoneDeliveryID;

      final CheckForWaiverIndicators checkForWaiverIndicators = readWaiverIndicatorDetails(
        milestoneDeliveryKey);

      listMilestoneForProductDeliveryDetails.waiverIndList.addRef(
        checkForWaiverIndicators);
    }
    // END, CR00142331

    // An instance of the key for a context description read
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Set key to read product delivery context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Get the context description
    listMilestoneForProductDeliveryDetails.description = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listMilestoneForProductDeliveryDetails;
  }

  /**
   * {@inheritDoc}
   */
  public ListMilestoneForProductDeliveryDetails listUncompletedMilestone(
    final CaseHeaderKey key) throws AppException, InformationalException {

    final ListMilestoneForProductDeliveryDetails listMilestoneForProductDeliveryDetails = new ListMilestoneForProductDeliveryDetails();

    final MilestoneDelivery milestoneDeliveryObj = MilestoneDeliveryFactory.newInstance();

    listMilestoneForProductDeliveryDetails.dtls = milestoneDeliveryObj.listUncompletedMilestoneDeliveries(
      key);

    // BEGIN, CR00142331, SAI
    for (int i = 0; i
      < listMilestoneForProductDeliveryDetails.dtls.dtlsList.dtls.size(); i++) {

      final MilestoneDeliveryKey milestoneDeliveryKey = new MilestoneDeliveryKey();

      milestoneDeliveryKey.milestoneDeliveryID = listMilestoneForProductDeliveryDetails.dtls.dtlsList.dtls.item(i).milestoneDeliveryID;

      final CheckForWaiverIndicators checkForWaiverIndicators = readWaiverIndicatorDetails(
        milestoneDeliveryKey);

      listMilestoneForProductDeliveryDetails.waiverIndList.addRef(
        checkForWaiverIndicators);
    }
    // END, CR00142331

    // BEGIN, CR00105225, MC
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    // Get the Investigation delivery context description
    listMilestoneForProductDeliveryDetails.description.description = getInvestigationDeliveryContextDescription(caseHeaderKey).description;
    // END, CR00105225

    return listMilestoneForProductDeliveryDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void modifyMilestone(final MilestoneDeliveryDtls dtls)
    throws AppException, InformationalException {

    MilestoneDeliveryFactory.newInstance().modify(dtls);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReadMilestoneDeliveryDetails readMilestone(
    final MilestoneDeliveryKey key) throws AppException,
      InformationalException {

    final MilestoneDelivery milestoneDeliveryObj = MilestoneDeliveryFactory.newInstance();
    // BEGIN, CR00128715, ZV
    final ReadMilestoneDeliveryDetails readMilestoneDeliveryDetails = new ReadMilestoneDeliveryDetails();

    // BEGIN, CR00234436, PM
    final curam.core.sl.entity.intf.MilestoneDelivery milestoneDelivery = curam.core.sl.entity.fact.MilestoneDeliveryFactory.newInstance();
    final NotFoundIndicator notFoundIndicator = new NotFoundIndicator();
    final curam.core.sl.entity.struct.MilestoneDeliveryDtls milestoneDeliveryDtls = milestoneDelivery.read(
      notFoundIndicator, key);

    if (notFoundIndicator.isNotFound()) {
      return readMilestoneDeliveryDetails;
    }
    // END, CR00234436

    readMilestoneDeliveryDetails.milestoneDetails = milestoneDeliveryObj.read(
      key);

    // BEGIN, CR00146068, SAI
    readMilestoneDeliveryDetails.waiverIndDtls = readWaiverIndicatorDetails(key);
    // END, CR00146068

    // BEGIN, CR00147167, SAI
    final curam.core.sl.entity.struct.MilestoneDeliveryKey milestoneDeliveryKey = new curam.core.sl.entity.struct.MilestoneDeliveryKey();

    milestoneDeliveryKey.milestoneDeliveryID = key.milestoneDeliveryID;

    final curam.core.sl.intf.MilestoneLink milestoneLink = curam.core.sl.fact.MilestoneLinkFactory.newInstance();

    final curam.core.sl.entity.struct.MilestoneCreatedBySystem milestoneCreatedBySystem = milestoneDelivery.readCreatedBySystemInd(
      key);

    if (milestoneCreatedBySystem.createdBySystem) {
      readMilestoneDeliveryDetails.associatedDtls = milestoneLink.readMilestoneComponentDetails(
        readMilestoneDeliveryDetails.milestoneDetails);
    }

    // END, CR00147167

    final curam.core.facade.intf.Case caseObj = curam.core.facade.fact.CaseFactory.newInstance();
    final curam.core.facade.struct.CaseContextDescriptionKey caseContextDescriptionKey = new curam.core.facade.struct.CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = readMilestoneDeliveryDetails.milestoneDetails.readDetails.caseID;

    readMilestoneDeliveryDetails.description.description = caseObj.readCaseContextDescription(caseContextDescriptionKey).description;
    // END, CR00128715

    return readMilestoneDeliveryDetails;
    // END, CR00128715
  }

  // END, CR00105225

  // ___________________________________________________________________________
  /**
   * Sets a boolean parameter to true only when the expected time frame indicator
   * is set to true and if the waiver required indicator is set to false in the
   * administration application for a milestone. Based on this boolean value the
   * user will be allowed to change the expected start and end date.
   *
   * @curam .util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
   * @param key The milestone configuration identifier.
   *
   * @return checkForWaiverIndicators returns true when only the expected time
   * frame indicator is set to true in Admin for a milestone.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00146068, SAI
  public CheckForWaiverIndicators readWaiverIndicatorDetails(
    final MilestoneDeliveryKey key) throws AppException,
      InformationalException {

    final CheckForWaiverIndicators checkForWaiverIndicators = new CheckForWaiverIndicators();

    final MilestoneDelivery milestoneDeliveryObj = MilestoneDeliveryFactory.newInstance();

    final ReadMilestoneDeliveryDetails readMilestoneDeliveryDetails = new ReadMilestoneDeliveryDetails();

    readMilestoneDeliveryDetails.milestoneDetails = milestoneDeliveryObj.read(
      key);

    final curam.core.sl.entity.intf.MilestoneDelivery milestoneDelivery = curam.core.sl.entity.fact.MilestoneDeliveryFactory.newInstance();
    final curam.core.sl.entity.struct.MilestoneCreatedBySystem milestoneCreatedBySystem = milestoneDelivery.readCreatedBySystemInd(
      key);

    final MilestoneConfigurationKey milestoneConfigurationKey = new MilestoneConfigurationKey();

    milestoneConfigurationKey.milestoneConfigurationID = readMilestoneDeliveryDetails.milestoneDetails.readDetails.milestoneConfigurationID;

    final MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

    final WaiverIndicatorDetails waiverIndicatorDetails = milestoneConfigurationObj.readWaiverIndicatorsDetails(
      milestoneConfigurationKey);

    // BEGIN, CR00145948, SAI
    if (milestoneCreatedBySystem.createdBySystem) {
      // END, CR00145948
      if (waiverIndicatorDetails.expectedTimeFrameInd
        && !waiverIndicatorDetails.waiverRequired) {

        checkForWaiverIndicators.expectedTimeFrameInd = true;
      }
      if (waiverIndicatorDetails.expectedTimeFrameInd
        && waiverIndicatorDetails.waiverRequired) {
        checkForWaiverIndicators.waiverLinkInd = true;
      }
    } else {
      checkForWaiverIndicators.expectedTimeFrameInd = true;
      checkForWaiverIndicators.waiverLinkInd = false;
    }

    return checkForWaiverIndicators;
  }

  // END, CR00146068

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InvestigationDeliveryDetailsList listInvestigation(
    final CaseHeaderKey key) throws AppException, InformationalException {

    return InvestigationDeliveryFactory.newInstance().listInvestigationByRelatedCase(
      key);
  }

  // BEGIN, CR00128702, MC
  // ___________________________________________________________________________
  /**
   * Returns the context description for the client. The following format is
   * returned: Investigation type, case reference number, primary client name,
   * alternate ID Example: Benefit Fraud 514 - James Smith 24684
   *
   * @param CaseHeaderKey
   * key the case header key for the investigation case.
   * @return ContextDescriptionDetails A description of the case context.
   */
  @Override
  protected ContextDescription getInvestigationDeliveryContextDescription(
    final CaseHeaderKey key) throws AppException, InformationalException {

    // Create return object
    final ContextDescription contextDescription = new ContextDescription();
    final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

    investigationDeliveryKey.caseID = key.caseID;

    contextDescription.description = InvestigationDeliveryFactory.newInstance().getInvestigationDeliveryContextDescription(investigationDeliveryKey).description;

    return contextDescription;
  }

  // END, CR00128702

  // BEGIN, CR00142331, SAI
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void modifyMilestoneForWaiver(final MilestoneDeliveryDtls details)
    throws AppException, InformationalException {

    MilestoneDeliveryFactory.newInstance().modify(details);
  }

  // END, CR00142331

  // BEGIN, CR00150402, PDN
  // ___________________________________________________________________________
  /**
   * This method returns the value of the environment variable
   * ENV_CREATE_NOTE_ON_CASE_CLOSURE which determines if on closing a case a
   * note is created.
   *
   * @return The value of the environment variable
   * ENV_CREATE_NOTE_ON_CASE_CLOSURE .
   */
  public CuramInd readCloseCaseInd() throws AppException,
      InformationalException {

    final CuramInd curamInd = new CuramInd();

    curamInd.statusInd = Configuration.getBooleanProperty(
      EnvVars.ENV_APPEALS_ISINSTALLED);

    return curamInd;
  }

  // END, CR00150402

  // BEGIN, CR00165145, JMA
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList userActionFixedDeduction(
    final DeductionActivationDetails details) throws AppException,
      InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    final FixedDeductionDetails1 fixedDeductionDetails = new FixedDeductionDetails1();

    fixedDeductionDetails.deductionDtls = details.deductionDtls;
    fixedDeductionDetails.nomineeDtls = details.nomineeDtls;

    if (details.deductionDtls.relatedCaseID != 0) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.deductionDtls.relatedCaseID;

      // Get the liability concern role id
      final ReadParticipantRoleIDDetails readParticipantRoleIDDetails = CaseHeaderFactory.newInstance().readParticipantRoleID(
        caseHeaderKey);

      fixedDeductionDetails.deductionDtls.liabilityConcernRoleID = readParticipantRoleIDDetails.concernRoleID;
    }

    if (details.actionIDProperty.equals(ClientActionConst.kActivate_Now_Fixed)) {

      informationMsgDtlsList = createActiveFixedDeduction(fixedDeductionDetails);

    } else if (details.actionIDProperty.equals(
      ClientActionConst.kActivate_Later_Fixed)) {

      informationMsgDtlsList = createFixedDeduction1(fixedDeductionDetails);

    } else {
      final AppException e = new AppException(
        BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 7);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList userActionVariableDeduction(
    final DeductionActivationDetails details) throws AppException,
      InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    CreateDeductionDetails1 createDeductionDetails1 = new CreateDeductionDetails1();

    createDeductionDetails1 = details.deductionDtls;

    if (details.deductionDtls.relatedCaseID != 0) {

      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = details.deductionDtls.relatedCaseID;

      // Get the liability concern role id
      final ReadParticipantRoleIDDetails readParticipantRoleIDDetails = CaseHeaderFactory.newInstance().readParticipantRoleID(
        caseHeaderKey);

      createDeductionDetails1.liabilityConcernRoleID = readParticipantRoleIDDetails.concernRoleID;
    }

    if (details.actionIDProperty.equals(
      ClientActionConst.kActivate_Now_Variable)) {

      informationMsgDtlsList = createActiveVariableDeduction(
        createDeductionDetails1);

    } else if (details.actionIDProperty.equals(
      ClientActionConst.kActivate_Later_Variable)) {

      informationMsgDtlsList = createVariableDeduction1(createDeductionDetails1);

    } else {
      final AppException e = new AppException(
        BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 6);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // BEGIN, CR00264925, ZV
  // _________________________________________________________________________
  /**
   * This method creates third party fixed deductions and activates them if the
   * user has selected the activate option.
   *
   * @param details
   * The details to create the third party deduction.
   *
   * @return List of informational messages.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #processThirdPartyFixedDeduction()}
   *
   * If the client action was to save and activate the deduction then the
   * deduction will be created and activated. Otherwise the deduction will just
   * be created but not activated.
   */
  @Deprecated
  public InformationMsgDtlsList userActionThirdPartyFixedDeduction(
    final ThirdPartyDeductionActivationDetails details) throws AppException,
      InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Get the deduction concern role
    final ConcernRoleID concernRoleID = new ConcernRoleID();

    concernRoleID.concernRoleID = getDeductionClient(details.deductionClientDetails).concernRoleID;

    if (details.actionIDProperty.equals(
      ClientActionConst.kActivate_Now_ThirdPartyFixed)) {

      final ThirdPartyFixedDeductionDetails1 thirdPartyFixedDeductionDetails1 = new ThirdPartyFixedDeductionDetails1();

      thirdPartyFixedDeductionDetails1.deductionDtls = details.deductionDtls;
      thirdPartyFixedDeductionDetails1.nomineeDtls = details.nomineeDtls;
      thirdPartyFixedDeductionDetails1.thirdPartyDtls = details.thirdPartyDtls;
      thirdPartyFixedDeductionDetails1.thirdPartyDtls.thirdPartyConcernRoleID = concernRoleID.concernRoleID;

      informationMsgDtlsList = createActiveThirdPartyFixedDeduction(
        thirdPartyFixedDeductionDetails1);

    } else if (details.actionIDProperty.equals(
      ClientActionConst.kActivate_Later_ThirdPartyFixed)) {

      final ThirdPartyFixedDeductionDetails1 thirdPartyFixedDeductionDetails1 = new ThirdPartyFixedDeductionDetails1();

      thirdPartyFixedDeductionDetails1.deductionDtls = details.deductionDtls;
      thirdPartyFixedDeductionDetails1.nomineeDtls = details.nomineeDtls;
      thirdPartyFixedDeductionDetails1.thirdPartyDtls = details.thirdPartyDtls;
      thirdPartyFixedDeductionDetails1.thirdPartyDtls.thirdPartyConcernRoleID = concernRoleID.concernRoleID;

      informationMsgDtlsList = createThirdPartyFixedDeduction1(
        thirdPartyFixedDeductionDetails1);

    } else {
      final AppException e = new AppException(
        BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 5);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // END, CR00264925

  // BEGIN, CR00264925, ZV
  // _________________________________________________________________________
  /**
   * This method creates third party variable deductions and activates them if
   * the user has selected the activate option.
   *
   * @param details
   * The details to create the third party deduction.
   *
   * @return List of informational messages.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #processThirdPartyVariableDeduction()}
   *
   * If the client action was to save and activate the deduction then the
   * deduction will be created and activated. Otherwise the deduction will just
   * be created but not activated.
   */
  @Deprecated
  public InformationMsgDtlsList userActionThirdPartyVariableDeduction(
    final ThirdPartyDeductionActivationDetails details) throws AppException,
      InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Get the deduction concern role
    final ConcernRoleID concernRoleID = new ConcernRoleID();

    concernRoleID.concernRoleID = getDeductionClient(details.deductionClientDetails).concernRoleID;

    if (details.actionIDProperty.equals(
      ClientActionConst.kActivate_Now_ThirdPartyVariable)) {

      final ThirdPartyVariableDeductionDetails1 thirdPartyVariableDeductionDetails = new ThirdPartyVariableDeductionDetails1();

      thirdPartyVariableDeductionDetails.deductionDtls = details.deductionDtls;
      thirdPartyVariableDeductionDetails.thirdPartyDtls = details.thirdPartyDtls;
      thirdPartyVariableDeductionDetails.thirdPartyDtls.thirdPartyConcernRoleID = concernRoleID.concernRoleID;

      informationMsgDtlsList = createActiveThirdPartyVariableDeduction(
        thirdPartyVariableDeductionDetails);

    } else if (details.actionIDProperty.equals(
      ClientActionConst.kActivate_Later_ThirdPartyVariable)) {

      final ThirdPartyVariableDeductionDetails1 thirdPartyVariableDeductionDetails = new ThirdPartyVariableDeductionDetails1();

      thirdPartyVariableDeductionDetails.deductionDtls = details.deductionDtls;
      thirdPartyVariableDeductionDetails.thirdPartyDtls = details.thirdPartyDtls;
      thirdPartyVariableDeductionDetails.thirdPartyDtls.thirdPartyConcernRoleID = concernRoleID.concernRoleID;

      informationMsgDtlsList = createThirdPartyVariableDeduction1(
        thirdPartyVariableDeductionDetails);

    } else {
      final AppException e = new AppException(
        BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    }

    // return all informational messages
    return informationMsgDtlsList;

  }

  // END, CR00264925


  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList createActiveFixedDeduction(
    final FixedDeductionDetails1 details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details.deductionDtls);

    maintainDeductionItemDetails.caseNomineeID = details.deductionDtls.nomineeID;

    final DeductionName deductionName = new DeductionName();

    deductionName.deductionName = details.deductionDtls.deductionName;

    final curam.core.sl.struct.ReadDeductionDetails readDeductionDetails = DeductionFactory.newInstance().readDeductionDetailsByName(
      deductionName);

    maintainDeductionItemDetails.deductionName = readDeductionDetails.dtls.deductionName;

    // Set deduction type to be fixed
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.FIXED;
    maintainDeductionItemDetails.category = readDeductionDetails.dtls.category;
    maintainDeductionItemDetails.actionType = readDeductionDetails.dtls.actionType;

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem1(maintainDeductionItemDetails);

    final CaseDeductionItemKey caseDeductionItemKey = new CaseDeductionItemKey();

    caseDeductionItemKey.caseDeductionItemID = maintainDeductionItemDetails.caseDeductionItemID;

    // Get the version no for the case deduction
    final VersionNo versionNo = CaseDeductionItemFactory.newInstance().readVersionNo(
      caseDeductionItemKey);

    final curam.core.struct.CaseDeductionItemIDVersionNo caseDeductionItemIDVersionNo = new curam.core.struct.CaseDeductionItemIDVersionNo();

    // Assign case deduction item key details
    caseDeductionItemIDVersionNo.caseDeductionItemID = maintainDeductionItemDetails.caseDeductionItemID;
    caseDeductionItemIDVersionNo.versionNo = versionNo.versionNo;

    // Activate the deduction item
    maintainDeductionItemsObj.activateDeduction(caseDeductionItemIDVersionNo);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList createActiveThirdPartyFixedDeduction(
    final ThirdPartyFixedDeductionDetails1 details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details.deductionDtls);
    maintainDeductionItemDetails.assign(details.thirdPartyDtls);

    maintainDeductionItemDetails.caseNomineeID = details.deductionDtls.nomineeID;

    final DeductionName deductionName = new DeductionName();

    deductionName.deductionName = details.deductionDtls.deductionName;

    final curam.core.sl.struct.ReadDeductionDetails readDeductionDetails = DeductionFactory.newInstance().readDeductionDetailsByName(
      deductionName);

    maintainDeductionItemDetails.deductionName = readDeductionDetails.dtls.deductionName;

    // Set deduction type to be fixed
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.FIXED;
    maintainDeductionItemDetails.category = readDeductionDetails.dtls.category;
    maintainDeductionItemDetails.actionType = readDeductionDetails.dtls.actionType;

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem1(maintainDeductionItemDetails);

    final CaseDeductionItemKey caseDeductionItemKey = new CaseDeductionItemKey();

    caseDeductionItemKey.caseDeductionItemID = maintainDeductionItemDetails.caseDeductionItemID;

    // Get the version no for the case deduction
    final VersionNo versionNo = CaseDeductionItemFactory.newInstance().readVersionNo(
      caseDeductionItemKey);

    final curam.core.struct.CaseDeductionItemIDVersionNo caseDeductionItemIDVersionNo = new curam.core.struct.CaseDeductionItemIDVersionNo();

    // Assign case deduction item key details
    caseDeductionItemIDVersionNo.caseDeductionItemID = maintainDeductionItemDetails.caseDeductionItemID;

    caseDeductionItemIDVersionNo.versionNo = versionNo.versionNo;

    // Activate the deduction item
    maintainDeductionItemsObj.activateDeduction(caseDeductionItemIDVersionNo);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList createActiveThirdPartyVariableDeduction(
    final ThirdPartyVariableDeductionDetails1 details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details.deductionDtls);
    maintainDeductionItemDetails.assign(details.thirdPartyDtls);

    maintainDeductionItemDetails.caseNomineeID = details.deductionDtls.nomineeID;
    maintainDeductionItemDetails.rulesObjectiveID = details.deductionDtls.rulesObjectiveID;

    final DeductionName deductionName = new DeductionName();

    deductionName.deductionName = details.deductionDtls.deductionName;

    final curam.core.sl.struct.ReadDeductionDetails readDeductionDetails = DeductionFactory.newInstance().readDeductionDetailsByName(
      deductionName);

    maintainDeductionItemDetails.deductionName = readDeductionDetails.dtls.deductionName;

    // Set deduction type to be variable
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.VARIABLE;
    maintainDeductionItemDetails.category = readDeductionDetails.dtls.category;
    maintainDeductionItemDetails.actionType = readDeductionDetails.dtls.actionType;

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem1(maintainDeductionItemDetails);

    final CaseDeductionItemKey caseDeductionItemKey = new CaseDeductionItemKey();

    caseDeductionItemKey.caseDeductionItemID = maintainDeductionItemDetails.caseDeductionItemID;

    // Get the version no for the case deduction
    final VersionNo versionNo = CaseDeductionItemFactory.newInstance().readVersionNo(
      caseDeductionItemKey);

    final curam.core.struct.CaseDeductionItemIDVersionNo caseDeductionItemIDVersionNo = new curam.core.struct.CaseDeductionItemIDVersionNo();

    // Assign case deduction item key details
    caseDeductionItemIDVersionNo.caseDeductionItemID = maintainDeductionItemDetails.caseDeductionItemID;

    caseDeductionItemIDVersionNo.versionNo = versionNo.versionNo;

    // Activate the deduction item
    maintainDeductionItemsObj.activateDeduction(caseDeductionItemIDVersionNo);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList createActiveVariableDeduction(
    final CreateDeductionDetails1 details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details);

    maintainDeductionItemDetails.caseNomineeID = details.nomineeID;

    final DeductionName deductionName = new DeductionName();

    deductionName.deductionName = details.deductionName;

    final curam.core.sl.struct.ReadDeductionDetails readDeductionDetails = DeductionFactory.newInstance().readDeductionDetailsByName(
      deductionName);

    // Set deduction type to be variable
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.VARIABLE;
    maintainDeductionItemDetails.category = readDeductionDetails.dtls.category;
    maintainDeductionItemDetails.actionType = readDeductionDetails.dtls.actionType;

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem1(maintainDeductionItemDetails);

    final CaseDeductionItemKey caseDeductionItemKey = new CaseDeductionItemKey();

    caseDeductionItemKey.caseDeductionItemID = maintainDeductionItemDetails.caseDeductionItemID;

    // Get the version no for the case deduction
    final VersionNo versionNo = CaseDeductionItemFactory.newInstance().readVersionNo(
      caseDeductionItemKey);

    final curam.core.struct.CaseDeductionItemIDVersionNo caseDeductionItemIDVersionNo = new curam.core.struct.CaseDeductionItemIDVersionNo();

    // Assign case deduction item key details
    caseDeductionItemIDVersionNo.caseDeductionItemID = maintainDeductionItemDetails.caseDeductionItemID;
    caseDeductionItemIDVersionNo.versionNo = versionNo.versionNo;

    // Activate the deduction item
    maintainDeductionItemsObj.activateDeduction(caseDeductionItemIDVersionNo);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;

  }

  // BEGIN, CR00264925, ZV
  // ___________________________________________________________________________
  /**
   * Returns a list of active liabilities for a concern.
   *
   * @param key
   * Key to read the liabilities for a concern.
   *
   * @return A list of active liabilities for a concern.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #listActiveLiabilitiesForConcernRole()}
   */
  @Deprecated
  public ListActiveLiabilityDetails1 listActiveLiabilitiesForConcern1(
    final ListActiveLiabilitesForConcernKey1 key) throws AppException,
      InformationalException {

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final ListActiveLiabilityDetails1 listActiveLiabilityDetails1 = new ListActiveLiabilityDetails1();
    // BEGIN, CR00208998, CW
    // Local list to hold active overpayment payment correction cases
    final ListActiveLiabilityDetails1 listActiveOverpaymentPaymentCorrectionDetails = new ListActiveLiabilityDetails1();
    // END, CR00208998

    final CreateDeductionItemDtls createDeductionItemDtls = new CreateDeductionItemDtls();

    final DeductionClientDetails deductionClientDetails = new DeductionClientDetails();

    deductionClientDetails.concernRoleType = key.concernRoleType;
    deductionClientDetails.dtls.caseParticipantConcernRoleID = key.caseParticipantConcernRoleID;

    deductionClientDetails.dtls.clientConcernRoleID = key.concernRoleID;

    createDeductionItemDtls.concernRoleID = getDeductionClient(deductionClientDetails).concernRoleID;

    // Retrieve the list of active liabilities and assign to return object
    listActiveLiabilityDetails1.assign(
      MaintainDeductionItemsFactory.newInstance().getActiveLiabilityCasesForConcernRole(
        createDeductionItemDtls));

    // BEGIN, CR00208998, CW
    //
    // Add any active overPayment payment correction cases to the list of
    // liabilities
    // for the concern role
    //

    // Retrieve the active overPayment payment corrections
    listActiveOverpaymentPaymentCorrectionDetails.assign(
      MaintainDeductionItemsFactory.newInstance().getActiveOverpaymentCorrectionCasesForConcern(
        createDeductionItemDtls));

    // Add the active overPayment payment corrections to the list of liabilities
    for (int j = 0; j
      < listActiveOverpaymentPaymentCorrectionDetails.dtls.size(); j++) {

      listActiveLiabilityDetails1.dtls.addRef(
        listActiveOverpaymentPaymentCorrectionDetails.dtls.item(j));
    }
    // END, CR00208998

    final MaintainDeductionItems maintainDeductionItemsObj = MaintainDeductionItemsFactory.newInstance();
    final curam.core.struct.RelatedCaseID relatedCaseID = new curam.core.struct.RelatedCaseID();
    DeductionLiabilityAmountDetails deductionLiabilityAmountDetails;

    if (listActiveLiabilityDetails1.dtls.size() != 0) {

      for (int i = 0; i < listActiveLiabilityDetails1.dtls.size(); i++) {

        relatedCaseID.relatedCaseID = listActiveLiabilityDetails1.dtls.item(i).caseID;

        deductionLiabilityAmountDetails = maintainDeductionItemsObj.readLiabilityAmounts(
          relatedCaseID);

        if (!deductionLiabilityAmountDetails.outstandingAmount.isZero()) {

          listActiveLiabilityDetails1.dtls.item(i).originalAmount = deductionLiabilityAmountDetails.originalAmount;
          listActiveLiabilityDetails1.dtls.item(i).outstandingAmount = deductionLiabilityAmountDetails.outstandingAmount;

        } else {
          listActiveLiabilityDetails1.dtls.remove(i);
          i--;
        }
      }
    } else {

      final AppException appException = new AppException(
        BPOMAINTAINDEDUCTIONITEMS.INF_DEDUCTION_NOMINEE_NO_LIABILITIES);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    informationalManager.failOperation();

    return listActiveLiabilityDetails1;
  }

  // END, CR00264925

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DeductionHeaderDetails readDeductionLiabilityDetails(
    final curam.core.sl.struct.CaseIDKey key) throws AppException,
      InformationalException {

    final DeductionHeaderDetails deductionHeaderDetails = MaintainDeductionItemsFactory.newInstance().readDeductionLiabilityDetails(
      key);

    return deductionHeaderDetails;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationalMsgDtlsList readLastPaymentDate(final CaseIDKey key)
    throws AppException, InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    final MaintainFinancialComponent maintainFinancialComponentObj = MaintainFinancialComponentFactory.newInstance();
    final FCCaseID fcCaseID = new FCCaseID();

    fcCaseID.caseID = key.dtls.dtls.caseID;

    final FCCoverDate fcCoverDate = maintainFinancialComponentObj.getLatestCoverPeriodTo(
      fcCaseID);

    if (!fcCoverDate.coverDate.isZero()) {

      final AppException lastPaymentDate = new AppException(
        curam.message.BPOMAINTAINDEDUCTIONITEMS.ERR_DEDUCTION_CASE_LAST_PAYMENT_DATE);

      lastPaymentDate.arg(fcCoverDate.coverDate);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        lastPaymentDate, GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }

    // return all informational messages
    return informationalMsgDtlsList;

  }

  // BEGIN, CR00264512, ZV
  // ___________________________________________________________________________
  /**
   * @return List of participants to display in participant search list.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #readThirdPartyDeductionParticipantsWithoutProspect()}
   * Reads the list of participants that a third party deduction can be applied
   * to.
   */
  @Deprecated
  public ParticipantTypeDescList readThirdPartyDeductionParticipants()
    throws AppException, InformationalException {

    String deductionParticipantString = Configuration.getProperty(
      EnvVars.ENV_THIRDPARTY_DEDUCTION_PARTICIPANTS);

    if (deductionParticipantString == null) {
      deductionParticipantString = Configuration.getProperty(
        EnvVars.ENV_THIRDPARTY_DEDUCTION_PARTICIPANTS_DEFAULT);
    }

    return populateParticipantList(deductionParticipantString);
  }

  // ___________________________________________________________________________
  /**
   * @return List of participants to display in participant search list.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #readAppliedDeductionParticipantsWithoutProspect()}
   * Reads the list of participants that a third party deduction can be applied
   * to.
   */
  @Deprecated
  public ParticipantTypeDescList readAppliedDeductionParticipants()
    throws AppException, InformationalException {

    String deductionParticipantString = Configuration.getProperty(
      EnvVars.ENV_APPLIED_DEDUCTION_PARTICIPANTS);

    if (deductionParticipantString == null) {
      deductionParticipantString = Configuration.getProperty(
        EnvVars.ENV_APPLIED_DEDUCTION_PARTICIPANTS_DEFAULT);
    }

    return populateParticipantList(deductionParticipantString);
  }

  // END, CR00264512

  // BEGIN, CR00252215, CW
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ActivityAttendeeTypeDescList readCaseEventInvitedAttendeeParticipants()
    throws AppException, InformationalException {

    //
    // Read the configured list of attendee types for search
    //
    String attendeeParticipantString = Configuration.getProperty(
      EnvVars.ENV_CASE_EVENT_INVITE_ATTENDEE_PARTICIPANTS);

    if (attendeeParticipantString == null) {
      attendeeParticipantString = Configuration.getProperty(
        EnvVars.ENV_CASE_EVENT_INVITE_ATTENDEE_PARTICIPANTS_DEFAULT);
    }

    //
    // Turn the configured list of attendee types into a list for display
    //
    final String[] attendeeTypeArray = attendeeParticipantString.split(
      CuramConst.gkComma);

    // BEGIN, CR00311773, IBM
    // Read the contents of the ActivityAttendeeType codetable
    final LinkedHashMap<String, String> activityAttendeeTypeHashMap = CodeTable.getAllEnabledItems(
      ACTIVITYATTENDEETYPE.TABLENAME, TransactionInfo.getProgramLocale());
    // END, CR00311773

    Set<String> activityAttendeeKeys = new TreeSet<String>();

    if (!activityAttendeeTypeHashMap.isEmpty()) {

      activityAttendeeKeys = activityAttendeeTypeHashMap.keySet();
    }

    final ActivityAttendeeTypeDescList activityAttendeeTypeDescList = new ActivityAttendeeTypeDescList();

    ActivityAttendeeTypeDescription activityAttendeeTypeDescription;

    // Read the codetable description entry for each item in the configured
    // list of attendee types
    for (int i = 0; i < attendeeTypeArray.length; i++) {

      if (!activityAttendeeKeys.isEmpty()) {

        final Iterator<String> itr = activityAttendeeKeys.iterator();

        while (itr.hasNext()) {
          final String activityAttendeeKey = itr.next().toString();

          // BEGIN, CR00331694, KH
          if (attendeeTypeArray[i].trim().equals(activityAttendeeKey)) {

            activityAttendeeTypeDescription = new ActivityAttendeeTypeDescription();
            activityAttendeeTypeDescription.activityAttendeeType = activityAttendeeKey;
            activityAttendeeTypeDescription.activityAttendeeDescription = activityAttendeeTypeHashMap.get(activityAttendeeKey).toString();

            activityAttendeeTypeDescList.activityAttendeeTypeDescription.addRef(
              activityAttendeeTypeDescription);
          }
          // END, CR00331694
        }
      }
    }

    return activityAttendeeTypeDescList;

  }

  // END, CR00252215

  // BEGIN, CR00264512, ZV
  // ___________________________________________________________________________
  /**
   * @return List of participants to display in participant search list.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #populateParticipantWithoutProspectList()}
   * Reads a list of participants.
   */
  @Deprecated
  protected ParticipantTypeDescList populateParticipantList(
    final String participantString) throws AppException,
      InformationalException {
    // END, CR00198672
    final String[] participantArray = participantString.split(
      CuramConst.gkComma);

    final LinkedHashMap<String, String> concernRoleHashMap = CodeTable.getAllItems(
      curam.codetable.CONCERNROLETYPE.TABLENAME,
      TransactionInfo.getProgramLocale());

    Set<String> concernRoleKeys = new TreeSet<String>();

    if (!concernRoleHashMap.isEmpty()) {

      concernRoleKeys = concernRoleHashMap.keySet();
    }

    final ParticipantTypeDescList participantTypeDescList = new ParticipantTypeDescList();

    ParticipantTypeDescription participantTypeDescription;

    for (int i = 0; i < participantArray.length; i++) {

      if (!concernRoleKeys.isEmpty()) {

        final Iterator<String> itr = concernRoleKeys.iterator();

        while (itr.hasNext()) {
          final String concernRoleKey = itr.next().toString();

          // BEGIN, CR00331694, KH
          if (participantArray[i].trim().equals(concernRoleKey)) {

            participantTypeDescription = new ParticipantTypeDescription();
            participantTypeDescription.participantType = concernRoleKey;
            participantTypeDescription.participantDescription = concernRoleHashMap.get(concernRoleKey).toString();

            participantTypeDescList.participantTypeDescription.addRef(
              participantTypeDescription);
          }
          // END, CR00331694
        }
      }
    }

    return participantTypeDescList;
  }

  // END, CR00264512

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList createFixedDeduction1(
    final FixedDeductionDetails1 details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details.deductionDtls);

    maintainDeductionItemDetails.caseNomineeID = details.deductionDtls.nomineeID;

    final DeductionName deductionName = new DeductionName();

    deductionName.deductionName = details.deductionDtls.deductionName;

    final curam.core.sl.struct.ReadDeductionDetails readDeductionDetails = DeductionFactory.newInstance().readDeductionDetailsByName(
      deductionName);

    maintainDeductionItemDetails.deductionName = readDeductionDetails.dtls.deductionName;

    // Set deduction type to be fixed
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.FIXED;
    maintainDeductionItemDetails.category = readDeductionDetails.dtls.category;
    maintainDeductionItemDetails.actionType = readDeductionDetails.dtls.actionType;

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem1(maintainDeductionItemDetails);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;

  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList createThirdPartyFixedDeduction1(
    final ThirdPartyFixedDeductionDetails1 details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details.deductionDtls);
    maintainDeductionItemDetails.assign(details.thirdPartyDtls);

    maintainDeductionItemDetails.caseNomineeID = details.deductionDtls.nomineeID;

    final DeductionName deductionName = new DeductionName();

    deductionName.deductionName = details.deductionDtls.deductionName;

    final curam.core.sl.struct.ReadDeductionDetails readDeductionDetails = DeductionFactory.newInstance().readDeductionDetailsByName(
      deductionName);

    maintainDeductionItemDetails.deductionName = readDeductionDetails.dtls.deductionName;

    // Set deduction type to be fixed
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.FIXED;
    maintainDeductionItemDetails.category = readDeductionDetails.dtls.category;
    maintainDeductionItemDetails.actionType = readDeductionDetails.dtls.actionType;

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem1(maintainDeductionItemDetails);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;

  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList createThirdPartyVariableDeduction1(
    final ThirdPartyVariableDeductionDetails1 details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details.deductionDtls);
    maintainDeductionItemDetails.assign(details.thirdPartyDtls);

    final DeductionName deductionName = new DeductionName();

    deductionName.deductionName = details.deductionDtls.deductionName;

    final curam.core.sl.struct.ReadDeductionDetails readDeductionDetails = DeductionFactory.newInstance().readDeductionDetailsByName(
      deductionName);

    maintainDeductionItemDetails.deductionName = readDeductionDetails.dtls.deductionName;

    // Set deduction type to be fixed
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.VARIABLE;
    maintainDeductionItemDetails.category = readDeductionDetails.dtls.category;
    maintainDeductionItemDetails.actionType = readDeductionDetails.dtls.actionType;

    maintainDeductionItemDetails.caseNomineeID = details.deductionDtls.nomineeID;
    maintainDeductionItemDetails.rulesObjectiveID = details.deductionDtls.rulesObjectiveID;

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem1(maintainDeductionItemDetails);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList createVariableDeduction1(
    final CreateDeductionDetails1 details) throws AppException,
      InformationalException {

    // MaintainDeductionItems manipulation variables
    final curam.core.intf.MaintainDeductionItems maintainDeductionItemsObj = curam.core.fact.MaintainDeductionItemsFactory.newInstance();
    final MaintainDeductionItemDetails maintainDeductionItemDetails = new MaintainDeductionItemDetails();

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Assign details to create deduction
    maintainDeductionItemDetails.assign(details);

    final DeductionName deductionName = new DeductionName();

    deductionName.deductionName = details.deductionName;

    final curam.core.sl.struct.ReadDeductionDetails readDeductionDetails = DeductionFactory.newInstance().readDeductionDetailsByName(
      deductionName);

    // Set deduction type to be variable
    maintainDeductionItemDetails.deductionType = DEDUCTIONITEMTYPE.VARIABLE;
    maintainDeductionItemDetails.category = readDeductionDetails.dtls.category;
    maintainDeductionItemDetails.actionType = readDeductionDetails.dtls.actionType;

    maintainDeductionItemDetails.caseNomineeID = details.nomineeID;

    // Call MaintainDeductionItems BPO to create the deduction item
    maintainDeductionItemsObj.createDeductionItem1(maintainDeductionItemDetails);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // return all informational messages
    return informationMsgDtlsList;

  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList modifyCaseDeductionItem1(
    final ModifyCaseDeductionItemDetails1 details) throws AppException,
      InformationalException {

    final ModifyCaseDeductionItemDetails modifyCaseDeductionItemDetails = new ModifyCaseDeductionItemDetails();

    modifyCaseDeductionItemDetails.deductionDtls = details.deductionDtls;
    modifyCaseDeductionItemDetails.modifyDtls = details.modifyDtls;
    modifyCaseDeductionItemDetails.nomineeIDPopup = details.nomineeID;
    modifyCaseDeductionItemDetails.rulesObjectiveIDPopup = details.rulesObjectiveID;

    final InformationMsgDtlsList informationMsgDtlsList = modifyCaseDeductionItem(
      modifyCaseDeductionItemDetails);

    // Create an informational manager
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // BEGIN, CR00163245, MC
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList countActiveTasks(final CaseKey caseKey)
    throws AppException, InformationalException {

    final InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj = curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();

    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new SearchTaskForConcernOrCaseKey();

    final SearchTasksForConcernAndCaseDetails searchTasksForConcernAndCaseDetails = new SearchTasksForConcernAndCaseDetails();

    searchTaskForConcernOrCaseKey.details.linkedID = caseKey.caseID;

    searchTasksForConcernAndCaseDetails.dtls = workAllocationTaskObj.listCaseTasks(
      searchTaskForConcernOrCaseKey);

    final int numTasks = searchTasksForConcernAndCaseDetails.dtls.dtls.dtls.size();
    int numberOfTasks = numTasks;

    // check that each task is either COMPLETED or CLOSED
    for (int i = 0; i < numTasks; i++) {

      if (searchTasksForConcernAndCaseDetails.dtls.dtls.dtls.item(i).status.equals(
        curam.codetable.TASKSTATUS.COMPLETED)) {
        numberOfTasks--;
      }
    }

    // Environment variable to define if a case can be closed without manually
    // closing all of the task on it first
    boolean closeCaseWithTasks = false;
    String closeCaseWithTasksProperty = Configuration.getProperty(
      EnvVars.ENV_CLOSE_CASE_WITH_TASKS);

    if (closeCaseWithTasksProperty.length() == 0
      || closeCaseWithTasksProperty == null) {
      closeCaseWithTasksProperty = EnvVars.ENV_CLOSE_CASE_WITH_TASKS_DEFAULT;
    }

    closeCaseWithTasks = closeCaseWithTasksProperty.equalsIgnoreCase(
      EnvVars.ENV_VALUE_YES);

    // If there are active tasks
    if (numberOfTasks > 0 && closeCaseWithTasks) {

      final AppException e = new AppException(
        curam.message.BPOCLOSECASE.INF_CLOSECASE_ACTIVE_TASKS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }

    return informationalMsgDtlsList;
  }

  // END, CR00163245

  // BEGIN, CR00173434, MC
  // ___________________________________________________________________________
  /**
   * Generates the menu data for a Product Delivery on an Integrated Case.
   *
   * @param key
   * Contains the case identifier.
   *
   * @return Menu data for a product delivery.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ICProductDeliveryMenuDataDetails getICProductDeliveryMenuData(
    final ICProductDeliveryMenuDataKey key) throws AppException,
      InformationalException {

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    final CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance().readCaseTypeCode(
      caseKey);

    final ProductHookManager productHookManager = new ProductHookManager();
    final curam.core.facade.intf.MenuData menuDataObj = productHookManager.getMenuDataHook(
      caseTypeCode.caseTypeCode);

    return menuDataObj.getICProductDeliveryMenuData(key);
  }

  // END, CR00173434

  // BEGIN, CR00184236, MC
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public UnprocessedILIDetailsList listUnprocessedILIs(
    final SearchUnprocessedByCaseIDKey searchUnprocessedKey)
    throws AppException, InformationalException {

    final UnprocessedILIDetailsList unprocessedILIDetailsList = new UnprocessedILIDetailsList();

    searchUnprocessedKey.statusCode = ILISTATUS.UNPROCESSED;

    final curam.core.struct.UnprocessedILIDetailsList unprocessedILIDtlsList = InstructionLineItemFactory.newInstance().searchUnprocessedByCaseIDStatus(
      searchUnprocessedKey);

    if (unprocessedILIDtlsList.dtls.size() > 0) {
      unprocessedILIDetailsList.unprocessedILIsInd = true;

      UnprocessedILIDetails unprocessedILIDetails;

      for (int i = 0; i < unprocessedILIDtlsList.dtls.size(); i++) {

        unprocessedILIDetails = new UnprocessedILIDetails();

        unprocessedILIDetails.dtls = unprocessedILIDtlsList.dtls.item(i);

        if (unprocessedILIDetails.dtls.caseNomineeID != 0) {
          final CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

          caseNomineeKey.caseNomineeID = unprocessedILIDetails.dtls.caseNomineeID;
          unprocessedILIDetails.caseNomineeName = ConcernRoleFactory.newInstance().readNameByCaseNomineeID(caseNomineeKey).concernRoleName;
        }
        // Add the cover period value to each of the ILI items
        final LocalisableString coverPeriod = new LocalisableString(
          curam.message.GENERAL.INF_DATE_TO_DATE);

        coverPeriod.arg(unprocessedILIDetails.dtls.coverPeriodFrom);
        coverPeriod.arg(unprocessedILIDetails.dtls.coverPeriodTo);

        unprocessedILIDetails.coversPeriod = coverPeriod.toClientFormattedText();

        unprocessedILIDetailsList.dtlsList.addRef(unprocessedILIDetails);
      }
    } else {
      unprocessedILIDetailsList.unprocessedILIsInd = false;
    }

    return unprocessedILIDetailsList;
  }

  // END, CR00184236

  // BEGIN, CR00192101, CSH
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public OverUnderPaymentBreakdownDetailsList listOverUnderPaymentBreakdown(
    final ReadOverUnderPaymentDetailsKey key) throws AppException,
      InformationalException {

    final OverUnderPaymentBreakdownDetailsList overUnderPaymentBreakdownDetailsList = new OverUnderPaymentBreakdownDetailsList();

    final NomineeOverUnderPayment piNomineeOverUnderPaymentObj = nomineeOverUnderPaymentDAO.get(
      key.nomineeOverUnderPaymentID);

    final OverUnderPaymentHeader overUnderPaymentHeaderObj = overUnderPaymentHeaderDAO.get(
      piNomineeOverUnderPaymentObj.getOverUnderPaymentHeader());

    final List<OverUnderPaymentBreakdown> breakdownList = overUnderPaymentBreakdownDAO.searchByNomineeOverUnderPayment(
      piNomineeOverUnderPaymentObj);

    // BEGIN, CR00220579, KH
    int numComponents = 0;

    // END, CR00220579

    // BEGIN, CR00193820, CSH
    for (final OverUnderPaymentBreakdown breakdown : breakdownList) {

      // BEGIN, CR00211167, KH
      // Skip any 'No Change' reassessment results
      if (breakdown.getReassessmentResult().equals(
        REASSESSMENTRESULTEntry.NOCHANGE)) {
        continue;
      }
      // END, CR00211167

      // BEGIN, CR00220579, KH
      numComponents++;
      // END, CR00220579

      // BEGIN, CR00220915, KH
      // Take the cover period dates from the BreakdownInfo records
      Date coverPeriodFrom = Date.kZeroDate;
      Date coverPeriodTo = Date.kZeroDate;

      final List<BreakdownInfo> breakdownInfoList = breakdownInfoDAO.searchByOverUnderPaymentBreakdown(
        breakdown);

      for (final BreakdownInfo breakdownInfo : breakdownInfoList) {

        final Date startDate = breakdownInfo.getDateRange().start();
        final Date endDate = breakdownInfo.getDateRange().end();

        if (coverPeriodFrom.isZero() || startDate.before(coverPeriodFrom)) {
          coverPeriodFrom = startDate;
        }
        if (coverPeriodTo.isZero() || endDate.after(coverPeriodTo)) {
          coverPeriodTo = endDate;
        }
      }
      // END, CR00220915

      final OverUnderPaymentBreakdownDetails oupBreakdownDetails = new OverUnderPaymentBreakdownDetails();

      oupBreakdownDetails.amount = breakdown.getAmount();
      oupBreakdownDetails.coverPeriodFrom = coverPeriodFrom;
      oupBreakdownDetails.coverPeriodTo = coverPeriodTo;
      oupBreakdownDetails.reassessmentResultType = breakdown.getReassessmentResult().getCode();
      oupBreakdownDetails.rulesObjectiveID = breakdown.getRulesObjective();
      oupBreakdownDetails.overUnderPaymentBreakdownID = breakdown.getID();
      oupBreakdownDetails.nomineeOverUnderPaymentID = key.nomineeOverUnderPaymentID;
      oupBreakdownDetails.reassessmentDate = overUnderPaymentHeaderObj.getReassessmentDate();
      oupBreakdownDetails.caseNomineeID = piNomineeOverUnderPaymentObj.getCaseNominee();
      oupBreakdownDetails.overUnderPaymentHeaderID = piNomineeOverUnderPaymentObj.getOverUnderPaymentHeader();

      // BEGIN, CR00195852, CSH
      final CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

      caseNomineeKey.caseNomineeID = piNomineeOverUnderPaymentObj.getCaseNominee();
      oupBreakdownDetails.nomineeName = ConcernRoleFactory.newInstance().readNameByCaseNomineeID(caseNomineeKey).concernRoleName;
      // END, CR00195852

      final CaseNomineeCaseIDKey caseNomineeCaseIDKey = new CaseNomineeCaseIDKey();

      caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID = key.caseID;
      final CaseNomineeObjectiveNameDetailsList objectiveNameDetailsList = CaseNomineeFactory.newInstance().listObjective(
        caseNomineeCaseIDKey);

      for (int l = 0; l
        < objectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.size(); l++) {

        if (breakdown.getRulesObjective().equals(
          objectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.item(l).rulesObjectiveID)) {

          oupBreakdownDetails.objectiveName = objectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.item(l).objectiveCode;
          break;
        }
      }

      // BEGIN, CR00201861, CSH
      // Set the Case description variable for the line item
      final LocalisableString componentDescription = new LocalisableString(
        GENERAL.INF_COMPONENT_REASSESSMENT_SEPARATOR);

      final String componentName = CodeTable.getOneItem(
        RULESCOMPONENTTYPE.TABLENAME, oupBreakdownDetails.objectiveName);

      componentDescription.arg(componentName);

      if (oupBreakdownDetails.reassessmentResultType.equals(
        REASSESSMENTRESULTEntry.OVERPAYMENT.getCode())) {
        componentDescription.arg(GENERAL.INF_OVERPAID.toString());
      } else if (oupBreakdownDetails.reassessmentResultType.equals(
        REASSESSMENTRESULTEntry.UNDERPAYMENT.getCode())) {
        componentDescription.arg(GENERAL.INF_UNDERPAID.toString());
      } else if (oupBreakdownDetails.reassessmentResultType.equals(
        REASSESSMENTRESULTEntry.NOCHANGE.getCode())) {
        componentDescription.arg(GENERAL.INF_NO_CHANGE.toString());
      }

      oupBreakdownDetails.componentDescription = componentDescription.toClientFormattedText();

      // Set the cover period for this line item
      final LocalisableString coverPeriod = new LocalisableString(
        GENERAL.INF_DATE_TO_DATE);

      coverPeriod.arg(oupBreakdownDetails.coverPeriodFrom);
      coverPeriod.arg(oupBreakdownDetails.coverPeriodTo);

      oupBreakdownDetails.coversPeriod = coverPeriod.toClientFormattedText();
      // END, CR00201861

      overUnderPaymentBreakdownDetailsList.dtlsList.addRef(oupBreakdownDetails);
    }
    // END, CR00193820

    // BEGIN, CR00220579, KH
    if (numComponents > 1) {
      overUnderPaymentBreakdownDetailsList.multipleObjectivesInd = true;
    }
    // END, CR00220579

    return overUnderPaymentBreakdownDetailsList;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public BenefitStatementDetailsList listBenefitStatementDetails(
    final BenefitStatementKey key) throws AppException,
      InformationalException {

    final BenefitStatementDetailsList benefitStatementDetailsList = new BenefitStatementDetailsList();

    final NomineeOverUnderPayment nomineeOverUnderPaymentObj = nomineeOverUnderPaymentDAO.get(
      key.nomineeOverUnderPaymentID);

    // The client page passes a zero string when requesting rolled up details
    if (!key.rulesObjectiveID.equalsIgnoreCase(CuramConst.gkStringZero)) {

      // Only return the records for the specified rulesObjectiveID
      final List<OverUnderPaymentBreakdown> breakdownList = overUnderPaymentBreakdownDAO.searchByRulesObjectiveNomineeOverUnderPayment(
        nomineeOverUnderPaymentObj, key.rulesObjectiveID);

      getBenefitStatementDetails(key, benefitStatementDetailsList,
        breakdownList);
    } else {

      // return for all components
      final List<OverUnderPaymentBreakdown> breakdownList = overUnderPaymentBreakdownDAO.searchByNomineeOverUnderPayment(
        nomineeOverUnderPaymentObj);

      getBenefitStatementDetails(key, benefitStatementDetailsList,
        breakdownList);
    }

    return benefitStatementDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Reads the benefit statement details for a specified list of over payment or
   * under payment breakdown records for a product delivery.
   *
   * @curam .util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
   *
   * @param key The identifiers for the reassessed case, the nominee over/under
   * payment and the reassessment information details.
   *
   * @param benefitStatementDetailsList A list of benefit statement details that
   * will be returned.
   *
   * @param breakdownList The list of payment breakdown records for a particular
   * objective.
   * Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected void getBenefitStatementDetails(final BenefitStatementKey key,
    final BenefitStatementDetailsList benefitStatementDetailsList,
    final List<OverUnderPaymentBreakdown> breakdownList) throws AppException,
      InformationalException {
    // END, CR00198672

    final ReassessmentInfo reassessmentInfoObj = ReassessmentInfoFactory.newInstance();
    final CaseNominee caseNomineeObj = CaseNomineeFactory.newInstance();

    // BEGIN, CR00220579, KH
    Money totalDifferenceAmount = Money.kZeroMoney;
    // END, CR00220579

    // BEGIN, CR00220579, KH
    int numComponents = 0;

    // END, CR00220579

    for (final OverUnderPaymentBreakdown breakdown : breakdownList) {

      // BEGIN, CR00220579, KH
      // Don't count the 'No Change' reassessment results
      if (!breakdown.getReassessmentResult().equals(
        REASSESSMENTRESULTEntry.NOCHANGE)) {
        numComponents++;
      }
      // END, CR00220579

      final List<BreakdownInfo> breakdownInfoList = breakdownInfoDAO.searchByOverUnderPaymentBreakdown(
        breakdown);

      for (final BreakdownInfo breakdownInfo : breakdownInfoList) {

        // BEGIN, CR00211030, KH
        // Filter out periods where the amount has not changed
        if (breakdownInfo.getActualAmount().equals(
          breakdownInfo.getReassessedAmount())) {
          continue; // with next breakdown info record
        }
        // END, CR00211030

        // BEGIN, CR00193820, CSH
        final BenefitStatementDetails benefitStatementDetails = new BenefitStatementDetails();

        benefitStatementDetails.fromDate = breakdownInfo.getDateRange().start();
        benefitStatementDetails.toDate = breakdownInfo.getDateRange().end();
        benefitStatementDetails.actualAmount = breakdownInfo.getActualAmount();
        benefitStatementDetails.reassessedAmount = breakdownInfo.getReassessedAmount();

        // BEGIN, CR00201861, CSH
        // Set the covers period for this line item
        final LocalisableString coverPeriod = new LocalisableString(
          GENERAL.INF_DATE_TO_DATE);

        coverPeriod.arg(benefitStatementDetails.fromDate);
        coverPeriod.arg(benefitStatementDetails.toDate);

        benefitStatementDetails.coversPeriod = coverPeriod.toClientFormattedText();
        // END, CR00201861

        // BEGIN, CR00220579, KH
        // Calculate difference amount
        final double actAmount = benefitStatementDetails.actualAmount.getValue();
        final double reassAmount = benefitStatementDetails.reassessedAmount.getValue();
        final Money differenceAmount = new Money(reassAmount - actAmount);

        totalDifferenceAmount = new Money(
          totalDifferenceAmount.getValue() + differenceAmount.getValue());

        // BEGIN, CR00202877, CW
        final LocalisableString difference = formatTotalDifferenceForDisplay(
          differenceAmount);

        // END, CR00202877

        benefitStatementDetails.difference = difference.toClientFormattedText();
        // END, CR00220579

        if (!key.rulesObjectiveID.equalsIgnoreCase(null)) {

          benefitStatementDetails.rulesObjectiveID = key.rulesObjectiveID;

          // Read the objective name
          final CaseNomineeCaseIDKey caseNomineeCaseIDKey = new CaseNomineeCaseIDKey();

          caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID = key.caseID;
          final CaseNomineeObjectiveNameDetailsList list = caseNomineeObj.listObjective(
            caseNomineeCaseIDKey);

          for (int k = 0; k < list.caseNomineeObjectiveNameDetailsList.size(); k++) {

            if (breakdown.getRulesObjective().equals(
              list.caseNomineeObjectiveNameDetailsList.item(k).rulesObjectiveID)) {

              benefitStatementDetails.rulesComponentTypeCode = list.caseNomineeObjectiveNameDetailsList.item(k).objectiveCode;

              break; // from caseNomineeObjectiveNameDetailsList
            } // end if breakdownList
          } // end if key.rulesObjectiveID

          // Read the reassessment info identifier
          final ReadmultiByNomineeOverUnderPaymentIDKey rmKey = new ReadmultiByNomineeOverUnderPaymentIDKey();

          rmKey.nomineeOverUnderPaymentID = key.nomineeOverUnderPaymentID;

          final ReassessmentInfoDtlsList reassessmentInfoDtlsList = reassessmentInfoObj.searchByNomineeOverUnderPaymentID(
            rmKey);

          for (int l = 0; l < reassessmentInfoDtlsList.dtls.size(); l++) {

            if (reassessmentInfoDtlsList.dtls.item(l).fromDate.equals(
              benefitStatementDetails.fromDate)
                && reassessmentInfoDtlsList.dtls.item(l).toDate.equals(
                  benefitStatementDetails.toDate)) {

              benefitStatementDetails.reassessmentInfoID = reassessmentInfoDtlsList.dtls.item(l).reassessmentInfoID;
              break; // reassessmentInfoDtlsList
            }
          } // end for l

          // BEGIN, CR00220915, CR00222016, KH
          // Get the reassessment period decisions
          final ReassessmentInfoKey listDecisionsKey = new ReassessmentInfoKey();

          listDecisionsKey.reassessmentInfoID = benefitStatementDetails.reassessmentInfoID;

          // If multiple pairs are found set the indicator for the client page
          if (ViewOverUnderPaymentResultFactory.newInstance().listFilteredDecisionsForReassessmentPeriod(listDecisionsKey).dtls.size()
            > 1) {
            benefitStatementDetails.multipleDecisionPeriodsInd = true;
          }
          // END, CR00220915, CR00222016

          benefitStatementDetailsList.dtlsList.addRef(benefitStatementDetails);
        } // end for k
        // END, CR00193820
      } // end for j
    } // end for i

    // BEGIN, CR00220579, KH
    if (numComponents > 1) {
      benefitStatementDetailsList.multipleObjectivesInd = true;
    }
    // END, CR00220579

    // BEGIN, CR00202877, CW
    final LocalisableString totalDifference = formatTotalDifferenceForDisplay(
      totalDifferenceAmount);

    // END, CR00202877

    benefitStatementDetailsList.totalDifference = totalDifference.toClientFormattedText();
    // END, CR00220579

    sortBenefitStatementDetailsList(benefitStatementDetailsList);
  } // END, CR00192101

  // BEGIN, CR00220915, CR00222016, KH
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException Generic Exception Signature.
   */
  public FilteredReassessmentDecisionsDetails listSingleReassessmentPeriodDecision(
    final ListDecisionsForReassessmentPeriodKey key)
    throws AppException, InformationalException {

    // Assign key and read decisions for reassessment period
    final ReassessmentInfoKey listDecisionsKey = new ReassessmentInfoKey();

    listDecisionsKey.reassessmentInfoID = key.reassessmentInfoID;

    final FilteredReassessmentDecisionsDetailsList result = ViewOverUnderPaymentResultFactory.newInstance().listFilteredDecisionsForReassessmentPeriod(
      listDecisionsKey);

    // Always return the first pair
    return result.dtls.item(0);
  }

  // END, CR00220915, CR00222016

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public BenefitOverpaymentEvidenceResult getBenefitOverpaymentEvidence(
    final CaseHeaderKey key) throws AppException, InformationalException {

    final BenefitOverpaymentEvidenceResult benefitOverpaymentEvidenceResult = new BenefitOverpaymentEvidenceResult();

    final GetEvidenceKey getEvidenceKey = new GetEvidenceKey();

    getEvidenceKey.caseID = key.caseID;

    benefitOverpaymentEvidenceResult.result = assessmentEngine.getBenefitOverpaymentCaseEvidence(getEvidenceKey).evidenceResult;

    return benefitOverpaymentEvidenceResult;
  }

  // BEGIN, CR00201861, CSH
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReassessmentResultDetailsList listReassessmentResults(
    final ListOverUnderPaymentKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReassessmentResultDetailsList reassessmentResultDetailsList = new ReassessmentResultDetailsList();
    final ListOverUnderPaymentDetails listOverUnderPaymentDetails = new ListOverUnderPaymentDetails();

    // Get the details list and assign it to the return object
    listOverUnderPaymentDetails.getAllOverUnderPaymentsResult = ViewOverUnderPaymentResultFactory.newInstance().getAllOverUnderPayments(
      key.getAllOverUnderPaymentsIn);

    final GetReassessmentCoverPeriodKey getReassessmentCoverPeriodKey = new GetReassessmentCoverPeriodKey();

    // BEGIN, CR00202877, CW
    // Flag to indicate that no breakdown exists for the reassessment
    boolean noBreakdownInformationExists = false;

    // END, CR00202877

    for (int i = 0; i
      < listOverUnderPaymentDetails.getAllOverUnderPaymentsResult.outList.dtls.size(); i++) {

      // BEGIN, CR00219209, VM
      final GetAllOverUnderPaymentsDetails result = listOverUnderPaymentDetails.getAllOverUnderPaymentsResult.outList.dtls.item(
        i);

      getReassessmentCoverPeriodKey.nomineeOverUnderPaymentID = result.nomineeOverUnderPaymentID;

      final GetReassessmentCoverPeriodResult getReassessmentCoverPeriodResult = ProcessOverUnderPaymentsFactory.newInstance().getReassessmentCoverPeriod(
        getReassessmentCoverPeriodKey);
      // END, CR00219209

      final ReassessmentResultDetails reassessmentResultDetails = new ReassessmentResultDetails();

      reassessmentResultDetails.amount = result.totalAmount;
      reassessmentResultDetails.caseNomineeID = result.caseNomineeID;
      reassessmentResultDetails.nomineeName = result.nomineeName;
      reassessmentResultDetails.nomineeOverUnderPaymentID = result.nomineeOverUnderPaymentID;
      reassessmentResultDetails.overUnderPaymentHeaderID = result.overUnderPaymentHeaderID;
      reassessmentResultDetails.reassessmentDate = result.reassessmentDate;
      reassessmentResultDetails.reassessmentResultType = result.amountTypeCode;
      // BEGIN, CR00243265, KH
      reassessmentResultDetails.coverPeriodFrom = getReassessmentCoverPeriodResult.fromDate;
      reassessmentResultDetails.coverPeriodTo = getReassessmentCoverPeriodResult.toDate;
      // END, CR00243265

      // Set the covers period for this line item
      final LocalisableString coverPeriod = new LocalisableString(
        GENERAL.INF_DATE_TO_DATE);

      coverPeriod.arg(reassessmentResultDetails.coverPeriodFrom);
      coverPeriod.arg(reassessmentResultDetails.coverPeriodTo);

      reassessmentResultDetails.coversPeriod = coverPeriod.toClientFormattedText();

      // BEGIN, CR00220579, KH
      // Check if the reassessment has multiple objectives
      int numComponents = 0;

      final List<OverUnderPaymentBreakdown> breakdownList = overUnderPaymentBreakdownDAO.searchByNomineeOverUnderPayment(
        nomineeOverUnderPaymentDAO.get(result.nomineeOverUnderPaymentID));

      // BEGIN, CR00202877, CW
      // Set the breakdown information flag if it has not already been set
      if (!noBreakdownInformationExists && breakdownList.isEmpty()) {

        // There is breakdown information for the reassessment
        noBreakdownInformationExists = true;
      } else {

        // BEGIN, CR00239173, CW
        // Populate the case reference and case id of the over or under
        // payment case using the related breakdown records.
        // We can use the first item in the list as they will all have the
        // same case id
        final OverUnderPaymentBreakdownKey overUnderPaymentBreakdownKey = new OverUnderPaymentBreakdownKey();

        overUnderPaymentBreakdownKey.overUnderPaymentBreakdownID = breakdownList.get(0).getID();

        // Read the case id and case reference of the over or under payment
        // case from the Payment Correction Evidence
        final List<PaymentCorrectionEvidence> pcEvidenceList = paymentCorrectionEvidenceDAO.searchByOverUnderPaymentBreakdown(
          overUnderPaymentBreakdownKey);

        if (!pcEvidenceList.isEmpty()) {

          // Only display valid over and under payment cases
          // Do not display net zero cases or the sample benefit case itself,
          // which is stored on the Payment Correction Evidence record
          // if no over or under payment case is created.
          final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

          caseHeaderKey.caseID = pcEvidenceList.get(0).getCase().getID();

          if (paymentCorrection.isPaymentCorrectionCase(caseHeaderKey)
            && !paymentCorrection.isNetZeroPaymentCorrection(caseHeaderKey)) {

            reassessmentResultDetails.overUnderPaymentCaseID = pcEvidenceList.get(0).getCase().getID();
            reassessmentResultDetails.overUnderPaymentCaseReference = pcEvidenceList.get(0).getCase().getCaseReference();
          }
        }
        // END, CR00239173
      }
      // END, CR00202877

      for (final OverUnderPaymentBreakdown breakdown : breakdownList) {

        // Don't count the 'No Change' reassessment results
        if (!breakdown.getReassessmentResult().equals(
          REASSESSMENTRESULTEntry.NOCHANGE)) {
          numComponents++;
        }
      }

      if (numComponents > 1) {
        reassessmentResultDetails.multipleObjectivesInd = true;
      }
      // END, CR00220579
      // Add item to the return list
      reassessmentResultDetailsList.dtlsList.addRef(reassessmentResultDetails);
    }

    // BEGIN, CR00202877, CW
    // If the breakdown list is empty for the over/under payment statement,
    // return an informational to the client
    if (noBreakdownInformationExists) {

      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      final AppException e = new AppException(
        BPOPRODUCTDELIVERY.INF_BREAKDOWN_LIST_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // Obtain the informational(s) to be returned to the client
      final String[] warnings = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {

        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = warnings[i];
        reassessmentResultDetailsList.informationalMsgDtlsList.dtls.addRef(
          informationalMsgDtls);
      }
    }
    // END, CR00202877

    return reassessmentResultDetailsList;
  }

  // END, CR00201861

  // BEGIN, CR00203103, CR00224704, CSH, CW
  // ___________________________________________________________________________
  /**
   * Returns the details of a reassessment of a product delivery in the format
   * required for displaying as a chart.
   *
   * @param key
   * The reassessment identifier.
   *
   * @return The reassessment details in xml format.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public BIReportDetails getReassessmentResultsChart(
    final BenefitStatementKey key) throws AppException,
      InformationalException {

    // Return structure
    final BIReportDetails reportDetails = new BIReportDetails();

    final Map <String, String> reportParameters = new HashMap<String, String>();

    // Check if a particular objective has been specified
    if (key.rulesObjectiveID.length() != 0) {

      // Display results for single component
      reportParameters.put(CuramConst.gkParam_RP_noupID,
        String.valueOf(key.nomineeOverUnderPaymentID));
      reportParameters.put(CuramConst.gkParam_RP_rulesObjectiveID,
        String.valueOf(key.rulesObjectiveID));

      final WidgetDocumentBuilder reportSingleComponentBuilder = biHelper.getDocumentBuilder(
        CuramConst.gkReassessmentResultChartForComponent, reportParameters);

      reportDetails.report = reportSingleComponentBuilder.toString();
    } else {

      // Display the full results
      reportParameters.put(CuramConst.gkParam_RP_noupID,
        String.valueOf(key.nomineeOverUnderPaymentID));

      final WidgetDocumentBuilder reportFullReassessmentBuilder = biHelper.getDocumentBuilder(
        CuramConst.gkReassessmentResultChart, reportParameters);

      reportDetails.report = reportFullReassessmentBuilder.toString();
    }

    return reportDetails;
  }

  // END, CR00224704

  // ___________________________________________________________________________
  /**
   * Sorts the supplied benefit statement details by from date and rule component
   * type.
   *
   * @curam .util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
   * @param list The benefit statement details to be sorted.
   */
  protected void sortBenefitStatementDetailsList(
    final BenefitStatementDetailsList list) {

    Collections.sort(list.dtlsList,
      new Comparator<BenefitStatementDetails>() {

      public int compare(final BenefitStatementDetails struct1,
        final BenefitStatementDetails struct2) {

        if (struct1.fromDate.after(struct2.fromDate)) {
          return -1;
        } else if (struct1.fromDate.before(struct2.fromDate)) {
          return 1;
        }

        // if the dates are the same then sort by component
        final int component = struct1.rulesComponentTypeCode.compareTo(
          struct2.rulesComponentTypeCode);

        return component;
      }
    });
  }

  // END, CR00203103

  // BEGIN, CR00203241, VM
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReadHeaderResult readHeader1(final ReadHeaderKey key)
    throws AppException, InformationalException {

    // Return object
    final ReadHeaderResult result = new ReadHeaderResult();

    // Get case header details
    final ProductDeliveryFurtherDetailsKey productDeliveryFurtherDetailsKey = new ProductDeliveryFurtherDetailsKey();

    productDeliveryFurtherDetailsKey.caseID = key.caseID;

    final ReadCaseHeaderResult headerResult = MaintainProductDeliveryFurtherDetailsFactory.newInstance().readCaseHeader1(
      productDeliveryFurtherDetailsKey);

    result.openEndedCaseInd = headerResult.openEndedCaseInd;
    result.details.comments = headerResult.details.comments;
    result.details.outcomeCode = headerResult.details.outcomeCode;
    result.details.outcomeName = headerResult.details.outcomeName;
    result.details.priorityCode = headerResult.details.priorityCode;
    result.details.receivedDate = headerResult.details.receivedDate;
    result.details.startDate = headerResult.details.startDate;
    result.details.expectedOutcome = headerResult.details.expectedOutcome;
    result.details.actualOutcome = headerResult.details.actualOutcome;
    result.details.classificationCode = headerResult.details.classificationCode;
    result.details.expectedEndDate = headerResult.details.expectedEndDate;
    result.details.objectiveCode = headerResult.details.objectiveCode;

    // BEGIN, CR00241132, VM
    // Find out if the product is open ended. The openEndedCaseInd
    // flag determines the conditional display of the expected end date field
    // on the case header details page. This will always be displayed for
    // open ended cases, regardless of whether or not the field is populated.
    final DeterminationCalculator determinationCalculator = determinationCalculatorFactory.newInstanceForCaseID(
      key.caseID);

    result.openEndedCaseInd = determinationCalculator.allowOpenEndedCases();

    return result;
    // END, CR00241132
  }

  // END, CR00203241

  // BEGIN, CR00220182, ZV
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReadHomePageDetails1 readHomePageDetails1(final ReadHomePageKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadHomePageDetails1 readHomePageDetails = new ReadHomePageDetails1();

    // ProductDeliveryHome manipulation variables
    final curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory.newInstance();
    final ProductDeliveryHomeKey productDeliveryHomeKey = new ProductDeliveryHomeKey();
    GetProductDeliveryDetailsResult getProductDeliveryDetailsResult;

    // Context description key object
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // BEGIN, CR00066883, SPD
    // UserRecentAction manipulation variables
    final UserRecentAction userRecentActionObj = UserRecentActionFactory.newInstance();
    final UserRecentActionDetails userRecentActionDetails = new UserRecentActionDetails();

    // END, CR00066883

    // Set key to read Product Delivery home page details
    productDeliveryHomeKey.caseID = key.caseID;

    // Read ProductDelivery home page details
    getProductDeliveryDetailsResult = productDeliveryHomeObj.getProductDeliveryDetails(
      productDeliveryHomeKey);

    // Assign home page details to output struct
    readHomePageDetails.homePageDetails.assign(
      getProductDeliveryDetailsResult.dtls);

    // BEGIN, CR00092078, SPD
    // Populate the bookmark indicator for the case
    readHomePageDetails.caseIsUserBookmarkInd = getProductDeliveryDetailsResult.productDeliveryHomeIndicators.caseIsUserBookmarkInd;
    // END, CR00092078

    // Set key to read context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to output object
    readHomePageDetails.contextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    // BEGIN, CR00022280, PL

    // Read Transaction Log Details

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = key.caseID;

    // BEGIN CR00108134, GBA
    readHomePageDetails.transactionLogDtls.assign(
      caseTransactionLogProvider.get().readNumberOfTransactions(caseIDKey));
    // END CR00108134
    // END, CR00022280

    // BEGIN, CR00066883, SPD
    // populate caseID to create a userRecentAction for the case
    userRecentActionDetails.dtls.referenceNo = key.caseID;

    // create a userRecentAction of type 'Viewed'
    userRecentActionObj.createCaseActionView(userRecentActionDetails);
    // END, CR00066883

    // BEGIN, CR00163271, PDN
    // If the case is closed then need to populate the close details for the
    // case.
    if (readHomePageDetails.homePageDetails.caseStatusCode.equals(
      curam.codetable.CASESTATUS.CLOSED)) {
      // Set the case close indicator
      readHomePageDetails.isCaseClosedInd = true;

      final ReadCaseClosureKey readCaseClosureKey = new ReadCaseClosureKey();

      readCaseClosureKey.caseID = readHomePageDetails.homePageDetails.caseID;

      final ClosureDtls closureDtls = MaintainCaseClosureFactory.newInstance().readCaseClosure(
        readCaseClosureKey);

      readHomePageDetails.closureDtls.assign(closureDtls);

      // Populate the user's full name
      final curam.core.intf.Users usersObj = UsersFactory.newInstance();
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = closureDtls.userName;

      readHomePageDetails.closureDtls.userFullName = usersObj.read(usersKey).fullName;

      // BEGIN, CR00163613, PDN
      // create the date user message
      final LocalisableString dateUserNameMessage = new LocalisableString(
        curam.message.GENERAL.INF_DATE_BY_USERNAME);

      // BEGIN, CR00166458, PDN
      // Add the username that closed the case
      dateUserNameMessage.arg(readHomePageDetails.closureDtls.userFullName);

      // Add the closure date
      dateUserNameMessage.arg(readHomePageDetails.closureDtls.closureDate);
      // END, CR00166458

      readHomePageDetails.closureDtls.closureDateAndUserFullName = dateUserNameMessage.toClientFormattedText();
      // END, CR00163613

    }
    // END, CR00163271

    return readHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public BenefitUnderpmtHomePageDetails1 readBenefitUnderpmtHomePageDetails1(
    final ReadHomePageKey key) throws AppException, InformationalException {

    // Create return object
    final BenefitUnderpmtHomePageDetails1 benefitUnderpmtHomePageDetails = new BenefitUnderpmtHomePageDetails1();

    // ReassessmentProduct manipulation variables
    final curam.core.sl.struct.GetUnderpmtEvidenceKey getUnderpmtEvidenceKey = new curam.core.sl.struct.GetUnderpmtEvidenceKey();

    // Call local method to retrieve home page details - this includes the
    // context description
    benefitUnderpmtHomePageDetails.details = readHomePageDetails1(key);

    // Now need to retrieve the benefit underpayment evidence as this is
    // going to be shown on the home page
    getUnderpmtEvidenceKey.caseID = key.caseID;

    // BEGIN, CR00211744, VM
    final GetBUCaseEvidenceKey getBUCaseEvidenceKey = new GetBUCaseEvidenceKey();

    getBUCaseEvidenceKey.key.caseID = key.caseID;

    benefitUnderpmtHomePageDetails.evidenceDetails = assessmentEngine.getBenefitUnderpaymentCaseEvidence(getBUCaseEvidenceKey).evidenceResult;
    // END, CR00211744

    return benefitUnderpmtHomePageDetails;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public LiabilityOverbillingHomePageDetails1 readLiabilityOverbillingHomePageDetails1(
    final ReadHomePageKey key) throws AppException, InformationalException {

    // Create return object
    final LiabilityOverbillingHomePageDetails1 liabilityOverbillingHomePageDetails = new LiabilityOverbillingHomePageDetails1();

    // ReassessmentProduct manipulation variables
    final ReassessmentProduct reassessmentProductObj = ReassessmentProductFactory.newInstance();
    final GetLiabilityOverbillingEvidenceKey getLiabilityOverbillingEvidenceKey = new GetLiabilityOverbillingEvidenceKey();

    // Call local method to retrieve home page details - this includes the
    // context description
    liabilityOverbillingHomePageDetails.details = readHomePageDetails1(key);

    // Now need to retrieve the liability overbilling evidence as this is
    // going to be shown on the home page
    getLiabilityOverbillingEvidenceKey.caseID = key.caseID;

    // Call BPO to get the liability overbilling evidence
    liabilityOverbillingHomePageDetails.evidenceDetails = reassessmentProductObj.getLiabilityOverbillingEvidence(
      getLiabilityOverbillingEvidenceKey);
    // BEGIN, CR00022501, RR
    // Transaction Log
    // Read Transaction Log Details

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = key.caseID;

    // BEGIN, CR00108134, GBA
    liabilityOverbillingHomePageDetails.details.transactionLogDtls.assign(
      caseTransactionLogProvider.get().readNumberOfTransactions(caseIDKey));
    // END, CR00108134
    // END, CR00022501

    return liabilityOverbillingHomePageDetails;
  }

  // END, CR00220182

  // BEGIN, CR00220794, ZV
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListCertificationDetails1 listCertification1(final CertificationCaseIDKey key)
    throws AppException, InformationalException {

    // Create the return object
    final ListCertificationDetails1 listCertificationDetails = new ListCertificationDetails1();

    // MaintainCertification manipulation variables
    final curam.core.intf.MaintainCertification maintainCertificationObj = curam.core.fact.MaintainCertificationFactory.newInstance();
    final MaintainCertificationCaseIDKey maintainCertificationCaseIDKey = new MaintainCertificationCaseIDKey();

    // An instance of the key for a context description read
    final ProductDeliveryContextDescriptionKey productDeliveryContextDescriptionKey = new ProductDeliveryContextDescriptionKey();

    // Assign certification key details
    maintainCertificationCaseIDKey.assign(key);

    // Call MaintainCertification BPO to retrieve certifications
    listCertificationDetails.assign(
      maintainCertificationObj.getCertifications(maintainCertificationCaseIDKey));

    // Set key to read product delivery context description
    productDeliveryContextDescriptionKey.caseID = key.caseID;

    // Get the context description
    listCertificationDetails.productDeliveryContextDescription = getProductDeliveryContextDescription(
      productDeliveryContextDescriptionKey);

    return listCertificationDetails;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void reject1(final RejectCaseKey_fo1 key) throws AppException,
      InformationalException {

    // ProductDeliveryApproval manipulation variables
    final curam.core.intf.ProductDeliveryApproval productDeliveryApprovalObj = curam.core.fact.ProductDeliveryApprovalFactory.newInstance();
    final curam.core.struct.ProductDeliveryApprovalKey1 productDeliveryApprovalKey = new curam.core.struct.ProductDeliveryApprovalKey1();

    // Set key to reject product delivery
    productDeliveryApprovalKey.assign(key);

    // Call ProductDeliveryApproval BPO to reject the case
    productDeliveryApprovalObj.reject1(productDeliveryApprovalKey);
  }

  // END, CR00220794

  // BEGIN, CR00202877, CW

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public BenefitStatementDetailsList benefitStatementBreakdownExists(
    final BenefitStatementKey key) throws AppException, InformationalException {

    // We only want to populate the flag to indicate whether or not breakdown
    // information exists for the benefit statement.
    final BenefitStatementDetailsList benefitStatementDetailsList = new BenefitStatementDetailsList();

    final NomineeOverUnderPayment nomineeOverUnderPaymentObj = nomineeOverUnderPaymentDAO.get(
      key.nomineeOverUnderPaymentID);

    List<OverUnderPaymentBreakdown> breakdownList;

    // The client page passes a zero string when requesting rolled up details
    if (!key.rulesObjectiveID.equalsIgnoreCase(CuramConst.gkStringZero)
      && !key.rulesObjectiveID.equalsIgnoreCase(CuramConst.gkEmpty)) {

      // Only return the records for the specified rulesObjectiveID
      breakdownList = overUnderPaymentBreakdownDAO.searchByRulesObjectiveNomineeOverUnderPayment(
        nomineeOverUnderPaymentObj, key.rulesObjectiveID);

    } else {

      // return for all components
      breakdownList = overUnderPaymentBreakdownDAO.searchByNomineeOverUnderPayment(
        nomineeOverUnderPaymentObj);

    }

    // Set flag indicating that there are breakdown records for the benefit statement
    benefitStatementDetailsList.breakdownInfoExistsInd = !breakdownList.isEmpty();

    return benefitStatementDetailsList;
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public BenefitStatementDetailsList listBenefitStatementDetailsNoBreakdown(
    final BenefitStatementKey key) throws AppException, InformationalException {

    final BenefitStatementDetailsList benefitStatementDetailsList = new BenefitStatementDetailsList();

    Money totalDifferenceAmount = Money.kZeroMoney;

    //
    // Read the reassessment info records for the over or under payment
    //
    final ReassessmentInfo reassessmentInfoObj = ReassessmentInfoFactory.newInstance();

    final ReadmultiByNomineeOverUnderPaymentIDKey rmKey = new ReadmultiByNomineeOverUnderPaymentIDKey();

    rmKey.nomineeOverUnderPaymentID = key.nomineeOverUnderPaymentID;

    final ReassessmentInfoDtlsList reassessmentInfoDtlsList = reassessmentInfoObj.searchByNomineeOverUnderPaymentID(
      rmKey);

    final curam.core.intf.ReassessmentAmountInfo reassessAmountInfoObj = curam.core.fact.ReassessmentAmountInfoFactory.newInstance();

    final ReassessmentAmountInformationKey reassessAmountInfoKey = new ReassessmentAmountInformationKey();

    // Iterate through the reassessment info records
    for (int i = 0; i < reassessmentInfoDtlsList.dtls.size(); i++) {

      final ReassessmentInfoDtls reassessmentInfoDtls = reassessmentInfoDtlsList.dtls.item(
        i);

      reassessAmountInfoKey.reassessmentInfoID = reassessmentInfoDtls.reassessmentInfoID;

      // Read all the reassessment amount records for the reassessment info
      final ReassessmentAmountInfoDtlsList reassessAmountDtlsList = reassessAmountInfoObj.searchByReassessInfoID(
        reassessAmountInfoKey);

      for (int l = 0; l < reassessAmountDtlsList.dtls.size(); l++) {

        final ReassessmentAmountInfoDtls reassessAmountDtls = reassessAmountDtlsList.dtls.item(
          l);

        // We are only interested in the gross amount
        if (!reassessAmountDtls.amountType.equals(
          curam.codetable.REASSESSMENT_AMOUNT.GROSS)) {

          continue;
        }

        // Create a benefit statement details line item for each reassessment
        // gross amount record
        final BenefitStatementDetails benefitStatementDetails = new BenefitStatementDetails();

        // BEGIN, CR00423372, CSH
        benefitStatementDetails.reassessmentInfoID = reassessmentInfoDtls.reassessmentInfoID;
        // END, CR00423372

        benefitStatementDetails.fromDate = reassessmentInfoDtls.fromDate;
        benefitStatementDetails.toDate = reassessmentInfoDtls.toDate;

        benefitStatementDetails.actualAmount = reassessAmountDtls.actualAmount;
        benefitStatementDetails.reassessedAmount = reassessAmountDtls.reassessedAmount;

        // Set the covers period for this benefit statement line item
        final LocalisableString coverPeriod = new LocalisableString(
          GENERAL.INF_DATE_TO_DATE);

        coverPeriod.arg(benefitStatementDetails.fromDate);
        coverPeriod.arg(benefitStatementDetails.toDate);

        benefitStatementDetails.coversPeriod = coverPeriod.toClientFormattedText();

        // We are unable to read the rules component type where there is
        // no breakdown information available so the column is populated
        // with a localized string.
        final LocalisableString rulesComponent = new LocalisableString(
          BPOPRODUCTDELIVERY.INF_STATEMENT_VIEW_RULES_COMPONENT);

        benefitStatementDetails.rulesComponentDisplay = rulesComponent.toClientFormattedText();

        // Calculate difference amount for the benefit statement details
        final double actAmount = benefitStatementDetails.actualAmount.getValue();
        final double reassAmount = benefitStatementDetails.reassessedAmount.getValue();
        final Money differenceAmount = new Money(reassAmount - actAmount);

        totalDifferenceAmount = new Money(
          totalDifferenceAmount.getValue() + differenceAmount.getValue());

        final LocalisableString difference = formatTotalDifferenceForDisplay(
          differenceAmount);

        benefitStatementDetails.difference = difference.toClientFormattedText();

        // BEGIN, CR00423372, CSH
        if (!differenceAmount.isZero()
          || (differenceAmount.isZero()
            && Configuration.getBooleanProperty(
              EnvVars.ENV_DISPLAY_ZERO_DIFFERENCE))) {

          benefitStatementDetailsList.dtlsList.add(benefitStatementDetails);
        }
        // END, CR00423372

      } // end for reassessAmountDtlsList loop

    } // end for reassessmentInfoDtlsList loop

    //
    // Calculate total difference amount for the benefit statement list
    //
    final LocalisableString totalDifference = formatTotalDifferenceForDisplay(
      totalDifferenceAmount);

    benefitStatementDetailsList.totalDifference = totalDifference.toClientFormattedText();
    sortBenefitStatementDetailsList(benefitStatementDetailsList);

    return benefitStatementDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Helper method to format the total amount for display on the benefit
   * statement details page.
   *
   * @param totalDifferenceAmount The amount to be formatted for display
   * @return LocalisableString to be displayed on the benefit statement.
   * Generic Exception Signature.
   * @throws AppException
   */
  protected LocalisableString formatTotalDifferenceForDisplay(
    Money totalDifferenceAmount) throws AppException, InformationalException {

    LocalisableString totalDifference = null;

    if (totalDifferenceAmount.isNegative()) {
      totalDifference = new LocalisableString(GENERAL.INF_AMOUNT_OVERPAID);
    } else {
      totalDifference = new LocalisableString(GENERAL.INF_AMOUNT_UNDERPAID);
    }

    totalDifferenceAmount = new Money(
      Math.sqrt(
        totalDifferenceAmount.getValue() * totalDifferenceAmount.getValue()));

    totalDifference.arg(totalDifferenceAmount);

    return totalDifference;
  }

  // END, CR00202877

  // BEGIN, CR00231961, ZV
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public RepresentativeID createNomineeRepresentativeWithTextBankAccountSortCode(
    final RepresentativeRegistrationWithTextBankAccountSortCodeDetails dtls)
    throws AppException, InformationalException {

    final curam.core.facade.intf.Representative representativeObj = curam.core.facade.fact.RepresentativeFactory.newInstance();

    RepresentativeID representativeID;

    dtls.representativeRegistrationDetails.representativeDtls.representativeType = curam.codetable.REPRESENTATIVETYPE.NOMINEE;

    final RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

    representativeRegistrationDetails.representativeRegistrationDetails.assign(
      dtls.representativeRegistrationDetails);
    representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.bankSortCode = dtls.bankSortCode;

    representativeID = representativeObj.registerRepresentative(
      representativeRegistrationDetails);

    return representativeID;
  }

  // END, CR00231961

  // BEGIN, CR00264512, ZV
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ParticipantWithoutProspectTypeDescList readAppliedDeductionParticipantsWithoutProspect()
    throws AppException, InformationalException {

    final PropertyDescriptionString deductionParticipantString = new PropertyDescriptionString();

    deductionParticipantString.description = Configuration.getProperty(
      EnvVars.ENV_APPLIED_DEDUCTION_PARTICIPANTS);

    if (deductionParticipantString.description.length() == CuramConst.gkZero) {
      deductionParticipantString.description = Configuration.getProperty(
        EnvVars.ENV_APPLIED_DEDUCTION_PARTICIPANTS_DEFAULT);
    }

    return populateParticipantWithoutProspectList(deductionParticipantString);
  }

  // ___________________________________________________________________________
  /**
   * Reads the list of participants that a third party deduction can be applied
   * to.
   *
   * @return List of participants to display in participant search list.
   */
  public ParticipantWithoutProspectTypeDescList readThirdPartyDeductionParticipantsWithoutProspect()
    throws AppException, InformationalException {

    final PropertyDescriptionString deductionParticipantString = new PropertyDescriptionString();

    deductionParticipantString.description = Configuration.getProperty(
      EnvVars.ENV_THIRDPARTY_DEDUCTION_PARTICIPANTS);

    if (deductionParticipantString.description.length() == CuramConst.gkZero) {
      deductionParticipantString.description = Configuration.getProperty(
        EnvVars.ENV_THIRDPARTY_DEDUCTION_PARTICIPANTS_DEFAULT);
    }

    return populateParticipantWithoutProspectList(deductionParticipantString);
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  protected ParticipantWithoutProspectTypeDescList populateParticipantWithoutProspectList(
    final PropertyDescriptionString details)
    throws AppException, InformationalException {

    final String[] participantArray = details.description.split(
      CuramConst.gkComma);

    final LinkedHashMap<String, String> concernRoleHashMap = CodeTable.getAllItems(
      curam.codetable.CONCERNROLEWITHOUTPROSPECTTYPE.TABLENAME,
      TransactionInfo.getProgramLocale());

    Set<String> concernRoleKeys = new TreeSet<String>();

    if (!concernRoleHashMap.isEmpty()) {
      concernRoleKeys = concernRoleHashMap.keySet();
    }

    final ParticipantWithoutProspectTypeDescList participantTypeDescList = new ParticipantWithoutProspectTypeDescList();

    ParticipantWithoutProspectTypeDescription participantTypeDescription;

    for (int i = 0; i < participantArray.length; i++) {

      if (!concernRoleKeys.isEmpty()) {

        final Iterator<String> itr = concernRoleKeys.iterator();

        while (itr.hasNext()) {
          final String concernRoleKey = itr.next().toString();

          // BEGIN, CR00331694, KH
          if (participantArray[i].trim().equals(concernRoleKey)) {

            participantTypeDescription = new ParticipantWithoutProspectTypeDescription();
            participantTypeDescription.participantType = concernRoleKey;
            participantTypeDescription.participantDescription = concernRoleHashMap.get(concernRoleKey).toString();

            participantTypeDescList.participantTypeDescription.addRef(
              participantTypeDescription);
          }
          // END, CR00331694
        }
      }
    }

    return participantTypeDescList;
  }

  // END, CR00264512

  // BEGIN, CR00264925, ZV
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListActiveLiabilityDetails1 listActiveLiabilitiesForConcernRole(
    final ListActiveLiabilitesForConcernKeyStruct key)
    throws AppException, InformationalException {

    // Create an informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final ListActiveLiabilityDetails1 listActiveLiabilityDetails1 = new ListActiveLiabilityDetails1();
    // BEGIN, CR00208998, CW
    // Local list to hold active overpayment payment correction cases
    final ListActiveLiabilityDetails1 listActiveOverpaymentPaymentCorrectionDetails = new ListActiveLiabilityDetails1();
    // END, CR00208998

    final CreateDeductionItemDtls createDeductionItemDtls = new CreateDeductionItemDtls();

    final DeductionClientDetails deductionClientDetails = new DeductionClientDetails();

    deductionClientDetails.concernRoleType = key.concernRoleType;
    deductionClientDetails.dtls.caseParticipantConcernRoleID = key.caseParticipantConcernRoleID;

    deductionClientDetails.dtls.clientConcernRoleID = key.concernRoleID;

    createDeductionItemDtls.concernRoleID = getDeductionClient(deductionClientDetails).concernRoleID;

    // Retrieve the list of active liabilities and assign to return object
    listActiveLiabilityDetails1.assign(
      MaintainDeductionItemsFactory.newInstance().getActiveLiabilityCasesForConcernRole(
        createDeductionItemDtls));

    // BEGIN, CR00208998, CW
    //
    // Add any active overPayment payment correction cases to the list of
    // liabilities
    // for the concern role
    //

    // Retrieve the active overPayment payment corrections
    listActiveOverpaymentPaymentCorrectionDetails.assign(
      MaintainDeductionItemsFactory.newInstance().getActiveOverpaymentCorrectionCasesForConcern(
        createDeductionItemDtls));

    // Add the active overPayment payment corrections to the list of liabilities
    for (int j = 0; j
      < listActiveOverpaymentPaymentCorrectionDetails.dtls.size(); j++) {

      listActiveLiabilityDetails1.dtls.addRef(
        listActiveOverpaymentPaymentCorrectionDetails.dtls.item(j));
    }
    // END, CR00208998

    final MaintainDeductionItems maintainDeductionItemsObj = MaintainDeductionItemsFactory.newInstance();
    final curam.core.struct.RelatedCaseID relatedCaseID = new curam.core.struct.RelatedCaseID();
    DeductionLiabilityAmountDetails deductionLiabilityAmountDetails;

    if (listActiveLiabilityDetails1.dtls.size() != 0) {

      for (int i = 0; i < listActiveLiabilityDetails1.dtls.size(); i++) {

        relatedCaseID.relatedCaseID = listActiveLiabilityDetails1.dtls.item(i).caseID;

        deductionLiabilityAmountDetails = maintainDeductionItemsObj.readLiabilityAmounts(
          relatedCaseID);

        if (!deductionLiabilityAmountDetails.outstandingAmount.isZero()) {

          listActiveLiabilityDetails1.dtls.item(i).originalAmount = deductionLiabilityAmountDetails.originalAmount;
          listActiveLiabilityDetails1.dtls.item(i).outstandingAmount = deductionLiabilityAmountDetails.outstandingAmount;

        } else {
          listActiveLiabilityDetails1.dtls.remove(i);
          i--;
        }
      }
    } else {

      final AppException appException = new AppException(
        BPOMAINTAINDEDUCTIONITEMS.INF_DEDUCTION_NOMINEE_NO_LIABILITIES);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }

    informationalManager.failOperation();

    return listActiveLiabilityDetails1;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList processThirdPartyFixedDeduction(
    final ThirdPartyDeductionActivationStruct details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Get the deduction concern role
    final ConcernRoleID concernRoleID = new ConcernRoleID();

    final DeductionClientDetails deductionClientDetails = new DeductionClientDetails();

    deductionClientDetails.assign(details.deductionClientDetails);

    concernRoleID.concernRoleID = getDeductionClient(deductionClientDetails).concernRoleID;

    if (details.actionIDProperty.equals(
      ClientActionConst.kActivate_Now_ThirdPartyFixed)) {

      final ThirdPartyFixedDeductionDetails1 thirdPartyFixedDeductionDetails1 = new ThirdPartyFixedDeductionDetails1();

      thirdPartyFixedDeductionDetails1.deductionDtls = details.deductionDtls;
      thirdPartyFixedDeductionDetails1.nomineeDtls = details.nomineeDtls;
      thirdPartyFixedDeductionDetails1.thirdPartyDtls = details.thirdPartyDtls;
      thirdPartyFixedDeductionDetails1.thirdPartyDtls.thirdPartyConcernRoleID = concernRoleID.concernRoleID;

      informationMsgDtlsList = createActiveThirdPartyFixedDeduction(
        thirdPartyFixedDeductionDetails1);

    } else if (details.actionIDProperty.equals(
      ClientActionConst.kActivate_Later_ThirdPartyFixed)) {

      final ThirdPartyFixedDeductionDetails1 thirdPartyFixedDeductionDetails1 = new ThirdPartyFixedDeductionDetails1();

      thirdPartyFixedDeductionDetails1.deductionDtls = details.deductionDtls;
      thirdPartyFixedDeductionDetails1.nomineeDtls = details.nomineeDtls;
      thirdPartyFixedDeductionDetails1.thirdPartyDtls = details.thirdPartyDtls;
      thirdPartyFixedDeductionDetails1.thirdPartyDtls.thirdPartyConcernRoleID = concernRoleID.concernRoleID;

      informationMsgDtlsList = createThirdPartyFixedDeduction1(
        thirdPartyFixedDeductionDetails1);

    } else {
      final AppException e = new AppException(
        BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 8);
    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList processThirdPartyVariableDeduction(
    final ThirdPartyDeductionActivationStruct details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Get the deduction concern role
    final ConcernRoleID concernRoleID = new ConcernRoleID();

    final DeductionClientDetails deductionClientDetails = new DeductionClientDetails();

    deductionClientDetails.assign(details.deductionClientDetails);

    concernRoleID.concernRoleID = getDeductionClient(deductionClientDetails).concernRoleID;

    if (details.actionIDProperty.equals(
      ClientActionConst.kActivate_Now_ThirdPartyVariable)) {

      final ThirdPartyVariableDeductionDetails1 thirdPartyVariableDeductionDetails = new ThirdPartyVariableDeductionDetails1();

      thirdPartyVariableDeductionDetails.deductionDtls = details.deductionDtls;
      thirdPartyVariableDeductionDetails.thirdPartyDtls = details.thirdPartyDtls;
      thirdPartyVariableDeductionDetails.thirdPartyDtls.thirdPartyConcernRoleID = concernRoleID.concernRoleID;

      informationMsgDtlsList = createActiveThirdPartyVariableDeduction(
        thirdPartyVariableDeductionDetails);

    } else if (details.actionIDProperty.equals(
      ClientActionConst.kActivate_Later_ThirdPartyVariable)) {

      final ThirdPartyVariableDeductionDetails1 thirdPartyVariableDeductionDetails = new ThirdPartyVariableDeductionDetails1();

      thirdPartyVariableDeductionDetails.deductionDtls = details.deductionDtls;
      thirdPartyVariableDeductionDetails.thirdPartyDtls = details.thirdPartyDtls;
      thirdPartyVariableDeductionDetails.thirdPartyDtls.thirdPartyConcernRoleID = concernRoleID.concernRoleID;

      informationMsgDtlsList = createThirdPartyVariableDeduction1(
        thirdPartyVariableDeductionDetails);

    } else {
      final AppException e = new AppException(
        BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 4);
    }

    // return all informational messages
    return informationMsgDtlsList;

  }

  // END, CR00264925

  // BEGIN, CR00369134, KRK
  /**
   * Returns the default deduction amount.
   *
   * @param finInstructionIDAndDeductionDetails
   * Contains the financialInstrucionID and Deduction details.
   *
   * @return The deduction amount.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadDeductionAmount getDefaultAmountForDeduction(
    final ReadFinInstructionIDAndDeductionDetails readFinInstructionIDAndDeductionDetails)
    throws AppException, InformationalException {

    final ReadDeductionAmount readDeductionAmount = maintainDeductionAmount.getDeductionAmount(
      readFinInstructionIDAndDeductionDetails);

    return readDeductionAmount;
  }

  /**
   * {@inheritDoc}
   */
  public InformationalMsgDtlsList readDeductionPaymentDetails(
    ReadFinInstructionIDAndDeductionDetails readFinInstructionIDAndDeductionDetails) throws AppException,
      InformationalException {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    final InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();
    final AmountDetail amountDetail = new AmountDetail();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.wizardStateID = readFinInstructionIDAndDeductionDetails.wizardStateID;

    final RegenerateDeductionDetails regenerateDeductionDetails = FinancialFactory.newInstance().readUnappliedDeductionWizardDetails(
      wizardStateID);

    readFinInstructionIDAndDeductionDetails.deductionAmount = regenerateDeductionDetails.deductionDetails.amount;

    ListCaseFinancialsKey listCaseFinancialsKey = new ListCaseFinancialsKey();

    listCaseFinancialsKey.caseID = readFinInstructionIDAndDeductionDetails.caseID;
    curam.core.facade.struct.ViewCaseFinancialInstructionList viewCaseFinancialInstructionList = curam.core.facade.fact.ProductDeliveryFactory.newInstance().listCaseFinancialInstruction(
      listCaseFinancialsKey);

    for (ViewCaseInstructionDetails viewCaseInstructionDetails : viewCaseFinancialInstructionList.dtls.dtlsList.items()) {

      if (viewCaseInstructionDetails.finInstructDtls.finInstructionID
        == readFinInstructionIDAndDeductionDetails.finInstructionID) {

        if (DEDUCTIONCATEGORYCODE.APPLIEDDEDUCTION.equals(
          readFinInstructionIDAndDeductionDetails.category)) {

          curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

          caseIDKey.caseID = readFinInstructionIDAndDeductionDetails.relatedCaseID;

          DeductionHeaderDetails deductionHeaderDetails = readDeductionLiabilityDetails(
            caseIDKey);

          Money totalAmount = new Money(
            (viewCaseInstructionDetails.finInstructDtls.amount.getValue()
              - readFinInstructionIDAndDeductionDetails.deductionAmount.getValue()));

          amountDetail.amount = totalAmount;

          final AppException e = new AppException(
            BPOMAINTAINDEDUCTIONITEMS.INF_REISSUE_APPLIED_DEDUCTION_PAYMENT);

          e.arg(
            TabDetailFormatterFactory.newInstance().formatCurrencyAmount(amountDetail).amount);

          amountDetail.amount = readFinInstructionIDAndDeductionDetails.deductionAmount;
          e.arg(
            TabDetailFormatterFactory.newInstance().formatCurrencyAmount(amountDetail).amount);
          e.arg(deductionHeaderDetails.liabilityNameReference);

          ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(e,
            GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kWarning,
            ValidationManagerConst.kSetOne, 0);
        } else if (DEDUCTIONCATEGORYCODE.UNAPPLIEDDEDUCTION.equals(
          readFinInstructionIDAndDeductionDetails.category)) {

          Money totalAmount = new Money(
            (viewCaseInstructionDetails.finInstructDtls.amount.getValue()
              - readFinInstructionIDAndDeductionDetails.deductionAmount.getValue()));
          final AppException reissuePayment = new AppException(
            BPOMAINTAINDEDUCTIONITEMS.INF_REISSUE_DEDUCTION_PAYMENT);

          amountDetail.amount = totalAmount;

          reissuePayment.arg(
            TabDetailFormatterFactory.newInstance().formatCurrencyAmount(amountDetail).amount);
          amountDetail.amount = readFinInstructionIDAndDeductionDetails.deductionAmount;
          reissuePayment.arg(
            TabDetailFormatterFactory.newInstance().formatCurrencyAmount(amountDetail).amount);

          ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            reissuePayment, GeneralConstants.kEmpty,
            InformationalElement.InformationalType.kWarning,
            ValidationManagerConst.kSetOne, 0);
        }
      }
    }
    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }

    return informationalMsgDtlsList;
  }
  // END, CR00369134

}
