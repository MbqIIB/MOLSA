/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.AUDITCASEFOCUSAREAEntry;
import curam.util.persistence.StandardDAO;

/**
 * Data access for {@linkplain curam.caseaudit.impl.AuditCaseFocusArea}.
 */
@ImplementedBy(AuditCaseFocusAreaDAOImpl.class)
public interface AuditCaseFocusAreaDAO 
  extends StandardDAO<AuditCaseFocusArea> {

  // ___________________________________________________________________________
  /**
   * Returns a list of audit case focus area records 
   * for an audit case configuration.
   *  
   * @param auditCaseConfig
   *          the audit case configuration.
   *          
   * @return List of audit case focus area records 
   * for an audit case configuration.
   */
  public Set<AuditCaseFocusArea> searchBy(AuditCaseConfig auditCaseConfig);

  // ___________________________________________________________________________
  /**
   * Returns a list of audit case focus area records for a specified 
   * audit case configuration and focus area.
   *  
   * @param auditCaseConfig
   *          the audit case configuration.
   * @param focusAreaCode
   *          the focus area to search for.
          
   * @return List of audit case focus area records 
   * for a specified audit case configuration and focus area.
   */

  public Set<AuditCaseFocusArea> searchByAuditCaseConfigAndFocusArea(
    final AuditCaseConfig auditCaseConfig, 
    final AUDITCASEFOCUSAREAEntry focusAreaCode);

}
