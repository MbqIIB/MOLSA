/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import org.apache.log4j.Logger;

import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.core.struct.FCdateRangeDeliveryMethod;
import curam.core.struct.FCdateRangeKey;
import curam.core.struct.FCdeliveryMethod;
import curam.core.struct.FCexclusionDateDeliveryMethod;
import curam.core.struct.FinancialCalendarDtls;
import curam.core.struct.FinancialCalendarDtlsList;
import curam.core.struct.FinancialCalendarKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * @see curam.core.intf.CachedFinancialCalendar 
 */
public abstract class CachedFinancialCalendar extends curam.core.base.CachedFinancialCalendar {

  protected static ThreadLocal cachedFinancialCalDtlsListByDelMethodType = new ThreadLocal();
  protected static ThreadLocal cachedFinancialCalendarDtls = new ThreadLocal();
  protected static ThreadLocal cachedFinancialCalendarDtlsListByExclusionDateRange = new ThreadLocal();

  // ___________________________________________________________________________

  // Logger for the caching output
  // BEGIN, CR00023323, SK
  public static final String kBatchCachingCategory = Trace.kDefaultTraceCategory
    + ExtensionConst.kBatchCachingCategory;
  // END, CR00023323
  public static final Logger kBatchLauncherCacheLogger = Logger.getLogger(
    kBatchCachingCategory);

  // ___________________________________________________________________________
  /**
   * class to hold the cached FinancialCalendarDtlsList
   */
  protected class FinancialCalendarDtlsListCache {
    // BEGIN, CR00049218, GM
    public String deliveryMethodType = CuramConst.gkEmpty;
    // END, CR00049218

    public int transactionID = 0;
    public FinancialCalendarDtlsList financialCalendarDtlsList = new FinancialCalendarDtlsList();
  }


  // ___________________________________________________________________________
  /**
   * class to hold the cached FinancialCalendarDtlsList
   */
  protected class FinancialCalendarDtlsCache {

    public int transactionID = 0;
    public FinancialCalendarDtls financialCalendarDtls = new FinancialCalendarDtls();
  }


  // ___________________________________________________________________________

  // declare custom exception class
  public final class AppMultipleRecordException extends curam.util.exception.MultipleRecordException {

    public AppMultipleRecordException() {
      super(null, null, null);
    }
  }


  // ___________________________________________________________________________
  // declare custom exception class
  public final class AppRecordNotFoundException extends curam.util.exception.RecordNotFoundException {

    public AppRecordNotFoundException() {
      super(null, null, null);
    }

  }
  // ___________________________________________________________________________
  public static final boolean logging;
  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;

  static {

    cachingEnabled = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);

    String logging_enabled = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED);

    if (logging_enabled == null) {
      logging_enabled = EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED_DEFAULT;
    }

    if (logging_enabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      logging = true;

    } else {
      logging = false;
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public FinancialCalendarDtlsList readFinancialCalendarDtlsByExclusionDateRange(FCdateRangeKey key)
    throws AppException, InformationalException {

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    FinancialCalendarDtlsList financialCalendarDtlsList = new FinancialCalendarDtlsList();

    // If this is a batch transaction or deferred processing
    // and caching is enabled try to read from the cache
    if ((transactionType.equals(TransactionType.kBatch)
      || transactionType.equals(TransactionType.kDeferred))
        && cachingEnabled) {

      // Read the cache
      FinancialCalendarDtlsListCache financialCalendarDtlsListCache = (FinancialCalendarDtlsListCache)
        cachedFinancialCalendarDtlsListByExclusionDateRange.get();

      // If this is a deferred transaction, we must also check
      // that the transaction numbers match
      if (financialCalendarDtlsListCache != null
        && transactionType.equals(TransactionType.kDeferred)
        && TransactionInfo.getIdentifierForThisThread()
          != financialCalendarDtlsListCache.transactionID) {

        financialCalendarDtlsListCache = null;
      }

      if (financialCalendarDtlsListCache != null) {

        // Initialize the return object
        financialCalendarDtlsList = new FinancialCalendarDtlsList();
        financialCalendarDtlsList.dtls.ensureCapacity(
          financialCalendarDtlsListCache.financialCalendarDtlsList.dtls.size());

        // Assign all records from the cache
        financialCalendarDtlsList.assign(
          financialCalendarDtlsListCache.financialCalendarDtlsList);

        // Set up the key to filter by dates
        FCdateRangeDeliveryMethod fcDateRangeDeliveryMethod = new FCdateRangeDeliveryMethod();

        fcDateRangeDeliveryMethod.dateFrom = key.dateFrom;
        fcDateRangeDeliveryMethod.dateTo = key.dateTo;

        // Return only those that fit the exclusion dates
        return getFinancialCalendarListDtls(financialCalendarDtlsList,
          fcDateRangeDeliveryMethod);
      }
    }

    // Otherwise load the cache and return the details
    financialCalendarDtlsList = reloadDtlsListExclusionDateCache(key);

    return financialCalendarDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public FinancialCalendarDtlsList readFinancialCalendarDtlsByDeliveryMethodExclusionDateRange(FCdateRangeDeliveryMethod key)
    throws AppException, InformationalException {

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    FinancialCalendarDtlsList financialCalendarDtlsList = new FinancialCalendarDtlsList();

    // If this is a batch transaction or deferred processing
    // and caching is enabled try to read from the cache
    if ((transactionType.equals(TransactionType.kBatch)
      || transactionType.equals(TransactionType.kDeferred))
        && cachingEnabled) {

      // Read the cache
      FinancialCalendarDtlsListCache financialCalendarDtlsListCache = (FinancialCalendarDtlsListCache)
        cachedFinancialCalDtlsListByDelMethodType.get();

      // If this is a deferred transaction, we must also check
      // that the transaction numbers match
      if (financialCalendarDtlsListCache != null
        && transactionType.equals(TransactionType.kDeferred)
        && TransactionInfo.getIdentifierForThisThread()
          != financialCalendarDtlsListCache.transactionID) {

        financialCalendarDtlsListCache = null;
      }

      // Try to find the data in the cache
      if (financialCalendarDtlsListCache != null
        && financialCalendarDtlsListCache.deliveryMethodType.equals(
          key.deliveryMethodType)) {

        financialCalendarDtlsList = new FinancialCalendarDtlsList();
        financialCalendarDtlsList.dtls.ensureCapacity(
          financialCalendarDtlsListCache.financialCalendarDtlsList.dtls.size());

        // Assign all records regardless of the exclusion dates
        financialCalendarDtlsList.assign(
          financialCalendarDtlsListCache.financialCalendarDtlsList);

        // Return only those that fit the exclusion dates
        return getFinancialCalendarListDtls(financialCalendarDtlsList, key);
      }
    }

    // Otherwise reload the data into the cache and return the details
    FCexclusionDateDeliveryMethod fcExclusionDateDeliveryMethod = new FCexclusionDateDeliveryMethod();

    fcExclusionDateDeliveryMethod.deliveryMethodType = key.deliveryMethodType;

    financialCalendarDtlsList = reloadDtlsListCache(
      fcExclusionDateDeliveryMethod);

    return getFinancialCalendarListDtls(financialCalendarDtlsList, key);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public FinancialCalendarDtls readByExclusionDateDeliveryMethod(FCexclusionDateDeliveryMethod key)
    throws AppException, InformationalException {

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    FinancialCalendarDtlsList financialCalendarDtlsList;

    // If this is a batch transaction or deferred processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    if ((transactionType.equals(TransactionType.kBatch)
      || transactionType.equals(TransactionType.kDeferred))
        && cachingEnabled) {

      FinancialCalendarDtlsListCache financialCalendarDtlsListCache = (FinancialCalendarDtlsListCache)
        cachedFinancialCalDtlsListByDelMethodType.get();

      // if this is a deferred transaction, we must also check
      // that the transaction numbers match
      if (financialCalendarDtlsListCache != null
        && transactionType.equals(TransactionType.kDeferred)
        && TransactionInfo.getIdentifierForThisThread()
          != financialCalendarDtlsListCache.transactionID) {

        financialCalendarDtlsListCache = null;
      }

      // Try to find the data in the cache
      if (financialCalendarDtlsListCache != null
        && financialCalendarDtlsListCache.deliveryMethodType.equals(
          key.deliveryMethodType)) {

        financialCalendarDtlsList = new FinancialCalendarDtlsList();

        financialCalendarDtlsList.dtls.ensureCapacity(
          financialCalendarDtlsListCache.financialCalendarDtlsList.dtls.size());
        financialCalendarDtlsList.assign(
          financialCalendarDtlsListCache.financialCalendarDtlsList);

        return getFinancialCalendarDtls(financialCalendarDtlsList, key);
      }

    }

    // otherwise reload the data
    financialCalendarDtlsList = reloadDtlsListCache(key);

    return getFinancialCalendarDtls(financialCalendarDtlsList, key);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public FinancialCalendarDtls read(FinancialCalendarKey key)
    throws AppException, InformationalException {

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    // If this is a batch or deferred processing transaction
    // (and caching is enabled), and we've hit
    // the cache just copy the data from the cache
    if ((transactionType.equals(TransactionType.kBatch)
      || transactionType.equals(TransactionType.kDeferred))
        && cachingEnabled) {

      FinancialCalendarDtlsCache financialCalendarDtlsCache = (FinancialCalendarDtlsCache) cachedFinancialCalendarDtls.get();

      if (financialCalendarDtlsCache != null
        && transactionType.equals(TransactionType.kDeferred)
        && TransactionInfo.getIdentifierForThisThread()
          != financialCalendarDtlsCache.transactionID) {

        financialCalendarDtlsCache = null;
      }

      if (financialCalendarDtlsCache != null
        && financialCalendarDtlsCache.financialCalendarDtls.financialCalendarID
          == key.financialCalendarID) {

        return financialCalendarDtlsCache.financialCalendarDtls;
      }
    }

    return reloadDtlsCache(key);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public FinancialCalendarDtlsList reloadDtlsListExclusionDateCache(FCdateRangeKey key) throws AppException, InformationalException {

    FinancialCalendarDtlsList financialCalendarDtlsList;

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    // FinancialCalendar manipulation variables
    curam.core.intf.FinancialCalendar financialCalendarObj = curam.core.fact.FinancialCalendarFactory.newInstance();

    // Read the financial calendar records
    financialCalendarDtlsList = financialCalendarObj.searchByExclusionDateRange(
      key);

    financialCalendarDtlsList.dtls.trimToSize();

    // Check the transaction type
    if ((transactionType.equals(TransactionInfo.TransactionType.kBatch)
      || transactionType.equals(TransactionInfo.TransactionType.kDeferred))
        && cachingEnabled) {

      FinancialCalendarDtlsListCache financialCalendarDtlsListCache = new FinancialCalendarDtlsListCache();

      financialCalendarDtlsListCache.transactionID = TransactionInfo.getIdentifierForThisThread();

      financialCalendarDtlsListCache.financialCalendarDtlsList.dtls.ensureCapacity(
        financialCalendarDtlsList.dtls.size());

      // BEGIN, CR00021235, TV
      // BEGIN, HARP 61893, GYH
      financialCalendarDtlsListCache.financialCalendarDtlsList.assign(
        financialCalendarDtlsList);
      // END, HARP 61893
      // END, CR00021235


      // set the cached record
      cachedFinancialCalendarDtlsListByExclusionDateRange.set(
        financialCalendarDtlsListCache);

    }

    return financialCalendarDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public FinancialCalendarDtlsList reloadDtlsListCache(FCexclusionDateDeliveryMethod key) throws AppException, InformationalException {

    FinancialCalendarDtlsList financialCalendarDtlsList;

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    // FinancialCalendar manipulation variables
    curam.core.intf.FinancialCalendar financialCalendarObj = curam.core.fact.FinancialCalendarFactory.newInstance();

    FCdeliveryMethod fCdeliveryMethod = new FCdeliveryMethod();

    fCdeliveryMethod.deliveryMethodType = key.deliveryMethodType;

    financialCalendarDtlsList = financialCalendarObj.searchByDeliveryMethod(
      fCdeliveryMethod);

    financialCalendarDtlsList.dtls.trimToSize();

    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((transactionType.equals(TransactionInfo.TransactionType.kBatch)
      || transactionType.equals(TransactionInfo.TransactionType.kDeferred))
        && cachingEnabled) {

      FinancialCalendarDtlsListCache financialCalendarDtlsListCache = new FinancialCalendarDtlsListCache();

      financialCalendarDtlsListCache.transactionID = TransactionInfo.getIdentifierForThisThread();

      financialCalendarDtlsListCache.deliveryMethodType = key.deliveryMethodType;

      financialCalendarDtlsListCache.financialCalendarDtlsList.dtls.ensureCapacity(
        financialCalendarDtlsList.dtls.size());

      financialCalendarDtlsListCache.financialCalendarDtlsList.assign(
        financialCalendarDtlsList);

      // set the cached record
      cachedFinancialCalDtlsListByDelMethodType.set(
        financialCalendarDtlsListCache);

    }

    return financialCalendarDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void clearCache() throws AppException, InformationalException {

    cachedFinancialCalDtlsListByDelMethodType.set(null);
    cachedFinancialCalendarDtlsListByExclusionDateRange.set(null);
    cachedFinancialCalendarDtls.set(null);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public FinancialCalendarDtlsList getFinancialCalendarListDtls(FinancialCalendarDtlsList financialCalendarDtlsList, FCdateRangeDeliveryMethod key) {

    FinancialCalendarDtlsList financialCalDtlsList = new FinancialCalendarDtlsList();

    // Filter out the records from FinancialCalendarDtlsList
    // that match the passed key values
    // BEGIN, CR00213649, PB.
    for (int i = 0; i < financialCalendarDtlsList.dtls.size(); i++) {
      // END, CR00213649, PB
      if ((financialCalendarDtlsList.dtls.item(i).exclusionDate.after(
        key.dateFrom)
          || financialCalendarDtlsList.dtls.item(i).exclusionDate.equals(
            key.dateFrom))
              && (financialCalendarDtlsList.dtls.item(i).exclusionDate.before(
                key.dateTo)
                  || financialCalendarDtlsList.dtls.item(i).exclusionDate.equals(
                    key.dateTo))) {

        financialCalDtlsList.dtls.addRef(financialCalendarDtlsList.dtls.item(i));
      }
    }

    // BEGIN, CR00213649, PB.
    return financialCalDtlsList;
    // END, CR00213649, PB
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public FinancialCalendarDtls getFinancialCalendarDtls(FinancialCalendarDtlsList financialCalendarDtlsList, FCexclusionDateDeliveryMethod key) {

    FinancialCalendarDtlsList financialCalDtlsList = new FinancialCalendarDtlsList();
    FinancialCalendarDtls financialCalendarDtls = new FinancialCalendarDtls();

    // Filter out the records from FinancialCalendarDtlsList
    // that match the passed key values
    for (int i = financialCalendarDtlsList.dtls.size(); --i >= 0;) {
      if (financialCalendarDtlsList.dtls.item(i).exclusionDate.equals(
        key.exclusionDate)) {

        financialCalDtlsList.dtls.addRef(financialCalendarDtlsList.dtls.item(i));
      }
    }

    final int kNumberOfRecords = financialCalDtlsList.dtls.size();

    // There should only be one matching record
    if (kNumberOfRecords > 1) {
      throw new AppMultipleRecordException();
    } else if (kNumberOfRecords == 1) {

      financialCalendarDtls = financialCalDtlsList.dtls.get(0);

    } else {
      // record not found
      throw new AppRecordNotFoundException();
    }

    return financialCalendarDtls;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public FinancialCalendarDtls reloadDtlsCache(FinancialCalendarKey key) throws AppException, InformationalException {

    FinancialCalendarDtls financialCalendarDtls;

    // FinancialCalendar manipulation variables
    curam.core.intf.FinancialCalendar financialCalendarObj = curam.core.fact.FinancialCalendarFactory.newInstance();

    financialCalendarDtls = financialCalendarObj.read(key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((TransactionInfo.getTransactionType().equals(TransactionType.kBatch)
      || TransactionInfo.getTransactionType().equals(TransactionType.kDeferred))
        && cachingEnabled) {

      FinancialCalendarDtlsCache financialCalendarDtlsCache = new FinancialCalendarDtlsCache();

      financialCalendarDtlsCache.financialCalendarDtls = financialCalendarDtls;
      financialCalendarDtlsCache.transactionID = TransactionInfo.getIdentifierForThisThread();

      cachedFinancialCalendarDtls.set(financialCalendarDtlsCache);
    }
    return financialCalendarDtls;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public FinancialCalendarDtls getDtlsCache() {

    FinancialCalendarDtls financialCalendarDtlsCache = (FinancialCalendarDtls) cachedFinancialCalendarDtls.get();

    if (financialCalendarDtlsCache != null) {

      FinancialCalendarDtls financialCalendarDtls = new FinancialCalendarDtls();

      // return a copy of the Dtls struct
      return financialCalendarDtls.assign(financialCalendarDtlsCache);

    }
    return null;

  }

}
