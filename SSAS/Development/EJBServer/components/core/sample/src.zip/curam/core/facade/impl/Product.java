/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import java.util.Map;

import com.google.inject.Inject;

import curam.attendance.entity.struct.AbsenceReasonConfigurationDtls;
import curam.attendance.entity.struct.AbsenceReasonConfigurationKey;
import curam.attendance.impl.AbsenceReasonConfiguration;
import curam.attendance.impl.AbsenceReasonConfigurationDAO;
import curam.codetable.ASSESSMENTNAME;
import curam.codetable.CASETYPECODE;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.EVIDENCELEVEL;
import curam.codetable.EVIDENCESCREENRELATEDTYPE;
import curam.codetable.EVIDENCE_APPROVAL_CHECK;
import curam.codetable.INVESTIGATECONFIGTYPE;
import curam.codetable.ISSUECONFIGURATIONTYPE;
import curam.codetable.METHODOFDELIVERY;
import curam.codetable.OVERUNDERPMNTPROCESSING;
import curam.codetable.PAGETYPE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTNAME;
import curam.codetable.RECORDSTATUS;
import curam.codetable.RESOLUTIONCONIFIGURATION;
import curam.codetable.RULESCOMPONENTTYPE;
import curam.codetable.SCREENINGNAMECODE;
import curam.codetable.SITEMAP;
import curam.codetable.TEMPORAL_EVIDENCE_TYPE_APPROVAL;
import curam.codetable.impl.ABSENCEREASONASSOCIATETYPEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.collaboration.impl.CaseCollaborationAdminStrategy;
import curam.core.facade.fact.OrganizationFactory;
import curam.core.facade.fact.ResourceFactory;
import curam.core.facade.intf.Resource;
import curam.core.facade.struct.AbsenceReasonConfigurationDetailsList;
import curam.core.facade.struct.AddCategoriesToProductKey;
import curam.core.facade.struct.AddDeductionKey;
import curam.core.facade.struct.AssessmentConfigurationIDAndNameDetailsList;
import curam.core.facade.struct.AssignRuleSetToProductDetails;
import curam.core.facade.struct.AssociateIDKey;
import curam.core.facade.struct.BenefitProductDetails;
import curam.core.facade.struct.BenefitProductDetails1;
import curam.core.facade.struct.BenefitProductType;
import curam.core.facade.struct.BenefitProductTypeList;
import curam.core.facade.struct.CancelAdhocBonusKey;
import curam.core.facade.struct.CancelDeliveryPatternKey;
import curam.core.facade.struct.CancelEvidenceApprovalCheckKey;
import curam.core.facade.struct.CancelEvidenceGroupPageDetails;
import curam.core.facade.struct.CancelEvidencePageDetails;
import curam.core.facade.struct.CancelInvestigationApprovalCheckKey;
import curam.core.facade.struct.CancelIssueResolutionApprovalCheckKey;
import curam.core.facade.struct.CancelPDAssessmentConfigurationDetails;
import curam.core.facade.struct.CancelProductApprovalCheckKey;
import curam.core.facade.struct.CancelProductEvidenceFormLinkKey;
import curam.core.facade.struct.CancelProductKey;
import curam.core.facade.struct.CancelProductProvisionKey;
import curam.core.facade.struct.CancelProductTimeConstraint;
import curam.core.facade.struct.CancelProvisionLocationKey;
import curam.core.facade.struct.CancelRuleSetFromProductKey;
import curam.core.facade.struct.CancelSiteMapDetails;
import curam.core.facade.struct.ComponentBaseType;
import curam.core.facade.struct.ComponentType;
import curam.core.facade.struct.ConcernRoleKeyStruct;
import curam.core.facade.struct.CorrectionProductDetails;
import curam.core.facade.struct.CreateAdhocBonusCriteriaDetails;
import curam.core.facade.struct.CreateDeductionAndProductLinkDetails;
import curam.core.facade.struct.CreateDeductionDtls;
import curam.core.facade.struct.CreateDeductionProductLinkDetails;
import curam.core.facade.struct.CreateDeliveryPatternDetails;
import curam.core.facade.struct.CreateEvidenceGroupPageDetails;
import curam.core.facade.struct.CreateEvidencePageDetails;
import curam.core.facade.struct.CreatePDAssessmentConfigurationDetails;
import curam.core.facade.struct.CreateProductEvidenceFormLinkDetails;
import curam.core.facade.struct.CreateProductTimeConstraint;
import curam.core.facade.struct.CreateProvisionLocationDetails;
import curam.core.facade.struct.CreateSiteMapDetails;
import curam.core.facade.struct.DeductionKey;
import curam.core.facade.struct.DeductionProductLinkDetailsList;
import curam.core.facade.struct.DeductionProductLinkKey;
import curam.core.facade.struct.DeductionProductLinkWithVersionNoDetailsList;
import curam.core.facade.struct.DeliveryPatternNameDetails;
import curam.core.facade.struct.DeliveryPatternNamePrefMethodPmtIndDetails;
import curam.core.facade.struct.DeliveryPatternNamePrefMethodPmtIndDetails1;
import curam.core.facade.struct.DeliveryPatternNamePrefMethodPmtIndDtlsList;
import curam.core.facade.struct.DeliveryPatternNamePrefMethodPmtIndDtlsList1;
import curam.core.facade.struct.EligibleParticipantDetails;
import curam.core.facade.struct.EvidenceApprovalCheckDtls;
import curam.core.facade.struct.EvidenceGroupPageDetails;
import curam.core.facade.struct.EvidenceListDetails;
import curam.core.facade.struct.EvidenceMetadataDetails;
import curam.core.facade.struct.EvidenceMetadataDetailsList;
import curam.core.facade.struct.EvidenceMetadataRecordStatusVersionNo;
import curam.core.facade.struct.EvidencePageDetails;
import curam.core.facade.struct.InvestigationApprovalCheckDetails;
import curam.core.facade.struct.InvestigationCaseContextDescriptionDetails;
import curam.core.facade.struct.InvestigationCaseContextDescriptionKey;
import curam.core.facade.struct.InvestigationConfigurationDetails;
import curam.core.facade.struct.InvestigationConfigurationListDetails;
import curam.core.facade.struct.InvestigationTypeContextDescriptionDetails;
import curam.core.facade.struct.InvestigationTypeContextDescriptionKey;
import curam.core.facade.struct.IssueConfigTypeList;
import curam.core.facade.struct.IssueConfigurationDetails;
import curam.core.facade.struct.IssueConfigurationDetailsList;
import curam.core.facade.struct.IssueResLinkIDResolutionDtlsList;
import curam.core.facade.struct.IssueResolutionApprovalCheckDetails;
import curam.core.facade.struct.IssueResolutionLinkDtls;
import curam.core.facade.struct.IssueResolutionLinkKey;
import curam.core.facade.struct.IssueTimeConstraintList;
import curam.core.facade.struct.IssueTypeContextDescriptionDetails;
import curam.core.facade.struct.IssueTypeContextDescriptionKey;
import curam.core.facade.struct.IssueTypeDescriptionDetailsList;
import curam.core.facade.struct.LiabilityProductDetails;
import curam.core.facade.struct.LiabilityProductDetails1;
import curam.core.facade.struct.LiabilityProductType;
import curam.core.facade.struct.LiabilityProductTypeList;
import curam.core.facade.struct.ListActiveBenefitProductsForPersonDetails;
import curam.core.facade.struct.ListActiveBenefitProductsForPersonKey;
import curam.core.facade.struct.ListActiveEvidenceFormsDetails;
import curam.core.facade.struct.ListAdhocBonusCriteriaDetails;
import curam.core.facade.struct.ListAdhocBonusCriteriaKey;
import curam.core.facade.struct.ListAllProductsDetails;
import curam.core.facade.struct.ListAllProviderLocations;
import curam.core.facade.struct.ListApprovalChecksForProductDetails;
import curam.core.facade.struct.ListApprovalChecksForProductKey;
import curam.core.facade.struct.ListAssessmentTypesForPDCaseIDKey;
import curam.core.facade.struct.ListAssessmentTypesForPDCaseIDListDetails;
import curam.core.facade.struct.ListDeliveryPatternDetails;
import curam.core.facade.struct.ListDeliveryPatternHistoryDetails;
import curam.core.facade.struct.ListDeliveryPatternHistoryKey;
import curam.core.facade.struct.ListDeliveryPatternKey;
import curam.core.facade.struct.ListDeliveryPatternNameDetails;
import curam.core.facade.struct.ListDeliveryPatternNamesKey;
import curam.core.facade.struct.ListEvidenceApprovalCheckDetails;
import curam.core.facade.struct.ListEvidenceApprovalCheckKey;
import curam.core.facade.struct.ListEvidenceFormsForProductDetails;
import curam.core.facade.struct.ListEvidenceFormsForProductKey;
import curam.core.facade.struct.ListEvidenceGroupPageDetails;
import curam.core.facade.struct.ListEvidenceGroupPageKey;
import curam.core.facade.struct.ListEvidencePageDetails;
import curam.core.facade.struct.ListEvidencePageKey;
import curam.core.facade.struct.ListInvestigationApprovalCheckDetails;
import curam.core.facade.struct.ListInvestigationApprovalCheckDetailsAndVersionNo;
import curam.core.facade.struct.ListIssueResolutionApprovalCheckDetails;
import curam.core.facade.struct.ListIssueResolutionApprovalCheckDetailsAndVersionNo;
import curam.core.facade.struct.ListLocationForProviderDetails;
import curam.core.facade.struct.ListLocationForProviderKey;
import curam.core.facade.struct.ListProductCategoryDetails;
import curam.core.facade.struct.ListProductCategoryKey;
import curam.core.facade.struct.ListProductDeliveryPatternDetails;
import curam.core.facade.struct.ListProductDetailsStruct;
import curam.core.facade.struct.ListProductProvisionsForProduct;
import curam.core.facade.struct.ListProductProvisionsForProductKey;
import curam.core.facade.struct.ListProductTimeConstraint;
import curam.core.facade.struct.ListProductTimeConstraintAndVersionNo;
import curam.core.facade.struct.ListProductsForCategoryKey;
import curam.core.facade.struct.ListProviderAndLocationDetails;
import curam.core.facade.struct.ListProviderAndLocationKey;
import curam.core.facade.struct.ListProvisionLocationDetails;
import curam.core.facade.struct.ListProvisionLocationKey;
import curam.core.facade.struct.ListRulesForProductDetails;
import curam.core.facade.struct.ListRulesForProductDetailsAndVersionNo;
import curam.core.facade.struct.ListRulesForProductKey;
import curam.core.facade.struct.ListRulesObjectiveDetails;
import curam.core.facade.struct.ListRulesObjectiveKey;
import curam.core.facade.struct.ListRulesObjectiveTagDetails;
import curam.core.facade.struct.ListRulesObjectiveTagKey;
import curam.core.facade.struct.ListSiteMapDetails;
import curam.core.facade.struct.ListSiteMapKey;
import curam.core.facade.struct.MilestoneComponentList;
import curam.core.facade.struct.MilestoneConfigurationDtls;
import curam.core.facade.struct.MilestoneConfigurationDtlsList;
import curam.core.facade.struct.MilestoneSubComponentList;
import curam.core.facade.struct.ModifyAdhocBonusCriteriaDetails;
import curam.core.facade.struct.ModifyDeductionPriorityDetails;
import curam.core.facade.struct.ModifyDeliverPatternDetails;
import curam.core.facade.struct.ModifyEvidenceGroupPageDetails;
import curam.core.facade.struct.ModifyEvidencePageDetails;
import curam.core.facade.struct.ModifyPDAssessmentConfigurationDetails;
import curam.core.facade.struct.ModifyProductDeductionDetails;
import curam.core.facade.struct.ModifyProductDeliveryPatternDetails;
import curam.core.facade.struct.ModifyProductEvidenceFormLinkDetails;
import curam.core.facade.struct.ModifyProductProvisionDetails;
import curam.core.facade.struct.ModifyProductTimeConstraint;
import curam.core.facade.struct.ModifyProvisionLocationDetails;
import curam.core.facade.struct.ModifyProvisionLocationKey;
import curam.core.facade.struct.ModifyRuleSetAssignmentDetails;
import curam.core.facade.struct.ModifySiteMapDetails;
import curam.core.facade.struct.ModifyTemporalEvidenceApprovalCheck;
import curam.core.facade.struct.PDAssessmentConfigurationContextDescriptionDetails;
import curam.core.facade.struct.PDAssessmentConfigurationContextDescriptionKey;
import curam.core.facade.struct.PDAssessmentConfigurationDetails;
import curam.core.facade.struct.PDAssessmentConfigurationSummaryDetailsList;
import curam.core.facade.struct.PDAssessmentConfigurationSummaryDetailsListAndVersionNo;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.facade.struct.PercentageAndCommentsDetails;
import curam.core.facade.struct.ProductApprovalCheckDetails;
import curam.core.facade.struct.ProductContextDescriptionDetails;
import curam.core.facade.struct.ProductContextDescriptionKey;
import curam.core.facade.struct.ProductCreateProductProvisionDetails;
import curam.core.facade.struct.ProductDefaultValuesDetails;
import curam.core.facade.struct.ProductDetailsStruct;
import curam.core.facade.struct.ProductEvidenceLinkDetails;
import curam.core.facade.struct.ProductEvidenceTypeDetails;
import curam.core.facade.struct.ProductIDAndConcernRoleID;
import curam.core.facade.struct.ProductMilestoneLinkKey;
import curam.core.facade.struct.ProductNameList;
import curam.core.facade.struct.ProductProvisionsForProductStruct;
import curam.core.facade.struct.ProductRuleSetContextDecriptionDetails;
import curam.core.facade.struct.ProductRuleSetContextDescriptionKey;
import curam.core.facade.struct.ProductTimeConstraintKey;
import curam.core.facade.struct.ProviderAndLocationDetails;
import curam.core.facade.struct.ProvisionLocationContextDescriptionDetails;
import curam.core.facade.struct.ProvisionLocationContextDescriptionKey;
import curam.core.facade.struct.ProvisionLocationDetailsStruct;
import curam.core.facade.struct.ReadAdhocBonusCriteriaDetails;
import curam.core.facade.struct.ReadAdhocBonusCriteriaKey;
import curam.core.facade.struct.ReadBenefitProductKey;
import curam.core.facade.struct.ReadBenefitProductStruct;
import curam.core.facade.struct.ReadBenefitProductStruct1;
import curam.core.facade.struct.ReadDeductionDtls;
import curam.core.facade.struct.ReadDeliveryPatternDetails;
import curam.core.facade.struct.ReadDeliveryPatternKey;
import curam.core.facade.struct.ReadEvidenceApprovalCheckDetails;
import curam.core.facade.struct.ReadEvidenceApprovalCheckKey;
import curam.core.facade.struct.ReadEvidenceGroupPageDetails;
import curam.core.facade.struct.ReadEvidenceGroupPageKey;
import curam.core.facade.struct.ReadEvidencePageDetails;
import curam.core.facade.struct.ReadEvidencePageKey;
import curam.core.facade.struct.ReadInvestigationApprovalCheckDetails;
import curam.core.facade.struct.ReadInvestigationApprovalCheckKey;
import curam.core.facade.struct.ReadIssueResolutionApprovalCheckDetails;
import curam.core.facade.struct.ReadIssueResolutionApprovalCheckKey;
import curam.core.facade.struct.ReadLiabilityProductStruct;
import curam.core.facade.struct.ReadLiabilityProductStruct1;
import curam.core.facade.struct.ReadModifyDeductionPriorityDetails;
import curam.core.facade.struct.ReadProductApprovalCheckDetails;
import curam.core.facade.struct.ReadProductApprovalCheckKey;
import curam.core.facade.struct.ReadProductDeliveryPatternDetails;
import curam.core.facade.struct.ReadProductEvidenceFormDetails;
import curam.core.facade.struct.ReadProductEvidenceFormKey;
import curam.core.facade.struct.ReadProductProvisionDetails;
import curam.core.facade.struct.ReadProductTimeConstraint;
import curam.core.facade.struct.ReadProductTimeConstraintRMKey;
import curam.core.facade.struct.ReadProvisionLocationDetails;
import curam.core.facade.struct.ReadProvisionLocationKey;
import curam.core.facade.struct.ReadRuleSetAssignmentDetails;
import curam.core.facade.struct.ReadRuleSetAssignmentDetailsKey;
import curam.core.facade.struct.ReadRuleSetKey;
import curam.core.facade.struct.ReadRulesObjectiveKey;
import curam.core.facade.struct.ReadRulesObjectiveTagDetails;
import curam.core.facade.struct.ReadSiteMapDetails;
import curam.core.facade.struct.ReadSiteMapKey;
import curam.core.facade.struct.ResolutionConfigurationDtls;
import curam.core.facade.struct.ResolutionConfigurationDtlsList;
import curam.core.facade.struct.ResolutionContextDescription;
import curam.core.facade.struct.RuleSetContextDescriptionDetails;
import curam.core.facade.struct.RuleSetContextDescriptionKey;
import curam.core.facade.struct.RuleSetDetailsStruct;
import curam.core.facade.struct.RulesForProductDetails;
import curam.core.facade.struct.RulesForProductDetailsAndVersionNo;
import curam.core.facade.struct.RulesObjectiveContextDescriptionDetails;
import curam.core.facade.struct.RulesObjectiveContextDescriptionKey;
import curam.core.facade.struct.RulesObjectiveDetailsStruct;
import curam.core.facade.struct.RulesObjectiveTagDetailsStruct;
import curam.core.facade.struct.SetAsDefaultDeliveryPatternKey;
import curam.core.facade.struct.SiteMapDetails;
import curam.core.facade.struct.TemporalEvidenceApprovalCheckDetails;
import curam.core.facade.struct.TemporalEvidenceApprovalCheckKey;
import curam.core.facade.struct.UnassociatedDeductionDetailsList;
import curam.core.facade.struct.VersionNo;
import curam.core.facade.struct.ViewTemporalEvidenceApprovalCheck;
import curam.core.fact.AdminProductDeliveryPatternInfoFactory;
import curam.core.fact.AdminProductFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.MaintainInstructionLineItemFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.ProductFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.ProductIntf;
import curam.core.intf.AdminProductDeliveryPatternInfo;
import curam.core.intf.ConcernRole;
import curam.core.intf.MaintainInstructionLineItem;
import curam.core.intf.ProductDelivery;
import curam.core.intf.ProductDeliveryPatternInfo;
import curam.core.sl.entity.struct.CaseTypeID;
import curam.core.sl.entity.struct.InvestigationConfigKey;
import curam.core.sl.entity.struct.InvestigationIDTypeDtls;
import curam.core.sl.entity.struct.InvestigationIDTypeDtlsList;
import curam.core.sl.entity.struct.InvestigationResolutionLinkDtls;
import curam.core.sl.entity.struct.InvestigationResolutionLinkKey;
import curam.core.sl.entity.struct.IssueConfigurationKey;
import curam.core.sl.entity.struct.IssueTimeConstraintDtls;
import curam.core.sl.entity.struct.IssueTimeConstraintKey;
import curam.core.sl.entity.struct.IssueTypeDtls;
import curam.core.sl.entity.struct.MilestoneConfigurationKey;
import curam.core.sl.entity.struct.MilestoneLinkDtls;
import curam.core.sl.entity.struct.MilestoneLinkKey;
import curam.core.sl.entity.struct.PDAssessmentConfigurationKey;
import curam.core.sl.entity.struct.ResolutionConfigurationKey;
import curam.core.sl.fact.DeductionProductLinkFactory;
import curam.core.sl.fact.InvestigationConfigurationFactory;
import curam.core.sl.fact.IssueTimeConstraintFactory;
import curam.core.sl.fact.MilestoneConfigurationFactory;
import curam.core.sl.fact.MilestoneLinkFactory;
import curam.core.sl.fact.ProductAssessmentConfigurationFactory;
import curam.core.sl.impl.ComponentHookManager;
import curam.core.sl.infrastructure.entity.struct.EvidenceType;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeAndRecStatusKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.ProdIDRecStatusAndApprovTypeKey;
import curam.core.sl.infrastructure.entity.struct.ProductIDAndRecordStatusKey;
import curam.core.sl.infrastructure.entity.struct.ProductIDEvidenceTypeAndRecStatusKey;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.fact.EvidenceMetadataFactory;
import curam.core.sl.infrastructure.fact.ProductEvidenceLinkFactory;
import curam.core.sl.infrastructure.fact.TemporalEvidenceApprovalCheckFactory;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.sl.infrastructure.intf.EvidenceController;
import curam.core.sl.infrastructure.product.creole.fact.CREOLEProductFactory;
import curam.core.sl.infrastructure.product.creole.struct.CREOLEProductKey;
import curam.core.sl.infrastructure.struct.CancelTemporalEvidenceApprovalCheck;
import curam.core.sl.infrastructure.struct.EvidenceTypeList;
import curam.core.sl.infrastructure.struct.EvidenceTypeTabList;
import curam.core.sl.infrastructure.struct.ProductEvidenceLinkAndEvidenceTypeKey;
import curam.core.sl.intf.DeductionProductLink;
import curam.core.sl.intf.IssueTimeConstraint;
import curam.core.sl.intf.MilestoneConfiguration;
import curam.core.sl.intf.MilestoneLink;
import curam.core.sl.intf.ProductAssessmentConfiguration;
import curam.core.sl.struct.AddMilestoneKey;
import curam.core.sl.struct.CancelEvidenceScreenDetails;
import curam.core.sl.struct.CaseType;
import curam.core.sl.struct.CaseTypeIDAndType;
import curam.core.sl.struct.CreateEvidenceScreenDetails;
import curam.core.sl.struct.CreateProductTimeConstraintDetails;
import curam.core.sl.struct.DeductionProductLinkDetails;
import curam.core.sl.struct.InvestigationResLinkIDResolutionDtlsList;
import curam.core.sl.struct.ListEvidenceScreenDetails;
import curam.core.sl.struct.ListEvidenceScreenKey;
import curam.core.sl.struct.MilestoneConfigurationLinkDetailsList;
import curam.core.sl.struct.MilestoneConfigurationLinkDtlsList;
import curam.core.sl.struct.MilestoneConfigurationSummaryDtlsList;
import curam.core.sl.struct.MilestoneLinkAssociatedInfo;
import curam.core.sl.struct.MilestoneLinkConfigDetails;
import curam.core.sl.struct.ReadEvidenceScreenDetails;
import curam.core.sl.struct.ReadEvidenceScreenKey;
import curam.core.sl.struct.ScreeningConfigurationDetails;
import curam.core.struct.AdminIntegratedCaseKey;
import curam.core.struct.AdminPDPIIDKey;
import curam.core.struct.AdminPDPIProdDelPatIDKey;
import curam.core.struct.AdminPDPIProdDelPatIDProdIDKey;
import curam.core.struct.BankAccountAndPublicOfficeDetails;
import curam.core.struct.BenefitIndicator;
import curam.core.struct.BonusCriteriaKey;
import curam.core.struct.CancelProductDeliveryPatternInfoKey;
import curam.core.struct.CancelProductKeyStruct;
import curam.core.struct.CancelProductProvisionKeyStruct;
import curam.core.struct.CancelProvisionLocationKeyStruct;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.GetProductProviderDetailsResult;
import curam.core.struct.GetProductProviderKey;
import curam.core.struct.GetProductProviderNameDtls;
import curam.core.struct.GetProductProvisionDtls;
import curam.core.struct.GetProductRulesLinkDtls;
import curam.core.struct.GetProvisionLocationDtls;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.IntegratedCaseTypeStruct;
import curam.core.struct.PatternInfoByProductIDKey;
import curam.core.struct.ProductCategoryLists;
import curam.core.struct.ProductCategoryReadmultiDetails1List;
import curam.core.struct.ProductCategoryTabList;
import curam.core.struct.ProductClientTabList;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryPatternInfoDetailsList;
import curam.core.struct.ProductDeliveryPatternInfoDtls;
import curam.core.struct.ProductDeliveryPatternInfoKey;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductIDDetails;
import curam.core.struct.ProductKey;
import curam.core.struct.ProductKeyStruct;
import curam.core.struct.ProductKeyStructRef;
import curam.core.struct.ProductList;
import curam.core.struct.ProductNameStructRef;
import curam.core.struct.ProductProvisionDetailsListRef;
import curam.core.struct.ProductProvisionDetailsStruct;
import curam.core.struct.ProductProvisionDtls;
import curam.core.struct.ProductProvisionKey;
import curam.core.struct.ProductProvisionKeyStructRef;
import curam.core.struct.ProductRulesLinkDetailsListRef;
import curam.core.struct.ProductRulesLinkDetailsListRefAndVersionNo;
import curam.core.struct.ProductRulesLinkDtlsRef;
import curam.core.struct.ProductRulesLinkKeyRef;
import curam.core.struct.ProductSummaryDetailsList;
import curam.core.struct.ProductTypeCodeIn;
import curam.core.struct.ProductTypeList;
import curam.core.struct.ProviderLocationSearchKey;
import curam.core.struct.ProviderLocationSummaryStructRefList;
import curam.core.struct.ProvisionLocationDetailsListRef;
import curam.core.struct.ProvisionLocationDtls;
import curam.core.struct.ProvisionLocationKey;
import curam.core.struct.ProvisionLocationKeyStructRef;
import curam.core.struct.ReadProductResult1;
import curam.core.struct.ReadProductsInCategoryByStatusKey;
import curam.core.struct.RulesObjectiveDetailsList;
import curam.core.struct.RulesObjectiveKeyRef;
import curam.core.struct.RulesObjectiveTagDetailsList;
import curam.core.struct.RulesObjectiveTagFullDetails;
import curam.core.struct.SIDTypeKey;
import curam.core.struct.ViewRulesObjectiveDetailsByInformationIDKey;
import curam.core.struct.ViewRulesObjectiveTagDetailsByObjectiveIDKey;
import curam.evidence.impl.EvidenceTypeFactory;
import curam.message.BPOINVESTIGATIONAPPROVALCHECK;
import curam.message.BPOINVESTIGATIONCONFIGURATION;
import curam.message.BPOISSUERESOLUTIONAPPROVALCHECK;
import curam.message.BPOPRODUCT;
import curam.message.BPORESOLUTIONCONFIGURATION;
import curam.message.FACADERESOURCE;
import curam.piwrapper.caseconfiguration.impl.CaseConfigurationDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.FrequencyPattern;
import curam.util.type.NotFoundIndicator;
import curam.util.type.StringList;
import curam.workspaceservices.facade.struct.LocalizableTextDetails;
import curam.workspaceservices.facade.struct.TextTranslationDetails;
import curam.workspaceservices.facade.struct.ViewLocalizableTextDetails;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.impl.TextTranslation;
import curam.workspaceservices.localization.impl.TextTranslationDAO;


/**
 * Presentation layer for products.
 */

public abstract class Product extends curam.core.facade.base.Product {

  // BEGIN, CR00112688, POH
  @Inject
  protected CaseConfigurationDAO caseConfigurationDAO;

  @Inject
  protected CaseCollaborationAdminStrategy caseCollaborationAdminStrategy;

  // BEGIN, CR00233651, GP
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;
  @Inject
  protected TextTranslationDAO textTranslationDAO;
  // END, CR00233651
  
  // BEGIN, CR00312643, SG
  @Inject
  private Map<String, ProductIntf> productIntfMap;
  // END, CR00312643

  /**
   * Constructor.
   */
  public Product() {
    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00112688

  // BEGIN, CR00221293, SS

  /**
   * Absence Reason DAO
   */
  @Inject
  protected AbsenceReasonConfigurationDAO absenceReasonConfigurationDAO;

  // END CR00221293

  /**
   * Operation to read the Product Context Description.
   *
   * @param key
   * The Product Context Description Key.
   *
   * @return The context description of the product.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected ProductContextDescriptionDetails getProductContextDescription(
    final ProductContextDescriptionKey key) throws AppException,
      InformationalException {

    // Product manipulation variables
    curam.core.intf.Product productObj = curam.core.fact.ProductFactory.newInstance();
    ProductKey productKey = new ProductKey();
    ProductNameStructRef productNameStructRef;

    // Product Context Description object
    ProductContextDescriptionDetails productContextDescriptionDetails = new ProductContextDescriptionDetails();

    // Set key to read product
    productKey.productID = key.productID;

    // Read product name code
    productNameStructRef = productObj.readProductName(productKey);

    // Create a localizable string based on the message entry
    LocalisableString contextDescription = new LocalisableString(
      BPOPRODUCT.INF_PRODUCT_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(PRODUCTNAME.TABLENAME,
      productNameStructRef.name));

    // Populate the context description field with the localizable text
    productContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    return productContextDescriptionDetails;
  }

  /**
   * Assigns a rule set to a product.
   *
   * @param details
   * The rule set details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void assignRuleSetToProduct(final AssignRuleSetToProductDetails details)
    throws AppException, InformationalException {

    // AdminProductRulesLink manipulation variables
    curam.core.intf.AdminProductRulesLink adminProductRulesLinkObj = curam.core.fact.AdminProductRulesLinkFactory.newInstance();
    ProductRulesLinkDtlsRef productRulesLinkDtlsRef = new ProductRulesLinkDtlsRef();

    // Assign the rule set details
    productRulesLinkDtlsRef.assign(details);

    // Call AdminProductRulesLink BPO to assign the rule set details
    // to the product
    adminProductRulesLinkObj.assignRulesToProduct(productRulesLinkDtlsRef);
  }

  /**
   * Cancels an ad hoc bonus criteria record.
   *
   * @param key
   * Identifies the ad hoc bonus criteria record to be canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelAdhocBonusCriteria(CancelAdhocBonusKey key)
    throws AppException, InformationalException {

    // MaintainAd hocBonusCriteria business object
    curam.core.intf.MaintainAdhocBonusCriteria maintainAdhocBonusCriteriaObj = curam.core.fact.MaintainAdhocBonusCriteriaFactory.newInstance();

    // BonusCriteriaKey object
    BonusCriteriaKey bonusCriteriaKey = new BonusCriteriaKey();

    // Set bonusCriteriaKey to cancel record
    bonusCriteriaKey.adhocBonusCriteriaID = key.bonusCriteriaKey.adhocBonusCriteriaID;

    // Call MaintainAdhocBonusCriteria BPO to cancel the ad hoc bonus
    // criteria record
    maintainAdhocBonusCriteriaObj.cancelAdhocBonus(bonusCriteriaKey);
  }

  /**
   * Presentation layer operation to cancel an Evidence Approval Check.
   *
   * @param key
   * The id of the Evidence Approval Check to be canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelEvidenceApprovalCheck(
    final CancelEvidenceApprovalCheckKey key) throws AppException,
      InformationalException {

    // EvidenceApprovalCheck business object
    curam.core.sl.intf.EvidenceApprovalCheck evidenceApprovalCheckObj = curam.core.sl.fact.EvidenceApprovalCheckFactory.newInstance();

    // Call EvidenceApprovalCheck BPO to perform the create operation
    evidenceApprovalCheckObj.cancel(key.cancelEvidenceApprovalCheckDetails);

  }

  /**
   * Presentation layer operation to cancel a Product.
   *
   * @param key
   * The details needed in order to cancel Product.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelProduct(CancelProductKey key) throws AppException,
      InformationalException {

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // Key Passed into method.
    CancelProductKeyStruct cancelProductKeyStruct = new CancelProductKeyStruct();

    // Assign ProductID
    cancelProductKeyStruct.productID = key.productID;

    // Assign VersionNo
    cancelProductKeyStruct.versionNo = key.versionNo;

    // Call Method to cancel Product.
    adminProductObj.cancelProduct(cancelProductKeyStruct);

  }

  /**
   * This method will change the recordStatus of Case Approval Check from Active
   * to Canceled.
   *
   * @param key
   * The key of the Case Approval Check to be canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelProductApprovalCheck(CancelProductApprovalCheckKey key)
    throws AppException, InformationalException {

    // CaseApprovalCheck business object
    curam.core.sl.intf.CaseApprovalCheck CaseApprovalCheckObj = curam.core.sl.fact.CaseApprovalCheckFactory.newInstance();

    // Cancel the case approval check
    CaseApprovalCheckObj.cancel(key.cancelCaseApprovalCheckDetails);
  }

  /**
   * This process will cancel an evidence form for a product.
   *
   * @param key
   * The unique identifier for the product evidence form.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelProductEvidenceFormLink(
    final CancelProductEvidenceFormLinkKey key) throws AppException,
      InformationalException {

    // AdminProductEvidenceFormLink business object
    curam.core.intf.AdminProductEvidenceFormLink adminProductEvidenceFormLinkObj = curam.core.fact.AdminProductEvidenceFormLinkFactory.newInstance();

    // Call the AdminProductEvidenceFormLink BPO to cancel the evidence form
    adminProductEvidenceFormLinkObj.cancelProductEvidenceFormLink(
      key.productEvidenceFormLinkByIDKey);
  }

  /**
   * This process will cancel a product provision for a product.
   *
   * @param key
   * The unique identifier for the product provision.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelProductProvision(CancelProductProvisionKey key)
    throws AppException, InformationalException {

    // AdminProductProvision manipulation variables
    curam.core.intf.AdminProductProvision adminProductProvisionObj = curam.core.fact.AdminProductProvisionFactory.newInstance();
    CancelProductProvisionKeyStruct cancelProductProvisionKeyStruct = new CancelProductProvisionKeyStruct();

    // Set key to cancel the product provision
    cancelProductProvisionKeyStruct.productProvisionID = key.productProvisionID;
    cancelProductProvisionKeyStruct.versionNo = key.versionNo;

    // Call AdminProductProvision to cancel the Product Provision
    adminProductProvisionObj.cancelProductProvision(
      cancelProductProvisionKeyStruct);
  }

  /**
   * Presentation layer operation to create an Evidence Approval Check.
   *
   * @param details
   * The details of the Evidence Approval being created.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createEvidenceApprovalCheck(
    final EvidenceApprovalCheckDtls details) throws AppException,
      InformationalException {

    // EvidenceApprovalCheck business object
    curam.core.sl.intf.EvidenceApprovalCheck evidenceApprovalCheckObj = curam.core.sl.fact.EvidenceApprovalCheckFactory.newInstance();

    // Call EvidenceApprovalCheck BPO to perform the create operation
    evidenceApprovalCheckObj.create(details.evidenceApprovalCheckDetails);
  }

  /**
   * Adds case approval check information for a product.
   *
   * @param details
   * Case approval check details for the product.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createProductApprovalCheck(ProductApprovalCheckDetails details)
    throws AppException, InformationalException {

    // CaseApprovalCheck manipulation variables
    curam.core.sl.intf.CaseApprovalCheck caseApprovalCheckObj = curam.core.sl.fact.CaseApprovalCheckFactory.newInstance();

    // Create approval
    caseApprovalCheckObj.create(details.caseApprovalCheckDetails);
  }

  /**
   * This process will create a product evidence form.
   *
   * @param details
   * Details of the new product evidence form.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createProductEvidenceFormLink(
    CreateProductEvidenceFormLinkDetails details) throws AppException,
      InformationalException {

    // AdminProductEvidenceFormLink business object
    curam.core.intf.AdminProductEvidenceFormLink adminProductEvidenceFormLinkObj = curam.core.fact.AdminProductEvidenceFormLinkFactory.newInstance();

    // Call AdminProductEvidenceFormLink BPO to create a new product evidence
    // form
    adminProductEvidenceFormLinkObj.createProductEvidenceFormLink(
      details.productEvidenceFormLinkDetails);
  }

  public ListActiveEvidenceFormsDetails listActiveEvidenceForms()
    throws AppException, InformationalException {
    return null;
  }

  /**
   * Returns a list of ad hoc Bonus Criteria records.
   *
   * @param key
   * Identifies the ad hoc bonus criteria to be read.
   *
   * @return Details of the ad hoc bonus criteria record.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListAdhocBonusCriteriaDetails listAdhocBonusCriteria(
    final ListAdhocBonusCriteriaKey key) throws AppException,
      InformationalException {

    // Create return object
    ListAdhocBonusCriteriaDetails listAdhocBonusCriteriaDetails = new ListAdhocBonusCriteriaDetails();

    // MaintainAd hocBonusCriteria business object.
    curam.core.intf.MaintainAdhocBonusCriteria maintainAdhocBonusCriteriaObj = curam.core.fact.MaintainAdhocBonusCriteriaFactory.newInstance();

    // Product manipulation variables.
    curam.core.intf.Product productObj = curam.core.fact.ProductFactory.newInstance();
    ProductDtls productDtls = new ProductDtls();
    ProductKey productKey = new ProductKey();

    // Create benefitIndicator object
    BenefitIndicator benefitIndicator = new BenefitIndicator();

    // Set key to read product
    productKey.productID = key.readByProductIDKey.productID;

    // Read product details
    productDtls = productObj.read(productKey);

    // Set benefitIndicator based on productDtls
    benefitIndicator.benefitInd = productDtls.benefitInd;

    // Read all ad hocBonusCriteria records
    listAdhocBonusCriteriaDetails.readAllAdhocBonusCriteriaResult = maintainAdhocBonusCriteriaObj.readAllAdhocBonusCriteria(
      key.readByProductIDKey, benefitIndicator);

    // Create productContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Set key to read product context description
    productContextDescriptionKey.productID = key.readByProductIDKey.productID;

    // Read the product context description
    listAdhocBonusCriteriaDetails.productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    return listAdhocBonusCriteriaDetails;
  }

  // BEGIN, CR00201637, KH
  /**
   * Returns a list of all benefit products.
   *
   * @return List of all benefit products.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link curam.core.facade.impl.Product#listBenefitProducts()}.
   * <p>
   * With the introduction of Correction products it is no longer
   * sufficient to rely on the <code>Product.benefitInd</code> alone
   * to identify Benefit products, the
   * <code>Product.adminCategory</code> must be used. See release
   * note CR00201637.
   */
  @Deprecated
  public ListProductDetailsStruct listAllBenefitProducts() throws AppException,
      InformationalException {

    // Create return object
    ListProductDetailsStruct listProductDetailsStruct = new ListProductDetailsStruct();

    // ProductDetailsStruct object
    ProductDetailsStruct productDetailsStruct;

    // Call AdminProduct BPO to return products
    ProductList productList = AdminProductFactory.newInstance().listAllProducts();

    // Iterate through productList and filter out liability products
    // i.e. products where benefitInd is set to False
    for (int i = 0; i < productList.dtls.size(); i++) {

      if (productList.dtls.item(i).benefitInd) {

        productDetailsStruct = new ProductDetailsStruct();
        productDetailsStruct.assign(productList.dtls.item(i));

        listProductDetailsStruct.productDetailsStruct.addRef(
          productDetailsStruct);
      }
    }

    return listProductDetailsStruct;
  }

  /**
   * Returns a list of all liability products.
   *
   * @return List of all liability products.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link curam.core.facade.impl.Product#listLiabilityProducts()}.
   * <p>
   * With the introduction of Correction products it is no longer
   * sufficient to rely on the <code>Product.benefitInd</code> alone
   * to identify Liability products, the
   * <code>Product.adminCategory</code> must be used. See release
   * note CR00201637.
   */
  @Deprecated
  public ListProductDetailsStruct listAllLiabilityProducts()
    throws AppException, InformationalException {

    // Create return object
    ListProductDetailsStruct listProductDetailsStruct = new ListProductDetailsStruct();

    // ProductDetailsStruct object
    ProductDetailsStruct productDetailsStruct;

    // Call AdminProduct BPO to return products
    ProductList productList = AdminProductFactory.newInstance().listAllProducts();

    // Iterate through productList and filter out benefit products
    // i.e. products where benefitInd is set to True
    for (int i = 0; i < productList.dtls.size(); i++) {

      if (!productList.dtls.item(i).benefitInd) {

        productDetailsStruct = new ProductDetailsStruct();
        productDetailsStruct.assign(productList.dtls.item(i));

        listProductDetailsStruct.productDetailsStruct.addRef(
          productDetailsStruct);
      }
    }

    return listProductDetailsStruct;
  }

  /**
   * This method replaces the deprecated method
   * {@link curam.core.facade.impl.Product#listAllBenefitProducts()}
   * <p>
   * Returns all products having an admin category of <code>BENEFIT</code>.
   *
   * @return List of all benefit products.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProductSummaryDetailsList listBenefitProducts() throws AppException,
      InformationalException {

    return AdminProductFactory.newInstance().listBenefitProducts();
  }

  /**
   * Returns all products having an admin category of <code>CORRECTION</code>.
   *
   * @return List of all correction products.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProductSummaryDetailsList listCorrectionProducts()
    throws AppException, InformationalException {

    return AdminProductFactory.newInstance().listCorrectionProducts();
  }

  /**
   * This method replaces the deprecated method
   * {@link curam.core.facade.impl.Product#listAllLiabilityProducts()}
   * <p>
   * Returns all products having an admin category of <code>LIABILITY</code>.
   *
   * @return List of all liability products.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProductSummaryDetailsList listLiabilityProducts() throws AppException,
      InformationalException {

    return AdminProductFactory.newInstance().listLiabilityProducts();
  }

  // END, CR00201637

  /**
   * Retrieves the case approval check information for the specified product.
   *
   * @param key
   * List product case approval key.
   *
   * @return a list of products case approval details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListApprovalChecksForProductDetails listApprovalChecksForProduct(
    ListApprovalChecksForProductKey key) throws AppException,
      InformationalException {

    // Create return object
    ListApprovalChecksForProductDetails listApprovalChecksForProductDetails = new ListApprovalChecksForProductDetails();

    // CaseApprovalCheck manipulation variables
    curam.core.sl.intf.CaseApprovalCheck caseApprovalCheckObj = curam.core.sl.fact.CaseApprovalCheckFactory.newInstance();

    // ProductContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Call CaseApprovalCheck BPO to get list of approval checks for
    // product
    listApprovalChecksForProductDetails.caseApprovalCheckDetailsList = caseApprovalCheckObj.listApprovalChecksByProduct(
      key.searchAllProductCheckKey);

    // Set key to read product context description
    productContextDescriptionKey.productID = key.searchAllProductCheckKey.searchAllProductCheckKey.productID;

    // Read product context description
    listApprovalChecksForProductDetails.productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    return listApprovalChecksForProductDetails;
  }

  /**
   * Presentation layer operation to list Evidence Approval Checks.
   *
   * @param key
   * The ID of the Evidence Approval to be found.
   *
   * @return A list of the Evidence Approvals found for the given key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListEvidenceApprovalCheckDetails listEvidenceApprovalCheck(
    ListEvidenceApprovalCheckKey key) throws AppException,
      InformationalException {

    // Create return object
    ListEvidenceApprovalCheckDetails listEvidenceApprovalCheckDetails = new ListEvidenceApprovalCheckDetails();

    // EvidenceApprovalCheck business object
    curam.core.sl.intf.EvidenceApprovalCheck evidenceApprovalCheckObj = curam.core.sl.fact.EvidenceApprovalCheckFactory.newInstance();

    // Use the EvidenceApprovalCheck to perform the modify operation
    listEvidenceApprovalCheckDetails.evidenceApprovalCheckDetailsList = evidenceApprovalCheckObj.listEvidenceApprovalChecksByProduct(
      key.searchByProductKey);

    // ProductContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    productContextDescriptionKey.productID = key.searchByProductKey.searchByProductKey.productID;

    // Retrieve the Workgroup Context Description using the context key.
    listEvidenceApprovalCheckDetails.productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    return listEvidenceApprovalCheckDetails;

  }

  /**
   * This process will retrieve a list of evidence forms for a product.
   *
   * @param key
   * The unique identifier for the product.
   *
   * @return A list of evidence forms for product details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListEvidenceFormsForProductDetails listEvidenceFormsForProduct(
    ListEvidenceFormsForProductKey key) throws AppException,
      InformationalException {

    // Create a return object
    ListEvidenceFormsForProductDetails listEvidenceFormsForProductDetails = new ListEvidenceFormsForProductDetails();

    // AdminProductEvidenceFormLink business object
    curam.core.intf.AdminProductEvidenceFormLink adminProductEvidenceFormLinkObj = curam.core.fact.AdminProductEvidenceFormLinkFactory.newInstance();

    // ProductContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Read the list of evidence forms into the return object
    listEvidenceFormsForProductDetails.productEvidenceFormLinkDetailsList = adminProductEvidenceFormLinkObj.getProductEvidenceFormLinkByProductID(
      key.productEvidenceFormLinkByProductIDKey);

    // Set key to read the product context description
    productContextDescriptionKey.productID = key.productEvidenceFormLinkByProductIDKey.productID;

    // Read the context description into the return object
    listEvidenceFormsForProductDetails.productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    return listEvidenceFormsForProductDetails;
  }

  /**
   * Returns a list of provisions for a product.
   *
   * @param key
   * Contains the product identifier.
   *
   * @return The product provision details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProductProvisionsForProduct listProductProvisionsForProduct(
    ListProductProvisionsForProductKey key) throws AppException,
      InformationalException {

    // Create return object
    ListProductProvisionsForProduct listProductProvisionsForProduct = new ListProductProvisionsForProduct();

    // AdminProductProvision manipulation variables
    curam.core.intf.AdminProductProvision adminProductProvisionObj = curam.core.fact.AdminProductProvisionFactory.newInstance();
    ProductKeyStructRef productKeyStructRef = new ProductKeyStructRef();

    // BPO Method Return Details
    ProductProvisionDetailsListRef productProvisionDetailsListRef;

    // ProductProvisionsForProductStruct object
    ProductProvisionsForProductStruct productProvisionsForProductStruct;

    // Context Description Key
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Set key to retrieve provisions for the product
    productKeyStructRef.productID = key.productID;

    // Call AdminProductProvision BPO to retrieve list of product provisions
    productProvisionDetailsListRef = adminProductProvisionObj.listProductProvisionsForProduct(
      productKeyStructRef);

    // Map the returned details for each record
    for (int i = 0; i < productProvisionDetailsListRef.dtls.size(); i++) {

      productProvisionsForProductStruct = new ProductProvisionsForProductStruct();

      productProvisionsForProductStruct.assign(
        productProvisionDetailsListRef.dtls.item(i));

      listProductProvisionsForProduct.productProvisionsForProductStruct.addRef(
        productProvisionsForProductStruct);
    }

    // Set key to retrieve context description
    productContextDescriptionKey.productID = key.productID;

    // Get context Description.
    listProductProvisionsForProduct.productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    return listProductProvisionsForProduct;
  }

  /**
   * Returns a list of Product Provision Locations.
   *
   * @param key
   * Product Provision Location identifier.
   *
   * @return List of Product Provision Locations.
   *
   * description key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProvisionLocationDetails listProvisionLocation(
    ListProvisionLocationKey key) throws AppException, InformationalException {

    // Create return object
    ListProvisionLocationDetails listProvisionLocationDetails = new ListProvisionLocationDetails();

    // AdminProvisionLocation business object
    curam.core.intf.AdminProvisionLocation adminProvisionLocationObj = curam.core.fact.AdminProvisionLocationFactory.newInstance();

    // ProductProvisionKeyStructRef object
    ProductProvisionKeyStructRef productProvisionKeyStructRef = new ProductProvisionKeyStructRef();

    // ProvisionLocationDetailsListRef object
    ProvisionLocationDetailsListRef provisionLocationDetailsListRef;

    // ProvisionLocationDetailsStruct object
    ProvisionLocationDetailsStruct provisionLocationDetailsStruct;

    // ProvisionLocationContextDescriptionKey object
    ProvisionLocationContextDescriptionKey provisionLocationContextDescriptionKey = new ProvisionLocationContextDescriptionKey();

    // ProvisionLocationContextDescriptionDetails object
    ProvisionLocationContextDescriptionDetails provisionLocationContextDescriptionDetails;

    // Set key to read provision location details
    productProvisionKeyStructRef.productProvisionID = key.productProvisionID;

    // Call AdminProvisionLocation BPO to return list of provision locations
    provisionLocationDetailsListRef = adminProvisionLocationObj.listProvisionLocationForProvision(
      productProvisionKeyStructRef);

    // if provision location list is not blank
    if (provisionLocationDetailsListRef.dtls.size() != 0) {

      // Map the returned details for each record
      for (int i = 0; i < provisionLocationDetailsListRef.dtls.size(); i++) {

        provisionLocationDetailsStruct = new ProvisionLocationDetailsStruct();

        provisionLocationDetailsStruct.assign(
          provisionLocationDetailsListRef.dtls.item(i));

        listProvisionLocationDetails.provisionLocationDetailsStruct.addRef(
          provisionLocationDetailsStruct);
      }

    }

    // Read provision location context description
    provisionLocationContextDescriptionKey.provisionID = key.productProvisionID;

    provisionLocationContextDescriptionDetails = getProvisionLocationContextDescription(
      provisionLocationContextDescriptionKey);

    // Set context description in the return object
    listProvisionLocationDetails.provisionLocationContextDescriptionDetails.description = provisionLocationContextDescriptionDetails.description;

    return listProvisionLocationDetails;
  }

  /**
   * Reads a list of rules for a product.
   *
   * @param key
   * The product ID.
   *
   * @return The rules objective tag details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListRulesForProductDetails listRulesForProduct(
    ListRulesForProductKey key) throws AppException, InformationalException {

    // Create the return object
    ListRulesForProductDetails listRulesForProductDetails = new ListRulesForProductDetails();

    // AdminProductRulesLink manipulation variables
    curam.core.intf.AdminProductRulesLink adminProductRulesLinkObj = curam.core.fact.AdminProductRulesLinkFactory.newInstance();
    ProductKeyStructRef productKeyStructRef = new ProductKeyStructRef();
    ProductRulesLinkDetailsListRef productRulesLinkDetailsListRef = new ProductRulesLinkDetailsListRef();

    // Product Context Description objects
    ProductContextDescriptionDetails productContextDescriptionDetails = new ProductContextDescriptionDetails();
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // RulesForProductDetails object
    RulesForProductDetails rulesForProductDetails;

    // Set key to read product rules links
    productKeyStructRef.productID = key.productID;

    // Call AdminProductRulesLink BPO to return product rules links
    productRulesLinkDetailsListRef = adminProductRulesLinkObj.listProductRulesLinkForProduct(
      productKeyStructRef);

    // Map the returned details for each record
    for (int i = 0; i < productRulesLinkDetailsListRef.dtls.size(); i++) {

      rulesForProductDetails = new RulesForProductDetails();

      rulesForProductDetails.assign(productRulesLinkDetailsListRef.dtls.item(i));

      listRulesForProductDetails.rulesForProductDetails.addRef(
        rulesForProductDetails);
    }

    // Set key to read the product context description
    productContextDescriptionKey.productID = key.productID;

    // Read the product context description
    productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    // Set context description in the return struct
    listRulesForProductDetails.productContextDescription.description = productContextDescriptionDetails.description;

    return listRulesForProductDetails;
  }

  // BEGIN, CR00220094, JF
  /**
   * Reads a list of rules and versionNo for a product.
   *
   * @param key
   * The product ID.
   *
   * @return The rules objective tag details and versionNo.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListRulesForProductDetailsAndVersionNo listRulesForProductAndVersionNo(
    ListRulesForProductKey key) throws AppException, InformationalException {

    // Create the return object
    ListRulesForProductDetailsAndVersionNo listRulesForProductDetailsAndVersionNo = new ListRulesForProductDetailsAndVersionNo();

    // AdminProductRulesLink manipulation variables
    curam.core.intf.AdminProductRulesLink adminProductRulesLinkObj = curam.core.fact.AdminProductRulesLinkFactory.newInstance();
    ProductKeyStructRef productKeyStructRef = new ProductKeyStructRef();
    ProductRulesLinkDetailsListRefAndVersionNo productRulesLinkDetailsListRefAndVersionNo = new ProductRulesLinkDetailsListRefAndVersionNo();

    // RulesForProductDetails object
    RulesForProductDetailsAndVersionNo rulesForProductDetailsAndVersionNo;

    // Set key to read product rules links
    productKeyStructRef.productID = key.productID;

    // Call AdminProductRulesLink BPO to return product rules links
    productRulesLinkDetailsListRefAndVersionNo = adminProductRulesLinkObj.listProductRulesLinkForProductAndVersionNo(
      productKeyStructRef);

    // Map the returned details for each record
    for (int i = 0; i
      < productRulesLinkDetailsListRefAndVersionNo._productRulesLinkDetailsListRef.size(); i++) {

      rulesForProductDetailsAndVersionNo = new RulesForProductDetailsAndVersionNo();

      rulesForProductDetailsAndVersionNo.assign(
        productRulesLinkDetailsListRefAndVersionNo._productRulesLinkDetailsListRef.item(
          i));

      listRulesForProductDetailsAndVersionNo.dtls.addRef(
        rulesForProductDetailsAndVersionNo);
    }

    return listRulesForProductDetailsAndVersionNo;
  }

  // END, CR00220094, JF

  /**
   * Returns a list of Temporal Evidence Approval Checks that are related to the
   * specified product.
   *
   * @param key
   * Key details to retrieve a list of temporal evidence approval
   * checks for a product.
   * @return List of temporal evidence approval checks for the specified product
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public curam.core.facade.struct.TemporalEvidenceApprovalCheckList listTemporalEvApprovalCheckByProductID(
    ProdIDRecStatusAndApprovTypeKey key) throws AppException,
      InformationalException {

    // Return object
    curam.core.facade.struct.TemporalEvidenceApprovalCheckList temporalEvidenceApprovalCheckList = new curam.core.facade.struct.TemporalEvidenceApprovalCheckList();

    // Call service layer operation to retrieve list by product
    curam.core.sl.infrastructure.struct.TemporalEvidenceApprovalCheckList temporalEvidenceApprovalCheckTempList = new curam.core.sl.infrastructure.struct.TemporalEvidenceApprovalCheckList();

    temporalEvidenceApprovalCheckTempList = TemporalEvidenceApprovalCheckFactory.newInstance().listByProduct(
      key);

    temporalEvidenceApprovalCheckList.assign(
      temporalEvidenceApprovalCheckTempList);

    // Populate count search key
    EvidenceTypeAndRecStatusKey evidenceTypeAndRecStatusKey = new EvidenceTypeAndRecStatusKey();

    evidenceTypeAndRecStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    for (int i = 0; i < temporalEvidenceApprovalCheckList.list.size(); i++) {

      // Read each evidence type

      // BEGIN, CR00191839
      final EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

      evidenceTypeKey.evidenceType = temporalEvidenceApprovalCheckList.list.item(i).evidenceType;

      // check if evidence types appears more than once
      if (EvidenceTypeFactory.newInstance().isSharedEvidence(evidenceTypeKey)) {

        // if it does, type is shared
        temporalEvidenceApprovalCheckList.list.item(i).shared = true;
      } else {
        // otherwise not shared
        temporalEvidenceApprovalCheckList.list.item(i).shared = false;
      }
      // END, CR00191839

    }

    // Retrieve the context description
    ProductKey productKey = new ProductKey();

    productKey.productID = key.productID;

    // BEGIN, CR00163098, JC
    temporalEvidenceApprovalCheckList.contextDescription = CodeTable.getOneItem(
      PRODUCTNAME.TABLENAME,
      ProductFactory.newInstance().readProductName(productKey).name,
      TransactionInfo.getProgramLocale());
    // END, CR00163098, JC

    return temporalEvidenceApprovalCheckList;
  }

  /**
   * Read a list of rules objective details.
   *
   * @param key
   * The rules objective ID.
   *
   * @return The rule objective tag details returned from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListRulesObjectiveDetails listRulesObjective(ListRulesObjectiveKey key)
    throws AppException, InformationalException {

    // Create the return object
    ListRulesObjectiveDetails listRulesObjectiveDetails = new ListRulesObjectiveDetails();

    // RulesObjectiveDetailsStruct object
    RulesObjectiveDetailsStruct rulesObjectiveDetailsStruct;

    // AdminRulesObjective manipulation variables
    curam.core.intf.AdminRulesObjective adminRulesObjectiveObj = curam.core.fact.AdminRulesObjectiveFactory.newInstance();
    ViewRulesObjectiveDetailsByInformationIDKey rulesObjectiveIDKey = new ViewRulesObjectiveDetailsByInformationIDKey();
    RulesObjectiveDetailsList rulesObjectiveDetailsList = new RulesObjectiveDetailsList();

    // Rule Set Context Description objects
    RuleSetContextDescriptionKey ruleSetContextDescriptionKey = new RuleSetContextDescriptionKey();
    RuleSetContextDescriptionDetails ruleSetContextDescriptionDetails = new RuleSetContextDescriptionDetails();

    // Set key to read the rules objective details
    rulesObjectiveIDKey.ruleSetID = key.ruleSetID;

    // Call AdminRulesObjective to read the rules objective details
    rulesObjectiveDetailsList = adminRulesObjectiveObj.viewRulesObjectives(
      rulesObjectiveIDKey);

    // Map the returned details for each record.
    for (int i = 0; i < rulesObjectiveDetailsList.dtls.size(); i++) {

      rulesObjectiveDetailsStruct = new RulesObjectiveDetailsStruct();

      rulesObjectiveDetailsStruct.type = rulesObjectiveDetailsList.dtls.item(i).type;
      rulesObjectiveDetailsStruct.target = rulesObjectiveDetailsList.dtls.item(i).target;
      rulesObjectiveDetailsStruct.rulesObjectiveID = rulesObjectiveDetailsList.dtls.item(i).rulesObjectiveID;
      rulesObjectiveDetailsStruct.description = rulesObjectiveDetailsList.dtls.item(i).description;

      listRulesObjectiveDetails.rulesObjectiveDetailsStruct.addRef(
        rulesObjectiveDetailsStruct);
    }

    // Set key to retrieve the rule set context description
    ruleSetContextDescriptionKey.ruleSetID = key.ruleSetID;

    // Read the rule set context description.
    ruleSetContextDescriptionDetails = getRuleSetContextDescription(
      ruleSetContextDescriptionKey);

    // Set context description in the output struct
    listRulesObjectiveDetails.ruleSetContextDescription.description = ruleSetContextDescriptionDetails.description;

    return listRulesObjectiveDetails;
  }

  /**
   * Read a list of rules objective tag details.
   *
   * @param key
   * The rules objective ID.
   *
   * @return The rule objective tag details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListRulesObjectiveTagDetails listRulesObjectiveTag(
    ListRulesObjectiveTagKey key) throws AppException, InformationalException {

    // Create the return object
    ListRulesObjectiveTagDetails listRulesObjectiveTagDetails = new ListRulesObjectiveTagDetails();

    // RulesObjectiveTagDetailsStruct object
    RulesObjectiveTagDetailsStruct rulesObjectiveTagDetailsStruct;

    // AdminRulesObjective manipulation variables
    curam.core.intf.AdminRulesObjective adminRulesObjectiveObj = curam.core.fact.AdminRulesObjectiveFactory.newInstance();
    ViewRulesObjectiveTagDetailsByObjectiveIDKey rulesObjectiveIDKey = new ViewRulesObjectiveTagDetailsByObjectiveIDKey();
    RulesObjectiveTagDetailsList rulesObjectiveTagDetailsList = new RulesObjectiveTagDetailsList();

    // Rules Objective Context Description objects
    RulesObjectiveContextDescriptionKey rulesObjectiveContextKey = new RulesObjectiveContextDescriptionKey();
    RulesObjectiveContextDescriptionDetails rulesObjectiveContextDescriptionDetails = new RulesObjectiveContextDescriptionDetails();

    // Set key to read the list of objective tags
    rulesObjectiveIDKey.rulesObjectiveID = key.rulesObjectiveID;

    // Call AdminRulesObjective BPO to read the list of objective tags
    rulesObjectiveTagDetailsList = adminRulesObjectiveObj.viewRulesObjectiveTags(
      rulesObjectiveIDKey);

    // Map the returned details for each record
    for (int i = 0; i < rulesObjectiveTagDetailsList.dtls.size(); i++) {

      rulesObjectiveTagDetailsStruct = new RulesObjectiveTagDetailsStruct();

      rulesObjectiveTagDetailsStruct.rulesObjectiveTagID = rulesObjectiveTagDetailsList.dtls.item(i).rulesObjectiveTagID;
      rulesObjectiveTagDetailsStruct.value = rulesObjectiveTagDetailsList.dtls.item(i).value;

      listRulesObjectiveTagDetails.rulesObjectiveTagDetailsStruct.addRef(
        rulesObjectiveTagDetailsStruct);
    }

    // Set key to read the rules objective context description
    rulesObjectiveContextKey.rulesObjectiveID = key.rulesObjectiveID;

    // Read the rules objective context description
    rulesObjectiveContextDescriptionDetails = getRulesObjectiveContextDescription(
      rulesObjectiveContextKey);

    // Set context description in the return struct
    listRulesObjectiveTagDetails.rulesObjectiveContextDescription.description = rulesObjectiveContextDescriptionDetails.description;

    return listRulesObjectiveTagDetails;
  }

  /**
   * Modifies details of an ad hoc bonus criteria record.
   *
   * @param details
   * Details of the ad hoc bonus criteria record to be modified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyAdhocBonusCriteria(ModifyAdhocBonusCriteriaDetails details)
    throws AppException, InformationalException {

    // MaintainAd hocBonusCriteria business object
    curam.core.intf.MaintainAdhocBonusCriteria maintainAdhocBonusCriteriaObj = curam.core.fact.MaintainAdhocBonusCriteriaFactory.newInstance();

    // Call MaintainAdhocBonusCriteria BPO to modify ad hoc bonus criteria
    // details
    maintainAdhocBonusCriteriaObj.modifyAdhocBonusCriteriaDetails(
      details.bonusCriteriaDetails);
  }

  /**
   * Presentation layer operation to modify an Evidence Approval Check.
   *
   * @param details
   * The data with which to update an Evidence Approval.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyEvidenceApprovalCheck(EvidenceApprovalCheckDtls details)
    throws AppException, InformationalException {

    // EvidenceApprovalCheck business object
    curam.core.sl.intf.EvidenceApprovalCheck evidenceApprovalCheckObj = curam.core.sl.fact.EvidenceApprovalCheckFactory.newInstance();

    details.evidenceApprovalCheckDetails.evidenceApprovalCheckDtls.typeCode = EVIDENCE_APPROVAL_CHECK.PRODUCT;

    // Call EvidenceApprovalCheck BPO to perform the modify operation
    evidenceApprovalCheckObj.modify(details.evidenceApprovalCheckDetails);

  }

  /**
   * Modifies case approval check information for a product.
   *
   * @param details
   * The modified case approval check details for the product.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyProductApprovalCheck(ProductApprovalCheckDetails details)
    throws AppException, InformationalException {

    // CaseApprovalCheck manipulation variables
    curam.core.sl.intf.CaseApprovalCheck caseApprovalCheckObj = curam.core.sl.fact.CaseApprovalCheckFactory.newInstance();

    // Modify the case approval check
    caseApprovalCheckObj.modify(details.caseApprovalCheckDetails);
  }

  /**
   * This process will modify a product evidence form.
   *
   * @param details
   * Details of the product evidence to be updated.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyProductEvidenceFormLink(
    ModifyProductEvidenceFormLinkDetails details) throws AppException,
      InformationalException {

    // AdminProductEvidenceFormLink business object
    curam.core.intf.AdminProductEvidenceFormLink adminProductEvidenceFormLinkObj = curam.core.fact.AdminProductEvidenceFormLinkFactory.newInstance();

    // Call AdminProductEvidenceFormLink BPO to modify the details of the
    // product evidence form.
    adminProductEvidenceFormLinkObj.modifyProductEvidenceFormLink(
      details.productEvidenceFormLinkDetails);
  }

  /**
   * Modifies a product provision for a product.
   *
   * @param key
   * Contains the product provision identifier.
   *
   * @param details
   * The details of the product provision.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyProductProvision(
    curam.core.facade.struct.ProductProvisionKey key,
    ModifyProductProvisionDetails details) throws AppException,
      InformationalException {

    // AdminProductProvision manipulation variables
    curam.core.intf.AdminProductProvision adminProductProvisionObj = curam.core.fact.AdminProductProvisionFactory.newInstance();
    ProductProvisionKeyStructRef productProvisionKeyStructRef = new ProductProvisionKeyStructRef();

    // ProductProvision manipulation variables
    curam.core.intf.ProductProvision productProvisionObj = curam.core.fact.ProductProvisionFactory.newInstance();
    curam.core.struct.ProductProvisionKey productProvisionKey = new curam.core.struct.ProductProvisionKey();
    ProductProvisionDtls productProvisionDtls;

    // ProductProvisionDetailsStruct object
    ProductProvisionDetailsStruct productProvisionDetailsStruct = new ProductProvisionDetailsStruct();

    // Set productProvisionKeyStructRef for modify
    productProvisionKeyStructRef.productProvisionID = key.productProvisionID;

    // Set key to read productProvision
    productProvisionKey.productProvisionID = key.productProvisionID;

    // Read productProvision
    productProvisionDtls = productProvisionObj.read(productProvisionKey);

    // Assign details to struct for update
    productProvisionDetailsStruct.assign(details);

    productProvisionDetailsStruct.productProvisionID = key.productProvisionID;

    productProvisionDetailsStruct.productID = productProvisionDtls.productID;
    productProvisionDetailsStruct.nextPaymentDate = productProvisionDtls.nextPaymentDate;
    productProvisionDetailsStruct.statusCode = productProvisionDtls.statusCode;

    // Call AdminProductProvision BPO to modify the product provision details
    adminProductProvisionObj.modifyProductProvision(
      productProvisionKeyStructRef, productProvisionDetailsStruct);
  }

  /**
   * Modifies rule set assignment details.
   *
   * @param details
   * The modified rule set assignment details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyRuleSetAssignmentDetails(
    ModifyRuleSetAssignmentDetails details) throws AppException,
      InformationalException {

    // AdminProductRulesLink manipulation variables
    curam.core.intf.AdminProductRulesLink adminProductRulesLinkObj = curam.core.fact.AdminProductRulesLinkFactory.newInstance();
    GetProductRulesLinkDtls getProductRulesLinkDtls = new GetProductRulesLinkDtls();

    // Assign the rule set details
    getProductRulesLinkDtls.assign(details);

    // Call AdminProductRulesLink BPO to modify the rule set details
    adminProductRulesLinkObj.modifyProductRulesLink(getProductRulesLinkDtls);
  }

  /**
   * Reads an ad hoc bonus criteria record.
   *
   * @param key
   * Identifies the ad hoc bonus criteria to be read.
   *
   * @return Ad hoc bonus criteria details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadAdhocBonusCriteriaDetails readAdhocBonusCriteria(
    ReadAdhocBonusCriteriaKey key) throws AppException,
      InformationalException {

    // Create return object
    ReadAdhocBonusCriteriaDetails readAdhocBonusCriteriaDetails = new ReadAdhocBonusCriteriaDetails();

    // MaintainAd hocBonusCriteria business object
    curam.core.intf.MaintainAdhocBonusCriteria maintainAdhocBonusCriteriaObj = curam.core.fact.MaintainAdhocBonusCriteriaFactory.newInstance();

    // Read the ad hoc bonus criteria details
    readAdhocBonusCriteriaDetails.adhocBonusCriteriaDetails = maintainAdhocBonusCriteriaObj.readAdhocBonusCriteriaDetails(
      key.bonusCriteriaKey);

    // Set key to read product context description
    key.productContextDescriptionKey.productID = readAdhocBonusCriteriaDetails.adhocBonusCriteriaDetails.productID;

    // Read the product context description
    readAdhocBonusCriteriaDetails.productContextDescriptionDetails = getProductContextDescription(
      key.productContextDescriptionKey);

    return readAdhocBonusCriteriaDetails;
  }

  /**
   * @param key
   * The product identifier for reading the product details.
   *
   * @return Details of the benefit product.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #readBenefitProduct1()}.
   * New method reads additional attributes which indicates if cases
   * of this benefit type are displayed in the participants programs
   * list, in My Cases filter and in Case Search filter.
   *
   * Reads product details for the benefit product home page.
   */
  @Deprecated
  public ReadBenefitProductStruct readBenefitProduct(ReadBenefitProductKey key)
    throws AppException, InformationalException {

    // Create return object
    ReadBenefitProductStruct readBenefitProductStruct = new ReadBenefitProductStruct();

    // BEGIN, CR00173421, ZV
    ReadBenefitProductStruct1 readBenefitProductStruct1 = readBenefitProduct1(
      key);

    readBenefitProductStruct.assign(readBenefitProductStruct1);
    // END, CR00173421

    // BEGIN, CR00230245, CW
    // Assign overUnderPaymentAutoProcessInd based on reassessmentActionType
    if (readBenefitProductStruct1.benefitHomePageDetails.reassessmentActionType.equals(
      OVERUNDERPMNTPROCESSING.AUTOMATIC)
        || readBenefitProductStruct1.benefitHomePageDetails.reassessmentActionType.equals(
          OVERUNDERPMNTPROCESSING.AUTOPAYMENTCORRECTIONACTIVATION)) {

      // Create over payment cases
      readBenefitProductStruct.benefitHomePageDetails.overUnderPaymentAutoProcessInd = true;
    } else {

      // Do not create over payment cases for all other reassessmentActionType
      // values
      readBenefitProductStruct.benefitHomePageDetails.overUnderPaymentAutoProcessInd = false;
    }
    // END, CR00230245

    return readBenefitProductStruct;
  }

  /**
   * Presentation layer operation to read the Evidence Approval details.
   *
   * @param key
   * The ID of the Evidence Approval to be read.
   *
   * @return Details of the Evidence Approval read.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadEvidenceApprovalCheckDetails readEvidenceApprovalCheck(
    ReadEvidenceApprovalCheckKey key) throws AppException,
      InformationalException {

    // Create return object
    ReadEvidenceApprovalCheckDetails readEvidenceApprovalCheckDetails = new ReadEvidenceApprovalCheckDetails();

    // EvidenceApprovalCheck business object
    curam.core.sl.intf.EvidenceApprovalCheck evidenceApprovalCheckObj = curam.core.sl.fact.EvidenceApprovalCheckFactory.newInstance();

    // Use the EvidenceApprovalCheck to perform the modify operation
    readEvidenceApprovalCheckDetails.readEvidenceApprovalCheckDetails = evidenceApprovalCheckObj.read(
      key.evidenceApprovalCheckKey);

    // ProductContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Set context description key
    productContextDescriptionKey.productID = readEvidenceApprovalCheckDetails.readEvidenceApprovalCheckDetails.evidenceApprovalCheckDetails.productID;

    // Get context description
    readEvidenceApprovalCheckDetails.productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    return readEvidenceApprovalCheckDetails;

  }

  /**
   * Retrieves the details of the specified product case approval check
   * information.
   *
   * @param key
   * Unique identifier for the approval check.
   *
   * @return Product case approval details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadProductApprovalCheckDetails readProductApprovalCheck(
    ReadProductApprovalCheckKey key) throws AppException,
      InformationalException {

    // Create return object
    ReadProductApprovalCheckDetails readProductApprovalCheckDetails = new ReadProductApprovalCheckDetails();

    // CaseApprovalCheck manipulation variables
    curam.core.sl.intf.CaseApprovalCheck caseApprovalCheckObj = curam.core.sl.fact.CaseApprovalCheckFactory.newInstance();

    // Product Context Description Key object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Call AdminCaseApprovalCheck BPO to read product approval check details
    readProductApprovalCheckDetails.readCaseApprovalCheckDetails = caseApprovalCheckObj.read(
      key.caseApprovalCheckKey);

    // Set key to read product context description
    productContextDescriptionKey.productID = key.productContextDescriptionKey.productID;

    // Read product context description and map to output struct
    readProductApprovalCheckDetails.productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    return readProductApprovalCheckDetails;
  }

  /**
   * This process will read an evidence form for a product.
   *
   * @param key
   * The unique identifier for the product.
   *
   * @return details of read product evidence form.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadProductEvidenceFormDetails readProductEvidenceFormLink(
    ReadProductEvidenceFormKey key) throws AppException,
      InformationalException {

    // Create return object
    ReadProductEvidenceFormDetails readProductEvidenceFormDetails = new ReadProductEvidenceFormDetails();

    // AdminProductEvidenceFormLink business object
    curam.core.intf.AdminProductEvidenceFormLink adminProductEvidenceFormLinkObj = curam.core.fact.AdminProductEvidenceFormLinkFactory.newInstance();

    // Create a ProductContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Read the evidence form details into the return object
    readProductEvidenceFormDetails.productEvidenceFormLinkDetails = adminProductEvidenceFormLinkObj.getProductEvidenceFormLink(
      key.productEvidenceFormLinkByIDKey);

    // Set key to read the product context description
    productContextDescriptionKey.productID = readProductEvidenceFormDetails.productEvidenceFormLinkDetails.productID;

    // Read the product context description into the return object
    readProductEvidenceFormDetails.productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    return readProductEvidenceFormDetails;
  }

  /**
   * Read the product provision details.
   *
   * @param key
   * Contains the product provision identifier.
   *
   * @return The product provision details returned from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadProductProvisionDetails readProductProvision(
    curam.core.facade.struct.ProductProvisionKey key) throws AppException,
      InformationalException {

    // Create return object
    ReadProductProvisionDetails readProductProvisionDetails = new ReadProductProvisionDetails();

    // AdminProductProvision manipulation variables
    curam.core.intf.AdminProductProvision adminProductProvisionObj = curam.core.fact.AdminProductProvisionFactory.newInstance();
    ProductProvisionKeyStructRef productProvisionKeyStructRef = new ProductProvisionKeyStructRef();

    // Create a ProductContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Assign productProvisionID
    productProvisionKeyStructRef.productProvisionID = key.productProvisionID;

    // Get Product Provision Details
    GetProductProvisionDtls getProductProvisionDtls;

    // Call AdminProductProvision BPO to read Product Provision details
    getProductProvisionDtls = adminProductProvisionObj.readProductProvision(
      productProvisionKeyStructRef);

    // Assign details to output struct
    readProductProvisionDetails.productProvisionDetails.assign(
      getProductProvisionDtls);

    // Set key to read the product context description
    productContextDescriptionKey.productID = getProductProvisionDtls.productID;

    // Read the product context description into the return object
    readProductProvisionDetails.productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    return readProductProvisionDetails;
  }

  /**
   * Read Provision Locations details.
   *
   * @param key
   * Provision location key
   *
   * @return Provision Location details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadProvisionLocationDetails readProvisionLocation(
    final ReadProvisionLocationKey key) throws AppException,
      InformationalException {

    // Admin Provision Location business object
    curam.core.intf.AdminProvisionLocation adminProvisionLocationObj = curam.core.fact.AdminProvisionLocationFactory.newInstance();

    // provision location key struct ref object
    ProvisionLocationKeyStructRef provisionLocationKeyStructRef = new ProvisionLocationKeyStructRef();

    // details to be returned
    ReadProvisionLocationDetails readProvisionLocationDetails = new ReadProvisionLocationDetails();

    // provision location key struct ref object
    provisionLocationKeyStructRef.provisionLocationID = key.provisionLocationID;

    // get provision location details object
    GetProvisionLocationDtls getProvisionLocationDtls;

    // read the provision details
    getProvisionLocationDtls = adminProvisionLocationObj.readProvisionLocation(
      provisionLocationKeyStructRef);

    // populate provisionLocationDetails
    readProvisionLocationDetails.provisionLocationDetails.comments = getProvisionLocationDtls.comments;
    readProvisionLocationDetails.provisionLocationDetails.creationDate = getProvisionLocationDtls.creationDate;
    readProvisionLocationDetails.provisionLocationDetails.endDate = getProvisionLocationDtls.endDate;
    readProvisionLocationDetails.provisionLocationDetails.estimatedCost = getProvisionLocationDtls.estimateCost;
    readProvisionLocationDetails.provisionLocationDetails.productProvisionID = getProvisionLocationDtls.productProvisionID;
    readProvisionLocationDetails.provisionLocationDetails.providerLocationID = getProvisionLocationDtls.providerLocationID;
    readProvisionLocationDetails.provisionLocationDetails.provisionLocationID = getProvisionLocationDtls.provisionLocationID;
    readProvisionLocationDetails.provisionLocationDetails.startDate = getProvisionLocationDtls.startDate;
    readProvisionLocationDetails.provisionLocationDetails.statusCode = getProvisionLocationDtls.statusCode;
    readProvisionLocationDetails.provisionLocationDetails.versionNo = getProvisionLocationDtls.versionNo;
    readProvisionLocationDetails.provisionLocationDetails.providerLocationName = getProvisionLocationDtls.providerLocationName;

    // ProvisionLocation manipulation variables
    curam.core.intf.ProvisionLocation provisionLocationObj = curam.core.fact.ProvisionLocationFactory.newInstance();
    ProvisionLocationKey provisionLocationKey = new ProvisionLocationKey();
    ProvisionLocationDtls provisionLocationDtls;

    provisionLocationKey.provisionLocationID = key.provisionLocationID;

    provisionLocationDtls = provisionLocationObj.read(provisionLocationKey);

    // Context Description Key
    ProvisionLocationContextDescriptionKey provisionLocationContextDescriptionKey = new ProvisionLocationContextDescriptionKey();

    // read provision location context description
    provisionLocationContextDescriptionKey.provisionID = provisionLocationDtls.productProvisionID;

    readProvisionLocationDetails.provisionLocationContextDescriptionDetails = getProvisionLocationContextDescription(
      provisionLocationContextDescriptionKey);

    // return details
    return readProvisionLocationDetails;
  }

  /**
   * Read the rule set assignment details.
   *
   * @param key
   * The product rules link ID of the rule set.
   *
   * @return The product rules details returned from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadRuleSetAssignmentDetails readRuleSetAssignmentDetails(
    final ReadRuleSetAssignmentDetailsKey key) throws AppException,
      InformationalException {

    // Create the return object
    ReadRuleSetAssignmentDetails readRuleSetAssignmentDetails = new ReadRuleSetAssignmentDetails();

    // AdminProductRulesLink manipulation variables
    curam.core.intf.AdminProductRulesLink adminProductRulesLinkObj = curam.core.fact.AdminProductRulesLinkFactory.newInstance();
    GetProductRulesLinkDtls getProductRulesLinkDtls = new GetProductRulesLinkDtls();
    ProductRulesLinkKeyRef productRulesLinkKeyRef = new ProductRulesLinkKeyRef();

    // Set key to read rule set assignment details
    productRulesLinkKeyRef.productRulesLinkID = key.productRulesLinkID;

    // Call AdminProductRulesLink BPO to read the rule set assignment details
    getProductRulesLinkDtls = adminProductRulesLinkObj.readProductRulesLink(
      productRulesLinkKeyRef);

    // Assign the details to the output struct
    readRuleSetAssignmentDetails.ruleSetAssignmentDetails.assign(
      getProductRulesLinkDtls);

    // Get the context description for the rule set assignment.
    ProductRuleSetContextDescriptionKey contextDescriptionKey = new ProductRuleSetContextDescriptionKey();

    // Set the context description key.
    contextDescriptionKey.productRulesLinkID = key.productRulesLinkID;

    // Read the rule set assignment context description.
    readRuleSetAssignmentDetails.contextDescription = getProductRuleSetContextDescription(
      contextDescriptionKey);

    return readRuleSetAssignmentDetails;
  }

  /**
   * This method exists for customers to implement using 'sub classing with
   * replacement'.
   *
   * @param key
   * The rules information ID of the rule set.
   *
   * @return The rule set details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public RuleSetDetailsStruct readRuleSet(ReadRuleSetKey key)
    throws AppException, InformationalException {

    return null;
  }

  /**
   * Read the rules objective details.
   *
   * @param key
   * The rules objective ID of the rule set.
   *
   * @return The rule objective details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public curam.core.facade.struct.RulesObjectiveDetails readRulesObjective(
    ReadRulesObjectiveKey key) throws AppException, InformationalException {

    // Create the return object
    curam.core.facade.struct.RulesObjectiveDetails rulesObjectiveDetailsRet = new curam.core.facade.struct.RulesObjectiveDetails();

    // AdminRulesObjective manipulation variables
    curam.core.intf.AdminRulesObjective adminRulesObjectiveObj = curam.core.fact.AdminRulesObjectiveFactory.newInstance();
    RulesObjectiveKeyRef rulesObjectiveKeyRef = new RulesObjectiveKeyRef();
    curam.core.struct.RulesObjectiveDetails rulesObjectiveDetails = new curam.core.struct.RulesObjectiveDetails();

    // Set key to read the rules objective details
    rulesObjectiveKeyRef.rulesObjectiveID = key.rulesObjectiveID;

    // Call AdminRulesObjective BPO to read the rules objective details
    rulesObjectiveDetails = adminRulesObjectiveObj.readRulesObjective(
      rulesObjectiveKeyRef);

    // Assign details read to the output struct
    rulesObjectiveDetailsRet.comments = rulesObjectiveDetails.comments;
    rulesObjectiveDetailsRet.deductionAllowed = rulesObjectiveDetails.deductionAllowableInd;
    rulesObjectiveDetailsRet.rulesObjectiveID = rulesObjectiveDetails.rulesObjectiveID;
    rulesObjectiveDetailsRet.target = rulesObjectiveDetails.target;
    rulesObjectiveDetailsRet.type = rulesObjectiveDetails.type;

    return rulesObjectiveDetailsRet;
  }

  /**
   * Cancel a product rules link.
   *
   * @param key
   * The product rules link ID which will be cancelled
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelRuleSetFromProduct(CancelRuleSetFromProductKey key)
    throws AppException, InformationalException {

    // AdminProductRulesLink manipulation variables
    curam.core.intf.AdminProductRulesLink adminProductRulesLinkObj = curam.core.fact.AdminProductRulesLinkFactory.newInstance();
    ProductRulesLinkKeyRef productRulesLinkKeyRef = new ProductRulesLinkKeyRef();

    // Set key to cancel rule set from product
    productRulesLinkKeyRef.productRulesLinkID = key.productRulesLinkID;

    // Call AdminProductRulesLink to cancel the product rules link
    adminProductRulesLinkObj.cancelRulesFromProduct(productRulesLinkKeyRef);
  }

  /**
   * Presentation layer operation to set a Default Delivery Pattern.
   *
   * @param key
   * The key of the Delivery Pattern to be set as default.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void setAsDefaultDeliveryPattern(SetAsDefaultDeliveryPatternKey key)
    throws AppException, InformationalException {

    // Admin Delivery Pattern object
    curam.core.intf.AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = curam.core.fact.AdminProductDeliveryPatternInfoFactory.newInstance();

    // Create AdminPDPIProdDelPatIDProdIDKey object
    AdminPDPIProdDelPatIDProdIDKey adminPDPIProdDelPatIDProdIDKey = new AdminPDPIProdDelPatIDProdIDKey();

    // Set key to set default product delivery pattern ID
    adminPDPIProdDelPatIDProdIDKey.productID = key.adminPDPIProdDelPatIDProdIDKey.productID;

    // Sets the Admin Key Product Delivery Pattern ID
    adminPDPIProdDelPatIDProdIDKey.productDeliveryPatternID = key.adminPDPIProdDelPatIDProdIDKey.productDeliveryPatternID;

    // Sets the Default Product Delivery Pattern Info
    adminProductDeliveryPatternInfoObj.setDefaultProductDeliveryPatternID(
      adminPDPIProdDelPatIDProdIDKey);
  }

  /**
   * Presentation layer operation to cancel a Delivery Pattern.
   *
   * @param key
   * The key of the Delivery Pattern to cancel.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelDeliveryPattern(CancelDeliveryPatternKey key)
    throws AppException, InformationalException {

    // AdminProductDeliveryPatternInfo manipulation variables
    curam.core.intf.AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = curam.core.fact.AdminProductDeliveryPatternInfoFactory.newInstance();
    CancelProductDeliveryPatternInfoKey cancelProductDeliveryPatternInfoKey = new CancelProductDeliveryPatternInfoKey();

    // Assign Key to cancel product delivery pattern
    cancelProductDeliveryPatternInfoKey.assign(
      key.cancelProductDeliveryPatternInfoKey);

    // Cancel product delivery pattern
    adminProductDeliveryPatternInfoObj.cancelProductDeliveryPatternInfo(
      cancelProductDeliveryPatternInfoKey);
  }

  // BEGIN, CR00279693, MV
  /**
   * Presentation layer operation to create a Delivery Pattern.
   *
   * @param details
   * The details of the Delivery Pattern to create.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2 , replaced with
   * {@link Product# createDeliveryPatternInfo()}. The
   * existing method, createDeliveryPattern, does not
   * support the display of informational message to be shown when
   * the offset does not have an effect on delivery pattern. Hence the new method
   * createDeliveryPatternInfo has been created, which will
   * validate the offset against a delivery pattern and returns the informational message.
   * See release note: CEF-8154.
   */
  // END, CR00279693
  @Deprecated
  public void createDeliveryPattern(CreateDeliveryPatternDetails details)
    throws AppException, InformationalException {

    // AdminProductDeliveryPatternInfo business object
    curam.core.intf.AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = curam.core.fact.AdminProductDeliveryPatternInfoFactory.newInstance();

    // Create a Product Delivery Pattern Info record.
    adminProductDeliveryPatternInfoObj.createProductDeliveryPatternInfo(
      details.productDeliveryPatternInfoDetails);
  }

  // BEGIN, CR00279693, MV
  /**
   * Presentation layer operation to create a Delivery Pattern.
   *
   * @param details
   * The details of the Delivery Pattern to create.
   *
   * @return InformationalMsgDtlsList The Informational Message List.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList createDeliveryPatternInfo(CreateDeliveryPatternDetails deliveryPatternInfoDetails)
    throws AppException, InformationalException {

    // AdminProductDeliveryPatternInfo business object
    final AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = AdminProductDeliveryPatternInfoFactory.newInstance();

    InformationalMsgDtlsList informationMsgDtlsList = new InformationalMsgDtlsList();

    // Create a Product Delivery Pattern Info record.
    adminProductDeliveryPatternInfoObj.createProductDeliveryPatternInfo(
      deliveryPatternInfoDetails.productDeliveryPatternInfoDetails);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (final String informationMsgTxt : warnings) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = informationMsgTxt;
      informationMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
    return informationMsgDtlsList;
  }

  // END, CR00279693

  // BEGIN, CR00235829, GP
  /**
   * Presentation layer operation to list delivery pattern details.
   *
   * @param key
   * The key of the delivery pattern.
   *
   * @return The delivery pattern list.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated since curam 6.0 , replaced by
   * {@link Product# listAllDeliveryPatterns()} See release note:
   * CR00235829.
   */
  @Deprecated
  // END, CR00235829
  public ListDeliveryPatternDetails listDeliveryPattern(
    ListDeliveryPatternKey key) throws AppException, InformationalException {

    // Create return object
    ListDeliveryPatternDetails listDeliveryPatternDetails = new ListDeliveryPatternDetails();

    // AdminProductDeliveryPatternInfo manipulation variables
    curam.core.intf.AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = curam.core.fact.AdminProductDeliveryPatternInfoFactory.newInstance();

    // ProductContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // List of all Product Delivery Pattern Info Details
    listDeliveryPatternDetails.productDeliveryPatternInfoDetailsList = adminProductDeliveryPatternInfoObj.listCurrentFutureAndCancelledByProductID(
      key.patternInfoByProductIDKey);

    // Set key to read resource context description
    productContextDescriptionKey.productID = key.patternInfoByProductIDKey.productID;

    // Read resource context description
    listDeliveryPatternDetails.productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    return listDeliveryPatternDetails;
  }

  // BEGIN, CR00235829, GP
  /**
   * Presentation layer operation to list delivery pattern details.
   *
   * @param key
   * contains the key of the delivery pattern.
   *
   * @return The delivery pattern list.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProductDeliveryPatternDetails listAllDeliveryPatterns(
    ListDeliveryPatternKey key) throws AppException, InformationalException {

    ListProductDeliveryPatternDetails listDeliveryPatternDetails = new ListProductDeliveryPatternDetails();

    curam.core.intf.AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = curam.core.fact.AdminProductDeliveryPatternInfoFactory.newInstance();

    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // List of all Product Delivery Pattern Info Details
    listDeliveryPatternDetails.productDeliveryPatternInfoDetailsList = adminProductDeliveryPatternInfoObj.listCurrentFutureAndCancelledDeliveryPatternsByProductID(
      key.patternInfoByProductIDKey);

    // Set key to read resource context description
    productContextDescriptionKey.productID = key.patternInfoByProductIDKey.productID;

    // Read resource context description
    listDeliveryPatternDetails.productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    return listDeliveryPatternDetails;
  }

  // END, CR00235829

  /**
   * Presentation layer operation to list Delivery Pattern History Details.
   *
   * @param key
   * The key of the Delivery Pattern.
   *
   * @return The Delivery Pattern History List.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListDeliveryPatternHistoryDetails listDeliveryPatternHistory(
    ListDeliveryPatternHistoryKey key) throws AppException,
      InformationalException {

    // Create return object
    ListDeliveryPatternHistoryDetails listDeliveryPatternHistoryDetails = new ListDeliveryPatternHistoryDetails();

    // AdminProductDeliveryPatternInfo manipulation variables
    curam.core.intf.AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = curam.core.fact.AdminProductDeliveryPatternInfoFactory.newInstance();
    AdminPDPIProdDelPatIDKey adminPDPIProdDelPatIDKey = new AdminPDPIProdDelPatIDKey();

    // Assign key to read product delivery pattern history
    adminPDPIProdDelPatIDKey.assign(key.adminPDPIProdDelPatIDKey);

    // Read product delivery pattern history details
    listDeliveryPatternHistoryDetails.productDeliveryPatternInfoDetailsList = adminProductDeliveryPatternInfoObj.listByProductDeliveryPatternID(
      adminPDPIProdDelPatIDKey);

    return listDeliveryPatternHistoryDetails;
  }

  // BEGIN, CR00235829, GP
  /**
   * Presentation layer operation to modify a Delivery Pattern.
   *
   * @param details
   * The details of the Delivery Pattern to be modified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated since curam 6.0 , replaced by
   * {@link Product# modifyProductDeliveryPattern()} See release
   * note: CR00235829.
   */
  @Deprecated
  // END, CR00235829
  public void modifyDeliveryPattern(ModifyDeliverPatternDetails details)
    throws AppException, InformationalException {

    // AdminProductDeliveryPatternInfo business object
    curam.core.intf.AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = curam.core.fact.AdminProductDeliveryPatternInfoFactory.newInstance();

    // Call the AdminProductDeliveryPatternInfo BPO to modify the
    // product delivery pattern info details
    adminProductDeliveryPatternInfoObj.modifyProductDeliveryPatternInfo(
      details.productDeliveryPatternInfoDetails);
  }

  // BEGIN, CR00278876, MV
  /**
   * Modifies a Product Delivery Pattern.
   *
   * @param details
   * The details of the Delivery Pattern to be modified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2 , replaced with
   * {@link Product# modifyProductDeliveryPatternInfo()}. The
   * existing method, modifyProductDeliveryPattern, does not
   * support the display of informational message to be shown when
   * the offset does not have an effect on delivery pattern. Hence the new method
   * modifyProductDeliveryPatternInfo has been created, which will
   * validate the offset against a delivery pattern and returns the informational message.
   * See release note: CEF-8154.
   */
  @Deprecated
  // END, CR00278876
  public void modifyProductDeliveryPattern(
    ModifyProductDeliveryPatternDetails details) throws AppException,
      InformationalException {

    AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = curam.core.fact.AdminProductDeliveryPatternInfoFactory.newInstance();

    // Call the AdminProductDeliveryPatternInfo BPO to modify the
    // product delivery pattern info details
    adminProductDeliveryPatternInfoObj.modifyProductDeliveryPatternInfoDetails(
      details.dtls);
  }

  // BEGIN, CR00278876, MV
  /**
   * Modifies a Product Delivery Pattern.
   *
   * @param details
   * The details of the Delivery Pattern to be modified.
   *
   * @return InformationalMsgDtlsList The Informational Message List.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList modifyProductDeliveryPatternInfo(
    ModifyProductDeliveryPatternDetails productDeliveryPatternInfoDetails)
    throws AppException, InformationalException {

    AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = curam.core.fact.AdminProductDeliveryPatternInfoFactory.newInstance();

    InformationalMsgDtlsList informationMsgDtlsList = new InformationalMsgDtlsList();

    adminProductDeliveryPatternInfoObj.modifyProductDeliveryPatternInfoDetails(
      productDeliveryPatternInfoDetails.dtls);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
    return informationMsgDtlsList;
  }

  // END, CR00278876

  /**
   * Presentation layer operation to read a Delivery Pattern.
   *
   * @param key
   * The key of the Delivery Pattern to be read.
   *
   * @return The delivery pattern details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated since curam 6.0 , replaced by
   * {@link Product#readProductDeliveryPattern()} See release note:
   * CR00235829
   */
  @Deprecated
  // END, CR00235829
  public ReadDeliveryPatternDetails readDeliveryPattern(
    ReadDeliveryPatternKey key) throws AppException, InformationalException {

    // Create return object
    ReadDeliveryPatternDetails readDeliveryPatternDetails = new ReadDeliveryPatternDetails();

    // AdminProductDeliveryPatternInfo manipulation variables
    curam.core.intf.AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = curam.core.fact.AdminProductDeliveryPatternInfoFactory.newInstance();
    AdminPDPIIDKey adminPDPIIDKey = new AdminPDPIIDKey();

    // Assign key to read product delivery pattern info details
    adminPDPIIDKey.assign(key.adminPDPIIDKey);

    // Read product delivery pattern info details
    readDeliveryPatternDetails.productDeliveryPatternInfoDetails = adminProductDeliveryPatternInfoObj.readProductDeliveryPatternInfo(
      adminPDPIIDKey);

    return readDeliveryPatternDetails;
  }

  // BEGIN, CR00235829, GP
  /**
   * Reads the Delivery Pattern details.
   *
   * @param key
   * contains the key of the Delivery Pattern to be read.
   *
   * @return The delivery pattern details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadProductDeliveryPatternDetails readProductDeliveryPattern(
    ReadDeliveryPatternKey key) throws AppException, InformationalException {

    ReadProductDeliveryPatternDetails readDeliveryPatternDetails = new ReadProductDeliveryPatternDetails();

    AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = AdminProductDeliveryPatternInfoFactory.newInstance();
    AdminPDPIIDKey adminPDPIIDKey = new AdminPDPIIDKey();

    // Assign key to read product delivery pattern info details.
    adminPDPIIDKey.assign(key.adminPDPIIDKey);

    // Read product delivery pattern info details.
    readDeliveryPatternDetails.dtls = adminProductDeliveryPatternInfoObj.readProductDeliveryPatternInfoDetails(
      adminPDPIIDKey);

    return readDeliveryPatternDetails;
  }

  // END, CR00235829

  // BEGIN, CR00312643, SG
  /**
   * This method exists for customers to implement using 'sub classing with
   * replacement'.
   *
   * @param key The rules information ID.
   *
   * @return The rule information context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected RuleSetContextDescriptionDetails getRuleSetContextDescription(
    RuleSetContextDescriptionKey key) throws AppException,
      InformationalException {
    
    return productIntfMap.get("PRODUCT").getRuleSetContextDescription(key);
    
  }

  // END, CR00312643

  /**
   * Cancels a Provision Location.
   *
   * @param key
   * Identifier of the Provision Location to be canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelProvisionLocation(CancelProvisionLocationKey key)
    throws AppException, InformationalException {

    // AdminProvisionLocation business object
    curam.core.intf.AdminProvisionLocation adminProvisionLocationObj = curam.core.fact.AdminProvisionLocationFactory.newInstance();

    // CancelProvisionLocationKeyStruct object
    CancelProvisionLocationKeyStruct cancelProvisionLocationKeyStruct = new CancelProvisionLocationKeyStruct();

    // Set key to cancel the provision location
    cancelProvisionLocationKeyStruct.provisionLocationID = key.provisionLocationID;
    cancelProvisionLocationKeyStruct.versionNo = key.versionNo;

    // Call AdminProvisionLocation BPO to cancel the Provision Location
    adminProvisionLocationObj.cancelProvisionLocation(
      cancelProvisionLocationKeyStruct);
  }

  /**
   * Creates an ad hoc bonus criteria record.
   *
   * @param details
   * Details of the ad hoc bonus criteria to be created.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createAdhocBonusCriteria(CreateAdhocBonusCriteriaDetails details)
    throws AppException, InformationalException {

    // MaintainAd hocBonusCriteria business object
    curam.core.intf.MaintainAdhocBonusCriteria maintainAdhocBonusCriteriaObj = curam.core.fact.MaintainAdhocBonusCriteriaFactory.newInstance();

    // Call MaintainAd hocBonusCriteria BPO to create the ad hoc bonus criteria
    // record
    maintainAdhocBonusCriteriaObj.createAdhocBonusCriteria(
      details.bonusCriteriaDetails);
  }

  /**
   * Modify details of a Provision Location.
   *
   * @param key
   * Provision Location key.
   *
   * @param details
   * Modified Provision Location details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyProvisionLocation(ModifyProvisionLocationKey key,
    ModifyProvisionLocationDetails details) throws AppException,
      InformationalException {

    // AdminProvisionLocation business object
    curam.core.intf.AdminProvisionLocation adminProvisionLocationObj = curam.core.fact.AdminProvisionLocationFactory.newInstance();

    // ProvisionLocationKeyStructRef object
    ProvisionLocationKeyStructRef provisionLocationKeyStructRef = new ProvisionLocationKeyStructRef();

    // ProvisionLocationDetails object
    curam.core.struct.ProvisionLocationDetails provisionLocationDetails = new curam.core.struct.ProvisionLocationDetails();

    // Set provision location key
    provisionLocationKeyStructRef.provisionLocationID = key.provisionLocationID;

    // Populate provisionLocationDetails for modification
    provisionLocationDetails.comments = details.comments;
    provisionLocationDetails.provisionLocationID = key.provisionLocationID;
    provisionLocationDetails.creationDate = details.creationDate;
    provisionLocationDetails.endDate = details.endDate;
    provisionLocationDetails.estimateCost = details.estimatedCost;
    provisionLocationDetails.productProvisionID = details.productProvisionID;
    provisionLocationDetails.providerLocationID = details.providerLocation;
    provisionLocationDetails.startDate = details.startDate;
    provisionLocationDetails.statusCode = details.statusCode;
    provisionLocationDetails.versionNo = details.versionNo;

    // Call AdminProvisionLocation BPO to modify a provision location
    adminProvisionLocationObj.modifyProvisionLocation(
      provisionLocationKeyStructRef, provisionLocationDetails);
  }

  /**
   * Read a rules objective tag details.
   *
   * @param key
   * The rules objective tag ID.
   *
   * @return The rule objective tag details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadRulesObjectiveTagDetails readRulesObjectiveTag(
    curam.core.facade.struct.ReadRulesObjectiveTagKey key)
    throws AppException, InformationalException {

    // Create the return object
    ReadRulesObjectiveTagDetails readRulesObjectiveTagDetails = new ReadRulesObjectiveTagDetails();

    // AdminRulesObjective manipulation variables
    curam.core.intf.AdminRulesObjective adminRulesObjectiveObj = curam.core.fact.AdminRulesObjectiveFactory.newInstance();
    curam.core.struct.ReadRulesObjectiveTagKey readRulesObjectiveTagKey = new curam.core.struct.ReadRulesObjectiveTagKey();
    RulesObjectiveTagFullDetails rulesObjectiveTagFullDetails = new RulesObjectiveTagFullDetails();

    // Set key to read the objective tag details
    readRulesObjectiveTagKey.rulesObjectiveTagID = key.rulesObjectiveTagID;

    // Call AdminRulesObjective BPO to read the objective tag details
    rulesObjectiveTagFullDetails = adminRulesObjectiveObj.readRulesObjectiveTag(
      readRulesObjectiveTagKey);

    // Map the rule objective tag details to the output struct
    readRulesObjectiveTagDetails.rulesObjectiveTagDetails.recurrencePattern = rulesObjectiveTagFullDetails.recurrencePattern;
    readRulesObjectiveTagDetails.rulesObjectiveTagDetails.rulesObjectiveTagID = rulesObjectiveTagFullDetails.rulesObjectiveTagID;
    readRulesObjectiveTagDetails.rulesObjectiveTagDetails.value = rulesObjectiveTagFullDetails.value;
    readRulesObjectiveTagDetails.rulesObjectiveTagDetails.rulesObjectiveID = rulesObjectiveTagFullDetails.rulesObjectiveID;
    readRulesObjectiveTagDetails.rulesObjectiveTagDetails.comments = rulesObjectiveTagFullDetails.comments;

    return readRulesObjectiveTagDetails;
  }

  /**
   * Operation to read the Provision Location Context Description.
   *
   * @param key
   * Provision Location context description key.
   *
   * @return Provision Location context description details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected ProvisionLocationContextDescriptionDetails getProvisionLocationContextDescription(
    ProvisionLocationContextDescriptionKey key) throws AppException,
      InformationalException {

    // Create return object
    ProvisionLocationContextDescriptionDetails provisionLocationContextDescriptionDetails = new ProvisionLocationContextDescriptionDetails();

    // Product Provision manipulation variables
    curam.core.intf.ProductProvision productProvisionObj = curam.core.fact.ProductProvisionFactory.newInstance();
    curam.core.struct.ProductProvisionKey productProvisionKey = new curam.core.struct.ProductProvisionKey();
    ProductProvisionDtls productProvisionDtls;

    // read product provision details
    productProvisionKey.productProvisionID = key.provisionID;
    productProvisionDtls = productProvisionObj.read(productProvisionKey);

    // Product manipulation variables
    curam.core.intf.Product productObj = curam.core.fact.ProductFactory.newInstance();
    ProductKey productKey = new ProductKey();

    ProductNameStructRef productNameStructRef;

    // Set key to read product
    productKey.productID = productProvisionDtls.productID;

    // Read product name code
    productNameStructRef = productObj.readProductName(productKey);

    // Create a localizable string based on the message entry
    LocalisableString contextDescription = new LocalisableString(
      BPOPRODUCT.INF_PROVISION_LOCATION_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(PRODUCTNAME.TABLENAME,
      productNameStructRef.name));

    // product provider name
    GetProductProviderNameDtls getProductProviderNameDtls;

    getProductProviderNameDtls = productProvisionObj.getProductProviderName(
      productProvisionKey);

    // Add the Product Provider Name to the localizable string
    contextDescription.arg(getProductProviderNameDtls.productProviderName);

    // Populate the context description field with the localizable text
    provisionLocationContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    return provisionLocationContextDescriptionDetails;
  }

  /**
   * Returns a list of SIDs of type Product.
   *
   * @return List of Security Identifiers of type Product.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public curam.core.facade.struct.SecurityIDList listProductSIDs()
    throws AppException, InformationalException {

    // Create return object
    curam.core.facade.struct.SecurityIDList securityIDListRet = new curam.core.facade.struct.SecurityIDList();

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // SecurityIDList object
    curam.core.struct.SecurityIDList securityIDList = new curam.core.struct.SecurityIDList();

    // SIDTypeKey object
    SIDTypeKey sidTypeKey = new SIDTypeKey();

    // Call AdminProduct BPO to return list of product SIDs
    securityIDList = adminProductObj.listSIDs(sidTypeKey);

    // Assign list of product SIDs for return to client
    securityIDListRet.securityIDList.assign(securityIDList);

    return securityIDListRet;
  }

  /**
   * Create a new Provision Location.
   *
   * @param details
   * New Provision Location details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createProvisionLocation(CreateProvisionLocationDetails details)
    throws AppException, InformationalException {

    // AdminProvisionLocation business object
    curam.core.intf.AdminProvisionLocation adminProvisionLocationObj = curam.core.fact.AdminProvisionLocationFactory.newInstance();

    // Call AdminProvisionLocation BPO to create a Provision Location
    adminProvisionLocationObj.insertProvisionLocation(
      details.provisionLocationDetails);
  }

  /**
   * Add one or more product categories to a product.
   *
   * @param key
   * Add categories to product.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addCategoriesToProduct(AddCategoriesToProductKey key)
    throws AppException, InformationalException {

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // Call BPO to add categories to product
    adminProductObj.addCategoriesToProduct(key.productKeyStruct,
      key.categoryTabList);
  }

  /**
   * @param details
   * Details to create a new benefit product.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #createBenefitProduct1()}.
   * New method contains additional attributes to indicate if cases
   * of this benefit type are displayed in the participants programs
   * list, in My Cases filter and in Case Search filter
   *
   * Creates a new benefit product.
   */
  @Deprecated
  public void createBenefitProduct(BenefitProductDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00173421, ZV
    BenefitProductDetails1 benefitProductDetails1 = new BenefitProductDetails1();

    benefitProductDetails1.assign(details);

    benefitProductDetails1.myCasesFilterInd = true;
    benefitProductDetails1.caseSearchFilterInd = true;

    createBenefitProduct1(benefitProductDetails1);

    details.assign(benefitProductDetails1);
    // END, CR00173421

  }

  /**
   * @param details
   * Details to create a new liability product.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #createLiabilityProduct1()}
   * . New method contains additional attributes to indicate if
   * cases of this liability type are displayed in the participants
   * programs list, in My Cases filter and in Case Search filter.
   *
   * Creates a new liability product.
   */
  @Deprecated
  public void createLiabilityProduct(LiabilityProductDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00173421, ZV
    LiabilityProductDetails1 liabilityProductDetails1 = new LiabilityProductDetails1();

    liabilityProductDetails1.assign(details);

    liabilityProductDetails1.myCasesFilterInd = true;
    liabilityProductDetails1.caseSearchFilterInd = true;

    createLiabilityProduct1(liabilityProductDetails1);

    details.assign(liabilityProductDetails1);
    // END, CR00173421

  }

  /**
   * Returns a list of categories in product and a list of categories not in
   * product
   *
   * @param key
   * List Product Category Key.
   *
   * @return A list of categories in product and a list of categories not in
   * product.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProductCategoryDetails listProductCategory(
    ListProductCategoryKey key) throws AppException, InformationalException {

    // Create return object
    ListProductCategoryDetails listProductCategoryDetails = new ListProductCategoryDetails();

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // ProductCategoryLists object
    ProductCategoryLists productCategoryLists;

    // ProductKeyStruct object
    ProductKeyStruct productKeyStruct = new ProductKeyStruct();

    // Set key to read productCategory lists
    productKeyStruct.productID = key.productID;

    // Call AdminProduct BPO to return productCategory lists
    productCategoryLists = adminProductObj.listProductCategory(productKeyStruct);

    // Set productCategory lists to be returned to the client
    listProductCategoryDetails.productCategoryLists.categoriesInProduct = productCategoryLists.categoriesInProduct;
    listProductCategoryDetails.productCategoryLists.categoriesNotInProduct = productCategoryLists.categoriesNotInProduct;

    return listProductCategoryDetails;
  }

  /**
   * @param key
   * Product Key Struct which contains the product identifier.
   *
   * @param details
   * Modified benefit product details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #modifyBenefitProduct1()}.
   * New method contains additional attributes to indicate if cases
   * of this benefit type are displayed in the participants programs
   * list, in My Cases filter and in Case Search filter.
   *
   * Modifies details of a benefit product.
   */
  @Deprecated
  public void modifyBenefitProduct(ProductKeyStruct key,
    BenefitProductDetails details) throws AppException,
      InformationalException {

    // BEGIN, CR00173421, ZV
    BenefitProductDetails1 benefitProductDetails1 = new BenefitProductDetails1();

    benefitProductDetails1.assign(details);

    benefitProductDetails1.myCasesFilterInd = true;
    benefitProductDetails1.caseSearchFilterInd = true;
    // BEGIN, CR00230245, CW
    // Assign reassessmentActionType based on overUnderPaymentAutoProcessInd
    if (details.overUnderPaymentAutoProcessInd) {
      benefitProductDetails1.reassessmentActionType = OVERUNDERPMNTPROCESSING.AUTOMATIC;
    } else {
      benefitProductDetails1.reassessmentActionType = OVERUNDERPMNTPROCESSING.SENDTICKET;
    }
    // END, CR00230245

    modifyBenefitProduct1(key, benefitProductDetails1);
    // END, CR00173421

  }

  /**
   * @param key
   * Product Key Struct which contains the product identifier.
   *
   * @param details
   * Modified liability product details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #modifyLiabilityProduct1()}
   * . New method contains additional attributes to indicate if
   * cases of this liability type are displayed in the participants
   * programs list, in My Cases filter and in Case Search filter.
   *
   * Modifies details of a liability product.
   */
  @Deprecated
  public void modifyLiabilityProduct(ProductKeyStruct key,
    LiabilityProductDetails details) throws AppException,
      InformationalException {

    // BEGIN, CR00173421, ZV
    LiabilityProductDetails1 liabilityProductDetails1 = new LiabilityProductDetails1();

    liabilityProductDetails1.assign(details);

    liabilityProductDetails1.myCasesFilterInd = true;
    liabilityProductDetails1.caseSearchFilterInd = true;

    modifyLiabilityProduct1(key, liabilityProductDetails1);
    // END, CR00173421

  }

  /**
   * @param key
   * This contains the product identifier.
   *
   * @return ReadLiabilityProductStruct Contains liability product information.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #readLiabilityProduct1()}.
   * New method reads additional attributes which indicate if cases
   * of this liability type are displayed in the participants
   * programs list, in My Cases filter and in Case Search filter.
   *
   * Reads details of a liability product.
   */
  @Deprecated
  public ReadLiabilityProductStruct readLiabilityProduct(ProductKeyStruct key)
    throws AppException, InformationalException {

    // Create return object
    ReadLiabilityProductStruct readLiabilityProductStruct = new ReadLiabilityProductStruct();

    // BEGIN, CR00173421, ZV
    ReadLiabilityProductStruct1 readLiabilityProductStruct1 = readLiabilityProduct1(
      key);

    readLiabilityProductStruct.assign(readLiabilityProductStruct1);
    // END, CR00173421

    return readLiabilityProductStruct;
  }

  /**
   * Remove a product category from a product.
   *
   * @param key
   * Remove Category From Product Key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void removeCategoryFromProduct(
    curam.core.facade.struct.RemoveCategoryFromProductKey key)
    throws AppException, InformationalException {

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // RemoveCategoryFromProductKey object
    curam.core.struct.RemoveCategoryFromProductKey removeCategoryFromProductKey = new curam.core.struct.RemoveCategoryFromProductKey();

    // Set key to remove category from product
    removeCategoryFromProductKey.assign(key);

    // Call AdminProduct BPO to remove category from product
    adminProductObj.removeCategoryFromProduct(removeCategoryFromProductKey);
  }

  /**
   * Creates a client tab list based on indicators set on creation/modification
   * of products.
   *
   * @param details
   * Eligible Participant Details.
   *
   * @return Product Client Tab List.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected ProductClientTabList createClientTabList(
    EligibleParticipantDetails details) throws AppException,
      InformationalException {

    // ProductCategoryTabList object
    ProductClientTabList productClientTabList = new ProductClientTabList();

    // StringBuffer for creating clientTabList
    final int kStringBufferSize = 256;
    StringBuffer clientList = new StringBuffer(kStringBufferSize);

    if (details.personInd == true) {

      clientList.append(CONCERNROLETYPE.PERSON).append(
        CuramConst.gkTabDelimiter);
    }

    if (details.employerInd == true) {

      clientList.append(CONCERNROLETYPE.EMPLOYER).append(
        CuramConst.gkTabDelimiter);
    }

    if (details.utilityInd == true) {

      clientList.append(CONCERNROLETYPE.UTILITY).append(
        CuramConst.gkTabDelimiter);
    }

    if (details.serviceSupplierInd == true) {

      clientList.append(CONCERNROLETYPE.SERVICESUPPLIER).append(
        CuramConst.gkTabDelimiter);
    }

    if (details.productProviderInd == true) {

      clientList.append(CONCERNROLETYPE.PRODUCTPROVIDER).append(
        CuramConst.gkTabDelimiter);
    }

    if (details.informationProviderInd == true) {

      clientList.append(CONCERNROLETYPE.INFORMATIONPROVIDER).append(
        CuramConst.gkTabDelimiter);
    }

    // convert buffer to string
    productClientTabList.productClientTabList = clientList.toString();

    return productClientTabList;
  }

  /**
   * Returns a list of all products on the system.
   *
   * @return A list of all products on the system.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListAllProductsDetails listAllProducts() throws AppException,
      InformationalException {

    // Create return object
    ListAllProductsDetails listAllProductsDetails = new ListAllProductsDetails();

    // Create AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // ProductDetails object
    curam.core.facade.struct.ProductDetails productDetails;

    // Create productList object
    ProductList productList;

    // Call BPO method to return list of all products
    productList = adminProductObj.listAllProducts();

    // Iterate through productList and assign details to output struct
    for (int i = 0; i < productList.dtls.size(); i++) {

      productDetails = new curam.core.facade.struct.ProductDetails();

      // Assign details to productDetails struct
      productDetails.assign(productList.dtls.item(i));

      // BEGIN, CR00163098, JC
      // Need to convert product name code to description for display
      productDetails.nameDescription = curam.util.type.CodeTable.getOneItem(
        PRODUCTNAME.TABLENAME, productList.dtls.item(i).name,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      listAllProductsDetails.dtls.addRef(productDetails);
    }

    return listAllProductsDetails;
  }

  /**
   * Reads a rules objective context description.
   *
   * @param key
   * The rules objective ID.
   *
   * @return The rule objective context description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected RulesObjectiveContextDescriptionDetails getRulesObjectiveContextDescription(
    RulesObjectiveContextDescriptionKey key) throws AppException,
      InformationalException {

    // Create the return object
    RulesObjectiveContextDescriptionDetails rulesObjectiveContextDescriptionDetails = new RulesObjectiveContextDescriptionDetails();

    // AdminRulesObjective manipulation variables
    curam.core.intf.AdminRulesObjective adminRulesObjectiveObj = curam.core.fact.AdminRulesObjectiveFactory.newInstance();
    RulesObjectiveKeyRef rulesObjectiveKeyRef = new RulesObjectiveKeyRef();
    curam.core.struct.RulesObjectiveDetails rulesObjectiveDetails;

    // Set key to read the rules objective details
    rulesObjectiveKeyRef.rulesObjectiveID = key.rulesObjectiveID;

    // Calls AdminRulesObjective BPO to read the rules objective details
    rulesObjectiveDetails = adminRulesObjectiveObj.readRulesObjective(
      rulesObjectiveKeyRef);

    // Create a localizable string based on the message entry
    LocalisableString contextDescription = new LocalisableString(
      BPOPRODUCT.INF_RULES_OBJECTIVE_CONTEXT_DESCRIPTION);

    contextDescription.arg(rulesObjectiveDetails.rulesSetName);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(RULESCOMPONENTTYPE.TABLENAME,
      rulesObjectiveDetails.type));

    // Populate the context description field with the localizable text
    rulesObjectiveContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    return rulesObjectiveContextDescriptionDetails;
  }

  /**
   * Presentation layer operation to read the Product Rule Context Description.
   *
   * @param key
   * The Product Rule Link ID.
   *
   * @return The context description of the product rule.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected ProductRuleSetContextDecriptionDetails getProductRuleSetContextDescription(
    ProductRuleSetContextDescriptionKey key) throws AppException,
      InformationalException {

    // The rule set description which is returned.
    ProductRuleSetContextDecriptionDetails productRuleSetContextDecriptionDetails = new ProductRuleSetContextDecriptionDetails();

    // The admin rules information object and key.
    curam.core.intf.AdminProductRulesLink adminProductRulesLinkObj = curam.core.fact.AdminProductRulesLinkFactory.newInstance();
    ProductRulesLinkKeyRef productRulesLinkKeyRef = new ProductRulesLinkKeyRef();
    // The details returned from rules information read.
    GetProductRulesLinkDtls getProductRulesLinkDtls;

    // Set the product rule link ID.
    productRulesLinkKeyRef.productRulesLinkID = key.productRulesLinkID;

    // Read the product rule link details.
    getProductRulesLinkDtls = adminProductRulesLinkObj.readProductRulesLink(
      productRulesLinkKeyRef);

    // Create a localizable string based on the message entry
    LocalisableString contextDescription = new LocalisableString(
      BPOPRODUCT.INF_PRODUCT_RULE_SET_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(PRODUCTNAME.TABLENAME,
      getProductRulesLinkDtls.productName));

    // Add the Rule Set name to the localizable string
    contextDescription.arg(getProductRulesLinkDtls.rulesName);

    // Populate the context description field with the localizable text
    productRuleSetContextDecriptionDetails.description = contextDescription.toClientFormattedText();

    // Return the description.
    return productRuleSetContextDecriptionDetails;
  }

  /**
   * Presentation layer operation to create a Product Provision.
   *
   * @param details
   * The details of the product provision to be created.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createProductProvision(
    ProductCreateProductProvisionDetails details) throws AppException,
      InformationalException {

    // AdminProductProvision business object
    curam.core.intf.AdminProductProvision adminProductProvisionObj = curam.core.fact.AdminProductProvisionFactory.newInstance();

    // Call AdminProductProvision to create a new Product Provision
    adminProductProvisionObj.insertProductProvision(
      details.productProvisionDetailsStruct);
  }

  // BEGIN, CR00097501, SAI
  /**
   * Returns a complete list of Provider Locations associated to a particular
   * product provision
   *
   * @param key
   * Product Provision id
   * @return ListAllProviderLocations List of all Provider Locations.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public ListAllProviderLocations listAllProviderLocations(
    curam.core.facade.struct.ProductProvisionKey key) throws AppException,
      InformationalException {

    // Create return object
    ListAllProviderLocations listAllProviderLocations = new ListAllProviderLocations();

    // ProviderLocation manipulation variables
    curam.core.intf.ProviderLocation providerLocationObj = curam.core.fact.ProviderLocationFactory.newInstance();
    ProviderLocationSummaryStructRefList providerLocationSummaryStructRefList;

    // Create a ProviderLocationSearchKey and read in providerLocationID and
    // productProvisionID
    ProviderLocationSearchKey providerLocationSearchKey = new ProviderLocationSearchKey();

    // read product provision
    // productProvision manipulation variables
    curam.core.intf.ProductProvision productProvisionObj = curam.core.fact.ProductProvisionFactory.newInstance();

    ProductProvisionKey productProvisionKey = new ProductProvisionKey();

    productProvisionKey.productProvisionID = key.productProvisionID;
    ProductProvisionDtls productProvisionDtls = productProvisionObj.read(
      productProvisionKey);

    providerLocationSearchKey.productProviderID = productProvisionDtls.providerConcernRoleID;
    providerLocationSearchKey.productProvisionID = key.productProvisionID;
    providerLocationSearchKey.statusCode = RECORDSTATUS.NORMAL;

    // get a list of unassigned provider location for this provider.
    providerLocationSummaryStructRefList = providerLocationObj.searchUnassignedProviderLocationsByProviderID(
      providerLocationSearchKey);
    // END, CR00097501

    // Assign details to output object
    listAllProviderLocations.assign(providerLocationSummaryStructRefList);

    return listAllProviderLocations;
  }

  /**
   * Returns a list of Delivery Pattern Names.
   *
   * @param key
   * The product to return Delivery Pattern Names for.
   *
   * @return List of all Delivery Pattern Names.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListDeliveryPatternNameDetails listDeliveryPatternNames(
    ListDeliveryPatternNamesKey key) throws AppException,
      InformationalException {

    // Details to be returned
    ListDeliveryPatternNameDetails listDeliveryPatternNameDetails = new ListDeliveryPatternNameDetails();

    // AdminProductDeliveryPatternInfo manipulation variables
    curam.core.intf.AdminProductDeliveryPatternInfo adminProductDeliveryPatternInfoObj = curam.core.fact.AdminProductDeliveryPatternInfoFactory.newInstance();

    ProductDeliveryPatternInfoDetailsList productDeliveryPatternInfoDetailsList;
    PatternInfoByProductIDKey patternInfoByProductIDKey = new PatternInfoByProductIDKey();

    // Get productID from key
    patternInfoByProductIDKey.productID = key.productID;

    // Call listCurrentByProductID operation
    productDeliveryPatternInfoDetailsList = adminProductDeliveryPatternInfoObj.listCurrentByProductID(
      patternInfoByProductIDKey);

    // Copy list to return object
    for (int i = 0; i < productDeliveryPatternInfoDetailsList.dtls.size(); i++) {

      DeliveryPatternNameDetails deliveryPatternNameDetails = new DeliveryPatternNameDetails();

      deliveryPatternNameDetails.productDeliveryPatternID = productDeliveryPatternInfoDetailsList.dtls.item(i).productDeliveryPatternID;
      deliveryPatternNameDetails.productDeliveryPatternInfoID = productDeliveryPatternInfoDetailsList.dtls.item(i).productDeliveryPatternInfoID;
      deliveryPatternNameDetails.name = productDeliveryPatternInfoDetailsList.dtls.item(i).name;

      listDeliveryPatternNameDetails.dtls.addRef(deliveryPatternNameDetails);
    }

    return listDeliveryPatternNameDetails;
  }

  // BEGIN, CR00031174, NG
  // BEGIN, CR00224271, ZV
  /**
   * Returns a list of Delivery Pattern Names and Concerned Preferred delivery
   * method indicator.
   *
   * @param key
   * The Key contains productID and concernRoleID
   *
   * @return List of all Delivery Pattern Names and concern preferred delivery
   * method indicator.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listDeliveryPatternPreferredMethodOfPayment1()}.
   */
  @Deprecated
  public DeliveryPatternNamePrefMethodPmtIndDtlsList listDeliveryPatternPreferredMethodOfPayment(
    final ProductIDAndConcernRoleID key) throws AppException,
      InformationalException {

    // Details List to be returned
    DeliveryPatternNamePrefMethodPmtIndDtlsList deliveryPatternNamePrefMethodPmtIndDtlsList = new DeliveryPatternNamePrefMethodPmtIndDtlsList();

    // details of Method of pmt code of this concern
    curam.core.struct.DeliveryMethodType deliveryMethodType;

    // get the concern default method of payment code
    curam.core.struct.ConcernRoleID concernRoleID = new ConcernRoleID();

    concernRoleID.concernRoleID = key.concernRoleID;
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    deliveryMethodType = maintainInstructionLineItemObj.getDeliveryMethodForConcernRole(
      concernRoleID);

    // Get the list of Delivery patterns names for the product.
    ListDeliveryPatternNameDetails listDeliveryPatternNameDetails = new ListDeliveryPatternNameDetails();
    ListDeliveryPatternNamesKey listDeliveryPatternNamesKey = new ListDeliveryPatternNamesKey();

    listDeliveryPatternNamesKey.productID = key.productID;

    listDeliveryPatternNameDetails = listDeliveryPatternNames(
      listDeliveryPatternNamesKey);

    // Copy list to return object
    for (int i = 0; i < listDeliveryPatternNameDetails.dtls.size(); i++) {

      DeliveryPatternNamePrefMethodPmtIndDetails deliveryPatternNamePrefMethodPmtIndDetails = new DeliveryPatternNamePrefMethodPmtIndDetails();

      // Read the delivery pattern details for the product
      ReadDeliveryPatternKey readDeliveryPatternKey = new ReadDeliveryPatternKey();
      ReadDeliveryPatternDetails readDeliveryPatternDetails = new ReadDeliveryPatternDetails();

      readDeliveryPatternKey.adminPDPIIDKey.productDeliveryPatternInfoID = listDeliveryPatternNameDetails.dtls.item(i).productDeliveryPatternInfoID;

      readDeliveryPatternDetails = readDeliveryPattern(readDeliveryPatternKey);

      // compare concern preferred delivery method of payment code with
      // current delivery pattern
      if (deliveryMethodType.deliveryMethodType.equals(
        readDeliveryPatternDetails.productDeliveryPatternInfoDetails.deliveryMethodTypeCode)) {

        deliveryPatternNamePrefMethodPmtIndDetails.concernPrefDeliveryMthdInd = true;

      }

      // BEGIN, CR00092443, CSH
      // Set the client's preferred delivery method on the return struct
      deliveryPatternNamePrefMethodPmtIndDtlsList.preferredDeliveryMethod = deliveryMethodType.deliveryMethodType;
      // END, CR00092443

      deliveryPatternNamePrefMethodPmtIndDetails.name = listDeliveryPatternNameDetails.dtls.item(i).name;
      deliveryPatternNamePrefMethodPmtIndDetails.productDeliveryPatternID = listDeliveryPatternNameDetails.dtls.item(i).productDeliveryPatternID;
      deliveryPatternNamePrefMethodPmtIndDetails.productDeliveryPatternInfoID = listDeliveryPatternNameDetails.dtls.item(i).productDeliveryPatternInfoID;

      deliveryPatternNamePrefMethodPmtIndDtlsList.dtls.addRef(
        deliveryPatternNamePrefMethodPmtIndDetails);
    }

    // Return delivery pattern details
    return deliveryPatternNamePrefMethodPmtIndDtlsList;
  }

  // END, CR00224271
  // END, CR00031174

  /**
   * Returns a list of Providers and their location for a product.
   *
   * @param key
   * The product to return Providers and their locations for.
   *
   * @return List of Providers and their Locations.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProviderAndLocationDetails listProvidersAndLocations(
    ListProviderAndLocationKey key) throws AppException,
      InformationalException {

    // Details to be returned
    ListProviderAndLocationDetails listProviderAndLocationDetails = new ListProviderAndLocationDetails();

    // CreateProductDelivery manipulation variables
    curam.core.intf.CreateProductDelivery createProductDeliveryObj = curam.core.fact.CreateProductDeliveryFactory.newInstance();

    GetProductProviderDetailsResult getProductProviderDetailsResult;
    GetProductProviderKey getProductProviderKey = new GetProductProviderKey();

    // Get productID from key
    getProductProviderKey.assign(key);

    // Call getProductProviderDetails operation
    getProductProviderDetailsResult = createProductDeliveryObj.getProductProviderDetails(
      getProductProviderKey);

    // Copy list to return object
    for (int i = 0; i
      < getProductProviderDetailsResult.productProvidersDetailsList.dtls.size(); i++) {

      ProviderAndLocationDetails providerAndLocationDetails = new ProviderAndLocationDetails();

      providerAndLocationDetails.productProviderID = getProductProviderDetailsResult.productProvidersDetailsList.dtls.item(i).productProviderID;
      providerAndLocationDetails.productProviderName = getProductProviderDetailsResult.productProvidersDetailsList.dtls.item(i).productProviderName;
      providerAndLocationDetails.locationID = getProductProviderDetailsResult.productProvidersDetailsList.dtls.item(i).providerLocationID;
      providerAndLocationDetails.locationName = getProductProviderDetailsResult.productProvidersDetailsList.dtls.item(i).locationName;
      providerAndLocationDetails.estimatedCost = getProductProviderDetailsResult.productProvidersDetailsList.dtls.item(i).estimatedCost;

      listProviderAndLocationDetails.providerAndLocationDetails.addRef(
        providerAndLocationDetails);
    }

    // Return Details
    return listProviderAndLocationDetails;
  }

  /**
   * Returns a products in a particular category
   *
   * @param key
   * Key containing product category.
   *
   * @return List of products in the specified category.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProductDetailsStruct listProductsForCategory(
    ListProductsForCategoryKey key) throws AppException,
      InformationalException {

    // Create return object
    ListProductDetailsStruct listProductDetailsStruct = new ListProductDetailsStruct();

    // ProductCategory manipulation variables
    curam.core.intf.ProductCategory productCategoryObj = curam.core.fact.ProductCategoryFactory.newInstance();

    ReadProductsInCategoryByStatusKey readProductsInCategoryByStatusKey = new ReadProductsInCategoryByStatusKey();

    ProductCategoryReadmultiDetails1List productCategoryReadmultiDetails1List;

    // CaseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // Set key to read caseHeader
    caseHeaderKey.caseID = key.caseID;

    // Read caseHeader
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Set key to read products in category
    readProductsInCategoryByStatusKey.categoryCode = caseHeaderDtls.integratedCaseType;

    readProductsInCategoryByStatusKey.statusCode = RECORDSTATUS.NORMAL;

    // Read products in the specified category
    productCategoryReadmultiDetails1List = productCategoryObj.searchProductsByCategoryAndStatus(
      readProductsInCategoryByStatusKey);

    // Check to see if the list is populated
    if (!productCategoryReadmultiDetails1List.dtls.isEmpty()) {

      // Product manipulation variables
      curam.core.intf.Product productObj = curam.core.fact.ProductFactory.newInstance();
      ProductNameStructRef productNameStructRef;
      ProductKey productKey = new ProductKey();

      // ProductDetailsStruct object
      curam.core.facade.struct.ProductDetailsStruct productDetailsStruct;

      // Iterate through the list of product identifiers and read the
      // product name for each one
      for (int i = 0; i < productCategoryReadmultiDetails1List.dtls.size(); i++) {

        productDetailsStruct = new curam.core.facade.struct.ProductDetailsStruct();

        // Set key to read the product name
        productKey.productID = productCategoryReadmultiDetails1List.dtls.item(i).productID;

        // Read product name
        productNameStructRef = productObj.readProductName(productKey);

        // Set product details
        productDetailsStruct.productID = productKey.productID;
        productDetailsStruct.name = productNameStructRef.name;

        // Add details to return object
        listProductDetailsStruct.productDetailsStruct.addRef(
          productDetailsStruct);
      }
    }

    return listProductDetailsStruct;
  }

  /**
   * Cancels an evidence group page.
   *
   * @param details
   * Details to cancel an evidence group page.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelEvidenceGroupPage(CancelEvidenceGroupPageDetails details)
    throws AppException, InformationalException {

    // EvidenceScreen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    CancelEvidenceScreenDetails cancelEvidenceScreenDetails = new CancelEvidenceScreenDetails();

    // Set key to cancel an evidence screen
    cancelEvidenceScreenDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Set details for cancel
    cancelEvidenceScreenDetails.details.versionNo = details.versionNo;

    // Call BPO to cancel the evidence screen
    evidenceScreenObj.cancel(cancelEvidenceScreenDetails);
  }

  /**
   * Cancels an evidence page.
   *
   * @param details
   * Evidence page details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelEvidencePage(CancelEvidencePageDetails details)
    throws AppException, InformationalException {

    // EvidenceScreen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    CancelEvidenceScreenDetails cancelEvidenceScreenDetails = new CancelEvidenceScreenDetails();

    // Set key to cancel an evidence screen
    cancelEvidenceScreenDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Set details for cancel
    cancelEvidenceScreenDetails.details.versionNo = details.versionNo;

    // Call BPO to cancel evidence screen
    evidenceScreenObj.cancel(cancelEvidenceScreenDetails);
  }

  /**
   * Cancels a site map page
   *
   * @param details
   * Details to cancel a site map page.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelSiteMap(CancelSiteMapDetails details) throws AppException,
      InformationalException {

    // EvidenceScreen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    CancelEvidenceScreenDetails cancelEvidenceScreenDetails = new CancelEvidenceScreenDetails();

    // Set key to cancel an evidence screen
    cancelEvidenceScreenDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Set details for cancel
    cancelEvidenceScreenDetails.details.versionNo = details.versionNo;

    // Call BPO to cancel an evidence screen
    evidenceScreenObj.cancel(cancelEvidenceScreenDetails);
  }

  /**
   * Creates evidence group page.
   *
   * @param details
   * Evidence group page details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createEvidenceGroupPage(CreateEvidenceGroupPageDetails details)
    throws AppException, InformationalException {

    // Evidence Screen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    CreateEvidenceScreenDetails createEvidenceScreenDetails = new CreateEvidenceScreenDetails();

    // Assign evidence screen details
    createEvidenceScreenDetails.dtls.assign(details);

    // Set codetable values for evidence group page creation
    createEvidenceScreenDetails.dtls.evidenceLevel = EVIDENCELEVEL.EVIDENCEGROUP;
    createEvidenceScreenDetails.dtls.pageType = PAGETYPE.EVIDENCEGROUP;
    createEvidenceScreenDetails.dtls.relatedType = EVIDENCESCREENRELATEDTYPE.PRODUCT;

    // Call BPO to create evidence screen record
    evidenceScreenObj.create(createEvidenceScreenDetails);
  }

  /**
   * Creates an evidence page.
   *
   * @param details
   * Evidence page details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createEvidencePage(CreateEvidencePageDetails details)
    throws AppException, InformationalException {

    // Evidence Screen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    CreateEvidenceScreenDetails createEvidenceScreenDetails = new CreateEvidenceScreenDetails();

    // Assign evidence screen details
    createEvidenceScreenDetails.dtls.assign(details);

    // Set codetable values for evidence page creation
    createEvidenceScreenDetails.dtls.evidenceLevel = EVIDENCELEVEL.EVIDENCE;
    createEvidenceScreenDetails.dtls.relatedType = EVIDENCESCREENRELATEDTYPE.PRODUCT;

    // Call BPO to create evidence screen record
    evidenceScreenObj.create(createEvidenceScreenDetails);
  }

  /**
   * Creates a site map page.
   *
   * @param details
   * Site map page details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createSiteMap(CreateSiteMapDetails details) throws AppException,
      InformationalException {

    // Evidence Screen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    CreateEvidenceScreenDetails createEvidenceScreenDetails = new CreateEvidenceScreenDetails();

    // Assign evidence screen details
    createEvidenceScreenDetails.dtls.assign(details);

    // Setting codes to default values for Site Map page
    createEvidenceScreenDetails.dtls.evidenceLevel = EVIDENCELEVEL.SITEMAP;
    createEvidenceScreenDetails.dtls.pageType = PAGETYPE.SITEMAP;
    createEvidenceScreenDetails.dtls.relatedType = EVIDENCESCREENRELATEDTYPE.PRODUCT;
    createEvidenceScreenDetails.dtls.evidenceNodeCode = SITEMAP.SITEMAP;

    // Call BPO to create evidence screen record for site map
    evidenceScreenObj.create(createEvidenceScreenDetails);
  }

  /**
   * Reads list of evidence group page details.
   *
   * @param key
   * Key to read list of evidence group page details.
   *
   * @return List of evidence group page details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListEvidenceGroupPageDetails listEvidenceGroupPage(
    ListEvidenceGroupPageKey key) throws AppException, InformationalException {

    // Create return object
    ListEvidenceGroupPageDetails listEvidenceGroupPageDetails = new ListEvidenceGroupPageDetails();

    // EvidenceScreen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    ListEvidenceScreenKey listEvidenceScreenKey = new ListEvidenceScreenKey();
    ListEvidenceScreenDetails listEvidenceScreenDetails;

    // Product context description variables
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();
    ProductContextDescriptionDetails productContextDescriptionDetails;

    // Set key to read list of evidence group page details
    listEvidenceScreenKey.key.relatedID = key.key.key.relatedID;
    listEvidenceScreenKey.key.evidenceLevel = EVIDENCELEVEL.EVIDENCEGROUP;

    // Call BPO to read list of evidence group page details
    listEvidenceScreenDetails = evidenceScreenObj.list(listEvidenceScreenKey);

    // Evidence group page manipulation variables
    EvidenceGroupPageDetails evidenceGroupPageDetails;

    // Reserve space in return object
    listEvidenceGroupPageDetails.detailsList.dtls.ensureCapacity(
      listEvidenceScreenDetails.detailsList.dtls.size());

    for (int i = 0; i < listEvidenceScreenDetails.detailsList.dtls.size(); i++) {

      evidenceGroupPageDetails = new EvidenceGroupPageDetails();

      evidenceGroupPageDetails.assign(
        listEvidenceScreenDetails.detailsList.dtls.item(i));

      listEvidenceGroupPageDetails.detailsList.dtls.addRef(
        evidenceGroupPageDetails);
    }

    // Set key to read product context description
    productContextDescriptionKey.productID = key.key.key.relatedID;

    // Read product context description
    productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    // Assign product context description to return object
    listEvidenceGroupPageDetails.contextDescription.description = productContextDescriptionDetails.description;

    return listEvidenceGroupPageDetails;
  }

  /**
   * Reads list of evidence page details.
   *
   * @param key
   * Key to read list of evidence page details.
   *
   * @return List of evidence page details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListEvidencePageDetails listEvidencePage(ListEvidencePageKey key)
    throws AppException, InformationalException {

    // Create return object
    ListEvidencePageDetails listEvidencePageDetails = new ListEvidencePageDetails();

    // EvidenceScreen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    ListEvidenceScreenKey listEvidenceScreenKey = new ListEvidenceScreenKey();
    ListEvidenceScreenDetails listEvidenceScreenDetails;

    // Product context description variables
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();
    ProductContextDescriptionDetails productContextDescriptionDetails;

    // Set key to read list of evidence screen details
    listEvidenceScreenKey.key.relatedID = key.key.key.relatedID;
    listEvidenceScreenKey.key.evidenceLevel = EVIDENCELEVEL.EVIDENCE;

    // Read list of evidence screen details
    listEvidenceScreenDetails = evidenceScreenObj.list(listEvidenceScreenKey);

    // Evidence page manipulation variables
    EvidencePageDetails evidencePageDetails;

    // Reserve capacity in return object
    listEvidencePageDetails.detailsList.dtls.ensureCapacity(
      listEvidenceScreenDetails.detailsList.dtls.size());

    for (int i = 0; i < listEvidenceScreenDetails.detailsList.dtls.size(); i++) {

      evidencePageDetails = new EvidencePageDetails();

      evidencePageDetails.assign(
        listEvidenceScreenDetails.detailsList.dtls.item(i));

      listEvidencePageDetails.detailsList.dtls.addRef(evidencePageDetails);
    }

    // Set key to read product context description
    productContextDescriptionKey.productID = key.key.key.relatedID;

    // Read product context description
    productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    // Assign product context description
    listEvidencePageDetails.contextDescription.description = productContextDescriptionDetails.description;

    return listEvidencePageDetails;
  }

  /**
   * Reads list of site map details.
   *
   * @param key
   * Key to read list of site map details.
   *
   * @return List of site map details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListSiteMapDetails listSiteMap(ListSiteMapKey key)
    throws AppException, InformationalException {

    // Create return object
    ListSiteMapDetails listSiteMapDetails = new ListSiteMapDetails();

    // EvidenceScreen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    ListEvidenceScreenKey listEvidenceScreenKey = new ListEvidenceScreenKey();
    ListEvidenceScreenDetails listEvidenceScreenDetails;

    // Product context description variables
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();
    ProductContextDescriptionDetails productContextDescriptionDetails;

    // Set key to read list evidence screens
    listEvidenceScreenKey.key.relatedID = key.key.key.relatedID;
    listEvidenceScreenKey.key.evidenceLevel = EVIDENCELEVEL.SITEMAP;

    // Read list of evidence screen details
    listEvidenceScreenDetails = evidenceScreenObj.list(listEvidenceScreenKey);

    // Site Map manipulation variables
    SiteMapDetails siteMapDetails;

    // Reserve capacity in return object
    listSiteMapDetails.detailsList.dtls.ensureCapacity(
      listEvidenceScreenDetails.detailsList.dtls.size());

    for (int i = 0; i < listEvidenceScreenDetails.detailsList.dtls.size(); i++) {

      siteMapDetails = new SiteMapDetails();

      siteMapDetails.assign(listEvidenceScreenDetails.detailsList.dtls.item(i));

      listSiteMapDetails.detailsList.dtls.addRef(siteMapDetails);
    }

    // Set key to read product context description
    productContextDescriptionKey.productID = key.key.key.relatedID;

    // Read product context description
    productContextDescriptionDetails = getProductContextDescription(
      productContextDescriptionKey);

    // Assign product context description
    listSiteMapDetails.contextDescription.description = productContextDescriptionDetails.description;

    return listSiteMapDetails;
  }

  /**
   * Modifies evidence group page details for a Product.
   *
   * @param details
   * Modified evidence group page details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyEvidenceGroupPage(ModifyEvidenceGroupPageDetails details)
    throws AppException, InformationalException {

    // EvidenceScreen business layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    curam.core.sl.struct.ModifyEvidenceGroupPageDetails modifyEvidenceGroupPageDetails = new curam.core.sl.struct.ModifyEvidenceGroupPageDetails();

    // Set key to modify evidence group page details
    modifyEvidenceGroupPageDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Assign details to modify evidence group page
    modifyEvidenceGroupPageDetails.details.assign(details);

    // Call BPO to modify evidence group page
    evidenceScreenObj.modifyEvidenceGroupPage(modifyEvidenceGroupPageDetails);
  }

  /**
   * Modifies evidence page details for a Product.
   *
   * @param details
   * Modified evidence page details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyEvidencePage(ModifyEvidencePageDetails details)
    throws AppException, InformationalException {

    // EvidenceScreen business layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    curam.core.sl.struct.ModifyEvidencePageDetails modifyEvidencePageDetails = new curam.core.sl.struct.ModifyEvidencePageDetails();

    // Set key to modify evidence page details
    modifyEvidencePageDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Assign details to modify evidence page details
    modifyEvidencePageDetails.details.assign(details);

    // Call BPO to modify evidence page details
    evidenceScreenObj.modifyEvidencePage(modifyEvidencePageDetails);
  }

  /**
   * Modifies site map page details for a product.
   *
   * @param details
   * Modified site map details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifySiteMap(ModifySiteMapDetails details) throws AppException,
      InformationalException {

    // EvidenceScreen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    curam.core.sl.struct.ModifySiteMapDetails modifySiteMapDetails = new curam.core.sl.struct.ModifySiteMapDetails();

    // Set key to modify site map
    modifySiteMapDetails.key.evidenceScreenID = details.evidenceScreenID;

    // Assign details to modify site map
    modifySiteMapDetails.details.assign(details);

    // Call BPO to modify site map
    evidenceScreenObj.modifySiteMap(modifySiteMapDetails);
  }

  /**
   * Reads evidence group page details.
   *
   * @param key
   * Key to read evidence group page details.
   *
   * @return Evidence group page details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadEvidenceGroupPageDetails readEvidenceGroupPage(
    ReadEvidenceGroupPageKey key) throws AppException, InformationalException {

    // Create return object
    ReadEvidenceGroupPageDetails readEvidenceGroupPageDetails = new ReadEvidenceGroupPageDetails();

    // EvidenceScreen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    ReadEvidenceScreenKey readEvidenceScreenKey = new ReadEvidenceScreenKey();
    ReadEvidenceScreenDetails readEvidenceScreenDetails;

    // Set key to read evidence screen details
    readEvidenceScreenKey.key.evidenceScreenID = key.key.evidenceScreenID;

    // Read evidence screen details
    readEvidenceScreenDetails = evidenceScreenObj.readEvidenceScreenDetails(
      readEvidenceScreenKey);

    // Assign details to return object
    readEvidenceGroupPageDetails.assign(readEvidenceScreenDetails.details);

    return readEvidenceGroupPageDetails;
  }

  /**
   * Reads site map page details.
   *
   * @param key
   * Key to read site map details.
   *
   * @return Site map page details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadSiteMapDetails readSiteMap(ReadSiteMapKey key)
    throws AppException, InformationalException {

    // Create return object
    ReadSiteMapDetails readSiteMapDetails = new ReadSiteMapDetails();

    // EvidenceScreen service layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    ReadEvidenceScreenKey readEvidenceScreenKey = new ReadEvidenceScreenKey();
    ReadEvidenceScreenDetails readEvidenceScreenDetails;

    // Set key to read evidence screen details
    readEvidenceScreenKey.key.evidenceScreenID = key.key.evidenceScreenID;

    // Call BPO to read evidence screen details
    readEvidenceScreenDetails = evidenceScreenObj.readEvidenceScreenDetails(
      readEvidenceScreenKey);

    // Assign details to return object
    readSiteMapDetails.assign(readEvidenceScreenDetails.details);

    return readSiteMapDetails;
  }

  /**
   * Reads evidence page details.
   *
   * @param key
   * Key to read details of the evidence page.
   *
   * @return Evidence page details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadEvidencePageDetails readEvidencePage(ReadEvidencePageKey key)
    throws AppException, InformationalException {

    // Create return object
    ReadEvidencePageDetails readEvidencePageDetails = new ReadEvidencePageDetails();

    // EvidenceScreen business layer objects
    curam.core.sl.intf.EvidenceScreen evidenceScreenObj = curam.core.sl.fact.EvidenceScreenFactory.newInstance();
    ReadEvidenceScreenKey readEvidenceScreenKey = new ReadEvidenceScreenKey();
    ReadEvidenceScreenDetails readEvidenceScreenDetails;

    // Set key to read evidence screen details
    readEvidenceScreenKey.key.evidenceScreenID = key.key.evidenceScreenID;

    // Call BPO to read evidence screen details
    readEvidenceScreenDetails = evidenceScreenObj.readEvidenceScreenDetails(
      readEvidenceScreenKey);

    // Assign details to return object
    readEvidencePageDetails.assign(readEvidenceScreenDetails.details);

    return readEvidencePageDetails;
  }

  /**
   * Cancels a product time constraint record.
   *
   * @param key
   * Identifies the product time constraint record to be canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelProductTimeConstraint(CancelProductTimeConstraint key)
    throws AppException, InformationalException {

    // product time constraint business object
    curam.core.sl.intf.ProductTimeConstraint productTimeConstraintObj = curam.core.sl.fact.ProductTimeConstraintFactory.newInstance();

    // cancel the time constraint
    productTimeConstraintObj.cancelProductTimeConstraint(
      key.cancelProductTimeConstraint);
  }

  /**
   * Creates a product time constraint record.
   *
   * @param dtls
   * Details of the product time constraint to be created.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createProductTimeConstraint(CreateProductTimeConstraint dtls)
    throws AppException, InformationalException {

    // product time constraint business object
    curam.core.sl.intf.ProductTimeConstraint productTimeConstraintObj = curam.core.sl.fact.ProductTimeConstraintFactory.newInstance();

    CreateProductTimeConstraintDetails createProductTimeConstraintDetails = new CreateProductTimeConstraintDetails();

    // assign time constraint dtls
    createProductTimeConstraintDetails.assign(dtls.productTimeConstraintDtls);

    // create the product time constraint
    productTimeConstraintObj.createProductTimeConstraint(
      createProductTimeConstraintDetails);
  }

  /**
   * Returns a list of Product Time Constraint records.
   *
   * @param key
   * Identifies the product time constraint to be read.
   *
   * @return Details of the product time constraint record.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProductTimeConstraint listProductTimeConstaint(
    ReadProductTimeConstraintRMKey key) throws AppException,
      InformationalException {

    // create a return object
    ListProductTimeConstraint listProductTimeConstraint = new ListProductTimeConstraint();

    // product time constraint business object and key
    curam.core.sl.intf.ProductTimeConstraint productTimeConstraintObj = curam.core.sl.fact.ProductTimeConstraintFactory.newInstance();

    // list product time constraints
    listProductTimeConstraint.productTimeConstraintListDtls = productTimeConstraintObj.listProductTimeConstraints(
      key.readMultiKey);

    // ProductContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    productContextDescriptionKey.productID = key.readMultiKey.key.productID;

    listProductTimeConstraint.description = getProductContextDescription(
      productContextDescriptionKey);

    return listProductTimeConstraint;
  }

  /**
   * Modifies details of a product time constraint record.
   *
   * @param dtls
   * Details of the product time constraint record to be modified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyProductTimeConstraint(ModifyProductTimeConstraint dtls)
    throws AppException, InformationalException {

    // product time constraint business object
    curam.core.sl.intf.ProductTimeConstraint productTimeConstraintObj = curam.core.sl.fact.ProductTimeConstraintFactory.newInstance();

    // modify the product time constraint
    productTimeConstraintObj.modifyProductTimeConstraint(
      dtls.productTimeConstraintDtls);
  }

  /**
   * Modifies details of a product time constraint record.
   *
   * @param key
   * Identifies the ad hoc bonus criteria to be read.
   *
   * @return read product time constraint.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadProductTimeConstraint readProductTimeConstraint(
    ProductTimeConstraintKey key) throws AppException, InformationalException {

    // create a return object
    ReadProductTimeConstraint readProductTimeConstraint = new ReadProductTimeConstraint();

    // product time constraint business object and key.
    curam.core.sl.intf.ProductTimeConstraint productTimeConstraintObj = curam.core.sl.fact.ProductTimeConstraintFactory.newInstance();

    // read the product time constraint
    readProductTimeConstraint.productTimeConstraintDtls = productTimeConstraintObj.readProductTimeConstraint(
      key.timeConstraintKey);

    // ProductContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    productContextDescriptionKey.productID = readProductTimeConstraint.productTimeConstraintDtls.details.details.productID;

    readProductTimeConstraint.description = getProductContextDescription(
      productContextDescriptionKey);

    return readProductTimeConstraint;
  }

  // BEGIN, CR00312643, SG
  /**
   * This method exists for customers to implement using 'sub classing with
   * replacement'.
   *
   * @param key Concern Role identifier for a client
   *
   * @return Active products for a client
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListActiveBenefitProductsForPersonDetails listActiveBenefitProductsForPerson(
    final ListActiveBenefitProductsForPersonKey key) throws AppException,
      InformationalException {

    return productIntfMap.get("PRODUCT").listActiveBenefitProductsForPerson(key);
  }

  /**
   * This method exists for customers to implement using 'sub classing with
   * replacement'.
   *
   * @param key Identifier for a product provider.
   *
   * @return List of provider locations.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListLocationForProviderDetails listLocationForProvider(
    final ListLocationForProviderKey key) throws AppException,
      InformationalException {

    return productIntfMap.get("PRODUCT").listLocationForProvider(key);
    
  }

  /**
   * This method exists for customers to implement using 'sub classing with
   * replacement'.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void readRuleSet() throws AppException, InformationalException {
    
    productIntfMap.get("PRODUCT").readRuleSet();
    
  }

  // END, CR00312643

  /**
   * Returns a list of benefit products applicable to concern roles of type
   * Person.
   *
   * @return List of benefit products applicable to concern roles of type
   * Person.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProductDetailsStruct listBenefitProductsForTypePerson()
    throws AppException, InformationalException {

    // Create return object
    ListProductDetailsStruct listProductDetailsStruct;

    // Call local method to retrieve list of benefit products
    listProductDetailsStruct = listAllBenefitProducts();

    // Filter products
    curam.core.sl.fact.CaseFactory.newInstance().filterProductsForTypePerson(
      listProductDetailsStruct);

    return listProductDetailsStruct;
  }

  /**
   * Returns a list of liability products applicable to concern roles of type
   * Person.
   *
   * @return List of liability products applicable to concern roles of type
   * Person.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProductDetailsStruct listLiabilityProductsForTypePerson()
    throws AppException, InformationalException {

    // Create return object
    ListProductDetailsStruct listProductDetailsStruct = new ListProductDetailsStruct();

    // BEGIN, CR00080479, CW
    // Call local method to retrieve list of enabled liability products
    listProductDetailsStruct = listAllEnabledLiabilityProducts();
    // END, CR00080479

    // Filter products
    curam.core.sl.fact.CaseFactory.newInstance().filterProductsForTypePerson(
      listProductDetailsStruct);

    return listProductDetailsStruct;
  }

  /**
   * Returns a list of products of a specified category and applicable to
   * concerns of type Person.
   *
   * @param key
   * Key to return list of products
   * @return List of products
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProductDetailsStruct listProductsForCategoryAndPerson(
    ListProductsForCategoryKey key) throws AppException,
      InformationalException {

    // Create return object
    ListProductDetailsStruct listProductDetailsStruct = new ListProductDetailsStruct();

    // Call local method to retrieve list of benefit products
    listProductDetailsStruct = listProductsForCategory(key);

    // BEGIN CR00096042, GBA
    // Filter products
    curam.core.sl.fact.CaseFactory.newInstance().filterProductsForTypePerson(
      listProductDetailsStruct);
    // END CR00096042

    return listProductDetailsStruct;
  }

  /**
   * Sets a Evidence Metadata entry status to cancelled
   *
   * @param details
   * struct containing the record status and version no
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelEvidenceMetadata(
    EvidenceMetadataRecordStatusVersionNo details) throws AppException,
      InformationalException {

    // Call the service layer cancel operation
    EvidenceMetadataFactory.newInstance().cancel(details.details);
  }

  /**
   * Operation to create an Evidence Metadata entry
   *
   * @param details
   * Evidence metadata details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createEvidenceMetadata(EvidenceMetadataDetails details)
    throws AppException, InformationalException {

    if (details.productID == 0) {

      // call the service layer insert operation
      EvidenceMetadataFactory.newInstance().insert(details.details);

    } else {

      // ProductKey
      ProductKey productKey = new ProductKey();

      productKey.productID = details.productID;

      // call the service layer insert and create link operation
      EvidenceMetadataFactory.newInstance().insertAndCreateProductLink(
        details.details, productKey);
    }

  }

  /**
   * Modifies an Evidence Metadata entry
   *
   * @param details
   * Modified Evidence Metadata details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyEvidenceMetadata(EvidenceMetadataDetails details)
    throws AppException, InformationalException {

    // Call the service layer modify operation
    EvidenceMetadataFactory.newInstance().modify(details.details);
  }

  /**
   * Retrieves details of a single Evidence Metadata entry
   *
   * @param key
   * Evidence Metadata entity key
   *
   * @return Evidence Metadata details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public EvidenceMetadataDetails readEvidenceMetadata(
    curam.core.sl.infrastructure.entity.struct.EvidenceMetadataKey key)
    throws AppException, InformationalException {

    // Create return object
    EvidenceMetadataDetails evidenceMetadataDetails = new EvidenceMetadataDetails();

    // Call the service layer read operation
    evidenceMetadataDetails.details = EvidenceMetadataFactory.newInstance().read(
      key);

    return evidenceMetadataDetails;
  }

  /**
   * Retrieves a list of all Evidence Metadata entries
   *
   * @return EvidenceMetadataDetailsList A list of all Evidence Metadata records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public EvidenceMetadataDetailsList listEvidenceMetadata()
    throws AppException, InformationalException {

    // Create return object
    EvidenceMetadataDetailsList evidenceMetadataDetailsList = new EvidenceMetadataDetailsList();

    // Call the service layer list operation
    evidenceMetadataDetailsList.list = EvidenceMetadataFactory.newInstance().list();

    return evidenceMetadataDetailsList;
  }

  /**
   * Creates a ProductEvidenceLink record
   *
   * @param dtls
   * Details to create a ProductEvidenceLink record
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createProductEvidenceLink(ProductEvidenceLinkDetails dtls)
    throws AppException, InformationalException {

    // Call the service layer create operation
    ProductEvidenceLinkFactory.newInstance().create(dtls.details);
  }

  /**
   * Deletes a ProductEvidenceLink record
   *
   * @param key
   * Contains the unique identifier of the record to be (physically)
   * deleted
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteProductEvidenceLink(
    ProductEvidenceLinkAndEvidenceTypeKey key) throws AppException,
      InformationalException {

    // Call the service layer remove operation
    ProductEvidenceLinkFactory.newInstance().remove(key);
  }

  /**
   * Lists all evidence types linked to a specified product.
   *
   * @param key
   * Product entity key
   *
   * @return EvidenceMetadataDetailsList A list of all the currently active
   * Evidence Metadata records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProductEvidenceTypeDetails listProductEvidenceLink(ProductKey key)
    throws AppException, InformationalException {

    // Create return object
    ProductEvidenceTypeDetails productEvidenceTypeDetails = new ProductEvidenceTypeDetails();

    // Call the service layer list operation
    productEvidenceTypeDetails.list = ProductEvidenceLinkFactory.newInstance().listByProductID(
      key);

    return productEvidenceTypeDetails;
  }

  /**
   * Lists all currently active Evidence Metadata entries
   *
   * @param key
   * product key
   *
   * @return EvidenceMetadataDetailsList A list of all currently active Evidence
   * Metadata records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public EvidenceMetadataDetailsList listCurrentActiveEvidenceMetadata(
    ProductKey key) throws AppException, InformationalException {

    // Create return object
    EvidenceMetadataDetailsList evidenceMetadataDetailsList = new EvidenceMetadataDetailsList();

    // Call the service layer listCurrentActive operation
    evidenceMetadataDetailsList.list = EvidenceMetadataFactory.newInstance().listActive(
      key);

    return evidenceMetadataDetailsList;
  }

  /**
   * Associates one or more deductions with a product
   *
   * @param key
   * Tab-delimited string list of deductionID's and the productID
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addDeductionProductLink(AddDeductionKey key) throws AppException,
      InformationalException {

    // Create service layer class
    DeductionProductLink deductionProductLinkObj = DeductionProductLinkFactory.newInstance();

    // Associate the deduction(s) with a product
    deductionProductLinkObj.addDeduction(key.key);

  }

  /**
   * Creates a new deduction and also associates that deduction with a product
   *
   * @param details
   * Details needed to create a deduction and a deduction product link
   * record
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createDeductionAndProductLink(
    CreateDeductionAndProductLinkDetails details) throws AppException,
      InformationalException {

    // Create service layer class
    Resource resourceObj = ResourceFactory.newInstance();

    // Details struct needed to create a deduction record
    CreateDeductionDtls createDeductionDtls = new CreateDeductionDtls();

    // Details struct needed to create a deduction product link record
    CreateDeductionProductLinkDetails createDeductionProductLinkDetails = new CreateDeductionProductLinkDetails();

    // Set the details
    createDeductionDtls.dtls = details.deductionDtls.dtls;

    // Create a deduction record
    resourceObj.createDeduction(createDeductionDtls);

    // Populate struct to create deduction product link record
    createDeductionProductLinkDetails.deductionDtls.deductionID = details.deductionDtls.dtls.dtls.deductionID;
    createDeductionProductLinkDetails.deductionDtls.productID = details.deductionDtls.productDtls.productID;
    createDeductionProductLinkDetails.deductionDtls.priority = details.deductionDtls.dtls.dtls.priority;
    createDeductionProductLinkDetails.deductionDtls.nextPriorityInd = details.deductionDtls.dtls.nextPriority.applyNextPriorityInd;
    // BEGIN, CR00285981, ZV
    createDeductionProductLinkDetails.deductionDtls.preventOverlappingIndOpt = details.deductionDtls.dtls.dtls.preventOverlappingInd;
    // END, CR00285981

    // Create a deduction product link record
    createDeductionProductLink(createDeductionProductLinkDetails);
  }

  /**
   * Creates an association between a deduction and a product.
   *
   * @param details
   * Details needed to create a deduction product link record
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createDeductionProductLink(
    CreateDeductionProductLinkDetails details) throws AppException,
      InformationalException {

    // Create service layer class
    DeductionProductLink deductionProductLinkObj = DeductionProductLinkFactory.newInstance();

    // Create a deduction product link record
    deductionProductLinkObj.create(details.deductionDtls);

  }

  // BEGIN, CR00243704, KX
  /**
   * Returns a list of deductions for a product.
   *
   * This method replaces the deprecated method {@link #listDeduction()}
   *
   * @param key
   * Product Key Details
   *
   * @return List of all deductions currently associated with a product The
   * context description is also returned
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public DeductionProductLinkWithVersionNoDetailsList listDeductionWithVersionNo(
    ProductKey key) throws AppException, InformationalException {
    // Create service layer class
    DeductionProductLink deductionProductLinkObj = DeductionProductLinkFactory.newInstance();

    // Create return object
    DeductionProductLinkWithVersionNoDetailsList deductionProductLinkDetailsList = new DeductionProductLinkWithVersionNoDetailsList();

    // ProductContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Set key for read
    productContextDescriptionKey.productID = key.productID;

    // Call local method to retrieve context description
    deductionProductLinkDetailsList.contextDescription = getProductContextDescription(
      productContextDescriptionKey);

    // Return a list of deductions associated with a product
    deductionProductLinkDetailsList.deductionDtlsList = deductionProductLinkObj.listDeductionWithVersionNo(
      key);

    return deductionProductLinkDetailsList;
  }

  /**
   * @param key
   * Product Key Details
   *
   * @return List of all deductions currently associated with a product The
   * context description is also returned
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link #listDeductionWithVersionNo()}. As part of the new API
   * versionNo fields must be returned in lists which allow items to
   * be deleted See release note: CR00243704.
   *
   * Returns a list of deductions for a product.
   */
  @Deprecated
  public DeductionProductLinkDetailsList listDeduction(ProductKey key)
    throws AppException, InformationalException {

    // Create service layer class
    DeductionProductLinkDetailsList deductionProductLinkDetailsList = new DeductionProductLinkDetailsList();
    DeductionProductLinkWithVersionNoDetailsList deductionProductLinkWithVersionNoDetailsList = listDeductionWithVersionNo(
      key);

    deductionProductLinkDetailsList.assign(
      deductionProductLinkWithVersionNoDetailsList);
    return deductionProductLinkDetailsList;
  }

  // END, CR00243704, KX

  /**
   * Returns a list of active deductions not associated with a product.
   *
   * @param key
   * Product Key Details
   *
   * @return List of all deductions not currently associated with a product The
   * context description is also returned
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public UnassociatedDeductionDetailsList listUnassociatedDeduction(
    ProductKey key) throws AppException, InformationalException {

    // Create service layer class
    DeductionProductLink deductionProductLinkObj = DeductionProductLinkFactory.newInstance();

    // Create return object
    UnassociatedDeductionDetailsList unassociatedDeductionDetailsList = new UnassociatedDeductionDetailsList();

    // ProductContextDescriptionKey object
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Set key for read
    productContextDescriptionKey.productID = key.productID;

    // Call local method to retrieve context description
    unassociatedDeductionDetailsList.contextDescription = getProductContextDescription(
      productContextDescriptionKey);

    // Return a list of unassociated deductions
    unassociatedDeductionDetailsList.deductionDtlsList = deductionProductLinkObj.listUnassociatedDeduction(
      key);

    return unassociatedDeductionDetailsList;
  }

  // BEGIN, CR00285981, ZV
  /**
   * Modifies the priority for a deduction product link record.
   *
   * @param details
   * Details needed to modify a deduction priority
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced by {@link #modifyDeduction()}.
   */
  @Deprecated
  public void modifyDeductionPriority(ModifyDeductionPriorityDetails details)
    throws AppException, InformationalException {

    // Create service layer class
    DeductionProductLink deductionProductLinkObj = DeductionProductLinkFactory.newInstance();

    // Modify priority for a deduction
    deductionProductLinkObj.modifyPriority(details.deductionDtls);

  }

  // END, CR00285981

  /**
   * Reads deduction details to modify deduction priority.
   *
   * @param key
   * The key of the deduction product link record to be read
   *
   * @return Details needed to display modify page
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadModifyDeductionPriorityDetails readModifyDeductionDetails(
    DeductionProductLinkKey key) throws AppException, InformationalException {

    // Create service layer class
    DeductionProductLink deductionProductLinkObj = DeductionProductLinkFactory.newInstance();

    // Create return object
    ReadModifyDeductionPriorityDetails readModifyDeductionPriorityDetails = new ReadModifyDeductionPriorityDetails();

    // Read back details
    readModifyDeductionPriorityDetails.modifyDtls = deductionProductLinkObj.readModifyDeductionDetails(
      key.key);

    return readModifyDeductionPriorityDetails;

  }

  /**
   * Removes a deduction product link record
   *
   * @param key
   * The key of the deduction product link record to be removed
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void removeDeduction(DeductionProductLinkKey key) throws AppException,
      InformationalException {

    // Create service layer class
    DeductionProductLink deductionProductLinkObj = DeductionProductLinkFactory.newInstance();

    // Remove deduction product link record
    deductionProductLinkObj.remove(key.key);

  }

  /**
   * Returns a list of evidence types associated with a specified product.
   *
   * @param key
   * Product entity key
   * @return List of evidence types
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public EvidenceTypeList listEvidenceTypesForCreateByProductID(ProductKey key)
    throws AppException, InformationalException {

    return TemporalEvidenceApprovalCheckFactory.newInstance().listEvidenceTypesForCreateByProduct(
      key);

  }

  /**
   * Creates a Temporal Evidence Approval Check for each evidence type specified
   * in the input list.
   *
   * @param dtls
   * Common details for each entry
   * @param list
   * List of evidence types
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createMultipleTemporalEvApprovalCheck(
    PercentageAndCommentsDetails dtls, EvidenceListDetails list)
    throws AppException, InformationalException {

    // Tab list variable
    EvidenceTypeTabList evidenceTypeTabList = new EvidenceTypeTabList();

    // evidenceList
    StringList evidenceList = StringUtil.tabText2StringList(
      list.details.evidenceList);

    for (int i = 0; i < evidenceList.size(); i++) {

      EvidenceType evidenceType = new EvidenceType();

      evidenceType.typeCodeValue = evidenceList.item(i).toString();
      evidenceTypeTabList.list.add(evidenceType);
    }

    // Call service layer operation to insert checks for each evidence type
    // selected.
    TemporalEvidenceApprovalCheckFactory.newInstance().insertChecksForProduct(
      dtls.details, evidenceTypeTabList);
  }

  /**
   * Returns a list of products which share evidence with the product specified
   * in the input key.
   *
   * @param key
   * Search key containing the evidenceType and ProductID
   * @return List of product names and productIDs
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProductNameList listProductsSharingEvidence(
    ProductIDEvidenceTypeAndRecStatusKey key) throws AppException,
      InformationalException {

    // Return object
    ProductNameList productNameList = new ProductNameList();

    key.recordStatus = RECORDSTATUS.NORMAL;

    productNameList.list = TemporalEvidenceApprovalCheckFactory.newInstance().listProductsSharingEvidence(
      key);

    return productNameList;
  }

  /**
   * Returns details of a single Temporal Evidence Approval Check
   *
   * @param key
   * Contains a Temporal Evidence Approval Check entity key
   *
   * @return details of Temporal Evidence Approval Check
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewTemporalEvidenceApprovalCheck readTemporalEvidenceApprovalCheck(
    TemporalEvidenceApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return object
    ViewTemporalEvidenceApprovalCheck viewTemporalEvidenceApprovalCheck = new ViewTemporalEvidenceApprovalCheck();

    TemporalEvidenceApprovalCheckDetails temporalEvidenceApprovalCheckDetails = new TemporalEvidenceApprovalCheckDetails();

    // Call service layer operation to read Temporal Evidence Approval Check
    // details
    temporalEvidenceApprovalCheckDetails.details = TemporalEvidenceApprovalCheckFactory.newInstance().read(
      key.key);

    viewTemporalEvidenceApprovalCheck.assign(
      temporalEvidenceApprovalCheckDetails.details.dtls);

    return viewTemporalEvidenceApprovalCheck;
  }

  /**
   * Cancels a single Temporal Evidence Approval Check.
   *
   * @param key
   * Contains a Temporal Evidence Approval Check entity key
   * @param dtls
   * Modify Temporal Evidence Approval Check details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelTemporalEvidenceApprovalCheck(
    TemporalEvidenceApprovalCheckKey key,
    ModifyTemporalEvidenceApprovalCheck dtls) throws AppException,
      InformationalException {

    CancelTemporalEvidenceApprovalCheck cancelTemporalEvidenceApprovalCheck = new CancelTemporalEvidenceApprovalCheck();

    cancelTemporalEvidenceApprovalCheck.key = key.key.key;

    cancelTemporalEvidenceApprovalCheck.dtls.recordStatus = dtls.recordStatus;
    cancelTemporalEvidenceApprovalCheck.dtls.versionNo = dtls.versionNo;

    // Calls the service layer operation to cancel a Temporal Evidence Approval
    // Check
    TemporalEvidenceApprovalCheckFactory.newInstance().cancel(
      cancelTemporalEvidenceApprovalCheck);
  }

  /**
   * Modifies details of a single Temporal Evidence Approval Check
   *
   * @param details
   * Modified Temporal Evidence Approval Check details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyTemporalEvidenceApprovalCheck(
    ModifyTemporalEvidenceApprovalCheck details) throws AppException,
      InformationalException {

    TemporalEvidenceApprovalCheckDetails temporalEvidenceApprovalCheckDetails = new TemporalEvidenceApprovalCheckDetails();

    TemporalEvidenceApprovalCheckKey temporalEvidenceApprovalCheckKey = new TemporalEvidenceApprovalCheckKey();

    temporalEvidenceApprovalCheckKey.key.key.temporalEvApprovalCheckID = details.temporalEvApprovalCheckID;

    temporalEvidenceApprovalCheckDetails.details = TemporalEvidenceApprovalCheckFactory.newInstance().read(
      temporalEvidenceApprovalCheckKey.key);

    temporalEvidenceApprovalCheckDetails.details.dtls.assign(details);

    // Call service layer operation to modify a Temporal Evidence Approval Check
    TemporalEvidenceApprovalCheckFactory.newInstance().modify(
      temporalEvidenceApprovalCheckDetails.details);
  }

  /**
   * Lists evidence types that are related to a specified product.
   *
   * @param key
   * Search key containing the productID
   * @return List of the related evidence types
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public curam.core.facade.struct.EvidenceTypeList listEvidenceTypesByProductID(
    ProductIDAndRecordStatusKey key) throws AppException,
      InformationalException {

    // Return object
    curam.core.facade.struct.EvidenceTypeList evidenceTypeList = new curam.core.facade.struct.EvidenceTypeList();

    if (key.productID == 0) {

      evidenceTypeList.evidenceList.evidenceList.addAll(
        OrganizationFactory.newInstance().listEvidenceTypes().dtls);

    } else {

      evidenceTypeList.evidenceList = TemporalEvidenceApprovalCheckFactory.newInstance().listEvidenceTypesByProduct(
        key);

      for (int i = 0; i < evidenceTypeList.evidenceList.evidenceList.size(); i++) {
        // BEGIN, CR00163098, JC
        evidenceTypeList.evidenceList.evidenceList.item(i).evidenceDescription = CodeTable.getOneItem(
          TEMPORAL_EVIDENCE_TYPE_APPROVAL.TABLENAME,
          evidenceTypeList.evidenceList.evidenceList.item(i).typeCodeValue,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    }

    int numTypes = evidenceTypeList.evidenceList.evidenceList.size();

    for (int i = 0; i < numTypes; i++) {

      evidenceTypeList.evidenceList.evidenceList.item(i).typeCodeString = evidenceTypeList.evidenceList.evidenceList.item(i).typeCodeValue;
    }

    return evidenceTypeList;
  }

  /**
   * Reads the product type for a specified product
   *
   * @param key
   * Contains a product identifier
   * @return Product type
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProductTypeCodeIn readProductTypeByProductID(ProductKeyStruct key)
    throws AppException, InformationalException {

    return AdminProductFactory.newInstance().readProductTypeByProductID(key);
  }

  // BEGIN, CR00017391, CM
  /**
   * Sets issue resolution link record to status "Canceled".
   *
   * @param key
   * The key identifying the record to be cancelled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelIssueResolutionLink(IssueResolutionLinkKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00032499, CSH
    // Issue Resolution Link Business object
    curam.core.sl.intf.IssueResolutionLink issueResolutionLinkObj = curam.core.sl.fact.IssueResolutionLinkFactory.newInstance();

    // END, CR00032499

    // cancel issue resolution link
    issueResolutionLinkObj.cancelIssueResolutionLink(key.key);

  }

  /**
   * Creates an existing resolution for an issue.
   *
   * @param dtls
   * details for the creation of the resolution configuration for the
   * issue.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createResolutionForIssue(IssueResolutionLinkDtls dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00032499, CSH
    // Issue Resolution Link Business object
    curam.core.sl.intf.IssueResolutionLink issueResolutionLinkObj = curam.core.sl.fact.IssueResolutionLinkFactory.newInstance();

    // END, CR00032499

    issueResolutionLinkObj.createResolutionForIssue(dtls.dtls);

  }

  // BEGIN, CR00018821, CSH
  /**
   * Reads a resolution configuration record.
   *
   * @param key
   * The key for the record to be read.
   *
   * @return details of resolution configuration.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public ResolutionConfigurationDtls readResolutionConfiguration(
    ResolutionConfigurationKey key) throws AppException,
      InformationalException {

    // Resolution configuration business process object.
    curam.core.sl.intf.ResolutionConfiguration resolutionConfigurationObj = curam.core.sl.fact.ResolutionConfigurationFactory.newInstance();

    // Return object.
    ResolutionConfigurationDtls resolutionConfigurationDtls = new ResolutionConfigurationDtls();

    // BEGIN, CR00029582, CSH
    // Retrieve resolution configuration details.
    resolutionConfigurationDtls.dtls = resolutionConfigurationObj.read(key);
    // END, CR00029582

    // Return the details.
    return resolutionConfigurationDtls;
  }

  /**
   * Modifies a resolution configuration record.
   *
   * @param details
   * The modification details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyResolutionConfiguration(ResolutionConfigurationDtls details)
    throws AppException, InformationalException {

    // Resolution configuration business process object.
    curam.core.sl.intf.ResolutionConfiguration resolutionConfigurationObj = curam.core.sl.fact.ResolutionConfigurationFactory.newInstance();

    // Update resolution configuration details.
    resolutionConfigurationObj.modify(details.dtls);

  }

  // END, CR00018821

  // BEGIN, CR00029582, CSH
  /**
   * Displays a List of resolution configurations already associated with a
   * specified issue type.
   *
   * @param key
   * issue configuration key.
   *
   * @return List of resolution for issue details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public IssueResLinkIDResolutionDtlsList listResolutionsForIssue(
    IssueConfigurationKey key) throws AppException, InformationalException {

    // BEGIN, CR00032499, CSH
    // Issue Resolution Link Business object
    curam.core.sl.intf.IssueResolutionLink issueResolutionLinkObj = curam.core.sl.fact.IssueResolutionLinkFactory.newInstance();
    // END, CR00032499

    // create return struct
    IssueResLinkIDResolutionDtlsList issueResLinkIDResolutionDtlsList = new IssueResLinkIDResolutionDtlsList();

    issueResLinkIDResolutionDtlsList.dtlsList = issueResolutionLinkObj.listResolutionForIssue(
      key);

    // IssueTypeContextDescriptionKey object
    IssueTypeContextDescriptionKey issueTypeContextDescriptionKey = new IssueTypeContextDescriptionKey();

    issueTypeContextDescriptionKey.issueConfigurationID = key.issueConfigurationID;

    // Retrieve the Issue Type Context Description using the context key.
    issueResLinkIDResolutionDtlsList.listIssueResLinkContextDescriptionDetails = getIssueTypeContextDescription(
      issueTypeContextDescriptionKey);

    return issueResLinkIDResolutionDtlsList;

  }

  /**
   * Creates a new resolution configuration.
   *
   * @param dtls
   * Details for the creation of the resolution configuration
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createResolutionConfiguration(ResolutionConfigurationDtls dtls)
    throws AppException, InformationalException {

    // Resolution configuration business process object.
    curam.core.sl.intf.ResolutionConfiguration resolutionConfigurationObj = curam.core.sl.fact.ResolutionConfigurationFactory.newInstance();

    // create resolution configuration details
    resolutionConfigurationObj.create(dtls.dtls);

  }

  // END, CR00029582

  /**
   * Lists resolution configurations for a given day.
   *
   * @return List of resolution configuration details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ResolutionConfigurationDtlsList listResolutionConfiguration()
    throws AppException, InformationalException {

    // BEGIN, CR00032499, CSH
    // Resolution Configuration Business object
    curam.core.sl.intf.ResolutionConfiguration resolutionConfigurationObj = curam.core.sl.fact.ResolutionConfigurationFactory.newInstance();
    // END, CR00032499

    // create return struct
    ResolutionConfigurationDtlsList resolutionConfigurationDtlsList = new ResolutionConfigurationDtlsList();

    // call service layer for list
    resolutionConfigurationDtlsList.dtlsList = resolutionConfigurationObj.list();

    return resolutionConfigurationDtlsList;
  }

  /**
   * Removes physically a resolution configuration.
   *
   * @param key
   * Resolution Configuration key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void removeResolutionConfiguration(ResolutionConfigurationKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00032499, CSH
    // Resolution Configuration Business object
    curam.core.sl.intf.ResolutionConfiguration resolutionConfigurationObj = curam.core.sl.fact.ResolutionConfigurationFactory.newInstance();

    // END, CR00032499

    // BEGIN, CR00029582, CSH
    // remove resolution configuration record
    resolutionConfigurationObj.remove(key);
    // END, CR00029582

  }

  /**
   * Lists unassigned resolution configurations.
   *
   * @param key
   * issue configuration key.
   *
   * @return List of unassigned resolution configuration details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ResolutionConfigurationDtlsList listUnassignedResolutionDetails(
    IssueConfigurationKey key) throws AppException, InformationalException {

    // BEGIN, CR00105577, MC
    // Issue Resolution Configuration Link Business object
    curam.core.sl.intf.IssueResolutionLink issueResolutionLinkObj = curam.core.sl.fact.IssueResolutionLinkFactory.newInstance();

    // create return struct
    ResolutionConfigurationDtlsList resolutionConfigurationDtlsList = new ResolutionConfigurationDtlsList();

    // call service layer for list unassigned resolutions
    resolutionConfigurationDtlsList.dtlsList = issueResolutionLinkObj.listUnassignedResolutionsForIssue(
      key);
    // END, CR00105577

    return resolutionConfigurationDtlsList;
  }

  /**
   * Reads resolution context description.
   *
   * @param key
   * Contains resolution configuration id key.
   *
   * @return Resolution Configuration Context Description details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ResolutionContextDescription getResolutionContextDescription(
    curam.core.sl.entity.struct.ResolutionConfigurationKey key)
    throws AppException, InformationalException {

    // return value
    ResolutionContextDescription resolutionContextDescription = new ResolutionContextDescription();

    // Product manipulation variables
    // BEGIN, CR00032499, CSH
    curam.core.sl.entity.intf.ResolutionConfiguration resolutionConfigurationEntObj = curam.core.sl.entity.fact.ResolutionConfigurationFactory.newInstance();
    // END, CR00032499
    curam.core.sl.entity.struct.ResolutionConfigurationKey resolutionConfigurationKey = new curam.core.sl.entity.struct.ResolutionConfigurationKey();
    curam.core.sl.entity.struct.ResolutionNameStruct resolutionNameStruct = new curam.core.sl.entity.struct.ResolutionNameStruct();

    // BEGIN, CR00029582, CSH
    // Set key to read resolution
    resolutionConfigurationKey.resolutionConfigurationID = key.resolutionConfigurationID;
    // END, CR00029582

    // Read resolution name code
    resolutionNameStruct = resolutionConfigurationEntObj.readResolutionName(
      resolutionConfigurationKey);

    // Create a localizable string based on the message entry
    LocalisableString contextDescription = new LocalisableString(
      BPORESOLUTIONCONFIGURATION.INF_RESOLUTION_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(RESOLUTIONCONIFIGURATION.TABLENAME,
      resolutionNameStruct.resolution));

    // Populate the context description field with the localizable text
    resolutionContextDescription.description = contextDescription.toClientFormattedText();

    return resolutionContextDescription;

  }

  // END, CR00017391

  // BEGIN, CR00017461, PMD
  /**
   * This method allows an administrator to cancel an Issue Resolution Approval
   * Check for a particular issue.
   *
   * @param key
   * The unique id of the Issue Resolution Approval Check to be
   * canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelResolutionApprovalCheckForIssue(
    CancelIssueResolutionApprovalCheckKey key) throws AppException,
      InformationalException {

    // IssueResolutionApprovalCheck business object
    curam.core.sl.intf.IssueResolutionApprovalCheck issueResolutionApprovalCheckObj = curam.core.sl.fact.IssueResolutionApprovalCheckFactory.newInstance();

    // Call IssueResolutionApprovalCheck BPO to perform the cancel operation
    issueResolutionApprovalCheckObj.cancel(
      key.cancelIssueResolutionApprovalCheckDetails);

  }

  /**
   * This method allows an administrator to configure an approval check for a
   * particular issue. It allows a percentage of resolutions on issues which are
   * submitted for approval to be reviewed.
   *
   * @param details
   * The Issue Resolution Approval Check details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createResolutionApprovalCheckForIssue(
    IssueResolutionApprovalCheckDetails details) throws AppException,
      InformationalException {

    // IssueResolutionApprovalCheck business object
    curam.core.sl.intf.IssueResolutionApprovalCheck issueResolutionApprovalCheckObj = curam.core.sl.fact.IssueResolutionApprovalCheckFactory.newInstance();

    // Call IssueResolutionApprovalCheck BPO to perform the create operation
    issueResolutionApprovalCheckObj.create(
      details.issueResolutionApprovalCheckDetails);

  }

  /**
   * This method lists all existing approval checks for a particular issue.
   *
   * @param key
   * The unique id of the issue that the resolution approval checks are
   * being listed for.
   * @return A list of resolution approval checks for the specified issue.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListIssueResolutionApprovalCheckDetails listResolutionApprovalCheckForIssue(
    IssueConfigurationKey key) throws AppException, InformationalException {

    // Return Object
    ListIssueResolutionApprovalCheckDetails listIssueResolutionApprovalCheckDetails = new ListIssueResolutionApprovalCheckDetails();

    // IssueResolutionApprovalCheck business object
    curam.core.sl.intf.IssueResolutionApprovalCheck issueResolutionApprovalCheckObj = curam.core.sl.fact.IssueResolutionApprovalCheckFactory.newInstance();

    // Call IssueResolutionApprovalCheck BPO to perform the list operation
    listIssueResolutionApprovalCheckDetails.issueResolutionApprovalCheckDetailsList = issueResolutionApprovalCheckObj.listResolutionApprovalChecksForIssue(
      key);

    // IssueTypeContextDescriptionKey object
    IssueTypeContextDescriptionKey issueTypeContextDescriptionKey = new IssueTypeContextDescriptionKey();

    issueTypeContextDescriptionKey.issueConfigurationID = key.issueConfigurationID;

    // Retrieve the Issue Type Context Description using the context key.
    listIssueResolutionApprovalCheckDetails.issueTypeContextDescriptionDetails = getIssueTypeContextDescription(
      issueTypeContextDescriptionKey);

    return listIssueResolutionApprovalCheckDetails;
  }

  // BEGIN, CR00219695, JF
  // ___________________________________________________________________________
  /**
   * This method lists all existing approval checks for a particular issue.
   *
   * @param key
   * The unique id of the issue that the resolution approval checks are
   * being listed for.
   * @return A list of resolution approval checks for the specified issue
   * including a versionNo.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListIssueResolutionApprovalCheckDetailsAndVersionNo listResolutionApprovalCheckForIssueAndVersionNo(
    IssueConfigurationKey listIssueResolutionApprovalCheckKey)
    throws AppException, InformationalException {

    // Return Object
    ListIssueResolutionApprovalCheckDetailsAndVersionNo listIssueResolutionApprovalCheckDetailsAndVersionNo = new ListIssueResolutionApprovalCheckDetailsAndVersionNo();

    // IssueResolutionApprovalCheck business object
    curam.core.sl.intf.IssueResolutionApprovalCheck issueResolutionApprovalCheckObj = curam.core.sl.fact.IssueResolutionApprovalCheckFactory.newInstance();

    // Call IssueResolutionApprovalCheck BPO to perform the list operation
    listIssueResolutionApprovalCheckDetailsAndVersionNo.dtls = issueResolutionApprovalCheckObj.listResolutionApprovalChecksForIssueAndVersionNo(
      listIssueResolutionApprovalCheckKey);

    return listIssueResolutionApprovalCheckDetailsAndVersionNo;
  }

  // END, CR00219695, JF

  /**
   * This method allows an administrator to modify an Issue Resolution Approval
   * Check for a particular issue.
   *
   * @param details
   * The issue resolution approval check modified details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyResolutionApprovalCheckForIssue(
    IssueResolutionApprovalCheckDetails details) throws AppException,
      InformationalException {

    // IssueResolutionApprovalCheck business object
    curam.core.sl.intf.IssueResolutionApprovalCheck issueResolutionApprovalCheckObj = curam.core.sl.fact.IssueResolutionApprovalCheckFactory.newInstance();

    // Call IssueResolutionApprovalCheck BPO to perform the modify operation
    issueResolutionApprovalCheckObj.modify(
      details.issueResolutionApprovalCheckDetails);

  }

  /**
   * This method allows an administrator to view a resolution approval check for
   * a particular issue.
   *
   * @param key
   * The unique id of the Issue Resolution Approval Check to be read.
   * @return The resolution approval check details for the specified issue.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadIssueResolutionApprovalCheckDetails readResolutionApprovalCheckForIssue(
    ReadIssueResolutionApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return Object
    ReadIssueResolutionApprovalCheckDetails readIssueResolutionApprovalCheckDetails = new ReadIssueResolutionApprovalCheckDetails();

    // IssueResolutionApprovalCheck business object
    curam.core.sl.intf.IssueResolutionApprovalCheck issueResolutionApprovalCheckObj = curam.core.sl.fact.IssueResolutionApprovalCheckFactory.newInstance();

    // Call IssueResolutionApprovalCheck BPO to perform the read operation
    readIssueResolutionApprovalCheckDetails.readIssueResolutionApprovalCheckDetails = issueResolutionApprovalCheckObj.read(
      key.readIssueResolutionApprovalCheckKey);

    // IssueTypeContextDescriptionKey object
    IssueTypeContextDescriptionKey issueTypeContextDescriptionKey = new IssueTypeContextDescriptionKey();

    issueTypeContextDescriptionKey.issueConfigurationID = readIssueResolutionApprovalCheckDetails.readIssueResolutionApprovalCheckDetails.dtls.issueConfigurationID;

    // Retrieve the Issue Type Context Description using the context key.
    readIssueResolutionApprovalCheckDetails.issueTypeContextDescriptionDetails = getIssueTypeContextDescription(
      issueTypeContextDescriptionKey);

    return readIssueResolutionApprovalCheckDetails;
  }

  /**
   * Operation to read the Issue Type Context Description.
   *
   * @param key
   * The Issue Context Description Key.
   *
   * @return The context description of the issue.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected IssueTypeContextDescriptionDetails getIssueTypeContextDescription(
    IssueTypeContextDescriptionKey key) throws AppException,
      InformationalException {

    // Return Object
    IssueTypeContextDescriptionDetails issueTypeContextDescriptionDetails = new IssueTypeContextDescriptionDetails();

    // Issue Configuration Manipulation variables
    curam.core.sl.entity.intf.IssueConfiguration issueConfigurationObj = curam.core.sl.entity.fact.IssueConfigurationFactory.newInstance();
    curam.core.sl.entity.struct.IssueConfigurationKey issueConfigurationKey = new curam.core.sl.entity.struct.IssueConfigurationKey();

    // Get the issue type
    issueConfigurationKey.issueConfigurationID = key.issueConfigurationID;

    IssueTypeDtls issueTypeDtls = issueConfigurationObj.readIssueType(
      issueConfigurationKey);

    // Create a localizable string based on the message entry
    LocalisableString contextDescription = new LocalisableString(
      BPOISSUERESOLUTIONAPPROVALCHECK.INF_ISSUE_TYPE_CONTEXT_DESCRIPTION);

    // BEGIN, CR00163098, JC
    // Add the code table item to the localizable string
    contextDescription.arg(
      CodeTable.getOneItem(ISSUECONFIGURATIONTYPE.TABLENAME, issueTypeDtls.type,
      TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC

    // Populate the context description field with the localizable text
    issueTypeContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    return issueTypeContextDescriptionDetails;
  }

  // END, CR00017461

  // BEGIN, CR00017538, CSH
  // BEGIN, CR00029582, CSH
  /**
   * Sets the status of an issue configuration to canceled.
   *
   * @param key
   * Details containing key and version number
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelIssueConfiguration(
    curam.core.sl.entity.struct.IssueConfigurationKey key)
    throws AppException, InformationalException {

    // Issue configuration business process object.
    curam.core.sl.intf.IssueConfiguration issueConfigurationObj = curam.core.sl.fact.IssueConfigurationFactory.newInstance();

    // BEGIN, CR00030077, CSH
    // Change the status of the issue configuration record to canceled.
    issueConfigurationObj.cancelIssueConfiguration(key);
    // END, CR00030077
  }

  // END, CR00029582

  /**
   * Creates an issue configuration record.
   *
   * @param details
   * Details to be added
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createIssueConfiguration(IssueConfigurationDetails details)
    throws AppException, InformationalException {

    // Issue configuration business process object.
    curam.core.sl.intf.IssueConfiguration issueConfigurationObj = curam.core.sl.fact.IssueConfigurationFactory.newInstance();

    // Create new issue configuration record.
    issueConfigurationObj.create(details.dtls);
  }

  /**
   * Lists all active and canceled issue configuration records.
   *
   * @return detailsList List of all issue configuration records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public IssueConfigurationDetailsList listAllIssueConfigurations()
    throws AppException, InformationalException {

    // Issue configuration business process object.
    curam.core.sl.intf.IssueConfiguration issueConfigurationObj = curam.core.sl.fact.IssueConfigurationFactory.newInstance();

    // Variable to hold the list.
    IssueConfigurationDetailsList issueConfigurationDetailsList = new IssueConfigurationDetailsList();

    // Populate the list.
    issueConfigurationDetailsList.list = issueConfigurationObj.list();

    // Return the list.
    return issueConfigurationDetailsList;
  }

  /**
   * Modifies the details of an issue configuration record.
   *
   * @param details
   * Details to be modified
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyIssueConfiguration(IssueConfigurationDetails details)
    throws AppException, InformationalException {

    // Issue configuration business process object.
    curam.core.sl.intf.IssueConfiguration issueConfigurationObj = curam.core.sl.fact.IssueConfigurationFactory.newInstance();

    // Update issue configuration details.
    issueConfigurationObj.modify(details.dtls);
  }

  /**
   * Reads the details for an issue configuration record.
   *
   * @param key
   * Search key containing the issueConfigurationID
   * @return details Details of the record that is read
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public IssueConfigurationDetails readIssueConfiguration(
    curam.core.sl.entity.struct.IssueConfigurationKey key)
    throws AppException, InformationalException {

    // Issue configuration business process object.
    curam.core.sl.intf.IssueConfiguration issueConfigurationObj = curam.core.sl.fact.IssueConfigurationFactory.newInstance();

    // Return object.
    IssueConfigurationDetails issueConfigurationDetails = new IssueConfigurationDetails();

    // BEGIN, CR00029582, CSH
    // Retrieve issue configuration details.
    issueConfigurationDetails.dtls = issueConfigurationObj.read(key);
    // END, CR00029582

    // Return the details.
    return issueConfigurationDetails;
  }

  // END, CR00017538
  /**
   * Retrieves the list of Assessment Configuration relationships for the
   * specified Product.
   *
   * @param key
   * The Product Key
   *
   * @return List of Assessment Configuration
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PDAssessmentConfigurationSummaryDetailsList listAssessmentConfigsForProduct(
    ProductKey key) throws AppException, InformationalException {
    // Product Assessment Configuration BPO
    ProductAssessmentConfiguration productAssessmentConfigurationObj = ProductAssessmentConfigurationFactory.newInstance();
    // Return Object
    PDAssessmentConfigurationSummaryDetailsList pdAssessmentConfigurationDetailsList = new PDAssessmentConfigurationSummaryDetailsList();

    // Retrieve the list of Assessment Configurations associated to a product
    pdAssessmentConfigurationDetailsList.list = productAssessmentConfigurationObj.listAssessmentConfigsForProduct(
      key);

    // set the context description key
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    productContextDescriptionKey.productID = key.productID;
    // Get the context description details
    pdAssessmentConfigurationDetailsList.description = getProductContextDescription(
      productContextDescriptionKey);
    return pdAssessmentConfigurationDetailsList;
  }

  /**
   * Creates an PDAssessmentConfiguration record.
   *
   * @param dtls
   * PDAssessmentConfiguration details
   *
   * @return key PDAssessmentConfigurationKey
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public curam.core.facade.struct.PDAssessmentConfigurationKey createPDAssessmentConfiguration(
    CreatePDAssessmentConfigurationDetails dtls) throws AppException,
      InformationalException {
    // Product Assessment Configuration BPO
    ProductAssessmentConfiguration productAssessmentConfigurationObj = ProductAssessmentConfigurationFactory.newInstance();
    // Call the create method
    PDAssessmentConfigurationKey key = productAssessmentConfigurationObj.createPDAssessmentConfiguration(
      dtls.dtls);
    // Return Object
    curam.core.facade.struct.PDAssessmentConfigurationKey pdAssessmentConfigurationKey = new curam.core.facade.struct.PDAssessmentConfigurationKey();

    // Assign the return object
    pdAssessmentConfigurationKey.key.pdAssessmentConfigurationID = key.pdAssessmentConfigurationID;
    return pdAssessmentConfigurationKey;
  }

  /**
   * Modifies an existing PDAssessmentConfiguration record.
   *
   * @param details
   * PDAssessmentConfiguration details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyPDAssessmentConfiguration(
    ModifyPDAssessmentConfigurationDetails details) throws AppException,
      InformationalException {
    // Product Assessment Configuration BPO
    ProductAssessmentConfiguration productAssessmentConfigurationObj = ProductAssessmentConfigurationFactory.newInstance();

    // Call the modify method
    productAssessmentConfigurationObj.modifyPDAssessmentConfiguration(
      details.dtls);
  }

  /**
   * Retrieves a specific relationship details between an Product and an
   * Assessment Configuration.
   *
   * @param key
   * The PDAssessmentConfiguration ID
   *
   * @return The PDAssessmentConfiguration details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PDAssessmentConfigurationDetails readPDAssessmentConfiguration(
    curam.core.facade.struct.PDAssessmentConfigurationKey key)
    throws AppException, InformationalException {
    // Product Assessment Configuration BPO
    ProductAssessmentConfiguration productAssessmentConfigurationObj = ProductAssessmentConfigurationFactory.newInstance();
    // Return Object
    PDAssessmentConfigurationDetails pdAssessmentConfigurationDetails = new PDAssessmentConfigurationDetails();

    // Call the read method
    pdAssessmentConfigurationDetails.dtls = productAssessmentConfigurationObj.readPDAssessmentConfiguration(
      key.key);
    // set the context description key
    PDAssessmentConfigurationContextDescriptionKey contextDescriptionKey = new PDAssessmentConfigurationContextDescriptionKey();

    contextDescriptionKey.pdAssessmentConfigurationID = key.key.pdAssessmentConfigurationID;
    // get the context description
    pdAssessmentConfigurationDetails.description = getPDAssessmentConfigContextDescription(
      contextDescriptionKey);
    return pdAssessmentConfigurationDetails;
  }

  /**
   * This method gets the context description for Product and Assessment
   * Configuration association
   *
   * @param key
   * The Product Assessment Configuration ID.
   *
   * @return The context description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected PDAssessmentConfigurationContextDescriptionDetails getPDAssessmentConfigContextDescription(
    PDAssessmentConfigurationContextDescriptionKey key) throws AppException,
      InformationalException {

    // Create the return object
    PDAssessmentConfigurationContextDescriptionDetails pdAssessmentConfigurationContextDescriptionDetails = new PDAssessmentConfigurationContextDescriptionDetails();
    // Product Assessment Configuration BPO
    ProductAssessmentConfiguration pdAssessmentConfigurationObj = curam.core.sl.fact.ProductAssessmentConfigurationFactory.newInstance();
    // Create and populate the key to read the PDAssessmentConfiguration
    PDAssessmentConfigurationKey pdAssessmentConfigurationKey = new PDAssessmentConfigurationKey();

    pdAssessmentConfigurationKey.pdAssessmentConfigurationID = key.pdAssessmentConfigurationID;
    // Read the PDAssessmentConfiguration details.
    curam.core.sl.struct.PDAssessmentConfigurationDetails pdAssessmentConfigurationDetails = pdAssessmentConfigurationObj.readPDAssessmentConfiguration(
      pdAssessmentConfigurationKey);
    // Get the Product Name
    // Product manipulation variables
    curam.core.intf.Product productObj = curam.core.fact.ProductFactory.newInstance();
    ProductKey productKey = new ProductKey();
    ProductNameStructRef productNameStructRef;

    // Set key to read product
    productKey.productID = pdAssessmentConfigurationDetails.dtls.productID;
    // Read product name code
    productNameStructRef = productObj.readProductName(productKey);

    // Create a localizable string based on the message entry
    LocalisableString contextDescription = new LocalisableString(
      BPOPRODUCT.INF_PRODUCT_ASSESSMENTCONFIG_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(PRODUCTNAME.TABLENAME,
      productNameStructRef.name));
    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(ASSESSMENTNAME.TABLENAME,
      pdAssessmentConfigurationDetails.dtls.assessmentName));
    // Populate the context description field with the localizable text
    pdAssessmentConfigurationContextDescriptionDetails.description = contextDescription.toClientFormattedText();
    // Return the description.
    return pdAssessmentConfigurationContextDescriptionDetails;
  }

  /**
   * Cancels (logical delete) the specified Product Case Assessment
   * Configuration.
   *
   * @param details
   * The Product Assessment Configuration
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deletePDAssessmentConfiguration(
    CancelPDAssessmentConfigurationDetails details) throws AppException,
      InformationalException {
    // Product Assessment Configuration BPO
    ProductAssessmentConfiguration productAssessmentConfigurationObj = ProductAssessmentConfigurationFactory.newInstance();

    // Call the delete method
    productAssessmentConfigurationObj.deletePDAssessmentConfiguration(
      details.dtls);
  }

  /**
   * Retrieves the list of Product for the specified assessment configuration.
   *
   * @param key
   * The AssessmentConfiguration ID
   *
   * @return List of Benefit Products
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListAssessmentTypesForPDCaseIDListDetails listPDAssessmentConfigurationByCaseID(
    ListAssessmentTypesForPDCaseIDKey key) throws AppException,
      InformationalException {
    // Return Struct
    ListAssessmentTypesForPDCaseIDListDetails listAssessmentTypesForPDCaseIDListDetails = new ListAssessmentTypesForPDCaseIDListDetails();
    // Product Assessment Configuration BPO
    ProductAssessmentConfiguration productAssessmentConfigurationObj = ProductAssessmentConfigurationFactory.newInstance();

    // get the list of assessment configuration by case
    listAssessmentTypesForPDCaseIDListDetails.dtls = productAssessmentConfigurationObj.listPDAssessmentConfigurationsByCaseID(
      key.key);
    return listAssessmentTypesForPDCaseIDListDetails;
  }

  /**
   * Retrieves the list of distinct AssessmentConfigurations for the specified
   * Case.
   *
   * @param key
   * The AssessmentConfiguration ID
   *
   * @return List of Benefit Products
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public AssessmentConfigurationIDAndNameDetailsList listDistinctPDAssessmentConfigurationByCaseID(
    ListAssessmentTypesForPDCaseIDKey key) throws AppException,
      InformationalException {
    // Return Struct
    AssessmentConfigurationIDAndNameDetailsList assessmentConfigIDAndNameDetailsList = new AssessmentConfigurationIDAndNameDetailsList();
    // Product Assessment Configuration BPO
    ProductAssessmentConfiguration productAssessmentConfigurationObj = ProductAssessmentConfigurationFactory.newInstance();

    // get the list of assessment configuration by case
    assessmentConfigIDAndNameDetailsList.list = productAssessmentConfigurationObj.listDistinctPDAssessmentConfigurationsByCaseID(
      key.key);

    return assessmentConfigIDAndNameDetailsList;
  }

  /**
   * Cancels an issue time constraint.
   *
   * @param key
   * The issueTimeConstraintID of the record being cancelled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelIssueTimeConstraint(IssueTimeConstraintKey key)
    throws AppException, InformationalException {

    // IssueTimeConstraint object
    IssueTimeConstraint issueTimeConstraintObj = IssueTimeConstraintFactory.newInstance();

    // cancel the issue time constraint
    issueTimeConstraintObj.cancelTimeConstraint(key);
  }

  /**
   * Creates a new issue time constraint.
   *
   * @param details
   * The details needed to create an issue time constraint.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createIssueTimeConstraint(IssueTimeConstraintDtls details)
    throws AppException, InformationalException {

    // IssueTimeConstraint object
    IssueTimeConstraint issueTimeConstraintObj = IssueTimeConstraintFactory.newInstance();

    // create issue time constraint
    issueTimeConstraintObj.createTimeConstraint(details);
  }

  /**
   * Lists all issue time constraints associated with a particular issue type.
   *
   * @param key
   * The associated issueConfigurationID.
   * @return List of all issue time constraints related to the specified issue
   * type.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public IssueTimeConstraintList listIssueTimeConstraint(
    IssueConfigurationKey key) throws AppException, InformationalException {

    // IssueTimeConstraint object
    IssueTimeConstraint issueTimeConstraintObj = IssueTimeConstraintFactory.newInstance();

    // Struct needed to find context description
    IssueTypeContextDescriptionKey issueTypeContextDescriptionKey = new IssueTypeContextDescriptionKey();

    // return struct
    IssueTimeConstraintList issueTimeConstraintList = new IssueTimeConstraintList();

    // populate key
    issueTypeContextDescriptionKey.issueConfigurationID = key.issueConfigurationID;

    // read back list of time constraints associated with the issue type
    issueTimeConstraintList.list = issueTimeConstraintObj.listTimeConstraint(
      key);

    // read back context description for the issue type
    issueTimeConstraintList.description = getIssueTypeContextDescription(
      issueTypeContextDescriptionKey);

    return issueTimeConstraintList;
  }

  /**
   * Modifies an existing issue time constraint with updated data.
   *
   * @param details
   * The updated modified issue time constraint details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyIssueTimeConstraint(IssueTimeConstraintDtls details)
    throws AppException, InformationalException {

    // IssueTimeConstraint object
    IssueTimeConstraint issueTimeConstraintObj = IssueTimeConstraintFactory.newInstance();

    // modify existing issue time constraint
    issueTimeConstraintObj.modifyTimeConstraint(details);
  }

  /**
   * Reads back the details of a particular issue time constraint.
   *
   * @param key
   * The issueTimeConstraintID of the record being returned.
   * @return The details of the issue time constraint.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public IssueTimeConstraintDtls readIssueTimeConstraint(
    IssueTimeConstraintKey key) throws AppException, InformationalException {

    // IssueTimeConstraint object
    IssueTimeConstraint issueTimeConstraintObj = IssueTimeConstraintFactory.newInstance();

    // return struct
    IssueTimeConstraintDtls issueTimeConstraintDtls = new IssueTimeConstraintDtls();

    // read back issue time constraint details
    issueTimeConstraintDtls = issueTimeConstraintObj.readTimeConstraint(key);

    return issueTimeConstraintDtls;
  }

  // BEGIN, CR00045300, CM
  /**
   * Sets the status of a milestone configuration to canceled.
   *
   * @param key
   * The milestone configuration key
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelMilestoneConfiguration(MilestoneConfigurationKey key)
    throws AppException, InformationalException {

    // Milestone configuration business process object.
    MilestoneConfiguration milestoneObj = MilestoneConfigurationFactory.newInstance();

    // Cancel the milestone configuration
    milestoneObj.cancel(key);

  }

  /**
   * Creates a milestone configuration record.
   *
   * @param details
   * Details to be added
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createMilestoneConfiguration(
    curam.core.facade.struct.MilestoneConfigurationDtls details)
    throws AppException, InformationalException {

    // Milestone configuration business process object.
    MilestoneConfiguration milestoneObj = MilestoneConfigurationFactory.newInstance();

    // Create a milestone configuration
    milestoneObj.create(details.dtls);

  }

  /**
   * Lists all active and canceled milestone configuration records.
   *
   * @return detailsList List of all milestone configuration records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public MilestoneConfigurationDtlsList listAllMilestoneConfigurations()
    throws AppException, InformationalException {

    // Milestone configuration business process object.
    MilestoneConfiguration milestoneObj = MilestoneConfigurationFactory.newInstance();

    // Return struct
    MilestoneConfigurationDtlsList milestoneConfigurationDtlsList = new MilestoneConfigurationDtlsList();

    // List the milestone configurations
    milestoneConfigurationDtlsList.dtlsList = milestoneObj.list();

    return milestoneConfigurationDtlsList;
  }

  /**
   * Modifies the details of a milestone configuration record.
   *
   * @param details
   * Details to be modified
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyMilestoneConfiguration(
    curam.core.facade.struct.MilestoneConfigurationDtls details)
    throws AppException, InformationalException {

    // Milestone configuration business process object.
    MilestoneConfiguration milestoneObj = MilestoneConfigurationFactory.newInstance();

    // Modify a milestone configuration record
    milestoneObj.modify(details.dtls);

  }

  /**
   * Reads the details for a milestone configuration record.
   *
   * @param key
   * MilestoneConfigurationKey
   * @return details Details of the record that is read
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public curam.core.facade.struct.MilestoneConfigurationDtls readMilestoneConfiguration(
    MilestoneConfigurationKey key) throws AppException,
      InformationalException {

    // Milestone configuration business process object.
    MilestoneConfiguration milestoneObj = MilestoneConfigurationFactory.newInstance();

    // Return struct
    curam.core.facade.struct.MilestoneConfigurationDtls milestoneConfigurationDtls = new curam.core.facade.struct.MilestoneConfigurationDtls();

    // Read the milestone configuration details
    milestoneConfigurationDtls.dtls = milestoneObj.read(key);

    return milestoneConfigurationDtls;
  }

  // END, CR00045300

  // BEGIN, CR00058145, CSH
  /**
   * Lists all active issue type details.
   *
   * @return List of all active issue type details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public IssueTypeDescriptionDetailsList listActiveIssueTypes()
    throws AppException, InformationalException {

    // Return struct
    IssueTypeDescriptionDetailsList issueTypeDescriptionDetailsList = new IssueTypeDescriptionDetailsList();

    // Issue configuration business process object
    curam.core.sl.intf.IssueConfiguration issueConfigurationObj = curam.core.sl.fact.IssueConfigurationFactory.newInstance();

    // Populate the list with the active issue type details
    issueTypeDescriptionDetailsList.list = issueConfigurationObj.listActiveIssueTypeDetails();

    return issueTypeDescriptionDetailsList;
  }

  /**
   * Lists evidence types for a specified type of product.
   *
   * @param key
   * The unique identifier for the product delivery case.
   * @return List of the evidence types associated with the specified product
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public curam.core.facade.struct.EvidenceTypeList listEvidenceTypesByCaseID(
    CaseID key) throws AppException, InformationalException {

    // Return object
    curam.core.facade.struct.EvidenceTypeList evidenceTypeList = new curam.core.facade.struct.EvidenceTypeList();

    // Product manipulation variables
    ProductIDAndRecordStatusKey productIDAndRecordStatusKey = new ProductIDAndRecordStatusKey();

    // ProductDelivery manipulation variables
    ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    // Retrieve the productID using the case id
    productDeliveryKey.caseID = key.caseID;
    ProductIDDetails productIDDetails = productDeliveryObj.readProductID(
      productDeliveryKey);

    productIDAndRecordStatusKey.productID = productIDDetails.productID;
    productIDAndRecordStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // Get the evidenceTypeList
    evidenceTypeList = listEvidenceTypesByProductID(productIDAndRecordStatusKey);

    // BEGIN, CR00087761, VM
    // Filter Participant evidence types from the list
    if (!evidenceTypeList.evidenceList.evidenceList.isEmpty()) {

      // EvidenceController manipulation variables
      EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();
      EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

      for (int i = 0; i < evidenceTypeList.evidenceList.evidenceList.size(); i++) {

        // Set the evidence type key
        evidenceTypeKey.evidenceType = evidenceTypeList.evidenceList.evidenceList.item(i).typeCodeValue;

        // If this evidence is participant evidence
        if (evidenceControllerObj.isEvidenceParticipantData(evidenceTypeKey)) {

          // Remove the participant evidence type from the list
          evidenceTypeList.evidenceList.evidenceList.remove(i);
          i--;
        }

      }

    }
    // END, CR00087761

    return evidenceTypeList;
  }

  // END, CR00058145

  // BEGIN, CR00081013, PMD
  /**
   * Method to list all issue types
   *
   * @return a list of all issue types
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public IssueConfigTypeList listAllIssueTypes() throws AppException,
      InformationalException {

    // Return struct
    IssueConfigTypeList issueConfigTypeList = new IssueConfigTypeList();

    curam.core.sl.intf.IssueConfiguration issueConfigObj = curam.core.sl.fact.IssueConfigurationFactory.newInstance();

    // Get the list of all issue types
    issueConfigTypeList.issueConfigTypeList = issueConfigObj.listAllIssueTypes();

    return issueConfigTypeList;
  }

  // END, CR00081013

  // BEGIN, CR00081013, PMD
  /**
   * Method to return a list of benefit product types.
   *
   * @return List of benefit product types
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public BenefitProductTypeList listAllBenefitProductTypes()
    throws AppException, InformationalException {

    // Return struct
    BenefitProductTypeList benefitProductTypeList = new BenefitProductTypeList();

    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // Get the list of all product types
    ProductTypeList allProductTypes = adminProductObj.listAllProductTypes();

    for (int i = 0; i < allProductTypes.productTypeList.dtls.size(); i++) {

      // If the product type is a benefit,
      // add it to the return struct
      if (allProductTypes.productTypeList.dtls.item(i).benefitInd) {

        BenefitProductType benefitProductType = new BenefitProductType();

        benefitProductType.type = allProductTypes.productTypeList.dtls.item(i).typeCode;

        benefitProductTypeList.benefitTypeList.addRef(benefitProductType);
      }
    }

    return benefitProductTypeList;
  }

  /**
   * Method to return a list of liability product types.
   *
   * @return List of liability product types
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public LiabilityProductTypeList listAllLiabilityProductTypes()
    throws AppException, InformationalException {

    // Return struct
    LiabilityProductTypeList liabilityProductTypeList = new LiabilityProductTypeList();

    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // Get the list of all product types
    ProductTypeList allProductTypes = adminProductObj.listAllProductTypes();

    for (int i = 0; i < allProductTypes.productTypeList.dtls.size(); i++) {

      // If the product type is a liability,
      // add it to the return struct
      if (!allProductTypes.productTypeList.dtls.item(i).benefitInd) {

        LiabilityProductType liabilityProductType = new LiabilityProductType();

        liabilityProductType.type = allProductTypes.productTypeList.dtls.item(i).typeCode;

        liabilityProductTypeList.liabilityTypeList.addRef(liabilityProductType);
      }
    }

    return liabilityProductTypeList;
  }

  // END, CR00081013

  // BEGIN, CR00096593, MC
  /**
   * Resolves the home page for the concern. Security checks are not applied in
   * this method as it must be used from the resolve script only.
   *
   * @param key
   * The concern Role ID of the record being read.
   * @return The home page name.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ParticipantHomePageName resolveMemberHome(ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    // Return struct
    ParticipantHomePageName participantHomePageName = new ParticipantHomePageName();

    // BEGIN, CR00101909, ELG
    // Concern Role object
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleTypeDetails concernRoleTypeDetails;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;

    // Read the concern role details
    concernRoleTypeDetails = concernRoleObj.readConcernRoleType(concernRoleKey);

    // If the concern role is of type person
    if (concernRoleTypeDetails.concernRoleType.equals(CONCERNROLETYPE.PERSON)) {
      // Set home page name to person home
      // BEGIN, CR00023312, GM
      // BEGIN, CR00354096, BD
      participantHomePageName.participantHomePageName = UimConst.PersonResolveHomePage;
      // END, CR00354096
      // END, CR00023312
    } // If the concern role is of type prospect person
    else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.PROSPECTPERSON)) {
      // Set home page name to prospect person home
      // BEGIN, CR00023312, GM
      participantHomePageName.participantHomePageName = UimConst.kparticipantHomePageName;
      // END, CR00023312
    } // BEGIN, CR00103528, AK
    // If the concern role is of type product provider
    else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.PRODUCTPROVIDER)) {
      // Set home page name to product provider home
      participantHomePageName.participantHomePageName = UimConst.kProductProviderHome;
    } // END, CR00103528
    // END, CR00101909
    // BEGIN, CR00143128, SS
    else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.REPRESENTATIVE)) {
      participantHomePageName.participantHomePageName = UimConst.kRepresentativeHomePage;
    } // END, CR00143128
    // BEGIN, CR00157473, MR
    else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.EMPLOYER)) {
      participantHomePageName.participantHomePageName = UimConst.kEmployerHomePageName;
    }
    // END, CR00157473

    return participantHomePageName;
  }

  // END, CR00096593

  // BEGIN, CR00104804, SD
  // BEGIN, CR00104400, SD
  /**
   * This method cancels an investigation configuration record by setting the
   * status to Canceled.
   *
   * @param key
   * Contains the investigation configuration id.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelInvestigationConfiguration(InvestigationConfigKey key)
    throws AppException, InformationalException {

    // Cancel the investigation configuration record
    InvestigationConfigurationFactory.newInstance().deleteInvestigationConfiguration(
      key);

    // BEGIN, CR00112688, POH
    if (caseCollaborationAdminStrategy.isCollaborationEnabled()) {
      caseCollaborationAdminStrategy.cancelCaseCollaborationAdmin(
        caseConfigurationDAO.readByIDAndCaseType(key.investigationConfigID,
        CASETYPECODEEntry.INVESTIGATIONCASE));
    }
    // END, CR00112688
  }

  /**
   * This method lists all information configurations - Active and Canceled.
   *
   * @return The complete list of investigation configurations.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InvestigationConfigurationListDetails listAllInvestigationConfigurations()
    throws AppException, InformationalException {

    // Declare list to be returned
    InvestigationConfigurationListDetails investigationConfigurationListDetails = new InvestigationConfigurationListDetails();

    // Get the list of all investigation configurations and return it
    investigationConfigurationListDetails.dtls = InvestigationConfigurationFactory.newInstance().listInvestigationConfiguration();

    return investigationConfigurationListDetails;
  }

  /**
   * This method modifies an investigation configuration record.
   *
   * @param details
   * Contains the modified investigation configuration details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyInvestigationConfiguration(
    InvestigationConfigurationDetails details) throws AppException,
      InformationalException {

    // Modify the investigation configuration record
    InvestigationConfigurationFactory.newInstance().modifyInvestigationConfiguration(
      details.dtls);

    // BEGIN, CR00112688, POH
    if (caseCollaborationAdminStrategy.isCollaborationEnabled()) {
      caseCollaborationAdminStrategy.modifyCaseCollaborationAdmin(
        caseConfigurationDAO.readByIDAndCaseType(
          details.dtls.dtls.investigationConfigID,
          CASETYPECODEEntry.INVESTIGATIONCASE),
          details.administrationCaseCollaborationDtls);
    }
    // END, CR00112688
  }

  /**
   * This method returns the details for an investigation configuration.
   *
   * @param key
   * Contains the investigation configuration id.
   * @return The investigation configuration details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InvestigationConfigurationDetails readInvestigationConfiguration(
    InvestigationConfigKey key) throws AppException, InformationalException {

    // Declare the details to be returned
    InvestigationConfigurationDetails investigationConfigurationDetails = new InvestigationConfigurationDetails();

    // Read the relevant investigation configuration details and return them
    investigationConfigurationDetails.dtls = InvestigationConfigurationFactory.newInstance().readInvestigationConfiguration(
      key);

    // BEGIN, CR00112688, POH
    if (caseCollaborationAdminStrategy.isCollaborationEnabled()) {
      investigationConfigurationDetails.administrationCaseCollaborationDtls = caseCollaborationAdminStrategy.readCaseCollaborationAdmin(
        caseConfigurationDAO.readByIDAndCaseType(key.investigationConfigID,
        CASETYPECODEEntry.INVESTIGATIONCASE));
    }
    // END, CR00112688
    // BEGIN, CR00235514, PB
    if (!investigationConfigurationDetails.dtls.dtls.adminTranslationRequiredInd) {
      investigationConfigurationDetails.dtls.dtls.adminTranslationRequiredInd = false;
    }
    // END, CR00235514
    return investigationConfigurationDetails;
  }

  // END, CR00104400

  // BEGIN, CR00104864, ZV
  /**
   * Adds a set of existing milestones to the investigation case.
   *
   * @param key
   * Identifies the investigation case configuration key and the
   * milestoneTabList to be added.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addInvestigationCaseExistingMilestone(AddMilestoneKey key)
    throws AppException, InformationalException {

    // Milestone Link business process object.
    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    CaseType caseType = new CaseType();

    caseType.caseType = CASETYPECODE.INVESTIGATIONCASE;

    // add existing milestone configuration to investigation case
    milestoneLinkObj.addExistingMilestone(key, caseType);

  }

  /**
   * Creates a new milestone configuration and then creates the link between the
   * milestone and the investigation case.
   *
   * @param key
   * Identifies the investigation case configuration key.
   * @param details
   * Identifies the milestone configuration details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createInvestigationCaseMilestone(ProductKey key,
    MilestoneConfigurationDtls details) throws AppException,
      InformationalException {

    // Milestone service layer object.
    MilestoneConfiguration milestoneObj = MilestoneConfigurationFactory.newInstance();

    // MilestoneLink service layer object
    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    // create a milestone configuration
    milestoneObj.create(details.dtls);

    // Set the milestone link details to create the link
    MilestoneLinkDtls milestoneLinkDtls = new MilestoneLinkDtls();

    milestoneLinkDtls.caseTypeID = key.productID;
    milestoneLinkDtls.caseType = CASETYPECODE.INVESTIGATIONCASE;
    milestoneLinkDtls.milestoneConfigurationID = details.dtls.dtls.milestoneConfigurationID;

    // create milestone link
    milestoneLinkObj.create(milestoneLinkDtls);

  }

  // BEGIN, CR00236426, GP
  /**
   * Lists all the milestones which are currently associated with a particular
   * product.
   *
   * @param key
   * Identifies the product key
   * @return List of milestone configuration Link details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated since curam 6.0, replaced by
   * {@link Product# listAssociatedMilestones()}. See release note:
   * CR00236426
   */
  @Deprecated
  // END, CR00236426
  public MilestoneConfigurationLinkDtlsList listMilestone(ProductKey key)
    throws AppException, InformationalException {

    // return struct
    MilestoneConfigurationLinkDtlsList milestoneConfigurationLinkDtlsList = new MilestoneConfigurationLinkDtlsList();

    // Milestone Link business process object.
    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    // Context description key
    InvestigationCaseContextDescriptionKey contextDescriptionKey = new InvestigationCaseContextDescriptionKey();

    // set the key
    CaseTypeID caseTypeID = new CaseTypeID();

    caseTypeID.caseTypeID = key.productID;

    // lists the milestones associated with product
    milestoneConfigurationLinkDtlsList = milestoneLinkObj.listMilestonesForCase(
      caseTypeID);

    contextDescriptionKey.investigationConfigID = key.productID;

    // Retrieve the Context Description using the context key.
    milestoneConfigurationLinkDtlsList.contextDescription.contextDescription = getInvestigationCaseContextDescription(contextDescriptionKey).description;

    return milestoneConfigurationLinkDtlsList;
  }

  // BEGIN, CR00236426, GP
  /**
   * Lists all the milestones which are currently associated with a particular
   * product.
   *
   * @param key
   * Identifies the product key
   * @return List of milestone configuration Link details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public MilestoneConfigurationLinkDetailsList listAssociatedMilestones(
    ProductKey key) throws AppException, InformationalException {

    MilestoneConfigurationLinkDetailsList milestoneConfigurationLinkDetailsList = new MilestoneConfigurationLinkDetailsList();
    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();
    InvestigationCaseContextDescriptionKey contextDescriptionKey = new InvestigationCaseContextDescriptionKey();
    CaseTypeID caseTypeID = new CaseTypeID();

    caseTypeID.caseTypeID = key.productID;

    milestoneConfigurationLinkDetailsList = milestoneLinkObj.listAssociatedMilestonesForCase(
      caseTypeID);

    contextDescriptionKey.investigationConfigID = key.productID;

    // Retrieve the Context Description using the context key.
    milestoneConfigurationLinkDetailsList.contextDescription.contextDescription = getInvestigationCaseContextDescription(contextDescriptionKey).description;

    return milestoneConfigurationLinkDetailsList;
  }

  // END, CR00236426

  /**
   * Lists all the active milestones not already associated with a particular
   * product.
   *
   * @param key
   * Identifies the product key
   * @return List of milestone configuration summary details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public MilestoneConfigurationSummaryDtlsList listUnassociatedMilestone(
    ProductKey key) throws AppException, InformationalException {

    // return struct
    MilestoneConfigurationSummaryDtlsList milestoneDtlsList = new MilestoneConfigurationSummaryDtlsList();

    // Milestone Configuration service layer object
    MilestoneConfiguration milestoneObj = MilestoneConfigurationFactory.newInstance();

    // Context description key
    InvestigationCaseContextDescriptionKey contextDescriptionKey = new InvestigationCaseContextDescriptionKey();

    // set the key
    CaseTypeID caseTypeID = new CaseTypeID();

    caseTypeID.caseTypeID = key.productID;

    // lists all the unassociated milestones
    milestoneDtlsList = milestoneObj.listUnassociatedMilestone(caseTypeID);

    contextDescriptionKey.investigationConfigID = key.productID;

    return milestoneDtlsList;

  }

  /**
   * Removes the link between a milestone and a product.
   *
   * @param key
   * Identifies the milestone link key
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void removeMilestone(MilestoneLinkKey key) throws AppException,
      InformationalException {

    // Milestone Link business process object.
    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    // removes the link between the milestone and the product
    milestoneLinkObj.remove(key);

  }

  /**
   * Operation to read the Investigation Case Context Description.
   *
   * @param key
   * The Investigation Case Context Description Key.
   *
   * @return The context description of the investigation case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected InvestigationCaseContextDescriptionDetails getInvestigationCaseContextDescription(
    InvestigationCaseContextDescriptionKey key) throws AppException,
      InformationalException {

    // Return Object
    InvestigationCaseContextDescriptionDetails investigationCaseContextDescriptionDetails = new InvestigationCaseContextDescriptionDetails();

    // Investigation Configuration Manipulation variables
    curam.core.sl.entity.intf.InvestigationConfig investigationConfigObj = curam.core.sl.entity.fact.InvestigationConfigFactory.newInstance();
    curam.core.sl.entity.struct.InvestigationConfigKey investigationConfigKey = new curam.core.sl.entity.struct.InvestigationConfigKey();

    investigationConfigKey.investigationConfigID = key.investigationConfigID;

    curam.core.sl.entity.struct.InvestigationConfigDtls investigationConfigDtls = investigationConfigObj.read(
      investigationConfigKey);

    // Create a localizable string based on the message entry
    LocalisableString contextDescription = new LocalisableString(
      BPOINVESTIGATIONCONFIGURATION.INF_INVESTIGATIONCASE_CONTEXT_DESCRIPTION);

    // BEGIN, CR00163098, JC
    // Add the code table item to the localizable string
    contextDescription.arg(
      CodeTable.getOneItem(INVESTIGATECONFIGTYPE.TABLENAME,
      investigationConfigDtls.type, TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC

    // Populate the context description field with the localizable text
    investigationCaseContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    return investigationCaseContextDescriptionDetails;
  }

  // END, CR00104864

  /**
   * This method creates an investigation configuration record.
   *
   * @param details
   * - The investigation configuration details to be inserted.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createInvestigationConfiguration(
    InvestigationConfigurationDetails details) throws AppException,
      InformationalException {

    // Insert the The investigation configuration details in a new record
    InvestigationConfigurationFactory.newInstance().createInvestigationConfiguration(
      details.dtls);

    // BEGIN, CR00112688, POH
    // determine if collaboration is enabled and attempt if this is the case
    if (caseCollaborationAdminStrategy.isCollaborationEnabled()) {
      caseCollaborationAdminStrategy.createCaseCollaborationAdmin(
        caseConfigurationDAO.readByIDAndCaseType(
          details.dtls.dtls.investigationConfigID,
          CASETYPECODEEntry.INVESTIGATIONCASE),
          details.administrationCaseCollaborationDtls);
    }
    // END, CR00112688
  }

  // END, CR00104804

  // BEGIN, CR00104908, ZV
  // BEGIN, CR00105577, MC
  /**
   * Displays a List of resolution configurations already associated with a
   * specified investigation.
   *
   * @param key
   * investigation configuration key
   *
   * @return List of resolution for investigation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InvestigationResLinkIDResolutionDtlsList listResolutionsForInvestigation(
    InvestigationConfigKey key) throws AppException, InformationalException {

    // Investigation Resolution Link Business object
    curam.core.sl.intf.InvestigationResolutionLink investigationResolutionLinkObj = curam.core.sl.fact.InvestigationResolutionLinkFactory.newInstance();

    // create return struct
    InvestigationResLinkIDResolutionDtlsList investigationResLinkIDResolutionDtlsList = new InvestigationResLinkIDResolutionDtlsList();
    InvestigationConfigKey investigationConfigurationKey = new InvestigationConfigKey();

    investigationConfigurationKey.investigationConfigID = key.investigationConfigID;

    investigationResLinkIDResolutionDtlsList = investigationResolutionLinkObj.listResolutionForInvestigation(
      investigationConfigurationKey);

    // InvestigationCaseContextDescriptionKey object
    InvestigationCaseContextDescriptionKey investigationCaseContextDescriptionKey = new InvestigationCaseContextDescriptionKey();

    investigationCaseContextDescriptionKey.investigationConfigID = key.investigationConfigID;

    // Retrieve the Investigation Type Context Description using the context
    // key.
    investigationResLinkIDResolutionDtlsList.contextDtls.description = getInvestigationCaseContextDescription(investigationCaseContextDescriptionKey).description;

    return investigationResLinkIDResolutionDtlsList;

  }

  /**
   * Lists unassigned resolution configurations for an investigation.
   *
   * @param key
   * investigation configuration key
   *
   * @return List of unassigned resolution configuration details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ResolutionConfigurationDtlsList listUnassignedResolutionDetailsForInvestigation(
    InvestigationConfigKey key) throws AppException, InformationalException {

    // Resolution Configuration Business object
    curam.core.sl.intf.InvestigationResolutionLink investigationResolutionLinkObj = curam.core.sl.fact.InvestigationResolutionLinkFactory.newInstance();

    // create return struct
    ResolutionConfigurationDtlsList resolutionConfigurationDtlsList = new ResolutionConfigurationDtlsList();

    InvestigationConfigKey investigationConfigKey = new InvestigationConfigKey();

    investigationConfigKey.investigationConfigID = key.investigationConfigID;

    // call service layer for a list of unassigned resolutions
    resolutionConfigurationDtlsList.dtlsList = investigationResolutionLinkObj.listUnassignedResolutionsForInvestigation(
      investigationConfigKey);

    return resolutionConfigurationDtlsList;
  }

  /**
   * Adds a new resolution configuration and associated it with an Investigation
   * configuration.
   *
   * @param resolutionDtls
   * the details of the resolution to be created and the investigation
   * configuration it is to be added to.
   * @param investigationConfigKey
   * Contains the investigation configuration id
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createAndAddResolutionToInvestigation(
    ResolutionConfigurationDtls resolutionDtls,
    InvestigationConfigKey investigationConfigKey) throws AppException,
      InformationalException {

    // Add the resolution configuration
    // Resolution configuration business process object.
    curam.core.sl.intf.ResolutionConfiguration resolutionConfigurationObj = curam.core.sl.fact.ResolutionConfigurationFactory.newInstance();

    // create resolution configuration details
    resolutionConfigurationObj.create(resolutionDtls.dtls);

    InvestigationResolutionLinkDtls investigationResolutionLinkDtls = new InvestigationResolutionLinkDtls();

    investigationResolutionLinkDtls.resolutionConfigurationID = resolutionDtls.dtls.dtls.resolutionConfigurationID;
    investigationResolutionLinkDtls.investigationConfigID = investigationConfigKey.investigationConfigID;

    // Associate the resolution configuration with the Investigation
    // Investigation Resolution Link Business object
    curam.core.sl.intf.InvestigationResolutionLink investigationResolutionLinkObj = curam.core.sl.fact.InvestigationResolutionLinkFactory.newInstance();

    investigationResolutionLinkObj.createResolutionForInvestigation(
      investigationResolutionLinkDtls);

  }

  // END, CR00105577
  // END, CR00104908

  // BEGIN, CR00104693, MC
  /**
   * This method allows an administrator to cancel an Investigation Approval
   * Check for a particular investigation.
   *
   * @param key
   * The unique id of the Investigation Resolution Approval Check to be
   * canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelApprovalCheckForInvestigation(
    CancelInvestigationApprovalCheckKey key) throws AppException,
      InformationalException {

    // InvestigationApprovalCheck business object
    curam.core.sl.intf.InvestigationApprovalCheck investigationApprovalCheckObj = curam.core.sl.fact.InvestigationApprovalCheckFactory.newInstance();

    // Call InvestigationApprovalCheck BPO to perform the cancel operation
    investigationApprovalCheckObj.cancel(key.cancelDtls);

  }

  /**
   * This method allows an administrator to configure an approval check for a
   * particular investigation. It allows a percentage of investigations which
   * are submitted for approval to be reviewed.
   *
   * @param details
   * The Investigation Approval Check details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createApprovalCheckForInvestigation(
    InvestigationApprovalCheckDetails details) throws AppException,
      InformationalException {

    // InvestigationApprovalCheck business object
    curam.core.sl.intf.InvestigationApprovalCheck investigationApprovalCheckObj = curam.core.sl.fact.InvestigationApprovalCheckFactory.newInstance();

    // Call InvestigationApprovalCheck BPO to perform the create operation
    investigationApprovalCheckObj.create(details.dtls);

  }

  /**
   * This method lists all existing approval checks for a particular
   * investigation.
   *
   * @param key
   * The unique id of the investigation that the approval checks are
   * being listed for.
   * @return A list of approval checks for the specified investigation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListInvestigationApprovalCheckDetails listApprovalCheckForInvestigation(
    InvestigationConfigKey key) throws AppException, InformationalException {

    // Return Object
    ListInvestigationApprovalCheckDetails listInvestigationApprovalCheckDetails = new ListInvestigationApprovalCheckDetails();

    // InvestigationApprovalCheck business object
    curam.core.sl.intf.InvestigationApprovalCheck investigationApprovalCheckObj = curam.core.sl.fact.InvestigationApprovalCheckFactory.newInstance();

    // Call InvestigationApprovalCheck BPO to perform the list operation
    listInvestigationApprovalCheckDetails.detailsList = investigationApprovalCheckObj.listApprovalChecksForInvestigation(
      key);

    // InvestigationTypeContextDescriptionKey object
    InvestigationTypeContextDescriptionKey investigationTypeContextDescriptionKey = new InvestigationTypeContextDescriptionKey();

    investigationTypeContextDescriptionKey.investigationConfigurationID = key.investigationConfigID;

    // Retrieve the Investigation Type Context Description using the context
    // key.
    listInvestigationApprovalCheckDetails.contextDtls = getInvestigationTypeContextDescription(
      investigationTypeContextDescriptionKey);

    return listInvestigationApprovalCheckDetails;
  }

  /**
   * This method allows an administrator to modify an Investigation Approval
   * Check for a particular investigation.
   *
   * @param details
   * The investigation approval check modified details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyApprovalCheckForInvestigation(
    InvestigationApprovalCheckDetails details) throws AppException,
      InformationalException {

    // InvestigationApprovalCheck business object
    curam.core.sl.intf.InvestigationApprovalCheck investigationApprovalCheckObj = curam.core.sl.fact.InvestigationApprovalCheckFactory.newInstance();

    // Call InvestigationApprovalCheck BPO to perform the modify operation
    investigationApprovalCheckObj.modify(details.dtls);

  }

  /**
   * This method allows an administrator to view a approval check for a
   * particular investigation.
   *
   * @param key
   * The unique id of the Investigation Approval Check to be read.
   * @return The approval check details for the specified investigation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadInvestigationApprovalCheckDetails readApprovalCheckForInvestigation(
    ReadInvestigationApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return Object
    ReadInvestigationApprovalCheckDetails readInvestigationApprovalCheckDetails = new ReadInvestigationApprovalCheckDetails();

    // InvestigationApprovalCheck business object
    curam.core.sl.intf.InvestigationApprovalCheck investigationApprovalCheckObj = curam.core.sl.fact.InvestigationApprovalCheckFactory.newInstance();

    // Call InvestigationApprovalCheck BPO to perform the read operation
    readInvestigationApprovalCheckDetails.dtls.dtls = investigationApprovalCheckObj.read(
      key.key);

    // InvestigationTypeContextDescriptionKey object
    InvestigationTypeContextDescriptionKey investigationTypeContextDescriptionKey = new InvestigationTypeContextDescriptionKey();

    investigationTypeContextDescriptionKey.investigationConfigurationID = readInvestigationApprovalCheckDetails.dtls.dtls.dtls.investigationConfigID;

    // Retrieve the Investigation Type Context Description using the context
    // key.
    readInvestigationApprovalCheckDetails.contextDtls = getInvestigationTypeContextDescription(
      investigationTypeContextDescriptionKey);

    return readInvestigationApprovalCheckDetails;
  }

  /**
   * Operation to read the Investigation Type Context Description.
   *
   * @param key
   * The Investigation Context Description Key.
   *
   * @return The context description of the investigation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected InvestigationTypeContextDescriptionDetails getInvestigationTypeContextDescription(
    InvestigationTypeContextDescriptionKey key) throws AppException,
      InformationalException {

    // Return Object
    InvestigationTypeContextDescriptionDetails investigationTypeContextDescriptionDetails = new InvestigationTypeContextDescriptionDetails();

    // Investigation Configuration Manipulation variables
    curam.core.sl.entity.intf.InvestigationConfig investigationConfigurationObj = curam.core.sl.entity.fact.InvestigationConfigFactory.newInstance();
    curam.core.sl.entity.struct.InvestigationConfigKey investigationConfigurationKey = new curam.core.sl.entity.struct.InvestigationConfigKey();

    // Get the Investigation type
    investigationConfigurationKey.investigationConfigID = key.investigationConfigurationID;

    InvestigationIDTypeDtls investigationTypeDtls = investigationConfigurationObj.readInvestigationType(
      investigationConfigurationKey);

    // Create a localizable string based on the message entry
    LocalisableString contextDescription = new LocalisableString(
      BPOINVESTIGATIONAPPROVALCHECK.INF_INVESTIGATION_TYPE_CONTEXT_DESCRIPTION);

    // BEGIN, CR00163098, JC
    // Add the code table item to the localizable string
    contextDescription.arg(
      CodeTable.getOneItem(INVESTIGATECONFIGTYPE.TABLENAME,
      investigationTypeDtls.type, TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC

    // Populate the context description field with the localizable text
    investigationTypeContextDescriptionDetails.description = contextDescription.toClientFormattedText();

    return investigationTypeContextDescriptionDetails;
  }

  // END, CR00104693

  // BEGIN, CR00105142, SD
  /**
   * This method returns a list of current active investigation configuration
   * types.
   *
   * @return The investigation configuration type list.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InvestigationIDTypeDtlsList listActiveInvestigationTypes()
    throws AppException, InformationalException {

    return InvestigationConfigurationFactory.newInstance().listActiveInvestigationTypes();
  }

  // END, CR00105142

  // BEGIN, CR00105577, MC
  /**
   * Creates an existing resolution for an investigation.
   *
   * @param details
   * The details for the creation of the resolution configuration for
   * the investigation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createResolutionForInvestigation(
    InvestigationResolutionLinkDtls details) throws AppException,
      InformationalException {

    // Investigation Resolution Link Business object
    curam.core.sl.intf.InvestigationResolutionLink investigationResolutionLinkObj = curam.core.sl.fact.InvestigationResolutionLinkFactory.newInstance();

    investigationResolutionLinkObj.createResolutionForInvestigation(details);

  }

  /**
   * Sets investigation resolution link record to status "Canceled".
   *
   * @param key
   * The key identifying the record to be cancelled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelInvestigationResolutionLink(
    InvestigationResolutionLinkKey key) throws AppException,
      InformationalException {

    // Investigation Resolution Link Business object
    curam.core.sl.intf.InvestigationResolutionLink investigationResolutionLinkObj = curam.core.sl.fact.InvestigationResolutionLinkFactory.newInstance();

    // cancel investigation resolution link
    investigationResolutionLinkObj.cancelInvestigationResolutionLink(key);
  }

  // END, CR00105577

  // BEGIN, CR00143570, SAI
  // BEGIN, CR00236426, GP
  /**
   * This method helps to list all the Milestone configuration details of a
   * particular Case Type ID and Case Type
   *
   * @param key
   * - This key will have the value of case type ID and Case Type of a
   * particular product
   * @return The Milestone configuration and Milestone link details list.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since curam 6.0, replaced by
   * {@link Product# listMilestoneConfigurationsForCaseType()} See
   * release note:CR00236426
   */
  @Deprecated
  // END, CR00236426
  public MilestoneConfigurationLinkDtlsList listMilestoneConfigurations(
    CaseTypeIDAndType key) throws AppException, InformationalException {

    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    MilestoneConfigurationLinkDtlsList milestoneConfigurationLinkDtlsList = milestoneLinkObj.listMilestonesForCaseTypeAndID(
      key);

    if (CASETYPECODE.PRODUCTDELIVERY.equals(key.caseType)) {

      ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

      productContextDescriptionKey.productID = key.caseTypeID;

      milestoneConfigurationLinkDtlsList.contextDescription.contextDescription = getProductContextDescription(productContextDescriptionKey).description;
    } else if (CASETYPECODE.INTEGRATEDCASE.equals(key.caseType)) {

      milestoneConfigurationLinkDtlsList.contextDescription.contextDescription = getIntegratedCaseContextDescription(key.caseTypeID).toClientFormattedText();
    } else if (CASETYPECODE.SCREENINGCASE.equals(key.caseType)) {

      milestoneConfigurationLinkDtlsList.contextDescription.contextDescription = getScreeningContextDescription(key.caseTypeID).toClientFormattedText();
    }
    return milestoneConfigurationLinkDtlsList;
  }

  // BEGIN, CR00236426, GP
  /**
   * Lists all the Milestone configuration details of a particular Case Type ID
   * and Case Type.
   *
   * @param key
   * contains the key will have the value of case type ID and Case Type
   * of a particular product.
   * @return The Milestone configuration and Milestone link details list.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public MilestoneConfigurationLinkDetailsList listMilestoneConfigurationsForCaseType(
    CaseTypeIDAndType key) throws AppException, InformationalException {

    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    MilestoneConfigurationLinkDetailsList milestoneConfigurationLinkDetailsList = milestoneLinkObj.listAssociatedMilestonesForCaseTypeAndID(
      key);

    if (CASETYPECODE.PRODUCTDELIVERY.equals(key.caseType)) {

      ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

      productContextDescriptionKey.productID = key.caseTypeID;

      milestoneConfigurationLinkDetailsList.contextDescription.contextDescription = getProductContextDescription(productContextDescriptionKey).description;
    } else if (CASETYPECODE.INTEGRATEDCASE.equals(key.caseType)) {

      milestoneConfigurationLinkDetailsList.contextDescription.contextDescription = getIntegratedCaseContextDescription(key.caseTypeID).toClientFormattedText();
    } else if (CASETYPECODE.SCREENINGCASE.equals(key.caseType)) {

      milestoneConfigurationLinkDetailsList.contextDescription.contextDescription = getScreeningContextDescription(key.caseTypeID).toClientFormattedText();
    }
    return milestoneConfigurationLinkDetailsList;
  }

  // END, CR00236426

  /**
   * This method helps to create a Milestone for a Case Type with the details
   * provided by the user.
   *
   * @param key
   * - This key will have the value of case type ID and Case Type of a
   * particular product
   * @param details
   * - This parameter will have all the information given by the user
   * while creating a milestone for a particular case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createMilestoneForCaseType(CaseTypeIDAndType key,
    MilestoneConfigurationDtls details) throws AppException,
      InformationalException {

    // Milestone service layer object.
    MilestoneConfiguration milestoneObj = MilestoneConfigurationFactory.newInstance();

    // MilestoneLink service layer object
    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    // create a milestone configuration
    milestoneObj.create(details.dtls);

    // Set the milestone link details to create the link
    MilestoneLinkDtls milestoneLinkDtls = new MilestoneLinkDtls();

    milestoneLinkDtls.caseTypeID = key.caseTypeID;
    milestoneLinkDtls.caseType = key.caseType;
    milestoneLinkDtls.milestoneConfigurationID = details.dtls.dtls.milestoneConfigurationID;

    milestoneLinkDtls.creationEvent = details.creationEvent;
    milestoneLinkDtls.completionEvent = details.completionEvent;

    String components = details.components;

    if (components != null && components.trim().length() > 0) {
      String[] comps = components.split(CuramConst.gkComma);

      if (comps.length > 0) {
        milestoneLinkDtls.componentCategory = comps[0];
        if (comps.length == 2) {
          milestoneLinkDtls.componentType = comps[1];
        }
      }

    }

    // create milestone link
    milestoneLinkObj.create(milestoneLinkDtls);
  }

  /**
   * This method helps to add the existing milestone to a selected product from
   * list of milestones which was created earlier for different products.
   *
   * @param key
   * - This key will have the value of case type ID and list of
   * milestone configuration ID selected by the user.
   * @param caseType
   * type of case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addExistingMilestone(AddMilestoneKey key, CaseType caseType)
    throws AppException, InformationalException {

    // Milestone Link business process object.
    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    // add existing milestone configuration to investigation case
    milestoneLinkObj.addExistingMilestone(key, caseType);
  }

  /**
   * Presentation layer operation to read the Screening Configuration Context
   * Description.
   *
   * @param key
   * The Screening Configuration ID and optional details
   *
   * @return The context description.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected LocalisableString getScreeningContextDescription(long key)
    throws AppException, InformationalException {

    // Create a localizable string based on the message entry
    LocalisableString contextDescription = new LocalisableString(
      FACADERESOURCE.INF_SCREENING_CONFIGURATION_CONTEXT_DESCRIPTION);

    // The screening configuration object and key.
    curam.core.sl.intf.ScreeningConfiguration screeningConfigurationObj = curam.core.sl.fact.ScreeningConfigurationFactory.newInstance();

    curam.core.sl.struct.ScreeningConfigurationKey screeningConfigurationKey = new curam.core.sl.struct.ScreeningConfigurationKey();

    // Set the screening configuration ID.
    screeningConfigurationKey.dtls.screeningConfigID = key;

    // Read the screening configuration details.
    ScreeningConfigurationDetails screeningConfigurationDetails = screeningConfigurationObj.viewScreeningConfiguration(
      screeningConfigurationKey);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(SCREENINGNAMECODE.TABLENAME,
      screeningConfigurationDetails.dtls.dtls.name));

    return contextDescription;
  }

  /**
   * Reads the integrated case context description.
   *
   * @param key
   * Key to read the integrated case context description.
   *
   * @return Integrated Case context description
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected LocalisableString getIntegratedCaseContextDescription(long key)
    throws AppException, InformationalException {

    // AdminIntegratedCase manipulation variables
    curam.core.intf.AdminIntegratedCase adminIntegratedCaseObj = curam.core.fact.AdminIntegratedCaseFactory.newInstance();
    IntegratedCaseTypeStruct integratedCaseTypeStruct;
    AdminIntegratedCaseKey adminIntegratedCaseKey = new AdminIntegratedCaseKey();

    // Set key to read AdminIntegratedCase
    adminIntegratedCaseKey.adminIntegratedCaseID = key;

    // Read AdminIntegratedCase to get IC Type
    integratedCaseTypeStruct = adminIntegratedCaseObj.readIntegratedCaseType(
      adminIntegratedCaseKey);

    // Create a localizable string based on the message entry
    LocalisableString contextDescription = new LocalisableString(
      FACADERESOURCE.INF_INTEGRATED_CASE_CONTEXT_DESCRIPTION);

    // Add the code table item to the localizable string
    contextDescription.arg(
      new CodeTableItemIdentifier(PRODUCTCATEGORY.TABLENAME,
      integratedCaseTypeStruct.integratedCaseType));

    return contextDescription;
  }

  // END, CR00143570

  // BEGIN, CR00105577, MC

  /**
   * Returns a list of components based on the component base type.
   *
   * @param componentBaseType
   * is the initial value based on which the components are retrieved
   *
   * @return MilestoneComponentList is the list of all components
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public MilestoneComponentList getComponentList(
    ComponentBaseType componentBaseType) throws AppException,
      InformationalException {

    MilestoneComponentList milestoneComponentList = new MilestoneComponentList();

    milestoneComponentList.dtls = ComponentHookManager.getComponentHook(componentBaseType.dtls.code).getMilestoneComponents(
      componentBaseType.dtls);
    return milestoneComponentList;
  }

  /**
   * Returns a list of sub components based on the component base type.
   *
   * @param componentType
   * is the parent component based on which sub components are
   * retrieved
   *
   * @return MilestoneSubComponentList is the list of all sub components
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public MilestoneSubComponentList getSubComponentList(
    ComponentType componentType) throws AppException, InformationalException {

    MilestoneSubComponentList milestoneSubComponentList = new MilestoneSubComponentList();

    milestoneSubComponentList.dtls = ComponentHookManager.getComponentHook(componentType.dtls.componentCode).getMilestoneSubComponents(
      componentType.dtls);
    return milestoneSubComponentList;
  }

  /**
   * Lists unassociated milestones for a product id and case type.
   *
   * @param key
   * product milestone link key
   *
   * @return MilestoneConfigurationSummaryDtlsList milestone configuration
   * summary details list
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public MilestoneConfigurationSummaryDtlsList listUnassociatedMilestoneForProductIDCaseType(
    ProductMilestoneLinkKey key) throws AppException, InformationalException {

    MilestoneConfigurationSummaryDtlsList milestoneDtlsList = new MilestoneConfigurationSummaryDtlsList();

    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();
    CaseTypeIDAndType caseTypeIDAndType = new CaseTypeIDAndType();

    caseTypeIDAndType.caseType = key.caseType;
    caseTypeIDAndType.caseTypeID = key.productID;
    milestoneDtlsList = milestoneLinkObj.listUnassociatedMilestones(
      caseTypeIDAndType);

    return milestoneDtlsList;
  }

  /**
   * Returns milestone link details based on the milestone link id
   *
   * @param key
   * MilestoneLinkKey - The unique id of each milestone link
   * @return MilestoneLinkAssociatedInfo milestone link details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public MilestoneLinkAssociatedInfo readMilestoneConfigurationLink(
    MilestoneLinkKey key) throws AppException, InformationalException {
    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();
    MilestoneLinkAssociatedInfo milestoneLinkAssociatedInfo = milestoneLinkObj.readMilestoneConfigurationLink(
      key);

    return milestoneLinkAssociatedInfo;
  }

  /**
   * This method helps to add the existing milestone to a selected product from
   * list of milestones which was created earlier for different products.
   *
   * @param key
   * Identifies the investigation case configuration key and the
   * milestoneTabList to be added.
   * @param caseType
   * This will have the value of case type ID and list of milestone
   * configuration ID selected by the user.
   * @param configDetails
   * The config details contain details such as creation completion
   * event details along with the component category and the component
   * type.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void addExistingMilestoneWithConfigDetails(AddMilestoneKey key,
    CaseType caseType, MilestoneLinkConfigDetails configDetails)
    throws AppException, InformationalException {
    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    milestoneLinkObj.addExistingMilestoneWithConfigDetails(key, caseType,
      configDetails);

  }

  /**
   * Adds a set of existing milestones to the investigation case.
   *
   * @param key
   * Identifies the investigation case configuration key and the
   * milestoneTabList to be added.
   * @param configDetails
   * details contain details such as creation completion event details
   * along with the component category and the component type.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addInvestigationCaseExistingMilestoneWithConfig(
    AddMilestoneKey key, MilestoneLinkConfigDetails configDetails)
    throws AppException, InformationalException {

    // Milestone Link business process object.
    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    CaseType caseType = new CaseType();

    caseType.caseType = CASETYPECODE.INVESTIGATIONCASE;

    // add existing milestone configuration to investigation case
    milestoneLinkObj.addExistingMilestoneWithConfigDetails(key, caseType,
      configDetails);

  }

  /**
   * Modifies associated configuration details for milestone link.
   *
   * @param key
   * Identifies the milestone link id
   * @param details
   * contains the details which are to be updated for the milestone
   * link
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void modifyMilestoneLinkAssociation(MilestoneLinkKey key,
    MilestoneLinkConfigDetails details) throws AppException,
      InformationalException {

    MilestoneLink milestoneLinkObj = MilestoneLinkFactory.newInstance();

    milestoneLinkObj.modifyMilestoneLinkAssociation(details, key);

  }

  // END, CR00105577

  // BEGIN, CR00080479, CW

  /**
   * Returns a list of all enabled liability products.
   *
   * @return List of all enabled liability products.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProductDetailsStruct listAllEnabledLiabilityProducts()
    throws AppException, InformationalException {

    // Return list
    ListProductDetailsStruct enabledLiabilityProductList = new ListProductDetailsStruct();

    // Retrieve all liability products
    ListProductDetailsStruct listProductDetailsStruct = listAllLiabilityProducts();

    // Filter out any products that are 'CANCELLED'
    for (int i = 0; i < listProductDetailsStruct.productDetailsStruct.size(); i++) {

      if (!listProductDetailsStruct.productDetailsStruct.item(i).statusCode.equalsIgnoreCase(
        RECORDSTATUS.CANCELLED)) {

        // Product is not 'CANCELLED' so add it to the return list
        enabledLiabilityProductList.productDetailsStruct.addRef(
          listProductDetailsStruct.productDetailsStruct.item(i));
      }
    }

    return enabledLiabilityProductList;
  }

  // END, CR00080479

  // BEGIN, CR00173421, ZV
  // ___________________________________________________________________________
  /**
   * This method replaces the deprecated method {@link #createBenefitProduct()}
   * Creates a new benefit product. This method contains additional attributes
   * to indicate if cases of this benefit type are displayed in the participants
   * programs list, in My Cases filter and in Case Search filter.
   *
   * @param details
   * Details to create a new benefit product.
   */
  public void createBenefitProduct1(BenefitProductDetails1 details)
    throws AppException, InformationalException {

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // ProductDetails object
    curam.core.struct.ProductDetails1 productDetails = new curam.core.struct.ProductDetails1();

    // ProductCategoryTabList object
    ProductCategoryTabList productCategoryTabList = new ProductCategoryTabList();

    // ProductClientTabList object
    ProductClientTabList productClientTabList = new ProductClientTabList();

    // EligibleParticipantDetails object
    EligibleParticipantDetails eligibleParticipantDetails = new EligibleParticipantDetails();

    // Assign details from input struct to productDetails
    productDetails.assign(details);

    // Need to set indicators for AdminProduct BPO
    if (details.unitCost.isPositive()) {

      productDetails.fixedCostInd = true;
    }

    if (details.unitCost.isZero() && details.calculateCostInd) {

      productDetails.notApplicableInd = true;
    }

    if (details.reviewFrequency.length() == 0) {

      productDetails.reviewFrequency = CuramConst.gkEmpty;
    }

    if (details.rerateFrequency.length() == 0) {

      productDetails.rerateFrequency = CuramConst.gkEmpty;
    }

    if (details.adjustmentFrequency.length() == 0) {

      productDetails.adjustmentFrequency = CuramConst.gkEmpty;
    }

    if (details.certificationFrequency.length() == 0) {

      productDetails.certificationFrequency = CuramConst.gkEmpty;
    }

    // Assign eligible participant details
    eligibleParticipantDetails.assign(details);

    // Call local method to create a client tab list
    productClientTabList = createClientTabList(eligibleParticipantDetails);

    productDetails.benefitInd = true;

    // Call AdminProduct BPO to insert new benefit product details
    adminProductObj.insertBenefitProduct1(productDetails,
      productCategoryTabList, productClientTabList);

    details.productID = productDetails.productID;
  }

  // ___________________________________________________________________________
  /**
   * This method replaces the deprecated method
   * {@link #createLiabilityProduct()} Creates a new liability product. This
   * method contains additional attributes to indicate if cases of this
   * liability type are displayed in the participants programs list, in My Cases
   * filter and in Case Search filter.
   *
   * @param details
   * Details to create a new liability product.
   */
  public void createLiabilityProduct1(LiabilityProductDetails1 details)
    throws AppException, InformationalException {

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // ProductDetails object
    curam.core.struct.ProductDetails1 productDetails = new curam.core.struct.ProductDetails1();

    // ProductCategoryTabList object
    ProductCategoryTabList productCategoryTabList = new ProductCategoryTabList();

    // ProductClientTabList object
    ProductClientTabList productClientTabList = new ProductClientTabList();

    // EligibleParticipantDetails object
    EligibleParticipantDetails eligibleParticipantDetails = new EligibleParticipantDetails();

    // Assign details from input struct to productDetails
    productDetails.assign(details);

    // Need to set indicators for AdminProduct BPO
    if (details.unitCost.isPositive()) {

      productDetails.fixedCostInd = true;
    }

    if (details.unitCost.isZero() && details.calculateCostInd) {

      productDetails.notApplicableInd = true;
    }

    if (details.reviewFrequency.length() == 0) {

      productDetails.reviewFrequency = CuramConst.gkEmpty;
    }

    if (details.rerateFrequency.length() == 0) {

      productDetails.rerateFrequency = CuramConst.gkEmpty;
    }

    if (details.adjustmentFrequency.length() == 0) {

      productDetails.adjustmentFrequency = CuramConst.gkEmpty;
    }

    if (details.certificationFrequency.length() == 0) {

      productDetails.certificationFrequency = CuramConst.gkEmpty;
    }

    // Assign eligible participant details
    eligibleParticipantDetails.assign(details);

    // Call local method to create a client tab list
    productClientTabList = createClientTabList(eligibleParticipantDetails);

    // Call AdminProduct BPO to insert new benefit product details
    adminProductObj.insertLiabilityProduct1(productDetails,
      productCategoryTabList, productClientTabList);

    details.productID = productDetails.productID;
  }

  /**
   * This method replaces the deprecated method {@link #modifyBenefitProduct()}
   * Modifies details of a benefit product. This method contains additional
   * attributes to indicate if cases of this benefit type are displayed in the
   * participants programs list, in My Cases filter and in Case Search filter.
   *
   * @param key
   * Product Key Struct which contains the product identifier.
   * @param details
   * Modified benefit product details
   */
  public void modifyBenefitProduct1(ProductKeyStruct key,
    BenefitProductDetails1 details) throws AppException,
      InformationalException {

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // ProductDetails object
    curam.core.struct.ProductDetails1 productDetails = new curam.core.struct.ProductDetails1();

    // ProductCategoryTabList object
    ProductCategoryTabList productCategoryTabList = new ProductCategoryTabList();

    // ProductClientTabList object
    ProductClientTabList productClientTabList = new ProductClientTabList();

    // Assign modified details to productDetails
    productDetails.assign(details);
    productDetails.productID = key.productID;

    productDetails.coverPeriodType = details.coverPeriodType;

    if (details.unitCost.isPositive()) {

      productDetails.fixedCostInd = true;
    }

    if (details.unitCost.isZero() && details.calculateCostInd) {

      productDetails.notApplicableInd = true;
    }

    if (details.reviewFrequency.length() == 0) {

      productDetails.reviewFrequency = CuramConst.gkEmpty;
    }

    if (details.rerateFrequency.length() == 0) {

      productDetails.rerateFrequency = CuramConst.gkEmpty;
    }

    if (details.adjustmentFrequency.length() == 0) {

      productDetails.adjustmentFrequency = CuramConst.gkEmpty;
    }

    if (details.certificationFrequency.length() == 0) {

      productDetails.certificationFrequency = CuramConst.gkEmpty;
    }

    // EligibleParticipantDetails object
    EligibleParticipantDetails eligibleParticipantDetails = new EligibleParticipantDetails();

    // Assign eligible participant details
    eligibleParticipantDetails.assign(details);

    // Call local method to create a client tab list
    productClientTabList = createClientTabList(eligibleParticipantDetails);

    // Call AdminProduct BPO to modify benefit product
    adminProductObj.modifyBenefitProduct1(productDetails,
      productCategoryTabList, productClientTabList);
  }

  /**
   * This method replaces the deprecated method
   * {@link #modifyLiabilityProduct()} Modifies details of a liability product.
   * This method contains additional attributes to indicate if cases of this
   * liability type are displayed in the participants programs list, in My Cases
   * filter and in Case Search filter.
   *
   * @param key
   * Product Key Struct which contains the product identifier.
   * @param details
   * Modified liability product details
   */
  public void modifyLiabilityProduct1(ProductKeyStruct key,
    LiabilityProductDetails1 details) throws AppException,
      InformationalException {

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // ProductDetails object
    curam.core.struct.ProductDetails1 productDetails = new curam.core.struct.ProductDetails1();

    // ProductCategoryTabList object
    ProductCategoryTabList productCategoryTabList = new ProductCategoryTabList();

    // ProductClientTabList object
    ProductClientTabList productClientTabList = new ProductClientTabList();

    // Assign modified details to productDetails
    productDetails.assign(details);
    productDetails.productID = key.productID;

    productDetails.coverPeriodType = details.coverPeriodType;

    // Need to set indicators for AdminProduct BPO
    if (details.unitCost.isPositive()) {

      productDetails.fixedCostInd = true;
    }

    if (details.unitCost.isZero() && details.calculateCostInd) {

      productDetails.notApplicableInd = true;
    }

    if (details.reviewFrequency.length() == 0) {

      productDetails.reviewFrequency = CuramConst.gkEmpty;
    }

    if (details.rerateFrequency.length() == 0) {

      productDetails.rerateFrequency = CuramConst.gkEmpty;
    }

    if (details.adjustmentFrequency.length() == 0) {

      productDetails.adjustmentFrequency = CuramConst.gkEmpty;
    }

    if (details.certificationFrequency.length() == 0) {

      productDetails.certificationFrequency = CuramConst.gkEmpty;
    }

    // EligibleParticipantDetails object
    EligibleParticipantDetails eligibleParticipantDetails = new EligibleParticipantDetails();

    // Assign eligible participant details
    eligibleParticipantDetails.assign(details);

    // Call local method to create a client tab list
    productClientTabList = createClientTabList(eligibleParticipantDetails);

    // Call AdminProduct BPO to modify benefit product
    adminProductObj.modifyLiabiltyProduct1(productDetails,
      productCategoryTabList, productClientTabList);
  }

  /**
   * This method replaces the deprecated method {@link #readBenefitProduct()}
   * Reads product details for the benefit product home page. This method reads
   * additional attributes which indicates if cases of this benefit type are
   * displayed in the participants programs list, in My Cases filter and in Case
   * Search filter.
   *
   * @param key
   * The product identifier for reading the product details.
   *
   * @return Details of the benefit product.
   */
  public ReadBenefitProductStruct1 readBenefitProduct1(ReadBenefitProductKey key)
    throws AppException, InformationalException {

    // Create return object
    ReadBenefitProductStruct1 readBenefitProductStruct = new ReadBenefitProductStruct1();

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // ProductKeyStruct object
    ProductKeyStruct productKeyStruct = new ProductKeyStruct();

    // Return object for AdminProduct product read
    ReadProductResult1 readProductResult = new ReadProductResult1();

    // Context Description Key
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Set key to read product details
    productKeyStruct.productID = key.productID;

    // Call AdminProduct BPO to read product details
    readProductResult = adminProductObj.readProduct1(productKeyStruct);

    // if the NULL frequency has been set for review frequency, return a blank
    // field to the user as opposed to Every day(s) which is currently used
    // to denote a NULL frequency
    if (readProductResult.dtls.reviewFrequency.equals(
      FrequencyPattern.kZeroFrequencyPattern.toString())) {
      // BEGIN, CR00049218, GM
      readProductResult.dtls.reviewFrequency = CuramConst.gkEmpty;
      // END, CR00049218
    }

    // Assign product details for return to client
    readBenefitProductStruct.benefitHomePageDetails.assign(
      readProductResult.dtls);

    readBenefitProductStruct.benefitHomePageDetails.coverPeriodType = readProductResult.dtls.coverPeriodType;

    // Assign client category details for return to client
    readBenefitProductStruct.categoriesInProduct.assign(
      readProductResult.categoriesInList);

    // Need to see what eligible participants are returned from AdminProduct
    // The corresponding indicators need to be set for return to client
    for (int i = 0; i < readProductResult.clientsEligible.dtls.size(); i++) {

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.PERSON)) {

        readBenefitProductStruct.benefitHomePageDetails.personInd = true;
      }

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.EMPLOYER)) {

        readBenefitProductStruct.benefitHomePageDetails.employerInd = true;
      }

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.UTILITY)) {

        readBenefitProductStruct.benefitHomePageDetails.utilityInd = true;
      }

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.SERVICESUPPLIER)) {

        readBenefitProductStruct.benefitHomePageDetails.serviceSupplierInd = true;
      }

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.PRODUCTPROVIDER)) {

        readBenefitProductStruct.benefitHomePageDetails.productProviderInd = true;
      }

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.INFORMATIONPROVIDER)) {

        readBenefitProductStruct.benefitHomePageDetails.informationProviderInd = true;
      }
    }

    // BEGIN, CR00241190, KH
    // Is this a CER product?
    NotFoundIndicator nf = new NotFoundIndicator();
    CREOLEProductKey productKey = new CREOLEProductKey();

    productKey.productID = key.productID;
    CREOLEProductFactory.newInstance().read(nf, productKey);

    if (!nf.isNotFound()) {
      // This is a CER product
      readBenefitProductStruct.benefitHomePageDetails.cerProductInd = true;
    }
    // END, CR00241190

    // Set key to retrieve product context description
    productContextDescriptionKey.productID = key.productID;

    // Get Context Description
    readBenefitProductStruct.contextDescription = getProductContextDescription(
      productContextDescriptionKey);
    // BEGIN, CR00235514, PB
    if (!readBenefitProductStruct.benefitHomePageDetails.adminTranslationRequiredInd) {
      readBenefitProductStruct.benefitHomePageDetails.adminTranslationRequiredInd = false;
    }
    // END, CR00235514
    return readBenefitProductStruct;
  }

  /**
   * This method replaces the deprecated method {@link #readLiabilityProduct()}
   * Reads details of a liability product. This method reads additional
   * attributes which indicate if cases of this liability type are displayed in
   * the participants programs list, in My Cases filter and in Case Search
   * filter.
   *
   * @param key
   * This contains the product identifier.
   *
   * @return ReadLiabilityProductStruct Contains liability product information.
   */
  public ReadLiabilityProductStruct1 readLiabilityProduct1(ProductKeyStruct key)
    throws AppException, InformationalException {

    // Create return object
    ReadLiabilityProductStruct1 readLiabilityProductStruct = new ReadLiabilityProductStruct1();

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // ProductKeyStruct object
    ProductKeyStruct productKeyStruct = new ProductKeyStruct();

    // Return object for AdminProduct product read
    ReadProductResult1 readProductResult = new ReadProductResult1();

    // Context Description Key
    ProductContextDescriptionKey productContextDescriptionKey = new ProductContextDescriptionKey();

    // Set key to read product details
    productKeyStruct.productID = key.productID;

    // Call AdminProduct BPO to read product details
    readProductResult = adminProductObj.readProduct1(productKeyStruct);

    // if the NULL frequency has been set for review frequency, return a blank
    // field to the user as opposed to Every day(s) which is currently used
    // to denote a NULL frequency
    if (readProductResult.dtls.reviewFrequency.equals(
      FrequencyPattern.kZeroFrequencyPattern.toString())) {
      // BEGIN, CR00049218, GM
      readProductResult.dtls.reviewFrequency = CuramConst.gkEmpty;
      // END, CR00049218

    }

    // Assign product details for return to client
    readLiabilityProductStruct.liabilityProductDetails.assign(
      readProductResult.dtls);

    readLiabilityProductStruct.liabilityProductDetails.coverPeriodType = readProductResult.dtls.coverPeriodType;

    // Assign client category details for return to client
    readLiabilityProductStruct.categoriesInProduct.assign(
      readProductResult.categoriesInList);

    // Need to see what eligible participants are returned from AdminProduct
    // The corresponding indicators need to be set for return to client
    for (int i = 0; i < readProductResult.clientsEligible.dtls.size(); i++) {

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.PERSON)) {

        readLiabilityProductStruct.liabilityProductDetails.personInd = true;
      }

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.EMPLOYER)) {

        readLiabilityProductStruct.liabilityProductDetails.employerInd = true;
      }

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.UTILITY)) {

        readLiabilityProductStruct.liabilityProductDetails.utilityInd = true;
      }

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.SERVICESUPPLIER)) {

        readLiabilityProductStruct.liabilityProductDetails.serviceSupplierInd = true;
      }

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.PRODUCTPROVIDER)) {

        readLiabilityProductStruct.liabilityProductDetails.productProviderInd = true;
      }

      if (readProductResult.clientsEligible.dtls.item(i).clientType.equals(
        CONCERNROLETYPE.INFORMATIONPROVIDER)) {

        readLiabilityProductStruct.liabilityProductDetails.informationProviderInd = true;
      }
    }

    // BEGIN, CR00241190, KH
    // Is this a CER product?
    NotFoundIndicator nf = new NotFoundIndicator();
    CREOLEProductKey productKey = new CREOLEProductKey();

    productKey.productID = key.productID;
    CREOLEProductFactory.newInstance().read(nf, productKey);

    if (!nf.isNotFound()) {
      // This is a CER product
      readLiabilityProductStruct.liabilityProductDetails.cerProductInd = true;
    }
    // END, CR00241190

    // Set key to retrieve product context description
    productContextDescriptionKey.productID = key.productID;

    // Get Context Description
    readLiabilityProductStruct.contextDescription = getProductContextDescription(
      productContextDescriptionKey);

    return readLiabilityProductStruct;
  }

  /**
   * Returns default details to create new product.
   *
   * @return Default product details.
   */
  public ProductDefaultValuesDetails getProductDefaultValues()
    throws AppException, InformationalException {

    ProductDefaultValuesDetails productDefaultValuesDetails = new ProductDefaultValuesDetails();

    productDefaultValuesDetails.myCasesFilterInd = true;
    productDefaultValuesDetails.caseSearchFilterInd = true;

    return productDefaultValuesDetails;
  }

  // END, CR00173421

  // BEGIN, CR00209689, CSH
  /**
   * Reads product details for the correction product home page. This method
   * reads additional attributes which indicates if cases associated with this
   * product type are displayed in the participants programs list, in the My
   * Cases filter and in the Case Search filter.
   *
   * @param key
   * The product identifier for reading the product details.
   *
   * @return Details of the benefit product.
   */
  public CorrectionProductDetails readCorrection(ReadBenefitProductKey key)
    throws AppException, InformationalException {

    // Create return object
    CorrectionProductDetails correctionProductDetails = new CorrectionProductDetails();

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // ProductKeyStruct object
    ProductKeyStruct productKeyStruct = new ProductKeyStruct();

    // Return object for AdminProduct product read
    ReadProductResult1 readProductResult = new ReadProductResult1();

    // Set key to read product details
    productKeyStruct.productID = key.productID;

    // Call AdminProduct BPO to read product details
    readProductResult = adminProductObj.readProduct1(productKeyStruct);
    correctionProductDetails.assign(readProductResult.dtls);

    // if the NULL frequency has been set for review frequency, return a blank
    // field to the user as opposed to Every day(s) which is currently used
    // to denote a NULL frequency
    if (readProductResult.dtls.reviewFrequency.equals(
      FrequencyPattern.kZeroFrequencyPattern.toString())) {

      readProductResult.dtls.reviewFrequency = CuramConst.gkEmpty;
    }

    return correctionProductDetails;
  }

  /**
   * Reads product details for the correction product home page. This method
   * reads additional attributes which indicates if cases associated with this
   * product type are displayed in the participants programs list, in the My
   * Cases filter and in the Case Search filter.
   *
   * @param key
   * The product identifier for reading the product details.
   *
   * @return Details of the benefit product.
   */
  public void modifyCorrection(CorrectionProductDetails details)
    throws AppException, InformationalException {

    // AdminProduct business object
    curam.core.intf.AdminProduct adminProductObj = curam.core.fact.AdminProductFactory.newInstance();

    // ProductDetails object
    curam.core.struct.ProductDetails1 productDetails = new curam.core.struct.ProductDetails1();

    // Assign modified details to productDetails
    productDetails.assign(details);
    productDetails.productID = details.productID;

    productDetails.coverPeriodType = details.coverPeriodType;

    if (details.unitCost.isPositive()) {

      productDetails.fixedCostInd = true;
    }

    if (details.unitCost.isZero() && details.calculateCostInd) {

      productDetails.notApplicableInd = true;
    }

    if (details.reviewFrequency.length() == 0) {

      productDetails.reviewFrequency = CuramConst.gkEmpty;
    }

    if (details.adjustmentFrequency.length() == 0) {

      productDetails.adjustmentFrequency = CuramConst.gkEmpty;
    }

    // Call AdminProduct BPO to modify benefit product
    adminProductObj.modifyCorrectionProduct(productDetails);
  }

  // END, CR00209689

  /**
   * Retrieves the list of Assessment Configuration relationships for the
   * specified Product, Includes versionNo.
   *
   * @param key
   * The Product Key
   *
   * @return List of Assessment Configuration
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PDAssessmentConfigurationSummaryDetailsListAndVersionNo listAssessmentConfigsForProductAndVersionNo(
    ProductKey key) throws AppException, InformationalException {

    // Product Assessment Configuration BPO
    ProductAssessmentConfiguration productAssessmentConfigurationObj = ProductAssessmentConfigurationFactory.newInstance();

    // Return Object
    PDAssessmentConfigurationSummaryDetailsListAndVersionNo pdAssessmentConfigurationDetailsList = new PDAssessmentConfigurationSummaryDetailsListAndVersionNo();

    // Retrieve the list of Assessment Configurations associated to a product
    pdAssessmentConfigurationDetailsList.list = productAssessmentConfigurationObj.listAssessmentConfigsForProductAndVersionNo(
      key);

    return pdAssessmentConfigurationDetailsList;
  }

  /**
   * Returns a list of Product Time Constraint records, includes versionNo
   *
   * @param key
   * Identifies the product time constraint to be read.
   *
   * @return Details of the product time constraint record.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListProductTimeConstraintAndVersionNo listProductTimeConstaintAndVersionNo(
    ReadProductTimeConstraintRMKey key) throws AppException,
      InformationalException {

    // create a return object
    ListProductTimeConstraintAndVersionNo listProductTimeConstraint = new ListProductTimeConstraintAndVersionNo();

    // product time constraint business object and key
    curam.core.sl.intf.ProductTimeConstraint productTimeConstraintObj = curam.core.sl.fact.ProductTimeConstraintFactory.newInstance();

    // list product time constraints
    listProductTimeConstraint.dtls = productTimeConstraintObj.listProductTimeConstraintsAndVersionNo(
      key.readMultiKey);

    return listProductTimeConstraint;
  }

  // ___________________________________________________________________________
  /**
   * This method lists all existing approval checks for a particular
   * investigation and version Numbers.
   *
   * @param key
   * The unique id of the investigation that the approval checks are
   * being listed for.
   * @return A list of approval checks for the specified investigation and
   * version numbers.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListInvestigationApprovalCheckDetailsAndVersionNo listApprovalCheckForInvestigationAndVersionNo(
    InvestigationConfigKey key) throws AppException, InformationalException {

    // Return Object
    ListInvestigationApprovalCheckDetailsAndVersionNo listInvestigationApprovalCheckDetails = new ListInvestigationApprovalCheckDetailsAndVersionNo();

    // InvestigationApprovalCheck business object
    curam.core.sl.intf.InvestigationApprovalCheck investigationApprovalCheckObj = curam.core.sl.fact.InvestigationApprovalCheckFactory.newInstance();

    // Call InvestigationApprovalCheck BPO to perform the list operation
    listInvestigationApprovalCheckDetails.dtls = investigationApprovalCheckObj.listApprovalChecksForInvestigationAndVersionNo(
      key);

    return listInvestigationApprovalCheckDetails;
  }

  // BEGIN, CR00221293, SS
  /**
   * This method is to create absence reason configuration which set the absence
   * reason is payable, non-payable or acceptable for the product and there
   * cannot be two active configuration for the same absence reason.
   *
   * @param dtls
   * contains the details of the absence reason record to be inserted
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void createAbsenceReasonConfiguration(
    AbsenceReasonConfigurationDtls dtls) throws AppException,
      InformationalException {

    final AbsenceReasonConfiguration absenceReasonConfiguration = absenceReasonConfigurationDAO.newInstance();

    absenceReasonConfiguration.setAssociateID(dtls.associateID);
    absenceReasonConfiguration.setAbsenceReasonCode(dtls.absenceReasonCode);
    absenceReasonConfiguration.setAbsenceReasonPayable(
      dtls.absenceReasonPayableInd);
    absenceReasonConfiguration.setAbsenceReasonDeductible(
      dtls.absenceReasonDeductibleInd);
    absenceReasonConfiguration.setAssociateType(
      ABSENCEREASONASSOCIATETYPEEntry.PRODUCT.getCode());
    absenceReasonConfiguration.setIsAcceptable(dtls.isAcceptable);
    absenceReasonConfiguration.insert();

  }

  /**
   * This method is to logically delete the absence reason for the product
   * offering which is payable, acceptable or non-payable.
   *
   * @param versionNo
   * contains versionNo.
   * @param key
   * contains absenceReasonID.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteAbsenceReasonConfiguration(VersionNo versionNo,
    AbsenceReasonConfigurationKey key) throws AppException,
      InformationalException {
    final AbsenceReasonConfiguration absenceReasonConfiguration = absenceReasonConfigurationDAO.get(
      key.absenceReasonID);

    absenceReasonConfiguration.cancel(versionNo.versionNo);

  }

  /**
   * This method is to list all the active absence reason configuration to
   * identify the list of absence reason configured for the product is payable,
   * non-payable or acceptable.
   *
   * @param key
   * Contains associateID for the product.
   * @return List of absence reason configuration details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public AbsenceReasonConfigurationDetailsList listAbsenceReasonConfiguration(
    AssociateIDKey key) throws AppException, InformationalException {
    final AbsenceReasonConfigurationDetailsList absenceReasonDetailsList = new AbsenceReasonConfigurationDetailsList();

    for (final AbsenceReasonConfiguration absenceReason : absenceReasonConfigurationDAO.searchByAssociateID(
      key.key.associateID)) {
      absenceReasonDetailsList.dtlsList.addRef(
        getAbsenceReasonFields(absenceReason));
    }
    return absenceReasonDetailsList;
  }

  /**
   * This method is to modify absence reason configuration for the absence
   * reasons to identify for the product is payable , acceptable or non-payable.
   *
   * @param dtls
   * contains the absence reason details to be updated.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyAbsenceReasonConfiguration(
    AbsenceReasonConfigurationDtls dtls) throws AppException,
      InformationalException {

    final AbsenceReasonConfiguration absenceReasonConfiguration = absenceReasonConfigurationDAO.get(
      dtls.absenceReasonID);

    absenceReasonConfiguration.setAbsenceReasonPayable(
      dtls.absenceReasonPayableInd);
    absenceReasonConfiguration.setAbsenceReasonDeductible(
      dtls.absenceReasonDeductibleInd);
    absenceReasonConfiguration.setIsAcceptable(dtls.isAcceptable);
    absenceReasonConfiguration.modify(dtls.versionNo);
  }

  /**
   * This method is to read absence reason configuration to identify for the
   * product is payable, acceptable or non-payable for the absence reason.
   *
   * @param key
   * Contains absenceReasonID.
   *
   * @return The absence reason details for the product.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public AbsenceReasonConfigurationDtls readAbsenceReasonConfiguration(
    AbsenceReasonConfigurationKey key) throws AppException,
      InformationalException {
    AbsenceReasonConfigurationDtls absenceReasonDtls = new AbsenceReasonConfigurationDtls();

    AbsenceReasonConfiguration absenceReason = absenceReasonConfigurationDAO.get(
      key.absenceReasonID);

    absenceReasonDtls.absenceReasonID = key.absenceReasonID;
    absenceReasonDtls.absenceReasonCode = absenceReason.getAbsenceReasoncode().toString();
    absenceReasonDtls.absenceReasonDeductibleInd = absenceReason.isAbsenceReasonDeductibleEnabled();
    absenceReasonDtls.absenceReasonPayableInd = absenceReason.isAbsenceReasonPayableEnabled();
    absenceReasonDtls.associateID = absenceReason.getAssociateID();
    absenceReasonDtls.associateType = absenceReason.getAssociateType().toString();
    absenceReasonDtls.isAcceptable = absenceReason.isAcceptable();
    absenceReasonDtls.recordStatus = absenceReason.getLifecycleState().toString();
    absenceReasonDtls.versionNo = absenceReason.getVersionNo();

    return absenceReasonDtls;
  }

  /**
   * This method is to set the absence reason configuration details which
   * consisting of absence reason and indicator to identify whether it is
   * payable or non-payable for the service offering or agency.
   *
   * @param absenceReason
   * Contain details of absence reason.
   *
   * @return The updated details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public AbsenceReasonConfigurationDtls getAbsenceReasonFields(
    AbsenceReasonConfiguration absenceReason) throws AppException,
      InformationalException {

    AbsenceReasonConfigurationDtls absenceReasonDtls = new AbsenceReasonConfigurationDtls();

    absenceReasonDtls.absenceReasonID = absenceReason.getAbsenceReasonID();
    absenceReasonDtls.associateType = absenceReason.getAssociateType().toString();
    absenceReasonDtls.absenceReasonCode = absenceReason.getAbsenceReasoncode().toString();
    absenceReasonDtls.absenceReasonDeductibleInd = absenceReason.isAbsenceReasonDeductibleEnabled();
    absenceReasonDtls.absenceReasonPayableInd = absenceReason.isAbsenceReasonPayableEnabled();
    absenceReasonDtls.isAcceptable = absenceReason.isAcceptable();
    absenceReasonDtls.associateID = absenceReason.getAssociateID();
    absenceReasonDtls.recordStatus = absenceReason.getLifecycleState().toString();
    absenceReasonDtls.versionNo = absenceReason.getVersionNo();

    return absenceReasonDtls;
  }

  // END CR00221293

  // BEGIN, CR00224271, ZV
  /**
   * Returns a list of Delivery Pattern Names and Concerned Preferred delivery
   * method indicator.
   *
   * @param key
   * The Key contains productID and concernRoleID
   *
   * @return List of all Delivery Pattern Names and concern preferred delivery
   * method indicator.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public DeliveryPatternNamePrefMethodPmtIndDtlsList1 listDeliveryPatternPreferredMethodOfPayment1(
    final ProductIDAndConcernRoleID key) throws AppException,
      InformationalException {

    // Details List to be returned
    DeliveryPatternNamePrefMethodPmtIndDtlsList1 deliveryPatternNamePrefMethodPmtIndDtlsList = new DeliveryPatternNamePrefMethodPmtIndDtlsList1();

    // details of Method of pmt code of this concern
    curam.core.struct.DeliveryMethodType deliveryMethodType;

    // get the concern default method of payment code
    ConcernRoleID concernRoleID = new ConcernRoleID();

    concernRoleID.concernRoleID = key.concernRoleID;
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    deliveryMethodType = maintainInstructionLineItemObj.getDeliveryMethodForConcernRole(
      concernRoleID);

    // BEGIN, CR00146808, CD
    // find out if the primary participant has an associated bank account
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;
    BankAccountAndPublicOfficeDetails bankDtls = concernRoleObj.readBankAccountAndPublicOfficeIDs(
      concernRoleKey);

    boolean noBankAccount = bankDtls.primaryBankAccountID == 0L;

    // Create an informational manager
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();
    // END, CR00146808

    // Get the list of Delivery patterns names for the product.
    ListDeliveryPatternNameDetails listDeliveryPatternNameDetails = new ListDeliveryPatternNameDetails();
    ListDeliveryPatternNamesKey listDeliveryPatternNamesKey = new ListDeliveryPatternNamesKey();

    listDeliveryPatternNamesKey.productID = key.productID;

    listDeliveryPatternNameDetails = listDeliveryPatternNames(
      listDeliveryPatternNamesKey);

    // Copy list to return object
    for (int i = 0; i < listDeliveryPatternNameDetails.dtls.size(); i++) {

      DeliveryPatternNamePrefMethodPmtIndDetails1 deliveryPatternNamePrefMethodPmtIndDetails = new DeliveryPatternNamePrefMethodPmtIndDetails1();

      // Read the delivery pattern details for the product
      ReadDeliveryPatternKey readDeliveryPatternKey = new ReadDeliveryPatternKey();
      ReadDeliveryPatternDetails readDeliveryPatternDetails = new ReadDeliveryPatternDetails();

      readDeliveryPatternKey.adminPDPIIDKey.productDeliveryPatternInfoID = listDeliveryPatternNameDetails.dtls.item(i).productDeliveryPatternInfoID;

      readDeliveryPatternDetails = readDeliveryPattern(readDeliveryPatternKey);

      // compare concern preferred delivery method of payment code with
      // current delivery pattern
      if (deliveryMethodType.deliveryMethodType.equals(
        readDeliveryPatternDetails.productDeliveryPatternInfoDetails.deliveryMethodTypeCode)) {

        deliveryPatternNamePrefMethodPmtIndDetails.concernPrefDeliveryMthdInd = true;

      }

      // BEGIN, CR00146808, CD
      if (noBankAccount
        && readDeliveryPatternDetails.productDeliveryPatternInfoDetails.deliveryMethodTypeCode.equals(
          METHODOFDELIVERY.EFT)) {
        if (deliveryPatternNamePrefMethodPmtIndDtlsList.informationalMsgDtlsList.dtls.size()
          == 0) {

          // Add the message to the informational manager
          AppException e = new AppException(
            BPOPRODUCT.INF_PRODUCT_EFT_DELIVERY_NO_ACCOUNT);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            e.arg(true), CuramConst.gkEmpty,
            curam.util.exception.InformationalElement.InformationalType.kWarning,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

        }
        deliveryPatternNamePrefMethodPmtIndDetails.selectLinkInd = false;
      } else {
        deliveryPatternNamePrefMethodPmtIndDetails.selectLinkInd = true;
      }
      // END, CR00146808

      // BEGIN, CR00092443, CSH
      // Set the client's preferred delivery method on the return struct
      deliveryPatternNamePrefMethodPmtIndDtlsList.preferredDeliveryMethod = deliveryMethodType.deliveryMethodType;
      // END, CR00092443

      deliveryPatternNamePrefMethodPmtIndDetails.name = listDeliveryPatternNameDetails.dtls.item(i).name;
      deliveryPatternNamePrefMethodPmtIndDetails.productDeliveryPatternID = listDeliveryPatternNameDetails.dtls.item(i).productDeliveryPatternID;
      deliveryPatternNamePrefMethodPmtIndDetails.productDeliveryPatternInfoID = listDeliveryPatternNameDetails.dtls.item(i).productDeliveryPatternInfoID;

      deliveryPatternNamePrefMethodPmtIndDtlsList.dtls.addRef(
        deliveryPatternNamePrefMethodPmtIndDetails);
    }

    // BEGIN, CR00146808, CD
    // Retrieve list of informational messages
    String[] messages = informationalManager.obtainInformationalAsString();

    // Return the Informational messages
    for (int i = 0; i < messages.length; i++) {

      InformationalMsgDtls infoMsg = new InformationalMsgDtls();

      infoMsg.informationMsgTxt = messages[i];

      deliveryPatternNamePrefMethodPmtIndDtlsList.informationalMsgDtlsList.dtls.addRef(
        infoMsg);
    }
    // END, CR00146808

    // Return delivery pattern details
    return deliveryPatternNamePrefMethodPmtIndDtlsList;

  }

  // END, CR00224271

  // BEGIN, CR00233651, GP
  /**
   * Assigns the text translation details.
   *
   * @param textTranslation
   * The text translation information.
   *
   * @return The text translation details.
   */
  protected TextTranslationDetails assignTextTranslationDtls(
    final TextTranslation textTranslation) {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    textTranslationDetails.dtls.localeCode = textTranslation.getLocale().getCode();
    textTranslationDetails.dtls.localizableTextID = textTranslation.getLocalizableTextID();

    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
      textTranslationDetails.dtls.localizableTextID);

    // BEGIN, CR00234640, GP
    if (localizableTextHandler.isShortTextInd()) {
      // END, CR00234640
      textTranslationDetails.dtls.shortText = textTranslation.getShortText();
    } else {
      textTranslationDetails.dtls.text = textTranslation.getText();
    }

    textTranslationDetails.dtls.textTranslationID = textTranslation.getID();
    return textTranslationDetails;
  }

  /**
   * Provides text translation for the attribute.
   *
   * @param LocalizableTextDetails
   * The localizable text translation details.
   *
   * @return The view localizable text details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  protected ViewLocalizableTextDetails getTextTranslation(
    final LocalizableTextDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
      localizableTextTranslationDetails.dtls.localizableTextID);
    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();

    viewLocalizableTextDetails.dtls.localizableTextID = localizableTextHandler.getID();

    for (TextTranslation textTranslation : localizableTextHandler.listTranslations()) {

      TextTranslationDetails textTranslationDetails = assignTextTranslationDtls(
        textTranslation);

      viewLocalizableTextDetails.translations.dtls.addRef(
        textTranslationDetails);

    }
    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the Milestone attribute, name.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Milestone name.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addMilestoneNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

    milestoneConfigurationObj.addNameTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the Milestone attribute, name.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Milestone name.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyMilestoneNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

    milestoneConfigurationObj.modifyNameTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the Milestone attribute, name.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the Milestone name.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TextTranslationDetails readMilestoneNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

      MilestoneConfigurationDtls milestoneConfigurationDtls = new MilestoneConfigurationDtls();
      MilestoneConfigurationKey milestoneConfigurationKey = new MilestoneConfigurationKey();

      milestoneConfigurationKey.milestoneConfigurationID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from MilestoneConfiguration
      // entity.
      milestoneConfigurationDtls.dtls = milestoneConfigurationObj.read(
        milestoneConfigurationKey);

      textTranslationDetails.dtls.shortText = milestoneConfigurationDtls.dtls.dtls.name;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the Milestone attribute, name.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the name.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewLocalizableTextDetails listLocalizableMilestoneNameText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

    MilestoneConfigurationDtls milestoneConfigurationDtls = new MilestoneConfigurationDtls();
    MilestoneConfigurationKey milestoneConfigurationKey = new MilestoneConfigurationKey();

    milestoneConfigurationKey.milestoneConfigurationID = localizableTextDetails.dtls.localizableTextParentID;

    milestoneConfigurationDtls.dtls = milestoneConfigurationObj.read(
      milestoneConfigurationKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != milestoneConfigurationDtls.dtls.dtls.nameTextID) {

      LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = milestoneConfigurationDtls.dtls.dtls.nameTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);

    } else {

      // Handle legacy data.
      // As there is no localization yet, read it from MilestoneConfiguration
      // entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.shortText = milestoneConfigurationDtls.dtls.dtls.name;
      if (!textTranslationDetails.dtls.shortText.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the Milestone attribute, type.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Milestone type.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addMilestoneTypeTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

    milestoneConfigurationObj.addTypeTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the Milestone attribute, Type.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Milestone Type.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyMilestoneTypeTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

    milestoneConfigurationObj.modifyTypeTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the Milestone attribute, Type.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the Milestone Type.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TextTranslationDetails readMilestoneTypeTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

      MilestoneConfigurationDtls milestoneConfigurationDtls = new MilestoneConfigurationDtls();
      MilestoneConfigurationKey milestoneConfigurationKey = new MilestoneConfigurationKey();

      milestoneConfigurationKey.milestoneConfigurationID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from MilestoneConfiguration
      // entity.
      milestoneConfigurationDtls.dtls = milestoneConfigurationObj.read(
        milestoneConfigurationKey);

      textTranslationDetails.dtls.shortText = milestoneConfigurationDtls.dtls.dtls.type;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the Milestone attribute, type.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the type.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewLocalizableTextDetails listLocalizableMilestoneTypeText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

    MilestoneConfigurationDtls milestoneConfigurationDtls = new MilestoneConfigurationDtls();
    MilestoneConfigurationKey milestoneConfigurationKey = new MilestoneConfigurationKey();

    milestoneConfigurationKey.milestoneConfigurationID = localizableTextDetails.dtls.localizableTextParentID;

    milestoneConfigurationDtls.dtls = milestoneConfigurationObj.read(
      milestoneConfigurationKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != milestoneConfigurationDtls.dtls.dtls.typeTextID) {

      LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = milestoneConfigurationDtls.dtls.dtls.typeTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);

    } else {

      // Handle legacy data.
      // As there is no localization yet, read it from MileStone Configuration
      // entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.shortText = milestoneConfigurationDtls.dtls.dtls.type;
      if (!textTranslationDetails.dtls.shortText.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the Milestone attribute, comments.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Milestone
   * comments.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addMilestoneCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

    milestoneConfigurationObj.addCommentsTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the Milestone attribute,
   * comments.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Milestone comments.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyMilestoneCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

    milestoneConfigurationObj.modifyCommentsTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the Milestone attribute, Comments.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the Milestone Comments.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TextTranslationDetails readMilestoneCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

      MilestoneConfigurationDtls milestoneConfigurationDtls = new MilestoneConfigurationDtls();
      MilestoneConfigurationKey milestoneConfigurationKey = new MilestoneConfigurationKey();

      milestoneConfigurationKey.milestoneConfigurationID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from MilestoneConfiguration
      // entity.
      milestoneConfigurationDtls.dtls = milestoneConfigurationObj.read(
        milestoneConfigurationKey);

      textTranslationDetails.dtls.text = milestoneConfigurationDtls.dtls.dtls.comments;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the Milestone attribute, Comments.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the Comments.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewLocalizableTextDetails listLocalizableMilestoneCommentsText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    MilestoneConfiguration milestoneConfigurationObj = MilestoneConfigurationFactory.newInstance();

    MilestoneConfigurationDtls milestoneConfigurationDtls = new MilestoneConfigurationDtls();
    MilestoneConfigurationKey milestoneConfigurationKey = new MilestoneConfigurationKey();

    milestoneConfigurationKey.milestoneConfigurationID = localizableTextDetails.dtls.localizableTextParentID;

    milestoneConfigurationDtls.dtls = milestoneConfigurationObj.read(
      milestoneConfigurationKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);

    } else if (0 != milestoneConfigurationDtls.dtls.dtls.commentsTextID) {

      LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = milestoneConfigurationDtls.dtls.dtls.commentsTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);

    } else {

      // Handle legacy data.
      // As there is no localization yet, read it from MileStone Configuration
      // entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = milestoneConfigurationDtls.dtls.dtls.comments;
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  // END, CR00233651

  // BEGIN, CR00235829, GP
  /**
   * Creates a text translation for the ProductDeliveryPatternInfo attribute,
   * name.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for DeliveryPattern
   * name.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addDeliveryPatternNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    AdminProductDeliveryPatternInfoFactory.newInstance().addNameTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the ProductDeliveryPatternInfo
   * attribute, name.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of DeliveryPattern
   * name.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyDeliveryPatternNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    AdminProductDeliveryPatternInfoFactory.newInstance().modifyNameTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the ProductDeliveryPatternInfo attribute,
   * name.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the DeliveryPattern name.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TextTranslationDetails readDeliveryPatternNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      ProductDeliveryPatternInfo productDeliveryPatternInfoObj = curam.core.fact.ProductDeliveryPatternInfoFactory.newInstance();

      ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls = new ProductDeliveryPatternInfoDtls();
      ProductDeliveryPatternInfoKey productDeliveryPatternInfoKey = new ProductDeliveryPatternInfoKey();

      productDeliveryPatternInfoKey.productDeliveryPatternInfoID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from
      // ProductDeliveryPatternInfo
      // entity.
      productDeliveryPatternInfoDtls = productDeliveryPatternInfoObj.read(
        productDeliveryPatternInfoKey);

      textTranslationDetails.dtls.shortText = productDeliveryPatternInfoDtls.name;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the ProductDeliveryPatternInfo attribute,
   * name.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the name.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewLocalizableTextDetails listLocalizableDeliveryPatternNameText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    ProductDeliveryPatternInfo productDeliveryPatternInfoObj = curam.core.fact.ProductDeliveryPatternInfoFactory.newInstance();

    ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls = new ProductDeliveryPatternInfoDtls();
    ProductDeliveryPatternInfoKey productDeliveryPatternInfoKey = new ProductDeliveryPatternInfoKey();

    productDeliveryPatternInfoKey.productDeliveryPatternInfoID = localizableTextDetails.dtls.localizableTextParentID;

    productDeliveryPatternInfoDtls = productDeliveryPatternInfoObj.read(
      productDeliveryPatternInfoKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != productDeliveryPatternInfoDtls.nameTextID) {

      LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = productDeliveryPatternInfoDtls.nameTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);

    } else {

      // Handle legacy data.
      // As there is no localization yet, read it from
      // ProductDeliveryPatternInfo
      // entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.shortText = productDeliveryPatternInfoDtls.name;
      viewLocalizableTextDetails.translations.dtls.addRef(
        textTranslationDetails);
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the ProductDeliveryPatternInfo attribute,
   * Comments.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for DeliveryPattern
   * name.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addDeliveryPatternCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    AdminProductDeliveryPatternInfoFactory.newInstance().addCommentsTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Modifies the text translation details for the ProductDeliveryPatternInfo
   * attribute, Comments.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of DeliveryPattern
   * comments.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyDeliveryPatternCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    AdminProductDeliveryPatternInfoFactory.newInstance().modifyCommentsTextTranslation(
      localizableTextDetails.dtls);
  }

  /**
   * Reads the text translation for the ProductDeliveryPatternInfo attribute,
   * Comments.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the DeliveryPattern Comments.
   *
   * @return The Text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TextTranslationDetails readDeliveryPatternCommentsTextTranslation(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      ProductDeliveryPatternInfo productDeliveryPatternInfoObj = curam.core.fact.ProductDeliveryPatternInfoFactory.newInstance();

      ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls = new ProductDeliveryPatternInfoDtls();
      ProductDeliveryPatternInfoKey productDeliveryPatternInfoKey = new ProductDeliveryPatternInfoKey();

      productDeliveryPatternInfoKey.productDeliveryPatternInfoID = localizableTextDetails.dtls.localizableTextParentID;

      // As there is no localization yet, read it from
      // ProductDeliveryPatternInfo
      // entity.
      productDeliveryPatternInfoDtls = productDeliveryPatternInfoObj.read(
        productDeliveryPatternInfoKey);

      textTranslationDetails.dtls.text = productDeliveryPatternInfoDtls.comments;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the ProductDeliveryPatternInfo attribute,
   * Comments.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the Comments.
   *
   * @return The view text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewLocalizableTextDetails listLocalizableDeliveryPatternCommentsText(
    final LocalizableTextDetails localizableTextDetails) throws AppException,
      InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();
    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    ProductDeliveryPatternInfo productDeliveryPatternInfoObj = curam.core.fact.ProductDeliveryPatternInfoFactory.newInstance();

    ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls = new ProductDeliveryPatternInfoDtls();
    ProductDeliveryPatternInfoKey productDeliveryPatternInfoKey = new ProductDeliveryPatternInfoKey();

    productDeliveryPatternInfoKey.productDeliveryPatternInfoID = localizableTextDetails.dtls.localizableTextParentID;

    productDeliveryPatternInfoDtls = productDeliveryPatternInfoObj.read(
      productDeliveryPatternInfoKey);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } else if (0 != productDeliveryPatternInfoDtls.commentsTextID) {

      LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = productDeliveryPatternInfoDtls.commentsTextID;
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);

    } else {

      // Handle legacy data.
      // As there is no localization yet, read it from
      // ProductDeliveryPatternInfo
      // entity.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = productDeliveryPatternInfoDtls.comments;
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  // END, CR00235829

  // BEGIN, CR00285981, ZV
  /**
   * Modifies a deduction product link record.
   *
   * @param details Deduction product link details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyDeduction(ModifyProductDeductionDetails details)
    throws AppException, InformationalException {

    DeductionProductLink deductionProductLinkObj = DeductionProductLinkFactory.newInstance();

    // Modify priority for a deduction
    deductionProductLinkObj.modify(details.deductionDtls);
  }

  /**
   * Reads a deduction and deduction product link details.
   *
   * @param details Deduction product link key
   *
   * @return Deduction and deduction product link details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadDeductionDtls readDeduction(DeductionProductLinkKey key)
    throws AppException, InformationalException {

    ReadDeductionDtls readDeductionDtls = new ReadDeductionDtls();

    // Read product deduction details
    DeductionProductLink deductionProductLinkObj = DeductionProductLinkFactory.newInstance();

    DeductionProductLinkDetails deductionProductLinkDetails = deductionProductLinkObj.read(
      key.key);

    Resource resourceObj = ResourceFactory.newInstance();
    DeductionKey deductionKey = new DeductionKey();

    deductionKey.key.key.deductionID = deductionProductLinkDetails.dtls.deductionID;

    // Read deduction details
    readDeductionDtls = resourceObj.readDeduction(deductionKey);

    readDeductionDtls.dtls.dtls.preventOverlappingInd = deductionProductLinkDetails.dtls.preventOverlappingInd;
    readDeductionDtls.dtls.dtls.priority = deductionProductLinkDetails.dtls.priority;

    return readDeductionDtls;
  }
  // END, CR00285981

}
