/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.clientdiary.impl;


import com.google.inject.ImplementedBy;

import curam.core.impl.CuramConst;
import curam.participant.impl.ConcernRole;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;


/**
 * Utility interface for {@link ScheduledAppointment} and {@link ClientDiary}
 * functionality.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@ImplementedBy(ScheduledAppointmentHandlerImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ScheduledAppointmentHandler {

  /**
   * Cancels the {@link ClientDiary} record for the given {@link ConcernRole}
   * and {@link ScheduledAppointment} if one exists.
   *
   * @param concernRole
   * The concern role to search by
   * @param scheduledAppointment
   * The scheduled appointment to search by
   * @throws InformationalException
   * Generic Exception Signature
   */
  void cancel(final ConcernRole concernRole,
    final ScheduledAppointment scheduledAppointment)
    throws InformationalException;

  /**
   * Cancels all {@link ClientDiary} records for the given
   * {@link ScheduledAppointment} if any exist.
   *
   * @param scheduledAppointment
   * The scheduled appointment to search by
   * @throws InformationalException
   * Generic Exception Signature
   */
  void cancel(final ScheduledAppointment scheduledAppointment)
    throws InformationalException;

  /**
   * Creates a {@link ClientDiary} record for the given {@link ConcernRole},
   * {@link ScheduledAppointment} and date range.
   *
   * @param concernRole
   * The client the appointment is for
   * @param scheduledAppointment
   * The details of the scheduled appointment
   * @param dateRange
   * The date range of the appointment
   * @throws InformationalException
   * Generic Exception Signature
   */
  void insert(final ConcernRole concernRole,
    final ScheduledAppointment scheduledAppointment, final DateRange dateRange)
    throws InformationalException;

  /**
   * Modifies the {@link ClientDiary} record for the given {@link ConcernRole},
   * {@link ScheduledAppointment} and date range if one exists.
   *
   * @param concernRole
   * The client the appointment is for
   * @param scheduledAppointment
   * The details of the scheduled appointment
   * @param dateRange
   * The date range of the appointment
   * @throws InformationalException
   * Generic Exception Signature
   */
  void modify(final ConcernRole concernRole,
    final ScheduledAppointment scheduledAppointment, final DateRange dateRange)
    throws InformationalException;

  /**
   * Modifies all {@link ClientDiary} records for the given
   * {@link ScheduledAppointment} and date range.
   *
   * @param scheduledAppointment
   * The details of the scheduled appointment
   * @param dateRange
   * The date range of the appointment
   * @throws InformationalException
   * Generic Exception Signature
   */
  void modify(final ScheduledAppointment scheduledAppointment,
    final DateRange dateRange) throws InformationalException;

  /**
   * Returns a description of the frequency of the scheduled appointment to be
   * converted on the client. E.g. for a calendar activity, this may be the
   * occurrence for a recurring meeting. For an action, this may be the
   * frequency pattern and duration of the activity. If the appointment is not
   * recurring, an empty string should be returned.
   * <p>
   * This is intended for use with the FREQUENCY_DURATION_STRING domain
   * definition, which is converted to a textual description of the frequency of
   * the scheduled appointment on the client. The string is made up of the
   * frequency pattern, plus {@link CuramConst#gkPipeDelimiter}, plus duration
   * as a client formatted LocalisableString. The frequency and duration are
   * optional and an empty string is returned if none are set.<br/>
   * E.g. Input string:
   * '000120100|3::curam.clientdiary.message.ScheduledAppointment:INFO_FREQUENCY_DURATION_STRING:(3|17)'
   * is converted to the output string 'Every 1 day(s) for 3 hours 17 minutes'
   * on the client.
   * </p>
   *
   * @param frequencyPattern
   * The frequency pattern to be converted,
   * {@link FrequencyPattern#kZeroFrequencyPattern} or
   * <code>null</code> should be used if this is not required
   * @param durationInMinutes
   * The duration in minutes to be converted, 0 should be used if this
   * is not required
   * @return A textual description of the frequency of the scheduled appointment
   */
  public String getFrequencyDuration(final FrequencyPattern frequencyPattern,
    final int durationInMinutes);

}
