/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;

import com.google.inject.Singleton;

import curam.caseaudit.entity.impl.AuditPlanTransactionLogAdapter;
import curam.caseaudit.entity.struct.AuditPlanTransactionLogDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Data access Implementation for
 * {@linkplain curam.caseaudit.impl.AuditPlanTransactionLog}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditPlanTransactionLogDAO
 */
@Singleton
// BEGIN, CR00183334, PS
public class AuditPlanTransactionLogDAOImpl extends StandardDAOImpl<AuditPlanTransactionLog, AuditPlanTransactionLogDtls>
  implements AuditPlanTransactionLogDAO {
  // END, CR00183334
  protected static final AuditPlanTransactionLogAdapter adapter = new AuditPlanTransactionLogAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected AuditPlanTransactionLogDAOImpl() {
    // END, CR00183334
    super(adapter, AuditPlanTransactionLog.class);
  }

  // ___________________________________________________________________________
  /**
   * Audit Plan Transaction Log Comparator.
   */
  protected class AuditPlanTransactionLogComparator implements
    Comparator<AuditPlanTransactionLog> {

    public AuditPlanTransactionLogComparator() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sorts audit plan transaction log list based on recorded date then by 
     * sequence number.
     */
    public int compare(final AuditPlanTransactionLog o1,
      final AuditPlanTransactionLog o2) {
      if (o1.getTransactionDateTime().before(o2.getTransactionDateTime())) {
        return 1;
      }

      if (o1.getTransactionDateTime().after(o2.getTransactionDateTime())) {
        return -1;
      }

      if (o1.getSequenceNumber() < o2.getSequenceNumber()) {
        return 1;
      } else if (o1.getSequenceNumber() > o2.getSequenceNumber()) {
        return -1;
      } else {
        return 0;
      }

    }

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public SortedSet<AuditPlanTransactionLog> searchByAuditPlan(
    final AuditPlan auditPlan) {

    SortedSet<AuditPlanTransactionLog> sortedTransactions = new TreeSet<AuditPlanTransactionLog>(
      new AuditPlanTransactionLogComparator());

    sortedTransactions.addAll(
      newList(adapter.searchByAuditPlan(auditPlan.getID())));

    return sortedTransactions;
  }
}
