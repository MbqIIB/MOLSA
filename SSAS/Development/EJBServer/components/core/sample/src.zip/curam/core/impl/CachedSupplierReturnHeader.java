/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.SupplierReturnHeaderDtls;
import curam.core.struct.SupplierReturnHeaderKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * @see curam.core.intf.CachedSupplierReturnHeader
 */
public abstract class CachedSupplierReturnHeader extends curam.core.base.CachedSupplierReturnHeader {

  protected static ThreadLocal cachedSupplierReturnHeaderDtls = new ThreadLocal();

  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;

  // __________________________________________________________________________
  // static to hold the cachingEnabled environment variable
  static {

    cachingEnabled = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);
  }

  // ___________________________________________________________________________
  /**
   * class to hold the cached SupplierReturnHeaderDtls
   */
  protected class SupplierReturnHeaderDtlsCacheRecord {
    int transactionID = 0;
    SupplierReturnHeaderDtls supplierReturnHeaderDtls = new SupplierReturnHeaderDtls();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public SupplierReturnHeaderDtls read(SupplierReturnHeaderKey key)
    throws AppException, InformationalException {

    // supplier return header dtls return variable
    SupplierReturnHeaderDtls supplierReturnHeaderDtlsReturn = new SupplierReturnHeaderDtls();

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    SupplierReturnHeaderDtlsCacheRecord supplierReturnHeaderDtlsCacheRecord = (SupplierReturnHeaderDtlsCacheRecord) cachedSupplierReturnHeaderDtls.get();

    boolean reloadCache = true;

    if (supplierReturnHeaderDtlsCacheRecord != null) {

      // If this is a batch transaction or deferred processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if (((transactionType.equals(TransactionType.kBatch)
        || transactionType.equals(TransactionType.kDeferred))
          && cachingEnabled)
            && (supplierReturnHeaderDtlsCacheRecord.supplierReturnHeaderDtls
              != null
                && supplierReturnHeaderDtlsCacheRecord.supplierReturnHeaderDtls.supplierReturnID
                  == key.supplierReturnID)) {

        // assign to local supplierReturnHeaderDtlsReturn
        supplierReturnHeaderDtlsReturn.assign(
          supplierReturnHeaderDtlsCacheRecord.supplierReturnHeaderDtls);
        reloadCache = false;
      }

      // if this is a deferred transaction, we must also check
      // that the transaction numbers match
      if (!reloadCache && transactionType.equals(TransactionType.kDeferred)
        && TransactionInfo.getIdentifierForThisThread()
        != supplierReturnHeaderDtlsCacheRecord.transactionID) {

        reloadCache = true;
      }
    }

    if (reloadCache) {

      // Otherwise we need to read the supplier return header data
      curam.core.intf.SupplierReturnHeader supplierReturnHeaderObj = curam.core.fact.SupplierReturnHeaderFactory.newInstance();

      // assign to local supplierReturnHeaderDtlsReturn
      supplierReturnHeaderDtlsReturn = supplierReturnHeaderObj.read(key);

      // If this was a cache miss (and caching is enabled), refresh the cache
      if ((transactionType.equals(TransactionType.kBatch)
        || transactionType.equals(TransactionType.kDeferred))
          && cachingEnabled) {

        supplierReturnHeaderDtlsCacheRecord = new SupplierReturnHeaderDtlsCacheRecord();
        // assign to static stSupplierReturnHeaderDtls
        supplierReturnHeaderDtlsCacheRecord.supplierReturnHeaderDtls = supplierReturnHeaderDtlsReturn;
        supplierReturnHeaderDtlsCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();

        cachedSupplierReturnHeaderDtls.set(supplierReturnHeaderDtlsCacheRecord);
      }

    }

    // return local supplierReturnHeaderDtlsReturn
    return supplierReturnHeaderDtlsReturn;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void clearCache() throws AppException, InformationalException {

    cachedSupplierReturnHeaderDtls.set(null);
  }

}
