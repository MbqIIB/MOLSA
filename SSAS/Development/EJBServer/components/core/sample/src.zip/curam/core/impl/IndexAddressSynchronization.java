/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.events.ADDRESS;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressElementDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.AddressKeyStruct;
import curam.core.struct.SynchronizeEventsDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class performs updates to the Search Server staging database when 
 * modifications are made to the Address entity
 */
public abstract class IndexAddressSynchronization extends curam.core.base.IndexAddressSynchronization {
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the address entity insert operation
   *
   * @param dtls alternate name details
   */
  public void insert(final AddressElementDtls dtls) throws AppException, InformationalException {// Insert default insert implementation here.
  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the address entity modify operation
   *
   * @param key address identifier
   */
  public void removeByAddressID(final AddressKeyStruct key) throws AppException, InformationalException {// Insert default removeByAddressID implementation here.
  }

  // BEGIN, CR00091119, DMC
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the address entity insert operation
   *
   * @param dtls address details
   */
  public void insertInternal(final AddressDtls dtls)
    throws AppException, InformationalException {

    final SynchronizeEvents synchronizeEventsObj =
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails =
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass =
      ADDRESS.INSERT_ADDRESS.eventClass;
    synchronizeEventsDetails.eventKey.eventType =
      ADDRESS.INSERT_ADDRESS.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.addressID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);

  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the address entity modify operation
   *
   * @param key address identifier
   * @param dtls address details
   */
  public void modify(final AddressKey key, final AddressDtls dtls)
    throws AppException, InformationalException {

    final SynchronizeEvents synchronizeEventsObj =
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails =
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass =
      ADDRESS.MODIFY_ADDRESS.eventClass;
    synchronizeEventsDetails.eventKey.eventType =
      ADDRESS.MODIFY_ADDRESS.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.addressID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
  }

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the address entity remove operation
   *
   * @param key address identifier
   */
  public void remove(final AddressKey key) throws AppException, InformationalException {

    final SynchronizeEvents synchronizeEventsObj =
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails =
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = 
      ADDRESS.REMOVE_ADDRESS.eventClass;
    synchronizeEventsDetails.eventKey.eventType = 
      ADDRESS.REMOVE_ADDRESS.eventType;
    synchronizeEventsDetails.primaryEventData = key.addressID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
  }
  // END, CR00091119
}
