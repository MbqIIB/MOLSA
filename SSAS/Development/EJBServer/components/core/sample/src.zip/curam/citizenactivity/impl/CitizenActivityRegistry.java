/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.citizenactivity.impl;


import com.google.inject.ImplementedBy;
import curam.citizenactivity.codetable.impl.CITIZENACTIVITYTYPEEntry;
import curam.participant.impl.ConcernRole;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * Contains a map of implementations of the {@link CitizenActivityDAO}
 * interface. Methods on this interface invoke these implementations that return
 * lists of Citizen Activities from various different entities. A customer who
 * wishes to add another source of citizen activities should bind their
 * implementation of {@link CitizenActivityDAO} into the map.
 *
 * @since 6.0
 */
@ImplementedBy(CitizenActivityRegistryImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface CitizenActivityRegistry {

  /**
   * Returns a list of citizen activities for the given {@link ConcernRole}. The
   * records are ordered by calling the bound implementations of the
   * {@link CitizenActivityComparator}.
   *
   * If no implementations have been bound into the map, this method shall return null.
   *
   * @param concernRole
   * the participant in question.
   * @return a list of CitizenActivities for the given {@link ConcernRole}.
   */
  java.util.List<CitizenActivity> searchByConcernRole(ConcernRole concernRole);

  /**
   * Returns an instance of the CitizenActivity interface, based on the ID and
   * type passed in. The type is used to determine which concrete DAO to call to
   * retrieve the record.
   *
   * If no implementations have been bound into the map, this method shall return null.
   *
   * @param id
   * ID of the record to be retrieved.
   * @param type
   * used to determine which concrete DAO to call to retrieve the
   * record, i.e. which entity it lives on.
   * @return an instance of the CitizenActivity interface based on the ID /
   * Type.
   */
  CitizenActivity get(long id, CITIZENACTIVITYTYPEEntry type);
}
