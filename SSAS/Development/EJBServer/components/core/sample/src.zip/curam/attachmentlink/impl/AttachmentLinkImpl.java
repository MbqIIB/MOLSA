/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 * Copyright IBM Corporation 2012,2013. All Rights Reserved.
 *
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attachmentlink.impl;


import java.util.List;

import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.attachment.impl.Attachment;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkDtls;
import curam.attachmentlink.struct.ListAttachmentLinkDetails;
import curam.caseaudit.impl.FocusAreaFinding;
import curam.caseaudit.impl.FocusAreaFindingDAO;
import curam.codetable.ATTACHMENTOBJECTLINKTYPE;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.core.sl.entity.struct.AllegationKey;
import curam.core.sl.fact.AllegationFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.sl.intf.Allegation;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.core.struct.AttachmentNameStruct;
import curam.core.struct.SensitivityCode;
import curam.message.impl.BPOATTACHMENTLINKExceptionCreator;
import curam.message.impl.GENERALExceptionCreator;
import curam.piwrapper.impl.ContactLog;
import curam.piwrapper.impl.ContactLogDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringHelper;


/**
 * AttachmentLink Implementation.
 *
 * For public method JavaDoc
 *
 * @see curam.attachmentlink.impl.AttachmentLink
 */
// BEGIN, CR00183334, PS
public class AttachmentLinkImpl extends SingleTableLogicallyDeleteableEntityImpl<AttachmentLinkDtls> implements
  AttachmentLink {
  // END, CR00183334

  // BEGIN, CR00231006, GD
  @Inject
  protected EventDispatcherFactory<AttachmentLinkEvents> eventDispatcherFactory;

  // BEGIN, CR00141221, PF
  @Inject
  protected EventDispatcherFactory<AttachmentLinkInsertionEvents> attachmentLinkInsertionEventDispatcherFactory;

  @Inject
  protected EventDispatcherFactory<AttachmentLinkCancelationEvents> attachmentLinkCancelationEventDispatcherFactory;

  @Inject
  protected EventDispatcherFactory<AttachmentLinkModificationEvents> attachmentLinkModificationEventDispatcherFactory;
  // END, CR00141221
  // END, CR00231006

  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;

  // BEGIN, CR00146458, VR

  @Inject
  protected Attachment attachment;

  // BEGIN, CR00365030, CD
  @Inject
  protected Provider<CMSMetadataInterface> cmsMetadataProvider;
  // END, CR00365030
    
  @Inject
  protected FocusAreaFindingDAO focusAreaFindingDAO;
  @Inject
  protected ContactLogDAO contactLogDAO;

  // END, CR00146458

  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice.
   */
  protected AttachmentLinkImpl() {// no-arg constructor for use only by Guice
  }

  // END, CR00183334

  // ___________________________________________________________________________
  public void crossEntityValidation() {// not required
  }

  // ___________________________________________________________________________
  public void crossFieldValidation() {// not required
  }

  // ___________________________________________________________________________
  public void mandatoryFieldValidation() {
    if (StringHelper.isEmpty(getDescription())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOATTACHMENTLINKExceptionCreator.ERR_ATTACHMENT_FV_EMPTY_DESCRIPTION(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getRelatedObjectType().equals(
      ATTACHMENTOBJECTLINKTYPEEntry.NOT_SPECIFIED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOATTACHMENTLINKExceptionCreator.ERR_ATTACHMENT_FV_MANDATORY_RELATED_OBJECT_TYPE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getRelatedObjectID() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOATTACHMENTLINKExceptionCreator.ERR_ATTACHMENT_FV_MANDATORY_RELATED_OBJECT_ID(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  @Override
  public void cancel(final int versionNo) throws InformationalException {

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).preCancel(this);
    
    // BEGIN, CR00141221, PF
    attachmentLinkCancelationEventDispatcherFactory.get(AttachmentLinkCancelationEvents.class).preCancel(
      this, versionNo);
    // END, CR00141221
    // END, CR00231006

    AttachmentKey attachmentKey = new AttachmentKey();

    checkSensitivity();
    ValidationHelper.failIfErrorsExist();

    attachmentKey.attachmentID = getAttachmentID();
    attachment.cancel(attachmentKey);
    super.cancel(versionNo);

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).postCancel(this);
    // BEGIN, CR00141221, PF
    attachmentLinkCancelationEventDispatcherFactory.get(AttachmentLinkCancelationEvents.class).postCancel(
      this, versionNo);
    // END, CR00141221
    // END, CR00231006
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public long insert(final AttachmentLinkDetails attachmentLinkDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).preCreate(this);
    
    // BEGIN, CR00141221, PF
    attachmentLinkInsertionEventDispatcherFactory.get(AttachmentLinkInsertionEvents.class).preInsert(
      this, attachmentLinkDetails);
    // END, CR00141221
    // END, CR00231006
    AttachmentDtls attachmentDtls = attachmentLinkDetails.attachmentDtls;

    // inserts attachment record
    attachment.insert(attachmentDtls);

    setAttachmentID(attachmentDtls.attachmentID);
    setRelatedObjectID(attachmentLinkDetails.attachmentLinkDtls.relatedObjectID);
    setRelatedObjectType(
      ATTACHMENTOBJECTLINKTYPEEntry.get(
        attachmentLinkDetails.attachmentLinkDtls.relatedObjectType));
    setDescription(attachmentLinkDetails.attachmentLinkDtls.description);
    setRecordStatus(RECORDSTATUSEntry.NORMAL);
    setParticipantRoleID(
      attachmentLinkDetails.attachmentLinkDtls.participantRoleID);
    setSensitivity(
      SENSITIVITYEntry.get(
        attachmentLinkDetails.attachmentLinkDtls.sensitivityCode));
    setCreator();
    insert();

    checkSensitivity();

    attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID = getID();
    attachmentLinkDetails.attachmentLinkDtls.versionNo = getVersionNo();

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).postCreate(this);
    // BEGIN, CR00141221, PF
    attachmentLinkInsertionEventDispatcherFactory.get(AttachmentLinkInsertionEvents.class).postInsert(
      this, attachmentLinkDetails, getID());
    // END, CR00141221
    // END, CR00231006    

    return getID();
  }

  // ___________________________________________________________________________
  public long getAttachmentID() {
    return getDtls().attachmentID;
  }

  // ___________________________________________________________________________
  public String getDescription() {
    return getDtls().description;
  }

  // ___________________________________________________________________________
  public long getRelatedObjectID() {
    return getDtls().relatedObjectID;
  }

  // ___________________________________________________________________________
  public SENSITIVITYEntry getSensitivityCode() {
    return SENSITIVITYEntry.get(getDtls().sensitivityCode);
  }

  // ___________________________________________________________________________
  public ATTACHMENTOBJECTLINKTYPEEntry getRelatedObjectType() {
    return ATTACHMENTOBJECTLINKTYPEEntry.get(getDtls().relatedObjectType);
  }

  // ___________________________________________________________________________
  public ListAttachmentLinkDetails listAttachmentByRelatedObject(
    final long relatedObjectID,
    final ATTACHMENTOBJECTLINKTYPEEntry attachmentLinkType)
    throws AppException, InformationalException {

    List<AttachmentLink> attachmentLinkList = attachmentLinkDAO.searchByRelatedIDAndType(
      relatedObjectID, attachmentLinkType);

    return assignAttachmentLinkDtls(attachmentLinkList);
  }

  // ___________________________________________________________________________
  /**
   * Populates a ListAttachmentLinkDetails struct with the details from a list
   * of AttachmentLink objects.
   *
   * @param attachmentLinkList
   * A list of AttachmentLink objects
   * @return A struct containing a list of AttachmentLink, and associated
   * attachment, details
   *
   * @throws InformationalException
   * @throws AppException
   */
  protected ListAttachmentLinkDetails assignAttachmentLinkDtls(
    final List<AttachmentLink> attachmentLinkList) throws AppException,
      InformationalException {
    ListAttachmentLinkDetails listAttachmentLinkDetails = new ListAttachmentLinkDetails();

    for (AttachmentLink attachmentLink : attachmentLinkList) {
      AttachmentLinkDetails attachmentLinkDetails = new AttachmentLinkDetails();

      attachmentLinkDetails.attachmentLinkDtls.attachmentID = attachmentLink.getAttachmentID();
      attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID = attachmentLink.getID();
      attachmentLinkDetails.attachmentLinkDtls.description = attachmentLink.getDescription();
      attachmentLinkDetails.attachmentLinkDtls.recordStatus = attachmentLink.getLifecycleState().getCode();
      attachmentLinkDetails.attachmentLinkDtls.relatedObjectID = attachmentLink.getRelatedObjectID();
      attachmentLinkDetails.attachmentLinkDtls.relatedObjectType = attachmentLink.getRelatedObjectType().getCode();
      attachmentLinkDetails.attachmentLinkDtls.versionNo = attachmentLink.getVersionNo();
      attachmentLinkDetails.attachmentLinkDtls.sensitivityCode = attachmentLink.getSensitivityCode().getCode();
      attachmentLinkDetails.attachmentLinkDtls.creatorUserName = attachmentLink.getCreator();
      AttachmentKey attachmentKey = new AttachmentKey();

      attachmentKey.attachmentID = attachmentLink.getAttachmentID();

      attachmentLinkDetails.attachmentDtls = attachment.read(attachmentKey);

      listAttachmentLinkDetails.attachmentLinkDetails.addRef(
        attachmentLinkDetails);

    }

    return listAttachmentLinkDetails;

  }

  // ___________________________________________________________________________
  public ListAttachmentLinkDetails listAttachmentByRelatedObjectAndStatus(
    final long relatedObjectID,
    final ATTACHMENTOBJECTLINKTYPEEntry attachmentLinkType,
    final RECORDSTATUSEntry recordStatus) throws AppException,
      InformationalException {

    List<AttachmentLink> attachmentLinkList = attachmentLinkDAO.searchByRelatedIDTypeAndStatus(
      relatedObjectID, attachmentLinkType, recordStatus);

    return assignAttachmentLinkDtls(attachmentLinkList);
  }

  // ___________________________________________________________________________
  public void checkSensitivity() throws InformationalException {

    boolean result = false;

    /*
     * Do perform sensitivity checking if the transaction is anything other than
     * an online transaction. For example, a batch transaction
     */
    if (!TransactionInfo.getTransactionType().equals(
      TransactionInfo.TransactionType.kOnline)) {
      return;
    }

    // If sensitivity is not set, just return
    if (StringHelper.isEmpty(getDtls().sensitivityCode)) {
      return;
    }

    // If the user is not an internal user
    try {

      // get the users sensitivity
      SensitivityCode userSensitivityCode;

      userSensitivityCode = UserAccessFactory.newInstance().readSensitivityCode();

      // check if concernRole sensitivity is greater than user sensitivity
      int userSensitivity = Integer.parseInt(userSensitivityCode.sensitivity);
      int attachmentSensitivity = Integer.parseInt(getDtls().sensitivityCode);

      if (userSensitivity >= attachmentSensitivity) {
        result = true;
      }
    } catch (NumberFormatException e) {// No action required, an error means it's false
    } catch (AppException e) {// No action required, an error means it's false
    } catch (InformationalException e) {// No action required, an error means it's false
    }

    if (!result) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOATTACHMENTLINKExceptionCreator.ERR_ATTACHMENT_FV_SENSITIVE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    ValidationHelper.failIfErrorsExist();
  }

  // ___________________________________________________________________________
  public void modify(final AttachmentLinkDetails attachmentLinkDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).preModify(this);
    
    // BEGIN, CR00141221, PF
    attachmentLinkModificationEventDispatcherFactory.get(AttachmentLinkModificationEvents.class).preModify(
      this, attachmentLinkDetails);
    // END, CR00141221, PF
    // END, CR00231006

    // BEGIN, CR00150184, MC
    curam.core.intf.MaintainAttachmentAssistant maintainAttachmentAssistantObj = curam.core.fact.MaintainAttachmentAssistantFactory.newInstance();
    AttachmentNameStruct attachmentNameStruct = new AttachmentNameStruct();
    boolean attachmentNameProvided = (attachmentLinkDetails.attachmentDtls.attachmentName.length()
      != 0);

    if (attachmentNameProvided) {
      attachmentNameStruct.attachmentName = attachmentLinkDetails.attachmentDtls.attachmentName;
      // parse attachmentName from path of attachment, leaving just the
      // base name
      maintainAttachmentAssistantObj.parseAttachmentFileName(
        attachmentNameStruct);

      if (attachmentNameStruct.attachmentName.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_FV_NAME_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    attachmentLinkDetails.attachmentDtls.attachmentName = attachmentNameStruct.attachmentName;
    // BEGIN, CR00155031, MC
    AttachmentKey attachmentKey = new AttachmentKey();

    attachmentKey.attachmentID = attachmentLinkDetails.attachmentDtls.attachmentID;
    // END, CR00150184, MC

    if (RECORDSTATUSEntry.get(getLifecycleState().getCode()).equals(
      RECORDSTATUSEntry.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        GENERALExceptionCreator.ERR_GENERAL_FV_NO_MODIFY_RECORD_CANCELLED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }

    checkSensitivity();

    // BEGIN, CR00161481, ZV
    if (attachmentLinkDetails.attachmentDtls.attachmentContents.length() == 0) {

      curam.core.intf.Attachment attachmentObj = curam.core.fact.AttachmentFactory.newInstance();
      AttachmentDtls attachmentDtls = attachmentObj.read(attachmentKey, true);

      attachmentLinkDetails.attachmentDtls.attachmentName = attachmentDtls.attachmentName;
      attachmentLinkDetails.attachmentDtls.attachmentContents = attachmentDtls.attachmentContents;

    }
    // END, CR00161481

    // BEGIN, CR00365030, CD
    populateCMSMetadata(attachmentLinkDetails);
    // END, CR00365030

    // Modifies the attachment details
    attachment.modify(attachmentKey, attachmentLinkDetails.attachmentDtls);

    setDescription(attachmentLinkDetails.attachmentLinkDtls.description);
    setSensitivity(
      SENSITIVITYEntry.get(
        attachmentLinkDetails.attachmentLinkDtls.sensitivityCode));
    setParticipantRoleID(
      attachmentLinkDetails.attachmentLinkDtls.participantRoleID);
    modify();

    // BEGIN, CR00231006, GD
    eventDispatcherFactory.get(AttachmentLinkEvents.class).postModify(this);
    // BEGIN, CR00141221, PF
    attachmentLinkModificationEventDispatcherFactory.get(AttachmentLinkModificationEvents.class).postModify(
      this, attachmentLinkDetails);
    // END, CR00141221, PF
    // END, CR00231006
  }

  /**
   * Populate meta data for the attachment depending on the related object type.
   *
   * @param attachmentLinkDetails The attachment link details.
   * @throws AppException 
   * @throws InformationalException
   */
  private void populateCMSMetadata(
    final AttachmentLinkDetails attachmentLinkDetails) throws AppException,
      InformationalException {
    
    // populate meta data for the attachment
    long caseID = 0;
    String caseReference = null;
    
    if (attachmentLinkDetails.attachmentLinkDtls.relatedObjectType.equals(
      ATTACHMENTOBJECTLINKTYPE.ALLEGATION)) {
    
      Allegation allegationObj = AllegationFactory.newInstance();
      AllegationKey allegationKey = new AllegationKey();  

      allegationKey.allegationID = attachmentLinkDetails.attachmentLinkDtls.relatedObjectID;
      caseID = allegationObj.read(allegationKey).allegationDtls.caseID;
      
    } else if (attachmentLinkDetails.attachmentLinkDtls.relatedObjectType.equals(
      ATTACHMENTOBJECTLINKTYPE.FOCUSAREAFINDING)) {
      
      FocusAreaFinding focusAreaFinding = focusAreaFindingDAO.get(
        attachmentLinkDetails.attachmentLinkDtls.relatedObjectID);      

      caseID = focusAreaFinding.getCaseAudit().getCase().getID();
      
    } else if (attachmentLinkDetails.attachmentLinkDtls.relatedObjectType.equals(
      ATTACHMENTOBJECTLINKTYPE.CONTACTLOG)) {
      // BEGIN, CR00391893, CMC      
      ContactLog contactLog = contactLogDAO.get(
        attachmentLinkDetails.attachmentLinkDtls.relatedObjectID); 
      
      if (null != contactLog.getCase()) {
        caseID = contactLog.getCase().getID();
      }
      // END, CR00391893
    }
    
    if (caseID != 0) {
      CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

      cmsMetadata.add(CMSMetadataConst.kCaseID, Long.toString(caseID));
    } else if (caseReference != null) {
      CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

      cmsMetadata.add(CMSMetadataConst.kCaseReference, caseReference);
    }
  }

  // ___________________________________________________________________________
  public void setAttachmentID(final long value) {
    getDtls().attachmentID = value;

  }

  // ___________________________________________________________________________
  public void setDescription(final String value) {
    getDtls().description = value;

  }

  // ___________________________________________________________________________
  public void setRelatedObjectID(final long value) {
    getDtls().relatedObjectID = value;

  }

  // ___________________________________________________________________________
  public void setRelatedObjectType(final ATTACHMENTOBJECTLINKTYPEEntry value) {
    getDtls().relatedObjectType = value.getCode();

  }

  // ___________________________________________________________________________
  public void setRecordStatus(final RECORDSTATUSEntry value) {
    getDtls().recordStatus = value.getCode();

  }

  // ___________________________________________________________________________
  public long getParticipantRoleID() {
    return getDtls().participantRoleID;
  }

  // ___________________________________________________________________________
  public void setParticipantRoleID(final long value) {
    getDtls().participantRoleID = value;
  }

  // ___________________________________________________________________________
  public void setSensitivity(final SENSITIVITYEntry value) {
    getDtls().sensitivityCode = value.getCode();
  }

  // ___________________________________________________________________________
  public String getCreator() {
    return getDtls().creatorUserName;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00198672, VK
  protected void setCreator() {
    // END, CR00198672
    getDtls().creatorUserName = TransactionInfo.getProgramUser();
  }

}
