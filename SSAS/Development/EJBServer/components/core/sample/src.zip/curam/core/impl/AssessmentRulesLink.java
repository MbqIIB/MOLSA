/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.fact.UniqueIDFactory;
import curam.core.struct.AssessmentRulesLinkDtls;
import curam.core.struct.UniqueIDKeySet;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Functions for manipulating assessment rules link information (insert, modify,
 * etc.)
 *
 */
public abstract class AssessmentRulesLink extends curam.core.base.AssessmentRulesLink {

  /**
   * Generates an unique assessmentRulesLinkID.
   *
   * @param details
   * Assessment rules link details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void preinsert(final AssessmentRulesLinkDtls details)
    throws AppException, InformationalException {

    final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    uniqueIDKeySet.keySetName = KeySets.KEY_SET_ASSMENTBO;
    details.assessmentRulesLinkID = UniqueIDFactory.newInstance().getNextIDFromKeySet(
      uniqueIDKeySet);
  }
}
