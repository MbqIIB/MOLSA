/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.caseaudit.entity.struct.CaseAuditFeedbackCompleteNotificationDetails;
import curam.caseaudit.entity.struct.CaseAuditFeedbackDtls;
import curam.caseaudit.fact.CaseAuditTaskManagementFactory;
import curam.codetable.impl.CASEAUDITTRANSACTIONTYPEEntry;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.UsersKey;
import curam.events.CASEAUDIT;
import curam.message.BPOCASEAUDITTRANSACTIONEVENTS;
import curam.message.ENTCASEAUDITFEEDBACK;
import curam.message.impl.ENTCASEAUDITFEEDBACKExceptionCreator;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringHelper;


/**
 * Implementation for CaseAuditFeedback.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.CaseAuditFeedback
 */
// BEGIN, CR00183334, PS
public class CaseAuditFeedbackImpl extends SingleTableEntityImpl<CaseAuditFeedbackDtls> implements CaseAuditFeedback {
  // END, CR00183334

  @Inject
  protected CaseAuditDAO caseAuditDAO;

  @Inject
  protected CaseAuditTransactionLogDAO caseAuditTransactionLogDAO;

  // ___________________________________________________________________________
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected CaseAuditFeedbackImpl() {
    // no-arg constructor for use only by Guice
    // END, CR00183334
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the focus area finding record.
   *
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
    
    // BEGIN, CR00219064, GD
    // if the feedback is complete raise notification to auditor / audit team 
    // assigned to the case audit 
    if (isFeedbackComplete()) {
      createCaseAuditFeedbackCompleteNotification();
    }
    // END, CR00219064
  }

  // ___________________________________________________________________________
  /**
   * Modifies the CaseAuditFeedback record.
   *
   * @param versionNo
   * The version number of the CaseAuditFeedback record.
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {

    super.modify(versionNo);

    if (getDtls().completeInd) {
      // raise event to dismiss the feedback workflow
      Event feedbackReceivedEvent = new Event();

      feedbackReceivedEvent.eventKey.eventClass = CASEAUDIT.FEEDBACKRECEIVED.eventClass;
      feedbackReceivedEvent.eventKey.eventType = CASEAUDIT.FEEDBACKRECEIVED.eventType;
      feedbackReceivedEvent.primaryEventData = getID();

      try {
        EventService.raiseEvent(feedbackReceivedEvent);
      } catch (AppException ae) {
        ValidationHelper.addValidationError(ae);
      }

      insertFeedbackReceivedTransaction();

      CaseAudit caseAudit = getCaseAudit();

      getCaseAudit().feedbackReceived(caseAudit.getVersionNo());
    }

    // BEGIN, CR00219064, GD
    // if the feedback is complete raise notification to auditor / audit team 
    // assigned to the case audit 
    if (isFeedbackComplete()) {
      createCaseAuditFeedbackCompleteNotification();
    }
    // END, CR00219064

  }

  // ___________________________________________________________________________
  /**
   * Inserts a new case audit transaction log record to record that feedback has
   * been received on the case.
   *
   * @throws AppException
   */
  protected void insertFeedbackReceivedTransaction()
    throws InformationalException {

    UserAccess userAccessObj = UserAccessFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    usersKey.userName = getUsername();

    CaseAuditTransactionLog caseAuditTransactionLog = caseAuditTransactionLogDAO.newInstance();

    caseAuditTransactionLog.setCaseAudit(getCaseAudit());
    caseAuditTransactionLog.setTransactionType(
      CASEAUDITTRANSACTIONTYPEEntry.FEEDBACK_RECEIVED);
    caseAuditTransactionLog.setUserName(TransactionInfo.getProgramUser());
    caseAuditTransactionLog.setRelatedID(getID());

    LocalisableString description;

    try {
      description = new LocalisableString(BPOCASEAUDITTRANSACTIONEVENTS.FEEDBACK_RECEIVED).arg(userAccessObj.getFullName(usersKey).fullname).arg(
        getCaseAudit().getCase().getCaseReference());
    } catch (AppException e) {
      // if the user's full name is not available use the user name field
      // instead
      description = new LocalisableString(BPOCASEAUDITTRANSACTIONEVENTS.FEEDBACK_RECEIVED).arg(getUsername()).arg(
        getCaseAudit().getCase().getCaseReference());
    }

    caseAuditTransactionLog.setDescription(
      description.getMessage(TransactionInfo.getProgramLocale()));
    caseAuditTransactionLog.insert();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link ENTCASEAUDITFEEDBACK#ERR_XFV_MANDATORY_FEEDBACK_COMMENTS_NOT_SPECIFIED} -
   * If mandatory feedback comments are not specified.</li>
   * </ul>
   */
  public void crossFieldValidation() {

    // BEGIN, CR00221556, GD
    if (getDtls().completeInd && StringHelper.isEmpty(getDtls().feedbackText)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITFEEDBACKExceptionCreator.ERR_XFV_MANDATORY_FEEDBACK_COMMENTS_NOT_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00221556
  }

  // ___________________________________________________________________________
  /**
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link ENTCASEAUDITFEEDBACK#ERR_FV_MANDATORY_CASE_AUDIT_NOT_SET} -
   * If mandatory case audit not specified.</li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    if (getDtls().caseAuditID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITFEEDBACKExceptionCreator.ERR_FV_MANDATORY_CASE_AUDIT_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Sets the username field to be the current user. 
   */
  public void setNewInstanceDefaults() {
    getDtls().username = TransactionInfo.getProgramUser();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setCaseAudit(final CaseAudit caseAudit) {
    getDtls().caseAuditID = caseAudit.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setFeedbackText(final String feedbackText) throws AppException,
      InformationalException {
    // BEGIN, CR00230760, GD
    // Only the person that is sent the enter feedback task can enter the 
    // feedback. 
    
    // Get the logged in user
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    String currentUser;

    try {
      currentUser = userAccessObj.getUserDetails().userName;
    } catch (AppException ae) {
      throw new AppRuntimeException(ae);
    } catch (InformationalException ie) {
      throw new AppRuntimeException(ie);
    } 
    // Check the current user was sent the feedback task.
    if (!getDtls().username.equals(currentUser)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITFEEDBACKExceptionCreator.ERR_FV_FEEDBACK_ENTERED_BY_INCORRECT_USER(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00230760    
    getDtls().feedbackText = feedbackText;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseAudit getCaseAudit() {
    return caseAuditDAO.get(getDtls().caseAuditID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getFeedbackText() throws AppException, InformationalException {
    // BEGIN, CR00221556, GD
    return getDtls().feedbackText;
    // END, CR00221556
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setFeedbackComplete(final boolean feedbackComplete) {
    getDtls().completeInd = feedbackComplete; 
  }
  
  // BEGIN, CR00219064, GD
  // ____________________________________________________________________________
  /**
   * Create a notification to inform auditor assigned to the case audit that 
   * feedback has been provided. Where the case audit is assigned to a team, 
   * each team member will receive the notification. 
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void createCaseAuditFeedbackCompleteNotification()
    throws InformationalException {

    CaseAuditFeedbackCompleteNotificationDetails caseAuditFeedbackCompleteNotificationDetails = new CaseAuditFeedbackCompleteNotificationDetails();

    caseAuditFeedbackCompleteNotificationDetails.caseAuditID = getDtls().caseAuditID;
    caseAuditFeedbackCompleteNotificationDetails.caseReference = getCaseAudit().getCase().getCaseReference();
    
    // case audit is assigned to auditor 
    if (getCaseAudit().getAuditor().isUser()) {

      // Send notification to auditor
      caseAuditFeedbackCompleteNotificationDetails.auditor = getCaseAudit().getAuditor().getAuditorName();

      try {
        CaseAuditTaskManagementFactory.newInstance().sendCaseAuditFeedbackCompleteNotification(
          caseAuditFeedbackCompleteNotificationDetails);
      } catch (AppException ae) {
        ValidationHelper.addValidationError(ae);
      }
    } // Case audit is assigned to audit team 
    else if (getCaseAudit().getAuditor().isTeam()) {

      // Send notification to all auditors on the audit team
      List<AuditTeamMember> members = getCaseAudit().getAuditor().getAuditTeam().getMembers();
      
      for (AuditTeamMember member : members) {

        // Send notification to audit team member 
        caseAuditFeedbackCompleteNotificationDetails.auditor = member.getAuditor().getAuditorName();

        try {
          CaseAuditTaskManagementFactory.newInstance().sendCaseAuditFeedbackCompleteNotification(
            caseAuditFeedbackCompleteNotificationDetails);
        } catch (AppException ae) {
          ValidationHelper.addValidationError(ae);
        }
      }
    }
  }

  // END, CR00219064
  
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getUsername() {
    return getDtls().username;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public boolean isFeedbackComplete() {
    return getDtls().completeInd;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setUsername(final String username) {
    getDtls().username = username;
  }
}
