/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.hook.task.impl;


import com.google.inject.ImplementedBy;
import curam.core.sl.struct.ReadMultiOperationDetails;
import curam.core.sl.struct.TaskQueryCriteria;
import curam.core.sl.struct.TaskQueryKey;
import curam.core.sl.struct.TaskQueryResultDetailsList;
import curam.core.struct.AvailableTaskSearchResult;
import curam.core.struct.Count;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Implementable;


/**
 * Contains a number of hooks which allow for custom specific search actions
 * for the task search and available task search functionality.
 */
@Implementable
@ImplementedBy(SearchTaskImpl.class)
public interface SearchTask {

  /**
   * Returns a list of task details using the specified search criteria. This 
   * method can be implemented to limit the number of tasks that are returned 
   * to the client.
   *
   * @param searchTaskKey The search criteria.
   * @param readMultiDetails Specifies the maximum size of the return list.
   *
   * @return A list of tasks satisfying the search criteria.
   */
  public TaskQueryResultDetailsList searchTask(TaskQueryKey searchTaskKey,
    ReadMultiOperationDetails readMultiDetails) throws AppException,
      InformationalException;

  /**
   * This method searches for available tasks for the currently logged in user
   * using the search criteria stored for the user in the database. This method
   * can be implemented to limit the number of tasks that are returned to the 
   * client.
   *
   * @param readMultiDetails Specifies the maximum size of the return list.
   *
   * @return A list of available tasks for the currently logged in user.
   */
  public AvailableTaskSearchResult searchAvailableTasks(
    ReadMultiOperationDetails readMultiDetails) throws AppException,
      InformationalException;

  /**
   * Returns a count of the available tasks for the currently logged in user 
   * using the search criteria stored for the user in the database.
   *
   * @return The number of tasks available to the user.
   */
  public Count countAvailableTasks() throws AppException, 
      InformationalException;

  /**
   * Returns a count of the tasks satisfying the specified search criteria.
   *
   * @param criteria The search criteria.
   *
   * @return The number of tasks satisfying the search criteria.
   */
  public Count countTasks(TaskQueryCriteria criteria) throws AppException,
      InformationalException;

  /**
   * Validates the task search details before performing a search.
   *
   * @param searchTaskKey The task search criteria key.
   */
  public void validateSearchTask(final TaskQueryKey searchTaskKey)
    throws AppException, InformationalException;
}
