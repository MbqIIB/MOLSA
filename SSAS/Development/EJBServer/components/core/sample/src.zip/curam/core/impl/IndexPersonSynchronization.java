/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.events.PERSON;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.struct.PersonDtls;
import curam.core.struct.PersonKey;
import curam.core.struct.SynchronizeEventsDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class performs updates to the Search Server staging database when 
 * modifications are made to the Person entity
 */
public abstract class IndexPersonSynchronization extends curam.core.base.IndexPersonSynchronization {

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the person entity insert operation
   *
   * @param dtls the person details
   */
  public void insert(final PersonDtls dtls) 
    throws AppException, InformationalException {

    // BEGIN, CR00091119, DMC
    final SynchronizeEvents synchronizeEventsObj =
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails =
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass =
      PERSON.INSERT_PERSON.eventClass;
    synchronizeEventsDetails.eventKey.eventType =
      PERSON.INSERT_PERSON.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.concernRoleID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
    // END, CR00091119
  }

  // ___________________________________________________________________________
  /**
   * Raises an event as a result of the person entity modify operation
   *
   * @param key the person key
   * @param dtls the person details
   */
  public void modify(final PersonKey key, final PersonDtls dtls) 
    throws AppException, InformationalException {

    // BEGIN, CR00091119, DMC
    final SynchronizeEvents synchronizeEventsObj =
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails =
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass =
      PERSON.MODIFY_PERSON.eventClass;
    ;
    synchronizeEventsDetails.eventKey.eventType =
      PERSON.MODIFY_PERSON.eventType;
    synchronizeEventsDetails.primaryEventData = key.concernRoleID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
    // END, CR00091119
  }

}
