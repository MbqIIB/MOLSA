/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CachedProductDeliveryPatternInfoFactory;
import curam.core.fact.CaseReassessmentFactory;
import curam.core.fact.DeliveryMethodFactory;
import curam.core.fact.FCGenerationUtilFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.MaintainFinancialComponentFactory;
import curam.core.fact.ProductDeliveryPatternInfoFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.CachedProductDeliveryPatternInfo;
import curam.core.intf.DeliveryMethod;
import curam.core.intf.FCGenerationUtil;
import curam.core.intf.InstructionLineItem;
import curam.core.intf.MaintainFinancialComponent;
import curam.core.intf.ProductDeliveryPatternInfo;
import curam.core.sl.fact.CaseNomineeFactory;
import curam.core.sl.fact.CaseStatusModeFactory;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngineHooks;
import curam.core.sl.intf.CaseNominee;
import curam.core.sl.intf.CaseStatusMode;
import curam.core.sl.struct.CaseStatusModeDetails;
import curam.core.sl.struct.GetNomineeForObjectiveKey;
import curam.core.sl.struct.GetNomineeForObjectiveResult;
import curam.core.sl.struct.GetObjectiveDetails;
import curam.core.struct.CalculateAmountKey;
import curam.core.struct.CaseDecisionObjectiveDtls;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CompleteDecisionCreation;
import curam.core.struct.CompleteDecisionCreationList;
import curam.core.struct.ComponentCaseDecisionLink;
import curam.core.struct.ComponentDetails;
import curam.core.struct.ComponentDetailsList;
import curam.core.struct.DeliveryMethodDtls;
import curam.core.struct.DeliveryMethodKey;
import curam.core.struct.FCCoverDate;
import curam.core.struct.GetLatestCoverPeriodToForCaseAndObjectiveKey;
import curam.core.struct.ILICaseIDNomineeAndObjectiveKey;
import curam.core.struct.ILICoverPeriodTo;
import curam.core.struct.PDPIByProdDelPatIDKey;
import curam.core.struct.PDPIByProdDelPatIDStatusAndDateKey;
import curam.core.struct.ProductDeliveryPatternInfoDtls;
import curam.core.struct.ProductDeliveryPatternInfoDtlsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.type.Date;
import curam.util.type.FrequencyPattern;


/**
 * Code to generate financial components associated with a given case decision.
 */
public abstract class GenerateFinancialComponents extends curam.core.base.GenerateFinancialComponents {

  // BEGIN, CR00211744, VM
  /**
   * Constructor.
   */
  public GenerateFinancialComponents() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected AssessmentEngineHooks assessmentEngineHooks;
  // END, CR00211744

  // BEGIN, CR00239968, VM
  protected final int kFirstElement = 0;
  // END, CR00239968

  // ___________________________________________________________________________
  /**
   * This method will return a list of components by period and nominee
   * assignment.
   *
   * @param completeDecisionCreationList The list of decisions from which the
   * components will be generated.
   *
   * @return The list of components.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ComponentDetailsList createComponentsListfromCaseDecisionSet(
    CompleteDecisionCreationList completeDecisionCreationList)
    throws AppException, InformationalException {

    CompleteDecisionCreation completeDecisionCreation;
    CaseDecisionObjectiveDtls caseDecisionObjectiveDtls;
    ComponentDetailsList componentDetailsList = new ComponentDetailsList();

    MaintainFinancialComponent maintainFinancialComponentObj = MaintainFinancialComponentFactory.newInstance();
    FCCoverDate fcCoverDate;
    GetLatestCoverPeriodToForCaseAndObjectiveKey getLatestCoverPeriodKey = new GetLatestCoverPeriodToForCaseAndObjectiveKey();

    // for each decision
    for (int i = 0; i < completeDecisionCreationList.dtls.size(); i++) {

      completeDecisionCreation = completeDecisionCreationList.dtls.item(i);

      // Get unique identifier for CaseDecisionID, if it's not already specified
      // This can happen when we are generating for the second time....
      if (completeDecisionCreation.details.caseDecisionID == 0L) {
        completeDecisionCreation.details.caseDecisionID = UniqueIDFactory.newInstance().getNextID();
      }

      // for each decision component
      for (int j = 0; j < completeDecisionCreation.dtlsList.size(); j++) {

        caseDecisionObjectiveDtls = completeDecisionCreation.dtlsList.item(j);

        // add a new component
        ComponentDetails newComponentDetails = new ComponentDetails();

        newComponentDetails.caseID = completeDecisionCreation.details.caseID;
        newComponentDetails.concernRoleID = caseDecisionObjectiveDtls.concernRoleID;
        newComponentDetails.objectiveID = caseDecisionObjectiveDtls.objectiveID;
        
        // BEGIN, CR00404532, CW
        newComponentDetails.inRespectOfIDOpt = caseDecisionObjectiveDtls.concernRoleID;
        // END, CR00404532
        
        newComponentDetails.fromDate = completeDecisionCreation.details.decisionFromDate;
        newComponentDetails.toDate = completeDecisionCreation.details.decisionToDate;

        // Get the last paid to date for this component
        getLatestCoverPeriodKey.key.caseID = newComponentDetails.caseID;
        getLatestCoverPeriodKey.key.rulesObjectiveID = newComponentDetails.objectiveID;
        // BEGIN, CR00296014, KH
        getLatestCoverPeriodKey.key.relatedReferenceOpt = caseDecisionObjectiveDtls.relatedReference;

        fcCoverDate = maintainFinancialComponentObj.getLatestCoverPeriodToForCaseAndListObjective(
          getLatestCoverPeriodKey);
        // END, CR00296014

        newComponentDetails.lastPaidToDate = fcCoverDate.coverDate;

        // Add decision details to the list
        ComponentCaseDecisionLink componentCaseDecisionLink = new ComponentCaseDecisionLink();

        componentCaseDecisionLink.caseDecisionID = completeDecisionCreation.details.caseDecisionID;

        // BEGIN, CR00068167, CR00068413, KH
        // BEGIN, CR00074136, CR00074834, CW, VM
        // Generate unique ID for the case decision objective here if it has not
        // already been assigned a value so we can add it to the link struct
        if (caseDecisionObjectiveDtls.caseDecisionObjectiveID == 0L) {
          caseDecisionObjectiveDtls.caseDecisionObjectiveID = UniqueIDFactory.newInstance().getNextID();
        }
        // END, CR00068413

        // BEGIN, CR00175021, KH
        // This will hold the related reference for a list objective
        newComponentDetails.relatedReference = caseDecisionObjectiveDtls.relatedReference;
        // END, CR00175021

        // END, CR00074136, CR00074834
        // Now set the case decision objective ID in the link struct
        componentCaseDecisionLink.caseDecisionObjectiveID = caseDecisionObjectiveDtls.caseDecisionObjectiveID;
        // END, CR00068167

        newComponentDetails.componentCaseDecisionLinkList.dtls.addRef(
          componentCaseDecisionLink);

        componentDetailsList.dtls.addRef(newComponentDetails);
      } // end for j
    } // end for i

    // BEGIN, CR00174460, KH
    // Determine the nominee assignments for the components
    componentDetailsList = getNomineesForComponents(componentDetailsList);

    // Compute the value which should be on the components
    calculateAmount(componentDetailsList);
    // END, CR00174460

    // BEGIN, CR00060400, MC
    // Order component list
    CaseReassessmentFactory.newInstance().orderComponentList(
      componentDetailsList);
    // END, CR00060400

    // BEGIN, CR00211744, VM
    ComponentDetailsList rolledUpComponentList = assessmentEngineHooks.rollUpComponents(
      componentDetailsList);

    // END, CR00211744

    // BEGIN, CR00102570, CW
    // Check if the component list is empty
    if (!rolledUpComponentList.dtls.isEmpty()) {

      // CaseStatusMode manipulation variables
      CaseStatusMode caseStatusModeObj = CaseStatusModeFactory.newInstance();

      // Call operation to retrieve the case status mode
      CaseStatusModeDetails caseStatusModeDetails = caseStatusModeObj.getMode();

      // BEGIN, CR00103556, CW
      // Check to see if the case is being suspended or closed. If it is, we
      // need to re-adjust the components in the componentDetailsList. Also
      // re-adjust components if the case closure date is being updated.
      if (caseStatusModeDetails.caseIsBeingSuspended) {
        componentDetailsList = adjustComponentsForSuspendedCase(
          rolledUpComponentList);
      } else if (caseStatusModeDetails.caseIsBeingClosed) {
        componentDetailsList = adjustComponentsForClosedCase(
          rolledUpComponentList);
      } else if (caseStatusModeDetails.caseClosureDateIsBeingUpdated) {
        componentDetailsList = adjustComponentsForCaseClosureDateUpdate(
          rolledUpComponentList);
      }
      // END, CR00103556
    }
    // END, CR00102570

    return componentDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This method will determine the nominee(s) for each component, adding
   * additional rows as necessary where the component is assigned to more
   * than one nominee for the period
   *
   * @param componentDetailsList The list of components.
   *
   * @return The expanded list of components derived from the nominee component
   * assignments and delivery patterns.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ComponentDetailsList getNomineesForComponents(
    ComponentDetailsList componentDetailsList)
    throws AppException, InformationalException {

    ComponentDetailsList newComponentDetailsList = new ComponentDetailsList();
    ProductDeliveryPatternInfo productDeliveryPatternInfoObj = ProductDeliveryPatternInfoFactory.newInstance();

    CaseNominee caseNomineeObj = CaseNomineeFactory.newInstance();
    GetNomineeForObjectiveKey getNomineeForObjectiveKey = new GetNomineeForObjectiveKey();

    DeliveryMethod deliveryMethodObj = DeliveryMethodFactory.newInstance();
    DeliveryMethodKey deliveryMethodKey = new DeliveryMethodKey();

    Date nextFromDate = new Date();

    // for each component
    for (int i = 0; i < componentDetailsList.dtls.size(); i++) {

      ComponentDetails currentComponentDetails = componentDetailsList.dtls.item(
        i);

      getNomineeForObjectiveKey.caseID = currentComponentDetails.caseID;
      getNomineeForObjectiveKey.rulesObjectiveID = currentComponentDetails.objectiveID;
      getNomineeForObjectiveKey.concernRoleID = currentComponentDetails.concernRoleID;
      getNomineeForObjectiveKey.fromDate = currentComponentDetails.fromDate;
      getNomineeForObjectiveKey.toDate = currentComponentDetails.toDate;

      // Get the Nominee(s) assigned for the period
      GetNomineeForObjectiveResult getNomineeForObjectiveResult = caseNomineeObj.getNomineeForObjective(
        getNomineeForObjectiveKey);

      // For each nominee
      for (int j = 0; j
        < getNomineeForObjectiveResult.getObjectiveDetailsList.size(); j++) {

        GetObjectiveDetails getObjectiveDetails = getNomineeForObjectiveResult.getObjectiveDetailsList.item(
          j);

        // Get the list of delivery patterns that apply
        PDPIByProdDelPatIDKey pDPIByProdDelPatIDKey = new PDPIByProdDelPatIDKey();

        pDPIByProdDelPatIDKey.productDeliveryPatternID = getObjectiveDetails.productDeliveryPatternID;

        ProductDeliveryPatternInfoDtlsList productDeliveryPatternInfoDtlsList = productDeliveryPatternInfoObj.searchByProdDelPatID(
          pDPIByProdDelPatIDKey);

        for (int k = 0; k < productDeliveryPatternInfoDtlsList.dtls.size(); k++) {

          ProductDeliveryPatternInfoDtls currentProductDeliveryPatternInfoDtls = productDeliveryPatternInfoDtlsList.dtls.item(
            k);

          nextFromDate = Date.kZeroDate;

          // BEGIN, CR00209826, CW
          if (currentProductDeliveryPatternInfoDtls.recordStatus.equals(
            RECORDSTATUS.NORMAL)
              && (!currentProductDeliveryPatternInfoDtls.fromDate.after(
                getObjectiveDetails.toDate)
                  || (getObjectiveDetails.toDate.isZero()))) {
            // END, CR00209826

            // Work out the fromDate of the next delivery pattern
            for (int l = 0; l < productDeliveryPatternInfoDtlsList.dtls.size(); l++) {

              if (productDeliveryPatternInfoDtlsList.dtls.item(l).recordStatus.equals(
                RECORDSTATUS.NORMAL)
                  && productDeliveryPatternInfoDtlsList.dtls.item(l).fromDate.after(
                    currentProductDeliveryPatternInfoDtls.fromDate)
                    && (productDeliveryPatternInfoDtlsList.dtls.item(l).fromDate.before(
                      nextFromDate)
                        || nextFromDate.isZero())) {

                nextFromDate = productDeliveryPatternInfoDtlsList.dtls.item(l).fromDate;
              }
            } // end for l

            // If the fromDate of the next delivery pattern is prior to the
            // fromDate of the objective, we can skip this pattern
            if (!nextFromDate.before(getObjectiveDetails.fromDate)
              || nextFromDate.isZero()) {

              ComponentDetails newComponentDetails = new ComponentDetails();

              // Create a new Component details record
              newComponentDetails.caseID = currentComponentDetails.caseID;
              newComponentDetails.lastPaidToDate = currentComponentDetails.lastPaidToDate;
              newComponentDetails.caseNomineeID = getObjectiveDetails.caseNomineeID;

              // Set the fromDate to be either the fromDate of the Objective or
              // the fromDate of the delivery pattern if it's later
              if (currentProductDeliveryPatternInfoDtls.fromDate.after(
                getObjectiveDetails.fromDate)) {

                newComponentDetails.fromDate = currentProductDeliveryPatternInfoDtls.fromDate;

              } else {

                if (getObjectiveDetails.fromDate.before(
                  currentComponentDetails.fromDate)) {

                  getObjectiveDetails.fromDate = currentComponentDetails.fromDate;
                }
                newComponentDetails.fromDate = getObjectiveDetails.fromDate;
              }

              // Adding CaseDecision FinancialComponent relations.
              newComponentDetails.componentCaseDecisionLinkList.assign(
                currentComponentDetails.componentCaseDecisionLinkList);

              // Set the toDate to be either the toDate of the Objective or the
              // earliest fromDate after the fromDate of the current record
              // (if there is one)
              if (!nextFromDate.isZero()) {
                if (nextFromDate.before(getObjectiveDetails.toDate)
                  || (getObjectiveDetails.toDate.isZero())) {

                  newComponentDetails.toDate = nextFromDate;
                }
              } else {
                newComponentDetails.toDate = getObjectiveDetails.toDate;
              }

              // Subtract one from the toDate
              if (!newComponentDetails.toDate.isZero()) {
                newComponentDetails.toDate = newComponentDetails.toDate.addDays(
                  -1);
              }

              newComponentDetails.assignedToPrimary = getObjectiveDetails.assignedToDefault;
              newComponentDetails.nomineeName = getObjectiveDetails.nomineeName;
              newComponentDetails.concernRoleID = getObjectiveDetails.concernRoleID;
              newComponentDetails.objectiveID = getObjectiveDetails.rulesObjectiveID;
              newComponentDetails.currencyTypeCode = getObjectiveDetails.currencyTypeCode;
              newComponentDetails.rulesComponentTarget = getObjectiveDetails.rulesComponentTarget;
              newComponentDetails.productDeliveryPatternID = getObjectiveDetails.productDeliveryPatternID;
              // BEGIN, CR00209826, CW
              newComponentDetails.productDeliveryPatternInfoID = currentProductDeliveryPatternInfoDtls.productDeliveryPatternInfoID;
              // END, CR00209826
              newComponentDetails.value = currentComponentDetails.value;

              // BEGIN, CR00175021, KH
              // This will hold the related reference for a list objective
              newComponentDetails.relatedReference = currentComponentDetails.relatedReference;
              // END, CR00175021

              // BEGIN, CR00404532, CW
              newComponentDetails.inRespectOfIDOpt = currentComponentDetails.inRespectOfIDOpt;
              // END, CR00404532

              // Get the Delivery Method details
              deliveryMethodKey.deliveryMethodID = currentProductDeliveryPatternInfoDtls.deliveryMethodID;

              DeliveryMethodDtls deliveryMethodDtls = deliveryMethodObj.read(
                deliveryMethodKey);

              newComponentDetails.deliveryMethodType = deliveryMethodDtls.name;

              // Add the new record to the new list
              newComponentDetailsList.dtls.addRef(newComponentDetails);
            }
          }
        } // end for k

        // Need to re-adjust the last record's toDate as we have subtracted
        // 1 day from each above
        if (!newComponentDetailsList.dtls.isEmpty()) {

          int lastRecord = newComponentDetailsList.dtls.size() - 1;

          if (!newComponentDetailsList.dtls.item(lastRecord).toDate.isZero()) {
            newComponentDetailsList.dtls.item(lastRecord).toDate = newComponentDetailsList.dtls.item(lastRecord).toDate.addDays(
              1);
          }
        }
      } // end for j
    } // end for i

    // InstructionLineItem manipulation variables
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
    ILICaseIDNomineeAndObjectiveKey iliCaseIDNomineeAndObjectiveKey = new ILICaseIDNomineeAndObjectiveKey();
    ILICoverPeriodTo iliCoverPeriodTo;

    for (int k = 0; k < newComponentDetailsList.dtls.size(); k++) {

      iliCaseIDNomineeAndObjectiveKey.caseID = newComponentDetailsList.dtls.item(k).caseID;
      iliCaseIDNomineeAndObjectiveKey.rulesObjectiveID = newComponentDetailsList.dtls.item(k).objectiveID;
      iliCaseIDNomineeAndObjectiveKey.caseNomineeID = newComponentDetailsList.dtls.item(k).caseNomineeID;
      // BEGIN, CR00296014, KH
      iliCaseIDNomineeAndObjectiveKey.relatedReferenceOpt = newComponentDetailsList.dtls.item(k).relatedReference;
      
      // We use a different read for a list objective
      if (iliCaseIDNomineeAndObjectiveKey.relatedReferenceOpt.isEmpty()) {
        iliCoverPeriodTo = instructionLineItemObj.readLatestCoverPeriodToForCaseNomineeAndObjective(
          iliCaseIDNomineeAndObjectiveKey);
      } else {
        iliCoverPeriodTo = instructionLineItemObj.readLatestCoverPeriodToForCaseNomineeAndListObjective(
          iliCaseIDNomineeAndObjectiveKey);
      }
      // END, CR00296014

      // Overwrite the lastPaidToDate with the one retrieved for that nominee
      newComponentDetailsList.dtls.item(k).lastPaidToDate = iliCoverPeriodTo.coverPeriodTo;
    }

    return newComponentDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This function re-adjusts the components generated in
   * createComponentsListfromCaseDecisionSet and getNomineesForComponent if
   * the case has been suspended.
   *
   * @param componentDetailsList the list of components.
   *
   * @return The re-adjusted list of components.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ComponentDetailsList adjustComponentsForSuspendedCase(
    ComponentDetailsList componentDetailsList)
    throws AppException, InformationalException {

    // MaintainFinancialComponent manipulation variables
    MaintainFinancialComponent maintainFinancialComponentObj = MaintainFinancialComponentFactory.newInstance();
    GetLatestCoverPeriodToForCaseAndObjectiveKey getLatestCoverPeriodKey = new GetLatestCoverPeriodToForCaseAndObjectiveKey();

    // Date of suspension is always the current date
    Date dateOfSuspension = Date.getCurrentDate();

    for (int i = 0; i < componentDetailsList.dtls.size(); i++) {

      // BEBIN, CR00218619, VM
      int kFirstElement = 0;
      int kLastElement = (componentDetailsList.dtls.size() - 1);

      // END, CR00218619

      // Set key to read latest paid to date for component
      getLatestCoverPeriodKey.key.caseID = componentDetailsList.dtls.item(i).caseID;
      getLatestCoverPeriodKey.key.rulesObjectiveID = componentDetailsList.dtls.item(i).objectiveID;
      // BEGIN, CR00296014, KH
      getLatestCoverPeriodKey.key.relatedReferenceOpt = componentDetailsList.dtls.item(i).relatedReference;

      FCCoverDate fcCoverDate = maintainFinancialComponentObj.getLatestCoverPeriodToForCaseAndListObjective(
        getLatestCoverPeriodKey);
      // END, CR00296014

      // Check the environment variable setting to see if payments up to the
      // date of suspension are to be included
      // BEGIN, CR00102570, CR00241558, CW, VM
      Boolean issuePaymentToSuspendDate = Configuration.getBooleanProperty(
        EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE,
        Configuration.getBooleanProperty(
          EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE_DEFAULT));

      // The components only need to be re-adjusted in the scenario where
      // the component to date is after the fcCoverDate.coverDate
      if (componentDetailsList.dtls.item(i).toDate.after(fcCoverDate.coverDate)
        || (componentDetailsList.dtls.item(i).toDate.isZero())) {

        if (issuePaymentToSuspendDate) {
          // END, CR00102570, CR00241558

          // BEBIN, CR00218619, VM
          if (dateOfSuspension.before(
            componentDetailsList.dtls.item(kFirstElement).fromDate)) {
            componentDetailsList.dtls.clear();
          } else if (dateOfSuspension.after(
            componentDetailsList.dtls.item(kLastElement).toDate)
              && !componentDetailsList.dtls.item(kLastElement).toDate.isZero()
              && fcCoverDate.coverDate.isZero()) {
            componentDetailsList.dtls.clear();
          } else {
            // Set the end date of the component to be date of suspension
            if (!componentDetailsList.dtls.item(i).fromDate.after(
              dateOfSuspension)) {
              if (dateOfSuspension.after(fcCoverDate.coverDate)) {
                if (!componentDetailsList.dtls.item(i).toDate.before(
                  dateOfSuspension)
                    || componentDetailsList.dtls.item(i).toDate.isZero()) {
                  componentDetailsList.dtls.item(i).toDate = dateOfSuspension;
                }
              } else {
                componentDetailsList.dtls.item(i).toDate = fcCoverDate.coverDate;
              }
            } else {
              // BEGIN, CR00283675, KH
              /*
               * If the component starts before the last date paid we don't
               * want to remove it, just shorten it.
               */
              if (componentDetailsList.dtls.item(i).fromDate.before(
                fcCoverDate.coverDate)) {
                componentDetailsList.dtls.item(i).toDate = fcCoverDate.coverDate;
              } else {
                componentDetailsList.dtls.remove(i);
                i--;
              }
              // END, CR00283675
            }
          }
          // END, CR00218619

        } else {

          if (dateOfSuspension.before(
            componentDetailsList.dtls.item(kFirstElement).fromDate)) {
            componentDetailsList.dtls.clear();
          } else if (dateOfSuspension.after(
            componentDetailsList.dtls.item(kLastElement).toDate)
              && !componentDetailsList.dtls.item(kLastElement).toDate.isZero()
              && fcCoverDate.coverDate.isZero()) {
            componentDetailsList.dtls.clear();
          } else {
            // Set the end date of the component to be the latest paid to date
            if (!componentDetailsList.dtls.item(i).fromDate.after(
              dateOfSuspension)) {
              if (!fcCoverDate.coverDate.isZero()) {
                componentDetailsList.dtls.item(i).toDate = fcCoverDate.coverDate;
              } else {
                componentDetailsList.dtls.remove(i);
                i--;
              }
            } else {
              // BEGIN, CR00283675, KH
              /*
               * If the component starts before the last date paid we don't
               * want to remove it, just shorten it.
               */
              if (componentDetailsList.dtls.item(i).fromDate.before(
                fcCoverDate.coverDate)) {
                componentDetailsList.dtls.item(i).toDate = fcCoverDate.coverDate;
              } else {
                componentDetailsList.dtls.remove(i);
                i--;
              }
              // END, CR00283675
            }
          }
        }
      }
    } // end for i

    return componentDetailsList;
  }

  // BEGIN, CR00102570, CW
  // ___________________________________________________________________________
  /**
   * This function re-adjusts the components generated in
   * createComponentsListfromCaseDecisionSet and getNomineesForComponent if
   * the case has been closed.
   *
   * @param componentDetailsList the list of components. Calls to this method
   * should ensure this list is not empty.
   *
   * @return The re-adjusted list of components.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ComponentDetailsList adjustComponentsForClosedCase(
    ComponentDetailsList componentDetailsList)
    throws AppException, InformationalException {

    // MaintainFinancialComponent manipulation variables
    MaintainFinancialComponent maintainFinancialComponentObj = MaintainFinancialComponentFactory.newInstance();
    GetLatestCoverPeriodToForCaseAndObjectiveKey getLatestCoverPeriodKey = new GetLatestCoverPeriodToForCaseAndObjectiveKey();

    // BEGIN, CR00103556, CW
    // Obtain case closure date
    Date dateOfClosure = getCaseClosureDate(
      componentDetailsList.dtls.item(0).caseID);

    // END, CR00103556

    for (int i = 0; i < componentDetailsList.dtls.size(); i++) {

      int kLastElement = (componentDetailsList.dtls.size() - 1);

      // Set key to read latest paid to date for component
      getLatestCoverPeriodKey.key.caseID = componentDetailsList.dtls.item(i).caseID;
      getLatestCoverPeriodKey.key.rulesObjectiveID = componentDetailsList.dtls.item(i).objectiveID;
      // BEGIN, CR00296014, KH
      getLatestCoverPeriodKey.key.relatedReferenceOpt = componentDetailsList.dtls.item(i).relatedReference;

      FCCoverDate fcCoverDate = maintainFinancialComponentObj.getLatestCoverPeriodToForCaseAndListObjective(
        getLatestCoverPeriodKey);
      // END, CR00296014

      // Check the environment variable setting to see if payments up to the
      // date of closure are to be included
      Boolean issuePaymentToClosedDate = Configuration.getBooleanProperty(
        EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE,
        Configuration.getBooleanProperty(
          EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE_DEFAULT));

      // The components only need to be re-adjusted in the scenario where
      // the component to date is after the fcCoverDate.coverDate

      // BEGIN, CR00239968, VM
      if (componentDetailsList.dtls.item(i).toDate.after(fcCoverDate.coverDate)) {

        if (issuePaymentToClosedDate) {

          if (dateOfClosure.before(
            componentDetailsList.dtls.item(kFirstElement).fromDate)) {
            componentDetailsList.dtls.clear();
          } else if (dateOfClosure.after(
            componentDetailsList.dtls.item(kLastElement).toDate)
              && !componentDetailsList.dtls.item(kLastElement).toDate.isZero()
              && fcCoverDate.coverDate.isZero()) {
            componentDetailsList.dtls.clear();
          } else {
            if (!componentDetailsList.dtls.item(i).fromDate.after(dateOfClosure)) {
              if (dateOfClosure.after(fcCoverDate.coverDate)) {
                if (!componentDetailsList.dtls.item(i).toDate.before(
                  dateOfClosure)) {
                  componentDetailsList.dtls.item(i).toDate = dateOfClosure;
                } else {
                  componentDetailsList.dtls.item(i).toDate = componentDetailsList.dtls.item(i).toDate;
                }
              } else {
                componentDetailsList.dtls.item(i).toDate = fcCoverDate.coverDate;
              }
            } else {
              // BEGIN, CR00283917, KH
              /*
               * If the component starts before the last date paid we don't
               * want to remove it, just shorten it.
               */
              if (componentDetailsList.dtls.item(i).fromDate.before(
                fcCoverDate.coverDate)) {
                componentDetailsList.dtls.item(i).toDate = fcCoverDate.coverDate;
              } else {
                componentDetailsList.dtls.remove(i);
                i--;
              }
              // END, CR00283917
            }

          }

        } else {

          if (dateOfClosure.before(
            componentDetailsList.dtls.item(kFirstElement).fromDate)) {
            componentDetailsList.dtls.clear();
          } else if (dateOfClosure.after(
            componentDetailsList.dtls.item(kLastElement).toDate)
              && !componentDetailsList.dtls.item(kLastElement).toDate.isZero()
              && fcCoverDate.coverDate.isZero()) {
            componentDetailsList.dtls.clear();
          } else {
            // Set the end date of the component to be the latest paid to date
            if (!componentDetailsList.dtls.item(i).fromDate.after(dateOfClosure)) {
              if (!fcCoverDate.coverDate.isZero()) {
                componentDetailsList.dtls.item(i).toDate = fcCoverDate.coverDate;
              } else {
                componentDetailsList.dtls.remove(i);
                i--;
              }
            } else {
              // BEGIN, CR00283917, KH
              /*
               * If the component starts before the last date paid we don't
               * want to remove it, just shorten it.
               */
              if (componentDetailsList.dtls.item(i).fromDate.before(
                fcCoverDate.coverDate)) {
                componentDetailsList.dtls.item(i).toDate = fcCoverDate.coverDate;
              } else {
                componentDetailsList.dtls.remove(i);
                i--;
              }
              // END, CR00283917
            }

          }

        }

      }
      // END, CR00239968
    } // end for i

    return componentDetailsList;
  }

  // END, CR00102570

  // BEGIN, CR00103556, CW
  // ___________________________________________________________________________
  /**
   * This function re-adjusts the components generated in
   * createComponentsListfromCaseDecisionSet and getNomineesForComponent to the
   * updated case closure date.
   * This method is called where the case closure date is being updated.
   *
   * @param componentDetailsList the list of components. Calls to this method
   * should ensure this list is not empty.
   *
   * @return The re-adjusted list of components.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ComponentDetailsList adjustComponentsForCaseClosureDateUpdate(
    final ComponentDetailsList componentDetailsList)
    throws AppException, InformationalException {

    // BEGIN, CR00307322, KH
    /*
     * We have the same considerations for modification of case closure date as
     * we have for case closure itself. So delegate to that method.
     */
    return adjustComponentsForClosedCase(componentDetailsList);
    // END, CR00307322
  }

  // END, CR00103556

  // BEGIN, CR00103556, CW
  // ___________________________________________________________________________
  /**
   * Read the case closure date for a given case id. This will return an empty
   * date where there is no end date on the case header.
   *
   * @param caseID The case id.
   *
   * @return The case closure date.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected Date getCaseClosureDate(long caseID)
    throws AppException, InformationalException {

    // Read case header
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseID;
    CaseHeaderDtls caseHeaderDtls = CachedCaseHeaderFactory.newInstance().read(
      caseHeaderKey);

    // Get the closure date
    Date dateOfClosure = caseHeaderDtls.endDate;

    return dateOfClosure;
  }

  // END, CR00103556

  // BEGIN, CR00174460, KH
  // ___________________________________________________________________________
  /**
   * Sets the value on each component. This value is the amount that will be
   * used on any recurring financial components.
   *
   * @param componentDetailsList The list of components.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected void calculateAmount(ComponentDetailsList componentDetailsList)
    throws AppException, InformationalException {

    FCGenerationUtil fcGenerationUtilObj = FCGenerationUtilFactory.newInstance();

    CachedProductDeliveryPatternInfo cachedProductDeliveryPatternInfoObj = CachedProductDeliveryPatternInfoFactory.newInstance();

    for (int i = 0; i < componentDetailsList.dtls.size(); i++) {

      PDPIByProdDelPatIDStatusAndDateKey pdpKey = new PDPIByProdDelPatIDStatusAndDateKey();

      pdpKey.effectiveDate = componentDetailsList.dtls.item(i).fromDate;
      pdpKey.productDeliveryPatternID = componentDetailsList.dtls.item(i).productDeliveryPatternID;
      pdpKey.recordStatus = RECORDSTATUS.NORMAL;
      ProductDeliveryPatternInfoDtls pdpDtls = cachedProductDeliveryPatternInfoObj.readNearestProdDelPatInfo(
        pdpKey);

      // Local variable to hold delivery frequency
      FrequencyPattern deliveryFrequency = new FrequencyPattern(
        pdpDtls.deliveryFrequency);

      // Convert delivery frequency into a date range
      final Date delFromDate;
      final Date delToDate;

      final Date prevDate = deliveryFrequency.getPrevOccurrence(
        componentDetailsList.dtls.item(i).fromDate);
      final Date nextDate = deliveryFrequency.getNextOccurrence(prevDate);

      if (componentDetailsList.dtls.item(i).fromDate.equals(nextDate)) {
        delFromDate = componentDetailsList.dtls.item(i).fromDate;
        delToDate = deliveryFrequency.getNextOccurrence(
          componentDetailsList.dtls.item(i).fromDate);
      } else {
        delFromDate = prevDate;
        delToDate = nextDate;
      }

      // Set key to calculate recurring amount for the component
      CalculateAmountKey calculateAmountKey = new CalculateAmountKey();

      calculateAmountKey.caseID = componentDetailsList.dtls.item(i).caseID;
      calculateAmountKey.rulesObjectiveID = componentDetailsList.dtls.item(i).objectiveID;
      calculateAmountKey.fromDate = delFromDate;
      calculateAmountKey.toDate = delToDate.addDays(-1);
      calculateAmountKey.deliveryFrequency = deliveryFrequency.toString();

      componentDetailsList.dtls.item(i).value = fcGenerationUtilObj.calculateAmount(calculateAmountKey, componentDetailsList.dtls.item(i).componentCaseDecisionLinkList).amount.toString();
    } // end for i
  }
  // END, CR00174460

}
