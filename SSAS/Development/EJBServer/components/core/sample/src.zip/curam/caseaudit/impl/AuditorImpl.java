/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2009, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.caseaudit.entity.struct.AuditorDtls;
import curam.caseaudit.fact.CaseAuditSecurityManagementFactory;
import curam.caseaudit.intf.CaseAuditSecurityManagement;
import curam.caseaudit.struct.CaseAuditSecurityKey;
import curam.codetable.AUDITORTYPE;
import curam.codetable.impl.AUDITORTYPEEntry;
import curam.codetable.impl.AUDITPLANTRANSACTIONTYPEEntry;
import curam.core.impl.EnvVars;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.UsersKey;
import curam.message.BPOAUDITPLANTRANSACTIONEVENTS;
import curam.message.ENTAUDITOR;
import curam.message.impl.ENTAUDITORExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.StringHelper;


/**
 * Implementation for Auditor.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.Auditor
 */
// BEGIN, CR00183334, PS
public class AuditorImpl extends SingleTableEntityImpl<AuditorDtls> 
  implements Auditor {
  // END, CR00183334

  @Inject
  protected AuditorDAO auditorDAO;

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected AuditTeamDAO auditTeamDAO;

  // BEGIN, CR00183007, GD
  @Inject
  protected AuditPlanTransactionLogDAO auditPlanTransactionLogDAO;

  // END, CR00183007

  // ___________________________________________________________________________
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected AuditorImpl() {
    // no-arg constructor for use only by Guice
    // END, CR00183334
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the auditor record.
   *
   */
  @Override
  public void insert() throws InformationalException {

    // set the dateAdded
    getDtls().dateAdded = Date.getCurrentDate();

    // set the auditor type
    setAuditorType();

    super.insert();

    // BEGIN, CR00210526, GD
    // validate auditor has access to this case audit type
    validateAuditorAccess();
    // END, CR00210526
    
    // BEGIN, CR00183007, GD
    if (getDtls().auditorType.equals(AUDITORTYPE.AUDITUSER)) {
      // Create the audit plan transaction log record for new auditor
      insertAuditorAddedTransaction();
    } else {
      // Create the audit plan transaction log record for new audit team
      insertAuditTeamAddedTransaction();
    }
    // END, CR00183007
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new audit plan transaction log record to record that a new
   * auditor has been added to the audit plan.
   */
  protected void insertAuditorAddedTransaction() throws InformationalException {

    LocalisableString description;

    try {
      description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.AUDITOR_ADDED).arg(getName()).arg(
        getAuditPlan().getAuditPlanReference());
    } catch (AppException e) {
      // if the auditor full name is not available use the user name field
      // instead
      description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.AUDITOR_ADDED).arg(getAuditorName()).arg(
        getAuditPlan().getAuditPlanReference());
    }

    createAuditPlanTransactionLog(AUDITPLANTRANSACTIONTYPEEntry.AUDITOR_ADDED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new audit plan transaction log record to record that a new
   * auditor has been added to the audit plan.
   *
   * @throws AppException
   */
  protected void insertAuditTeamAddedTransaction() 
    throws InformationalException {

    LocalisableString description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.AUDIT_TEAM_ADDED).arg(getAuditTeam().getName()).arg(
      getAuditPlan().getAuditPlanReference());

    createAuditPlanTransactionLog(
      AUDITPLANTRANSACTIONTYPEEntry.AUDIT_TEAM_ADDED,
      description.getMessage(TransactionInfo.getProgramLocale()), 
      getAuditTeam().getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new audit plan transaction log record to record that an auditor
   * has been removed from the audit plan.
   */
  protected void insertAuditorRemovedTransaction() 
    throws InformationalException {

    LocalisableString description;

    try {
      description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.AUDITOR_REMOVED).arg(getName()).arg(
        getAuditPlan().getAuditPlanReference());
    } catch (AppException e) {
      // if the auditor full name is not available use the user name field
      // instead
      description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.AUDITOR_REMOVED).arg(getAuditorName()).arg(
        getAuditPlan().getAuditPlanReference());
    }

    createAuditPlanTransactionLog(AUDITPLANTRANSACTIONTYPEEntry.AUDITOR_REMOVED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a audit plan transaction log record.
   *
   * @param transactionType
   * The value of the schedule start date
   * @param description
   * Transaction log description text
   * @param relatedID
   * Optional value for the id of the related object
   *
   * @throws InformationalException
   */
  protected void createAuditPlanTransactionLog(
    final AUDITPLANTRANSACTIONTYPEEntry transactionType, 
    final String description, final long relatedID) 
    throws InformationalException {
    
    AuditPlanTransactionLog auditPlanTransactionLog = auditPlanTransactionLogDAO.newInstance();

    auditPlanTransactionLog.setAuditPlan(getAuditPlan());
    auditPlanTransactionLog.setTransactionType(transactionType);
    auditPlanTransactionLog.setUserName(TransactionInfo.getProgramUser());
    auditPlanTransactionLog.setRelatedID(relatedID);
    auditPlanTransactionLog.setDescription(description);
    auditPlanTransactionLog.insert();
  }

  // ___________________________________________________________________________
  /**
   * Removes the auditor record.
   *
   * @param versionNo
   * The version number of the auditor record.
   */
  public void remove(final Integer versionNo) throws InformationalException {

    // BEGIN, CR00183007, GD
    if (getDtls().auditorType.equals(AUDITORTYPE.AUDITUSER)) {
      // Create the audit plan transaction log record for new auditor
      insertAuditorRemovedTransaction();
    } else {// no need to insert audit team removed transaction because this is
      // handled in the AuditTeam remove method
    }
    // END, CR00183007

    super.remove(versionNo);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setAuditPlan(final AuditPlan auditPlan) {
    getDtls().auditPlanID = auditPlan.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void setAuditorName(final String auditor) throws AppException,
      InformationalException {

    getDtls().userName = auditor;

    // BEGIN, CR00385977, KRK
    // Check the security roles are restricted for assignments.
    final boolean isUserRoleRestricted = Configuration.getBooleanProperty(
      EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES_DEFAULT));    

    if (isUserRoleRestricted) {
      // Validate the role name against current user.
      final UsersKey usersKey = new UsersKey();     

      usersKey.userName = auditor;
      
      final String roleName = UserAccessFactory.newInstance().getUserDetails(usersKey).roleName;

      if (!CaseAuditConst.kAuditorUserRoleName.equals(roleName)
        && !CaseAuditConst.kCoordinatorUserRoleName.equals(roleName)) {

        ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTAUDITORExceptionCreator.ERR_FV_AUDITOR_BADUSER(
            CaseAuditConst.kAuditorUserRoleName,
            CaseAuditConst.kCoordinatorUserRoleName),
            ValidationManagerConst.kSetOne,
            0);
      }
    }
    // END, CR00385977
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setAuditTeam(final AuditTeam auditTeam) {
    getDtls().auditTeamID = auditTeam.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setAuditorType(final AUDITORTYPEEntry auditorType) {
    getDtls().auditorType = auditorType.getCode();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getAuditorName() {
    return getDtls().userName;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @throws InformationalException
   * @throws AppException
   */
  public String getName() throws AppException, InformationalException {

    if (isTeam()) {

      AuditTeam auditTeamObj = auditTeamDAO.get(this.getAuditTeam().getID());

      return auditTeamObj.getName();

    }

    UserAccess userAccessObj = UserAccessFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    usersKey.userName = getAuditorName();
    return userAccessObj.getFullName(usersKey).fullname;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AUDITORTYPEEntry getAuditorType() {
    return AUDITORTYPEEntry.get(getDtls().auditorType);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Date getDateAdded() {
    return getDtls().dateAdded;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public boolean isUser() {
    return getAuditorType().equals(AUDITORTYPEEntry.AUDITUSER);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public boolean isTeam() {
    return getAuditorType().equals(AUDITORTYPEEntry.AUDITTEAM);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AuditPlan getAuditPlan() {
    return auditPlanDAO.get(getDtls().auditPlanID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AuditTeam getAuditTeam() {
    return auditTeamDAO.get(getDtls().auditTeamID);
  }

  // ___________________________________________________________________________
  /**
   * Validates that all the field values held are valid with respect to each
   * other.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link AUDITOR#ERR_XRV_DUPLICATE_USER_EXISTS} - If an attempt is made
   * to add a user that is already a member of the audit plan.</li>
   * </ul>
   */
  public void crossEntityValidation() {
    validateDuplicates();
  }

  // ___________________________________________________________________________
  /**
   * Validates that all the field values held are valid with respect to each
   * other.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link ENTAUDITOR#ERR_XFV_AUDITOR_AND_AUDIT_TEAM_SPECIFIED} - If the
   * auditor user name and audit team id are both specified.</li>
   * </ul>
   */
  public void crossFieldValidation() {

    if ((getDtls().auditTeamID != 0)
      && (!StringHelper.isEmpty(getDtls().userName))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITORExceptionCreator.ERR_XFV_AUDITOR_AND_AUDIT_TEAM_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link ENTAUDITOR#ERR_FV_MANDATORY_AUDIT_PLAN_NOT_SET} - If the audit
   * plan value is not entered.</li>
   * <li> {@link ENTAUDITOR#ERR_FV_MANDATORY_USER_NAME_NOT_SET} - If the auditor
   * user name is not entered.</li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    if (getDtls().auditPlanID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITORExceptionCreator.ERR_FV_MANDATORY_AUDIT_PLAN_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if ((getDtls().auditTeamID == 0) && (getDtls().userName.length() == 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITORExceptionCreator.ERR_FV_MANDATORY_USER_NAME_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * Validates that the user has not already been added to the audit plan.
   */
  protected void validateDuplicates() {

    UsersKey usersKey = new UsersKey();

    usersKey.userName = this.getAuditorName();

    List<curam.caseaudit.impl.Auditor> results = auditorDAO.searchByAuditPlanAndUser(
      getAuditPlan(), usersKey);

    boolean duplicate = false;

    for (Auditor auditor : results) {
      if (auditor.getID() != this.getID()
        && auditor.getAuditorName().equals(this.getAuditorName())
        && auditor.getAuditPlan().equals(this.getAuditPlan())) {
        duplicate = true;
      }
    }

    if (duplicate) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITORExceptionCreator.ERR_XRV_DUPLICATE_USER_EXISTS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to set the derived auditor type value. If the auditor team id value
   * is set the Auditor Type is set to team, otherwise it is set to user.
   */
  protected void setAuditorType() {
    if (getDtls().auditTeamID != 0) {
      getDtls().auditorType = AUDITORTYPE.AUDITTEAM;
    } else {
      getDtls().auditorType = AUDITORTYPE.AUDITUSER;
    }
  }
  
  // BEGIN, CR00210526, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void validateAuditorAccess() 
    throws InformationalException {
    
    if (isUser()) {
      
      CaseAuditSecurityManagement caseAuditSecurityManagementObj = CaseAuditSecurityManagementFactory.newInstance();
      
      CaseAuditSecurityKey caseAuditSecurityKey = new CaseAuditSecurityKey();

      caseAuditSecurityKey.auditPlanID = getAuditPlan().getID();
      caseAuditSecurityKey.userName = getAuditorName();
      
      try {
        caseAuditSecurityManagementObj.checkCaseAuditSecurity(
          caseAuditSecurityKey);
      } catch (AppException ae) {
        ValidationHelper.addValidationError(ae);
      }
    }
  }
  // END, CR00210526
  
}
