/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.hook.task.impl;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import curam.codetable.TASKDEADLINEDUE;
import curam.codetable.TASKSTATUS;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.struct.TaskQueryCriteria;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.StringUtil;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringList;


/**
 * Default implementation of {@link SearchTaskSQL}. The default algorithms used 
 * for the various hook points points are defined here. 
 * <P>
 * By default there are three types of task search functionality:
 *
 * <ul>
 * <li>curam.core.facade.impl.TaskQuery</li>
 * <li>curam.core.facade.impl.Inbox.searchAvailableTasks()</li>
 * <li>curam.core.facade.impl.Inbox.searchForTasks(TaskQueryKey)</li>
 * </ul>
 */
public class SearchTaskSQLImpl implements SearchTaskSQL {

  /**
   * {@inheritDoc}
   */
  @Override
  public String getSQLStatement(TaskQueryCriteria criteria)
    throws AppException, InformationalException {

    return getSelectClause(criteria) + getFromClause(criteria)
      + getWhereClause(criteria) + getOrderBySQL(criteria);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getSelectClause(TaskQueryCriteria criteria) {
    StringBuffer selectClause = new StringBuffer();

    selectClause.append("SELECT DISTINCT ");
    selectClause.append("T.TASKID, ");
    selectClause.append("T.PRIORITY, ");
    selectClause.append("T.STATUS, ");
    selectClause.append("T.WDOSNAPSHOT,  ");
    selectClause.append("WFD.DEADLINETIME, ");
    selectClause.append("T.ASSIGNEDDATETIME, ");
    selectClause.append("T.CATEGORY, ");
    selectClause.append("T.CREATIONTIME, ");
    selectClause.append("T.RESERVEDBY, ");
    selectClause.append("T.RESTARTTIME, ");
    selectClause.append("T.VERSIONNO  ");

    selectClause.append(" INTO ");
    selectClause.append(":taskID, ");
    selectClause.append(":priority, ");
    selectClause.append(":status, ");
    selectClause.append(":subject, ");
    selectClause.append(":deadlineDateTime, ");
    selectClause.append(":assignedDateTime, ");
    selectClause.append(":category, ");
    selectClause.append(":creationTime, ");
    selectClause.append(":reservedBy, ");
    selectClause.append(":restartTime, ");
    selectClause.append(":versionNo ");
    return selectClause.toString();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getFromClause(TaskQueryCriteria criteria) {
    StringBuffer fromClause = new StringBuffer();

    fromClause.append("FROM ");
    fromClause.append("TASK T ");

    fromClause.append(
      " LEFT OUTER JOIN WORKFLOWDEADLINE WFD "
        + "ON ( T.TASKID = WFD.TASKID ) ");

    // additional join clause, if and only if we need to filter against the
    // BizObjAssociation table:
    if (criteria.businessObjectType.length() > 0) {
      fromClause.append(
        "LEFT OUTER JOIN BIZOBJASSOCIATION BOA ON "
          + "( T.TASKID = BOA.TASKID ) ");
    }

    // additional join clause, if and only if we need to filter against the
    // TaskAssignment table:
    if (criteria.assigneeType.length() > 0) {
      fromClause.append(
        " LEFT OUTER JOIN TASKASSIGNMENT TA ON " + "( T.TASKID = TA.TASKID ) ");
    }
    return fromClause.toString();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getWhereClause(TaskQueryCriteria criteria) throws AppException,
      InformationalException {

    List<String> whereClauses = new ArrayList<String>();
    String taskIDSQL = getTaskIDSQL(criteria);

    if (taskIDSQL.length() != 0) {
      whereClauses.add(taskIDSQL);
    }

    String reservedBySQL = getReservedBySQL(criteria);

    if (reservedBySQL.length() != 0) {
      whereClauses.add(reservedBySQL);
    }

    String statusSQL = getStatusSQL(criteria);

    if (statusSQL.length() != 0) {
      whereClauses.add(statusSQL);
    }

    String prioritySQL = getPrioritySQL(criteria);

    if (prioritySQL.length() != 0) {
      whereClauses.add(prioritySQL);
    }

    String busObjectTypeSQL = getBusinessObjectTypeSQL(criteria);

    if (busObjectTypeSQL.length() != 0) {
      whereClauses.add(busObjectTypeSQL);
    }

    String orgObjectSQL = getOrgObjectSQL(criteria);

    if (orgObjectSQL.length() != 0) {
      whereClauses.add(orgObjectSQL);
    }

    String deadlineSQL = getDeadlineSQL(criteria);

    if (deadlineSQL.length() != 0) {
      whereClauses.add(deadlineSQL);
    }

    String categorySQL = getCategorySQL(criteria);

    if (categorySQL.length() != 0) {
      whereClauses.add(categorySQL);
    }

    String creationDateSQL = getCreationDateSQL(criteria);

    if (creationDateSQL.length() != 0) {
      whereClauses.add(creationDateSQL);
    }

    String restartDateSQL = getRestartDateSQL(criteria);

    if (restartDateSQL.length() != 0) {
      whereClauses.add(restartDateSQL);
    }

    Iterator<String> iter = whereClauses.iterator();
    StringBuffer whereClause = new StringBuffer();

    if (iter.hasNext()) {
      whereClause.append("WHERE ");
      while (iter.hasNext()) {
        whereClause.append(iter.next());
        if (iter.hasNext()) {
          whereClause.append(" AND ");
        }
      }
    }

    return whereClause.toString();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getOrderBySQL(TaskQueryCriteria criteria) {
    return " ORDER BY WFD.DEADLINETIME ";
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getCountSQLStatement(TaskQueryCriteria criteria)
    throws AppException, InformationalException {

    StringBuffer selectClause = new StringBuffer();

    selectClause.append("SELECT COUNT (*) INTO :numberOfRecords ");

    return selectClause + getFromClause(criteria) + getWhereClause(criteria);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getBusinessObjectTypeSQL(TaskQueryCriteria criteria) {
    StringBuffer whereClause = new StringBuffer();

    if (criteria.businessObjectType.length() > 0) {
      whereClause.append(" BOA.BIZOBJECTTYPE = :businessObjectType ");
      whereClause.append(" AND BOA.BIZOBJECTID = :businessObjectID ");
    }
    return whereClause.toString();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getCategorySQL(TaskQueryCriteria criteria) {
    StringBuffer whereClause = new StringBuffer();

    if (criteria.taskCategory.length() != 0) {
      whereClause.append(" T.CATEGORY = :taskCategory ");
    }
    return whereClause.toString();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getOrgObjectSQL(TaskQueryCriteria criteria) {
    List<String> assigneeClauses = new ArrayList<String>();

    if (criteria.assigneeType.length() > 0) {
      assigneeClauses.add(" TA.ASSIGNEETYPE = :assigneeType ");
      if (criteria.relatedID != 0) {
        assigneeClauses.add(" TA.RELATEDID = :relatedID ");
      }
      if (criteria.relatedName.length() > 0) {
        assigneeClauses.add(" TA.RELATEDNAME = :relatedName ");
      }
    }
    Iterator<String> iter = assigneeClauses.iterator();
    StringBuffer whereClause = new StringBuffer();

    while (iter.hasNext()) {
      whereClause.append(iter.next());
      if (iter.hasNext()) {
        whereClause.append(" AND ");
      }
    }

    return whereClause.toString();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getStatusSQL(TaskQueryCriteria criteria) {
    StringBuffer whereClause = new StringBuffer();

    // In the available task search we always search for tasks that are not
    // closed. For the other searches we filter using the status entered by the 
    // user.
    if (!criteria.isAvailableTaskSearch && criteria.status.length() > 0) {
      whereClause.append(" T.STATUS = :status ");
    } else if (criteria.isAvailableTaskSearch) {
      criteria.status = TASKSTATUS.CLOSED;
      whereClause.append(" T.STATUS <> :status ");
    }

    return whereClause.toString();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getTaskIDSQL(TaskQueryCriteria criteria) {
    StringBuffer whereClause = new StringBuffer();

    if (criteria.taskID != 0) {
      whereClause.append(" T.TASKID = :taskID ");

    }
    return whereClause.toString();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getReservedBySQL(TaskQueryCriteria criteria)
    throws AppException, InformationalException {
    StringBuffer whereClause = new StringBuffer();

    if (criteria.isAvailableTaskSearch) {
      // If the search is the available task search then reserved by must be
      // null
      whereClause.append(" T.RESERVEDBY IS NULL ");
    } else if (criteria.isTaskQuery) {
      // If the search is the task query then reserved by must be the current
      // user if the search by user tasks indicator is set. Otherwise reserved
      // by must null
      if (criteria.searchMyTasksOnly) {

        // BEGIN, CR00378956, IBM
        if (StringUtil.isNullOrEmpty(criteria.relatedName)) {
          criteria.relatedName = UserAccessFactory.newInstance().getUserDetails().userName;
        }
        // END, CR00378956
        
        whereClause.append(" T.RESERVEDBY = :relatedName ");
      } else {
        // The indicator is not set so reserved by must be the current user or
        // null
        whereClause.append(" T.RESERVEDBY IS NULL ");
      }
    }

    return whereClause.toString();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getPrioritySQL(TaskQueryCriteria criteria) {
    StringBuffer whereClause = new StringBuffer();

    // It will never be the case where both the priority and selected priorities
    // attributes will be populated.
    if (criteria.priority.length() > 0) {
      whereClause.append(" T.PRIORITY = :priority ");
    } 

    return whereClause.toString();
  }

  /**
   * Returns a flag that indicates whether to append a SQL OR clause in the 
   * deadline due SQL. Because tasks due this month and tasks due this week 
   * covers tasks due today. We don't include any SQL clause in the query 
   * that is covered by another, therefore we need to look ahead in the SQL 
   * process to see if an OR clause needs to be added when looping through 
   * the deadline due codes selected by the user.
   *
   * @param nextDeadlineDueCode The task deadline due code table value
   * @param selectedDeadlines A tabbed delimited list of selected task 
   * deadline due code values.
   *
   * @return <code>True</code> if an OR clause is to be appended, otherwise
   * <code>false</code>.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected boolean appendOrClauseInDeadlineDueSQL(String nextDeadlineDueCode,
    String selectedDeadlines) {

    boolean answer = true;

    if (nextDeadlineDueCode.equals(TASKDEADLINEDUE.DUETODAY)
      && (selectedDeadlines.contains(TASKDEADLINEDUE.DUETHISMONTH)
        || selectedDeadlines.contains(TASKDEADLINEDUE.DUETHISWEEK))) {
      answer = false;
    }
    return answer;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getDeadlineSQL(TaskQueryCriteria criteria) {
    StringBuffer whereClause = new StringBuffer();

    if (!criteria.deadlineDateTime.isZero()) {
      whereClause.append(" WFD.DEADLINETIME <= :deadlineDateTime ");
    } else if (criteria.deadlineDue.length() != 0) {
      if (criteria.deadlineDue.equals(TASKDEADLINEDUE.DUEAFTERTHISMONTH)) {
        criteria.deadlineFromDateTime = SearchTaskUtilities.getFirstDayOfNextMonth();
        whereClause.append(" WFD.DEADLINETIME >= :deadlineFromDateTime");
      } else if (criteria.deadlineDue.equals(TASKDEADLINEDUE.DUETHISMONTH)) {
        criteria.deadlineFromDateTime = SearchTaskUtilities.getFirstDayOfThisMonth();
        criteria.deadlineToDateTime = SearchTaskUtilities.getFirstDayOfNextMonth();
        whereClause.append(" WFD.DEADLINETIME < :deadlineToDateTime");
        whereClause.append(" AND WFD.DEADLINETIME >= :deadlineFromDateTime");
      } else if (criteria.deadlineDue.equals(TASKDEADLINEDUE.DUETHISWEEK)) {
        criteria.deadlineFromDateTime = SearchTaskUtilities.getFirstDayOfThisWeek();
        criteria.deadlineToDateTime = SearchTaskUtilities.getFirstDayOfNextWeek();
        whereClause.append(" WFD.DEADLINETIME < :deadlineToDateTime");
        whereClause.append(" AND WFD.DEADLINETIME >= :deadlineFromDateTime");
      } else if (criteria.deadlineDue.equals(TASKDEADLINEDUE.DUETODAY)) {
        criteria.deadlineFromDateTime = Date.getCurrentDate().getDateTime();
        criteria.deadlineToDateTime = SearchTaskUtilities.getMidnightTomorrow();
        whereClause.append(" WFD.DEADLINETIME < :deadlineToDateTime");
        whereClause.append(" AND WFD.DEADLINETIME >= :deadlineFromDateTime");
      } else if (criteria.deadlineDue.equals(TASKDEADLINEDUE.OVERDUE)) {
        criteria.deadlineToDateTime = DateTime.getCurrentDateTime();
        whereClause.append(" WFD.DEADLINETIME < :deadlineToDateTime");
      }
    } else if (!criteria.deadlineFromDate.isZero()
      && !criteria.deadlineToDate.isZero()) {
      // Both filled
      // Dates default to midnight and will always be inclusive, therefore we
      // need to add 1 day to the to date to make it midnight the next day. Then
      // all SQL comparisons will use less than to implement the inclusive
      // meaning of the to date
      criteria.deadlineFromDateTime = criteria.deadlineFromDate.getDateTime();
      criteria.deadlineToDateTime = criteria.deadlineToDate.addDays(1).getDateTime();
      whereClause.append(" WFD.DEADLINETIME >= :deadlineFromDateTime ");
      whereClause.append(" AND WFD.DEADLINETIME < :deadlineToDateTime ");
    } else if (!criteria.deadlineFromDate.isZero()
      && criteria.deadlineToDate.isZero()) {
      // From filled, To not filled
      criteria.deadlineFromDateTime = criteria.deadlineFromDate.getDateTime();
      whereClause.append(" WFD.DEADLINETIME >= :deadlineFromDateTime ");
    } else if (criteria.deadlineFromDate.isZero()
      && !criteria.deadlineToDate.isZero()) {
      // From not filled, To filled
      // Dates default to midnight and will always be inclusive, therefore we
      // need to add 1 day to the to date to make it midnight the next day. Then
      // all SQL comparisons will use less than to implement the inclusive
      // meaning of the to date
      criteria.deadlineToDateTime = criteria.deadlineToDate.addDays(1).getDateTime();
      whereClause.append(" WFD.DEADLINETIME < :deadlineToDateTime ");
    } else if (criteria.selectedDeadline.length() != 0) {
      StringList selectedDeadlineDue = StringUtil.tabText2StringListWithTrim(
        criteria.selectedDeadline);
      Iterator<String> deadlines = selectedDeadlineDue.iterator();

      if (deadlines.hasNext()) {
        whereClause.append("(");
      }
      while (deadlines.hasNext()) {
        String nextDeadline = deadlines.next();

        if (nextDeadline.equals(TASKDEADLINEDUE.DUEAFTERTHISMONTH)) {
          criteria.deadlineAfterThisMonth = SearchTaskUtilities.getFirstDayOfNextMonth();
          whereClause.append(" WFD.DEADLINETIME >= :deadlineAfterThisMonth");
        } else if (nextDeadline.equals(TASKDEADLINEDUE.OVERDUE)) {
          criteria.deadlineOverdueDateTime = DateTime.getCurrentDateTime();
          whereClause.append(" WFD.DEADLINETIME < :deadlineOverdueDateTime");
        } else if (nextDeadline.equals(TASKDEADLINEDUE.DUETHISMONTH)) {
          criteria.deadlineThisMonthFromDateTime = SearchTaskUtilities.getFirstDayOfThisMonth();
          criteria.deadlineThisMonthToDateTime = SearchTaskUtilities.getFirstDayOfNextMonth();
          whereClause.append(" WFD.DEADLINETIME < :deadlineThisMonthToDateTime");
          whereClause.append(
            " AND WFD.DEADLINETIME >= :deadlineThisMonthFromDateTime");
        } else if (nextDeadline.equals(TASKDEADLINEDUE.DUETHISWEEK)) {
          criteria.deadlineThisWeekFromDateTime = SearchTaskUtilities.getFirstDayOfThisWeek();
          criteria.deadlineThisWeekToDateTime = SearchTaskUtilities.getFirstDayOfNextWeek();
          whereClause.append(" WFD.DEADLINETIME < :deadlineThisWeekToDateTime");
          whereClause.append(
            " AND WFD.DEADLINETIME >= :deadlineThisWeekFromDateTime");
        } else if (nextDeadline.equals(TASKDEADLINEDUE.DUETODAY)
          && !criteria.selectedDeadline.contains(TASKDEADLINEDUE.DUETHISMONTH)
          && !criteria.selectedDeadline.contains(TASKDEADLINEDUE.DUETHISWEEK)) {
          // Don't need to go here if due this month or due this week has been
          // selected because they cover due today
          criteria.deadlineTodayFromDateTime = Date.getCurrentDate().getDateTime();
          criteria.deadlineTodayToDateTime = SearchTaskUtilities.getMidnightTomorrow();
          whereClause.append(" WFD.DEADLINETIME < :deadlineTodayToDateTime");
          whereClause.append(
            " AND WFD.DEADLINETIME >= :deadlineTodayFromDateTime");
        }
        if (deadlines.hasNext()
          && appendOrClauseInDeadlineDueSQL(nextDeadline,
          criteria.selectedDeadline)) {
          whereClause.append(" OR ");
        }
      }
      if (selectedDeadlineDue.iterator().hasNext()) {
        whereClause.append(")");
      }
    }

    return whereClause.toString();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getCreationDateSQL(TaskQueryCriteria key) {
    StringBuffer whereClause = new StringBuffer();

    if (!key.creationFromDate.isZero() && !key.creationToDate.isZero()) {
      // Both filled
      // Dates default to midnight and will always be inclusive, therefore we
      // need to add 1 day to the to date to make it midnight the next day. Then
      // all SQL comparisons will use less than to implement the inclusive
      // meaning of the to date
      key.creationFromDateTime = key.creationFromDate.getDateTime();
      key.creationToDateTime = key.creationToDate.addDays(1).getDateTime();
      whereClause.append(" T.CREATIONTIME >= :creationFromDateTime ");
      whereClause.append(" AND T.CREATIONTIME < :creationToDateTime ");
    } else if (!key.creationFromDate.isZero() && key.creationToDate.isZero()) {
      // From filled, To not filled
      key.creationFromDateTime = key.creationFromDate.getDateTime();
      whereClause.append(" T.CREATIONTIME >= :creationFromDateTime ");
    } else if (key.creationFromDate.isZero() && !key.creationToDate.isZero()) {
      // From not filled, To filled
      // Dates default to midnight and will always be inclusive, therefore we
      // need to add 1 day to the to date to make it midnight the next day. Then
      // all SQL comparisons will use less than to implement the inclusive
      // meaning of the to date
      key.creationToDateTime = key.creationToDate.addDays(1).getDateTime();
      whereClause.append(" T.CREATIONTIME < :creationToDateTime ");
    } else if (key.creationLastNumberOfDays != -1) {
      key.creationFromDateTime = SearchTaskUtilities.getDaysAgo(
        key.creationLastNumberOfDays);
      key.creationToDateTime = SearchTaskUtilities.getMidnightTomorrow();
      whereClause.append(" T.CREATIONTIME >= :creationFromDateTime ");
      whereClause.append(" AND T.CREATIONTIME < :creationToDateTime ");
    } else if (key.creationLastNumberOfWeeks != -1) {
      key.creationFromDateTime = SearchTaskUtilities.getWeeksAgo(
        key.creationLastNumberOfWeeks);
      key.creationToDateTime = SearchTaskUtilities.getMidnightTomorrow();
      whereClause.append(" T.CREATIONTIME >= :creationFromDateTime ");
      whereClause.append(" AND T.CREATIONTIME < :creationToDateTime ");
    }

    return whereClause.toString();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getRestartDateSQL(TaskQueryCriteria key) {
    StringBuffer whereClause = new StringBuffer();

    if (!key.restartFromDate.isZero() && !key.restartToDate.isZero()) {
      // Both filled
      // Dates default to midnight and will always be inclusive, therefore we
      // need to add 1 day to the to date to make it midnight the next day. Then
      // all SQL comparisons will use less than to implement the inclusive
      // meaning of the to date
      key.restartFromDateTime = key.restartFromDate.getDateTime();
      key.restartToDateTime = key.restartToDate.addDays(1).getDateTime();
      whereClause.append(" T.RESTARTTIME >= :restartFromDateTime ");
      whereClause.append(" AND T.RESTARTTIME < :restartToDateTime ");
    } else if (!key.restartFromDate.isZero() && key.restartToDate.isZero()) {
      // From filled, To not filled
      key.restartFromDateTime = key.restartFromDate.getDateTime();
      whereClause.append(" T.RESTARTTIME >= :restartFromDateTime ");
    } else if (key.restartFromDate.isZero() && !key.restartToDate.isZero()) {
      // From not filled, To filled
      // Dates default to midnight and will always be inclusive, therefore we
      // need to add 1 day to the to date to make it midnight the next day. Then
      // all SQL comparisons will use less than to implement the inclusive
      // meaning of the to date
      key.restartToDateTime = key.restartToDate.addDays(1).getDateTime();
      whereClause.append(" T.RESTARTTIME < :restartToDateTime ");
    }
    return whereClause.toString();
  }
}
