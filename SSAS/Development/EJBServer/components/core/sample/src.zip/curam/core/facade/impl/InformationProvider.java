/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.CONCERNROLETYPE;
import curam.codetable.INFORMATIONPROVIDERTYPE;
import curam.core.facade.struct.InformationProviderRegistrationDetails;
import curam.core.facade.struct.InformationProviderRegistrationResult;
import curam.core.facade.struct.InformationProviderSearchDetails;
import curam.core.facade.struct.InformationProviderSearchKey;
import curam.core.facade.struct.MaintainConcernRoleKey;
import curam.core.facade.struct.ModifyInformationProviderDetails;
import curam.core.facade.struct.ModifyInformationProviderReturnDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ParticipantSearchDetails;
import curam.core.facade.struct.ParticipantSearchKey;
import curam.core.facade.struct.ParticipantSearchResult;
import curam.core.facade.struct.ReadInformationProviderDetails;
import curam.core.facade.struct.ReadInformationProviderDetailsKey;
import curam.core.facade.struct.ReadInformationProviderHomeKey;
import curam.core.facade.struct.ReadInformationProviderHomePageDetails;
import curam.core.fact.MaintainConcernRoleDetailsFactory;
import curam.core.sl.fact.ParticipantSearchRouterFactory;
import curam.core.sl.intf.ParticipantSearchRouter;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CuramInd;
import curam.core.struct.InfoProviderDetails;
import curam.core.struct.InfoProviderSearchKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.ReadInfoProviderResult;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for the Information Provider
 * presentation layer.
 *
 */
public abstract class InformationProvider extends curam.core.facade.base.InformationProvider {

  // ___________________________________________________________________________
  /**
   * Register Information Provider
   *
   * @param details concern role identifier & concern role Information Provider
   * details
   *
   * @return Registration ID details
   */
  public InformationProviderRegistrationResult register(InformationProviderRegistrationDetails details)
    throws AppException, InformationalException {

    // Information Provider maintenance object
    curam.core.intf.InfoProviderRegistration infoProviderRegistrationObj = curam.core.fact.InfoProviderRegistrationFactory.newInstance();

    // Concern role entity objects
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Read concern ID from ConcernRole, if necessary
    if (details.infoProvRegistrationDetails.relatedConcernRoleID != 0) {
      concernRoleKey.concernRoleID = details.infoProvRegistrationDetails.relatedConcernRoleID;
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      // Set concern ID in registration details
      details.infoProvRegistrationDetails.concernID = concernRoleDtls.concernID;
    }

    // Details to be returned
    InformationProviderRegistrationResult informationProviderRegistrationResult = new InformationProviderRegistrationResult();

    // Register Information Provider
    informationProviderRegistrationResult.registrationIDDetails = infoProviderRegistrationObj.registerInfoProvider(
      details.infoProvRegistrationDetails);

    // Return details
    return informationProviderRegistrationResult;
  }

  // ___________________________________________________________________________
  /**
   * @param key Information Provider identifier.
   *
   * @return Information Provider Search Details
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}
   *
   * Searches for InformationProvider Search Details
   */
  @Deprecated
  public InformationProviderSearchDetails search(InformationProviderSearchKey key)
    throws AppException, InformationalException {

    // Information Provider Search object and key.
    curam.core.intf.InformationProviderSearchRouter informationProviderSearchRouterObj = curam.core.fact.InformationProviderSearchRouterFactory.newInstance();
    InfoProviderSearchKey infoProviderSearchKey;

    // Details to be returned
    InformationProviderSearchDetails informationProviderSearchDetails = new InformationProviderSearchDetails();

    // Get the details for the search from the search key.
    infoProviderSearchKey = key.infoProviderSearchKey;

    // Search for Information Provider
    informationProviderSearchDetails.infoProviderSearchResult = informationProviderSearchRouterObj.search(
      infoProviderSearchKey);

    // Return the details.
    return informationProviderSearchDetails;
  }

  // ___________________________________________________________________________
  /**
   * Read the Information Provider Homepage details.
   *
   * @param key Information Provider Identifier
   *
   * @return Information Provider Homepage Details
   */
  public ReadInformationProviderHomePageDetails readHomePageDetails(ReadInformationProviderHomeKey key)
    throws AppException, InformationalException {

    // An instance of ReadInformationProviderHomePageDetails to be returned
    // when fields fully populated.
    ReadInformationProviderHomePageDetails readInformationProviderHomePageDetails = new ReadInformationProviderHomePageDetails();

    // Create an instance of InfoProviderHomePage.
    curam.core.intf.InfoProviderHomePage infoProviderHomePageObj = curam.core.fact.InfoProviderHomePageFactory.newInstance();

    // Read an ReadInfoProviderResult from the previously created
    // InfoProviderHomePage using the concernRoleHomePageKey attribute of the
    // ReadInformationProviderHomeKey Object passed as a parameter.
    ReadInfoProviderResult readInfoProviderResult = infoProviderHomePageObj.read(
      key.concernRoleHomePageKey);

    // Assign values from the ReadInfoProviderResult to the attributes.
    readInformationProviderHomePageDetails.informationalMsgDtlsList.assign(
      readInfoProviderResult.messages);
    readInformationProviderHomePageDetails.informationProviderHomeDetails.assign(
      readInfoProviderResult.details);

    // Create an instance of MaintainConcernRoleKey and set its concernRoleID
    // equal to the value of the concernRoleID attribute of the
    // concernRoleHomePageKey attribute of the ReadInformationProviderHomeKey
    // Object passed as a parameter.
    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    maintainConcernRoleKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    // Create an instance of MaintainConcernRoleDetails.
    curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();

    // Use the previously created MaintainConcernRoleKey to find the corresponding
    // InfoProviderDetails Object from the MaintainConcernRoleDetails.
    InfoProviderDetails infoProviderDetails = maintainConcernRoleDetailsObj.readInfoProvider(
      maintainConcernRoleKey);

    // Assign the returned InfoProviderDetails Object to the
    // informationProviderHomeDetails attribute.
    readInformationProviderHomePageDetails.informationProviderHomeDetails.assign(
      infoProviderDetails);

    // Context object and key
    curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Populate context description key
    participantContextDescriptionKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    // Read the context description
    readInformationProviderHomePageDetails.participantContextDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return the fully populated ReadInformationProviderHomePageDetails
    // instance.
    return readInformationProviderHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * Updates an information provider with modified details.
   *
   * @param details details of information provider to be modified.
   *
   * @return Information provider details.
   */
  public ModifyInformationProviderReturnDetails modifyInformationProviderDetails(ModifyInformationProviderDetails details)
    throws AppException, InformationalException {

    // Information provider maintenance object and key
    curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Details to be returned.
    ModifyInformationProviderReturnDetails modifyInformationProviderReturnDetails = new ModifyInformationProviderReturnDetails();

    // Get the concern role ID from the modify details.
    maintainConcernRoleKey.concernRoleID = details.infoProviderDetails.concernRoleID;

    // Modify the information provider details
    maintainConcernRoleDetailsObj.modifyInfoProvider(maintainConcernRoleKey,
      details.infoProviderDetails);

    // BEGIN, CR00016578, SPD
    // Create an informational manager
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      modifyInformationProviderReturnDetails.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00016578

    // Return details
    return modifyInformationProviderReturnDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves details of the specified information provider.
   *
   * @param key identifies information provider concerned
   *
   * @return Information provider details
   */
  public ReadInformationProviderDetails readInformationProviderDetails(ReadInformationProviderDetailsKey key)
    throws AppException, InformationalException {

    // Information provider search object and key
    curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Details to be returned.
    ReadInformationProviderDetails readInformationProviderDetails = new ReadInformationProviderDetails();

    // Context object and key
    curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Get the concern role ID from the search key.
    maintainConcernRoleKey.concernRoleID = key.maintainConcernRoleKey.concernRoleID;

    // Read the information provider details from the maintainConcernRoleKey
    readInformationProviderDetails.infoProviderDetails = maintainConcernRoleDetailsObj.readInfoProvider(
      maintainConcernRoleKey);

    // Populate context description key
    participantContextDescriptionKey.concernRoleID = readInformationProviderDetails.infoProviderDetails.concernRoleID;

    // Read the context description
    readInformationProviderDetails.participantContextDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return details
    return readInformationProviderDetails;
  }

  // BEGIN, CR00218851, ZV
  // BEGIN, CR00290965, IBM
  /**
   * Searches for an Information Provider by specified search criteria.
   *
   * @param key Information provider search criteria
   *
   * @return Information provider details found
   *
   * @throws InformationalException Informational Exception
   *
   * @throws AppException Application Exception
   * @deprecated Since Curam 6.0 SP2, replaced with {@link 
   * InformationProvider#searchInformationProvider(ParticipantSearchKey)}
   *
   * This method is deprecated as informational messages are not returned. This 
   * method is replaced by searchInformationProvider(ParticipantSearchKey) which 
   * returns the informational message along with information provider details 
   * as well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantSearchResult search1(ParticipantSearchKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    
    ParticipantSearchRouter participantSearchRouterObj = ParticipantSearchRouterFactory.newInstance();

    ParticipantSearchResult participantSearchResult = new ParticipantSearchResult();

    key.key.concernRoleType = CONCERNROLETYPE.INFORMATIONPROVIDER;

    participantSearchResult.dtls = participantSearchRouterObj.search(key.key);

    return participantSearchResult;
  }

  // END, CR00218851

  // BEGIN, CR00290965, IBM
  /**
   * Searches for an Information Provider by specified search criteria.
   *
   * @param key Information provider search criteria
   *
   * @return Information provider details found
   *
   * @throws InformationalException Informational Exception
   * @throws AppException Application Exception
   */
  public ParticipantSearchDetails searchInformationProvider(
    final ParticipantSearchKey participantSearchKey) throws AppException, InformationalException {
    
    ParticipantSearchRouter participantSearchRouter = ParticipantSearchRouterFactory.newInstance();

    ParticipantSearchDetails participantSearchDetails = new ParticipantSearchDetails();

    participantSearchKey.key.concernRoleType = CONCERNROLETYPE.INFORMATIONPROVIDER;

    participantSearchDetails.dtls = participantSearchRouter.search(
      participantSearchKey.key);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    String[] infos = informationalManager.obtainInformationalAsString();

    for (String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      participantSearchDetails.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }

    return participantSearchDetails;
  }

  // END, CR00290965

  // BEGIN, CR00300404, MC
  // __________________________________________________________________________
  /**
   * Returns true is the Information Provider is an Educational Institute.
   *
   * @param concernRoleKey Concern role ID for the Information Provider.
   * @return curamInd True if the Information Provider is an Educational Institute.
   */
  @Override
  public CuramInd isEducationalInstitute(MaintainConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {
    
    CuramInd curamInd = new CuramInd();

    curamInd.statusInd = MaintainConcernRoleDetailsFactory.newInstance().readInfoProvider(concernRoleKey.maintainConcernRoleKey).typeCode.equals(
      INFORMATIONPROVIDERTYPE.EDUINSTITUTE);
    
    return curamInd;
  }
  // END, CR00300404
  
}
