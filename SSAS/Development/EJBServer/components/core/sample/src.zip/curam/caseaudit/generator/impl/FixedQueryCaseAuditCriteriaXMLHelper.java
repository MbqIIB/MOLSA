/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.generator.impl;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.xpath.XPath;

import curam.cefwidgets.docbuilder.impl.XMLBuilder;
import curam.core.facade.struct.CaseSampleKey;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;

public class FixedQueryCaseAuditCriteriaXMLHelper 
  implements CaseAuditCriteriaXMLHelper {

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public FixedQueryCaseAuditCriteriaXMLHelper() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Builds the XML <code>String</code> representation of the data to be
   * to be used in the creation of the case audit sample. 
   *  
   * @param key
   *          The search criteria to be used in the generation of the case
   *          audit sample.
   *           
   * @return An XML <code>String</code> representation of the data to be used 
   *         in the creation of the case audit sample.
   */
  public String buildCriteria(final CaseSampleKey key) 
    throws AppException, InformationalException {

    XMLBuilder xmlBuilder = 
      new XMLBuilder(CaseAuditCriteriaXMLConst.kCaseSampleKey);
    
    if (key.auditPlanID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAuditPlanID);
      xmlBuilder.addTagData(String.valueOf(key.auditPlanID));
      xmlBuilder.closeTag();
    }

    if (key.totalNumCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kTotalNumCases);
      xmlBuilder.addTagData(String.valueOf(key.totalNumCases));
      xmlBuilder.closeTag();      
    }
    
    if (key.numberOfCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kNumCases);
      xmlBuilder.addTagData(String.valueOf(key.numberOfCases));
      xmlBuilder.closeTag();      
    }
    
    if (key.percentageOfCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kPercentageOfCases);
      xmlBuilder.addTagData(String.valueOf(key.percentageOfCases));
      xmlBuilder.closeTag();      
    }
    
    if (key.selectionQueryID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kSelectionQueryID);
      xmlBuilder.addTagData(String.valueOf(key.selectionQueryID));
      xmlBuilder.closeTag();      
    }
    
    if (key.details != null) {
      
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAlgorithmParameters);
      
      if (key.details.startPoint > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStartPoint);
        xmlBuilder.addTagData(String.valueOf(key.details.startPoint));
        xmlBuilder.closeTag();      
      }
      
      if (key.details.interval > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kInterval);
        xmlBuilder.addTagData(String.valueOf(key.details.interval));
        xmlBuilder.closeTag();      
      }
      xmlBuilder.closeTag();      
    }
    
    return xmlBuilder.getXmlString();
  }

  // ___________________________________________________________________________
  /**
   * Parses an XML document that represents the data to be used in the 
   * creation of the case audit sample.
   *  
   * @param document
   *         The XML <code>String</code> representation of the data to be used 
   *         in the creation of the case audit sample.
   *           
   * @return The key containing the search criteria.
   */
  public CaseSampleKey parseCriteria(final Document document) 
    throws AppException, InformationalException {

    CaseSampleKey caseSampleKey = new CaseSampleKey(); 
    
    try { 
    
      XPath xpath = XPath.newInstance("//CaseSampleKey/auditPlanID/text()");
      org.jdom.Text text = 
        (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {       
        caseSampleKey.auditPlanID = new Long(text.getText()).longValue();
      }
      
      xpath = XPath.newInstance("//CaseSampleKey/totalNumCases/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.totalNumCases = Integer.parseInt(text.getText());
      }
      
      xpath = XPath.newInstance("//CaseSampleKey/numberOfCases/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.numberOfCases = Integer.parseInt(text.getText());
      }
  
      xpath = XPath.newInstance("//CaseSampleKey/percentageOfCases/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.percentageOfCases = Double.parseDouble(text.getText());
      }
      
      xpath = XPath.newInstance("//CaseSampleKey/selectionQueryID/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.selectionQueryID = new Long(text.getText()).longValue();
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/algorithmParameters/startPoint/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.details.startPoint = Integer.parseInt(text.getText());
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/algorithmParameters/interval/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.details.interval = Integer.parseInt(text.getText());
      }      
    } catch (final JDOMException e) {
      throw new AppRuntimeException(e);
    }
    return caseSampleKey;
  }
}
