/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 - 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.generator.impl;


import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.xpath.XPath;

import curam.cefwidgets.docbuilder.impl.XMLBuilder;
import curam.codetable.impl.CASECATEGORYEntry;
import curam.codetable.impl.CASEDECISIONRESULTCODEEntry;
import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.GENDEREntry;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.core.facade.struct.CaseSampleKey;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Locale;
import curam.util.type.Date;
import curam.util.type.StringHelper;


public class LiabilityCaseAuditCriteriaXMLHelper 
  implements CaseAuditCriteriaXMLHelper {

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public LiabilityCaseAuditCriteriaXMLHelper() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Builds the XML <code>String</code> representation of the data to be
   * to be used in the creation of the case audit sample. 
   *
   * @param key
   * The search criteria to be used in the generation of the case
   * audit sample.
   *
   * @return An XML <code>String</code> representation of the data to be used 
   * in the creation of the case audit sample.
   */
  public String buildCriteria(final CaseSampleKey key) 
    throws AppException, InformationalException {

    XMLBuilder xmlBuilder = new XMLBuilder(
      CaseAuditCriteriaXMLConst.kCaseSampleKey);
    
    if (key.auditPlanID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAuditPlanID);
      xmlBuilder.addTagData(String.valueOf(key.auditPlanID));
      xmlBuilder.closeTag();
    }

    if (key.totalNumCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kTotalNumCases);
      xmlBuilder.addTagData(String.valueOf(key.totalNumCases));
      xmlBuilder.closeTag();      
    }
    
    if (key.numberOfCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kNumCases);
      xmlBuilder.addTagData(String.valueOf(key.numberOfCases));
      xmlBuilder.closeTag();      
    }
    
    if (key.percentageOfCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kPercentageOfCases);
      xmlBuilder.addTagData(String.valueOf(key.percentageOfCases));
      xmlBuilder.closeTag();      
    }
    
    if (key.selectionQueryID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kSelectionQueryID);
      xmlBuilder.addTagData(String.valueOf(key.selectionQueryID));
      xmlBuilder.closeTag();      
    }
    
    if (key.externalCaseAuditDataID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kExternalCaseAuditDataID);
      xmlBuilder.addTagData(String.valueOf(key.externalCaseAuditDataID));
      xmlBuilder.closeTag();      
    }

    if (key.details != null) {
      
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAlgorithmParameters);
      
      if (key.details.startPoint > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStartPoint);
        xmlBuilder.addTagData(String.valueOf(key.details.startPoint));
        xmlBuilder.closeTag();      
      }
      
      if (key.details.interval > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kInterval);
        xmlBuilder.addTagData(String.valueOf(key.details.interval));
        xmlBuilder.closeTag();      
      }
      xmlBuilder.closeTag();      
    }
      
    if (key.lpdDtls != null) {
      
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCommonLPDSearchCriteria);
      
      if (!key.lpdDtls.status.equals(CASESTATUSEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStatus);
        xmlBuilder.addTagData(key.lpdDtls.status);
        xmlBuilder.closeTag();      
      }
      
      if (key.lpdDtls.age > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAge);
        xmlBuilder.addTagData(String.valueOf(key.lpdDtls.age));
        xmlBuilder.closeTag();      
      }      
      
      if (!StringHelper.isEmpty(key.lpdDtls.caseOwner)) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCaseOwner);
        xmlBuilder.addTagData(String.valueOf(key.lpdDtls.caseOwner));
        xmlBuilder.closeTag();      
      }      
      
      if (!key.lpdDtls.caseTypeCode.equals(
        CASETYPECODEEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCaseTypeCode);
        xmlBuilder.addTagData(String.valueOf(key.lpdDtls.caseTypeCode));
        xmlBuilder.closeTag();      
      }      
      
      if (!key.lpdDtls.category.equals(
        CASECATEGORYEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCaseCategory);
        xmlBuilder.addTagData(String.valueOf(key.lpdDtls.category));
        xmlBuilder.closeTag();      
      }      
      
      if (!key.lpdDtls.endDateFrom.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kEndDateFrom);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.lpdDtls.endDateFrom, Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }
      
      if (!key.lpdDtls.endDateTo.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kEndDateTo);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.lpdDtls.endDateTo, Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }
      
      if (!key.lpdDtls.startDateFrom.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStartDateFrom);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.lpdDtls.startDateFrom, Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }
      
      if (!key.lpdDtls.startDateTo.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStartDateTo);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.lpdDtls.startDateTo, Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      
      }
      if (!key.lpdDtls.gender.equals(GENDEREntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kGender);
        xmlBuilder.addTagData(String.valueOf(key.lpdDtls.gender));
        xmlBuilder.closeTag();              
      }
      
      if (key.lpdDtls.ownerLocation != 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kOwnerLocation);
        xmlBuilder.addTagData(String.valueOf(key.lpdDtls.ownerLocation));
        xmlBuilder.closeTag();              
      }
      
      if (key.lpdDtls.filterOptionList.length() > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kFilterOptionList);
        xmlBuilder.addTagData(String.valueOf(key.lpdDtls.filterOptionList));
        xmlBuilder.closeTag();              
      }
      
      if (!key.lpdDtls.orgObjectType.equals(
        ORGOBJECTTYPEEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kOrgObjectType);
        xmlBuilder.addTagData(String.valueOf(key.lpdDtls.orgObjectType));
        xmlBuilder.closeTag();              
      }
      
      if (!key.lpdDtls.certificationFromDate.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCertificationFrom);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.lpdDtls.certificationFromDate,
          Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }

      if (!key.lpdDtls.certificationToDate.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCertificationTo);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.lpdDtls.certificationToDate,
          Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }

      if (!key.lpdDtls.timePeriodFromDate.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kTimePeriodFrom);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.lpdDtls.timePeriodFromDate,
          Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }

      if (!key.lpdDtls.timePeriodToDate.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kTimePeriodTo);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.lpdDtls.timePeriodToDate, Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }

      if (!key.lpdDtls.decision.equals(
        CASEDECISIONRESULTCODEEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kDecision);
        xmlBuilder.addTagData(String.valueOf(key.lpdDtls.decision));
        xmlBuilder.closeTag();              
      }

      xmlBuilder.closeTag();      
    }
    
    return xmlBuilder.getXmlString();
  }

  // ___________________________________________________________________________
  /**
   * Parses an XML document that represents the data to be used in the 
   * creation of the case audit sample.
   *
   * @param document
   * The XML <code>String</code> representation of the data to be used 
   * in the creation of the case audit sample.
   *
   * @return The key containing the search criteria.
   */
  public CaseSampleKey parseCriteria(final Document document) 
    throws AppException, InformationalException {

    CaseSampleKey caseSampleKey = new CaseSampleKey(); 
    
    try { 
    
      XPath xpath = XPath.newInstance("//CaseSampleKey/auditPlanID/text()");
      org.jdom.Text text = (org.jdom.Text) xpath.selectSingleNode(
        document.getRootElement());

      if (text != null) {       
        caseSampleKey.auditPlanID = new Long(text.getText()).longValue();
      }
      
      xpath = XPath.newInstance("//CaseSampleKey/totalNumCases/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.totalNumCases = Integer.parseInt(text.getText());
      }
      
      xpath = XPath.newInstance("//CaseSampleKey/numberOfCases/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.numberOfCases = Integer.parseInt(text.getText());
      }
  
      xpath = XPath.newInstance("//CaseSampleKey/percentageOfCases/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.percentageOfCases = Double.parseDouble(text.getText());
      }
      
      xpath = XPath.newInstance("//CaseSampleKey/selectionQueryID/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.selectionQueryID = new Long(text.getText()).longValue();
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/externalCaseAuditDataID/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.externalCaseAuditDataID = new Long(text.getText()).longValue();
      }
  
      xpath = XPath.newInstance(
        "//CaseSampleKey/algorithmParameters/startPoint/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.details.startPoint = Integer.parseInt(text.getText());
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/algorithmParameters/interval/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.details.interval = Integer.parseInt(text.getText());
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/status/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.lpdDtls.status = text.getText();
      }
      
      xpath = XPath.newInstance(
        "" + "//CaseSampleKey/commonLPDSearchCriteria/age/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.lpdDtls.age = Integer.parseInt(text.getText());
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/caseOwner/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.lpdDtls.caseOwner = text.getText();
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/caseTypeCode/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.lpdDtls.caseTypeCode = text.getText();
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/category/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.lpdDtls.category = text.getText();
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/endDateFrom/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.lpdDtls.endDateFrom = Date.fromISO8601(text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/endDateTo/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.lpdDtls.endDateTo = Date.fromISO8601(text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/startDateFrom/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {        
        // BEGIN, CR00298436, PMD
        caseSampleKey.lpdDtls.startDateFrom = Date.fromISO8601(text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/startDateTo/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.lpdDtls.startDateTo = Date.fromISO8601(text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/gender/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.lpdDtls.gender = text.getText();
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/ownerLocation/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.lpdDtls.ownerLocation = Long.parseLong(text.getText());
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/filterOptionList/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.lpdDtls.filterOptionList = text.getText();
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/orgObjectType/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.lpdDtls.orgObjectType = text.getText();
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/certificationFrom/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {      
        // BEGIN, CR00298436, PMD
        caseSampleKey.lpdDtls.certificationFromDate = Date.fromISO8601(
          text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/certificationTo/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.lpdDtls.certificationToDate = Date.fromISO8601(
          text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/timePeriodFrom/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {      
        // BEGIN, CR00298436, PMD
        caseSampleKey.lpdDtls.timePeriodFromDate = Date.fromISO8601(
          text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/timePeriodTo/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.lpdDtls.timePeriodToDate = Date.fromISO8601(
          text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonLPDSearchCriteria/decision/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.lpdDtls.decision = text.getText();
      }

    } catch (final JDOMException e) {
      throw new AppRuntimeException(e);
    }
    return caseSampleKey;
  }
}
