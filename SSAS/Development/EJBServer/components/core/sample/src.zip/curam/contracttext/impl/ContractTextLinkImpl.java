/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracttext.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CONTRACTTEXTLINKTYPEEntry;
import curam.core.sl.entity.struct.CancelContractTextDetails;
import curam.core.sl.entity.struct.ContractTextDtls;
import curam.core.sl.entity.struct.ContractTextKey;
import curam.core.sl.entity.struct.ContractTextLinkDtls;
import curam.core.sl.entity.struct.RelatedReferenceKey;
import curam.message.impl.BPOCONTRACTTEXTLINKExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Standard implementation of {@linkplain curam.contracttext.impl.ContractTextLink}.
 */
// BEGIN, CR00183334, PS
public class ContractTextLinkImpl extends SingleTableEntityImpl<ContractTextLinkDtls> implements ContractTextLink {

  /**
   * Constructor for the class.
   */
  protected ContractTextLinkImpl() {
    // END, CR00183334
    // Bootstrap dependency injection for this class.
    GuiceWrapper.getInjector().injectMembers(this);
  }
  
  /**
   * Instance variable of contractTextDtls type to hold the details of contract text 
   */
  protected ContractTextDtls contractTextDtls = new ContractTextDtls();
  
  /**
   * Reference to Contract Text Link DAO.
   */
  @Inject
  protected ContractTextLinkDAO contractTextLinkDAO;

  /**
   * {@inheritDoc}
   */
  public ContractTextDtls getContractText() throws AppException,
      InformationalException {

    curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();
    ContractTextKey contractTextKey = new ContractTextKey();

    contractTextKey.contractTextID = getDtls().contractTextID;

    return contractTextObj.read(contractTextKey);
  }

  /**
   * {@inheritDoc}
   */
  public void setContractText(ContractTextDtls contractTextDtls) {

    getDtls().contractTextID = contractTextDtls.contractTextID;
    this.contractTextDtls = contractTextDtls;
  }

  /**
   * {@inheritDoc}
   */
  public RelatedReferenceKey getRelatedReference() {

    RelatedReferenceKey relatedReferenceKey = new RelatedReferenceKey();

    relatedReferenceKey.relatedID = getDtls().relatedID;

    return relatedReferenceKey;
  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedReference(RelatedReferenceKey relatedReferenceKey) {

    getDtls().relatedID = relatedReferenceKey.relatedID;

  }

  /**
   * Inserts a contract text link record.
   *
   * @throws InformationalException
   * {@link curam.message.BPOCONTRACTTEXTLINK#ERR_CONTRACTTEXTLINK_XRV_CONTRACTTEXT_ALREADY_EXISTS_FOR_THIS_LANGAUGE}
   * - If a contract text already exists for the given language.
   * @throws InformationalException
   * {@link curam.message.BPOCONTRACTTEXTLINK#ERR_CONTRACTTEXTLINK_XRV_CONTRACTTEXT_DOES_NOT_EXIST}
   * - If contract text record is not found.
   */
  @Override
  public void insert() throws InformationalException {

    // Check if there exists a contract text, for the same related reference and
    // same language.

    RelatedReferenceKey relatedReferenceKey = new RelatedReferenceKey();

    relatedReferenceKey.relatedID = getDtls().relatedID;

    Set<ContractTextLink> contractTextLinks = contractTextLinkDAO.searchByRelatedReference(
      relatedReferenceKey);

    curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();
    curam.core.sl.entity.struct.ContractTextKey contractTextKey = new curam.core.sl.entity.struct.ContractTextKey();

    try {
      // For each contract text link, get the associated contract text and check
      // if it is of same language as the
      // one that is going to be inserted, i.e check if for the same related
      // reference and language, a contract text already exists.
      for (ContractTextLink contractTextLink : contractTextLinks) {

        contractTextKey.contractTextID = contractTextLink.getContractText().contractTextID;
        ContractTextDtls contractTxtDtls = contractTextObj.read(contractTextKey);

        if (contractTextDtls.languageCode.equalsIgnoreCase(
          contractTxtDtls.languageCode)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            BPOCONTRACTTEXTLINKExceptionCreator.ERR_CONTRACTTEXTLINK_XRV_CONTRACTTEXT_ALREADY_EXISTS_FOR_THIS_LANGAUGE(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
          ValidationHelper.failIfErrorsExist();
        }
      }
    } catch (AppException appException) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOCONTRACTTEXTLINKExceptionCreator.ERR_CONTRACTTEXTLINK_XRV_CONTRACTTEXT_DOES_NOT_EXIST(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      ValidationHelper.failIfErrorsExist();
    }

    super.insert();
  }

  /**
   * {@inheritDoc}
   */
  public CONTRACTTEXTLINKTYPEEntry getRelatedType() {

    return CONTRACTTEXTLINKTYPEEntry.get(getDtls().relatedType);
  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedType(CONTRACTTEXTLINKTYPEEntry contractTextRelatedTypeEntry) {

    getDtls().relatedType = contractTextRelatedTypeEntry.getCode();
  }

  /**
   * Removes a contract text link record.
   *
   * @param versionNo
   * Version number of the contract text to be removed.
   *
   * @throws InformationalException
   * {@link curam.message.BPOCONTRACTTEXTLINK#ERR_CONTRACTTEXTLINK_XRV_CONTRACTTEXT_DOES_NOT_EXIST}
   * - If contract text record is not found.
   */
  public void remove(Integer versionNo) throws InformationalException {
    
    super.remove(versionNo);

    try {
      // Cancel the record status in the Contract Text entity.
      curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();
      curam.core.sl.entity.struct.ContractTextKey contractTextKey = new curam.core.sl.entity.struct.ContractTextKey();
      CancelContractTextDetails cancelContractTextDetails = new CancelContractTextDetails();

      // Set cancel key and details.
      contractTextKey.contractTextID = getDtls().contractTextID;
      ContractTextDtls contractTextDtls = contractTextObj.read(contractTextKey);

      cancelContractTextDetails.recordStatus = RECORDSTATUS.CANCELLED;
      cancelContractTextDetails.versionNo = contractTextDtls.versionNo;

      // Cancel the contract text.
      contractTextObj.cancel(contractTextKey, cancelContractTextDetails);
    } catch (AppException appException) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOCONTRACTTEXTLINKExceptionCreator.ERR_CONTRACTTEXTLINK_XRV_CONTRACTTEXT_DOES_NOT_EXIST(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      ValidationHelper.failIfErrorsExist();
    }

  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// Set the new instance defaults here.
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No cross entity validations exists.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No cross field validations exists.
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No mandatory field validations exists.
  }
}
