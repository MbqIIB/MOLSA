/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2011, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.impl;


import curam.codetable.impl.APPEALOBJECTTYPEEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;


/**
 * Abstracts all processing related to appeal object types.
 */
public interface Appealable {

  /**
   * Retrieve the home page URI for an appeal object type.
   *
   * @param objectType The object type code table code.
   * @param objectID The object identifier.
   *
   * @return URI for object home page.
   */
  public String getHomePageURI(APPEALOBJECTTYPEEntry objectType, long objectID)
    throws AppException, InformationalException;

  /**
   * Retrieve the description for an appeal object type.
   *
   * @param objectType The object type code table code.
   * @param objectID The object identifier.
   *
   * @return The description for an appeal object type.
   */
  public LocalisableString getAppealObjectDescription(APPEALOBJECTTYPEEntry objectType, long objectID)
    throws AppException, InformationalException;

}
