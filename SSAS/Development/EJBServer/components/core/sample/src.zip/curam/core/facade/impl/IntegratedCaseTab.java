/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;

import curam.core.sl.fact.IntegratedCaseTabFactory;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.IntegratedCaseTabDetail;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the Integrated Case
 * section tab details facade layer.
 */
public abstract class IntegratedCaseTab extends curam.core.facade.base.IntegratedCaseTab {

  //___________________________________________________________________________
  /**
   * Read the details for the integrated case preview details panel.
   *
   * @param integratedCaseTabDetailKey Contains the case ID.
   * @return IntegratedCaseTabDetail The details required for the integrated
   * case tab details panel.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public IntegratedCaseTabDetail readIntegratedCasePreviewDetail(CaseIDKey key)
      throws AppException, InformationalException {

    return IntegratedCaseTabFactory.newInstance().
      readIntegratedCasePreviewDetail(key);

  }

  //___________________________________________________________________________
  /**
   * Read the details for the integrated case tab details panel.
   *
   * @param integratedCaseTabDetailKey Contains the case ID.
   * @return IntegratedCaseTabDetail The details required for the integrated
   * case tab details panel.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public IntegratedCaseTabDetail readIntegratedCaseTabDetail(CaseIDKey key)
    throws AppException, InformationalException {

    return IntegratedCaseTabFactory.newInstance().
      readIntegratedCaseTabDetail(key);
  }

}