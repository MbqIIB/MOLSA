/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracttext.impl;


import java.util.Set;

import com.google.inject.Singleton;

import curam.core.sl.entity.impl.ContractTextLinkAdapter;
import curam.core.sl.entity.struct.ContractTextKey;
import curam.core.sl.entity.struct.ContractTextLinkDtls;
import curam.core.sl.entity.struct.RelatedReferenceKey;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of {@linkplain curam.contractext.impl.ContractTextLinkDAO}.
 */
@Singleton
// BEGIN, CR00183334, PS
public class ContractTextLinkDAOImpl extends StandardDAOImpl<ContractTextLink, ContractTextLinkDtls> implements
  ContractTextLinkDAO {
  // END, CR00183334
  /**
   * Instance of Contract Text Link adapter.
   */
  protected static final ContractTextLinkAdapter contractTextLinkAdapter = new ContractTextLinkAdapter();

  /**
   * Constructor for the class.
   */
  // BEGIN, CR00183334, PS
  protected ContractTextLinkDAOImpl() {
    // END, CR00183334
    super(contractTextLinkAdapter, ContractTextLink.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<ContractTextLink> searchByContractText(ContractTextKey contractTextKey) {

    return newSet(
      contractTextLinkAdapter.searchByContractText(
        contractTextKey.contractTextID));
  }

  /**
   * {@inheritDoc}
   */
  public Set<ContractTextLink> searchByRelatedReference(
    RelatedReferenceKey relatedReferenceKey) {

    return newSet(
      contractTextLinkAdapter.searchByRelatedReference(
        relatedReferenceKey.relatedID));
  }
 
}
