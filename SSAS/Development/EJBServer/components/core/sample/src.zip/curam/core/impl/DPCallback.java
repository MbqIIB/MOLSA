/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import org.apache.log4j.Logger;

import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.NotificationDetails;
import curam.core.struct.ResetStatusFollowingDelayedProcessing;
import curam.core.struct.WMInstanceDataDtls;
import curam.core.struct.WMInstanceDataKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Trace;


/**
 * Application specific callback functions required by the workflow system.
 *
 */
public class DPCallback extends curam.core.base.DPCallback
  implements curam.util.deferredprocessing.impl.DPCallback { // BEGIN, 49545, VM

  protected static final int kStringBufferSize = 256;
  // local variable to hold details of any changes made to ticket.
  protected static StringBuffer changesMade =
    new StringBuffer(kStringBufferSize);
  
  // BEGIN, CR00360915, CW
  /**
   * This constant is used to name the category into which the Deferred Process
   * Failure related trace output is placed.
   */
  public static final String kDeferredProcessFailureCategory = Trace.kDefaultTraceCategory
    + ExtensionConst.kDeferredProcessFailureCategory;

  /**
   * This constant is an alias which allows Deferred Process Failure related
   * tracing information to be written.
   */
  public static final Logger kDeferredProcessFailureLogger = Logger.getLogger(
    kDeferredProcessFailureCategory);
  // END, CR00360915


  // ___________________________________________________________________________
  /**
   * This Process is called by the error handler on the queue for delayed
   * processing tasks. This should be used to implement any application
   * business processing that should take place when an error occurred in a
   * delayed process.
   *
   * @param processName The name of the process called when the error occurred.
   * @param instDataID the instance data ID for this call
   *
   */
  public void dpHandleError(String processName, long instDataID)
    throws AppException, InformationalException {

    // WMInstanceData manipulation variables
    curam.core.intf.WMInstanceData wmInstanceDataObj =
      curam.core.fact.WMInstanceDataFactory.newInstance();
    WMInstanceDataDtls wmInstanceDataDtls;
    WMInstanceDataKey wmInstanceDataKey = new WMInstanceDataKey();

    // ModifyCaseStatusForDelayedProcessing object
    curam.core.intf.ModifyCaseStatusForDelayedProcessing modifyCaseStatusForDelayedProcessingObj =
      curam.core.fact.ModifyCaseStatusForDelayedProcessingFactory.newInstance();

    // ResetStatusFollowingDelayedProcessing object
    ResetStatusFollowingDelayedProcessing resetStatusFollowingDelayedProcessing =
      new ResetStatusFollowingDelayedProcessing();

    // CaseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // Notification manipulation variables
    curam.core.intf.Notification notificationObj =
      curam.core.fact.NotificationFactory.newInstance();
    NotificationDetails notificationDtls = new NotificationDetails();

    // register the security implementation
    SecurityImplementationFactory.register();

    // need to retrieve the key details from the workflow system
    wmInstanceDataKey.wm_instDataID = instDataID;

    wmInstanceDataDtls = wmInstanceDataObj.read(wmInstanceDataKey);

    // BEGIN, CR00360915, CW
    // deferred processing access variables
    curam.util.intf.DeferredProcessing dpAccessObj =
      curam.util.fact.DeferredProcessingFactory.newInstance();
    curam.util.struct.ProcessNameKey dpProcessByApiKey =
      new curam.util.struct.ProcessNameKey();
    curam.util.struct.ProcessInfoDetails dpProcessInfoDetails;

    dpProcessByApiKey.instDataID = instDataID;
    dpProcessByApiKey.processName = processName;

    dpProcessInfoDetails =
      dpAccessObj.getDeferredProcessInfo(dpProcessByApiKey);
    // END, CR00360915

    // if this is processing related to a case
    if (wmInstanceDataDtls.caseID != 0) {

      AppException subjectMsg =
        new AppException(
          curam.message.BPOWMTICKETCALLBACK.INF_DEFERRED_PROC_CASE_FAILED);

      // AppException reasonMsg =
      // new AppException(
      // curam.message.BPOWMTICKETCALLBACK.INF_DEFERRED_PROC_CASE_FAILED_REASON);
      new AppException(
        curam.message.BPOWMTICKETCALLBACK.INF_DEFERRED_PROC_CASE_FAILED_REASON);
      // BEGIN, CR00023618, SK
      // BEGIN, CR00124832, SAI
      notificationDtls.taskDefinitionID =
        TaskDefinitionIDConst.notificationTaskDefinitionID;
      // END, CR00124832
      // END, CR00023618
      // set caseStatus back to original status, if required
      if (wmInstanceDataDtls.caseStatus.length() > 0) {

        resetStatusFollowingDelayedProcessing.caseStatus =
          wmInstanceDataDtls.caseStatus;
        resetStatusFollowingDelayedProcessing.caseID =
          wmInstanceDataDtls.caseID;

        modifyCaseStatusForDelayedProcessingObj.reSetStatus(
          resetStatusFollowingDelayedProcessing);
      }

      // Set up the case specific components of the ticket
      // read CaseHeader from database
      caseHeaderKey.caseID = wmInstanceDataDtls.caseID;

      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      notificationDtls.concernRoleID = caseHeaderDtls.concernRoleID;
      notificationDtls.caseID = wmInstanceDataDtls.caseID;

      // include the details in the subject and reason texts.
      subjectMsg.arg(caseHeaderDtls.caseReference);

      // BEGIN, CR00360915, CW
      notificationDtls.subject = subjectMsg.toString();
      notificationDtls.reasonText = dpProcessInfoDetails.exceptionDescription;

      notificationDtls.recipientUserName = wmInstanceDataDtls.enteredByID;
      notificationDtls.currPriority = curam.codetable.TASKPRIORITY.NORMAL;
      notificationDtls.ticketType = curam.codetable.TICKETTYPE.USERNOTIFICATION;
      notificationDtls.ticketGenInd =
        curam.codetable.SYSTEMTICKET.GENDEFERREDPROCESSINGFAILEDTICKET;

      // create notification
      notificationObj.createNotification(notificationDtls);
      // END, CR00360915


    } else {

      // Set up the alternative subject and message
      AppException reasonMsg =
        new AppException(
          curam.message.BPOWMTICKETCALLBACK.INF_DEFERRED_PROC_FAILED_REASON);

      reasonMsg.arg(processName);
      // BEGIN, CR00360915, CW
      reasonMsg.arg(dpProcessInfoDetails.subject);

      kDeferredProcessFailureLogger.error(curam.message.BPOWMTICKETCALLBACK.INF_DEFERRED_PROC_FAILED);
      kDeferredProcessFailureLogger.error(reasonMsg);
      // END, CR00360915

    }
  }

}
