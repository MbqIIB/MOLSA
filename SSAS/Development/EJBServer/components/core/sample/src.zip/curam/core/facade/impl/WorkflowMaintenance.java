/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.sl.struct.UserNameAndFullName;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.UserNameKeyList;
import curam.events.CASE;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


// BEGIN, CR00091194, CM
/**
 * Process class for WorkflowMaintenance facade.
 */
public abstract class WorkflowMaintenance extends
  curam.core.facade.base.WorkflowMaintenance {

  // ___________________________________________________________________________
  /**
   * Confirm that the case supervisor exists
   *
   * @param key The case id.
   */
  public void confirmCaseSupervisorExists(CaseKey key)
    throws AppException, InformationalException {

    // UserName structs
    UserNameAndFullName userNameAndFullName = new UserNameAndFullName();

    // CaseHeaderKey struct
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // CaseUserRole object
    curam.core.sl.intf.CaseUserRole caseUserRoleObj =
      curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // set the key
    caseHeaderKey.caseID = key.caseID;

    // read back the explicit supervisor
    userNameAndFullName = caseUserRoleObj.readSupervisor(caseHeaderKey);

    // Check if supervisor exists
    if (userNameAndFullName.userName.length() == 0) {

      // No supervisor explicitly set
      // Get the list of supervisors for the case owner
      UserNameKeyList userNameKeyList =
        caseUserRoleObj.listSupervisorsForCaseOwner(caseHeaderKey);

      // if the supervisor exists raise the event
      if (userNameKeyList.dtls.size() == 0) {

        Event event = new Event();

        event.eventKey = CASE.NO_SUPERVISOR_EXISTS;
        event.primaryEventData = key.caseID;

        curam.util.events.impl.EventService.raiseEvent(event);
      } 
    }
  }
}
// END, CR00091194

