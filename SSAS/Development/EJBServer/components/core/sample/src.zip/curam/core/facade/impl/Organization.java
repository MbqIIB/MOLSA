/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2014
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office
 */

/*
 * Copyright 2002-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import com.google.inject.Inject;

import curam.cefwidgets.docbuilder.impl.AnnouncementsBuilder;
import curam.codetable.APPLICATION_CODE;
import curam.codetable.CALENDAREVENTTYPE;
import curam.codetable.CALENDARTYPE;
import curam.codetable.CALENDARVIEWTYPE;
import curam.codetable.ELEMENTTYPE;
import curam.codetable.METHODOFDELIVERY;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.ORGSTRUCTURESTATUS;
import curam.codetable.ORGUNITSTATUSCODE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REDIRECTIONTARGETITEMTYPE;
import curam.codetable.SECURITYIDENTIFIERTYPE;
import curam.codetable.SKILLTYPE;
import curam.codetable.TEMPORAL_EVIDENCE_TYPE_APPROVAL;
import curam.codetable.impl.CASESTATUSEntry;
import curam.core.facade.struct.ActionIDProperty;
import curam.core.facade.struct.ActivateLocationStructureDetails;
import curam.core.facade.struct.ActivateOrgStructureKey;
import curam.core.facade.struct.AddExclusionDateKey;
import curam.core.facade.struct.AddOrgUnitResourceDetails;
import curam.core.facade.struct.AdminIntegratedCaseTypes;
import curam.core.facade.struct.AlternateLoginEnabled;
import curam.core.facade.struct.AnnouncementDtls;
import curam.core.facade.struct.AnnouncementDtlsList;
import curam.core.facade.struct.AnnouncementsXML;
import curam.core.facade.struct.ApplicationSearchDetails;
import curam.core.facade.struct.ApplicationSearchDetailsList;
import curam.core.facade.struct.AssignResourceDetails;
import curam.core.facade.struct.BankBranchSearchResolver;
import curam.core.facade.struct.CancelAdminIntegratedCaseKey_fo;
import curam.core.facade.struct.CancelBankAccountKey;
import curam.core.facade.struct.CancelBankBranchKey;
import curam.core.facade.struct.CancelBankKey;
import curam.core.facade.struct.CancelCurrencyExchangeKey;
import curam.core.facade.struct.CancelDailyScheduleDetails;
import curam.core.facade.struct.CancelExclusionDateKey_fo;
import curam.core.facade.struct.CancelInvestigationApprovalCheckKey;
import curam.core.facade.struct.CancelIssueResolutionApprovalCheckKey;
import curam.core.facade.struct.CancelJobKey;
import curam.core.facade.struct.CancelLocationHolidayKey;
import curam.core.facade.struct.CancelLocationKey;
import curam.core.facade.struct.CancelLocationStructureDetails;
import curam.core.facade.struct.CancelOrgStructureKey;
import curam.core.facade.struct.CancelOrgUnitCaseApprovalKey;
import curam.core.facade.struct.CancelOrgUnitEvidenceApprovalKey;
import curam.core.facade.struct.CancelOrgUnitKey;
import curam.core.facade.struct.CancelOrganizationWorkingPatternKey;
import curam.core.facade.struct.CancelPositionByWorkFlowKey;
import curam.core.facade.struct.CancelPositionSlotAvailabilityDetails;
import curam.core.facade.struct.CancelResourceKey;
import curam.core.facade.struct.CancelSlotDetails;
import curam.core.facade.struct.CancelUserCaseApprovalKey;
import curam.core.facade.struct.CancelUserEvidenceApprovalKey;
import curam.core.facade.struct.CancelUserKey;
import curam.core.facade.struct.CancelUserSkillDetails;
import curam.core.facade.struct.CancelUserWorkingPatternKey;
import curam.core.facade.struct.CaseApprovalCheckDetails;
import curam.core.facade.struct.CaseOwnerPageIdentifierResult;
import curam.core.facade.struct.ChildOrganisationUnitDetails;
import curam.core.facade.struct.CloneOrgStructureKey;
import curam.core.facade.struct.CloseOrganizationUserDetails;
import curam.core.facade.struct.CloseUserInd;
import curam.core.facade.struct.CreateAdminIntegratedCaseDetails;
import curam.core.facade.struct.CreateAdminIntegratedCaseDetails1;
import curam.core.facade.struct.CreateAndAssignUserForPosition;
import curam.core.facade.struct.CreateDailyScheduleReturnKey;
import curam.core.facade.struct.CreateLocationHolidayDetails;
import curam.core.facade.struct.CreateLocationStructureDetails;
import curam.core.facade.struct.CreateOrganizationWorkingPatternDetails;
import curam.core.facade.struct.CreatePositionDetails;
import curam.core.facade.struct.CreatePositionSlotAvailabilityReturnKey;
import curam.core.facade.struct.CreateSlotReturnKey;
import curam.core.facade.struct.CreateTemporalEvidenceApprovalCheck;
import curam.core.facade.struct.CreateUserDetails;
import curam.core.facade.struct.CreateUserWorkingPatternDetails;
import curam.core.facade.struct.DailyScheduleContextDescription;
import curam.core.facade.struct.DailyScheduleCreateDetails;
import curam.core.facade.struct.DailyScheduleDetails;
import curam.core.facade.struct.DailyScheduleKey;
import curam.core.facade.struct.DailyScheduleListKey;
import curam.core.facade.struct.DailyScheduleModifyDetails;
import curam.core.facade.struct.EvidenceApprovalCheckDetails;
import curam.core.facade.struct.ExclusionDateRange;
import curam.core.facade.struct.ICEvidenceTypeDetailsList;
import curam.core.facade.struct.IntegratedCaseDefaultValuesDetails;
import curam.core.facade.struct.InvestigationApprovalCheckDetails;
import curam.core.facade.struct.InvestigationConfigurationTypeDetailsList;
import curam.core.facade.struct.IssueConfigurationTypeDetailsList;
import curam.core.facade.struct.IssueResolutionApprovalCheckDetails;
import curam.core.facade.struct.JobContextDescriptionDetails;
import curam.core.facade.struct.JobDetails;
import curam.core.facade.struct.JobKey;
import curam.core.facade.struct.ListActiveAdminIntegratedCaseDetails;
import curam.core.facade.struct.ListActiveLocationDetails;
import curam.core.facade.struct.ListActiveResourcesDetails;
import curam.core.facade.struct.ListAllAdminIntegratedCaseDetails;
import curam.core.facade.struct.ListBankAccountDetails;
import curam.core.facade.struct.ListBankBranchDetails;
import curam.core.facade.struct.ListBankBranchKey;
import curam.core.facade.struct.ListBankDetails;
import curam.core.facade.struct.ListCaseByCurrentUserDetails;
import curam.core.facade.struct.ListChildLocationsDetails;
import curam.core.facade.struct.ListChildLocationsKey;
import curam.core.facade.struct.ListCurrencyExchangeDetails;
import curam.core.facade.struct.ListCurrencyExchangeHistoryDetails;
import curam.core.facade.struct.ListCurrencyExchangeHistoryKey_fo;
import curam.core.facade.struct.ListDailyScheduleDetails;
import curam.core.facade.struct.ListJobDetails;
import curam.core.facade.struct.ListJobForOrgUnitDetails;
import curam.core.facade.struct.ListJobForOrgUnitWithVersionNoDetails;
import curam.core.facade.struct.ListJobWithVersionNoDetails;
import curam.core.facade.struct.ListLocationForOrganisationUnit;
import curam.core.facade.struct.ListLocationHolidayDetails;
import curam.core.facade.struct.ListLocationHolidayKey;
import curam.core.facade.struct.ListLocationStructureDetails;
import curam.core.facade.struct.ListLocationWorkingPatternDetails;
import curam.core.facade.struct.ListOrgUnitCaseApprovalDetails;
import curam.core.facade.struct.ListOrgUnitCaseApprovalKey;
import curam.core.facade.struct.ListOrgUnitDetailsForUser;
import curam.core.facade.struct.ListOrgUnitEvidenceApprovalDetails;
import curam.core.facade.struct.ListOrgUnitEvidenceApprovalKey;
import curam.core.facade.struct.ListOrgUnitInvestigationApprovalCheckDetails;
import curam.core.facade.struct.ListOrgUnitInvestigationApprovalCheckKey;
import curam.core.facade.struct.ListOrgUnitResolutionApprovalCheckDetails;
import curam.core.facade.struct.ListOrgUnitResolutionApprovalCheckDetailsAndVersionNo;
import curam.core.facade.struct.ListOrgUnitResolutionApprovalCheckKey;
import curam.core.facade.struct.ListOrgUnitUserDetails;
import curam.core.facade.struct.ListOrganisationStructureDetails;
import curam.core.facade.struct.ListOrganisationStructureDetails1;
import curam.core.facade.struct.ListOrganisationUnitDetails;
import curam.core.facade.struct.ListOrganisationUnitForOrgStructureDetails;
import curam.core.facade.struct.ListOrganisationUnitForOrgStructureWithVersionNoDetails;
import curam.core.facade.struct.ListOrganisationUnitForOrgUnitDetails;
import curam.core.facade.struct.ListOrganisationUnitForOrgUnitWithVersionNoDetails;
import curam.core.facade.struct.ListOrganizationWorkingPatternDetails;
import curam.core.facade.struct.ListPositionDetailsForUser;
import curam.core.facade.struct.ListPositionForJobDetails;
import curam.core.facade.struct.ListPositionForOrgStructureDetails;
import curam.core.facade.struct.ListPositionForOrgUnitDetails;
import curam.core.facade.struct.ListPositionForPositionDetails;
import curam.core.facade.struct.ListPositionSearchDetails;
import curam.core.facade.struct.ListPositionSlotAvailabilityDetails;
import curam.core.facade.struct.ListResourcesForLocationDetails;
import curam.core.facade.struct.ListResourcesForLocationKey;
import curam.core.facade.struct.ListResourcesForOrgUnitDetails;
import curam.core.facade.struct.ListResourcesForOrgUnitKey;
import curam.core.facade.struct.ListResourcesInOperationDetails;
import curam.core.facade.struct.ListSlotDetails;
import curam.core.facade.struct.ListUserCaseApprovalDetails;
import curam.core.facade.struct.ListUserCaseApprovalKey;
import curam.core.facade.struct.ListUserEvidenceApprovalDetails;
import curam.core.facade.struct.ListUserEvidenceApprovalKey;
import curam.core.facade.struct.ListUserForOrgStructureDetails;
import curam.core.facade.struct.ListUserForOrgUnitDetails;
import curam.core.facade.struct.ListUserForOrganisationDetails;
import curam.core.facade.struct.ListUserForPositionDetails;
import curam.core.facade.struct.ListUserInvestigationApprovalCheckDetails;
import curam.core.facade.struct.ListUserInvestigationApprovalCheckKey;
import curam.core.facade.struct.ListUserResolutionApprovalCheckDetails;
import curam.core.facade.struct.ListUserResolutionApprovalCheckDetailsAndVersionNo;
import curam.core.facade.struct.ListUserResolutionApprovalCheckKey;
import curam.core.facade.struct.ListUserSkillDetails;
import curam.core.facade.struct.ListUserWorkingPatternDetails;
import curam.core.facade.struct.ListUserWorkingPatternKey;
import curam.core.facade.struct.LocStructureAndLocKey;
import curam.core.facade.struct.LocationAccessDetails;
import curam.core.facade.struct.LocationByNameAndTypeKey;
import curam.core.facade.struct.LocationContextDescriptionDetails;
import curam.core.facade.struct.LocationContextDescriptionKey;
import curam.core.facade.struct.LocationDetailsForPositionHomeList;
import curam.core.facade.struct.LocationSearchKey;
import curam.core.facade.struct.LocationSearchResolver;
import curam.core.facade.struct.MaintainBankAccountDetails_fo;
import curam.core.facade.struct.MaintainBankAccountWithTextSortCodeDetails;
import curam.core.facade.struct.MaintainBankBranchDetails;
import curam.core.facade.struct.MaintainBankDetails;
import curam.core.facade.struct.MaintainCurrencyExchangeDetails;
import curam.core.facade.struct.MaintainLocationDetails;
import curam.core.facade.struct.MaintainLocationHolidayDetails;
import curam.core.facade.struct.MaintainNonStandardWorkingPatternDetails;
import curam.core.facade.struct.MaintainResourceDetails;
import curam.core.facade.struct.ModifyAdminIntegratedCaseDetails;
import curam.core.facade.struct.ModifyAdminIntegratedCaseDetails1;
import curam.core.facade.struct.ModifyJobDetails;
import curam.core.facade.struct.ModifyLocationStructureDetails;
import curam.core.facade.struct.ModifyOrgUnitPrinterDetails;
import curam.core.facade.struct.ModifyOrganisationStructureDetails;
import curam.core.facade.struct.ModifyOrganisationUnitDetails;
import curam.core.facade.struct.ModifyOrganizationDetails1;
import curam.core.facade.struct.ModifyOrganizationWorkingPatternDetails;
import curam.core.facade.struct.ModifyPositionDetails;
import curam.core.facade.struct.ModifyTemporalEvidenceApprovalCheck;
import curam.core.facade.struct.ModifyUserDetails;
import curam.core.facade.struct.ModifyUserPrinterDetails;
import curam.core.facade.struct.ModifyUserWorkingPatternDetails;
import curam.core.facade.struct.OrgLocationSearchKey;
import curam.core.facade.struct.OrgStructureAndOrgUnitKey;
import curam.core.facade.struct.OrgStructureAndPositionKey;
import curam.core.facade.struct.OrgStructureBreadCrumbDetails;
import curam.core.facade.struct.OrgStructureBrowserKey;
import curam.core.facade.struct.OrgStructureChildElementDetails;
import curam.core.facade.struct.OrgUnitBreadCrumbDetails;
import curam.core.facade.struct.OrgUnitBrowserKey;
import curam.core.facade.struct.OrgUnitDetailsList;
import curam.core.facade.struct.OrgUnitLocationDetails;
import curam.core.facade.struct.OrganisationStructureContextDescriptionDetails;
import curam.core.facade.struct.OrganisationStructureDetails;
import curam.core.facade.struct.OrganisationStructureKey;
import curam.core.facade.struct.OrganisationUnitContactDetails;
import curam.core.facade.struct.OrganisationUnitContextDescriptionDetails;
import curam.core.facade.struct.OrganisationUnitDetails;
import curam.core.facade.struct.OrganisationUnitIDDetails;
import curam.core.facade.struct.OrganisationUnitKey;
import curam.core.facade.struct.OrganisationUnitSearchCriteria;
import curam.core.facade.struct.OrganisationUnitSearchInd;
import curam.core.facade.struct.OrganisationUnitSearchResults;
import curam.core.facade.struct.OrganizationContextDescriptionDetails;
import curam.core.facade.struct.OrganizationContextDescriptionKey;
import curam.core.facade.struct.OrganizationResourceContextDescriptionDetails;
import curam.core.facade.struct.OrganizationResourceContextDescriptionKey;
import curam.core.facade.struct.OrganizationUserContextDescriptionKey;
import curam.core.facade.struct.ParentLocationIDDetails;
import curam.core.facade.struct.PositionContextDescriptionDetails;
import curam.core.facade.struct.PositionKey;
import curam.core.facade.struct.PositionLocationDetails;
import curam.core.facade.struct.PositionNameAndOrgStructureIDKey;
import curam.core.facade.struct.PositionSearchCriteria;
import curam.core.facade.struct.PositionSearchResolver;
import curam.core.facade.struct.PositionSlotAvailabilityCreateDetails;
import curam.core.facade.struct.PositionSlotAvailabilityDetails;
import curam.core.facade.struct.PositionSlotAvailabilityListKey;
import curam.core.facade.struct.PositionSlotAvailabilityModifyDetails;
import curam.core.facade.struct.QuickLinkApplicationDetailsList;
import curam.core.facade.struct.QuickLinkApplicationLinkDtls;
import curam.core.facade.struct.QuickLinkApplicationLinkDtlsList;
import curam.core.facade.struct.QuickLinkDetails;
import curam.core.facade.struct.QuickLinkDetailsList;
import curam.core.facade.struct.ReadAdminIntegratedCaseDetails;
import curam.core.facade.struct.ReadAdminIntegratedCaseDetails1;
import curam.core.facade.struct.ReadAdminIntegratedCaseKey_fo;
import curam.core.facade.struct.ReadAllExclusionDateDetails;
import curam.core.facade.struct.ReadAllExclusionDateKey;
import curam.core.facade.struct.ReadAllLocationHolidayDetails_fo;
import curam.core.facade.struct.ReadAllLocationHolidayKey_fo;
import curam.core.facade.struct.ReadBankAccountDetails;
import curam.core.facade.struct.ReadBankAccountKey_fo;
import curam.core.facade.struct.ReadBankBranchKey;
import curam.core.facade.struct.ReadBankBranchNameBankNameDtlsList;
import curam.core.facade.struct.ReadBankBranchNameBankNameKey;
import curam.core.facade.struct.ReadBankKey;
import curam.core.facade.struct.ReadCurrencyExchangeKey;
import curam.core.facade.struct.ReadExclusionDateDetails;
import curam.core.facade.struct.ReadExclusionDateKey_fo;
import curam.core.facade.struct.ReadInvestigationApprovalCheckKey;
import curam.core.facade.struct.ReadIssueResolutionApprovalCheckKey;
import curam.core.facade.struct.ReadLocationDetails;
import curam.core.facade.struct.ReadLocationHolidayDetails;
import curam.core.facade.struct.ReadLocationHolidayKey;
import curam.core.facade.struct.ReadLocationKey;
import curam.core.facade.struct.ReadLocationListForLocationStructure;
import curam.core.facade.struct.ReadLocationStructureDetails;
import curam.core.facade.struct.ReadLocationWorkingPatternDetails;
import curam.core.facade.struct.ReadOrgUnitCaseApprovalDetails;
import curam.core.facade.struct.ReadOrgUnitCaseApprovalKey;
import curam.core.facade.struct.ReadOrgUnitEvidenceApprovalDetails;
import curam.core.facade.struct.ReadOrgUnitEvidenceApprovalKey;
import curam.core.facade.struct.ReadOrgUnitInvestigationApprovalCheckDetails;
import curam.core.facade.struct.ReadOrgUnitResolutionApprovalCheckDetails;
import curam.core.facade.struct.ReadOrganizationHomePageDetails1;
import curam.core.facade.struct.ReadOrganizationLocationList;
import curam.core.facade.struct.ReadOrganizationNonStandardWorkingPatternDetails;
import curam.core.facade.struct.ReadOrganizationNonStandardWorkingPatternKey;
import curam.core.facade.struct.ReadOrganizationPublicOfficeList;
import curam.core.facade.struct.ReadOrganizationUserHomePageDetails;
import curam.core.facade.struct.ReadOrganizationWorkingPatternDetails;
import curam.core.facade.struct.ReadOrganizationWorkingPatternKey;
import curam.core.facade.struct.ReadParentLocationKey;
import curam.core.facade.struct.ReadPositionSlotAvailabiliySlotID;
import curam.core.facade.struct.ReadPrintersForOrgUnitDetails;
import curam.core.facade.struct.ReadPrintersForOrgUnitKey;
import curam.core.facade.struct.ReadResourceDetails;
import curam.core.facade.struct.ReadResourceKey;
import curam.core.facade.struct.ReadResourceList;
import curam.core.facade.struct.ReadSecurityRoles;
import curam.core.facade.struct.ReadSecurityRolesList;
import curam.core.facade.struct.ReadUserCaseApprovalDetails;
import curam.core.facade.struct.ReadUserCaseApprovalKey;
import curam.core.facade.struct.ReadUserDetails_fo;
import curam.core.facade.struct.ReadUserEvidenceApprovalDetails;
import curam.core.facade.struct.ReadUserEvidenceApprovalKey;
import curam.core.facade.struct.ReadUserHomePageKey;
import curam.core.facade.struct.ReadUserInvestigationApprovalCheckDetails;
import curam.core.facade.struct.ReadUserKey;
import curam.core.facade.struct.ReadUserNonStandardWorkingPatternDetails;
import curam.core.facade.struct.ReadUserNonStandardWorkingPatternKey;
import curam.core.facade.struct.ReadUserResolutionApprovalCheckDetails;
import curam.core.facade.struct.ReadUserWorkingPatternDetails;
import curam.core.facade.struct.ReadUserWorkingPatternKey;
import curam.core.facade.struct.ReadXMLDetails;
import curam.core.facade.struct.RecentlyApprovedCaseDetailsList;
import curam.core.facade.struct.RecentlyApprovedInvestigationDetailsList;
import curam.core.facade.struct.RecentlyAssignedCaseDetailsList;
import curam.core.facade.struct.RecentlyAssignedInvestigationDetailsList;
import curam.core.facade.struct.RecentlyViewedCaseDetailsList;
import curam.core.facade.struct.RecentlyViewedInvestigationDetailsList;
import curam.core.facade.struct.RemoveCurrencyExchangeKey;
import curam.core.facade.struct.RemoveLocationAccessKey;
import curam.core.facade.struct.RemovePositionLocationDetails;
import curam.core.facade.struct.RemoveResourceFromOrgUnitDetails;
import curam.core.facade.struct.RemoveResourceKey;
import curam.core.facade.struct.RemoveUserFromPositionKey;
import curam.core.facade.struct.ReopenUserDetails;
import curam.core.facade.struct.ReportDetails;
import curam.core.facade.struct.ReportDetailsList;
import curam.core.facade.struct.ReportSecurityRoleDetailsList;
import curam.core.facade.struct.ReportSecurityRoleLinkDetails;
import curam.core.facade.struct.ReportUserDetailsList;
import curam.core.facade.struct.ReportUserLinkDetails;
import curam.core.facade.struct.ResourceLocationDetails;
import curam.core.facade.struct.ResourceOrganisationUnitDetail;
import curam.core.facade.struct.ResourceSearchKey;
import curam.core.facade.struct.RootOrganisationUnitDetails;
import curam.core.facade.struct.RuleSetNodeKey;
import curam.core.facade.struct.SearchBankBranchCriteria;
import curam.core.facade.struct.SearchUserDetails;
import curam.core.facade.struct.SecurityIDList;
import curam.core.facade.struct.SingleDayEventDetails;
import curam.core.facade.struct.SingleDayEventNode;
import curam.core.facade.struct.SlotContextDescription;
import curam.core.facade.struct.SlotCreateDetails;
import curam.core.facade.struct.SlotDetails;
import curam.core.facade.struct.SlotKey;
import curam.core.facade.struct.SlotListKey;
import curam.core.facade.struct.SlotModifyDetails;
import curam.core.facade.struct.TemporalEvidenceApprovalCheckDetails;
import curam.core.facade.struct.TemporalEvidenceApprovalCheckKey;
import curam.core.facade.struct.UserApplicationHome;
import curam.core.facade.struct.UserContextDescriptionDetails;
import curam.core.facade.struct.UserForPositionDetails;
import curam.core.facade.struct.UserLanguageSkillCreationDetails;
import curam.core.facade.struct.UserPasswordDetails;
import curam.core.facade.struct.UserRecentCaseList;
import curam.core.facade.struct.UserSearchDetails;
import curam.core.facade.struct.UserSearchDetailsResults;
import curam.core.facade.struct.UserSearchKey;
import curam.core.facade.struct.UserSkillContextDescription;
import curam.core.facade.struct.UserSkillCreateDetails;
import curam.core.facade.struct.UserSkillDetails;
import curam.core.facade.struct.UserSkillKey;
import curam.core.facade.struct.UserSkillLanguageDetails;
import curam.core.facade.struct.UserSkillListKey;
import curam.core.facade.struct.UserSkillModifyDetails;
import curam.core.facade.struct.UserSkills;
import curam.core.facade.struct.UserStatusDetails_fo;
import curam.core.facade.struct.UserSummaryDetails;
import curam.core.facade.struct.UserSummaryDetails1;
import curam.core.facade.struct.UserSummaryDetailsKey;
import curam.core.facade.struct.ViewJobDetails;
import curam.core.facade.struct.ViewOrganisationStructureDetails;
import curam.core.facade.struct.ViewOrganisationStructureDetails1;
import curam.core.facade.struct.ViewOrganisationUnitDetails;
import curam.core.facade.struct.ViewPositionDetails;
import curam.core.facade.struct.ViewTemporalEvidenceApprovalCheck;
import curam.core.facade.struct.WorkingPatternContextDescriptionDetails;
import curam.core.facade.struct.WorkingPatternContextDescriptionKey;
import curam.core.facade.struct.WorkingPatternDetailsList;
import curam.core.facade.struct.WorkingPatternTypeDetails;
import curam.core.facade.struct.listPrintersDetails;
import curam.core.fact.AdminBankBranchFactory;
import curam.core.fact.AdminBankFactory;
import curam.core.fact.AdminLocationFactory;
import curam.core.fact.AdminOrganisationFactory;
import curam.core.fact.AdminResourcesFactory;
import curam.core.fact.AdminUserFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.DataBaseLocationSearchFactory;
import curam.core.fact.DatabaseBankbranchSearchFactory;
import curam.core.fact.FinancialCalendarFactory;
import curam.core.fact.LocationAdminSecurityFactory;
import curam.core.fact.LocationFactory;
import curam.core.fact.LocationHolidayFactory;
import curam.core.fact.LocationHolidayLinkFactory;
import curam.core.fact.MaintainAdminIntegratedCaseFactory;
import curam.core.fact.MaintainCashPmtCalendarFactory;
import curam.core.fact.MaintainChequePmtCalendarFactory;
import curam.core.fact.MaintainEFTPmtCalendarFactory;
import curam.core.fact.MaintainExclusionDateFactory;
import curam.core.fact.MaintainInvoiceCalendarFactory;
import curam.core.fact.MaintainLocationHolidayFactory;
import curam.core.fact.MaintainVoucherPmtCalendarFactory;
import curam.core.fact.MaintainWorkingPatternFactory;
import curam.core.fact.OrganisationAdminSecurityFactory;
import curam.core.fact.ResourcesFactory;
import curam.core.fact.SecurityLinkFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UserLinkFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.OrganisationAdminSecurity;
import curam.core.intf.AdminLocation;
import curam.core.intf.AdminOrganisation;
import curam.core.intf.AdminUser;
import curam.core.intf.LocationAdminSecurity;
import curam.core.intf.MaintainWorkingPattern;
import curam.core.intf.SystemUser;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.ExternalUserFactory;
import curam.core.sl.entity.fact.JobFactory;
import curam.core.sl.entity.fact.OrganisationStructureFactory;
import curam.core.sl.entity.intf.ExternalUser;
import curam.core.sl.entity.intf.OrganisationStructure;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.struct.AnnouncementDetails;
import curam.core.sl.entity.struct.AnnouncementDetailsList;
import curam.core.sl.entity.struct.AnnouncementKey;
import curam.core.sl.entity.struct.ApplicationCodeKey;
import curam.core.sl.entity.struct.CaseIDStructList;
import curam.core.sl.entity.struct.CatStatusRefUserType;
import curam.core.sl.entity.struct.ExternalUserKey;
import curam.core.sl.entity.struct.JobName;
import curam.core.sl.entity.struct.ListOrgUnitDetails;
import curam.core.sl.entity.struct.ListOrganisationStructureKey;
import curam.core.sl.entity.struct.OrgStructAndOrgUnitID;
import curam.core.sl.entity.struct.OrgUnitIDAndOrgStructIDKey;
import curam.core.sl.entity.struct.OrgUnitUserNameAndStatusKey;
import curam.core.sl.entity.struct.OrganisationAdminSecurityIdentifierDetails;
import curam.core.sl.entity.struct.OrganisationStructureID;
import curam.core.sl.entity.struct.OrganisationStructureIDList;
import curam.core.sl.entity.struct.OrganisationStructureName;
import curam.core.sl.entity.struct.OrganisationStructureStatus;
import curam.core.sl.entity.struct.OrganisationUnitAndParentNameDetails;
import curam.core.sl.entity.struct.OrganisationUnitDtls;
import curam.core.sl.entity.struct.OrganisationUnitIDAndNameDetails;
import curam.core.sl.entity.struct.OrganisationUnitIDAndNameDetailsList;
import curam.core.sl.entity.struct.OrganisationUnitIDDtls;
import curam.core.sl.entity.struct.OrganisationUnitLocationDetailsList;
import curam.core.sl.entity.struct.OrganisationUnitName;
import curam.core.sl.entity.struct.OrganisationUnitStatus;
import curam.core.sl.entity.struct.PositionAndOrgUnitIDDetails;
import curam.core.sl.entity.struct.PositionIDAndOrgStructIDKey;
import curam.core.sl.entity.struct.PositionName;
import curam.core.sl.entity.struct.QuickLinkApplicationLinkKey;
import curam.core.sl.entity.struct.QuickLinkKey;
import curam.core.sl.entity.struct.RecordStatusAndDateTime;
import curam.core.sl.entity.struct.ReportKey;
import curam.core.sl.entity.struct.ReportSecurityRoleLinkKey;
import curam.core.sl.entity.struct.ReportUserLinkKey;
import curam.core.sl.entity.struct.RoleNameKey;
import curam.core.sl.entity.struct.SearchByOrgUnitKey;
import curam.core.sl.entity.struct.SearchByUserKey;
import curam.core.sl.entity.struct.SupervisorOrgUnitDetails;
import curam.core.sl.entity.struct.SupervisorOrgUnitDetailsList;
import curam.core.sl.entity.struct.UserKey;
import curam.core.sl.entity.struct.UserNameAndDateTimeKey;
import curam.core.sl.entity.struct.UserSkillDtls;
import curam.core.sl.entity.struct.UserSkillLanguagesDtls;
import curam.core.sl.entity.struct.UserSkillLanguagesDtlsList;
import curam.core.sl.entity.struct.ViewPositionUserOrgUnitDetails;
import curam.core.sl.fact.AnnouncementFactory;
import curam.core.sl.fact.ApplicationSearchFactory;
import curam.core.sl.fact.CaseApprovalCheckFactory;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.fact.DailyScheduleFactory;
import curam.core.sl.fact.DatabaseOrganisationUnitSearchFactory;
import curam.core.sl.fact.DatabasePositionSearchFactory;
import curam.core.sl.fact.EvidenceApprovalCheckFactory;
import curam.core.sl.fact.InvestigationApprovalCheckFactory;
import curam.core.sl.fact.IssueResolutionApprovalCheckFactory;
import curam.core.sl.fact.LocationStructureFactory;
import curam.core.sl.fact.LocationStructureTreeFactory;
import curam.core.sl.fact.OrgObjectLinkFactory;
import curam.core.sl.fact.OrganisationStructureTreeFactory;
import curam.core.sl.fact.OrganisationUnitFactory;
import curam.core.sl.fact.OrganisationUnitResourceFactory;
import curam.core.sl.fact.PositionFactory;
import curam.core.sl.fact.PositionHolderLinkFactory;
import curam.core.sl.fact.PositionLocationLinkFactory;
import curam.core.sl.fact.PositionSlotAvailabilityFactory;
import curam.core.sl.fact.QuickLinkApplicationLinkFactory;
import curam.core.sl.fact.QuickLinkFactory;
import curam.core.sl.fact.ReportFactory;
import curam.core.sl.fact.ReportSecurityRoleLinkFactory;
import curam.core.sl.fact.ReportUserLinkFactory;
import curam.core.sl.fact.SlotFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.fact.UserRecentActionFactory;
import curam.core.sl.fact.UserSkillFactory;
import curam.core.sl.fact.UserSkillLanguagesFactory;
import curam.core.sl.impl.LocationTreeXMLCacheNode;
import curam.core.sl.impl.LocationTreeXMLNodeDetail;
import curam.core.sl.impl.OrganisationTreeXMLCacheNode;
import curam.core.sl.impl.OrganisationTreeXMLNodeDetail;
import curam.core.sl.infrastructure.entity.struct.EvidenceType;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeList;
import curam.core.sl.infrastructure.entity.struct.SearchByPositionKey;
import curam.core.sl.infrastructure.fact.TemporalEvidenceApprovalCheckFactory;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.UtilCuramConst;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.struct.CancelTemporalEvidenceApprovalCheck;
import curam.core.sl.infrastructure.struct.EvidenceTypeAdminDetailsList;
import curam.core.sl.infrastructure.struct.TemporalEvidenceApprovalCheckList;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.intf.UserSkill;
import curam.core.sl.intf.UserSkillLanguages;
import curam.core.sl.struct.ApplicationCodeDetailsList;
import curam.core.sl.struct.ApplicationSearchKey;
import curam.core.sl.struct.ClearTaskRedirectionDetails;
import curam.core.sl.struct.ListJobsKey;
import curam.core.sl.struct.ListOrganisationUnitsKey;
import curam.core.sl.struct.ListPositionsByJobKey;
import curam.core.sl.struct.ListPositionsKey;
import curam.core.sl.struct.ListUserSkillKey;
import curam.core.sl.struct.ListUserSkillTypeStatusKey;
import curam.core.sl.struct.OrgObjectReferenceOrgObjectType;
import curam.core.sl.struct.OrgStructureOrgUnitPositionKey;
import curam.core.sl.struct.OrgUnitSearchCriteria;
import curam.core.sl.struct.OrganisationUnitAndActiveStatusIndKey;
import curam.core.sl.struct.OrganisationUnitDetailsAndUserList;
import curam.core.sl.struct.PositionDetailsAndUserList;
import curam.core.sl.struct.PositionIDKey;
import curam.core.sl.struct.ReadUserSkillDetails;
import curam.core.sl.struct.ReadUserSkillKey;
import curam.core.sl.struct.RecordCount;
import curam.core.sl.struct.RedetermineTranslatorStruct;
import curam.core.sl.struct.SearchAllUserCheckKey;
import curam.core.sl.struct.TaskRedirectionsForUserDetails;
import curam.core.sl.struct.UserNameAndFullName;
import curam.core.sl.struct.UserSkillLanguageReadMultiKey;
import curam.core.sl.struct.UserType;
import curam.core.sl.supervisor.fact.UserWorkspaceFactory;
import curam.core.sl.supervisor.struct.ActiveAndPendingTaskRedirectionFromUserDetailsList;
import curam.core.sl.supervisor.struct.AllTaskAllocationBlockingPeriodsForUserDetails;
import curam.core.sl.supervisor.struct.ExpiredTaskRedirectionFromUserDetailsList;
import curam.core.sl.supervisor.struct.RedirectTaskDetails;
import curam.core.sl.supervisor.struct.TaskAllocationBlockingDetails;
import curam.core.sl.supervisor.struct.TaskRedirectionsFromUserDetails;
import curam.core.struct.AccountStatusDetails;
import curam.core.struct.AdminIntegratedCaseKey;
import curam.core.struct.BankBranchKeyStruct;
import curam.core.struct.BankKeyStruct;
import curam.core.struct.CancelAdminIntegratedCaseKey;
import curam.core.struct.ExclusionDateDeliveryMethod;
import curam.core.struct.ExclusionDatesSummary;
import curam.core.struct.ExclusionDtls;
import curam.core.struct.FinancialCalendarDtls;
import curam.core.struct.FinancialCalendarKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.ListUsersKey_bo;
import curam.core.struct.LocationDetails;
import curam.core.struct.LocationDtls;
import curam.core.struct.LocationHolidayDtls;
import curam.core.struct.LocationHolidayIDKey;
import curam.core.struct.LocationHolidayKey;
import curam.core.struct.LocationHolidaySearchDetails;
import curam.core.struct.LocationHolidaySearchDetailsList;
import curam.core.struct.LocationIDDetails;
import curam.core.struct.LocationIDDetailsList;
import curam.core.struct.LocationKey;
import curam.core.struct.LocationKeyRef;
import curam.core.struct.LocationKeyStruct;
import curam.core.struct.LocationStructureKey;
import curam.core.struct.MaintainAdminIntegratedCaseDetails1;
import curam.core.struct.MaintainAdminIntegratedCaseKey;
import curam.core.struct.MaintainLocationHolidayKey;
import curam.core.struct.MaintainWorkingPatternKey;
import curam.core.struct.NSPatternByDayIndexKey;
import curam.core.struct.OrgBankAccountDetails;
import curam.core.struct.OrgBankAccountKeyStruct;
import curam.core.struct.OrgBankAccountListDetails;
import curam.core.struct.OrgCurrExchByDateKeyStruct;
import curam.core.struct.OrgCurrencyExchangeSearchKey;
import curam.core.struct.OrgCurrencyHistoryKeyStruct;
import curam.core.struct.OrganisationAdminAuthorisationKey;
import curam.core.struct.OrganisationAdminSecurityResult;
import curam.core.struct.OrganisationDetails;
import curam.core.struct.OrganisationKey;
import curam.core.struct.OrganisationKeyStruct;
import curam.core.struct.OrganisationKeyStructRef;
import curam.core.struct.ReadWorkingPatternResult;
import curam.core.struct.ResourcesDtls;
import curam.core.struct.ResourcesKey;
import curam.core.struct.ResourcesKeyStruct;
import curam.core.struct.SIDTypeKey;
import curam.core.struct.SearchAllUserByPositionKey;
import curam.core.struct.SearchHolidayByLocationKey;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UpdatedLocationHolidayIDDetails;
import curam.core.struct.UserDetails;
import curam.core.struct.UserFullname;
import curam.core.struct.UserKeyStruct;
import curam.core.struct.UserNameIDDetails;
import curam.core.struct.UserNameKey;
import curam.core.struct.UserNamePositionIDOrgStructIDKey;
import curam.core.struct.UserNameTypeAndStatusCode;
import curam.core.struct.UserPasswordDtls;
import curam.core.struct.UserRedirectionDetails;
import curam.core.struct.UserRoleAndContactDetails;
import curam.core.struct.UserSummaryPositionKey;
import curam.core.struct.UserSupervisorAndLeadPositionInd;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.core.struct.WorkingPatternDetails;
import curam.core.struct.WorkingPatternKey;
import curam.core.struct.WorkingPatternOwnerKey;
import curam.evidence.impl.EvidenceTypeFactory;
import curam.message.BPOBANKBRANCH;
import curam.message.BPOLOCATION;
import curam.message.BPOLOCATIONSECURITY;
import curam.message.BPOORGANISATIONSTRUCTURE;
import curam.message.BPOORGANISATIONUNIT;
import curam.message.BPOORGANIZATION;
import curam.message.BPOPOSITION;
import curam.message.BPOREDETERMINETRANSLATOR;
import curam.message.BPOTASKREDIRECTION;
import curam.message.GENERALSEARCH;
import curam.util.administration.fact.CacheAdminFactory;
import curam.util.administration.struct.ExtendedUsersInfoDetails;
import curam.util.administration.struct.ExtendedUsersInfoLoginID;
import curam.util.administration.struct.ExtendedUsersInfoUserName;
import curam.util.administration.struct.SecurityRoleDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.EnvironmentConstants;
import curam.util.resources.Locale;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringList;
import curam.workspaceservices.facade.struct.LocalizableTextDetails;
import curam.workspaceservices.facade.struct.TextTranslationDetails;
import curam.workspaceservices.facade.struct.ViewLocalizableTextDetails;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.impl.TextTranslation;
import curam.workspaceservices.localization.impl.TextTranslationDAO;


/**
 * This process class provides the functionality for the Organization facade
 * methods.
 */
public abstract class Organization extends curam.core.facade.base.Organization {

  // BEGIN, CR00226138, GP
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;

  @Inject
  protected TextTranslationDAO textTranslationDAO;

  // END, CR00226138

  // BEGIN, CR00207573, PB
  // BEGIN, CR00341851, MV
  /**
   * Create User Skill Language Details.
   *
   * @param key
   * User Language Skill Creation Details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.5.0, replaced with
   * {@link #createUserSkillsLanguages(UserLanguageSkillCreationDetails)}
   * This method is deprecated because of the new requirement where
   * informational has to be return when the redetermination of
   * translator required runs on batch. See release note:
   * CR00341851.
   */
  // END, CR00341851
  public void createUserSkillLanguages(
    final UserLanguageSkillCreationDetails key) throws AppException,
      InformationalException {

    UserSkill userSkillObj = UserSkillFactory.newInstance();
    curam.core.sl.struct.UserSkillDetails userSkillDetails = new curam.core.sl.struct.UserSkillDetails();
    ListUserSkillTypeStatusKey listUserSkillTypeStatuskey = new ListUserSkillTypeStatusKey();
    UserSkillLanguages userSkillLanguagesObj = UserSkillLanguagesFactory.newInstance();

    curam.core.sl.entity.intf.UserSkillLanguages userSkillLanguagesObj1 = curam.core.sl.entity.fact.UserSkillLanguagesFactory.newInstance();
    ReadUserSkillKey readUserSkillKey = new ReadUserSkillKey();

    readUserSkillKey.userSkillID = userSkillDetails.details.userSkillID;
    listUserSkillTypeStatuskey.userName = key._userSkillLanguageSkillCreationDetails.userName;
    listUserSkillTypeStatuskey.skillType = curam.codetable.SKILLTYPE.LANGUAGES;
    listUserSkillTypeStatuskey.recordStatus = RECORDSTATUS.NORMAL;
    userSkillDetails = userSkillObj.listByUserSkillStatus(
      listUserSkillTypeStatuskey);

    key._userSkillLanguageSkillCreationDetails.dtls.userSkillID = userSkillDetails.details.userSkillID;

    UserSkillLanguageDetails userSkillLanguageDetails = new UserSkillLanguageDetails();
    UserSkillKey userSkillKey = new UserSkillKey();

    userSkillKey.userSkillKey.userSkillID = userSkillDetails.details.userSkillID;
    readUserSkillKey.userSkillID = userSkillDetails.details.userSkillID;
    userSkillLanguageDetails = viewUserLanguagesSkill(userSkillKey);

    if (userSkillLanguageDetails.dtlsList.dtls.size() > 0) {
      userSkillLanguagesObj1.removeLanguageDetails(readUserSkillKey);
    }

    curam.core.sl.entity.struct.UserSkillLanguagesDtls userSkillLanguagesDtls;
    StringList languageCodeList = StringUtil.tabText2StringListWithTrim(
      key.languageCodeList);

    for (String languageCode : languageCodeList.items()) {
      userSkillLanguagesDtls = new curam.core.sl.entity.struct.UserSkillLanguagesDtls();
      userSkillLanguagesDtls.languageCode = languageCode;
      key._userSkillLanguageSkillCreationDetails.dtls.languageCode = userSkillLanguagesDtls.languageCode;
      userSkillLanguagesObj.create(key._userSkillLanguageSkillCreationDetails);
    }

    // BEGIN, CR00214140, PB
    RedetermineTranslatorStruct redetermineTranslatorStruct = new RedetermineTranslatorStruct();
    CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();

    redetermineTranslatorStruct.userName = key._userSkillLanguageSkillCreationDetails.userName;
    caseParticipantRoleObj.redetermineTranslator(redetermineTranslatorStruct);
    // END, CR00214140

  }
  
  // BEGIN, CR00341851, MV
  /**
   * Create User Skill Language Details.
   *
   * @param key
   * User Language Skill Creation Details.
   *
   * @return InformationalMsgDtlsList List of informational messages
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList createUserSkillsLanguages(
    final UserLanguageSkillCreationDetails key) throws AppException,
      InformationalException {

    final ListUserSkillTypeStatusKey listUserSkillTypeStatuskey = new ListUserSkillTypeStatusKey();
    final ReadUserSkillKey readUserSkillKey = new ReadUserSkillKey();

    listUserSkillTypeStatuskey.userName = key._userSkillLanguageSkillCreationDetails.userName;
    listUserSkillTypeStatuskey.skillType = curam.codetable.SKILLTYPE.LANGUAGES;
    listUserSkillTypeStatuskey.recordStatus = RECORDSTATUS.NORMAL;
    final curam.core.sl.struct.UserSkillDetails userSkillDetails = UserSkillFactory.newInstance().listByUserSkillStatus(
      listUserSkillTypeStatuskey);

    key._userSkillLanguageSkillCreationDetails.dtls.userSkillID = userSkillDetails.details.userSkillID;
    UserSkillKey userSkillKey = new UserSkillKey();

    userSkillKey.userSkillKey.userSkillID = userSkillDetails.details.userSkillID;
    readUserSkillKey.userSkillID = userSkillDetails.details.userSkillID;
    final UserSkillLanguageDetails userSkillLanguageDetails = viewUserLanguagesSkill(
      userSkillKey);

    if (userSkillLanguageDetails.dtlsList.dtls.size() > 0) {
      curam.core.sl.entity.fact.UserSkillLanguagesFactory.newInstance().removeLanguageDetails(
        readUserSkillKey);
    }

    UserSkillLanguagesDtls userSkillLanguagesDtls;
    final StringList languageCodeList = StringUtil.tabText2StringListWithTrim(
      key.languageCodeList);

    for (String languageCode : languageCodeList.items()) {
      userSkillLanguagesDtls = new curam.core.sl.entity.struct.UserSkillLanguagesDtls();
      userSkillLanguagesDtls.languageCode = languageCode;
      key._userSkillLanguageSkillCreationDetails.dtls.languageCode = userSkillLanguagesDtls.languageCode;
      UserSkillLanguagesFactory.newInstance().create(
        key._userSkillLanguageSkillCreationDetails);
    }

    final int kMaxNoCases;
    final String envMaxNoCases = Configuration.getProperty(
      EnvVars.ENV_CASES_MAXNOCASES_ONLINEAUTOTRANSLATORDETERMINATION);
    
    if (envMaxNoCases == null) {

      kMaxNoCases = EnvVars.ENV_CASES_MAXNOCASES_ONLINEAUTOTRANSLATORDETERMINATION_DEFAULT;
    } else {
      kMaxNoCases = Integer.parseInt(envMaxNoCases);
    }
    
    final UserNameTypeAndStatusCode userNameTypeAndStatusCode = new UserNameTypeAndStatusCode();

    userNameTypeAndStatusCode.userName = key._userSkillLanguageSkillCreationDetails.userName;
    userNameTypeAndStatusCode.statusCode = CASESTATUSEntry.CLOSED.getCode();
    CaseIDStructList caseIDStructList = CaseHeaderFactory.newInstance().searchCaseIDByUserNameAndCaseStatus(
      userNameTypeAndStatusCode);
    
    // The number of cases owned by a particular case owner is less than or equal to that the environmental variable
    // then the execution will happen in on-line mode
    if (kMaxNoCases >= caseIDStructList.dtls.size()) {
      RedetermineTranslatorStruct redetermineTranslatorStruct = new RedetermineTranslatorStruct();
      CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();

      redetermineTranslatorStruct.userName = key._userSkillLanguageSkillCreationDetails.userName;
      caseParticipantRoleObj.redetermineTranslator(redetermineTranslatorStruct);
    } else {
      
      LocalisableString infoMessage = new LocalisableString(
        BPOREDETERMINETRANSLATOR.INF_PDPI_XFV_BATCHPROCESS_SHOULDBE_EXECUTED);

      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        ValidationManagerConst.kSetOne, 1);
    }
    final String[] warnings = TransactionInfo.getInformationalManager().obtainInformationalAsString();
    final InformationalMsgDtlsList informationMsgDtlsList = new InformationalMsgDtlsList();

    for (final String informationMsgTxt : warnings) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = informationMsgTxt;
      informationMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
    return informationMsgDtlsList;
  }

  // END, CR00341851


  /**
   * Reads user Skill language details
   *
   * @param key
   * User skill id.
   * @return User Skill language details
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public UserSkillLanguageDetails viewUserLanguagesSkill(UserSkillKey key)
    throws AppException, InformationalException {
    // Return variable for organization structure details
    UserSkillDetails userSkillDetails = new UserSkillDetails();

    // Read organization structure details
    userSkillDetails.userSkillDetails = UserSkillFactory.newInstance().read(
      key.userSkillKey);
    curam.core.sl.entity.intf.UserSkillLanguages userSkillLanguagesObj = curam.core.sl.entity.fact.UserSkillLanguagesFactory.newInstance();
    UserSkillLanguageDetails userSkillLanguageDetails = new UserSkillLanguageDetails();
    UserSkillLanguageReadMultiKey userSkillLanguageReadMultiKey = new UserSkillLanguageReadMultiKey();
    UserSkillLanguagesDtlsList userSkillLanguagesDtlsList = new UserSkillLanguagesDtlsList();

    // BEGIN, CR00282330, PB
    if (userSkillDetails.userSkillDetails.details.skillType.equals(
      SKILLTYPE.LANGUAGES)
        && RECORDSTATUS.NORMAL.equals(
          userSkillDetails.userSkillDetails.details.recordStatus)) {
      // END, CR00282330
      userSkillLanguageReadMultiKey.userSkillID = key.userSkillKey.userSkillID;
      // Insert the daily schedule details record
      userSkillLanguagesDtlsList = userSkillLanguagesObj.searchByUserSkillID(
        userSkillLanguageReadMultiKey);
      userSkillLanguageDetails.dtlsList.assign(userSkillLanguagesDtlsList);
      userSkillLanguageDetails.languageListIndicator = true;
    }
    userSkillLanguageDetails.userSkillDetails.assign(userSkillDetails);
    return userSkillLanguageDetails;
  }

  // END, CR00207573
  // BEGIN, CR00199849, SS
  /**
   * Default constructor.
   */
  public Organization() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00199849
  // BEGIN, CR00023323, SK
  /**
   * Used to create Dynamic Menu node.
   */
  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  /**
   * Used to create xml child Link node.
   */
  protected static final String kItem = XmlMetaDataConst.kItem;

  /**
   * Used to set as attribute name for description.
   */
  protected static final String kDesc = XmlMetaDataConst.kDesc;

  /**
   * Used to set as attribute name for link page.
   */
  protected static final String kPageID = XmlMetaDataConst.kPageID;

  /**
   * Used to set as attribute value for Element ID parameter.
   */
  protected static final String kParamElementID = XmlMetaDataConst.kParamElementID;

  /**
   * Used to set as attribute value for Element type parameter.
   */
  protected static final String kParamElementType = XmlMetaDataConst.kParamElementType;

  /**
   * Used to set as attribute value for link page.
   */
  protected static final String kOrgUnitBrowser = XmlMetaDataConst.kOrgUnitBrowser;

  /**
   * Used to create a parameter.
   */
  protected static final String kParam = XmlMetaDataConst.kParam;

  /**
   * Used to set as attribute name for parameters name.
   */
  protected static final String kName = XmlMetaDataConst.kName;

  /**
   * Used to set as attribute name for parameters value.
   */
  protected static final String kValue = XmlMetaDataConst.kValue;

  // BEGIN HARP 31951, CC
  /**
   * Used to set as attribute value for list of Organization unit.
   */
  protected static final String kListOrgUnit = XmlMetaDataConst.kListOrgUnit;

  /**
   * Used to set as attribute value for Organization Unit ID for Organization
   * unit.
   */
  protected static final String kParamOrgUnitID = XmlMetaDataConst.kParamOrgUnitID;

  /**
   * Used to set as attribute value for Organization Structure ID for
   * Organization unit.
   */
  protected static final String kParamOrgStructureID = XmlMetaDataConst.kParamOrgStructureID;

  /**
   * Used for time format.
   */
  protected static final String kTimeFormat = UtilCuramConst.kTimeFormat;

  /**
   * Used to set Date Format.
   */
  protected static final String kDateFormat = Locale.defaultDateFormat;

  /**
   * Used to set organization ID to zero.
   */
  protected static final int kZeroOrganizationUnitID = 0;

  // END, CR00023323

  // BEGIN, CR00066677, CM
  
  /**
   * Returns the home page name for the Case Owner. The Case Owners are either a
   * User, a Position, an Org Unit or a Work Queue.
   *
   * @param key
   * The OrgObjectType
   * @return caseOwnerPageIdentifierResult The CaseOwnerPageIdentifierResult
   */
  public CaseOwnerPageIdentifierResult resolveCaseOwnerHome(
    OrgObjectReferenceOrgObjectType key) throws AppException,
      InformationalException {

    // Create return object
    CaseOwnerPageIdentifierResult caseOwnerPageIdentifierResult = new CaseOwnerPageIdentifierResult();

    // organization structure object
    OrganisationStructure organisationStructureObj = OrganisationStructureFactory.newInstance();
    OrganisationStructureID organisationStructureID = new OrganisationStructureID();

    // struct which holds the statusCode
    ListOrganisationStructureKey listOrganisationStructureKey = new ListOrganisationStructureKey();

    // Position entity object
    curam.core.sl.entity.intf.Position positionObj = curam.core.sl.entity.fact.PositionFactory.newInstance();
    curam.core.sl.entity.struct.PositionKey positionKey = new curam.core.sl.entity.struct.PositionKey();

    // OrganisationUnitIDDtls struct
    OrganisationUnitIDDtls organisationUnitID = new OrganisationUnitIDDtls();

    // If orgObjectType is a User
    if (key.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

      // Set pageIdentifierResult to go to the User Home page
      // BEGIN, CR00143146, ZV
      caseOwnerPageIdentifierResult.pageIdentifier = CuramConst.gkViewUserPage;
      // END, CR00143146
    } // If orgObjectType is an Org Unit
    else if (key.orgObjectType.equals(ORGOBJECTTYPE.ORGUNIT)) {

      // Set the statusCode to active
      listOrganisationStructureKey.statusCode = ORGSTRUCTURESTATUS.ACTIVE;

      // search active organization structure record by status code
      OrganisationStructureIDList organisationStructureIDList = organisationStructureObj.searchIDByStatusCode(
        listOrganisationStructureKey);

      // The will always only ever be one active organization structure.
      organisationStructureID.organisationStructureID = organisationStructureIDList.dtls.item(0).organisationStructureID;

      // Set organisationStructureID that needs to be a parameter
      // for the Org Unit home page
      caseOwnerPageIdentifierResult.organisationStructureID = organisationStructureID.organisationStructureID;

      // Set pageIdentifierResult to go to the Org Unit Home page
      // BEGIN, CR00143146, ZV
      caseOwnerPageIdentifierResult.pageIdentifier = CuramConst.gkViewOrgUnitPage;
      // END, CR00143146

    } // If orgObjectType is a Position
    else if (key.orgObjectType.equals(ORGOBJECTTYPE.POSITION)) {

      // Set the statusCode to active
      listOrganisationStructureKey.statusCode = ORGSTRUCTURESTATUS.ACTIVE;

      // search active organization structure record by status code
      OrganisationStructureIDList organisationStructureIDList = organisationStructureObj.searchIDByStatusCode(
        listOrganisationStructureKey);

      // The will always only ever be one active organization structure.
      organisationStructureID.organisationStructureID = organisationStructureIDList.dtls.item(0).organisationStructureID;

      // Set organisationStructureID that needs to be a parameter
      // for the Position home page
      caseOwnerPageIdentifierResult.organisationStructureID = organisationStructureID.organisationStructureID;

      // Set pageIdentifierResult to go to the Position Home page
      // BEGIN, CR00143146, ZV
      caseOwnerPageIdentifierResult.pageIdentifier = CuramConst.gkViewPositionPage;
      // END, CR00143146

      // set position key
      positionKey.positionID = key.orgObjectReference;

      // read the organisationUnitID
      organisationUnitID = positionObj.readOrganisationUnitID(positionKey);

      // Set organisationUnitID for the pageIdentifierResult
      caseOwnerPageIdentifierResult.organisationUnitID = organisationUnitID.organisationUnitID;

    } // If orgObjectType is a Work Queue
    else if (key.orgObjectType.equals(ORGOBJECTTYPE.WORKQUEUE)) {

      // Set pageIdentifierResult to go to the Work Queue Home page
      // BEGIN, CR00143146, ZV
      caseOwnerPageIdentifierResult.pageIdentifier = CuramConst.gkViewWorkQueuePage;
      // END, CR00143146

    } // BEGIN, CR00079264, CM
    // If orgObjectType is empty, there is no owner but it is a supervisor
    else {

      // Set pageIdentifierResult to go to the User Home page
      caseOwnerPageIdentifierResult.pageIdentifier = CuramConst.gkUserHomePage;
    }
    // END, CR00079264

    return caseOwnerPageIdentifierResult;
  }

  // END, CR00066677

  // BEGIN, CR00170283, DJ
  // BEGIN, CR00247294, PM
  /**
   * Presentation layer operation to search for a user within the organization.
   *
   * @param key
   * user to be read
   *
   * @return details of the user
   *
   * @deprecated Since Curam 5.2 SP4, replaced with
   * {@link #userDetailsSearch(UserSearchKey)} This method is
   * deprecated because it was not allowing to do a search based on
   * the start date of a position.The userDetailsSearch method
   * considers the start date of a position also when doing a user
   * search for the active positions.See release note: CR00215472.
   */
  // END, CR00247294
  @Deprecated
  public UserSearchDetails userSearch(UserSearchKey key) throws AppException,
      InformationalException {

    // details to be returned
    UserSearchDetails userSearchDetails = new UserSearchDetails();

    // search for users
    userSearchDetails.userSearchResultsList = AdminUserFactory.newInstance().search(
      key.userSearchCriteria);

    // Return user details
    return userSearchDetails;
  }

  // END, CR00170283
  
  /**
   * Retrieve a list of all locations for an organization.
   *
   * @return A List of locations for the organization
   */
  public ReadOrganizationLocationList listLocation() throws AppException,
      InformationalException {

    // Details to be returned
    ReadOrganizationLocationList readOrganizationLocationList = new ReadOrganizationLocationList();

    // Retrieve a list of locations
    readOrganizationLocationList.locationsList = AdminLocationFactory.newInstance().listAllLocations();

    // Return details
    return readOrganizationLocationList;
  }

  /**
   * Retrieve a list of all locations for a given location structure id.
   *
   * @param key
   * Identifier for the Location Structure
   *
   * @return A List of locations for the location structure
   */
  public ReadLocationListForLocationStructure listLocationsForLocationStructure(
    curam.core.facade.struct.LocationStructureKey key) throws AppException,
      InformationalException {

    // Details to be returned
    ReadLocationListForLocationStructure readLocationListForLocationStructure = new ReadLocationListForLocationStructure();

    LocationStructureKey locationStructKey = new LocationStructureKey();

    locationStructKey.locationStructureID = key.dtls.locationStructureID;

    // Retrieve a list of locations
    readLocationListForLocationStructure.locationList = AdminLocationFactory.newInstance().listLocationsforLocationStructure(
      locationStructKey);

    // Retrieve location structure name
    readLocationListForLocationStructure.name = readLocationStructure(key).dtls.readDtls.name;

    // Return details
    return readLocationListForLocationStructure;
  }

  /**
   * Retrieve a list of public offices.
   *
   * @return A list of public offices for the user
   */
  public ReadOrganizationPublicOfficeList listPublicOffice()
    throws AppException, InformationalException {

    // AdminOrganization business process object and key
    curam.core.intf.AdminOrganisation adminOrganisationObj = curam.core.fact.AdminOrganisationFactory.newInstance();
    OrganisationKeyStruct organisationKeyStruct = new OrganisationKeyStruct();

    // Details to be returned
    ReadOrganizationPublicOfficeList readOrganizationPublicOfficeList = new ReadOrganizationPublicOfficeList();

    // BEGIN, CR00168663, LD
    // Set up the key for the operation
    organisationKeyStruct.organisationID = getOrganizationID();
    // END, CR00168663

    // Retrieve a list of public offices
    readOrganizationPublicOfficeList.orgPublicOfficeList = adminOrganisationObj.ListAllPublicOfficesInOrg(
      organisationKeyStruct);

    // Return details
    return readOrganizationPublicOfficeList;
  }

  /**
   * Reads the description of the Organization.
   *
   * @param key
   * Key for the organization
   *
   * @return Organization context description details
   */
  @Override
  protected OrganizationContextDescriptionDetails readOrganizationContextDescription(
    OrganizationContextDescriptionKey key) throws AppException,
      InformationalException {

    // Organization maintenance business process object
    curam.core.intf.Organisation organisationObj = curam.core.fact.OrganisationFactory.newInstance();

    // Details to be returned
    OrganizationContextDescriptionDetails organizationContextDescriptionDetails = new OrganizationContextDescriptionDetails();

    // Read the organization details
    OrganisationKey organisationKey = new OrganisationKey();

    organisationKey.organisationID = key.organizationID;

    curam.core.struct.OrganisationDtls organisationDtls = new curam.core.struct.OrganisationDtls();

    organisationDtls = organisationObj.read(organisationKey);

    // Prepare the context description details
    organizationContextDescriptionDetails.description = organisationDtls.name;

    // Return the details
    return organizationContextDescriptionDetails;
  }

  /**
   * Reads the description of the User.
   *
   * @param key
   * Identifier for user whose description is to be returned
   *
   * @return Context description for a user
   */
  @Override
  protected UserContextDescriptionDetails readUserContextDescription(
    OrganizationUserContextDescriptionKey key) throws AppException,
      InformationalException {

    // User maintenance business process object
    UserAccess userAccessObj = UserAccessFactory.newInstance();

    // Details to be returned
    UserContextDescriptionDetails userContextDescriptionDetails = new UserContextDescriptionDetails();

    // Read the user details
    UsersKey usersKey = new UsersKey();

    usersKey.userName = key.userName;
    UserFullname userFullName = userAccessObj.getFullName(usersKey);

    // Prepare the context description details
    userContextDescriptionDetails.description = userFullName.fullname;

    // Return details
    return userContextDescriptionDetails;
  }

  /**
   * Inserts a new user.
   *
   * @param details
   * Details of the new user to be created
   */
  public void createUser(CreateUserDetails details) throws AppException,
      InformationalException {
    // BEGIN, CR00190252, NP
    UsersDtls dtls = new UsersDtls();

    validateUserName(dtls.assign(details.userDetails));
    // END, CR00190252
      
    details.userDetails.alternateLoginEnabled = Boolean.valueOf(
      Configuration.getProperty(EnvironmentConstants.Security.kAltLoginEnabled));

    // Create the user
    AdminUserFactory.newInstance().insert(details.userDetails);
    
    if (details.userDetails.alternateLoginEnabled) {
      curam.util.administration.intf.SecurityAdmin securityAdminObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();    

      ExtendedUsersInfoDetails extendedUsersInfoDetails = new ExtendedUsersInfoDetails();

      extendedUsersInfoDetails.loginID = details.loginId;      
      extendedUsersInfoDetails.userName = details.userDetails.userName;
      extendedUsersInfoDetails.upperLoginID = details.loginId.toUpperCase();
      securityAdminObj.addLoginID(extendedUsersInfoDetails); 
    }
  }

  // BEGIN, CR00226138, GP
  /**
   * Modifies Organization details.
   *
   * @param details
   * Details of organization to be modified
   *
   * @deprecated Since Curam 6.0, replaced with {@link Organization#
   * modifyOrganization1(ModifyOrganizationDetails1)} as part of implementing
   * localization of free text fields in Organization home page.
   *
   * See release note : <CR00226138>
   */
  @Deprecated
  public void modifyOrganization(
    curam.core.facade.struct.ModifyOrganizationDetails details)
    throws AppException, InformationalException {

    // Admin Organization object.
    curam.core.intf.AdminOrganisation adminOrganisationObj = curam.core.fact.AdminOrganisationFactory.newInstance();

    // Struct passed to Admin Organization modify.
    OrganisationDetails organisationDetails = new OrganisationDetails();

    organisationDetails = details.organisationDetails;

    // Modify organization details
    adminOrganisationObj.modifyOrganisation(organisationDetails);
  }

  /**
   * Modifies Organization details.
   *
   * @param details
   * Details of organization to be modified.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyOrganization1(ModifyOrganizationDetails1 details)
    throws AppException, InformationalException {

    AdminOrganisation adminOrganisationObj = AdminOrganisationFactory.newInstance();

    // Call service layer method.
    adminOrganisationObj.modifyOrganisation1(details.organisationDetails1);
  }

  // END, CR00226138

   
  
  /**
   * Modify the details for a user.
   *
   * @param details
   * The modified details for a user
   */
  public void modifyUser(ModifyUserDetails details) throws AppException,
      InformationalException {
    // BEGIN, CR00407060, RD
    final OrgUnitUserNameAndStatusKey nameAndStatusKey = new OrgUnitUserNameAndStatusKey();

    nameAndStatusKey.userName = details.userDetails.userName;
    nameAndStatusKey.status = RECORDSTATUS.CANCELLED;
    nameAndStatusKey.orgStructStatusCode = ORGSTRUCTURESTATUS.ACTIVE;
    OrganisationUnit organizationUnit = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();
    SupervisorOrgUnitDetailsList orgUnitDetailsList = new SupervisorOrgUnitDetailsList();

    orgUnitDetailsList = organizationUnit.searchChildOrgUnitsByUser(
      nameAndStatusKey);

    OrganisationAdminSecurityIdentifierDetails organisationAdminSecurityIdentifierDetails = new OrganisationAdminSecurityIdentifierDetails();
    curam.core.sl.entity.struct.OrganisationUnitKey organisationUnitKey = new curam.core.sl.entity.struct.OrganisationUnitKey();

    for (SupervisorOrgUnitDetails supervisorOrgUnitDetails : orgUnitDetailsList.dtls.items()) {
      organisationUnitKey.organisationUnitID = supervisorOrgUnitDetails.orgUnitID;
      organisationAdminSecurityIdentifierDetails = organizationUnit.readSecurityIdentifiers(
        organisationUnitKey);
      if (!organisationAdminSecurityIdentifierDetails.maintainSID.isEmpty()) {
        validateMaintainSID(
          organisationAdminSecurityIdentifierDetails.maintainSID,
          supervisorOrgUnitDetails.orgUnitName);
      }
    }
    // END, CR00407060
    
    // BEGIN, CR00190252, NP
    UsersDtls dtls = new UsersDtls();
    
    validateUserName(dtls.assign(details.userDetails));
    // END, CR00190252
    // Prepare key for modify operation
    UserKeyStruct userKeyStruct = new UserKeyStruct();

    userKeyStruct.userName = details.userDetails.userName;
    
    details.userDetails.alternateLoginEnabled = Boolean.valueOf(
      Configuration.getProperty(EnvironmentConstants.Security.kAltLoginEnabled));

    if (details.userDetails.alternateLoginEnabled) {
      curam.util.administration.intf.SecurityAdmin securityAdminObj = curam.util.administration.fact.SecurityAdminFactory.newInstance(); 
      ExtendedUsersInfoDetails extendedUsersInfoDetails = new ExtendedUsersInfoDetails();
      ExtendedUsersInfoUserName extendedUsersInfoUserName = new ExtendedUsersInfoUserName();

      extendedUsersInfoUserName.userName = details.userDetails.userName;
      extendedUsersInfoDetails.loginID = details.userDetails.loginID;
      extendedUsersInfoDetails.userName = details.userDetails.userName;
      extendedUsersInfoDetails.upperLoginID = details.userDetails.loginID.toUpperCase();
                
      securityAdminObj.modifyLoginID(extendedUsersInfoUserName,
        extendedUsersInfoDetails);        
    }
    
    // Modify the user details
    AdminUserFactory.newInstance().modify(userKeyStruct, details.userDetails);
  }

  // BEGIN, CR00226138, GP
  /**
   * Reads the Organization record specified by the input key.
   *
   * @return Organization home page details
   * @deprecated Since Curam 6.0, replaced with {@link Organization#
   * readOrganizationHomePage1()} as part of implementing localization of free
   * text fields in Organization home page.
   *
   * See release note : <CR00226138>
   */
  @Deprecated
  public curam.core.facade.struct.ReadOrganizationHomePageDetails readOrganizationHomePage() throws AppException, InformationalException {

    // Organization Maintenance object.
    curam.core.intf.AdminOrganisation adminOrganisationObj = curam.core.fact.AdminOrganisationFactory.newInstance();

    // Details to be returned.
    curam.core.facade.struct.ReadOrganizationHomePageDetails readOrganizationHomePageDetails = new curam.core.facade.struct.ReadOrganizationHomePageDetails();

    // Struct passed to ReadOrganisation read.
    OrganisationKeyStruct organisationKeyStruct = new OrganisationKeyStruct();

    // BEGIN, CR00168663, LD
    // Set up key for the operation
    organisationKeyStruct.organisationID = getOrganizationID();
    // END, CR00168663

    readOrganizationHomePageDetails.organisationDetails = adminOrganisationObj.ReadOrganisation(
      organisationKeyStruct);

    // Struct passed to readOrganizationContextDescription read
    OrganizationContextDescriptionKey organizationContextDescriptionKey = new OrganizationContextDescriptionKey();

    // BEGIN, CR00168663, LD
    // Set up key for the operation
    organizationContextDescriptionKey.organizationID = getOrganizationID();
    // END, CR00168663

    // Read organization context description
    readOrganizationHomePageDetails.organizationContextDescriptionDetails = readOrganizationContextDescription(
      organizationContextDescriptionKey);

    // Return the details.
    return readOrganizationHomePageDetails;
  }

  /**
   * Reads the Organization record specified by the input key.
   *
   * @return Organization home page details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReadOrganizationHomePageDetails1 readOrganizationHomePage1()
    throws AppException, InformationalException {

    AdminOrganisation adminOrganisationObj = AdminOrganisationFactory.newInstance();
    ReadOrganizationHomePageDetails1 readOrganizationHomePageDetails1 = new ReadOrganizationHomePageDetails1();
    OrganisationKeyStruct organisationKeyStruct = new OrganisationKeyStruct();

    organisationKeyStruct.organisationID = getOrganizationID();

    readOrganizationHomePageDetails1.organisationDetails = adminOrganisationObj.readOrganisation1(
      organisationKeyStruct);

    OrganizationContextDescriptionKey organizationContextDescriptionKey = new OrganizationContextDescriptionKey();

    organizationContextDescriptionKey.organizationID = getOrganizationID();

    // Read organization context description.
    readOrganizationHomePageDetails1.organizationContextDescriptionDetails = readOrganizationContextDescription(
      organizationContextDescriptionKey);

    return readOrganizationHomePageDetails1;
  }

  // END, CR00226138

  
  // BEGIN, CR00216807 MN
  /**
   * Retrieve the homepage details for a user.
   *
   * @param key
   * Identifier for a user
   *
   * @return Homepage details for a user
   *
   * @deprecated Since Curam 6.0 , replaced with
   * {@link Organization#readOrganizationUserHomePage(ReadUserHomePageKey key)}.
   * As part of CLE changes the implementation has been moved to
   * readOrganizationUserHomePage with a new return struct
   * ReadOrganizationUserHomePageDetails. This struct has all the fields of
   * ReadUserHomePageDetails struct along with the field toRedirectType.
   * See release note : <CR00216807>
   */
  @Deprecated
  public curam.core.facade.struct.ReadUserHomePageDetails readUserHomePage(ReadUserHomePageKey key)
    throws AppException, InformationalException {

    // Details to be returned
    curam.core.facade.struct.ReadUserHomePageDetails readUserHomePageDetails = new curam.core.facade.struct.ReadUserHomePageDetails();

    // BEGIN, CR00066601, NG
    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();
    // END, CR00066601

    // Read the users homepage details
    UserDetails userDetails;

    userDetails = AdminUserFactory.newInstance().read(key.userKeyStruct);
    readUserHomePageDetails.readUserDetails.assign(userDetails);

    readUserHomePageDetails.readUserDetails.oldPassword = CuramConst.gkRestricted;

    readUserHomePageDetails.readUserDetails.passwordExpiresOn = userDetails.passwordExpiresOn;

    // Read the users context description
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    organizationUserContextDescriptionKey.userName = key.userKeyStruct.userName;
    readUserHomePageDetails.userContextDescriptionDetails = readUserContextDescription(
      organizationUserContextDescriptionKey);

    // BEGIN, CR00066601, NG
    // Informational Manager handle
    curam.util.exception.InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; ++i) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      readUserHomePageDetails.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00066601

    // Return details
    return readUserHomePageDetails;
  }

  // END, CR00216807

  
  /**
   * Returns a list of security roles for the organization.
   *
   * @return List of security roles
   */
  public ReadSecurityRolesList listAllSecurityRoles() throws AppException,
      InformationalException {

    // Security maintenance business process object
    curam.util.administration.intf.SecurityAdmin securityAdministrationObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();

    // Details to be returned
    ReadSecurityRolesList readSecurityRolesList = new ReadSecurityRolesList();

    // Retrieve the list of security roles
    SecurityRoleDetailsList securityRoleDetailsList = new SecurityRoleDetailsList();

    securityRoleDetailsList = securityAdministrationObj.listAllSecurityRoles();

    // Copy list to return object
    for (int i = 0; i < securityRoleDetailsList.dtls.size(); i++) {
      ReadSecurityRoles readSecurityRoles = new ReadSecurityRoles();

      readSecurityRoles.roleName = securityRoleDetailsList.dtls.item(i).roleName;
      readSecurityRolesList.readSecurityRoles.addRef(readSecurityRoles);
    }

    // Return details
    return readSecurityRolesList;
  }

  /**
   * This method will change the recordStatus of Admin Location from Active to
   * Canceled.
   *
   * @param key
   * location identifier
   */
  public void cancelLocation(CancelLocationKey key) throws AppException,
      InformationalException {

    // Cancel the location
    AdminLocationFactory.newInstance().cancelLocation(key.cancelLocationKey);
  }

  /**
   * Adds a location record to the database.
   *
   * @param details
   * details of the new location to be created
   */
  public void createLocation(MaintainLocationDetails details)
    throws AppException, InformationalException {
    // BEGIN, CR00168663, LD
    // Set the organization id
    details.locationDetails.organisationID = getOrganizationID();
    // END, CR00168663

    // create and populate LocationDetails object
    LocationDetails locationDetails = new LocationDetails();

    locationDetails.assign(details.locationDetails);

    // add a new location.
    AdminLocationFactory.newInstance().addLocation(locationDetails);

    // BEGIN, CR00074155, KK
    // Highlight the parent location node when a child location is created.
    // key to update the TreeNodeDetails HashMap .
    RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // key to read the parent location details
    ReadLocationKey key = new ReadLocationKey();

    key.locationKeyRef.locationID = details.locationDetails.parentLocationID;

    ReadLocationDetails readLocationDetails = readLocation(key);

    // key and value pair
    ruleSetNodeKey.ruleSetID = String.valueOf(
      readLocationDetails.locationDetails.locationStructureID);
    ruleSetNodeKey.nodeID = details.locationDetails.parentLocationID;
    LocationpostUpdate(ruleSetNodeKey);
    // END, CR00074155
  }

  /**
   * Adds a root location record for a location structure.
   *
   * @param details
   * details of the new root location to be created
   */
  public void createRootLocation(MaintainLocationDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00168663, LD
    // Set the organization id
    details.locationDetails.organisationID = getOrganizationID();
    // END, CR00168663

    // create and populate LocationDetails object
    LocationDetails locationDetails = new LocationDetails();

    locationDetails.assign(details.locationDetails);

    // add a new root location
    AdminLocationFactory.newInstance().addRootLocation(locationDetails);
  }

  /**
   * Updates location details for the specified location.
   *
   * @param details
   * location details.
   */
  public void modifyLocation(MaintainLocationDetails details)
    throws AppException, InformationalException {

    // Get the location ID from the details.
    LocationKeyRef locationKeyRef = new LocationKeyRef();

    locationKeyRef.locationID = details.locationDetails.locationID;

    // Get the location details from details
    LocationDetails locationDetails = new LocationDetails();

    locationDetails.assign(details.locationDetails);

    // Modify the location details.
    AdminLocationFactory.newInstance().modifyLocation(locationKeyRef,
      locationDetails);

    // BEGIN, CR00091534 KK
    // Highlight the location node when the location is edited
    // key to update the TreeNodeDetails HashMap .
    RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // key and value pair
    ruleSetNodeKey.ruleSetID = String.valueOf(
      details.locationDetails.locationStructureID);
    // assign node id to the location Id which is has been modified
    ruleSetNodeKey.nodeID = details.locationDetails.locationID;

    LocationpostUpdate(ruleSetNodeKey);
    // END, CR00091534 KK
  }

  /**
   * Reads details about the location specified by the key.
   *
   * @param key
   * location identifier
   *
   * @return location details.
   */
  public ReadLocationDetails readLocation(ReadLocationKey key)
    throws AppException, InformationalException {

    // Admin Location object
    AdminLocation adminLocationObj = AdminLocationFactory.newInstance();

    // create return object
    ReadLocationDetails readLocationDetails = new ReadLocationDetails();

    // read the location details
    readLocationDetails.locationDetails.assign(
      adminLocationObj.readLocation(key.locationKeyRef));

    // Key to be passed to readLocationContextDescription
    LocationContextDescriptionKey locationContextDescriptionKey = new LocationContextDescriptionKey();

    locationContextDescriptionKey.locationID = readLocationDetails.locationDetails.locationID;

    // read context description
    readLocationDetails.locationContextDescriptionDetails = readLocationContextDescription(
      locationContextDescriptionKey);

    // Key to be passed for Daily schedule listing
    DailyScheduleListKey dailyScheduleListKey = new DailyScheduleListKey();

    dailyScheduleListKey.dailyScheduleListKey.locationID = key.locationKeyRef.locationID;

    // Get Daily schedule list
    readLocationDetails.schedules = listDailySchedule(dailyScheduleListKey);

    // Get additional location access list
    readLocationDetails.additionalLocationAccess = adminLocationObj.listAdditionalLocationAccess(
      key.locationKeyRef);

    // Return details
    return readLocationDetails;
  }
  
  // BEGIN, CR00407060, RD
  /**
   * Validates whether the logged in user has the SIDs.
   *
   * @param maintainSID
   * MaintainSID security identifier details.
   * @param orgUnitName Organization unit name.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateMaintainSID(
    String maintainSID, String orgUnitName)
    throws AppException, InformationalException {
    OrganisationAdminAuthorisationKey organisationAdminAuthorisationKey = new OrganisationAdminAuthorisationKey();
    SystemUser systemUser = SystemUserFactory.newInstance();

    organisationAdminAuthorisationKey.sidName = maintainSID;
    organisationAdminAuthorisationKey.userName = systemUser.getUserDetails().userName;

    if (!OrganisationAdminSecurityFactory.newInstance().authoriseSID(organisationAdminAuthorisationKey).result) {
      final AppException exception = new AppException(BPOORGANISATIONUNIT.ERR_ORGANISATIONSECURITY_MODIFY_USER_CHECK_FAILED).arg(
        orgUnitName);

      throw exception;
    }
  }

  // END, CR00407060

  /**
   * Reads the description of the Location.
   *
   * @param key
   * location identifier
   *
   * @return location description.
   */
  @Override
  protected LocationContextDescriptionDetails readLocationContextDescription(
    LocationContextDescriptionKey key) throws AppException,
      InformationalException {

    // Key to be passed to the read.
    LocationKey locationKey = new LocationKey();

    locationKey.locationID = key.locationID;

    LocationDtls locationDtls = curam.core.fact.LocationFactory.newInstance().read(
      locationKey);

    // Details to be returned
    LocationContextDescriptionDetails locationContextDescriptionDetails = new LocationContextDescriptionDetails();

    locationContextDescriptionDetails.description = locationDtls.name;

    // return details
    return locationContextDescriptionDetails;
  }

  /**
   * Reads the description of the Organization resources.
   *
   * @param key
   * The resource whose description is to be returned
   *
   * @return The resource description
   */
  @Override
  protected OrganizationResourceContextDescriptionDetails readResourceContextDescription(
    OrganizationResourceContextDescriptionKey key) throws AppException,
      InformationalException {

    // Details to be returned
    OrganizationResourceContextDescriptionDetails organizationResourceContextDescriptionDetails = new OrganizationResourceContextDescriptionDetails();

    // Read the organization details
    ResourcesKey resourcesKey = new ResourcesKey();

    resourcesKey.resourceID = key.resourceID;

    // read the details
    ResourcesDtls resourcesDtls = ResourcesFactory.newInstance().read(
      resourcesKey);

    // Prepare the context description details
    organizationResourceContextDescriptionDetails.description = resourcesDtls.name;

    // Return the context description details
    return organizationResourceContextDescriptionDetails;
  }

  /**
   * Adds a new resource.
   *
   * @param details
   * The details required to create a resource
   */
  public void createResource(MaintainResourceDetails details)
    throws AppException, InformationalException {

    // Create a new resource
    AdminResourcesFactory.newInstance().addResources(
      details.resourcesDetailStruct);
  }

  /**
   * Updates a resource.
   *
   * @param details
   * The resource details to be updated
   */
  public void modifyResource(MaintainResourceDetails details)
    throws AppException, InformationalException {

    // Create a ResourcesKeyStruct object
    ResourcesKeyStruct resourcesKeyStruct = new ResourcesKeyStruct();

    resourcesKeyStruct.resourceID = details.resourcesDetailStruct.resourceID;

    // Modify the resources record
    AdminResourcesFactory.newInstance().modifyResources(resourcesKeyStruct,
      details.resourcesDetailStruct);
  }

  /**
   * Returns a resource details.
   *
   * @param key
   * Read resource key.
   *
   * @return Details of the resource.
   */
  public ReadResourceDetails readResource(ReadResourceKey key)
    throws AppException, InformationalException {

    // Create the return object
    ReadResourceDetails readResourceDetails = new ReadResourceDetails();

    // Read in the details to the return object
    readResourceDetails.getResourcesDetails = AdminResourcesFactory.newInstance().readResources(
      key.resourcesKeyStruct);

    // Read the organization details
    ResourcesKey resourcesKey = new ResourcesKey();

    resourcesKey.resourceID = key.resourcesKeyStruct.resourceID;

    // Read in the details
    ResourcesDtls resourcesDtls = ResourcesFactory.newInstance().read(
      resourcesKey);

    // Read context description.
    readResourceDetails.organizationResourceContextDescriptionDetails.description = resourcesDtls.name;

    // Return the details.
    return readResourceDetails;
  }

  /**
   * Return a list of all resources.
   *
   * @return A list of resources.
   */
  public ReadResourceList listResource() throws AppException,
      InformationalException {

    // Create the return object
    ReadResourceList readResourceList = new ReadResourceList();

    // Read all the resources
    readResourceList.resourcesDetailsListRef = AdminResourcesFactory.newInstance().listAllResources();

    // Return the list of resources
    return readResourceList;
  }

  /**
   * This method will change the recordStatus of Resources Record from Active to
   * Canceled.
   *
   * @param key
   * The resourceID of the resource to be canceled
   */
  public void cancelResource(CancelResourceKey key) throws AppException,
      InformationalException {

    // Cancel the resource
    AdminResourcesFactory.newInstance().cancelResources(key.cancelResourceKey);
  }

  /**
   * This method will change remove the resource from location and(or) its
   * related locations.
   *
   * @param key
   * The resourceID of the resource to be removed
   */
  public void removeLocationResource(RemoveResourceKey key)
    throws AppException, InformationalException {

    // remove the resource
    AdminResourcesFactory.newInstance().removeLocationResource(key.removeDtls);
  }

  /**
   * This method will create a location resource.
   *
   * @param details
   * The details of the resource location to be created
   */
  public void createLocationResource(ResourceLocationDetails details)
    throws AppException, InformationalException {

    // create location resource
    AdminResourcesFactory.newInstance().createLocationResource(
      details.resourceLocationDtls);
  }

  /**
   * This method will create a Organization resource.
   *
   * @param details
   * The details of the resource Organization to be created
   */
  public void createOrganisationUnitResource(
    ResourceOrganisationUnitDetail details) throws AppException,
      InformationalException {

    // create Organization Unit resource
    AdminResourcesFactory.newInstance().createOrganisationUnitResource(
      details.resourceOrgUnitDtls);
  }

  /**
   * Assign resource to Location.
   *
   * @param details
   * The details of the resource to be assigned
   */
  public void assignResourceToLocation(AssignResourceDetails details)
    throws AppException, InformationalException {

    // Assign resource to location
    AdminResourcesFactory.newInstance().assignResourceToLocation(details.dtls);
  }

  /**
   * Search active operating resources by type code.
   *
   * @param key
   * The key for searching resources
   *
   * @return A list of active resources
   */
  public ListActiveResourcesDetails searchActiveResourcesByType(
    ResourceSearchKey key) throws AppException, InformationalException {

    ListActiveResourcesDetails listActiveResourcesDetails = new ListActiveResourcesDetails();

    // search active resources
    listActiveResourcesDetails.resourcesDetailsList = AdminResourcesFactory.newInstance().searchResourcesByType(
      key.resourceSearchKey);

    return listActiveResourcesDetails;
  }

  /**
   * Insert a new bank.
   *
   * @param details
   * Details for the bank.
   */
  public void createBank(MaintainBankDetails details) throws AppException,
      InformationalException {

    // add a new bank
    AdminBankFactory.newInstance().insertBank(details.bankStruct);
  }

  /**
   * Modify an existing Bank.
   *
   * @param details
   * Details for the bank.
   */
  public void modifyBank(MaintainBankDetails details) throws AppException,
      InformationalException {

    // Get the bank ID from the details.
    BankKeyStruct bankKeyStruct = new BankKeyStruct();

    bankKeyStruct.bankID = details.bankStruct.bankID;

    // Modify the bank record.
    AdminBankFactory.newInstance().modifyBank(bankKeyStruct, details.bankStruct);
  }

  /**
   * Read all details for a bank.
   *
   * @param key
   * Key for the bank
   *
   * @return bank details.
   */
  public MaintainBankDetails readBank(ReadBankKey key) throws AppException,
      InformationalException {

    // create return object
    MaintainBankDetails maintainBankDetails = new MaintainBankDetails();

    // read the bank details
    maintainBankDetails.bankStruct = AdminBankFactory.newInstance().readBank(
      key.bankKeyStruct);

    // Return details
    return maintainBankDetails;
  }

  /**
   * Lists all banks.
   *
   * @return list of banks
   */
  public ListBankDetails listBank() throws AppException, InformationalException {

    // The details to be returned
    ListBankDetails listBankDetails = new ListBankDetails();

    // Read the bank list
    listBankDetails.bankList = AdminBankFactory.newInstance().listAllBanks();

    // Return the details
    return listBankDetails;
  }

  /**
   * This method will change the recordStatus of Bank from Active to Canceled.
   *
   * @param key
   * Key for the bank
   */
  public void cancelBank(CancelBankKey key) throws AppException,
      InformationalException {

    // Cancel the bank
    AdminBankFactory.newInstance().cancelBank(key.cancelBankKey);
  }

  // BEGIN, CR00231961, ZV
  
  /**
   * Insert a new Bank Account for an Organization.
   *
   * @param details
   * Details of the bank account record to be created
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createBankAccountWithTextSortCode()}. See release note: CR00231961
   */
  @Deprecated
  public void createBankAccount(MaintainBankAccountDetails_fo details)
    throws AppException, InformationalException {

    MaintainBankAccountWithTextSortCodeDetails bankAccountDetails = new MaintainBankAccountWithTextSortCodeDetails();

    bankAccountDetails.maintainBankAccountDetails.assign(
      details.maintainBankAccountDetails);
    bankAccountDetails.bankSortCode = details.maintainBankAccountDetails.bankSortCode;

    createBankAccountWithTextSortCode(bankAccountDetails);
  }

  /**
   * Modify the details for a Bank Account.
   *
   * @param details
   * Details of the bank account to be modified
   * @deprecated Since Curam 6.0, replaced by
   * {@link #modifyBankAccountWithTextSortCode()}. See release note: CR00231961
   */
  @Deprecated
  public void modifyBankAccount(MaintainBankAccountDetails_fo details)
    throws AppException, InformationalException {

    MaintainBankAccountWithTextSortCodeDetails bankAccountDetails = new MaintainBankAccountWithTextSortCodeDetails();

    bankAccountDetails.maintainBankAccountDetails.assign(
      details.maintainBankAccountDetails);
    bankAccountDetails.bankSortCode = details.maintainBankAccountDetails.bankSortCode;

    modifyBankAccountWithTextSortCode(bankAccountDetails);
  }

  // END, CR00231961

  
  /**
   * Retrieve the details for a bank account.
   *
   * @param key
   * Identifier for bank account to be retrieved
   *
   * @return The details for the bank account
   */
  public ReadBankAccountDetails readBankAccount(ReadBankAccountKey_fo key)
    throws AppException, InformationalException {

    // Details to be returned
    ReadBankAccountDetails readBankAccountDetails = new ReadBankAccountDetails();

    // Key object to send to ReadBankAccount
    OrgBankAccountKeyStruct orgBankAccountKeyStruct = new OrgBankAccountKeyStruct();

    orgBankAccountKeyStruct.bankAccountID = key.readBankAccountKey.bankAccountID;

    // BEGIN, CR00168663, LD
    // Set organization id
    orgBankAccountKeyStruct.organisationID = getOrganizationID();
    // END, CR00168663

    // Read the bank account details
    readBankAccountDetails.orgBankAccountDetails = AdminOrganisationFactory.newInstance().ReadBankAccount(
      orgBankAccountKeyStruct);

    // Return details
    return readBankAccountDetails;
  }

  /**
   * Retrieve a list of bank accounts for the specified Organization.
   *
   * @return A list of bank accounts for the organization
   */
  public ListBankAccountDetails listBankAccount() throws AppException,
      InformationalException {

    // Details to be returned
    ListBankAccountDetails listBankAccountDetails = new ListBankAccountDetails();

    // Key object to send to ListAllBankAccountsInOrg
    OrganisationKeyStruct organisationKeyStruct = new OrganisationKeyStruct();

    // BEGIN, CR00168663, LD
    // Set organization id
    organisationKeyStruct.organisationID = getOrganizationID();
    // END, CR00168663

    // Retrieve the list of bank accounts
    listBankAccountDetails.orgBankAccountList = AdminOrganisationFactory.newInstance().ListAllBankAccountsInOrg(
      organisationKeyStruct);
    // BEGIN, CR00371769, VT
    // BEGIN, CR00372632, VT
    // Bank Account values should be displayed based on following logic
    // 1. If IBAN is entered, Bank Account field will populate the IBAN.
    // 2. If Basic Bank Account Number (BBAN) is entered, Bank Account field
    // will populate the BBAN.
    // 3. If IBAN and BBAN are entered, Bank Account field will populate the
    // IBAN value.

    for (final OrgBankAccountListDetails orgBankAccountListDetails : listBankAccountDetails.orgBankAccountList.dtls) {
      if (0 != orgBankAccountListDetails.ibanOpt.length()) {
        orgBankAccountListDetails.bankAccountNumberOpt = orgBankAccountListDetails.ibanOpt;
      } else {
        orgBankAccountListDetails.bankAccountNumberOpt = orgBankAccountListDetails.accountNumber;
      }
    }
    // END, CR00372596
    // END, CR00371769
    
    // Return details
    return listBankAccountDetails;
  }

  /**
   * Cancel a bank account record.
   *
   * @param key
   * Identifier of the bank account record to be canceled
   */
  public void cancelBankAccount(CancelBankAccountKey key) throws AppException,
      InformationalException {

    // Cancel the bank account
    AdminOrganisationFactory.newInstance().CancelBankAccount(
      key.cancelBankAccountKey);
  }

  /**
   * Inserts a new bank branch.
   *
   * @param details
   * maintain bank branch details facade object
   */
  public void createBankBranch(MaintainBankBranchDetails details)
    throws AppException, InformationalException {

    // inserts the bank branch details
    AdminBankBranchFactory.newInstance().InsertBankBranch(
      details.bankBranchStruct);
  }

  /**
   * Modifies an existing branch.
   *
   * @param details
   * maintain bank branch details facade object
   */
  public void modifyBankBranch(MaintainBankBranchDetails details)
    throws AppException, InformationalException {

    // get instance of bank branch key struct
    BankBranchKeyStruct bankBranchKeyStruct = new BankBranchKeyStruct();

    bankBranchKeyStruct.bankBranchID = details.bankBranchStruct.bankBranchID;

    // modify the bank branch details
    AdminBankBranchFactory.newInstance().ModifyBankBranch(bankBranchKeyStruct,
      details.bankBranchStruct);
  }

  /**
   * Read all details for a branch.
   *
   * @param key
   * read bank branch key facade object
   *
   * @return maintain bank branch details facade object
   */
  public MaintainBankBranchDetails readBankBranch(ReadBankBranchKey key)
    throws AppException, InformationalException {

    // the details to be returned
    MaintainBankBranchDetails maintainBankBranchDetails = new MaintainBankBranchDetails();

    // read the bank branch details
    maintainBankBranchDetails.bankBranchStruct = AdminBankBranchFactory.newInstance().ReadBankBranch(
      key.bankBranchKeyStruct);

    return maintainBankBranchDetails;
  }

  /**
   * Lists all Branches for the specified bank.
   *
   * @param key
   * list bank branch key
   *
   * @return bank branch details list facade object
   */
  public ListBankBranchDetails listBankBranch(ListBankBranchKey key)
    throws AppException, InformationalException {

    // The details to be returned
    ListBankBranchDetails listBankBranchDetails = new ListBankBranchDetails();

    // Retrieve the bank branch details list
    listBankBranchDetails.bankBranchList = AdminBankBranchFactory.newInstance().ListAllBranchesForBank(
      key.bankKeyStruct);

    // Retrieve the bank name
    listBankBranchDetails.listBankBranchBankDetails.bankName = AdminBankFactory.newInstance().readBank(key.bankKeyStruct).name;

    return listBankBranchDetails;
  }

  /**
   * This method will change the recordStatus of BankBranch from Active to
   * Canceled.
   *
   * @param key
   * cancel bank branch key facade object
   */
  public void cancelBankBranch(CancelBankBranchKey key) throws AppException,
      InformationalException {

    // Cancel the bank branch
    AdminBankBranchFactory.newInstance().cancelBankBranch(
      key.cancelBankBranchKey);
  }

  /**
   * Inserts a new currency exchange rate for an Organization.
   *
   * @param details
   * The details required to create a currency exchange rate.
   */
  public void createCurrencyExchange(MaintainCurrencyExchangeDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00263751, MC
    if (details.orgCurrencyExchangeDetails.organisationID == 0) {
      details.orgCurrencyExchangeDetails.organisationID = getOrganizationID();
    }
    // END, CR00263751
    // Add the new currency exchange
    AdminOrganisationFactory.newInstance().InsertCurrencyExchange(
      details.orgCurrencyExchangeDetails);
  }

  /**
   * Modifies currency exchange details.
   *
   * @param details
   * The currency exchange details to be updated
   */
  public void modifyCurrencyExchange(MaintainCurrencyExchangeDetails details)
    throws AppException, InformationalException {

    // Modify the currency exchange record
    AdminOrganisationFactory.newInstance().ModifyCurrencyExchange(
      details.orgCurrencyExchangeDetails);
  }

  /**
   * Reads the currency exchange record specified by the input key.
   *
   * @param key
   * Currency exchange key to a particular record.
   *
   * @return Details of the record returned.
   */
  public MaintainCurrencyExchangeDetails readCurrencyExchange(
    ReadCurrencyExchangeKey key) throws AppException, InformationalException {

    // Create an object to return the currency exchange details
    MaintainCurrencyExchangeDetails maintainCurrencyExchangeDetails = new MaintainCurrencyExchangeDetails();

    // Read the details into the return object
    maintainCurrencyExchangeDetails.orgCurrencyExchangeDetails = AdminOrganisationFactory.newInstance().ReadCurrencyExchange(
      key.orgCurrencyExchangeKeyStruct);

    // Return the currency exchange details
    return maintainCurrencyExchangeDetails;
  }

  /**
   * This process will read a currency exchange rate on a specified date.
   *
   * @return A list of currency exchanges.
   */
  public ListCurrencyExchangeDetails listCurrencyExchange()
    throws AppException, InformationalException {

    // Create an object to return the details
    ListCurrencyExchangeDetails listCurrencyExchangeDetails = new ListCurrencyExchangeDetails();

    // Create an OrgCurrExchByDateKeyStruct key for the read
    OrgCurrExchByDateKeyStruct orgCurrExchByDateKeyStruct = new OrgCurrExchByDateKeyStruct();

    // BEGIN, CR00168663, LD
    // Read the organisationID into the key
    orgCurrExchByDateKeyStruct.organisationID = getOrganizationID();
    // END, CR00168663

    // Read in all the currency exchanges
    listCurrencyExchangeDetails.orgCurrencyExchangeList = AdminOrganisationFactory.newInstance().ReadCurrencyExchangeByDate(
      orgCurrExchByDateKeyStruct);

    // Copy the currencyTypeCode into the currencyTypeText field
    for (int i = 0; i
      < listCurrencyExchangeDetails.orgCurrencyExchangeList.dtls.size(); i++) {
      listCurrencyExchangeDetails.orgCurrencyExchangeList.dtls.item(i).currencyTypeText = listCurrencyExchangeDetails.orgCurrencyExchangeList.dtls.item(i).currencyTypeCode;
    }

    // Read the organizationID into the return object
    listCurrencyExchangeDetails.readOrganizationKey.organizationID = orgCurrExchByDateKeyStruct.organisationID;

    // Return the list of currency exchanges
    return listCurrencyExchangeDetails;
  }

  // BEGIN, CR00050804, NRV
  
  /**
   * This process will read a currency exchange rate in a specified date range.
   *
   * @param key
   * The OrgCurrencyExchangeSearchKey
   * @return A list of currency exchanges.
   */

  public ListCurrencyExchangeDetails listCurrencyExchangeByDates(
    OrgCurrencyExchangeSearchKey key) throws AppException,
      InformationalException {

    // Create an object to return the details
    ListCurrencyExchangeDetails listCurrencyExchangeDetails = new ListCurrencyExchangeDetails();

    // BEGIN, CR00168663, LD
    // Read the organisationID into the key
    key.organisationID = getOrganizationID();
    // END, CR00168663

    // check if the search criteria is or not
    if (key.rateFromDate.isZero() && key.rateToDate.isZero()) {
      throw new AppException(GENERALSEARCH.ERR_FV_SEARCH_CRITERIA_MISSING);
    }

    // Read in all the currency exchanges
    listCurrencyExchangeDetails.orgCurrencyExchangeList = AdminOrganisationFactory.newInstance().readCurrExchRatesBydate(
      key);

    // Copy the currencyTypeCode into the currencyTypeText field
    for (int i = 0; i
      < listCurrencyExchangeDetails.orgCurrencyExchangeList.dtls.size(); i++) {
      listCurrencyExchangeDetails.orgCurrencyExchangeList.dtls.item(i).currencyTypeText = listCurrencyExchangeDetails.orgCurrencyExchangeList.dtls.item(i).currencyTypeCode;
    }

    // Read the organizationID into the return object
    listCurrencyExchangeDetails.readOrganizationKey.organizationID = key.organisationID;

    // Return the list of currency exchanges
    return listCurrencyExchangeDetails;
  }

  // END, CR00050804

  
  /**
   * This operation will read the history of currency exchange rates for a
   * selected currency.  It will list all the different rates for that currency
   * between the dates that you have specified.
   *
   * @param key
   * A currency exchange history identifier.
   *
   * @return Details of the currency exchange records returned.
   */
  public ListCurrencyExchangeHistoryDetails listCurrencyExchangeHistory(
    ListCurrencyExchangeHistoryKey_fo key) throws AppException,
      InformationalException {

    // Create a return object
    ListCurrencyExchangeHistoryDetails listCurrencyExchangeHistoryDetails = new ListCurrencyExchangeHistoryDetails();

    // Create an OrgCurrencyHistoryKeyStruct object
    OrgCurrencyHistoryKeyStruct orgCurrencyHistoryKeyStruct = new OrgCurrencyHistoryKeyStruct();

    // Assign the details in the key to the OrgCurrencyHistoryKeyStruct object
    orgCurrencyHistoryKeyStruct.assign(key.listCurrencyExchangeHistoryKey);

    // BEGIN, CR00168663, LD
    // Set the organizationID in the OrgCurrencyHistoryKeyStruct object
    orgCurrencyHistoryKeyStruct.organisationID = getOrganizationID();
    // END, CR00168663

    // Read the currency exchange history into the return object
    listCurrencyExchangeHistoryDetails.orgCurrencyExchangeList = AdminOrganisationFactory.newInstance().ReadCurrencyHistory(
      orgCurrencyHistoryKeyStruct);

    // BEGIN, CR00050804, NRV
    if (!listCurrencyExchangeHistoryDetails.orgCurrencyExchangeList.dtls.isEmpty()) {
      listCurrencyExchangeHistoryDetails.currencyExchangeCodeOutput.currencyTypeCode = listCurrencyExchangeHistoryDetails.orgCurrencyExchangeList.dtls.item(0).currencyTypeCode;
    }
    // END, CR00050804

    // Return the currency exchange history
    return listCurrencyExchangeHistoryDetails;
  }

  /**
   * This method will change the recordStatus of Currency Exchange from Active
   * to Canceled.
   *
   * @param key
   * The currency exchange rate to be canceled.
   */
  public void cancelCurrencyExchange(CancelCurrencyExchangeKey key)
    throws AppException, InformationalException {

    // Cancel the currency exchange rate
    AdminOrganisationFactory.newInstance().CancelCurrencyExchange(
      key.cancelCurrencyExchangeKey);
  }

  /**
   * Removes the currency exchange record identified by the input key.
   *
   * @param key
   * The currency exchange rate to be removed
   */
  public void removeCurrencyExchange(RemoveCurrencyExchangeKey key)
    throws AppException, InformationalException {

    // Remove the currency exchange record
    AdminOrganisationFactory.newInstance().RemoveCurrencyExchange(
      key.orgCurrencyExchangeKeyStruct);
  }

  /**
   * Reads the description of the working pattern.
   *
   * @param key
   * The user name
   *
   * @return details The working pattern context description.
   */
  @Override
  protected WorkingPatternContextDescriptionDetails readWorkingPatternContextDescription(
    WorkingPatternContextDescriptionKey key) throws AppException,
      InformationalException {

    // Details to be returned as the description.
    WorkingPatternContextDescriptionDetails workingPatternContextDescriptionDetails = new WorkingPatternContextDescriptionDetails();

    if (key.userName.length() > 0) {

      UsersKey usersKey = new UsersKey();

      usersKey.userName = key.userName;

      UserFullname userFullname = UsersFactory.newInstance().getFullName(
        usersKey);

      // Set the context description.
      workingPatternContextDescriptionDetails.description = userFullname.fullname;
    }

    return workingPatternContextDescriptionDetails;
  }

  /**
   * Presentation layer operation to cancel a User.
   *
   * @param key
   * The key of the User to cancel .
   */
  public void cancelUser(CancelUserKey key) throws AppException,
      InformationalException {

    // Cancel User
    AdminUserFactory.newInstance().cancel(key.cancelUserKeyStruct);
  }
  
  /**
   * Reads the User record specified by the input key.
   *
   * @param key
   * The user key
   *
   * @return The user details
   */
  public AlternateLoginEnabled readAlternateLoginEnabled() throws AppException,
      InformationalException {

    // Details to be returned
    AlternateLoginEnabled alternateLoginEnabled = new AlternateLoginEnabled();
 
    alternateLoginEnabled.alternateLoginEnabled = Boolean.valueOf(
      Configuration.getProperty(EnvironmentConstants.Security.kAltLoginEnabled));
    return alternateLoginEnabled;    
  }

  /**
   * Reads the User record specified by the input key.
   *
   * @param key
   * The user key
   *
   * @return The user details
   */
  public ReadUserDetails_fo readUser(ReadUserKey key) throws AppException,
      InformationalException {

    // Details to be returned
    ReadUserDetails_fo readUserDetails = new ReadUserDetails_fo();

    // Read the users homepage details
    readUserDetails.userDetails = AdminUserFactory.newInstance().read(
      key.userKeyStruct);
       
    readUserDetails.userDetails.alternateLoginEnabled = Boolean.valueOf(
      Configuration.getProperty(EnvironmentConstants.Security.kAltLoginEnabled));
   
    if (readUserDetails.userDetails.alternateLoginEnabled) {
      curam.util.administration.intf.SecurityAdmin securityAdminObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();  
      ExtendedUsersInfoLoginID extendedUsersInfoLoginID = new ExtendedUsersInfoLoginID();
      ExtendedUsersInfoUserName extendedUsersInfoUserName = new ExtendedUsersInfoUserName();

      extendedUsersInfoUserName.userName = key.userKeyStruct.userName;
        
      extendedUsersInfoLoginID = securityAdminObj.readLoginID(
        extendedUsersInfoUserName);
        
      readUserDetails.userDetails.loginID = extendedUsersInfoLoginID.loginID;        
    }  
    // Read the users context description
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    organizationUserContextDescriptionKey.userName = key.userKeyStruct.userName;
    readUserDetails.userContextDescriptionDetails = readUserContextDescription(
      organizationUserContextDescriptionKey);

    // Return details
    return readUserDetails;
  }

  /**
   * List the printers available for an org unit.
   *
   * @param readPrintersForOrgUnitKey
   * The org unit key
   *
   * @return A list of printers for specified org unit
   */
  public ReadPrintersForOrgUnitDetails listPrintersForOrgUnit(
    ReadPrintersForOrgUnitKey readPrintersForOrgUnitKey) throws AppException,
      InformationalException {

    // Create a return object
    ReadPrintersForOrgUnitDetails readPrintersForOrgUnitDetails = new ReadPrintersForOrgUnitDetails();

    // Read in a list of printers for the org unit
    readPrintersForOrgUnitDetails.orgUnitResourceDetailsListRef = OrganisationUnitResourceFactory.newInstance().listPrinter(
      readPrintersForOrgUnitKey.orgUnitKeyRef.organisationUnitKey);

    // Return the list of printers for the org unit
    return readPrintersForOrgUnitDetails;
  }

  /**
   * Cancels the Financial Calendar record specified by the input key.
   *
   * @param key
   * The financial calendar key
   */
  public void cancelExclusionDate(CancelExclusionDateKey_fo key)
    throws AppException, InformationalException {

    // Key for Financial Calendar read operation
    FinancialCalendarKey financialCalendarKey = new FinancialCalendarKey();

    // Populate key for read operation
    financialCalendarKey.financialCalendarID = key.cancelExclusionDateKey.financialCalendarID;

    // Read Financial Calendar record
    FinancialCalendarDtls financialCalendarDtls = FinancialCalendarFactory.newInstance().read(
      financialCalendarKey);

    // Struct used in removeExclusionDate operation
    ExclusionDatesSummary exclusionDatesSummary = new ExclusionDatesSummary();

    // Populate struct
    exclusionDatesSummary.dateFrom = financialCalendarDtls.exclusionDate;
    exclusionDatesSummary.dateTo = financialCalendarDtls.exclusionDate;
    exclusionDatesSummary.deliveryMethodType = financialCalendarDtls.deliveryMethodType;
    exclusionDatesSummary.reasonCode = financialCalendarDtls.reasonCode;

    // Remove exclusion date
    MaintainExclusionDateFactory.newInstance().removeExclusionDate(
      exclusionDatesSummary);
  }

  /**
   * Retrieves the case approval check information for the specified User.
   *
   * @param key
   * The username
   *
   * @return A list of case approvals for the user
   */
  public ListUserCaseApprovalDetails listUserCaseApproval(
    ListUserCaseApprovalKey key) throws AppException, InformationalException {

    // Return object
    ListUserCaseApprovalDetails listUserCaseApprovalDetails = new ListUserCaseApprovalDetails();

    // context description key object
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    // SearchAllUserCheckKey object
    SearchAllUserCheckKey searchAllUserCheckKey = new SearchAllUserCheckKey();

    searchAllUserCheckKey.searchAllUserCheckKey.userName = key.searchAllUserCheckKey.searchAllUserCheckKey.userName;

    // Get list of approval checks by user
    listUserCaseApprovalDetails.caseApprovalCheckDetailsList = CaseApprovalCheckFactory.newInstance().listApprovalChecksByUser(
      searchAllUserCheckKey);

    // Set context description key
    organizationUserContextDescriptionKey.userName = key.searchAllUserCheckKey.searchAllUserCheckKey.userName;

    // Get context description
    listUserCaseApprovalDetails.userContextDescriptionDetails = readUserContextDescription(
      organizationUserContextDescriptionKey);

    // Return details
    return listUserCaseApprovalDetails;
  }

  /**
   * To view an exclusion date from the financial calendar for a particular
   * delivery method.
   *
   * @param key
   * The read exclusion date key facade object
   *
   * @return The read exclusion date details facade object
   */
  public ReadExclusionDateDetails readExclusionDate(ReadExclusionDateKey_fo key)
    throws AppException, InformationalException {

    // Get instance of financial calendar key and set it's id
    FinancialCalendarKey financialCalendarKey = new FinancialCalendarKey();

    financialCalendarKey.financialCalendarID = key.readExclusionDateKey.financialCalendatID;

    // Read the financial calendar details
    FinancialCalendarDtls financialCalendarDtls = FinancialCalendarFactory.newInstance().read(
      financialCalendarKey);

    // Get instance of exclusion date delivery method struct
    ExclusionDateDeliveryMethod exclusionDateDeliveryMethod = new ExclusionDateDeliveryMethod();

    exclusionDateDeliveryMethod.deliveryMethodType = financialCalendarDtls.deliveryMethodType;
    exclusionDateDeliveryMethod.exclusionDate = financialCalendarDtls.exclusionDate;

    // Get instance of the object to be returned
    ReadExclusionDateDetails readExclusionDateDetails = new ReadExclusionDateDetails();

    // Set the calendar details
    readExclusionDateDetails.calendarDetails = MaintainExclusionDateFactory.newInstance().viewExclusionDate(
      exclusionDateDeliveryMethod);

    return readExclusionDateDetails;
  }

  /**
   * Return a list of dates to the cash payment calendar on which cash payments
   * cannot be processed by the organization.
   *
   * @param key
   * the read all exclusion date key facade object
   *
   * @return the read all exclusion date details
   */
  public ReadAllExclusionDateDetails readCashExclusionDate(
    ReadAllExclusionDateKey key) throws AppException, InformationalException {

    // The object to be returned
    ReadAllExclusionDateDetails readAllExclusionDateDetails = new ReadAllExclusionDateDetails();    

    ExclusionDtls[] dtls = MaintainCashPmtCalendarFactory.newInstance().getCashExclusionDates().exclusionDtlsList.dtls.items();

    // Buffer to hold dynamically generated XML
    // BEGIN, CR00023323, SK
    StringBuffer buffer = new StringBuffer(
      CuramCalendarHeaderConst.kCuramCalendarDataHeaderwithQuote);

    // END, CR00023323
    buffer.append(
      CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.CASH));
    buffer.append(CuramCalendarHeaderConst.kCloseTag);

    for (ExclusionDtls exclusionDtls : dtls) {        

      // The details struct passed to the getSingleDayEventNode method
      SingleDayEventDetails singleDayEventDetails = new SingleDayEventDetails();

      // Set the attributes of the details struct
      singleDayEventDetails.assign(exclusionDtls);
      singleDayEventDetails.eventType = CALENDAREVENTTYPE.EXCLUSIONDATE;

      // BEGIN, CR00163098, JC
      singleDayEventDetails.eventDescription = CodeTable.getOneItem(
        METHODOFDELIVERY.TABLENAME, METHODOFDELIVERY.CASH,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      // Append the returned XML string to the main XML string
      buffer.append(getSingleDayEventNode(singleDayEventDetails).nodeString);
    }

    // Close tag for the XML
    // BEGIN, CR00023323, SK
    buffer.append(CuramCalendarHeaderConst.kCuramCalendarDataFooter);
    // END, CR00023323
    // Assign the XML to the return object
    readAllExclusionDateDetails.calendarXMLString = buffer.toString();

    // Return the XML string
    return readAllExclusionDateDetails;
  }

  /**
   * Return a list of dates to the Check payment calendar on which Check
   * payments cannot be processed by the organization.
   *
   * @param key
   * The read all exclusion date key facade object
   *
   * @return The read all exclusion date details
   */
  public ReadAllExclusionDateDetails readChequeExclusionDate(
    ReadAllExclusionDateKey key) throws AppException, InformationalException {

    // The object to be returned
    ReadAllExclusionDateDetails readAllExclusionDateDetails = new ReadAllExclusionDateDetails();

    // Get the exclusion date range
    ExclusionDateRange exclusionDateRange = calculateExclusionDateRange(key);

    ExclusionDtls[] dtls = MaintainChequePmtCalendarFactory.newInstance().getChequeExclusionDates().exclusionDtlsList.dtls.items();

    // Buffer to hold dynamically generated XML
    // BEGIN, CR00023323, SK
    StringBuffer buffer = new StringBuffer(
      CuramCalendarHeaderConst.kCuramCalendarDataHeaderwithQuote);

    buffer.append(
      CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.CHECK));
    buffer.append(CuramCalendarHeaderConst.kCloseTag);
    // END, CR00023323

    for (ExclusionDtls exclusionDtls : dtls) {

      Date exclusionDate = exclusionDtls.exclusionDate;

      // Check whether exclusion date is within the range of
      // start date and end date
      if ((exclusionDate.after(exclusionDateRange.startDate)
        || exclusionDate.equals(exclusionDateRange.startDate))
          && (exclusionDate.before(exclusionDateRange.endDate)
            || exclusionDate.equals(exclusionDateRange.endDate))) {

        // The details struct passed to the getSingleDayEventNode method
        SingleDayEventDetails singleDayEventDetails = new SingleDayEventDetails();

        // Set the attributes of the details struct
        singleDayEventDetails.assign(exclusionDtls);
        singleDayEventDetails.eventType = CALENDAREVENTTYPE.EXCLUSIONDATE;
        singleDayEventDetails.eventDescription = CodeTable.getOneItem(
          METHODOFDELIVERY.TABLENAME, METHODOFDELIVERY.CHEQUE,
          TransactionInfo.getProgramLocale());

        // Append the returned XML string to the main XML string
        buffer.append(getSingleDayEventNode(singleDayEventDetails).nodeString);
      }
    }

    // Close tag for the XML
    buffer.append(CuramCalendarHeaderConst.kCuramCalendarDataFooter);

    // Assign the XML to the return object
    readAllExclusionDateDetails.calendarXMLString = buffer.toString();

    return readAllExclusionDateDetails;
  }

  /**
   * Return a list of dates to the EFT payment calendar on which EFT payments
   * cannot be processed by the organization.
   *
   * @param key
   * The read all exclusion date key facade object
   *
   * @return The read all exclusion date details facade object
   */
  public ReadAllExclusionDateDetails readEFTExclusionDate(
    ReadAllExclusionDateKey key) throws AppException, InformationalException {

    // The object to be returned
    ReadAllExclusionDateDetails readAllExclusionDateDetails = new ReadAllExclusionDateDetails();

    // Get the exclusion date range
    ExclusionDateRange exclusionDateRange = calculateExclusionDateRange(key);

    ExclusionDtls[] dtls = MaintainEFTPmtCalendarFactory.newInstance().getEFTexclusionDates().exclusionDtlsList.dtls.items();

    // Buffer to hold dynamically generated XML
    // BEGIN, CR00023323, SK
    StringBuffer buffer = new StringBuffer(
      CuramCalendarHeaderConst.kCuramCalendarDataHeaderwithQuote);

    buffer.append(
      CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.EFT));
    buffer.append(CuramCalendarHeaderConst.kCloseTag);
    // END, CR00023323

    for (ExclusionDtls exclusionDtls : dtls) {

      Date exclusionDate = exclusionDtls.exclusionDate;

      // Check whether exclusion date is within the range of start date
      // and end date
      if ((exclusionDate.after(exclusionDateRange.startDate)
        || exclusionDate.equals(exclusionDateRange.startDate))
          && (exclusionDate.before(exclusionDateRange.endDate)
            || exclusionDate.equals(exclusionDateRange.endDate))) {

        // The details struct passed to the getSingleDayEventNode method
        SingleDayEventDetails singleDayEventDetails = new SingleDayEventDetails();

        // Set the attributes of the details struct
        singleDayEventDetails.assign(exclusionDtls);
        singleDayEventDetails.eventType = CALENDAREVENTTYPE.EXCLUSIONDATE;
        // BEGIN, CR00163098, JC
        singleDayEventDetails.eventDescription = CodeTable.getOneItem(
          CALENDARTYPE.TABLENAME, CALENDARTYPE.EFT,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
        // Append the returned XML string to the main XML string
        buffer.append(getSingleDayEventNode(singleDayEventDetails).nodeString);
      }
    }

    // Close tag for the XML
    buffer.append(CuramCalendarHeaderConst.kCuramCalendarDataFooter);

    // Assign the XML to the return object
    readAllExclusionDateDetails.calendarXMLString = buffer.toString();

    return readAllExclusionDateDetails;
  }

  /**
   * Return a list of dates to the Invoice calendar on which invoices cannot be
   * issued by the organization.
   *
   * @param key
   * The read all exclusion date key facade object
   *
   * @return The read all exclusion date details facade object
   */
  public ReadAllExclusionDateDetails readInvoiceExclusionDate(
    ReadAllExclusionDateKey key) throws AppException, InformationalException {

    // The object to be returned
    ReadAllExclusionDateDetails readAllExclusionDateDetails = new ReadAllExclusionDateDetails();

    // Get the exclusion date range
    ExclusionDateRange exclusionDateRange = calculateExclusionDateRange(key);

    ExclusionDtls[] dtls = MaintainInvoiceCalendarFactory.newInstance().getInvoiceExclusionDates().exclusionDtlsList.dtls.items();

    // Buffer to hold dynamically generated XML
    // BEGIN, CR00023323, SK
    StringBuffer buffer = new StringBuffer(
      CuramCalendarHeaderConst.kCuramCalendarDataHeaderwithQuote);

    buffer.append(
      CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.INVOICE));
    buffer.append(CuramCalendarHeaderConst.kCloseTag);
    // END, CR00023323

    for (ExclusionDtls exclusionDtls : dtls) {

      Date exclusionDate = exclusionDtls.exclusionDate;

      // Check whether exclusion date is within the range of start date
      // and end date
      if ((exclusionDate.after(exclusionDateRange.startDate)
        || exclusionDate.equals(exclusionDateRange.startDate))
          && (exclusionDate.before(exclusionDateRange.endDate)
            || exclusionDate.equals(exclusionDateRange.endDate))) {

        // The details struct passed to the getSingleDayEventNode method
        SingleDayEventDetails singleDayEventDetails = new SingleDayEventDetails();

        // Set the attributes of the details struct
        singleDayEventDetails.assign(exclusionDtls);
        singleDayEventDetails.eventType = CALENDAREVENTTYPE.EXCLUSIONDATE;
        // BEGIN, CR00163098, JC
        singleDayEventDetails.eventDescription = CodeTable.getOneItem(
          METHODOFDELIVERY.TABLENAME, METHODOFDELIVERY.INVOICE,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
        // Append the returned XML string to the main XML string
        buffer.append(getSingleDayEventNode(singleDayEventDetails).nodeString);
      }
    }

    // Close tag for the XML
    buffer.append(CuramCalendarHeaderConst.kCuramCalendarDataFooter);

    // Assign the XML to the return object
    readAllExclusionDateDetails.calendarXMLString = buffer.toString();

    return readAllExclusionDateDetails;
  }

  /**
   * Return a list of dates to the Voucher payment calendar on which Voucher
   * payments cannot be processed by the organization.
   *
   * @param key
   * The read all exclusion date key facade object
   *
   * @return The read all exclusion date details facade object
   */
  public ReadAllExclusionDateDetails readVoucherExclusionDate(
    ReadAllExclusionDateKey key) throws AppException, InformationalException {

    // The object to be returned
    ReadAllExclusionDateDetails readAllExclusionDateDetails = new ReadAllExclusionDateDetails();

    // Get the exclusion date range
    ExclusionDateRange exclusionDateRange = calculateExclusionDateRange(key);

    ExclusionDtls[] dtls = MaintainVoucherPmtCalendarFactory.newInstance().getVoucherExclusionDates().exclusionDtlsList.dtls.items();

    // Buffer to hold dynamically generated XML
    // BEGIN, CR00023323, SK
    StringBuffer buffer = new StringBuffer(
      CuramCalendarHeaderConst.kCuramCalendarDataHeaderwithQuote);

    buffer.append(
      CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.VOUCHER));
    buffer.append(CuramCalendarHeaderConst.kCloseTag);
    // END, CR00023323

    for (ExclusionDtls exclusionDtls : dtls) {

      Date exclusionDate = exclusionDtls.exclusionDate;

      // Check whether exclusion date is within the range of start date
      // and end date
      if ((exclusionDate.after(exclusionDateRange.startDate)
        || exclusionDate.equals(exclusionDateRange.startDate))
          && (exclusionDate.before(exclusionDateRange.endDate)
            || exclusionDate.equals(exclusionDateRange.endDate))) {

        // The details struct passed to the getSingleDayEventNode method
        SingleDayEventDetails singleDayEventDetails = new SingleDayEventDetails();

        // Set the attributes of the details struct
        singleDayEventDetails.assign(exclusionDtls);
        singleDayEventDetails.eventType = CALENDAREVENTTYPE.EXCLUSIONDATE;
        // BEGIN, CR00163098, JC
        singleDayEventDetails.eventDescription = CodeTable.getOneItem(
          METHODOFDELIVERY.TABLENAME, METHODOFDELIVERY.VOUCHER,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
        // Append the returned XML string to the main XML string
        buffer.append(getSingleDayEventNode(singleDayEventDetails).nodeString);
      }
    }

    // Close tag for the XML
    buffer.append(CuramCalendarHeaderConst.kCuramCalendarDataFooter);

    // Assign the XML to the return object
    readAllExclusionDateDetails.calendarXMLString = buffer.toString();

    return readAllExclusionDateDetails;
  }

  /**
   * This process will add a cash exclusion date.
   *
   * @param key
   * the cash exclusion details to be added
   */
  public void addCashExclusionDate(AddExclusionDateKey key)
    throws AppException, InformationalException {

    // Add the method delivery type to the key
    key.exclusionDatesSummary.deliveryMethodType = METHODOFDELIVERY.CASH;

    // Create the cash exclusion date
    MaintainExclusionDateFactory.newInstance().captureExclusionDate(
      key.exclusionDatesSummary, key.prePaymentIndicator);
  }

  /**
   * Adds exclusion dates for the check calendar specified by the user.
   *
   * @param key
   * The exclusion dates details
   */
  public void addChequeExclusionDate(AddExclusionDateKey key)
    throws AppException, InformationalException {

    // Populate key with delivery method
    key.exclusionDatesSummary.deliveryMethodType = METHODOFDELIVERY.CHEQUE;

    // Add exclusion dates
    MaintainExclusionDateFactory.newInstance().captureExclusionDate(
      key.exclusionDatesSummary, key.prePaymentIndicator);
  }

  /**
   * To add an EFT exclusion date to the FinancialCalendar.
   *
   * @param key
   * The add exclusion date key facade object
   */
  public void addEFTExclusionDate(AddExclusionDateKey key) throws AppException,
      InformationalException {

    // Update the delivery method type
    key.exclusionDatesSummary.deliveryMethodType = METHODOFDELIVERY.EFT;

    // Add the exclusion date to the financial calendar
    MaintainExclusionDateFactory.newInstance().captureExclusionDate(
      key.exclusionDatesSummary, key.prePaymentIndicator);
  }

  /**
   * To add an Invoice exclusion date to the FinancialCalendar.
   *
   * @param key
   * The add exclusion date key facade object
   */
  public void addInvoiceExclusionDate(AddExclusionDateKey key)
    throws AppException, InformationalException {

    // Update the delivery method type
    key.exclusionDatesSummary.deliveryMethodType = METHODOFDELIVERY.INVOICE;

    // Add the exclusion date to the financial calendar
    MaintainExclusionDateFactory.newInstance().captureExclusionDate(
      key.exclusionDatesSummary, key.prePaymentIndicator);
  }

  /**
   * Adds exclusion dates for the voucher calendar specified by the user.
   *
   * @param key
   * The exclusion dates details
   */
  public void addVoucherExclusionDate(AddExclusionDateKey key)
    throws AppException, InformationalException {

    // Populate key with delivery method
    key.exclusionDatesSummary.deliveryMethodType = METHODOFDELIVERY.VOUCHER;

    // Add exclusion dates
    MaintainExclusionDateFactory.newInstance().captureExclusionDate(
      key.exclusionDatesSummary, key.prePaymentIndicator);
  }

  /**
   * This method publishes immediately any changes that are made to the
   * organization.
   */
  public void publishOrganizationChanges() throws AppException,
      InformationalException {

    // reload security cache
    CacheAdminFactory.newInstance().reloadSecurityCache();
  }

  /**
   * This process will return a list of printers.
   *
   * @return A list of printers.
   */
  public listPrintersDetails listPrinters() throws AppException,
      InformationalException {

    // Create a return object
    listPrintersDetails listPrintersDetails = new listPrintersDetails();

    // Create a OrganisationKeyStructRef object
    OrganisationKeyStructRef organisationKeyStructRef = new OrganisationKeyStructRef();

    // BEGIN, CR00168663, LD
    // Set up the key for the operation
    organisationKeyStructRef.organisationID = getOrganizationID();
    // END, CR00168663

    // Read in the list of printers
    listPrintersDetails.resourcesDetailsListRef = AdminResourcesFactory.newInstance().listAssignablePrinters(
      organisationKeyStructRef);

    // Return the list of printers
    return listPrintersDetails;
  }

  /**
   * This method will modify the default printer for the org unit..
   *
   * @param modifyOrgUnitPrinterDetails
   * the org unit and printer details.
   */
  public void modifyOrgUnitPrinter(
    ModifyOrgUnitPrinterDetails modifyOrgUnitPrinterDetails)
    throws AppException, InformationalException {

    // Modify the org unit printer
    OrganisationUnitResourceFactory.newInstance().modifyDefaultPrinter(
      modifyOrgUnitPrinterDetails.modifyOrgUnitPrinterDetails);
  }

  /**
   * Cancels an existing location holiday.
   *
   * @param key
   * The unique identifier for the Location Holiday record.
   */
  public void cancelLocationHoliday(CancelLocationHolidayKey key)
    throws AppException, InformationalException {

    // Cancel a location holiday
    MaintainLocationHolidayFactory.newInstance().cancelLocationHoliday(
      key.maintainLocationHolidayKey);
  }

  /**
   * This method will change the recordStatus of Case Approval Check from Active
   * to Canceled.
   *
   * @param key
   * The key of the user case approval
   */
  public void cancelUserCaseApproval(CancelUserCaseApprovalKey key)
    throws AppException, InformationalException {

    // Cancel the case approval
    CaseApprovalCheckFactory.newInstance().cancel(
      key.cancelCaseApprovalCheckDetails);
  }

  /**
   * Creates a new location holiday for the specified location on the specified
   * date.
   *
   * @param details
   * Contains location holiday details.
   *
   * @return The created location holiday details.
   */
  public CreateLocationHolidayDetails createLocationHoliday(
    MaintainLocationHolidayDetails details) throws AppException,
      InformationalException {

    CreateLocationHolidayDetails createLocationHolidayDetails = new CreateLocationHolidayDetails();

    // Create a new location holiday
    createLocationHolidayDetails.maintainLocationHolidayDetails = MaintainLocationHolidayFactory.newInstance().createLocationHoliday(
      details.maintainLocationHolidayDetails);

    return createLocationHolidayDetails;
  }

  /**
   * Adds case approval check information for a user. For example, this could
   * specify that 10% of cases for a specified user are sent for manual approval
   * checking.
   *
   * @param details
   * Case approval check details for the user.
   */
  public void createUserCaseApproval(CaseApprovalCheckDetails details)
    throws AppException, InformationalException {

    // Create Case Approval Check
    CaseApprovalCheckFactory.newInstance().create(
      details.caseApprovalCheckDetails);
  }

  /**
   * Retrieves summary information for all holidays for the specified location,
   * not including parent locations.
   *
   * @param key
   * Contains location ID that identifies specific location.
   *
   * @return A list of holidays for the specified location.
   */
  public ListLocationHolidayDetails listLocationHoliday(
    ListLocationHolidayKey key) throws AppException, InformationalException {

    // Location admin security manipulation variables
    LocationAdminSecurity locationAdminSecurityObj = LocationAdminSecurityFactory.newInstance();

    // populate the locationKeyRef
    LocationKeyRef locationKeyRef = new LocationKeyRef();

    // Details to be returned
    ListLocationHolidayDetails listLocationHolidayDetails = new ListLocationHolidayDetails();

    // Key to be passed to readLocationContextDescription.
    LocationContextDescriptionKey locationContextDescriptionKey = new LocationContextDescriptionKey();

    // Location admin security manipulation variables
    locationKeyRef.locationID = key.searchHolidayByLocationKey.locationID;

    // BEGIN, CR00342927, SS
    if (!key.userNameOpt.equals(TransactionInfo.getProgramUser())) {
      // check if the user has Maintain SID to view location
      if (!locationAdminSecurityObj.checkMaintainLocationSecurity(locationKeyRef).result
        && !locationAdminSecurityObj.checkReadLocationSecurity(locationKeyRef).result) {
        throw new AppException(
          curam.message.BPOLOCATIONSECURITY.ERR_LOCATIONSECURITY_CHECK_FAILED);
      }
    }
    // END, CR00342927
    locationContextDescriptionKey.locationID = key.searchHolidayByLocationKey.locationID;

    // read the context description
    listLocationHolidayDetails.locationContextDescriptionDetails = readLocationContextDescription(
      locationContextDescriptionKey);

    // Get list of location holiday details
    listLocationHolidayDetails.locationHolidaySearchDetailsList = MaintainLocationHolidayFactory.newInstance().searchLocalHolidaysForLocation(
      key.searchHolidayByLocationKey);

    // Return details
    return listLocationHolidayDetails;
  }

  /**
   * Modifies an existing location holiday.
   *
   * @param details
   * Contains modified location holiday details.
   * @return updatedLocationHolidayIDDetails The UpdatedLocationHolidayIDDetails
   */
  public UpdatedLocationHolidayIDDetails modifyLocationHoliday(
    MaintainLocationHolidayDetails details) throws AppException,
      InformationalException {

    // MaintainLocationHolidayKey object.
    MaintainLocationHolidayKey maintainLocationHolidayKey = new MaintainLocationHolidayKey();

    // Populate the maintainLocationHolidayKey object.
    maintainLocationHolidayKey.locationHolidayID = details.maintainLocationHolidayDetails.locationHolidayID;

    // Modify a location holiday.
    UpdatedLocationHolidayIDDetails updatedLocationHolidayIDDetails = MaintainLocationHolidayFactory.newInstance().modifyLocationHoliday(
      maintainLocationHolidayKey, details.maintainLocationHolidayDetails);

    return updatedLocationHolidayIDDetails;
  }

  /**
   * Modifies case approval check information for a user. For example, this
   * could specify that 10% of cases for a specified user are sent for manual
   * approval checking.
   *
   * @param details
   * The modified case approval check details for the user.
   */
  public void modifyUserCaseApproval(CaseApprovalCheckDetails details)
    throws AppException, InformationalException {

    // Modify a case approval
    CaseApprovalCheckFactory.newInstance().modify(
      details.caseApprovalCheckDetails);
  }

  /**
   * Returns an XML string containing the Location Holidays to be displayed on
   * the calendar.
   *
   * @param key
   * Contains the start date and the calendar view type.
   *
   * @return An XML string containing all holidays for the location.
   */
  public ReadAllLocationHolidayDetails_fo readAllLocationHoliday(
    ReadAllLocationHolidayKey_fo key) throws AppException,
      InformationalException {

    // Location admin security manipulation variables
    LocationAdminSecurity locationAdminSecurityObj = LocationAdminSecurityFactory.newInstance();

    // populate the locationKeyRef
    LocationKeyRef locationKeyRef = new LocationKeyRef();

    // Details to be returned
    ReadAllLocationHolidayDetails_fo readAllLocationHolidayDetails = new ReadAllLocationHolidayDetails_fo();

    // Location holiday search details list object
    LocationHolidaySearchDetailsList locationHolidaySearchDetailsList;

    // Search holiday by location key object
    SearchHolidayByLocationKey searchHolidayByLocationKey = new SearchHolidayByLocationKey();

    // Populate search holiday by location key
    searchHolidayByLocationKey.locationID = key.locationContextDescriptionKey.locationID;

    // Location admin security manipulation variables
    locationKeyRef.locationID = searchHolidayByLocationKey.locationID;

    // check if the user has Maintain SID to view location

    if (!locationAdminSecurityObj.checkMaintainLocationSecurity(locationKeyRef).result
      && !locationAdminSecurityObj.checkReadLocationSecurity(locationKeyRef).result) {
 
      throw new AppException(
        BPOLOCATIONSECURITY.ERR_LOCATIONSECURITY_CHECK_FAILED);
    }

    // Get list of location holiday details
    locationHolidaySearchDetailsList = MaintainLocationHolidayFactory.newInstance().searchLocalHolidaysForLocation(
      searchHolidayByLocationKey);

    // Instance of a read all exclusion date key
    ReadAllExclusionDateKey readAllExclusionDateKey = new ReadAllExclusionDateKey();

    // Populate the attributes
    readAllExclusionDateKey.calendarViewType = key.readAllLocationHolidayKey.calendarViewType;
    readAllExclusionDateKey.startDate = key.readAllLocationHolidayKey.startDate;

    // Get the exclusion date range
    ExclusionDateRange exclusionDateRange = calculateExclusionDateRange(
      readAllExclusionDateKey);

    // Buffer to hold dynamically generated XML
    // BEGIN, CR00023323, SK
    StringBuffer buffer = new StringBuffer(
      CuramCalendarHeaderConst.kCuramCalendarDataHeaderwithQuote);

    // BEGIN, CR00163098, JC
    buffer.append(
      CodeTable.getOneItem(CALENDARTYPE.TABLENAME, CALENDARTYPE.LOCATION,
      TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC
    buffer.append(CuramCalendarHeaderConst.kCloseTag);
    // END, CR00023323
    if (!locationHolidaySearchDetailsList.dtls.isEmpty()) {

      for (int i = 0; i < locationHolidaySearchDetailsList.dtls.size(); i++) {

        LocationHolidaySearchDetails locationHolidaySearchDetails = locationHolidaySearchDetailsList.dtls.item(
          i);

        Date holidayDate = locationHolidaySearchDetails.holidayDate;

        if ((holidayDate.after(exclusionDateRange.startDate)
          || holidayDate.equals(exclusionDateRange.startDate))
            && (holidayDate.before(exclusionDateRange.endDate)
              || holidayDate.equals(exclusionDateRange.endDate))) {

          // The details struct passed to the getSingleDayEventNode method
          SingleDayEventDetails singleDayEventDetails = new SingleDayEventDetails();

          // Set the attributes of the details struct
          singleDayEventDetails.eventDate = locationHolidaySearchDetails.holidayDate;
          singleDayEventDetails.eventID = locationHolidaySearchDetails.locationHolidayID;
          singleDayEventDetails.eventType = CALENDAREVENTTYPE.LOCATIONHOLIDAY;
          // BEGIN,CR00101441 ,GM
          singleDayEventDetails.eventDescription = locationHolidaySearchDetails.holidayName;
          // END, CR00101441
          // Append the returned XML string to the main XML string
          buffer.append(getSingleDayEventNode(singleDayEventDetails).nodeString);
        }
      }
    }

    // Close tag for the XML
    buffer.append(CuramCalendarHeaderConst.kCuramCalendarDataFooter);

    readAllLocationHolidayDetails.readAllLocationHolidayDetails.calendarXMLString = buffer.toString();

    // Key to be passed to readLocationContextDescription.
    LocationContextDescriptionKey locationContextDescriptionKey = new LocationContextDescriptionKey();

    locationContextDescriptionKey.locationID = key.locationContextDescriptionKey.locationID;

    // Read the context description
    readAllLocationHolidayDetails.locationContextDescriptionDetails = readLocationContextDescription(
      locationContextDescriptionKey);

    // Return details
    return readAllLocationHolidayDetails;
  }

  /**
   * Retrieves all information about an existing location holiday.
   *
   * @param key
   * Contains location holiday key that identifies specific location
   * holiday.
   *
   * @return The location holiday details.
   */
  public ReadLocationHolidayDetails readLocationHoliday(
    ReadLocationHolidayKey key) throws AppException, InformationalException {

    // BEGIN, CR00342927, SS
    final ReadLocationHolidayDetails readLocationHolidayDetails = new ReadLocationHolidayDetails();

    if (!key.userNameOpt.equals(TransactionInfo.getProgramUser())) {
      // View a location holiday
      readLocationHolidayDetails.maintainLocationHolidayDetails = MaintainLocationHolidayFactory.newInstance().viewLocationHoliday(
        key.maintainLocationHolidayKey);

    } else {
      final LocationHolidayKey locationHolidayKey = new LocationHolidayKey();

      locationHolidayKey.locationHolidayID = key.maintainLocationHolidayKey.locationHolidayID;
      final LocationHolidayDtls locationHolidayDtls = LocationHolidayFactory.newInstance().read(
        locationHolidayKey);

      // View a location holiday
      readLocationHolidayDetails.maintainLocationHolidayDetails.holidayDate = locationHolidayDtls.holidayDate;
      readLocationHolidayDetails.maintainLocationHolidayDetails.holidayName = locationHolidayDtls.holidayName;
      readLocationHolidayDetails.maintainLocationHolidayDetails.locationHolidayID = locationHolidayDtls.locationHolidayID;
      readLocationHolidayDetails.maintainLocationHolidayDetails.statusCode = locationHolidayDtls.statusCode;
      readLocationHolidayDetails.maintainLocationHolidayDetails.versionNo = locationHolidayDtls.versionNo;
      readLocationHolidayDetails.maintainLocationHolidayDetails.comments = locationHolidayDtls.comments;
    }
    // END, CR00342927
    
    // Key to be passed to readLocationContextDescription.
    LocationContextDescriptionKey locationContextDescriptionKey = new LocationContextDescriptionKey();

    locationContextDescriptionKey.locationID = key.maintainLocationHolidayKey.locationID;

    // Read the context description
    readLocationHolidayDetails.locationContextDescriptionDetails = readLocationContextDescription(
      locationContextDescriptionKey);

    // Return details
    return readLocationHolidayDetails;
  }

  /**
   * Retrieves the details of the specified user case approval check
   * information.
   *
   * @param key
   * Unique identifier for the approval check.
   *
   * @return User case approval details
   */
  public ReadUserCaseApprovalDetails readUserCaseApproval(
    ReadUserCaseApprovalKey key) throws AppException, InformationalException {

    // Object to be returned
    ReadUserCaseApprovalDetails readUserCaseApprovalDetails = new ReadUserCaseApprovalDetails();

    // Read the case approval checks
    readUserCaseApprovalDetails.readCaseApprovalCheckDetails = CaseApprovalCheckFactory.newInstance().read(
      key.caseApprovalCheckKey);

    // Context description key object
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    // Set context description key
    organizationUserContextDescriptionKey.userName = readUserCaseApprovalDetails.readCaseApprovalCheckDetails.caseApprovalCheckDetails.userName;

    // Get context description
    readUserCaseApprovalDetails.userContextDescriptionDetails = readUserContextDescription(
      organizationUserContextDescriptionKey);

    // Return details
    return readUserCaseApprovalDetails;
  }

  /**
   * This method calculates the date range for which exclusion dates are to be
   * returned.
   *
   * @param key
   * Includes the start and end date for the read.
   *
   * @return The date range for the exclusion date read
   */
  @Override
  protected ExclusionDateRange calculateExclusionDateRange(
    ReadAllExclusionDateKey key) throws AppException, InformationalException {

    // Range for exclusion date read
    ExclusionDateRange exclusionDateRange = new ExclusionDateRange();

    if (key.startDate.isZero()) {
      key.startDate = Date.getCurrentDate();
    }

    // Create range based on view type
    if (key.calendarViewType.equals(CALENDARVIEWTYPE.DAY)) {

      // If type is day, start = end
      exclusionDateRange.startDate = key.startDate;
      exclusionDateRange.endDate = key.startDate;
    } else if (key.calendarViewType.equals(CALENDARVIEWTYPE.WEEK)) {

      Calendar date = key.startDate.getCalendar();
      int dayOfWeek = date.get(Calendar.DAY_OF_WEEK);

      // If not Monday
      if (dayOfWeek > 1) {
        date.add(Calendar.DAY_OF_WEEK, 2 - dayOfWeek);
      }
      exclusionDateRange.startDate = new Date(date);

      // BEGIN, CR00238338, PF
      // Set end day seven days from Monday
      date.add(Calendar.DAY_OF_WEEK, CuramConst.gkNumberOfDaysInAWeek);
      // END, CR00238338, PF
      exclusionDateRange.endDate = new Date(date);
    } else if (key.calendarViewType.equals(CALENDARVIEWTYPE.MONTH)) {

      Calendar date = key.startDate.getCalendar();
      int dayOfMonth = date.get(Calendar.DAY_OF_MONTH);

      // If not first day of month
      if (dayOfMonth > 1) {
        date.add(Calendar.DAY_OF_MONTH, 1 - dayOfMonth);
      }
      exclusionDateRange.startDate = new Date(date);

      // Advance one month, subtract 1 day
      date.add(Calendar.MONTH, 1);
      date.add(Calendar.DAY_OF_MONTH, -1);
      exclusionDateRange.endDate = new Date(date);
    } else { // if(key.calendarViewType.equals(CALENDARVIEWTYPE.YEAR))

      Calendar date = key.startDate.getCalendar();
      int dayOfYear = date.get(Calendar.DAY_OF_YEAR);

      // If not the first day of the year
      if (dayOfYear > 1) {
        date.add(Calendar.DAY_OF_YEAR, 1 - dayOfYear);
      }
      exclusionDateRange.startDate = new Date(date);

      // Advance one year, subtract one day
      date.add(Calendar.YEAR, 1);
      date.add(Calendar.DAY_OF_YEAR, -1);
      exclusionDateRange.endDate = new Date(date);
    }

    return exclusionDateRange;

  }

  /**
   * This method returns a single day event in an XML string.
   *
   * @param details
   * Calendar event details.
   *
   * @return XML string containing a single day calendar event
   */
  @Override
  protected SingleDayEventNode getSingleDayEventNode(
    SingleDayEventDetails details) throws AppException,
      InformationalException {

    // The object to be returned
    SingleDayEventNode singleDayEventNode = new SingleDayEventNode();

    // Create root node
    Element singleDayElement = new Element(XmlMetaDataConst.kSingleDayEvent);

    // Create child ID node and add it to the root
    Element childElement = new Element(XmlMetaDataConst.kID);

    childElement.addContent(String.valueOf(details.eventID));
    singleDayElement.addContent(childElement);

    // Format the date
    // BEGIN, CR00023323, SK
    SimpleDateFormat xsDateFormatter = new SimpleDateFormat(kDateFormat);
    // END, CR00023323
    java.util.Date date = details.eventDate.getCalendar().getTime();

    // Create child Date node and add it to the root
    // BEGIN, CR00023323, SK
    childElement = new Element(XmlMetaDataConst.kDate);
    // END, CR00023323
    childElement.addContent(xsDateFormatter.format(date));
    singleDayElement.addContent(childElement);

    // Create child Type node and add it to the root
    // BEGIN, CR00023323, SK
    childElement = new Element(XmlMetaDataConst.kType);
    // END, CR00023323
    childElement.addContent(details.eventType);
    singleDayElement.addContent(childElement);

    // Create child Description node and add it to the root
    // BEGIN, CR00023323, SK
    childElement = new Element(XmlMetaDataConst.kDescription);
    // END, CR00023323
    childElement.addContent(details.eventDescription);
    singleDayElement.addContent(childElement);

    // Output the XML as a string and assign it to the return object
    XMLOutputter outputter = new XMLOutputter();

    singleDayEventNode.nodeString = outputter.outputString(singleDayElement);

    return singleDayEventNode;
  }

  /**
   * Cancels an organization working pattern.
   *
   * @param key
   * The working pattern ID.
   */
  public void cancelOrganizationWorkingPattern(
    CancelOrganizationWorkingPatternKey key) throws AppException,
      InformationalException {

    // Cancel the working pattern
    MaintainWorkingPatternFactory.newInstance().cancelWorkingPattern(
      key.maintainWorkingPatternKey);
  }

  /**
   * Cancels a user working pattern.
   *
   * @param key
   * The working pattern ID.
   */
  public void cancelUserWorkingPattern(CancelUserWorkingPatternKey key)
    throws AppException, InformationalException {

    // Cancel the working pattern
    MaintainWorkingPatternFactory.newInstance().cancelWorkingPattern(
      key.maintainWorkingPatternKey);
  }

  /**
   * Creates a default working pattern for an organization.
   *
   * @param details
   * The working pattern details being entered.
   */
  public void createOrganizationWorkingPattern(
    CreateOrganizationWorkingPatternDetails details) throws AppException,
      InformationalException {

    // Assign the working pattern details
    WorkingPatternDetails workingPatternDetails = new WorkingPatternDetails();

    workingPatternDetails.assign(details.workingPatternDetails);

    // BEGIN, CR00168663, LD
    // Set the organization ID
    workingPatternDetails.organisationID = getOrganizationID();
    // END, CR00168663

    // Assign the pattern start and end times
    workingPatternDetails.activePatternStartTime = details.workingPatternDetails.activePatternStartTime;
    workingPatternDetails.activePatternEndTime = details.workingPatternDetails.activePatternEndTime;

    // Create the working pattern
    MaintainWorkingPatternFactory.newInstance().createDefaultWorkingPattern(
      workingPatternDetails);
  }

  /**
   * Creates a default working pattern for a user.
   *
   * @param details
   * The working pattern details being entered.
   */
  public void createUserWorkingPattern(CreateUserWorkingPatternDetails details)
    throws AppException, InformationalException {

    // Assign the working pattern details
    WorkingPatternDetails workingPatternDetails = new WorkingPatternDetails();

    workingPatternDetails.assign(details.workingPatternDetails);

    // Assign the pattern start and end times
    workingPatternDetails.activePatternStartTime = details.workingPatternDetails.activePatternStartTime;
    workingPatternDetails.activePatternEndTime = details.workingPatternDetails.activePatternEndTime;

    // Create the working pattern
    MaintainWorkingPatternFactory.newInstance().createDefaultWorkingPattern(
      workingPatternDetails);
  }

  /**
   * Reads all existing default working patterns for a user.
   *
   * @param key
   * The working pattern owner ID being read.
   *
   * @return details The list of working patterns returned from the database.
   */
  public ListUserWorkingPatternDetails listUserWorkingPattern(
    ListUserWorkingPatternKey key) throws AppException,
      InformationalException {

    // Details to be returned
    ListUserWorkingPatternDetails listUserWorkingPatternDetails = new ListUserWorkingPatternDetails();

    // Assign the working pattern owner key
    WorkingPatternOwnerKey workingPatternOwnerKey = new WorkingPatternOwnerKey();

    workingPatternOwnerKey.userName = key.userName;

    // Get the list of working patterns.
    curam.core.struct.WorkingPatternDetailsList workingPatternDetailsList = MaintainWorkingPatternFactory.newInstance().readAllWorkingPatterns(
      workingPatternOwnerKey);

    // Copy list to return object
    for (int i = 0; i < workingPatternDetailsList.dtls.size(); i++) {

      WorkingPatternDetailsList workingPatternDetailsList_fo = new WorkingPatternDetailsList();

      workingPatternDetailsList_fo.endDate = workingPatternDetailsList.dtls.item(i).endDate;
      workingPatternDetailsList_fo.startDate = workingPatternDetailsList.dtls.item(i).startDate;
      workingPatternDetailsList_fo.workingPatternID = workingPatternDetailsList.dtls.item(i).workingPatternID;
      workingPatternDetailsList_fo.statusCode = workingPatternDetailsList.dtls.item(i).defaultRecordStatusCode;

      listUserWorkingPatternDetails.workingPatternDetailsList.addRef(
        workingPatternDetailsList_fo);
    }

    // Assign the working pattern context key.
    WorkingPatternContextDescriptionKey workingPatternContextDescriptionKey = new WorkingPatternContextDescriptionKey();

    workingPatternContextDescriptionKey.userName = key.userName;

    // Read context description.
    listUserWorkingPatternDetails.workingPatternContextDescriptionDetails = readWorkingPatternContextDescription(
      workingPatternContextDescriptionKey);

    // Return the details.
    return listUserWorkingPatternDetails;
  }

  /**
   * Modifies existing working pattern for an organization.
   *
   * @param details
   * The working pattern details being modified.
   */
  public void modifyOrganizationWorkingPattern(
    ModifyOrganizationWorkingPatternDetails details) throws AppException,
      InformationalException {

    // Assign the working pattern details
    WorkingPatternDetails workingPatternDetails = new WorkingPatternDetails();

    workingPatternDetails.assign(details.workingPatternDetails);

    // BEGIN, CR00168663, LD
    // Set the organization ID
    workingPatternDetails.organisationID = getOrganizationID();
    // END, CR00168663

    // Assign the pattern start and end times
    workingPatternDetails.activePatternStartTime = details.workingPatternDetails.activePatternStartTime;
    workingPatternDetails.activePatternEndTime = details.workingPatternDetails.activePatternEndTime;

    // Modify the working pattern
    MaintainWorkingPatternFactory.newInstance().modifyDefaultWorkingPattern(
      workingPatternDetails);
  }

  /**
   * Modifies existing working pattern for a user.
   *
   * @param details
   * The working pattern details being modified.
   */
  public void modifyUserWorkingPattern(ModifyUserWorkingPatternDetails details)
    throws AppException, InformationalException {

    // Assign the working pattern details
    WorkingPatternDetails workingPatternDetails = new WorkingPatternDetails();

    workingPatternDetails.assign(details.workingPatternDetails);

    // Assign the pattern start and end times
    workingPatternDetails.activePatternStartTime = details.workingPatternDetails.activePatternStartTime;
    workingPatternDetails.activePatternEndTime = details.workingPatternDetails.activePatternEndTime;

    // Modify the working pattern
    MaintainWorkingPatternFactory.newInstance().modifyDefaultWorkingPattern(
      workingPatternDetails);
  }

  /**
   * Returns default working pattern details and working pattern types for all
   * day indexes for a user.
   *
   * @param key
   * The working pattern ID being read.
   *
   * @return details The working pattern details returned from the database.
   */
  public ReadUserWorkingPatternDetails readUserWorkingPattern(
    ReadUserWorkingPatternKey key) throws AppException,
      InformationalException {

    // Details to be returned
    ReadUserWorkingPatternDetails readUserWorkingPatternDetails = new ReadUserWorkingPatternDetails();

    // Read the working pattern details
    ReadWorkingPatternResult readWorkingPatternResult = MaintainWorkingPatternFactory.newInstance().readWorkingPattern(
      key.maintainWorkingPatternKey);

    // Assign the working pattern details returned
    readUserWorkingPatternDetails.workingPatternDetails.assign(
      readWorkingPatternResult.details);

    // Get the hour and minute part of the start and end times
    readUserWorkingPatternDetails.workingPatternDetails.activePatternStartTime = readWorkingPatternResult.details.activePatternStartTime;
    readUserWorkingPatternDetails.workingPatternDetails.activePatternEndTime = readWorkingPatternResult.details.activePatternEndTime;

    // Assign the working pattern details for each day
    for (int i = 0; i < readWorkingPatternResult.typesList.dtls.size(); i++) {

      WorkingPatternTypeDetails workingPatternTypeDetails = new WorkingPatternTypeDetails();

      // Convert start time value to string
      // BEGIN, CR00023323, SK
      workingPatternTypeDetails.stringActivePatternStartTime = Locale.getFormattedDateTime(
        readWorkingPatternResult.typesList.dtls.item(i).startTime, kTimeFormat);

      // Convert end time value to string
      workingPatternTypeDetails.stringActivePatternEndTime = Locale.getFormattedDateTime(
        readWorkingPatternResult.typesList.dtls.item(i).endTime, kTimeFormat);
      // END CR00023323
      workingPatternTypeDetails.dayNumber = readWorkingPatternResult.typesList.dtls.item(i).dayNumber;
      workingPatternTypeDetails.nsVersionNo = readWorkingPatternResult.typesList.dtls.item(i).nsVersionNo;
      workingPatternTypeDetails.typeCode = readWorkingPatternResult.typesList.dtls.item(i).typeCode;

      readUserWorkingPatternDetails.workingPatternTypeDetailsList.addRef(
        workingPatternTypeDetails);
    }

    // Set the working pattern context key
    WorkingPatternContextDescriptionKey workingPatternContextDescriptionKey = new WorkingPatternContextDescriptionKey();

    workingPatternContextDescriptionKey.userName = readWorkingPatternResult.details.userName;

    // Read context description
    readUserWorkingPatternDetails.workingPatternContextDescriptionDetails = readWorkingPatternContextDescription(
      workingPatternContextDescriptionKey);

    // Return the details
    return readUserWorkingPatternDetails;
  }

  /**
   * This method creates or modifies non-standard working pattern or changes
   * pattern type for the day for a user.
   *
   * @param details
   * The non standard working pattern details.
   */
  public void createModifyUserNonStandardWorkingPattern(
    MaintainNonStandardWorkingPatternDetails details) throws AppException,
      InformationalException {

    // Maintain working pattern object
    MaintainWorkingPattern maintainWorkingPatternObj = MaintainWorkingPatternFactory.newInstance();

    // The key to read the working pattern for the specified day
    NSPatternByDayIndexKey nsPatternByDayIndexKey = new NSPatternByDayIndexKey();

    // Set the key
    nsPatternByDayIndexKey.dayNumber = details.dayNumber;
    nsPatternByDayIndexKey.workingPatternID = details.workingPatternID;

    // Read the working pattern details for the specified day number
    WorkingPatternDetails workingPatternDetails = maintainWorkingPatternObj.readWorkingPatternForDay(
      nsPatternByDayIndexKey);

    // Set the new working pattern details
    workingPatternDetails.dayNumber = details.dayNumber;
    workingPatternDetails.typeCode = details.typeCode;

    // Assign the pattern start and end times
    workingPatternDetails.activePatternStartTime = details.activePatternStartTime;
    workingPatternDetails.activePatternEndTime = details.activePatternEndTime;

    // Create the working pattern
    maintainWorkingPatternObj.createModifyWorkingPatternForDay(
      workingPatternDetails);
  }

  /**
   * Reads all existing default working patterns for an organization.
   *
   * @return The list of working patterns returned from the database.
   */
  public ListOrganizationWorkingPatternDetails listOrganizationWorkingPattern()
    throws AppException, InformationalException {

    // Details to be returned
    ListOrganizationWorkingPatternDetails listOrganizationWorkingPatternDetails = new ListOrganizationWorkingPatternDetails();

    // Set the organization ID
    WorkingPatternOwnerKey workingPatternOwnerKey = new WorkingPatternOwnerKey();

    // BEGIN, CR00168663, LD
    // Set organization id
    workingPatternOwnerKey.organisationID = getOrganizationID();
    // END, CR00168663

    // Get the list of working patterns
    curam.core.struct.WorkingPatternDetailsList workingPatternDetailsList = MaintainWorkingPatternFactory.newInstance().readAllWorkingPatterns(
      workingPatternOwnerKey);

    // Copy list to return object
    for (int i = 0; i < workingPatternDetailsList.dtls.size(); i++) {

      WorkingPatternDetailsList workingPatternDetailsList_fo = new WorkingPatternDetailsList();

      workingPatternDetailsList_fo.endDate = workingPatternDetailsList.dtls.item(i).endDate;
      workingPatternDetailsList_fo.startDate = workingPatternDetailsList.dtls.item(i).startDate;
      workingPatternDetailsList_fo.workingPatternID = workingPatternDetailsList.dtls.item(i).workingPatternID;
      workingPatternDetailsList_fo.statusCode = workingPatternDetailsList.dtls.item(i).defaultRecordStatusCode;

      listOrganizationWorkingPatternDetails.workingPatternDetailsList.addRef(
        workingPatternDetailsList_fo);
    }

    // Return the details
    return listOrganizationWorkingPatternDetails;
  }

  /**
   * This method creates or modifies non-standard working pattern or changes
   * pattern type for the day for an organization.
   *
   * @param details
   * The non standard working pattern details.
   */
  public void createModifyOrganizationNonStandardWorkingPattern(
    MaintainNonStandardWorkingPatternDetails details) throws AppException,
      InformationalException {

    // Maintain working pattern object
    MaintainWorkingPattern maintainWorkingPatternObj = MaintainWorkingPatternFactory.newInstance();

    // The key to read the working pattern for the specified day
    NSPatternByDayIndexKey nsPatternByDayIndexKey = new NSPatternByDayIndexKey();

    // Set the key
    nsPatternByDayIndexKey.dayNumber = details.dayNumber;
    nsPatternByDayIndexKey.workingPatternID = details.workingPatternID;

    // Read the working pattern details for the specified day number
    WorkingPatternDetails workingPatternDetails = maintainWorkingPatternObj.readWorkingPatternForDay(
      nsPatternByDayIndexKey);

    // Set the new working pattern details
    workingPatternDetails.dayNumber = details.dayNumber;
    workingPatternDetails.typeCode = details.typeCode;

    // Assign the pattern start and end times
    workingPatternDetails.activePatternStartTime = details.activePatternStartTime;
    workingPatternDetails.activePatternEndTime = details.activePatternEndTime;

    // Create the working pattern
    maintainWorkingPatternObj.createModifyWorkingPatternForDay(
      workingPatternDetails);
  }

  /**
   * Returns default working pattern details and working pattern types for all
   * day indexes for an organization.
   *
   * @param key
   * The working pattern ID being read.
   *
   * @return details The working pattern details returned from the database.
   */
  public ReadOrganizationWorkingPatternDetails readOrganizationWorkingPattern(
    ReadOrganizationWorkingPatternKey key) throws AppException,
      InformationalException {

    // Returned details
    ReadOrganizationWorkingPatternDetails readOrganizationWorkingPatternDetails = new ReadOrganizationWorkingPatternDetails();

    // Read the Working Pattern details
    ReadWorkingPatternResult readWorkingPatternResult = MaintainWorkingPatternFactory.newInstance().readWorkingPattern(
      key.maintainWorkingPatternKey);

    // Assign the details returned from the database
    readOrganizationWorkingPatternDetails.readWorkingPatternResult.assign(
      readWorkingPatternResult.details);

    // Get start and end times
    readOrganizationWorkingPatternDetails.readWorkingPatternResult.activePatternStartTime = readWorkingPatternResult.details.activePatternStartTime;

    readOrganizationWorkingPatternDetails.readWorkingPatternResult.activePatternEndTime = readWorkingPatternResult.details.activePatternEndTime;

    // Assign the working pattern details for each day
    for (int i = 0; i < readWorkingPatternResult.typesList.dtls.size(); i++) {

      WorkingPatternTypeDetails workingPatternTypeDetails = new WorkingPatternTypeDetails();

      // BEGIN, CR00023323, SK
      // Convert start time value to string
      workingPatternTypeDetails.stringActivePatternStartTime = Locale.getFormattedDateTime(
        readWorkingPatternResult.typesList.dtls.item(i).startTime, kTimeFormat);

      // Convert end time value to string
      workingPatternTypeDetails.stringActivePatternEndTime = Locale.getFormattedDateTime(
        readWorkingPatternResult.typesList.dtls.item(i).endTime, kTimeFormat);
      // END CR00023323
      workingPatternTypeDetails.dayNumber = readWorkingPatternResult.typesList.dtls.item(i).dayNumber;
      workingPatternTypeDetails.nsVersionNo = readWorkingPatternResult.typesList.dtls.item(i).nsVersionNo;
      workingPatternTypeDetails.typeCode = readWorkingPatternResult.typesList.dtls.item(i).typeCode;

      readOrganizationWorkingPatternDetails.workingPatternTypeDetailsList.addRef(
        workingPatternTypeDetails);
    }

    // Return the details
    return readOrganizationWorkingPatternDetails;
  }

  /**
   * This method reads the non-standard working pattern details for a specific
   * day for an organization.
   *
   * @param key
   * The working pattern ID and day number.
   *
   * @return details The non working pattern details.
   */
  public ReadOrganizationNonStandardWorkingPatternDetails readOrganizationNonStandardWorkingPattern(
    ReadOrganizationNonStandardWorkingPatternKey key) throws AppException,
      InformationalException {

    // The returned details
    ReadOrganizationNonStandardWorkingPatternDetails readOrganizationNonStandardWorkingPatternDetails = new ReadOrganizationNonStandardWorkingPatternDetails();

    // Read the working pattern details for the day.
    WorkingPatternDetails workingPatternDetails = MaintainWorkingPatternFactory.newInstance().readWorkingPatternForDay(
      key.nSPatternByDayIndexKey);

    // Get start and end times
    readOrganizationNonStandardWorkingPatternDetails.nonStandardDetails.startTime = workingPatternDetails.activePatternStartTime;
    readOrganizationNonStandardWorkingPatternDetails.nonStandardDetails.endTime = workingPatternDetails.activePatternEndTime;
    // Get the non standard type
    readOrganizationNonStandardWorkingPatternDetails.nonStandardDetails.typeCode = workingPatternDetails.typeCode;

    // Return the non standard details returned from the database
    return readOrganizationNonStandardWorkingPatternDetails;
  }

  /**
   * This method reads the non-standard working pattern details for a specific
   * day for a user.
   *
   * @param key
   * The working pattern ID and day number.
   *
   * @return details The non working pattern details.
   */
  public ReadUserNonStandardWorkingPatternDetails readUserNonStandardWorkingPattern(
    ReadUserNonStandardWorkingPatternKey key) throws AppException,
      InformationalException {

    // The returned details
    ReadUserNonStandardWorkingPatternDetails readUserNonStandardWorkingPatternDetails = new ReadUserNonStandardWorkingPatternDetails();

    // Read the working pattern details for the day
    WorkingPatternDetails workingPatternDetails = MaintainWorkingPatternFactory.newInstance().readWorkingPatternForDay(
      key.nSPatternByDayIndexKey);

    // Get start and end times
    readUserNonStandardWorkingPatternDetails.nonStandardDetails.startTime = workingPatternDetails.activePatternStartTime;
    readUserNonStandardWorkingPatternDetails.nonStandardDetails.endTime = workingPatternDetails.activePatternEndTime;
    // Get the non standard type
    readUserNonStandardWorkingPatternDetails.nonStandardDetails.typeCode = workingPatternDetails.typeCode;

    // Set the working pattern context key
    WorkingPatternContextDescriptionKey workingPatternContextDescriptionKey = new WorkingPatternContextDescriptionKey();

    workingPatternContextDescriptionKey.userName = workingPatternDetails.userName;

    // Read context description
    readUserNonStandardWorkingPatternDetails.workingPatternContextDescriptionDetails = readWorkingPatternContextDescription(
      workingPatternContextDescriptionKey);

    // Return the non standard details returned from the database
    return readUserNonStandardWorkingPatternDetails;
  }

  /**
   * Cancels an Admin Integrated Case.
   *
   * @param key
   * Key to cancel the Admin Integrated Case.
   */
  public void cancelAdminIntegratedCase(CancelAdminIntegratedCaseKey_fo key)
    throws AppException, InformationalException {

    CancelAdminIntegratedCaseKey cancelAdminIntegratedCaseKey = new CancelAdminIntegratedCaseKey();

    // Assign key details to cancel the record
    cancelAdminIntegratedCaseKey.assign(key);

    // Cancel the Admin Integrated Case
    MaintainAdminIntegratedCaseFactory.newInstance().cancelAdminIntegratedCase(
      cancelAdminIntegratedCaseKey);
  }

  /**
   * @param details
   * Details to create the Admin Integrated Case.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createAdminIntegratedCase1()}. New method contains additional
   * attributes to indicate if cases of this integrated case type are displayed
   * in the participants programs list, in My Cases filter and in Case Search
   * filter.
   *
   * Creates an Admin Integrated Case.
   */
  @Deprecated
  public void createAdminIntegratedCase(CreateAdminIntegratedCaseDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00173421, ZV
    CreateAdminIntegratedCaseDetails1 createAdminIntegratedCaseDetails1 = new CreateAdminIntegratedCaseDetails1();

    createAdminIntegratedCaseDetails1.assign(details);

    createAdminIntegratedCaseDetails1.myCasesFilterInd = true;
    createAdminIntegratedCaseDetails1.caseSearchFilterInd = true;

    createAdminIntegratedCase1(createAdminIntegratedCaseDetails1);

    details.assign(createAdminIntegratedCaseDetails1);
    // END, CR00173421
  }

  /**
   * Returns a list of active Admin Integrated Case details.
   *
   * @return A list of active Admin Integrated Case details.
   */
  public ListActiveAdminIntegratedCaseDetails listActiveAdminIntegratedCase()
    throws AppException, InformationalException {

    // Create return object
    ListActiveAdminIntegratedCaseDetails listActiveAdminIntegratedCaseDetails = new ListActiveAdminIntegratedCaseDetails();

    // Retrieve list of active Admin Integrated Case records
    listActiveAdminIntegratedCaseDetails.listAdminIntegratedCaseDetails.assign(
      MaintainAdminIntegratedCaseFactory.newInstance().listActiveAdminIntegratedCase());

    return listActiveAdminIntegratedCaseDetails;
  }

  /*
   * @deprecated Since Curam 6.0, replaced with
   * {@link #modifyAdminIntegratedCase1()}. New method contains additional
   * attributes to indicate if cases of this integrated case type are displayed
   * in the participants programs list, in My Cases filter and in Case Search
   * filter.
   *
   * Modifies an Admin Integrated Case.
   *
   * @param details
   * Details to modify the Admin Integrated Case.
   */
  @Deprecated
  public void modifyAdminIntegratedCase(ModifyAdminIntegratedCaseDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00173421, ZV
    ModifyAdminIntegratedCaseDetails1 modifyAdminIntegratedCaseDetails1 = new ModifyAdminIntegratedCaseDetails1();

    modifyAdminIntegratedCaseDetails1.assign(details);

    modifyAdminIntegratedCaseDetails1.details.myCasesFilterInd = true;
    modifyAdminIntegratedCaseDetails1.details.caseSearchFilterInd = true;

    modifyAdminIntegratedCase1(modifyAdminIntegratedCaseDetails1);
    // END, CR00173421
  }

  /**
   * @param key
   * Key to read details of an Admin Integrated Case.
   *
   * @return Details of the Admin Integrated Case.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #readAdminIntegratedCase1()}. New method reads additional attributes
   * which indicates if cases of this integrated case type are displayed in the
   * participants programs list, in My Cases filter and in Case Search filter.
   *
   * Reads details of Admin Integrated Case.
   */
  @Deprecated
  public ReadAdminIntegratedCaseDetails readAdminIntegratedCase(
    ReadAdminIntegratedCaseKey_fo key) throws AppException,
      InformationalException {

    // Create return object
    ReadAdminIntegratedCaseDetails readAdminIntegratedCaseDetails = new ReadAdminIntegratedCaseDetails();

    // BEGIN, CR00173421, ZV
    ReadAdminIntegratedCaseDetails1 readAdminIntegratedCaseDetails1 = readAdminIntegratedCase1(
      key);

    readAdminIntegratedCaseDetails.assign(readAdminIntegratedCaseDetails1);
    // END, CR00173421

    return readAdminIntegratedCaseDetails;
  }

  /**
   * Returns a list of all Admin Integrated Case records.
   *
   * @return A list of all Admin Integrated Case records.
   */
  public ListAllAdminIntegratedCaseDetails listAllAdminIntegratedCase()
    throws AppException, InformationalException {

    // Create return object
    ListAllAdminIntegratedCaseDetails listAllAdminIntegratedCaseDetails = new ListAllAdminIntegratedCaseDetails();

    // Retrieve list of all Admin Integrated Case records
    listAllAdminIntegratedCaseDetails.listAllAdminIntegratedCaseDetails.assign(
      MaintainAdminIntegratedCaseFactory.newInstance().listAdminIntegratedCase());

    return listAllAdminIntegratedCaseDetails;
  }

  /**
   * Presentation layer operation to assign a resource to an org unit.
   *
   * @param addOrgUnitResourceDetails
   * Information required to assign a resource to an org unit.
   */
  public void assignResourceToOrgUnit(
    AddOrgUnitResourceDetails addOrgUnitResourceDetails) throws AppException,
      InformationalException {

    // Assign the resource to the org unit
    OrganisationUnitResourceFactory.newInstance().addResource(
      addOrgUnitResourceDetails.addOrganisationUnitResourceDetails);
  }

  /**
   * Presentation layer operation to list resources for an org unit.
   *
   * @param listResourcesForOrgUnitKey
   * OrgUnitID of the org unit whose resources are to be listed.
   *
   * @return A list of resources for the org unit.
   */
  public ListResourcesForOrgUnitDetails listResourcesForOrgUnit(
    ListResourcesForOrgUnitKey listResourcesForOrgUnitKey)
    throws AppException, InformationalException {

    // Return struct
    ListResourcesForOrgUnitDetails listResourcesForOrgUnitDetails = new ListResourcesForOrgUnitDetails();

    // List the resources
    listResourcesForOrgUnitDetails.orgUnitResourceDetailsListRef = OrganisationUnitResourceFactory.newInstance().listResource(
      listResourcesForOrgUnitKey.orgUnitKeyRef.organisationUnitKey);

    // Key required to read the OrgUnit Context Description.
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitKey = listResourcesForOrgUnitKey.orgUnitKeyRef;

    // Read the context
    listResourcesForOrgUnitDetails.description = readOrganisationUnitContextDescription(
      organisationUnitKey);

    return listResourcesForOrgUnitDetails;
  }

  /**
   * Presentation layer operation to remove a resource from an org unit.
   *
   * @param removeResourceFromOrgUnitDetails
   * Information required to remove a resource from an org unit.
   */
  public void removeResourceFromOrgUnit(
    RemoveResourceFromOrgUnitDetails removeResourceFromOrgUnitDetails)
    throws AppException, InformationalException {

    OrganisationUnitResourceFactory.newInstance().removeResource(
      removeResourceFromOrgUnitDetails.removeOrgUnitResourceKey);
  }

  // __________________________________________________________________________
  /**
   * Presentation layer operation to assign a location from an org unit.
   *
   * @param key
   * Information required to assign a location from an org unit.
   */
  public void assignLocationtoOrgUnit(OrgUnitLocationDetails key)
    throws AppException, InformationalException {

    // Assign the location to the org unit
    OrganisationUnitFactory.newInstance().addLocation(key.orgUnitLocation);
  }

  // __________________________________________________________________________
  /**
   * Presentation layer operation to remove a location from an org unit.
   *
   * @param key
   * Information required to remove a location from an org unit.
   */
  public void removeLocationfromOrgUnit(OrgUnitLocationDetails key)
    throws AppException, InformationalException {

    // Assign the location to the org unit
    OrganisationUnitFactory.newInstance().removeLocation(key.orgUnitLocation);
  }

  /**
   * Presentation layer operation to list all available resources.
   *
   * @return A list of all available resources.
   */
  public ListResourcesInOperationDetails listResourcesInOperation()
    throws AppException, InformationalException {

    // Return information struct.
    ListResourcesInOperationDetails listResourcesInOperationDetails = new ListResourcesInOperationDetails();

    // list the resources.
    listResourcesInOperationDetails.resourcesDetailsListRef = AdminResourcesFactory.newInstance().listResourcesInOperation();

    return listResourcesInOperationDetails;
  }

  /**
   * Presentation layer operation to list locations within a location.
   *
   * @param key
   * LocationID of the location containing other locations.
   *
   * @return Locations within a location.
   */
  public ListChildLocationsDetails listChildLocations(ListChildLocationsKey key)
    throws AppException, InformationalException {

    // Return struct
    ListChildLocationsDetails listChildLocationsDetails = new ListChildLocationsDetails();

    // List the locations within this location
    listChildLocationsDetails.locationsList = AdminLocationFactory.newInstance().listChildLocations(
      key.locationKeyRef);

    // Context description key
    LocationContextDescriptionKey locationContextDescriptionKey = new LocationContextDescriptionKey();

    // Set the key value
    locationContextDescriptionKey.locationID = key.locationKeyRef.locationID;

    // Read the location context description
    listChildLocationsDetails.locationContextDescriptionDetails = readLocationContextDescription(
      locationContextDescriptionKey);

    return listChildLocationsDetails;
  }

  /**
   * Presentation layer operation to list resources for a location.
   *
   * @param key
   * LocationID of the location containing resources.
   *
   * @return Resources within a location.
   */
  public ListResourcesForLocationDetails listResourcesForLocation(
    ListResourcesForLocationKey key) throws AppException,
      InformationalException {

    // Return struct
    ListResourcesForLocationDetails listResourcesForLocationDetails = new ListResourcesForLocationDetails();

    // List the resources for the location
    listResourcesForLocationDetails.resourcesDetailsListRef = AdminResourcesFactory.newInstance().listResourcesForLocation(
      key.locationKeyRef);

    // Context Description key
    LocationContextDescriptionKey locationContextDescriptionKey = new LocationContextDescriptionKey();

    // Set the key value
    locationContextDescriptionKey.locationID = key.locationKeyRef.locationID;

    // Read the context description
    listResourcesForLocationDetails.locationContextDescriptionDetails = readLocationContextDescription(
      locationContextDescriptionKey);

    return listResourcesForLocationDetails;
  }

  /**
   * This method will modify the default printer for the user.
   *
   * @param details
   * The details of the new default printer
   */
  public void modifyUserPrinter(ModifyUserPrinterDetails details)
    throws AppException, InformationalException {

    // Modify the user printer
    AdminUserFactory.newInstance().modifyUserPrinter(
      details.modifyUserPrinterDetails);
  }

  /**
   * Reads the description of the job.
   *
   * @param jobKey
   * job identifier
   *
   * @return job context description
   */
  @Override
  protected JobContextDescriptionDetails readJobContextDescription(JobKey jobKey)
    throws AppException, InformationalException {

    // Details to be returned.
    JobContextDescriptionDetails jobContextDescriptionDetails = new JobContextDescriptionDetails();

    // Read job details
    JobName jobName = JobFactory.newInstance().readJobName(jobKey.jobKey.jobKey);

    // Set the context description
    jobContextDescriptionDetails.description = jobName.name;

    // return the details
    return jobContextDescriptionDetails;
  }

  /**
   * Reads the description of the organization structure.
   *
   * @param key
   * organization structure identifier
   *
   * @return organization structure context description
   */
  @Override
  protected OrganisationStructureContextDescriptionDetails readOrganisationStructureContextDescription(
    OrganisationStructureKey key) throws AppException, InformationalException {

    // Details to be returned
    OrganisationStructureContextDescriptionDetails organisationStructureContextDescriptionDetails = new OrganisationStructureContextDescriptionDetails();

    OrganisationStructureName organisationStructureName = curam.core.sl.entity.fact.OrganisationStructureFactory.newInstance().readOrgStructureName(
      key.organisationStructureKey.organisationStructureKey);

    // Set the context description
    organisationStructureContextDescriptionDetails.description = organisationStructureName.name;

    // Return the details
    return organisationStructureContextDescriptionDetails;
  }

  /**
   * Reads the description of the organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return organization unit context description
   */
  @Override
  protected OrganisationUnitContextDescriptionDetails readOrganisationUnitContextDescription(
    OrganisationUnitKey key) throws AppException, InformationalException {

    // Details to be returned
    OrganisationUnitContextDescriptionDetails organisationUnitContextDescriptionDetails = new OrganisationUnitContextDescriptionDetails();

    OrganisationUnitName organisationUnitName = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance().readOrgUnitName(
      key.organisationUnitKey.organisationUnitKey);

    // Set the context description
    organisationUnitContextDescriptionDetails.description = organisationUnitName.name;

    // Return the details
    return organisationUnitContextDescriptionDetails;
  }

  /**
   * Reads the description of the position.
   *
   * @param key
   * position identifier
   *
   * @return position context description
   */
  @Override
  protected PositionContextDescriptionDetails readPositionContextDescription(
    PositionKey key) throws AppException, InformationalException {

    // Details to be returned.
    PositionContextDescriptionDetails positionContextDescriptionDetails = new PositionContextDescriptionDetails();

    // Read position name
    PositionName positionName = curam.core.sl.entity.fact.PositionFactory.newInstance().readPositionName(
      key.positionKey.positionKey);

    // Set the context description
    positionContextDescriptionDetails.description = positionName.name;

    // Return the details
    return positionContextDescriptionDetails;
  }

  // BEGIN, CR00250660, ZV
  
  /**
   * Method to list all organization structures for organization.
   *
   * @return list of all organization structures for organization
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listOrganisationStructure1()}
   */
  @Deprecated
  public ListOrganisationStructureDetails listOrganisationStructure()
    throws AppException, InformationalException {

    // Variables for reading organization structure details list
    curam.core.sl.struct.ListOrganisationStructureKey listOrganisationStructureKey = new curam.core.sl.struct.ListOrganisationStructureKey();

    // Return variable for organization structure details list
    ListOrganisationStructureDetails listOrganisationStructureDetails = new ListOrganisationStructureDetails();

    // Assign details to key to read all organization structure details list
    listOrganisationStructureKey.allInd = true;

    // Read all organization structure details list
    listOrganisationStructureDetails.organisationStructureDetailsList = curam.core.sl.fact.OrganisationStructureFactory.newInstance().listOrganisationStructure(
      listOrganisationStructureKey);

    // Return organization structure details list
    return listOrganisationStructureDetails;
  }

  /**
   * Method to view organization structure details.
   * @param key
   * organization structure identifier
   *
   * @return organization structure details
   * @deprecated Since Curam 6.0, replaced by
   * {@link #viewOrganisationStructure1()}
   */
  // END, CR00250660
  @Deprecated
  public ViewOrganisationStructureDetails viewOrganisationStructure(
    OrganisationStructureKey key) throws AppException, InformationalException {

    // Return variable for organization structure details
    ViewOrganisationStructureDetails viewOrganisationStructureDetails = new ViewOrganisationStructureDetails();

    // Read organization structure details
    viewOrganisationStructureDetails.organisationStructureDetails = curam.core.sl.fact.OrganisationStructureFactory.newInstance().viewOrganisationStructure(
      key.organisationStructureKey);

    // Return organization structure details
    return viewOrganisationStructureDetails;
  }

  /**
   * Method to activate organization structure.
   *
   * @param activateOrgStructureKey
   * organization structure identifier
   */
  public void activateOrganisationStructure(
    ActivateOrgStructureKey activateOrgStructureKey) throws AppException,
      InformationalException {

    // Activate organization structure
    curam.core.sl.fact.OrganisationStructureFactory.newInstance().activateOrganisationStructure(
      activateOrgStructureKey.activateOrgStructureKey);
  }

  /**
   * Method to cancel organization structure.
   *
   * @param cancelOrgStructureKey
   * organization structure identifier
   */
  public void cancelOrganisationStructure(
    CancelOrgStructureKey cancelOrgStructureKey) throws AppException,
      InformationalException {

    // Cancel organization structure
    curam.core.sl.fact.OrganisationStructureFactory.newInstance().cancelOrganisationStructure(
      cancelOrgStructureKey.cancelOrgStructureKey);
  }

  // BEGIN, CR00242411, KX
  
  /**
   * Method to list organization units for organization structure.
   *
   * @param key
   * organization structure identifier
   *
   * @return list of organization units
   * @deprecated Since Curam 6.0, replaced with
   * {@link Organization#listOrgUnitForOrgStructureWithVersionNo(OrganisationStructureKey)}. As
   * part of the new API versionNo fields must be returned in lists which allow items to be deleted
   * See release note: CR00242411.
   */
  @Deprecated
  public ListOrganisationUnitForOrgStructureDetails listOrgUnitForOrgStructure(
    OrganisationStructureKey key) throws AppException, InformationalException {

    ListOrganisationUnitForOrgStructureDetails listOrganisationUnitForOrgStructureDetails = new ListOrganisationUnitForOrgStructureDetails();
    ListOrganisationUnitForOrgStructureWithVersionNoDetails listOrganisationUnitForOrgStructureWithVersionNoDetails = listOrgUnitForOrgStructureWithVersionNo(
      key);

    listOrganisationUnitForOrgStructureDetails.assign(
      listOrganisationUnitForOrgStructureWithVersionNoDetails);
    // Return organization unit details list
    return listOrganisationUnitForOrgStructureDetails;
  }

  /**
   * This method replaces the deprecated method
   * {@link #listOrgUnitForOrgStructure(OrganisationStructureKey)}
   * Method to list organization units for organization structure.
   *
   * @param key
   * organization structure identifier
   *
   * @return list of organization units
   */

  public ListOrganisationUnitForOrgStructureWithVersionNoDetails listOrgUnitForOrgStructureWithVersionNo(
    OrganisationStructureKey key) throws AppException, InformationalException {

    // Variables for reading organization unit details list
    ListOrganisationUnitsKey listOrganisationUnitsKey = new ListOrganisationUnitsKey();

    // Return variable for organization unit details list
    ListOrganisationUnitForOrgStructureWithVersionNoDetails listOrganisationUnitForOrgStructureWithVersionNoDetails = new
      ListOrganisationUnitForOrgStructureWithVersionNoDetails();

    // Assign details to key to read organization unit details list for
    // organization structure
    listOrganisationUnitsKey.allInd = false;
    listOrganisationUnitsKey.orgStructureID = key.organisationStructureKey.organisationStructureKey.organisationStructureID;

    // Read organization unit details list for organization structure
    listOrganisationUnitForOrgStructureWithVersionNoDetails.orgUnitList = OrganisationUnitFactory.newInstance().listOrganisationUnitsWithVersionNo(
      listOrganisationUnitsKey);

    // Read organization structure context description
    listOrganisationUnitForOrgStructureWithVersionNoDetails.orgStructureContextDescription = readOrganisationStructureContextDescription(
      key);

    // Return organization unit details list
    return listOrganisationUnitForOrgStructureWithVersionNoDetails;
  }

  // BEGIN, CR00388421, AC
  /**
   * Method to find if the organization unit search is enabled.
   *
   * @return result true if the organization search is enabled else false.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public OrganisationUnitSearchInd isOrganisationUnitSearchEnabled()
    throws AppException, InformationalException {
    OrganisationUnitSearchInd organisationUnitSearchInd = new OrganisationUnitSearchInd();
    final String organisationUnitSearch = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_ORGANISATIONUNIT_SEARCH_ENABLED);

    if (organisationUnitSearch.equalsIgnoreCase(CuramConst.gkYes)) {
      organisationUnitSearchInd.OrganisationUnitSearchInd = true;
    } else {
      organisationUnitSearchInd.OrganisationUnitSearchInd = false;
    }
    return organisationUnitSearchInd;
  }

  /**
   * Retrieves a list of organization unit for an organization with a given
   * search criteria.
   *
   * @param organizationUnitSearchCriteria
   * search criteria to search the organization unit.
   *
   * @return list of organization units.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public OrgUnitDetailsList searchOrganisationUnitDetails(
    final curam.core.facade.struct.OrgUnitSearchCriteria key,
    ActionIDProperty actionIDProperty) throws AppException,
      InformationalException {
    curam.core.facade.struct.OrgUnitDetailsList viewOrgUnitStructWithVersionNoList = new OrgUnitDetailsList();

    if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      return viewOrgUnitStructWithVersionNoList;
    }
    if (CuramConst.gkEmpty.equals(key.dtls.locationName)
      && CuramConst.gkEmpty.equals(key.dtls.name)
      && CuramConst.gkEmpty.equals(key.dtls.statusCode)
      && CuramConst.gkEmpty.equals(key.dtls.businessTypeCode)) {
      throw (new AppException(BPOORGANISATIONUNIT.ERR_ORGUNIT_FV_NAME_EMPTY));
    }
    final OrgUnitSearchCriteria organisationSearchCriteria = new OrgUnitSearchCriteria();

    key.dtls.businessTypeCode.equals(CuramConst.gkNull);
    organisationSearchCriteria.assign(key);
    if (key.dtls.businessTypeCode.equals(CuramConst.gkNull)) {
      organisationSearchCriteria.businessTypeCode = key.dtls.businessTypeCode;
    } else {
      organisationSearchCriteria.businessTypeCode = key.dtls.businessTypeCode;
    }
    organisationSearchCriteria.creationDate = key.dtls.creationDate;
    organisationSearchCriteria.locationName = key.dtls.locationName;
    organisationSearchCriteria.name = key.dtls.name;
    organisationSearchCriteria.organisationUnitID = key.dtls.organisationUnitID;

    organisationSearchCriteria.statusCode = key.dtls.statusCode;
    organisationSearchCriteria.organisationStructureID = key.dtls.organisationStructureID;
    curam.core.sl.struct.OrgUnitDetailsList orgUnitDetailsList = DatabaseOrganisationUnitSearchFactory.newInstance().searchOrganisationUnits(
      organisationSearchCriteria);

    if (CuramConst.gkZero == orgUnitDetailsList.dtls.size()) {
      throw (new AppException(BPOORGANISATIONUNIT.INF_ORGUNIT_SEARCH_NOT_FOUND));
    }
    for (ListOrgUnitDetails orgUnitDetails : orgUnitDetailsList.dtls) {
      viewOrgUnitStructWithVersionNoList.dtls.dtls.addRef(orgUnitDetails);
    }

    return viewOrgUnitStructWithVersionNoList;
  }

  // END, CR00388421
  /*
   * Method to list child organization units for parent organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of organization units
   * @deprecated Since Curam 6.0, replaced with
   * {@link Organization#listChildUnitForOrgUnitWithVersionNo(OrgStructureAndOrgUnitKey)}. As
   * part of the new API versionNo fields must be returned in lists which allow items to be deleted
   * See release note: CR00242411.
   */
  @Deprecated
  public ListOrganisationUnitForOrgUnitDetails listChildUnitForOrgUnit(
    OrgStructureAndOrgUnitKey key) throws AppException, InformationalException {
    ListOrganisationUnitForOrgUnitWithVersionNoDetails listOrganisationUnitForOrgUnitWithVersionNoDetails = listChildUnitForOrgUnitWithVersionNo(
      key);
    ListOrganisationUnitForOrgUnitDetails listOrganisationUnitForOrgUnitDetails = new ListOrganisationUnitForOrgUnitDetails();

    listOrganisationUnitForOrgUnitDetails.assign(
      listOrganisationUnitForOrgUnitWithVersionNoDetails);
    return listOrganisationUnitForOrgUnitDetails;
  }

  /**
   * This method replaces the deprecated method
   * {@link #listChildUnitForOrgUnit(OrgStructureAndOrgUnitKey)}
   * Method to list child organization units for parent organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of organization units
   */
  public ListOrganisationUnitForOrgUnitWithVersionNoDetails listChildUnitForOrgUnitWithVersionNo(
    OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    // Variables for reading organization unit details list
    ListOrganisationUnitsKey listOrganisationUnitsKey = new ListOrganisationUnitsKey();

    // Return variable for organization unit details list
    ListOrganisationUnitForOrgUnitWithVersionNoDetails listOrganisationUnitForOrgUnitWithVersionNoDetails = new ListOrganisationUnitForOrgUnitWithVersionNoDetails();

    // listOrganisationUnitForOrgUnitDetails.orgUnitList
    // Key to read organization unit context description
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    OrgUnitBrowserKey orgUnitBrowserKey = new OrgUnitBrowserKey();

    orgUnitBrowserKey.organisationStructureID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID;

    orgUnitBrowserKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // Get Org Structure bread crumb data
    listOrganisationUnitForOrgUnitWithVersionNoDetails.menuData = getOrgUnitBreadCrumb(orgUnitBrowserKey).menuData;

    // Assign details to key to read organization unit details list for
    // organization structure
    listOrganisationUnitsKey.allInd = false;
    listOrganisationUnitsKey.orgStructureID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID;

    listOrganisationUnitsKey.orgUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // Read organization unit details list for organization structure
    listOrganisationUnitForOrgUnitWithVersionNoDetails.orgUnitList = OrganisationUnitFactory.newInstance().listOrganisationUnitsWithVersionNo(
      listOrganisationUnitsKey);

    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // Read organization structure context description
    listOrganisationUnitForOrgUnitWithVersionNoDetails.orgUnitContextDescription = readOrganisationUnitContextDescription(
      organisationUnitKey);

    // Return organization unit details list
    return listOrganisationUnitForOrgUnitWithVersionNoDetails;
  }

  // END, CR00242411, KX

  
  /**
   * Method to list all organization units.
   *
   * @return list of organization units
   */
  public ListOrganisationUnitDetails listAllOrgUnit() throws AppException,
      InformationalException {

    // Variables for reading organization unit details list
    ListOrganisationUnitsKey listOrganisationUnitsKey = new ListOrganisationUnitsKey();

    // Return variable for organization unit details list
    ListOrganisationUnitDetails listOrganisationUnitDetails = new ListOrganisationUnitDetails();

    // Assign details to key to read organization unit details list for
    // organization structure
    listOrganisationUnitsKey.allInd = true;

    // Read organization unit details list for organization structure
    listOrganisationUnitDetails.orgUnitList = OrganisationUnitFactory.newInstance().listOrganisationUnits(
      listOrganisationUnitsKey);

    // Return organization unit details list
    return listOrganisationUnitDetails;
  }

  /**
   * Method to clone organization structure.
   *
   * @param cloneOrgStructureKey
   * organization structure identifier
   */
  public void cloneOrganisationStructure(
    CloneOrgStructureKey cloneOrgStructureKey) throws AppException,
      InformationalException {

    // Clone organization structure
    curam.core.sl.fact.OrganisationStructureFactory.newInstance().cloneOrganisationStructure(
      cloneOrgStructureKey.cloneOrganisationStructureKey);
  }

  /**
   * Method to view job details.
   *
   * @param jobKey
   * job identifier
   *
   * @return job details
   */
  public ViewJobDetails viewJob(JobKey jobKey) throws AppException,
      InformationalException {

    // Return variable for job details
    ViewJobDetails viewJobDetails = new ViewJobDetails();

    // Read job details
    viewJobDetails.jobDetails = curam.core.sl.fact.JobFactory.newInstance().viewJob(
      jobKey.jobKey);

    // Return job details
    return viewJobDetails;
  }

  /**
   * Method to view organization unit details.
   *
   * @param key
   * organization unit identifier
   *
   * @return organization unit details
   */
  public ViewOrganisationUnitDetails viewOrganisationUnit(
    final OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    // Return variable for organization unit details
    ViewOrganisationUnitDetails viewOrganisationUnitDetails = new ViewOrganisationUnitDetails();

    // Read organization unit details
    viewOrganisationUnitDetails.orgUnitDetails = OrganisationUnitFactory.newInstance().viewOrganisationUnit(
      key.orgStructureAndOrgUnitKey);

    if (viewOrganisationUnitDetails.orgUnitDetails.organisationUnitDetails.organisationUnitID
      != 0) {

      // Read organization unit contact information
      viewOrganisationUnitDetails.organisationUnitContactDetails = getOrganisationUnitContactInformation(
        key);
    }

    // BEGIN, CR00226381, GSP
    // read the location details
    viewOrganisationUnitDetails.orgUnitLocationDetails = OrganisationUnitFactory.newInstance().getOrganisationUnitLocationDetails(
      key.orgStructureAndOrgUnitKey);
    // END, CR00226381

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      viewOrganisationUnitDetails.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // Return organization unit details
    return viewOrganisationUnitDetails;
  }

  // BEGIN, CR00342012, IBM
  /**
   * Reads the position details by given organization structure and position key.
   *
   * @param key Contains organization structure id and position id.
   *
   * @return position details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  // END, CR00342012
  public ViewPositionDetails viewPosition(OrgStructureAndPositionKey key)
    throws AppException, InformationalException {

    // Return variable for position details
    ViewPositionDetails viewPositionDetails = new ViewPositionDetails();

    viewPositionDetails.viewPositionDetails = PositionFactory.newInstance().viewPosition(
      key.orgStructureAndPositionKey);
    // BEGIN, CR00334212, AC
    if (0
      < viewPositionDetails.viewPositionDetails.viewPositionDetails.reportsToName.length()) {
      viewPositionDetails.viewPositionDetails.viewPositionDetails.reportsToInd = true;
    } else {
      viewPositionDetails.viewPositionDetails.viewPositionDetails.reportsToInd = false;
    }
      
    // END, CR00334212
    
    return viewPositionDetails;
  }

  /**
   * Method to cancel organization unit.
   *
   * @param cancelOrgUnitKey
   * organization unit identifier
   */
  public void cancelOrganizationUnit(CancelOrgUnitKey cancelOrgUnitKey)
    throws AppException, InformationalException {

    // BEGIN, CR00161962, KY
    // Cancel organization unit
    OrganisationUnitFactory.newInstance().cancelOrganisationUnitStartWFProcess(
      cancelOrgUnitKey.cancelOrgUnitKey);
    // END, CR00161962
  }

  // BEGIN, CR00220774, AMD
  
  /**
   * Cancels an existing position and all associated Position Holder records.
   *
   * @param cancelPositionKey
   * position identifier
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #cancelPositionByWorkflow(CancelPositionByWorkFlowKey)}. The newer
   * version of this method contains the organization unit identifier, which
   * is used to notify the supervisors of the specified organization Unit. See
   * release notes for CR CR00220774.
   */
  @Deprecated
  public void cancelPosition(
    curam.core.facade.struct.CancelPositionKey cancelPositionKey)
    throws AppException, InformationalException {
    // Cancel position
    PositionFactory.newInstance().cancelPosition(
      cancelPositionKey.cancelPositionKey);
  }

  /**
   * Enacts a workflow to cancel a position and notifies the supervisors of
   * the organization Unit associated with the position.
   *
   * @param cancelPositionKey The position to cancel.
   */
  public void cancelPositionByWorkflow(CancelPositionByWorkFlowKey cancelPositionKey)
    throws AppException, InformationalException {

    // BEGIN, CR00161962, KY
    // Cancel position
    PositionFactory.newInstance().cancelPositionStartWFProcess(
      cancelPositionKey.cancelPositionKey);
    // END, CR00161962
  }

  // END, CR00220774

  
  /**
   * Method to create new job.
   *
   * @param details
   * job details
   */
  public void createJob(JobDetails details) throws AppException,
      InformationalException {

    // Create new job
    curam.core.sl.fact.JobFactory.newInstance().createJob(details.jobDetails);
  }

  /**
   * Method to create new organization structure.
   *
   * @param details
   * organization structure details
   */
  public void createOrganisationStructure(OrganisationStructureDetails details)
    throws AppException, InformationalException {

    // Create new organization structure
    curam.core.sl.fact.OrganisationStructureFactory.newInstance().createOrganisationStructure(
      details.orgStructureDetails);
  }

  /**
   * Method to create new organization unit.
   *
   * @param details
   * organization unit details
   */
  public void createOrganisationUnit(OrganisationUnitDetails details)
    throws AppException, InformationalException {

    // Create new organization unit
    OrganisationUnitFactory.newInstance().createOrganisationUnit(
      details.orgUnitDetails);

    // BEGIN, CR00091343 KK
    // Highlight the parent location node when a child location is created
    // key to update the TreeNodeDetails HashMap
    RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // key and value pair
    ruleSetNodeKey.ruleSetID = String.valueOf(
      details.orgUnitDetails.organisationStructureID);
    ruleSetNodeKey.nodeID = details.orgUnitDetails.parentOrganisationUnitID;
    final String selectedUnitPath = setSelectedPathForOrgUnit(details);

    OrganisationpostUpdate(ruleSetNodeKey, selectedUnitPath);
    // END, CR00091343 KK
  }

  /**
   * Method to create new position.
   *
   * @param createPositionDetails
   * position details
   */
  public void createPosition(CreatePositionDetails createPositionDetails)
    throws AppException, InformationalException {

    // Create new position
    PositionFactory.newInstance().createPosition(
      createPositionDetails.positionDetails);

    // BEGIN, CR00094026 KK
    // Highlight the organization node when a position is created for an
    // organization unit
    // key to update the OrganisationTreeXMLNodeDetail HashMap .
    RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // key and value pair
    ruleSetNodeKey.ruleSetID = String.valueOf(
      createPositionDetails.positionDetails.positionOrgDetails.organisationStructureID);
    ruleSetNodeKey.nodeID = // BEGIN, CR00104893, GSP
      createPositionDetails.positionDetails.positionOrgDetails.positionDtls.positionID;
    // END,  CR00104893, GSP
    String positionPath = setSelectedPathForPosition(createPositionDetails);

    OrganisationpostUpdate(ruleSetNodeKey, positionPath);
    // END, CR00094026 KK
  }

  /**
   * Method to update job details.
   *
   * @param modifyJobDetails
   * job details
   */
  public void modifyJob(ModifyJobDetails modifyJobDetails) throws AppException,
      InformationalException {

    // Update job details
    curam.core.sl.fact.JobFactory.newInstance().modifyJob(
      modifyJobDetails.jobDetails);
  }

  /**
   * Method to update organization structure details.
   *
   * @param modifyOrganisationStructureDetails
   * organization structure details
   */
  public void modifyOrganisationStructure(
    ModifyOrganisationStructureDetails modifyOrganisationStructureDetails)
    throws AppException, InformationalException {

    // Update organization structure details
    curam.core.sl.fact.OrganisationStructureFactory.newInstance().modifyOrganisationStructure(
      modifyOrganisationStructureDetails.orgStructureDetails);
  }

  /**
   * Method to update organization unit details.
   *
   * @param modifyOrganisationUnitDetails
   * organization unit details
   */
  public void modifyOrganisationUnit(
    ModifyOrganisationUnitDetails modifyOrganisationUnitDetails)
    throws AppException, InformationalException {

    // Update organization unit details
    OrganisationUnitFactory.newInstance().modifyOrganisationUnit(
      modifyOrganisationUnitDetails.orgUnitDetails);

    // BEGIN, CR00076504 RR
    // Highlight the organization unit node when the organization unit is edited
    // key to update the TreeNodeDetails HashMap
    RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // key and value pair
    ruleSetNodeKey.ruleSetID = String.valueOf(
      modifyOrganisationUnitDetails.orgUnitDetails.organisationStructureID);
    ruleSetNodeKey.nodeID = modifyOrganisationUnitDetails.orgUnitDetails.organisationUnitDtls.organisationUnitID;

    OrganisationpostUpdate(ruleSetNodeKey, "");
    // END, CR00076504 RR
  }

  /**
   * Method to update position details.
   *
   * @param modifyPositionDetails
   * position details
   */
  public void modifyPosition(ModifyPositionDetails modifyPositionDetails)
    throws AppException, InformationalException {

    // Update position details
    PositionFactory.newInstance().modifyPosition(
      modifyPositionDetails.modifyPositionDetails);

    // BEGIN,  CR00104893, GSP

    // Highlight the Organization node when the position is edited
    // key to update the TreeNodeDetails HashMap.
    RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // key and value pair
    ruleSetNodeKey.ruleSetID = String.valueOf(
      modifyPositionDetails.modifyPositionDetails.positionOrgDetails.organisationStructureID);
    // assign node id to the position ID
    ruleSetNodeKey.nodeID = modifyPositionDetails.modifyPositionDetails.positionDetails.positionID;
    OrganisationpostUpdate(ruleSetNodeKey, "");
    // END, CR00104893

  }

  /**
   * Method to create new child organization unit.
   *
   * @param childOrganisationUnitDetails
   * child organization unit details
   */
  public void addChildUnit(
    ChildOrganisationUnitDetails childOrganisationUnitDetails)
    throws AppException, InformationalException {

    // Create new organization unit
    OrganisationUnitFactory.newInstance().createOrganisationUnit(
      childOrganisationUnitDetails.orgUnitDetails);
  }

  /**
   * Method to create new root organization unit.
   *
   * @param rootOrganisationUnitDetails
   * organization unit details
   */
  public void createRootUnit(
    RootOrganisationUnitDetails rootOrganisationUnitDetails)
    throws AppException, InformationalException {

    // Create new organization unit
    OrganisationUnitFactory.newInstance().createOrganisationUnit(
      rootOrganisationUnitDetails.orgUnitDetails);
  }

  /**
   * Method to search for a position.
   *
   * @param key
   * position name to be read
   *
   * @return position details list
   */
  public ListPositionSearchDetails positionSearch(
    PositionNameAndOrgStructureIDKey key) throws AppException,
      InformationalException {

    // Return variable for position details list
    ListPositionSearchDetails listPositionSearchDetails = new ListPositionSearchDetails();

    listPositionSearchDetails.viewPositionSearchDetailsList = PositionFactory.newInstance().searchPositionByName(
      key.positionNameAndOrgStructureIDKey);

    // Return position details list
    return listPositionSearchDetails;
  }

  /**
   * Method to list all users for organization.
   *
   * @return list of users
   */
  public ListUserForOrganisationDetails listUserForOrganisation()
    throws AppException, InformationalException {

    // Key to read users details list
    ListUsersKey_bo listUsersKey = new ListUsersKey_bo();

    // Return variable for users details list
    ListUserForOrganisationDetails listUserForOrganisationDetails = new ListUserForOrganisationDetails();

    // Assign details to key to read all user details list for organization
    listUsersKey.allInd = true;

    // Read all user details list for organization
    listUserForOrganisationDetails.userForPositionDetailsList = AdminUserFactory.newInstance().listUsers(
      listUsersKey);

    // Return user details list
    return listUserForOrganisationDetails;
  }

  /**
   * Method to list users for organization structure.
   *
   * @param key
   * organization structure identifier
   *
   * @return list of users
   */
  public ListUserForOrgStructureDetails listUserForOrgStructure(
    OrganisationStructureKey key) throws AppException, InformationalException {

    // Key to read users details list
    ListUsersKey_bo listUsersKey = new ListUsersKey_bo();

    // Return variable for users details list
    ListUserForOrgStructureDetails listUserForOrgStructureDetails = new ListUserForOrgStructureDetails();

    // Assign details to key to read user details list for organization
    // structure
    listUsersKey.allInd = false;
    listUsersKey.orgStructureID = key.organisationStructureKey.organisationStructureKey.organisationStructureID;

    // Read user details list for organization structure
    listUserForOrgStructureDetails.userForPositionDetailsList = AdminUserFactory.newInstance().listUsers(
      listUsersKey);

    // Read organization structure context description
    listUserForOrgStructureDetails.orgStructureContextDescription = readOrganisationStructureContextDescription(
      key);

    // Return user details list
    return listUserForOrgStructureDetails;
  }

  /**
   * Method to list users for organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of users
   */
  public ListUserForOrgUnitDetails listUserForOrgUnit(
    OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    // Key to read users details list
    ListUsersKey_bo listUsersKey = new ListUsersKey_bo();

    // Key to read organization unit context description
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Return variable for users details list
    ListUserForOrgUnitDetails listUserForOrgUnitDetails = new ListUserForOrgUnitDetails();

    // Assign details to key to read user details list for organization unit
    listUsersKey.allInd = false;
    listUsersKey.orgStructureID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID;

    listUsersKey.orgUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // Read user details list for organization unit
    listUserForOrgUnitDetails.userForPositionDetailsList = AdminUserFactory.newInstance().listUsers(
      listUsersKey);

    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // Read organization unit context description
    listUserForOrgUnitDetails.orgUnitContextDescription = readOrganisationUnitContextDescription(
      organisationUnitKey);

    // Return user details list
    return listUserForOrgUnitDetails;
  }

  /**
   * Method to list users for position.
   *
   * @param key
   * position identifier
   *
   * @return list of users
   */
  public ListUserForPositionDetails listUserForPosition(
    OrgStructureAndPositionKey key) throws AppException,
      InformationalException {

    // Key to read users details list
    ListUsersKey_bo listUsersKey = new ListUsersKey_bo();

    // Key to read position context description
    PositionKey positionKey = new PositionKey();

    // Return variable for users details list
    ListUserForPositionDetails listUserForPositionDetails = new ListUserForPositionDetails();

    // Assign details to key to read user details list for organization
    // structure
    listUsersKey.allInd = false;
    listUsersKey.orgStructureID = key.orgStructureAndPositionKey.orgStructureAndPositionKey.organisationStructureID;
    listUsersKey.positionID = key.orgStructureAndPositionKey.orgStructureAndPositionKey.positionID;

    // Read user details list for position
    listUserForPositionDetails.userForPositionDetailsList = AdminUserFactory.newInstance().listUsers(
      listUsersKey);

    positionKey.positionKey.positionKey.positionID = key.orgStructureAndPositionKey.orgStructureAndPositionKey.positionID;

    // Read organization structure context description
    listUserForPositionDetails.positionContextDescriptionDetails = readPositionContextDescription(
      positionKey);

    // Return user details list
    return listUserForPositionDetails;
  }

  // BEGIN, CR00342012, IBM
  /**
   * Lists the subordinate users that reports to this position.
   *
   * @param key Contains organization structure id and position id.
   *
   * @return list of subordinate users.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  // END, CR00342012
  public ListOrgUnitUserDetails listSubordinateUserForPosition(
    OrgStructureAndPositionKey key) throws AppException,
      InformationalException {

    // Key to read organization unit context description
    PositionKey positionKey = new PositionKey();

    ListOrgUnitUserDetails listOrgUnitUserDetails = new ListOrgUnitUserDetails();

    // Read subordinate user details list for position
    listOrgUnitUserDetails.listOrgUnitUserDetails = PositionFactory.newInstance().listSubordinateUsers(
      key.orgStructureAndPositionKey);

    positionKey.positionKey.positionKey.positionID = key.orgStructureAndPositionKey.orgStructureAndPositionKey.positionID;

    // Read position context description
    listOrgUnitUserDetails.positionContextDescriptionDetails = readPositionContextDescription(
      positionKey);

    // Return user details list
    return listOrgUnitUserDetails;
  }

  // BEGIN, CR00342012, IBM
  /**
   * Lists the supervisor users that reports to this position.
   *
   * @param key Contains organization structure id and position id.
   *
   * @return list of supervisor users.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  // END, CR00342012
  public ListUserForPositionDetails listSupervisorUserForPosition(
    OrgStructureAndPositionKey key) throws AppException,
      InformationalException {

    // Key to read organization unit context description
    PositionKey positionKey = new PositionKey();

    // Return variable for users details list
    ListUserForPositionDetails listUserForPositionDetails = new ListUserForPositionDetails();

    // Read supervisor user details list for position
    listUserForPositionDetails.userForPositionDetailsList = PositionFactory.newInstance().listSupervisorUsers(
      key.orgStructureAndPositionKey);

    positionKey.positionKey.positionKey.positionID = key.orgStructureAndPositionKey.orgStructureAndPositionKey.positionID;

    // Read position context description
    listUserForPositionDetails.positionContextDescriptionDetails = readPositionContextDescription(
      positionKey);

    // Return user details list
    return listUserForPositionDetails;
  }

  // BEGIN, CR00243704, KX
  
  /**
   * This method replaces the deprecated method
   * {@link #listJob()}
   * Method to list all jobs for organization.
   *
   * @return list of jobs
   */
  public ListJobWithVersionNoDetails listJobWithVersionNo() throws AppException, InformationalException {

    // Key to read job details list
    ListJobsKey listJobsKey = new ListJobsKey();

    // Return variable for job details list
    ListJobWithVersionNoDetails listJobDetails = new ListJobWithVersionNoDetails();

    // Assign details to key to read job details list for organization unit
    listJobsKey.allInd = true;

    // Read job details list for organization unit
    listJobDetails.viewJobDetailsList = curam.core.sl.fact.JobFactory.newInstance().listJobsWithVersionNo(
      listJobsKey);

    // Return job details list
    return listJobDetails;
  }

  /**
   * @return list of jobs
   * @deprecated Since Curam 6.0, replaced with
   * {@link #listJobWithVersionNo(ListJobsKey)}. As
   * part of the new API versionNo fields must be returned in lists which allow items to be deleted
   * See release note: CR242411.
   * Method to list all jobs for organization.
   */
  @Deprecated
  public ListJobDetails listJob() throws AppException, InformationalException {

    // Return variable for job details list
    ListJobDetails listJobDetails = new ListJobDetails();

    ListJobWithVersionNoDetails listJobWithVersionNoDetails = listJobWithVersionNo();

    listJobDetails.assign(listJobWithVersionNoDetails);
    return listJobDetails;
  }

  /**
   * Method to list jobs for organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of jobs
   * @deprecated Since Curam 6.0, replaced with
   * {@link Organization#listJobForOrgUnitWithVersionNo(OrgStructureAndOrgUnitKey)}. As
   * part of the new API versionNo fields must be returned in lists which allow items to be deleted
   * See release note: CR00242411.
   */
  @Deprecated
  public ListJobForOrgUnitDetails listJobForOrgUnit(
    OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {
    ListJobForOrgUnitWithVersionNoDetails listJobForOrgUnitWithVersionNoDetails = listJobForOrgUnitWithVersionNo(
      key);
    ListJobForOrgUnitDetails listJobForOrgUnitDetails = new ListJobForOrgUnitDetails();

    listJobForOrgUnitDetails.assign(listJobForOrgUnitWithVersionNoDetails);
    return listJobForOrgUnitDetails;
  }

  /**
   * This method replaces the deprecated method
   * {@link #listJobForOrgUnit(OrgStructureAndOrgUnitKey)}
   * Method to list jobs for organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of jobs
   */
  public ListJobForOrgUnitWithVersionNoDetails listJobForOrgUnitWithVersionNo(
    OrgStructureAndOrgUnitKey key) throws AppException, InformationalException {

    // Key to read job details list
    ListJobsKey listJobsKey = new ListJobsKey();

    // Return variable for job details list
    ListJobForOrgUnitWithVersionNoDetails listJobForOrgUnitWithVersionNoDetails = new ListJobForOrgUnitWithVersionNoDetails();

    // Assign details to key to read job details list for organization unit
    listJobsKey.allInd = false;
    listJobsKey.orgUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;
    listJobsKey.orgStructureID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID;

    // Key to read organization unit context description
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // Read job details list for organization unit
    listJobForOrgUnitWithVersionNoDetails.viewJobDetailsList = curam.core.sl.fact.JobFactory.newInstance().listJobsWithVersionNo(
      listJobsKey);

    // Read organization unit description
    listJobForOrgUnitWithVersionNoDetails.orgUnitContextDescription = readOrganisationUnitContextDescription(
      organisationUnitKey);

    // Return job details list
    return listJobForOrgUnitWithVersionNoDetails;
  }

  // END, CR00242411, KX

  
  /**
   * Method to add position holder link for a user and position.
   *
   * @param userForPositionDetails
   * user name and position identifier
   */
  public void addUserForPosition(UserForPositionDetails userForPositionDetails)
    throws AppException, InformationalException {

    // read status and set record status.
    curam.core.sl.entity.struct.OrganisationUnitKey organisationUnitKey = new curam.core.sl.entity.struct.OrganisationUnitKey();

    organisationUnitKey.organisationUnitID = userForPositionDetails.organisationID;
    OrganisationUnitStatus organisationUnitStatus = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance().readStatus(
      organisationUnitKey);

    if (organisationUnitStatus.recordStatus.equals(ORGUNITSTATUSCODE.CLOSED)) {
      throw new AppException(BPOPOSITION.ERR_ORGANIZATION_UNIT_CLOSED);
    }

    // SID Validation
    curam.core.sl.struct.OrgStructureAndOrgUnitKey orgStructureAndOrgUnitKey = new curam.core.sl.struct.OrgStructureAndOrgUnitKey();

    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID = userForPositionDetails.positionHolderLinkDetails.positionHolderLinkDtls.organisationStructureID;
    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID = userForPositionDetails.organisationID;

    OrganisationAdminSecurity organisationAdminSecurity = new OrganisationAdminSecurity();

    OrganisationAdminSecurityResult organisationAdminSecurityResult = organisationAdminSecurity.checkCreateChildOrganisationSecurity(
      orgStructureAndOrgUnitKey);

    if (!organisationAdminSecurityResult.result) {
      throw new AppException(
        BPOORGANISATIONUNIT.ERR_ORGANISATIONSECURITY_CHECK_FAILED);
    }

    // Position id key
    UserNamePositionIDOrgStructIDKey userNamePositionIDOrgStructIDKey = new UserNamePositionIDOrgStructIDKey();

    // Create position holder link for a user and position
    PositionHolderLinkFactory.newInstance().createPositionHolderLink(
      userForPositionDetails.positionHolderLinkDetails);

    userNamePositionIDOrgStructIDKey.organisationStructureID = userForPositionDetails.positionHolderLinkDetails.positionHolderLinkDtls.organisationStructureID;
    userNamePositionIDOrgStructIDKey.userName = userForPositionDetails.positionHolderLinkDetails.positionHolderLinkDtls.userName;

    // Populate the position id key
    userNamePositionIDOrgStructIDKey.positionID = userForPositionDetails.positionHolderLinkDetails.positionHolderLinkDtls.positionID;

    // Set the organization unit printer as user default printer
    AdminUserFactory.newInstance().setDefaultPrinter(
      userNamePositionIDOrgStructIDKey);
  }

  /**
   * Method to remove position holder link for a user and position.
   *
   * @param removeUserFromPositionKey
   * user name and position identifier
   */
  public void removeUserFromPosition(
    RemoveUserFromPositionKey removeUserFromPositionKey) throws AppException,
      InformationalException {

    // Create position holder link for a user and position
    PositionHolderLinkFactory.newInstance().cancelPositionHolderLink(
      removeUserFromPositionKey.cancelPositionHolderLinkey);
  }

  /**
   * Method to list 'lead' positions for organization structure.
   *
   * @param key
   * organization structure identifier
   *
   * @return list of positions
   */
  public ListPositionForOrgStructureDetails listLeadPositionForOrgStructure(
    OrganisationStructureKey key) throws AppException, InformationalException {

    // Return variable for position details list
    ListPositionForOrgStructureDetails listPositionForOrgStructureDetails = new ListPositionForOrgStructureDetails();

    // Read 'lead' position details list for organization structure
    listPositionForOrgStructureDetails.positionList = curam.core.sl.fact.OrganisationStructureFactory.newInstance().listLeadPositions(
      key.organisationStructureKey);

    // Read organization structure description
    listPositionForOrgStructureDetails.orgStructureContextDescription = readOrganisationStructureContextDescription(
      key);

    // Return position details list
    return listPositionForOrgStructureDetails;
  }

  /**
   * Method to list all 'lead' positions for organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of positions
   */
  public ListPositionForOrgUnitDetails listLeadPositionForOrgUnit(
    OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    // Return variable for position details list
    ListPositionForOrgUnitDetails listPositionForOrgUnitDetails = new ListPositionForOrgUnitDetails();

    // Key to read organization unit context description
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Key to get all lead positions for organization unit
    OrganisationUnitAndActiveStatusIndKey organisationUnitAndActiveStatusIndKey = new OrganisationUnitAndActiveStatusIndKey();

    // Assign details to key to get all positions for organization units
    organisationUnitAndActiveStatusIndKey.organisationStructureID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID;

    organisationUnitAndActiveStatusIndKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;
    organisationUnitAndActiveStatusIndKey.activeInd = false;

    // Read 'lead' position details list for organization unit
    listPositionForOrgUnitDetails.viewPositionUserOrgUnitDetailsList = OrganisationUnitFactory.newInstance().listLeadPositions(
      organisationUnitAndActiveStatusIndKey);

    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // Read organization unit description
    listPositionForOrgUnitDetails.orgUnitContextDescription = readOrganisationUnitContextDescription(
      organisationUnitKey);

    // Return position details list
    return listPositionForOrgUnitDetails;
  }

  /**
   * Method to list active 'lead' positions for organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of positions
   */
  public ListPositionForOrgUnitDetails listActiveLeadPositionForOrgUnit(
    OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    // Return variable for position details list
    ListPositionForOrgUnitDetails listPositionForOrgUnitDetails = new ListPositionForOrgUnitDetails();

    // Key to read organization unit context description
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Key to get active lead positions for organization unit
    OrganisationUnitAndActiveStatusIndKey organisationUnitAndActiveStatusIndKey = new OrganisationUnitAndActiveStatusIndKey();

    // Assign details to key to get active positions for organization units
    organisationUnitAndActiveStatusIndKey.organisationStructureID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID;
    organisationUnitAndActiveStatusIndKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;
    organisationUnitAndActiveStatusIndKey.activeInd = true;

    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // Read 'lead' position details list for organization unit
    listPositionForOrgUnitDetails.viewPositionUserOrgUnitDetailsList = OrganisationUnitFactory.newInstance().listLeadPositions(
      organisationUnitAndActiveStatusIndKey);

    // Read organization unit description
    listPositionForOrgUnitDetails.orgUnitContextDescription = readOrganisationUnitContextDescription(
      organisationUnitKey);

    // Return position details list
    return listPositionForOrgUnitDetails;
  }

  /**
   * Method to list positions for job.
   *
   * @param key
   * job identifier
   *
   * @return list of positions
   */
  public ListPositionForJobDetails listPositionForJob(JobKey key)
    throws AppException, InformationalException {

    // Return variable for position details list
    ListPositionForJobDetails listPositionForJobDetails = new ListPositionForJobDetails();

    ListPositionsByJobKey listPositionsByJobKey = new ListPositionsByJobKey();

    listPositionsByJobKey.jobID = key.jobKey.jobKey.jobID;

    // Read position details list for job
    listPositionForJobDetails.viewDetailsList = PositionFactory.newInstance().listPositionsByJob(
      listPositionsByJobKey);

    // Read job description
    listPositionForJobDetails.jobContextDesciptionDetails = readJobContextDescription(
      key);

    // Return position details list
    return listPositionForJobDetails;
  }

  /**
   * Method to list positions for organization structure.
   *
   * @param key
   * organization structure identifier
   *
   * @return list of positions
   */
  public ListPositionForOrgStructureDetails listPositionForOrgStructure(
    OrganisationStructureKey key) throws AppException, InformationalException {
    // BEGIN, CR00377231, MV
    final ListPositionForOrgStructureDetails listPositionForOrgStructureDetails = new ListPositionForOrgStructureDetails();
    final ListPositionsKey listPositionsKey = new ListPositionsKey();

    listPositionsKey.allInd = false;
    listPositionsKey.orgStructureID = key.organisationStructureKey.organisationStructureKey.organisationStructureID;
    listPositionForOrgStructureDetails.positionList = PositionFactory.newInstance().listPositions(
      listPositionsKey);
    listPositionForOrgStructureDetails.orgStructureContextDescription = readOrganisationStructureContextDescription(
      key);
    // END, CR00377231
    return listPositionForOrgStructureDetails;
  }

  /**
   * Method to list all positions for organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of positions
   */
  public ListPositionForOrgUnitDetails listPositionForOrgUnit(
    OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    // Return variable for position details list
    ListPositionForOrgUnitDetails listPositionForOrgUnitDetails = new ListPositionForOrgUnitDetails();

    // Key to read organization unit context description
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Key to get all positions for organization unit
    OrganisationUnitAndActiveStatusIndKey organisationUnitAndActiveStatusIndKey = new OrganisationUnitAndActiveStatusIndKey();

    // Assign details to key to read position details list
    organisationUnitAndActiveStatusIndKey.organisationStructureID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID;
    organisationUnitAndActiveStatusIndKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;
    organisationUnitAndActiveStatusIndKey.activeInd = false;

    // Read position details list for organization unit
    listPositionForOrgUnitDetails.viewPositionUserOrgUnitDetailsList = OrganisationUnitFactory.newInstance().listPositions(
      organisationUnitAndActiveStatusIndKey);

    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // If organizationUnitID is equal to zero (e.g in case where listing
    // positions for parent org unit where there is no parent org unit).
    // Just return a blank list.
    if (key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID
      != 0) {

      // Read organization unit description
      listPositionForOrgUnitDetails.orgUnitContextDescription = readOrganisationUnitContextDescription(
        organisationUnitKey);
    }

    // Return position details list
    return listPositionForOrgUnitDetails;
  }

  /**
   * Method to list active positions for organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of positions
   */
  public ListPositionForOrgUnitDetails listActivePositionForOrgUnit(
    OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    // Return variable for position details list
    ListPositionForOrgUnitDetails listPositionForOrgUnitDetails = new ListPositionForOrgUnitDetails();

    // Key to read organization unit context description
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Key to get active positions for organization unit
    OrganisationUnitAndActiveStatusIndKey organisationUnitAndActiveStatusIndKey = new OrganisationUnitAndActiveStatusIndKey();

    // Assign details to key to read active position details list
    organisationUnitAndActiveStatusIndKey.organisationStructureID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID;
    organisationUnitAndActiveStatusIndKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;
    organisationUnitAndActiveStatusIndKey.activeInd = true;

    // Read active position details list for organization unit
    listPositionForOrgUnitDetails.viewPositionUserOrgUnitDetailsList = OrganisationUnitFactory.newInstance().listPositions(
      organisationUnitAndActiveStatusIndKey);

    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // If organizationUnitID is equal to zero (e.g in case where listing
    // positions for parent org unit where there is no parent org unit).
    // Just return a blank list.
    if (key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID
      != 0) {

      // Read organization unit description
      listPositionForOrgUnitDetails.orgUnitContextDescription = readOrganisationUnitContextDescription(
        organisationUnitKey);
    }

    // Return position details list
    return listPositionForOrgUnitDetails;
  }

  /**
   * Method to list vacant positions for organization structure.
   *
   * @param key
   * organization structure identifier
   *
   * @return list of positions
   */
  public ListPositionForOrgStructureDetails listVacantPositionForOrgStructure(
    OrganisationStructureKey key) throws AppException, InformationalException {

    // Return variable for position details list
    ListPositionForOrgStructureDetails listPositionForOrgStructureDetails = new ListPositionForOrgStructureDetails();

    // Read 'lead' position details list for organization structure
    listPositionForOrgStructureDetails.positionList = curam.core.sl.fact.OrganisationStructureFactory.newInstance().listVacantPositions(
      key.organisationStructureKey);

    // Read organization structure description
    listPositionForOrgStructureDetails.orgStructureContextDescription = readOrganisationStructureContextDescription(
      key);

    // Return position details list
    return listPositionForOrgStructureDetails;
  }

  /**
   * Method to list vacant positions for organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of positions
   */
  public ListPositionForOrgUnitDetails listVacantPositionForOrgUnit(
    OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    // Return variable for position details list
    ListPositionForOrgUnitDetails listPositionForOrgUnitDetails = new ListPositionForOrgUnitDetails();

    // Key to read organization unit context description
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Read 'lead' position details list for organization unit
    listPositionForOrgUnitDetails.viewPositionUserOrgUnitDetailsList = OrganisationUnitFactory.newInstance().listVacantPositions(
      key.orgStructureAndOrgUnitKey);

    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // Read organization unit description
    listPositionForOrgUnitDetails.orgUnitContextDescription = readOrganisationUnitContextDescription(
      organisationUnitKey);

    // Return position details list
    return listPositionForOrgUnitDetails;
  }

  /**
   * Method to list subordinate positions for position.
   *
   * @param key
   * position identifier
   *
   * @return list of positions
   */
  public ListPositionForPositionDetails listSubordinatePositionForPosition(
    OrgStructureAndPositionKey key) throws AppException,
      InformationalException {

    // Return variable for position details list
    ListPositionForPositionDetails listPositionForPositionDetails = new ListPositionForPositionDetails();

    // Key to read position context description
    PositionKey positionKey = new PositionKey();

    // Read position details list for organization unit
    listPositionForPositionDetails.viewPositionUserJobDetailsList = PositionFactory.newInstance().listSubordinatePositions(
      key.orgStructureAndPositionKey);

    positionKey.positionKey.positionKey.positionID = key.orgStructureAndPositionKey.orgStructureAndPositionKey.positionID;

    // Read organization unit description
    listPositionForPositionDetails.positionContextDescriptionDetails = readPositionContextDescription(
      positionKey);

    // Return position details list
    return listPositionForPositionDetails;
  }

  /**
   * Method to list 'lead' users for organization structure.
   *
   * @param key
   * organization structure identifier
   *
   * @return list of users
   */
  public ListUserForOrgStructureDetails listLeadUserForOrgStructure(
    OrganisationStructureKey key) throws AppException, InformationalException {

    // Return variable for users details list
    ListUserForOrgStructureDetails listUserForOrgStructureDetails = new ListUserForOrgStructureDetails();

    // Read user details list for organization structure
    listUserForOrgStructureDetails.userForPositionDetailsList = curam.core.sl.fact.OrganisationStructureFactory.newInstance().listLeadUsers(
      key.organisationStructureKey);

    // Read organization structure context description
    listUserForOrgStructureDetails.orgStructureContextDescription = readOrganisationStructureContextDescription(
      key);

    // Return user details list
    return listUserForOrgStructureDetails;
  }

  /**
   * Method to list 'lead' users for organization unit.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of users
   */
  public ListUserForOrgUnitDetails listLeadUserForOrgUnit(
    OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    // Return variable for users details list
    ListUserForOrgUnitDetails listUserForOrgUnitDetails = new ListUserForOrgUnitDetails();

    // Key to read organization unit context description
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Read user details list for organization unit
    listUserForOrgUnitDetails.userForPositionDetailsList = OrganisationUnitFactory.newInstance().listLeadUsers(
      key.orgStructureAndOrgUnitKey);

    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    // Read organization unit context description
    listUserForOrgUnitDetails.orgUnitContextDescription = readOrganisationUnitContextDescription(
      organisationUnitKey);

    // Return user details list
    return listUserForOrgUnitDetails;
  }

  /**
   * Method to return organization unit 'lead' user contact details.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of users
   */
  public OrganisationUnitContactDetails getOrganisationUnitContactInformation(
    OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    // Return user contact details
    return OrganisationUnitFactory.newInstance().getContactDetails(
      key.orgStructureAndOrgUnitKey);
  }

  /**
   * Method to return organization unit location details; The name of the
   * location which has been assigned to a Position within the Organization Unit
   * or one of its sub units along with position name and location status.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public OrganisationUnitLocationDetailsList getOrganisationUnitLocationDetails(
    OrgStructureAndOrgUnitKey key) throws AppException,
      InformationalException {

    // Read user details list for organization unit
    OrgStructAndOrgUnitID orgStructAndOrgUnitID = new OrgStructAndOrgUnitID();

    orgStructAndOrgUnitID.organisationStructureID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID;
    orgStructAndOrgUnitID.organisationUnitID = key.orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID;

    OrganisationUnitLocationDetailsList organisationUnitLocationDetailsList = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance().listOrganisationUnitLocationDetails(
      orgStructAndOrgUnitID);

    // Return user contact details
    return organisationUnitLocationDetailsList;
  }

  /**
   * Method to return organization unit 'lead' user contact details.
   *
   * @param cancelJobKey
   * organization unit identifier
   */
  public void cancelJob(CancelJobKey cancelJobKey) throws AppException,
      InformationalException {

    // Cancel job
    curam.core.sl.fact.JobFactory.newInstance().cancelJobStartWFProcess(
      cancelJobKey.cancelJobKey);
  }

  // ________________________________________________________________________
  /**
   * Cancel a daily schedule.
   *
   * @param cancelDailyScheduleDetails
   * cancel daily schedule details.
   */
  public void cancelDailySchedule(
    CancelDailyScheduleDetails cancelDailyScheduleDetails)
    throws AppException, InformationalException {

    // Cancel a daily schedule
    DailyScheduleFactory.newInstance().cancel(
      cancelDailyScheduleDetails.cancelDailyScheduleDetails);
  }

  // ________________________________________________________________________
  /**
   * Cancels a position slot availability record.
   *
   * @param cancelPositionSlotAvailabilityDetails
   * Cancel position slot availability details.
   */
  public void cancelPositionSlotavailability(
    CancelPositionSlotAvailabilityDetails cancelPositionSlotAvailabilityDetails)
    throws AppException, InformationalException {

    // Cancel the position availability slot
    PositionSlotAvailabilityFactory.newInstance().cancel(
      cancelPositionSlotAvailabilityDetails.cancelPositionSlotAvailabilityDetails);
  }

  // ________________________________________________________________________
  /**
   * Cancel a slot.
   *
   * @param cancelSlotDetails
   * Details to cancel a slot.
   */
  public void cancelSlotDetails(CancelSlotDetails cancelSlotDetails)
    throws AppException, InformationalException {

    // Cancel a slot
    SlotFactory.newInstance().cancel(cancelSlotDetails.cancelSlotDetails);
  }

  // ________________________________________________________________________
  /**
   * Create a daily schedule.
   *
   * @param dailyScheduleCreateDetails
   * Create daily schedule details.
   *
   * @return Schedule identifier.
   */
  public CreateDailyScheduleReturnKey createDailySchedule(
    DailyScheduleCreateDetails dailyScheduleCreateDetails)
    throws AppException, InformationalException {

    // Create return object
    CreateDailyScheduleReturnKey createDailyScheduleReturnKey = new CreateDailyScheduleReturnKey();

    // Call BPO to create a daily schedule
    createDailyScheduleReturnKey.createDailyScheduleReturnKey = DailyScheduleFactory.newInstance().create(
      dailyScheduleCreateDetails.dailyScheduleCreateDetails);

    return createDailyScheduleReturnKey;
  }

  // _______________________________________________________________________
  /**
   * Create a position slot availability record.
   *
   * @param positionSlotAvailabilityCreateDetails
   * Details to create a position slot availability record
   *
   * @return Position slot availability identifier
   */
  public CreatePositionSlotAvailabilityReturnKey createPositionSlotAvailability(
    PositionSlotAvailabilityCreateDetails positionSlotAvailabilityCreateDetails)
    throws AppException, InformationalException {

    // Create return object
    CreatePositionSlotAvailabilityReturnKey createPositionSlotAvailabilityReturnKey = new CreatePositionSlotAvailabilityReturnKey();

    // Call BPO to create a position slot availability record
    createPositionSlotAvailabilityReturnKey.createPositionSlotAvailabilityReturnKey = PositionSlotAvailabilityFactory.newInstance().create(
      positionSlotAvailabilityCreateDetails.positionSlotAvailabilityCreateDetails);

    return createPositionSlotAvailabilityReturnKey;
  }

  // ________________________________________________________________________
  /**
   * Create a slot.
   *
   * @param slotCreateDetails
   * Slot creation details.
   *
   * @return Slot identifier.
   */
  public CreateSlotReturnKey createSlot(SlotCreateDetails slotCreateDetails)
    throws AppException, InformationalException {

    // Create return object
    CreateSlotReturnKey createSlotReturnKey = new CreateSlotReturnKey();

    // Call BPO to create a slot
    createSlotReturnKey.createSlotReturnKey = SlotFactory.newInstance().create(
      slotCreateDetails.slotCreateDetails);

    return createSlotReturnKey;
  }

  // ________________________________________________________________________
  /**
   * Returns a list of daily schedules for a location.
   *
   * @param dailyScheduleListKey
   * Contains the location identifier.
   *
   * @return List of daily schedules.
   */
  public ListDailyScheduleDetails listDailySchedule(
    DailyScheduleListKey dailyScheduleListKey) throws AppException,
      InformationalException {

    // Create return details
    ListDailyScheduleDetails listDailyScheduleDetails = new ListDailyScheduleDetails();

    // Context description key
    LocationContextDescriptionKey locationContextDescriptionKey = new LocationContextDescriptionKey();

    // Call BPO to read list of daily schedules
    listDailyScheduleDetails.listDailyScheduleDetails = DailyScheduleFactory.newInstance().list(
      dailyScheduleListKey.dailyScheduleListKey);

    // Set key to read context description
    locationContextDescriptionKey.locationID = dailyScheduleListKey.dailyScheduleListKey.locationID;

    // Read the context description
    listDailyScheduleDetails.description.description = readLocationContextDescription(locationContextDescriptionKey).description;

    return listDailyScheduleDetails;
  }

  // ________________________________________________________________________
  /**
   * Method to list slots for a daily schedule.
   *
   * @param slotListKey
   * Contains identifier to read list of slots.
   *
   * @return List of slot details.
   */
  public ListSlotDetails listSlot(SlotListKey slotListKey) throws AppException,
      InformationalException {

    // Create return object
    ListSlotDetails listSlotDetails = new ListSlotDetails();

    // Context description key
    DailyScheduleKey dailyScheduleKey_fo = new DailyScheduleKey();

    // Call BPO to retrieve a list of slots
    listSlotDetails.listSlotdetails = SlotFactory.newInstance().list(
      slotListKey.slotListKey);

    // Set key to read context description
    dailyScheduleKey_fo.dailyScheduleKey.scheduleID = slotListKey.slotListKey.scheduleID;

    // Read context description
    listSlotDetails.description.description = readDailyScheduleContextDescription(dailyScheduleKey_fo).description;

    return listSlotDetails;
  }

  // __________________________________________________________________________
  /**
   * Modify a daily schedule.
   *
   * @param dailyScheduleModifyDetails
   * Details to modify a daily schedule.
   */
  public void modifyDailySchedule(
    DailyScheduleModifyDetails dailyScheduleModifyDetails)
    throws AppException, InformationalException {

    // Modify daily schedule
    DailyScheduleFactory.newInstance().modify(
      dailyScheduleModifyDetails.dailyScheduleModifyDetails);
  }

  // ________________________________________________________________________
  /**
   * Modifies a position slot availability record.
   *
   * @param positionSlotAvailabilityModifyDetails
   * Position slot availability details
   */
  public void modifyPositionSlotAvailability(
    PositionSlotAvailabilityModifyDetails positionSlotAvailabilityModifyDetails)
    throws AppException, InformationalException {

    // Modify a position slot availability record
    PositionSlotAvailabilityFactory.newInstance().modify(
      positionSlotAvailabilityModifyDetails.positionSlotAvailabilityModifyDetails);
  }

  // _______________________________________________________________________
  /**
   * Modifies slot details.
   *
   * @param slotModifyDetails
   * Modified slot details.
   */
  public void modifySlot(SlotModifyDetails slotModifyDetails)
    throws AppException, InformationalException {

    // Modify slot details
    SlotFactory.newInstance().modify(slotModifyDetails.slotModifyDetails);
  }

  // ________________________________________________________________________
  /**
   * Reads the daily schedule details.
   *
   * @param dailyScheduleKey
   * Contains identifier to read daily schedule
   *
   * @return Daily schedule details
   */
  public DailyScheduleDetails readDailySchedule(
    DailyScheduleKey dailyScheduleKey) throws AppException,
      InformationalException {

    // Create return object
    DailyScheduleDetails dailyScheduleDetails = new DailyScheduleDetails();

    // Slot manipulations variables
    curam.core.sl.struct.SlotListKey slotListKey = new curam.core.sl.struct.SlotListKey();

    // Call BPO to read daily schedule details
    dailyScheduleDetails.dailyScheduleDetails = DailyScheduleFactory.newInstance().read(
      dailyScheduleKey.dailyScheduleKey);

    // Set key to read list
    slotListKey.scheduleID = dailyScheduleKey.dailyScheduleKey.scheduleID;

    // Call BPO to retrieve list of slots
    curam.core.sl.struct.ListSlotDetails listSlotDetails = SlotFactory.newInstance().list(
      slotListKey);

    // Set in return object
    dailyScheduleDetails.slots.slotDtlsList = listSlotDetails.slotDtlsList;

    // Read context description
    dailyScheduleDetails.description.description = readDailyScheduleContextDescription(dailyScheduleKey).description;

    return dailyScheduleDetails;
  }

  // ________________________________________________________________________
  /**
   * Read daily schedule context description.
   *
   * @param dailyScheduleKeyObj
   * Contains daily schedule identifier.
   *
   * @return Daily schedule context description details.
   */
  @Override
  protected DailyScheduleContextDescription readDailyScheduleContextDescription(
    DailyScheduleKey dailyScheduleKeyObj) throws AppException,
      InformationalException {

    // Create return struct
    DailyScheduleContextDescription dailyScheduleContextDescription = new DailyScheduleContextDescription();

    // Context description key
    curam.core.sl.entity.struct.DailyScheduleKey dailyScheduleKey = new curam.core.sl.entity.struct.DailyScheduleKey();

    // Set key to read context description
    dailyScheduleKey.scheduleID = dailyScheduleKeyObj.dailyScheduleKey.scheduleID;

    // Read daily schedule details
    dailyScheduleContextDescription.description = curam.core.sl.entity.fact.DailyScheduleFactory.newInstance().readName(dailyScheduleKey).name;

    return dailyScheduleContextDescription;
  }

  // ________________________________________________________________________
  /**
   * Reads slot details.
   *
   * @param slotKey
   * Contains slot identifier.
   *
   * @return Slot details.
   */
  public SlotDetails readSlot(SlotKey slotKey) throws AppException,
      InformationalException {

    // Details to be returned
    curam.core.facade.struct.SlotDetails slotDetailsObj = new curam.core.facade.struct.SlotDetails();

    // Call BPO to read slot details
    slotDetailsObj.slotDetails = SlotFactory.newInstance().read(slotKey.slotKey);

    // PositionSlotAvailability manipulation variables
    curam.core.sl.struct.PositionSlotAvailabilityListKey positionSlotAvailabilityListKey = new curam.core.sl.struct.PositionSlotAvailabilityListKey();

    // Set key to read list of position slot availability records
    positionSlotAvailabilityListKey.slotID = slotKey.slotKey.slotID;

    // Call BPO to read position slot availability list
    slotDetailsObj.postionSlotAvailabilityList = PositionSlotAvailabilityFactory.newInstance().list(
      positionSlotAvailabilityListKey);

    // Read context description
    slotDetailsObj.description.description = readSlotContextDescription(slotKey).description;

    return slotDetailsObj;
  }

  // _________________________________________________________________________
  /**
   * Read slot context description.
   *
   * @param slotKey
   * Contains slot identifier.
   *
   * @return Slot context description details.
   */
  @Override
  protected SlotContextDescription readSlotContextDescription(SlotKey slotKey)
    throws AppException, InformationalException {

    // Create return object
    SlotContextDescription slotContextDescription = new SlotContextDescription();

    // Slot manipulation variables
    curam.core.sl.entity.struct.SlotKey slotKeyObj = new curam.core.sl.entity.struct.SlotKey();

    // Set key to read context description
    slotKeyObj.slotID = slotKey.slotKey.slotID;

    // Read context description
    slotContextDescription.description = curam.core.sl.entity.fact.SlotFactory.newInstance().readName(slotKeyObj).name;

    return slotContextDescription;
  }

  // ________________________________________________________________________
  /**
   * Read list of position slot availability records.
   *
   * @param positionSlotAvailabilityListKey
   * Contains slot identifier and position identifier.
   *
   * @return List of position slot availability records
   */
  public ListPositionSlotAvailabilityDetails listPositionSlotAvailability(
    PositionSlotAvailabilityListKey positionSlotAvailabilityListKey)
    throws AppException, InformationalException {

    // Create return object
    ListPositionSlotAvailabilityDetails listPositionSlotAvailabilityDetails = new ListPositionSlotAvailabilityDetails();

    // Context description key
    SlotKey slotKey_fo = new SlotKey();

    // Call BPO to retrieve position slot availability list
    listPositionSlotAvailabilityDetails.listPositionSlotAvailabilityDetails = PositionSlotAvailabilityFactory.newInstance().list(
      positionSlotAvailabilityListKey.positionSlotAvailabilityListKey);

    // Set context description key
    slotKey_fo.slotKey.slotID = positionSlotAvailabilityListKey.positionSlotAvailabilityListKey.slotID;

    // Read context description
    listPositionSlotAvailabilityDetails.description.description = readSlotContextDescription(slotKey_fo).description;

    return listPositionSlotAvailabilityDetails;
  }

  // ________________________________________________________________________
  /**
   * Reads position slot availability details.
   *
   * @param readPositionSlotAvailabiliySlotID
   * Contains position slot availability identifier.
   *
   * @return Position slot availability details.
   */
  public PositionSlotAvailabilityDetails readPositionSlotAvailability(
    ReadPositionSlotAvailabiliySlotID readPositionSlotAvailabiliySlotID)
    throws AppException, InformationalException {

    // Create return object
    PositionSlotAvailabilityDetails positionSlotAvailabilityDetails = new PositionSlotAvailabilityDetails();

    // Context description key
    SlotKey slotKey_fo = new SlotKey();

    // Call BPO to read position slot availability details
    positionSlotAvailabilityDetails.positionSlotAvailabilityDetails = PositionSlotAvailabilityFactory.newInstance().read(
      readPositionSlotAvailabiliySlotID.positionSlotAvailabilityKey);

    // Set key to read context description
    slotKey_fo.slotKey.slotID = positionSlotAvailabilityDetails.positionSlotAvailabilityDetails.details.slotID;

    // Read context description
    positionSlotAvailabilityDetails.description.description = readSlotContextDescription(slotKey_fo).description;

    return positionSlotAvailabilityDetails;
  }

  // BEGIN, CR00341851, MV
  /**
   * This method cancels a user skill.
   *
   * @param cancelUserSkillDetails
   * User Skill details details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.5.0, replaced with
   * {@link #cancelUserSkillsDetails(UserLanguageSkillCreationDetails)}
   * This method is deprecated because of the new requirement where
   * informational has to be return when the redetermination of
   * translator required runs on batch. See release note:
   * CR00341851.
   */
  // END, CR00341851
  public void cancelUserSkillDetails(
    final CancelUserSkillDetails cancelUserSkillDetails) throws AppException,
      InformationalException {

    // Cancel position
    UserSkillFactory.newInstance().cancel(
      cancelUserSkillDetails.cancelUserSkillDetails);
    // BEGIN, CR00226837, PB
    UserSkill userSkillObj = UserSkillFactory.newInstance();
    ReadUserSkillDetails readUserSkillDetails = new ReadUserSkillDetails();
    ReadUserSkillKey readUserSkillKey = new ReadUserSkillKey();

    readUserSkillKey.userSkillID = cancelUserSkillDetails.cancelUserSkillDetails.key.userSkillID;

    readUserSkillDetails = userSkillObj.read(readUserSkillKey);

    if (readUserSkillDetails.details.skillType.equals(SKILLTYPE.LANGUAGES)) {
      RedetermineTranslatorStruct redetermineTranslatorStruct = new RedetermineTranslatorStruct();

      CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();

      redetermineTranslatorStruct.userName = readUserSkillDetails.details.userName;
      caseParticipantRoleObj.redetermineTranslator(redetermineTranslatorStruct);
    }
    // END, CR00226837
  }
  
  // BEGIN, CR00341851, MV
  /**
   * This method cancels a user skill.
   *
   * @param cancelUserSkillDetails
   * User Skill details details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMsgDtlsList cancelUserSkillsDetails(
    final CancelUserSkillDetails cancelUserSkillDetails) throws AppException,
      InformationalException {

    UserSkillFactory.newInstance().cancel(
      cancelUserSkillDetails.cancelUserSkillDetails);
  
    final ReadUserSkillKey readUserSkillKey = new ReadUserSkillKey();

    readUserSkillKey.userSkillID = cancelUserSkillDetails.cancelUserSkillDetails.key.userSkillID;
    final ReadUserSkillDetails readUserSkillDetails = UserSkillFactory.newInstance().read(
      readUserSkillKey);

    final int kMaxNoCases;
    final String envMaxNoCases = Configuration.getProperty(
      EnvVars.ENV_CASES_MAXNOCASES_ONLINEAUTOTRANSLATORDETERMINATION);
  
    if (null == envMaxNoCases) {
      kMaxNoCases = EnvVars.ENV_CASES_MAXNOCASES_ONLINEAUTOTRANSLATORDETERMINATION_DEFAULT;
    } else {
      kMaxNoCases = Integer.parseInt(envMaxNoCases);
    }
  
    final UserNameTypeAndStatusCode userNameTypeAndStatusCode = new UserNameTypeAndStatusCode();

    userNameTypeAndStatusCode.userName = readUserSkillDetails.details.userName;
    userNameTypeAndStatusCode.statusCode = CASESTATUSEntry.CLOSED.getCode();
    CaseIDStructList caseIDStructList = CaseHeaderFactory.newInstance().searchCaseIDByUserNameAndCaseStatus(
      userNameTypeAndStatusCode);
    final InformationalMsgDtlsList informationMsgDtlsList = new InformationalMsgDtlsList();
  
    if (SKILLTYPE.LANGUAGES.equals(readUserSkillDetails.details.skillType)) {
      // The number of cases owned by a particular case owner is less than or equal to that the environmental variable
      // then the execution will happen in on-line mode
      if (kMaxNoCases >= caseIDStructList.dtls.size()) {
    
        final RedetermineTranslatorStruct redetermineTranslatorStruct = new RedetermineTranslatorStruct();

        redetermineTranslatorStruct.userName = readUserSkillDetails.details.userName;
        CaseParticipantRoleFactory.newInstance().redetermineTranslator(
          redetermineTranslatorStruct);
      } else {
      
        final LocalisableString infoMessage = new LocalisableString(
          BPOREDETERMINETRANSLATOR.INF_PDPI_XFV_BATCHPROCESS_SHOULDBE_EXECUTED);

        ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          infoMessage, CuramConst.gkEmpty,
          InformationalElement.InformationalType.kWarning,
          ValidationManagerConst.kSetOne, 1);
      }
    
      final String[] warnings = TransactionInfo.getInformationalManager().obtainInformationalAsString();

      for (final String informationMsgTxt : warnings) {
      
        final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt = informationMsgTxt;
        informationMsgDtlsList.dtls.addRef(informationalMsgDtls);
      }
    }
    return informationMsgDtlsList;
  }

  // END, CR00341851

  /**
   * Create a user skill.
   *
   * @param userSkillCreateDetails
   * user skill creation details
   */
  public void createUserSkill(UserSkillCreateDetails userSkillCreateDetails)
    throws AppException, InformationalException {

    // Create new user skill
    UserSkillFactory.newInstance().create(
      userSkillCreateDetails.userSkillCreateDetails);

  }

  /**
   * Modifies user skill details.
   *
   * @param userSkillModifyDetails
   * Details of user skill to be modified
   */
  public void modifyUserSkill(UserSkillModifyDetails userSkillModifyDetails)
    throws AppException, InformationalException {

    // Update user skill details
    UserSkillFactory.newInstance().modify(
      userSkillModifyDetails.modifyUserSkillDetails);
  }

  /**
   * This method reads a user skill record.
   *
   * @param userSkillKey
   * user skill id
   *
   * @return user skill details
   *
   * @deprecated Since Curam 6.0.
   */
  @Deprecated
  public UserSkillDetails viewUserSkill(UserSkillKey userSkillKey)
    throws AppException, InformationalException {

    // Return variable for organization structure details
    UserSkillDetails userSkillDetails = new UserSkillDetails();

    // Read organization structure details
    userSkillDetails.userSkillDetails = UserSkillFactory.newInstance().read(
      userSkillKey.userSkillKey);

    // Return organization structure details
    return userSkillDetails;
  }

  /**
   * This method gets the user skill context description.
   *
   * @param userSkillKey
   * user skill id
   *
   * @return user skill context description details
   */
  @Override
  protected UserSkillContextDescription readUserSkillContextDescription(
    UserSkillKey userSkillKey) throws AppException, InformationalException {

    UserSkillContextDescription userSkillContextDescription = new UserSkillContextDescription();

    // TODO: unimplemented?

    // Return details
    return userSkillContextDescription;
  }
  
  // BEGIN, CR00332548, VT
  
  /**
   * Method to list user skills for a user.
   *
   * @param userSkillListKey
   * user name
   *
   * @return list of user skills
   *
   * @deprecated Since Curam 6.0.4.0, replaced with
   * {@link Organization#getUserSkills(UserSkillListKey)}. This
   * method is being deprecated as the return struct does not have
   * an attribute to identify the language skill type. See release
   * note:CEF-9913.
   */
  // END, CR00332548
  @Deprecated
  public ListUserSkillDetails listUserSkill(UserSkillListKey userSkillListKey)
    throws AppException, InformationalException {

    // OrganizationUserContextDescriptionKey
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    // Key to read user skill details list
    ListUserSkillKey listUserSkillKey = new ListUserSkillKey();

    // Return variable for user skill details list
    ListUserSkillDetails listUserSkillDetails = new ListUserSkillDetails();

    // Assign details to key to read user skill details list for user
    listUserSkillKey.userName = userSkillListKey.userSkillList.userName;

    // Read user skill details list for user
    listUserSkillDetails.listUserSkillDetails = UserSkillFactory.newInstance().list(
      listUserSkillKey);
   
    organizationUserContextDescriptionKey.userName = userSkillListKey.userSkillList.userName;

    // Read user name description
    listUserSkillDetails.description.description = readUserContextDescription(organizationUserContextDescriptionKey).description;

    // Return user skill details list
    return listUserSkillDetails;
  }

  /**
   * Presentation layer operation to search for organization units.
   *
   * @param organisationUnitSearchCriteria
   * organization unit to be read
   *
   * @return details list of the organization unit
   */
  public OrganisationUnitSearchResults searchOrganisationUnit(
    OrganisationUnitSearchCriteria organisationUnitSearchCriteria)
    throws AppException, InformationalException {

    // Details to be returned
    OrganisationUnitSearchResults organisationUnitSearchResults = new OrganisationUnitSearchResults();

    // Search for organization units
    organisationUnitSearchResults.results = OrganisationUnitFactory.newInstance().search(
      organisationUnitSearchCriteria.criteria);

    // Return details
    return organisationUnitSearchResults;
  }

  /**
   * Retrieves the case approval check information for the specified
   * organization unit.
   *
   * @param key
   * List Org Unit case approval key
   *
   * @return a list of Org Unit case approval details
   */
  public ListOrgUnitCaseApprovalDetails listOrgUnitCaseApproval(
    ListOrgUnitCaseApprovalKey key) throws AppException,
      InformationalException {

    // Return object
    ListOrgUnitCaseApprovalDetails listOrgUnitCaseApprovalDetails = new ListOrgUnitCaseApprovalDetails();

    // Context description key object
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Get list of approval checks by organization unit
    listOrgUnitCaseApprovalDetails.caseApprovalCheckDetailsList = CaseApprovalCheckFactory.newInstance().listApprovalChecksByOrgUnit(
      key.searchAllOrgUnitCheckKey);

    // Set context description key
    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.searchAllOrgUnitCheckKey.searchAllOrgUnitCheckKey.organisationUnitID;

    // Get context description
    listOrgUnitCaseApprovalDetails.organisationUnitContextDescriptionDetails = readOrganisationUnitContextDescription(
      organisationUnitKey);

    // Return details
    return listOrgUnitCaseApprovalDetails;
  }

  /**
   * This method will change the recordStatus of Case Approval Check from Active
   * to Canceled.
   *
   * @param key
   * The key of the organization unit case approval
   */
  public void cancelOrgUnitCaseApproval(CancelOrgUnitCaseApprovalKey key)
    throws AppException, InformationalException {

    // Cancel the case approval
    CaseApprovalCheckFactory.newInstance().cancel(
      key.cancelCaseApprovalCheckDetails);
  }

  /**
   * Adds case approval check information for an organization unit. For example,
   * this could specify that 10% of cases for a specified organization unit are
   * sent for manual approval checking.
   *
   * @param details
   * Case approval check details for the organization unit.
   */
  public void createOrgUnitCaseApproval(CaseApprovalCheckDetails details)
    throws AppException, InformationalException {

    // Create Case Approval Check
    CaseApprovalCheckFactory.newInstance().create(
      details.caseApprovalCheckDetails);
  }

  /**
   * Modifies case approval check information for an organization unit. For
   * example, this could specify that 10% of cases for a specified organization
   * unit are sent for manual approval checking.
   *
   * @param details
   * The modified case approval check details for the organization
   * unit.
   */
  public void modifyOrgUnitCaseApproval(CaseApprovalCheckDetails details)
    throws AppException, InformationalException {

    // Modify a case approval
    CaseApprovalCheckFactory.newInstance().modify(
      details.caseApprovalCheckDetails);
  }

  /**
   * Retrieves the details of the specified organization unit case approval
   * check information.
   *
   * @param key
   * Unique identifier for the approval check.
   *
   * @return Organization Unit case approval details
   */
  public ReadOrgUnitCaseApprovalDetails readOrgUnitCaseApproval(
    ReadOrgUnitCaseApprovalKey key) throws AppException,
      InformationalException {

    // Object to be returned
    ReadOrgUnitCaseApprovalDetails readOrgUnitCaseApprovalDetails = new ReadOrgUnitCaseApprovalDetails();

    // Read the case approval checks
    readOrgUnitCaseApprovalDetails.readCaseApprovalCheckDetails = CaseApprovalCheckFactory.newInstance().read(
      key.caseApprovalCheckKey);

    // Context description key object
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Set context description key
    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = readOrgUnitCaseApprovalDetails.readCaseApprovalCheckDetails.caseApprovalCheckDetails.organisationUnitID;

    // SID Validation
    curam.core.sl.struct.OrgStructureAndOrgUnitKey orgStructureAndOrgUnitKey = new curam.core.sl.struct.OrgStructureAndOrgUnitKey();

    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID = key.organisationStructureID;

    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID = readOrgUnitCaseApprovalDetails.readCaseApprovalCheckDetails.caseApprovalCheckDetails.organisationUnitID;

    OrganisationAdminSecurity organisationAdminSecurity = new OrganisationAdminSecurity();

    OrganisationAdminSecurityResult organisationAdminSecurityResult = organisationAdminSecurity.checkReadOrganisationSecurity(
      orgStructureAndOrgUnitKey);

    if (!organisationAdminSecurityResult.result) {
      throw new AppException(
        BPOORGANISATIONUNIT.ERR_ORGANISATIONSECURITY_CHECK_FAILED);
    }

    // Get context description
    readOrgUnitCaseApprovalDetails.organisationUnitContextDescriptionDetails = readOrganisationUnitContextDescription(
      organisationUnitKey);

    // Return details
    return readOrgUnitCaseApprovalDetails;
  }

  /**
   * Updates the recordStatus of the EvidenceApprovalCheck record to be
   * canceled.
   *
   * @param cancelOrgUnitEvidenceApprovalKey
   * The key of the user evidence approval
   */
  public void cancelOrgUnitEvidenceApproval(
    CancelOrgUnitEvidenceApprovalKey cancelOrgUnitEvidenceApprovalKey)
    throws AppException, InformationalException {

    // Use the EvidenceApprovalCheck to perform the cancel operation
    EvidenceApprovalCheckFactory.newInstance().cancel(
      cancelOrgUnitEvidenceApprovalKey.cancelEvidenceApprovalCheckDetails);
  }

  /**
   * Updates the recordStatus of the EvidenceApprovalCheck record to be
   * canceled.
   *
   * @param cancelUserEvidenceApprovalKey
   * The key of the user evidence approval
   */
  public void cancelUserEvidenceApproval(
    CancelUserEvidenceApprovalKey cancelUserEvidenceApprovalKey)
    throws AppException, InformationalException {

    // Use the EvidenceApprovalCheck to perform the cancel operation
    EvidenceApprovalCheckFactory.newInstance().cancel(
      cancelUserEvidenceApprovalKey.cancelEvidenceApprovalCheckDetails);
  }

  /**
   * Adds evidence approval check information for an organization unit. For
   * example, this could specify that 10% of evidence updates for a specified
   * user are sent for manual approval checking.
   *
   * @param evidenceApprovalCheckDetails
   * The details of the Evidence Approval to create
   */
  public void createOrgUnitEvidenceApproval(
    EvidenceApprovalCheckDetails evidenceApprovalCheckDetails)
    throws AppException, InformationalException {

    // Use the EvidenceApprovalCheck to perform the create operation
    EvidenceApprovalCheckFactory.newInstance().create(
      evidenceApprovalCheckDetails.evidenceApprovalCheckDetails);
  }

  /**
   * Adds evidence approval check information for a user. For example, this
   * could specify that 10% of evidence updates for a specified user are sent
   * for manual approval checking.
   *
   * @param evidenceApprovalCheckDetails
   * The details of the Evidence Approval to create
   */
  public void createUserEvidenceApproval(
    EvidenceApprovalCheckDetails evidenceApprovalCheckDetails)
    throws AppException, InformationalException {

    // Use the EvidenceApprovalCheck to perform the create operation
    EvidenceApprovalCheckFactory.newInstance().create(
      evidenceApprovalCheckDetails.evidenceApprovalCheckDetails);
  }

  /**
   * Retrieves the evidence approval check information for the specified user.
   *
   * @param listOrgUnitEvidenceApprovalKey
   * List User evidence approval key.
   *
   * @return A list of the Evidence Approvals found for the given key.
   */
  public ListOrgUnitEvidenceApprovalDetails listOrgUnitEvidenceApproval(
    ListOrgUnitEvidenceApprovalKey listOrgUnitEvidenceApprovalKey)
    throws AppException, InformationalException {

    ListOrgUnitEvidenceApprovalDetails listOrgUnitEvidenceApprovalDetails = new ListOrgUnitEvidenceApprovalDetails();

    // Use the EvidenceApprovalCheck to perform the modify operation
    listOrgUnitEvidenceApprovalDetails.evidenceApprovalCheckDetailsList = EvidenceApprovalCheckFactory.newInstance().listEvidenceApprovalChecksByOrgUnit(
      listOrgUnitEvidenceApprovalKey.searchByOrgUnitKey);

    // Context description key object
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Set context description key
    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = listOrgUnitEvidenceApprovalKey.searchByOrgUnitKey.searchByOrgUnitKey.organisationUnitID;

    // Get context description
    listOrgUnitEvidenceApprovalDetails.organisationUnitContextDescriptionDetails = readOrganisationUnitContextDescription(
      organisationUnitKey);

    return listOrgUnitEvidenceApprovalDetails;
  }

  /**
   * Retrieves the evidence approval check information for the specified user.
   *
   * @param listUserEvidenceApprovalKey
   * List User evidence approval key.
   *
   * @return A list of the Evidence Approvals found for the given key.
   */
  public ListUserEvidenceApprovalDetails listUserEvidenceApproval(
    ListUserEvidenceApprovalKey listUserEvidenceApprovalKey)
    throws AppException, InformationalException {

    // Create the object to be returned as a result of this query
    ListUserEvidenceApprovalDetails listUserEvidenceApprovalDetails = new ListUserEvidenceApprovalDetails();

    // Use the EvidenceApprovalCheck to do the read and collect the results
    listUserEvidenceApprovalDetails.evidenceApprovalCheckDetailsList = EvidenceApprovalCheckFactory.newInstance().listEvidenceApprovalChecksByUser(
      listUserEvidenceApprovalKey.searchByUserKey);

    // Also fetch the Organization Unit Context Description details
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    organizationUserContextDescriptionKey.userName = listUserEvidenceApprovalKey.searchByUserKey.searchByUserKey.userName;

    // Retrieve the User Context Description using the context key.
    listUserEvidenceApprovalDetails.userContextDescriptionDetails = readUserContextDescription(
      organizationUserContextDescriptionKey);

    // Return details
    return listUserEvidenceApprovalDetails;
  }

  /**
   * Modifies evidence approval check information for an org unit. For example,
   * this could specify that 10% of evidence updates for a specified user are
   * sent for manual approval checking.
   *
   * @param evidenceApprovalCheckDetails
   * The modified evidence approval check details for the user.
   */
  public void modifyOrgUnitEvidenceApproval(
    EvidenceApprovalCheckDetails evidenceApprovalCheckDetails)
    throws AppException, InformationalException {

    // Use the EvidenceApprovalCheck to perform the modify operation
    EvidenceApprovalCheckFactory.newInstance().modify(
      evidenceApprovalCheckDetails.evidenceApprovalCheckDetails);
  }

  /**
   * Modifies evidence approval check information for a User. For example, this
   * could specify that 10% of evidence updates for a specified user are sent
   * for manual approval checking.
   *
   * @param evidenceApprovalCheckDetails
   * The modified evidence approval check details for the user.
   */
  public void modifyUserEvidenceApproval(
    EvidenceApprovalCheckDetails evidenceApprovalCheckDetails)
    throws AppException, InformationalException {

    // Use the EvidenceApprovalCheck to perform the create operation
    EvidenceApprovalCheckFactory.newInstance().modify(
      evidenceApprovalCheckDetails.evidenceApprovalCheckDetails);
  }

  /**
   * Retrieves the details of the specified evidence approval check information.
   *
   * @param readOrgUnitEvidenceApprovalKey
   * The unique identifier of the Evidence Approval to be read.
   *
   * @return User evidence approval details
   */
  public ReadOrgUnitEvidenceApprovalDetails readOrgUnitEvidenceApproval(
    ReadOrgUnitEvidenceApprovalKey readOrgUnitEvidenceApprovalKey)
    throws AppException, InformationalException {

    ReadOrgUnitEvidenceApprovalDetails readOrgUnitEvidenceApprovalDetails = new ReadOrgUnitEvidenceApprovalDetails();

    // Use the EvidenceApprovalCheck to perform the modify operation
    readOrgUnitEvidenceApprovalDetails.readEvidenceApprovalCheckDetails = EvidenceApprovalCheckFactory.newInstance().read(
      readOrgUnitEvidenceApprovalKey.evidenceApprovalCheckKey);

    // Context description key object
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Set context description key
    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = readOrgUnitEvidenceApprovalDetails.readEvidenceApprovalCheckDetails.evidenceApprovalCheckDetails.organisationUnitID;

    // SID Validation
    curam.core.sl.struct.OrgStructureAndOrgUnitKey orgStructureAndOrgUnitKey = new curam.core.sl.struct.OrgStructureAndOrgUnitKey();

    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID = readOrgUnitEvidenceApprovalKey.organisationStructureID;

    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID = readOrgUnitEvidenceApprovalDetails.readEvidenceApprovalCheckDetails.evidenceApprovalCheckDetails.organisationUnitID;

    OrganisationAdminSecurity organisationAdminSecurity = new OrganisationAdminSecurity();

    OrganisationAdminSecurityResult organisationAdminSecurityResult = organisationAdminSecurity.checkReadOrganisationSecurity(
      orgStructureAndOrgUnitKey);

    if (!organisationAdminSecurityResult.result) {
      throw new AppException(
        BPOORGANISATIONUNIT.ERR_ORGANISATIONSECURITY_CHECK_FAILED);
    }

    // Get context description
    readOrgUnitEvidenceApprovalDetails.organisationUnitContextDescriptionDetails = readOrganisationUnitContextDescription(
      organisationUnitKey);

    return readOrgUnitEvidenceApprovalDetails;
  }

  /**
   * Retrieves the details of the specified evidence approval check information.
   *
   * @param readUserEvidenceApprovalKey
   * The unique identifier of the Evidence Approval to be read.
   *
   * @return User evidence approval details
   */
  public ReadUserEvidenceApprovalDetails readUserEvidenceApproval(
    ReadUserEvidenceApprovalKey readUserEvidenceApprovalKey)
    throws AppException, InformationalException {

    ReadUserEvidenceApprovalDetails readUserEvidenceApprovalDetails = new ReadUserEvidenceApprovalDetails();

    // Use the EvidenceApprovalCheck to perform the create operation
    readUserEvidenceApprovalDetails.readEvidenceApprovalCheckDetails = EvidenceApprovalCheckFactory.newInstance().read(
      readUserEvidenceApprovalKey.evidenceApprovalCheckKey);

    // Context description key object
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    // Set context description key
    organizationUserContextDescriptionKey.userName = readUserEvidenceApprovalDetails.readEvidenceApprovalCheckDetails.evidenceApprovalCheckDetails.userName;

    // Get context description
    readUserEvidenceApprovalDetails.userContextDescriptionDetails = readUserContextDescription(
      organizationUserContextDescriptionKey);

    // Return details
    return readUserEvidenceApprovalDetails;
  }

  /**
   * Retrieves the bread crumb menu data details for an organization unit.
   *
   * @param orgStructureBrowserKey
   * The unique identifier of the organization unit we need to get the
   * bread crumb data for.
   *
   * @return Bread crumb data details
   */
  public OrgStructureBreadCrumbDetails getOrgStructureBreadCrumb(
    OrgStructureBrowserKey orgStructureBrowserKey) throws AppException,
      InformationalException {

    // Create return object
    OrgStructureBreadCrumbDetails orgStructureBreadCrumbDetails = new OrgStructureBreadCrumbDetails();

    boolean parentOrgUnitExists = true;

    curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();

    OrganisationUnitAndParentNameDetails organisationUnitAndParentNameDetails = new OrganisationUnitAndParentNameDetails();
    OrganisationUnitIDAndNameDetails organisationUnitIDAndNameDetails = new OrganisationUnitIDAndNameDetails();
    OrganisationUnitIDAndNameDetailsList organisationUnitIDAndNameDetailsList = new OrganisationUnitIDAndNameDetailsList();
    OrgUnitIDAndOrgStructIDKey orgUnitIDAndOrgStructIDKey = new OrgUnitIDAndOrgStructIDKey();

    orgUnitIDAndOrgStructIDKey.organisationStructureID = orgStructureBrowserKey.orgStructureBrowserKey.organisationStructureID;
    orgUnitIDAndOrgStructIDKey.organisationUnitID = orgStructureBrowserKey.orgStructureBrowserKey.elementID;

    // Read up through the org unit hierarchy until the root org unit is found
    while (parentOrgUnitExists) {

      organisationUnitIDAndNameDetails = new OrganisationUnitIDAndNameDetails();

      try {

        // Read organization unit
        organisationUnitAndParentNameDetails = organisationUnitObj.readByOrgStructure(
          orgUnitIDAndOrgStructIDKey);

        organisationUnitIDAndNameDetails = new OrganisationUnitIDAndNameDetails();

        organisationUnitIDAndNameDetails.assign(
          organisationUnitAndParentNameDetails);

        organisationUnitIDAndNameDetailsList.dtls.addRef(
          organisationUnitIDAndNameDetails);

      } catch (curam.util.exception.RecordNotFoundException e) {// do nothing
      }

      if (organisationUnitAndParentNameDetails.parentOrganisationUnitID == 0) {

        parentOrgUnitExists = false;

      } else {

        orgUnitIDAndOrgStructIDKey.organisationUnitID = organisationUnitAndParentNameDetails.parentOrganisationUnitID;
      }
    }

    // Create Root Node
    Element navigationMenuElement = new Element(kNavigationMenu);

    // Child Node
    Element linkElement;

    // We need to display the root org unit first and then each subsequent
    // org unit in the hierarchy so we need to start with the last item in the
    // list
    for (int i = organisationUnitIDAndNameDetailsList.dtls.size(); i != 0; i--) {

      // Create Child Node
      linkElement = new Element(kItem);

      LocalisableString description = new LocalisableString(
        BPOORGANIZATION.INF_ORGSTRUCTUREBROWSER_MENU_DESCRIPTION);

      String orgUnitName = organisationUnitIDAndNameDetailsList.dtls.item(i - 1).name;

      description.arg(orgUnitName);
      linkElement.setAttribute(kPageID, kOrgUnitBrowser);
      linkElement.setAttribute(kDesc, description.toClientFormattedText());

      navigationMenuElement.addContent(linkElement);

      Element paramElementOne = new Element(kParam);
      Element paramElementTwo = new Element(kParam);
      Element paramElementThree = new Element(kParam);

      paramElementOne.setAttribute(kName, kParamOrgStructureID);
      paramElementOne.setAttribute(kValue,
        String.valueOf(
        orgStructureBrowserKey.orgStructureBrowserKey.organisationStructureID));

      linkElement.addContent(paramElementOne);

      paramElementTwo.setAttribute(kName, kParamElementID);
      paramElementTwo.setAttribute(kValue,
        String.valueOf(
        organisationUnitIDAndNameDetailsList.dtls.item(i - 1).organisationUnitID));

      linkElement.addContent(paramElementTwo);

      paramElementThree.setAttribute(kName, kParamElementID);
      paramElementThree.setAttribute(kValue, ELEMENTTYPE.ORGANIZATIONUNIT);
      linkElement.addContent(paramElementThree);
    }

    // Output the XML as a string and assign it to the return object
    XMLOutputter outputter = new XMLOutputter();

    orgStructureBreadCrumbDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return orgStructureBreadCrumbDetails;
  }

  /**
   * Retrieves the bread crumb menu data details for a position.
   *
   * @param orgStructureBrowserKey
   * The unique identifier of the position we need to get the bread
   * crumb data for.
   *
   * @return Bread crumb data details
   */
  public OrgStructureBreadCrumbDetails getPositionBreadCrumb(
    OrgStructureBrowserKey orgStructureBrowserKey) throws AppException,
      InformationalException {

    // Create return object
    OrgStructureBreadCrumbDetails orgStructureBreadCrumbDetails = new OrgStructureBreadCrumbDetails();

    curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();

    curam.core.sl.entity.intf.Position positionObj = curam.core.sl.entity.fact.PositionFactory.newInstance();

    OrganisationUnitAndParentNameDetails organisationUnitAndParentNameDetails = new OrganisationUnitAndParentNameDetails();
    OrganisationUnitIDAndNameDetails organisationUnitIDAndNameDetails = new OrganisationUnitIDAndNameDetails();
    OrganisationUnitIDAndNameDetailsList organisationUnitIDAndNameDetailsList = new OrganisationUnitIDAndNameDetailsList();
    OrgUnitIDAndOrgStructIDKey orgUnitIDAndOrgStructIDKey = new OrgUnitIDAndOrgStructIDKey();
    PositionIDAndOrgStructIDKey positionIDAndOrgStructIDKey = new PositionIDAndOrgStructIDKey();

    positionIDAndOrgStructIDKey.organisationStructureID = orgStructureBrowserKey.orgStructureBrowserKey.organisationStructureID;
    positionIDAndOrgStructIDKey.positionID = orgStructureBrowserKey.orgStructureBrowserKey.elementID;

    // Read Position details
    PositionAndOrgUnitIDDetails positionAndOrgUnitIDDetails = positionObj.readByOrgStructure(
      positionIDAndOrgStructIDKey);

    // Get organization id for position
    orgUnitIDAndOrgStructIDKey.organisationStructureID = orgStructureBrowserKey.orgStructureBrowserKey.organisationStructureID;
    orgUnitIDAndOrgStructIDKey.organisationUnitID = positionAndOrgUnitIDDetails.organisationUnitID;

    // Read Org Unit that this position belongs to
    organisationUnitAndParentNameDetails = organisationUnitObj.readByOrgStructure(
      orgUnitIDAndOrgStructIDKey);

    organisationUnitIDAndNameDetails.assign(
      organisationUnitAndParentNameDetails);

    // add org unit to list
    organisationUnitIDAndNameDetailsList.dtls.addRef(
      organisationUnitIDAndNameDetails);

    // Check to see if this org unit has a parent, if it has then keep
    // reading up through the hierarchy until the root is found
    if (organisationUnitAndParentNameDetails.parentOrganisationUnitID != 0) {

      boolean parentOrgUnitExists = true;

      orgUnitIDAndOrgStructIDKey.organisationUnitID = organisationUnitAndParentNameDetails.parentOrganisationUnitID;

      // Read up through the org unit hierarchy until the root org unit is found
      while (parentOrgUnitExists) {

        // Read organization unit
        organisationUnitAndParentNameDetails = organisationUnitObj.readByOrgStructure(
          orgUnitIDAndOrgStructIDKey);

        organisationUnitIDAndNameDetails = new OrganisationUnitIDAndNameDetails();

        organisationUnitIDAndNameDetails.assign(
          organisationUnitAndParentNameDetails);

        organisationUnitIDAndNameDetailsList.dtls.addRef(
          organisationUnitIDAndNameDetails);

        if (organisationUnitAndParentNameDetails.parentOrganisationUnitID == 0) {

          parentOrgUnitExists = false;

        } else {

          orgUnitIDAndOrgStructIDKey.organisationUnitID = organisationUnitAndParentNameDetails.parentOrganisationUnitID;
        }
      }
    }

    // Create Root Node
    Element navigationMenuElement = new Element(kNavigationMenu);

    // Child Node
    Element linkElement;

    // We need to display the root org unit first and then each subsequent
    // org unit in the hierarchy so we need to start with the last item in the
    // list
    for (int i = organisationUnitIDAndNameDetailsList.dtls.size(); i != 0; i--) {

      // Create Child Node
      linkElement = new Element(kItem);

      LocalisableString description = new LocalisableString(
        BPOORGANIZATION.INF_ORGSTRUCTUREBROWSER_MENU_DESCRIPTION);

      String orgUnitName = organisationUnitIDAndNameDetailsList.dtls.item(i - 1).name;

      description.arg(orgUnitName);

      linkElement.setAttribute(kPageID, kOrgUnitBrowser);
      linkElement.setAttribute(kDesc, description.toClientFormattedText());

      navigationMenuElement.addContent(linkElement);

      Element paramElementOne = new Element(kParam);
      Element paramElementTwo = new Element(kParam);
      Element paramElementThree = new Element(kParam);

      paramElementOne.setAttribute(kName, kParamOrgStructureID);
      paramElementOne.setAttribute(kValue,
        String.valueOf(
        orgStructureBrowserKey.orgStructureBrowserKey.organisationStructureID));

      linkElement.addContent(paramElementOne);

      paramElementTwo.setAttribute(kName, kParamElementID);
      paramElementTwo.setAttribute(kValue,
        String.valueOf(
        organisationUnitIDAndNameDetailsList.dtls.item(i - 1).organisationUnitID));

      linkElement.addContent(paramElementTwo);

      paramElementThree.setAttribute(kName, kParamElementID);
      paramElementThree.setAttribute(kValue, ELEMENTTYPE.ORGANIZATIONUNIT);

      linkElement.addContent(paramElementThree);
    }

    // Now add the position element to the returned XML

    // Create Child Node
    linkElement = new Element(kItem);

    LocalisableString description = new LocalisableString(
      curam.message.BPOORGANIZATION.INF_ORGSTRUCTUREBROWSER_MENU_DESCRIPTION);

    String positionName = positionAndOrgUnitIDDetails.name;

    description.arg(positionName);

    linkElement.setAttribute(kPageID, kOrgUnitBrowser);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());

    navigationMenuElement.addContent(linkElement);

    Element paramElementOne = new Element(kParam);
    Element paramElementTwo = new Element(kParam);
    Element paramElementThree = new Element(kParam);

    paramElementOne.setAttribute(kName, kParamOrgStructureID);
    paramElementOne.setAttribute(kValue,
      String.valueOf(
      orgStructureBrowserKey.orgStructureBrowserKey.organisationStructureID));

    linkElement.addContent(paramElementOne);

    paramElementTwo.setAttribute(kName, kParamElementID);
    paramElementTwo.setAttribute(kValue,
      String.valueOf(positionAndOrgUnitIDDetails.positionID));

    linkElement.addContent(paramElementTwo);

    paramElementThree.setAttribute(kName, kParamElementID);
    paramElementThree.setAttribute(kValue, ELEMENTTYPE.POSITION);

    linkElement.addContent(paramElementThree);

    // Output the XML as a string and assign it to the return object
    XMLOutputter outputter = new XMLOutputter();

    orgStructureBreadCrumbDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return orgStructureBreadCrumbDetails;
  }

  /**
   * Retrieves the child elements for a position or organization unit.
   *
   * @param orgStructureBrowserKey
   * The unique identifier of the organization unit or position.
   *
   * @return List of child elements
   */
  public OrgStructureChildElementDetails listOrgStructureChildElements(
    OrgStructureBrowserKey orgStructureBrowserKey) throws AppException,
      InformationalException {

    curam.core.sl.intf.OrganisationStructure organisationStructureObj = curam.core.sl.fact.OrganisationStructureFactory.newInstance();

    // Create Return Object
    OrgStructureChildElementDetails orgStructureChildElementDetails = new OrgStructureChildElementDetails();

    // Check to see if element type is organization unit
    if (orgStructureBrowserKey.orgStructureBrowserKey.elementType.equals(
      ELEMENTTYPE.ORGANIZATIONUNIT)
        || orgStructureBrowserKey.orgStructureBrowserKey.elementType.length()
          == 0) {

      // Get Org Unit child elements
      orgStructureChildElementDetails.orgStructureChildElementDetailsList = organisationStructureObj.listOrgStructureChildElements(
        orgStructureBrowserKey.orgStructureBrowserKey);

      // Get Org Structure bread crumb data
      orgStructureChildElementDetails.orgStructureBreadCrumbDetails = getOrgStructureBreadCrumb(
        orgStructureBrowserKey);

      OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

      // Get org unit id from key
      organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = orgStructureBrowserKey.orgStructureBrowserKey.elementID;

      // Get org unit context description
      OrganisationUnitContextDescriptionDetails organisationUnitContextDescriptionDetails = readOrganisationUnitContextDescription(
        organisationUnitKey);

      orgStructureChildElementDetails.orgStructureBrowserContextDescriptionDetails.description = organisationUnitContextDescriptionDetails.description;

      // Set element Id and Type in return struct
      orgStructureChildElementDetails.browserElementDetails.organisationStructureID = orgStructureBrowserKey.orgStructureBrowserKey.organisationStructureID;

      orgStructureChildElementDetails.browserElementDetails.elementID = orgStructureBrowserKey.orgStructureBrowserKey.elementID;

      orgStructureChildElementDetails.browserElementDetails.elementType = orgStructureBrowserKey.orgStructureBrowserKey.elementType;

    } else if (orgStructureBrowserKey.orgStructureBrowserKey.elementType.equals(
      ELEMENTTYPE.POSITION)) {
      // Element Type is a position

      // Get users that belong to that position
      orgStructureChildElementDetails.orgStructureChildElementDetailsList = organisationStructureObj.listPositionChildElements(
        orgStructureBrowserKey.orgStructureBrowserKey);

      // Get position browser bread crumb data
      orgStructureChildElementDetails.orgStructureBreadCrumbDetails = getPositionBreadCrumb(
        orgStructureBrowserKey);

      PositionKey positionKey = new PositionKey();

      positionKey.positionKey.positionKey.positionID = orgStructureBrowserKey.orgStructureBrowserKey.elementID;

      PositionContextDescriptionDetails positionContextDescriptionDetails = readPositionContextDescription(
        positionKey);

      orgStructureChildElementDetails.orgStructureBrowserContextDescriptionDetails.description = positionContextDescriptionDetails.description;

      // Set element Id and Type in return struct
      orgStructureChildElementDetails.browserElementDetails.organisationStructureID = orgStructureBrowserKey.orgStructureBrowserKey.organisationStructureID;

      orgStructureChildElementDetails.browserElementDetails.elementID = orgStructureBrowserKey.orgStructureBrowserKey.elementID;
      orgStructureChildElementDetails.browserElementDetails.elementType = orgStructureBrowserKey.orgStructureBrowserKey.elementType;

    } else if (orgStructureBrowserKey.orgStructureBrowserKey.elementType.equals(
      ELEMENTTYPE.ORGANIZATIONSTRUCTURE)) {
      // Element Type is an organization structure

      curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();

      curam.core.sl.entity.struct.OrgStructureAndStatusKey orgStructureAndStatusKey = new curam.core.sl.entity.struct.OrgStructureAndStatusKey();

      orgStructureAndStatusKey.organisationStructureID = orgStructureBrowserKey.orgStructureBrowserKey.organisationStructureID;
      orgStructureAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

      try {
        // Get the root organization unit for the organization structure
        OrganisationUnitIDAndNameDetails organisationUnitIDAndNameDetails = organisationUnitObj.readRootOrgUnitByIDAndStatus(
          orgStructureAndStatusKey);

        orgStructureBrowserKey.orgStructureBrowserKey.elementID = organisationUnitIDAndNameDetails.organisationUnitID;
        orgStructureBrowserKey.orgStructureBrowserKey.elementType = ELEMENTTYPE.ORGANIZATIONUNIT;

        // Get Org Unit child elements
        orgStructureChildElementDetails.orgStructureChildElementDetailsList = organisationStructureObj.listOrgStructureChildElements(
          orgStructureBrowserKey.orgStructureBrowserKey);

        // Get Org Structure bread crumb data
        orgStructureChildElementDetails.orgStructureBreadCrumbDetails = getOrgStructureBreadCrumb(
          orgStructureBrowserKey);

        OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        // Get org unit id from key
        organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = orgStructureBrowserKey.orgStructureBrowserKey.elementID;

        // Get org unit context description
        OrganisationUnitContextDescriptionDetails organisationUnitContextDescriptionDetails = readOrganisationUnitContextDescription(
          organisationUnitKey);

        orgStructureChildElementDetails.orgStructureBrowserContextDescriptionDetails.description = organisationUnitContextDescriptionDetails.description;

        // Set element Id and Type in return struct
        orgStructureChildElementDetails.browserElementDetails.organisationStructureID = orgStructureBrowserKey.orgStructureBrowserKey.organisationStructureID;
        orgStructureChildElementDetails.browserElementDetails.elementID = orgStructureBrowserKey.orgStructureBrowserKey.elementID;
        orgStructureChildElementDetails.browserElementDetails.elementType = orgStructureBrowserKey.orgStructureBrowserKey.elementType;
      } catch (curam.util.exception.RecordNotFoundException rnfe) {

        InformationalManager informationalManager = TransactionInfo.getInformationalManager();

        AppException e = new AppException(
          BPOORGANISATIONSTRUCTURE.INF_ORGANIZATIONSTRUCTURE_NO_ROOTORGUNIT_EXISTS);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          e.arg(true), CuramConst.gkEmpty,
          InformationalElement.InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

        // Obtain the informational(s) to be returned to the client
        String[] warnings = informationalManager.obtainInformationalAsString();

        for (int i = 0; i < warnings.length; i++) {

          InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

          informationalMsgDtls.informationMsgTxt = warnings[i];
          orgStructureChildElementDetails.informationalMsgDtlsList.dtls.addRef(
            informationalMsgDtls);
        }

        // Set element Id and Type in return struct
        orgStructureChildElementDetails.browserElementDetails.organisationStructureID = orgStructureBrowserKey.orgStructureBrowserKey.organisationStructureID;
        orgStructureChildElementDetails.browserElementDetails.elementID = kZeroOrganizationUnitID;
        orgStructureChildElementDetails.browserElementDetails.elementType = ELEMENTTYPE.ORGANIZATIONUNIT;
      }

      // Get Org Structure bread crumb data
      orgStructureChildElementDetails.orgStructureBreadCrumbDetails = getOrgStructureBreadCrumb(
        orgStructureBrowserKey);
    }

    return orgStructureChildElementDetails;
  }

  /**
   * Retrieves the root organization unit ID for the current active structure.
   *
   * @return organization unit ID
   */
  public OrganisationUnitIDDetails resolveRootOrganisationUnit()
    throws AppException, InformationalException {

    // Details to be returned
    OrganisationUnitIDDetails organisationUnitIDDetails = new OrganisationUnitIDDetails();

    // Resolve organization unit id
    organisationUnitIDDetails.organisationUnitID.organisationUnitID = OrganisationUnitFactory.newInstance().resolveRootOrganisationUnit().organisationUnitID;

    // Return details
    return organisationUnitIDDetails;
  }

  // BEGIN, CR00170283, DJ
  // BEGIN, CR00247294, PM
  /**
   * Presentation layer operation to search for active users within the
   * organization.
   *
   * @param userSearchKey
   * user to be read
   *
   * @return details of the active users
   *
   * @deprecated Since Curam 5.2 SP4, replaced with
   * {@link #activeUserDetailsSearch(UserSearchKey)} This method is
   * deprecated because it was not allowing to do a search based on
   * the start date of a position.The userDetailsSearch method
   * considers the start date of a position also when doing a user
   * search for the active positions. See release note: CR00215472.
   */
  @Deprecated
  // END, CR00247294
  public UserSearchDetails activeUserSearch(UserSearchKey userSearchKey)
    throws AppException, InformationalException {

    // Details to be returned
    UserSearchDetails userSearchDetails = new UserSearchDetails();

    // Set the status code to active so only active user are found
    userSearchKey.userSearchCriteria.criteria.statusCode = RECORDSTATUS.NORMAL;

    // Search for users
    userSearchDetails.userSearchResultsList = AdminUserFactory.newInstance().search(
      userSearchKey.userSearchCriteria);

    // Return user details
    return userSearchDetails;
  }

  // END, CR00170283
  
  /**
   * Presentation layer operation that disables a users account.
   *
   * @param userStatusDetails
   * user to be read
   */
  public void disableUser(UserStatusDetails_fo userStatusDetails)
    throws AppException, InformationalException {

    // Set user status details
    AccountStatusDetails accountStatusDetails = userStatusDetails.details;

    accountStatusDetails.details.accountEnabled = false;

    // Disable the user
    AdminUserFactory.newInstance().setAccountStatus(accountStatusDetails);
  }

  /**
   * Presentation layer operation that enables a users account.
   *
   * @param userStatusDetails
   * user to be read
   */
  public void enableUser(UserStatusDetails_fo userStatusDetails)
    throws AppException, InformationalException {

    // Set user status details
    AccountStatusDetails accountStatusDetails = userStatusDetails.details;

    accountStatusDetails.details.accountEnabled = true;

    // Enable the user
    AdminUserFactory.newInstance().setAccountStatus(accountStatusDetails);
  }

  /**
   * Retrieves the bread crumb menu data details for an organization unit.
   *
   * @param orgUnitBrowserKey
   * The unique identifier of the organization unit we need to get the
   * bread crumb data for.
   *
   * @return Bread crumb data details
   */
  public OrgUnitBreadCrumbDetails getOrgUnitBreadCrumb(
    OrgUnitBrowserKey orgUnitBrowserKey) throws AppException,
      InformationalException {

    // Create return object
    OrgUnitBreadCrumbDetails orgUnitBreadCrumbDetails = new OrgUnitBreadCrumbDetails();

    boolean parentOrgUnitExists = true;

    curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();

    OrgUnitIDAndOrgStructIDKey orgUnitIDAndOrgStructIDKey = new OrgUnitIDAndOrgStructIDKey();
    OrganisationUnitAndParentNameDetails organisationUnitAndParentNameDetails = new OrganisationUnitAndParentNameDetails();
    OrganisationUnitIDAndNameDetails organisationUnitIDAndNameDetails = new OrganisationUnitIDAndNameDetails();
    OrganisationUnitIDAndNameDetailsList organisationUnitIDAndNameDetailsList = new OrganisationUnitIDAndNameDetailsList();

    orgUnitIDAndOrgStructIDKey.organisationStructureID = orgUnitBrowserKey.organisationStructureID;
    orgUnitIDAndOrgStructIDKey.organisationUnitID = orgUnitBrowserKey.organisationUnitID;

    // Read up through the org unit hierarchy until the root org unit is found
    while (parentOrgUnitExists) {

      // Read organization unit
      organisationUnitAndParentNameDetails = organisationUnitObj.readByOrgStructure(
        orgUnitIDAndOrgStructIDKey);

      organisationUnitIDAndNameDetails = new OrganisationUnitIDAndNameDetails();

      organisationUnitIDAndNameDetails.assign(
        organisationUnitAndParentNameDetails);

      organisationUnitIDAndNameDetailsList.dtls.addRef(
        organisationUnitIDAndNameDetails);

      if (organisationUnitAndParentNameDetails.parentOrganisationUnitID == 0) {

        parentOrgUnitExists = false;

      } else {

        orgUnitIDAndOrgStructIDKey.organisationUnitID = organisationUnitAndParentNameDetails.parentOrganisationUnitID;
      }
    }

    // Create Root Node
    Element navigationMenuElement = new Element(kNavigationMenu);
    // Child Node
    Element linkElement;

    // We need to display the root org unit first and then each subsequent
    // org unit in the hierarchy so we need to start with the last item in the
    // list
    for (int i = organisationUnitIDAndNameDetailsList.dtls.size(); i != 0; i--) {

      // Create Child Node
      linkElement = new Element(kItem);

      LocalisableString description = new LocalisableString(
        BPOORGANIZATION.INF_ORGSTRUCTUREBROWSER_MENU_DESCRIPTION);

      String orgUnitName = organisationUnitIDAndNameDetailsList.dtls.item(i - 1).name;

      description.arg(orgUnitName);

      linkElement.setAttribute(kPageID, kListOrgUnit);
      linkElement.setAttribute(kDesc, description.toClientFormattedText());

      navigationMenuElement.addContent(linkElement);

      Element paramElementOne = new Element(kParam);
      Element paramElementTwo = new Element(kParam);

      paramElementOne.setAttribute(kName, kParamOrgStructureID);
      paramElementOne.setAttribute(kValue,
        String.valueOf(orgUnitBrowserKey.organisationStructureID));

      linkElement.addContent(paramElementOne);

      paramElementTwo.setAttribute(kName, kParamOrgUnitID);
      paramElementTwo.setAttribute(kValue,
        String.valueOf(
        organisationUnitIDAndNameDetailsList.dtls.item(i - 1).organisationUnitID));

      linkElement.addContent(paramElementTwo);
    }

    // Output the XML as a string and assign it to the return object
    XMLOutputter outputter = new XMLOutputter();

    orgUnitBreadCrumbDetails.menuData = outputter.outputString(
      navigationMenuElement);

    return orgUnitBreadCrumbDetails;
  }

  /**
   * Method to change a user's password.
   *
   * @param dtls
   * The updated user password details.
   */
  public void modifyUserPassword(UserPasswordDetails dtls) throws AppException,
      InformationalException {

    UserPasswordDtls userPasswordDtls = new UserPasswordDtls();

    // Set the password details
    userPasswordDtls.confirmUserPassword = dtls.dtls.confirmUserPassword;
    userPasswordDtls.currentUserPassword = dtls.dtls.currentUserPassword;
    userPasswordDtls.newUserPassword = dtls.dtls.newUserPassword;
    // BEGIN, CR00086342, VM
    userPasswordDtls.userName = TransactionInfo.getProgramUser();
    // END, CR00086342

    // Call the modify password method
    AdminUserFactory.newInstance().modifyUserPassword(userPasswordDtls);
  }

  /**
   * Method to return bank branch name and bank name details.
   *
   * @param key
   * Key to preform read.
   * @return readBankBranchNameBankNameDtlsList
   */
  public ReadBankBranchNameBankNameDtlsList listBankBranchNameBankName(
    ReadBankBranchNameBankNameKey key) throws AppException,
      InformationalException {

    ReadBankBranchNameBankNameDtlsList readBankBranchNameBankNameDtlsList = new ReadBankBranchNameBankNameDtlsList();

    readBankBranchNameBankNameDtlsList.dtls = AdminBankBranchFactory.newInstance().listBankBranchNameBankName(
      key.key);

    return readBankBranchNameBankNameDtlsList;
  }

  /**
   * Method to remove ReportsTo value from position.
   *
   * @param key
   * organization structure and position identifier
   */
  public void removeReportsToFromPosition(OrgStructureAndPositionKey key)
    throws AppException, InformationalException {

    // Remove ReportsTo value from position
    PositionFactory.newInstance().cancelReportsTo(
      key.orgStructureAndPositionKey);
  }

  /**
   * Cancels a Temporal Evidence Approval Check.
   *
   * @param key
   * Contains Temporal Evidence Approval Check cancellation details.
   * @param dtls
   * Contains Temporal Evidence Approval Check cancellation details.
   */
  public void cancelTemporalEvidenceApprovalCheck(
    TemporalEvidenceApprovalCheckKey key,
    ModifyTemporalEvidenceApprovalCheck dtls) throws AppException,
      InformationalException {

    CancelTemporalEvidenceApprovalCheck cancelTemporalEvidenceApprovalCheck = new CancelTemporalEvidenceApprovalCheck();

    cancelTemporalEvidenceApprovalCheck.key = key.key.key;

    cancelTemporalEvidenceApprovalCheck.dtls.recordStatus = dtls.recordStatus;
    cancelTemporalEvidenceApprovalCheck.dtls.versionNo = dtls.versionNo;

    // SID validation
    curam.core.sl.struct.OrgStructureAndOrgUnitKey orgStructureAndOrgUnitKey = new curam.core.sl.struct.OrgStructureAndOrgUnitKey();

    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID = dtls.organisationStructureID;

    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID = dtls.organisationUnitID;

    OrganisationAdminSecurity organisationAdminSecurity = new OrganisationAdminSecurity();

    OrganisationAdminSecurityResult organisationAdminSecurityResult = organisationAdminSecurity.checkMaintainOrganisationSecurity(
      orgStructureAndOrgUnitKey);

    if (!organisationAdminSecurityResult.result) {
      throw new AppException(
        BPOORGANISATIONUNIT.ERR_ORGANISATIONSECURITY_CHECK_FAILED);
    }

    // Call entity cancel operation
    TemporalEvidenceApprovalCheckFactory.newInstance().cancel(
      cancelTemporalEvidenceApprovalCheck);
  }

  /**
   * Creates a Temporal Evidence Approval Check record.
   *
   * @param dtls
   * Temporal Evidence Approval Check details.
   */
  public void createTemporalEvidenceApprovalCheck(
    CreateTemporalEvidenceApprovalCheck dtls) throws AppException,
      InformationalException {

    TemporalEvidenceApprovalCheckDetails temporalEvidenceApprovalCheckDetails = new TemporalEvidenceApprovalCheckDetails();

    temporalEvidenceApprovalCheckDetails.details.allEvidenceInd = dtls.allEvidenceInd;
    temporalEvidenceApprovalCheckDetails.details.dtls.assign(dtls);

    // Organization Unit variables
    curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();
    OrganisationUnitDtls organisationUnitDtls = new OrganisationUnitDtls();
    curam.core.sl.entity.struct.OrganisationUnitKey organisationUnitKey = new curam.core.sl.entity.struct.OrganisationUnitKey();

    if (dtls.organisationUnitID != 0) {
      organisationUnitKey.organisationUnitID = dtls.organisationUnitID;

      // Read Organization unit Details
      organisationUnitDtls = organisationUnitObj.read(organisationUnitKey);

      // The user cannot create temporal evidence approval
      // for a cancelled Organization unit.
      if (organisationUnitDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

        if (dtls.positionID != 0) {

          throw new AppException(
            BPOORGANISATIONUNIT.ERR_CREATE_POSITION_TEMPORAL_EVIDENCE_APPROVAL_CLOSED_ORGUNIT);
        } else {

          throw new AppException(
            BPOORGANISATIONUNIT.ERR_CREATE_ORGUNIT_TEMPORAL_EVIDENCE_APPROVAL_CLOSED_ORGUNIT);
        }
      }
    }

    // SID Validation
    curam.core.sl.struct.OrgStructureAndOrgUnitKey orgStructureAndOrgUnitKey = new curam.core.sl.struct.OrgStructureAndOrgUnitKey();

    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID = dtls.organisationStructureID;
    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID = dtls.organisationUnitID;

    OrganisationAdminSecurity organisationAdminSecurity = new OrganisationAdminSecurity();

    OrganisationAdminSecurityResult organisationAdminSecurityResult = organisationAdminSecurity.checkCreateChildOrganisationSecurity(
      orgStructureAndOrgUnitKey);

    if (!organisationAdminSecurityResult.result) {
      throw new AppException(
        BPOORGANISATIONUNIT.ERR_ORGANISATIONSECURITY_CHECK_FAILED);
    }

    // Call the entity insert operation
    TemporalEvidenceApprovalCheckFactory.newInstance().insert(
      temporalEvidenceApprovalCheckDetails.details);
  }

  /**
   * Lists Temporal Evidence Approval Check details related to the Organization
   * Unit specified.
   *
   * @param key
   * Search key containing the Organization Unit identifier
   * @return List containing Temporal Evidence Approval Check entries related to
   * the Org Unit specified
   */
  public curam.core.facade.struct.TemporalEvidenceApprovalCheckList listTemporalEvidenceApprovalCheckByOrgUnit(
    SearchByOrgUnitKey key)  throws AppException, InformationalException {

    // Return object
    curam.core.facade.struct.TemporalEvidenceApprovalCheckList temporalEvidenceApprovalCheckList = new curam.core.facade.struct.TemporalEvidenceApprovalCheckList();

    // Read records from service layer object
    TemporalEvidenceApprovalCheckList temporalEvidenceApprovalCheckTempList = TemporalEvidenceApprovalCheckFactory.newInstance().listByOrganisationUnit(
      key);

    // Assign to return struct
    temporalEvidenceApprovalCheckList.assign(
      temporalEvidenceApprovalCheckTempList);

    // Retrieve context description
    OrganisationUnitKey orgUnitKey = new OrganisationUnitKey();

    orgUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.organisationUnitID;

    temporalEvidenceApprovalCheckList.contextDescription = readOrganisationUnitContextDescription(orgUnitKey).description;

    return temporalEvidenceApprovalCheckList;
  }

  /**
   * Lists Temporal Evidence Approval Check details related to a specified
   * Position.
   *
   * @param key
   * Search key containing the Position identifier
   * @return List containing Temporal Evidence Approval Check entries related to
   * the Position specified
   */
  public curam.core.facade.struct.TemporalEvidenceApprovalCheckList listTemporalEvidenceApprovalCheckByPosition(
    SearchByPositionKey key) throws AppException, InformationalException {

    // Return object
    curam.core.facade.struct.TemporalEvidenceApprovalCheckList temporalEvidenceApprovalCheckList = new curam.core.facade.struct.TemporalEvidenceApprovalCheckList();

    // Read records from service layer object
    TemporalEvidenceApprovalCheckList temporalEvidenceApprovalCheckTempList = TemporalEvidenceApprovalCheckFactory.newInstance().listByPosition(
      key);

    // Assign to return struct
    temporalEvidenceApprovalCheckList.assign(
      temporalEvidenceApprovalCheckTempList);

    // Retrieve context description
    PositionKey positionKey = new PositionKey();

    positionKey.positionKey.positionKey.positionID = key.positionID;

    temporalEvidenceApprovalCheckList.contextDescription = readPositionContextDescription(positionKey).description;

    return temporalEvidenceApprovalCheckList;
  }

  /**
   * Lists Temporal Evidence Approval Check details related to the specified
   * User.
   *
   * @param key
   * Search key containing the username
   * @return List containing Temporal Evidence Approval Check entries related to
   * the specified User.
   */
  public curam.core.facade.struct.TemporalEvidenceApprovalCheckList listTemporalEvidenceApprovalCheckByUser(
    SearchByUserKey key) throws AppException, InformationalException {

    // Return object
    curam.core.facade.struct.TemporalEvidenceApprovalCheckList temporalEvidenceApprovalCheckList = new curam.core.facade.struct.TemporalEvidenceApprovalCheckList();

    // Call service layer operation to retrieve list by positionID
    TemporalEvidenceApprovalCheckList temporalEvidenceApprovalCheckTempList = TemporalEvidenceApprovalCheckFactory.newInstance().listByUser(
      key);

    temporalEvidenceApprovalCheckList.assign(
      temporalEvidenceApprovalCheckTempList);

    // Retrieve context description
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    organizationUserContextDescriptionKey.userName = key.userName;

    temporalEvidenceApprovalCheckList.contextDescription = readUserContextDescription(organizationUserContextDescriptionKey).description;

    return temporalEvidenceApprovalCheckList;
  }

  /**
   * Modifies details of a single Temporal Evidence Approval Check.
   *
   * @param dtls
   * Modified Temporal Evidence Approval Check details
   */
  public void modifyTemporalEvidenceApprovalCheck(
    ModifyTemporalEvidenceApprovalCheck dtls) throws AppException,
      InformationalException {

    TemporalEvidenceApprovalCheckDetails temporalEvidenceApprovalCheckDetails = new TemporalEvidenceApprovalCheckDetails();

    TemporalEvidenceApprovalCheckKey temporalEvidenceApprovalCheckKey = new TemporalEvidenceApprovalCheckKey();

    temporalEvidenceApprovalCheckKey.key.key.temporalEvApprovalCheckID = dtls.temporalEvApprovalCheckID;

    temporalEvidenceApprovalCheckDetails.details = TemporalEvidenceApprovalCheckFactory.newInstance().read(
      temporalEvidenceApprovalCheckKey.key);

    temporalEvidenceApprovalCheckDetails.details.dtls.assign(dtls);

    temporalEvidenceApprovalCheckDetails.details.allEvidenceInd = dtls.allEvidenceInd;

    // SID Validation
    curam.core.sl.struct.OrgStructureAndOrgUnitKey orgStructureAndOrgUnitKey = new curam.core.sl.struct.OrgStructureAndOrgUnitKey();

    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID = dtls.organisationStructureID;
    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID = dtls.organisationUnitID;

    OrganisationAdminSecurity organisationAdminSecurity = new OrganisationAdminSecurity();

    OrganisationAdminSecurityResult organisationAdminSecurityResult = organisationAdminSecurity.checkMaintainOrganisationSecurity(
      orgStructureAndOrgUnitKey);

    if (!organisationAdminSecurityResult.result) {
      throw new AppException(
        BPOORGANISATIONUNIT.ERR_ORGANISATIONSECURITY_CHECK_FAILED);
    }

    // Call the entity modify operation
    TemporalEvidenceApprovalCheckFactory.newInstance().modify(
      temporalEvidenceApprovalCheckDetails.details);
  }

  /**
   * Returns details of a single Temporal Evidence Approval Check.
   *
   * @param key
   * Contains a Temporal Evidence Approval Check entity key
   * @return Temporal Evidence Approval Check entity details
   */
  public ViewTemporalEvidenceApprovalCheck readTemporalEvidenceApprovalCheck(
    TemporalEvidenceApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return struct
    ViewTemporalEvidenceApprovalCheck viewTemporalEvidenceApprovalCheck = new ViewTemporalEvidenceApprovalCheck();

    // Manipulation struct
    TemporalEvidenceApprovalCheckDetails temporalEvidenceApprovalCheckDetails = new TemporalEvidenceApprovalCheckDetails();

    // SID Validation
    curam.core.sl.struct.OrgStructureAndOrgUnitKey orgStructureAndOrgUnitKey = new curam.core.sl.struct.OrgStructureAndOrgUnitKey();

    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID = key.organisationStructureID;
    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID = key.organisationUnitID;

    OrganisationAdminSecurity organisationAdminSecurity = new OrganisationAdminSecurity();

    OrganisationAdminSecurityResult organisationAdminSecurityResult = organisationAdminSecurity.checkReadOrganisationSecurity(
      orgStructureAndOrgUnitKey);

    if (!organisationAdminSecurityResult.result) {
      throw new AppException(
        BPOORGANISATIONUNIT.ERR_ORGANISATIONSECURITY_CHECK_FAILED);
    }

    // Call the entity read operation
    temporalEvidenceApprovalCheckDetails.details = TemporalEvidenceApprovalCheckFactory.newInstance().read(
      key.key);

    // Assign to return struct
    viewTemporalEvidenceApprovalCheck.assign(
      temporalEvidenceApprovalCheckDetails.details.dtls);

    return viewTemporalEvidenceApprovalCheck;
  }

  /**
   * Returns a list of all possible evidence types.
   *
   * @return List of evidence types
   */
  public EvidenceTypeList listEvidenceTypes() throws AppException,
      InformationalException {

    // Return object
    EvidenceTypeList evidenceTypeList = new EvidenceTypeList();

    String[] evidenceTypes = CodeTable.getAllCodes(
      TEMPORAL_EVIDENCE_TYPE_APPROVAL.TABLENAME,
      TransactionInfo.getProgramLocale());

    evidenceTypeList.dtls.ensureCapacity(evidenceTypes.length);

    for (int i = 0; i < evidenceTypes.length; i++) {

      EvidenceType evidenceType = new EvidenceType();

      if (!evidenceTypes[i].toString().equals(
        TEMPORAL_EVIDENCE_TYPE_APPROVAL.ALLEVIDENCE)) {

        evidenceType.typeCodeValue = evidenceTypes[i].toString();

        // BEGIN, CR00163098, JC
        evidenceType.evidenceDescription = CodeTable.getOneItem(
          TEMPORAL_EVIDENCE_TYPE_APPROVAL.TABLENAME, evidenceType.typeCodeValue,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC

        evidenceTypeList.dtls.add(evidenceType);
      }
    }

    return evidenceTypeList;
  }

  // BEGIN, CR00018201, PMD
  
  // BEGIN, CR00343008, VT
  /**
   * This method lists all existing approval checks for a user.
   *
   * @param key
   * The unique id of the user that the resolution approval checks are
   * being listed for.
   * @return A list of resolution approval checks for the user.
   *
   * @deprecated Since Curam 6.0.5.0, replaced with
   * {@link Organization#listResolutionApprovalCheckForUserAndVersionNo(ListUserResolutionApprovalCheckKey)}.
   * This method is being deprecated as the return struct does not have version number attribute. 
   * See release note:CEF-10493.
   */
  // END, CR00343008
  @Deprecated
  public ListUserResolutionApprovalCheckDetails listResolutionApprovalCheckForUser(
    ListUserResolutionApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return Object
    ListUserResolutionApprovalCheckDetails listUserResolutionApprovalCheckDetails = new ListUserResolutionApprovalCheckDetails();

    // Context description key object
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    // Call IssueResolutionApprovalCheck BPO to perform the list operation
    listUserResolutionApprovalCheckDetails.listUserResolutionApprovalCheckDetails = IssueResolutionApprovalCheckFactory.newInstance().listResolutionApprovalChecksForUser(
      key.listUserResolutionApprovalCheckKey);

    // Set context description key
    organizationUserContextDescriptionKey.userName = key.listUserResolutionApprovalCheckKey.searchByUserKey.userName;

    // Get context description
    listUserResolutionApprovalCheckDetails.listUserResolutionApprovalCheckContextDescription = readUserContextDescription(
      organizationUserContextDescriptionKey);

    return listUserResolutionApprovalCheckDetails;
  }

  /**
   * This method allows an administrator to cancel an Issue Resolution Approval
   * Check for a user.
   *
   * @param key
   * The unique id of the Issue Resolution Approval Check to be
   * canceled.
   */
  public void cancelResolutionApprovalCheckForUser(
    CancelIssueResolutionApprovalCheckKey key) throws AppException,
      InformationalException {

    // Call IssueResolutionApprovalCheck BPO to perform the cancel operation
    IssueResolutionApprovalCheckFactory.newInstance().cancel(
      key.cancelIssueResolutionApprovalCheckDetails);
  }

  /**
   * This method allows an administrator to configure an approval check for a
   * user. It allows a percentage of resolutions on issues which are submitted
   * for approval to be reviewed.
   *
   * @param details
   * The Issue Resolution Approval Check details.
   */
  public void createResolutionApprovalCheckForUser(
    IssueResolutionApprovalCheckDetails details) throws AppException,
      InformationalException {

    // Call IssueResolutionApprovalCheck BPO to perform the create operation
    IssueResolutionApprovalCheckFactory.newInstance().create(
      details.issueResolutionApprovalCheckDetails);
  }

  /**
   * This method allows an administrator to modify an Issue Resolution Approval
   * Check for a user.
   *
   * @param details
   * The issue resolution approval check modified details.
   */
  public void modifyResolutionApprovalCheckForUser(
    IssueResolutionApprovalCheckDetails details) throws AppException,
      InformationalException {

    // Call IssueResolutionApprovalCheck BPO to perform the modify operation
    IssueResolutionApprovalCheckFactory.newInstance().modify(
      details.issueResolutionApprovalCheckDetails);
  }

  /**
   * This method allows an administrator to view a resolution approval check for
   * a user.
   *
   * @param key
   * The unique id of the Issue Resolution Approval Check to be read.
   * @return The resolution approval check details for the user.
   */
  public ReadUserResolutionApprovalCheckDetails readResolutionApprovalCheckForUser(
    ReadIssueResolutionApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return Object
    ReadUserResolutionApprovalCheckDetails readUserResolutionApprovalCheckDetails = new ReadUserResolutionApprovalCheckDetails();

    // Call IssueResolutionApprovalCheck BPO to perform the read operation
    readUserResolutionApprovalCheckDetails.readUserResolutionApprovalCheckDetails = IssueResolutionApprovalCheckFactory.newInstance().read(
      key.readIssueResolutionApprovalCheckKey);

    // Context description key object
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    // Set context description key
    organizationUserContextDescriptionKey.userName = readUserResolutionApprovalCheckDetails.readUserResolutionApprovalCheckDetails.dtls.userName;

    // Get context description
    readUserResolutionApprovalCheckDetails.readUserApprovalCheckContextDescription = readUserContextDescription(
      organizationUserContextDescriptionKey);

    return readUserResolutionApprovalCheckDetails;
  }

  /**
   * This method lists issue types that are available for approval check
   * creation.
   *
   * @return A list of issue types.
   */
  public IssueConfigurationTypeDetailsList listAvailableIssuesForApprovalCheck()
    throws AppException, InformationalException {

    // Return Object
    IssueConfigurationTypeDetailsList issueConfigurationTypeDetailsList = new IssueConfigurationTypeDetailsList();

    // Call IssueResolutionApprovalCheck BPO to perform the list operation
    issueConfigurationTypeDetailsList.issueConfigurationTypeDetailsList = IssueResolutionApprovalCheckFactory.newInstance().listAvailableIssuesForApprovalCheck();

    return issueConfigurationTypeDetailsList;
  }

  /**
   * This method allows an administrator to cancel an Issue Resolution Approval
   * Check for an organization unit.
   *
   * @param key
   * The unique id of the Issue Resolution Approval Check to be
   * canceled.
   */
  public void cancelResolutionApprovalCheckForOrgUnit(
    CancelIssueResolutionApprovalCheckKey key) throws AppException,
      InformationalException {

    // Call IssueResolutionApprovalCheck BPO to perform the cancel operation
    IssueResolutionApprovalCheckFactory.newInstance().cancel(
      key.cancelIssueResolutionApprovalCheckDetails);
  }

  /**
   * This method allows an administrator to configure an approval check for an
   * organization unit. It allows a percentage of resolutions on issues which
   * are submitted for approval to be reviewed.
   *
   * @param details
   * The Issue Resolution Approval Check details.
   */
  public void createResolutionApprovalCheckForOrgUnit(
    IssueResolutionApprovalCheckDetails details) throws AppException,
      InformationalException {

    // Call IssueResolutionApprovalCheck BPO to perform the create operation
    IssueResolutionApprovalCheckFactory.newInstance().create(
      details.issueResolutionApprovalCheckDetails);
  }

  /**
   * This method allows an administrator to modify an Issue Resolution Approval
   * Check for an organization unit.
   *
   * @param details
   * The issue resolution approval check modified details.
   */
  public void modifyResolutionApprovalCheckForOrgUnit(
    IssueResolutionApprovalCheckDetails details) throws AppException,
      InformationalException {

    // Call IssueResolutionApprovalCheck BPO to perform the modify operation
    IssueResolutionApprovalCheckFactory.newInstance().modify(
      details.issueResolutionApprovalCheckDetails);
  }

  /**
   * This method allows an administrator to view a resolution approval check for
   * an organization unit.
   *
   * @param key
   * The unique id of the Issue Resolution Approval Check to be read.
   * @return The resolution approval check details for the organization unit.
   */
  public ReadOrgUnitResolutionApprovalCheckDetails readResolutionApprovalCheckForOrgUnit(
    ReadIssueResolutionApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return Object
    ReadOrgUnitResolutionApprovalCheckDetails readOrgUnitResolutionApprovalCheckDetails = new ReadOrgUnitResolutionApprovalCheckDetails();

    // Call IssueResolutionApprovalCheck BPO to perform the read operation
    readOrgUnitResolutionApprovalCheckDetails.readOrgUnitResolutionApprovalCheckDetails = IssueResolutionApprovalCheckFactory.newInstance().read(
      key.readIssueResolutionApprovalCheckKey);

    // Context description key object
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Set context description key
    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = readOrgUnitResolutionApprovalCheckDetails.readOrgUnitResolutionApprovalCheckDetails.dtls.organisationUnitID;

    // Get context description
    readOrgUnitResolutionApprovalCheckDetails.readOrgUnitResolutionApprovalCheckContextDescriptionDetails = readOrganisationUnitContextDescription(
      organisationUnitKey);

    return readOrgUnitResolutionApprovalCheckDetails;
  }

  // BEGIN, CR00343008, VT
  /**
   * This method lists all existing approval checks for an organization unit.
   *
   * @param key
   * The unique id of the organization unit that the resolution
   * approval checks are being listed for.
   * @return A list of resolution approval checks for the organization unit.
   *
   * @deprecated Since Curam 6.0.5.0, replaced with
   * {@link Organization#listResolutionApprovalCheckForOrgUnitAndVersionNo(ListOrgUnitResolutionApprovalCheckKey)}.
   * This method is being deprecated as the return struct does not have version number attribute. 
   * See release note:CEF-10493.
   */
  // END, CR00343008
  @Deprecated
  public ListOrgUnitResolutionApprovalCheckDetails listResolutionApprovalCheckForOrgUnit(
    ListOrgUnitResolutionApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return Object
    ListOrgUnitResolutionApprovalCheckDetails listOrgUnitResolutionApprovalCheckDetails = new ListOrgUnitResolutionApprovalCheckDetails();

    // Context description key object
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Call IssueResolutionApprovalCheck BPO to perform the list operation
    listOrgUnitResolutionApprovalCheckDetails.listOrgUnitResolutionApprovalCheckDetails = IssueResolutionApprovalCheckFactory.newInstance().listResolutionApprovalChecksForOrgUnit(
      key.listOrgUnitResolutionApprovalCheckKey);

    // Set context description key
    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.listOrgUnitResolutionApprovalCheckKey.searchByOrgUnitKey.organisationUnitID;

    // Get context description
    listOrgUnitResolutionApprovalCheckDetails.listOrgUnitResolutionApprovalCheckContextDescriptionDetails = readOrganisationUnitContextDescription(
      organisationUnitKey);

    return listOrgUnitResolutionApprovalCheckDetails;
  }

  // END, CR00018201

  
  /**
   * Activates a Location Structure record.
   *
   * @param details
   * Activate Location Structure Details.
   */
  public void activateLocationStructure(ActivateLocationStructureDetails details)
    throws AppException, InformationalException {

    // Activate LocationStructure record
    LocationStructureFactory.newInstance().activateLocationStructure(
      details.dtls);
  }

  /**
   * Cancels a LocationStructure record.
   *
   * @param details
   * LocationStructure Details.
   */
  public void cancelLocationStructure(CancelLocationStructureDetails details)
    throws AppException, InformationalException {

    // Cancel a LocationStructure record
    LocationStructureFactory.newInstance().cancelLocationStructure(details.dtls);
  }

  /**
   * Creates a LocationStructure record.
   *
   * @param details
   * LocationStructure Details.
   */
  public void createLocationStructure(CreateLocationStructureDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00168663, LD
    // Set organization id
    details.dtls.createDtls.organisationID = getOrganizationID();
    // END, CR00168663

    // Create new Location Structure
    LocationStructureFactory.newInstance().createLocationStructure(details.dtls);
  }

  /**
   * Lists a LocationStructure record.
   *
   * @param key
   * OrganisationKey.
   * @return The List Of LocationStructure.
   */
  public ListLocationStructureDetails listLocationStructure(OrganisationKey key)
    throws AppException, InformationalException {

    ListLocationStructureDetails listLocationStructureDetails = new ListLocationStructureDetails();

    curam.core.sl.struct.OrganisationKey organisationKey = new curam.core.sl.struct.OrganisationKey();

    // BEGIN, CR00168663, LD
    // Set organization id
    organisationKey.organisationID = getOrganizationID();
    // END, CR00168663

    listLocationStructureDetails.dtls = LocationStructureFactory.newInstance().listLocationStructure(
      organisationKey);

    return listLocationStructureDetails;
  }

  /**
   * Modifies a  LocationStructure record.
   *
   * @param details
   * LocationStructure Details.
   */
  public void modifyLocationStructure(ModifyLocationStructureDetails details)
    throws AppException, InformationalException {
    // BEGIN, CR00168663, LD
    // Set organization id
    details.dtls.modifyDtls.organisationID = getOrganizationID();
    // END, CR00168663

    LocationStructureFactory.newInstance().modifyLocationStructure(details.dtls);
  }

  // BEGIN, CR00022520, KY
  
  /**
   * Reads parent location ID for a location.
   *
   * @param key
   * identifies location
   *
   * @return parent location ID
   */
  public ParentLocationIDDetails readParentLocationDetails(
    ReadParentLocationKey key) throws AppException, InformationalException {

    // Location variables
    ParentLocationIDDetails parentLocationDetails = new ParentLocationIDDetails();

    LocationKeyRef locationKey = new LocationKeyRef();

    locationKey.locationID = key.locationKey.locationID;

    parentLocationDetails.dtls = AdminLocationFactory.newInstance().readParentLocationID(
      locationKey);

    return parentLocationDetails;
  }

  // END, CR00022520

  // BEGIN, CR00049791 KK
  // _________________________________________________________________________
  /**
   * Fetches xml for location structure tree.
   *
   * @param key
   * LocStructureAndLocKey.
   *
   * @return details of the tree hierarchy in xml format.
   */
  public ReadXMLDetails getLocationStructureTreeXML(LocStructureAndLocKey key)
    throws AppException, InformationalException {

    ReadXMLDetails readXMLDetails = new ReadXMLDetails();

    readXMLDetails.xmlDtls = LocationStructureTreeFactory.newInstance().getXMLStringForLocationStructure(
      key.locStructureAndLocKey);

    return readXMLDetails;
  }

  /**
   * Reads a LocationStructure record.
   *
   * @param key
   * LocationStructure Details.
   *
   * @return details of the LocationStructure record.
   */
  public ReadLocationStructureDetails readLocationStructure(
    curam.core.facade.struct.LocationStructureKey key) throws AppException,
      InformationalException {

    ReadLocationStructureDetails readLocationStructureDetails = new ReadLocationStructureDetails();

    readLocationStructureDetails.dtls = LocationStructureFactory.newInstance().readLocationStructure(
      key.dtls);

    return readLocationStructureDetails;
  }

  // END, CR00049791

  // BEGIN, CR00087684, DK
  
  /**
   * Fetches xml for organization structure tree.
   *
   * @param key
   * OrgStructureOrgUnitPositionKey.
   *
   * @return details of the tree hierarchy in xml format.
   */
  public ReadXMLDetails getOrganisationStructureTreeXML(
    OrgStructureOrgUnitPositionKey key) throws AppException,
      InformationalException {

    ReadXMLDetails readXMLDetails = new ReadXMLDetails();

    readXMLDetails.xmlDtls = OrganisationStructureTreeFactory.newInstance().getXMLStringForOrgStructure(
      key);

    return readXMLDetails;
  }

  // END, CR00087684

  
  /**
   * Lists Location SIDS.
   *
   * @return List of Location SIDs
   */
  public SecurityIDList listLocationSIDs() throws AppException,
      InformationalException {

    // variable to hold result for return
    SecurityIDList securityIDListRet = new SecurityIDList();

    SIDTypeKey sIDTypeKey = new SIDTypeKey();

    sIDTypeKey.sidType = SECURITYIDENTIFIERTYPE.LOCATION;

    securityIDListRet.securityIDList = SecurityLinkFactory.newInstance().getSidsByType(
      sIDTypeKey);

    return securityIDListRet;
  }

  /**
   * Lists Organization SIDS.
   *
   * @return List of Organization SIDs
   */
  public SecurityIDList listOrganizationSIDs() throws AppException,
      InformationalException {

    // variable to hold result for return
    SecurityIDList securityIDListRet = new SecurityIDList();

    SIDTypeKey sIDTypeKey = new SIDTypeKey();

    // BEGIN, CR00051884
    sIDTypeKey.sidType = SECURITYIDENTIFIERTYPE.ORGANIZATION;
    // END, CR00051884

    securityIDListRet.securityIDList = SecurityLinkFactory.newInstance().getSidsByType(
      sIDTypeKey);

    return securityIDListRet;
  }

  /**
   * Assign additional location access.
   *
   * @param details
   * location access details
   */
  public void assignLocationAccess(LocationAccessDetails details)
    throws AppException, InformationalException {

    // Assign Location Access
    AdminLocationFactory.newInstance().assignLocationAccess(
      details.locationAccessDtls);
  }

  /**
   * Remove additional location access.
   *
   * @param key
   * location access identifier
   */
  public void removeLocationAccess(RemoveLocationAccessKey key)
    throws AppException, InformationalException {

    // Remove Location Access
    AdminLocationFactory.newInstance().removeLocationAccess(key.removeAccess);
  }

  /**
   * Method to return a list of all active locations by a specified location
   * type.
   *
   * @param key
   * The key for location search
   *
   * @return A list of all active locations by a specified location type
   */
  public ListActiveLocationDetails listActiveLocations(LocationSearchKey key)
    throws AppException, InformationalException {

    // return list for location search
    ListActiveLocationDetails listActiveLocationDetails = new ListActiveLocationDetails();

    // search all active locations by type
    listActiveLocationDetails.locationList = AdminLocationFactory.newInstance().searchActiveLocationsByType(
      key.key);

    return listActiveLocationDetails;
  }

  /**
   * Method to return a list of all active and operating locations by a
   * specified location type to be assigned to Organization unit or position.
   *
   * @param key
   * The key for location search
   *
   * @return A list of all active locations by a specified location type
   */
  public ListActiveLocationDetails listActiveLocationsForOrg(
    OrgLocationSearchKey key) throws AppException, InformationalException {

    // return list for location search
    ListActiveLocationDetails listActiveLocationDetails = new ListActiveLocationDetails();

    // search all active locations by type for Organization unit or position
    listActiveLocationDetails.locationList = AdminLocationFactory.newInstance().searchActiveLocationsForOrg(
      key.key);

    return listActiveLocationDetails;
  }

  /**
   * @return int
   */
  @Override
  public int hashCode() {

    return super.hashCode();
  }

  /**
   * @param arg0
   * an argument
   * @return boolean
   */
  @Override
  public boolean equals(Object arg0) {

    return super.equals(arg0);
  }

  /**
   * @return object
   */
  @Override
  protected Object clone() throws CloneNotSupportedException {

    return super.clone();
  }

  /**
   * @return String
   */
  @Override
  public String toString() {

    return super.toString();
  }

  /**
   * finalize method.
   */
  @Override
  protected void finalize() throws Throwable {

    super.finalize();
  }

  // BEGIN, CR00066601, NG
  
  // BEGIN, CR00216807 MN
  /**
   * Presentation layer operation to close a User.
   *
   * @param closeUserDetails
   * Details of the user to be closed
   *
   * @return InformationalMsgDtlsList List of informational messages
   *
   * @deprecated Since Curam 6.0 , replaced with
   * {@link Organization#closeOrganizationUser(CloseOrganizationUserDetails details)}.
   * As part of CLE changes the implementation has been moved to
   * closeOrganizationUser with a new input struct
   * CloseOrganizationUserDetails. This struct has all the fields of
   * closeUser struct along with fields toRedirectID and toRedirectType.
   * See release note : <CR00216807>
   */
  @Deprecated
  public InformationalMsgDtlsList closeUser(
    curam.core.facade.struct.CloseUserDetails closeUserDetails)
    throws AppException, InformationalException {

    // Return variable to hold the details.
    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    // Register Informational Manager
    TransactionInfo.setInformationalManager();

    // Service Layer Call to Close the User
    AdminUserFactory.newInstance().closeUser(closeUserDetails);

    // Informational Manager handle
    curam.util.exception.InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; ++i) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
    return informationalMsgDtlsList;
  }

  // END, CR00216807
  
  /**
   * Returns the display details of the user being closed.
   *
   * @param userKey
   * user identifier
   *
   * @return UserSupervisorAndLeadPositionInd contains details for user being
   * close
   */
  public UserSupervisorAndLeadPositionInd readCloseUserDetails(
    UserKeyStruct userKey) throws AppException, InformationalException {

    // Return variable to hold the details
    UserSupervisorAndLeadPositionInd userSupervisorAndLeadPositionInd = new UserSupervisorAndLeadPositionInd();

    // Register Informational Manager
    TransactionInfo.setInformationalManager();

    // read the details require for close user.
    userSupervisorAndLeadPositionInd = AdminUserFactory.newInstance().readSupervisorAndLeadPositionInd(
      userKey);

    return userSupervisorAndLeadPositionInd;
  }

  /**
   * Presentation layer operation to reopen a User.
   *
   * @param reopenUserDetails
   * Details of the user to be reopen
   */
  public void reopenUser(ReopenUserDetails reopenUserDetails)
    throws AppException, InformationalException {

    // Service Layer call to reopen the user
    AdminUserFactory.newInstance().reopenUser(reopenUserDetails);
  }

  // END, CR00066601

  // BEGIN, CR00051908 , KK
  
  /**
   * Retrieves the active and cancelled users of a particular Position.
   *
   * @param key
   * key holding the positionId and OrganisationStructureID.
   * @return user details list
   */
  public ListUserForPositionDetails listAllUsersForPosition(
    OrgStructureAndPositionKey key) throws AppException,
      InformationalException {
    // Key to read position context description
    PositionKey positionKey = new PositionKey();

    // Return variable for users details list
    ListUserForPositionDetails listUserForPositionDetails = new ListUserForPositionDetails();

    // Key to read the User Details
    SearchAllUserByPositionKey searchAllUserByPositionKey = new SearchAllUserByPositionKey();

    // BEGIN, CR00161962, KY
    if (key.orgStructureAndPositionKey.orgStructureAndPositionKey.organisationStructureID
      == 0) {

      curam.core.sl.entity.intf.OrganisationStructure organisationStructureObj = OrganisationStructureFactory.newInstance();
      OrganisationStructureStatus organisationStructureStatus = new OrganisationStructureStatus();

      organisationStructureStatus.statusCode = ORGSTRUCTURESTATUS.ACTIVE;
      try {
        key.orgStructureAndPositionKey.orgStructureAndPositionKey.organisationStructureID = organisationStructureObj.readActiveOrganisationStructureID(organisationStructureStatus).organisationStructureID;
      } catch (RecordNotFoundException re) {
        throw new AppException(
          curam.message.BPOORGANISATIONSTRUCTURE.ERR_ORGANIZATIONSTRUCTURE_XRV_ACTIVE_MUST_EXIST);
      }
    }
    // END, CR00161962
    searchAllUserByPositionKey.organisationStructureID = key.orgStructureAndPositionKey.orgStructureAndPositionKey.organisationStructureID;
    searchAllUserByPositionKey.positionID = key.orgStructureAndPositionKey.orgStructureAndPositionKey.positionID;
    searchAllUserByPositionKey.effectiveDate = Date.getCurrentDate();

    listUserForPositionDetails.userForPositionDetailsList = AdminUserFactory.newInstance().listAllUsersofPosition(
      searchAllUserByPositionKey);

    positionKey.positionKey.positionKey.positionID = key.orgStructureAndPositionKey.orgStructureAndPositionKey.positionID;

    // Read organization structure context description
    listUserForPositionDetails.positionContextDescriptionDetails = readPositionContextDescription(
      positionKey);

    // Return user details list
    return listUserForPositionDetails;
  }

  // END, CR00051908

  // BEGIN, CR00058145, CSH
  
  /**
   * This method lists the evidence type details for for the specified admin
   * integrated case.
   *
   * @param key
   * The unique identifier for the type of case.
   *
   * @return The list of evidence type details.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link Organization#listAllEvidenceTypesByAdminIntegratedCaseID
   * (AdminIntegratedCaseKey)}.
   */
  @Deprecated
  public ICEvidenceTypeDetailsList listEvidenceTypesByAdminIntegratedCaseID(
    AdminIntegratedCaseKey key) throws AppException, InformationalException {

    return listAllEvidenceTypesByAdminIntegratedCaseID(key);
  }

  // END, CR00058145

  // BEGIN, CR00175973, PDN
  
  /**
   * Retrieves the user summary detail for user summary page.
   *
   * @param key
   * key holding the username, organisationUnitID and
   * OrganisationStructureID.
   *
   * @return user summary details
   * @deprecated Since Curam 6.0, replaced by
   * {@link #readUserSummaryDetails1()}.
   */
  @Deprecated
  public UserSummaryDetails readUserSummaryDetails(UserSummaryDetailsKey key)
    throws AppException, InformationalException {

    UserSummaryDetails userSummaryDetails = new UserSummaryDetails();

    UserSummaryDetails1 userSummaryDetails1 = readUserSummaryDetails1(key);

    userSummaryDetails.assign(userSummaryDetails1);

    return userSummaryDetails;
  }

  /**
   * Retrieves the user summary detail for user summary page.
   *
   * @param key
   * key holding the username, organisationUnitID and
   * OrganisationStructureID.
   *
   * @return user summary details
   */
  public UserSummaryDetails1 readUserSummaryDetails1(UserSummaryDetailsKey key)
    throws AppException, InformationalException {

    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    // Admin user business process object
    AdminUser adminUserObj = AdminUserFactory.newInstance();

    // to get the user details
    UserKeyStruct userKeyStruct = new UserKeyStruct();
    UserSummaryDetails1 userSummaryDetails1 = new UserSummaryDetails1();

    // for position details
    UserSummaryPositionKey userSummaryPositionKey = new UserSummaryPositionKey();

    // SID validation
    curam.core.sl.struct.OrgStructureAndOrgUnitKey orgStructureAndOrgUnitKey = new curam.core.sl.struct.OrgStructureAndOrgUnitKey();

    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationStructureID = key.organisationStructureID;
    orgStructureAndOrgUnitKey.orgStructAndOrgUnitKey.organisationUnitID = key.organisationUnitID;

    OrganisationAdminSecurity organisationAdminSecurity = new OrganisationAdminSecurity();

    OrganisationAdminSecurityResult organisationAdminSecurityResult = organisationAdminSecurity.checkMaintainOrganisationSecurity(
      orgStructureAndOrgUnitKey);

    if (!organisationAdminSecurityResult.result) {

      throw new AppException(
        BPOORGANISATIONUNIT.ERR_ORGANISATIONSECURITY_CHECK_FAILED);
    }

    userKeyStruct.userName = key.userName;
    userSummaryDetails1.detail = adminUserObj.readSummaryDetail1(userKeyStruct);

    // to get user position details
    userSummaryPositionKey.organisationStructureID = key.organisationStructureID;
    userSummaryPositionKey.organisationUnitID = key.organisationUnitID;
    userSummaryPositionKey.userName = key.userName;
    userSummaryDetails1.positionDetail = adminUserObj.readUserSummaryPosition(
      userSummaryPositionKey);

    // Informational Manager handle
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; ++i) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      userSummaryDetails1.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return userSummaryDetails1;
  }

  // END, CR00175973

  // _________________________________________________________________________
  /**
   * Retrieves location details for position home page.
   *
   * @param key
   * key is the position id
   * @return location details for position home
   */
  public LocationDetailsForPositionHomeList viewLocationDetailsForPosition(
    curam.core.facade.struct.PositionIDKey key) throws AppException,
      InformationalException {

    LocationDetailsForPositionHomeList locationDetails = new LocationDetailsForPositionHomeList();

    PositionIDKey positionIDKey = new PositionIDKey();

    positionIDKey.positionID = key.positionID;

    locationDetails.locationDetailsForPosition = PositionFactory.newInstance().viewLocationDetailsForPositions(
      positionIDKey);

    return locationDetails;
  }

  /**
   * Creates new user and assigns the same user to a position.
   *
   * @param details
   * contains all the details of the user and position
   */
  public void createAndAssignUserForPosition(
    CreateAndAssignUserForPosition details) throws AppException,
      InformationalException {

    // create user details
    CreateUserDetails createUserDetails = new CreateUserDetails();

    createUserDetails.userDetails = details.createUserDetails;
    createUser(createUserDetails);

    // assign user to position
    UserForPositionDetails userForPositionDetails = details.assignDetails;

    userForPositionDetails.positionHolderLinkDetails.positionHolderLinkDtls.userName = details.createUserDetails.userName;
    // BEGIN, CR00101963, GSP

    // Highlight the Organization node when the position user is created
    // key to update the TreeNodeDetails HashMap.
    RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // key and value pair
    ruleSetNodeKey.ruleSetID = String.valueOf(
      details.assignDetails.positionHolderLinkDetails.positionHolderLinkDtls.organisationStructureID);
    // assign node id to the position ID
    ruleSetNodeKey.nodeID = details.assignDetails.positionHolderLinkDetails.positionHolderLinkDtls.positionID;

    // END, CR00101963
    addUserForPosition(userForPositionDetails);
    // BEGIN, CR00101963, GSP
    final String userSelectionPath = setUserSelectionPath(details);

    OrganisationpostUpdate(ruleSetNodeKey, userSelectionPath);
    // END, CR00101963
  }

  /**
   * This method assigns a location to a position.
   *
   * @param details
   * The location details
   */
  public void assignLocationToPosition(PositionLocationDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00052328  KK
    PositionLocationLinkFactory.newInstance().addLocationToPosition(
      details.PosLocDetails);
    // END, CR00052328  KK
  }

  /**
   * This method removes a location assigned to a position.
   *
   * @param details
   * Contains details of the location and position
   */
  public void removeLocationFromPosition(RemovePositionLocationDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00052328  KK
    PositionLocationLinkFactory.newInstance().removeLocationFromPosition(
      details.removePositionLocationDetails);
    // END, CR00052328  KK
  }

  // BEGIN, CR00066883, SPD
  
  /**
   * @return List of cases
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listRecentApprovedCasesForUserSubmittedOrOwned()}. New method
   * lists recently approved integrated and product delivery cases submitted
   * by current user or currently owned by current user or current user
   * organization object.
   *
   * Method to search for all cases recently approved by the user.
   */
  @Deprecated
  public UserRecentCaseList listRecentApprovedCasesForUser()
    throws AppException, InformationalException {

    // return struct
    UserRecentCaseList userRecentCaseList = new UserRecentCaseList();

    // BEGIN CR00099168, ELG
    // retrieve list of cases recently approved by user
    userRecentCaseList.detailsList = curam.core.sl.fact.CaseApprovalFactory.newInstance().searchRecentlyApprovedCasesForCurrentUser();
    // END CR00099168

    return userRecentCaseList;
  }

  /**
   * @return List of cases
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listRecentAssignedCasesForUserCurrentlyOwned()}. New method
   * lists integrated and product delivery recently assigned cases currently
   * owned by current user or current user organization object.
   *
   * Method to search for all cases recently assigned to the user.
   */
  @Deprecated
  public UserRecentCaseList listRecentAssignedCasesForUser()
    throws AppException, InformationalException {

    // return struct
    UserRecentCaseList userRecentCaseList = new UserRecentCaseList();

    // retrieve list of cases recently assigned to the user
    userRecentCaseList.detailsList = UserRecentActionFactory.newInstance().listAssignedCase();

    return userRecentCaseList;
  }

  /**
   * @return List of cases
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listRecentViewedCasesForUser1()}. New method
   * lists integrated and product delivery cases recently viewed by a user.
   *
   * Method to search for all cases recently viewed by the user.
   */
  @Deprecated
  public UserRecentCaseList listRecentViewedCasesForUser() throws AppException,
      InformationalException {

    // return struct
    UserRecentCaseList userRecentCaseList = new UserRecentCaseList();

    // retrieve list of cases recently viewed by the user
    userRecentCaseList.detailsList = UserRecentActionFactory.newInstance().listViewedCase();

    return userRecentCaseList;
  }

  /**
   * @param key
   * The CatStatusRefUserType
   * @return List of case details
   * @deprecated Since Curam 6.0, replaced by
   * {@link Case#caseDefaultSearchByOwner()}. New method performs a case search
   * based on search criteria which includes owner list passed as tab delimited
   * string. Owner can be any organizational object.
   *
   * Method to search for all filtered cases for an Organization unit.
   */
  @Deprecated
  public ListCaseByCurrentUserDetails listCasesForOrgUnitOwner(
    CatStatusRefUserType key) throws AppException, InformationalException {

    // informationalManager manipulation variables
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // return struct
    ListCaseByCurrentUserDetails listCaseByCurrentUserDetails = new ListCaseByCurrentUserDetails();

    // populate key with specific type
    key.type = ORGOBJECTTYPE.ORGUNIT;
    key.isOrgObjectRefNull = false;

    // search for cases
    listCaseByCurrentUserDetails.getCasesByOwnerResult = OrgObjectLinkFactory.newInstance().listCasesForOrgObject(
      key);

    // populate informational manager
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      listCaseByCurrentUserDetails.messageList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return listCaseByCurrentUserDetails;
  }

  /**
   * @param key
   * the case status user type
   * @return List of case details
   * @deprecated Since Curam 6.0, replaced by
   * {@link Case#caseDefaultSearchByOwner()}. New method
   * performs a case search based on search criteria which includes owner list
   * passed as tab delimited string. Owner can be any organizational object.
   *
   * Method to search for all filtered cases for a position.
   */
  @Deprecated
  public ListCaseByCurrentUserDetails listCasesForPositionOwner(
    CatStatusRefUserType key) throws AppException, InformationalException {

    // informationalManager manipulation variables
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // return struct
    ListCaseByCurrentUserDetails listCaseByCurrentUserDetails = new ListCaseByCurrentUserDetails();

    // populate key with specific type
    key.type = ORGOBJECTTYPE.POSITION;
    key.isOrgObjectRefNull = false;

    // search for cases
    listCaseByCurrentUserDetails.getCasesByOwnerResult = OrgObjectLinkFactory.newInstance().listCasesForOrgObject(
      key);

    // populate informational manager
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      listCaseByCurrentUserDetails.messageList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return listCaseByCurrentUserDetails;
  }

  /**
   * @param key
   * The CatStatusRefUserType
   *
   * @return List of case details
   * @deprecated Since Curam 6.0, replaced by
   * {@link Case#caseDefaultSearchByOwner()}. New method performs a
   * case search based on search criteria which includes owner list passed as
   * tab delimited string. Owner can be any organizational object.
   *
   * Method to search for all filtered cases for a user.
   */
  @Deprecated
  public ListCaseByCurrentUserDetails listCasesForUser(CatStatusRefUserType key)
    throws AppException, InformationalException {

    // informationalManager manipulation variables
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // return struct
    ListCaseByCurrentUserDetails listCaseByCurrentUserDetails = new ListCaseByCurrentUserDetails();

    // populate key with specific type
    key.type = ORGOBJECTTYPE.USER;
    key.userName = TransactionInfo.getProgramUser();
    key.isOrgObjectRefNull = true;

    // search for cases
    listCaseByCurrentUserDetails.getCasesByOwnerResult = OrgObjectLinkFactory.newInstance().listCasesForOrgObject(
      key);

    // populate informational manager
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      listCaseByCurrentUserDetails.messageList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return listCaseByCurrentUserDetails;
  }

  /**
   * Returns a list of Organization units assigned to a specified user.
   *
   * @return list Organization units for which the user is a member
   */
  public ListOrgUnitDetailsForUser listOrgUnitsForUser() throws AppException,
      InformationalException {

    // return struct
    ListOrgUnitDetailsForUser listOrgUnitDetailsForUser = new ListOrgUnitDetailsForUser();

    listOrgUnitDetailsForUser.list = OrganisationUnitFactory.newInstance().getOrgUnitsForUser();

    return listOrgUnitDetailsForUser;
  }

  /**
   * Returns a list of positions assigned to a specified user.
   *
   * @return list of positions for which the user is a member
   */
  public ListPositionDetailsForUser listPositionsForUser() throws AppException,
      InformationalException {

    // return struct
    ListPositionDetailsForUser listPositionDetailsForUser = new ListPositionDetailsForUser();

    listPositionDetailsForUser.list = PositionFactory.newInstance().getPositionsForUser();

    return listPositionDetailsForUser;
  }

  // END, CR00066883

  // BEGIN, CR00074155 KK
  
  /**
   * Perform post update maintenance of Organization Structure Tree.
   *
   * @param ruleSetNodeKey
   * locationStructureID and NodeID Details.
   * @param selectedPath String containing the selected path for
   * the lazy loading tree update.
   *
   * @throws InformationalException
   * If error occurs.
   * @throws AppException
   * If error occurs.
   */
  public void OrganisationpostUpdate(RuleSetNodeKey ruleSetNodeKey, String selectedPath)
    throws AppException, InformationalException {

    final OrganisationTreeXMLCacheNode selectedCache = OrganisationTreeXMLCacheNode.getInstance();

    if (ruleSetNodeKey.ruleSetID != null
      && ruleSetNodeKey.ruleSetID.trim().length() > 0) {

      // BEGIN, CR00085956, KK
      // The change here is initially the TreeXMLNodeDetails from
      // facade was accessed here , but the service layer TreeXMLNodeDetails
      // needs to be updated because the when reloading
      // the tree the last accessed
      // node is read from the service layer class.
      OrganisationTreeXMLNodeDetail lastAccessedNode = selectedCache.getTreeXMLNodeDetails(
        ruleSetNodeKey.ruleSetID);

      lastAccessedNode.setStLastAccessedNodeId(ruleSetNodeKey.nodeID);
      // TO DO: check if null values from non-create operations should be
      // stored potentially overriding the last selected info.
      // BEGIN, CR00223989
      selectedCache.storeSelectedPath(ruleSetNodeKey.ruleSetID, selectedPath);
      // END, CR00223989
    }
  }

  // END, CR00074155

  // BEGIN, CR00079117, VM
  
  /**
   * Returns the user type for a specified user.
   *
   * @param key
   * Users entity key
   * @return User Type
   */
  public UserType getUserType(UsersKey key) throws AppException,
      InformationalException {

    // Return object
    UserType userType = new UserType();

    userType.userType = UserAccessFactory.newInstance().getUserType(key);

    return userType;
  }

  // END, CR00079117

  // BEGIN, CR00081013, PMD
  
  /**
   * Method to return all integrated case types.
   *
   * @return a list of all integrated case types
   */
  public AdminIntegratedCaseTypes listAllIntegratedCaseTypes()
    throws AppException, InformationalException {

    // Return struct
    AdminIntegratedCaseTypes adminIntegratedCaseTypes = new AdminIntegratedCaseTypes();

    // Get the list of integrated case types
    adminIntegratedCaseTypes.typeList = MaintainAdminIntegratedCaseFactory.newInstance().listAllIntegratedCaseTypes();

    return adminIntegratedCaseTypes;
  }

  // END, CR00081013

  
  /**
   * Clears an active or pending task redirection record. If the task
   * redirection period is active, then the end date time of the task
   * redirection record is updated to be the current date time. If the task
   * redirection period is pending, the task redirection record is simply
   * removed.
   *
   * @param key
   * the clear task redirection key
   */
  public void clearTaskRedirectionForUser(final ClearTaskRedirectionDetails key)
    throws AppException, InformationalException {

    UserWorkspaceFactory.newInstance().clearTaskRedirectionForUser(key);
  }

  // BEGIN, CR00216807 MN
  /**
   * Returns a list of the task redirection records for a specified user. Two
   * lists of data are returned. The first contains the details of the all the
   * active and pending task redirection records for the specified user. The
   * second list contains a list of all the expired task redirection history
   * records for the specified user.
   *
   * @param key
   * The ID of the user.
   *
   * @return a list of all task redirection records for the specified user.
   *
   * @deprecated Since Curam 6.0 , replaced with
   * {@link Organization#getTaskRedirectionHistoryForUser(UserNameKey key)}.
   * As part of CLE changes the implementation has been moved to
   * getTaskRedirectionHistoryForUser with a new return struct
   * TaskRedirectionsFromUserDetails. This struct has all the fields of
   * AllTaskRedirectionsFromUserDetails struct along with fields
   * userFullName and UserNameKey. See release note : <CR00216807>
   */
  @Deprecated
  public curam.core.sl.supervisor.struct.AllTaskRedirectionsFromUserDetails listTaskRedirectionHistoryForUser(
    UserNameKey key) throws AppException, InformationalException {

    TaskRedirectionsFromUserDetails details = this.getTaskRedirectionHistoryForUser(
      key);

    curam.core.sl.supervisor.struct.AllTaskRedirectionsFromUserDetails allTaskRedirectionsFromUserDetails = new curam.core.sl.supervisor.struct.AllTaskRedirectionsFromUserDetails();

    // BEGIN, CR00225492 MN
    // populating Active and Pending Task Redirection details.
    RedirectTaskDetails redirectActiveAndPendingTaskDetails = null;

    curam.core.sl.supervisor.struct.TaskRedirectionDetails taskRedirectionDetails = new curam.core.sl.supervisor.struct.TaskRedirectionDetails();

    ActiveAndPendingTaskRedirectionFromUserDetailsList activeAndPendingTaskRedirectionDetailsList = new ActiveAndPendingTaskRedirectionFromUserDetailsList();

    for (int i = 0; i
      < details.activeAndPendingTaskRedirectionDetails.activeAndPendingDetails.size(); i++) {
      redirectActiveAndPendingTaskDetails = details.activeAndPendingTaskRedirectionDetails.activeAndPendingDetails.get(
        i);

      taskRedirectionDetails.endDateTime = redirectActiveAndPendingTaskDetails.endDateTime;
      taskRedirectionDetails.redirectionStatus = redirectActiveAndPendingTaskDetails.redirectionStatus;
      taskRedirectionDetails.startDateTime = redirectActiveAndPendingTaskDetails.startDateTime;
      taskRedirectionDetails.taskRedirectionID = redirectActiveAndPendingTaskDetails.taskRedirectionID;
      taskRedirectionDetails.toUserFullName = redirectActiveAndPendingTaskDetails.toUserFullName;
      taskRedirectionDetails.toUserName = redirectActiveAndPendingTaskDetails.toUserName;

      activeAndPendingTaskRedirectionDetailsList.activeAndPendingDtls.addRef(
        taskRedirectionDetails);
    }

    allTaskRedirectionsFromUserDetails.activeAndPendingTaskRedirections = activeAndPendingTaskRedirectionDetailsList;
    // _________________________________________________________
    // populating Expired Task Redirection details.
    RedirectTaskDetails redirectExpiredAndPendingTaskDetails = null;

    curam.core.sl.supervisor.struct.TaskRedirectionDetails expiredTaskRedirectionDetails = new curam.core.sl.supervisor.struct.TaskRedirectionDetails();

    ExpiredTaskRedirectionFromUserDetailsList expiredTaskRedirectionDetailsList = new ExpiredTaskRedirectionFromUserDetailsList();

    for (int i = 0; i
      < details.expiredTaskRedirectionDetails.expiredDetails.size(); i++) {
      redirectExpiredAndPendingTaskDetails = details.expiredTaskRedirectionDetails.expiredDetails.get(
        i);

      expiredTaskRedirectionDetails.endDateTime = redirectExpiredAndPendingTaskDetails.endDateTime;
      expiredTaskRedirectionDetails.redirectionStatus = redirectExpiredAndPendingTaskDetails.redirectionStatus;
      expiredTaskRedirectionDetails.startDateTime = redirectExpiredAndPendingTaskDetails.startDateTime;
      expiredTaskRedirectionDetails.taskRedirectionID = redirectExpiredAndPendingTaskDetails.taskRedirectionID;
      expiredTaskRedirectionDetails.toUserFullName = redirectExpiredAndPendingTaskDetails.toUserFullName;
      expiredTaskRedirectionDetails.toUserName = redirectExpiredAndPendingTaskDetails.toUserName;

      expiredTaskRedirectionDetailsList.expiredDtls.addRef(
        expiredTaskRedirectionDetails);
    }

    allTaskRedirectionsFromUserDetails.expiredTaskRedirections = expiredTaskRedirectionDetailsList;
    // END, CR00225492
    return allTaskRedirectionsFromUserDetails;
  }

  // END, CR00216807
  
  // BEGIN, CR00225492 MN
  /**
   * Creates a task redirection record for the specified user. This record
   * specifies another user to whom tasks for the specified user will be
   * redirected to. A start and end date time is also specified for each task
   * redirection record and this allows the creation of task redirections for
   * future dates also.
   *
   * @param key
   * The task redirection details.
   *
   * @deprecated Since Curam 6.0 , replaced with
   * {@link Organization#taskRedirectionsForUserDetails(TaskRedirectionsForUserDetails details)}.
   * In addition to the current functionality, the new method allows tasks to
   * be redirected to targets other than just users.
   * See release note : <CR00225492>
   */
  @Deprecated
  public void redirectTasksForUserDetails(
    curam.core.sl.struct.RedirectTasksForUserDetails key)
    throws AppException, InformationalException {

    TaskRedirectionsForUserDetails taskRedirectionsForUserDetails = new TaskRedirectionsForUserDetails();

    taskRedirectionsForUserDetails.endDateTime = key.endDateTime;
    taskRedirectionsForUserDetails.fromUserName = key.fromUserName;
    taskRedirectionsForUserDetails.startDateTime = key.startDateTime;
    taskRedirectionsForUserDetails.toUserName = key.toUserName;
    taskRedirectionsForUserDetails.toUserNameInSupervisorGroup = key.toUserNameInSupervisorGroup;
    taskRedirectionsForUserDetails.toRedirectType = REDIRECTIONTARGETITEMTYPE.USER;

    this.taskRedirectionsForUserDetails(taskRedirectionsForUserDetails);
  }

  // END, CR00225492

  
  /**
   * This method validates the task redirection details for a user.
   *
   * @param key
   * The task redirection details.
   *
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00225492 MN
  protected void validateTaskRedirection(TaskRedirectionsForUserDetails key)
    throws AppException, InformationalException {
    // END, CR00225492
    UserNameAndDateTimeKey userNameAndDateTimeKey = new UserNameAndDateTimeKey();

    // The time period of the task redirection block must not overlap with any
    // current or pending task allocation block.

    // Assign the key values
    userNameAndDateTimeKey.userName = key.fromUserName;
    userNameAndDateTimeKey.currentDateTime = new DateTime(
      Date.getCurrentDate().getDateTime());
    AllTaskAllocationBlockingPeriodsForUserDetails allTaskAllocationBlockingPeriodsForUserDetails = UserWorkspaceFactory.newInstance().listTaskAllocationBlockingHistoryForUser(
      userNameAndDateTimeKey);

    int numOfActiveAndPendingTaskAllocBlockingPeriodsForUser = allTaskAllocationBlockingPeriodsForUserDetails.activeAndPendingTaskAllocationBlockingPeriods.activeAndPendingDtls.size();

    for (int i = 0; i < numOfActiveAndPendingTaskAllocBlockingPeriodsForUser; i++) {

      TaskAllocationBlockingDetails taskAllocationBlockingDetails = new TaskAllocationBlockingDetails();

      taskAllocationBlockingDetails = allTaskAllocationBlockingPeriodsForUserDetails.activeAndPendingTaskAllocationBlockingPeriods.activeAndPendingDtls.item(
        i);

      if (!taskAllocationBlockingDetails.endDateTime.equals(
        DateTime.kZeroDateTime)) {
        // TAB end date time is not blank
        if (key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is blank
          if (taskAllocationBlockingDetails.endDateTime.before(
            key.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_ALLOCATION_BLOCKING_TIME_PERIODS_CANNOT_OVERLAP),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                1);
          }
        }
      } // TAB end date time is blank
      else {
        if (!key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is not blank
          if (key.endDateTime.before(
            taskAllocationBlockingDetails.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_ALLOCATION_BLOCKING_TIME_PERIODS_CANNOT_OVERLAP),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
          }
        } // key end date time is blank
        else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_ALLOCATION_BLOCKING_TIME_PERIODS_CANNOT_OVERLAP),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              2);
        }
      }
    }

    UserNameKey userNamekey = new UserNameKey();

    // The time period of the task redirection block must not overlap with any
    // current or pending task redirections.
    userNamekey.userName = key.fromUserName;
    // BEGIN, CR00225492 MN
    TaskRedirectionsFromUserDetails allTaskRedirectionsFromUserDetails = getTaskRedirectionHistoryForUser(
      userNamekey);
    // END, CR00225492
    int numOfTasksRedirectionHistoryDetails = allTaskRedirectionsFromUserDetails.activeAndPendingTaskRedirections.activeAndPendingDtls.size();

    for (int i = 0; i < numOfTasksRedirectionHistoryDetails; i++) {
      curam.core.sl.supervisor.struct.RedirectTaskDetails tasksRedirectionDetails = new curam.core.sl.supervisor.struct.RedirectTaskDetails();

      // BEGIN, CR00225492 MN
      tasksRedirectionDetails = allTaskRedirectionsFromUserDetails.activeAndPendingTaskRedirectionDetails.activeAndPendingDetails.item(
        i);
      // END, CR00225492

      if (!tasksRedirectionDetails.endDateTime.equals(DateTime.kZeroDateTime)) {
        // TAB end date time is not blank
        if (key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is blank
          if (tasksRedirectionDetails.endDateTime.before(key.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_REDIRECTION_TIME_PERIODS_CANNOT_OVERLAP),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                1);
          }
        }
      } // TAB end date time is blank
      else {
        if (!key.endDateTime.equals(DateTime.kZeroDateTime)) {
          // key end date time is not blank
          if (key.endDateTime.before(tasksRedirectionDetails.startDateTime)) {// continue;
          } else {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_REDIRECTION_TIME_PERIODS_CANNOT_OVERLAP),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                2);
          }
        } // key end date time is blank
        else {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOTASKREDIRECTION.ERR_TASKREDIRECTION_XRV_REDIRECTION_TIME_PERIODS_CANNOT_OVERLAP),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }

    }
  }

  // BEGIN CR00085891, KK
  
  /**
   * This method updates the last accessed node to zero so that when the
   * location structure tree is opened from the location home, the corresponding
   * node is highlighted. This method is accessed in the tree resolve pages from
   * the location home page.
   *
   * @param key
   * location structure id
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void setLocationTreeXMLNodeDetails(
    curam.core.facade.struct.LocationStructureKey key) throws AppException,
      InformationalException {

    // key to update the TreeNodeDetails HashMap
    RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // key and value pair
    ruleSetNodeKey.ruleSetID = String.valueOf(key.dtls.locationStructureID);
    ruleSetNodeKey.nodeID = 0;
    LocationpostUpdate(ruleSetNodeKey);
  }

  /**
   * This method updates the last accessed node to zero so that when the
   * organization structure tree is opened from the organization unit home or
   * position, the corresponding node is highlighted. This method is accessed in
   * the tree resolve pages from the position and organization unit home pages.
   *
   * @param key
   * organization structure id
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void setOrganisationTreeXMLNodeDetails(OrganisationStructureKey key)
    throws AppException, InformationalException {

    // key to update the TreeNodeDetails HashMap
    RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    // key and value pair
    ruleSetNodeKey.ruleSetID = String.valueOf(
      key.organisationStructureKey.organisationStructureKey.organisationStructureID);
    ruleSetNodeKey.nodeID = 0;
    // BEGIN, CR00251478, ZV
    OrganisationpostUpdate(ruleSetNodeKey, CuramConst.gkEmpty);
    // END, CR00251478

  }

  /**
   * Perform post update maintenance of location structure tree.
   *
   * @param ruleSetNodeKey
   * locationStructureID and NodeID Details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void LocationpostUpdate(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {

    if (ruleSetNodeKey.ruleSetID != null
      && ruleSetNodeKey.ruleSetID.trim().length() > 0) {

      // Initially the TreeXMLNodeDetails from the facade are accessed
      // here, but the service layer TreeXMLNodeDetails needs to be updated
      // as well because when reloading the tree the last accessed node
      // is read from the service layer.
      LocationTreeXMLNodeDetail lastAccessedNode = LocationTreeXMLCacheNode.getInstance().getTreeXMLNodeDetails(
        ruleSetNodeKey.ruleSetID);

      lastAccessedNode.setStLastAccessedNodeId(ruleSetNodeKey.nodeID);
    }
  }

  // END, CR00085891

  // BEGIN, CR00100372, KH
  
  /**
   * This method cancels the specified working pattern for the location.
   *
   * @param workingPatternKey
   * The ID of the working pattern to be cancelled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void cancelLocationWorkingPattern(WorkingPatternKey workingPatternKey)
    throws AppException, InformationalException {

    MaintainWorkingPatternKey key = new MaintainWorkingPatternKey();

    key.workingPatternID = workingPatternKey.workingPatternID;

    MaintainWorkingPatternFactory.newInstance().cancelWorkingPattern(key);
  }

  /**
   * This method creates a new working pattern for the location.
   *
   * @param details
   * Contains the working pattern details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void createLocationWorkingPattern(WorkingPatternDetails details)
    throws AppException, InformationalException {

    MaintainWorkingPatternFactory.newInstance().createDefaultWorkingPattern(
      details);
  }

  /**
   * This method lists all of the working patterns for a specified location.
   *
   * @param locationKey
   * The ID of the location.
   * @return listLocationWorkingPatternDetails
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ListLocationWorkingPatternDetails listLocationWorkingPattern(
    LocationKey locationKey) throws AppException, InformationalException {

    ListLocationWorkingPatternDetails listLocationWorkingPatternDetails = new ListLocationWorkingPatternDetails();

    WorkingPatternOwnerKey workingPatternOwnerKey = new WorkingPatternOwnerKey();

    workingPatternOwnerKey.locationID = locationKey.locationID;

    listLocationWorkingPatternDetails.dtlsList = MaintainWorkingPatternFactory.newInstance().readAllWorkingPatterns(
      workingPatternOwnerKey);

    // Assign context description
    LocationContextDescriptionKey locationContextDescriptionKey = new LocationContextDescriptionKey();

    locationContextDescriptionKey.locationID = locationKey.locationID;

    listLocationWorkingPatternDetails.description = readLocationContextDescription(
      locationContextDescriptionKey);

    return listLocationWorkingPatternDetails;
  }

  /**
   * This method modifies the details of a location working pattern.
   *
   * @param details
   * Contains the working pattern details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyLocationWorkingPattern(WorkingPatternDetails details)
    throws AppException, InformationalException {

    MaintainWorkingPatternFactory.newInstance().modifyDefaultWorkingPattern(
      details);
  }

  /**
   * This method reads the details of the specified working pattern.
   *
   * @param workingPatternKey
   * The ID of the working pattern to be displayed.
   * @return readLocationWorkingPatternDetails the details
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReadLocationWorkingPatternDetails readLocationWorkingPattern(
    WorkingPatternKey workingPatternKey) throws AppException,
      InformationalException {

    ReadLocationWorkingPatternDetails readLocationWorkingPatternDetails = new ReadLocationWorkingPatternDetails();

    // The key to read the working pattern
    MaintainWorkingPatternKey key = new MaintainWorkingPatternKey();

    key.workingPatternID = workingPatternKey.workingPatternID;

    ReadWorkingPatternResult readWorkingPatternResult = MaintainWorkingPatternFactory.newInstance().readWorkingPattern(
      key);

    readLocationWorkingPatternDetails.details.assign(readWorkingPatternResult);

    // Assign the working pattern details for each day
    for (int i = 0; i < readWorkingPatternResult.typesList.dtls.size(); i++) {

      WorkingPatternTypeDetails workingPatternTypeDetails = new WorkingPatternTypeDetails();

      // Convert start and end times to string
      workingPatternTypeDetails.stringActivePatternStartTime = Locale.getFormattedDateTime(
        readWorkingPatternResult.typesList.dtls.item(i).startTime, kTimeFormat);
      workingPatternTypeDetails.stringActivePatternEndTime = Locale.getFormattedDateTime(
        readWorkingPatternResult.typesList.dtls.item(i).endTime, kTimeFormat);

      workingPatternTypeDetails.dayNumber = readWorkingPatternResult.typesList.dtls.item(i).dayNumber;
      workingPatternTypeDetails.nsVersionNo = readWorkingPatternResult.typesList.dtls.item(i).nsVersionNo;
      workingPatternTypeDetails.typeCode = readWorkingPatternResult.typesList.dtls.item(i).typeCode;

      readLocationWorkingPatternDetails.dayList.addRef(
        workingPatternTypeDetails);
    }

    return readLocationWorkingPatternDetails;
  }

  /**
   * This method creates or modifies non-standard working pattern or changes
   * pattern type for the day for a location.
   *
   * @param details
   * The non standard working pattern details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void maintainLocationNonStandardWorkingPattern(
    MaintainNonStandardWorkingPatternDetails details) throws AppException,
      InformationalException {

    // Maintain working pattern object
    MaintainWorkingPattern maintainWorkingPatternObj = MaintainWorkingPatternFactory.newInstance();

    // The key to read the working pattern for the specified day
    NSPatternByDayIndexKey nsPatternByDayIndexKey = new NSPatternByDayIndexKey();

    nsPatternByDayIndexKey.dayNumber = details.dayNumber;
    nsPatternByDayIndexKey.workingPatternID = details.workingPatternID;

    // Read the working pattern details for the specified day number
    WorkingPatternDetails workingPatternDetails = maintainWorkingPatternObj.readWorkingPatternForDay(
      nsPatternByDayIndexKey);

    // Set the new working pattern details
    workingPatternDetails.dayNumber = details.dayNumber;
    workingPatternDetails.typeCode = details.typeCode;
    workingPatternDetails.activePatternStartTime = details.activePatternStartTime;
    workingPatternDetails.activePatternEndTime = details.activePatternEndTime;

    // Update the working pattern
    maintainWorkingPatternObj.createModifyWorkingPatternForDay(
      workingPatternDetails);
  }

  /**
   * This method reads the non-standard working pattern details for a specific
   * day for a location.
   *
   * @param key
   * The working pattern ID and day number.
   *
   * @return details The non working pattern details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WorkingPatternDetails readLocationNonStandardWorkingPattern(
    NSPatternByDayIndexKey key) throws AppException, InformationalException {

    return MaintainWorkingPatternFactory.newInstance().readWorkingPatternForDay(
      key);
  }

  // END, CR00100372

  // BEGIN, CR00104950, MC
  
  /**
   * This method allows an administrator to cancel an Investigation Resolution
   * Approval Check for an organization unit.
   *
   * @param key
   * The unique id of the Investigation Resolution Approval Check to be
   * canceled.
   */
  public void cancelInvestigationApprovalCheckForOrgUnit(
    CancelInvestigationApprovalCheckKey key) throws AppException,
      InformationalException {

    // Call InvestigationResolutionApprovalCheck BPO to perform the cancel
    // operation
    InvestigationApprovalCheckFactory.newInstance().cancel(key.cancelDtls);
  }

  /**
   * This method allows an administrator to configure an approval check for an
   * organization unit. It allows a percentage of resolutions on Investigations
   * which are submitted for approval to be reviewed.
   *
   * @param details
   * The Investigation Resolution Approval Check details.
   */
  public void createInvestigationApprovalCheckForOrgUnit(
    InvestigationApprovalCheckDetails details) throws AppException,
      InformationalException {

    // Call InvestigationResolutionApprovalCheck BPO to perform the create
    // operation
    InvestigationApprovalCheckFactory.newInstance().create(details.dtls);
  }

  /**
   * This method lists all existing approval checks for a user.
   *
   * @param key
   * The unique id of the user that the resolution approval checks are
   * being listed for.
   * @return A list of resolution approval checks for the user.
   */
  public ListUserInvestigationApprovalCheckDetails listInvestigationApprovalCheckForUser(
    ListUserInvestigationApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return Object
    ListUserInvestigationApprovalCheckDetails listUserApprovalCheckDetails = new ListUserInvestigationApprovalCheckDetails();

    // Context description key object
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    // Call InvestigationResolutionApprovalCheck BPO to perform the list
    // operation
    listUserApprovalCheckDetails.dtls = InvestigationApprovalCheckFactory.newInstance().listApprovalChecksForUser(
      key.dtlsList);

    // Set context description key
    organizationUserContextDescriptionKey.userName = key.dtlsList.searchByUserKey.userName;

    // Get context description
    listUserApprovalCheckDetails.contextDtls = readUserContextDescription(
      organizationUserContextDescriptionKey);

    return listUserApprovalCheckDetails;
  }

  /**
   * This method allows an administrator to cancel an Investigation Resolution
   * Approval Check for a user.
   *
   * @param key
   * The unique id of the Investigation Resolution Approval Check to be
   * canceled.
   */
  public void cancelInvestigationApprovalCheckForUser(
    CancelInvestigationApprovalCheckKey key) throws AppException,
      InformationalException {

    // Call InvestigationResolutionApprovalCheck BPO to perform the cancel
    // operation
    InvestigationApprovalCheckFactory.newInstance().cancel(key.cancelDtls);
  }

  /**
   * This method allows an administrator to configure an approval check for a
   * user. It allows a percentage of resolutions on investigations which are
   * submitted for approval to be reviewed.
   *
   * @param details
   * The Investigation Approval Check details.
   */
  public void createInvestigationApprovalCheckForUser(
    InvestigationApprovalCheckDetails details) throws AppException,
      InformationalException {

    // Call InvestigationResolutionApprovalCheck BPO to perform the create
    // operation
    InvestigationApprovalCheckFactory.newInstance().create(details.dtls);
  }

  /**
   * This method allows an administrator to modify an Investigation Approval
   * Check for a user.
   *
   * @param details
   * The Investigation approval check modified details.
   */
  public void modifyInvestigationApprovalCheckForUser(
    InvestigationApprovalCheckDetails details) throws AppException,
      InformationalException {

    // Call InvestigationResolutionApprovalCheck BPO to perform the modify
    // operation
    InvestigationApprovalCheckFactory.newInstance().modify(details.dtls);
  }

  /**
   * This method allows an administrator to view a approval check for a user.
   *
   * @param key
   * The unique id of the Investigation Approval Check to be read.
   * @return The approval check details for the user.
   */
  public ReadUserInvestigationApprovalCheckDetails readInvestigationApprovalCheckForUser(
    ReadInvestigationApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return Object
    ReadUserInvestigationApprovalCheckDetails readUserApprovalCheckDetails = new ReadUserInvestigationApprovalCheckDetails();

    // Call InvestigationResolutionApprovalCheck BPO to perform the read
    // operation
    readUserApprovalCheckDetails.dtls = InvestigationApprovalCheckFactory.newInstance().read(
      key.key);

    // Context description key object
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    // Set context description key
    organizationUserContextDescriptionKey.userName = readUserApprovalCheckDetails.dtls.dtls.userName;

    // Get context description
    readUserApprovalCheckDetails.contextDtls = readUserContextDescription(
      organizationUserContextDescriptionKey);

    return readUserApprovalCheckDetails;
  }

  /**
   * This method lists investigation types that are available for approval check
   * creation.
   *
   * @return A list of investigation types.
   */
  public InvestigationConfigurationTypeDetailsList listAvailableInvestigationsForApprovalCheck()
    throws AppException, InformationalException {

    // Return Object
    InvestigationConfigurationTypeDetailsList investigationConfigurationTypeDetailsList = new InvestigationConfigurationTypeDetailsList();

    // Call InvestigationResolutionApprovalCheck BPO to perform the list
    // operation
    investigationConfigurationTypeDetailsList.investigationConfigurationTypeDetailsList = InvestigationApprovalCheckFactory.newInstance().listAvailableInvestigationsForApprovalCheck();

    return investigationConfigurationTypeDetailsList;
  }

  /**
   * This method allows an administrator to modify an Investigation Approval
   * Check for an organization unit.
   *
   * @param details
   * The investigation approval check modified details.
   */
  public void modifyInvestigationApprovalCheckForOrgUnit(
    InvestigationApprovalCheckDetails details) throws AppException,
      InformationalException {

    // Call InvestigationApprovalCheck BPO to perform the modify operation
    InvestigationApprovalCheckFactory.newInstance().modify(details.dtls);
  }

  /**
   * This method allows an administrator to view a approval check for an
   * organization unit.
   *
   * @param key
   * The unique id of the Investigation Approval Check to be read.
   * @return The approval check details for the organization unit.
   */
  public ReadOrgUnitInvestigationApprovalCheckDetails readInvestigationApprovalCheckForOrgUnit(
    ReadInvestigationApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return Object
    ReadOrgUnitInvestigationApprovalCheckDetails readOrgUnitApprovalCheckDetails = new ReadOrgUnitInvestigationApprovalCheckDetails();

    // Call InvestigationResolutionApprovalCheck BPO to perform the read
    // operation
    readOrgUnitApprovalCheckDetails.dtls = InvestigationApprovalCheckFactory.newInstance().read(
      key.key);

    // Context description key object
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Set context description key
    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = readOrgUnitApprovalCheckDetails.dtls.dtls.organisationUnitID;

    // Get context description
    readOrgUnitApprovalCheckDetails.contextDetails = readOrganisationUnitContextDescription(
      organisationUnitKey);

    return readOrgUnitApprovalCheckDetails;
  }

  /**
   * This method lists all existing approval checks for an organization unit.
   *
   * @param key
   * The unique id of the organization unit that the resolution
   * approval checks are being listed for.
   * @return A list of resolution approval checks for the organization unit.
   */
  public ListOrgUnitInvestigationApprovalCheckDetails listInvestigationApprovalCheckForOrgUnit(
    ListOrgUnitInvestigationApprovalCheckKey key) throws AppException,
      InformationalException {

    // Return Object
    ListOrgUnitInvestigationApprovalCheckDetails listOrgUnitInvestigationApprovalCheckDetails = new ListOrgUnitInvestigationApprovalCheckDetails();

    // Context description key object
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    // Call InvestigationResolutionApprovalCheck BPO to perform the list
    // operation
    listOrgUnitInvestigationApprovalCheckDetails.dtls = InvestigationApprovalCheckFactory.newInstance().listApprovalChecksForOrgUnit(
      key.key);

    // Set context description key
    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.key.searchByOrgUnitKey.organisationUnitID;

    // Get context description
    listOrgUnitInvestigationApprovalCheckDetails.contextDtls = readOrganisationUnitContextDescription(
      organisationUnitKey);

    return listOrgUnitInvestigationApprovalCheckDetails;
  }

  // END, CR00104950

  
  /**
   * This method returns the correct home page for the logged in user.
   *
   * @return homePage contains the home page for the logged in user.
   */
  public UserApplicationHome getUserApplicationHome() throws AppException,
      InformationalException {

    // Return object
    UserApplicationHome applicationHome = new UserApplicationHome();
    // System User manipulation variables
    UserNameKey userNameKey = new UserNameKey();
    SystemUser systemUserObj = SystemUserFactory.newInstance();
    // Code table manipulation variable
    curam.util.internal.codetable.intf.CodeTable codeTableObj = CodeTableFactory.newInstance();
    String applicationCode = "";

    userNameKey.userName = systemUserObj.getUserDetails().userName;

    Users usersObj = UsersFactory.newInstance();

    applicationCode = usersObj.readUserAppCode(userNameKey).applicationCode;
    CTItemKey item = new CTItemKey();

    item.code = applicationCode;
    item.tableName = APPLICATION_CODE.TABLENAME;
    item.locale = TransactionInfo.getProgramLocale();

    // Ensure that an application code exists, otherwise default the value
    if (item.code.length() == 0) {
      item.code = APPLICATION_CODE.DEFAULTCODE;
    }

    applicationHome.homePageName = codeTableObj.getOneItem(item).description;

    return applicationHome;
  }

  /**
   * Method to return user name and full name of logged in user.
   *
   * @return User name and full name details.
   */
  public UserNameAndFullName getCurrentUser() throws AppException,
      InformationalException {

    // user name details return variable
    UserNameAndFullName userNameAndFullName = new UserNameAndFullName();

    // get current user name
    userNameAndFullName.userName = SystemUserFactory.newInstance().getUserDetails().userName;

    // Users key
    UsersKey usersKey = new UsersKey();

    // set user name key
    usersKey.userName = userNameAndFullName.userName;

    // get full user name
    userNameAndFullName.fullName = UserAccessFactory.newInstance().getFullName(usersKey).fullname;

    // return current user name details
    return userNameAndFullName;

  }

  // BEGIN, CR00112455, PMD
  
  /**
   * This method will change the record status of an announcement from Active to
   * Canceled.
   *
   * @param key
   * The unique identifier of the announcement.
   */
  public void cancelAnnouncement(AnnouncementKey key) throws AppException,
      InformationalException {

    // Cancel the announcement
    AnnouncementFactory.newInstance().cancel(key);
  }

  /**
   * This method allows an administrator to configure an organization wide
   * announcement. This announcement will appear on the user's home page when
   * they log on.
   *
   * @param details
   * The announcement details to be inserted.
   */
  public void createAnnouncement(AnnouncementDtls details) throws AppException,
      InformationalException {

    // Create the announcement
    AnnouncementFactory.newInstance().create(details.details);
  }

  /**
   * Method to allow an administrator to list all active and cancelled
   * announcements configured for the organization.
   *
   * @return detailsList List of all announcement records
   */
  public AnnouncementDtlsList listAnnouncements() throws AppException,
      InformationalException {

    // Return object
    AnnouncementDtlsList announcementDtlsList = new AnnouncementDtlsList();

    // Get the list of announcements
    announcementDtlsList.list = AnnouncementFactory.newInstance().list();

    return announcementDtlsList;
  }

  /**
   * Method to allow an administrator to modify the details of a specified
   * announcement that has been configured for the organization.
   *
   * @param details
   * Announcement details to be modified
   */
  public void modifyAnnouncement(AnnouncementDtls details) throws AppException,
      InformationalException {

    // Modify the announcement
    AnnouncementFactory.newInstance().modify(details.details);
  }

  /**
   * Method to allow an administrator to read the details of a specified
   * announcement that has been configured for the organization.
   *
   * @param key
   * The unique identifier of the announcement.
   * @return details Details of the announcement record.
   */
  public AnnouncementDtls readAnnouncement(AnnouncementKey key)
    throws AppException, InformationalException {

    // Return object
    AnnouncementDtls announcementDtls = new AnnouncementDtls();

    // Read the announcement
    announcementDtls.details = AnnouncementFactory.newInstance().read(key);

    return announcementDtls;
  }

  // END, CR00112455

  // BEGIN, CR00112785, CSH
  
  /**
   * This method will change the record status of a quick link from Active to
   * Canceled.
   *
   * @param key
   * The unique identifier of the quick link.
   */
  public void cancelQuickLink(QuickLinkKey key) throws AppException,
      InformationalException {

    // Cancel the quick link
    QuickLinkFactory.newInstance().cancel(key);
  }

  /**
   * This method allows an administrator to record a quick link for the
   * organization. This quick link can be associated with a users security role
   * and appear on their home page when they log on.
   *
   * @param details
   * The quick link details to be inserted.
   */
  public void createQuickLink(QuickLinkDetails details) throws AppException,
      InformationalException {

    // Create the quick link
    QuickLinkFactory.newInstance().create(details.dtls);
  }

  /**
   * Method to allow an administrator to list all active and cancelled quick
   * links recorded for the organization.
   *
   * @return detailsList List of all quick link records
   */
  public QuickLinkDetailsList listQuickLinks() throws AppException,
      InformationalException {

    // Return object
    QuickLinkDetailsList quickLinkDetailsList = new QuickLinkDetailsList();

    // Get the list of quick links
    quickLinkDetailsList.list = QuickLinkFactory.newInstance().list();

    return quickLinkDetailsList;
  }

  /**
   * Method to allow an administrator to modify the details of a specified quick
   * link that has been recorded for the organization.
   *
   * @param details
   * Quick Link details to be modified
   */
  public void modifyQuickLink(QuickLinkDetails details) throws AppException,
      InformationalException {

    // Modify the quick link
    QuickLinkFactory.newInstance().modify(details.dtls);
  }

  /**
   * Method to allow an administrator to read the details of a specified quick
   * link that has been recorded for the organization.
   *
   * @param key
   * The unique identifier of the quick link.
   * @return details Details of the quick link record.
   */
  public QuickLinkDetails readQuickLink(QuickLinkKey key) throws AppException,
      InformationalException {

    // Return object
    QuickLinkDetails quickLinkDetails = new QuickLinkDetails();

    // Read the quick link details
    quickLinkDetails.dtls = QuickLinkFactory.newInstance().read(key);

    return quickLinkDetails;
  }

  // BEGIN, CR00244797, ZV
  
  /**
   * This method allows an administrator to create an association between a
   * quick link and an application code. The associated quick link will appear
   * on the users home page when they log on.
   *
   * @param details
   * The quick link security role link details to be inserted.
   */
  public void addQuickLinkForApplicationCode(QuickLinkApplicationLinkDtls details)
    throws AppException, InformationalException {

    // Variable to hold the tab delimited list of quick link IDs
    String tabList = new String();

    // Set the list
    tabList = details.quickLinkList;

    // Convert the tab list to a list of strings
    StringList quickLinkList = StringUtil.tabText2StringList(tabList);

    // For each quick link in the list create a new link record with
    // the security role
    for (int i = 0; i < quickLinkList.size(); i++) {

      // Reset the ID
      details.dtls.dtls.quickLinkID = 0;
      details.dtls.dtls.quickLinkID = Long.parseLong(quickLinkList.item(i));

      // Create the quick link security role link record
      QuickLinkApplicationLinkFactory.newInstance().create(details.dtls);

    }
  }

  /**
   * This method lists all quick links associated with an application code
   *
   * @param key
   * The application code.
   */
  public QuickLinkApplicationDetailsList listQuickLinkForApplicationCode(
    final ApplicationCodeKey key)
    throws AppException, InformationalException {

    // Return object
    QuickLinkApplicationDetailsList quickLinkApplicationDetailsList = new QuickLinkApplicationDetailsList();

    // Get the list of quick links
    quickLinkApplicationDetailsList.list = QuickLinkApplicationLinkFactory.newInstance().list(
      key);

    // Create an informational manager
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Read any informationals returned from service layer
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      quickLinkApplicationDetailsList.list.info.dtls.addRef(
        informationalMsgDtls);

    }

    return quickLinkApplicationDetailsList;
  }

  /**
   * This method removes an association between a quick link and an application
   * code.
   *
   * @param key
   * The identifier of the record to be removed.
   */
  public void removeQuickLinkFromApplicationCode(QuickLinkApplicationLinkKey key)
    throws AppException, InformationalException {

    // Remove the quick link from the security role
    QuickLinkApplicationLinkFactory.newInstance().remove(key);

  }

  /**
   * This method lists all quick links that can be associated with a specified
   * application code.
   *
   * @param key
   * The application code.
   */
  public QuickLinkDetailsList listUnassociatedQuickLinks(ApplicationCodeKey key)
    throws AppException, InformationalException {

    // Return object
    QuickLinkDetailsList quickLinkDetailsList = new QuickLinkDetailsList();

    // Quick Link manipulation variables
    QuickLinkKey quickLinkKey = new QuickLinkKey();
    curam.core.sl.entity.intf.QuickLinkApplicationLink quickLinkApplicationObj = curam.core.sl.entity.fact.QuickLinkApplicationLinkFactory.newInstance();
    QuickLinkApplicationLinkDtlsList quickLinkApplicationLinkDtlsList = new QuickLinkApplicationLinkDtlsList();
    int counter;

    // List the quick links that have been recorded for the organization
    quickLinkDetailsList = listQuickLinks();

    for (int i = 0; i < quickLinkDetailsList.list.list.dtls.size(); i++) {

      // Reset counter
      counter = 0;

      // Set the quick link key
      quickLinkKey.quickLinkID = quickLinkDetailsList.list.list.dtls.item(i).quickLinkID;

      // Search for existing associations
      quickLinkApplicationLinkDtlsList.list.list = quickLinkApplicationObj.searchByQuickLinkID(
        quickLinkKey);

      for (int j = 0; j
        < quickLinkApplicationLinkDtlsList.list.list.dtls.size(); j++) {

        // Check if there are any existing associations for this role
        if (quickLinkApplicationLinkDtlsList.list.list.dtls.item(j).applicationCode.equals(
          key.applicationCode)) {

          // Increment counter for existing associations
          counter++;

        }
      }

      // Filter any quick links already associated with this application
      // code or cancelled records from the list
      if ((counter > 0)
        || (quickLinkDetailsList.list.list.dtls.item(i).statusCode.equals(
          RECORDSTATUS.CANCELLED))) {

        quickLinkDetailsList.list.list.dtls.remove(i);
        i--;
      }
    }
    return quickLinkDetailsList;
  }

  // END, CR00112785
  // END, CR00244797

  // BEGIN, CR00143146, ZV
  
  /**
   * Method to return organization unit details and users assigned to it
   * details list.
   *
   * @return Organization unit details and users assigned to it details list.
   */
  public OrganisationUnitDetailsAndUserList readOrganisationUnitDetailsAndUserList(
    curam.core.sl.entity.struct.OrgStructureAndOrgUnitKey key)
    throws AppException, InformationalException {

    return OrganisationUnitFactory.newInstance().readOrganisationUnitDetailsAndUserList(
      key);
  }

  /**
   * Method to return position details and users assigned to it details list.
   *
   * @return Position details and users assigned to it details list.
   */
  public PositionDetailsAndUserList readPositionDetailsAndUserList(
    curam.core.sl.entity.struct.OrgStructureAndPositionKey key)
    throws AppException, InformationalException {

    return PositionFactory.newInstance().readPositionDetailsAndUserList(key);
  }

  // BEGIN, CR00243101, PDN
  
  /**
   * @return User names, role name and contact details.
   * @deprecated - replaced by {@link #readUserRoleAndContactDetails1()}
   * @deprecated -since Version 6.0
   * Method to return user names, role name and contact details.
   */
  @Deprecated
  public UserRoleAndContactDetails readUserRoleAndContactDetails(UsersKey key)
    throws AppException, InformationalException {

    return AdminUserFactory.newInstance().readRoleAndContactDetails(key);
  }

  /**
   * Method to return user names, role name and contact details.
   *
   * @return User names, role name and contact details.
   */
  public curam.core.facade.struct.UserRoleAndContactDetails readUserRoleAndContactDetails1(UsersKey key) throws AppException,
      InformationalException {

    curam.core.facade.struct.UserRoleAndContactDetails details = new curam.core.facade.struct.UserRoleAndContactDetails();

    details.dtls = AdminUserFactory.newInstance().readRoleAndContactDetails(key);

    // Determine if the user is an external user
    ExternalUserKey externalUserKey = new ExternalUserKey();

    externalUserKey.userName = details.dtls.userName;
    ExternalUser externalUserObj = ExternalUserFactory.newInstance();

    boolean isExternalUser = false;

    try {
      externalUserObj.read(externalUserKey);
      isExternalUser = true;
    } catch (Exception ex1) {
      isExternalUser = false;
    }

    details.isExternalUser = isExternalUser;

    return details;
  }

  // END, CR00243101
  // END, CR00143146
  // BEGIN, CR00161962, KY
  /**
   * This method cancels an internal user.
   *
   * @param cancelUserKey
   * contains the user name to be canceled.
   */
  public void cancelInternalUser(CancelUserKey cancelUserKey)
    throws AppException, InformationalException {
    UserAccess userAccessObj = UserAccessFactory.newInstance();

    userAccessObj.cancelUserStartWFProcess(cancelUserKey.cancelUserKeyStruct);
  }

  // END, CR00161962


  // BEGIN, CR00244797, ZV
  // BEGIN, CR00129091, CSH
  
  /**
   * This method allows an administrator to create a new quick link from within
   * a users security role and to also create an association between this link
   * and the role.
   *
   * @param details
   * The quick link and security role link details to be inserted.
   */
  public void createAndAddQuickLinkToApplicationCode(QuickLinkDetails details)
    throws AppException, InformationalException {

    QuickLinkKey quickLinkKey = new QuickLinkKey();
    QuickLinkApplicationLinkDtls quickLinkApplicationLinkDtls = new QuickLinkApplicationLinkDtls();

    // Create the quick link
    quickLinkKey = QuickLinkFactory.newInstance().create(details.dtls);

    // Set the details
    quickLinkApplicationLinkDtls.dtls.dtls.quickLinkID = quickLinkKey.quickLinkID;
    quickLinkApplicationLinkDtls.dtls.dtls.applicationCode = details.dtls.applicationCode;

    // Create the quick link security role link record
    QuickLinkApplicationLinkFactory.newInstance().create(
      quickLinkApplicationLinkDtls.dtls);
  }

  // END, CR00129091
  // END, CR00244797

  // BEGIN, CR00129355, JC
  
  /**
   * Method to allow an administrator to read the details of a specified report
   * that has been recorded for the organization.
   *
   * @param key
   * The unique identifier of the report.
   * @return details Details of the report record.
   */
  public ReportDetails readReport(ReportKey key) throws AppException,
      InformationalException {

    // Return object
    ReportDetails reportDetails = new ReportDetails();

    // Read the quick link details
    reportDetails.dtls = ReportFactory.newInstance().read(key);

    return reportDetails;
  }

  /**
   * Method to allow an administrator to list all reports for the organization.
   *
   * @return detailsList List of all reports
   */
  public ReportDetailsList listAllReports() throws AppException,
      InformationalException {
    // Return object
    ReportDetailsList reportDetailsList = new ReportDetailsList();

    // Get the list of reports
    reportDetailsList.list = ReportFactory.newInstance().list();

    return reportDetailsList;
  }

  /**
   * Method to allow an user to add a report in his favorite reports.
   *
   * @return dtls Details of the report and the user.
   */
  public void addReportForUser(ReportUserLinkDetails dtls) throws AppException,
      InformationalException {

    // Get instance of SystemUser and SystemUserDetails..
    curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Get the current user
    systemUserDtls = systemUserObj.getUserDetails();

    // Set user name key
    UserNameKey nameKey = new UserNameKey();

    nameKey.userName = systemUserDtls.userName;

    // Read Id details
    UserNameIDDetails idDetails = UserLinkFactory.newInstance().readUserByName(
      nameKey);

    // The new details record struct to be added
    curam.core.sl.struct.ReportUserLinkDetails details = new curam.core.sl.struct.ReportUserLinkDetails();

    // Variable to hold the tab delimited list of report IDs
    String tabList = new String();

    // Set the list
    tabList = dtls.reportList;

    // Convert the tab list to a list of strings
    StringList reportList = StringUtil.tabText2StringList(tabList);

    // For each report in the list create a new link record with
    // the security role
    details.dtls.userID = idDetails.userID;
    for (int i = 0; i < reportList.size(); i++) {
      // Set report user link details
      details.dtls.reportID = Long.parseLong(reportList.item(i));

      // Create the report user link record
      ReportUserLinkFactory.newInstance().create(details);
    }

  }

  /**
   * Method to allow an user to list all reports of his favorite reports.
   *
   * @return detailsList List of all reports
   */
  public ReportUserDetailsList listReportForUser(UserKey key)
    throws AppException, InformationalException {

    // Get instance of SystemUser and SystemUserDetails..
    curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Get the current user
    systemUserDtls = systemUserObj.getUserDetails();

    // Set user name key
    UserNameKey nameKey = new UserNameKey();

    nameKey.userName = systemUserDtls.userName;

    // Read Id details
    UserNameIDDetails idDetails = UserLinkFactory.newInstance().readUserByName(
      nameKey);

    // Return object
    ReportUserDetailsList reportUserDetailsList = new ReportUserDetailsList();

    // Get the list of reports for the user, using user ID
    key.userID = idDetails.userID;
    reportUserDetailsList.list = ReportUserLinkFactory.newInstance().listByUser(
      key);
    return reportUserDetailsList;
  }

  /**
   * Method to allow an user to list all reports that are available to his
   * favorite list.
   *
   * @return key The unique identifier of report record in the favorite list.
   */
  public ReportDetailsList listUnassociatedReportForUser(UserKey key)
    throws AppException, InformationalException {

    // Get instance of SystemUser and SystemUserDetails..
    curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Get the current user
    systemUserDtls = systemUserObj.getUserDetails();

    // Set user name key
    UserNameKey nameKey = new UserNameKey();

    nameKey.userName = systemUserDtls.userName;

    // Read Id details
    UserNameIDDetails idDetails = UserLinkFactory.newInstance().readUserByName(
      nameKey);

    // Return object
    ReportDetailsList reportDetailsList = new ReportDetailsList();

    // Get the list of reports for the user
    key.userID = idDetails.userID;
    reportDetailsList.list = ReportUserLinkFactory.newInstance().listUnassociated(
      key);
    return reportDetailsList;
  }

  /**
   * This method removes an report from a user's favorite list of reports.
   *
   * @param key
   * The identifier of the record to be removed.
   */
  public void removeReportForUser(ReportUserLinkKey key) throws AppException,
      InformationalException {
    // Remove the report from the user's favorite list
    ReportUserLinkFactory.newInstance().remove(key);
  }

  /**
   * This method allow an user to run a real reports that are available in his
   * favorite list.
   *
   * @param key
   * The identifier for a report record in user's favorite to be run.
   */
  public ReportDetails runReportForUser(ReportUserLinkKey key)
    throws AppException, InformationalException {
    // Return object TODO remove this
    ReportDetails reportDetails = new ReportDetails();

    return reportDetails;
  }

  /**
   * Method to allow an administrator to add a report for a security role in the
   * organization.
   *
   * @return dtls Details of the report and security role record.
   */
  public void addReportToSecurityRole(ReportSecurityRoleLinkDetails dtls)
    throws AppException, InformationalException {

    // The new details record struct to be added
    curam.core.sl.struct.ReportSecurityRoleLinkDetails details = new curam.core.sl.struct.ReportSecurityRoleLinkDetails();

    // Variable to hold the tab delimited list of report IDs
    String tabList = new String();

    // Set the list
    tabList = dtls.reportList;

    // Convert the tab list to a list of strings
    StringList reportList = StringUtil.tabText2StringList(tabList);

    // For each report in the list create a new link record with
    // the security role
    details.dtls.roleName = dtls.dtls.dtls.roleName;
    for (int i = 0; i < reportList.size(); i++) {
      // Set report security role link details
      details.dtls.reportID = Long.parseLong(reportList.item(i));

      // Create the report security role link record
      ReportSecurityRoleLinkFactory.newInstance().create(details);
    }
  }

  /**
   * Method to allow an administrator to list all reports for a security role in
   * the organization.
   *
   * @return key The unique identifier of the security role.
   */
  public ReportSecurityRoleDetailsList listReportForSecurityRole(RoleNameKey key)
    throws AppException, InformationalException {
    // Return object
    ReportSecurityRoleDetailsList reportSecurityRoleDetailsList = new ReportSecurityRoleDetailsList();

    // Get the list of reports for the security role
    reportSecurityRoleDetailsList.list = ReportSecurityRoleLinkFactory.newInstance().list(
      key);

    return reportSecurityRoleDetailsList;
  }

  /**
   * Method to allow an administrator to list all reports that are unassociated
   * with a particular security role in the organization.
   *
   * @return key The unique identifier of the security role.
   */
  public ReportDetailsList listUnassociatedReportForSecurityRole(RoleNameKey key)
    throws AppException, InformationalException {
    // Return object
    ReportDetailsList reportDetailsList = new ReportDetailsList();

    // Get the list of reports for the security role
    reportDetailsList.list = ReportSecurityRoleLinkFactory.newInstance().listUnassociated(
      key);
    return reportDetailsList;
  }

  /**
   * This method removes an association between a report and a security role.
   *
   * @param key
   * The identifier of the record to be removed.
   */
  public void removeReportFromSecurityRole(ReportSecurityRoleLinkKey key)
    throws AppException, InformationalException {
    // Remove the report from the security role
    ReportSecurityRoleLinkFactory.newInstance().remove(key);
  }

  // END, CR00129355, JC

  // BEGIN, CR00168663, LD
  
  /**
   * Gets Organization ID
   * @return Organization ID
   */
  // BEGIN, CR00198672, VK
  protected long getOrganizationID() throws AppException, InformationalException {
    // END, CR00198672
    // Object to read organization details
    curam.core.intf.Organisation organizationObj = curam.core.fact.OrganisationFactory.newInstance();
    // Read organization details
    curam.core.struct.OrganisationDtls organizationDtlsObj = organizationObj.readOne();

    return organizationDtlsObj.organisationID;
  }

  // END, CR00168663


  // BEGIN, CR00167930, ZV
  
  /**
   * This method replaces the deprecated method
   * {@link #listRecentAssignedCasesForUser()}
   * Lists recently assigned integrated and product delivery cases currently
   * owned by current user or current user organization object.
   *
   * @return Recently assigned case details list.
   */
  public RecentlyAssignedCaseDetailsList listRecentAssignedCasesForUserCurrentlyOwned()
    throws AppException, InformationalException {

    RecentlyAssignedCaseDetailsList recentlyAssignedCaseDetailsList = new RecentlyAssignedCaseDetailsList();

    recentlyAssignedCaseDetailsList.dtls = UserRecentActionFactory.newInstance().listAssignedCaseCurrentlyOwned();

    return recentlyAssignedCaseDetailsList;

  }

  /**
   * This method replaces the deprecated method
   * {@link #listRecentViewedCasesForUser()}
   * Lists integrated and product delivery cases recently viewed by user.
   *
   * @return Recently viewed case details list.
   */
  public RecentlyViewedCaseDetailsList listRecentViewedCasesForUser1()
    throws AppException, InformationalException {

    RecentlyViewedCaseDetailsList recentlyViewedCaseDetailsList = new RecentlyViewedCaseDetailsList();

    recentlyViewedCaseDetailsList.dtls = UserRecentActionFactory.newInstance().listViewedCase1();

    return recentlyViewedCaseDetailsList;

  }

  /**
   * This method replaces the deprecated method
   * {@link #listRecentApprovedCasesForUser()}
   * Lists recently approved integrated and product delivery cases submitted
   * by current user or currently owned by current user or current user
   * organization object.
   *
   * @return Recently approved case details list.
   */
  public RecentlyApprovedCaseDetailsList listRecentApprovedCasesForUserSubmittedOrOwned()
    throws AppException, InformationalException {

    RecentlyApprovedCaseDetailsList recentlyApprovedCaseDetailsList = new RecentlyApprovedCaseDetailsList();

    recentlyApprovedCaseDetailsList.dtls = UserRecentActionFactory.newInstance().listApprovedCaseSubmittedOrOwned();

    return recentlyApprovedCaseDetailsList;

  }

  // END, CR00167930

  // BEGIN, CR00173421, ZV
  
  /**
   * This method replaces the deprecated method
   * {@link #createAdminIntegratedCase()}
   *
   * Creates an Admin Integrated Case. Method contains additional attributes
   * to indicate if cases of this integrated case type are displayed in the
   * participants programs list, in My Cases filter and in Case Search filter.
   *
   * @param details
   * Details to create the Admin Integrated Case.
   */

  public void createAdminIntegratedCase1(
    CreateAdminIntegratedCaseDetails1 details) throws AppException,
      InformationalException {

    MaintainAdminIntegratedCaseDetails1 maintainAdminIntegratedCaseDetails = new MaintainAdminIntegratedCaseDetails1();

    // Assign details to create the Admin Integrated Case
    maintainAdminIntegratedCaseDetails.assign(details);

    // Create the Admin Integrated Case

    MaintainAdminIntegratedCaseFactory.newInstance().createAdminIntegratedCase1(
      maintainAdminIntegratedCaseDetails);
  }

  /**
   * This method replaces the deprecated method
   * {@link #modifyAdminIntegratedCase()}
   *
   * Modifies an Admin Integrated Case. Method contains additional attributes to
   * indicate if cases of this integrated case type are displayed in the
   * participants programs list, in My Cases filter and in Case Search filter.
   *
   * @param details
   * Details to modify the Admin Integrated Case.
   */
  public void modifyAdminIntegratedCase1(
    ModifyAdminIntegratedCaseDetails1 details) throws AppException,
      InformationalException {

    // Modify the Admin Integrated Case
    MaintainAdminIntegratedCaseFactory.newInstance().modifyAdminIntegratedCase1(
      details.details);
  }

  /**
   * This method replaces the deprecated method
   * {@link #readAdminIntegratedCase()}
   * Reads details of Admin Integrated Case. Method reads additional  attributes
   * which indicates if cases of this integrated case type are displayed in the
   * participants programs list, in My Cases filter and in Case Search filter.
   *
   * @param key
   * Key to read details of an Admin Integrated Case.
   *
   * @return Details of the Admin Integrated Case.
   */
  public ReadAdminIntegratedCaseDetails1 readAdminIntegratedCase1(
    ReadAdminIntegratedCaseKey_fo key) throws AppException,
      InformationalException {

    // Create return object
    ReadAdminIntegratedCaseDetails1 readAdminIntegratedCaseDetails = new ReadAdminIntegratedCaseDetails1();

    MaintainAdminIntegratedCaseKey maintainAdminIntegratedCaseKey = new MaintainAdminIntegratedCaseKey();

    // Set key to read Admin Integrated Case details
    maintainAdminIntegratedCaseKey.adminIntegratedCaseID = key.adminIntegratedCaseID;

    // Read Admin Integrated Case details and assign to return object
    readAdminIntegratedCaseDetails.maintainAdminIntegratedCaseDetails.assign(
      MaintainAdminIntegratedCaseFactory.newInstance().readAdminIntegratedCase1(
        maintainAdminIntegratedCaseKey));
    // BEGIN, CR00235514, PB
    if (!readAdminIntegratedCaseDetails.maintainAdminIntegratedCaseDetails.adminTranslationRequiredInd) {
      readAdminIntegratedCaseDetails.maintainAdminIntegratedCaseDetails.adminTranslationRequiredInd = false;
    }
    // END, CR00235514
    return readAdminIntegratedCaseDetails;
  }

  /**
   * Returns default details to create new administration integrated case.
   *
   * @return Default administration integrated case details.
   */
  public IntegratedCaseDefaultValuesDetails getIntegratedCaseDefaultValues()
    throws AppException, InformationalException {

    IntegratedCaseDefaultValuesDetails integratedCaseDefaultValuesDetails = new IntegratedCaseDefaultValuesDetails();

    integratedCaseDefaultValuesDetails.myCasesFilterInd = true;
    integratedCaseDefaultValuesDetails.caseSearchFilterInd = true;

    return integratedCaseDefaultValuesDetails;
  }

  // END, CR00173421
  // BEGIN, CR00130063, DJ
  // BEGIN, CR00282028,IBM
  /**
   * Presentation layer operation to search for active users within
   * the organization.
   *
   * @param userSearchKey user to be read
   * @return details of the active users
   *
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0 SP2, replaced with {@link
   * Organization#searchActiveUserDetails(UserSearchKey)}.
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by searchActiveUserDetails(UserSearchKey) which returns
   * the informational message along with user details as well.
   * See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public UserSearchDetailsResults activeUserDetailsSearch(UserSearchKey key)
    throws AppException, InformationalException {
    // END, CR00282028
    // Details to be returned
    UserSearchDetailsResults userSearchDetailsResults = new UserSearchDetailsResults();

    // Set the status code to active so only active user are found
    key.userSearchCriteria.criteria.statusCode = RECORDSTATUS.NORMAL;

    // Search for users
    userSearchDetailsResults.dtls = AdminUserFactory.newInstance().searchUserDetails(
      key.userSearchCriteria);

    // Return user details
    return userSearchDetailsResults;
  }

  // BEGIN, CR00282028,IBM
  /**
   * Presentation layer operation to search for a user within the organization.
   *
   * @param key user to be read
   * @return details of the user
   *
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Organization#searchUserDetails(UserSearchKey)}.
   *
   * This method is being deprecated because it is not returning any
   * informational messages. So this replaced by new method
   * searchUserDetails(UserSearchKey key) which returns the
   * informational message as well . See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public UserSearchDetailsResults userDetailsSearch(UserSearchKey key)
    throws AppException, InformationalException {
    // END, CR00282028
    // details to be returned
    UserSearchDetailsResults userSearchDetailsResults = new UserSearchDetailsResults();

    // search for users
    userSearchDetailsResults.dtls = AdminUserFactory.newInstance().searchUserDetails(
      key.userSearchCriteria);

    // Return user details
    return userSearchDetailsResults;
  }

  // END, CR00130063

  // BEGIN, CR00188505, ZV
  
  /**
   * Method to return organization unit location details. The name of the
   * location which has been assigned to a Position within the Organization Unit
   * or one of its sub units along with position name and location status.
   *
   * @param key
   * organization unit identifier
   *
   * @return list of details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ListLocationForOrganisationUnit listOrganisationUnitLocation(
    OrgStructureAndOrgUnitKey key)
    throws AppException, InformationalException {

    ListLocationForOrganisationUnit listLocationForOrganisationUnit = new ListLocationForOrganisationUnit();

    listLocationForOrganisationUnit.locationList = getOrganisationUnitLocationDetails(
      key);

    return listLocationForOrganisationUnit;
  }

  // END, CR00188505

  // BEGIN, CR00190252, NP
  
  /**
   * Validate User Name
   *
   * @param details User details
   *
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected void validateUserName(UsersDtls details) throws InformationalException {
    // END, CR00198672
    // Create an informational manager
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (details.userName.toUpperCase().length() > CuramConst.kUpperUSERNAME) {

      // create the warning string
      curam.util.exception.LocalisableString infoMessage = new curam.util.exception.LocalisableString(
        curam.message.BPOADMINUSER.ERR_USER_FV_UPPERUSER_NAME_EXCEEDED_LIMIT);

      infoMessage.arg(
        details.userName.toUpperCase().length() - CuramConst.kUpperUSERNAME);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, curam.util.resources.GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // Validate the Person Name Details
    if (details.firstname.toUpperCase().length() > CuramConst.kUpperFIRSTNAME) {

      // create the warning string
      curam.util.exception.LocalisableString infoMessage = new curam.util.exception.LocalisableString(
        curam.message.BPOMAINTAINPERSONNAMES.ERR_FV_UPPERFIRST_NAME_EXCEEDED_LIMIT);

      infoMessage.arg(
        details.firstname.toUpperCase().length() - CuramConst.kUpperFIRSTNAME);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, curam.util.resources.GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    if (details.surname.toUpperCase().length() > CuramConst.kUpperSURNAME) {

      // create the warning string
      curam.util.exception.LocalisableString infoMessage = new curam.util.exception.LocalisableString(
        curam.message.BPOMAINTAINPERSONNAMES.ERR_FV_UPPERLAST_NAME_EXCEEDED_LIMIT);

      infoMessage.arg(
        details.surname.toUpperCase().length() - CuramConst.kUpperSURNAME);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, curam.util.resources.GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    informationalManager.failOperation();
  }

  // END, CR00190252

  /**
   * This method lists the evidence type details for for the specified admin
   * integrated case, both classic evidence and dynamic evidence types.
   *
   * @param key
   * The unique identifier for the type of case.
   *
   * @return The list of evidence type details.
   */
  public ICEvidenceTypeDetailsList listAllEvidenceTypesByAdminIntegratedCaseID(
    AdminIntegratedCaseKey key) throws  AppException, InformationalException {

    // BEGIN DEC
    curam.evidence.impl.EvidenceType evidenceTypeObj = EvidenceTypeFactory.newInstance();

    // BEGIN, CR00220422, PF
    EvidenceTypeAdminDetailsList types = evidenceTypeObj.listNonParticipantEvidenceTypes(
      key);

    ICEvidenceTypeDetailsList icEvidenceTypeDetailsList = new ICEvidenceTypeDetailsList();

    for (int i = 0; i < types.dtls.size(); i++) {
      String evidenceType = types.dtls.get(i).evidenceType;
      curam.core.sl.infrastructure.entity.struct.ICEvidenceTypeDetails curDtls = new curam.core.sl.infrastructure.entity.struct.ICEvidenceTypeDetails();

      curDtls.evidenceType = evidenceType;
      icEvidenceTypeDetailsList.list.list.dtls.add(curDtls);
    }
    // END, CR00220422

    return icEvidenceTypeDetailsList;
    // END DEC
  }

  // BEGIN, CR00203865, ZV
  
  /**
   * Lists recently approved investigations submitted by current user or
   * currently owned by current user or current user organization object.
   *
   * @return Recently approved investigation details list.
   */
  public RecentlyApprovedInvestigationDetailsList listRecentApprovedInvestigationForUserSubmittedOrOwned()
    throws AppException, InformationalException {

    RecentlyApprovedInvestigationDetailsList recentlyApprovedInvestigationDetailsList = new RecentlyApprovedInvestigationDetailsList();

    recentlyApprovedInvestigationDetailsList.dtls = UserRecentActionFactory.newInstance().listApprovedInvestigationSubmittedOrOwned();

    return recentlyApprovedInvestigationDetailsList;
  }

  /**
   * Lists recently assigned investigations currently owned by current user or
   * current user organization object.
   *
   * @return Recently assigned investigation details list.
   */
  public RecentlyAssignedInvestigationDetailsList listRecentAssignedInvestigationForUserCurrentlyOwned()
    throws AppException, InformationalException {

    RecentlyAssignedInvestigationDetailsList recentlyAssignedInvestigationDetailsList = new RecentlyAssignedInvestigationDetailsList();

    recentlyAssignedInvestigationDetailsList.dtls = UserRecentActionFactory.newInstance().listAssignedInvestigationCurrentlyOwned();

    return recentlyAssignedInvestigationDetailsList;
  }

  /**
   * Lists investigations recently viewed by user.
   *
   * @return Recently viewed investigation details list.
   */
  public RecentlyViewedInvestigationDetailsList listRecentViewedInvestigationForUser()
    throws AppException, InformationalException {

    RecentlyViewedInvestigationDetailsList recentlyViewedInvestigationDetailsList = new RecentlyViewedInvestigationDetailsList();

    recentlyViewedInvestigationDetailsList.dtls = UserRecentActionFactory.newInstance().listViewedInvestigation();

    return recentlyViewedInvestigationDetailsList;

  }

  // END, CR00203865

  // BEGIN, CR00266809, ZV
  // BEGIN, CR00203865, ZV
  
  /**
   * Performs search across all defined Application Objects e.g. Cases,
   * Participants etc
   * @param key reference number
   *
   * @return Found application object details list.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #searchApplicationReference()}
   */
  @Deprecated
  public ApplicationSearchDetailsList searchApplication(
    ApplicationSearchKey key)
    throws AppException, InformationalException {

    ApplicationSearchDetailsList applicationSearchDetailsList = new ApplicationSearchDetailsList();

    // Register Informational Manager
    TransactionInfo.setInformationalManager();

    applicationSearchDetailsList.list = ApplicationSearchFactory.newInstance().search(
      key);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; ++i) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      applicationSearchDetailsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return applicationSearchDetailsList;
  }

  // END, CR00203865
  // END, CR00266809

  // BEGIN, CR00266809, ZV
  // BEGIN, CR00217547, ZV
  
  /**
   * Counts number of records by reference across all defined Application
   * Objects e.g. Cases, Participants etc.
   *
   * @param key reference number
   *
   * @return Record count.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #countApplicationReferenceRecord()}
   */
  @Deprecated
  public RecordCount countApplicationSearchRecord(ApplicationSearchKey key)
    throws AppException, InformationalException {
    return ApplicationSearchFactory.newInstance().count(key);
  }

  // END, CR00266809

  
  /**
   * Performs a single record read by reference across all defined Application
   * Objects e.g. Cases, Participants etc
   *
   * @param key
   * reference number
   *
   * @return Found application object details.
   */
  public ApplicationSearchDetails readApplicationSearchRecord(
    ApplicationSearchKey key) throws AppException, InformationalException {

    ApplicationSearchDetails applicationSearchDetails = new ApplicationSearchDetails();

    applicationSearchDetails.dtls = ApplicationSearchFactory.newInstance().read(
      key);

    return applicationSearchDetails;
  }

  // END, CR00217547
  
  // BEGIN, CR00216807 MN
  /**
   * Presentation layer operation to close a User and
   * also members other than Users.
   *
   * @param closeUserDetails
   * Details of the user to be closed
   *
   * @return InformationalMsgDtlsList List of informational messages
   */
  public InformationalMsgDtlsList closeOrganizationUser(
    CloseOrganizationUserDetails details) throws AppException,
      InformationalException {
    // Return variable to hold the details.
    InformationalMsgDtlsList informationalMsgDtlsList = new InformationalMsgDtlsList();

    // Register Informational Manager
    TransactionInfo.setInformationalManager();

    // Service Layer Call to Close the User
    AdminUserFactory.newInstance().closeOrganizationUser(details);

    // Informational Manager handle
    curam.util.exception.InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; ++i) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
    return informationalMsgDtlsList;
  }

  /**
   * Retrieve the homepage details for a user.
   *
   * @param key
   * Identifier for a user
   *
   * @return Homepage details for a user
   */
  public ReadOrganizationUserHomePageDetails readOrganizationUserHomePage(
    ReadUserHomePageKey key) throws AppException, InformationalException {
    // Details to be returned
    ReadOrganizationUserHomePageDetails readUserHomePageDetails = new ReadOrganizationUserHomePageDetails();

    // set the informational manager for the transaction
    TransactionInfo.setInformationalManager();

    // BEGIN, CR00226671 MN
    // Read the users homepage details
    UserRedirectionDetails userDetails;

    userDetails = UserAccessFactory.newInstance().readInternalUserWithRedirectionDetails(
      key.userKeyStruct);
   
    // END, CR00226671
    readUserHomePageDetails.organizationUserDetails.alternateLoginEnabled = Boolean.valueOf(
      Configuration.getProperty(EnvironmentConstants.Security.kAltLoginEnabled));
    
    if (readUserHomePageDetails.organizationUserDetails.alternateLoginEnabled) {
      curam.util.administration.intf.SecurityAdmin securityAdminObj = curam.util.administration.fact.SecurityAdminFactory.newInstance();    
      ExtendedUsersInfoUserName extendedUsersInfoUserName = new ExtendedUsersInfoUserName();
      ExtendedUsersInfoLoginID extendedUsersInfoLoginID = new ExtendedUsersInfoLoginID();

      extendedUsersInfoUserName.userName = key.userKeyStruct.userName;
        
      extendedUsersInfoLoginID = securityAdminObj.readLoginID(
        extendedUsersInfoUserName);    
      readUserHomePageDetails.alternateLoginID.loginId = extendedUsersInfoLoginID.loginID;
    }
    
    readUserHomePageDetails.organizationUserDetails.assign(userDetails);

    readUserHomePageDetails.organizationUserDetails.oldPassword = CuramConst.gkRestricted;

    readUserHomePageDetails.organizationUserDetails.passwordExpiresOn = userDetails.passwordExpiresOn;

    // Read the users context description
    OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    organizationUserContextDescriptionKey.userName = key.userKeyStruct.userName;
    readUserHomePageDetails.userContextDescriptionDetails = readUserContextDescription(
      organizationUserContextDescriptionKey);

    // Informational Manager handle
    curam.util.exception.InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; ++i) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      readUserHomePageDetails.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // Return details
    return readUserHomePageDetails;
  }

  /**
   * Returns a list of the task redirection records for a specified user or a
   * member other than user. Two lists of data are returned. The first contains
   * the details of the all the active and pending task redirection records
   * for the specified user. The second list contains a list of all the
   * expired task redirection history records for the specified user.
   *
   * @param key
   * The ID of the user.
   *
   * @return a list of all task redirection records for the specified user.
   */
  public TaskRedirectionsFromUserDetails getTaskRedirectionHistoryForUser(
    UserNameKey key) throws AppException, InformationalException {

    UserNameAndDateTimeKey userNameAndDateTimeKey = new UserNameAndDateTimeKey();

    // Assign the key values
    userNameAndDateTimeKey.userName = key.userName;

    userNameAndDateTimeKey.currentDateTime = new DateTime(
      DateTime.getCurrentDateTime());
    if (key.userName.length() == 0) {
      userNameAndDateTimeKey.userName = TransactionInfo.getProgramUser();
    }
    TaskRedirectionsFromUserDetails redirectionsFromUserDetails = UserWorkspaceFactory.newInstance().getTaskRedirectionHistoryForUser(
      userNameAndDateTimeKey);

    return redirectionsFromUserDetails;
  }

  /**
   * Builds the selected path string for the newly created organization unit.
   * @param details organization unit details
   *
   * @return String the selected path.
   */
  protected String setSelectedPathForOrgUnit(OrganisationUnitDetails details) {
    final String orgId = String.valueOf(
      details.orgUnitDetails.organisationStructureID);
    String result = "orgStructure" + orgId + "/";
    final long unitID = details.orgUnitDetails.organisationUnitDtls.organisationUnitID;
    final long parentID = details.orgUnitDetails.parentOrganisationUnitID;

    if (details.orgUnitDetails.parentOrganisationUnitID != -1) {
      result += "/orgUnits" + String.valueOf(parentID);
    }
    result += "/orgUnit" + String.valueOf(unitID);
    return result;
  }

  /**
   * Builds the selected path string for the newly created position.
   * @param details new position details.
   *
   * @return String the selected path.
   */
  protected String setSelectedPathForPosition(CreatePositionDetails details) {
    final String orgId = String.valueOf(
      details.positionDetails.positionOrgDetails.organisationStructureID);
    String result = "orgStructure" + orgId;
    long orgUnitID = details.positionDetails.positionOrgDetails.organisationUnitID;
    long posId = details.positionDetails.positionOrgDetails.positionDtls.positionID;

    result += "//orgUnit" + String.valueOf(orgUnitID) + "/positions"
      + String.valueOf(orgUnitID) + "/position" + String.valueOf(orgUnitID)
      + "." + String.valueOf(posId);
    return result;
  }

  /**
   * Builds the selected path string for the newly created user.
   * @param details new user details.
   *
   * @return String the selected path.
   */
  protected String setUserSelectionPath(CreateAndAssignUserForPosition details) {
    final String orgId = String.valueOf(
      details.assignDetails.positionHolderLinkDetails.positionHolderLinkDtls.organisationStructureID);
    String result = "orgStructure" + orgId;
    long unitID = details.assignDetails.organisationID;
    final String posId = String.valueOf(
      details.assignDetails.positionHolderLinkDetails.positionHolderLinkDtls.positionID);

    result += "//orgUnit" + String.valueOf(unitID) + "/positions"
      + String.valueOf(unitID) + "/position" + String.valueOf(unitID) + "."
      + posId + "/user" + String.valueOf(unitID) + "." + posId + "."
      + details.assignDetails.positionHolderLinkDetails.positionHolderLinkDtls.userName;
    return result;
  }

  // BEGIN, CR00221953, BD
  /**
   * Build the XML required by the Announcements Renderer.
   *
   * The XML contains the list of announcements currently active, but also
   * contains information read from the configuration properties on how the
   * announcement player will display, such as the speed of the player and the
   * format of the date/time field.
   *
   * @return String in XML format containing all current Announcements.
   */
  public AnnouncementsXML getAnnouncementsAsXML() throws AppException,
      InformationalException {

    AnnouncementsXML announcementsXML = new AnnouncementsXML();

    RecordStatusAndDateTime recordStatusAndDateTime = new RecordStatusAndDateTime();

    recordStatusAndDateTime.recordStatus = RECORDSTATUS.NORMAL;
    recordStatusAndDateTime.dateTime = DateTime.getCurrentDateTime();

    // Get the list of announcements
    AnnouncementDetailsList announcements = curam.core.sl.entity.fact.AnnouncementFactory.newInstance().searchCurrentAnnouncements(
      recordStatusAndDateTime);

    AnnouncementsBuilder announcementBuilder = AnnouncementsBuilder.newAnnouncements();

    String dateFormat = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_ANNOUNCEMENTS_DATE_FORMAT);

    if (dateFormat == null) {
      dateFormat = EnvVars.ENV_ANNOUNCEMENTS_DATE_FORMAT_DEFAULT;
    }
    String timeFormat = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_ANNOUNCEMENTS_TIME_FORMAT);

    if (timeFormat == null) {
      timeFormat = EnvVars.ENV_ANNOUNCEMENTS_TIME_FORMAT_DEFAULT;
    }
    for (int i = 0; i < announcements.dtls.size(); i++) {
      AnnouncementDetails announcementDetails = announcements.dtls.item(i);

      String startDate = Locale.getFormattedDateTime(
        announcementDetails.startDateTime, dateFormat);
      String startTime = Locale.getFormattedDateTime(
        announcementDetails.startDateTime, timeFormat);

      // BEGIN, CR00242912, BD
      // Strip the text of any additional white space, including line returns.
      String text = announcementDetails.announcementText.trim();
      String id = new Long(announcementDetails.announcementID).toString();

      announcementBuilder.addAnnouncement(id, text, startDate, startTime);
      // END, CR00242912, BD
    }

    Integer timeIn = curam.util.resources.Configuration.getIntProperty(
      EnvVars.ENV_ANNOUNCEMENTS_TIME_IN);

    if (timeIn == null) {
      timeIn = EnvVars.ENV_ANNOUNCEMENTS_TIME_IN_DEFAULT;
    }
    Integer timeDisplayed = curam.util.resources.Configuration.getIntProperty(
      EnvVars.ENV_ANNOUNCEMENTS_TIME_DISPLAYED);

    if (timeDisplayed == null) {
      timeDisplayed = EnvVars.ENV_ANNOUNCEMENTS_TIME_DISPLAYED_DEFAULT;
    }
    Integer timeOut = curam.util.resources.Configuration.getIntProperty(
      EnvVars.ENV_ANNOUNCEMENTS_TIME_OUT);

    if (timeOut == null) {
      timeOut = EnvVars.ENV_ANNOUNCEMENTS_TIME_OUT_DEFAULT;
    }
    String popupPageID = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_ANNOUNCEMENTS_POPUP_PAGE_ID);

    if (popupPageID == null) {
      popupPageID = EnvVars.ENV_ANNOUNCEMENTS_POPUP_PAGE_ID_DEFAULT;
    }
    announcementBuilder.setTimeIn(timeIn);
    announcementBuilder.setTimeDisplayed(timeDisplayed);
    announcementBuilder.setTimeOut(timeOut);
    announcementBuilder.setDisplayMessageUIM(popupPageID);
    announcementsXML.contentXML = announcementBuilder.toString();

    return announcementsXML;

  }

  // END, CR00221953

  // BEGIN, CR00225492 MN
  /**
   * Creates a task redirection record for the specified user. This record
   * specifies another user to whom tasks for the specified user will be
   * redirected to. A start and end date time is also specified for each task
   * redirection record and this allows the creation of task redirections for
   * future dates also allows tasks to be redirected to targets other
   * than just users.
   *
   * @param key
   * The task redirection details.
   */
  public void taskRedirectionsForUserDetails(TaskRedirectionsForUserDetails key)
    throws AppException, InformationalException {

    // Validation method
    validateTaskRedirection(key);

    UserWorkspaceFactory.newInstance().taskRedirectionsForUser(key);

  }

  // END, CR00225492

  // BEGIN, CR00226138, GP
  /**
   * Assigns the text translation details.
   *
   * @param textTranslation
   * The text translation information.
   *
   * @return The text translation details.
   */
  protected TextTranslationDetails assignTextTranslationDtls(final
    TextTranslation textTranslation) {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    textTranslationDetails.dtls.localeCode = textTranslation.getLocale().getCode();
    textTranslationDetails.dtls.localizableTextID = textTranslation.getLocalizableTextID();
    textTranslationDetails.dtls.text = textTranslation.getText();
    textTranslationDetails.dtls.textTranslationID = textTranslation.getID();
    return textTranslationDetails;
  }

  /**
   * Provides text translation for the  attribute.
   *
   * @param LocalizableNameTextTranslationDetails
   * The localizable name text translation details.
   *
   * @return The view localizable text details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  protected ViewLocalizableTextDetails getTextTranslation(
    final LocalizableTextDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
      localizableTextTranslationDetails.dtls.localizableTextID);
    ViewLocalizableTextDetails viewLocalizableTextDetails = new
      ViewLocalizableTextDetails();

    viewLocalizableTextDetails.dtls.localizableTextID = localizableTextHandler.getID();

    for (TextTranslation textTranslation : localizableTextHandler.listTranslations()) {

      TextTranslationDetails textTranslationDetails = assignTextTranslationDtls(
        textTranslation);

      viewLocalizableTextDetails.translations.dtls.addRef(
        textTranslationDetails);

    }
    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the Organization attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Organization
   * description.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void addDescriptionTextTranslation(
    final LocalizableTextDetails localizableTranslationDetails)
    throws AppException, InformationalException {

    // Admin Organization object.
    AdminOrganisation adminOrganisationObj = AdminOrganisationFactory.newInstance();

    // Call service layer method.
    adminOrganisationObj.addDescriptionTextTranslation(
      localizableTranslationDetails.dtls);

  }

  /**
   * Modifies the text translation details for the Organization attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Organization
   * description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    // Admin Organization object.
    AdminOrganisation adminOrganisationObj = AdminOrganisationFactory.newInstance();

    // Call service layer method.
    adminOrganisationObj.modifyDescriptionTextTranslation(
      localizableTextDetails.dtls);

  }

  /**
   * Reads the text translation for the Organization attribute, description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the description.
   *
   * @return The Text translation details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TextTranslationDetails readDescriptionTextTranslation(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    TextTranslationDetails textTranslationDetails = new
      TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      // Read the Organization description.
      AdminOrganisation adminOrganisationObj = AdminOrganisationFactory.newInstance();
      ReadOrganizationHomePageDetails1 readOrganizationHomePageDetails = new ReadOrganizationHomePageDetails1();

      OrganisationKeyStruct organisationKeyStruct = new OrganisationKeyStruct();

      organisationKeyStruct.organisationID = localizableTextDetails.dtls.localizableTextParentID;
      readOrganizationHomePageDetails.organisationDetails = adminOrganisationObj.readOrganisation1(
        organisationKeyStruct);
      textTranslationDetails.dtls.text = readOrganizationHomePageDetails.organisationDetails.description;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the Organization attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the description.
   *
   * @return The view text translation details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewLocalizableTextDetails listLocalizableDescriptionText(
    final LocalizableTextDetails localizableTextDetails) throws
      AppException, InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new
      ViewLocalizableTextDetails();
    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();
    AdminOrganisation adminOrganisationObj = AdminOrganisationFactory.newInstance();
    ReadOrganizationHomePageDetails1 readOrganizationHomePageDetails = new ReadOrganizationHomePageDetails1();

    OrganisationKeyStruct organisationKeyStruct = new OrganisationKeyStruct();

    organisationKeyStruct.organisationID = localizableTextDetails.dtls.localizableTextParentID;
    readOrganizationHomePageDetails.organisationDetails = adminOrganisationObj.readOrganisation1(
      organisationKeyStruct);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } // BEGIN, CR00229110, GP
    else if (0
      != readOrganizationHomePageDetails.organisationDetails.descriptionTextID
      ) {

      LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = readOrganizationHomePageDetails.organisationDetails.descriptionTextID;

      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } // END, CR00229110
    else {

      // Handle legacy data.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = readOrganizationHomePageDetails.organisationDetails.description;
      if (!textTranslationDetails.dtls.text.equals(CuramConst.gkEmpty)) {
        viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);
      }
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Creates a text translation for the Organization attribute, name.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Organization
   * name.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void addNameTextTranslation(
    final LocalizableTextDetails localizableTranslationDetails)
    throws AppException, InformationalException {

    // Admin Organization object.
    AdminOrganisation adminOrganisationObj = AdminOrganisationFactory.newInstance();

    // Call service layer method.
    adminOrganisationObj.addNameTextTranslation(
      localizableTranslationDetails.dtls);

  }

  /**
   * Modifies the text translation details for the Organization attribute,
   * name.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Organization name.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void modifyNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    // Admin Organization object.
    AdminOrganisation adminOrganisationObj = AdminOrganisationFactory.newInstance();

    // Call service layer method.
    adminOrganisationObj.modifyNameTextTranslation(localizableTextDetails.dtls);

  }

  /**
   * Reads the text translation for the Organization attribute, name.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the name.
   *
   * @return The Text translation details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public TextTranslationDetails readNameTextTranslation(
    final LocalizableTextDetails localizableTextDetails)
    throws AppException, InformationalException {

    TextTranslationDetails textTranslationDetails = new
      TextTranslationDetails();

    // Handle legacy data.
    if (0 == localizableTextDetails.dtls.localizableTextID
      && 0 == localizableTextDetails.dtls.textTranslationID) {

      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

      // Read the Organization description.
      AdminOrganisation adminOrganisationObj = AdminOrganisationFactory.newInstance();
      ReadOrganizationHomePageDetails1 readOrganizationHomePageDetails = new ReadOrganizationHomePageDetails1();

      OrganisationKeyStruct organisationKeyStruct = new OrganisationKeyStruct();

      organisationKeyStruct.organisationID = localizableTextDetails.dtls.localizableTextParentID;
      readOrganizationHomePageDetails.organisationDetails = adminOrganisationObj.readOrganisation1(
        organisationKeyStruct);
      textTranslationDetails.dtls.text = readOrganizationHomePageDetails.organisationDetails.name;
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();

    } else {

      TextTranslation textTranslation = textTranslationDAO.get(
        localizableTextDetails.dtls.textTranslationID);

      textTranslationDetails = assignTextTranslationDtls(textTranslation);
    }

    return textTranslationDetails;
  }

  /**
   * Lists the text translations for the Organization attribute, name.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details like locale code,
   * localizable text, etc. for the name.
   *
   * @return The view text translation details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewLocalizableTextDetails listLocalizableNameText(
    final LocalizableTextDetails localizableTextDetails) throws
      AppException, InformationalException {

    ViewLocalizableTextDetails viewLocalizableTextDetails = new
      ViewLocalizableTextDetails();
    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    AdminOrganisation adminOrganisationObj = AdminOrganisationFactory.newInstance();
    ReadOrganizationHomePageDetails1 readOrganizationHomePageDetails = new ReadOrganizationHomePageDetails1();

    OrganisationKeyStruct organisationKeyStruct = new OrganisationKeyStruct();

    organisationKeyStruct.organisationID = localizableTextDetails.dtls.localizableTextParentID;
    readOrganizationHomePageDetails.organisationDetails = adminOrganisationObj.readOrganisation1(
      organisationKeyStruct);

    // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    } // BEGIN, CR00229116, GP
    else if (0
      != readOrganizationHomePageDetails.organisationDetails.nameTextID
      ) {

      LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();

      localizableTextDtls.dtls.localizableTextID = readOrganizationHomePageDetails.organisationDetails.nameTextID;

      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);
    } // END, CR00229116
    else {

      // Handle legacy data.
      textTranslationDetails.dtls.localeCode = ProgramLocale.getDefaultServerLocale();
      textTranslationDetails.dtls.text = readOrganizationHomePageDetails.organisationDetails.name;
      viewLocalizableTextDetails.translations.dtls.addRef(
        textTranslationDetails);
    }

    return viewLocalizableTextDetails;
  }

  // END, CR00226138

  // BEGIN, CR00231961, ZV
  
  /**
   * Insert a new Bank Account for an Organization.
   *
   * @param details
   * Details of the bank account record to be created
   */
  public void createBankAccountWithTextSortCode(
    final MaintainBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    OrgBankAccountDetails orgBankAccountDetails = new OrgBankAccountDetails();

    orgBankAccountDetails.assign(details.maintainBankAccountDetails);
    orgBankAccountDetails.bankSortCode = details.bankSortCode;
    // BEGIN, CR00371769, VT
    orgBankAccountDetails.bicOpt = details.bicOpt;
    // END, CR00371769

    orgBankAccountDetails.organisationID = getOrganizationID();

    AdminOrganisationFactory.newInstance().InsertBankAccount(
      orgBankAccountDetails);
  }

  /**
   * Modify the details for a Bank Account.
   *
   * @param details
   * Details of the bank account to be modified
   */
  public void modifyBankAccountWithTextSortCode(
    final MaintainBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    OrgBankAccountDetails orgBankAccountDetails = new OrgBankAccountDetails();

    orgBankAccountDetails.assign(details.maintainBankAccountDetails);
    orgBankAccountDetails.bankSortCode = details.bankSortCode;
    // BEGIN, CR00371769, VT
    orgBankAccountDetails.bicOpt = details.bicOpt;
    // END, CR00371769

    AdminOrganisationFactory.newInstance().ModifyBankAccount(
      orgBankAccountDetails);
  }

  // END, CR00231961

  // BEGIN, CR00244797, ZV
  
  /**
   * Lists application codetable values.
   *
   * @return Application codetable list with enabled items.
   */
  public ApplicationCodeDetailsList listApplicationCode()
    throws AppException, InformationalException {
    return QuickLinkApplicationLinkFactory.newInstance().listApplicationCode();
  }

  // END, CR00244797

  // BEGIN, CR00250660, ZV
  
  /**
   * Method to view organization structure details.
   *
   * @param key
   * organization structure identifier
   *
   * @return organization structure details
   */
  public ViewOrganisationStructureDetails1 viewOrganisationStructure1(
    final OrganisationStructureKey organisationStructureKey)
    throws AppException, InformationalException {

    ViewOrganisationStructureDetails1 viewOrganisationStructureDetails = new ViewOrganisationStructureDetails1();

    viewOrganisationStructureDetails.organisationStructureDetails = curam.core.sl.fact.OrganisationStructureFactory.newInstance().viewOrganisationStructure1(
      organisationStructureKey.organisationStructureKey);

    return viewOrganisationStructureDetails;
  }

  /**
   * Method to list all organization structures for organization.
   *
   * @return list of all organization structures for organization
   */
  public ListOrganisationStructureDetails1 listOrganisationStructure1()
    throws AppException, InformationalException {

    curam.core.sl.struct.ListOrganisationStructureKey listOrganisationStructureKey = new curam.core.sl.struct.ListOrganisationStructureKey();

    ListOrganisationStructureDetails1 listOrganisationStructureDetails = new ListOrganisationStructureDetails1();

    // Assign details to key to read all organization structure details list
    listOrganisationStructureKey.allInd = true;

    listOrganisationStructureDetails.organisationStructureDetailsList = curam.core.sl.fact.OrganisationStructureFactory.newInstance().listOrganisationStructure1(
      listOrganisationStructureKey);

    return listOrganisationStructureDetails;
  }

  // END, CR00250660

  // BEGIN, CR00258082, MC
  // __________________________________________________________________________
  /**
   * Read the location structure ID using the location ID.
   *
   * @param LocationKey the location ID.
   *
   * @return LocationStructureKey the location structure ID.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public LocationStructureKey readLocationStructureIDForLocationID(
    LocationKeyStruct locationKey)
    throws AppException, InformationalException {

    return LocationFactory.newInstance().readLocationStructureIDByLocationID(
      locationKey);
  }

  // END, CR00258082

  // BEGIN, CR00266809, ZV
  
  /**
   * Validates search text and performs search across all defined Application
   * Objects e.g. Cases, Participants etc.
   *
   * @param key search text
   *
   * @return Found application object details list.
   */
  public ApplicationSearchDetailsList searchApplicationReference(
    curam.core.facade.struct.ApplicationSearchKey key)
    throws AppException, InformationalException {

    ApplicationSearchDetailsList applicationSearchDetailsList = new ApplicationSearchDetailsList();

    // Register Informational Manager
    TransactionInfo.setInformationalManager();

    ApplicationSearchKey applicationSearchKey = new ApplicationSearchKey();

    applicationSearchKey.assign(key);

    applicationSearchDetailsList.list = ApplicationSearchFactory.newInstance().search(
      applicationSearchKey);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; ++i) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      applicationSearchDetailsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return applicationSearchDetailsList;
  }

  /**
   * Counts number of records by reference across all defined Application
   * Objects e.g. Cases, Participants etc.
   *
   * @param key reference number
   *
   * @return Record count.
   */
  public RecordCount countApplicationReferenceRecord(
    curam.core.facade.struct.ApplicationSearchKey key)
    throws AppException, InformationalException {

    ApplicationSearchKey applicationSearchKey = new ApplicationSearchKey();

    applicationSearchKey.assign(key);

    return ApplicationSearchFactory.newInstance().count(applicationSearchKey);
  }

  // END, CR00266809

  // BEGIN, CR00281533, IBM
  /**
   * This method is intended to be used by users responsible for administrating
   * services. Always this method returns first record of location Id details,
   * when multiple records are fetched for given location holiday Id.
   *
   * @param locationHolidayIDKey location holiday Id
   * @return location Id.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public LocationIDDetails readLocationIDByLocationHolidayKey(
    final LocationHolidayIDKey locationHolidayIDKey) throws AppException,
      InformationalException {

    LocationIDDetailsList locationIDDetailsList = LocationHolidayLinkFactory.newInstance().readLocationsAttachedToHoliday(
      locationHolidayIDKey);

    LocationIDDetails locationIDDetails = new LocationIDDetails();

    if (!locationIDDetailsList.dtls.isEmpty()) {
      locationIDDetails = locationIDDetailsList.dtls.item(0);
    }

    return locationIDDetails;
  }

  // END, CR00281533

  // BEGIN, CR00282028, IBM
  /**
   * Search for an active user details by given search criteria.
   *
   * @param userSearchKey
   * contains user search key
   *
   * @return user details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public SearchUserDetails searchActiveUserDetails(
    final UserSearchKey userSearchKey) throws AppException,
      InformationalException {

    SearchUserDetails searchUserDetails = new SearchUserDetails();

    userSearchKey.userSearchCriteria.criteria.statusCode = RECORDSTATUS.NORMAL;

    searchUserDetails.dtls = AdminUserFactory.newInstance().searchUserDetails(
      userSearchKey.userSearchCriteria);

    collectInformationalMsgs(searchUserDetails.informationalMsgDtls);

    return searchUserDetails;
  }

  /**
   * Search for an user detail within the organization.
   *
   * @param userSearchKey
   * contains user search key
   *
   * @return user details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public SearchUserDetails searchUserDetails(final UserSearchKey userSearchKey)
    throws AppException, InformationalException {

    SearchUserDetails searchUserDetails = new SearchUserDetails();

    searchUserDetails.dtls = AdminUserFactory.newInstance().searchUserDetails(
      userSearchKey.userSearchCriteria);

    collectInformationalMsgs(searchUserDetails.informationalMsgDtls);

    return searchUserDetails;
  }

  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList msgDtlsList) {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] infos = informationalManager.obtainInformationalAsString();

    for (String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      msgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00282028
  
  
  // BEGIN, CR00322668, VT
  /**
   * Returns a list of skills for a user.
   *
   * @param userSkillListKey
   * Contains username.
   *
   * @return A list of user skills.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  
  public UserSkills getUserSkills(final UserSkillListKey userSkillListKey)
    throws AppException, InformationalException {

    final OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();
    
    final ListUserSkillKey listUserSkillKey = new ListUserSkillKey();
    final ListUserSkillDetails listUserSkillDetails = new ListUserSkillDetails();
    final UserSkills userSkills = new UserSkills();
 
    listUserSkillKey.userName = userSkillListKey.userSkillList.userName;

    listUserSkillDetails.listUserSkillDetails = UserSkillFactory.newInstance().list(
      listUserSkillKey);

    organizationUserContextDescriptionKey.userName = userSkillListKey.userSkillList.userName;

    listUserSkillDetails.description.description = readUserContextDescription(organizationUserContextDescriptionKey).description;

    for (final UserSkillDtls userSkillDtls : listUserSkillDetails.listUserSkillDetails.userSkillDtlsList.dtls.items()) {
      
      curam.core.sl.entity.struct.UserSkillDetails userSkillDetails = new curam.core.sl.entity.struct.UserSkillDetails();
      
      userSkillDetails.dtls.assign(userSkillDtls);
      
      if (SKILLTYPE.LANGUAGES.equals(userSkillDtls.skillType)
        && RECORDSTATUS.NORMAL.equals(userSkillDtls.recordStatus)) {
        userSkillDetails.languageListIndicator = true;
      }
      
      userSkills.listUserSkillDetails.userSkillDtlsList.add(userSkillDetails);
      
    }    
    return userSkills;
  }
  
  // END, CR00322668
  
  // BEGIN, CR00343008, VT
  /**
   * Lists all existing approval checks for a user.
   *
   * @param key
   * The unique id of the user that the resolution approval checks are
   * being listed for.
   * @return A list of resolution approval checks for the user.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListUserResolutionApprovalCheckDetailsAndVersionNo listResolutionApprovalCheckForUserAndVersionNo(
    final ListUserResolutionApprovalCheckKey key) throws AppException,
      InformationalException {

    final ListUserResolutionApprovalCheckDetailsAndVersionNo listUserResolutionApprovalCheckDetailsAndVersionNo = new ListUserResolutionApprovalCheckDetailsAndVersionNo();

    final OrganizationUserContextDescriptionKey organizationUserContextDescriptionKey = new OrganizationUserContextDescriptionKey();

    listUserResolutionApprovalCheckDetailsAndVersionNo.listUserResolutionApprovalCheckDetailsAndVersionNo = IssueResolutionApprovalCheckFactory.newInstance().listResolutionApprovalChecksForUserAndVersionNo(
      key.listUserResolutionApprovalCheckKey);

    organizationUserContextDescriptionKey.userName = key.listUserResolutionApprovalCheckKey.searchByUserKey.userName;

    listUserResolutionApprovalCheckDetailsAndVersionNo.listUserResolutionApprovalCheckContextDescription = readUserContextDescription(
      organizationUserContextDescriptionKey);

    return listUserResolutionApprovalCheckDetailsAndVersionNo;
  }

  // END, CR00343008

  // BEGIN, CR00343008, VT
  /**
   * Lists all existing approval checks for an organization unit.
   *
   * @param key
   * The unique id of the organization unit that the resolution
   * approval checks are being listed for.
   * @return A list of resolution approval checks for the organization unit.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListOrgUnitResolutionApprovalCheckDetailsAndVersionNo listResolutionApprovalCheckForOrgUnitAndVersionNo(
    final ListOrgUnitResolutionApprovalCheckKey key) throws AppException,
      InformationalException {

    final ListOrgUnitResolutionApprovalCheckDetailsAndVersionNo listOrgUnitResolutionApprovalCheckDetailsAndVersionNo = new ListOrgUnitResolutionApprovalCheckDetailsAndVersionNo();
    final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

    listOrgUnitResolutionApprovalCheckDetailsAndVersionNo.listOrgUnitResolutionApprovalCheckDetailsAndVersionNo = IssueResolutionApprovalCheckFactory.newInstance().listResolutionApprovalChecksForOrgUnitAndVersionNo(
      key.listOrgUnitResolutionApprovalCheckKey);

    organisationUnitKey.organisationUnitKey.organisationUnitKey.organisationUnitID = key.listOrgUnitResolutionApprovalCheckKey.searchByOrgUnitKey.organisationUnitID;
    listOrgUnitResolutionApprovalCheckDetailsAndVersionNo.listOrgUnitResolutionApprovalCheckContextDescriptionDetails = readOrganisationUnitContextDescription(
      organisationUnitKey);

    return listOrgUnitResolutionApprovalCheckDetailsAndVersionNo;
  }

  // END, CR00343008
  
  // BEGIN, CR00388421, MV
  /**
   * Method to find if the location search is enabled.
   *
   * @return result true if the location search is enabled else false.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public LocationSearchResolver isLocationSearchenabled()
    throws AppException, InformationalException {

    final LocationSearchResolver locationSearchResolver = new LocationSearchResolver();
    final String envLocationSearch = Configuration.getProperty(
      EnvVars.ENV_LOCATION_SEARCH_ENABLED);

    if (envLocationSearch.equalsIgnoreCase(CuramConst.gkYes)) {
      locationSearchResolver.isLocationSearchenabled = true;
    } else {
      locationSearchResolver.isLocationSearchenabled = false;
    }

    return locationSearchResolver;
  }

  /**
   * Method to find if the bank branch search is enabled.
   *
   * @return result true if the bank branch search is enabled else false.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public BankBranchSearchResolver isBankBranchSearchenabled()
    throws AppException, InformationalException {
    final BankBranchSearchResolver bankBranchSearchResolver = new BankBranchSearchResolver();
    final String envLocationSearch = Configuration.getProperty(
      EnvVars.ENV_BANKBRANCH_SEARCH_ENABLED);

    if (envLocationSearch.equalsIgnoreCase(CuramConst.gkYes)) {
      bankBranchSearchResolver.isBankBranchSearchenabled = true;
    } else {
      bankBranchSearchResolver.isBankBranchSearchenabled = false;
    }

    return bankBranchSearchResolver;

  }

  /**
   * Method to find if the position search is enabled.
   *
   * @return result true if the position search is enabled else false.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PositionSearchResolver isPositionSearchenabled()
    throws AppException, InformationalException {
    final PositionSearchResolver positionSearchResolver = new PositionSearchResolver();
    final String envLocationSearch = Configuration.getProperty(
      EnvVars.ENV_POSITION_SEARCH_ENABLED);

    if (envLocationSearch.equalsIgnoreCase(CuramConst.gkYes)) {
      positionSearchResolver.isPositionSearchenabled = true;
    } else {
      positionSearchResolver.isPositionSearchenabled = false;
    }

    return positionSearchResolver;
  }

  /**
   * Retrieves a list of locations for an organization with a given name or
   * type.
   *
   * @param locationByNameAndTypeKey
   * Contains location name and location type.
   *
   * @return A list of user skills.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReadOrganizationLocationList searchLocationsByLocationNameOrType(
    final LocationByNameAndTypeKey key,
    ActionIDProperty actionIDProperty) throws AppException,
      InformationalException {

    final ReadOrganizationLocationList readOrganizationLocationList = new ReadOrganizationLocationList();

    if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      return readOrganizationLocationList;
    }

    if (CuramConst.gkEmpty.equals(key.key.locationName)
      && CuramConst.gkEmpty.equals(key.key.locationType)) {
      throw (new AppException(
        BPOLOCATION.ERR_LOCATION_XFV_SPECIFY_SEARCH_CRITERIA));
    }

    readOrganizationLocationList.locationsList = DataBaseLocationSearchFactory.newInstance().searchLocationsByLocationNameOrType(
      key.key);

    if (CuramConst.gkZero
      == readOrganizationLocationList.locationsList.dtls.size()) {
      throw (new AppException(BPOLOCATION.INF_LOCATION_NO_MATCH_FOUND));
    }
    return readOrganizationLocationList;
  }

  /**
   * Retrieves a list of bank branch for an organization with a given search
   * criteria.
   *
   * @param searchBankBranchCriteria
   * search criteria to search the bank branch.
   *
   * @return A list of user skills.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ListBankBranchDetails searchBankBranch(
    final SearchBankBranchCriteria searchBankBranchCriteria,
    ActionIDProperty actionIDProperty) throws AppException,
      InformationalException {

    final ListBankBranchDetails listBankBranchDetails = new ListBankBranchDetails();

    if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      return listBankBranchDetails;
    }

    if (CuramConst.gkEmpty.equals(
      searchBankBranchCriteria.searchBankBranchCriteria.addressLine1)
        && CuramConst.gkEmpty.equals(
          searchBankBranchCriteria.searchBankBranchCriteria.addressLine2)
          && CuramConst.gkEmpty.equals(
            searchBankBranchCriteria.searchBankBranchCriteria.name)
            && CuramConst.gkEmpty.equals(
              searchBankBranchCriteria.searchBankBranchCriteria.bicOpt)
              && CuramConst.gkEmpty.equals(
                searchBankBranchCriteria.searchBankBranchCriteria.bankSortCode)) {
      throw (new AppException(
        BPOBANKBRANCH.ERR_BANKBRANCH_XFV_SPECIFY_SEARCH_CRITERIA));
    }

    listBankBranchDetails.bankBranchList = DatabaseBankbranchSearchFactory.newInstance().searchBankBranch(
      searchBankBranchCriteria.searchBankBranchCriteria);

    if (CuramConst.gkZero == listBankBranchDetails.bankBranchList.dtls.size()) {
      AppException e = new AppException(
        BPOBANKBRANCH.INF_BANKBRANCH_NO_MATCH_FOUND);

      throw (new AppException(BPOPOSITION.INF_POSITION_NO_MATCH_FOUND));
    }

    final BankKeyStruct bankKeyStruct = new BankKeyStruct();

    bankKeyStruct.bankID = searchBankBranchCriteria.searchBankBranchCriteria.bankID;

    listBankBranchDetails.listBankBranchBankDetails.bankName = AdminBankFactory.newInstance().readBank(bankKeyStruct).name;

    return listBankBranchDetails;
  }

  /**
   * Retrieves a list of position for an organization with a given search
   * criteria.
   *
   * @param positionSearchCriteria
   * search criteria to search the positions.
   *
   * @return A list of user skills.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ListPositionForOrgStructureDetails searchOrganizationPositions(
    PositionSearchCriteria positionSearchCriteria,
    ActionIDProperty actionIDProperty) throws AppException,
      InformationalException {

    final ListPositionForOrgStructureDetails listPositionForOrgStructureDetails = new ListPositionForOrgStructureDetails();

    if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      return listPositionForOrgStructureDetails;
    }
    if (CuramConst.gkEmpty.equals(
      positionSearchCriteria.positionSearchCriteriaKey.jobName)
        && !positionSearchCriteria.positionSearchCriteriaKey.leadPositionInd
        && CuramConst.gkEmpty.equals(
          positionSearchCriteria.positionSearchCriteriaKey.positionName)
          && CuramConst.gkEmpty.equals(
            positionSearchCriteria.positionSearchCriteriaKey.orgUnitName)) {
      throw (new AppException(
        BPOPOSITION.ERR_POSITION_XFV_SPECIFY_SEARCH_CRITERIA));
    }

    listPositionForOrgStructureDetails.positionList = DatabasePositionSearchFactory.newInstance().searchOrganizationPositions(
      positionSearchCriteria.positionSearchCriteriaKey);

    if (CuramConst.gkZero
      == listPositionForOrgStructureDetails.positionList.viewPositionUserOrgUnitDetailsList.dtls.size()) {

      throw (new AppException(BPOPOSITION.INF_POSITION_NO_MATCH_FOUND));
    }

    final OrganisationStructureKey organisationStructureKey = new OrganisationStructureKey();

    organisationStructureKey.organisationStructureKey.organisationStructureKey.organisationStructureID = positionSearchCriteria.positionSearchCriteriaKey.orgStructureID;
    listPositionForOrgStructureDetails.orgStructureContextDescription = readOrganisationStructureContextDescription(
      organisationStructureKey);
    final OrgStructureAndPositionKey orgStructureAndPositionKey = new OrgStructureAndPositionKey();

    for (ViewPositionUserOrgUnitDetails viewPositionUser : listPositionForOrgStructureDetails.positionList.viewPositionUserOrgUnitDetailsList.dtls.items()) {
      orgStructureAndPositionKey.orgStructureAndPositionKey.orgStructureAndPositionKey.positionID = viewPositionUser.positionID;
      orgStructureAndPositionKey.orgStructureAndPositionKey.orgStructureAndPositionKey.organisationStructureID = positionSearchCriteria.positionSearchCriteriaKey.orgStructureID;
      orgStructureAndPositionKey.orgStructureAndPositionKey.orgStructureAndPositionKey.organisationUnitID = viewPositionUser.organisationUnitID;
      final ViewPositionDetails viewPositionDetails = new ViewPositionDetails();

      viewPositionDetails.viewPositionDetails = PositionFactory.newInstance().viewPosition(
        orgStructureAndPositionKey.orgStructureAndPositionKey);

      if (0
        < viewPositionDetails.viewPositionDetails.viewPositionDetails.reportsToName.length()
          && viewPositionDetails.viewPositionDetails.viewPositionDetails.positionName
            == viewPositionUser.positionName) {
        viewPositionUser.reportsToIndOpt = true;
      } else {
        viewPositionUser.reportsToIndOpt = false;
      }
    }
    return listPositionForOrgStructureDetails;
  }

  // END, CR00388421
  // BEGIN, CR00409509, VT
  /**
   * Method to check whether the user is closed or not
   *
   * @param key
   * The ID of the user.
   *
   * @return CloseUserInd close user indicator
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  
  public CloseUserInd isUserClosed(final UserNameKey key)throws AppException, InformationalException {
    
    final CloseUserInd closeUserInd = new CloseUserInd();
    final UserKeyStruct userKeyStruct = new UserKeyStruct();
   
    userKeyStruct.userName = key.userName;
    
    final UserDetails userDetails = AdminUserFactory.newInstance().read(
      userKeyStruct);
        
    if (!userDetails.endDate.isZero()
      && RECORDSTATUS.NORMAL.equals(userDetails.statusCode)) {
      closeUserInd.closeUserInd = true;
    }
    
    return closeUserInd;
  }

  // END, CR00409509


}
