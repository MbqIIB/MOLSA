/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.clientdiary.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.clientdiary.codetable.impl.CLIENTDIARYRELATEDTYPEEntry;
import curam.clientdiary.entity.struct.ClientDiaryDtls;
import curam.clientdiary.message.impl.CLIENTDIARYExceptionCreator;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.StringHelper;


/**
 * Implementation for a {@link ClientDiary}.
 *
 * @since 6.0
 */
class ClientDiaryImpl extends SingleTableLogicallyDeleteableEntityImpl<ClientDiaryDtls> implements
  ClientDiary {

  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  @Inject
  protected ClientDiaryDAO clientDiaryDAO;

  @Inject
  protected ScheduledAppointmentDAO scheduledAppointmentDAO;

  /**
   * {@inheritDoc}
   */
  public ConcernRole getConcernRole() {
    return concernRoleDAO.get(getDtls().concernRoleID);
  }

  /**
   * {@inheritDoc}
   */
  public Long getRelatedID() {
    return getDtls().relatedID;
  }

  /**
   * {@inheritDoc}
   */
  public CLIENTDIARYRELATEDTYPEEntry getRelatedType() {
    return CLIENTDIARYRELATEDTYPEEntry.get(getDtls().relatedType);
  }

  /**
   * {@inheritDoc}
   */
  public void setConcernRole(final ConcernRole concernRole) {
    if (null != concernRole) {
      getDtls().concernRoleID = concernRole.getID();
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setDateRange(final DateRange dateRange) {
    if (null != dateRange) {
      dateRange.validateRange();
      getDtls().startDate = dateRange.start();
      getDtls().endDate = dateRange.end();
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedID(final Long relatedID) {
    getDtls().relatedID = relatedID;
  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedType(final CLIENTDIARYRELATEDTYPEEntry relatedType) {
    getDtls().relatedType = relatedType.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {

    // check for duplicates
    List<ClientDiary> activeClientDiaries = clientDiaryDAO.listByConcernRoleScheduledAppointmentAndStatus(
      getConcernRole(),
      scheduledAppointmentDAO.get(getRelatedID(), getRelatedType()),
      RECORDSTATUSEntry.NORMAL);

    for (ClientDiary clientDiary : activeClientDiaries) {
      if (clientDiary.getID() != getID()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CLIENTDIARYExceptionCreator.ERR_XRV_DUPLICATE(
            getConcernRole().getName(), getRelatedID(),
            getRelatedType().getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
        break;
      }
    }
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none needed
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {
    // concern role
    if (0 == getDtls().concernRoleID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CLIENTDIARYExceptionCreator.ERR_FV_CONCERN_ROLE_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // related ID
    if (0 == getDtls().relatedID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CLIENTDIARYExceptionCreator.ERR_FV_RELATED_ID_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // related type
    if (StringHelper.isEmpty(getDtls().relatedType)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CLIENTDIARYExceptionCreator.ERR_FV_RELATED_TYPE_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // start date
    if (getDtls().startDate.equals(Date.kZeroDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CLIENTDIARYExceptionCreator.ERR_FV_START_DATE_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public ScheduledAppointment getScheduledAppointment() {
    return scheduledAppointmentDAO.get(getRelatedID(), getRelatedType());
  }

  /**
   * {@inheritDoc}
   */
  public void setScheduledAppointment(
    final ScheduledAppointment scheduledAppointment) {
    if (null != scheduledAppointment) {
      setRelatedID(scheduledAppointment.getID());
      setRelatedType(scheduledAppointment.getClientDiaryRelatedType());
    }
  }

  /**
   * {@inheritDoc}
   */
  public int compareTo(final ClientDiary clientDiary) {

    return getDateRange().start().compareTo(clientDiary.getDateRange().start());
  }

}
