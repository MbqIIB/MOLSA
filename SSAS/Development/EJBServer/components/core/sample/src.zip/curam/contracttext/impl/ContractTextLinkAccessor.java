/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracttext.impl;

import curam.codetable.impl.CONTRACTTEXTLINKTYPEEntry;
import curam.core.sl.entity.struct.ContractTextDtls;
import curam.core.sl.entity.struct.RelatedReferenceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;

/**
 * Contract Text Link Accessor for {@linkplain curam.contracttext.impl.ContractTextLink}.
 */
public interface ContractTextLinkAccessor extends StandardEntity {

  /**
   * Gets the Contract Text details for Contract Text Link.
   * 
   * @return The details of the Contract Text associated with the Contract Text Link.
   * 
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  ContractTextDtls getContractText() throws AppException, InformationalException;

  /**
   * Gets the related reference for Contract Text Link.
   * 
   * @return The related reference key having related reference ID.
   */
  RelatedReferenceKey getRelatedReference();

  /**
   * Gets the type of the related reference for Contract Text Link.
   * 
   * @return The type of the related reference associated with the Contract Text.
   */
  CONTRACTTEXTLINKTYPEEntry getRelatedType();
}
