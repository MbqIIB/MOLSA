/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import java.util.SortedSet;

import com.google.inject.Inject;

import curam.caseaudit.entity.struct.CaseAuditKey;
import curam.caseaudit.entity.struct.CaseAuditTransactionLogKey;
import curam.caseaudit.impl.CaseAuditDAO;
import curam.caseaudit.impl.CaseAuditTransactionLogDAO;
import curam.core.facade.struct.CaseAuditTransactionLogDtls;
import curam.core.facade.struct.CaseAuditTransactionLogDtlsList;
import curam.core.impl.EnvVars;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.UsersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * Facade Class for the Case Audit Transaction Log implementation.
 *
 */
public abstract class CaseAuditTransactionLog extends curam.core.facade.base.CaseAuditTransactionLog {

  @Inject
  protected CaseAuditTransactionLogDAO caseAuditTransactionLogDAO;
  
  @Inject
  protected CaseAuditDAO caseAuditDAO;
  
  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public CaseAuditTransactionLog() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  
  // ___________________________________________________________________________
  /**
   * Returns the list of all transactions for a given case audit.
   *
   * @param key - CaseAuditKey The case audit id.
   *
   * @return CaseAuditTransactionLogDtlsList The list of transaction logs.
   */
  public CaseAuditTransactionLogDtlsList listAllTransactions(CaseAuditKey key)
    throws AppException, InformationalException {
    // Return Struct
    CaseAuditTransactionLogDtlsList caseAuditTransactionLogDtlsList = new CaseAuditTransactionLogDtlsList();
    
    curam.caseaudit.impl.CaseAudit caseAudit = caseAuditDAO.get(key.caseAuditID);
    
    UsersKey usersKey = new UsersKey();
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    
    SortedSet<curam.caseaudit.impl.CaseAuditTransactionLog> caseAuditTransactionLogList = caseAuditTransactionLogDAO.searchByCaseAudit(
      caseAudit);
    
    for (curam.caseaudit.impl.CaseAuditTransactionLog caseAuditTransactionLog :  caseAuditTransactionLogList) {
    
      CaseAuditTransactionLogDtls caseAuditTransactionLogDtls = new CaseAuditTransactionLogDtls();
    
      caseAuditTransactionLogDtls.caseAuditID = caseAuditTransactionLog.getCaseAudit().getID();
      caseAuditTransactionLogDtls.description = caseAuditTransactionLog.getDescription();
      caseAuditTransactionLogDtls.transactionID = caseAuditTransactionLog.getID();
      caseAuditTransactionLogDtls.relatedID = caseAuditTransactionLog.getRelatedID();
      caseAuditTransactionLogDtls.transactionDateTime = caseAuditTransactionLog.getTransactionDateTime();
      caseAuditTransactionLogDtls.transactionType = caseAuditTransactionLog.getTransactionType().getCode();
      
      String userName = caseAuditTransactionLog.getUserName();

      usersKey.userName = userName;
      
      caseAuditTransactionLogDtls.userName = userName;
        
      caseAuditTransactionLogDtls.name = userAccessObj.getFullName(usersKey).fullname;

      caseAuditTransactionLogDtlsList.dtlsList.addRef(
        caseAuditTransactionLogDtls);
    }
    
    return caseAuditTransactionLogDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Returns the list of recent transactions for a given case audit.
   *
   * @param key - CaseAuditKey The case audit id.
   *
   * @return CaseAuditTransactionLogDtlsList The list of transaction logs.
   */
  public CaseAuditTransactionLogDtlsList listRecentTransactions(CaseAuditKey key)
    throws AppException, InformationalException {
    
    CaseAuditTransactionLogDtlsList allTransactions = listAllTransactions(key);
    CaseAuditTransactionLogDtlsList filteredTransactions = new CaseAuditTransactionLogDtlsList();
    
    long numberOfTransactions = allTransactions.dtlsList.size(); 
    
    if (curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_CASE_AUDIT_TRANSACTION_LOG_NO_OF_TRANSACTION)
        != null) {
      numberOfTransactions = Long.parseLong(
        curam.util.resources.Configuration.getProperty(
          EnvVars.ENV_CASE_AUDIT_TRANSACTION_LOG_NO_OF_TRANSACTION));
    }
    
    if (allTransactions.dtlsList.size() > 0) {
      for (int i = 0; i < numberOfTransactions; i++) {

        // Number of Transaction Log records available is less than 
        // configured max number of Transactions
        if (allTransactions.dtlsList.size() <= i) {
          break;
        }
        filteredTransactions.dtlsList.addRef(allTransactions.dtlsList.item(i));
      }
    }
    return filteredTransactions;
  }
  
  // ___________________________________________________________________________
  /**
   * Returns the details of a given case audit transaction.
   *
   * @param key - CaseAuditTransactionLogKey The case audit transaction id.
   *
   * @return CaseAuditTransactionLogDtls The details of the case audit transaction.
   */
  public CaseAuditTransactionLogDtls readCaseAuditTransaction(
    CaseAuditTransactionLogKey key) throws AppException,
      InformationalException {
    
    // Return Struct
    CaseAuditTransactionLogDtls caseAuditTransactionLogDtls = new CaseAuditTransactionLogDtls();
    
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    
    curam.caseaudit.impl.CaseAuditTransactionLog caseAuditTransactionLog = caseAuditTransactionLogDAO.get(
      key.transactionID); 
    
    caseAuditTransactionLogDtls.caseAuditID = caseAuditTransactionLog.getCaseAudit().getID();
    caseAuditTransactionLogDtls.description = caseAuditTransactionLog.getDescription();
    caseAuditTransactionLogDtls.transactionID = caseAuditTransactionLog.getID();
    caseAuditTransactionLogDtls.relatedID = caseAuditTransactionLog.getRelatedID();
    caseAuditTransactionLogDtls.transactionDateTime = caseAuditTransactionLog.getTransactionDateTime();
    caseAuditTransactionLogDtls.transactionType = caseAuditTransactionLog.getTransactionType().getCode();
    
    String userName = caseAuditTransactionLog.getUserName();
    UsersKey usersKey = new UsersKey();

    usersKey.userName = userName;
    
    caseAuditTransactionLogDtls.userName = userName;
    caseAuditTransactionLogDtls.name = userAccessObj.getFullName(usersKey).fullname;
        
    return caseAuditTransactionLogDtls;
  }

}
