/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2002, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.Map.Entry;

import curam.codetable.ADDRESSELEMENTTYPE;
import curam.codetable.ADDRESSLAYOUTTYPE;
import curam.codetable.STREETNUMBERSUFFIXTYPE;
import curam.codetable.STREETTYPE;
import curam.core.fact.AddressFactory;
import curam.core.intf.Address;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.struct.AddressChangedInd;
import curam.core.struct.AddressDataKey;
import curam.core.struct.AddressFieldDetails;
import curam.core.struct.AddressHeaderDetails;
import curam.core.struct.AddressIDData;
import curam.core.struct.AddressLine;
import curam.core.struct.AddressLineList;
import curam.core.struct.AddressMap;
import curam.core.struct.AddressMapList;
import curam.core.struct.AddressTagDetails;
import curam.core.struct.ElementDetails;
import curam.core.struct.LayoutKey;
import curam.core.struct.LocaleStruct;
import curam.core.struct.OtherAddressData;
import curam.message.BPOADDRESS;
import curam.message.BPOADDRESSDATA;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * This process class provides the functionality to manipulate address data.
 */
public abstract class AddressData extends curam.core.base.AddressData {

  protected static final char kEquals = '=';
  // BEGIN, CR00023618, SK
  protected static final String kOne = CuramConst.gkModifiableIndex;
  // END, CR00023618
  protected static final char kNewLine = '\n';

  // length of kEquals constant in characters
  protected static final int kEqualsLen = 1;

  // ___________________________________________________________________________
  /**
   * This method parses an address data string delimited by line termination
   * characters and returns a list of <name> = <value> pairs derived from the
   * address information. The address must not be a freeform address.
   *
   * @param addressData Structure containing address data string
   *
   * @return A list of <name> = <value> pairs
   */
  public AddressMapList parseDataToMap(OtherAddressData addressData)
    throws AppException, InformationalException {

    // address map list
    AddressMapList addressMapList = new AddressMapList();

    // Address line lists and iterator
    AddressLineList addressLineList;
    int i;

    // Address map
    AddressMap addressMap;

    // Address string length
    int addressStringLength;
    int position;

    // Number of name-value lines
    int lineNo;

    addressLineList = newlineText2List(addressData);

    if (addressLineList.dtls.size() > AddressUtil.kAddressHeaderLineCount) {

      i = 0;

      // points to the list element 3
      i += AddressUtil.AddressDataLineIndex.I_ADDRESS_LAYOUT_TYPE;

      if (!addressLineList.dtls.item(i).addressString.equals(
        curam.codetable.ADDRESSLAYOUTTYPE.FREEFORM)) {

        // copy all lines in the list from the line 7 onwards
        // into addressMapList
        for (i = AddressUtil.AddressDataLineIndex.I_ADDRESS_LINE_1, lineNo = 1; i
          < addressLineList.dtls.size(); i++, lineNo++) {

          addressStringLength = (addressLineList.dtls.item(i).addressString).length();

          if (addressStringLength > 0) {

            position = (addressLineList.dtls.item(i).addressString.indexOf(
              kEquals, 0));

            if (position > 0) {

              addressMap = new AddressMap();
              addressMap.name = (addressLineList.dtls.item(i).addressString).substring(
                0, position);

              if (position + 1 < addressStringLength) {
                addressMap.value = (addressLineList.dtls.item(i).addressString).substring(
                  position + 1, addressStringLength);
              } else { // position points on the last element so there are
                // no elements left in the addressString

                // BEGIN, CR00049218, GM
                addressMap.value = CuramConst.gkEmpty;
                // END, CR00049218
              }

              addressMapList.dtls.addRef(addressMap);

            } else {

              if (position == 0) { // <name> tag is blank

                AppException e = new AppException(
                  curam.message.BPOADDRESSDATA.ERR_ADDRESSDATA_FV_NO_NAME);

                e.arg(lineNo);
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
                  e,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  0);
              } else {
                AppException e = new AppException(
                  curam.message.BPOADDRESSDATA.ERR_ADDRESSDATA_FV_ADDRESS_LINE_FORMAT);

                e.arg(lineNo);
                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
                  e,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  0);
              }

            }

          }

        }

      } else {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOADDRESSDATA.ERR_ADDRESSDATA_FREEFORM),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    }

    return addressMapList;
  }

  // ___________________________________________________________________________
  /**
   * This method parses an address data string delimited by line termination
   * characters and returns a list of freeform address lines derived from the
   * address information. The address must be a freeform address.
   *
   * @param addressData Structure containing address data string
   *
   * @return Structure containing address vector of strings
   */
  public AddressLineList parseDataToFreeform(OtherAddressData addressData)
    throws AppException, InformationalException {

    // address line/list manipulation variables
    AddressLineList addressLineList = new AddressLineList();
    AddressLineList addLineList;

    AddressLine addressLine;

    int i; // addressLineList iterator

    addLineList = newlineText2List(addressData);

    if (addLineList.dtls.size() > AddressUtil.kAddressHeaderLineCount) {

      i = 0;

      // points to the list element 3
      i += AddressUtil.AddressDataLineIndex.I_ADDRESS_LAYOUT_TYPE;

      if (addLineList.dtls.item(i).addressString.equals(
        curam.codetable.ADDRESSLAYOUTTYPE.FREEFORM)) {

        // copy all lines from line 7 onwards into a new list
        for (i = AddressUtil.AddressDataLineIndex.I_ADDRESS_LINE_1; i
          < addLineList.dtls.size(); i++) {

          addressLine = new AddressLine();

          addressLine.addressString = addLineList.dtls.item(i).addressString;

          addressLineList.dtls.addRef(addressLine);

        }

      } else {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOADDRESSDATA.ERR_ADDRESSDATA_NOT_FREEFORM),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    }

    return addressLineList;
  }

  // ___________________________________________________________________________
  /**
   * This method parses an address data string delimited by line termination
   * characters and returns a struct containing the header information for the
   * address. Validation will be handled in a different method.
   *
   * @param addressData Address data string
   *
   * @return Address header details
   */
  public AddressHeaderDetails parseDataToHeader(OtherAddressData addressData)
    throws AppException, InformationalException {

    // address header details manipulation variable
    AddressHeaderDetails addressHeaderDetails = new AddressHeaderDetails();

    // Output from newlineText2List
    AddressLineList addressLineList;

    // Iterator for address line lists
    int i;

    addressLineList = newlineText2List(addressData);

    if (addressLineList.dtls.size() >= AddressUtil.kAddressHeaderLineCount) {

      i = 0;

      addressHeaderDetails.widgetVersion = Integer.parseInt(
        addressLineList.dtls.item(i).addressString);
      i++;

      addressHeaderDetails.addressID = java.lang.Long.parseLong(
        addressLineList.dtls.item(i).addressString);
      i++;

      addressHeaderDetails.addressLayoutType = addressLineList.dtls.item(i).addressString;
      i++;

      addressHeaderDetails.countryCode = addressLineList.dtls.item(i).addressString;
      i++;

      addressHeaderDetails.modifiableInd = addressLineList.dtls.item(i).addressString.equals(
        kOne);
      i++;

      addressHeaderDetails.versionNo = Integer.parseInt(
        addressLineList.dtls.item(i).addressString);

    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOADDRESS.ERR_ADDRESS_FV_ADDRESSHEADER_INVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    return addressHeaderDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method adds the specified name and value to the address map list.
   * If the specified name already exists in the map list then an error will
   * occur.
   *
   * @param addressMapList List of <name> = <value> pairs
   * @param addressMap An element of the address map list
   */
  public void addElementToMap(
    AddressMapList addressMapList,
    AddressMap addressMap)
    throws AppException, InformationalException {

    // Element details
    ElementDetails elementDetails;

    elementDetails = findElement(addressMapList, addressMap);

    if (elementDetails.elementFound) {
      AppException e = new AppException(
        curam.message.BPOADDRESSDATA.ERR_ADDRESSDATA_FV_NAME);

      e.arg(addressMap.name);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    } else {

      addressMapList.dtls.addRef(addressMap);

    }

  }

  // ___________________________________________________________________________
  /**
   * This method searches through the address map list to find the specified
   * element. If the element is found, its value is returned.
   *
   * @param addressMapList List of <name> = <value> pairs
   * @param addressMap An element of the address map list
   *
   * @return Struct which contains name and value attributes
   */
  public ElementDetails findElement(
    AddressMapList addressMapList,
    AddressMap addressMap)
    throws AppException, InformationalException {

    // address element details manipulation variable
    ElementDetails elementDetails = new ElementDetails();

    // iterator for address map lists
    int i;

    elementDetails.elementFound = false;
    // BEGIN, CR00049218, GM
    elementDetails.elementValue = CuramConst.gkEmpty;
    // END, CR00049218

    for (i = 0; i < addressMapList.dtls.size(); i++) {

      if (addressMapList.dtls.item(i).name.equals(addressMap.name)) {
        elementDetails.elementFound = true;
        elementDetails.elementValue = addressMapList.dtls.item(i).value;
        break;
      }

    }

    return elementDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method takes an address map list and converts it to a string
   * containing <name>=<value> pairs delimited by line termination characters.
   *
   * @param addressMapList List of <name> = <value> pairs
   *
   * @return Struct containing address data string
   */
  public OtherAddressData parseMapToData(AddressMapList addressMapList)
    throws AppException, InformationalException {

    OtherAddressData addressData = new OtherAddressData();

    // iterator for address map lists
    int i;

    // BEGIN, CR00049218, GM
    addressData.addressData = CuramConst.gkEmpty;
    // END, CR00049218
    StringBuffer formatBuffer = new StringBuffer();
    int buffLen = 0;

    for (i = 0; i < addressMapList.dtls.size(); i++) {
      buffLen = buffLen + addressMapList.dtls.item(i).name.length()
        + kEqualsLen + addressMapList.dtls.item(i).value.length()
        + CuramConst.gkNewLine.length();
    }

    formatBuffer.ensureCapacity(buffLen);

    for (i = 0; i < addressMapList.dtls.size(); i++) {
      formatBuffer.append(addressMapList.dtls.item(i).name);
      formatBuffer.append(kEquals);
      formatBuffer.append(addressMapList.dtls.item(i).value);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    addressData.addressData = formatBuffer.toString();
    return addressData;
  }

  // ___________________________________________________________________________
  /**
   * This method takes a list of freeform address lines and converts it to a
   * string containing address lines delimited by line termination characters.
   *
   * @param addressLineList Struct containing address vector of strings
   *
   * @return Struct containing address data string
   */
  public OtherAddressData parseFreeformToData(AddressLineList addressLineList)
    throws AppException, InformationalException {

    // address data manipulation variable
    OtherAddressData addressData = new OtherAddressData();

    // AddressLineList iterator
    int i;

    StringBuffer formatBuffer = new StringBuffer();
    int buffLen = 0;

    // ensure correct buffer length
    for (i = 0; i < addressLineList.dtls.size(); i++) {
      buffLen = buffLen + addressLineList.dtls.item(i).addressString.length()
        + CuramConst.gkNewLine.length();
    }

    formatBuffer.ensureCapacity(buffLen);

    for (i = 0; i < addressLineList.dtls.size(); i++) {
      formatBuffer.append(addressLineList.dtls.item(i).addressString);
      formatBuffer.append(CuramConst.gkNewLine);
    }

    addressData.addressData = formatBuffer.toString();

    return addressData;
  }

  // ___________________________________________________________________________
  /**
   * This method sets the addressID in the addressData to the specified unique
   * address ID.
   *
   * @param addressData Struct containing address data string
   * @param addressKey Struct containing addressID
   */
  public void setAddressHeaderID(
    OtherAddressData addressData,
    AddressDataKey addressKey)
    throws AppException, InformationalException {

    // AddressMapList and iterator
    AddressMapList addressMapList;
    int i = 0; // iterator to find specific address element

    addressMapList = parseDataToMap(addressData);
    i++; // Point to the second element

    addressMapList.dtls.item(i).value = String.valueOf((addressKey.addressID));
    addressData = parseMapToData(addressMapList);
  }

  // ___________________________________________________________________________
  /**
   * This method checks that all of the tags in the specified tag string
   * appear in the addressMapList, and that no tags appear in the
   * addressMapList that do not appear in the tag string. The tag string must
   * be a tab-delimited string containing the correct tags.
   *
   * @param addressMapList List of <name>=<value> pairs
   * @param addressTagDetails List of address tags
   */
  public void validateTags(
    AddressMapList addressMapList,
    AddressTagDetails addressTagDetails)
    throws AppException, InformationalException {

    // address map manipulation variable
    AddressMap addressMap = new AddressMap();

    // AddressDetails vector
    curam.util.type.StringList addressDetailsVector;

    // Element details structure for search results.
    ElementDetails elementDetails;

    // flag to indicate if record is found
    boolean recordFound;
    
    // convert tab delimited string to vector of tags
    addressDetailsVector = curam.util.resources.StringUtil.tabText2StringList(
      addressTagDetails.addressTags);
    
    // check, that no tags appear in  addressMapList
    // that do not appear in addressTagDetails
    for (int i = 0; i < addressMapList.dtls.size(); i++) {

      recordFound = false;

      for (int j = 0; j < addressDetailsVector.size(); j++) {

        if (addressMapList.dtls.item(i).name.equals(
          addressDetailsVector.item(j))) {

          recordFound = true;
          break;
        }

      }

      if (!recordFound) {
        AppException e = new AppException(
          curam.message.BPOADDRESSDATA.ERR_ADDRESSDATA_FV_WRONGTAG);

        e.arg(addressMapList.dtls.item(i).name);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }

    }

    // check that no tags appear in the addressTagDetails
    // that do not appear in the addressMapList.
    for (int j = 0; j < addressDetailsVector.size(); j++) {

      addressMap.name = addressDetailsVector.item(j);
      elementDetails = findElement(addressMapList, addressMap);

      if (!elementDetails.elementFound) {
        AppException e = new AppException(
          curam.message.BPOADDRESSDATA.ERR_ADDRESSDATA_FV_TAGNOTFOUND);

        e.arg(addressMap.name);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }

    }

  }

  // ___________________________________________________________________________
  /**
   * This method takes a string delimited by line termination characters and
   * copies each of the entries into a list of strings.
   *
   * @param newlineText Struct containing address data string
   *
   * @return Struct containing address vector of strings
   */
  public AddressLineList newlineText2List(OtherAddressData newlineText)
    throws AppException, InformationalException {

    // addressLineList manipulation variable
    AddressLineList addressLineList = new AddressLineList();

    // addressLine manipulation variable

    AddressLine addressLine;

    int posEnd = 0;
    int posStart = 0;

    // iterator for string
    int j;

    // string buffer used in conversion
    String sBuff;

    // remove last NL delimiter if available from the end of string

    if (newlineText.addressData.length() > 0) {
      j = newlineText.addressData.length() - 1;

      if (newlineText.addressData.charAt(j) == kNewLine) {
        sBuff = newlineText.addressData.substring(0,
          newlineText.addressData.length() - 1);
      } else {
        sBuff = newlineText.addressData;
      }

    } else {
      // BEGIN, CR00049218, GM
      sBuff = CuramConst.gkEmpty;
      // END, CR00049218
    }

    // Newline text length
    int newlineTextLength = sBuff.length();

    if (newlineTextLength != 0) {

      while (posEnd <= newlineTextLength) {
        posEnd = sBuff.indexOf(kNewLine, posStart);

        addressLine = new AddressLine();

        if (posEnd == -1) {
          // newline not found - use string from posStart up to the end
          addressLine.addressString = sBuff.substring(posStart);

          addressLineList.dtls.addRef(addressLine);

          break;

        } else {
          addressLine.addressString = sBuff.substring(posStart, posEnd);

          addressLineList.dtls.addRef(addressLine);

        }

        posStart = posEnd + 1;

      }

    }

    return addressLineList;
  }

  // ___________________________________________________________________________
  /**
   * This method converts an address, specified by individual fields, into an
   * address data stream delimited by line termination characters.
   *
   * @param addressFieldDetails Structure containing individual address strings
   *
   * @return Address data string
   */
  public OtherAddressData parseFieldsToData(AddressFieldDetails
    addressFieldDetails) throws AppException, InformationalException {

    OtherAddressData addressData;
    
    // parse address fields into address stream
    if (ADDRESSLAYOUTTYPE.US.equals(addressFieldDetails.addressLayoutType)) {

      // BEGIN, CR00099876, SD
      // Check if the US address format contains the county field
      // BEGIN, CR00113430, ELG
      if (Configuration.getBooleanProperty(EnvVars.ENV_USADDRESSWITHCOUNTY,
        Configuration.getBooleanProperty(
        EnvVars.ENV_USADDRESSWITHCOUNTY_DEFAULT))) {
        // END, CR00113430
        addressData = parseUSWithCountyFieldsToData(addressFieldDetails);
      } else {
        addressData = parseUSFieldsToData(addressFieldDetails);
      }
      // END, CR00099876
    } else if (addressFieldDetails.addressLayoutType.equals(
      ADDRESSLAYOUTTYPE.UK)) {

      addressData = parseUKFieldsToData(addressFieldDetails);

    } else if (addressFieldDetails.addressLayoutType.equals(
      ADDRESSLAYOUTTYPE.CA)) {

      addressData = parseCAFieldsToData(addressFieldDetails);
      // BEGIN, CR00285272, ZV
    } else if (addressFieldDetails.addressLayoutType.equals(
      ADDRESSLAYOUTTYPE.CA_CIVIC)) {
      addressData = parseCACivicFieldsToData(addressFieldDetails);
      // END, CR00285272
      // BEGIN, CR00345882, SPD
    } else if (addressFieldDetails.addressLayoutType.equals(
      ADDRESSLAYOUTTYPE.TW)) {
      addressData = parseTWFieldsToData(addressFieldDetails);    
    } else if (addressFieldDetails.addressLayoutType.equals(
      ADDRESSLAYOUTTYPE.CN)) {
      addressData = parseCNFieldsToData(addressFieldDetails);         
    } else if (addressFieldDetails.addressLayoutType.equals(
      ADDRESSLAYOUTTYPE.KR)) {
      addressData = parseKRFieldsToData(addressFieldDetails);    
    } else if (addressFieldDetails.addressLayoutType.equals(
      ADDRESSLAYOUTTYPE.JP)) {
      addressData = parseJPFieldsToData(addressFieldDetails);
      // END, CR00345882  
    } else {
      addressData = new OtherAddressData();
    }

    return addressData;
  }

  // ___________________________________________________________________________
  /**
   * This method converts an US address, specified by individual fields, into an
   * address data stream delimited by line termination characters.
   *
   * @param addressFieldDetails Structure containing individual address strings
   *
   * @return Address data string
   */
  protected OtherAddressData parseUSFieldsToData(AddressFieldDetails
    addressFieldDetails) throws AppException, InformationalException {

    OtherAddressData addressData = new OtherAddressData();

    // BEGIN, CR00049218, GM
    String sModifiableInd = CuramConst.gkEmpty;
    // END, CR00049218
    String sZip;

    StringBuffer formatBuffer = new StringBuffer();

    // get zipCode
    if (addressFieldDetails.zipCode.length() > 0) {
      sZip = addressFieldDetails.zipCode;

    } else {
      // BEGIN, CR00049218, GM
      sZip = CuramConst.gkEmpty;
      // END, CR00049218
    }

    if (sZip == null) {
      // BEGIN, CR00049218, GM
      sZip = CuramConst.gkEmpty;
      // END, CR00049218
    }

    if (addressFieldDetails.modifiableInd) {
      // BEGIN, CR00051622, ANK
      sModifiableInd = kOne;
      // END, CR00051622
    } else {
      sModifiableInd = CuramConst.gkStringZero;
    }

    formatBuffer.ensureCapacity(
      CuramConst.gkNewLine.length() * 11 + CuramConst.gkStringZero.length() * 2
      + kEqualsLen * 6 + AddressUtil.kWidgetVersion.length()
      + curam.codetable.ADDRESSLAYOUTTYPE.US.length()
      + addressFieldDetails.countryCode.length() + sModifiableInd.length()
      + curam.codetable.ADDRESSELEMENTTYPE.LINE1.length()
      + addressFieldDetails.addressLine1.length()
      + curam.codetable.ADDRESSELEMENTTYPE.LINE2.length()
      + addressFieldDetails.addressLine2.length()
      + curam.codetable.ADDRESSELEMENTTYPE.LINE3.length()
      + addressFieldDetails.addressLine3.length()
      + curam.codetable.ADDRESSELEMENTTYPE.CITY.length()
      + addressFieldDetails.city.length()
      + curam.codetable.ADDRESSELEMENTTYPE.STATE.length()
      + addressFieldDetails.stateCode.length()
      + curam.codetable.ADDRESSELEMENTTYPE.ZIP.length() + sZip.length());

    formatBuffer.append(AddressUtil.kWidgetVersion);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(CuramConst.gkStringZero);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSLAYOUTTYPE.US);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.countryCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(sModifiableInd);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(CuramConst.gkStringZero);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.LINE1);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine1);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.LINE2);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine2);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.LINE3);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine3);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.CITY);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.city);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.STATE);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.stateCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.ZIP);
    formatBuffer.append(kEquals);
    formatBuffer.append(sZip);

    addressData.addressData = formatBuffer.toString();

    return addressData;
  }

  // BEGIN, CR00099876, SD
  // ___________________________________________________________________________
  /**
   * This method converts an US with county address, specified by individual
   * fields, into an address data stream delimited by line termination
   * characters.
   *
   * @param addressFieldDetails Structure containing individual address strings
   * @return Address data string
   */
  protected OtherAddressData parseUSWithCountyFieldsToData(AddressFieldDetails
    addressFieldDetails) throws AppException, InformationalException {

    OtherAddressData addressData = new OtherAddressData();

    String sModifiableInd = CuramConst.gkEmpty;
    String sZip;

    StringBuffer formatBuffer = new StringBuffer();

    // get zipCode
    if (addressFieldDetails.zipCode.length() > 0) {
      sZip = addressFieldDetails.zipCode;

    } else {
      sZip = CuramConst.gkEmpty;
    }

    if (sZip == null) {
      sZip = CuramConst.gkEmpty;
    }

    if (addressFieldDetails.modifiableInd) {
      sModifiableInd = kOne;
    } else {
      sModifiableInd = CuramConst.gkStringZero;
    }

    formatBuffer.ensureCapacity(
      CuramConst.gkNewLine.length() * 11 + CuramConst.gkStringZero.length() * 2
      + kEqualsLen * 6 + AddressUtil.kWidgetVersion.length()
      + curam.codetable.ADDRESSLAYOUTTYPE.US.length()
      + addressFieldDetails.countryCode.length() + sModifiableInd.length()
      + curam.codetable.ADDRESSELEMENTTYPE.LINE1.length()
      + addressFieldDetails.addressLine1.length()
      + curam.codetable.ADDRESSELEMENTTYPE.LINE2.length()
      + addressFieldDetails.addressLine2.length()
      + curam.codetable.ADDRESSELEMENTTYPE.LINE3.length()
      + addressFieldDetails.addressLine3.length()
      + curam.codetable.ADDRESSELEMENTTYPE.CITY.length()
      + addressFieldDetails.city.length()
      + curam.codetable.ADDRESSELEMENTTYPE.USCOUNTY.length()
      + addressFieldDetails.usCountyCode.length()
      + curam.codetable.ADDRESSELEMENTTYPE.STATE.length()
      + addressFieldDetails.stateCode.length()
      + curam.codetable.ADDRESSELEMENTTYPE.ZIP.length() + sZip.length());

    formatBuffer.append(AddressUtil.kWidgetVersion);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(CuramConst.gkStringZero);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSLAYOUTTYPE.US);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.countryCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(sModifiableInd);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(CuramConst.gkStringZero);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.LINE1);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine1);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.LINE2);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine2);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.LINE3);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine3);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.CITY);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.city);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.USCOUNTY);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.usCountyCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.STATE);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.stateCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.ZIP);
    formatBuffer.append(kEquals);
    formatBuffer.append(sZip);

    addressData.addressData = formatBuffer.toString();

    return addressData;
  }

  // END, CR00099876

  // ___________________________________________________________________________
  /**
   * This method converts an UK address, specified by individual fields, into an
   * address data stream delimited by line termination characters.
   *
   * @param addressFieldDetails Structure containing individual address strings
   *
   * @return Address data string
   */
  protected OtherAddressData parseUKFieldsToData(AddressFieldDetails
    addressFieldDetails) throws AppException, InformationalException {

    OtherAddressData addressData = new OtherAddressData();

    // BEGIN, CR00049218, GM
    String sModifiableInd = CuramConst.gkEmpty;
    // END, CR00049218

    String sPostCode;
    String sCountry;

    StringBuffer formatBuffer = new StringBuffer();

    // get Postal code
    if (addressFieldDetails.postalCode.length() > 0) {
      sPostCode = curam.util.type.CodeTable.getOneItem(
        curam.codetable.POSTALCODE.TABLENAME, addressFieldDetails.postalCode);
    } else {
      // BEGIN, CR00049218, GM
      sPostCode = CuramConst.gkEmpty;
      // END, CR00049218
    }

    if (sPostCode == null) {
      // BEGIN, CR00049218, GM
      sPostCode = CuramConst.gkEmpty;
      // END, CR00049218
    }

    // get Country
    if (addressFieldDetails.countryCode.length() > 0) {
      sCountry = curam.util.type.CodeTable.getOneItem(
        curam.codetable.ADDRESSCOUNTRY.TABLENAME,
        addressFieldDetails.countryCode);
    } else {
      // BEGIN, CR00049218, GM
      sCountry = CuramConst.gkEmpty;
      // END, CR00049218
    }

    if (sCountry == null) {
      // BEGIN, CR00049218, GM
      sCountry = CuramConst.gkEmpty;
      // END, CR00049218
    }

    if (addressFieldDetails.modifiableInd) {
      // BEGIN, CR00051622, ANK
      sModifiableInd = kOne;
      // END, CR00051622
    } else {
      sModifiableInd = CuramConst.gkStringZero;
    }

    formatBuffer.ensureCapacity(
      CuramConst.gkNewLine.length() * 12 + CuramConst.gkStringZero.length() * 2
      + kEqualsLen * 6 + AddressUtil.kWidgetVersion.length()
      + curam.codetable.ADDRESSLAYOUTTYPE.UK.length()
      + addressFieldDetails.countryCode.length() + sModifiableInd.length()
      + curam.codetable.ADDRESSELEMENTTYPE.LINE1.length()
      + addressFieldDetails.addressLine1.length()
      + curam.codetable.ADDRESSELEMENTTYPE.LINE2.length()
      + addressFieldDetails.addressLine2.length()
      + curam.codetable.ADDRESSELEMENTTYPE.LINE3.length()
      + addressFieldDetails.addressLine3.length()
      + curam.codetable.ADDRESSELEMENTTYPE.LINE4.length()
      + addressFieldDetails.addressLine4.length()
      + curam.codetable.ADDRESSELEMENTTYPE.LINE5.length()
      + addressFieldDetails.addressLine5.length()
      + curam.codetable.ADDRESSELEMENTTYPE.CITY.length()
      + addressFieldDetails.city.length()
      + curam.codetable.ADDRESSELEMENTTYPE.POSTCODE.length()
      + sPostCode.length()
      + curam.codetable.ADDRESSELEMENTTYPE.COUNTRY.length()
      + addressFieldDetails.countryCode.length());

    // create address header
    formatBuffer.append(AddressUtil.kWidgetVersion);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(CuramConst.gkStringZero);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSLAYOUTTYPE.UK);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.countryCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(sModifiableInd);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(CuramConst.gkStringZero);
    formatBuffer.append(CuramConst.gkNewLine);

    // create address body
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.LINE1);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine1);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.LINE2);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine2);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.LINE3);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine3);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.LINE4);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine4);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.LINE5);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine5);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.CITY);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.city);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.POSTCODE);
    formatBuffer.append(kEquals);
    formatBuffer.append(sPostCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(curam.codetable.ADDRESSELEMENTTYPE.COUNTRY);
    formatBuffer.append(kEquals);
    formatBuffer.append(sCountry);

    addressData.addressData = formatBuffer.toString();

    return addressData;
  }

  // BEGIN, CR00199929, SS
  /**
   * This method converts an CA address, specified by individual fields, into an
   * address data stream delimited by line termination characters.
   *
   * @param addressFieldDetails Structure containing individual address strings
   *
   * @return Address data string
   */
  protected OtherAddressData parseCAFieldsToData(AddressFieldDetails
    addressFieldDetails) throws AppException, InformationalException {
    OtherAddressData addressData = new OtherAddressData();
    String sModifiableInd = CuramConst.gkEmpty;
    String sPostCode;
    StringBuffer formatBuffer = new StringBuffer();

    // Get Postal code.
    // BEGIN, CR00267526, GD
    sPostCode = addressFieldDetails.postalCode;
    // END, CR00267526

    if (addressFieldDetails.modifiableInd) {
      sModifiableInd = kOne;
    } else {
      sModifiableInd = CuramConst.gkStringZero;
    }

    // Just to ensure that the StringBuffer formatBuffer has a minimum capacity
    // to fit Canadian address.
    formatBuffer.ensureCapacity(
      CuramConst.gkNewLine.length() * 11 + CuramConst.gkStringZero.length() * 2
      + kEqualsLen * 7 + AddressUtil.kWidgetVersion.length()
      + ADDRESSLAYOUTTYPE.CA.length()
      + addressFieldDetails.countryCode.length() + sModifiableInd.length()
      + ADDRESSELEMENTTYPE.LINE1.length()
      + addressFieldDetails.addressLine1.length()
      + ADDRESSELEMENTTYPE.LINE2.length()
      + addressFieldDetails.addressLine2.length()
      + ADDRESSELEMENTTYPE.LINE3.length()
      + addressFieldDetails.addressLine3.length()
      + ADDRESSELEMENTTYPE.LINE4.length()
      + addressFieldDetails.addressLine4.length()
      + ADDRESSELEMENTTYPE.CITY.length() + addressFieldDetails.city.length()
      + ADDRESSELEMENTTYPE.PROVINCE.length()
      + addressFieldDetails.province.length()
      + ADDRESSELEMENTTYPE.POSTCODE.length() + sPostCode.length());

    // Creating address header.
    formatBuffer.append(AddressUtil.kWidgetVersion);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.addressID); // CuramConst.gkStringZero
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSLAYOUTTYPE.CA);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.countryCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(sModifiableInd);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.versionNo); // CuramConst.gkStringZero
    formatBuffer.append(CuramConst.gkNewLine);

    // Creating address body.
    formatBuffer.append(ADDRESSELEMENTTYPE.APT);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.suiteNum);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.LINE1);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine1);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.LINE2);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine2);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.CITY);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.city);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.PROVINCE);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.province);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.POSTCODE);
    formatBuffer.append(kEquals);
    formatBuffer.append(sPostCode);

    addressData.addressData = formatBuffer.toString();

    return addressData;
  }

  // END, CR00199929

  // ___________________________________________________________________________
  /**
   * This method returns true if there is a difference between the address data,
   * the address header is not checked as it is assumed this is not changed.
   *
   * @param otherAddressData The original address strings before modification.
   * @param modifiedOtherAddressData The modified address strings.
   *
   * @return AddressChangedInd indicating if the address data changed
   */
  public AddressChangedInd hasAddressDataChanged(
    OtherAddressData otherAddressData,
    OtherAddressData modifiedOtherAddressData)
    throws AppException, InformationalException {

    // the indicator to be returned
    AddressChangedInd addressChangedInd = new AddressChangedInd();

    // Variable to manipulate the addressData
    OtherAddressData orderedModifiedOtherAddressData = new OtherAddressData();
    OtherAddressData orderedOtherAddressData = new OtherAddressData();

    // Variables for address
    curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();

    // Need to order the address data for comparison.
    orderedOtherAddressData = addressObj.reorderAddressDataTags(
      otherAddressData);
    orderedModifiedOtherAddressData = addressObj.reorderAddressDataTags(
      modifiedOtherAddressData);

    // Address line lists and iterator
    AddressLineList oldAddressLineList;
    AddressLineList modifiedAddressLineList;

    // Number of name-value lines
    int lineNo;

    // Copy the details into a list of strings so we can compare them.
    oldAddressLineList = newlineText2List(orderedOtherAddressData);
    modifiedAddressLineList = newlineText2List(orderedModifiedOtherAddressData);

    // Set the return to be false.
    addressChangedInd.addressChangedInd = false;

    if (oldAddressLineList.dtls.size() > AddressUtil.kAddressHeaderLineCount) {

      int x = 0;

      // Points to the list element 3
      x += AddressUtil.AddressDataLineIndex.I_ADDRESS_LAYOUT_TYPE;

      // Compare all lines in the list from the line 7 onwards (not the header)
      for (x = AddressUtil.AddressDataLineIndex.I_ADDRESS_LINE_1, lineNo = 1; x
        < oldAddressLineList.dtls.size(); x++, lineNo++) {

        // Compare the address string.
        if (!oldAddressLineList.dtls.item(x).addressString.equals(
          modifiedAddressLineList.dtls.item(x).addressString)) {
          // The address has changed so we can exit
          addressChangedInd.addressChangedInd = true;
          break;
        }
      }
    }

    return addressChangedInd;
  }

  // ___________________________________________________________________________
  /**
   * This method returns an address data string which contains the correct
   * address layout for the specified locale.
   *
   * @return Address data string
   */
  public OtherAddressData getAddressDataForLocale()
    throws AppException, InformationalException {

    // BEGIN, CR00214655, PB
    return getAddressDataForLocale(false);
    // END, CR00214655
  }

  // BEGIN, CR00214655, PB
  // BEGIN, CR00225881, PB
  /**
   * This method returns an address data string which contains the correct
   * address layout for the specified locale.
   *
   * @param displayInd
   * Indicates whether address data should be generated for display
   * or for storage. Address data for display will have default
   * localized text, while address data for storage will have default
   * English Address Unavailable text.
   *
   * @return Address data string
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected OtherAddressData getAddressDataForLocale(boolean displayInd)
    throws AppException, InformationalException {
    // END, CR00225881
    // BEGIN, CR00113430, ELG
    // BEGIN, CR00023323, SK
    final String kEnGB = CuramConst.gkGBLocale;
    // END, CR00023323
    // END, CR00113430

    // BEGIN, CR00190258, CL

    String noAddress;

    if (displayInd) {
      noAddress = new curam.util.exception.LocalisableString(curam.message.BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE).getMessage(
        TransactionInfo.getProgramLocale());
    } else {
      // BEGIN, CR00340652, KRK
      noAddress = BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00340652    
    }

    final String kDeDE = CuramConst.gkDELocale;
    // END, CR00190258

    final String kEnCA = CuramConst.gkCALocale;
    final String kZhTw = CuramConst.gkZH_TWLocale;
    final String kZhCn = CuramConst.gkZH_CNLocale;
    final String kJa = CuramConst.gkJALocale;
    final String kKo = CuramConst.gkKOLocale;
    
    // get locale type
    String addressDataLocaleForDefaultAddresses = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_ADDRESSDATALOCALEFORDEFAULTADDRESSES);

    if (addressDataLocaleForDefaultAddresses == null) {
      // BEGIN, CR00362646, BD
      addressDataLocaleForDefaultAddresses = curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_ADDRESSDATALOCALEFORDEFAULTADDRESSES_DEFAULT);
      // END, CR00362646
    }

    final OtherAddressData otherAddressData = new OtherAddressData();

    // BEGIN, CR00190258, CL
    // BEGIN, CR00113430, ELG
    // if locales match, use specific address layout else use default (en_US)
    if (kEnGB.equalsIgnoreCase(addressDataLocaleForDefaultAddresses)) {
      // END, CR00113430
      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "UK" + CuramConst.gkNewLine + "GB"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "ADD1=" + noAddress + CuramConst.gkNewLine
        + "ADD2=" + CuramConst.gkNewLine + "ADD3=" + CuramConst.gkNewLine
        + "ADD4=" + CuramConst.gkNewLine + "ADD5=" + CuramConst.gkNewLine
        + "CITY=" + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine
        + "COUNTRY=" + CuramConst.gkNewLine;
    } else if (kDeDE.equalsIgnoreCase(addressDataLocaleForDefaultAddresses)) {
      // BEGIN, CR00315504, ZV
      // BEGIN, CR00219204, SW
      // BEGIN, CR00390589, SPD
      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "DE" + CuramConst.gkNewLine + "DE"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "ADD1=" + noAddress + CuramConst.gkNewLine
        + "ADD2=" + CuramConst.gkNewLine + "DISTRICT=" + CuramConst.gkNewLine
        + "POBOXNO=" + CuramConst.gkNewLine + "POSTCODE=" + noAddress
        + CuramConst.gkNewLine + "CITY=" + noAddress + CuramConst.gkNewLine
        + "COUNTRY=" + CuramConst.gkNewLine;
      ;
      // END, CR00390589
      // END, CR00219204
      // END, CR00315504
    } // BEGIN, CR00277220, ELG
    // BEGIN, CR00199929, SS
    else if (kEnCA.equalsIgnoreCase(addressDataLocaleForDefaultAddresses)) {
      // BEGIN, CR00285272, ZV
      // Get address layout for "en_CA" locale
      String addressLayout = Configuration.getProperty(
        EnvVars.ENV_ADDRESS_LAYOUT);

      if (addressLayout == null || addressLayout.isEmpty()) {
        addressLayout = EnvVars.ENV_ADDRESS_LAYOUT_DEFAULT;
      }
      
      if (addressLayout.equals(ADDRESSLAYOUTTYPE.CA_CIVIC)) {
        otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "CACIVIC" + CuramConst.gkNewLine + "CA"
          + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "ADI=" + CuramConst.gkNewLine + "UNITNO="
          + CuramConst.gkNewLine + "STRNUMBER=" + CuramConst.gkNewLine
          + "STRNOSFX=" + CuramConst.gkNewLine + "STRNAME=" + noAddress
          + CuramConst.gkNewLine + "STRTYPE=" + CuramConst.gkNewLine
          + "STRDIR=" + CuramConst.gkNewLine + "CITY=" + CuramConst.gkNewLine 
          + "PROV=" + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine;
      } else {
        otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "CA" + CuramConst.gkNewLine + "CA"
          + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine + "APT="
          + CuramConst.gkNewLine + "ADD1=" + noAddress + CuramConst.gkNewLine
          + "CITY=" + noAddress + CuramConst.gkNewLine + "ADD2="
          + CuramConst.gkNewLine + "PROV=" + CuramConst.gkNewLine;
      }
      // END, CR00285272
      // END, CR00199929
      // BEGIN, CR00345882, SPD
      // Traditional Chinese address format
    } else if (kZhTw.equalsIgnoreCase(addressDataLocaleForDefaultAddresses)) {
      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "TW" + CuramConst.gkNewLine + "TW"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine + "CITY="
        + CuramConst.gkNewLine + "DISTRICT=" + CuramConst.gkNewLine + "ADD1="
        + noAddress + CuramConst.gkNewLine + "ADD2=" + CuramConst.gkNewLine;
      
      // Simplified Chinese address format
    } else if (kZhCn.equalsIgnoreCase(addressDataLocaleForDefaultAddresses)) {
      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "CN" + CuramConst.gkNewLine + "CN"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine + "PROV="
        + CuramConst.gkNewLine + "CITY=" + CuramConst.gkNewLine + "DISTRICT="
        + CuramConst.gkNewLine + "ADD1=" + noAddress + CuramConst.gkNewLine
        + "ADD2=" + CuramConst.gkNewLine;
        
      // Japan address format
    } else if (kJa.equalsIgnoreCase(addressDataLocaleForDefaultAddresses)) {
      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "JP" + CuramConst.gkNewLine + "JP"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine + "PROV="
        + CuramConst.gkNewLine + "CITY=" + CuramConst.gkNewLine + "ADD1="
        + noAddress + CuramConst.gkNewLine + "ADD2=" + CuramConst.gkNewLine;
      
      // South Korea address format
    } else if (kKo.equalsIgnoreCase(addressDataLocaleForDefaultAddresses)) {
      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "KR" + CuramConst.gkNewLine + "KR"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine + "CITY="
        + CuramConst.gkNewLine + "ADD1=" + noAddress + CuramConst.gkNewLine
        + "ADD2=" + CuramConst.gkNewLine;    
      // END, CR00345882
      
    } else {

      // BEGIN, CR00099876, SD
      // Check if the county field is included in the US address format

      // BEGIN, CR00113430, ELG
      if (Configuration.getBooleanProperty(EnvVars.ENV_USADDRESSWITHCOUNTY,
        Configuration.getBooleanProperty(
        EnvVars.ENV_USADDRESSWITHCOUNTY_DEFAULT))) {
        // END, CR00113430
        otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "US" + CuramConst.gkNewLine + "US"
          + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "ZIP=" + CuramConst.gkNewLine + "ADD3="
          + CuramConst.gkNewLine + "USCOUNTY=" + CuramConst.gkNewLine + "ADD2="
          + noAddress + CuramConst.gkNewLine + "CITY=" + CuramConst.gkNewLine
          + "ADD1=" + CuramConst.gkNewLine + "STATE=" + CuramConst.gkNewLine;

      } else {

        // Default US address data
        otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "US" + CuramConst.gkNewLine + "US"
          + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "ZIP=" + CuramConst.gkNewLine + "ADD3="
          + CuramConst.gkNewLine + "ADD2=" + noAddress + CuramConst.gkNewLine
          + "CITY=" + CuramConst.gkNewLine + "ADD1=" + CuramConst.gkNewLine
          + "STATE=" + CuramConst.gkNewLine;
      }
      // END, CR00099876
      // END, CR00190258
      // END, CR00277220
    }
    return otherAddressData;
  }

  // END, CR00214655


  // BEGIN, CR00103736, ELG
  // ___________________________________________________________________________
  /**
   * This method returns an address data stream which contains default address
   * information for the address layout type specified. If address layout
   * type is unspecified or not recognized, then its default values are
   * retrieved from the system environment.
   *
   * @param key Contains address layout information.
   * @return Address data string.
   */
  public OtherAddressData getDefaultAddressDataForLayout(LayoutKey key)
    throws AppException, InformationalException {

    // return structure
    OtherAddressData otherAddressData = new OtherAddressData();

    // BEGIN, CR00190258, CL
    // BEGIN, CR00214655, PB
    // BEGIN, CR00222190, ELG
    // BEGIN, CR00340652, KRK
    final String noAddress = BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(
      TransactionInfo.getProgramLocale());

    // END, CR00340652
    // END, CR00222190
    // END, CR00214655
    // END, CR00190258

    if (ADDRESSLAYOUTTYPE.US.equals(key.addressLayoutType)) {

      // BEGIN, CR00190258, CL
      // BEGIN, CR00113430, ELG
      if (curam.util.resources.Configuration.getBooleanProperty(
        EnvVars.ENV_USADDRESSWITHCOUNTY,
        curam.util.resources.Configuration.getBooleanProperty(
          EnvVars.ENV_USADDRESSWITHCOUNTY_DEFAULT))) {

        // BEGIN, CR00277220, ELG
        otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "US" + CuramConst.gkNewLine + "US"
          + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "ZIP=" + CuramConst.gkNewLine + "ADD3="
          + CuramConst.gkNewLine + "USCOUNTY=" + CuramConst.gkNewLine + "ADD2="
          + noAddress + CuramConst.gkNewLine + "CITY=" + CuramConst.gkNewLine
          + "ADD1=" + CuramConst.gkNewLine + "STATE=" + CuramConst.gkNewLine;
        ;

      } else {

        otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "US" + CuramConst.gkNewLine + "US"
          + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
          + CuramConst.gkNewLine + "ZIP=" + CuramConst.gkNewLine + "ADD3="
          + CuramConst.gkNewLine + "ADD2=" + noAddress + CuramConst.gkNewLine
          + "CITY=" + CuramConst.gkNewLine + "ADD1=" + CuramConst.gkNewLine
          + "STATE=" + CuramConst.gkNewLine;

      }
      // END, CR00277220
      // END, CR00113430

    } else if (ADDRESSLAYOUTTYPE.UK.equals(key.addressLayoutType)) {

      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "UK" + CuramConst.gkNewLine + "GB"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "ADD1=" + noAddress + CuramConst.gkNewLine
        + "ADD2=" + CuramConst.gkNewLine + "ADD3=" + CuramConst.gkNewLine
        + "ADD4=" + CuramConst.gkNewLine + "ADD5=" + CuramConst.gkNewLine
        + "CITY=" + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine
        + "COUNTRY=" + CuramConst.gkNewLine;
      // BEGIN, CR00199929, SS
    } else if (ADDRESSLAYOUTTYPE.CA.equals(key.addressLayoutType)) {

      // BEGIN, CR00277220, ELG
      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "CA" + CuramConst.gkNewLine + "CA"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine + "APT="
        + CuramConst.gkNewLine + "ADD1=" + noAddress + CuramConst.gkNewLine
        + "CITY=" + noAddress + CuramConst.gkNewLine + "ADD2="
        + CuramConst.gkNewLine + "PROV=" + CuramConst.gkNewLine;
      // END, CR00277220
      // END, CR00199929

    } else if (ADDRESSLAYOUTTYPE.FREEFORM.equals(key.addressLayoutType)) {

      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "FREEFORM" + CuramConst.gkNewLine + "US"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + noAddress + CuramConst.gkNewLine;
      // BEGIN, CR00285272, ZV
    } else if (ADDRESSLAYOUTTYPE.CA_CIVIC.equals(key.addressLayoutType)) {

      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "CACIVIC" + CuramConst.gkNewLine + "CA"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "ADI=" + CuramConst.gkNewLine + "UNITNO=" 
        + CuramConst.gkNewLine + "STRNUMBER=" + CuramConst.gkNewLine 
        + "STRNOSFX=" + CuramConst.gkNewLine + "STRNAME=" + noAddress 
        + CuramConst.gkNewLine + "STRTYPE=" + CuramConst.gkNewLine + "STRDIR=" 
        + CuramConst.gkNewLine + "CITY=" + CuramConst.gkNewLine + "PROV="
        + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine;
      // END, CR00285272

      // BEGIN, CR00345882, SPD
      // Taiwan address format
    } else if (ADDRESSLAYOUTTYPE.TW.equals(key.addressLayoutType)) {
      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "TW" + CuramConst.gkNewLine + "TW"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine + "CITY="
        + CuramConst.gkNewLine + "DISTRICT=" + CuramConst.gkNewLine + "ADD1="
        + noAddress + CuramConst.gkNewLine + "ADD2=" + CuramConst.gkNewLine;
      
      // Chinese address format
    } else if (ADDRESSLAYOUTTYPE.CN.equals(key.addressLayoutType)) {
      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "CN" + CuramConst.gkNewLine + "CN"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine + "PROV="
        + CuramConst.gkNewLine + "CITY=" + CuramConst.gkNewLine + "DISTRICT="
        + CuramConst.gkNewLine + "ADD1=" + noAddress + CuramConst.gkNewLine
        + "ADD2=" + CuramConst.gkNewLine;
      
      // Japan address format
    } else if (ADDRESSLAYOUTTYPE.JP.equals(key.addressLayoutType)) {
      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "JP" + CuramConst.gkNewLine + "JP"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine + "PROV="
        + CuramConst.gkNewLine + "CITY=" + CuramConst.gkNewLine + "ADD1="
        + noAddress + CuramConst.gkNewLine + "ADD2=" + CuramConst.gkNewLine;
      
      // South Korea address format
    } else if (ADDRESSLAYOUTTYPE.KR.equals(key.addressLayoutType)) {
      otherAddressData.addressData = "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "KR" + CuramConst.gkNewLine + "KR"
        + CuramConst.gkNewLine + "1" + CuramConst.gkNewLine + "0"
        + CuramConst.gkNewLine + "POSTCODE=" + CuramConst.gkNewLine + "CITY="
        + CuramConst.gkNewLine + "ADD1=" + noAddress + CuramConst.gkNewLine 
        + "ADD2=" + CuramConst.gkNewLine;  
      // END, CR00345882
        
    } else {
      // BEGIN, CR00214655, PB
      otherAddressData = getAddressDataForLocale(false);
      // END, CR00214655
    }
    // END, CR00190258

    return otherAddressData;

  }

  // END, CR00103736
  // BEGIN, CR00172711, SPD
  // ___________________________________________________________________________
  /**
   * This method validates the selecting of an address. The user can choose to
   * either select an existing address or create a new one.
   *
   * @link BPOADDRESS#ERR_ADDRESS_XFV_NOT_SUPPLIED
   * - An address must be selected or a new address entered.}
   * @link BPOADDRESS#ERR_ADDRESS_XFV_MULTIPLE_ADDRESS
   * - An address must be selected or a new address entered but
   * not both.}
   * @param details Address details to be validated.
   *
   * @throws AppException {
   * @throws AppException {
   */
  public void validateSelectAddress(AddressIDData details)
    throws AppException, InformationalException {

    // Address manipulation variables
    Address addressObj = AddressFactory.newInstance();
    OtherAddressData otherAddressData = new OtherAddressData();

    // Create an informational manager to handle any validations thrown
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Determine if a new address has been entered
    otherAddressData.addressData = details.addressData;
    boolean addressEmpty = addressObj.isEmpty(otherAddressData).emptyInd;

    // Cannot select an address and also create a new address record
    if (!addressEmpty && details.addressID != 0) {

      AppException e = new AppException(
        BPOADDRESS.ERR_ADDRESS_XFV_MULTIPLE_ADDRESS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // BEGIN, CR00180791, SPD
      informationalManager.failOperation();
      // END, CR00180791
    }

    // Address is mandatory.
    if (details.addressID == 0 && addressEmpty) {

      AppException e = new AppException(BPOADDRESS.ERR_ADDRESS_XFV_NOT_SUPPLIED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // BEGIN, CR00180791, SPD
      informationalManager.failOperation();
      // END, CR00180791
    }
  }

  // END, CR00172711

  // BEGIN, CR00222456, ZV
  // ___________________________________________________________________________
  /**
   * Returns address layout for specified or default locale. Method is updated
   * to read locale from property as requirements have changed to support
   * different address layouts for the same locale.
   *
   * @param details Contains locale code.
   *
   * @return address layout code
   */
  public LayoutKey getLayoutForLocale(LocaleStruct details)
    throws AppException, InformationalException {

    LayoutKey layoutKey = new LayoutKey();

    // BEGIN, CR00285272, ZV
    layoutKey.addressLayoutType = Configuration.getProperty(
      EnvVars.ENV_ADDRESS_LAYOUT);
    
    if (layoutKey.addressLayoutType == null 
      || layoutKey.addressLayoutType.length() == 0) {
      layoutKey.addressLayoutType = EnvVars.ENV_ADDRESS_LAYOUT_DEFAULT;
    }
    // END, CR00285272

    return layoutKey;
  }

  // END, CR00222456
  
  // BEGIN, CR00285272, ZV
  /**
   * This method converts a CA Civic address, specified by individual fields, 
   * into an address data stream delimited by line termination characters.
   *
   * @param addressFieldDetails Structure containing individual address strings
   *
   * @return Address data string
   */
  protected OtherAddressData parseCACivicFieldsToData(AddressFieldDetails
    addressFieldDetails) throws AppException, InformationalException {
    OtherAddressData addressData = new OtherAddressData();
    String sModifiableInd = CuramConst.gkEmpty;
    StringBuffer formatBuffer = new StringBuffer();

    if (addressFieldDetails.modifiableInd) {
      sModifiableInd = kOne;
    } else {
      sModifiableInd = CuramConst.gkStringZero;
    }

    // Just to ensure that the StringBuffer formatBuffer has a minimum capacity
    // to fit Canadian address.
    formatBuffer.ensureCapacity(
      CuramConst.gkNewLine.length() * 15 + kEqualsLen * 10 
      + AddressUtil.kWidgetVersion.length()
      + String.valueOf(addressFieldDetails.addressID).length()
      + ADDRESSLAYOUTTYPE.CA_CIVIC.length()
      + addressFieldDetails.countryCode.length() + sModifiableInd.length()
      + String.valueOf(addressFieldDetails.versionNo).length()
      + ADDRESSELEMENTTYPE.ADDITIONAL_DELIVERY_INFORMATION.length()
      + addressFieldDetails.addressLine1.length() - CuramConst.gkOne
      + ADDRESSELEMENTTYPE.UNIT_NUMBER.length()
      + ADDRESSELEMENTTYPE.STREET_NUMBER.length()
      + ADDRESSELEMENTTYPE.STREET_NUMBER_SUFFIX.length()
      + ADDRESSELEMENTTYPE.STREET_NAME.length()
      + addressFieldDetails.addressLine2.length() - CuramConst.gkOne
      + ADDRESSELEMENTTYPE.STREET_TYPE.length()
      + ADDRESSELEMENTTYPE.STREET_DIRECTION.length()
      + ADDRESSELEMENTTYPE.CITY.length() + addressFieldDetails.city.length()
      + ADDRESSELEMENTTYPE.PROVINCE.length()
      + addressFieldDetails.province.length()
      + ADDRESSELEMENTTYPE.POSTCODE.length() 
      + addressFieldDetails.postalCode.length());

    // Creating address header.
    formatBuffer.append(AddressUtil.kWidgetVersion);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.addressID);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSLAYOUTTYPE.CA_CIVIC);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.countryCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(sModifiableInd);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.versionNo);
    formatBuffer.append(CuramConst.gkNewLine);

    // Creating address body.
    String streetNumber = CuramConst.gkEmpty;
    String streetNumberSuffix = CuramConst.gkEmpty;
    
    if (!addressFieldDetails.addressLine1.isEmpty()) {
      
      String streetNumberSuffixCode = CuramConst.gkEmpty;

      int spaceNumberPos = addressFieldDetails.addressLine1.lastIndexOf(
        CuramConst.gkSpace);

      if (spaceNumberPos > CuramConst.gkZero) {
        streetNumber = addressFieldDetails.addressLine1.substring(
          CuramConst.gkZero, spaceNumberPos);
        streetNumberSuffix = addressFieldDetails.addressLine1.substring(
          spaceNumberPos + CuramConst.gkOne);

        // get corresponding street number suffix code from value
        if (!streetNumberSuffix.isEmpty()) {

          java.util.LinkedHashMap<String, String> streetNumberSuffixList = CodeTable.getAllEnabledItems(
            STREETNUMBERSUFFIXTYPE.TABLENAME,
            TransactionInfo.getProgramLocale());
          
          for (Entry<String, String> entry : streetNumberSuffixList.entrySet()) {
            if (entry.getValue().equals(streetNumberSuffix)) {
              streetNumberSuffixCode = entry.getKey();
              break;
            }
          }
        }
      }
      
      if (streetNumberSuffixCode.isEmpty()) {
        streetNumber = addressFieldDetails.addressLine1;
      } else {
        streetNumberSuffix = streetNumberSuffixCode;
      }

    }
    
    String streetName = CuramConst.gkEmpty;
    String streetType = CuramConst.gkEmpty;

    if (!addressFieldDetails.addressLine2.isEmpty()) {
      
      String streetTypeCode = CuramConst.gkEmpty;

      int spaceStreetPos = addressFieldDetails.addressLine2.lastIndexOf(
        CuramConst.gkSpace);
      
      if (spaceStreetPos > CuramConst.gkZero) {
        streetName = addressFieldDetails.addressLine2.substring(
          CuramConst.gkZero, spaceStreetPos);
        streetType = addressFieldDetails.addressLine2.substring(
          spaceStreetPos + CuramConst.gkOne);

        // get corresponding street type code from value
        if (!streetType.isEmpty()) {

          java.util.LinkedHashMap<String, String> streetTypeList = CodeTable.getAllEnabledItems(
            STREETTYPE.TABLENAME, TransactionInfo.getProgramLocale());
          
          for (Entry<String, String> entry : streetTypeList.entrySet()) {
            if (entry.getValue().equals(streetType)) {
              streetTypeCode = entry.getKey();
              break;
            }
          }
        }
      }
      
      if (streetTypeCode.isEmpty()) {
        streetName = addressFieldDetails.addressLine2;
        if (!streetType.isEmpty()) {
          streetType = STREETTYPE.NOT_AVAILABLE;
        }
      } else {
        streetType = streetTypeCode;
      }

    }
    
    formatBuffer.append(ADDRESSELEMENTTYPE.ADDITIONAL_DELIVERY_INFORMATION);
    formatBuffer.append(kEquals);
    formatBuffer.append(CuramConst.gkEmpty);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.UNIT_NUMBER);
    formatBuffer.append(kEquals);
    formatBuffer.append(CuramConst.gkEmpty);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.STREET_NUMBER);
    formatBuffer.append(kEquals);
    formatBuffer.append(streetNumber);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.STREET_NUMBER_SUFFIX);
    formatBuffer.append(kEquals);
    formatBuffer.append(streetNumberSuffix);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.STREET_NAME);
    formatBuffer.append(kEquals);
    formatBuffer.append(streetName);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.STREET_TYPE);
    formatBuffer.append(kEquals);
    formatBuffer.append(streetType);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.STREET_DIRECTION);
    formatBuffer.append(kEquals);
    formatBuffer.append(CuramConst.gkEmpty);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.CITY);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.city);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.PROVINCE);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.province);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.POSTCODE);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.postalCode);

    addressData.addressData = formatBuffer.toString();

    return addressData;
  }

  // END, CR00285272

  // BEGIN, CR00345882, SPD
  // ___________________________________________________________________________
  /**
   * This method converts a Traditional Chinese (zh_TW) address, specified by
   * individual fields, into an address data stream delimited by line
   * termination characters.
   *
   * @param addressFieldDetails Structure containing individual address strings
   *
   * @return Address data string
   */
  @Override
  protected OtherAddressData parseTWFieldsToData(
    AddressFieldDetails addressFieldDetails) 
    throws AppException, InformationalException {
    
    OtherAddressData addressData = new OtherAddressData();
    String sModifiableInd = CuramConst.gkEmpty;
    StringBuffer formatBuffer = new StringBuffer();

    if (addressFieldDetails.modifiableInd) {
      sModifiableInd = kOne;
    } else {
      sModifiableInd = CuramConst.gkStringZero;
    }

    // Just to ensure that the StringBuffer formatBuffer has a minimum capacity
    // to fit the address.
    formatBuffer.ensureCapacity(
      CuramConst.gkNewLine.length() * 10 + kEqualsLen * 5 
      + AddressUtil.kWidgetVersion.length()
      + String.valueOf(addressFieldDetails.addressID).length()
      + ADDRESSLAYOUTTYPE.TW.length()
      + addressFieldDetails.countryCode.length() + sModifiableInd.length()
      + String.valueOf(addressFieldDetails.versionNo).length()
      + ADDRESSELEMENTTYPE.POSTCODE.length()
      + addressFieldDetails.postalCode.length()
      + ADDRESSELEMENTTYPE.CITY.length() + addressFieldDetails.city.length()
      + ADDRESSELEMENTTYPE.DISTRICT.length()
      + addressFieldDetails.addressLine3.length()
      + ADDRESSELEMENTTYPE.LINE1.length()
      + addressFieldDetails.addressLine1.length()
      + ADDRESSELEMENTTYPE.LINE2.length()
      + addressFieldDetails.addressLine2.length());
      
    // Creating address header.
    formatBuffer.append(AddressUtil.kWidgetVersion);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.addressID);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSLAYOUTTYPE.TW);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.countryCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(sModifiableInd);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.versionNo);
    formatBuffer.append(CuramConst.gkNewLine);

    // Creating address body.
    formatBuffer.append(ADDRESSELEMENTTYPE.POSTCODE);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.postalCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.CITY);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.city);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.DISTRICT);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine3);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.LINE1);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine1);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.LINE2);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine2);
    formatBuffer.append(CuramConst.gkNewLine);

    addressData.addressData = formatBuffer.toString();

    return addressData;    
  }
  
  // ___________________________________________________________________________
  /**
   * This method converts a Simplified Chinese (zh_CN) address, specified by
   * individual fields, into an address data stream delimited by line
   * termination characters.
   *
   * @param addressFieldDetails Structure containing individual address strings
   *
   * @return Address data string
   */
  @Override
  public OtherAddressData parseCNFieldsToData(AddressFieldDetails addressFieldDetails)
    throws AppException, InformationalException {

    OtherAddressData addressData = new OtherAddressData();
    String sModifiableInd = CuramConst.gkEmpty;
    StringBuffer formatBuffer = new StringBuffer();

    if (addressFieldDetails.modifiableInd) {
      sModifiableInd = kOne;
    } else {
      sModifiableInd = CuramConst.gkStringZero;
    }

    // Just to ensure that the StringBuffer formatBuffer has a minimum capacity
    // to fit the address.
    formatBuffer.ensureCapacity(
      CuramConst.gkNewLine.length() * 11 + kEqualsLen * 6 
      + AddressUtil.kWidgetVersion.length()
      + String.valueOf(addressFieldDetails.addressID).length()
      + ADDRESSLAYOUTTYPE.CN.length()
      + addressFieldDetails.countryCode.length() + sModifiableInd.length()
      + String.valueOf(addressFieldDetails.versionNo).length()
      + ADDRESSELEMENTTYPE.POSTCODE.length()
      + addressFieldDetails.postalCode.length()
      + ADDRESSELEMENTTYPE.PROVINCE.length()
      + addressFieldDetails.province.length()
      + ADDRESSELEMENTTYPE.CITY.length() + addressFieldDetails.city.length()
      + ADDRESSELEMENTTYPE.DISTRICT.length()
      + addressFieldDetails.addressLine3.length()
      + ADDRESSELEMENTTYPE.LINE1.length()
      + addressFieldDetails.addressLine1.length()
      + ADDRESSELEMENTTYPE.LINE2.length()
      + addressFieldDetails.addressLine2.length());
      
    // Creating address header.
    formatBuffer.append(AddressUtil.kWidgetVersion);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.addressID);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSLAYOUTTYPE.CN);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.countryCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(sModifiableInd);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.versionNo);
    formatBuffer.append(CuramConst.gkNewLine);

    // Creating address body.
    formatBuffer.append(ADDRESSELEMENTTYPE.POSTCODE);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.postalCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.PROVINCE);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.province);
    formatBuffer.append(CuramConst.gkNewLine);    
    formatBuffer.append(ADDRESSELEMENTTYPE.CITY);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.city);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.DISTRICT);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine3);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.LINE1);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine1);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.LINE2);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine2);
    formatBuffer.append(CuramConst.gkNewLine);

    addressData.addressData = formatBuffer.toString();

    return addressData;   
  }

  // ___________________________________________________________________________
  /**
   * This method converts a Japanese (JP) address, specified by
   * individual fields, into an address data stream delimited by line
   * termination characters.
   *
   * @param addressFieldDetails Structure containing individual address strings
   *
   * @return Address data string
   */
  @Override
  protected OtherAddressData parseJPFieldsToData(
    AddressFieldDetails addressFieldDetails) 
    throws AppException, InformationalException {
    
    OtherAddressData addressData = new OtherAddressData();
    String sModifiableInd = CuramConst.gkEmpty;
    StringBuffer formatBuffer = new StringBuffer();

    if (addressFieldDetails.modifiableInd) {
      sModifiableInd = kOne;
    } else {
      sModifiableInd = CuramConst.gkStringZero;
    }

    // Just to ensure that the StringBuffer formatBuffer has a minimum capacity
    // the address.
    formatBuffer.ensureCapacity(
      CuramConst.gkNewLine.length() * 10 + kEqualsLen * 5 
      + AddressUtil.kWidgetVersion.length()
      + String.valueOf(addressFieldDetails.addressID).length()
      + ADDRESSLAYOUTTYPE.JP.length()
      + addressFieldDetails.countryCode.length() + sModifiableInd.length()
      + String.valueOf(addressFieldDetails.versionNo).length()
      + ADDRESSELEMENTTYPE.POSTCODE.length()
      + addressFieldDetails.postalCode.length()
      + ADDRESSELEMENTTYPE.PROVINCE.length()
      + addressFieldDetails.province.length()
      + ADDRESSELEMENTTYPE.CITY.length() + addressFieldDetails.city.length()
      + ADDRESSELEMENTTYPE.LINE1.length()
      + addressFieldDetails.addressLine1.length()
      + ADDRESSELEMENTTYPE.LINE2.length()
      + addressFieldDetails.addressLine2.length());
      
    // Creating address header.
    formatBuffer.append(AddressUtil.kWidgetVersion);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.addressID);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSLAYOUTTYPE.JP);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.countryCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(sModifiableInd);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.versionNo);
    formatBuffer.append(CuramConst.gkNewLine);

    // Creating address body.
    formatBuffer.append(ADDRESSELEMENTTYPE.POSTCODE);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.postalCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.PROVINCE);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.province);
    formatBuffer.append(CuramConst.gkNewLine);    
    formatBuffer.append(ADDRESSELEMENTTYPE.CITY);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.city);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.LINE1);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine1);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.LINE2);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine2);
    formatBuffer.append(CuramConst.gkNewLine);

    addressData.addressData = formatBuffer.toString();

    return addressData;       
  }

  // ___________________________________________________________________________
  /**
   * This method converts a South Korean (KR) address, specified by
   * individual fields, into an address data stream delimited by line
   * termination characters.
   *
   * @param addressFieldDetails Structure containing individual address strings
   *
   * @return Address data string
   */
  @Override
  protected OtherAddressData parseKRFieldsToData(
    AddressFieldDetails addressFieldDetails) 
    throws AppException, InformationalException {
    
    OtherAddressData addressData = new OtherAddressData();
    String sModifiableInd = CuramConst.gkEmpty;
    StringBuffer formatBuffer = new StringBuffer();

    if (addressFieldDetails.modifiableInd) {
      sModifiableInd = kOne;
    } else {
      sModifiableInd = CuramConst.gkStringZero;
    }

    // Just to ensure that the StringBuffer formatBuffer has a minimum capacity
    // the address.
    formatBuffer.ensureCapacity(
      CuramConst.gkNewLine.length() * 9 + kEqualsLen * 4 
      + AddressUtil.kWidgetVersion.length()
      + String.valueOf(addressFieldDetails.addressID).length()
      + ADDRESSLAYOUTTYPE.KR.length()
      + addressFieldDetails.countryCode.length() + sModifiableInd.length()
      + String.valueOf(addressFieldDetails.versionNo).length()
      + ADDRESSELEMENTTYPE.POSTCODE.length()
      + addressFieldDetails.postalCode.length()
      + ADDRESSELEMENTTYPE.CITY.length() + addressFieldDetails.city.length()
      + ADDRESSELEMENTTYPE.LINE1.length()
      + addressFieldDetails.addressLine1.length()
      + ADDRESSELEMENTTYPE.LINE2.length()
      + addressFieldDetails.addressLine2.length());
      
    // Creating address header.
    formatBuffer.append(AddressUtil.kWidgetVersion);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.addressID);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSLAYOUTTYPE.KR);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.countryCode);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(sModifiableInd);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(addressFieldDetails.versionNo);
    formatBuffer.append(CuramConst.gkNewLine);

    // Creating address body.
    formatBuffer.append(ADDRESSELEMENTTYPE.POSTCODE);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.postalCode);
    formatBuffer.append(CuramConst.gkNewLine);    
    formatBuffer.append(ADDRESSELEMENTTYPE.CITY);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.city);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.LINE1);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine1);
    formatBuffer.append(CuramConst.gkNewLine);
    formatBuffer.append(ADDRESSELEMENTTYPE.LINE2);
    formatBuffer.append(kEquals);
    formatBuffer.append(addressFieldDetails.addressLine2);
    formatBuffer.append(CuramConst.gkNewLine);

    addressData.addressData = formatBuffer.toString();

    return addressData;    
  }

  // END, CR00345882
  
  // BEGIN, CR00368946, GA
  /**
   * Parses an address data string delimited by line termination
   * characters and returns a list of <name> = <value> pairs derived from the
   * address information. The address must not be a free form address. 
   * The names will be delimited by the pipe delimiter.
   *
   * @param addressData Structure containing address data string
   *
   * @return A list of <name> = <value> pairs
   */
  public AddressMapList parseDataToMapWithDelimiter(final OtherAddressData addressData)
    throws AppException, InformationalException {

    final AddressMapList addressMapList = new AddressMapList();

    final AddressLineList addressLineList;
    int i, addressStringLength, position, lineNo;
    AddressMap addressMap;

    addressLineList = newlineText2List(addressData);

    if (addressLineList.dtls.size() > AddressUtil.kAddressHeaderLineCount) {

      i = 0;

      // Points to the list element 3.
      i += AddressUtil.AddressDataLineIndex.I_ADDRESS_LAYOUT_TYPE;

      if (!ADDRESSLAYOUTTYPE.FREEFORM.equals(
        addressLineList.dtls.item(i).addressString)) {

        // Copy all lines in the list from the line 7 onwards
        // into addressMapList.
        for (i = AddressUtil.AddressDataLineIndex.I_ADDRESS_LINE_1, lineNo = 1; i
          < addressLineList.dtls.size(); i++, lineNo++) {

          addressStringLength = (addressLineList.dtls.item(i).addressString).length();

          if (0 < addressStringLength) {
   
            position = (addressLineList.dtls.item(i).addressString.indexOf(
              kEquals, 0));

            if (0 < position) {

              addressMap = new AddressMap();
              addressMap.name = (addressLineList.dtls.item(i).addressString).substring(
                0, position)
                  + CuramConst.gkPipeDelimiter;

              if (position + 1 < addressStringLength) {
                addressMap.value = (addressLineList.dtls.item(i).addressString).substring(
                  position + 1, addressStringLength);
              } else { 

                // Position points on the last element so there are
                // no elements left in the addressString.

                addressMap.value = CuramConst.gkEmpty;
              }

              addressMapList.dtls.addRef(addressMap);

            } else {

              if (0 == position) { // <name> tag is blank.

                AppException e = new AppException(
                  BPOADDRESSDATA.ERR_ADDRESSDATA_FV_NO_NAME);

                e.arg(lineNo);
                ValidationManagerFactory.getManager().throwWithLookup(e,
                  ValidationManagerConst.kSetOne, 0);
              } else {
                AppException e = new AppException(
                  BPOADDRESSDATA.ERR_ADDRESSDATA_FV_ADDRESS_LINE_FORMAT);

                e.arg(lineNo);
                ValidationManagerFactory.getManager().throwWithLookup(e,
                  ValidationManagerConst.kSetOne, 0);
              }

            }

          }

        }

      } else {

        ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOADDRESSDATA.ERR_ADDRESSDATA_FREEFORM),
          ValidationManagerConst.kSetOne, 0);
      }

    }

    return addressMapList;
  }
  // END, CR00368946
  
}
