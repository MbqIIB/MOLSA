/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.codetable.TASKDEADLINEDUE;
import curam.core.hook.task.impl.SearchTask;
import curam.core.hook.task.impl.SearchTaskSQL;
import curam.core.hook.task.impl.SearchTaskUtilities;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.impl.TaskSort;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.ReadMultiOperationDetails;
import curam.core.sl.struct.SQLStatement;
import curam.core.sl.struct.TaskQueryCriteria;
import curam.core.sl.struct.TaskQueryResultDetailsList;
import curam.core.sl.struct.TaskSearchKey;
import curam.core.sl.struct.TaskSearchResult;
import curam.core.struct.Count;
import curam.core.struct.OrganisationObjectDetails;
import curam.core.struct.UsersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.DateTime;


/**
 * This class contains the methods required to search for tasks using SQL,
 * there are three types of task search functionality:
 * <ul>
 * <li>Saved Task Query
 * (see {@link #curam.core.facade.impl.TaskQuery TaskQuery})</li>
 * <li>Available Task Search
 * (see {@link #curam.core.facade.impl.Inbox.searchAvailableTasks()
 * searchAvailableTasks})</li>
 * <li>Task Search
 * (see {@link #curam.core.facade.impl.Inbox.searchTask()
 * searchTask})</li>
 * </ul>
 *
 * @deprecated Since Curam 6.0 SP1, this class has been replaced by {@link 
 * curam.core.hook.task.impl.SearchTask}. See release note CR00222551.
 */
@Deprecated
public abstract class DatabaseTaskSearch extends curam.core.base.DatabaseTaskSearch {

  /**
   * The task sort comparator.
   */
  @Inject
  protected TaskSort taskSort;

  /**
   * The task search SQL hook interface.
   */
  @Inject
  protected SearchTaskSQL searchTaskSQLHook;

  /**
   * The task search SQL hook interface.
   */
  @Inject
  protected SearchTask searchTaskHook;

  public DatabaseTaskSearch() {
    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Method to perform a task search
   *
   * @param key The search criteria, which can be the task ID,
   * priority, status or reserved by.
   *
   * @return The task records the satisfy the search criteria
   *
   * @deprecated Since Curam 6.0. This method has been replaced by
   * {@link #searchTask(TaskQueryCriteria)}. The
   * task search functionality has been enhanced for Curam 6.0 therefore this
   * method is no longer used. See release note CR00221722.
   */
  @Deprecated
  public TaskSearchResult taskSearch(TaskSearchKey key)
    throws AppException, InformationalException {

    // Check if any search criteria has been specified
    if (key.key.taskID == 0 && key.key.priority.length() == 0
      && key.key.reservedBy.length() == 0 && key.key.status.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOWORKALLOCATION.ERR_WORK_ALLOCATION_XFV_SPECIFY_SEARCH_CRITERIA),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Create return object
    TaskSearchResult taskSearchResultRet = new TaskSearchResult();

    // Task manipulation variables
    curam.core.sl.entity.intf.Task_wa task_waObj = curam.core.sl.entity.fact.Task_waFactory.newInstance();
    curam.core.sl.entity.struct.TaskSearchDetailsList taskSearchDetailsList;
    curam.core.sl.entity.struct.TaskSearchResult taskSearchResult;

    // Call entity operation to search for tasks
    taskSearchDetailsList = task_waObj.search(key.key);

    // Check if any tasks have been returned from the search
    if (taskSearchDetailsList.dtls.isEmpty()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOWORKALLOCATION.INF_WORK_ALLOCATION_NO_MATCH_FOUND),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    } else {

      // Users manipulation variables
      UserAccess userAccessObj = UserAccessFactory.newInstance();
      UsersKey usersKey = new UsersKey();

      for (int i = 0; i < taskSearchDetailsList.dtls.size(); i++) {

        taskSearchResult = new curam.core.sl.entity.struct.TaskSearchResult();

        // Assign task details
        taskSearchResult.assign(taskSearchDetailsList.dtls.item(i));

        // Need to retrieve the full name of the reservedBy user
        if (taskSearchResult.reservedBy.length() > 0) {

          // Set key to read user full name
          usersKey.userName = taskSearchResult.reservedBy;

          // Read the reservedBy user's full name
          taskSearchResult.reservedByFullName = userAccessObj.getFullName(usersKey).fullname;
        }

        // Add details to return object
        taskSearchResultRet.dtls.addRef(taskSearchResult);
      }

    }
    return taskSearchResultRet;
  }

  // ___________________________________________________________________________
  /**
   * Search for tasks using the specified search criteria. By default the
   * returned tasks are ordered deadline time in ascending order using the sort
   * class {@link curam.core.sl.impl.TaskSortByDeadlineAscending
   * TaskSortByDeadlineAscending}. This can be changed by using Guice to bind
   * {@link curam.core.sl.impl.TaskSort TaskSort} to another sort class.
   * For further information on search criteria see
   * {@link #curam.core.sl.impl.TaskQuery TaskQuery}.
   * This method limits the number of tasks that are returned to the client.
   *
   * @param key The search criteria.
   * @param readMultiDetails Specifies the maximum size of the return list.
   * If the number of records exceeds the specified maximum value then an
   * information message is displayed
   * ({@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED
   * INF_READMULTI_MAX_EXCEEDED}) informing the user that more records exist.
   *
   * @return A list of tasks satisfying the search criteria.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#searchTask(
   * TaskQueryCriteria, ReadMultiOperationDetails)}. 
   * See release note CR00222551.
   */
  @Deprecated
  public TaskQueryResultDetailsList searchTask(
    TaskQueryCriteria key, ReadMultiOperationDetails readMultiDetails)
    throws AppException, InformationalException {
    return SearchTaskUtilities.searchTask(key, readMultiDetails);
  }

  /**
   * Sets the assignee search criteria for the current search when searching by
   * organization object.
   * @param key The search criteria
   * @param orgObject The organization object details to be searched
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#setAssigneeCriteria(
   * TaskQueryCriteria, curam.core.struct.OrganisationObjectDetails)}. 
   * See release note CR00222551.
   */
  @Deprecated
  protected void setAssigneeCriteria(
    TaskQueryCriteria key, OrganisationObjectDetails orgObject) {
    SearchTaskUtilities.setAssigneeCriteria(key, orgObject);
  }
    
  /**
   * Get the organization objects selected by the user. The objects selected are
   * converted from a tab delimited string into a list of structs. 
   * @param key The query criteria
   * @return A list of selected organization objects. If organization object is 
   * not part of the search then this method returns a list containing a single 
   * uninitialized organization object struct.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#getSelectedOrgObjects(
   * TaskQueryCriteria)}. 
   * See release note CR00222551.
   */
  @Deprecated
  protected List<OrganisationObjectDetails> getSelectedOrgObjects(
    TaskQueryCriteria key) throws AppException, InformationalException {
    return SearchTaskUtilities.getSelectedOrgObjects(key);
  }
  
  // ___________________________________________________________________________
  /**
   * Converts the a tab delimited string of organization objects to a list of 
   * organization object details. The format of the tabbed delimited string is 
   * "OrgObjectType|OrgObjectID    OrgObjectType|OrgObjectID" where each type
   * and ID pair is separated by the pipe character
   * e.g. "RL9|userName    RL21|15    RL20|25"
   *
   * @return A list of organization object details.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#convertTabListToOrgObjectList(
   * String)}. 
   * See release note CR00222551.
   */
  @Deprecated
  protected List<OrganisationObjectDetails> convertTabListToOrgObjectList(
    String tabList) throws AppException, InformationalException {
    return SearchTaskUtilities.convertTabListToOrgObjectList(tabList);
  }

  /**
   * Indicates whether the specified date time is in the past or not.
   * @param dateTime A date time.
   * @return true if the specified date time is in the past, false otherwise.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#isOverdue(DateTime)}. 
   * See release note CR00222551.
   */
  @Deprecated
  protected boolean isOverdue(DateTime dateTime) {
    return SearchTaskUtilities.isOverdue(dateTime);
  }
  
  // ___________________________________________________________________________
  /**
   * Counts the tasks satisfying the specified search criteria.
   *
   * @param criteria The search criteria.
   *
   * @return The number of tasks satisfying the search criteria.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTask#countTasks(TaskQueryCriteria)}. 
   * See release note CR00222551.
   */
  @Deprecated
  public Count countTasks(TaskQueryCriteria key)
    throws AppException, InformationalException {
    return searchTaskHook.countTasks(key);
  }

  // ____________________________________________________________________________
  /**
   * This method generates the Available task SQL for the organization objects
   * selected by the user. An organizational object can be an organizational
   * unit, position or job that the current user is a member of, a work queue
   * that the user is subscribed to.
   *
   * @param whereClause The where clause to append the SQL to
   * @param addAndClause Indicated whether a SQL AND clause should be added
   * @param criteria The search criteria
   *
   * @return boolean Indicates whether SQL was appended to the specified where
   * clause parameter.
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getOrgObjectSQL(
   * TaskQueryCriteria)}. See release note CR00222551.
   */
  @Deprecated
  protected boolean getOrgObjectSQL(StringBuffer whereClause,
    boolean addAndClause, TaskQueryCriteria criteria) 
    throws AppException, InformationalException {
    int startLength = whereClause.length();
    
    whereClause.append(searchTaskSQLHook.getOrgObjectSQL(criteria));

    boolean sqlAdded = false;

    if (startLength != whereClause.length()) {
      sqlAdded = true;
    }
    return sqlAdded;
  }

  // ____________________________________________________________________________
  /**
   * This method generates the available task SQL for the status selected by
   * the user.
   *
   * @param whereClause The where clause to append the SQL to
   * @param addAndClause Indicated whether a SQL AND clause should be added
   * @param criteria The search criteria
   *
   * @return boolean Indicates whether SQL was appended to the specified where
   * clause parameter.
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getStatusSQL(
   * TaskQueryCriteria)}. See release note CR00222551.
   */
  @Deprecated
  protected boolean getStatusSQL(StringBuffer whereClause,
    boolean addAndClause, TaskQueryCriteria criteria) 
    throws AppException, InformationalException {

    int startLength = whereClause.length();
    
    whereClause.append(searchTaskSQLHook.getStatusSQL(criteria));

    boolean sqlAdded = false;

    if (startLength != whereClause.length()) {
      sqlAdded = true;
    }
    return sqlAdded;
  }

  // ____________________________________________________________________________
  /**
   * This method generates the task ID SQL for the task by searched for.
   *
   * @param whereClause The where clause to append the SQL to
   * @param addAndClause Indicated whether a SQL AND clause should be added
   * @param criteria The search criteria
   *
   * @return boolean Indicates whether SQL was appended to the specified where
   * clause parameter.
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getTaskIDSQL(
   * TaskQueryCriteria)}. See release note CR00222551.
   */
  @Deprecated
  protected boolean getTaskIDSQL(StringBuffer whereClause,
    boolean addAndClause, TaskQueryCriteria criteria) 
    throws AppException, InformationalException {
    int startLength = whereClause.length();

    whereClause.append(searchTaskSQLHook.getTaskIDSQL(criteria));
    
    boolean sqlAdded = false;

    if (startLength != whereClause.length()) {
      sqlAdded = true;
    }
    return sqlAdded;
  }

  // ____________________________________________________________________________
  /**
   * This method generates the reserved by SQL for the status selected by
   * the user. If the search is the available task search then reserved by must 
   * be null. If the search is the task query then reserved by can either be the 
   * current user or null.
   *
   * @param whereClause The where clause to append the SQL to
   * @param addAndClause Indicated whether a SQL AND clause should be added
   * @param criteria The search criteria
   *
   * @return boolean Indicates whether SQL was appended to the specified where
   * clause parameter.
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getReservedBySQL(
   * TaskQueryCriteria)}. See release note CR00222551.
   */
  @Deprecated
  protected boolean getReservedSQL(StringBuffer whereClause,
    boolean addAndClause, TaskQueryCriteria criteria) 
    throws AppException, InformationalException {
    int startLength = whereClause.length();

    whereClause.append(searchTaskSQLHook.getReservedBySQL(criteria));
    
    boolean sqlAdded = false;

    if (startLength != whereClause.length()) {
      sqlAdded = true;
    }
    return sqlAdded;
  }
  
  // ____________________________________________________________________________
  /**
   * This method generates the available task SQL for the priorities
   * selected by the user.
   *
   * @param whereClause The where clause to append the SQL to
   * @param addAndClause Indicated whether a SQL AND clause should be added
   * @param criteria The search criteria.
   *
   * @return boolean Indicates whether SQL was appended to the specified where
   * clause parameter.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getPrioritySQL(
   * TaskQueryCriteria)}. See release note CR00222551.
   */
  @Deprecated
  protected boolean getPrioritySQL(StringBuffer whereClause,
    boolean addAndClause, TaskQueryCriteria criteria) 
    throws AppException, InformationalException {

    int startLength = whereClause.length();

    whereClause.append(searchTaskSQLHook.getPrioritySQL(criteria));

    boolean sqlAdded = false;

    if (startLength != whereClause.length()) {
      sqlAdded = true;
    }
    return sqlAdded;
  }

  // ____________________________________________________________________________
  /**
   * Indicates whether to append a SQL OR clause in the deadline due SQL.
   * Because tasks due this month and tasks due this week covers tasks due 
   * today. We don't include any SQL clause in the query that is covered by
   * another, therefore we need to look ahead in the SQL process to see if an
   * OR clause needs to be added when looping through the deadline due codes
   * selected by the user.
   *
   * @param nextDeadlineDueCode The task deadline due code table value
   * @param selectedDeadlines A tabbed delimited list of selected task deadline
   * due code values.
   *
   * @return true if an OR clause is to be appended, false otherwise.
   *
   * @deprecated Since Curam 6.0 SP1, this method is no longer used. See 
   * release note CR00222551.
   */
  @Deprecated
  protected boolean appendOrClauseInDeadlineDueSQL(
    String nextDeadlineDueCode, String selectedDeadlines) {

    boolean answer = true;

    if (nextDeadlineDueCode.equals(TASKDEADLINEDUE.DUETODAY)
      && (selectedDeadlines.contains(TASKDEADLINEDUE.DUETHISMONTH)
        || selectedDeadlines.contains(TASKDEADLINEDUE.DUETHISWEEK))) {
      answer = false;
    }
    return answer;
  }

  /**
   * This method generates the task SQL for the deadlines.
   *
   * @param key The criteria entered by the user.
   *
   * @param whereClause The where clause to append the SQL to
   * @param addAndClause Indicated whether a SQL AND clause should be added
   * @return boolean Indicates whether SQL was appended to the specified where
   * clause parameter.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getDeadlineSQL(
   * TaskQueryCriteria)}. See release note CR00222551.
   */
  @Deprecated
  protected boolean getDeadlineSQL(StringBuffer whereClause,
    boolean addAndClause, TaskQueryCriteria criteria) 
    throws AppException, InformationalException {

    int startLength = whereClause.length();

    whereClause.append(searchTaskSQLHook.getDeadlineSQL(criteria));

    boolean sqlAdded = false;

    if (startLength != whereClause.length()) {
      sqlAdded = true;
    }
    return sqlAdded;
  }

  // ____________________________________________________________________________
  /**
   * This method generates the task query SQL for the creation dates selected
   * by the user.
   *
   * @param whereClause The where clause to append the SQL to
   * @param addAndClause Indicated whether a SQL AND clause should be added
   * @param key The criteria entered by the user.
   *
   * @return boolean Indicates whether SQL was appended to the specified where
   * clause parameter.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getCreationDateSQL(
   * TaskQueryCriteria)}. See release note CR00222551.
   */
  @Deprecated
  protected boolean getTaskQueryCreationSQL(
    StringBuffer whereClause, boolean addAndClause, TaskQueryCriteria key) 
    throws AppException, InformationalException {
    int startLength = whereClause.length();

    whereClause.append(searchTaskSQLHook.getCreationDateSQL(key));

    boolean sqlAdded = false;

    if (startLength != whereClause.length()) {
      sqlAdded = true;
    }
    return sqlAdded;
  }

  // ____________________________________________________________________________
  /**
   * This method generates the task query SQL for the restart dates selected
   * by the user.
   *
   * @param whereClause The where clause to append the SQL to
   * @param addAndClause Indicated whether a SQL AND clause should be added
   * @param key The criteria entered by the user.
   *
   * @return boolean Indicates whether SQL was appended to the specified where
   * clause parameter.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getRestartDateSQL(
   * TaskQueryCriteria)}. See release note CR00222551.
   */
  @Deprecated
  protected boolean getTaskQueryRestartSQL(
    StringBuffer whereClause, boolean addAndClause, TaskQueryCriteria key) 
    throws AppException, InformationalException {
    int startLength = whereClause.length();

    whereClause.append(searchTaskSQLHook.getRestartDateSQL(key));
    boolean sqlAdded = false;

    if (startLength != whereClause.length()) {
      sqlAdded = true;
    }
    return sqlAdded;
  }

  // ____________________________________________________________________________
  /**
   * This method dynamically creates a database SQL query based on the task
   * search criteria for the task query. If the specified criteria does not
   * contains a query name then the available task search SQL query will be
   * generated, otherwise a generic task query will be generated.
   *
   * @param criteria The search criteria
   *
   * @return A SQL string to use as the search query.
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getSQLStatement(
   * TaskQueryCriteria)}. See release note CR00222551.
   */
  @Deprecated
  public SQLStatement getSQLStatement(TaskQueryCriteria criteria)
    throws AppException, InformationalException {
    SQLStatement sqlStatement = new SQLStatement();

    sqlStatement.sqlStatement = searchTaskSQLHook.getSQLStatement(criteria);
    return sqlStatement;
  }

  // ____________________________________________________________________________
  /**
   * This method dynamically creates a database count SQL statement, to return
   * a count of the number of records that satisfy the specified task search
   * criteria.
   *
   * @param criteria The search criteria
   *
   * @return A SQL string to use as the search query.
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getCountSQLStatement(
   * TaskQueryCriteria)}. See release note CR00222551.
   */
  @Deprecated
  public SQLStatement getCountSQLStatement(TaskQueryCriteria criteria)
    throws AppException, InformationalException {

    SQLStatement sqlStatement = new SQLStatement();

    sqlStatement.sqlStatement = searchTaskSQLHook.getCountSQLStatement(criteria);
    return sqlStatement;
  }

  /**
   * This method dynamically creates the from and where clauses of the database
   * SQL query based on the task search criteria for the task query.
   *
   * @param criteria The search criteria
   *
   * @return A SQL string to use as the SQL body.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by the concatenation of the 
   * return objects of
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getFromClause(
   * TaskQueryCriteria)} and 
   * {@link curam.core.hook.task.impl.SearchTaskSQL#getWhereClause(
   * TaskQueryCriteria)}. See release note CR00222551.
   */
  @Deprecated
  protected String getSQLBody(TaskQueryCriteria criteria) 
    throws AppException, InformationalException {
    return searchTaskSQLHook.getFromClause(criteria) 
      + searchTaskSQLHook.getWhereClause(criteria);
  }

  // ____________________________________________________________________________
  /**
   * Get the first day of next month.
   *
   * @return The first day of next month.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#getFirstDayOfNextMonth()}. 
   * See release note CR00222551.
   */
  @Deprecated
  protected DateTime getFirstDayOfNextMonth() {
    return SearchTaskUtilities.getFirstDayOfNextMonth();
  }

  // ____________________________________________________________________________
  /**
   * Get the first day of this month.
   *
   * @return The first day of this month.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#getFirstDayOfThisMonth()}. 
   * See release note CR00222551.
   */
  @Deprecated
  protected DateTime getFirstDayOfThisMonth() {
    return SearchTaskUtilities.getFirstDayOfThisMonth();
  }

  // ____________________________________________________________________________
  /**
   * Get the first day of this week.
   *
   * @return The first day of this week.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#getFirstDayOfThisWeek()}. 
   * See release note CR00222551.
   */
  @Deprecated
  protected DateTime getFirstDayOfThisWeek() {
    return SearchTaskUtilities.getFirstDayOfThisWeek();
  }

  // ____________________________________________________________________________
  /**
   * Get the first day of next week.
   *
   * @return The first day of next week.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#getFirstDayOfNextWeek()}. 
   * See release note CR00222551.
   */
  @Deprecated
  protected DateTime getFirstDayOfNextWeek() {
    return SearchTaskUtilities.getFirstDayOfNextWeek();
  }

  // ____________________________________________________________________________
  /**
   * Get midnight tomorrow.
   *
   * @return Midnight tomorrow.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#getMidnightTomorrow()}. 
   * See release note CR00222551.
   */
  @Deprecated
  protected DateTime getMidnightTomorrow() {
    return SearchTaskUtilities.getMidnightTomorrow();
  }

  // ____________________________________________________________________________
  /**
   * Gets the date corresponding to today minus the specified number of days
   * @param numDays The number of days to subtract from today
   * @return The date corresponding to today minus the specified number of days.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#getDaysAgo(int)}. 
   * See release note CR00222551.
   */
  @Deprecated
  protected DateTime getDaysAgo(int numDays) {
    return SearchTaskUtilities.getDaysAgo(numDays);
  }

  // ____________________________________________________________________________
  /**
   * Gets the date corresponding to midnight today minus the specified number
   * of weeks.
   * @param numDays The number of weeks to subtract from midnight today
   * @return The date corresponding to midnight today minus the specified number
   * of weeks.
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link curam.core.hook.task.impl.SearchTaskUtilities#getWeeksAgo(int)}. 
   * See release note CR00222551.
   */
  @Deprecated
  protected DateTime getWeeksAgo(int numWeeks) {
    return SearchTaskUtilities.getWeeksAgo(numWeeks);
  }

  // ____________________________________________________________________________
  /**
   * This method simply determines if we need to append an "AND"
   * clause to the WHERE clause.
   *
   * @param addAndClause Indicates whether to add the SQL "AND" clause
   *
   * @return String Either empty string if the specified boolean parameter is
   * false or " AND" if the parameter is true.
   *
   * @deprecated Since Curam 6.0 SP1, this method is no longer used. See 
   * release note CR00222551.
   */
  @Deprecated
  protected String formatWhereClause(boolean addAndClause) {
    if (!addAndClause) {
      return "";
    } else {
      return " AND ";
    }
  }
}
