/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.generator.impl;


import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.google.inject.Inject;

import curam.caseaudit.entity.struct.AuditPlanCriteriaDtls;
import curam.caseaudit.impl.AuditCaseConfig;
import curam.caseaudit.impl.AuditPlan;
import curam.caseaudit.impl.AuditPlanDAO;
import curam.codetable.CASEDECISIONRESULTCODE;
import curam.codetable.CASESEARCHFILTER;
import curam.codetable.CASESTATUS;
import curam.codetable.GENDER;
import curam.codetable.impl.CASEDECISIONRESULTCODEEntry;
import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.GENDEREntry;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.codetable.impl.SAMPLINGSTRATEGYEntry;
import curam.core.facade.struct.CaseAuditDetails;
import curam.core.facade.struct.CaseLoadDetails;
import curam.core.facade.struct.CaseSampleKey;
import curam.core.facade.struct.NumberAndPercentageOfCases;
import curam.core.fact.LocationFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.Location;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.struct.LocationKey;
import curam.message.BPOAUDITPLANSAMPLECRITERIA;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.samplingstrategy.impl.SamplingStrategy;
import curam.selectionquery.impl.SelectionQuery;
import curam.selectionquery.impl.SelectionQueryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Locale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.StringHelper;
import curam.util.type.StringList;


public class PDCaseAuditGenerator implements CaseAuditGenerator {

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  @Inject
  protected SelectionQueryDAO selectionQueryDAO;

  @Inject
  protected Map<SAMPLINGSTRATEGYEntry, SamplingStrategy> samplingStrategies;

  protected static final String kDateFormat = Locale.defaultDateFormat;
  
  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public PDCaseAuditGenerator() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Generates the sample list of product delivery cases for audit based on the
   * supplied search criteria. This method filters the list using the algorithm
   * associated with the case type for this audit plan. The number of cases
   * returned in the list is also restricted by the number of cases or
   * percentage of cases specified by the user.
   *
   * @param key The search criteria, percentage/number of cases to generate and 
   * any algorithm parameters.
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void generateCaseAudits(final CaseSampleKey key) 
    throws AppException, InformationalException {
  
    AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    
    // In the case of regeneration, remove existing case audits
    auditPlan.clearCaseLoad();
    auditPlan.clearSelectionCriteria();

    if (key.pdDtls.filterOptionList.length() > 0) {

      StringList filterOptionList = StringUtil.tabText2StringListWithTrim(
        key.pdDtls.filterOptionList);

      for (int i = 0; i < filterOptionList.size(); i++) {

        String filterCode = filterOptionList.item(i);

        if (filterCode.equals(CASESEARCHFILTER.APPEALS)) {
          key.pdDtls.searchWithAppeals = true;
          continue;
        }
        if (filterCode.equals(CASESEARCHFILTER.ISSUES)) {
          key.pdDtls.searchWithIssues = true;
          continue;
        }
      }
    }

    AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    key.pdDtls.caseTypeCode = auditCaseConfig.getCaseType().getCode();
    key.pdDtls.category = auditCaseConfig.getCaseCategory().getCode();

    // Run search to get initial case list
    List<curam.piwrapper.caseheader.impl.CaseHeader> caseList = caseHeaderDAO.searchCommonPDCriteria(
      key.pdDtls);

    CaseAuditGeneratorHelper caseAuditGeneratorHelperObj = new CaseAuditGeneratorHelper();
    
    CaseLoadDetails caseLoadDetails = new CaseLoadDetails();

    caseLoadDetails.numberOfCases = key.numberOfCases;
    caseLoadDetails.percentageOfCases = key.percentageOfCases;
    caseLoadDetails.totalCases = caseList.size();
    
    NumberAndPercentageOfCases numberAndPercentageOfCases = caseAuditGeneratorHelperObj.determineNumCasesToProcess(
      caseLoadDetails);

    // Get algorithm to use to generate case sample
    final SamplingStrategy samplingStrategy = samplingStrategies.get(
      auditPlan.getAuditCaseConfig().getAuditAlgorithm());

    List<Long> caseIDList = new ArrayList<Long>();

    for (CaseHeader caseHeader : caseList) {
      caseIDList.add(caseHeader.getID());
    }

    if (key.details.startPoint == 0) {
      key.details.startPoint = new Double(CuramConst.gkOne + Math.random() * numberAndPercentageOfCases.numberOfCases).intValue();            
    }
    
    if (key.details.interval == 0) {
      key.details.interval = Math.round(
        key.totalNumCases / numberAndPercentageOfCases.numberOfCases);
    }

    Map<String, Object> params = new TreeMap<String, Object>();

    params.put(CuramConst.kSystematicSamplingStartIndex,
      new Integer(key.details.startPoint));
    params.put(CuramConst.kSystematicSamplingInterval,
      new Integer(key.details.interval));

    // Call algorithm to generate case sample
    List<Long> caseIDs = samplingStrategy.getRandomSample(caseIDList,
      numberAndPercentageOfCases.numberOfCases, params);

    curam.core.facade.intf.CaseAudit caseAuditObj = curam.core.facade.fact.CaseAuditFactory.newInstance();

    // for each case, create a case audit
    for (int i = 0; i < caseIDs.size(); i++) {

      CaseAuditDetails caseAuditDetails = new CaseAuditDetails();

      caseAuditDetails.dtls.auditPlanID = key.auditPlanID;
      caseAuditDetails.dtls.caseID = caseIDs.get(i);
      caseAuditObj.createCaseAudit(caseAuditDetails);
    }

    // Update audit plan with number/percentage cases and query used
    SelectionQuery selectionQuery = selectionQueryDAO.get(key.selectionQueryID);

    auditPlan.setNumberCases(numberAndPercentageOfCases.numberOfCases);
    auditPlan.setPercentageCases(numberAndPercentageOfCases.percentageOfCases);    
    auditPlan.setSelectionQuery(selectionQuery);
    auditPlan.modify(auditPlan.getVersionNo());

    // Record the criteria entered by the audit coordinator
    recordSelectionCriteria(key);
    
    auditPlan.auditPlanPending(auditPlan.getVersionNo());
    auditPlan.caseSampleListGenerated(); 
  }
  
  // ___________________________________________________________________________
  /**
   * Records the criteria entered by the audit coordinator during PD case sample
   * generation.
   *
   * @param auditPlanKey The unique identifier of the audit plan that the case
   * sample list is being generated for.
   * @param details The criteria entered by the audit coordinator during PD
   * case sample generation.
   */
  public void recordSelectionCriteria(final CaseSampleKey key)
    throws AppException, InformationalException {

    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(kDateFormat);

    curam.core.facade.intf.AuditPlanCriteria auditPlanCriteriaObj = curam.core.facade.fact.AuditPlanCriteriaFactory.newInstance();

    if (!key.pdDtls.startDateFrom.isZero()) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_START_DATE_FROM.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.pdDtls.startDateFrom.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (!key.pdDtls.startDateTo.isZero()) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_START_DATE_TO.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.pdDtls.startDateTo.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (!key.pdDtls.endDateFrom.isZero()) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_END_DATE_FROM.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.pdDtls.endDateFrom.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (!key.pdDtls.endDateTo.isZero()) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_END_DATE_TO.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.pdDtls.endDateTo.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (!key.pdDtls.status.equals(CASESTATUSEntry.NOT_SPECIFIED.getCode())) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_STATUS.getMessageText();
      auditPlanCriteriaDtls.value = CodeTable.getOneItem(CASESTATUS.TABLENAME,
        key.pdDtls.status, TransactionInfo.getProgramLocale());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (key.pdDtls.age > 0) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_AGE.getMessageText();
      auditPlanCriteriaDtls.value = String.valueOf(key.pdDtls.age);
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (!key.pdDtls.gender.equals(GENDEREntry.NOT_SPECIFIED.getCode())) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_GENDER.getMessageText();
      auditPlanCriteriaDtls.value = CodeTable.getOneItem(GENDER.TABLENAME,
        key.pdDtls.gender, TransactionInfo.getProgramLocale());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (key.pdDtls.ownerLocation > 0) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_LOCATION.getMessageText();

      Location locationObj = LocationFactory.newInstance();
      LocationKey locationKey = new LocationKey();

      locationKey.locationID = key.pdDtls.ownerLocation;
      auditPlanCriteriaDtls.value = locationObj.read(locationKey).name;
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (key.pdDtls.searchWithIssues) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_CASES_WITH_ISSUES.getMessageText();
      auditPlanCriteriaDtls.value = String.valueOf(key.pdDtls.searchWithIssues);
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
    if (key.pdDtls.searchWithAppeals) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_CASES_WITH_APPEALS.getMessageText();
      auditPlanCriteriaDtls.value = String.valueOf(key.pdDtls.searchWithAppeals);
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }

    if (!key.pdDtls.certificationFromDate.isZero()) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_CERTIFICATION_DATE_FROM.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.pdDtls.certificationFromDate.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }

    if (!key.pdDtls.certificationToDate.isZero()) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_CERTIFICATION_DATE_TO.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.pdDtls.certificationToDate.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }

    if (!key.pdDtls.timePeriodFromDate.isZero()) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_TIME_PERIOD_FROM.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.pdDtls.timePeriodFromDate.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }

    if (!key.pdDtls.timePeriodToDate.isZero()) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_TIME_PERIOD_TO.getMessageText();
      auditPlanCriteriaDtls.value = simpleDateFormat.format(
        key.pdDtls.timePeriodToDate.getCalendar().getTime());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }

    if (!key.pdDtls.decision.equals(
      CASEDECISIONRESULTCODEEntry.NOT_SPECIFIED.getCode())) {

      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_DECISION.getMessageText();
      auditPlanCriteriaDtls.value = CodeTable.getOneItem(
        CASEDECISIONRESULTCODE.TABLENAME, key.pdDtls.decision,
        TransactionInfo.getProgramLocale());
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }

    if (!StringHelper.isEmpty(key.pdDtls.caseOwner)
      && !key.pdDtls.orgObjectType.equals(
        ORGOBJECTTYPEEntry.NOT_SPECIFIED.getCode())) {
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanID = key.auditPlanID;
      auditPlanCriteriaDtls.name = BPOAUDITPLANSAMPLECRITERIA.CRITERIA_OWNER.getMessageText();

      if (key.pdDtls.orgObjectType.equals(ORGOBJECTTYPEEntry.USER.getCode())) {

        auditPlanCriteriaDtls.value = key.pdDtls.caseOwner;

      } else if (key.pdDtls.orgObjectType.equals(
        ORGOBJECTTYPEEntry.ORGUNIT.getCode())) {

        curam.core.sl.entity.intf.OrganisationUnit organisationUnitObj = curam.core.sl.entity.fact.OrganisationUnitFactory.newInstance();
        OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = Long.parseLong(
          key.pdDtls.caseOwner);
        auditPlanCriteriaDtls.value = organisationUnitObj.read(organisationUnitKey).name;

      } else if (key.pdDtls.orgObjectType.equals(
        ORGOBJECTTYPEEntry.POSITION.getCode())) {

        curam.core.sl.entity.intf.Position positionObj = curam.core.sl.entity.fact.PositionFactory.newInstance();
        PositionKey positionKey = new PositionKey();

        positionKey.positionID = Long.parseLong(key.pdDtls.caseOwner);
        auditPlanCriteriaDtls.value = positionObj.read(positionKey).name;

      } else if (key.pdDtls.orgObjectType.equals(
        ORGOBJECTTYPEEntry.WORKQUEUE.getCode())) {

        curam.core.sl.entity.intf.WorkQueue workQueueObj = curam.core.sl.entity.fact.WorkQueueFactory.newInstance();
        WorkQueueKey workQueueKey = new WorkQueueKey();

        workQueueKey.workQueueID = Long.parseLong(key.pdDtls.caseOwner);
        auditPlanCriteriaDtls.value = workQueueObj.read(workQueueKey).name;
      }
      auditPlanCriteriaObj.createAuditPlanCriteria(auditPlanCriteriaDtls);
    }
  }  
}
