/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2015. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;

import curam.codetable.CASEDECISIONINITREASONCODE;
import curam.codetable.CASEDECISIONSTATUS;
import curam.codetable.FINCOMPONENTCATEGORY;
import curam.codetable.FINCOMPONENTSTATUS;
import curam.codetable.FINCOMPONENTTYPE;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseDecisionFactory;
import curam.core.fact.FinancialComponentFactory;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.infrastructure.assessment.codetable.impl.CASEASSESSMENTDETERMINATIONREASONEntry;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngine;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculator;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculatorFactory;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrection;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.LanguageLocaleMapDetails;
import curam.core.sl.struct.OwnerInd;
import curam.core.sl.struct.ProFormaCommDetails1;
import curam.core.struct.CancelReferralKey;
import curam.core.struct.CaseClosureDtls;
import curam.core.struct.CaseDecisionDtlsList;
import curam.core.struct.CaseEventCaseIDAndTypeKey;
import curam.core.struct.CaseEventDtls;
import curam.core.struct.CaseEventDtlsList;
import curam.core.struct.CaseEventKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseIDStatusInitReasonCodeKey;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseReferralDtls;
import curam.core.struct.CaseReferralKey;
import curam.core.struct.CaseReviewByCaseIDKey;
import curam.core.struct.CaseReviewDtlsList;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseStatusKey;
import curam.core.struct.CloseCaseEventKey;
import curam.core.struct.ClosureDtls;
import curam.core.struct.ConcernRoleDocumentDetails;
import curam.core.struct.ConcernRoleDocumentKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.DetermineEligibilityKey;
import curam.core.struct.FCstatusCodeCaseID;
import curam.core.struct.FinancialComponentDtlsList;
import curam.core.struct.MaintainCaseReviewKey;
import curam.core.struct.ParticipantOrgObjectLinkIDAndCaseRef;
import curam.core.struct.RegenerateCaseFinancialsKey;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UpdateCaseStatusReasonEndKey;
import curam.core.struct.UpdateCaseStatusReasonEndKey1;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.message.GENERALCASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.NotFoundIndicator;


/**
 * Code for closing the case
 *
 */
public abstract class CloseCase extends curam.core.base.CloseCase {

  // BEGIN, CR00211744, VM
  /**
   * Constructor.
   */
  public CloseCase() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected AssessmentEngine assessmentEngine;

  // END, CR00211744

  // BEGIN, CROO211297, CW
  /**
   * Reference to Payment Correction interface.
   */
  @Inject
  protected PaymentCorrection paymentCorrection;

  // END, CROO211297

  // BEGIN, CR00287600, RB
  @Inject
  protected DeterminationCalculatorFactory determinationCalculatorFactory;

  // END, CR00287600

  // ___________________________________________________________________________
  /**
   * close associated records for a case
   *
   * @param dtls
   * contains caseID for the case to be closed
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void closeAssociatedRecords(final ClosureDtls dtls)
    throws AppException, InformationalException {

    // variable to store current date
    final curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // validation - cannot close case with a closure date in the
    // future
    if (dtls.closureDate.after(currentDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCLOSECASE.ERR_CLOSECASE_FV_CLOSUREDATE_LARGE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // CaseEvent manipulation variables
    final curam.core.intf.CaseEvent caseEventObj = curam.core.fact.CaseEventFactory.newInstance();
    final CaseEventCaseIDAndTypeKey caseEventCaseIDAndTypeKey = new CaseEventCaseIDAndTypeKey();
    CaseEventDtlsList caseEventDtlsList;

    // MaintainCaseReferral manipulation variables
    final curam.core.intf.MaintainCaseReferral maintainCaseReferralObj = curam.core.fact.MaintainCaseReferralFactory.newInstance();
    final CancelReferralKey cancelReferralKey = new CancelReferralKey();

    // CaseReferral manipulation variables
    final curam.core.intf.CaseReferral caseReferralObj = curam.core.fact.CaseReferralFactory.newInstance();
    final CaseReferralKey caseReferralKey = new CaseReferralKey();
    CaseReferralDtls caseReferralDtls;

    final curam.core.intf.CachedCaseStatus cachedCaseStatusObj = curam.core.fact.CachedCaseStatusFactory.newInstance();

    // ConcernRoleDocuments manipulation variables
    final ConcernRoleDocumentKey concernRoleDocumentKey = new ConcernRoleDocumentKey();
    final ConcernRoleDocumentDetails concernRoleDocumentDetails = new ConcernRoleDocumentDetails();

    // ProductEligibility manipulation variables
    final DetermineEligibilityKey determineEligibilityKey = new DetermineEligibilityKey();

    final CloseCaseEventKey closeCaseEventKey = new CloseCaseEventKey();

    // XSL templates manipulation variables
    final curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey = new curam.util.xml.struct.XSLTemplateIDCodeKey();

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj = curam.core.sl.fact.CommunicationFactory.newInstance();

    final curam.core.intf.MaintainXSLTemplate maintainXSLTemplateObj = curam.core.fact.MaintainXSLTemplateFactory.newInstance();

    // concernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // read CaseHeader from database
    caseHeaderKey.caseID = dtls.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // key used to perform case status updates
    // BEGIN, CR00220971, ZV
    final UpdateCaseStatusReasonEndKey1 updateCaseStatusReasonEndKey = new UpdateCaseStatusReasonEndKey1();

    // END, CR00220971

    // set new values for case header
    updateCaseStatusReasonEndKey.caseID = dtls.caseID;
    updateCaseStatusReasonEndKey.statusCode = curam.codetable.CASESTATUS.CLOSED;
    // end date for case should be closure date
    updateCaseStatusReasonEndKey.endDate = dtls.closureDate;

    // set values for new case status record
    updateCaseStatusReasonEndKey.startDate = dtls.closureDate;
    updateCaseStatusReasonEndKey.reasonCode = dtls.reasonCode;
    updateCaseStatusReasonEndKey.actualOutcome = dtls.actualOutcome;
    // BEGIN, CR00150402, PDN
    updateCaseStatusReasonEndKey.userName = dtls.userName;
    updateCaseStatusReasonEndKey.comments = dtls.comments;
    // END, CR00150402

    // update case status and create new status record
    // BEGIN, CR00220971, ZV
    updateCaseStatus1(updateCaseStatusReasonEndKey);
    // END, CR00220971

    // BEGIN, CR00102570, CW
    // Update the status mode
    // CaseStatusMode manipulation variables
    final curam.core.sl.intf.CaseStatusMode caseStatusModeObj = curam.core.sl.fact.CaseStatusModeFactory.newInstance();
    final curam.core.sl.struct.CaseStatusModeDetails caseStatusModeDetails = new curam.core.sl.struct.CaseStatusModeDetails();

    caseStatusModeDetails.caseIsBeingClosed = true;
    caseStatusModeObj.setMode(caseStatusModeDetails);
    // END, CR00102570

    // Reassess case
    determineEligibilityKey.caseID = dtls.caseID;

    // BEGIN, CR00239968, VM
    // case should be reassessed from the closure date to the
    // current date
    determineEligibilityKey.toDate = currentDate;
    determineEligibilityKey.reconciliationInd = false;

    // Find the earlier live FC start date
    final FCstatusCodeCaseID fcKey = new FCstatusCodeCaseID();

    fcKey.caseID = dtls.caseID;
    fcKey.statusCode = FINCOMPONENTSTATUS.LIVE;

    final FinancialComponentDtlsList fcList = FinancialComponentFactory.newInstance().searchByStatusCaseID(
      fcKey);

    Date earliestFCStartDate = Date.kZeroDate;

    // Filter out FCs of category 'Case Deduction Item' and types
    // of 'Benefit
    // Underpayment'
    for (int i = 0; i < fcList.dtls.size(); i++) {
      if (!fcList.dtls.item(i).categoryCode.equals(
        FINCOMPONENTCATEGORY.CASEDEDUCTIONITEM)
          && !fcList.dtls.item(i).typeCode.equals(
            FINCOMPONENTTYPE.BENEFITUNDERPAYMENT)) {
        if (fcList.dtls.item(i).startDate.before(earliestFCStartDate)
          || earliestFCStartDate.isZero()) {
          earliestFCStartDate = fcList.dtls.item(i).startDate;
        }
      }
    }

    if (earliestFCStartDate.before(dtls.closureDate)
      && !earliestFCStartDate.isZero()) {
      determineEligibilityKey.fromDate = earliestFCStartDate;
    } else {
      determineEligibilityKey.fromDate = dtls.closureDate;
    }

    determineEligibilityKey.toDate = caseHeaderDtls.expectedEndDate;
    // END, CR00239968

    cachedCaseStatusObj.clearCache();

    // BEGIN, CR00211744, CR00243401, VM
    // BEGIN, CR00287600, RB
    final DeterminationCalculator determinationCalculator = determinationCalculatorFactory.newInstanceForCaseID(
      dtls.caseID);

    if (determinationCalculator.supportsReassessment(dtls.caseID)) {

      // BEGIN, CR00327453, RB
      // check whether there are any current release decisions for
      // the case
      final CaseIDStatusInitReasonCodeKey caseIDStatusInitReasonCodeKey = new CaseIDStatusInitReasonCodeKey();

      caseIDStatusInitReasonCodeKey.caseID = dtls.caseID;
      caseIDStatusInitReasonCodeKey.statusCode = CASEDECISIONSTATUS.CURRENT;
      caseIDStatusInitReasonCodeKey.initReasonCode = CASEDECISIONINITREASONCODE.RELEASE;
      final CaseDecisionDtlsList caseDecisionDtlsList = CaseDecisionFactory.newInstance().searchByCaseIDStatusInitReasonCode(
        caseIDStatusInitReasonCodeKey);

      if (!caseDecisionDtlsList.dtls.isEmpty()) {

        // BEGIN, CR00289719, KH
        determineEligibilityKey.determinationReasonOpt = CASEASSESSMENTDETERMINATIONREASONEntry.CASECLOSURE.getCode();
        // END, CR00289719

        assessmentEngine.reassessEligibility(determineEligibilityKey, false);

      }
      // END, CR00327453
      
      // BEGIN, CR00465435, CSH
    } else {
      final RegenerateCaseFinancialsKey regenKey = new RegenerateCaseFinancialsKey();

      regenKey.caseID = dtls.caseID;
      assessmentEngine.regenerateFinancials(regenKey);
    }
    // END, CR00465435
    
    // END, CR00287600
    // END, CR00211744, CR00243401

    // close case reactivation event if one exists
    closeCaseEventKey.caseID = dtls.caseID;
    closeCaseEventKey.eventTypeCode = curam.codetable.CASEEVENTTYPE.CASEREACTIVATION;
    closeCaseEvent(closeCaseEventKey);

    //
    // close associated Plan Item
    //
    // ProductDeliveryPlanItemLink manipulation variables
    final curam.core.sl.intf.ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = curam.core.sl.fact.ProductDeliveryPlanItemLinkFactory.newInstance();
    final curam.core.sl.struct.PlannedItemClosureDetails plannedItemClosureDetails = new curam.core.sl.struct.PlannedItemClosureDetails();

    // set plan item closure details
    plannedItemClosureDetails.caseID = dtls.caseID;
    plannedItemClosureDetails.startDate = caseHeaderDtls.startDate;
    plannedItemClosureDetails.endDate = dtls.closureDate;
    plannedItemClosureDetails.outcomeAchieved = dtls.actualOutcome;

    // close associated plan item
    productDeliveryPlanItemLinkObj.closePlannedItem(plannedItemClosureDetails);

    // BEGIN, CR00236672, NS
    final ProFormaCommDetails1 proFormaCommDetails = new ProFormaCommDetails1();
    // END, CR00236672
    // END , HARP, 36803

    // BEGIN, CR00211297, CW
    //
    // Print communications if ENV_PRINTCASECOMMUNICATIONS is set
    // to true
    // and this is not a net zero payment correction case
    //
    final boolean isNetZeroPaymentCorrectionCase = paymentCorrection.isPaymentCorrectionCase(
      caseHeaderKey)
        && paymentCorrection.isNetZeroPaymentCorrection(caseHeaderKey);

    final boolean printCaseCommunications = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_PRINTCASECOMMUNICATIONS,
      curam.util.resources.Configuration.getBooleanProperty(
        EnvVars.ENV_PRINTCASECOMMUNICATIONS_DEFAULT))
          && !isNetZeroPaymentCorrectionCase;

    // END, CR00211297

    // BEGIN HARP 48722 VM
    proFormaCommDetails.printInd = printCaseCommunications;
    // END HARP 48722 VM

    // find any active referrals for this case
    caseEventCaseIDAndTypeKey.caseID = dtls.caseID;
    caseEventCaseIDAndTypeKey.eventTypeCode = curam.codetable.CASEEVENTTYPE.CASEREFERRAL;

    caseEventDtlsList = caseEventObj.searchByCaseIDAndType(
      caseEventCaseIDAndTypeKey);

    final curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj = curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();
    curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey = new curam.util.administration.struct.XSLTemplateInstanceKey();

    // BEGIN, CR00146629, SK
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;
    LanguageLocaleMapDetails languageLocaleMapDetails = new LanguageLocaleMapDetails();
    final curam.core.intf.ConcernRoleDocuments concernRoleDocumentsObj = curam.core.fact.ConcernRoleDocumentsFactory.newInstance();

    // Get the locale information
    languageLocaleMapDetails = concernRoleDocumentsObj.getLocaleInfo(
      concernRoleKey);
    xslTemplateIDCodeKey.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;

    if (!caseEventDtlsList.dtls.isEmpty()) {

      // set up document data only if printing required
      if (printCaseCommunications) {

        xslTemplateIDCodeKey.templateIDCode = curam.codetable.TEMPLATEIDCODE.CASECLOSURESUPPLIERNOTIFICATION;

        try {
          xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
            xslTemplateIDCodeKey);
        } catch (final RecordNotFoundException rnfe) {
          final AppException ae = new AppException(
            curam.message.GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);
          final String codeItemDescription = curam.util.type.CodeTable.getOneItem(
            curam.codetable.TEMPLATEIDCODE.TABLENAME,
            xslTemplateIDCodeKey.templateIDCode,
            TransactionInfo.getProgramLocale());

          ae.arg(codeItemDescription);

          throw ae;
        }
        // END, CR00146629
        // set the common data for all the supplier communications
        concernRoleDocumentKey.caseID = dtls.caseID;
        concernRoleDocumentKey.concernRoleID = caseHeaderDtls.concernRoleID;
        concernRoleDocumentKey.documentID = xslTemplateInstanceKey.templateID;
        concernRoleDocumentDetails.documentID = xslTemplateInstanceKey.templateID;
        concernRoleDocumentDetails.versionNo = xslTemplateInstanceKey.templateVersion;
      }
      xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);

      // populate the template name
      final curam.core.struct.XSLTemplateIn key = new curam.core.struct.XSLTemplateIn();

      key.templateID = xslTemplateInstanceKey.templateID;
      // BEGIN, CR00146629, SK
      key.localeIdentifier = xslTemplateInstanceKey.locale;
      // END, CR00146629
      // BEGIN, CR00279987, KRK
      proFormaCommDetails.subject = maintainXSLTemplateObj.readXSLTemplateDetails(key).templateName;
      // END, CR00279987
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.correspondentType = curam.codetable.CORRESPONDENT.CLIENT;
      proFormaCommDetails.proFormaVersionNo = xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.caseID = dtls.caseID;
      proFormaCommDetails.communicationTypeCode = curam.codetable.COMMUNICATIONTYPE.LETTER;
      proFormaCommDetails.localeIdentifier = xslTemplateInstanceKey.locale;

      for (int i = 0; i < caseEventDtlsList.dtls.size(); i++) {

        if (caseEventDtlsList.dtls.item(i).statusCode.equals(
          curam.codetable.CASEEVENTSTATUS.ACTIVE)
            || caseEventDtlsList.dtls.item(i).statusCode.equals(
              curam.codetable.CASEEVENTSTATUS.PENDING)) {

          // cancel referral and event
          cancelReferralKey.assign(caseEventDtlsList.dtls.item(i));
          maintainCaseReferralObj.cancelReferral(cancelReferralKey);

          caseReferralKey.caseReferralID = caseEventDtlsList.dtls.item(i).relatedID;

          // read CaseReferral from database
          caseReferralDtls = caseReferralObj.read(caseReferralKey);

          concernRoleKey.concernRoleID = caseReferralDtls.serviceSupplierID;

          // populate communication details
          proFormaCommDetails.addressID = concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
          proFormaCommDetails.correspondentName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
          proFormaCommDetails.correspondentParticipantRoleID = caseReferralDtls.serviceSupplierID;
          proFormaCommDetails.correspondentParticipantRoleID = caseReferralDtls.serviceSupplierID;

          // BEGIN, CR00236672, NS
          // Create communication.
          communicationObj.createProForma1(proFormaCommDetails);
          // END, CR00236672

        }
      }
    }

    // print closure communication for concern role if required
    if (printCaseCommunications) {
      xslTemplateIDCodeKey.templateIDCode = curam.codetable.TEMPLATEIDCODE.CASECLOSURECLIENTNOTIFICATION;

      // BEGIN, CR00146629, SK
      try {
        xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
          xslTemplateIDCodeKey);

      } catch (final RecordNotFoundException rnfe) {
        final AppException ae = new AppException(
          curam.message.GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);

        final String codeItemDescription = curam.util.type.CodeTable.getOneItem(
          curam.codetable.TEMPLATEIDCODE.TABLENAME,
          xslTemplateIDCodeKey.templateIDCode,
          TransactionInfo.getProgramLocale());

        ae.arg(codeItemDescription);
        throw ae;
      }
      // populate the template name
      final curam.core.struct.XSLTemplateIn key = new curam.core.struct.XSLTemplateIn();

      key.templateID = xslTemplateInstanceKey.templateID;
      key.localeIdentifier = xslTemplateInstanceKey.locale;
      // END, CR00146629

      // BEGIN, CR00279987, KRK
      proFormaCommDetails.subject = maintainXSLTemplateObj.readXSLTemplateDetails(key).templateName;
      // END, CR00279987

      concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

      // populate communication details

      proFormaCommDetails.correspondentType = curam.codetable.CORRESPONDENT.CLIENT;
      proFormaCommDetails.caseID = dtls.caseID;
      proFormaCommDetails.communicationTypeCode = curam.codetable.COMMUNICATIONTYPE.LETTER;
      proFormaCommDetails.proFormaID = xslTemplateInstanceKey.templateID;
      proFormaCommDetails.proFormaVersionNo = xslTemplateInstanceKey.templateVersion;
      proFormaCommDetails.addressID = concernRoleObj.readPrimaryAddress(concernRoleKey).primaryAddressID;
      proFormaCommDetails.correspondentName = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
      proFormaCommDetails.correspondentParticipantRoleID = caseHeaderDtls.concernRoleID;
      proFormaCommDetails.correspondentParticipantRoleID = caseHeaderDtls.concernRoleID;
      // BEGIN, CR00146629, SK
      proFormaCommDetails.localeIdentifier = xslTemplateInstanceKey.locale;
      // END, CR00146629

      // BEGIN, CR00236672, NS
      // Create communication.
      communicationObj.createProForma1(proFormaCommDetails);
      // END, CR00236672
    }
    // BEGIN, CR00102570, CW
    // Reset the case status mode
    caseStatusModeObj.resetMode();
    // END, CR00102570
  }

  // ___________________________________________________________________________
  /**
   * close case record with a future date
   *
   * @param dtls
   * contains caseID and closure details for the case to
   * be closed
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void closeCaseWithFutureDate(final ClosureDtls dtls)
    throws AppException, InformationalException {

    // CaseClosure manipulation variables
    final curam.core.intf.CaseClosure caseClosureObj = curam.core.fact.CaseClosureFactory.newInstance();
    final CaseClosureDtls caseClosureDtls = new CaseClosureDtls();

    // CaseEvent manipulation variables
    final curam.core.intf.CaseEvent caseEventObj = curam.core.fact.CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();

    final CloseCaseEventKey closeCaseEventKey = new CloseCaseEventKey();

    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // close case reactivation record if one exists
    closeCaseEventKey.caseID = dtls.caseID;
    closeCaseEventKey.eventTypeCode = curam.codetable.CASEEVENTTYPE.CASEREACTIVATION;

    closeCaseEvent(closeCaseEventKey);

    // update case status
    // BEGIN, CR00220971, ZV
    final UpdateCaseStatusReasonEndKey1 updateCaseStatusReasonEndKey = new UpdateCaseStatusReasonEndKey1();

    // END, CR00220971

    updateCaseStatusReasonEndKey.caseID = dtls.caseID;
    updateCaseStatusReasonEndKey.statusCode = curam.codetable.CASESTATUS.PENDINGCLOSURE;
    updateCaseStatusReasonEndKey.reasonCode = dtls.reasonCode;
    // start date not provided as current date is default
    // case header end date is set to closure date
    updateCaseStatusReasonEndKey.endDate = dtls.closureDate;
    // BEGIN, CR00150402, PDN
    updateCaseStatusReasonEndKey.comments = dtls.comments;
    updateCaseStatusReasonEndKey.userName = dtls.userName;
    // END, CR00150402
    // BEGIN, CR00313966, AC
    updateCaseStatusReasonEndKey.actualOutcome = dtls.actualOutcome;
    // END, CR00313966
    // BEGIN, CR00220971, ZV
    updateCaseStatus1(updateCaseStatusReasonEndKey);
    // END, CR00220971

    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();

    final CaseIDKey caseIDKey = new CaseIDKey();
    CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName;

    caseIDKey.caseID = dtls.caseID;

    caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
      caseIDKey);

    // The entered text has to be appended after the generated
    // text.
    if (dtls.comments.length() == 0) {

      final AppException noteText = new AppException(
        curam.message.BPOCLOSECASE.INF_CLOSECASE_PENDINGCLOSURE_SUBJECT);

      final String dateAsString = curam.util.resources.Locale.getFormattedDate(
        dtls.closureDate.getDateTime());

      noteText.arg(caseReferenceProductNameConcernRoleName.caseReference);
      noteText.arg(caseReferenceProductNameConcernRoleName.productName);
      noteText.arg(caseReferenceProductNameConcernRoleName.concernRoleName);
      noteText.arg(dateAsString);
      noteText.arg(dtls.userName);
    }

    // assign values to closure record (case closure)
    caseClosureDtls.assign(dtls);
    caseClosureDtls.caseClosureID = uniqueIDObj.getNextID();

    caseClosureDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    // save CaseClosure to database
    caseClosureObj.insert(caseClosureDtls);

    // assign values to closure record (case event)
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = dtls.caseID;
    caseEventDtls.startDate = dtls.closureDate;
    caseEventDtls.endDate = dtls.closureDate;
    caseEventDtls.relatedID = caseClosureDtls.caseClosureID;
    caseEventDtls.statusCode = curam.codetable.CASEEVENTSTATUS.DEFAULTCODE;
    caseEventDtls.eventTypeCode = curam.codetable.CASEEVENTTYPE.PENDINGCLOSURE;
    caseEventDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    // save CaseEvent to database
    caseEventObj.insert(caseEventDtls);

    // issue appropriate tickets
    createTickets(dtls);
  }

  // ___________________________________________________________________________
  /**
   * close case and associated records
   *
   * @param dtls
   * contains caseID and closure details for the case to
   * be closed
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void closeCase(final ClosureDtls dtls)
    throws AppException, InformationalException {

    // CaseEvent manipulation variables
    final curam.core.intf.CaseEvent caseEventObj = curam.core.fact.CaseEventFactory.newInstance();
    final CaseEventDtls caseEventDtls = new CaseEventDtls();
    final CaseEventCaseIDAndTypeKey caseEventCaseIDAndTypeKey = new CaseEventCaseIDAndTypeKey();
    CaseEventDtlsList caseEventDtlsList;

    // CaseClosure manipulation variables
    final curam.core.intf.CaseClosure caseClosureObj = curam.core.fact.CaseClosureFactory.newInstance();
    final CaseClosureDtls caseClosureDtls = new CaseClosureDtls();

    // unique ID generation variable
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // MaintainCaseReview manipulation variables
    final curam.core.intf.MaintainCaseReviewAssistant maintainCaseReviewAssistantObj = curam.core.fact.MaintainCaseReviewAssistantFactory.newInstance();
    final MaintainCaseReviewKey maintainCaseReviewKey = new MaintainCaseReviewKey();

    // BEGIN, CR00226315, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = dtls.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00226315

    // assign values to case closure
    caseClosureDtls.assign(dtls);
    caseClosureDtls.caseClosureID = uniqueIDObj.getNextID();

    caseClosureDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    // save closure record to database
    caseClosureObj.insert(caseClosureDtls);

    // assign values to case event
    caseEventDtls.caseEventID = uniqueIDObj.getNextID();
    caseEventDtls.caseID = dtls.caseID;
    caseEventDtls.startDate = dtls.closureDate;
    caseEventDtls.endDate = dtls.closureDate;
    caseEventDtls.relatedID = caseClosureDtls.caseClosureID;
    caseEventDtls.statusCode = curam.codetable.CASEEVENTSTATUS.DEFAULTCODE;
    caseEventDtls.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    caseEventDtls.eventTypeCode = curam.codetable.CASEEVENTTYPE.CASECLOSURE;

    // save case event record to database
    caseEventObj.insert(caseEventDtls);

    // close associated records
    try {
      closeAssociatedRecords(dtls);

    } catch (final AppException e) {

      // unexpected exception - no business value to add
      throw e;
    }

    // issue tickets
    createTickets(dtls);

    // reviews now canceled at this point as they may be referenced
    // in
    // createTickets method above
    caseEventCaseIDAndTypeKey.caseID = dtls.caseID;
    caseEventCaseIDAndTypeKey.eventTypeCode = curam.codetable.CASEEVENTTYPE.CASEREVIEW;

    caseEventDtlsList = caseEventObj.searchByCaseIDAndType(
      caseEventCaseIDAndTypeKey);

    if (!caseEventDtlsList.dtls.isEmpty()) {

      for (int i = 0; i < caseEventDtlsList.dtls.size(); i++) {

        // we should cancel only active and pending reviews
        if (caseEventDtlsList.dtls.item(i).statusCode.equals(
          curam.codetable.CASEEVENTSTATUS.ACTIVE)
            || caseEventDtlsList.dtls.item(i).statusCode.equals(
              curam.codetable.CASEEVENTSTATUS.PENDING)) {

          // cancel case review
          maintainCaseReviewKey.assign(caseEventDtlsList.dtls.item(i));
          maintainCaseReviewAssistantObj.cancelReview(maintainCaseReviewKey);
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * create tickets for case owner and case reviewers advising them
   * of case closure
   *
   * @param dtls
   * contains caseID for the case to be closed
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void createTickets(final ClosureDtls dtls)
    throws AppException, InformationalException {

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    ParticipantOrgObjectLinkIDAndCaseRef participantOrgObjectLinkIDAndCaseRef;

    // Users manipulation variables
    final curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    UsersDtls usersDtls;
    // BEGIN, CR00158383, RV
    // concernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    CaseHeaderDtls caseHeaderDtls;
    // END, CR00158383

    // CaseReview manipulation variables
    final curam.core.intf.CaseReview caseReviewObj = curam.core.fact.CaseReviewFactory.newInstance();
    final CaseReviewByCaseIDKey caseReviewByCaseIDKey = new CaseReviewByCaseIDKey();
    CaseReviewDtlsList caseReviewDtlsList;
    final CaseReviewDtlsList tempReviewers = new CaseReviewDtlsList();

    curam.util.type.Date informReviewersUntil;
    int informReviewersNextNDaysOfClosure;

    // BEGIN, CR00213430, AK
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    final OrgObjectLink orgObjectLinkObj = OrgObjectLinkFactory.newInstance();
    OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();
    String userLocale;
    // END, CR00213430
    final curam.util.type.Date today = curam.util.type.Date.getCurrentDate();

    // may be issuing tickets due to actual closure or future-dated
    // closure.
    // ticket subject and reason text vary in either case
    boolean indCloseInFuture = false;

    if (today.before(dtls.closureDate)) {
      indCloseInFuture = true;
    }

    // notification manipulation variables
    final curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();
    // WorkAllocationTask service layer object
    final StandardManualTaskDtls standardManualDtls = new StandardManualTaskDtls();

    // User variables
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls currentSystemUserDtls;

    // BEGIN, CR00060051, PMD
    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // END, CR00060051

    // set user variable
    currentSystemUserDtls = systemUserObj.getUserDetails();

    // check the environment variable
    String genClosedTicket = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENCASECLOSEDTICKET);

    if (genClosedTicket == null) {

      genClosedTicket = EnvVars.ENV_GENCASECLOSEDTICKET_DEFAULT;
    }

    if (genClosedTicket.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {
      return;
    }

    caseHeaderKey.caseID = dtls.caseID;

    // BEGIN, CR00060051, PMD
    participantOrgObjectLinkIDAndCaseRef = caseHeaderObj.readParticipantOrgObjectLinkIDAndCaseRef(
      caseHeaderKey);

    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();

    final CaseIDKey caseIDKey = new CaseIDKey();
    CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName;

    caseIDKey.caseID = dtls.caseID;
    // BEGIN, CR00234114, AK
    caseHeaderKey.caseID = dtls.caseID;
    orgObjectLinkKey.orgObjectLinkID = caseHeaderObj.readCaseOwner(caseHeaderKey).ownerOrgObjectLinkID;
    orgObjectLinkDtls = orgObjectLinkObj.read(orgObjectLinkKey);
    usersKey.userName = orgObjectLinkDtls.userName;
    usersDtls = usersObj.read(nfIndicator, usersKey);
    if (!nfIndicator.isNotFound()) {
      userLocale = usersDtls.defaultLocale;
    } else {
      userLocale = TransactionInfo.getProgramLocale();
    }

    caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseIDAndLocale(
      caseIDKey, userLocale);
    // END, CR00234114

    // if the current user is not the case owner, send a
    // notification to the
    // owner

    // BEGIN, CR00158383, RV
    // Read Case Header
    caseHeaderKey.caseID = dtls.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;
    // read concernRole entity
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    // END, CR00158383

    final UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = currentSystemUserDtls.userName;

    // Check if the user owns the case, or is part of an
    // organization object that owns the case.
    final OwnerInd isUserOwnerInd = caseUserRoleObj.isUserCaseOwner(userNameKey,
      caseHeaderKey);

    if (!isUserOwnerInd.ownerInd) {
      // tickets for the owner
      AppException infSubjectForOwner;
      AppException infReasonForOwner;

      // format the subject and reason texts
      if (indCloseInFuture) {
        infSubjectForOwner = new AppException(
          curam.message.BPOCLOSECASE.INF_CLOSECASE_PENDINGCLOSURE_SUBJECT);
        infReasonForOwner = new AppException(
          curam.message.BPOCLOSECASE.INF_CLOSECASE_PENDINGCLOSURE_REASON);
        infSubjectForOwner.arg(
          caseReferenceProductNameConcernRoleName.caseReference);
        infSubjectForOwner.arg(
          caseReferenceProductNameConcernRoleName.productName);
        infSubjectForOwner.arg(
          caseReferenceProductNameConcernRoleName.concernRoleName);

        // BEGIN, CR00168992, MR
        infSubjectForOwner.arg(dtls.closureDate.toString());
        // END, CR00168992

        infSubjectForOwner.arg(dtls.userName);
        infReasonForOwner.arg(
          caseReferenceProductNameConcernRoleName.caseReference);
        infReasonForOwner.arg(
          caseReferenceProductNameConcernRoleName.productName);
        infReasonForOwner.arg(
          caseReferenceProductNameConcernRoleName.concernRoleName);
        infReasonForOwner.arg(dtls.closureDate.toString());
        infReasonForOwner.arg(dtls.userName);
        // BEGIN, CR00023618, SK
        standardManualDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.casePendingNotificationTaskDefinitionID;
        // END, CR00023618
      } else {

        infSubjectForOwner = new AppException(
          curam.message.BPOCLOSECASE.INF_CLOSECASE_CLOSED_DATE);

        infReasonForOwner = new AppException(
          curam.message.BPOCLOSECASE.INF_CLOSECASE_CLOSED_REASON);
        infReasonForOwner.arg(
          participantOrgObjectLinkIDAndCaseRef.caseReference);
        infReasonForOwner.arg(
          caseReferenceProductNameConcernRoleName.productName);
        infReasonForOwner.arg(
          caseReferenceProductNameConcernRoleName.concernRoleName);
        // BEGIN, CR00021533, CMB
        // BEGIN, HARP 65191, KN
        infReasonForOwner.arg(
          curam.util.transaction.TransactionInfo.getProgramUser());
        // END, HARP 65191
        // END, CR00021533

        infSubjectForOwner.arg(
          caseReferenceProductNameConcernRoleName.caseReference);
        infSubjectForOwner.arg(
          caseReferenceProductNameConcernRoleName.productName);
        infSubjectForOwner.arg(
          caseReferenceProductNameConcernRoleName.concernRoleName);

        infSubjectForOwner.arg(dtls.closureDate);
        // BEGIN, CR00023618, SK
        standardManualDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.caseCloseNotificationTaskDefinitionID;
        // END, CR00021533
      }

      // BEGIN, CR00213430, AK
      // BEGIN, CR00163236, CL
      standardManualDtls.dtls.taskDtls.subject = infSubjectForOwner.getMessage(
        userLocale);
      standardManualDtls.dtls.taskDtls.comments = infReasonForOwner.getMessage(
        userLocale);
      // END, CR00163236
      // END, CR00213430

      standardManualDtls.dtls.concerningDtls.caseID = dtls.caseID;
      standardManualDtls.dtls.concerningDtls.participantRoleID = participantOrgObjectLinkIDAndCaseRef.concernRoleID;
      // BEGIN, CR00158383, RV
      standardManualDtls.dtls.concerningDtls.participantType = concernRoleDtls.concernRoleType;
      // END, CR00158383

      // Send notifications to the list of users
      notificationObj.sendCaseOwnerNotification(standardManualDtls);

    }

    // set the key for reading database
    caseReviewByCaseIDKey.caseID = dtls.caseID;
    caseReviewByCaseIDKey.reviewStatus1 = curam.codetable.CASEREVIEWSTATUS.ACTIVE;
    caseReviewByCaseIDKey.reviewStatus2 = curam.codetable.CASEREVIEWSTATUS.PENDING;

    // read all the case reviews
    caseReviewDtlsList = caseReviewObj.searchByCaseID(caseReviewByCaseIDKey);

    // if there are no reviews, no need to read environment
    // variable etc.
    if (!caseReviewDtlsList.dtls.isEmpty()) {

      // get environment variable
      final String numDaysAsString = curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_INFORM_REVIEWERS_NEXT_N_DAYS_OF_CLOSURE);

      if (numDaysAsString != null) {

        informReviewersNextNDaysOfClosure = Integer.parseInt(numDaysAsString);

      } else {

        informReviewersNextNDaysOfClosure = EnvVars.ENV_INFORM_REVIEWERS_NEXT_N_DAYS_OF_CLOSURE_DEFAULT;
      }

      informReviewersUntil = dtls.closureDate.addDays(
        informReviewersNextNDaysOfClosure);

      // iterate through the reviews, find out pending ones and
      // determine the
      // reviewers for them
      for (int i = 0; i < caseReviewDtlsList.dtls.size(); i++) {

        if (caseReviewDtlsList.dtls.item(i).statusCode.equals(
          curam.codetable.CASEREVIEWSTATUS.PENDING)
            && !caseReviewDtlsList.dtls.item(i).scheduledStartDate.after(
              informReviewersUntil)
                || caseReviewDtlsList.dtls.item(i).statusCode.equals(
                  curam.codetable.CASEREVIEWSTATUS.ACTIVE)
                    && !caseReviewDtlsList.dtls.item(i).startDate.after(
                      informReviewersUntil)) {

          boolean indReviewerExists = false;

          // search list of existing reviewers to see if this one
          // is already
          // in it
          for (int j = 0; j < tempReviewers.dtls.size(); j++) {

            if (caseReviewDtlsList.dtls.item(i).reviewerID.equals(
              tempReviewers.dtls.item(j).reviewerID)) {

              indReviewerExists = true;

              break;
            }
          }

          // if it isn't, add it
          if (!indReviewerExists) {

            tempReviewers.dtls.addRef(caseReviewDtlsList.dtls.item(i));
          }
        }
      }

      // assign values to subject and reason fields, because they
      // will be the
      // same for all the reviewers
      AppException infSubjectForReviewer;
      AppException infReasonForReviewer;

      if (indCloseInFuture) {

        infSubjectForReviewer = new AppException(
          curam.message.BPOCLOSECASE.INF_CLOSECASE_PENDINGCLOSURE_REVIEWER_SUBJECT);

        infReasonForReviewer = new AppException(
          curam.message.BPOCLOSECASE.INF_CLOSECASE_PENDINGCLOSURE_REVIEWER_REASON);

      } else {

        infSubjectForReviewer = new AppException(
          curam.message.BPOCLOSECASE.INF_CLOSECASE_REVIEWCANCELED_SUBJECT);

        infReasonForReviewer = new AppException(
          curam.message.BPOCLOSECASE.INF_CLOSECASE_REVIEWCANCELED_REASON);
      }

      infSubjectForReviewer.arg(
        caseReferenceProductNameConcernRoleName.caseReference);
      infSubjectForReviewer.arg(
        caseReferenceProductNameConcernRoleName.productName);
      infSubjectForReviewer.arg(
        caseReferenceProductNameConcernRoleName.concernRoleName);

      infReasonForReviewer.arg(
        participantOrgObjectLinkIDAndCaseRef.caseReference);
      infReasonForReviewer.arg(
        caseReferenceProductNameConcernRoleName.productName);
      infReasonForReviewer.arg(
        caseReferenceProductNameConcernRoleName.concernRoleName);
      infReasonForReviewer.arg(dtls.closureDate);

      infReasonForReviewer.arg(
        curam.util.resources.Locale.getFormattedDate(
          dtls.closureDate.getDateTime()));

      // BEGIN, CR00023618, SK
      standardManualDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.caseReviewCancelationTaskDefinitionID;
      // END, CR00021533
      // iterate through all the reviewers
      for (int i = 0; i < tempReviewers.dtls.size(); i++) {

        // set the key for reading database
        usersKey.userName = tempReviewers.dtls.item(i).reviewerID;

        // read Users from database
        usersDtls = usersObj.read(usersKey);
        // BEGIN, CR00213430, AK
        standardManualDtls.dtls.taskDtls.subject = infSubjectForReviewer.getMessage(
          usersDtls.defaultLocale);
        standardManualDtls.dtls.taskDtls.comments = infReasonForReviewer.getMessage(
          usersDtls.defaultLocale);
        // END, CR00213430

        standardManualDtls.dtls.concerningDtls.caseID = caseHeaderKey.caseID;

        standardManualDtls.dtls.assignDtls.assignmentID = usersDtls.userName;
        standardManualDtls.dtls.concerningDtls.participantRoleID = participantOrgObjectLinkIDAndCaseRef.concernRoleID;

        notificationObj.createWorkAllocationNotification(standardManualDtls);

      }
      // END, CR00060051
    }
  }

  // ___________________________________________________________________________
  /**
   * send ticket to user or owner when closing the case and
   * associated records if the case cannot be closed due to the
   * existence of an under/overpayment
   *
   * @param key
   * contains caseID for the case to be closed
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createTicketClosureFailed(final ClosureDtls key)
    throws AppException, InformationalException {

    // check the environment variable
    String genClosedTicket = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENCASECLOSEDTICKET);

    if (genClosedTicket == null) {
      genClosedTicket = EnvVars.ENV_GENCASECLOSEDTICKET_DEFAULT;
    }

    if (genClosedTicket.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {
      return;
    }

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // read CaseHeader from database
    caseHeaderKey.caseID = key.caseID;
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();

    final CaseIDKey caseIDKey = new CaseIDKey();
    CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName;

    caseIDKey.caseID = key.caseID;

    caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
      caseIDKey);

    // User variables
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls currentSystemUserDtls;

    // set user
    currentSystemUserDtls = systemUserObj.getUserDetails();

    // Create notification information
    final AppException infSubject = new AppException(
      curam.message.BPOCLOSECASE.INF_CLOSECASE_CASELIABILITY_UNDERPAYMENT_SUBJECT);

    final AppException infReason = new AppException(
      curam.message.BPOCLOSECASE.INF_CLOSECASE_CASELIABILITY_UNDERPAYMENT_REASON);

    // notification manipulation variables
    final curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();
    // WorkAllocationTask service layer object
    final StandardManualTaskDtls standardManualDtls = new StandardManualTaskDtls();

    // send ticket to current user
    infReason.arg(caseHeaderDtls.caseReference);
    infReason.arg(caseReferenceProductNameConcernRoleName.concernRoleName);

    infSubject.arg(caseReferenceProductNameConcernRoleName.caseReference);
    infSubject.arg(caseReferenceProductNameConcernRoleName.productName);
    infSubject.arg(caseReferenceProductNameConcernRoleName.concernRoleName);

    // BEGIN, CR00163236, CL
    standardManualDtls.dtls.taskDtls.subject = infSubject.getMessage(
      TransactionInfo.getProgramLocale());
    standardManualDtls.dtls.taskDtls.comments = infReason.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163236
    // BEGIN, CR00023618, SK
    standardManualDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.caseCloseFailedNotificationTaskDefinitionID;
    // END, CR00021533
    standardManualDtls.dtls.concerningDtls.caseID = key.caseID;

    standardManualDtls.dtls.assignDtls.assignmentID = currentSystemUserDtls.userName;

    standardManualDtls.dtls.concerningDtls.participantRoleID = caseHeaderDtls.concernRoleID;

    // Send notification to case owner(s)
    notificationObj.sendCaseOwnerNotification(standardManualDtls);
    // END, CR00069238
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * contains caseID, new status, start date for new
   * status, reason for the status and end date for the
   * case
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #updateCaseStatus1()}
   *
   * Update case status by updating CaseHeader and
   * CaseStatus entities. Parameter data supplied
   * includes new status code, start date for new
   * status and end date for case.
   *
   * If no start date for new status is supplied,
   * current date is assumed as transition date.
   *
   * Case Header status and end date are set to those
   * supplied.
   *
   * New status record is created with start date and
   * status provided.
   *
   * Current status record end date is set to start
   * date of new status record.
   */
  @Override
  @Deprecated
  public void updateCaseStatus(
    final UpdateCaseStatusReasonEndKey key) throws AppException,
      InformationalException {

    // CaseHeader manipulation variables
    final curam.core.intf.CachedCaseHeader cachedCaseHeader = curam.core.fact.CachedCaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHdrKey = new CaseHeaderKey();
    CaseHeaderDtls caseHdrDtls;

    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // read CaseHeader from database
    caseHdrKey.caseID = key.caseID;

    caseHdrDtls = cachedCaseHeader.read(caseHdrKey);

    // set end date and new status on case header
    caseHdrDtls.endDate = key.endDate;
    caseHdrDtls.statusCode = key.statusCode;
    caseHdrDtls.actualOutcome = key.actualOutcome;

    // update CaseHeader
    cachedCaseHeader.modify(caseHdrKey, caseHdrDtls);

    // CaseStatus manipulation variables
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    CaseStatusDtls caseStatusDtls;
    final CurrentCaseStatusKey currCaseStatusKey = new CurrentCaseStatusKey();

    currCaseStatusKey.assign(caseHdrDtls);
    currCaseStatusKey.nullDate = curam.util.type.Date.kZeroDate;

    // Read current status by retrieved Case ID
    caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID(currCaseStatusKey);

    final CaseStatusDtls newCaseStatusDtls = new CaseStatusDtls();

    // based on domain INTERNAL_ID
    final long uniqCaseStatusID = uniqueIDObj.getNextID();

    // set values for new status record
    newCaseStatusDtls.caseID = caseHdrDtls.caseID;
    newCaseStatusDtls.statusCode = key.statusCode;
    newCaseStatusDtls.reasonCode = key.reasonCode;
    newCaseStatusDtls.caseStatusID = uniqCaseStatusID;

    // if a start date for new status is not supplied, current date
    // is used
    if (!key.startDate.isZero()) {

      newCaseStatusDtls.startDate = key.startDate;

    } else {

      newCaseStatusDtls.startDate = curam.util.transaction.TransactionInfo.getSystemDate();
    }

    // end date for new status record is not set
    newCaseStatusDtls.endDate = curam.util.type.Date.kZeroDate;

    // Insert new record with KEY case status
    caseStatusObj.insert(newCaseStatusDtls);

    // Modify current case status - set end date to start date of
    // new status
    final CaseStatusKey caseStatusKey = new CaseStatusKey();

    caseStatusKey.caseStatusID = caseStatusDtls.caseStatusID;

    caseStatusDtls.endDate = newCaseStatusDtls.startDate;
    // BEGIN, CR00162569, PDN
    caseStatusDtls.endDateTime = curam.util.transaction.TransactionInfo.getSystemDateTime();
    // END, CR00162569

    caseStatusObj.modify(caseStatusKey, caseStatusDtls);
  }

  // ___________________________________________________________________________
  /**
   * Close case closure or reactivation event given case id and
   * event type
   *
   * @param key
   * contains caseID and case event type code
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void closeCaseEvent(final CloseCaseEventKey key)
    throws AppException, InformationalException {

    // CaseEvent manipulation variables
    final curam.core.intf.CaseEvent caseEventObj = curam.core.fact.CaseEventFactory.newInstance();
    final CaseEventCaseIDAndTypeKey caseEventCaseIDAndTypeKey = new CaseEventCaseIDAndTypeKey();
    CaseEventDtlsList caseEventDtlsList;
    final CaseEventKey caseEventKey = new CaseEventKey();

    boolean eventFoundInd = false;

    // set the key
    caseEventCaseIDAndTypeKey.caseID = key.caseID;
    caseEventCaseIDAndTypeKey.eventTypeCode = key.eventTypeCode;

    // read the case events
    caseEventDtlsList = caseEventObj.searchByCaseIDAndType(
      caseEventCaseIDAndTypeKey);

    // variable used as index in search for open case event
    int i;

    // find open event
    for (i = 0; i < caseEventDtlsList.dtls.size(); i++) {

      if (!caseEventDtlsList.dtls.item(i).statusCode.equals(
        curam.codetable.CASEEVENTSTATUS.CLOSED)) {

        eventFoundInd = true;
        break;
      }
    }

    // close it
    if (eventFoundInd) {

      caseEventDtlsList.dtls.item(i).statusCode = curam.codetable.CASEEVENTSTATUS.CLOSED;

      caseEventKey.caseEventID = caseEventDtlsList.dtls.item(i).caseEventID;

      // save modified CaseEvent record to database
      caseEventObj.modify(caseEventKey, caseEventDtlsList.dtls.item(i));

    }

  }

  // BEGIN, CR00220971, ZV
  // ___________________________________________________________________________
  /**
   * Update case status by updating CaseHeader and CaseStatus
   * entities. Parameter data supplied includes new status code,
   * start date for new status and end date for case.
   *
   * If no start date for new status is supplied, current date is
   * assumed as transition date.
   *
   * Case Header status and end date are set to those supplied.
   *
   * New status record is created with start date and status
   * provided.
   *
   * Current status record end date is set to start date of new
   * status record.
   *
   * @param key
   * contains caseID, new status, start date for new
   * status, reason for the status and end date for the
   * case
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void updateCaseStatus1(
    final UpdateCaseStatusReasonEndKey1 key)
    throws AppException, InformationalException {

    // CaseHeader manipulation variables
    final curam.core.intf.CachedCaseHeader cachedCaseHeader = curam.core.fact.CachedCaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHdrKey = new CaseHeaderKey();
    CaseHeaderDtls caseHdrDtls;

    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // read CaseHeader from database
    caseHdrKey.caseID = key.caseID;

    caseHdrDtls = cachedCaseHeader.read(caseHdrKey);

    // set end date and new status on case header
    caseHdrDtls.endDate = key.endDate;
    caseHdrDtls.statusCode = key.statusCode;
    caseHdrDtls.actualOutcome = key.actualOutcome;

    // update CaseHeader
    cachedCaseHeader.modify(caseHdrKey, caseHdrDtls);

    // CaseStatus manipulation variables
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    CaseStatusDtls caseStatusDtls;
    final CurrentCaseStatusKey currCaseStatusKey = new CurrentCaseStatusKey();

    currCaseStatusKey.assign(caseHdrDtls);
    currCaseStatusKey.nullDate = curam.util.type.Date.kZeroDate;

    // Read current status by retrieved Case ID
    // BEGIN, CR00224271, ZV
    caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(currCaseStatusKey);
    // END, CR00224271

    final CaseStatusDtls newCaseStatusDtls = new CaseStatusDtls();

    // based on domain INTERNAL_ID
    final long uniqCaseStatusID = uniqueIDObj.getNextID();

    // set values for new status record
    newCaseStatusDtls.caseID = caseHdrDtls.caseID;
    newCaseStatusDtls.statusCode = key.statusCode;
    newCaseStatusDtls.reasonCode = key.reasonCode;
    newCaseStatusDtls.caseStatusID = uniqCaseStatusID;
    // BEGIN, CR00150402, PDN
    newCaseStatusDtls.comments = key.comments;
    newCaseStatusDtls.userName = key.userName;
    // END, CR00150402

    // if a start date for new status is not supplied, current date
    // is used
    if (!key.startDate.isZero()) {

      newCaseStatusDtls.startDate = key.startDate;

    } else {

      newCaseStatusDtls.startDate = curam.util.transaction.TransactionInfo.getSystemDate();
    }

    // end date for new status record is not set
    newCaseStatusDtls.endDate = curam.util.type.Date.kZeroDate;

    // Insert new record with KEY case status
    caseStatusObj.insert(newCaseStatusDtls);

    // Modify current case status - set end date to start date of
    // new status
    final CaseStatusKey caseStatusKey = new CaseStatusKey();

    caseStatusKey.caseStatusID = caseStatusDtls.caseStatusID;

    caseStatusDtls.endDate = newCaseStatusDtls.startDate;
    // BEGIN, CR00162569, PDN
    caseStatusDtls.endDateTime = curam.util.transaction.TransactionInfo.getSystemDateTime();
    // END, CR00162569

    caseStatusObj.modify(caseStatusKey, caseStatusDtls);
  }
  // END, CR00220971

}
