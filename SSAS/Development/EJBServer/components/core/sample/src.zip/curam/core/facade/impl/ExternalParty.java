/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import curam.codetable.CASETYPECODE;
import curam.codetable.CONCERNROLETYPE;
import curam.core.facade.fact.FinancialContextFactory;
import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.intf.Communication;
import curam.core.facade.struct.ExtPartyTaskRedirectionsFromUserDetails;
import curam.core.facade.struct.ExternalPartyAddressDetails;
import curam.core.facade.struct.ExternalPartyAddressDetailsList;
import curam.core.facade.struct.ExternalPartyAdjustmentInstructionResult;
import curam.core.facade.struct.ExternalPartyAdminRoleDetailsList;
import curam.core.facade.struct.ExternalPartyAdministratorDetailsList;
import curam.core.facade.struct.ExternalPartyAlternateIDDetails;
import curam.core.facade.struct.ExternalPartyAlternateIDDetailsList;
import curam.core.facade.struct.ExternalPartyBankAccountDetails;
import curam.core.facade.struct.ExternalPartyBankAccountDetailsList;
import curam.core.facade.struct.ExternalPartyBankAccountList;
import curam.core.facade.struct.ExternalPartyCommunicationDetails;
import curam.core.facade.struct.ExternalPartyCommunicationDetails1;
import curam.core.facade.struct.ExternalPartyCommunicationDetailsList;
import curam.core.facade.struct.ExternalPartyCommunicationExceptionDetails;
import curam.core.facade.struct.ExternalPartyCommunicationExceptionDetailsList;
import curam.core.facade.struct.ExternalPartyConcernContactDetails;
import curam.core.facade.struct.ExternalPartyConcernContactDetailsList;
import curam.core.facade.struct.ExternalPartyConcernRoleDetailsList;
import curam.core.facade.struct.ExternalPartyContactDetails;
import curam.core.facade.struct.ExternalPartyContactDetailsList;
import curam.core.facade.struct.ExternalPartyEmailAddressDetails;
import curam.core.facade.struct.ExternalPartyEmailAddressDetailsList;
import curam.core.facade.struct.ExternalPartyEmailDetails;
import curam.core.facade.struct.ExternalPartyFinancialDetailsList;
import curam.core.facade.struct.ExternalPartyHomePageDetails;
import curam.core.facade.struct.ExternalPartyInstructionLineItemDetails;
import curam.core.facade.struct.ExternalPartyInteractionDetails;
import curam.core.facade.struct.ExternalPartyInteractionDetailsList;
import curam.core.facade.struct.ExternalPartyIssuedPaymentInstrumentDetailsList;
import curam.core.facade.struct.ExternalPartyListResourcesForLocationDetails;
import curam.core.facade.struct.ExternalPartyListResourcesForLocationKey;
import curam.core.facade.struct.ExternalPartyListSecurityRoleDetails;
import curam.core.facade.struct.ExternalPartyMSWordDetails;
import curam.core.facade.struct.ExternalPartyNoteDetails;
import curam.core.facade.struct.ExternalPartyNoteDetails1;
import curam.core.facade.struct.ExternalPartyNoteDetailsList;
import curam.core.facade.struct.ExternalPartyNoteDetailsList1;
import curam.core.facade.struct.ExternalPartyOfficeMemberEmailDetails;
import curam.core.facade.struct.ExternalPartyOfficeMemberEmailList;
import curam.core.facade.struct.ExternalPartyOfficeSearchDetails;
import curam.core.facade.struct.ExternalPartyOfficeSearchKey;
import curam.core.facade.struct.ExternalPartyOfficeSearchKey1;
import curam.core.facade.struct.ExternalPartyOfficeSearchResult;
import curam.core.facade.struct.ExternalPartyOfficeSearchResult1;
import curam.core.facade.struct.ExternalPartyPaymentInstructionDetails;
import curam.core.facade.struct.ExternalPartyPhoneDetails;
import curam.core.facade.struct.ExternalPartyPhoneDetailsList;
import curam.core.facade.struct.ExternalPartyProFormaDetails;
import curam.core.facade.struct.ExternalPartyReadAllLocationHolidayDetails_fo;
import curam.core.facade.struct.ExternalPartyReadAllLocationHolidayKey_fo;
import curam.core.facade.struct.ExternalPartyReadLocationDetails;
import curam.core.facade.struct.ExternalPartyReadLocationKey;
import curam.core.facade.struct.ExternalPartyReadSecurityRole;
import curam.core.facade.struct.ExternalPartyRegistrationDetails;
import curam.core.facade.struct.ExternalPartyRegistrationResult;
import curam.core.facade.struct.ExternalPartyResourceDetails;
import curam.core.facade.struct.ExternalPartyResourceKey;
import curam.core.facade.struct.ExternalPartySearchKey;
import curam.core.facade.struct.ExternalPartySearchKey1;
import curam.core.facade.struct.ExternalPartySearchResult;
import curam.core.facade.struct.ExternalPartySecurityRoleKey;
import curam.core.facade.struct.ExternalPartyTaskAssignmentDetails;
import curam.core.facade.struct.ExternalPartyTaskAssignmentDetails1;
import curam.core.facade.struct.ExternalPartyTaskDetails;
import curam.core.facade.struct.ExternalPartyTaskDetailsList;
import curam.core.facade.struct.ExternalPartyTaskHistoryTextDetails;
import curam.core.facade.struct.ExternalPartyTaskManagementTaskKey;
import curam.core.facade.struct.ExternalPartyUserDetails;
import curam.core.facade.struct.ExternalPartyUserHomePageKey;
import curam.core.facade.struct.ExternalPartyUserNameKey;
import curam.core.facade.struct.ExternalPartyWebAddressDetails;
import curam.core.facade.struct.ExternalPartyWebAddressDetailsList;
import curam.core.facade.struct.ExternalPartyWorkflowGraphDetails;
import curam.core.facade.struct.FinancialContextDescriptionKey;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.ListExternalPartyPrintersDetails;
import curam.core.facade.struct.MenuDataDetails;
import curam.core.facade.struct.ParticipantContextDescriptionDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ParticipantFinancials;
import curam.core.facade.struct.ParticipantSearchDetails;
import curam.core.facade.struct.ParticipantSearchResult;
import curam.core.facade.struct.PaymentDetails;
import curam.core.facade.struct.PaymentILIDetails;
import curam.core.facade.struct.ProFormaCommDetails1;
import curam.core.facade.struct.ReadAdjustmentInstructionKey;
import curam.core.facade.struct.ReadAdjustmentInstructionResult;
import curam.core.facade.struct.ReadEmailCommKey;
import curam.core.facade.struct.ReadInstructionLineItemKey;
import curam.core.facade.struct.ReadMSWordCommunicationDetails;
import curam.core.facade.struct.ReadMSWordCommunicationDetails1;
import curam.core.facade.struct.ReadMSWordCommunicationKey;
import curam.core.facade.struct.ReadParticipantEmailAddressListKey;
import curam.core.facade.struct.ReadPaymentInstructionDetails;
import curam.core.facade.struct.ReadPaymentInstructionDetails1;
import curam.core.facade.struct.ReadPaymentInstructionKey;
import curam.core.facade.struct.ReadProFormaCommKey;
import curam.core.facade.struct.ReadRecordedCommKey;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.MaintainAdminConcernRoleFactory;
import curam.core.fact.MaintainConcernRoleAddressFactory;
import curam.core.fact.MaintainConcernRoleAltIDFactory;
import curam.core.fact.MaintainConcernRoleBankAcFactory;
import curam.core.fact.MaintainConcernRoleCommExceptionFactory;
import curam.core.fact.MaintainConcernRoleDetailsFactory;
import curam.core.fact.MaintainConcernRoleEmailFactory;
import curam.core.fact.MaintainConcernRolePhoneFactory;
import curam.core.fact.MaintainContactsFactory;
import curam.core.fact.ViewConcernAccountFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.intf.ExternalPartyOffice;
import curam.core.sl.entity.intf.ExternalPartyOfficeMember;
import curam.core.sl.entity.struct.ClientInteractionDtls;
import curam.core.sl.entity.struct.ClientInteractionKey;
import curam.core.sl.entity.struct.ExternalPartyDtls;
import curam.core.sl.entity.struct.ExternalPartyKey;
import curam.core.sl.entity.struct.ExternalPartyOfficeAddressKey;
import curam.core.sl.entity.struct.ExternalPartyOfficeDtls;
import curam.core.sl.entity.struct.ExternalPartyOfficeKey;
import curam.core.sl.entity.struct.ExternalPartyOfficeMemberDtls;
import curam.core.sl.entity.struct.ExternalPartyOfficeMemberKey;
import curam.core.sl.entity.struct.ExternalPartyOfficePhoneNumberKey;
import curam.core.sl.entity.struct.MaintainExternalPartyOfficeAddressDtls;
import curam.core.sl.entity.struct.ReadInteractionKey;
import curam.core.sl.fact.ClientInteractionFactory;
import curam.core.sl.fact.CommunicationFactory;
import curam.core.sl.fact.ExternalPartyFactory;
import curam.core.sl.fact.ExternalPartyOfficeAddressFactory;
import curam.core.sl.fact.ExternalPartyOfficeFactory;
import curam.core.sl.fact.ExternalPartyOfficeMemberFactory;
import curam.core.sl.fact.ExternalPartyOfficePhoneNumberFactory;
import curam.core.sl.fact.ParticipantNoteFactory;
import curam.core.sl.fact.ParticipantSearchRouterFactory;
import curam.core.sl.fact.WebAddressFactory;
import curam.core.sl.fact.WorkAllocationTaskFactory;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.intf.ClientInteraction;
import curam.core.sl.intf.ParticipantSearchRouter;
import curam.core.sl.struct.CommunicationKey;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.sl.struct.ConcernRoleWebAddressKey;
import curam.core.sl.struct.ExternalPartyDetails;
import curam.core.sl.struct.ExternalPartyOfficeAddressDetails;
import curam.core.sl.struct.ExternalPartyOfficeAddressDetailsList;
import curam.core.sl.struct.ExternalPartyOfficeDetails;
import curam.core.sl.struct.ExternalPartyOfficeList;
import curam.core.sl.struct.ExternalPartyOfficeMemberDetailsList;
import curam.core.sl.struct.ExternalPartyOfficeMemberFullDetails;
import curam.core.sl.struct.ExternalPartyOfficePhoneNumberDetails;
import curam.core.sl.struct.ExternalPartyOfficePhoneNumberDetailsList;
import curam.core.sl.struct.ParticipantKey;
import curam.core.sl.struct.ParticipantNoteKey;
import curam.core.sl.struct.ReadExternalPartyResult;
import curam.core.sl.struct.SearchTaskForConcernOrCaseKey;
import curam.core.sl.supervisor.struct.ActiveAndPendingTaskRedirectionFromUserDetailsList;
import curam.core.sl.supervisor.struct.ExpiredTaskRedirectionFromUserDetailsList;
import curam.core.sl.supervisor.struct.RedirectTaskDetails;
import curam.core.struct.AccountInstructionIdentifier;
import curam.core.struct.BankAccountRMDtls;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ContactRMByConcernKey;
import curam.core.struct.ContactReadKey;
import curam.core.struct.FinancialAccountIdentifier;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.MaintainAddressKey;
import curam.core.struct.MaintainAdminConcernRoleKey;
import curam.core.struct.MaintainBankAccountKey;
import curam.core.struct.MaintainCommExceptionKey;
import curam.core.struct.MaintainConcernRoleAltIDKey;
import curam.core.struct.MaintainConcernRoleKey;
import curam.core.struct.MaintainEmailKey;
import curam.core.struct.MaintainPhoneNumberKey;
import curam.core.struct.ReadConcernRoleAddressKey;
import curam.core.struct.ReadConcernRoleAltIDKey;
import curam.core.struct.ReadConcernRoleBankAcKey;
import curam.core.struct.ReadConcernRoleCommExcKey;
import curam.core.struct.ReadConcernRoleEmailKey;
import curam.core.struct.ReadConcernRoleKey;
import curam.core.struct.ReadConcernRolePhoneKey;
import curam.core.struct.UserNameKey;
import curam.core.struct.ViewConcAccountSummaryResult;
import curam.message.GENERALEXTERNALPARTY;
import curam.serviceplans.facade.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.facade.intf.ServicePlanDelivery;
import curam.serviceplans.facade.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.impl.ServicePlanSecurity;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for the External Party presentation
 * layer.
 *
 */
public abstract class ExternalParty extends curam.core.facade.base.ExternalParty {

  // BEGIN, CR00101406, KH
  // BEGIN, CR00178447, PM
  /**
   * The external party node type. 
   */
  public static final String kTypeExternalParty = XmlMetaDataConst.kTypeExternalParty;

  /**
   * The external party office node type. 
   */
  public static final String kTypeExternalPartyOffice = XmlMetaDataConst.kTypeExternalPartyOffice;

  /**
   * The external party office member node type. 
   */
  public static final String kTypeOfficeMember = XmlMetaDataConst.kTypeOfficeMember;
  // END, CR00178447
  
  /**
   * The Dynamic Menu node. 
   */
  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  /**
   * The Link (child) node. 
   */
  protected static final String kItem = XmlMetaDataConst.kItem;

  /**
   * The page id attribute for a node. 
   */
  protected static final String kPageID = XmlMetaDataConst.kPageID;

  /**
   * The description attribute for a node. 
   */
  protected static final String kDesc = XmlMetaDataConst.kDesc;

  /**
   * The type attribute for a node. 
   */
  protected static final String kType = XmlMetaDataConst.kType;

  /**
   * The parameter attribute for a node. 
   */
  protected static final String kParam = XmlMetaDataConst.kParam;

  /**
   * The name tag for a parameter. 
   */
  protected static final String kName = XmlMetaDataConst.kName;

  /**
   * The value tag for a parameter. 
   */
  protected static final String kValue = XmlMetaDataConst.kValue;

  /**
   * The concern role ID parameter. 
   */
  protected static final String kParamConcernRoleID = XmlMetaDataConst.kParamConcernRoleID;

  /**
   * The external party office ID parameter. 
   */
  protected static final String kParamExternalPartyOfficeID = XmlMetaDataConst.kParamExternalPartyOfficeID;

  /**
   * The external party office member ID parameter. 
   */
  protected static final String kParamExternalPartyOfficeMemberID = XmlMetaDataConst.kParamExternalPartyOfficeMemberID;

  /**
   * The external party homepage URL. 
   */
  protected static final String kExternalPartyHome = UimConst.kExternalPartyHome;

  /**
   * The external party office homepage URL. 
   */
  protected static final String kExternalPartyOfficeHome = UimConst.kExternalPartyOfficeHome;

  /**
   * The external party office member homepage URL. 
   */
  protected static final String kExternalPartyOfficeMemberHome = UimConst.kExternalPartyOfficeMemberHome;
  // END, CR00101406

  // BEGIN, CR00099821, CW
  // BEGIN, CR00100115, KH
  // BEGIN, CR00099033, CW

  /**
   * This method registers an external party with the organization.
   *
   * @param externalPartyRegistrationDetails The details of the external party
   * being registered.
   *
   * @return The external party registration details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyRegistrationResult registerExternalParty(
    final ExternalPartyRegistrationDetails externalPartyRegistrationDetails)
    throws AppException, InformationalException {
    // END, CR00178447 

    // BEGIN, CR00099173, CW
    // Create return object
    final ExternalPartyRegistrationResult externalPartyRegistrationResult = new ExternalPartyRegistrationResult();

    // Register external party
    externalPartyRegistrationResult.externalPartyRegistrationIDDetails = ExternalPartyFactory.newInstance().registerExternalParty(
      externalPartyRegistrationDetails.externalPartyRegistrationDetails);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // BEGIN, CR00099223, CW
    // Handle messages from the informational manager
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    externalPartyRegistrationResult.warnings = informationMsgDtlsList;
    // END, CR00099223

    return externalPartyRegistrationResult;
    // END, CR00099173
  }

  // END, CR00099033

  // BEGIN, CR00099051, CW

  /**
   * This method displays the external party home page details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey Identifies the external party concerned.
   *
   * @return The external party home page details to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyHomePageDetails readExternalPartyHomePageDetails(
    final ExternalPartyKey externalPartyKey)
    throws AppException, InformationalException {
    // END, CR00178447 

    // BEGIN, CR00099199, CW
    // Create return object
    final ExternalPartyHomePageDetails readExternalPartyHomeDetails = new ExternalPartyHomePageDetails();

    // BEGIN, CR00100137, KH
    // Read the external party home page details
    final ReadExternalPartyResult readExternalPartyResult = ExternalPartyFactory.newInstance().readExternalParty(
      externalPartyKey);

    // END, CR00100137

    // BEGIN, CR00099373, CW
    readExternalPartyHomeDetails.externalPartyDetails.assign(
      readExternalPartyResult.details);
    // END, CR00099373

    readExternalPartyHomeDetails.informationalMsgDtlsList = readExternalPartyResult.messages;

    // BEGIN, CR00102890, KH
    readExternalPartyHomeDetails.participantContextDetails.participantContextDescriptionDetails = getExternalPartyContextDescription(
      externalPartyKey);
    // END, CR00102890

    // BEGIN, CR00101406, KH
    readExternalPartyHomeDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);
    // END, CR00101406

    return readExternalPartyHomeDetails;
  }

  // END, CR00099199
  // END, CR00099051

  // BEGIN, CR00099051, CW
  // BEGIN, CR00099223, CW

  /**
   * This method searches for an external party.
   * @param key Identifies the external party information.
   *
   * @return The details of the external party records read from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #searchExternalParty1()}.
   */
  @Deprecated
  // BEGIN, CR00178447, PM
  public ExternalPartySearchResult searchExternalParty(
    final ExternalPartySearchKey key) throws AppException,
      InformationalException {
    // END, CR00178447

    // Create return object
    final ExternalPartySearchResult externalPartySearchResult = new ExternalPartySearchResult();

    // External party search object and key
    final curam.core.sl.intf.ExternalParty externalPartySearchObj = ExternalPartyFactory.newInstance();
    curam.core.sl.struct.ExternalPartySearchKey externalPartySearchKey = new curam.core.sl.struct.ExternalPartySearchKey();

    // Get the details for the search from the search key
    externalPartySearchKey = key.externalPartySearchKey;

    // Search for the details
    externalPartySearchResult.dtlsList = externalPartySearchObj.search(
      externalPartySearchKey);

    return externalPartySearchResult;
  }

  // END, CR00099223
  // END, CR00099051

  // BEGIN, CR00099145, NP

  /**
   * This method registers an external party office with the organization.
   *
   * @param officeDetails The new external party office details.
   *
   * @return A list of validation/informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public InformationMsgDtlsList createExternalPartyOffice(
    final ExternalPartyOfficeDetails officeDetails) throws AppException,
      InformationalException {
    // END, CR00178447

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Flush out the informational manager
    TransactionInfo.setInformationalManager();

    // Create the external party office
    ExternalPartyOfficeFactory.newInstance().createExternalPartyOffice(
      officeDetails);

    // Handle messages from the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // BEGIN, CR00099568, NP

  /**
   * This method lists all offices which belong to the specified external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party offices to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyOfficeList listExternalPartyOffice(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // BEGIN, CR00100310, CW
    // BEGIN, CR00101480, CW
    // Read external party office list
    final ExternalPartyOfficeList externalPartyOfficeList = ExternalPartyOfficeFactory.newInstance().listExternalPartyOffice(
      externalPartyKey);

    // END, CR00101480

    // BEGIN, CR00102890, KH
    externalPartyOfficeList.description = getExternalPartyContextDescription(externalPartyKey).description;
    // END, CR00102890

    // BEGIN, CR00101406, KH
    externalPartyOfficeList.menuData = getExternalPartyMenuData(
      externalPartyKey);
    // END, CR00101406

    return externalPartyOfficeList;
    // END, CR00100310
  }

  /**
   * This method modifies the details of an external party office.
   *
   * @param officeDtls Contains the new external party office details.
   *
   * @return A list of validation/informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public InformationMsgDtlsList modifyExternalPartyOffice(
    final ExternalPartyOfficeDtls officeDtls) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Flush out the informational manager
    TransactionInfo.setInformationalManager();

    // Modify the external party office details
    ExternalPartyOfficeFactory.newInstance().modifyExternalPartyOffice(
      officeDtls);

    // Handle messages from the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // END, CR00099568

  // BEGIN, CR00101406, KH

  /**
   * This method displays the external party office details.
   * As this page is called from the external party office navigation hierarchy, the
   * external party office menu data is also returned.
   *
   * @param officeKey The ID of the external party office member.
   *
   * @return The external party office details to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public curam.core.facade.struct.ExternalPartyOfficeDetails readExternalPartyOffice(
    final ExternalPartyOfficeKey officeKey)
    throws AppException, InformationalException {
    // END, CR00178447

    final curam.core.facade.struct.ExternalPartyOfficeDetails officeDetails = new curam.core.facade.struct.ExternalPartyOfficeDetails();

    officeDetails.dtls = ExternalPartyOfficeFactory.newInstance().readExternalPartyOffice(
      officeKey);

    officeDetails.menuData = getExternalPartyOfficeMenuData(officeKey);

    return officeDetails;
  }

  // END, CR00101406
  // END, CR00099145

  // BEGIN, CR00098924, KH

  /**
   * This method registers an external party office member with the organization.
   *
   * @param details Contains the external party office member details.
   *
   * @return A list of validation/informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public InformationMsgDtlsList createOfficeMember(
    final ExternalPartyOfficeMemberFullDetails details)
    throws AppException, InformationalException {
    // END, CR00178447

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Flush out the informational manager
    TransactionInfo.setInformationalManager();

    // Create the office member
    ExternalPartyOfficeMemberFactory.newInstance().createOfficeMember(details);

    // Handle messages from the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  /**
   * This method displays the external party office member details.
   * As this page is called from the external party office member navigation hierarchy, the
   * external party office member menu data is also returned.
   *
   * @param officeMemberKey The ID of the external party office member.
   *
   * @return The external party office member details to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyOfficeMemberFullDetails readOfficeMember(
    final ExternalPartyOfficeMemberKey officeMemberKey)
    throws AppException, InformationalException {
    // END, CR00178447

    // BEGIN, CR00101406, KH
    final ExternalPartyOfficeMemberFullDetails officeMemberDetails = ExternalPartyOfficeMemberFactory.newInstance().readOfficeMember(
      officeMemberKey);

    officeMemberDetails.menuData = getExternalPartyOfficeMemberMenuData(
      officeMemberKey);

    return officeMemberDetails;
    // END, CR00101406
  }

  /**
   * This method modifies the details of an external party office member.
   *
   * @param details Contains the new external party office member details.
   *
   * @return A list of validation/informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public InformationMsgDtlsList modifyOfficeMember(
    final ExternalPartyOfficeMemberFullDetails details)
    throws AppException, InformationalException {
    // END, CR00178447

    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Flush out the informational manager
    TransactionInfo.setInformationalManager();

    // BEGIN, CR00099834, CW
    // Modify the office member details
    ExternalPartyOfficeMemberFactory.newInstance().modifyOfficeMember(details);
    // END, CR00099834

    // Handle messages from the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  /**
   * This method cancels the external party office member.
   *
   * @param officeMemberKey The ID of the external party office member.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public void cancelOfficeMember(
    final ExternalPartyOfficeMemberKey officeMemberKey)
    throws AppException, InformationalException {
    // END, CR00178447

    // BEGIN, CR00099834, CW
    final ExternalPartyOfficeMember officeMemberObj = curam.core.sl.entity.fact.ExternalPartyOfficeMemberFactory.newInstance();

    final ExternalPartyOfficeMemberDtls details = officeMemberObj.read(
      officeMemberKey);

    officeMemberObj.cancel(officeMemberKey, details);
    // END, CR00099834
  }

  // END, CR00098924

  // BEGIN, CR00099363, CW

  /**
   * This method modifies the details of an external party.
   *
   * @param details Contains the new external party details.
   *
   * @return A list of validation/informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public InformationMsgDtlsList modifyExternalParty(final ExternalPartyDetails details)
    throws AppException, InformationalException {
    // END, CR00178447
    
    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Flush out the informational manager
    TransactionInfo.setInformationalManager();

    // BEGIN, CR00100137, KH
    // Modify the external party details
    ExternalPartyFactory.newInstance().modifyExternalParty(details);
    // END, CR00100137

    // Handle messages from the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // END, CR00099363

  // BEGIN, CR00099256, KH

  /**
   * This method lists all the members who belong to the specified external
   * party office.
   * As this page is called from the external party office navigation hierarchy, the
   * external party office menu data is also returned.
   *
   * @param officeKey The ID of the external party office.
   *
   * @return The list of external party office members to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyOfficeMemberDetailsList listOfficeMember(
    final ExternalPartyOfficeKey officeKey) throws AppException,
      InformationalException {
    // END, CR00178447

    // BEGIN, CR00101406, KH
    final ExternalPartyOfficeMemberDetailsList officeMemberDetailsList = ExternalPartyOfficeMemberFactory.newInstance().listOfficeMember(
      officeKey);

    officeMemberDetailsList.menuData = getExternalPartyOfficeMenuData(officeKey);

    return officeMemberDetailsList;
    // END, CR00101406
  }

  // END, CR00099256

  // BEGIN, CR00099388, NP

  /**
   * This method cancels the external party office and all associated members.
   *
   * @param officeKey The ID of the external party office.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public void cancelExternalPartyOffice(final ExternalPartyOfficeKey officeKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final ExternalPartyOffice externalPartyOfficeObj = curam.core.sl.entity.fact.ExternalPartyOfficeFactory.newInstance();

    final ExternalPartyOfficeDtls details = externalPartyOfficeObj.read(
      officeKey);

    externalPartyOfficeObj.cancel(officeKey, details);
  }

  // END, CR00099388
  // END, CR00099821

  // BEGIN, CR00099939, KH

  /**
   * This method lists all the phone numbers for the specified external party
   * office.
   * As this page is called from the external party office navigation hierarchy, the
   * external party office menu data is also returned.
   *
   * @param officeKey The ID of the external party office.
   *
   * @return The list of external party office phone numbers to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyOfficePhoneNumberDetailsList listOfficePhoneNumber(
    final ExternalPartyOfficeKey officeKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // BEGIN, CR00102719, KH
    final ExternalPartyOfficePhoneNumberDetailsList officePhoneNumberDetailsList = ExternalPartyOfficePhoneNumberFactory.newInstance().listOfficePhoneNumber(
      officeKey);

    officePhoneNumberDetailsList.menuData = getExternalPartyOfficeMenuData(
      officeKey);

    return officePhoneNumberDetailsList;
    // END, CR00102719
  }

  // END, CR00099939

  // BEGIN, CR00099974, KH

  /**
   * This method creates an office phone number for an external party office.
   *
   * @param details Contains the external party office phone number details.
   *
   * @return A list of validation/informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public InformationMsgDtlsList createOfficePhoneNumber(
    final ExternalPartyOfficePhoneNumberDetails details) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Flush out the informational manager
    TransactionInfo.setInformationalManager();

    // Create the office phone number
    ExternalPartyOfficePhoneNumberFactory.newInstance().createOfficePhoneNumber(
      details);

    // Handle messages from the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // BEGIN, CR00102719, KH

  /**
   * This method displays the external party office phone number details.
   * As this page is called from the external party office navigation hierarchy, the
   * external party office menu data is also returned.
   *
   * @param officePhoneNumberKey The ID of the external party office phone number.
   *
   * @return The external party office phone number details to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public curam.core.facade.struct.ExternalPartyOfficePhoneNumberDetails readOfficePhoneNumber(
    final ExternalPartyOfficePhoneNumberKey officePhoneNumberKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final curam.core.facade.struct.ExternalPartyOfficePhoneNumberDetails officePhoneNumberDetails = new curam.core.facade.struct.ExternalPartyOfficePhoneNumberDetails();

    officePhoneNumberDetails.dtls = ExternalPartyOfficePhoneNumberFactory.newInstance().readOfficePhoneNumber(
      officePhoneNumberKey);

    final ExternalPartyOfficeKey officeKey = new ExternalPartyOfficeKey();

    officeKey.externalPartyOfficeID = officePhoneNumberDetails.dtls.officePhoneNumberDtls.externalPartyOfficeID;

    officePhoneNumberDetails.menuData = getExternalPartyOfficeMenuData(
      officeKey);

    return officePhoneNumberDetails;
  }

  // END, CR00102719


  /**
   * This method modifies the details of an external party office phone number.
   *
   * @param details Contains the new external party office phone number details.
   *
   * @return A list of validation/informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public InformationMsgDtlsList modifyOfficePhoneNumber(
    final ExternalPartyOfficePhoneNumberDetails details) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Flush out the informational manager
    TransactionInfo.setInformationalManager();

    ExternalPartyOfficePhoneNumberFactory.newInstance().modifyOfficePhoneNumber(
      details);

    // Handle messages from the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  /**
   * This method cancels the external party office phone number.
   *
   * @param officePhoneNumberKey The ID of the external party office phone
   * number.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public void cancelOfficePhoneNumber(
    final ExternalPartyOfficePhoneNumberKey officePhoneNumberKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    // BEGIN, CR00100540, CW
    ExternalPartyOfficePhoneNumberFactory.newInstance().cancelOfficePhoneNumber(
      officePhoneNumberKey);
    // END, CR00100540
  }

  // END, CR00099974

  // BEGIN, CR00099958, CW

  /**
   * This method lists all the addresses for the specified external party office.
   * As this page is called from the external party office navigation hierarchy, the
   * external party office menu data is also returned.
   *
   * @param officeKey The ID of the external party office.
   *
   * @return The list of external party office addresses to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyOfficeAddressDetailsList listOfficeAddress(
    final ExternalPartyOfficeKey officeKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // BEGIN, CR00102719, KH
    final ExternalPartyOfficeAddressDetailsList officeAddressDetailsList = ExternalPartyOfficeAddressFactory.newInstance().listOfficeAddress(
      officeKey);

    officeAddressDetailsList.menuData = getExternalPartyOfficeMenuData(
      officeKey);

    return officeAddressDetailsList;
    // END, CR00102719
  }

  // END, CR00099958

  // BEGIN, CR00099984, CW

  /**
   * This method creates an office address for an external party office.
   *
   * @param details Contains the external party office address details.
   *
   * @return A list of validation/informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public InformationMsgDtlsList createOfficeAddress(
    final ExternalPartyOfficeAddressDetails details) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Flush out the informational manager
    TransactionInfo.setInformationalManager();

    // Create the external party office address record
    ExternalPartyOfficeAddressFactory.newInstance().createOfficeAddress(details);

    // Handle messages from the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // END, CR00099984

  // BEGIN, CR00099984, CW

  /**
   * This method modifies the details of an external party office address.
   *
   * @param details Contains the new external party office address details.
   *
   * @return A list of validation/informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public InformationMsgDtlsList modifyOfficeAddress(
    final ExternalPartyOfficeAddressDetails details) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // Create return object
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Flush out the informational manager
    TransactionInfo.setInformationalManager();

    // Set up the parameters to service layer modify
    final MaintainExternalPartyOfficeAddressDtls dtls = new MaintainExternalPartyOfficeAddressDtls();

    dtls.assign(details.officeAddressDtls);
    dtls.assign(details.addressDtls);
    // BEGIN, CR00100045, CW
    dtls.primaryAddressInd = details.primaryAddressInd;
    dtls.versionNo = details.officeAddressDtls.versionNo;
    // END, CR00100045

    final ExternalPartyOfficeKey key = new ExternalPartyOfficeKey();

    key.externalPartyOfficeID = details.officeAddressDtls.externalPartyOfficeID;

    // BEGIN, CR00100045, CW
    // Modify the external party office address
    ExternalPartyOfficeAddressFactory.newInstance().modifyOfficeAddress(key,
      dtls);
    // END, CR00100045

    // Handle messages from the informational manager
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // END, CR00099984

  // BEGIN, CR00099984, CW
  // BEGIN, CR00102719, KH

  /**
   * This method displays the external party office address details.
   * As this page is called from the external party office navigation hierarchy, the
   * external party office menu data is also returned.
   *
   * @param officeAddressKey The ID of the external party office address.
   *
   * @return The external party office address details to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public curam.core.facade.struct.ExternalPartyOfficeAddressDetails readOfficeAddress(
    final ExternalPartyOfficeAddressKey officeAddressKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final curam.core.facade.struct.ExternalPartyOfficeAddressDetails officeAddressDetails = new curam.core.facade.struct.ExternalPartyOfficeAddressDetails();

    officeAddressDetails.dtls = ExternalPartyOfficeAddressFactory.newInstance().readOfficeAddress(
      officeAddressKey);

    final ExternalPartyOfficeKey officeKey = new ExternalPartyOfficeKey();

    officeKey.externalPartyOfficeID = officeAddressDetails.dtls.officeAddressDtls.externalPartyOfficeID;

    officeAddressDetails.menuData = getExternalPartyOfficeMenuData(officeKey);

    return officeAddressDetails;
  }

  // END, CR00102719
  // END, CR00099984

  // BEGIN, CR00099984, CW

  /**
   * This method cancels the external party office address.
   *
   * @param officeAddressKey The ID of the external party office address.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public void cancelOfficeAddress(
    final ExternalPartyOfficeAddressKey officeAddressKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    // BEGIN, CR00100045, CW
    ExternalPartyOfficeAddressFactory.newInstance().cancelOfficeAddress(
      officeAddressKey);
    // END, CR00100045
  }

  // END, CR00099984
  // END, CR00100115

  // BEGIN, CR00101406, KH

  /**
   * This method lists all the email address which belong to the specified
   * external party office member.
   * As this page is called from the external party office member navigation hierarchy, the
   * external party office member menu data is also returned.
   *
   * @param officeMemberKey The ID of the external party office member.
   *
   * @return The list of office member email addresses to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyOfficeMemberEmailList listOfficeMemberEmailAddress(
    final ExternalPartyOfficeMemberKey officeMemberKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyOfficeMemberEmailList officeMemberEmailList = new ExternalPartyOfficeMemberEmailList();

    // Get the concern role Id of the office member
    final ExternalPartyOfficeMemberFullDetails officeMemberDetails = ExternalPartyOfficeMemberFactory.newInstance().readOfficeMember(
      officeMemberKey);

    final ReadParticipantEmailAddressListKey emailListKey = new ReadParticipantEmailAddressListKey();

    emailListKey.maintainEmailKey.concernRoleID = officeMemberDetails.concernRoleDtls.concernRoleID;

    officeMemberEmailList.dtls = MaintainConcernRoleEmailFactory.newInstance().readmultiByConcernRole(emailListKey.maintainEmailKey).details;

    officeMemberEmailList.menuData = getExternalPartyOfficeMemberMenuData(
      officeMemberKey);
    officeMemberEmailList.concernRoleID = officeMemberDetails.concernRoleDtls.concernRoleID;
    officeMemberEmailList.concernRoleName = officeMemberDetails.concernRoleDtls.concernRoleName;

    return officeMemberEmailList;
  }

  /**
   * This method displays the external party office member email address details.
   * As this page is called from the external party office member navigation hierarchy, the
   * external party office member menu data is also returned.
   *
   * @param emailKey The ID of the email address.
   *
   * @return The office member email address details to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyOfficeMemberEmailDetails readOfficeMemberEmailAddress(
    final ReadConcernRoleEmailKey emailKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyOfficeMemberEmailDetails officeMemberEmailDetails = new ExternalPartyOfficeMemberEmailDetails();

    // Read the email address
    officeMemberEmailDetails.dtls = MaintainConcernRoleEmailFactory.newInstance().readEmailAddress(
      emailKey);

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = officeMemberEmailDetails.dtls.concernRoleID;

    final ExternalPartyOfficeMemberDtls officeMemberDtls = curam.core.sl.entity.fact.ExternalPartyOfficeMemberFactory.newInstance().readByConcernRoleID(
      concernRoleKey);

    final ExternalPartyOfficeMemberKey officeMemberKey = new ExternalPartyOfficeMemberKey();

    officeMemberKey.officeMemberID = officeMemberDtls.officeMemberID;

    officeMemberEmailDetails.menuData = getExternalPartyOfficeMemberMenuData(
      officeMemberKey);

    return officeMemberEmailDetails;
  }

  // BEGIN, CR00102890, KH

  /**
   * This method lists all the addresses which belong to the specified
   * external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party addresses to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyAddressDetailsList listExternalPartyAddress(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyAddressDetailsList addressList = new ExternalPartyAddressDetailsList();

    final MaintainAddressKey addressListKey = new MaintainAddressKey();

    addressListKey.concernRoleID = externalPartyKey.concernRoleID;

    addressList.dtls = MaintainConcernRoleAddressFactory.newInstance().readmultiByConcernRoleID(addressListKey).details;

    addressList.description = getExternalPartyContextDescription(
      externalPartyKey);

    addressList.menuData = getExternalPartyMenuData(externalPartyKey);

    return addressList;
  }

  // BEGIN, CR00103074, KH

  /**
   * This method displays the external party address details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param concernRoleAddressKey The ID of the concern role address.
   *
   * @return The details of the external party address to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyAddressDetails readExternalPartyAddress(
    final ReadConcernRoleAddressKey concernRoleAddressKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final ExternalPartyAddressDetails addressDetails = new ExternalPartyAddressDetails();

    addressDetails.dtls = MaintainConcernRoleAddressFactory.newInstance().readAddress(
      concernRoleAddressKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = addressDetails.dtls.concernRoleID;

    addressDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return addressDetails;
  }

  // END, CR00103074


  /**
   * This method lists all the email addresses which belong to the specified
   * external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party email addresses to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyEmailAddressDetailsList listExternalPartyEmailAddress(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyEmailAddressDetailsList emailAddressList = new ExternalPartyEmailAddressDetailsList();

    final MaintainEmailKey emailListKey = new MaintainEmailKey();

    emailListKey.concernRoleID = externalPartyKey.concernRoleID;

    emailAddressList.dtls = MaintainConcernRoleEmailFactory.newInstance().readmultiByConcernRole(emailListKey).details;

    emailAddressList.description = getExternalPartyContextDescription(
      externalPartyKey);

    emailAddressList.menuData = getExternalPartyMenuData(externalPartyKey);

    return emailAddressList;
  }

  // BEGIN, CR00103074, KH

  /**
   * This method displays the external party email address details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param concernRoleEmailAddressKey The ID of the concern role email address.
   *
   * @return The details of the external party email address to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyEmailAddressDetails readExternalPartyEmailAddress(
    final ReadConcernRoleEmailKey concernRoleEmailAddressKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final ExternalPartyEmailAddressDetails emailAddressDetails = new ExternalPartyEmailAddressDetails();

    emailAddressDetails.dtls = MaintainConcernRoleEmailFactory.newInstance().readEmailAddress(
      concernRoleEmailAddressKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = emailAddressDetails.dtls.concernRoleID;

    emailAddressDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return emailAddressDetails;
  }

  // END, CR00103074


  /**
   * This method lists all the phone numbers which belong to the specified
   * external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party phone numbers to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyPhoneDetailsList listExternalPartyPhoneNumber(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyPhoneDetailsList phoneList = new ExternalPartyPhoneDetailsList();

    final MaintainPhoneNumberKey phoneListKey = new MaintainPhoneNumberKey();

    phoneListKey.concernRoleID = externalPartyKey.concernRoleID;

    phoneList.dtls = MaintainConcernRolePhoneFactory.newInstance().readmultiByConcernRole(phoneListKey).details;

    phoneList.description = getExternalPartyContextDescription(externalPartyKey);

    phoneList.menuData = getExternalPartyMenuData(externalPartyKey);

    return phoneList;
  }

  // BEGIN, CR00103074, KH

  /**
   * This method displays the external party phone number details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param concernRolePhoneNumberKey The ID of the concern role phone number.
   *
   * @return The details of the external party phone number to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyPhoneDetails readExternalPartyPhoneNumber(
    final ReadConcernRolePhoneKey concernRolePhoneNumberKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final ExternalPartyPhoneDetails phoneDetails = new ExternalPartyPhoneDetails();

    phoneDetails.dtls = MaintainConcernRolePhoneFactory.newInstance().readPhoneNumber(
      concernRolePhoneNumberKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = phoneDetails.dtls.concernRoleID;

    phoneDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return phoneDetails;
  }

  /**
   * This method lists all the alternate IDs which belong to the specified
   * external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party alternate IDs to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyAlternateIDDetailsList listExternalPartyAlternateID(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyAlternateIDDetailsList alternateIDList = new ExternalPartyAlternateIDDetailsList();

    final MaintainConcernRoleAltIDKey alternateIDListKey = new MaintainConcernRoleAltIDKey();

    alternateIDListKey.concernRoleID = externalPartyKey.concernRoleID;

    alternateIDList.dtls = MaintainConcernRoleAltIDFactory.newInstance().readmultiByConcernRoleID(alternateIDListKey).details;

    alternateIDList.description = getExternalPartyContextDescription(
      externalPartyKey);

    alternateIDList.menuData = getExternalPartyMenuData(externalPartyKey);

    return alternateIDList;
  }

  /**
   * This method displays the external party alternate ID details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param concernRoleAlternateIDKey The ID of the concern role alternate ID.
   *
   * @return The details of the external party alternate ID to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyAlternateIDDetails readExternalPartyAlternateID(
    final ReadConcernRoleAltIDKey concernRoleAlternateIDKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final ExternalPartyAlternateIDDetails alternateIDDetails = new ExternalPartyAlternateIDDetails();

    alternateIDDetails.dtls = MaintainConcernRoleAltIDFactory.newInstance().readAlternateID(
      concernRoleAlternateIDKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = alternateIDDetails.dtls.concernRoleID;

    alternateIDDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return alternateIDDetails;
  }

  // BEGIN, CR00178447, PM
  /**
   * This method lists all the bank accounts which belong to the specified
   * external party. 
   * As this page is called from the external party navigation hierarchy, the 
   * external party menu data is also returned.
   *
   * @param externalPartyKey
   * Contains the ID of the external party.
   *
   * @return The list of external party bank accounts to be displayed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 5.2 SP3, replaced with
   * {@link ExternalParty#
   * listExternalPartyBankAccount1(ExternalPartyKey)}.
   * This method is being deprecated because it is not returning any
   * informational message. So the new method
   * listExternalPartyBankAccount1() displays an informational
   * message if the end date has passed on the primary record. See
   * release note : CS-07331/CR00178447.
   */
  @Deprecated
  public ExternalPartyBankAccountDetailsList listExternalPartyBankAccount(
    final ExternalPartyKey externalPartyKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final ExternalPartyBankAccountDetailsList bankAccountList = new ExternalPartyBankAccountDetailsList();

    final MaintainBankAccountKey bankAccountListKey = new MaintainBankAccountKey();

    bankAccountListKey.concernRoleID = externalPartyKey.concernRoleID;

    bankAccountList.dtls = MaintainConcernRoleBankAcFactory.newInstance().readmultiByConcernRole(bankAccountListKey).details;

    bankAccountList.description = getExternalPartyContextDescription(
      externalPartyKey);

    bankAccountList.menuData = getExternalPartyMenuData(externalPartyKey);

    return bankAccountList;
  }

  // BEGIN, CR00178447, PM
  /**
   * This method replaces the deprecated method
   * {@link ExternalParty#listExternalPartyBankAccount(ExternalPartyKey)}.
   * <P>
   * This method lists all the bank accounts which belong to the specified
   * external party. It also displays an informational message if the end date
   * has passed on the primary record.
   *
   * @param externalPartyKey
   * Contains the ID of the external party.
   *
   * @return The list of external party bank accounts to be displayed along with
   * the informational messages if any.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */  
  public ExternalPartyBankAccountList listExternalPartyBankAccount1(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    final ExternalPartyBankAccountList externalPartyBankAccountList = new ExternalPartyBankAccountList();

    final MaintainBankAccountKey maintainBankAccountKey = new MaintainBankAccountKey();

    maintainBankAccountKey.concernRoleID = externalPartyKey.concernRoleID;

    externalPartyBankAccountList.dtls = MaintainConcernRoleBankAcFactory.newInstance().readmultiByConcernRole(maintainBankAccountKey).details;

    externalPartyBankAccountList.description = getExternalPartyContextDescription(
      externalPartyKey);
    
    // BEGIN, CR00371769, VT
    // BEGIN, CR00372632, VT
    // Bank Account values should be displayed based on following logic
    // 1. If IBAN is entered, Bank Account field will populate the IBAN.
    // 2. If Basic Bank Account Number (BBAN) is entered, Bank Account field
    // will populate the BBAN.
    // 3. If IBAN and BBAN are entered, Bank Account field will populate the
    // IBAN value.

    for (final BankAccountRMDtls bankAccountRMDtls : externalPartyBankAccountList.dtls.dtls) {
      if (0 != bankAccountRMDtls.ibanOpt.length()) {
        bankAccountRMDtls.bankAccountNumberOpt = bankAccountRMDtls.ibanOpt;
      } else {
        bankAccountRMDtls.bankAccountNumberOpt = bankAccountRMDtls.accountNumber;
      }
    }
    // END, CR00372632
    // END, CR00371769


    externalPartyBankAccountList.menuData = getExternalPartyMenuData(
      externalPartyKey);

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (final String warning : warnings) {
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warning;
      externalPartyBankAccountList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return externalPartyBankAccountList;
  }

  // END, CR00178447


  /**
   * This method displays the external party bank account details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param concernRoleBankAccountKey The ID of the concern role bank account.
   *
   * @return The details of the external party bank account to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyBankAccountDetails readExternalPartyBankAccount(
    final ReadConcernRoleBankAcKey concernRoleBankAccountKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final ExternalPartyBankAccountDetails bankAccountDetails = new ExternalPartyBankAccountDetails();

    bankAccountDetails.dtls = MaintainConcernRoleBankAcFactory.newInstance().readBankAccount(
      concernRoleBankAccountKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = bankAccountDetails.dtls.concernRoleID;

    bankAccountDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return bankAccountDetails;
  }

  /**
   * This method lists all the active bank accounts which belong to the
   * specified external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of active external party bank accounts to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyBankAccountDetailsList listExternalPartyActiveBankAccount(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyBankAccountDetailsList activeBankAccountList = new ExternalPartyBankAccountDetailsList();

    final MaintainConcernRoleKey bankAccountListKey = new MaintainConcernRoleKey();

    bankAccountListKey.concernRoleID = externalPartyKey.concernRoleID;

    activeBankAccountList.dtls = MaintainConcernRoleBankAcFactory.newInstance().readmultiByConcernRoleForNomineeWizard(bankAccountListKey).nomineeBankAccountList;
    
    // BEGIN, CR00372632, VT
    // Bank Account values should be displayed based on following logic
    // 1. If IBAN is entered, Bank Account field will populate the IBAN.
    // 2. If Basic Bank Account Number (BBAN) is entered, Bank Account field
    // will populate the BBAN.
    // 3. If IBAN and BBAN are entered, Bank Account field will populate the
    // IBAN value.

    for (final BankAccountRMDtls bankAccountRMDtls : activeBankAccountList.dtls.dtls) {
      if (0 != bankAccountRMDtls.ibanOpt.length()) {
        bankAccountRMDtls.bankAccountNumberOpt = bankAccountRMDtls.ibanOpt;
      } else {
        bankAccountRMDtls.bankAccountNumberOpt = bankAccountRMDtls.accountNumber; 
      }
    }
    // END, CR00372632

    activeBankAccountList.description = getExternalPartyContextDescription(
      externalPartyKey);

    activeBankAccountList.menuData = getExternalPartyMenuData(externalPartyKey);

    return activeBankAccountList;
  }

  /**
   * This method lists all the communication exceptions which belong to the
   * specified external party. As this page is called from the external party
   * navigation hierarchy, the external party menu data is also returned.
   *
   * @param externalPartyKey
   * The ID of the external party.
   *
   * @return The list of external party communication exceptions to be
   * displayed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyCommunicationExceptionDetailsList listExternalPartyCommunicationException(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyCommunicationExceptionDetailsList commExceptionList = new ExternalPartyCommunicationExceptionDetailsList();

    final MaintainCommExceptionKey commExceptionListKey = new MaintainCommExceptionKey();

    commExceptionListKey.concernRoleID = externalPartyKey.concernRoleID;

    commExceptionList.dtls = MaintainConcernRoleCommExceptionFactory.newInstance().readmultiByConcernRole(
      commExceptionListKey);

    commExceptionList.description = getExternalPartyContextDescription(
      externalPartyKey);

    commExceptionList.menuData = getExternalPartyMenuData(externalPartyKey);

    return commExceptionList;
  }

  /**
   * This method displays the external party communication exception details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param concernRoleCommExceptionKey The ID of the concern role communication
   * exception.
   *
   * @return The details of the external party communication exception to be
   * displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyCommunicationExceptionDetails readExternalPartyCommunicationException(
    final ReadConcernRoleCommExcKey concernRoleCommExceptionKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final ExternalPartyCommunicationExceptionDetails commExceptionDetails = new ExternalPartyCommunicationExceptionDetails();

    commExceptionDetails.dtls = MaintainConcernRoleCommExceptionFactory.newInstance().readCommException(
      concernRoleCommExceptionKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = commExceptionDetails.dtls.concernRoleID;

    commExceptionDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return commExceptionDetails;
  }

  // BEGIN, CR00231506, PDN

  /**
   * This method lists all the notes which belong to the specified external
   * party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party notes to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #listExternalPartyNote1()}
   */  
  @Deprecated
  // BEGIN, CR00178447, PM
  public ExternalPartyNoteDetailsList listExternalPartyNote(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyNoteDetailsList noteList = new ExternalPartyNoteDetailsList();

    final ParticipantKey noteListKey = new ParticipantKey();

    noteListKey.key.participantID = externalPartyKey.concernRoleID;

    noteList.dtls = ParticipantNoteFactory.newInstance().list(noteListKey);

    noteList.description = getExternalPartyContextDescription(externalPartyKey);

    noteList.menuData = getExternalPartyMenuData(externalPartyKey);

    return noteList;
  }
  
  /**
   * This method lists all the notes which belong to the specified external
   * party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party notes to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyNoteDetailsList1 listExternalPartyNote1(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyNoteDetailsList1 noteList1 = new ExternalPartyNoteDetailsList1();

    final ParticipantKey noteListKey = new ParticipantKey();

    noteListKey.key.participantID = externalPartyKey.concernRoleID;

    noteList1.dtls = ParticipantNoteFactory.newInstance().list1(noteListKey);

    noteList1.description = getExternalPartyContextDescription(externalPartyKey);

    noteList1.menuData = getExternalPartyMenuData(externalPartyKey);

    return noteList1;
  }  
 
  /**
   * This method displays the external party note details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   * @param noteKey The ID of the note.
   *
   * @return The details of the external party note to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #readExternalPartyNote1()}
   */
  // BEGIN, CR00178447, PM
  @Deprecated
  public ExternalPartyNoteDetails readExternalPartyNote(
    final ParticipantNoteKey noteKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyNoteDetails noteDetails = new ExternalPartyNoteDetails();

    noteDetails.dtls = ParticipantNoteFactory.newInstance().read(noteKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = noteDetails.dtls.noteDetails.participantID;

    noteDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return noteDetails;
  }
  
  /**
   * This method displays the external party note details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param noteKey The ID of the note.
   *
   * @return The details of the external party note to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyNoteDetails1 readExternalPartyNote1(
    final ParticipantNoteKey noteKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyNoteDetails1 noteDetails = new ExternalPartyNoteDetails1();

    noteDetails.dtls = ParticipantNoteFactory.newInstance().read1(noteKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = noteDetails.dtls.noteDetails.participantID;

    noteDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return noteDetails;
  }  
  
  // END, CR00231506   

  // END, CR00103074

  // BEGIN, CR00103430, KH
  // BEGIN, CR00294967, MV
  /**
   * This method lists all the contacts which belong to the specified external
   * party. As this page is called from the external party navigation hierarchy,
   * the external party menu data is also returned.
   *
   * @param externalPartyKey
   * The ID of the external party.
   *
   * @return The list of external party contacts to be displayed.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by
   * {@link #listExternalPartyConcernContact()}. The return struct of
   * the current method listExternalPartyContact has an
   * aggregation to the struct ConcernContactRMDtls, the attribute
   * statusCode in the struct ConcernContactRMDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct
   * ExternalPartyConcernContactDetailsList which has an
   * aggregation to the new struct ConcernContactRMultiDtls where
   * the attribute statusCode is modeled with a domain of
   * RECORD_STATUS_CODE. See release note: CEF-8999.
   */
  @Deprecated
  // END, CR00294967
  
  // BEGIN, CR00178447, PM
  public ExternalPartyContactDetailsList listExternalPartyContact(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyContactDetailsList contactList = new ExternalPartyContactDetailsList();

    final ContactRMByConcernKey contactListKey = new ContactRMByConcernKey();

    contactListKey.concernRoleID = externalPartyKey.concernRoleID;

    contactList.dtls = MaintainContactsFactory.newInstance().readmultiByConcernRoleID(
      contactListKey);

    // Get the concern role type for each contact
    if (!contactList.dtls.dtls.isEmpty()) {

      // Concern Role object and key
      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

      for (int i = 0; i < contactList.dtls.dtls.size(); i++) {

        concernRoleKey.concernRoleID = contactList.dtls.dtls.item(i).contactConRoleID;

        concernRoleDtls = concernRoleObj.read(concernRoleKey);

        contactList.dtls.dtls.item(i).contactConcernRoleType = concernRoleDtls.concernRoleType;
      }
    }

    contactList.description = getExternalPartyContextDescription(
      externalPartyKey);

    contactList.menuData = getExternalPartyMenuData(externalPartyKey);

    return contactList;
  }
  
  // BEGIN, CR00294967, MV
  /**
   * This method lists all the contacts which belong to the specified external
   * party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party contacts to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ExternalPartyConcernContactDetailsList listExternalPartyConcernContact(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    
    final ExternalPartyConcernContactDetailsList contactList = new ExternalPartyConcernContactDetailsList();

    final ContactRMByConcernKey contactListKey = new ContactRMByConcernKey();

    contactListKey.concernRoleID = externalPartyKey.concernRoleID;

    contactList.dtls = MaintainContactsFactory.newInstance().readmultiConcernContactByConcernRoleID(
      contactListKey);

    contactList.description = getExternalPartyContextDescription(
      externalPartyKey);

    contactList.menuData = getExternalPartyMenuData(externalPartyKey);

    return contactList;
  }

  /**
   * This method displays the external party contact details. As this page is
   * called from the external party navigation hierarchy, the external party
   * menu data is also returned.
   *
   * @param contactKey
   * The ID of the contact.
   *
   * @return The details of the external party contact to be displayed.
   *
   * @throws AppException
   * Generic Exception Signature.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by
   * {@link #readExternalPartyConcernContact()}. The return struct
   * of the current method readExternalPartyContact has an
   * aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct
   * ExternalPartyConcernContactDetails which has an aggregation
   * to the new struct ConcernContactRMultiDtls where the
   * attribute statusCode is modeled with a domain of
   * RECORD_STATUS_CODE. See release note: CEF-8999.
   */
  @Deprecated
  // END, CR00294967
  
  // BEGIN, CR00178447, PM
  public ExternalPartyContactDetails readExternalPartyContact(
    final ContactReadKey contactKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyContactDetails contactDetails = new ExternalPartyContactDetails();

    contactDetails.dtls = MaintainContactsFactory.newInstance().readContact(
      contactKey);

    // Get the concern role type
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = contactDetails.dtls.contactConRoleID;

    contactDetails.dtls.contactConcernRoleType = ConcernRoleFactory.newInstance().read(concernRoleKey).concernRoleType;

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = contactDetails.dtls.concernRoleID;

    contactDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return contactDetails;
  }
  
  // BEGIN, CR00294967, MV
  /**
   * This method displays the external party contact details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param contactKey The ID of the contact.
   *
   * @return The details of the external party contact to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ExternalPartyConcernContactDetails readExternalPartyConcernContact(
    final ContactReadKey contactKey) throws AppException,
      InformationalException {
    
    final ExternalPartyConcernContactDetails contactDetails = new ExternalPartyConcernContactDetails();

    contactDetails.dtls = MaintainContactsFactory.newInstance().readConcernContact(
      contactKey);

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // BEGIN, CR00305441, MV
    // BEGIN, CR00304525, MV
    concernRoleKey.concernRoleID = contactDetails.dtls.concernRoleID;

    contactDetails.dtls.contactConcernRoleType = ConcernRoleFactory.newInstance().read(concernRoleKey).concernRoleType;
    // END, CR00304525
    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = contactDetails.dtls.concernRoleID;
    contactDetails.dtls.companyContactTypeCode = contactDetails.dtls.contactTypeCode;
    contactDetails.dtls.contactTypeCode = CuramConst.gkEmpty;
    // END, CR00305441
    contactDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return contactDetails;
  }

  // END, CR00294967
  
  /**
   * This method lists all the web addresses which belong to the specified
   * external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party web addresses to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyWebAddressDetailsList listExternalPartyWebAddress(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyWebAddressDetailsList webAddressList = new ExternalPartyWebAddressDetailsList();

    final ConcernRoleIDKey webListKey = new ConcernRoleIDKey();

    webListKey.concernRoleID = externalPartyKey.concernRoleID;

    webAddressList.dtls = WebAddressFactory.newInstance().list(webListKey);

    webAddressList.description = getExternalPartyContextDescription(
      externalPartyKey);

    webAddressList.menuData = getExternalPartyMenuData(externalPartyKey);

    return webAddressList;
  }

  /**
   * This method displays the external party web address details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param concernRoleWebAddressKey The ID of the concern role web address.
   *
   * @return The details of the external party web address to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyWebAddressDetails readExternalPartyWebAddress(
    final ConcernRoleWebAddressKey concernRoleWebAddressKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final ExternalPartyWebAddressDetails webAddressDetails = new ExternalPartyWebAddressDetails();

    webAddressDetails.dtls = WebAddressFactory.newInstance().read(
      concernRoleWebAddressKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = webAddressDetails.dtls.dtls.concernRoleID;

    webAddressDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return webAddressDetails;
  }

  // END, CR00103430

  // BEGIN, CR00103571, KH

  // BEGIN, CR00177505, RPB
  /**
   * @param externalPartyKey
   * The ID of the external party.
   *
   * @return The list of external party administration roles to be displayed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listExternalPartyAdministrators(ExternalPartyKey)}.
   *
   * This method lists all the administration roles which belong to the
   * specified external party. As this page is called from the external party
   * navigation hierarchy, the external party menu data is also returned.
   */
  @Deprecated
  // BEGIN, CR00178447, PM
  public ExternalPartyAdminRoleDetailsList listExternalPartyAdminRole(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyAdminRoleDetailsList adminRoleList = new ExternalPartyAdminRoleDetailsList();

    final MaintainAdminConcernRoleKey adminRoleKey = new MaintainAdminConcernRoleKey();

    adminRoleKey.concernRoleID = externalPartyKey.concernRoleID;

    adminRoleList.dtls = MaintainAdminConcernRoleFactory.newInstance().readmultiByConcernRole(
      adminRoleKey);

    adminRoleList.description = getExternalPartyContextDescription(
      externalPartyKey);

    adminRoleList.menuData = getExternalPartyMenuData(externalPartyKey);

    return adminRoleList;
  }

  /**
   * Lists all the administrators for the specified external party. As this page
   * is called from the external party navigation hierarchy, the external party
   * menu data is also returned.
   *
   * @param externalPartyKey
   * Contains the ID of the external party.
   *
   * @return The list of external party administrators to be displayed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyAdministratorDetailsList listExternalPartyAdministrators(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    final ExternalPartyAdministratorDetailsList externalPartyAdministratorDetailsList = new ExternalPartyAdministratorDetailsList();
    final MaintainAdminConcernRoleKey maintainAdminRoleKey = new MaintainAdminConcernRoleKey();

    maintainAdminRoleKey.concernRoleID = externalPartyKey.concernRoleID;
    externalPartyAdministratorDetailsList.adminConcernRoleDetailsList = MaintainAdminConcernRoleFactory.newInstance().readAdministratorsForConcernRole(
      maintainAdminRoleKey);
    externalPartyAdministratorDetailsList.participantContextDescriptionDetails = getExternalPartyContextDescription(
      externalPartyKey);
    externalPartyAdministratorDetailsList.menuDetails = getExternalPartyMenuData(
      externalPartyKey);
    return externalPartyAdministratorDetailsList;
  }

  // END, CR00177505


  /**
   * This method lists all the concern roles which belong to the specified
   * external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party concern roles to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyConcernRoleDetailsList listExternalPartyConcernRole(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyConcernRoleDetailsList concernRoleList = new ExternalPartyConcernRoleDetailsList();

    final ReadConcernRoleKey concernRoleKey = new ReadConcernRoleKey();

    concernRoleKey.concernRoleID = externalPartyKey.concernRoleID;

    concernRoleList.dtls = MaintainConcernRoleDetailsFactory.newInstance().readListOfConcernRoles(
      concernRoleKey);

    concernRoleList.description = getExternalPartyContextDescription(
      externalPartyKey);

    concernRoleList.menuData = getExternalPartyMenuData(externalPartyKey);

    return concernRoleList;
  }

  /**
   * This method lists all the interactions which belong to the specified
   * external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party interactions to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyInteractionDetailsList listExternalPartyInteraction(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyInteractionDetailsList interactionList = new ExternalPartyInteractionDetailsList();

    // BEGIN, CR00192165, VM
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = externalPartyKey.concernRoleID;
    final ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();

    interactionList.dtls = clientInteractionObj.listForParticipant(
      concernRoleKey);
    // END, CR00192165

    interactionList.description = getExternalPartyContextDescription(
      externalPartyKey);

    interactionList.menuData = getExternalPartyMenuData(externalPartyKey);

    return interactionList;
  }

  /**
   * This method displays the external party interaction details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param interactionKey The ID of the interaction.
   *
   * @return The details of the external party interaction to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyInteractionDetails readExternalPartyInteraction(
    final ReadInteractionKey interactionKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyInteractionDetails interactionDetails = new ExternalPartyInteractionDetails();

    // BEGIN, CR00192165, VM
    final ClientInteractionKey clientInteractionKey = new ClientInteractionKey();

    clientInteractionKey.clientInteractionID = interactionKey.clientInteractionID;

    final ClientInteractionDtls clientInteractionDtls = ClientInteractionFactory.newInstance().view(
      clientInteractionKey);

    interactionDetails.dtls.assign(clientInteractionDtls);
    // END, CR00192165

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = interactionDetails.dtls.concernRoleID;

    interactionDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return interactionDetails;
  }

  /**
   * This method lists all the tasks which belong to the specified external
   * party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party tasks to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyTaskDetailsList listExternalPartyTask(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyTaskDetailsList taskList = new ExternalPartyTaskDetailsList();

    final SearchTaskForConcernOrCaseKey taskListKey = new SearchTaskForConcernOrCaseKey();

    taskListKey.details.linkedID = externalPartyKey.concernRoleID;

    taskList.dtls = WorkAllocationTaskFactory.newInstance().listConcernRoleTasks(
      taskListKey);

    // BEGIN, CR00140814, CW
    // Iterate through the task list and set the reservedBy flag
    for (int i = 0; i < taskList.dtls.dtls.dtls.size(); i++) {

      if (taskList.dtls.dtls.dtls.item(i).reservedBy.length() > 0) {

        taskList.dtls.dtls.dtls.item(i).reservedByExistsInd = true;
      }
    }
    // END, CR00140814

    taskList.description = getExternalPartyContextDescription(externalPartyKey);

    taskList.menuData = getExternalPartyMenuData(externalPartyKey);

    return taskList;
  }

  // END, CR00103571

  // BEGIN, CR00103596, KH

  /**
   * This method lists all the financials which belong to the specified external
   * party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party financials to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyFinancialDetailsList listExternalPartyFinancial(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyFinancialDetailsList financialList = new ExternalPartyFinancialDetailsList();

    // Set key to search for the external party financials
    final FinancialAccountIdentifier financialListKey = new FinancialAccountIdentifier();

    financialListKey.concernRoleID = externalPartyKey.concernRoleID;

    final ViewConcAccountSummaryResult viewConcernRoleAccountSummary = ViewConcernAccountFactory.newInstance().viewConcernRoleAccountSummary(
      financialListKey);

    // Iterate through the list if it's populated
    if (!viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.isEmpty()) {

      // Reserve space in the output object
      financialList.dtls.dtls.ensureCapacity(
        viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.size());

      ParticipantFinancials participantFinancials;

      for (int i = 0; i
        < viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.size(); i++) {

        participantFinancials = new ParticipantFinancials();

        participantFinancials.assign(
          viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.item(i));

        // Amounts are always stored on the database in the base currency and
        // always read back as such. The base currency is returned here for
        // display purposes. The amounts in the money field(s) on each row will
        // be shown in the following format: "USD 1000"
        participantFinancials.currencyType = viewConcernRoleAccountSummary.concernRoleAccSummHeader.currencyType;

        // Add details to the list
        financialList.dtls.dtls.addRef(participantFinancials);
      } // end for i
    }

    financialList.description = getExternalPartyContextDescription(
      externalPartyKey);

    financialList.menuData = getExternalPartyMenuData(externalPartyKey);

    return financialList;
  }

  /**
   * This method lists all issued payment instruments where the specified
   * external party is the client or the nominee.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of issued payment instruments to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyIssuedPaymentInstrumentDetailsList listExternalPartyIssuedPaymentInstrument(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyIssuedPaymentInstrumentDetailsList financialList = new ExternalPartyIssuedPaymentInstrumentDetailsList();

    final ConcernRoleID financialListKey = new ConcernRoleID();

    financialListKey.concernRoleID = externalPartyKey.concernRoleID;

    financialList.dtls = ViewConcernAccountFactory.newInstance().listConcernNomineeIssuedPaymentInstrument(
      financialListKey);

    financialList.description = getExternalPartyContextDescription(
      externalPartyKey);

    financialList.menuData = getExternalPartyMenuData(externalPartyKey);

    return financialList;
  }

  /**
   * This method lists all the communications which belong to the specified
   * external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param externalPartyKey The ID of the external party.
   *
   * @return The list of external party communications to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link Participant#listCommunication()}.
   */
  @Deprecated
  // BEGIN, CR00178447, PM
  public ExternalPartyCommunicationDetailsList listExternalPartyCommunication(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyCommunicationDetailsList communicationList = new ExternalPartyCommunicationDetailsList();

    final CommunicationKey communicationListKey = new CommunicationKey();

    communicationListKey.concernRoleID = externalPartyKey.concernRoleID;

    communicationList.dtls = CommunicationFactory.newInstance().listCommunication(
      communicationListKey);

    communicationList.description = getExternalPartyContextDescription(
      externalPartyKey);

    communicationList.menuData = getExternalPartyMenuData(externalPartyKey);

    return communicationList;
  }

  /**
   * This method displays the external party recorded communication details. As
   * this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param readRecordedCommKey
   * The ID of the recorded communication.
   *
   * @return The details of the external party communication to be displayed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link Communication#readExternalPartyCommunication1(ReadRecordedCommKey)}
   * . See release note: CR00237138.
   */
  // BEGIN, CR00178447, PM
  @Deprecated
  public ExternalPartyCommunicationDetails readExternalPartyCommunication(
    final ReadRecordedCommKey readRecordedCommKey) throws AppException,
      InformationalException {
    // END, CR00178447

    final ExternalPartyCommunicationDetails communicationDetails = new ExternalPartyCommunicationDetails();

    communicationDetails.dtls = curam.core.facade.fact.CommunicationFactory.newInstance().readRecordedCommunication(
      readRecordedCommKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = communicationDetails.dtls.recordedCommDetails.clientParticipantRoleID;

    communicationDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return communicationDetails;
  }

  // BEGIN, CR00237138, NS
  /**
   * This method displays the external party recorded communication details. As
   * this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param readRecordedCommKey
   * The ID of the recorded communication.
   *
   * @return The details of the external party communication to be displayed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ExternalPartyCommunicationDetails1 readExternalPartyCommunication1(
    ReadRecordedCommKey key) throws AppException, InformationalException {

    final ExternalPartyCommunicationDetails1 communicationDetails = new ExternalPartyCommunicationDetails1();

    communicationDetails.dtls = curam.core.facade.fact.CommunicationFactory.newInstance().readRecordedCommunication1(
      key);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = communicationDetails.dtls.recordedCommDetails.clientParticipantRoleID;

    communicationDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return communicationDetails;
  }

  // END, CR00237138

  /**
   * This method displays the external party email communication details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param readEmailCommKey The ID of the email communication.
   *
   * @return The details of the external party email to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyEmailDetails readExternalPartyEmail(
    final ReadEmailCommKey readEmailCommKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyEmailDetails emailDetails = new ExternalPartyEmailDetails();

    emailDetails.dtls = curam.core.facade.fact.CommunicationFactory.newInstance().readEmail(
      readEmailCommKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = emailDetails.dtls.details.clientParticipantRoleID;

    emailDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return emailDetails;
  }

  /**
   * This method displays the external party ms word communication details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param readMSWordCommunicationKey The ID of the ms word communication.
   *
   * @return The details of the external party ms word to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyMSWordDetails readExternalPartyMSWord(
    final ReadMSWordCommunicationKey readMSWordCommunicationKey)
    throws AppException, InformationalException {
    // END, CR00178447
    
    final ExternalPartyMSWordDetails msWordDetails = new ExternalPartyMSWordDetails();

    final Communication communicationObj = curam.core.facade.fact.CommunicationFactory.newInstance();
        
    final ReadMSWordCommunicationDetails readMSWordCommunicationDetails = new ReadMSWordCommunicationDetails();
    
    final ReadMSWordCommunicationDetails1 readMSWordCommunicationDetails1 = communicationObj.readMSWordCommunication1(
      readMSWordCommunicationKey);
    
    readMSWordCommunicationDetails.dtls.assign(
      readMSWordCommunicationDetails1.dtls);
    
    msWordDetails.dtls = readMSWordCommunicationDetails;

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = msWordDetails.dtls.dtls.participantRoleID;

    msWordDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return msWordDetails;
  }

  /**
   * This method displays the external party pro forma communication details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param readProFormaCommKey The ID of the pro forma communication.
   *
   * @return The details of the external party pro forma to be displayed.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyProFormaDetails readExternalPartyProForma(
    final ReadProFormaCommKey readProFormaCommKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyProFormaDetails proFormaDetails = new ExternalPartyProFormaDetails();

    // BEGIN, CR00232757, GD
    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj = curam.core.sl.fact.CommunicationFactory.newInstance();

    // Communication ID Key
    final curam.core.sl.struct.CommunicationIDKey communicationIDKey = new curam.core.sl.struct.CommunicationIDKey();

    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // set communication key
    communicationIDKey.communicationID = readProFormaCommKey.proFormaCommKey.communicationID;

    // set case key
    caseKey.caseID = communicationObj.readCaseID(communicationIDKey).caseID;

    if (caseKey.caseID != 0) {
      // read case type code
      final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

      // if case type is service plan, check service plan security
      if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

        // ServicePlanDelivery facade
        final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
        final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

        // register the service plan security implementation
        ServicePlanSecurityImplementationFactory.register();

        // set the key
        servicePlanSecurityKey.caseID = caseKey.caseID;
        servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

        // check security
        servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      }
    } 

    // BEGIN, CR00236672, NS
    // Call service layer method to modify an email communication.
    final ProFormaCommDetails1 proFormaCommDetails1 = new ProFormaCommDetails1();

    proFormaCommDetails1.readProFormaCommDetails = communicationObj.readProForma1(
      readProFormaCommKey.proFormaCommKey);
    
    proFormaDetails.dtls.readProFormaCommDetails.assign(
      proFormaCommDetails1.readProFormaCommDetails);
    // END, CR00232757

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = proFormaDetails.dtls.readProFormaCommDetails.clientParticipantRoleID;

    proFormaDetails.menuData = getExternalPartyMenuData(externalPartyKey);

    return proFormaDetails;
  }

  // END, CR00103596


  /**
   * This method generates the context description data for an external party.
   *
   * @param externalPartyKey Contains the external party identifier.
   *
   * @return Context description data for the external party.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  @Override
  protected ParticipantContextDescriptionDetails getExternalPartyContextDescription(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ParticipantContextDescriptionKey key = new ParticipantContextDescriptionKey();

    key.concernRoleID = externalPartyKey.concernRoleID;

    return ParticipantContextFactory.newInstance().readContextDescription(key);
  }

  // END, CR00102890


  /**
   * This method generates the dynamic menu data for an external party.
   *
   * @param externalPartyKey Contains the external party identifier.
   *
   * @return Menu data for the external party.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public MenuDataDetails getExternalPartyMenuData(
    final ExternalPartyKey externalPartyKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // Create return object
    final MenuDataDetails menuDataDetails = new MenuDataDetails();

    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Retrieve the external party details
    final ExternalPartyDtls externalPartyDtls = curam.core.sl.entity.fact.ExternalPartyFactory.newInstance().read(
      externalPartyKey);

    // Build the child node and add it to the root node
    navigationMenuElement.addContent(buildExternalPartyNode(externalPartyDtls));

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    menuDataDetails.menuData = outputter.outputString(navigationMenuElement);

    return menuDataDetails;
  }

  /**
   * This method generates the dynamic menu data for an external party office.
   *
   * @param officeKey Contains the external party office identifier.
   *
   * @return Menu data for the external party office.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  @Override
  protected MenuDataDetails getExternalPartyOfficeMenuData(
    final ExternalPartyOfficeKey officeKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // Create return object
    final MenuDataDetails menuDataDetails = new MenuDataDetails();

    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Retrieve the external party office details
    final ExternalPartyOfficeDtls officeDtls = curam.core.sl.entity.fact.ExternalPartyOfficeFactory.newInstance().read(
      officeKey);

    // Retrieve the external party details
    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = officeDtls.concernRoleID;
    final ExternalPartyDtls externalPartyDtls = curam.core.sl.entity.fact.ExternalPartyFactory.newInstance().read(
      externalPartyKey);

    // Build the child nodes and add them to the root node
    navigationMenuElement.addContent(buildExternalPartyNode(externalPartyDtls));
    navigationMenuElement.addContent(buildExternalPartyOfficeNode(officeDtls));

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    menuDataDetails.menuData = outputter.outputString(navigationMenuElement);

    return menuDataDetails;
  }

  /**
   * This method generates the dynamic menu data for an external party office
   * member.
   *
   * @param officeMemberKey Contains the external party office member identifier.
   *
   * @return Menu data for the external party office member.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  @Override
  protected MenuDataDetails getExternalPartyOfficeMemberMenuData(
    final ExternalPartyOfficeMemberKey officeMemberKey) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // Create return object
    final MenuDataDetails menuDataDetails = new MenuDataDetails();

    // Create Root Node
    final Element navigationMenuElement = new Element(kNavigationMenu);

    // Retrieve the external party office member details
    final ExternalPartyOfficeMemberFullDetails officeMemberDetails = ExternalPartyOfficeMemberFactory.newInstance().readOfficeMember(
      officeMemberKey);

    // Retrieve the external party office details
    final ExternalPartyOfficeKey officeKey = new ExternalPartyOfficeKey();

    officeKey.externalPartyOfficeID = officeMemberDetails.officeMemberDtls.externalPartyOfficeID;
    final ExternalPartyOfficeDtls officeDtls = curam.core.sl.entity.fact.ExternalPartyOfficeFactory.newInstance().read(
      officeKey);

    // Retrieve the external party details
    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = officeDtls.concernRoleID;
    final ExternalPartyDtls externalPartyDtls = curam.core.sl.entity.fact.ExternalPartyFactory.newInstance().read(
      externalPartyKey);

    // Build the child nodes and add them to the root node
    navigationMenuElement.addContent(buildExternalPartyNode(externalPartyDtls));
    navigationMenuElement.addContent(buildExternalPartyOfficeNode(officeDtls));
    navigationMenuElement.addContent(
      buildExternalPartyOfficeMemberNode(officeMemberDetails));

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    menuDataDetails.menuData = outputter.outputString(navigationMenuElement);

    return menuDataDetails;
  }

  /**
   * This method creates the external party node of the dynamic menu.
   *
   * @param externalPartyDtls Contains the details of the external party.
   *
   * @return The external party node.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  // BEGIN, CR00198672, VK
  protected Element buildExternalPartyNode(
    final ExternalPartyDtls externalPartyDtls) throws AppException,
      InformationalException {
    // END, CR00178447
    // END, CR00198672
    // Create Node (link elements)
    final Element linkElement = new Element(kItem);

    final LocalisableString description = new LocalisableString(
      GENERALEXTERNALPARTY.INF_DYNAMIC_MENU_DESCRIPTION_DOUBLE);

    description.arg(externalPartyDtls.name);
    description.arg(externalPartyDtls.primaryAlternateID);

    // Setting the link page ID, description and type
    linkElement.setAttribute(kPageID, kExternalPartyHome);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeExternalParty);

    // Create parameter
    final Element paramElement = new Element(kParam);

    // Set the parameters name and value
    paramElement.setAttribute(kName, kParamConcernRoleID);
    paramElement.setAttribute(kValue,
      String.valueOf(externalPartyDtls.concernRoleID));

    // Add the parameter elements to the node
    linkElement.addContent(paramElement);

    return linkElement;
  }

  /**
   * This method creates the external party office node of the dynamic menu.
   *
   * @param officeDtls
   * Contains the details of the external party office.
   *
   * @return The external party office node.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  // BEGIN, CR00198672, VK
  protected Element buildExternalPartyOfficeNode(
    final ExternalPartyOfficeDtls officeDtls) throws AppException,
      InformationalException {
    // END, CR00178447
    // END, CR00198672
    // Create Node (link elements)
    final Element linkElement = new Element(kItem);

    final LocalisableString description = new LocalisableString(
      GENERALEXTERNALPARTY.INF_DYNAMIC_MENU_DESCRIPTION_SINGLE);

    description.arg(officeDtls.name);

    // Setting the link page ID, description and type
    linkElement.setAttribute(kPageID, kExternalPartyOfficeHome);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeExternalPartyOffice);

    // Create parameter
    final Element paramElement = new Element(kParam);

    // Set the parameters name and value
    paramElement.setAttribute(kName, kParamExternalPartyOfficeID);
    paramElement.setAttribute(kValue,
      String.valueOf(officeDtls.externalPartyOfficeID));

    // Add the parameter elements to the node
    linkElement.addContent(paramElement);

    return linkElement;
  }

  /**
   * This method creates the external party office member node of the dynamic
   * menu.
   *
   * @param officeMemberDetails Contains the full details of the office member.
   *
   * @return The external party office member node.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  // BEGIN, CR00198672, VK
  protected Element buildExternalPartyOfficeMemberNode(
    final ExternalPartyOfficeMemberFullDetails officeMemberDetails)
    throws AppException, InformationalException {
    // END, CR00178447
    // END, CR00198672
    // Create Node (link elements)
    final Element linkElement = new Element(kItem);

    final LocalisableString description = new LocalisableString(
      GENERALEXTERNALPARTY.INF_DYNAMIC_MENU_DESCRIPTION_DOUBLE);

    description.arg(officeMemberDetails.concernRoleDtls.concernRoleName);
    description.arg(officeMemberDetails.concernRoleDtls.primaryAlternateID);

    // Setting the link page ID, description and type
    linkElement.setAttribute(kPageID, kExternalPartyOfficeMemberHome);
    linkElement.setAttribute(kDesc, description.toClientFormattedText());
    linkElement.setAttribute(kType, kTypeOfficeMember);

    // Create parameter
    final Element paramElement = new Element(kParam);

    // Set the parameters name and value
    paramElement.setAttribute(kName, kParamExternalPartyOfficeMemberID);
    paramElement.setAttribute(kValue,
      String.valueOf(officeMemberDetails.officeMemberDtls.officeMemberID));

    // Add the parameter elements to the node
    linkElement.addContent(paramElement);

    return linkElement;
  }

  // END, CR00101406

  // BEGIN, CR00104187, CW
  /**
   * Reads the details of an adjustment instruction for an external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key to read details of the adjustment instruction
   *
   * @return Adjustment instruction details for the external party.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyAdjustmentInstructionResult readExternalPartyAdjustmentInstruction(
    final ReadAdjustmentInstructionKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyAdjustmentInstructionResult externalPartyAdjustmentInstructionResult = new ExternalPartyAdjustmentInstructionResult();
    
    // BEGIN, CR00232757, GD
    // ViewConcernAccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();
    final AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

    // Set key to retrieve adjustment instruction details
    accountInstructionIdentifier.finInstructionID = key.financialInstructionID;
    accountInstructionIdentifier.concernRoleID = key.concernRoleID;
    
    final ReadAdjustmentInstructionResult readAdjustmentInstructionResult = new ReadAdjustmentInstructionResult();
    
    // Retrieve adjustment instruction details
    readAdjustmentInstructionResult.result = viewConcernAccountObj.viewAdjustmentInstructionDetail(
      accountInstructionIdentifier);

    // Add a context description
    final FinancialContextDescriptionKey financialContextDescriptionKey = new FinancialContextDescriptionKey();

    // Details to be returned.
    financialContextDescriptionKey.finInstructionID = key.financialInstructionID;

    // Read financial context description
    readAdjustmentInstructionResult.contextDescription.contextDescription = FinancialContextFactory.newInstance().readContextDescription(financialContextDescriptionKey).contextDescription;
    // END, CR00232757    

    // Retrieve adjustment instruction details
    externalPartyAdjustmentInstructionResult.dtls.result = viewConcernAccountObj.viewAdjustmentInstructionDetail(
      accountInstructionIdentifier);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = externalPartyAdjustmentInstructionResult.dtls.result.adjustmentHeader.concernRoleID;

    externalPartyAdjustmentInstructionResult.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyAdjustmentInstructionResult;
  }

  // END, CR00104187

  // BEGIN, CR00104187, CW

  /**
   * Reads details of an Instruction Line Item for an external party.
   * This can be a component of a payment, liability,
   * payment received, reversal or write-off.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Contains an Instruction Line Item identifier.
   *
   * @return Details of the Instruction Line Item.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyInstructionLineItemDetails readExternalPartyInstructionLineItemDetails(
    final ReadInstructionLineItemKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyInstructionLineItemDetails externalPartyInstructionLineItemDetails = new ExternalPartyInstructionLineItemDetails();

    externalPartyInstructionLineItemDetails.dtls = curam.core.facade.fact.FinancialFactory.newInstance().readInstructionLineItemDetails(
      key);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    if (!externalPartyInstructionLineItemDetails.dtls.primaryClientType.equalsIgnoreCase(
      curam.codetable.CONCERNROLETYPE.EXTERNALPARTY)) {

      // The line item is not directly associated with the external party so we need to
      // read the financial instruction to determine the external party concern role id

      final ReadPaymentInstructionKey paymentInstructionKey = new ReadPaymentInstructionKey();

      paymentInstructionKey.finInstructionID = externalPartyInstructionLineItemDetails.dtls.finInstructionID;
      
      // BEGIN, CR00232757, GD
      final ReadPaymentInstructionDetails1 readPaymentInstructionDetails1 = curam.core.facade.fact.FinancialFactory.newInstance().readPaymentInstruction1(
        paymentInstructionKey);

      // END, CR00232757
      
      externalPartyKey.concernRoleID = readPaymentInstructionDetails1.paymentHeaderDetails.concernRoleID;

    } else {
      // The line item is directly associated with the external party
      externalPartyKey.concernRoleID = externalPartyInstructionLineItemDetails.dtls.primaryClientID;
    }

    externalPartyInstructionLineItemDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyInstructionLineItemDetails;
  }

  // END, CR00104187

  // BEGIN, CR00104187, CW

  /**
   * Returns details of a Payment Instruction for an external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key to search for the Payment Instruction details.
   *
   * @return Payment Instruction details.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyPaymentInstructionDetails readExternalPartyPaymentInstruction(
    final ReadPaymentInstructionKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    
    // BEGIN, CR00232757, GD
    final ExternalPartyPaymentInstructionDetails externalPartyPaymentInstructionDetails = new ExternalPartyPaymentInstructionDetails();

    final ReadPaymentInstructionDetails readPaymentInstructionDetails = new ReadPaymentInstructionDetails();
    
    final ReadPaymentInstructionDetails1 readPaymentInstructionDetails1 = curam.core.facade.fact.FinancialFactory.newInstance().readPaymentInstruction1(
      key);
    
    readPaymentInstructionDetails.assign(readPaymentInstructionDetails1);
    
    readPaymentInstructionDetails.informationalMsgDtlsList = readPaymentInstructionDetails1.informationalMsgDtlsList;

    readPaymentInstructionDetails.paymentHeaderDetails.assign(
      readPaymentInstructionDetails1.paymentHeaderDetails);
    // END, CR00225016

    PaymentILIDetails paymentILIDetails;
    PaymentDetails paymentDetails;

    for (int i = 0; i
      < readPaymentInstructionDetails1.paymentILIList.dtls.size(); i++) {

      paymentILIDetails = readPaymentInstructionDetails1.paymentILIList.dtls.item(
        i);
      paymentDetails = new PaymentDetails();

      paymentDetails = paymentILIDetails.paymentItemDetails;

      readPaymentInstructionDetails.paymentDetailsList.dtls.addRef(
        paymentDetails);
    }
    
    externalPartyPaymentInstructionDetails.dtls = readPaymentInstructionDetails;
    // END, CR00232757
    
    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = externalPartyPaymentInstructionDetails.dtls.paymentHeaderDetails.concernRoleID;

    externalPartyPaymentInstructionDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyPaymentInstructionDetails;
  }

  // END, CR00104187

  // BEGIN, CDR00104187, CW

  /**
   * Returns a resource details.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the external party concern role id and the resource key.
   *
   * @return Details of the resource.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyResourceDetails readExternalPartyResource(
    final ExternalPartyResourceKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyResourceDetails externalPartyResourceDetails = new ExternalPartyResourceDetails();

    externalPartyResourceDetails.dtls = curam.core.facade.fact.OrganizationFactory.newInstance().readResource(
      key.readResourceKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyResourceDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyResourceDetails;
  }

  // END, CR00104187

  // BEGIN, CR00104187, CW

  /**
   * Retrieve the homepage details for a user.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the external party concern role id and the identifier for a user
   *
   * @return Homepage details for a user
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link ExternalParty#readExternalPartyUserHomePageDetails(ExternalPartyUserHomePageKey key)}.
   * As part of CLE changes the implementation has been moved to
   * readExternalPartyUserHomePageDetails with a new return struct
   * ExternalPartyUserDetails. This struct has all the fields of
   * ExternalPartyUserHomePageDetails struct along with fields
   * toRedirectID and toRedirectType. See release note : <CR00216807>
   */
  @Deprecated
  // BEGIN, CR00178447, PM
  public curam.core.facade.struct.ExternalPartyUserHomePageDetails readExternalPartyUserHomePage(
    final ExternalPartyUserHomePageKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final curam.core.facade.struct.ExternalPartyUserHomePageDetails externalPartyUserHomePageDetails = new curam.core.facade.struct.ExternalPartyUserHomePageDetails();

    externalPartyUserHomePageDetails.dtls = curam.core.facade.fact.OrganizationFactory.newInstance().readUserHomePage(
      key.readUserHomePageKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyUserHomePageDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyUserHomePageDetails;
  }

  // END, CR00104187

  // BEGIN, CR00104187, CW

  /**
   * Returns the details regarding a specific task for an external party.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the external party concern role id and the unique identifier of the task
   *
   * @return Task details
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyTaskDetails viewExternalPartyTaskHome(
    final ExternalPartyTaskManagementTaskKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    final ExternalPartyTaskDetails externalPartyTaskDetails = new ExternalPartyTaskDetails();

    externalPartyTaskDetails.dtls = curam.core.facade.fact.TaskManagementFactory.newInstance().viewTaskHome(
      key.taskManagementTaskKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyTaskDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyTaskDetails;
  }

  // END, CR00104187

  // BEGIN, CR00104187, CW

  /**
   * This process will return a list of printers.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the external party concern role id.
   * @return A list of printers.
   */
  // BEGIN, CR00178447, PM
  public ListExternalPartyPrintersDetails listExternalPartyPrinters(
    final ExternalPartyKey key) throws AppException, InformationalException {
    // END, CR00178447
    
    final ListExternalPartyPrintersDetails listExternalPartyPrintersDetails = new ListExternalPartyPrintersDetails();

    listExternalPartyPrintersDetails.dtls = curam.core.facade.fact.OrganizationFactory.newInstance().listPrinters();

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    listExternalPartyPrintersDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return listExternalPartyPrintersDetails;
  }

  // END, CR00104187

  // BEGIN, CR00104187, CW

  // BEGIN, CR00216807 MN
  /**
   * Returns a list of the task redirection records for a specified user. Two
   * lists of data are returned. The first contains the details of the all the
   * active and pending task redirection records for the specified user. The
   * second list contains a list of all the expired task redirection history
   * records for the specified user.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the id of the user and the external party concern role id.
   *
   * @return a list of all task redirection records for the specified user.
   *
   * @deprecated Since Curam 6.0 , replaced with
   * {@link ExternalParty#getExternalPartyTaskRedirectionHistoryForUser(UserNameKey key)}.
   * As part of CLE changes the implementation has been moved to
   * getExternalPartyTaskRedirectionHistoryForUser with a new return struct
   * ExtPartyTaskRedirectionsFromUserDetails. This struct has all the fields of
   * ExternalPartyTaskRedirectionsFromUserDetails struct along with fields
   * toRedirectID and toRedirectType. See release note : <CR00216807>
   */
  @Deprecated
  // BEGIN, CR00178447, PM
  public curam.core.facade.struct.ExternalPartyTaskRedirectionsFromUserDetails listExternalPartyTaskRedirectionHistoryForUser(
    final ExternalPartyUserNameKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    final ExtPartyTaskRedirectionsFromUserDetails details = this.getExternalPartyTaskRedirectionHistoryForUser(
      key);

    final curam.core.facade.struct.ExternalPartyTaskRedirectionsFromUserDetails externalPartyTaskRedirectionsFromUserDetails = new curam.core.facade.struct.ExternalPartyTaskRedirectionsFromUserDetails();

    final curam.core.sl.supervisor.struct.AllTaskRedirectionsFromUserDetails allTaskRedirectionsFromUserDetails = new curam.core.sl.supervisor.struct.AllTaskRedirectionsFromUserDetails();

    // BEGIN, CR00225492 MN
    // populating Active and Pending Task Redirection details.
    RedirectTaskDetails redirectActiveAndPendingTaskDetails = null;

    final curam.core.sl.supervisor.struct.TaskRedirectionDetails taskRedirectionDetails = new curam.core.sl.supervisor.struct.TaskRedirectionDetails();

    final ActiveAndPendingTaskRedirectionFromUserDetailsList activeAndPendingTaskRedirectionDetailsList = new ActiveAndPendingTaskRedirectionFromUserDetailsList();

    for (int i = 0; i
      < details.dtls.activeAndPendingTaskRedirectionDetails.activeAndPendingDetails.size(); i++) {
      redirectActiveAndPendingTaskDetails = details.dtls.activeAndPendingTaskRedirectionDetails.activeAndPendingDetails.get(
        i);

      taskRedirectionDetails.endDateTime = redirectActiveAndPendingTaskDetails.endDateTime;
      taskRedirectionDetails.redirectionStatus = redirectActiveAndPendingTaskDetails.redirectionStatus;
      taskRedirectionDetails.startDateTime = redirectActiveAndPendingTaskDetails.startDateTime;
      taskRedirectionDetails.taskRedirectionID = redirectActiveAndPendingTaskDetails.taskRedirectionID;
      taskRedirectionDetails.toUserFullName = redirectActiveAndPendingTaskDetails.toUserFullName;
      taskRedirectionDetails.toUserName = redirectActiveAndPendingTaskDetails.toUserName;

      activeAndPendingTaskRedirectionDetailsList.activeAndPendingDtls.addRef(
        taskRedirectionDetails);
    }

    allTaskRedirectionsFromUserDetails.activeAndPendingTaskRedirections = activeAndPendingTaskRedirectionDetailsList;
    // _________________________________________________________
    // populating Expired Task Redirection details.
    RedirectTaskDetails redirectExpiredAndPendingTaskDetails = null;

    final curam.core.sl.supervisor.struct.TaskRedirectionDetails expiredTaskRedirectionDetails = new curam.core.sl.supervisor.struct.TaskRedirectionDetails();

    final ExpiredTaskRedirectionFromUserDetailsList expiredTaskRedirectionDetailsList = new ExpiredTaskRedirectionFromUserDetailsList();

    for (int i = 0; i
      < details.dtls.expiredTaskRedirectionDetails.expiredDetails.size(); i++) {
      redirectExpiredAndPendingTaskDetails = details.dtls.expiredTaskRedirectionDetails.expiredDetails.get(
        i);

      expiredTaskRedirectionDetails.endDateTime = redirectExpiredAndPendingTaskDetails.endDateTime;
      expiredTaskRedirectionDetails.redirectionStatus = redirectExpiredAndPendingTaskDetails.redirectionStatus;
      expiredTaskRedirectionDetails.startDateTime = redirectExpiredAndPendingTaskDetails.startDateTime;
      expiredTaskRedirectionDetails.taskRedirectionID = redirectExpiredAndPendingTaskDetails.taskRedirectionID;
      expiredTaskRedirectionDetails.toUserFullName = redirectExpiredAndPendingTaskDetails.toUserFullName;
      expiredTaskRedirectionDetails.toUserName = redirectExpiredAndPendingTaskDetails.toUserName;

      expiredTaskRedirectionDetailsList.expiredDtls.addRef(
        expiredTaskRedirectionDetails);
    }

    allTaskRedirectionsFromUserDetails.expiredTaskRedirections = expiredTaskRedirectionDetailsList;
    // END, CR00225492

    externalPartyTaskRedirectionsFromUserDetails.dtls = allTaskRedirectionsFromUserDetails;
    externalPartyTaskRedirectionsFromUserDetails.menuData = details.menuData;

    return externalPartyTaskRedirectionsFromUserDetails;
  }

  // END, CR00216807
  // END, CR00104187

  // BEGIN, CR00104187, CW

  /**
   * Reads details about the location specified by the key.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the location identifier and the external party concern role id.
   *
   * @return location details.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyReadLocationDetails readExternalPartyLocation(
    final ExternalPartyReadLocationKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyReadLocationDetails externalPartyReadLocationDetails = new ExternalPartyReadLocationDetails();

    externalPartyReadLocationDetails.dtls = curam.core.facade.fact.OrganizationFactory.newInstance().readLocation(
      key.readLocationKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyReadLocationDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyReadLocationDetails;
  }

  // END, CR00104187

  // BEGIN, CR00104187, CW
  // BEGIN, CR00175973, PDN

  /**
   * Retrieves the list of users and work queues currently assigned to a task.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the unique identifier of the task and the
   * external party concern role id..
   *
   * @return the list of users and work queues currently assigned to a task.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #viewExternalPartyAssignmentList1()}.
   */
  @Deprecated
  // BEGIN, CR00178447, PM
  public ExternalPartyTaskAssignmentDetails viewExternalPartyAssignmentList(
    final ExternalPartyTaskManagementTaskKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyTaskAssignmentDetails externalPartyTaskAssignmentDetails = new ExternalPartyTaskAssignmentDetails();

    externalPartyTaskAssignmentDetails.assign(
      viewExternalPartyAssignmentList1(key));

    return externalPartyTaskAssignmentDetails;
  }

  // END, CR00104187



  /**
   * Retrieves the list of users and work queues currently assigned to a task.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the unique identifier of the task and the
   * external party concern role id.
   *
   * @return the list of users and work queues currently assigned to a task.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyTaskAssignmentDetails1 viewExternalPartyAssignmentList1(
    final ExternalPartyTaskManagementTaskKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyTaskAssignmentDetails1 externalPartyTaskAssignmentDetails1 = new ExternalPartyTaskAssignmentDetails1();

    externalPartyTaskAssignmentDetails1.dtls = curam.core.facade.fact.TaskManagementFactory.newInstance().viewAssignmentList1(
      key.taskManagementTaskKey);
    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyTaskAssignmentDetails1.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyTaskAssignmentDetails1;
  }

  // END, CR00175973

  // BEGIN, CR00104187, CW

  /**
   * Displays task history text for the specified task.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the unique identifier of the task and the external party concern role id.
   *
   * @return Task history text details
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyTaskHistoryTextDetails viewExternalPartyHistoryText(
    final ExternalPartyTaskManagementTaskKey key) throws AppException,
      InformationalException {

    // END, CR00178447
    
    final ExternalPartyTaskHistoryTextDetails externalPartyTaskHistoryTextDetails = new ExternalPartyTaskHistoryTextDetails();

    externalPartyTaskHistoryTextDetails.dtls = curam.core.facade.fact.TaskManagementFactory.newInstance().viewHistoryText(
      key.taskManagementTaskKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyTaskHistoryTextDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyTaskHistoryTextDetails;
  }

  // END, CR00104187

  // BEGIN, CR00104187, CW

  /**
   * Retrieves the XML necessary to visualize a process instance associated
   * with a task.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the unique identifier of the task and the external party concern role id.
   *
   * @return an XML representation of a graphical view of the process instance
   * associated with a task.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyWorkflowGraphDetails visualiseExternalPartyProcessInstanceForTask(
    final ExternalPartyTaskManagementTaskKey key) throws AppException,
      InformationalException {

    // END, CR00178447
    
    final ExternalPartyWorkflowGraphDetails externalPartyWorkflowGraphDetails = new ExternalPartyWorkflowGraphDetails();

    externalPartyWorkflowGraphDetails.dtls = curam.core.facade.fact.TaskManagementFactory.newInstance().visualiseProcessInstanceForTask(
      key.taskManagementTaskKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyWorkflowGraphDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyWorkflowGraphDetails;
  }

  // END, CR00104187

  // BEGIN, CR00104738, CW

  /**
   * Presentation layer operation to list resources for a location.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the LocationID of the location containing resources and the external party concern role id.
   *
   * @return Resources within a location.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyListResourcesForLocationDetails listExternalPartyResourcesForLocation(
    final ExternalPartyListResourcesForLocationKey key) throws AppException,
      InformationalException {

    // END, CR00178447
    
    final ExternalPartyListResourcesForLocationDetails externalPartyListResourcesForLocationDetails = new ExternalPartyListResourcesForLocationDetails();

    externalPartyListResourcesForLocationDetails.dtls = curam.core.facade.fact.OrganizationFactory.newInstance().listResourcesForLocation(
      key.listResourcesForLocationKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyListResourcesForLocationDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyListResourcesForLocationDetails;
  }

  // END, CR00104738


  // BEGIN, CR00104738, CW
  /**
   * Returns an XML string containing the Location Holidays to be displayed on
   * the calendar.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the start date and the calendar view type and the external party concern role id.
   *
   * @return An XML string containing all holidays for the location.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyReadAllLocationHolidayDetails_fo readAllExternalPartyLocationHoliday(
    final ExternalPartyReadAllLocationHolidayKey_fo key) throws AppException,
      InformationalException {

    // END, CR00178447
    
    final ExternalPartyReadAllLocationHolidayDetails_fo externalPartyReadAllLocationHolidayDetails_fo = new ExternalPartyReadAllLocationHolidayDetails_fo();

    externalPartyReadAllLocationHolidayDetails_fo.dtls = curam.core.facade.fact.OrganizationFactory.newInstance().readAllLocationHoliday(
      key.readAllLocationHolidayKey_fo);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyReadAllLocationHolidayDetails_fo.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyReadAllLocationHolidayDetails_fo;
  }

  // END, CR00104738

  // BEGIN, CR00104738, CW
  /**
   * Reads details of the security role.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Contains the security role identifier and the external party concern role id.
   *
   * @return Security role details, including groups in role and groups not
   * in role.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyReadSecurityRole readExternalPartySecurityRole(
    final ExternalPartySecurityRoleKey key) throws AppException,
      InformationalException {

    // END, CR00178447
    
    final ExternalPartyReadSecurityRole externalPartyReadSecurityRole = new ExternalPartyReadSecurityRole();

    externalPartyReadSecurityRole.dtls = curam.core.facade.fact.SystemFactory.newInstance().readSecurityRole(
      key.securityRoleKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyReadSecurityRole.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyReadSecurityRole;
  }

  // END, CR00104738

  // BEGIN, CR00104738, CW
  /**
   * Returns a list of security roles.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Contains the ID of the external party.
   *
   * @return List of security role details.
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyListSecurityRoleDetails listExternalPartySecurityRole(
    final ExternalPartyKey key) throws AppException, InformationalException {

    // END, CR00178447
    
    final ExternalPartyListSecurityRoleDetails externalPartyListSecurityRoleDetails = new ExternalPartyListSecurityRoleDetails();

    externalPartyListSecurityRoleDetails.dtls = curam.core.facade.fact.SystemFactory.newInstance().listSecurityRole();

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyListSecurityRoleDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyListSecurityRoleDetails;

  }

  // END, CR00104738

  // BEGIN, CR00117610, RKi
  /**
   * @param externalPartyOfficeSearchKey Identifies the external party office
   * information.
   *
   * @return The details of the external party office records read from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #searchExternalPartyOffice1()}.
   *
   * This method searches for an external party office.
   */
  @Deprecated
  // BEGIN, CR00178447, PM
  public ExternalPartyOfficeSearchResult searchExternalPartyOffice(
    final ExternalPartyOfficeSearchKey externalPartyOfficeSearchKey)
    throws AppException, InformationalException {
    // END, CR00178447
    

    // Create return object
    final ExternalPartyOfficeSearchResult externalPartyOfficeSearchResult = new ExternalPartyOfficeSearchResult();

    // External party office search object and key
    final curam.core.sl.intf.ExternalPartyOffice externalPartyOfficeSearchObj = ExternalPartyOfficeFactory.newInstance();

    final curam.core.sl.struct.ExternalPartyOfficeSearchKey officeSearchKey = new curam.core.sl.struct.ExternalPartyOfficeSearchKey();

    // Get the details for the search from the search key
    officeSearchKey.officeSearchKey = externalPartyOfficeSearchKey.officeSearchKey;

    // Search for the details
    externalPartyOfficeSearchResult.officeDtlsList = externalPartyOfficeSearchObj.searchExternalPartyOffice(
      officeSearchKey);

    return externalPartyOfficeSearchResult;
  }

  // END, CR00117610

  // BEGIN, CR00218851, ZV
  // BEGIN, CR00290965, IBM
  /**
   * Searches for an External Party by specified search criteria.
   *
   * @param key External party search criteria
   *
   * @return External party details found
   *
   * @throws AppException Application Exception
   * @throws InformationalException Informational Exception
   *
   * @deprecated Since Curam 6.0 SP2, replaced with {@link 
   * ExternalParty#searchExternalPartyDetails(ExternalPartySearchKey1)}
   *
   * This method is deprecated as informational messages are not returned. This 
   * method is replaced by searchExternalPartyDetails(ExternalPartySearchKey1) 
   * which returns the informational message along with external party details 
   * as well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  // BEGIN, CR00178447, PM
  public ParticipantSearchResult searchExternalParty1(
    final ExternalPartySearchKey1 key) throws AppException,
      InformationalException {
    // END, CR00178447
    // END, CR00290965
    
    final ParticipantSearchRouter participantSearchRouterObj = ParticipantSearchRouterFactory.newInstance();

    final ParticipantSearchResult participantSearchResult = new ParticipantSearchResult();

    key.key.key.concernRoleType = CONCERNROLETYPE.EXTERNALPARTY;
    key.key.key.subtype = key.type;

    participantSearchResult.dtls = participantSearchRouterObj.search(
      key.key.key);

    return participantSearchResult;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Searches for an External Party Office by specified search criteria.
   *
   * @param key External party office search criteria
   *
   * @return External party office details found
   *
   * @throws AppException Application Exception
   * @throws InformationalException Informational Exception
   *
   * @deprecated Since Curam 6.0 SP2, replaced with {@link 
   * ExternalParty#searchExternalPartyOfficeDetails(ExternalPartyOfficeSearchKey1)}
   *
   * This method is deprecated as informational messages are not returned. This 
   * method is replaced by searchExternalPartyOfficeDetails(ExternalPartyOfficeSearchKey1) 
   * which returns the informational message along with external party search 
   * details as well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  // BEGIN, CR00178447, PM
  public ExternalPartyOfficeSearchResult1 searchExternalPartyOffice1(
    final ExternalPartyOfficeSearchKey1 key) throws AppException,
      InformationalException {
    // END, CR00178447
    // END, CR00290965

    final curam.core.sl.intf.ExternalPartyOffice externalPartyOfficeSearchObj = ExternalPartyOfficeFactory.newInstance();

    final ExternalPartyOfficeSearchResult1 externalPartyOfficeSearchResult = new ExternalPartyOfficeSearchResult1();

    externalPartyOfficeSearchResult.dtls = externalPartyOfficeSearchObj.searchExternalPartyOffice1(
      key.key);

    return externalPartyOfficeSearchResult;
  }

  // END, CR00218851

  // BEGIN, CR00216807 MN
  /**
   * Retrieve the homepage details for a user.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the external party concern role id and the
   * identifier for a user
   *
   * @return Homepage details for a user
   */
  // BEGIN, CR00178447, PM
  public ExternalPartyUserDetails readExternalPartyUserHomePageDetails(
    final ExternalPartyUserHomePageKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExternalPartyUserDetails externalPartyUserHomePageDetails = new ExternalPartyUserDetails();

    externalPartyUserHomePageDetails.dtls = curam.core.facade.fact.OrganizationFactory.newInstance().readOrganizationUserHomePage(
      key.readUserHomePageKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyUserHomePageDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyUserHomePageDetails;
  }

  /**
   * Returns a list of the task redirection records for a specified user. Two
   * lists of data are returned. The first contains the details of the all the
   * active and pending task redirection records for the specified user. The
   * second list contains a list of all the expired task redirection history
   * records for the specified user.
   * As this page is called from the external party navigation hierarchy, the
   * external party menu data is also returned.
   *
   * @param key Key containing the id of the user and the external
   * party concern role id.
   *
   * @return a list of all task redirection records for the specified user.
   */
  // BEGIN, CR00178447, PM
  public ExtPartyTaskRedirectionsFromUserDetails getExternalPartyTaskRedirectionHistoryForUser(
    final ExternalPartyUserNameKey key) throws AppException,
      InformationalException {
    // END, CR00178447
    
    final ExtPartyTaskRedirectionsFromUserDetails externalPartyTaskRedirectionsFromUserDetails = new ExtPartyTaskRedirectionsFromUserDetails();

    externalPartyTaskRedirectionsFromUserDetails.dtls = curam.core.facade.fact.OrganizationFactory.newInstance().getTaskRedirectionHistoryForUser(
      key.userNameKey);

    final ExternalPartyKey externalPartyKey = new ExternalPartyKey();

    externalPartyKey.concernRoleID = key.concernRoleID;

    externalPartyTaskRedirectionsFromUserDetails.menuData = getExternalPartyMenuData(
      externalPartyKey);

    return externalPartyTaskRedirectionsFromUserDetails;
  }

  // END, CR00216807

  // BEGIN, CR00290965, IBM
  /**
   * Searches for an external party by specified search criteria.
   *
   * @param externalPartySearchKey1 contains external party search key
   *
   * @return external party search details
   *
   * @throws AppException Application Exception
   * @throws InformationalException Informational Exception
   */
  public ParticipantSearchDetails searchExternalPartyDetails(
    final ExternalPartySearchKey1 externalPartySearchKey1) throws AppException, InformationalException {
    
    ParticipantSearchRouter participantSearchRouter = ParticipantSearchRouterFactory.newInstance();

    ParticipantSearchDetails participantSearchDetails = new ParticipantSearchDetails();

    externalPartySearchKey1.key.key.concernRoleType = CONCERNROLETYPE.EXTERNALPARTY;
    externalPartySearchKey1.key.key.subtype = externalPartySearchKey1.type;

    participantSearchDetails.dtls = participantSearchRouter.search(
      externalPartySearchKey1.key.key);

    collectInformationalMsgs(participantSearchDetails.informationalMsgDtls);
    
    return participantSearchDetails;
  }
  
  /**
   * Searches for an external party office by specified search criteria.
   *
   * @param externalPartyOfficeSearchKey1 contains external party office search key
   *
   * @return external party office details
   *
   * @throws AppException Application Exception
   * @throws InformationalException Informational Exception
   */
  public ExternalPartyOfficeSearchDetails searchExternalPartyOfficeDetails(
    final ExternalPartyOfficeSearchKey1 externalPartyOfficeSearchKey1) throws AppException,
      InformationalException {
    
    curam.core.sl.intf.ExternalPartyOffice externalPartyOfficeSearch = ExternalPartyOfficeFactory.newInstance();

    ExternalPartyOfficeSearchDetails externalPartyOfficeSearchDetails = new ExternalPartyOfficeSearchDetails();

    externalPartyOfficeSearchDetails.dtls = externalPartyOfficeSearch.searchExternalPartyOffice1(
      externalPartyOfficeSearchKey1.key);
    
    collectInformationalMsgs(
      externalPartyOfficeSearchDetails.informationalMsgDtls);

    return externalPartyOfficeSearchDetails;
  }
  
  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList msgDtlsList) {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    String[] infos = informationalManager.obtainInformationalAsString();

    for (String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      msgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }
  // END, CR00290965
}
