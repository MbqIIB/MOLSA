/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.fact.ConcernRoleEmailAddressFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.struct.ConcernRoleEmailAddressDtls;
import curam.core.struct.ConcernRoleEmailAddressDtlsList;
import curam.core.struct.ConcernRoleEmailAddressKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmailAddressDtls;
import curam.core.struct.EmailAddressKey;
import curam.core.struct.UniqueIDKeySet;
import curam.message.PARTICIPANTDATACASE;
import curam.pdc.fact.PDCUtilFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Functions for manipulating an email address information (insert, modify,
 * etc.)
 *
 */
public abstract class EmailAddress extends curam.core.base.EmailAddress {

  /**
   * Generates an unique emailAddressID.
   *
   * @param details
   * Email address entity details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void preinsert(final EmailAddressDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00270920, KR
    if (details.emailAddressID == 0) {
      final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

      uniqueIDKeySet.keySetName = KeySets.KEY_SET_EMAILADDSS;

      details.emailAddressID = UniqueIDFactory.newInstance().getNextIDFromKeySet(
        uniqueIDKeySet);

    }
    // END, CR00270920
  }
  
  // __________________________________________________________________________
  /**
   * Prevents invocation of the modify method if Participant Data Case 
   * is enabled and the email address being modified is linked to a concern 
   * role for whom invocation of the method is not allowed. 
   *
   * @param key
   * email address key structure (contains email address ID).
   * @param details
   * email address details structure.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled and the email address being modified 
   * is linked to a concern role for whom invocation of the modify method is 
   * not allowed.
   */
  protected void premodify(EmailAddressKey key, EmailAddressDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00354954, GD
    // Is PDC enabled
    if (PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {
      // Check to see if this email address is linked to a concern role
      // for whom invocation of the modify method is not allowed 
      ConcernRoleEmailAddressDtlsList concernRoleEmailAddressDtlsList = ConcernRoleEmailAddressFactory.newInstance().searchByEmailAddress(
        key);

      ConcernRoleEmailAddressKey concernRoleEmailAddressKey = new ConcernRoleEmailAddressKey();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      
      for (ConcernRoleEmailAddressDtls concernRoleEmailAddressDtls : concernRoleEmailAddressDtlsList.dtls) {
        concernRoleEmailAddressKey.concernRoleEmailAddressID = concernRoleEmailAddressDtls.concernRoleEmailAddressID;
        concernRoleKey.concernRoleID = ConcernRoleEmailAddressFactory.newInstance().read(concernRoleEmailAddressKey).concernRoleID;
        
        if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {    
          throw new AppException(
            PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
        }
      }      
    }
    // END, CR00354954
  }
}
