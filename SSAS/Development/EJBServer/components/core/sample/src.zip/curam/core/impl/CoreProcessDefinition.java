/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007 - 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


/**
 * Contains constants for the process definitions that are defined for use by
 * the core application.
 */
public abstract class CoreProcessDefinition {

  // Supervisor Application Process Definitions.

  /**
   * The workflow used to send a close task notification when closed from
   * the supervisor application.
   */
  public static final String kSupervisorCloseTaskNotification =
    "SupervisorCloseTaskNotification";

  /**
   * The workflow used to send a forward task notification when forwarded from
   * the supervisor application.
   */
  public static final String kSupervisorForwardTaskNotification =
    "SupervisorForwardTaskNotification";

  /**
   * The workflow used to send a reserve task notification when reserved from
   * the supervisor application.
   */
  public static final String kSupervisorReserveTaskNotification =
    "SupervisorReserveTaskNotification";

  /**
   * The workflow used to send a defer task notification when deferred from
   * the supervisor application.
   */
  public static final String kSupervisorDeferTaskNotification =
    "SupervisorDeferTaskNotification";

  /**
   * The workflow used to send a reallocate task notification when reallocated
   * from the supervisor application.
   */
  public static final String kSupervisorReallocateTaskNotification =
    "SupervisorReallocateTaskNotification";

  /**
   * The workflow used to send an unreserve task notification when un-reserved
   * from the supervisor application.
   */
  public static final String kSupervisorUnreserveTaskNotification =
    "SupervisorUnreserveTaskNotification";

  /**
   * The workflow used to send a notification to a user when their supervisor
   * subscribes them to a work queue.
   */
  public static final String kSupervisorWorkQueueSubscribeNotification =
    "SupervisorWorkQueueSubscribeNotification";

  /**
   * The workflow used to send a notification to a user when their supervisor
   * un-subscribes them from a work queue.
   */
  public static final String kSupervisorWorkQueueUnsubscribeNotification =
    "SupervisorWorkQueueUnsubscribeNotification";
}
