/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2012, 2014
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office
 */

/*
 * Copyright 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.facade.struct.ActiveSpecialCautionDisplayIndicator;
import curam.core.facade.struct.CaseParticipantRoleIdentityKey;
import curam.core.facade.struct.SpecialCautionConcernKey;
import curam.core.facade.struct.SpecialCautionDetails;
import curam.core.facade.struct.SpecialCautionKey;
import curam.core.facade.struct.SpecialCautionVersionKey;
import curam.core.facade.struct.SpecialCautionsList;
import curam.core.fact.SpecialCautionFactory;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.SpecialCautionDtls;
import curam.core.struct.SpecialCautionDtlsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the Special Cautions
 * Presentation Layer.
 *
 */
// BEGIN CR00427285, MP
@curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
// END CR00427285
public abstract class SpecialCaution extends curam.core.facade.base.SpecialCaution {

  // ___________________________________________________________________________
  /**
   * This method lists all the special caution details. based on case
   * participant role id.
   *
   * @param key -
   * case participant role id
   *
   * @return specialCautionsList - list of special cautions.
   *
   * @throws AppException -
   * throws app exception
   * @throws InformationalException -
   * throws informational exception
   */
  // BEGIN CR00427285, MP
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END CR00427285
  public SpecialCautionsList listAllSpecialCautionsByCaseParticipantRoleID(
    CaseParticipantRoleIdentityKey key) throws AppException,
      InformationalException {

    // Instance of return struct
    SpecialCautionsList specialCautionsList = new SpecialCautionsList();
    // Instance of the service layer Object.
    curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory.newInstance();

    specialCautionsList.list = specialCautionObj.listAllSpecialCautionsByCaseParticipantRoleID(
      key.key);

    return specialCautionsList;
  }

  // ___________________________________________________________________________
  /**
   * This method lists the special caution details which are active based on
   * case participant role id.
   *
   * @param key -
   * case participant role id
   *
   * @return specialCautionsList - list of special cautions.
   *
   * @throws AppException -
   * throws app exception
   * @throws InformationalException -
   * throws informational exception
   */
  // BEGIN CR00427285, MP
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END CR00427285
  public SpecialCautionsList listSpecialCautionsByCaseParticipantRoleID(
    CaseParticipantRoleIdentityKey key) throws AppException,
      InformationalException {

    // Instance of return struct
    SpecialCautionsList specialCautionsList = new SpecialCautionsList();
    // Instance of the service layer Object.
    curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory.newInstance();

    specialCautionsList.list = specialCautionObj.listSpecialCautionsByCaseParticipantRoleID(
      key.key);

    return specialCautionsList;
  }

  // ___________________________________________________________________________
  /**
   * This method creates the special caution details.
   *
   * @param details -
   * special caution details
   *
   * @return specialCautionKey - specialcautionID
   *
   * @throws AppException -
   * throws app exception
   * @throws InformationalException -
   * throws informational exception
   */
  // BEGIN CR00427285, MP
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END CR00427285
  public SpecialCautionKey createSpecialCaution(SpecialCautionDetails details)
    throws AppException, InformationalException {

    // Instance of the return struct
    SpecialCautionKey specialCautionKey = new SpecialCautionKey();
    // Instance of the service layer Object.
    curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory.newInstance();

    // Call to method createSpecialCaution on the Service layer Object
    specialCautionKey.key = specialCautionObj.createSpecialCaution(details.dtls);

    return specialCautionKey;
  }

  // ___________________________________________________________________________
  /**
   * This method delete the special caution details.
   *
   * @param key -
   * contains the specialcautionID and version number.
   *
   * @throws AppException -
   * throws app exception
   * @throws InformationalException -
   * throws informational exception
   */
  // BEGIN CR00427285, MP
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END CR00427285
  public void deleteSpecialCaution(SpecialCautionVersionKey key)
    throws AppException, InformationalException {

    // Instance of the service layer Object.
    curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory.newInstance();

    // Call to method deleteSpecialCaution on the Service layer Object
    specialCautionObj.deleteSpecialCaution(key.key);
  }

  // ___________________________________________________________________________
  /**
   * This method lists all the special caution details.
   *
   * @param key -
   * contains the specialcautionID.
   *
   * @return cautionListDetails - special caution details list.
   *
   * @throws AppException -
   * throws app exception
   * @throws InformationalException -
   * throws informational exception
   */
  // BEGIN CR00427285, MP
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END CR00427285
  public SpecialCautionsList listAllSpecialCautions(SpecialCautionConcernKey key)
    throws AppException, InformationalException {

    // Instance of the return struct
    SpecialCautionsList specialCautionsList = new SpecialCautionsList();
    // Instance of the service layer Object.
    curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory.newInstance();

    // Call to method listAllSpecialCautions on the Service layer Object
    specialCautionsList.list = specialCautionObj.listAllSpecialCautions(key.key);

    return specialCautionsList;
  }

  // ___________________________________________________________________________
  /**
   * This method lists the special caution details which are active.
   *
   * @param key -
   * contains the specialcautionID, concernRoleID and
   * caseparticipantroleID.
   *
   * @return Special caution details list
   *
   * @throws AppException -
   * throws app exception
   * @throws InformationalException -
   * throws informational exception
   */
  
  // BEGIN CR00427285, MP
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END CR00427285
  public SpecialCautionsList listSpecialCautions(SpecialCautionConcernKey key)
    throws AppException, InformationalException {

    // Instance of the return struct
    SpecialCautionsList specialCautionsList = new SpecialCautionsList();
    // Instance of the service layer Object.
    curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory.newInstance();

    // Call to method listSpecialCautions on the Service layer Object
    specialCautionsList.list = specialCautionObj.listSpecialCautions(key.key);

    return specialCautionsList;
  }

  // ___________________________________________________________________________
  /**
   * This method modifies the special caution details.
   *
   * @param key -
   * contains the specialcautionID.
   * @param details -
   * special caution details
   *
   * @throws AppException -
   * throws app exception
   * @throws InformationalException -
   * throws informational exception
   */
  // BEGIN CR00427285, MP
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END CR00427285
  public void modifySpecialCaution(SpecialCautionKey key,
    SpecialCautionDetails details) throws AppException,
      InformationalException {

    // Instance of the service layer Object.
    curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory.newInstance();

    // Call to method modifySpecialCaution on the Service layer Object
    specialCautionObj.modifySpecialCaution(key.key, details.dtls);
  }

  // ___________________________________________________________________________
  /**
   * This method read the special caution details.
   *
   * @param key -
   * contains the specialcautionID.
   *
   * @return specialCautionDetails - special caution details
   *
   * @throws AppException -
   * throws app exception
   * @throws InformationalException -
   * throws informational exception
   */
  // BEGIN CR00427285, MP
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END CR00427285
  public SpecialCautionDetails readSpecialCaution(SpecialCautionKey key)
    throws AppException, InformationalException {

    // Instance of the return struct
    SpecialCautionDetails specialCautionDetails = new SpecialCautionDetails();
    // Instance of the service layer Object.
    curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory.newInstance();

    // Call to method readSpecialCaution on the Service layer Object
    specialCautionDetails.dtls = specialCautionObj.readSpecialCaution(key.key);

    return specialCautionDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method display special caution indicator based on active special
   * caution.
   *
   * @param key -
   * contains the specialcautionID.
   *
   * @return specialCautionDetails - special caution details
   *
   * @throws AppException -
   * throws app exception
   * @throws InformationalException -
   * throws informational exception
   */
  // BEGIN CR00427285, MP
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END CR00427285
  public ActiveSpecialCautionDisplayIndicator displayActiveSpecialCautionIndicator(
    SpecialCautionConcernKey key) throws AppException, InformationalException {

    // Instance of return struct
    ActiveSpecialCautionDisplayIndicator activeSpecialCautionDisplayIndicator = new ActiveSpecialCautionDisplayIndicator();
    // Instance of the service layer Object.
    curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory.newInstance();

    // Call to method displayActiveSpecialCautionIndicator() on the service
    // layer object
    activeSpecialCautionDisplayIndicator.indicator = specialCautionObj.displayActiveSpecialCautionIndicator(
      key.key);

    return activeSpecialCautionDisplayIndicator;
  }

  // BEGIN, CR00226543, GYH
  /**
   * Creates the special caution for a case participant.
   *
   * @param details
   * Contains special caution details.
   *
   * @return Special caution record identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN CR00427285, MP
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  // END CR00427285, MP
  public SpecialCautionKey createSpecialCautionFromCase(
    SpecialCautionDetails details) throws AppException,
      InformationalException {
    SpecialCautionKey specialCautionKey = new SpecialCautionKey();
    curam.core.sl.intf.SpecialCaution specialCautionObj = curam.core.sl.fact.SpecialCautionFactory.newInstance();

    specialCautionKey.key = specialCautionObj.createSpecialCaution(details.dtls);
    return specialCautionKey;
  }

  // END, CR00226543
  
  
  /**
   * This method populates special cautions list for a concern role id.
   *
   * @param key
   * - special caution concernRoleID
   * @param list
   * - list of special caution list
   *
   * @throws AppException
   * Application Exception
   * @throws InformationalException
   * Informational Exception
   */
  // BEGIN CR00427285, MP
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.EXTERNAL)
  
  @Override
  public SpecialCautionDtlsList listByConcernRole(ConcernRoleID concernRoleID) throws AppException,
      InformationalException {
    SpecialCautionDtlsList specialCautionDtlsList = SpecialCautionFactory.newInstance().searchByConcernRole(
      concernRoleID);

    return specialCautionDtlsList;
  }
  // END CR00427285
}
