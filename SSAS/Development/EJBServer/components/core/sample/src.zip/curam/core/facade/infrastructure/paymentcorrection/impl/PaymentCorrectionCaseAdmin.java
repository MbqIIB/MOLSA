/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.infrastructure.paymentcorrection.impl;


import com.google.inject.Inject;

import curam.codetable.RULESCOMPONENTTYPE;
import curam.core.facade.fact.ProductDeliveryFactory;
import curam.core.facade.infrastructure.paymentcorrection.struct.PaymentCorrectionHomePageDetails;
import curam.core.facade.struct.CaseNomineeCaseIDKey;
import curam.core.facade.struct.ReadHomePageDetails1;
import curam.core.facade.struct.ReadHomePageKey;
import curam.core.sl.entity.struct.CaseNomineeKey;
import curam.core.sl.entity.struct.DefaultCaseNomineeDetails;
import curam.core.sl.entity.struct.DefaultCaseNomineeKey;
import curam.core.sl.fact.CaseNomineeFactory;
import curam.core.sl.infrastructure.paymentcorrection.entity.fact.PaymentCorrectionEvidenceFactory;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrection;
import curam.core.sl.struct.CaseNomObjectiveAndDelPatternDetailsList;
import curam.core.sl.struct.CaseNomineeDetails;
import curam.core.sl.struct.CaseNomineeViewDetails;
import curam.core.sl.struct.CaseNomineeViewKey;
import curam.core.struct.CaseHeaderKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;


/**
 * Provides the functionality for the Payment Correction facade layer.
 */
public abstract class PaymentCorrectionCaseAdmin extends curam.core.facade.infrastructure.paymentcorrection.base.PaymentCorrectionCaseAdmin {

  /**
   * Reference to Payment Correction interface.
   */
  @Inject
  private PaymentCorrection paymentCorrection;

  // ____________________________________________________________________________
  /**
   * Constructor.
   */
  public PaymentCorrectionCaseAdmin() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00210716, KH
  // ___________________________________________________________________________
  /**
   * Read the home page details for the specified case.
   *
   * @param key
   * Contains the ID of the case.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public PaymentCorrectionHomePageDetails readHomePageDetails(
    final CaseHeaderKey key) throws AppException, InformationalException {

    PaymentCorrectionHomePageDetails correctionHomePageDetails = new PaymentCorrectionHomePageDetails();

    // Read the common product delivery home page details
    ReadHomePageKey pdKey = new ReadHomePageKey();

    pdKey.caseID = key.caseID;
    // BEGIN, CR00220182, ZV
    ReadHomePageDetails1 homePageDetails = ProductDeliveryFactory.newInstance().readHomePageDetails1(
      pdKey);

    // END, CR00220182

    // Assign the details across to the payment correction struct
    correctionHomePageDetails.dtls.assign(homePageDetails.homePageDetails);
    correctionHomePageDetails.closureDtls.assign(homePageDetails.closureDtls);
    correctionHomePageDetails.transactionLogDtls.assign(
      homePageDetails.transactionLogDtls);
    correctionHomePageDetails.context.assign(homePageDetails.contextDescription);
    correctionHomePageDetails.caseIsUserBookmarkInd = homePageDetails.caseIsUserBookmarkInd;
    correctionHomePageDetails.isCaseClosedInd = homePageDetails.isCaseClosedInd;

    // Set the conditional indicator that controls which cluster is displayed
    correctionHomePageDetails.isOverpaymentInd = paymentCorrection.isOverPaymentPaymentCorrection(
      key);

    // BEGIN, CR00219209, VM
    CaseNomineeDetails nomineeDetails = getNomineeDetails(key);

    correctionHomePageDetails.caseNomineeID = nomineeDetails.caseNomineeID;
    correctionHomePageDetails.nomineeConcernRoleID = nomineeDetails.concernRoleID;
    correctionHomePageDetails.caseNomineeName = nomineeDetails.concernRoleName;
    correctionHomePageDetails.concernRoleType = nomineeDetails.concernRoleType;
    // END, CR00219209

    return correctionHomePageDetails;
  }

  // END, CR00210716

  // ___________________________________________________________________________
  /**
   * Method to issue the financials on payment correction case.
   *
   * @param key
   * Contains the ID of the case on which we are issuing financials.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void issueFinancials(final CaseHeaderKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00203088, CW
    paymentCorrection.issueFinancials(key);
    // END, CR00203088
  }

  // ___________________________________________________________________________
  /**
   * Method to list all objectives for a case and their current delivery pattern
   *
   * @param key
   * Contains the case ID.
   *
   * @return List of all objectives for this case, the details of the
   * participant to whom each is assigned and the current delivery
   * pattern for each objective.
   */
  public CaseNomObjectiveAndDelPatternDetailsList listObjectiveAndDelPattern(
    final CaseHeaderKey key) throws AppException, InformationalException {

    CaseNomineeCaseIDKey caseNomineeCaseIDKey = new CaseNomineeCaseIDKey();

    caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID = key.caseID;

    CaseNomObjectiveAndDelPatternDetailsList returnList = CaseNomineeFactory.newInstance().listObjectiveAndDelPattern(
      caseNomineeCaseIDKey.caseNomineeCaseIDKey);

    for (int i = returnList.dtls.size() - 1; i >= 0; i--) {

      // Only display relevant component for Payment Correction type
      if (paymentCorrection.isOverPaymentPaymentCorrection(key)
        && returnList.dtls.item(i).objectiveCode.equals(
          RULESCOMPONENTTYPE.BENEFITUNDERPAYMENT)) {

        returnList.dtls.remove(i);
      } else if (paymentCorrection.isUnderPaymentPaymentCorrection(key)
        && returnList.dtls.item(i).objectiveCode.equals(
          RULESCOMPONENTTYPE.BENEFITOVERPAYMENT)) {

        returnList.dtls.remove(i);
      }
    }
    return returnList;
  }

  // BEGIN, CR00219209, VM
  // ___________________________________________________________________________
  /**
   * Returns details for the nominee who was over/under paid on the payment
   * correction case.
   *
   * @param key
   * Case Header entity key.
   *
   * @return Case Nominee details
   */
  protected CaseNomineeDetails getNomineeDetails(CaseHeaderKey key)
    throws AppException, InformationalException {

    CaseNomineeDetails caseNomineeDetails = new CaseNomineeDetails();
    
    // BEGIN, CR00327227, KH
    try {
      CaseNomineeKey caseNomineeKey = PaymentCorrectionEvidenceFactory.newInstance().readNomineeForCase(
        key);
      
      CaseNomineeViewKey caseNomineeViewKey = new CaseNomineeViewKey();

      caseNomineeViewKey.caseNomineeViewKey.caseNomineeID = caseNomineeKey.caseNomineeID;

      CaseNomineeViewDetails caseNomineeViewDetails = CaseNomineeFactory.newInstance().viewCaseNomineeDetails(
        caseNomineeViewKey);

      caseNomineeDetails.caseNomineeID = caseNomineeViewDetails.caseNomineeDetails.caseNomineeID;
      caseNomineeDetails.concernRoleID = caseNomineeViewDetails.caseNomineeDetails.concernRoleID;
      caseNomineeDetails.concernRoleName = caseNomineeViewDetails.caseNomineeDetails.concernRoleName;
      caseNomineeDetails.concernRoleType = caseNomineeViewDetails.caseNomineeDetails.concernRoleType;
      
    } catch (RecordNotFoundException rnfe) {
      
      /*
       * This supports payment corrections which are created as a result of
       * reversing a refund
       */
      DefaultCaseNomineeKey defaultKey = new DefaultCaseNomineeKey();

      defaultKey.caseID = key.caseID;
      defaultKey.defaultNomInd = true;
      DefaultCaseNomineeDetails nomineeDetails = curam.core.sl.entity.fact.CaseNomineeFactory.newInstance().readDefaultCaseNominee(
        defaultKey);

      caseNomineeDetails.caseNomineeID = nomineeDetails.caseNomineeID;
      caseNomineeDetails.concernRoleID = nomineeDetails.concernRoleID;
      caseNomineeDetails.concernRoleName = nomineeDetails.concernRoleName;
      caseNomineeDetails.concernRoleType = nomineeDetails.concernRoleType;
    }
    // END, CR00327227

    return caseNomineeDetails;
  }
  // END, CR00219209

}
