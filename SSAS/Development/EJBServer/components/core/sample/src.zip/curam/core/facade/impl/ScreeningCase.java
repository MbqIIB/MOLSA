/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright (c) 2002-2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.facade.struct.ActiveAssessmentList;
import curam.core.facade.struct.CaseIDKey;
import curam.core.facade.struct.ScreeningConfigurationList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Provides the ability to create and maintain screening cases, without getting
 * into the specifics of the screening case itself. Things like adding evidence,
 * etc. will be done from the custom screening facades.
 *
 */

public abstract class ScreeningCase extends curam.core.facade.base.ScreeningCase {

  // ___________________________________________________________________________
  /**
   * lists the currently active Screening Configuration, such that one will be
   * chosen to create an instance of such.
   *
   */
  public ScreeningConfigurationList listActiveScreening()
    throws AppException, InformationalException {

    // Instantiate the ScreeningCase Object
    curam.core.sl.intf.ScreeningCase screeningCaseObj =
      curam.core.sl.fact.ScreeningCaseFactory.newInstance();

    // Create the return object.
    ScreeningConfigurationList screeningConfigurationList =
      new ScreeningConfigurationList();

    // Assign the value returned from the BPO method
    screeningConfigurationList.dtls = screeningCaseObj.listActiveScreening();

    return screeningConfigurationList;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the list of assessments that can be added at this time to a live
   * screening, that is those that are not canceled or where the end date has
   * passed. Note that if a particular assessment type has been added already,
   * it may still exist in the list as it could cover a different date range.
   *
   * @param caseKey The Case ID for a Screening.
   *  Screening Configuration, status and date range.
   *
   */
  public ActiveAssessmentList listAvailableAssessmentsForAdding(
    CaseIDKey caseKey)
    throws AppException, InformationalException {

    // Instantiate the ScreeningCase Object
    curam.core.sl.intf.ScreeningCase screeningCaseObj =
      curam.core.sl.fact.ScreeningCaseFactory.newInstance();

    // Create the return object.
    ActiveAssessmentList activeAssessmentList = new ActiveAssessmentList();

    // Assign the value returned from the BPO method
    activeAssessmentList.dtls =
      screeningCaseObj.listAvailableAssessmentsForAdding(caseKey.dtls);

    return activeAssessmentList;
  }

}
