/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import org.jdom.Document;

import com.google.inject.Inject;

import curam.caseaudit.entity.fact.WMCaseAuditInstanceDataFactory;
import curam.caseaudit.entity.intf.WMCaseAuditInstanceData;
import curam.caseaudit.entity.struct.WMCaseAuditInstanceDataDtls;
import curam.caseaudit.entity.struct.WMCaseAuditInstanceDataKey;
import curam.caseaudit.generator.impl.ExternalServiceCaseAuditCriteriaXMLHelper;
import curam.caseaudit.generator.impl.ExternalServiceCaseAuditGenerator;
import curam.caseaudit.generator.impl.FixedQueryCaseAuditCriteriaXMLHelper;
import curam.caseaudit.generator.impl.FixedQueryCaseAuditGenerator;
import curam.caseaudit.generator.impl.ICCaseAuditCriteriaXMLHelper;
import curam.caseaudit.generator.impl.ICCaseAuditGenerator;
import curam.caseaudit.generator.impl.InvestigationCaseAuditCriteriaXMLHelper;
import curam.caseaudit.generator.impl.InvestigationCaseAuditGenerator;
import curam.caseaudit.generator.impl.LiabilityCaseAuditCriteriaXMLHelper;
import curam.caseaudit.generator.impl.LiabilityCaseAuditGenerator;
import curam.caseaudit.generator.impl.PDCaseAuditCriteriaXMLHelper;
import curam.caseaudit.generator.impl.PDCaseAuditGenerator;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.core.facade.struct.CaseSampleKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.XMLUtil;

/**
 * Provides the functionality for generating case audits through a deferred 
 * process.
 */
public abstract class DeferredCaseAuditGeneration 
  extends curam.caseaudit.base.DeferredCaseAuditGeneration {

  @Inject 
  ICCaseAuditGenerator icCaseAuditGenerator;
  
  @Inject
  ICCaseAuditCriteriaXMLHelper icCaseAuditCriteriaXMLHelper;

  @Inject 
  PDCaseAuditGenerator pdCaseAuditGenerator;
  
  @Inject
  PDCaseAuditCriteriaXMLHelper pdCaseAuditCriteriaXMLHelper;
  
  @Inject 
  LiabilityCaseAuditGenerator liabilityCaseAuditGenerator;
  
  @Inject
  LiabilityCaseAuditCriteriaXMLHelper liabilityCaseAuditCriteriaXMLHelper;

  @Inject 
  InvestigationCaseAuditGenerator invCaseAuditGenerator;
  
  @Inject
  InvestigationCaseAuditCriteriaXMLHelper invCaseAuditCriteriaXMLHelper;

  @Inject 
  FixedQueryCaseAuditGenerator fixedCaseAuditGenerator;
  
  @Inject
  FixedQueryCaseAuditCriteriaXMLHelper fixedCaseAuditCriteriaXMLHelper;

  @Inject 
  ExternalServiceCaseAuditGenerator extCaseAuditGenerator;
  
  @Inject
  ExternalServiceCaseAuditCriteriaXMLHelper extCaseAuditCriteriaXMLHelper;

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public DeferredCaseAuditGeneration() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Deferred process that generates a list of case audits based on the 
   * supplied search criteria, query or external service. This method delegates 
   * to the relevant generator to generate the case audits.
   *
   * @param ticketID ticket that started process.
   * @param instDataID id for retrieving data needed for the case audit
   *        generation.
   * @param flag whether ticket closing is deferred.
   * 
   * @throws AppException
   * @throws InformationalException
   */  
  public void generateCaseAudits(final long ticketID, final long instDataID, 
    final boolean flag) throws AppException, InformationalException {

    CaseSampleKey caseSampleKey = new CaseSampleKey();
    
    WMCaseAuditInstanceDataKey wmInstanceDataKey =
      new WMCaseAuditInstanceDataKey();
    wmInstanceDataKey.wmInstDataID = instDataID;
    
    WMCaseAuditInstanceData wmInstanceDataObj = 
      WMCaseAuditInstanceDataFactory.newInstance();
    WMCaseAuditInstanceDataDtls wmInstanceDataDtls = 
      wmInstanceDataObj.read(wmInstanceDataKey);

    if (wmInstanceDataDtls.fixedQueryInd) {
      
      final String xmlString = 
        new String(wmInstanceDataDtls.genCaseAuditXML.copyBytes());

      Document xmlDoc = XMLUtil.convertStringToJDOMDocument(xmlString);

      // Convert the criteria from a document to a key
      caseSampleKey = fixedCaseAuditCriteriaXMLHelper.parseCriteria(xmlDoc);

      fixedCaseAuditGenerator.generateCaseAudits(caseSampleKey);      

    } else if (wmInstanceDataDtls.externalServiceInd) {

        final String xmlString = 
          new String(wmInstanceDataDtls.genCaseAuditXML.copyBytes());
  
        Document xmlDoc = XMLUtil.convertStringToJDOMDocument(xmlString);
  
        // Convert the criteria from a document to a key
        caseSampleKey = extCaseAuditCriteriaXMLHelper.parseCriteria(xmlDoc);
  
        extCaseAuditGenerator.generateCaseAudits(caseSampleKey);      

    } else if (wmInstanceDataDtls.caseType.equals(
        CASETYPECODEEntry.INTEGRATEDCASE.getCode())) {

        final String xmlString = 
          new String(wmInstanceDataDtls.genCaseAuditXML.copyBytes());
  
        Document xmlDoc = XMLUtil.convertStringToJDOMDocument(xmlString);
  
        // Convert the criteria from a document to a key
        caseSampleKey = icCaseAuditCriteriaXMLHelper.parseCriteria(xmlDoc);
  
        icCaseAuditGenerator.generateCaseAudits(caseSampleKey);      
      
    } else if (wmInstanceDataDtls.caseType.equals(
        CASETYPECODEEntry.PRODUCTDELIVERY.getCode())) {
        
        final String xmlString = 
          new String(wmInstanceDataDtls.genCaseAuditXML.copyBytes());
  
        Document xmlDoc = XMLUtil.convertStringToJDOMDocument(xmlString);
  
        // Convert the criteria from a document to a key
        caseSampleKey = pdCaseAuditCriteriaXMLHelper.parseCriteria(xmlDoc);
  
        pdCaseAuditGenerator.generateCaseAudits(caseSampleKey);      

    } else if (wmInstanceDataDtls.caseType.equals(
        CASETYPECODEEntry.LIABILITY.getCode())) {

        final String xmlString = 
          new String(wmInstanceDataDtls.genCaseAuditXML.copyBytes());
  
        Document xmlDoc = XMLUtil.convertStringToJDOMDocument(xmlString);
  
        // Convert the criteria from a document to a key
        caseSampleKey = 
          liabilityCaseAuditCriteriaXMLHelper.parseCriteria(xmlDoc);
  
        liabilityCaseAuditGenerator.generateCaseAudits(caseSampleKey);      

    } else if (wmInstanceDataDtls.caseType.equals(
        CASETYPECODEEntry.INVESTIGATIONCASE.getCode())) {
      
        final String xmlString = 
          new String(wmInstanceDataDtls.genCaseAuditXML.copyBytes());
  
        Document xmlDoc = XMLUtil.convertStringToJDOMDocument(xmlString);
  
        // Convert the criteria from a document to a key
        caseSampleKey = invCaseAuditCriteriaXMLHelper.parseCriteria(xmlDoc);
  
        invCaseAuditGenerator.generateCaseAudits(caseSampleKey);      
    } 
  }
}
