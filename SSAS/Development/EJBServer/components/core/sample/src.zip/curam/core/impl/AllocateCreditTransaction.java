/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2008, 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.codetable.CASETRANSACTIONEVENTS;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.struct.CaseIDKey;
import curam.core.struct.AllocatedAmt;
import curam.core.struct.AllocationDtlsCaptured;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CreditAllocateKey;
import curam.core.struct.DAcreditILIidStatus;
import curam.core.struct.DraftAllocationLineDtls;
import curam.core.struct.DraftAllocationLineDtlsList;
import curam.core.struct.DraftAllocationLineKey;
import curam.core.struct.ILIConcernRoleIDStatusCodeCreditDebitType;
import curam.core.struct.InstructionLineItemDtls;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.InstructionLineItemKey;
import curam.core.struct.LiabilityFinInstructionID;
import curam.core.struct.LiabilityInstrumentID;
import curam.core.struct.PaymentReceivedInstructionDtls;
import curam.core.struct.PmtRecvFinInstructionID;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductKey;
import curam.core.struct.ReadDebitsForAllocationResult;
import curam.core.struct.RelatedILIDetailsList;
import curam.core.struct.RelatedILIidentifier;
import curam.core.struct.StatusFinInstructID;
import curam.message.BPOALLOCATECREDITTRANSACTION;
import curam.message.BPOCASEEVENTS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;


/**
 * To find the debits to which a credit transaction may be allocated and
 * perform the allocations to these.
 *
 */
public abstract class AllocateCreditTransaction extends curam.core.base.AllocateCreditTransaction {
       
  // BEGIN CR00110127, MR
  // Add injection for using the new CaseTransactionLog API
  public AllocateCreditTransaction() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;
  // END CR00110127

  // ___________________________________________________________________________
  /*
   * Description: readmulti class to process draft allocation line groups
   */
  static class TransferAllocation extends curam.util.dataaccess.ReadmultiOperation {

    // Total debit allocation amount
    curam.util.type.Money totalDebitAllocation = curam.util.type.Money.kZeroMoney;

    // InstructionLineItem manipulation variables
    InstructionLineItemDtls creditILIDtls = new InstructionLineItemDtls();

    curam.util.type.Money creditUnallocatedAmt = curam.util.type.Money.kZeroMoney;

    // _________________________________________________________________________
    /**
     * Operation for each record in TransferAllocation readmulti class
     *
     * @param objDtls draft allocation line details
     *
     * @return boolean
     */
    public boolean operation(Object objDtls) throws AppException, 
        InformationalException {

      DraftAllocationLineDtls dtls = (DraftAllocationLineDtls) objDtls;

      // Debit instruction line item key and details
      curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();
      InstructionLineItemKey debitILIKey = new InstructionLineItemKey();
      InstructionLineItemDtls debitILIDtls;

      // Validation section
      if (dtls.amount.getValue() > creditILIDtls.unprocessedAmount.getValue()) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOALLOCATECREDITTRANSACTION.ERR_DRAFTALLOCATION_XFV_ALLOC_UNALLOCAMT_CDT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }

      totalDebitAllocation = new curam.util.type.Money(
        totalDebitAllocation.getValue() + dtls.amount.getValue());

      if (totalDebitAllocation.getValue() > creditUnallocatedAmt.getValue()) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOALLOCATECREDITTRANSACTION.ERR_DRAFTALLOCATION_XFV_ALLOCATIONS_LARGE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      // Validations o.k., therefore start the live allocations
      // Get the details of the debit instruction line item record for
      // allocation

      // set key to read debit ILI
      debitILIKey.instructLineItemID = dtls.debitInstructionLineItemID;

      // read debit ILI
      debitILIDtls = instructionLineItemObj.read(debitILIKey, true);

      // Use the AllocateCredit BPO to perform live allocations
      // allocateCredit manipulation variables
      curam.core.intf.AllocateCredit allocateCreditObj = curam.core.fact.AllocateCreditFactory.newInstance();

      // Allocated amount
      AllocatedAmt allocatedAmt = new AllocatedAmt();

      allocatedAmt.assign(dtls);

      if (dtls.amount.getValue() > debitILIDtls.unprocessedAmount.getValue()) {

        AllocatedAmt overallocatedAmt = new AllocatedAmt();

        if (debitILIDtls.unprocessedAmount.isPositive()) {

          allocatedAmt.amount = debitILIDtls.unprocessedAmount;

          if (creditILIDtls.instructLineItemCategory.equals(
            curam.codetable.ILICATEGORY.ADJUSTMENTINSTRUCTION)) {

            allocateCreditObj.allocateDeductionAdjustment(creditILIDtls,
              debitILIDtls, allocatedAmt);

          } else {

            allocateCreditObj.allocatePaymentReceived(creditILIDtls,
              debitILIDtls, allocatedAmt);
          }

          overallocatedAmt.amount = new curam.util.type.Money(
            dtls.amount.getValue() - allocatedAmt.amount.getValue());

        } else {

          overallocatedAmt.amount = dtls.amount;
        }

        allocateCreditObj.overallocateCreditTransaction(creditILIDtls,
          debitILIDtls, overallocatedAmt);

      } else {

        // Validations completed in "Capture" will ensure that only liability
        // ILI's can be over-allocated against
        allocatedAmt.amount = dtls.amount;

        if (creditILIDtls.instructLineItemCategory.equals(
          curam.codetable.ILICATEGORY.ADJUSTMENTINSTRUCTION)) {

          allocateCreditObj.allocateDeductionAdjustment(creditILIDtls,
            debitILIDtls, allocatedAmt);

        } else {

          allocateCreditObj.allocatePaymentReceived(creditILIDtls, debitILIDtls,
            allocatedAmt);

        }

      }

      // As live allocation process was successful, remove the draft allocation
      // records

      // Draft allocation line key
      DraftAllocationLineKey draftAllocationLineKey = new DraftAllocationLineKey();

      draftAllocationLineKey.draftAllocationLineID = dtls.draftAllocationLineID;

      // object and struct for removing the current record
      curam.core.intf.DraftAllocationLine removeObj = curam.core.fact.DraftAllocationLineFactory.newInstance();
      DraftAllocationLineKey removeKey = new DraftAllocationLineKey();

      removeKey.draftAllocationLineID = dtls.draftAllocationLineID;
      removeObj.remove(removeKey);

      return true;

    }

    // _________________________________________________________________________
    /**
     * Operation for the first record read by the TransferAllocation readmulti
     * class.
     *
     * @param objDtls draft allocation line details
     */
    public void first(Object objDtls) throws AppException, 
        InformationalException {

      DraftAllocationLineDtls dtls = (DraftAllocationLineDtls) objDtls;

      // instructionLineItem manipulation variables
      InstructionLineItemKey creditILIKey = new InstructionLineItemKey();
      curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();

      creditILIKey.instructLineItemID = dtls.creditInstructionLineItemID;

      creditILIDtls = instructionLineItemObj.read(creditILIKey, true);

      creditUnallocatedAmt = creditILIDtls.unprocessedAmount;
    }

  }

  // ___________________________________________________________________________
  /**
   * To get debit allocation summary and a summary list of credits to which the
   * debit may be allocated.
   *
   * @param creditAllocateKey Credit allocate key
   *
   * @return Debits outstanding details list and credit allocation summary
   * details
   */
  public ReadDebitsForAllocationResult readDebitsForAllocation(
    CreditAllocateKey creditAllocateKey) throws AppException, 
      InformationalException {

    ReadDebitsForAllocationResult readDebitsForAllocationResult = new ReadDebitsForAllocationResult();

    // Instruction line item key and details
    InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();
    curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();
    // BEGIN, CR00158104, SAI
    InstructionLineItemDtls instructionLineItemDtls = new
      InstructionLineItemDtls();
    // END, CR00158104
    InstructionLineItemDtlsList iliDtlsList;

    // allocateCreditTransactionAssistant manipulation variables
    curam.core.intf.AllocateCreditTransactionAssistant allocateCreditTransactionAssistantObj = curam.core.fact.AllocateCreditTransactionAssistantFactory.newInstance();

    RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();
    RelatedILIDetailsList relatedILIDetailsList;

    if (creditAllocateKey.instructionLineItemID != 0) {

      // set key to read instructionLineItem entity
      instructionLineItemKey.instructLineItemID = creditAllocateKey.instructionLineItemID;

      // read instructionLineItem entity
      instructionLineItemDtls = instructionLineItemObj.read(
        instructionLineItemKey);

    } else {

      // BEGIN, CR00158104, SAI
      // payment is reversed and cannot be allocated
      AppException e = new AppException(
        BPOALLOCATECREDITTRANSACTION.INF_DRAFTALLOCATION_FV_NO_ALLOCATION);

      curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        e.arg(true), curam.core.impl.CuramConst.gkEmpty,
        curam.util.exception.InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    double pmtAllocation = 0;

    pmtAllocation = instructionLineItemDtls.unprocessedAmount.getValue();

    if (creditAllocateKey.liabilityExternalRefNo != 0) {

      // liabilityInstrument manipulation variable
      LiabilityInstrumentID lbyInstrumentID = new LiabilityInstrumentID();

      // liabilityInstruction manipulation variables
      curam.core.intf.LiabilityInstruction liabilityInstructionObj = curam.core.fact.LiabilityInstructionFactory.newInstance();
      LiabilityFinInstructionID lbyFinInstructionID;

      StatusFinInstructID statusFinInstructID = new StatusFinInstructID();

      // set key to read liabilityInstruction entity
      lbyInstrumentID.liabInstrumentID = creditAllocateKey.liabilityExternalRefNo;

      try {
        lbyFinInstructionID = liabilityInstructionObj.readFinInstructIDByLiabInstrumID(
          lbyInstrumentID);

        statusFinInstructID.finInstructionID = lbyFinInstructionID.finInstructionID;
        statusFinInstructID.statusCode = curam.codetable.ILISTATUS.PROCESSED;

        iliDtlsList = instructionLineItemObj.searchByFinInstructStatus(
          statusFinInstructID);

      } catch (curam.util.exception.RecordNotFoundException e) {
        iliDtlsList = null;
      }

    } else {

      // Instruction line item search key and details list
      ILIConcernRoleIDStatusCodeCreditDebitType iliConcernStatusCDT = new ILIConcernRoleIDStatusCodeCreditDebitType();

      // set key to read instructionLineItem entity
      iliConcernStatusCDT.concernRoleID = creditAllocateKey.concernRoleID;
      iliConcernStatusCDT.statusCode = curam.codetable.ILISTATUS.PROCESSED;
      iliConcernStatusCDT.creditDebitType = curam.codetable.CREDITDEBIT.DEBIT;

      // read liabilityInstruction entity
      iliDtlsList = instructionLineItemObj.searchByConcernRoleIDCreditDebitTypeStatusCode(
        iliConcernStatusCDT);
    }

    if (iliDtlsList != null) {

      if (iliDtlsList.dtls.size() > 0) {

        for (int i = 0; i < iliDtlsList.dtls.size(); i++) {

          DraftAllocationLineDtls draftAllocDtls;

          if ((!iliDtlsList.dtls.item(i).instructLineItemCategory.equals(
            curam.codetable.ILICATEGORY.PAYMENTINSTRUCTION))
              && (!iliDtlsList.dtls.item(i).instructionLineItemType.equals(
                curam.codetable.ILITYPE.LOANLIABILITY))
                && (!iliDtlsList.dtls.item(i).instructionLineItemType.equals(
                  curam.codetable.ILITYPE.INTERESTAPPLIED))
                  // BEGIN, CR00053019, MC.
                  // BEGIN, HARP 72528, MC.
                  && !iliDtlsList.dtls.item(i).unprocessedAmount.isZero()
                  // END, HARP 72528
                  // END, CR00053019
                  // BEGIN, CR00053024, GSP
                  // BEGIN, HARP 71524, GSP
                  && (!iliDtlsList.dtls.item(i).instructionLineItemType.equals(
                    curam.codetable.ILITYPE.DEDUCTIONPAYMENT))) {
            // END, HARP 71524
            // END, CR00053024

            boolean skipRecord = false;

            // Payment Instruction, Loan liability and interest cannot
            // be allocated
            if ((iliDtlsList.dtls.item(i).instructLineItemCategory.equals(
              curam.codetable.ILICATEGORY.LIABILITYINSTRUCTION))
                && (creditAllocateKey.liabilityExternalRefNo != 0)) {

              relatedILIidentifier.instructLineItemID = iliDtlsList.dtls.item(i).instructLineItemID;
              relatedILIidentifier.type = curam.codetable.ILIRELATIONSHIP.ALLOCATIONREVERSAL;

              relatedILIDetailsList = instructionLineItemObj.searchRelatedILIByInstrLineItemIDType(
                relatedILIidentifier);

              if (!relatedILIDetailsList.dtls.isEmpty()) {

                for (int j = 0; j < relatedILIDetailsList.dtls.size(); j++) {

                  InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();
                  InstructionLineItemDtls relatedILIDtls;

                  // set key to read instructionLineItem entity
                  relatedILIKey.instructLineItemID = relatedILIDetailsList.dtls.item(j).instructLineItemID;

                  // read instructionLineItem entity
                  relatedILIDtls = instructionLineItemObj.read(relatedILIKey);

                  if (!relatedILIDtls.statusCode.equals(
                    curam.codetable.ILISTATUS.ALLOCATED)) {

                    draftAllocDtls = allocateCreditTransactionAssistantObj.viewOutstandingDebits(
                      creditAllocateKey, relatedILIDtls,
                      readDebitsForAllocationResult.debitsOutstandingList);

                    pmtAllocation = (pmtAllocation
                      - draftAllocDtls.amount.getValue());
                  }
                }

              } else {

                if ((iliDtlsList.dtls.item(i).instructLineItemCategory.equals(
                  curam.codetable.ILICATEGORY.REVERSALINSTRUCTION))
                    && (iliDtlsList.dtls.item(i).instructionLineItemType.equals(
                      curam.codetable.ILITYPE.ALLOCATEDREVERSAL))) {

                  // check for reversed LoanLiability
                  relatedILIDetailsList.dtls.clear();

                  relatedILIidentifier.instructLineItemID = iliDtlsList.dtls.item(i).instructLineItemID;
                  relatedILIidentifier.type = curam.codetable.ILIRELATIONSHIP.REVERSALS;

                  relatedILIDetailsList = instructionLineItemObj.searchRelatedILIByRelatedLineItemIDType(
                    relatedILIidentifier);

                  // Related instruction line item details list iterator
                  for (int k = 0; k < relatedILIDetailsList.dtls.size(); k++) {

                    if (relatedILIDetailsList.dtls.item(k).instructionLineItemType.equals(
                      curam.codetable.ILITYPE.REPAYMENTEXPECTED)) {

                      skipRecord = true;
                      break;
                    }

                  }

                }

              }

            }
            
            // BEGIN, CR00330723, CSH
            // Can't allocate to an ILI with zero outstanding amount
            if (iliDtlsList.dtls.item(i).unprocessedAmount.isZero()) {
              skipRecord = true;
            }
            // END, CR00330723

            if (!skipRecord) {

              draftAllocDtls = allocateCreditTransactionAssistantObj.viewOutstandingDebits(
                creditAllocateKey, iliDtlsList.dtls.item(i),
                readDebitsForAllocationResult.debitsOutstandingList);

              pmtAllocation -= draftAllocDtls.amount.getValue();

            }

          }

        }

      }

    }

    // Populate the output CreditAllocationSummary struct
    readDebitsForAllocationResult.creditAllocationSummary.amount = instructionLineItemDtls.amount;
    readDebitsForAllocationResult.creditAllocationSummary.effectiveDate = instructionLineItemDtls.effectiveDate;
    readDebitsForAllocationResult.creditAllocationSummary.unallocatedAmount = new curam.util.type.Money(
      pmtAllocation);
    readDebitsForAllocationResult.creditAllocationSummary.receiptMethod = instructionLineItemDtls.deliveryMethodType;

    readDebitsForAllocationResult.creditAllocationSummary.currencyType = instructionLineItemDtls.currencyTypeCode;

    return readDebitsForAllocationResult;
  }

  // ___________________________________________________________________________
  /**
   * To take the allocation details captured and store these on persistent
   * storage by creating a new DraftAllocationLine record or updating an
   * existing DraftAllocationLine record (if the allocation existed previously)
   *
   * @param allocDtlsCaptured Allocation captured details
   */
  public void captureAllocationLine(AllocationDtlsCaptured allocDtlsCaptured)
    throws AppException, InformationalException {

    // draftAllocationLine manipulation variables
    DraftAllocationLineDtlsList draftAllocationLineDtlsList;
    DAcreditILIidStatus dacreditILIidStatus = new DAcreditILIidStatus();
    curam.core.intf.DraftAllocationLine draftAllocationLineObj = curam.core.fact.DraftAllocationLineFactory.newInstance();

    // product manipulation variables
    curam.core.intf.Product productObj = curam.core.fact.ProductFactory.newInstance();
    ProductDtls productDtls;
    ProductKey productKey = new ProductKey();

    // productDelivery manipulation variables
    curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
    ProductDeliveryDtls productDeliveryDtls;
    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    // instructionLineItem manipulation variables
    InstructionLineItemKey creditILIKey = new InstructionLineItemKey();
    InstructionLineItemKey debitILIKey = new InstructionLineItemKey();
    curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();
    InstructionLineItemDtls creditILIDtls;
    InstructionLineItemDtls debitILIDtls;

    // allocateCreditTransactionAssistant manipulation variables
    curam.core.intf.AllocateCreditTransactionAssistant allocateCreditTransactionAssistantObj = curam.core.fact.AllocateCreditTransactionAssistantFactory.newInstance();

    // set key to read credit ILI
    creditILIKey.instructLineItemID = allocDtlsCaptured.creditInstructionLineItemID;

    // read credit ILI
    creditILIDtls = instructionLineItemObj.read(creditILIKey);

    // set key to read debit ILI
    debitILIKey.instructLineItemID = allocDtlsCaptured.debitInstructionLineItemID;

    // read debit ILI
    debitILIDtls = instructionLineItemObj.read(debitILIKey);

    // Validate the input allocation amount against the specified outstanding
    // amounts of the specified InstructionLineItem records.
    if (allocDtlsCaptured.amount.getValue()
      > creditILIDtls.unprocessedAmount.getValue()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOALLOCATECREDITTRANSACTION.ERR_DRAFTALLOCATION_XFV_ALLOC_UNALLOCAMT_CDT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    if (allocDtlsCaptured.amount.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOALLOCATECREDITTRANSACTION.ERR_DRAFTALLOCATION_XFV_ZEROAMOUNT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (debitILIDtls.caseID != 0) {

      // set key to read productDelivery entity
      productDeliveryKey.caseID = debitILIDtls.caseID;

      // read productDelivery entity
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

      // set key to read product entity
      productKey.productID = productDeliveryDtls.productID;

      // read product entity
      productDtls = productObj.read(productKey);

      if (allocDtlsCaptured.amount.getValue()
        > debitILIDtls.unprocessedAmount.getValue()) {

        if ((!productDtls.overAllocationInd)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOALLOCATECREDITTRANSACTION.ERR_DRAFTALLOCATION_XFV_ALLOC_UNALLOCAMT_DBT),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
        }

      }

    }

    if (allocDtlsCaptured.amount.getValue()
      > debitILIDtls.unprocessedAmount.getValue()) {

      if (debitILIDtls.caseID == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOALLOCATECREDITTRANSACTION.ERR_DRAFTALLOCATION_XFV_ALLOC_UNALLOCAMT_DBT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    }

    allocateCreditTransactionAssistantObj.addAllocationDetails(
      allocDtlsCaptured);

    // BEGIN CR00110127, MR
    // Log Transaction Details
    if (debitILIDtls.caseID != 0) {
      InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();

      // Set key to retrieve newly created payment ILI
      instructionLineItemKey.instructLineItemID = allocDtlsCaptured.creditInstructionLineItemID;
             
      // Read ILI details
      InstructionLineItemDtls iliDtls = instructionLineItemObj.read(
        instructionLineItemKey);

      // populate financial instruction ID to retrieve
      // Payment Received details
      PmtRecvFinInstructionID pmtRecvFinInstructionID = new PmtRecvFinInstructionID();

      pmtRecvFinInstructionID.finInstructionID = iliDtls.finInstructionID;

      // paymentReceivedInstruction manipulation variables
      curam.core.intf.PaymentReceivedInstruction paymentReceivedInstructionObj = curam.core.fact.PaymentReceivedInstructionFactory.newInstance();
      PaymentReceivedInstructionDtls paymentReceivedInstructionDtls = new PaymentReceivedInstructionDtls();
      // set the paymentInstructionEffectiveDate to default date
      curam.util.type.Date paymentReceivedInstructionReceivedDate = curam.util.type.Date.kZeroDate;

      // get the payment Received Date
      try {
        paymentReceivedInstructionDtls = paymentReceivedInstructionObj.readByFinInstructionID(
          pmtRecvFinInstructionID);
        paymentReceivedInstructionReceivedDate = paymentReceivedInstructionDtls.receivedDate;
      } catch (curam.util.exception.RecordNotFoundException e) {// Ignore exceptions of this type
      }
      // Case Header Manipulation variables to get Case Reference Number
      curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      CaseSearchKey caseSearchKey = new CaseSearchKey();

      // set caseId
      caseSearchKey.caseID = debitILIDtls.caseID;  
      // maintainCase manipulation variables to get product name
      curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
      CaseIDKey caseIDKey = new CaseIDKey();

      // set key to read maintainCase
      caseIDKey.caseID = debitILIDtls.caseID;
      CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
        caseIDKey);   
      LocalisableString description = new LocalisableString(BPOCASEEVENTS.PAYMENTS_RECEIVED).arg(paymentReceivedInstructionReceivedDate).arg(caseReferenceProductNameConcernRoleName.productName).arg(
        caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.PAYMENT_RECEIVED, description, 
        debitILIDtls.caseID, iliDtls.finInstructionID);
    }
    // END CR00110127
    
    dacreditILIidStatus.creditInstructionLineItemID = allocDtlsCaptured.creditInstructionLineItemID;
    dacreditILIidStatus.statusCode = curam.codetable.ALLOCATIONSTATUS.ACTIVE;

    draftAllocationLineDtlsList = draftAllocationLineObj.searchByCreditILIStatus(
      dacreditILIidStatus);

    if (!draftAllocationLineDtlsList.dtls.isEmpty()) {

      // Payment received allocation amount
      curam.util.type.Money creditAllocAmt = curam.util.type.Money.kZeroMoney;

      for (int i = 0; i < draftAllocationLineDtlsList.dtls.size(); i++) {

        creditAllocAmt = new curam.util.type.Money(
          creditAllocAmt.getValue()
            + draftAllocationLineDtlsList.dtls.item(i).amount.getValue());
      }

      if (creditAllocAmt.getValue()
        > creditILIDtls.unprocessedAmount.getValue()) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOALLOCATECREDITTRANSACTION.ERR_DRAFTALLOCATION_XFV_ALLOC_UNALLOCAMT_CDT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    }

  }

  // ___________________________________________________________________________
  /**
   * To transfer the DraftAllocationLines for a payment received to the live
   * AllocationLine and continue the normal allocation process.
   *
   * @param creditAllocateKey Credit Allocate Key
   */
  public void allocateCreditTransaction(CreditAllocateKey creditAllocateKey)
    throws AppException, InformationalException {

    // Draft allocation readmulti data status
    DAcreditILIidStatus draftAllocKey = new DAcreditILIidStatus();
    curam.core.intf.DraftAllocationLine draftAllocationLineObj = curam.core.fact.DraftAllocationLineFactory.newInstance();

    // Read multi class
    TransferAllocation transferAlloc = new TransferAllocation();

    draftAllocKey.creditInstructionLineItemID = creditAllocateKey.instructionLineItemID;
    draftAllocKey.statusCode = curam.codetable.ALLOCATIONSTATUS.ACTIVE;

    draftAllocationLineObj.searchByCreditILIStatus(draftAllocKey, transferAlloc);

  }

  // ___________________________________________________________________________
  /**
   * To remove allocations from the DraftAllocation table to where the debit
   * allocation was not completed.
   *
   * @param creditAllocateKey Credit Allocate Key
   */
  public void removeAllocationDtls(CreditAllocateKey creditAllocateKey)
    throws AppException, InformationalException {

    // draftAllocationLine details list
    DraftAllocationLineDtlsList draftAllocDtlsList;

    // draftAllocationLine manipulation variables
    DAcreditILIidStatus draftAllocKey = new DAcreditILIidStatus();
    curam.core.intf.DraftAllocationLine draftAllocationLineObj = curam.core.fact.DraftAllocationLineFactory.newInstance();

    // set key to read draftAllocationLine entity
    draftAllocKey.creditInstructionLineItemID = creditAllocateKey.instructionLineItemID;
    draftAllocKey.statusCode = curam.codetable.ALLOCATIONSTATUS.ACTIVE;

    // read draftAllocation entity
    draftAllocDtlsList = draftAllocationLineObj.searchByCreditILIStatus(
      draftAllocKey);

    if (!draftAllocDtlsList.dtls.isEmpty()) {

      // draftAllocation manipulation variable
      DraftAllocationLineKey draftAllocationLineKey = new DraftAllocationLineKey();

      for (int i = 0; i < draftAllocDtlsList.dtls.size(); i++) {

        draftAllocationLineKey.draftAllocationLineID = draftAllocDtlsList.dtls.item(i).draftAllocationLineID;

        try {
          draftAllocationLineObj.remove(draftAllocationLineKey);

        } catch (curam.util.exception.RecordNotFoundException e) {// ignore exception of this type - we were trying to remove it so it
          // doesn't exist, the same objective exists
        }

      }

    }

  }

}
