/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2013 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import java.util.ArrayList;
import java.util.HashMap;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.CONCERNROLEADDRESSTYPE;
import curam.codetable.ENTITYATTRIBUTENAMES;
import curam.codetable.RECORDSTATUS;
import curam.core.events.CONCERNROLEADDRESS;
import curam.core.fact.AddressFactory;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.AddressKey;
import curam.core.struct.AddressReadMultiDtlsList;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleAddressDtls;
import curam.core.struct.ConcernRoleAddressKey;
import curam.core.struct.ConcernRoleAddressSnapshotDtls;
import curam.core.struct.ConcernRoleAddressSnapshotKey;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.message.PARTICIPANTDATACASE;
import curam.message.SUMMARYDETAILS;
import curam.pdc.fact.PDCUtilFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;


public abstract class ConcernRoleAddress extends curam.core.base.ConcernRoleAddress implements ParticipantEvidenceInterface {

  // BEGIN, CR00059195, POH
  protected static ThreadLocal<ConcernRoleAddressCache> cachedReadTL = new ThreadLocal<ConcernRoleAddressCache>();

  // ___________________________________________________________________________
  /**
   * Clear cached data in cachedReadTL
   */
  protected void clearCaches() {
    ConcernRoleAddressCache cache = cachedReadTL.get();

    if (cache != null) {
      cache.map.clear();
    } else {
      cache = new ConcernRoleAddressCache();
      cachedReadTL.set(cache);
    }
    cache.transactionID = TransactionInfo.getIdentifierForThisThread();

  }

  // ___________________________________________________________________________
  /**
   * Caching Details for Improved Performance
   */
  protected class ConcernRoleAddressCache {
    public ConcernRoleAddressCache() {
      map = new HashMap<Long, ConcernRoleAddressDtls>();
      transactionID = 0;
    }

    HashMap<Long, ConcernRoleAddressDtls> map;

    int transactionID;
  }

  // BEGIN, CR00065902, MMC

  // ___________________________________________________________________________
  /**
   * Calculates the AttributionDates For entity, specifically for its use as a
   * ParticipantEvidence.
   *
   * @param caseKey
   * @param evKey
   * Evidence key containing the evidenceID and evidenceType
   * @return AttributedDateDetails
   */
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey,
    EIEvidenceKey evKey) throws AppException, InformationalException {

    // return struct
    AttributedDateDetails attributedDateDetails = new AttributedDateDetails();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    ConcernRoleAddressDtls concernRoleAddressDtls = read(evKey);

    // END, CR00240667    

    // populate return struct
    attributedDateDetails.fromDate = concernRoleAddressDtls.startDate;
    attributedDateDetails.toDate = concernRoleAddressDtls.endDate;

    return attributedDateDetails;
  }

  /**
   * Reads the entity details given the evidence record identifier.
   *
   * @param key The evidence record identifier.
   *
   * @return The entity details.
   *
   * @throws InformationalException
   * @throws AppException
   */
  protected ConcernRoleAddressDtls read(EIEvidenceKey key) throws AppException,
      InformationalException {
    
    // manipulation variables
    ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();
    ConcernRoleAddressDtls concernRoleAddressDtls = new ConcernRoleAddressDtls();
    curam.core.intf.ConcernRoleAddress concernRoleAddressObj = curam.core.fact.ConcernRoleAddressFactory.newInstance();

    // populate the key with passed in parameter
    concernRoleAddressKey.concernRoleAddressID = key.evidenceID;

    // BEGIN, CR00067890, POH
    // read concernRoleAddress details
    try {
      concernRoleAddressDtls = concernRoleAddressObj.read(concernRoleAddressKey);
    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot concernRoleAddress entity
      ConcernRoleAddressSnapshotKey concernRoleAddressSnapshotKey = new ConcernRoleAddressSnapshotKey();

      curam.core.intf.ConcernRoleAddressSnapshot concernRoleAddressSnapshotObj = curam.core.fact.ConcernRoleAddressSnapshotFactory.newInstance();

      // populate the concernRoleAddress snapshot key with passed in parameter
      concernRoleAddressSnapshotKey.concernRoleAddressSnapshotID = key.evidenceID;

      // read concernRoleAddress snapshot details
      ConcernRoleAddressSnapshotDtls concernRoleAddressSnapshotDtls = concernRoleAddressSnapshotObj.read(
        concernRoleAddressSnapshotKey);

      concernRoleAddressDtls.assign(concernRoleAddressSnapshotDtls);
    }
    // END, CR00067890
    return concernRoleAddressDtls;
  }

  // ___________________________________________________________________________
  /**
   * Get evidence details for the list display
   *
   * @param key
   * Evidence key containing the evidenceID and evidenceType
   * @return Evidence details to be displayed on the list page
   */
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key)
    throws AppException, InformationalException {

    // Return struct
    EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    ConcernRoleAddressDtls concernRoleAddressDtls = read(key);

    // END, CR00240667  
    
    // set start and end dates
    eiFieldsForListDisplayDtls.startDate = concernRoleAddressDtls.startDate;
    eiFieldsForListDisplayDtls.endDate = concernRoleAddressDtls.startDate;

    // Set the summary details.
    curam.core.intf.Address addressObj = AddressFactory.newInstance();

    // BEGIN, CR00101196, VM
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = concernRoleAddressDtls.addressID;

    curam.core.struct.OtherAddressData otherAddressData = addressObj.readAddressData(
      addressKey);

    // END, CR00101196

    addressObj.getOneLineAddressString(otherAddressData);

    // BEGIN, CR00241068, CD
    LocalisableString message = new LocalisableString(SUMMARYDETAILS.ADDRESS);

    message.arg(
      CodeTable.getOneItem(CONCERNROLEADDRESSTYPE.TABLENAME,
      concernRoleAddressDtls.typeCode));
    message.arg(otherAddressData.addressData);

    eiFieldsForListDisplayDtls.summary = message.getMessage(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00241068

    return eiFieldsForListDisplayDtls;
  }

  // ___________________________________________________________________________
  /**
   * Inserts evidence details - overrides Participant Evidence inherited
   * abstract method
   *
   * @param dtls
   * Object containing details of entity
   * @param parentKey
   * EIEvidenceKey for parent
   * @return the eiEvidenceKey to access the inserted evidence
   */
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ConcernRoleAddressDtls) dtls);

    eiEvidenceKey.evidenceID = ((ConcernRoleAddressDtls) dtls).concernRoleAddressID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEADDRESS;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Inserts ConcernRoleAddress evidence on modification
   *
   * @param dtls
   * Object containing details of entity
   * @param origKey
   * EIEvidenceKey for entity to insert
   * @param parentKey
   * EIEvidenceKey for parent
   * @return the EIEvidenceKey to access the inserted evidence
   */
  public EIEvidenceKey insertEvidenceOnModify(Object dtls,
    EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException,
      InformationalException {

    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ConcernRoleAddressDtls) dtls);

    eiEvidenceKey.evidenceID = ((ConcernRoleAddressDtls) dtls).concernRoleAddressID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEADDRESS;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modify ConcernRoleAddress evidence
   *
   * @param key
   * Evidence key containing evidenceID and evidenceType
   * @param dtls
   * ConcernRoleAddress entity details
   */
  public void modifyEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {
    // ConcernRoleAddress entity key
    ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();

    // Set entity key for modify
    concernRoleAddressKey.concernRoleAddressID = key.evidenceID;

    // Modify details
    modify(concernRoleAddressKey, (ConcernRoleAddressDtls) dtls);

  }

  // ___________________________________________________________________________
  /**
   * Inserts details into database. The cache is cleared first.
   *
   * @param details
   * Contains entity details
   */
  public void insert(ConcernRoleAddressDtls details) throws AppException,
      InformationalException {

    this.clearCaches();
    super.insert(details);
  }

  // ___________________________________________________________________________
  /**
   * Modifies details in the database Entity. The cache is cleared first.
   *
   * @param key
   * Contains key to access entity details
   * @param details
   * Contains details to modify
   */
  public void modify(ConcernRoleAddressKey key, ConcernRoleAddressDtls details)
    throws AppException, InformationalException {
    // We want to clear the cache in case for some reason the database
    // evidence is required e.g. if the evidence was updated by another user.
    // So to ensure we have the correct evidence, clear the cache and force a
    // read from the database
    this.clearCaches();

    super.modify(key, details);

    // The reason why we have to clear the cache here is a result of how the
    // evidence controller performs the modifying of evidence. PreModifying the
    // record it reads the details (first time it reads the details so will be
    // read from database and cached). The record is modified and post
    // modifying, the evidence controller calls performValidation
    // (validates the record) which requires a read of the evidence. The cached
    // evidence has stored the evidence PRIOR to the modification of the record.
    // Therefore we want to go to the database to read the modified evidence and
    // as a result clear the cache post modification.
    this.clearCaches();
  }

  // ___________________________________________________________________________
  /**
   * reads all ConcernRoleAddress Entities by its Parent ID
   *
   * @param key
   * EIEvidenceKey, the evidence key of the parent
   * @return the EIEvidenceKeyList of children
   */
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key)
    throws AppException, InformationalException {
    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Read evidence details - overrides Participant Evidence inherited abstract
   * method
   *
   * @param key
   * Evidence key containing the evidenceID and evidenceType
   * @return the Object with the readEvidence details
   */
  public Object readEvidence(EIEvidenceKey key) throws AppException,
      InformationalException {

    // manipulation variables
    ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();
    ConcernRoleAddressDtls concernRoleAddressDtls = new ConcernRoleAddressDtls();
    curam.core.intf.ConcernRoleAddress concernRoleAddressObj = curam.core.fact.ConcernRoleAddressFactory.newInstance();

    // populate the concernRoleAddress key with passed in parameter
    concernRoleAddressKey.concernRoleAddressID = key.evidenceID;

    try {
      // read concernRoleAddress details
      concernRoleAddressDtls = concernRoleAddressObj.read(concernRoleAddressKey);

      return concernRoleAddressDtls;

    } catch (RecordNotFoundException recordNotFoundException) {

      // BEGIN, CR00060045, POH
      // If no record has been return for ID passed
      // read from the snapshot concernRoleAddress entity
      ConcernRoleAddressSnapshotKey concernRoleAddressSnapshotKey = new ConcernRoleAddressSnapshotKey();
      ConcernRoleAddressSnapshotDtls concernRoleAddressSnapshotDtls = new ConcernRoleAddressSnapshotDtls();
      curam.core.intf.ConcernRoleAddressSnapshot concernRoleAddressSnapshotObj = curam.core.fact.ConcernRoleAddressSnapshotFactory.newInstance();

      // populate the concernRoleAddress snapshot key with passed in parameter
      concernRoleAddressSnapshotKey.concernRoleAddressSnapshotID = key.evidenceID;

      // read concernRoleAddress snapshot details
      concernRoleAddressSnapshotDtls = concernRoleAddressSnapshotObj.read(
        concernRoleAddressSnapshotKey);

      // replace primary key on concernRoleDtls with concernRoleSnapshot
      // primary key concernRoleSnapshotID
      concernRoleAddressDtls.assign(concernRoleAddressSnapshotDtls);

      return concernRoleAddressDtls;
      // END, CR00060045
    }

  }

  // ___________________________________________________________________________
  /**
   * return list for validation
   *
   * @param evKey
   * Evidence key containing the evidenceID and evidenceType
   * @return the EIEvidenceKeyList for validation
   */
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey)
    throws AppException, InformationalException {
    // This evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * run validations
   *
   * @param evKey
   * EIEvidenceKey
   * @param evKeyList
   * EIEvidenceKeyList
   * @param mode
   * Validate Mode
   */
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList,
    ValidateMode mode) throws AppException, InformationalException {// This
    // evidence
    // interface
    // method
    // is
    // currently
    // not
    // implemented
    // for
    // participant evidence.
  }

  // ___________________________________________________________________________
  /**
   * To create a new snapshot record of the concernRoleAddress entity,
   * specifically for its use as a ParticpantEvidence.
   *
   * @param key
   * the key to access the entity for which to create a snapshot
   * @return the key to access the snapshot
   */
  public EIEvidenceKey createSnapshot(EIEvidenceKey key) throws AppException,
      InformationalException {

    // return struct
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // manipulation variables
    ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();
    ConcernRoleAddressDtls concernRoleAddressDtls = new ConcernRoleAddressDtls();
    ConcernRoleAddressSnapshotDtls concernRoleAddressSnapshotDtls = new ConcernRoleAddressSnapshotDtls();
    curam.core.intf.ConcernRoleAddress concernRoleAddressObj = curam.core.fact.ConcernRoleAddressFactory.newInstance();
    curam.core.intf.ConcernRoleAddressSnapshot concernRoleAddressSnapshotObj = curam.core.fact.ConcernRoleAddressSnapshotFactory.newInstance();

    // populate the key with passed in parameter
    concernRoleAddressKey.concernRoleAddressID = key.evidenceID;

    // read concernRoleAddress details
    concernRoleAddressDtls = concernRoleAddressObj.read(concernRoleAddressKey);

    // BEGIN, CR00060045, POH
    // populate snapshot details
    concernRoleAddressSnapshotDtls.assign(concernRoleAddressDtls);
    // END, CR00060045

    concernRoleAddressSnapshotDtls.creationDateTime = DateTime.getCurrentDateTime();

    // insert snapshot record
    concernRoleAddressSnapshotObj.insert(concernRoleAddressSnapshotDtls);

    // populate return struct
    eiEvidenceKey.evidenceID = concernRoleAddressSnapshotDtls.concernRoleAddressSnapshotID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEADDRESS;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * remove Entity
   *
   * @param key
   * Evidence key containing the evidenceID and evidenceType
   * @param dtls
   * of entity to remove
   */
  public void removeEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Entity key
    ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();

    // Set entity key for modify
    concernRoleAddressKey.concernRoleAddressID = key.evidenceID;

    // Modify details
    modify(concernRoleAddressKey, (ConcernRoleAddressDtls) dtls);

  }

  // END, CR00059195

  // __________________________________________________________________________
  /**
   * Raise a post Insert event
   *
   * @param details
   * details for the ConcernRoleAddress record.
   */
  protected void postinsert(ConcernRoleAddressDtls details)
    throws AppException, InformationalException {

    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLEADDRESS.INSERT_CONCERN_ROLE_ADDRESS;
    // END, CR00047242
    event.primaryEventData = details.concernRoleAddressID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // __________________________________________________________________________
  /**
   * Raise a post Modify event
   *
   * @param key
   * ConcernRoleAddress key to modify
   * @param details
   * details for the ConcernRoleAddress record.
   */
  protected void postmodify(ConcernRoleAddressKey key,
    ConcernRoleAddressDtls details) throws AppException,
      InformationalException {

    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLEADDRESS.MODIFY_CONCERN_ROLE_ADDRESS;
    // END, CR00047242
    event.primaryEventData = details.concernRoleAddressID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // __________________________________________________________________________
  /**
   * Raise a post remove event
   *
   * @param key
   * ConcernRoleAddress key to remove
   */
  protected void postremove(ConcernRoleAddressKey key) throws AppException,
      InformationalException {// Code was moved to pre-remove method. For more details please see CR00373611.  
  }
  
  // BEGIN, CR00059697, SK
  // ___________________________________________________________________________
  /**
   * Method to search for records on a participant entity by concernRoleID and
   * status.
   *
   * @param key
   * - The unique concernRoleID of the participant.
   *
   * @return A list of EIEvidenceKey objects each containing an
   * evidenceID/evidenceType pair.
   */
  public EIEvidenceKeyList readAllByConcernRoleID(ConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00060045, POH
    // return struct
    EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    // manipulation variables
    EIEvidenceKey eiEvidenceKey;
    // BEGIN, CR00060163, POH
    // BEGIN, CR00066203, AC
    ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();
    AddressReadMultiDtlsList addressReadMultiDtlsList = new AddressReadMultiDtlsList();
    curam.core.intf.ConcernRoleAddress concernRoleAddressObj = curam.core.fact.ConcernRoleAddressFactory.newInstance();

    // populate the concernRoleAddress key with passed in parameter
    concernRoleIDStatusCodeKey.concernRoleID = key.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = RECORDSTATUS.NORMAL;

    // read list of concernRoleAddress records for concernRole
    addressReadMultiDtlsList = concernRoleAddressObj.searchAddressesByConcernRoleIDAndStatus(
      concernRoleIDStatusCodeKey);
    // END, CR00066203

    // loop through returned list adding each returned ID to returned struct.
    for (int i = 0; i < addressReadMultiDtlsList.dtls.size(); i++) {

      // Instantiate struct
      eiEvidenceKey = new EIEvidenceKey();

      // populate details
      eiEvidenceKey.evidenceID = addressReadMultiDtlsList.dtls.item(i).concernRoleAddressID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEADDRESS;

      // add details to return struct
      eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
    }

    return eiEvidenceKeyList;
    // END, CR00060045
  }

  // END, CR00059697
  // END, CR00065902

  // BEGIN, CR00069014, JPG
  // ___________________________________________________________________________
  /**
   * Method to compare attributes on two records of the same entity type. It
   * then returns an ArrayList of strings with the names of each attribute that
   * was different between them.
   *
   * @param key
   * - Contains an evidenceID / evidenceType pairing
   * @param dtls
   * - a struct of the same type as the key containing the attributes
   * to be compared against
   *
   * @return A list of Strings. Each represents an attribute name that differed.
   */
  public ArrayList<String> getChangedAttributeList(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Declare the return list to hold the names of the attributes that changed
    ArrayList<String> attributesChanged = new ArrayList<String>();

    // Create ConcernRoleAddress structs to allow a comparison of what is
    // in the database and what is in the struct dtls.
    ConcernRoleAddressDtls concernRoleAddressCompareDtls1 = new ConcernRoleAddressDtls();
    ConcernRoleAddressDtls concernRoleAddressCompareDtls2 = new ConcernRoleAddressDtls();

    try {

      curam.core.intf.ConcernRoleAddress concernRoleAddressObj = curam.core.fact.ConcernRoleAddressFactory.newInstance();

      ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();

      concernRoleAddressKey.concernRoleAddressID = key.evidenceID;

      // read concernRoleAddressKey details
      concernRoleAddressCompareDtls1 = concernRoleAddressObj.read(
        concernRoleAddressKey);

      // Populate the concernRoleAddress struct that will be compared against
      concernRoleAddressCompareDtls2.assign((ConcernRoleAddressDtls) dtls);

    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot concernRoleAddress entity
      curam.core.intf.ConcernRoleAddressSnapshot concernRoleAddressSnapshotObj = curam.core.fact.ConcernRoleAddressSnapshotFactory.newInstance();

      ConcernRoleAddressSnapshotKey concernRoleAddressSnapshotKey = new ConcernRoleAddressSnapshotKey();

      // populate the concernRoleAddress snapshot key with passed in parameter
      concernRoleAddressSnapshotKey.concernRoleAddressSnapshotID = key.evidenceID;

      // Read the concernRoleAddress snapshot details
      concernRoleAddressCompareDtls2.assign(
        concernRoleAddressSnapshotObj.read(concernRoleAddressSnapshotKey));

      // Populate the concernRoleAddress struct that will be compared against
      concernRoleAddressCompareDtls1.assign((ConcernRoleAddressDtls) dtls);
    }

    if (concernRoleAddressCompareDtls1.concernRoleID
      != concernRoleAddressCompareDtls2.concernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEID);
    }
    if (concernRoleAddressCompareDtls1.concernRoleAddressID
      != concernRoleAddressCompareDtls2.concernRoleAddressID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEADDRESSID);
    }
    if (concernRoleAddressCompareDtls1.addressID
      != concernRoleAddressCompareDtls2.addressID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.ADDRESSID);
    }
    if (!concernRoleAddressCompareDtls1.typeCode.equals(
      concernRoleAddressCompareDtls2.typeCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.TYPECODE);
    }
    if (!concernRoleAddressCompareDtls1.startDate.equals(
      concernRoleAddressCompareDtls2.startDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STARTDATE);
    }
    if (!concernRoleAddressCompareDtls1.endDate.equals(
      concernRoleAddressCompareDtls2.endDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.ENDDATE);
    }
    if (!concernRoleAddressCompareDtls1.statusCode.equals(
      concernRoleAddressCompareDtls2.statusCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STATUSCODE);
    }
    if (!concernRoleAddressCompareDtls1.comments.equals(
      concernRoleAddressCompareDtls2.comments)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COMMENTS);
    }

    return attributesChanged;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if the attributes that changed during a modify require
   * reassessment to be run when they are applied.
   *
   * @param attributesChanged
   * - A list of Strings. Each represents the name of an attribute that
   * changed
   *
   * @return true if Reassessment required
   */
  public boolean checkForReassessment(ArrayList attributesChanged)
    throws AppException, InformationalException {

    return true;

    /*
     * Implement code here if you wish to only reassess modifications to
     * participant evidence when specified attributes are changed during the
     * modification. Currently this method returns true so any modifications to
     * participant evidence will trigger reassessment. To Implement set an
     * indicator to false and check the attributesChanged list for the
     * attributes that require reassessment. If one is found set the in
     * indicator to true
     */
  }

  // END, CR00069014
  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    // BEGIN, CR00240667, CD
    return read(evKey).endDate;
    // END, CR00240667
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    // BEGIN, CR00240667, CD
    return read(evKey).startDate;
    // END, CR00240667
  }

  // END, CR002204022

  
  // BEGIN, CR00345190, ELG
  // ___________________________________________________________________________
  /**
   * When Participant Data Case is enabled an Application Exception will be thrown
   * when this method is called.  
   *
   * @param key Concern Role Address key to remove.
   *
   * @throws InformationalException
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_PARTICIPANT_INVOCATION_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   */  
  @Override
  protected void preremove(final ConcernRoleAddressKey key) throws AppException,
      InformationalException {
    
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleAddressDtls concernRoleAddressDtls = read(key);

    concernRoleKey.concernRoleID = concernRoleAddressDtls.concernRoleID;
        
    if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    }
    
    // BEGIN, CR00373611, ELG
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLEADDRESS.REMOVE_CONCERN_ROLE_ADDRESS;
    // END, CR00047242

    event.primaryEventData = key.concernRoleAddressID;
    curam.util.events.impl.EventService.raiseEvent(event);
    // END, CR00373611
      
  }
  
  // ___________________________________________________________________________
  /**
   * When Participant Data Case is enabled an Application Exception will be thrown
   * when this method is called.  
   *
   * @param details Concern Role Address details to insert.
   *
   * @throws InformationalException
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_PARTICIPANT_INVOCATION_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   */  
  @Override
  protected void preinsert(final ConcernRoleAddressDtls details) throws AppException,
      InformationalException {
    
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    
    concernRoleKey.concernRoleID = details.concernRoleID;
        
    if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    }   
    
  }

  // ___________________________________________________________________________
  /**
   * When Participant Data Case is enabled an Application Exception will be thrown
   * when this method is called.  
   *
   * @param key Concern Role Address key to modify.
   * @param details Modified Concern Role Address details.
   *
   * @throws InformationalException
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_PARTICIPANT_INVOCATION_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   */  
  @Override
  protected void premodify(final ConcernRoleAddressKey key,
    final ConcernRoleAddressDtls details) throws AppException,
      InformationalException {
    
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    
    concernRoleKey.concernRoleID = details.concernRoleID;
        
    if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) { 
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    }   
    
  }

  // __________________________________________________________________________
  /**
   * Raise a post Insert event.
   *
   * @param details
   * details for the ConcernRoleAddress record.
   */
  @Override
  protected void postpdcInsert(final ConcernRoleAddressDtls details)
    throws AppException, InformationalException {
    
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLEADDRESS.INSERT_CONCERN_ROLE_ADDRESS;
    // END, CR00047242
    event.primaryEventData = details.concernRoleAddressID;
    curam.util.events.impl.EventService.raiseEvent(event);
    
  }
  
  // __________________________________________________________________________
  /**
   * Raise a post Modify event.
   *
   * @param key
   * ConcernRoleAddress key to modify
   * @param details
   * details for the ConcernRoleAddress record.
   */
  @Override
  protected void postpdcModify(final ConcernRoleAddressKey key,
    final ConcernRoleAddressDtls details) throws AppException,
      InformationalException {
    
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLEADDRESS.MODIFY_CONCERN_ROLE_ADDRESS;
    // END, CR00047242
    event.primaryEventData = details.concernRoleAddressID;
    curam.util.events.impl.EventService.raiseEvent(event);
    
  }

  // END, CR00345190

  // BEGIN, CR00373611, ELG
  /**
   * Raise address removal event.
   *
   * @param key
   * ConcernRoleAddress key to remove
   */
  @Override
  protected void prepdcRemove(ConcernRoleAddressKey key) throws AppException,
      InformationalException {
    
    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = CONCERNROLEADDRESS.REMOVE_CONCERN_ROLE_ADDRESS;

    event.primaryEventData = key.concernRoleAddressID;
    curam.util.events.impl.EventService.raiseEvent(event);
    
  }
  // END, CR00373611
  
}
