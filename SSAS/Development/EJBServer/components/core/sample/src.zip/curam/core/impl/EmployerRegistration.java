/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2009, 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.Map;

import com.google.inject.Inject;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.CONCERNROLEADDRESSTYPE;
import curam.codetable.CONCERNROLEALTERNATEID;
import curam.codetable.CONCERNROLESTATUS;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.LOCATIONSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REPRESENTATIVETYPE;
import curam.codetable.SENSITIVITY;
import curam.codetable.TRADINGSTATUS;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.core.fact.ConcernRoleAlternateIDFactory;
import curam.core.intf.ConcernRoleAlternateID;
import curam.core.sl.fact.RepresentativeFactory;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorInsertDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceInsertDtls;
import curam.core.sl.infrastructure.impl.ValidationManager;
import curam.core.sl.intf.Representative;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.AdminConcernRoleDetails;
import curam.core.struct.AlternateIDTypeCodeKey;
import curam.core.struct.CommExceptionDetails;
import curam.core.struct.ConcernDtls;
import curam.core.struct.ConcernRoleAddressDtls;
import curam.core.struct.ConcernRoleAlternateIDDtls;
import curam.core.struct.ConcernRoleAlternateReadKey;
import curam.core.struct.ConcernRoleContactDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.DupConcernRoleAltIDDetailsList;
import curam.core.struct.EmployerDtls;
import curam.core.struct.EmployerRegistrationDetails;
import curam.core.struct.LocationKey;
import curam.core.struct.MaintainAdminConcernRoleKey;
import curam.core.struct.MaintainCommExceptionKey;
import curam.core.struct.MaintainTradingStatusKey;
import curam.core.struct.PhoneNumberDetails;
import curam.core.struct.PhoneNumberDtls;
import curam.core.struct.RegistrationIDDetails;
import curam.core.struct.SearchCRTypeAltIDType;
import curam.core.struct.TradingStatusDetails;
import curam.message.BPOEMPLOYERREGISTRATION;
import curam.message.BPOMAINTAINCONCERNROLEALTID;
import curam.message.BPOMAINTAINCONTACTS;
import curam.message.BPOPERSONREGISTRATION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.CodeTable;


/**
 * Registration of employer
 */
public abstract class EmployerRegistration extends curam.core.base.EmployerRegistration {

  // BEGIN, CR00312286, SG
  @Inject
  private Map<String, AllocateParticipantID> allocateParticipantIDMap;

  /**
   * Add injection.
   */
  public EmployerRegistration() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00312286

  /**
   * Called to register a new employer with the organization.
   *
   * @param details
   * Details of the employer to be registered.
   *
   * @return Details of the employer's registration id.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RegistrationIDDetails registerEmployer(
    EmployerRegistrationDetails details)
    throws AppException, InformationalException {

    // return value
    RegistrationIDDetails registrationmIDDetailsRet = new RegistrationIDDetails();

    // general objects & variables
    // BEGIN, CR00060544, POH
    // EvidenceController business object
    curam.core.sl.infrastructure.impl.EvidenceControllerInterface evidenceControllerObj = (curam.core.sl.infrastructure.impl.EvidenceControllerInterface)
      curam.core.sl.infrastructure.fact.EvidenceControllerFactory.newInstance();

    // Evidence descriptor details
    EvidenceDescriptorInsertDtls evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    // Evidence Interface details
    EIEvidenceInsertDtls eiEvidenceInsertDtls = new EIEvidenceInsertDtls();
    // END, CR00060544

    // object for any unique id generation
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // current date
    curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // declaration of variables to prevent duplicate alternative ID's
    AlternateIDTypeCodeKey alternateIDTypeCodeKey = new AlternateIDTypeCodeKey();
    boolean altIDExist = true;

    // variables for concern registration
    // Concern Entity
    curam.core.intf.Concern concernObj = curam.core.fact.ConcernFactory.newInstance();
    ConcernDtls concernDtls = new ConcernDtls(); // Concern structure
    // based on domain CONCERN_ID
    long concernID = 0;

    // based on domain CONCERN_ROLE_ID
    long concernRoleID = 0;

    // variables for different IDs
    // based on domain ADDRESS_ID
    long primaryAddressID = 0;
    // based on domain ALTERNATE_ID

    // BEGIN, CR00049218, GM
    String alternateEmployerReferenceNo = CuramConst.gkEmpty;
    // END, CR00049218

    // BEGIN, CR00021614, NVR
    // variable to determine if the reference number is provided
    boolean bAlternateEmployerRefNo = false;
    // END, CR00021614

    // based on domain PHONE_NUMBER_ID
    long phoneNumberID = 0;

    // variables for registration of concernRole
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleAlternateReadKey concernRoleAlternateReadKey = new ConcernRoleAlternateReadKey();
    ConcernRoleDtls concernRoleDtls;

    // variables for concern role alternate ID
    // entity
    curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj = curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();
    // concern role alternate id details structure
    ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls;

    // based on domain CONCERN_ROLE_ALTERNATE_ID
    long concernRoleAlternateIDID = 0;

    // structure
    EmployerDtls employerDtls = new EmployerDtls();

    ConcernRoleAddressDtls concernRoleAddressBDtls = new ConcernRoleAddressDtls();
    // based on domain CONCERN_ROLE_ADDRESS_ID
    long concernRoleAddressBID = 0;

    // variables for address (business)
    curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    AddressDtls addressDtls = new AddressDtls();

    ConcernRoleAddressDtls concernRoleAddressRDtls = new ConcernRoleAddressDtls();
    // based on domain CONCERN_ROLE_ADDRESS_ID
    long concernRoleAddressRID = 0;

    // based on domain ADDRESS_ID
    long addressRID = 0;

    // variables for phone number & concern role phone number registration
    curam.core.intf.PhoneNumber phoneNumberObj = curam.core.fact.PhoneNumberFactory.newInstance();
    PhoneNumberDtls phoneNumberDtls = new PhoneNumberDtls();

    curam.core.intf.ConcernRolePhoneNumber concernRolePhoneNumberObj = curam.core.fact.ConcernRolePhoneNumberFactory.newInstance();
    ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls = new ConcernRolePhoneNumberDtls();
    // based on domain CONCERN_ROLE_PHONE_NUMBER_ID
    long concernRolePhoneNumberID = 0;

    // Maintain admin concern role details
    curam.core.intf.MaintainAdminConcernRole maintainAdminConcernRoleObj = curam.core.fact.MaintainAdminConcernRoleFactory.newInstance();

    MaintainAdminConcernRoleKey maintainAdminConcernRoleKey = new MaintainAdminConcernRoleKey();

    curam.core.intf.ValidateEmployerDetails validateEmployerDetailsObj = curam.core.fact.ValidateEmployerDetailsFactory.newInstance();

    // Call the validation method
    validateEmployerDetailsObj.validateEmployer(details);

    curam.core.intf.MaintainEmployerTradingStatus maintainEmployerTradingStatusObj = curam.core.fact.MaintainEmployerTradingStatusFactory.newInstance();

    MaintainTradingStatusKey maintainTradingStatusKey = new MaintainTradingStatusKey();
    TradingStatusDetails tradingStatusDetails = new TradingStatusDetails();

    // Generate the mandatory Unique ID's
    if (details.concernID == 0) {
      // generate unique concern id
      concernID = uniqueIDObj.getNextID();
    }

    // generate ids
    concernRoleID = uniqueIDObj.getNextID();
    // BEGIN, CR00096068, SD
    boolean recordNotFound = false;

    // END, CR00096068
    // set details to null before loop

    concernRoleDtls = null;
    concernRoleAlternateIDDtls = null;

    // validation to prevent the user from selecting a canceled office location
    if (details.prefPublicOfficeID != 0) {

      // Location business process object
      curam.core.intf.Location locationObj = curam.core.fact.LocationFactory.newInstance();

      LocationKey locationKey = new LocationKey();

      locationKey.locationID = details.prefPublicOfficeID;

      // read the public office status details
      String locationStatus = locationObj.read(locationKey).locationStatus;

      // if the public office is closed
      if (locationStatus.equals(LOCATIONSTATUS.CLOSED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOPERSONREGISTRATION.ERR_PUBLIC_OFFICE_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 5);

      }

      // if the public office is deleted.
      if (locationStatus.equals(RECORDSTATUS.CANCELLED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOPERSONREGISTRATION.ERR_PUBLIC_OFFICE_CANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 5);

      }
    }

    // validation to prevent duplicate alternative ID's

    // BEGIN, CR00394029, GD
    ValidationManager validationManagerObj = curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager();

    // BEGIN CR00020797, NH
    if (details.socialSecurityNumber.length() != 0) {
      alternateEmployerReferenceNo = details.socialSecurityNumber;

      // BEGIN, CR00021614, NVR
      bAlternateEmployerRefNo = true;
      // alternateIDTypeCodeKey.typeCode = CONCERNROLEALTERNATEID.INSURANCENUMBER;
      alternateIDTypeCodeKey.typeCode = CONCERNROLEALTERNATEID.EMPLOYER_REFERENCE_NUMBER;
      // END, CR00021614

      alternateIDTypeCodeKey.alternateID = alternateEmployerReferenceNo;

      alternateIDTypeCodeKey.statusCode = RECORDSTATUS.NORMAL;
      // BEGIN, CR00394323, PMD

      if (validationManagerObj.enabled(
        BPOMAINTAINCONCERNROLEALTID.ERR_CONCERNROLEALTID_XRV_ID_TYPE_CONCERNTYPE_OVERLAP,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 5)) {

        ConcernRoleAlternateID concernRoleAltIDObj = ConcernRoleAlternateIDFactory.newInstance();
      
        SearchCRTypeAltIDType searchCRTypeAltIDType = new SearchCRTypeAltIDType();

        searchCRTypeAltIDType.alternateID = alternateEmployerReferenceNo;
        searchCRTypeAltIDType.alternateIDType = CONCERNROLEALTERNATEID.EMPLOYER_REFERENCE_NUMBER;
        searchCRTypeAltIDType.statusCode = RECORDSTATUS.NORMAL;
        searchCRTypeAltIDType.concernRoleType = CONCERNROLETYPE.EMPLOYER;
        
        DupConcernRoleAltIDDetailsList dupConcernRoleAltIDDetailsList = concernRoleAltIDObj.searchByCRTypeAltIDAndType(
          searchCRTypeAltIDType);
        
        if (dupConcernRoleAltIDDetailsList.dtls.size() > 0) {
          
          final AppException ae = new AppException(
            BPOMAINTAINCONCERNROLEALTID.ERR_CONCERNROLEALTID_XRV_ID_TYPE_CONCERNTYPE_OVERLAP);
  
          ae.arg(
            CodeTable.getOneItem(CONCERNROLETYPE.TABLENAME,
            CONCERNROLETYPE.EMPLOYER));
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            ae,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 5);
        } else {
          recordNotFound = true;
        }
      } else {
        recordNotFound = true;
      }
      // END, CR00394323
      
      // BEGIN, CR00394029, GD
      if (validationManagerObj.enabled(
        BPOEMPLOYERREGISTRATION.ERR_EMPLOYER_SSN_ALREADY_EXISTS,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0)) {

        try {
          concernRoleAlternateIDDtls = concernRoleAlternateIDObj.readByAltIDTypeCode(
            alternateIDTypeCodeKey);
  
          if (details.socialSecurityNumber.length() > 0
            && details.socialSecurityNumber.equals(
              concernRoleAlternateIDDtls.alternateID)) {
            AppException ae = new AppException(
              BPOEMPLOYERREGISTRATION.ERR_EMPLOYER_SSN_ALREADY_EXISTS);
  
            ae.arg(details.socialSecurityNumber);
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              ae,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
          }
        } catch (curam.util.exception.MultipleRecordException e) {
  
          AppException ae = new AppException(
            BPOEMPLOYERREGISTRATION.ERR_EMPLOYER_SSN_ALREADY_EXISTS);
  
          ae.arg(details.socialSecurityNumber);
          throw ae;
        } catch (curam.util.exception.RecordNotFoundException e) {
          recordNotFound = true;
        }
      } else {
        recordNotFound = true; 
      }
      // END, CR00394029 
      // BEGIN, CR00096068, SD
      if (recordNotFound) {
        concernRoleAlternateReadKey.primaryAlternateID = alternateEmployerReferenceNo;

        concernRoleAlternateReadKey.statusCode = CONCERNROLESTATUS.DEFAULTCODE;
        
        // BEGIN, CR00394029, GD
        if (validationManagerObj.enabled(
          BPOEMPLOYERREGISTRATION.ERR_REFERENCE_NUM_ALREADY_EXISTS_AS_PRIMARY_ALT_ID,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0)) {
          try {
            concernRoleDtls = concernRoleObj.readByAlternateID(
              concernRoleAlternateReadKey);
  
            if (concernRoleAlternateReadKey.primaryAlternateID.equals(
              concernRoleDtls.primaryAlternateID)) {
              curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
                new AppException(
                  BPOEMPLOYERREGISTRATION.ERR_REFERENCE_NUM_ALREADY_EXISTS_AS_PRIMARY_ALT_ID),
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  0);
            }
          } catch (curam.util.exception.RecordNotFoundException e) {
            altIDExist = false;
          }
        } else {
          altIDExist = false;
        }
        // END, CR00394029
      }
      // END, CR00096068
    } else {
      while (altIDExist) {

        // BEGIN, CR00312286, SG
        alternateEmployerReferenceNo = allocateParticipantIDMap.get("EMPLOYER").getNextID();
        // END, CR00312286

        // BEGIN, CR00021614, NVR
        // alternateIDTypeCodeKey.typeCode = CONCERNROLEALTERNATEID.INSURANCENUMBER;
        alternateIDTypeCodeKey.typeCode = CONCERNROLEALTERNATEID.REFERENCE_NUMBER;
        // END, CR00021614

        alternateIDTypeCodeKey.alternateID = alternateEmployerReferenceNo;

        alternateIDTypeCodeKey.statusCode = RECORDSTATUS.NORMAL;

        recordNotFound = false;

        try {
          concernRoleAlternateIDDtls = concernRoleAlternateIDObj.readByAltIDTypeCode(
            alternateIDTypeCodeKey);

          if (alternateEmployerReferenceNo.equals(
            concernRoleAlternateIDDtls.alternateID)) {
            // if found continue to generate the next number
            continue;
          }
        } catch (curam.util.exception.MultipleRecordException e) {// BEGIN, CR00158767, LD
          /*
           * If you find possibility of more than one records in the database and if you have any specific
           exception message to display then implement it. In this case, we are making sure system generated alternate ID is unique.
           There could be an existing identical alternate id record, if any then we are continuing until we get a unique one generated.*/ // END, CR00158767
        } catch (curam.util.exception.RecordNotFoundException e) {
          recordNotFound = true;
        }

        if (recordNotFound) {

          if (validationManagerObj.enabled(
            BPOEMPLOYERREGISTRATION.ERR_REFERENCE_NUM_ALREADY_EXISTS_AS_PRIMARY_ALT_ID,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0)) { 
            
            concernRoleAlternateReadKey.primaryAlternateID = alternateEmployerReferenceNo;

            concernRoleAlternateReadKey.statusCode = CONCERNROLESTATUS.DEFAULTCODE;

            try {
              concernRoleDtls = concernRoleObj.readByAlternateID(
                concernRoleAlternateReadKey);
            } catch (curam.util.exception.RecordNotFoundException e) {
              altIDExist = false;
            }
          } else {
            altIDExist = false;
          }
        }
      }
    }
    // END CR00020797

    // insert concern (if it was not specified)
    if (details.concernID == 0) {
      // fill in the data structure
      concernDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();
      concernDtls.name = details.tradingName;
      concernDtls.concernID = concernID;
      // BEGIN, CR00049218, GM
      concernDtls.comments = CuramConst.gkEmpty;
      // END, CR00049218
      // insert concern record
      concernObj.insert(concernDtls);

    }

    addressDtls.addressData = details.businessAddressData;
    // save the address data (insert the record)
    addressObj.insert(addressDtls);

    primaryAddressID = addressDtls.addressID;

    // insert phone number details
    boolean phoneDetailsSpecified;

    if ((details.phoneAreaCode.length() + details.phoneCountryCode.length()
      + details.phoneExtension.length() + details.phoneNumber.length()
      + details.phoneType.length())
      > 0) {

      phoneDetailsSpecified = true;

    } else {

      phoneDetailsSpecified = false;

    }

    if (phoneDetailsSpecified) {

      curam.core.intf.MaintainPhoneNumber maintainPhoneNumberObj = curam.core.fact.MaintainPhoneNumberFactory.newInstance();
      PhoneNumberDetails phoneNumberDetails = new PhoneNumberDetails();

      phoneNumberDetails.phoneExtension = details.phoneExtension;
      phoneNumberDetails.phoneCountryCode = details.phoneCountryCode;
      phoneNumberDetails.phoneAreaCode = details.phoneAreaCode;
      phoneNumberDetails.phoneNumber = details.phoneNumber;
      // BEGIN, CR00049218, GM
      phoneNumberDetails.comments = CuramConst.gkEmpty;
      // END, CR00049218
      maintainPhoneNumberObj.validatePhoneNumber(phoneNumberDetails);

      // generate new unique id for inserting concernRolePhoneNumber
      concernRolePhoneNumberID = uniqueIDObj.getNextID();

      // fill in the data structure
      phoneNumberDtls.assign(phoneNumberDetails);

      // save phoneNumber to database
      phoneNumberObj.insert(phoneNumberDtls);

      // BEGIN, CR00260989, MR
      phoneNumberID = phoneNumberDtls.phoneNumberID;
      // END, CR00260989
    }

    // insert concern role

    // if instance of concern role details has not been created yet
    // create it here
    if (concernRoleDtls == null) {
      concernRoleDtls = new ConcernRoleDtls();
    }

    // fill in the data structure
    concernRoleDtls.concernRoleID = concernRoleID;
    if (details.concernID == 0) {
      concernRoleDtls.concernID = concernID;
    } else {
      concernRoleDtls.concernID = details.concernID;
    }

    concernRoleDtls.concernRoleType = CONCERNROLETYPE.EMPLOYER;
    concernRoleDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();
    concernRoleDtls.registrationDate = details.registrationDate;
    concernRoleDtls.startDate = details.registrationDate;
    concernRoleDtls.endDate = curam.util.type.Date.kZeroDate;
    concernRoleDtls.statusCode = CONCERNROLESTATUS.CURRENT;
    concernRoleDtls.concernRoleName = details.tradingName;
    concernRoleDtls.primaryAddressID = primaryAddressID;
    concernRoleDtls.primaryAlternateID = alternateEmployerReferenceNo;

    concernRoleDtls.primaryPhoneNumberID = phoneNumberID;

    concernRoleDtls.primaryEmailAddressID = 0;
    concernRoleDtls.regUserName = curam.util.transaction.TransactionInfo.getProgramUser();
    // BEGIN, CR00049218, GM
    concernRoleDtls.comments = CuramConst.gkEmpty;
    // END, CR00049218
    concernRoleDtls.prefPublicOfficeID = details.prefPublicOfficeID;

    // pass in the preferred language from the concern role table
    concernRoleDtls.preferredLanguage = details.preferredLanguage;
    concernRoleDtls.prefCommMethod = details.prefCommMethod;
    concernRoleDtls.sensitivity = SENSITIVITY.DEFAULTCODE;

    if (details.prefCommMethod.length() > 0) {
      concernRoleDtls.prefCommFromDate = details.registrationDate;
    }

    // save data to DB
    // BEGIN, CR00061193, POH
    // Call the EvidenceController object and insert evidence

    // Evidence descriptor details
    evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.participantID = concernRoleDtls.concernRoleID;
    evidenceDescriptorInsertDtls.evidenceType = CASEEVIDENCE.CONCERNROLE;
    evidenceDescriptorInsertDtls.receivedDate = curam.util.type.Date.getCurrentDate();

    // Evidence Interface details
    eiEvidenceInsertDtls = new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.descriptor.participantID = concernRoleDtls.concernRoleID;
    eiEvidenceInsertDtls.evidenceObject = concernRoleDtls;

    // Insert the evidence
    evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    // END, CR00061193

    // insert employer
    // fill in the data
    employerDtls.registeredName = details.registeredName;
    employerDtls.tradingName = details.tradingName;
    employerDtls.industryType = details.industryType;
    employerDtls.companyType = details.companyType;
    employerDtls.businessDesc = details.businessDescription;
    employerDtls.specialInterestCode = details.specialInterestType;
    employerDtls.exemptionInd = false; // impossible to set to blank
    employerDtls.concernRoleID = concernRoleID;
    employerDtls.numberPermanentStaff = details.permanentStaff;
    employerDtls.numberCasualStaff = details.casualStaff;
    employerDtls.statusCode = RECORDSTATUS.NORMAL;

    // BEGIN, CR00049218, GM
    employerDtls.comments = CuramConst.gkEmpty;
    // END, CR00049218
    employerDtls.primaryAlternateID = alternateEmployerReferenceNo;
    employerDtls.paymentFrequency = details.paymentFrequency;
    employerDtls.currencyType = details.currencyType;
    employerDtls.methodOfPmtCode = details.methodOfPmtCode;
    // based on domain FREQUENCY_PATTERN
    // calculate the next payment date if payment frequency has been entered
    if (employerDtls.paymentFrequency.length() != 0) {
      // BEGIN, CR00049218, GM
      String frequencyPattern = CuramConst.gkEmpty;

      // END, CR00049218
      frequencyPattern = employerDtls.paymentFrequency;
      employerDtls.nextPaymentDate = new curam.util.type.FrequencyPattern(frequencyPattern).getNextOccurrence(
        currentDate);
    }

    // save data to DB
    // BEGIN, CR00060544, POH
    // Call the EvidenceController object and insert evidence

    // Evidence descriptor details
    evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.participantID = employerDtls.concernRoleID;
    evidenceDescriptorInsertDtls.evidenceType = CASEEVIDENCE.EMPLOYER;
    evidenceDescriptorInsertDtls.receivedDate = curam.util.type.Date.getCurrentDate();

    // Evidence Interface details
    eiEvidenceInsertDtls = new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.descriptor.participantID = employerDtls.concernRoleID;
    eiEvidenceInsertDtls.evidenceObject = employerDtls;

    // Insert the evidence
    evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    // END, CR00060544

    // Generate the remaining Unique IDs required
    // generate unique id for the alternate ID
    concernRoleAlternateIDID = uniqueIDObj.getNextID();

    // generate unique id for the Business Address
    concernRoleAddressBID = uniqueIDObj.getNextID();

    // generate unique id for registered concern role address
    concernRoleAddressRID = uniqueIDObj.getNextID();

    if (concernRoleAlternateIDDtls == null) {
      concernRoleAlternateIDDtls = new ConcernRoleAlternateIDDtls();
    }

    // insert concern role alternate id
    // fill in the data structure
    concernRoleAlternateIDDtls.concernRoleAlternateID = concernRoleAlternateIDID;
    concernRoleAlternateIDDtls.concernRoleID = concernRoleID;
    concernRoleAlternateIDDtls.alternateID = alternateEmployerReferenceNo;

    // BEGIN, CR00021614, NVR
    if (bAlternateEmployerRefNo) {
      concernRoleAlternateIDDtls.typeCode = CONCERNROLEALTERNATEID.EMPLOYER_REFERENCE_NUMBER;
    } else {
      concernRoleAlternateIDDtls.typeCode = CONCERNROLEALTERNATEID.REFERENCE_NUMBER;
    }
    // concernRoleAlternateIDDtls.typeCode = CONCERNROLEALTERNATEID.INSURANCENUMBER;
    // END, CR00021614

    concernRoleAlternateIDDtls.startDate = details.registrationDate;
    concernRoleAlternateIDDtls.endDate = curam.util.type.Date.kZeroDate;
    concernRoleAlternateIDDtls.statusCode = RECORDSTATUS.NORMAL;
    // BEGIN, CR00049218, GM
    concernRoleAlternateIDDtls.comments = CuramConst.gkEmpty;
    // END, CR00049218

    // BEGIN, CR00059688, POH
    // Call the EvidenceController object and insert evidence

    // Evidence descriptor details
    evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.participantID = concernRoleAlternateIDDtls.concernRoleID;
    evidenceDescriptorInsertDtls.evidenceType = CASEEVIDENCE.CONCERNROLEALTERNATEID;
    evidenceDescriptorInsertDtls.receivedDate = curam.util.type.Date.getCurrentDate();

    // Evidence Interface details
    eiEvidenceInsertDtls = new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.descriptor.participantID = concernRoleAlternateIDDtls.concernRoleID;
    eiEvidenceInsertDtls.evidenceObject = concernRoleAlternateIDDtls;

    // Insert the evidence
    evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    // END,  CR00059688

    // insert concern role address (business)
    // fill in the data structure
    concernRoleAddressBDtls.concernRoleAddressID = concernRoleAddressBID;
    concernRoleAddressBDtls.concernRoleID = concernRoleID;
    concernRoleAddressBDtls.addressID = primaryAddressID;
    concernRoleAddressBDtls.typeCode = CONCERNROLEADDRESSTYPE.BUSINESS;
    concernRoleAddressBDtls.startDate = details.registrationDate;
    concernRoleAddressBDtls.endDate = curam.util.type.Date.kZeroDate;
    concernRoleAddressBDtls.statusCode = RECORDSTATUS.NORMAL;

    // save record to db
    // BEGIN, CR00061099, POH
    // Call the EvidenceController object and insert evidence
    // Evidence descriptor details
    evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.participantID = concernRoleAddressBDtls.concernRoleID;
    evidenceDescriptorInsertDtls.evidenceType = CASEEVIDENCE.CONCERNROLEADDRESS;
    evidenceDescriptorInsertDtls.receivedDate = curam.util.type.Date.getCurrentDate();

    // Evidence Interface details
    eiEvidenceInsertDtls = new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.descriptor.participantID = concernRoleAddressBDtls.concernRoleID;
    eiEvidenceInsertDtls.evidenceObject = concernRoleAddressBDtls;

    // Insert the evidence
    evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    // END,  CR00061099


    addressDtls.addressData = details.registeredAddressData;
    // save record to DB
    addressObj.insert(addressDtls);

    addressRID = addressDtls.addressID;

    // insert concern role address (registered)
    // fill in the data structure
    concernRoleAddressRDtls.concernRoleAddressID = concernRoleAddressRID;
    concernRoleAddressRDtls.concernRoleID = concernRoleID;
    concernRoleAddressRDtls.addressID = addressRID;
    concernRoleAddressRDtls.typeCode = CONCERNROLEADDRESSTYPE.REGISTERED;
    concernRoleAddressRDtls.startDate = details.registrationDate;
    concernRoleAddressRDtls.endDate = curam.util.type.Date.kZeroDate;
    concernRoleAddressRDtls.statusCode = RECORDSTATUS.NORMAL;

    // save record to DB
    // BEGIN, CR00061099, POH
    // Call the EvidenceController object and insert evidence
    // Evidence descriptor details
    evidenceDescriptorInsertDtls = new EvidenceDescriptorInsertDtls();

    evidenceDescriptorInsertDtls.participantID = concernRoleAddressRDtls.concernRoleID;
    evidenceDescriptorInsertDtls.evidenceType = CASEEVIDENCE.CONCERNROLEADDRESS;
    evidenceDescriptorInsertDtls.receivedDate = curam.util.type.Date.getCurrentDate();

    // Evidence Interface details
    eiEvidenceInsertDtls = new EIEvidenceInsertDtls();

    eiEvidenceInsertDtls.descriptor.assign(evidenceDescriptorInsertDtls);
    eiEvidenceInsertDtls.descriptor.participantID = concernRoleAddressRDtls.concernRoleID;
    eiEvidenceInsertDtls.evidenceObject = concernRoleAddressRDtls;

    // Insert the evidence
    evidenceControllerObj.insertEvidence(eiEvidenceInsertDtls);

    // END,  CR00061099


    // insert the concern Role phone number details
    if (phoneDetailsSpecified) {

      // fill in the data structure
      concernRolePhoneNumberDtls.typeCode = details.phoneType;
      concernRolePhoneNumberDtls.concernRolePhoneNumberID = concernRolePhoneNumberID;
      concernRolePhoneNumberDtls.concernRoleID = concernRoleID;
      concernRolePhoneNumberDtls.phoneNumberID = phoneNumberID;
      concernRolePhoneNumberDtls.startDate = details.registrationDate;
      concernRolePhoneNumberDtls.endDate = curam.util.type.Date.kZeroDate;

      // save concernRolePhoneNumber to database
      concernRolePhoneNumberObj.insert(concernRolePhoneNumberDtls);
    }

    // insert communication exception
    // if any exception details are entered - validate
    if ((details.commExceptionMethodCode.length() > 0)
      || (details.commExceptionReasonCode.length() > 0)
      || (!details.commExceptionFromDate.isZero())
      || (!details.commExceptionToDate.isZero())) {

      // communication exception maintenance variables
      curam.core.intf.MaintainConcernRoleCommException maintainConcernRoleCommExceptionObj = curam.core.fact.MaintainConcernRoleCommExceptionFactory.newInstance();
      MaintainCommExceptionKey maintainCommExceptionKey = new MaintainCommExceptionKey();
      CommExceptionDetails commExceptionDetails = new CommExceptionDetails();

      // set up communication exception key and details
      maintainCommExceptionKey.concernRoleID = concernRoleID;

      commExceptionDetails.concernRoleID = concernRoleID;
      commExceptionDetails.typeCode = details.commExceptionMethodCode;
      commExceptionDetails.reasonCode = details.commExceptionReasonCode;
      commExceptionDetails.fromDate = details.commExceptionFromDate;
      commExceptionDetails.toDate = details.commExceptionToDate;

      // create communication exception
      maintainConcernRoleCommExceptionObj.createCommException(
        maintainCommExceptionKey, commExceptionDetails);
    }

    // if any of contact details are supplied then register a contact
    boolean fContactDetails;

    fContactDetails = ((details.contactTitle.length() > 0)
      || (details.contactName.length() > 0)
      || (details.contactPhoneCountryCode.length() > 0)
      || (details.contactPhoneAreaCode.length() > 0)
      || (details.contactPhoneNumber.length() > 0)
      || (details.contactPhoneExtension.length() > 0)
      || (details.contactEmailType.length() > 0)
      || (details.contactEmailAddress.length() > 0));

    if (fContactDetails) {

      if (details.contactTitle.length() == 0
        || details.contactName.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOMAINTAINCONTACTS.ERR_CONTACTS_XFV_NAME_TYPE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 5);

      }

      // ConcernRoleContact manipulation variables
      curam.core.intf.ConcernRoleContact concernRoleContactObj = curam.core.fact.ConcernRoleContactFactory.newInstance();
      ConcernRoleContactDtls concernRoleContactDtls = new ConcernRoleContactDtls();

      // Representative maintenance object
      // BEGIN, CR00155209, AK
      Representative representativeObj = RepresentativeFactory.newInstance();
      // END, CR00155209
      // Struct passed to Representative::registerRepresentative
      RepresentativeRegistrationDetails representativeRegistrationDetails = new RepresentativeRegistrationDetails();

      representativeRegistrationDetails.representativeDtls.representativeName = details.contactName;
      representativeRegistrationDetails.representativeDtls.representativeType = REPRESENTATIVETYPE.CONTACT;

      representativeRegistrationDetails.representativeRegistrationDetails.addressData = details.businessAddressData;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = details.contactPhoneCountryCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = details.contactPhoneAreaCode;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = details.contactPhoneNumber;
      representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension = details.contactPhoneExtension;
      representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = details.registrationDate;
      representativeRegistrationDetails.representativeRegistrationDetails.sensitivity = SENSITIVITY.DEFAULTCODE;

      // Call registerRepresentative
      // BEGIN, CR00095820, SD
      representativeObj.registerRepresentativeForParticipants(
        representativeRegistrationDetails, concernRoleAlternateIDDtls.typeCode);
      // END, CR00095820

      // generate unique ID for contact details
      concernRoleContactDtls.contactID = uniqueIDObj.getNextID();

      // insert concern role information
      concernRoleContactDtls.contactConRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
      concernRoleContactDtls.concernRoleID = concernRoleID;
      concernRoleContactDtls.contactTypeCode = details.contactTitle;
      concernRoleContactDtls.name = details.contactName;
      // BEGIN, CR00294967, MV
      concernRoleContactDtls.statusCode = RECORDSTATUS.NORMAL;
      // END, CR00294967
      // BEGIN, CR00108971 - PA
      concernRoleContactDtls.startDate = details.registrationDate;
      // END, CR00108971 - PA

      // insert concernRoleContact
      concernRoleContactObj.insert(concernRoleContactDtls);
    }

    if (!details.tradingDate.isZero()) {

      maintainTradingStatusKey.concernRoleID = employerDtls.concernRoleID;

      tradingStatusDetails.startDate = details.tradingDate;
      tradingStatusDetails.tradingStatusCode = TRADINGSTATUS.DEFAULTCODE;

      maintainEmployerTradingStatusObj.createTradingStatus(
        maintainTradingStatusKey, tradingStatusDetails);
    }

    registrationmIDDetailsRet.alternateID = alternateEmployerReferenceNo;
    registrationmIDDetailsRet.concernRoleID = concernRoleID;

    // set the key
    maintainAdminConcernRoleKey.concernRoleID = concernRoleID;

    // BEGIN, CR00176534, RPB
    AdminConcernRoleDetails adminConcernRoleDetails = new AdminConcernRoleDetails();

    adminConcernRoleDetails.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    adminConcernRoleDetails.startDate = currentDate;
    adminConcernRoleDetails.orgObjectType = ORGOBJECTTYPEEntry.USER.getCode();
    maintainAdminConcernRoleObj.createConcernRoleOwner(
      maintainAdminConcernRoleKey, adminConcernRoleDetails);
    // END, CR00176534

    return registrationmIDDetailsRet;
  }

}
