/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2006, 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import org.jdom.Element;

import curam.core.facade.fact.RulesEditorFactory;
import curam.core.facade.intf.RulesEditor;
import curam.core.facade.struct.ObjectiveGroupSummaryDetails;
import curam.core.facade.struct.ObjectiveListGroupSummaryDtls;
import curam.core.facade.struct.ObjectiveSummaryDetails;
import curam.core.facade.struct.ReadDataAssignmentDetails;
import curam.core.facade.struct.ReadXMLStringDetails;
import curam.core.facade.struct.RuleGroupSummaryDetails;
import curam.core.facade.struct.RuleSetIDAndNameDtls;
import curam.core.facade.struct.RuleSetIDStruct;
import curam.core.facade.struct.RuleSetNodeKey;
import curam.core.facade.struct.RuleSetType;
import curam.core.facade.struct.RuleSummaryDetail;
import curam.core.facade.struct.RulesListGroupSummaryDetails;
import curam.core.facade.struct.SubRuleSetSummaryDtls;
import curam.core.sl.infrastructure.impl.XmlTreeConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class builds the SubRuleset tree in XML format.
 *
 */
public abstract class SubRuleSetTreeView extends curam.core.facade.base.SubRuleSetTreeView {

  /**
   * Fetches the SubRuleSet data and builds tree in XML format
   *
   * @param ruleSetIDStruct identifies the RuleSetID
   *
   * @return  XML Data.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  public ReadXMLStringDetails buildSubRuleSetTree(RuleSetIDStruct ruleSetIDStruct)
    throws AppException, InformationalException {

    curam.core.facade.struct.ReadXMLStringDetails readXMLDetails =
      new curam.core.facade.struct.ReadXMLStringDetails();

    RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    RuleSetType ruleSetType = new RuleSetType();

    ruleSetType.ruleSetType = XmlTreeConst.kSubRuleSetTreeViewName;

    readXMLDetails = rulesEditor.createRulesTree(ruleSetIDStruct, ruleSetType);

    return readXMLDetails;

  }

  // ___________________________________________________________________________
  /**
   * Creates all NodeTypes allowed in the Rules tree
   *
   * @return All Rules NodeTypes
   */
  protected static Element createNodeTypesXML() {
    // BEGIN, CR00023323, SK
    Element nodeTypesElement =
      new Element(XmlTreeConst.kNodeTypes, XmlTreeConst.kNamespace);
    Element nodeTypeElement =
      new Element(XmlTreeConst.kNodeType, XmlTreeConst.kNamespace);

    nodeTypesElement.addContent(nodeTypeElement);

    // Build Sub Rule Set node type
    nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kSubRuleSet);
    Element actionsElement =
      new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);

    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    Element actionElement =
      new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);

    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    Element paramElement =
      new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);

    // Build Rule Group node type
    nodeTypeElement =
      new Element(XmlTreeConst.kNodeType, XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleGroup);
    actionsElement =
      new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    Element paramElementforNodeID1 =
      new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID1);
    paramElementforNodeID1.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Objective Group node type
    nodeTypeElement =
      new Element(XmlTreeConst.kNodeType, XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kObjectiveGroup);
    actionsElement =
      new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    Element paramElementforNodeID2 =
      new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID2);
    paramElementforNodeID2.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Objective node type
    nodeTypeElement =
      new Element(XmlTreeConst.kNodeType, XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kObjective);
    actionsElement =
      new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    Element paramElementforNodeID3 =
      new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID3);
    paramElementforNodeID3.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Objective List Group node type
    nodeTypeElement =
      new Element(XmlTreeConst.kNodeType, XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kObjectiveListGroup);
    actionsElement =
      new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    Element paramElementforNodeID4 =
      new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID4);
    paramElementforNodeID4.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Rule List Group node type
    nodeTypeElement =
      new Element(XmlTreeConst.kNodeType, XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kRuleListGroup);
    actionsElement =
      new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    Element paramElementforNodeID5 =
      new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID5);
    paramElementforNodeID5.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Rule node type
    nodeTypeElement =
      new Element(XmlTreeConst.kNodeType, XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRule);
    actionsElement =
      new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    Element paramElementforNodeID6 =
      new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID6);
    paramElementforNodeID6.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build Data Item Assignment node type
    nodeTypeElement =
      new Element(XmlTreeConst.kNodeType, XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kDataItemAssignment);
    actionsElement =
      new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    Element paramElementforNodeID7 =
      new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID7);
    paramElementforNodeID7.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);

    // Build SubRuleSet Link node type
    nodeTypeElement =
      new Element(XmlTreeConst.kNodeType, XmlTreeConst.kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kSubRuleSetLink);
    actionsElement =
      new Element(XmlTreeConst.kActions, XmlTreeConst.kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(XmlTreeConst.kDefault, XmlTreeConst.kView);
    actionElement = new Element(XmlTreeConst.kAction, XmlTreeConst.kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kView);
    paramElement = new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID);
    Element paramElementforNodeID8 =
      new Element(XmlTreeConst.kKey, XmlTreeConst.kNamespace);

    actionElement.addContent(paramElementforNodeID8);
    paramElementforNodeID8.setAttribute(XmlTreeConst.kName,
      XmlTreeConst.kNodeID);
    // END, CR00023323

    return nodeTypesElement;

  }

  // ___________________________________________________________________________
  /**
   * Constructs SubRuleSet Node
   *
   * @param ruleSetIDStruct identifies SubRuleSet.
   *
   * @return NodeSetElement with all nodes.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createSubRuleSetXML(RuleSetIDStruct ruleSetIDStruct)
    throws AppException, InformationalException {
    // END, CR00198672
    // SubRuleSetSummary variables
    curam.core.facade.struct.SubRuleSetSummaryDtls subRuleSetSummaryDetails =
      new SubRuleSetSummaryDtls();
    RulesEditor rulesEditor = RulesEditorFactory.newInstance();
    RuleSetNodeKey ruleSetNodeKey = new RuleSetNodeKey();

    String ruleSetID = ruleSetIDStruct.ruleSetID;
    TreeXMLNodeDetails treeXMLNodeDetails =
      TreeXMLNodeCache.getInstance().getTreeXMLNodeDetails(ruleSetID);

    // Get Sub Rule Set details
    subRuleSetSummaryDetails =
      rulesEditor.readSubRuleSetSummary(ruleSetIDStruct);
    // BEGIN, CR00023323, SK
    Element nodeSetElement =
      new Element(XmlTreeConst.kNodeSet, XmlTreeConst.kNamespace);
    String subRuleSetName = subRuleSetSummaryDetails.subRuleSetDtls.ruleSetName;
    String subRuleSetNodeID = subRuleSetSummaryDetails.subRuleSetDtls.ruleSetID;

    Element subRuleSetNode =
      new Element(XmlTreeConst.kNode, XmlTreeConst.kNamespace);

    nodeSetElement.addContent(subRuleSetNode);

    subRuleSetNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + subRuleSetNodeID);

    String stStartNodeId =
      XmlTreeConst.kRuleIDPrefix + treeXMLNodeDetails.getStLastAccessedNodeId();

    nodeSetElement.setAttribute(XmlTreeConst.kStartNode, stStartNodeId);

    subRuleSetNode.setAttribute(XmlTreeConst.kType, XmlTreeConst.kSubRuleSet);

    Element subRuleSetTitleElement =
      new Element(XmlTreeConst.kTitle, XmlTreeConst.kNamespace);

    subRuleSetNode.addContent(subRuleSetTitleElement);
    subRuleSetTitleElement.setText(subRuleSetName);

    Element subRuleSetParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    subRuleSetNode.addContent(subRuleSetParamValueElement);
    subRuleSetParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      subRuleSetNodeID);
    // END, CR00023323
    for (int i = 0; i
      < subRuleSetSummaryDetails.childItemDtls.nodeDetails.size(); i++) {

      ruleSetNodeKey.ruleSetID =
        subRuleSetSummaryDetails.subRuleSetDtls.ruleSetID;
      ruleSetNodeKey.nodeID =
        subRuleSetSummaryDetails.childItemDtls.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      // create different nodes depending on the node type
      if (subRuleSetSummaryDetails.childItemDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // Rule Group
        subRuleSetNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      } else if (subRuleSetSummaryDetails.childItemDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOG)) { // Objective Group
        subRuleSetNode.addContent(createObjectiveGroupXML(ruleSetNodeKey));
      } else if (subRuleSetSummaryDetails.childItemDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOLG)) { // Objective List Group
        // END, CR00023323
        subRuleSetNode.addContent(createObjectiveListGroupXML(ruleSetNodeKey));
      } else { // RuleListGroup
        subRuleSetNode.addContent(createRuleListGroupXML(ruleSetNodeKey));
      }
    }

    return nodeSetElement;
  }

  // ___________________________________________________________________________
  /**
   * Constructs ObjectiveGroup Node
   *
   * @param ruleSetNodeKey identifies the Objective Group in the Rule Set.
   *
   * @return ObjectiveGroupNodeElementDetails.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createObjectiveGroupXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {
    // END, CR00198672
    // Objective Group Summary variables
    ObjectiveGroupSummaryDetails objectiveGroupSummary =
      new ObjectiveGroupSummaryDetails();
    RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // read objective group details
    objectiveGroupSummary =
      rulesEditor.readObjectiveGroupSummary(ruleSetNodeKey);
    String objectiveGroupName = objectiveGroupSummary.objectiveGroupDtls.name;

    String objectiveGroupNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    Element objectiveGroupNode =
      new Element(XmlTreeConst.kNode, XmlTreeConst.kNamespace);

    objectiveGroupNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + objectiveGroupNodeID);
    objectiveGroupNode.setAttribute(XmlTreeConst.kType,
      XmlTreeConst.kObjectiveGroup);

    Element objectiveGroupTitleElement =
      new Element(XmlTreeConst.kTitle, XmlTreeConst.kNamespace);

    objectiveGroupNode.addContent(objectiveGroupTitleElement);
    objectiveGroupTitleElement.setText(objectiveGroupName);

    Element ruleSetIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveGroupNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    Element nodeIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveGroupNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      objectiveGroupNodeID);
    // END, CR00023323
    for (int i = 0; i < objectiveGroupSummary.childItemList.nodeDetails.size(); i++) {

      ruleSetNodeKey.nodeID =
        objectiveGroupSummary.childItemList.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      if (objectiveGroupSummary.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // RuleGroup
        objectiveGroupNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      } else if (objectiveGroupSummary.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOG)) { // ObjectiveGroup
        objectiveGroupNode.addContent(createObjectiveGroupXML(ruleSetNodeKey));
      } else if (objectiveGroupSummary.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOLG)) { // ObjectiveListGroup
        objectiveGroupNode.addContent(
          createObjectiveListGroupXML(ruleSetNodeKey));
      } else if (objectiveGroupSummary.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRLG)) { // RuleListGroup
        objectiveGroupNode.addContent(createRuleListGroupXML(ruleSetNodeKey));
      } else if (objectiveGroupSummary.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kSRSL)) { // SubRuleSetLink
        // END, CR00023323
        objectiveGroupNode.addContent(createSubRuleSetLinkXML(ruleSetNodeKey));
      } else {
        objectiveGroupNode.addContent(createObjectivesXML(ruleSetNodeKey));
      }

    }

    return objectiveGroupNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs ObjectiveListGroup Node
   *
   * @param ruleSetNodeKey identifies the Objective List Group in the RuleSet
   *
   * @return ObjectiveListGroupNodeElementDetails.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createObjectiveListGroupXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {
    // END, CR00198672
    ObjectiveListGroupSummaryDtls objectiveListGroupSummaryDtls =
      new ObjectiveListGroupSummaryDtls();
    RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // Read Objective List Group details
    objectiveListGroupSummaryDtls =
      rulesEditor.readObjectiveListGroupSummary(ruleSetNodeKey);

    String objectiveListGroupName =
      objectiveListGroupSummaryDtls.summaryDtls.name;
    String objectiveListGroupNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    Element objectiveListGroupNode =
      new Element(XmlTreeConst.kNode, XmlTreeConst.kNamespace);

    objectiveListGroupNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + objectiveListGroupNodeID);
    objectiveListGroupNode.setAttribute(XmlTreeConst.kType,
      XmlTreeConst.kObjectiveListGroup);

    Element objectiveListGroupTitleElement =
      new Element(XmlTreeConst.kTitle, XmlTreeConst.kNamespace);

    objectiveListGroupNode.addContent(objectiveListGroupTitleElement);
    objectiveListGroupTitleElement.setText(objectiveListGroupName);

    Element ruleSetIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveListGroupNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    Element nodeIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveListGroupNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      objectiveListGroupNodeID);
    // END, CR00023323
    for (int i = 0; i
      < objectiveListGroupSummaryDtls.nodeItems.nodeDetails.size(); i++) {

      ruleSetNodeKey.ruleSetID =
        objectiveListGroupSummaryDtls.summaryDtls.ruleSetID;
      ruleSetNodeKey.nodeID =
        objectiveListGroupSummaryDtls.nodeItems.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      if (objectiveListGroupSummaryDtls.nodeItems.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // RuleGroup
        objectiveListGroupNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      } else if (objectiveListGroupSummaryDtls.nodeItems.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOG)) { // Objective Group
        objectiveListGroupNode.addContent(
          createObjectiveGroupXML(ruleSetNodeKey));
      } else if (objectiveListGroupSummaryDtls.nodeItems.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kOLG)) { // Objective List Group
        objectiveListGroupNode.addContent(
          createObjectiveListGroupXML(ruleSetNodeKey));
      } else if (objectiveListGroupSummaryDtls.nodeItems.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRLG)) { // RuleListGroup
        objectiveListGroupNode.addContent(
          createRuleListGroupXML(ruleSetNodeKey));
      } else if (objectiveListGroupSummaryDtls.nodeItems.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kSRSL)) { // SubRuleSetLink
        // END, CR00023323
        objectiveListGroupNode.addContent(
          createSubRuleSetLinkXML(ruleSetNodeKey));
      } else {
        objectiveListGroupNode.addContent(createObjectivesXML(ruleSetNodeKey));
      }

    }
    return objectiveListGroupNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs RuleListGroup Node
   *
   * @param ruleSetNodeKey identifies the Rule List Group in the RuleSet.
   *
   * @return RuleListGroupNodeElementDetails.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createRuleListGroupXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {
    // END, CR00198672
    RulesListGroupSummaryDetails rulesListGroupSummaryDetails =
      new RulesListGroupSummaryDetails();
    RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // Read Rule List Group details
    rulesListGroupSummaryDetails =
      rulesEditor.readRuleListGroupSummary(ruleSetNodeKey);

    String rulesListGroupName = rulesListGroupSummaryDetails.summaryDtls.name;
    String ruleListGroupNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    Element ruleListGroupNode =
      new Element(XmlTreeConst.kNode, XmlTreeConst.kNamespace);

    ruleListGroupNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + ruleListGroupNodeID);
    ruleListGroupNode.setAttribute(XmlTreeConst.kType,
      XmlTreeConst.kRuleListGroup);

    Element ruleListGroupTitleElement =
      new Element(XmlTreeConst.kTitle, XmlTreeConst.kNamespace);

    ruleListGroupNode.addContent(ruleListGroupTitleElement);
    ruleListGroupTitleElement.setText(rulesListGroupName);
    Element ruleSetIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleListGroupNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    Element nodeIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleListGroupNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      ruleListGroupNodeID);
    // END, CR00023323
    for (int i = 0; i
      < rulesListGroupSummaryDetails.childItemList.nodeDetails.size(); i++) {

      ruleSetNodeKey.ruleSetID =
        rulesListGroupSummaryDetails.summaryDtls.ruleSetID;
      ruleSetNodeKey.nodeID =
        rulesListGroupSummaryDetails.childItemList.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      if (rulesListGroupSummaryDetails.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // RuleGroup
        ruleListGroupNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      } else if (rulesListGroupSummaryDetails.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kR)) { // Rule
        ruleListGroupNode.addContent(createRuleXML(ruleSetNodeKey));
      } else if (rulesListGroupSummaryDetails.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRLG)) { // RuleListGroup
        ruleListGroupNode.addContent(createRuleListGroupXML(ruleSetNodeKey));
      } else if (rulesListGroupSummaryDetails.childItemList.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kSRSL)) { // SubRuleSetLink
        // END, CR00023323
        ruleListGroupNode.addContent(createSubRuleSetLinkXML(ruleSetNodeKey));
      } else {
        ruleListGroupNode.addContent(
          createDataItemAssignmentXML(ruleSetNodeKey));
      }

    }

    return ruleListGroupNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs RuleGroup Node
   *
   * @param ruleSetNodeKey RuleSetID.
   *
   * @return RuleGroupNodeElementDetails.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createRuleGroupXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {
    // END, CR00198672
    RuleGroupSummaryDetails ruleGroupSummaryDetails =
      new RuleGroupSummaryDetails();
    RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // Reads Rule Group details
    ruleGroupSummaryDetails = rulesEditor.readRuleGroupSummary(ruleSetNodeKey);

    String ruleGroupName = ruleGroupSummaryDetails.ruleGroupDtls.name;

    String ruleGroupNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    Element ruleGroupNode =
      new Element(XmlTreeConst.kNode, XmlTreeConst.kNamespace);

    ruleGroupNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + ruleGroupNodeID);
    ruleGroupNode.setAttribute(XmlTreeConst.kType, XmlTreeConst.kRuleGroup);
    Element ruleGroupTitleElement =
      new Element(XmlTreeConst.kTitle, XmlTreeConst.kNamespace);

    ruleGroupNode.addContent(ruleGroupTitleElement);
    ruleGroupTitleElement.setText(ruleGroupName);

    Element ruleSetIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleGroupNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    Element nodeIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleGroupNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      ruleGroupNodeID);
    // END, CR00023323
    for (int i = 0; i
      < ruleGroupSummaryDetails.childItemDtls.nodeDetails.size(); i++) {

      ruleSetNodeKey.ruleSetID =
        ruleGroupSummaryDetails.ruleGroupDtls.ruleSetID;
      ruleSetNodeKey.nodeID =
        ruleGroupSummaryDetails.childItemDtls.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      if (ruleGroupSummaryDetails.childItemDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // RuleGroup
        ruleGroupNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      } else if (ruleGroupSummaryDetails.childItemDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kR)) { // Rule
        ruleGroupNode.addContent(createRuleXML(ruleSetNodeKey));
      } else if (ruleGroupSummaryDetails.childItemDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRLG)) { // RuleListGroup
        ruleGroupNode.addContent(createRuleListGroupXML(ruleSetNodeKey));
      } else if (ruleGroupSummaryDetails.childItemDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kSRSL)) { // SubRuleSetLink
        // END, CR00023323
        ruleGroupNode.addContent(createSubRuleSetLinkXML(ruleSetNodeKey));
      } else {
        ruleGroupNode.addContent(createDataItemAssignmentXML(ruleSetNodeKey));
      }

    }

    return ruleGroupNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs Objective Node
   *
   * @param ruleSetNodeKey identifies the Objectives inside the RuleSet
   *
   * @return ObjectiveNodeElementDetails.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createObjectivesXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {
    // END, CR00198672
    ObjectiveSummaryDetails objectiveSummaryDetails =
      new ObjectiveSummaryDetails();
    RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // Reads objective details
    objectiveSummaryDetails = rulesEditor.readObjectiveSummary(ruleSetNodeKey);
    String objectiveNodeID = Long.toString(ruleSetNodeKey.nodeID);
    String objectiveName = objectiveSummaryDetails.objectiveDtls.name;
    // BEGIN, CR00023323, SK
    Element objectiveNode =
      new Element(XmlTreeConst.kNode, XmlTreeConst.kNamespace);

    objectiveNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + objectiveNodeID);
    objectiveNode.setAttribute(XmlTreeConst.kType, XmlTreeConst.kObjective);

    Element objectiveTitleElement =
      new Element(XmlTreeConst.kTitle, XmlTreeConst.kNamespace);

    objectiveNode.addContent(objectiveTitleElement);
    objectiveTitleElement.setText(objectiveName);

    Element ruleSetIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    Element nodeIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    objectiveNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      objectiveNodeID);
    // END, CR00023323
    for (int i = 0; i
      < objectiveSummaryDetails.childItemDtls.childDtls.nodeDetails.size(); i++) {

      ruleSetNodeKey.nodeID =
        objectiveSummaryDetails.childItemDtls.childDtls.nodeDetails.item(i).nodeID;
      // BEGIN, CR00023323, SK
      if (objectiveSummaryDetails.childItemDtls.childDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRG)) { // RuleGroup
        objectiveNode.addContent(createRuleGroupXML(ruleSetNodeKey));
      }
      if (objectiveSummaryDetails.childItemDtls.childDtls.nodeDetails.item(i).nodeType.equalsIgnoreCase(
        XmlTreeConst.kRLG)) { // RuleListGroup
        objectiveNode.addContent(createRuleListGroupXML(ruleSetNodeKey));
      }
      // END, CR00023323

    }

    return objectiveNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs Rule Node
   *
   * @param ruleSetNodeKey identifies the Rule inside the RuleSet.
   *
   * @return RuleNodeElementDetails.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createRuleXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {
    // END, CR00198672
    RuleSummaryDetail ruleSummaryDetail = new RuleSummaryDetail();
    RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    // Reads Rule details
    ruleSummaryDetail = rulesEditor.readRuleSummary(ruleSetNodeKey);

    String ruleName = ruleSummaryDetail.ruleDataDtls.ruleName;
    String ruleNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    Element ruleNode = new Element(XmlTreeConst.kNode, XmlTreeConst.kNamespace);

    ruleNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + ruleNodeID);
    ruleNode.setAttribute(XmlTreeConst.kType, XmlTreeConst.kRule);

    Element ruleTitleElement =
      new Element(XmlTreeConst.kTitle, XmlTreeConst.kNamespace);

    ruleNode.addContent(ruleTitleElement);
    ruleTitleElement.setText(ruleName);

    Element ruleSetIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    Element nodeIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    ruleNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      ruleNodeID);
    // END, CR00023323
    return ruleNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs DataItemAssignment Node
   *
   * @param ruleSetNodeKey identifies the Data Item Assignment inside the RuleSet.
   *
   * @return DataItemAssignmentNodeElementDetails.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createDataItemAssignmentXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {
    // END, CR00198672
    ReadDataAssignmentDetails readDataAssignmentDetails =
      new ReadDataAssignmentDetails();
    RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    readDataAssignmentDetails = rulesEditor.readDataAssignment(ruleSetNodeKey);
    String dataAssignmentName = readDataAssignmentDetails.formulaString;

    String dataItemNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    Element dataItemAssignmentNode =
      new Element(XmlTreeConst.kNode, XmlTreeConst.kNamespace);

    dataItemAssignmentNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + dataItemNodeID);
    dataItemAssignmentNode.setAttribute(XmlTreeConst.kType,
      XmlTreeConst.kDataItemAssignment);

    Element dataItemTitleElement =
      new Element(XmlTreeConst.kTitle, XmlTreeConst.kNamespace);

    dataItemAssignmentNode.addContent(dataItemTitleElement);
    dataItemTitleElement.setText(dataAssignmentName);

    Element ruleSetIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    dataItemAssignmentNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    Element nodeIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    dataItemAssignmentNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      dataItemNodeID);
    // END, CR00023323
    return dataItemAssignmentNode;
  }

  // ___________________________________________________________________________
  /**
   * Constructs SubRuleSetLink Node
   *
   * @param ruleSetNodeKey identifies the SubRuleSetLink for the RuleSet.
   *
   * @return SubRuleSetLinkNodeElementDetails.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createSubRuleSetLinkXML(RuleSetNodeKey ruleSetNodeKey)
    throws AppException, InformationalException {
    // END, CR00198672
    RuleSetIDAndNameDtls ruleSetIDAndNameDtls = new RuleSetIDAndNameDtls();
    RulesEditor rulesEditor = RulesEditorFactory.newInstance();

    ruleSetIDAndNameDtls = rulesEditor.viewSubRuleSetLink(ruleSetNodeKey);
    String subRuleSetLinkName = ruleSetIDAndNameDtls.ruleSetName;

    String subRuleSetLinkNodeID = Long.toString(ruleSetNodeKey.nodeID);
    // BEGIN, CR00023323, SK
    Element subRuleSetLinkNode =
      new Element(XmlTreeConst.kNode, XmlTreeConst.kNamespace);

    subRuleSetLinkNode.setAttribute(XmlTreeConst.kID,
      XmlTreeConst.kRuleIDPrefix + subRuleSetLinkNodeID);
    subRuleSetLinkNode.setAttribute(XmlTreeConst.kType,
      XmlTreeConst.kSubRuleSetLink);

    Element subRuleSetLinkTitleElement =
      new Element(XmlTreeConst.kTitle, XmlTreeConst.kNamespace);

    subRuleSetLinkNode.addContent(subRuleSetLinkTitleElement);
    subRuleSetLinkTitleElement.setText(subRuleSetLinkName);

    Element ruleSetIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    subRuleSetLinkNode.addContent(ruleSetIDParamValueElement);
    ruleSetIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kRuleSetID).addContent(
      ruleSetNodeKey.ruleSetID);

    Element nodeIDParamValueElement =
      new Element(XmlTreeConst.kParamValue, XmlTreeConst.kNamespace);

    subRuleSetLinkNode.addContent(nodeIDParamValueElement);
    nodeIDParamValueElement.setAttribute(XmlTreeConst.kName, XmlTreeConst.kNodeID).addContent(
      subRuleSetLinkNodeID);
    // END, CR00023323
    return subRuleSetLinkNode;
  }

}
