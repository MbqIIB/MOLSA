/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * @see curam.core.intf.ClearCachedRecords
 */
public abstract class ClearCachedRecords extends curam.core.base.ClearCachedRecords {

  /**
   * {@inheritDoc}
   */
  @Override
  public void clearAllCaches() throws AppException, InformationalException {

    // cachedCaseEvidence manipulation variable
    curam.core.intf.CachedCaseEvidence cachedCaseEvidenceObj = curam.core.fact.CachedCaseEvidenceFactory.newInstance();

    // cachedCaseEvidence manipulation variable
    curam.core.intf.CachedCaseHeader cachedCaseHeaderObj = curam.core.fact.CachedCaseHeaderFactory.newInstance();

    // cachedCaseEvidence manipulation variable
    curam.core.intf.CachedCaseStatus cachedCaseStatusObj = curam.core.fact.CachedCaseStatusFactory.newInstance();

    // cachedCaseEvidence manipulation variable
    curam.core.intf.CachedPerson cachedPersonObj = curam.core.fact.CachedPersonFactory.newInstance();

    // cachedCaseEvidence manipulation variable
    curam.core.intf.CachedProduct cachedProductObj = curam.core.fact.CachedProductFactory.newInstance();

    // cachedCaseEvidence manipulation variable
    curam.core.intf.CachedProductDelivery cachedProductDeliveryObj = curam.core.fact.CachedProductDeliveryFactory.newInstance();

    // cachedCaseEvidence manipulation variable
    curam.core.intf.CachedProductDeliveryCertDiary cachedProductDeliveryCertDiaryObj = curam.core.fact.CachedProductDeliveryCertDiaryFactory.newInstance();

    // cachedCaseEvidence manipulation variable
    curam.core.intf.CachedProductRulesLink cachedProductRulesLinkObj = curam.core.fact.CachedProductRulesLinkFactory.newInstance();

    // cachedCaseEvidence manipulation variable
    curam.core.intf.CachedProviderLocation cachedProviderLocationObj = curam.core.fact.CachedProviderLocationFactory.newInstance();

    // cachedCaseEvidence manipulation variable
    curam.core.intf.CachedConcernRoleRelationship cachedConcernRoleRelationshipObj = curam.core.fact.CachedConcernRoleRelationshipFactory.newInstance();

    // cachedCaseEvidence manipulation variable
    curam.core.intf.CachedSupplierReturnHeader cachedSupplierReturnHeaderObj = curam.core.fact.CachedSupplierReturnHeaderFactory.newInstance();

    // CachedCaseNomineeProdDelPattern manipulation variable
    curam.core.intf.CachedCaseNomineeProdDelPattern cachedCaseNomineeProdDelPatternObj = curam.core.fact.CachedCaseNomineeProdDelPatternFactory.newInstance();

    // CachedCaseParticipantRole manipulation variable
    curam.core.intf.CachedCaseParticipantRole cachedCaseParticipantRoleObj = curam.core.fact.CachedCaseParticipantRoleFactory.newInstance();

    // CachedCaseRelationship manipulation variable
    curam.core.intf.CachedCaseRelationship cachedCaseRelationshipObj = curam.core.fact.CachedCaseRelationshipFactory.newInstance();

    // CachedCaseRelationship manipulation variable
    curam.core.intf.CachedFinancialCalendar cachedFinancialCalendarObj = curam.core.fact.CachedFinancialCalendarFactory.newInstance();

    // CachedProductDeliveryPattern manipulation variable
    curam.core.intf.CachedProductDeliveryPattern cachedProductDeliveryPatternObj = curam.core.fact.CachedProductDeliveryPatternFactory.newInstance();

    // CachedProductDeliveryPatternInfo manipulation variable
    curam.core.intf.CachedProductDeliveryPatternInfo cachedProductDeliveryPatternInfoObj = curam.core.fact.CachedProductDeliveryPatternInfoFactory.newInstance();

    // CachedRateTable manipulation variable
    curam.core.intf.CachedRateTable cachedRateTableObj = curam.core.fact.CachedRateTableFactory.newInstance();

    curam.core.intf.CachedAttributedEvidence cachedAttributedEvidenceObj = curam.core.fact.CachedAttributedEvidenceFactory.newInstance();

    // clear caches...
    cachedCaseEvidenceObj.clearCache();

    cachedCaseHeaderObj.clearCache();

    cachedCaseStatusObj.clearCache();

    cachedPersonObj.clearCache();

    cachedProductObj.clearCache();

    cachedProductDeliveryObj.clearCache();

    cachedProductDeliveryCertDiaryObj.clearCache();

    cachedProductRulesLinkObj.clearCache();

    cachedProviderLocationObj.clearCache();

    cachedConcernRoleRelationshipObj.clearCache();

    cachedSupplierReturnHeaderObj.clearCache();

    cachedCaseNomineeProdDelPatternObj.clearCache();

    cachedCaseParticipantRoleObj.clearCache();

    cachedCaseRelationshipObj.clearCache();

    cachedFinancialCalendarObj.clearCache();

    cachedProductDeliveryPatternInfoObj.clearCache();

    cachedRateTableObj.clearCache();

    cachedProductDeliveryPatternObj.clearCache();
    
    cachedAttributedEvidenceObj.clearCache();
  }

}
