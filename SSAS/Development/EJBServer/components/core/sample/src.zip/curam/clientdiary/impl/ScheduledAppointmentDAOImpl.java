/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.clientdiary.impl;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.clientdiary.codetable.impl.CLIENTDIARYRELATEDTYPEEntry;
import curam.participant.impl.ConcernRole;
import curam.util.persistence.ReaderDAO;
import curam.util.type.DateRange;


/**
 * Implementation of {@link ScheduledAppointmentDAO}. This maps to the concrete
 * DAOs for each type of scheduled appointment.
 *
 * @since 6.0
 */
@Singleton
class ScheduledAppointmentDAOImpl implements ScheduledAppointmentDAO {

  @Inject
  protected ClientDiaryDAO clientDiaryDAO;

  @Inject
  protected Map<CLIENTDIARYRELATEDTYPEEntry, ReaderDAO<Long, ? extends ScheduledAppointment>> concreteDAOTypes;

  /**
   * {@inheritDoc}
   */
  public ScheduledAppointment get(final Long relatedID,
    final CLIENTDIARYRELATEDTYPEEntry relatedType) {

    return concreteDAOTypes.get(relatedType).get(relatedID);
  }

  /**
   * {@inheritDoc}
   */
  public List<ScheduledAppointment> listActiveByConcernRoleDateRange(
    final ConcernRole concernRole, final DateRange dateRange) {

    List<ScheduledAppointment> scheduledAppointmentList = new ArrayList<ScheduledAppointment>();

    List<ClientDiary> clientDiaryList = clientDiaryDAO.listActiveByConcernRoleDateRange(
      concernRole, dateRange);

    for (ClientDiary clientDiary : clientDiaryList) {
      scheduledAppointmentList.add(clientDiary.getScheduledAppointment());
    }
    return scheduledAppointmentList;
  }

}
