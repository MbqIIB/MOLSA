/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005, 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.struct.InsuranceReturnHdrDetails;
import curam.core.struct.TicketText;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality required to maintain and
 * capture the insurance return header details for a return from an employer
 *
 */
public abstract class EmployerInsuranceRetHeaderAssistant extends curam.core.base.EmployerInsuranceRetHeaderAssistant {

  // ___________________________________________________________________________
  /**
   * This process is used to validate a new Insurance return Header for an
   * employer
   *
   * @param details Insurance return header details (in)
   */
  public void validateEmployerInsRetHeader(InsuranceReturnHdrDetails details)
    throws AppException, InformationalException {

    // based on domain CURAM_DATE
    // Variable to store the current date
    curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // Validation - insurance return type must not be blank
    if (details.insuranceReturnType.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_FV_INSRETTYPE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Validation - insurance return period must not be blank
    if (details.insuranceReturnPeriodID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERALCONTRIB.ERR_INSRETURNPERIOD_FV_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Validation - total contribution amount must not be blank
    if (details.totalContribAmt.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_FV_TOTCONTRIBAMT_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Validation - total number of employees must not be blank
    if (details.totNumEmployees == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_FV_TOTEMPLOYEES_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Validation - if the receipt date is later than the current date
    if (details.receiptDate.after(currentDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETURNHEADER_XFV_RECEIPTDATE_LATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Validation - total employer contribution amount and/or
    // total employee contribution amount must be entered
    if (details.employerContribAmt.isZero()
      && details.employeeContribAmt.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_XFV_TOTCONTRIBAMT_ZERO),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN,HARP 39472, BAP
    // Add validation to check if Total Employer Contribution is not negative
    if (details.employerContribAmt.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_FV_TOTALEMPLOYERCONTRIBUTIONAMOUNTNEG),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Add validation to check if Total Employee Contribution is not negative
    if (details.employeeContribAmt.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_FV_TOTALEMPLOYEECONTRIBUTIONAMOUNTNEG),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Validation - total contribution amount must equal employee
    // contribution + employer contribution amount
    if (details.totalContribAmt.getValue()
      != (details.employeeContribAmt.getValue()
        + details.employerContribAmt.getValue())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_XFV_TOTCONTRIBAMT_EMPLOYEE_EMPLOYER),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END,HARP 39472

    // Validation - total payroll must be entered
    if (details.totalPayroll.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_FV_TOTALPAYROLL_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (details.totalContribAmt.getValue() > details.totalPayroll.getValue()
      && !details.totalPayroll.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_XFV_TOTCONTRIBAMTPAYROLL),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Validation - number of casual employees must not be negative.
    if (details.numCasualEmployees < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_FV_TOTALNUMEMPLOYEES_CASUAL_NEGATIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Validation - number of permanent employees must not be negative.
    if (details.numPermanentEmployees < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_FV_TOTALNUMEMPLOYEES_PERMANENT_NEGATIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Validation - total number of employees must not be zero.
    if ((details.numPermanentEmployees + details.numCasualEmployees) == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_XFV_TOTNUMEMPLOYEES_ZERO),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Validation - total number of employees must equal the number of
    // permanent employees plus number of casual employees
    if ((details.numPermanentEmployees + details.numCasualEmployees > 0)
      && (details.totNumEmployees
        != (details.numPermanentEmployees + details.numCasualEmployees))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADERASSISTANT.ERR_INSRETHEADER_XFV_TOTNUMEMPLOYEES_PERMANENT_CASUAL),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * This process is used to automatically create a ticket and assign it to a
   * specified user if the creation or modification of an employer insurance
   * return header causes an error.
   *
   * @param details Insurance return header details (in)
   * @param ticketDetails Ticket text (in)
   */
  public void createTicket(
    InsuranceReturnHdrDetails details,
    TicketText ticketDetails)
    throws AppException, InformationalException {

    // Variables used to read users
    curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    UsersKey usersKey = new UsersKey();
    UsersDtls usersDtls;

    // Variables used to create notification
    curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();
    // WorkAllocationTask service layer object
    StandardManualTaskDtls standardManualTaskDtls = new StandardManualTaskDtls();

    String genTicket;

    // check the environment variable
    genTicket = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENINSRETLINEITEMINVALIDTICKET);

    // if the environment variable is not set, use default value
    if (genTicket == null) {
      genTicket = EnvVars.ENV_GENINSRETLINEITEMINVALIDTICKET_DEFAULT;
    }

    if (genTicket.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {
      return;
    }

    // Read user details for current user logged in
    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    usersDtls = usersObj.read(usersKey);

    standardManualTaskDtls.dtls.taskDtls.comments = ticketDetails.reasonText;
    standardManualTaskDtls.dtls.taskDtls.subject = ticketDetails.subjectText;
    // BEGIN, CR00023618, SK
    standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.employerInsuranceTaskDefinitionID;
    // END, CR00023618
    standardManualTaskDtls.dtls.concerningDtls.participantRoleID = details.concernRoleID;

    standardManualTaskDtls.dtls.assignDtls.assignmentID = usersDtls.userName;

    notificationObj.createWorkAllocationNotification(standardManualTaskDtls);

  }

}
