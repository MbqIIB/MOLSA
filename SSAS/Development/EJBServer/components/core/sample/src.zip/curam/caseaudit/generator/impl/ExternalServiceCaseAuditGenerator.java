/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.generator.impl;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.google.inject.Inject;

import curam.caseaudit.impl.AuditCaseConfig;
import curam.caseaudit.impl.AuditPlan;
import curam.caseaudit.impl.AuditPlanDAO;
import curam.caseaudit.impl.ExternalCaseAuditData;
import curam.caseaudit.impl.ExternalCaseAuditDataDAO;
import curam.caseaudit.impl.ExternalCaseAuditDataItem;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.SAMPLINGSTRATEGYEntry;
import curam.core.facade.struct.CaseAuditDetails;
import curam.core.facade.struct.CaseLoadDetails;
import curam.core.facade.struct.CaseSampleKey;
import curam.core.facade.struct.NumberAndPercentageOfCases;
import curam.core.impl.CuramConst;
import curam.samplingstrategy.impl.SamplingStrategy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public class ExternalServiceCaseAuditGenerator {

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected ExternalCaseAuditDataDAO externalCaseAuditDataDAO;

  @Inject
  protected Map<SAMPLINGSTRATEGYEntry, SamplingStrategy> samplingStrategies;

  // ___________________________________________________________________________
  /**
   * Generates the sample list of cases for audit using the supplied external 
   * service. This method filters the list using the algorithm associated with
   * the case type for this audit plan. The number of cases returned in the list
   * is also restricted by the number of cases or percentage of cases specified
   * by the user.
   *
   * @param key The external case audit data id, percentage/number of cases 
   * to generate and any algorithm parameters.
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void generateCaseAudits(final CaseSampleKey key)
    throws AppException, InformationalException {

    AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    
    // In the case of regeneration, remove existing case audits
    auditPlan.clearCaseLoad();
    auditPlan.clearSelectionCriteria();

    AuditCaseConfig auditCaseConfig = auditPlan.getAuditCaseConfig();

    ExternalCaseAuditData externalCaseAuditData = externalCaseAuditDataDAO.get(
      key.externalCaseAuditDataID);
        
    List<ExternalCaseAuditDataItem> externalCaseList = externalCaseAuditData.getExternalCaseAuditDataItemsByType(
      CASETYPECODEEntry.get(auditCaseConfig.getCaseType().getCode()), 
      auditCaseConfig.getCaseCategory());

    CaseAuditGeneratorHelper caseAuditGeneratorHelperObj = new CaseAuditGeneratorHelper();

    CaseLoadDetails caseLoadDetails = new CaseLoadDetails();

    caseLoadDetails.numberOfCases = key.numberOfCases;
    caseLoadDetails.percentageOfCases = key.percentageOfCases;
    caseLoadDetails.totalCases = externalCaseList.size();
    
    NumberAndPercentageOfCases numberAndPercentageOfCases = caseAuditGeneratorHelperObj.determineNumCasesToProcess(
      caseLoadDetails);

    // Get algorithm to use to generate case sample
    final SamplingStrategy samplingStrategy = samplingStrategies.get(
      auditCaseConfig.getAuditAlgorithm());

    List<Long> caseIDList = new ArrayList<Long>();

    for (ExternalCaseAuditDataItem externalCaseAuditDataItem : 
      externalCaseList) {
      caseIDList.add(externalCaseAuditDataItem.getCase().getID());
    }

    if (key.details.startPoint == 0) {
      key.details.startPoint = new Double(CuramConst.gkOne + Math.random() * numberAndPercentageOfCases.numberOfCases).intValue();            
    }
    
    if (key.details.interval == 0) {
      key.details.interval = Math.round(
        key.totalNumCases / numberAndPercentageOfCases.numberOfCases);
    }

    Map<String, Object> params = new TreeMap<String, Object>();

    params.put(CuramConst.kSystematicSamplingStartIndex,
      new Integer(key.details.startPoint));
    params.put(CuramConst.kSystematicSamplingInterval,
      new Integer(key.details.interval));

    // Call algorithm to generate case sample
    List<Long> caseIDs = samplingStrategy.getRandomSample(caseIDList,
      numberAndPercentageOfCases.numberOfCases, params);

    curam.core.facade.intf.CaseAudit caseAuditObj = curam.core.facade.fact.CaseAuditFactory.newInstance();

    // for each case, create a case audit
    for (int i = 0; i < caseIDs.size(); i++) {

      CaseAuditDetails caseAuditDetails = new CaseAuditDetails();

      caseAuditDetails.dtls.auditPlanID = key.auditPlanID;
      caseAuditDetails.dtls.caseID = caseIDs.get(i);
      caseAuditObj.createCaseAudit(caseAuditDetails);
    }

    // Update audit plan with number/percentage cases
    auditPlan.setNumberCases(numberAndPercentageOfCases.numberOfCases);
    auditPlan.setPercentageCases(numberAndPercentageOfCases.percentageOfCases);    
    auditPlan.modify(auditPlan.getVersionNo());

    auditPlan.auditPlanPending(auditPlan.getVersionNo());
    auditPlan.caseSampleListGenerated();

  }
}
