/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import curam.codetable.impl.AUDITPLANTRANSACTIONTYPEEntry;
import curam.util.persistence.StandardEntity;
import curam.util.type.DateTime;

/**
 * AuditPlanTransactionLog Accessor for
 * {@linkplain curam.caseaudit.impl.AuditPlanTransactionLog}
 * 
 */
public interface AuditPlanTransactionLogAccessor extends StandardEntity {

  // ____________________________________________________________________________
  /**
   * Returns the AuditPlan record associated with this AuditPlanTransactionLog.
   * 
   * @return The AuditPlan record associated with this AuditPlanTransactionLog
   */
  public AuditPlan getAuditPlan();

  // ____________________________________________________________________________
  /**
   * Returns the transaction type for this AuditPlanTransactionLog.
   * 
   * @return The transaction type of this AuditPlanTransactionLog
   */
  public AUDITPLANTRANSACTIONTYPEEntry getTransactionType();

  // ____________________________________________________________________________
  /**
   * Returns the date and time that this AuditPlanTransactionLog was created.
   * 
   * @return The date and time that this AuditPlanTransactionLog was created
   */
  public DateTime getTransactionDateTime();

  // ___________________________________________________________________________
  /**
   * Returns the name of the user that created the AuditPlanTransactionLog
   * record.
   * 
   * @return The name of the user that created the AuditPlanTransactionLog.
   */
  public String getUserName();

  // ___________________________________________________________________________
  /**
   * Returns the description of the AuditPlanTransactionLog record.
   * 
   * @return The description of the AuditPlanTransactionLog.
   */
  public String getDescription();

  // ___________________________________________________________________________
  /**
   * Returns the relatedID, the unique ID of the record the audit plan
   * transaction log record relates to.
   * 
   * @return The unique ID of the related record.
   */
  public long getRelatedID();

  // ___________________________________________________________________________
  /**
   * Returns the unique sequence number for this transaction, used to ensure
   * lists of transactions are sorted correctly
   * 
   * @return The sequence number for this record
   */
  public long getSequenceNumber();
}
