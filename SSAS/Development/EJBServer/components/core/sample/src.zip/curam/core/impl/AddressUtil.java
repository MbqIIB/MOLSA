/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2003, 2010, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

/**
 * This is additional utility class for address handling. This class contains
 * various utility constants used in Address and AddressData classes.
 *
 */

package curam.core.impl;


public abstract class AddressUtil {

  // indexes for accessing address data lines
  // (all address header lines + first data line)
  public static class AddressDataLineIndex {
    public static final int I_WIDGET_VERSION = 0;
    public static final int I_ADDRESS_ID = 1;
    public static final int I_ADDRESS_LAYOUT_TYPE = 2;
    public static final int I_COUNTRY_CODE = 3;
    public static final int I_MODIFIABLE_IND = 4;
    public static final int I_VERSION_NO = 5;
    public static final int I_ADDRESS_LINE_1 = 6;
  }


  // BEGIN, CR00219204, SW
  // constants for US address line identification
  /**
   * @deprecated Since Curam 6.0, replaced with
   * {@linkplain curam.core.impl.AddressUtil.AddressDataIndex}.
   * This constant is deprecated because it did not facilitate localization.    
   * See release note: CR00219204
   */
  @Deprecated
  public static class AddressUSDataIndex {
    public static final int US_ADDRESS_LINE_1 = 0;
    public static final int US_ADDRESS_LINE_2 = 1;
    public static final int US_ADDRESS_LINE_3 = 2;
  }
  

  // BEGIN, CR00274729, ZV
  // Constants for US/DE address line identification.
  // Note, that ADDRESS_DATA_LINE here does not refer to the particular
  // AddressData tag, but to the data line number in the bunch of data
  // lines that go straight after the address header.
  public static class AddressDataIndex {
    public static final int ADDRESS_DATA_LINE_1 = 0;
    public static final int ADDRESS_DATA_LINE_2 = 1;
    public static final int ADDRESS_DATA_LINE_3 = 2;
    public static final int ADDRESS_DATA_LINE_4 = 3;
    public static final int ADDRESS_DATA_LINE_5 = 4;
    public static final int ADDRESS_DATA_LINE_6 = 5;
    public static final int ADDRESS_DATA_LINE_7 = 6;
    public static final int ADDRESS_DATA_LINE_8 = 7;
    public static final int ADDRESS_DATA_LINE_9 = 8;
    public static final int ADDRESS_DATA_LINE_10 = 9;
    public static final int ADDRESS_DATA_LINE_11 = 10;
  }
  // END, CR00274729
  // END, CR00219204

  // line count in address header
  public static final int kAddressHeaderLineCount = 6;
  // Address widget version. Currently defaults to 1.
  // In future address widget should support
  // its version handling by itself
  // BEGIN, CR00052924, GM
  public static final String kWidgetVersion = CuramConst.gkModifiableIndex;
  // END, CR00052924
  // minimal length of address line
  public static final int kMinAddrLineLen = 3;

  // misc. utility constants
  public static final int kFirst = 1;
  public static final int kSecond = 2;
  public static final int kThird = 3;

  // data element count constants for US and UK addresses
  public static final int US_ADDRESS_ELEMENT_COUNT = 6;
  public static final int UK_ADDRESS_ELEMENT_COUNT = 7;

}
