/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2007, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


/**
 * Code to maintain circular buffer used for some of the cached
 * Entity operations in the Application.
 *
 */

public abstract class CircularBuffer {
  // current array pointer
  protected int current;
  // Array used as buffer.
  protected Object[] buffer;
  protected int bufSize;

  // ____________________________________________________________________________
  /**
   * Description: Method to initialize the current array pointer
   *
   * @param theBufSize the buffer size
   */

  public CircularBuffer(int theBufSize) {

    current = 0;

    bufSize = theBufSize;
    buffer = new Object[bufSize];
  }

  // ____________________________________________________________________________
  /**
   * Description: Method to insert item, add to buffer and increment current
   * pointer
   *
   * @param t item which is being added to the circular buffer
   */

  public final void insert(Object t) {

    buffer[current] = t;

    // Loop current point if we've reached the end of the array
    if (++current >= bufSize) {

      current = 0;

    }

  }

  // ____________________________________________________________________________
  /**
   * Description: Method to check if a given item is
   * in the buffer. Uses the function call operator of the subclass for
   * comparison
   *
   * @param criterion item criterion for finding operation
   *
   * @return item found in the buffer or null
   */

  public final Object find(Object criterion) {

    for (int i = 0; i < bufSize; i++) {

      if (buffer[i] != null) {

        if (itemsEqual(buffer[i], criterion)) {

          return buffer[i]; // a match !

        }

      }

    }

    return null; // not found

  }

  // ___________________________________________________________________________
  /**
   * Description: Method to used to clear the buffer. Uses the clear operation
   * on the subclass to clear the array elements.
   *
   */

  public final void clearCache() {

    for (int i = 0; i < bufSize; i++) {

      // Clear item only if its value is not null
      if (buffer[i] != null) {
        clearItem(buffer[i]);
      }

    }

  }

  protected abstract boolean itemsEqual(Object o1, Object o2);

  protected abstract void clearItem(Object o);

}
