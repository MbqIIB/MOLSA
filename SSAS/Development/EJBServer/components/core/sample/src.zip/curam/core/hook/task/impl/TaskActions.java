/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.hook.task.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.Implementable;


/**
 * Contains a number of hook points which allow for custom specific processing 
 * of task management operations.
 */
@Implementable
@ImplementedBy(TaskActionsImpl.class)
public interface TaskActions {

  /**
   * Adds a comment to a task by inserting a record into the task history
   * table.
   *
   * @param taskID The identifier of the task which the comment is being added.
   * @param comment The comment to be added.
   */
  public void addComment(final long taskID, final String comment)
    throws AppException, InformationalException;

  /**
   * Closes a task.
   *
   * @param taskID The identifier of the task to be closed
   */
  public void close(final long taskID)
    throws AppException, InformationalException;

  /**
   * Creates a new task
   *
   * @param subject The task subject.
   * @param priority The task priority.
   * @param assignedTo The object that the task will be assigned to.
   * @param assigneeType The type of the organization object.
   * @param deadlineDateTime The task deadline.
   * @param participantRoleID The participant role identifier.
   * @param participantType  The participant type.
   * @param caseID The case identifier.
   * @param addToMyTasksInd A flag to indicate whether the task should 
   * be added to the users task list.
   * @param comment The task comment.
   */
  public void create(
    final String subject,
    final String priority,
    final String assignedTo,
    final String assigneeType,
    final DateTime deadlineDateTime,
    final long participantRoleID,
    final String participantType,
    final long caseID,
    final boolean addToMyTasksInd,
    final String comment) throws AppException, InformationalException;

  /**
   * Defers a task until a later date.
   *
   * @param taskID The identifier of the task to be deferred.
   * @param restartDate The date the task is to be restarted.
   * @param comment A comment indicating why the task is being deferred.
   * @param versionNo The optimistic locking version number of the task.
   */
  public void defer(final long taskID, final Date restartDate,
    final String comment, final int versionNo)
    throws AppException, InformationalException;

  /**
   * Restarts a deferred task.
   *
   * @param taskID The identifier of the task to be restarted.
   * @param comments A comment indicating why the task is being restarted.
   * @param versionNo The optimistic locking version number of the task.
   */
  public void restart(final long taskID, final String comments,
    final int versionNo) throws AppException, InformationalException;

  /**
   * Forwards a task to a job, position, organization unit, user, work queue
   * or allocation target.
   *
   * @param taskID The identifier of the task to be forwarded.
   * @param forwardToID The identifier of the object who the task is being
   * forwarded.
   * @param forwardToType The type of the object who the task is being 
   * forwarded.
   * @param comment A comment indicating why the task is being forwarded.
   * @param versionNo The optimistic locking version number of the task.
   */
  public void forward(final long taskID, final String forwardToID,
    final String forwardToType, final String comment, final int versionNo)
    throws AppException, InformationalException;

  /**
   * Modifies the total time worked on the specified task.
   *
   * @param taskID The identifier of the task whose total time worked
   * on will be updated.
   * @param totalTimeWorked The total time worked expressed as a date time.
   * @param timeHoursWorked The number of hours worked.
   * @param timeMinutesWorked The number of minutes worked.
   * @param comment A comment to be added.
   * @param versionNo The optimistic locking version number of the task.
   */
  public void modifyTimeWorked(final long taskID, 
    final DateTime totalTimeWorked, final long timeHoursWorked,
    final long timeMinutesWorked, final String comment, final int versionNo)
    throws AppException, InformationalException;

  /**
   * Modifies the priority of a task.
   *
   * @param taskID The identifier of the task whose priority will be updated.
   * @param priority The priority that the task will be updated to.
   * @param comments The comments associated with the priority modification
   * action. These will be stored in the associated task history record
   * written as a result of this action.
   * @param versionNo The optimistic locking version number of the task.
   */
  public void modifyPriority(final long taskID, final String priority,
    final String comments, final int versionNo)
    throws AppException, InformationalException;

  /**
   * Modifies the deadline of a task.
   *
   * @param taskID The identifier of the task whose deadline will be updated.
   * @param deadline The date and time that the task deadline will be
   * updated to.
   * @param comments The comments associated with the deadline modification
   * action. These will be stored in the associated task history record
   * written as a result of this action.
   * @param versionNo The optimistic locking version number of the deadline
   * record associated with the task.
   */
  public void modifyDeadline(final long taskID, final DateTime deadline,
    final String comments, final int versionNo)
    throws AppException, InformationalException;

  /**
   * Reallocates a task. Reallocation of a task invokes the tasks initial
   * allocation strategy. This results in the task being made available to
   * the group of users, organizational objects or work queues to which it
   * was originally available to.
   *
   * @param taskID The identifier of the task which is being reallocated.
   * @param comment A comment to be added indicating why the task is being 
   * reallocated.
   * @param versionNo The optimistic locking version number of the task.
   */
  public void reallocate(final long taskID, final String comment,
    final int versionNo) throws AppException, InformationalException;

  /**
   * Adds the task to the user's <code>My Tasks</code> task list.
   *
   * @param taskID The identifier of the task being added to the user's 
   * <code>My Tasks</code> list.
   * @param comment A comment to be added.
   * @param versionNo The optimistic locking version number of the task.
   */
  public void getTask(final long taskID, final String comment,
    final int versionNo) throws AppException, InformationalException;

  /**
   * Makes the specified task available to the organization object, 
   * user or work queue that it was previously available for.
   *
   * @param taskID The identifier of the task to make available.
   * @param comment A comment to indicate why the task is being made available.
   * @param versionNo The optimistic locking version number of the task.
   */
  public void makeAvailable(final long taskID, final String comment,
    final int versionNo) throws AppException, InformationalException;
}
