/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalcheck.impl;


import com.google.inject.Inject;

import curam.approvalcheck.entity.struct.ApprovalCheckDtls;
import curam.codetable.impl.APPROVALCHECKTYPEEntry;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.core.impl.CuramConst;
import curam.message.impl.APPROVALCHECKExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Money;
import curam.util.type.StringHelper;


/**
 * Approval Check Implementation. Provides implementation for Approval Check
 * Accessor and Mutator interfaces.
 */
// BEGIN, CR00183334, PS
public class ApprovalCheckImpl extends SingleTableLogicallyDeleteableEntityImpl<ApprovalCheckDtls> implements
  ApprovalCheck {
  // END, CR00183334

  // BEGIN, CR00231006, GD
  @Inject
  protected EventDispatcherFactory<ApprovalCheckCreateEvent> createEventDispatcherFactory;
  
  @Inject
  protected EventDispatcherFactory<ApprovalCheckModifyEvent> modifyEventDispatcherFactory;
  // END, CR00231006
 
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice.
   */
  protected ApprovalCheckImpl() {// no-arg constructor for use only by Guice.
  }

  // END, CR00183334

  /**
   * {@inheritDoc}
   */
  public void createApprovalCheck(final APPROVALRELATEDTYPEEntry relatedType,
    final long relatedID, final APPROVALCHECKTYPEEntry typeCode)
    throws InformationalException {

    getDtls().relatedType = relatedType.getCode();
    getDtls().relatedID = relatedID;
    getDtls().typeCode = typeCode.getCode();
    // notify listeners that something is about to happen

    // BEGIN, CR00231006, GD
    createEventDispatcherFactory.get(ApprovalCheckCreateEvent.class).preCreateApprovalCheck(
      this);
    // END, CR00231006

    validateApprovalCheckType();

    insert();

    // notify listeners that something has just been done
    // BEGIN, CR00231006, GD
    createEventDispatcherFactory.get(ApprovalCheckCreateEvent.class).postCreateApprovalCheck(
      this);
    // END, CR00231006
  }

  /**
   * Validates against the type of Approval Check being performed.
   *
   */
  void validateApprovalCheckType() {
    // perform validations for organization unit approval check
    if (getDtls().typeCode != null
      && getDtls().typeCode.equals(
        APPROVALCHECKTYPEEntry.ORGANISATIONUNIT.getCode())) {
      mandatoryOrgUnitFieldValidation(getOrganisationUnitID());
      userNameNotSetValidation(getUsername());
    } // perform validations for related type approval check
    else if (getDtls().typeCode != null
      && getDtls().typeCode.equals(APPROVALCHECKTYPEEntry.RELATEDTYPE.getCode())) {
      userNameAndOrgUnitExistsValidation(getUsername(), getOrganisationUnitID());
    } // perform validations for user approval check
    else if (getDtls().typeCode != null
      && getDtls().typeCode.equals(APPROVALCHECKTYPEEntry.USER.getCode())) {
      addOrgUnitIDNotSetValidation(getOrganisationUnitID());
      mandatoryUserFieldValidation(getUsername());
    }
  }

  /**
   * {@inheritDoc}
   */
  public Money getCost() {
    return new Money(getDtls().cost);
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  public long getOrganisationUnitID() {
    return getDtls().organisationUnitID;
  }

  /**
   * {@inheritDoc}
   */
  public short getPercentage() {
    return getDtls().percentage;
  }

  /**
   * {@inheritDoc}
   */
  public long getRelatedID() {
    return getDtls().relatedID;
  }

  /**
   * {@inheritDoc}
   */
  public APPROVALRELATEDTYPEEntry getRelatedType() {
    return APPROVALRELATEDTYPEEntry.get(getDtls().relatedType);
  }

  /**
   * {@inheritDoc}
   */
  public APPROVALCHECKTYPEEntry getType() {
    return APPROVALCHECKTYPEEntry.get(getDtls().typeCode);
  }

  /**
   * {@inheritDoc}
   */
  public String getUsername() {
    return getDtls().username;
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// defined in subclass
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// defined in subclass
  }

  /**
   * {@inheritDoc}
   */
  public void modifyApprovalCheck(final int versionNo)
    throws InformationalException {

    // notify listeners that something is about to happen

    // BEGIN, CR00231006, GD
    modifyEventDispatcherFactory.get(ApprovalCheckModifyEvent.class).preModifyApprovalCheck(
      this);
    // END, CR00231006, GD

    validateApprovalCheckType();
    modify(versionNo);

    // notify listeners that something has just been done
    // BEGIN, CR00231006, GD
    modifyEventDispatcherFactory.get(ApprovalCheckModifyEvent.class).postModifyApprovalCheck(
      this);
    // END, CR00231006

  }

  /**
   * {@inheritDoc}
   */
  public void setCost(final Money cost) {
    getDtls().cost = cost;
  }

  /**
   * {@inheritDoc}
   */
  public void setOrganisationUnitID(final long organisationUnitID) {
    getDtls().organisationUnitID = organisationUnitID;
  }

  /**
   * {@inheritDoc}
   */
  public void setPercentage(final short percent) {
    getDtls().percentage = percent;
    // BEGIN, CR00238338, PF
    if (getPercentage() < CuramConst.gkZero
      || getPercentage() > CuramConst.gkOneHundredPercent) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        APPROVALCHECKExceptionCreator.ERR_FV_PERCENTAGE_INVALID_RANGE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00238338
  }

  /**
   * {@inheritDoc}
   */
  public void setUsername(final String username) {
    getDtls().username = username;
  }

  /**
   * {@inheritDoc}
   */
  public void setComments(final String comments) {
    getDtls().comments = comments;
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {
    
    if (getDtls().typeCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        APPROVALCHECKExceptionCreator.ERR_FV_TYPE_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // related type
    if (getDtls().relatedType.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        APPROVALCHECKExceptionCreator.ERR_FV_RELATED_TYPE_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  /**
   * Performs mandatory field validation for Organization Unit approval Check.
   *
   * @param organisationUnitID
   * the identifier for the organization unit.
   */
  void mandatoryOrgUnitFieldValidation(final long organisationUnitID) {
    if (organisationUnitID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        APPROVALCHECKExceptionCreator.ERR_XFV_TYPE_ORGANISATION_UNIT_ORGANISATIONUNITID_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  /**
   * Performs validation on the user name being set. If the username is set then
   * a validation is thrown.
   *
   * @param userName
   * the user name.
   */
  void userNameNotSetValidation(final String userName) {
    
    if (!StringHelper.isEmpty(userName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        APPROVALCHECKExceptionCreator.ERR_XFV_TYPE_ORGANISATION_UNIT_AND_USERNAME_INVALID(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  /**
   * Validation for organization unit and user name being set.
   *
   * @param userName
   * The user name of the user.
   * @param orgUnitID
   * The organization unit identifier.
   */
  void userNameAndOrgUnitExistsValidation(final String userName,
    final long orgUnitID) {
    
    if (orgUnitID != CuramConst.gkZero || !StringHelper.isEmpty(userName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        APPROVALCHECKExceptionCreator.ERR_XFV_TYPE_RELATED_TYPE_AND_USERNAME_OR_ORGANISATION_UNIT_INVALID(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  /**
   * Validation for organization unit identifier being set.
   *
   * @param orgUnitID
   * the organization unit identifier.
   */
  void addOrgUnitIDNotSetValidation(final long orgUnitID) {
    if (orgUnitID != CuramConst.gkZero) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        APPROVALCHECKExceptionCreator.ERR_XFV_TYPE_USER_AND_ORGANISATION_UNIT_INVALID(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  /**
   * Mandatory field validation for User Approval Checks.
   *
   * @param userName
   * The user name of the user.
   */
  void mandatoryUserFieldValidation(final String userName) {
    
    if (StringHelper.isEmpty(userName)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        APPROVALCHECKExceptionCreator.ERR_XFV_TYPE_USER_USERNAME_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }
}
