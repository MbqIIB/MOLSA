/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


/**
 * Functions for manipulating user activity dates and times.
 */
public abstract class ActivityDateTimeManipulation {

  // ___________________________________________________________________________
  /**
   * Formats a DateTime based on a datePart and a timePart,
   * e.g. to return the DateTime of an occurrence of activity which occurs at
   * same time every day.
   * Note that only the time information in timePart will be used - any date
   * information will be discarded.
   *
   * @param datePart where the date is taken from
   * @param timePart where the time is taken from
   *
   * @return the new date/time made from the inputs
   *
   */
  public static curam.util.type.DateTime getDateTimeFromDateAndTime(
    curam.util.type.Date datePart,
    curam.util.type.DateTime timePart) {

    curam.util.type.DateTime dateTime = datePart.getDateTime();
    // midnight on the date

    // create a calendar to get the hours/minutes/seconds
    java.util.Calendar timePartCal = timePart.getCalendar();

    // create a calendar to set the hours/minutes/seconds
    java.util.Calendar dateTimeCal = dateTime.getCalendar();

    dateTimeCal.set(java.util.Calendar.HOUR_OF_DAY,
      timePartCal.get(java.util.Calendar.HOUR_OF_DAY));
    dateTimeCal.set(java.util.Calendar.MINUTE,
      timePartCal.get(java.util.Calendar.MINUTE));
    dateTimeCal.set(java.util.Calendar.SECOND,
      timePartCal.get(java.util.Calendar.SECOND));

    return new curam.util.type.DateTime(dateTimeCal);

  }

}
