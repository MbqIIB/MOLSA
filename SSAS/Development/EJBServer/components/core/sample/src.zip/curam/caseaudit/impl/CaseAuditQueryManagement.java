/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2010, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.caseaudit.impl;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.core.impl.CuramConst;
import curam.core.sl.struct.CaseIDKey;
import curam.message.impl.CASEAUDITQUERYMANAGEMENTExceptionCreator;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.selectionquery.impl.Criteria;
import curam.selectionquery.impl.SelectionQuery;
import curam.selectionquery.impl.SelectionQueryDAO;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.rules.StringTokenizer;
import curam.util.transaction.TransactionInfo;


/**
 * This class provides public APIs to run fixed or dynamic search queries.
 */
public class CaseAuditQueryManagement {

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  @Inject
  protected SelectionQueryDAO selectionQueryDAO;

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public CaseAuditQueryManagement() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Executes a Case Audit dynamic selection query and returns list of case header
   * records that match the criteria specified in the fixed query.
   *
   * @param selectionQueryID the unique identifier of the dynamic selection
   * query
   *
   * @param parameterMap Map of all parameters in name value pairs.
   * @return A list of Case Header records that satisfy the search criteria
   * @throws AppException
   * @throws InformationalException
   */
  public List<CaseHeader> runDynamicQueryCaseSearch(final long selectionQueryID,
    final HashMap<String, String> parameterMap)
    throws AppException, InformationalException {

    // retrieve selection query details
    SelectionQuery selectionQuery = selectionQueryDAO.get(selectionQueryID);

    // Build dynamic SQL
    String sql = selectionQuery.getSQLText();

    // retrieve list of parameters
    Set<String> keys = parameterMap.keySet();

    // generate list of expected parameters
    Set<String> expectedParameters = getExpectedParametersFromSQL(sql);

    for (String key : keys) {
      String value = parameterMap.get(key).trim();

      key = convertKey(key);
      value = convertValue(value);

      // Make sure passed in parameter is in the list of expected parameters
      if (!expectedParameters.contains(key)) {

        // BEGIN, CR00339770, ZV
        // remove the : from the name of the invalid parameter
        AppException ae = CASEAUDITQUERYMANAGEMENTExceptionCreator.ERR_RV_DYNAMIC_QUERY_SQL_INVALID_PARAMETER(
          key.substring(1, key.length()));

        // END, CR00339770

        ValidationHelper.addValidationError(ae);
      } else {
        // remove parameter from the expected parameter list as this has been
        // supplied.
        expectedParameters.remove(key);
      }

      sql = sql.replaceAll(key, value);
    }

    // check to see if all the expected parameters were supplied
    if (expectedParameters.size() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CASEAUDITQUERYMANAGEMENTExceptionCreator.ERR_RV_DYNAMIC_QUERY_SQL_MISSING_PARAMETER(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // check for validation errors
    ValidationHelper.failIfErrorsExist();

    // Call dynamic SQL API to execute SQL
    return runSQLCaseSearch(sql);
  }

  // ___________________________________________________________________________
  /**
   * Executes a Case Audit fixed selection query and returns list of case header
   * records that match the criteria specified in the fixed query.
   *
   * @param selectionQueryID the unique identifier of the fixed selection query
   * @return A list of Case Header records that satisfy the search criteria
   * @throws AppException
   * @throws InformationalException
   */
  public List<CaseHeader> runFixedQueryCaseSearch(final long selectionQueryID)
    throws AppException, InformationalException {

    // retrieve selection query details
    SelectionQuery selectionQuery = selectionQueryDAO.get(selectionQueryID);
    
    // retrieve fixed query criteria and values
    List<Criteria> criteriaList = selectionQuery.getCriteria();
    
    // Build dynamic SQL
    String sql = selectionQuery.getSQLText();

    // generate list of expected parameters
    Set<String> expectedParameters = getExpectedParametersFromSQL(sql);

    for (Criteria criteria : criteriaList) {
      
      String value = criteria.getValue().trim();
      String key = criteria.getName().trim();

      key = convertKey(key);
      value = convertValue(value);

      // Make sure passed in parameter is in the list of expected parameters
      if (!expectedParameters.contains(key)) {

        // BEGIN, CR00339770, ZV
        // remove the : from the name of the invalid parameter
        AppException ae = CASEAUDITQUERYMANAGEMENTExceptionCreator.ERR_RV_FIXED_QUERY_SQL_INVALID_PARAMETER(
          key.substring(1, key.length()));

        // END, CR00339770

        ValidationHelper.addValidationError(ae);
        
      } else {
        // remove parameter from the expected parameter list as this has been
        // supplied.
        expectedParameters.remove(key);
      }

      sql = sql.replaceAll(key, value);
    }

    // check to see if all the expected parameters were supplied
    if (expectedParameters.size() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CASEAUDITQUERYMANAGEMENTExceptionCreator.ERR_RV_FIXED_QUERY_SQL_MISSING_PARAMETER(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // check for validation errors
    ValidationHelper.failIfErrorsExist();

    // Call dynamic SQL API to execute SQL
    return runSQLCaseSearch(sql);
  }

  /**
   * Converts the value passed in to be in the format 'value'.
   * @param value the value to be converted
   * @return the converted value
   */
  protected String convertValue(final String value) {
    
    // return struct 
    String ret = value.trim();
    
    // convert value to be in form 'value' add apostrophes if they are missing
    if (ret.charAt(0) != '\'') {
      ret = '\'' + ret;
    }

    if (ret.charAt(ret.length() - 1) != '\'') {
      ret = ret + '\'';
    }
    
    return ret;
  }

  /**
   * Converts the key value passed in into the format ":keyName".
   * @param key the key name to be converted
   * @return the converted key name
   */
  protected String convertKey(final String key) {
    
    // return value
    String ret = key.trim();
    
    // convert key into the format :keyName, add colon if it is not first char
    if (ret.charAt(0) != ':') {
      ret = ':' + ret;
    }
    return ret;
  }

  // ___________________________________________________________________________
  /**
   * Executes SQL using the Dynamic SQL API and converts results into list of
   * case header records. If no records are returned from the SQL and no errors
   * are encountered then an empty list is returned.
   *
   * @param sqlText The SQL query to be executed using the Dynamic API
   * @return A list of Case Header records that satisfy the search criteria
   * @throws Exception 
   * @throws InformationalException 
   */
  public List<CaseHeader> runSQLCaseSearch(final String sqlText)
    throws AppException, InformationalException {

    // return struct
    List<CaseHeader> caseHeaderList = new ArrayList<CaseHeader>();
    
    // BEGIN, CR00290965, IBM
    // Call dynamic SQL API to execute SQL
    CuramValueList<CaseIDKey> curamValueList = DynamicDataAccess.executeNsMulti(
      CaseIDKey.class, null, false, true, sqlText);

    // END, CR00290965
    
    for (int i = 0; i < curamValueList.size(); i++) {

      CaseIDKey caseIDKey = curamValueList.get(i);

      caseHeaderList.add(caseHeaderDAO.get(caseIDKey.caseID));
    }
    
    return caseHeaderList;
  }
  
  /**
   * Returns a set of all the parameters that are specified in the supplied SQL.
   * @param sqlText The SQL text of the fixed or dynamic query
   * @return Set of expected parameter names
   */
  protected Set<String> getExpectedParametersFromSQL(final String sqlText) {
    
    // return struct 
    Set<String> expectedParameters = new HashSet<String>();
    
    // find start of where clause
    int wherePos = sqlText.toLowerCase().indexOf("where ");
    
    // if there is no where clause then return empty set
    if (wherePos == -1) {
      return expectedParameters;
    }
    
    // BEGIN, CR00339770, ZV
    String whereClause = sqlText.substring(wherePos).trim();
    // END, CR00339770
    
    StringTokenizer stringTokenizer = new StringTokenizer(whereClause, ":");

    // ignore the first token as this contains no parameters
    stringTokenizer.nextToken();

    // add parameters to expected parameter set
    while (stringTokenizer.hasMoreTokens()) {
      // if token has empty space then this is not the last token and need to
      // strip out the parameter, otherwise token is the parameter
      String nextToken = stringTokenizer.nextToken();

      if (nextToken.indexOf(" ") == -1) {
        // BEGIN, CR00417671, GK  
        expectedParameters.add(
          ":"
            + new StringTokenizer(nextToken, System.getProperty(CuramConst.gkSystemLineSeparatorKey)).nextToken());
        // END, CR00417671
      } else {
        int spacePos = nextToken.indexOf(" ");

        // BEGIN, CR00417671, GK
        expectedParameters.add(
          ":"
            + new StringTokenizer(nextToken.substring(0, spacePos), System.getProperty(CuramConst.gkSystemLineSeparatorKey)).nextToken());
        // END, CR00417671
      }
    }
    
    return expectedParameters;
  }
}
