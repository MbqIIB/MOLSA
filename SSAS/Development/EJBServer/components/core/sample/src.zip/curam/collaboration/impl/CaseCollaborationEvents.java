/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.collaboration.impl;


import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Implementable;


/**
 * Business events that cases which support collaboration must raise in order
 * for collaboration to function correctly for the case. At various stages in
 * the life cycle of a case events must be raised so that the collaboration
 * details can be updated according to the state of the case that the
 * collaboration is happening on.
 *
 * @since 6.0
 */
// BEGIN, CR00309529, POH
@SuppressWarnings("unused")
@AccessLevel(AccessLevelType.EXTERNAL)
@Implementable
public abstract class CaseCollaborationEvents {
  // END CR00309529
  /**
   * Business event invoked after the creation of the case.
   *
   * @param caseHeader
   * The case header instance of the newly created case.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public void postCaseCreation(final CaseHeader caseHeader) {// implementation
    // to be provided
    // by listeners
  }

  /**
   * Business event invoked after the closure of the case.
   *
   * @param caseHeader
   * The case header instance of the case being closed.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public void postCaseClosure(final CaseHeader caseHeader) {// implementation to
    // be provided by
    // listener
  }
}
