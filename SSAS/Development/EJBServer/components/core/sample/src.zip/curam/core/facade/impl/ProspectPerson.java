/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2006, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import java.util.regex.Pattern;

import curam.codetable.INDIGENOUSGROUPCODE;
import curam.codetable.INDIGENOUSREGIONCODE;
import curam.codetable.RACECODE;
import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.fact.PersonFactory;
import curam.core.facade.intf.Participant;
import curam.core.facade.intf.Person;
import curam.core.facade.struct.AddressString;
import curam.core.facade.struct.AllParticipantSearchDetails;
import curam.core.facade.struct.AllParticipantSearchKey;
import curam.core.facade.struct.AllParticipantSearchResult;
import curam.core.facade.struct.BankAccountListForRedirectionDetails;
import curam.core.facade.struct.BankAccountString;
import curam.core.facade.struct.CancelCitizenshipKey;
import curam.core.facade.struct.CancelCommunicationKey;
import curam.core.facade.struct.CancelContactKey;
import curam.core.facade.struct.CancelEducationKey;
import curam.core.facade.struct.CancelEmploymentKey;
import curam.core.facade.struct.CancelEmploymentWorkingHourDetails;
import curam.core.facade.struct.CancelParticipantAddressKey;
import curam.core.facade.struct.CancelParticipantAlternateIDKey;
import curam.core.facade.struct.CancelParticipantBankAccountKey;
import curam.core.facade.struct.CancelParticipantCommunicationExceptionKey;
import curam.core.facade.struct.CancelParticipantEmailAddressKey;
import curam.core.facade.struct.CancelParticipantNoteDetails;
import curam.core.facade.struct.CancelParticipantPhoneNumberKey;
import curam.core.facade.struct.CancelParticipantWebAddressDetails;
import curam.core.facade.struct.CancelPersonForeignResidencyKey;
import curam.core.facade.struct.CancelPersonNameKey;
import curam.core.facade.struct.CancelPersonRelationshipDetailsKey;
import curam.core.facade.struct.CancelUtilityPaymentKey;
import curam.core.facade.struct.CommunicationDetailList;
import curam.core.facade.struct.ConcernRoleKeyStruct;
import curam.core.facade.struct.ConcernRoleTypeDetails;
import curam.core.facade.struct.ConcernRoleWaitListDetailsList;
import curam.core.facade.struct.ContactContextDescriptionDetails;
import curam.core.facade.struct.ContactContextDescriptionKey;
import curam.core.facade.struct.CreateContactDetails;
import curam.core.facade.struct.CreateContactFromUnregisteredParticipant;
import curam.core.facade.struct.CreateEmailCommunicationDetails;
import curam.core.facade.struct.CreateEmploymentWorkingHourDetails;
import curam.core.facade.struct.CreateFreeformCommunication;
import curam.core.facade.struct.CreateHomePhoneNumber;
import curam.core.facade.struct.CreateMailingAddress;
import curam.core.facade.struct.CreateParticipantAddressDetails;
import curam.core.facade.struct.CreateParticipantAdminRoleDetails;
import curam.core.facade.struct.CreateParticipantAlternateIDDetails;
import curam.core.facade.struct.CreateParticipantBankAccountDetails;
import curam.core.facade.struct.CreateParticipantEmailAddressDetails;
import curam.core.facade.struct.CreateParticipantPhoneDetails;
import curam.core.facade.struct.CreateTemplateCommunication;
import curam.core.facade.struct.CreateWorkPhoneNumber;
import curam.core.facade.struct.CreatedAlternateNameDetails;
import curam.core.facade.struct.CreatedCitizenshipDetails;
import curam.core.facade.struct.CreatedEducationDetails;
import curam.core.facade.struct.CreatedEmploymentWorkingHourDetails;
import curam.core.facade.struct.CreatedForeignResidencyDetails;
import curam.core.facade.struct.CreatedRelationshipDetails;
import curam.core.facade.struct.EducationReadKey;
import curam.core.facade.struct.EmploymentWorkingHourAndVersionNoList;
import curam.core.facade.struct.EmploymentWorkingHourContextDescription;
import curam.core.facade.struct.EmploymentWorkingHourContextDescriptionKey;
import curam.core.facade.struct.EmploymentWorkingHourKey;
import curam.core.facade.struct.EmploymentWorkingHourList;
import curam.core.facade.struct.EndDeductionDetails;
import curam.core.facade.struct.FormattedAddressList;
import curam.core.facade.struct.FormattedBankAccountList;
import curam.core.facade.struct.IndigenousGroupList;
import curam.core.facade.struct.IndigenousGroupSearchKey;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.InformationalMsgDetailsList;
import curam.core.facade.struct.InsertPrimaryResAddress;
import curam.core.facade.struct.ListActiveBenefitCaseDetails;
import curam.core.facade.struct.ListActiveBenefitCasesKey;
import curam.core.facade.struct.ListCasesByConcernRoleDetails;
import curam.core.facade.struct.ListConcernContactDetails;
import curam.core.facade.struct.ListContactDetails;
import curam.core.facade.struct.ListContactKey;
import curam.core.facade.struct.ListDuplicateParticipantFinancials;
import curam.core.facade.struct.ListDuplicateParticipantInteractionDetails;
import curam.core.facade.struct.ListDuplicateParticipantIssuedPaymentInstrument;
import curam.core.facade.struct.ListEmploymentWorkingHourKey;
import curam.core.facade.struct.ListInteractionDetails;
import curam.core.facade.struct.ListInteractionKey;
import curam.core.facade.struct.ListParticipantFinancials;
import curam.core.facade.struct.ListParticipantFinancials1;
import curam.core.facade.struct.ListParticipantFinancialsKey;
import curam.core.facade.struct.ListParticipantIssuedPaymentInstrument;
import curam.core.facade.struct.ListParticipantTaskKey_eo;
import curam.core.facade.struct.ListTemplateByTypeAndParticipantKey;
import curam.core.facade.struct.ListTemplateByTypeAndParticpant;
import curam.core.facade.struct.MaintainCitizenshipDetails;
import curam.core.facade.struct.MaintainConcernRoleKey;
import curam.core.facade.struct.MaintainParticipantAddressDetails;
import curam.core.facade.struct.MaintainParticipantAlternateIDDetails;
import curam.core.facade.struct.MaintainParticipantBankAccountDetails;
import curam.core.facade.struct.MaintainParticipantBankAccountWithTextSortCodeDetails;
import curam.core.facade.struct.MaintainParticipantCommunicationExceptionDetails;
import curam.core.facade.struct.MaintainParticipantEmailAddressDetails;
import curam.core.facade.struct.MaintainParticipantPhoneDetails;
import curam.core.facade.struct.MaintainPersonAlternativeNameDetails;
import curam.core.facade.struct.MaintainPersonDetails;
import curam.core.facade.struct.MaintainPersonEducationDetails;
import curam.core.facade.struct.MaintainPersonEmploymentDetails;
import curam.core.facade.struct.MaintainPersonForeignResidencyDetails;
import curam.core.facade.struct.MaintainPersonRelationships;
import curam.core.facade.struct.MaintainProspectPersonDtls;
import curam.core.facade.struct.MaintainProspectPersonRelationshipDetails;
import curam.core.facade.struct.MaintainUtilityPaymentsDetails;
import curam.core.facade.struct.ModifedEmploymentDetails;
import curam.core.facade.struct.ModifiedAddressDetails;
import curam.core.facade.struct.ModifiedAlternateIDDetails;
import curam.core.facade.struct.ModifiedAlternateNameDetails;
import curam.core.facade.struct.ModifiedCitizenshipDetails;
import curam.core.facade.struct.ModifiedEducationDetails;
import curam.core.facade.struct.ModifiedEmploymentWorkingHourDetails;
import curam.core.facade.struct.ModifiedForeignResidencyDetails;
import curam.core.facade.struct.ModifiedRelationshipDetails;
import curam.core.facade.struct.ModifyCommDetails;
import curam.core.facade.struct.ModifyConcernContactDetails;
import curam.core.facade.struct.ModifyContactDetails;
import curam.core.facade.struct.ModifyEmploymentWorkingHourDetails;
import curam.core.facade.struct.ModifyParticipantNoteDetails;
import curam.core.facade.struct.ModifyParticipantNoteDetails1;
import curam.core.facade.struct.ModifySentCommunicationDetails;
import curam.core.facade.struct.ParticipantAddressStringList;
import curam.core.facade.struct.ParticipantAdministratorDetails;
import curam.core.facade.struct.ParticipantAdministratorDetailsList;
import curam.core.facade.struct.ParticipantAssessmentsList;
import curam.core.facade.struct.ParticipantBankAccountRedirectionKey;
import curam.core.facade.struct.ParticipantBankAccountRedirectionKey1;
import curam.core.facade.struct.ParticipantBankAccountStringList;
import curam.core.facade.struct.ParticipantCommunicationKey;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ParticipantContextDetails;
import curam.core.facade.struct.ParticipantContextKey;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.facade.struct.ParticipantInvestigationList;
import curam.core.facade.struct.ParticipantKey;
import curam.core.facade.struct.ParticipantNoteDetails;
import curam.core.facade.struct.ParticipantNoteKey;
import curam.core.facade.struct.ParticipantNoteList;
import curam.core.facade.struct.ParticipantNoteList1;
import curam.core.facade.struct.ParticipantScreeningList;
import curam.core.facade.struct.ParticipantWebAddressDetails;
import curam.core.facade.struct.ParticipantWebAddressKey;
import curam.core.facade.struct.ParticipantWebAddressList;
import curam.core.facade.struct.ParticipantWebAddressListKey;
import curam.core.facade.struct.PersonAlternateIDSearchKey;
import curam.core.facade.struct.PersonAndProspectPersonSearchResult;
import curam.core.facade.struct.PersonNameAndAddressDetails;
import curam.core.facade.struct.PersonNameRMDtlsList;
import curam.core.facade.struct.PersonReadDtls;
import curam.core.facade.struct.PersonRegistrationDetails;
import curam.core.facade.struct.PersonRegistrationResult;
import curam.core.facade.struct.PersonSearchDetailsResult;
import curam.core.facade.struct.PersonSearchFurtherDtls;
import curam.core.facade.struct.PersonSearchKey;
import curam.core.facade.struct.PersonSearchKey1;
import curam.core.facade.struct.PersonSearchMaintainConcernRoleKey;
import curam.core.facade.struct.PersonSearchResult;
import curam.core.facade.struct.PersonSearchResult1;
import curam.core.facade.struct.PrintCommunicationKey;
import curam.core.facade.struct.ProspectPersonRegistrationDetails;
import curam.core.facade.struct.ProspectPersonRegistrationResult;
import curam.core.facade.struct.ProspectPersonSearchKey;
import curam.core.facade.struct.ProspectPersonSearchResult;
import curam.core.facade.struct.RaceCodeList;
import curam.core.facade.struct.ReadActiveBankAccountList;
import curam.core.facade.struct.ReadAddressHistoryList;
import curam.core.facade.struct.ReadAddressHistoryListKey;
import curam.core.facade.struct.ReadAttachmentKey;
import curam.core.facade.struct.ReadCitizenshipDetails;
import curam.core.facade.struct.ReadCitizenshipHistoryList;
import curam.core.facade.struct.ReadCitizenshipHistoryListKey;
import curam.core.facade.struct.ReadCitizenshipKey;
import curam.core.facade.struct.ReadCitizenshipList;
import curam.core.facade.struct.ReadCitizenshipListKey;
import curam.core.facade.struct.ReadCommDetails;
import curam.core.facade.struct.ReadCommKey;
import curam.core.facade.struct.ReadCommunicationAttachmentDetails;
import curam.core.facade.struct.ReadConcernContactDetails;
import curam.core.facade.struct.ReadContactDetails;
import curam.core.facade.struct.ReadContactKey;
import curam.core.facade.struct.ReadDuplicateParticipantConcernRoleList;
import curam.core.facade.struct.ReadDuplicateParticipantDeductionList;
import curam.core.facade.struct.ReadEducationDetails;
import curam.core.facade.struct.ReadEducationDetailsList;
import curam.core.facade.struct.ReadEducationHistoryList;
import curam.core.facade.struct.ReadEducationHistoryListKey;
import curam.core.facade.struct.ReadEducationListByConcernKey;
import curam.core.facade.struct.ReadEmploymentDetails;
import curam.core.facade.struct.ReadEmploymentDetailsWithMsgList;
import curam.core.facade.struct.ReadEmploymentHistoryList;
import curam.core.facade.struct.ReadEmploymentHistoryListKey;
import curam.core.facade.struct.ReadEmploymentKey;
import curam.core.facade.struct.ReadEmploymentWorkingHourDetails;
import curam.core.facade.struct.ReadEmploymentWorkingHourHistoryList;
import curam.core.facade.struct.ReadEmploymentWorkingHourHistoryListKey;
import curam.core.facade.struct.ReadInteractionDetails;
import curam.core.facade.struct.ReadInteractionKey;
import curam.core.facade.struct.ReadParticipantActiveAddressList;
import curam.core.facade.struct.ReadParticipantAddressDetails;
import curam.core.facade.struct.ReadParticipantAddressKey;
import curam.core.facade.struct.ReadParticipantAddressList;
import curam.core.facade.struct.ReadParticipantAddressListKey;
import curam.core.facade.struct.ReadParticipantAdminRoleList;
import curam.core.facade.struct.ReadParticipantAdminRoleListKey;
import curam.core.facade.struct.ReadParticipantAltIDHistoryList;
import curam.core.facade.struct.ReadParticipantAltIDHistoryListKey;
import curam.core.facade.struct.ReadParticipantAlternateIDDetails;
import curam.core.facade.struct.ReadParticipantAlternateIDKey;
import curam.core.facade.struct.ReadParticipantAlternateIDList;
import curam.core.facade.struct.ReadParticipantAlternateIDListKey;
import curam.core.facade.struct.ReadParticipantBankAcHistoryList;
import curam.core.facade.struct.ReadParticipantBankAcHistoryListKey;
import curam.core.facade.struct.ReadParticipantBankAccountDetails;
import curam.core.facade.struct.ReadParticipantBankAccountKey;
import curam.core.facade.struct.ReadParticipantBankAccountList;
import curam.core.facade.struct.ReadParticipantBankAccountListKey;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionDetails;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionKey;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionList;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionListKey;
import curam.core.facade.struct.ReadParticipantConcernRoleKey;
import curam.core.facade.struct.ReadParticipantConcernRoleList;
import curam.core.facade.struct.ReadParticipantDeductionList;
import curam.core.facade.struct.ReadParticipantDeductionList1;
import curam.core.facade.struct.ReadParticipantEmailAddressDetails;
import curam.core.facade.struct.ReadParticipantEmailAddressKey;
import curam.core.facade.struct.ReadParticipantEmailAddressList;
import curam.core.facade.struct.ReadParticipantEmailAddressListKey;
import curam.core.facade.struct.ReadParticipantFormattedAddressListKey;
import curam.core.facade.struct.ReadParticipantFormattedBankAccountListKey;
import curam.core.facade.struct.ReadParticipantNoteDetails;
import curam.core.facade.struct.ReadParticipantNoteDetails1;
import curam.core.facade.struct.ReadParticipantPhoneNumberDetails;
import curam.core.facade.struct.ReadParticipantPhoneNumberKey;
import curam.core.facade.struct.ReadParticipantPhoneNumberList;
import curam.core.facade.struct.ReadParticipantPhoneNumberListKey;
import curam.core.facade.struct.ReadParticipantWebAddressDetails;
import curam.core.facade.struct.ReadPersonAlternativeNameListKey;
import curam.core.facade.struct.ReadPersonDetails;
import curam.core.facade.struct.ReadPersonEmploymentListKey;
import curam.core.facade.struct.ReadPersonForeignResidencyDetails;
import curam.core.facade.struct.ReadPersonForeignResidencyDetailsList;
import curam.core.facade.struct.ReadPersonForeignResidencyHistoryList;
import curam.core.facade.struct.ReadPersonForeignResidencyHistoryListKey;
import curam.core.facade.struct.ReadPersonForeignResidencyKey;
import curam.core.facade.struct.ReadPersonForeignResidencyListKey;
import curam.core.facade.struct.ReadPersonHistoryList;
import curam.core.facade.struct.ReadPersonHistoryListKey;
import curam.core.facade.struct.ReadPersonHomeDetails;
import curam.core.facade.struct.ReadPersonHomeKey;
import curam.core.facade.struct.ReadPersonKey;
import curam.core.facade.struct.ReadPersonNameDetails;
import curam.core.facade.struct.ReadPersonNameHistoryList;
import curam.core.facade.struct.ReadPersonNameHistoryListKey;
import curam.core.facade.struct.ReadPersonNameKey;
import curam.core.facade.struct.ReadPersonRelationshipDetails;
import curam.core.facade.struct.ReadPersonRelationshipDetailsKey;
import curam.core.facade.struct.ReadPersonRelationshipList;
import curam.core.facade.struct.ReadPersonRelationshipListKey;
import curam.core.facade.struct.ReadProspectPersonDtls;
import curam.core.facade.struct.ReadProspectPersonHistoryList;
import curam.core.facade.struct.ReadProspectPersonHistoryListKey;
import curam.core.facade.struct.ReadProspectPersonHomeDetails;
import curam.core.facade.struct.ReadProspectPersonHomeKey;
import curam.core.facade.struct.ReadProspectPersonKey;
import curam.core.facade.struct.ReadRelationshipHistoryList;
import curam.core.facade.struct.ReadRelationshipHistoryListKey;
import curam.core.facade.struct.ReadUtilityPaymentDetails;
import curam.core.facade.struct.ReadUtilityPaymentKey;
import curam.core.facade.struct.ReadUtilityPaymentsList;
import curam.core.facade.struct.ReadUtilityPaymentsListKey;
import curam.core.facade.struct.RecordExistingCommunicationDetails;
import curam.core.facade.struct.SearchCaseDetails;
import curam.core.facade.struct.SearchCaseDetails1;
import curam.core.facade.struct.SearchCaseKey_fo;
import curam.core.facade.struct.SearchCasesByConcernRoleKey;
import curam.core.facade.struct.SearchCasesForDuplicateDetails;
import curam.core.facade.struct.SearchCasesForDuplicateDetails1;
import curam.core.facade.struct.SearchWithNicknames;
import curam.core.facade.struct.SendEmailCommKey;
import curam.core.facade.struct.TasksForConcernAndCaseDetails;
import curam.core.facade.struct.TasksForDuplicateConcernAndCaseDetails;
import curam.core.facade.struct.UpdateBankAccPaymentDtlsKey;
import curam.core.fact.MaintainProspectPersonFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.MaintainProspectPerson;
import curam.core.sl.fact.ProspectPersonSearchRouterFactory;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.struct.ECWarningsDtls;
import curam.core.sl.intf.ProspectPersonSearchRouter;
import curam.core.sl.struct.ProspectPersonHomeDetails;
import curam.core.sl.struct.ProspectPersonRegistrationDtls;
import curam.core.struct.BankAccountRMDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PersonReadDtlsList;
import curam.message.BPOADDRESS;
import curam.message.BPOPROSPECTPERSONREGISTRATION;
import curam.message.BPOPROSPECTPERSONSEARCH;
import curam.message.SEPARATOR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.message.CatEntry;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.StringList;


/**
 * This process class provides the functionality for the Prospect Person
 * presentation layer.
 */
public abstract class ProspectPerson extends curam.core.facade.base.ProspectPerson {

  // BEGIN, CR00228866, DJ
  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kParamConcernRoleID = XmlMetaDataConst.kParamConcernRoleID;

  protected static final String kCommaSpace = CuramConst.gkComma
    + CuramConst.gkSpace;

  @Deprecated
  protected static final String kSeparator = SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;

  // BEGIN, CR00238338, PF
  @Deprecated
  protected static final int kMinimumPhoneNumberLength = CuramConst.gkMinimumPhoneNumberLength;
  // END, CR00238338
  // END, CR00228866


  /**
   * This method registers a given Prospect Person as a Person Participant
   *
   * @param key -
   * The Prospect Person key to be registered as a person
   * @param prospectPersonRegistrationDetails -
   * the Person details
   * @return - the details resulting from the person registration process
   * @throws AppException
   * @throws InformationalException
   */
  public ProspectPersonRegistrationResult registerProspectPersonAsPerson(
    ReadProspectPersonKey key,
    ProspectPersonRegistrationDetails prospectPersonRegistrationDetails)
    throws AppException, InformationalException {
    curam.core.sl.intf.RegisterProspectPerson registerProspectPersonObj = curam.core.sl.fact.RegisterProspectPersonFactory.newInstance();

    ProspectPersonRegistrationResult prospectPersonRegistrationResult = new ProspectPersonRegistrationResult();

    // BEGIN, CR00108252, PA
    // It checks for the indigenous person indicator, if indicator is true and
    // indigenous group code is empty then throws AppException
    if (!prospectPersonRegistrationDetails.prospectPersonRegistrationDtls.indigenousPersonInd
      && !prospectPersonRegistrationDetails.prospectPersonRegistrationDtls.indigenousGroupCode.equalsIgnoreCase(
        CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOPROSPECTPERSONREGISTRATION.ERR_XFV_INDIGENOUS_PROSPECT_PERSON_INDICATOR_CHECK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }
    // END, CR00108252, PA

    prospectPersonRegistrationResult.registrationIDDetails = registerProspectPersonObj.registerProspectPersonAsPerson(
      key.maintainConcernRoleKey,
      prospectPersonRegistrationDetails.prospectPersonRegistrationDtls);

    // BEGIN, CR00078486, POH
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      prospectPersonRegistrationResult.warnings.dtls.addRef(ecWarningsDtls);
    }
    // END, CR00078486

    return prospectPersonRegistrationResult;
  }

  /**
   * This method return the Prospect Person Home Page Details
   *
   * @param key
   * The Prospect Person Key
   * @return Prospect Person Home Page Details
   * @throws AppException
   * @throws InformationalException
   */
  public ReadProspectPersonHomeDetails readHomePageDetails(
    ReadProspectPersonHomeKey key) throws AppException,
      InformationalException {

    // Prospect Person Home Page object.
    curam.core.sl.intf.ProspectPersonHome prospectPersonHomeObj = curam.core.sl.fact.ProspectPersonHomeFactory.newInstance();

    // Details to be returned.
    ReadProspectPersonHomeDetails readProspectPersonHomeDetails = new ReadProspectPersonHomeDetails();

    // Struct returned from ProspectPersonHomePage read.
    ProspectPersonHomeDetails prospectPersonHomeDetails;

    // BEGIN, CR00105372, CSH
    // Client Merge manipulation variables
    curam.core.sl.intf.ClientMerge clientMergeObj = curam.core.sl.fact.ClientMergeFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // END, CR00105372

    // Read the Person Home Page details
    prospectPersonHomeDetails = prospectPersonHomeObj.read(
      key.concernRoleHomePageKey);

    // BEGIN, CR00108252, PA

    String regionDescription = null;
    String groupDescription = null;

    StringBuffer stringTypeCode = new StringBuffer();

    StringList indigenousTabList;

    // Check whether this prospect person associated with a Indigenous Group
    if (!prospectPersonHomeDetails.dtls.indigenousGroupCode.equalsIgnoreCase(
      CuramConst.gkEmpty)) {

      indigenousTabList = StringUtil.delimitedText2StringListWithTrim(
        prospectPersonHomeDetails.dtls.indigenousGroupCode,
        CuramConst.gkTabDelimiterChar);
      // Appending region description with group description separating by dash
      // for an Indigenous Group
      for (int j = 0; j < indigenousTabList.size(); j++) {
        if (!indigenousTabList.item(j).equalsIgnoreCase(CuramConst.gkEmpty)) {
          // BEGIN, CR00163098, JC
          regionDescription = CodeTable.getOneItem(
            INDIGENOUSREGIONCODE.TABLENAME,
            CodeTable.getParentCode(INDIGENOUSGROUPCODE.TABLENAME,
            indigenousTabList.item(j)),
            TransactionInfo.getProgramLocale());
          groupDescription = CodeTable.getOneItem(INDIGENOUSGROUPCODE.TABLENAME,
            indigenousTabList.item(j), TransactionInfo.getProgramLocale());
          // END, CR00163098, JC

          stringTypeCode.append(regionDescription);
          stringTypeCode.append(CuramConst.gkDash);
          stringTypeCode.append(groupDescription);

          if (j < indigenousTabList.size() - 1) {
            stringTypeCode.append(CuramConst.gkComma);
          }
        }
      }
      prospectPersonHomeDetails.dtls.indigenousGroupCode = stringTypeCode.toString();
    }

    stringTypeCode = new StringBuffer();
    StringList raceTypeTabList;

    raceTypeTabList = StringUtil.delimitedText2StringListWithTrim(
      prospectPersonHomeDetails.dtls.race, CuramConst.gkTabDelimiterChar);
    // Appending all the races description and separating with Comma
    for (int j = 0; j < raceTypeTabList.size(); j++) {
      // BEGIN, CR00163098, JC
      stringTypeCode.append(
        CodeTable.getOneItem(RACECODE.TABLENAME, raceTypeTabList.item(j),
        TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC
      if (j < raceTypeTabList.size() - 1) {
        stringTypeCode.append(CuramConst.gkComma);
      }
    }
    prospectPersonHomeDetails.dtls.race = stringTypeCode.toString();

    // END, CR00108252, PA

    readProspectPersonHomeDetails.prospectPersonHomeDetails.assign(
      prospectPersonHomeDetails.dtls);
    readProspectPersonHomeDetails.informationalMsgDtlsList = prospectPersonHomeDetails.informationalMsgDtlsList;

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    readProspectPersonHomeDetails.participantContextDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // BEGIN, CR00105372, CSH
    // Check if this prospect has been marked as a duplicate
    concernRoleKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    // The indicator is set to true if the prospect has been
    // marked as a duplicate
    readProspectPersonHomeDetails.statusInd.statusInd = clientMergeObj.isConcernRoleDuplicate(concernRoleKey).statusInd;
    // END, CR00105372

    // BEGIN, CR00386007, VT
    if (CuramConst.gkMinusOne
      == readProspectPersonHomeDetails.prospectPersonHomeDetails.fromAge) {

      readProspectPersonHomeDetails.prospectPersonHomeDetails.estimatedFromAgeOpt = CuramConst.gkStringZero;

    } else if (CuramConst.gkZero
      == readProspectPersonHomeDetails.prospectPersonHomeDetails.fromAge) {

      readProspectPersonHomeDetails.prospectPersonHomeDetails.estimatedFromAgeOpt = CuramConst.gkEmpty;

    } else {

      readProspectPersonHomeDetails.prospectPersonHomeDetails.estimatedFromAgeOpt = Integer.toString(
        readProspectPersonHomeDetails.prospectPersonHomeDetails.fromAge);

    }

    if (CuramConst.gkMinusOne
      == readProspectPersonHomeDetails.prospectPersonHomeDetails.toAge) {

      readProspectPersonHomeDetails.prospectPersonHomeDetails.estimatedToAgeOpt = CuramConst.gkStringZero;

    } else if (CuramConst.gkZero
      == readProspectPersonHomeDetails.prospectPersonHomeDetails.toAge) {

      readProspectPersonHomeDetails.prospectPersonHomeDetails.estimatedToAgeOpt = CuramConst.gkEmpty;

    } else {

      readProspectPersonHomeDetails.prospectPersonHomeDetails.estimatedToAgeOpt = Integer.toString(
        readProspectPersonHomeDetails.prospectPersonHomeDetails.toAge);

    }   
    // END, CR00386007

    // BEGIN, CR00100098, CSH
    // Create an informational manager
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Read any informationals returned from service layer
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      readProspectPersonHomeDetails.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00100098

    // Return the details.
    return readProspectPersonHomeDetails;
  }

  /**
   * This method searches for prospect persons depending on the search criteria
   * contained in the ProspectPersonSearchKey
   *
   * @param key -
   * the search criteria.
   *
   * @return List of Prospect Persons matching the search criteria
   * @throws AppException
   * @throws InformationalException
   */
  public ProspectPersonSearchResult searchProspectPersons(
    ProspectPersonSearchKey key) throws AppException, InformationalException {

    // Prospect Person Search object and key.
    curam.core.sl.intf.ProspectPersonSearchRouter prospectPersonSearchRouterObj = curam.core.sl.fact.ProspectPersonSearchRouterFactory.newInstance();
    curam.core.sl.struct.ProspectPersonSearchKey prospectPersonSearchKey;

    // Details to be returned.
    curam.core.facade.struct.ProspectPersonSearchResult prospectPersonSearchResult = new curam.core.facade.struct.ProspectPersonSearchResult();

    // Get the details for the search from the search key.
    prospectPersonSearchKey = key.prospectPersonSearchKey;

    prospectPersonSearchResult.prospectPersonSearchResult = prospectPersonSearchRouterObj.searchProspectPersons(
      prospectPersonSearchKey);

    for (int i = 0; i
      < prospectPersonSearchResult.prospectPersonSearchResult.ppDetails.dtls.size(); i++) {

      prospectPersonSearchResult.prospectPersonSearchResult.ppDetails.dtls.item(i).personFullName = prospectPersonSearchResult.prospectPersonSearchResult.ppDetails.dtls.item(i).forename
        + CuramConst.gkSpace
        + prospectPersonSearchResult.prospectPersonSearchResult.ppDetails.dtls.item(i).surname;
      // BEGIN CR00096360, PN
      // BEGIN CR00096008, PN
      // BEGIN, CR00190258, CL
      // BEGIN, CR00214655, PB
      // BEGIN, CR00340652, KRK
      if (BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(TransactionInfo.getProgramLocale()).equals(
        prospectPersonSearchResult.prospectPersonSearchResult.ppDetails.dtls.item(i).address)) // END, CR00340652
      // END, CR00214655
      {
        prospectPersonSearchResult.prospectPersonSearchResult.ppDetails.dtls.item(i).address = CuramConst.gkEmpty;
      }

      // END CR00096008
      // END CR00096360
      // BEGIN, CR00214655, PB
      // BEGIN, CR00340652, KRK
      if (BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(TransactionInfo.getProgramLocale()).equals(
        prospectPersonSearchResult.prospectPersonSearchResult.ppDetails.dtls.item(i).city)) // END, CR00340652
      // END, CR00214655
      {
        prospectPersonSearchResult.prospectPersonSearchResult.ppDetails.dtls.item(i).city = CuramConst.gkEmpty;
      }
      // END, CR00190258
    }
    PersonAndProspectPersonSearchResult result = new PersonAndProspectPersonSearchResult();

    result.personAndProspectPersonSearchResult.ppDetails.assign(
      prospectPersonSearchResult.prospectPersonSearchResult.ppDetails);

    prospectPersonSearchResult.prospectPersonSearchResult.ppDetails.assign(
      result.personAndProspectPersonSearchResult.ppDetails);

    // Return the details.
    return prospectPersonSearchResult;
  }

  /**
   * This method registers a prospect person with the organization
   *
   * @param details -
   * details of the prospect person to be registered
   *
   * @return details resulting out from the registration operation
   * @throws AppException
   * @throws InformationalException
   */
  public ProspectPersonRegistrationResult registerProspectPerson(
    ProspectPersonRegistrationDetails details) throws AppException,
      InformationalException {
    // BEGIN, CR00190252, NP
    // Validate prospect person name limits
    validateProspectPersonName(details.prospectPersonRegistrationDtls);
    // END, CR00190252
    
    // BEGIN, CR00386007, VT
    validateProspectPersonEstimatedAge(details.prospectPersonRegistrationDtls);

    if (CuramConst.gkStringZero.equals(
      details.prospectPersonRegistrationDtls.estimatedFromAgeOpt)) {

      details.prospectPersonRegistrationDtls.fromAge = CuramConst.gkMinusOne;

    } else if (details.prospectPersonRegistrationDtls.estimatedFromAgeOpt.isEmpty()) {

      details.prospectPersonRegistrationDtls.fromAge = CuramConst.gkZero;

    } else {

      details.prospectPersonRegistrationDtls.fromAge = Integer.parseInt(
        details.prospectPersonRegistrationDtls.estimatedFromAgeOpt);

    }

    if (CuramConst.gkStringZero.equals(
      details.prospectPersonRegistrationDtls.estimatedToAgeOpt)) {

      details.prospectPersonRegistrationDtls.toAge = CuramConst.gkMinusOne;

    } else if (details.prospectPersonRegistrationDtls.estimatedToAgeOpt.isEmpty()) {

      details.prospectPersonRegistrationDtls.toAge = CuramConst.gkZero;

    } else {

      details.prospectPersonRegistrationDtls.toAge = Integer.parseInt(
        details.prospectPersonRegistrationDtls.estimatedToAgeOpt);
    }

    // END, CR00386007

    // Prospect Person Registration object
    curam.core.sl.intf.RegisterProspectPerson registerProspectPersonObj = curam.core.sl.fact.RegisterProspectPersonFactory.newInstance();

    // Details to be returned
    ProspectPersonRegistrationResult prospectPersonRegistrationResult = new ProspectPersonRegistrationResult();

    // Set the addressType to private
    details.prospectPersonRegistrationDtls.addressType = curam.codetable.CONCERNROLEADDRESSTYPE.PRIVATE;

    // BEGIN, CR00108252, PA
    // It checks for the indigenous person indicator, if indicator is true and
    // indigenous group code is empty then throws AppException
    // BEGIN, CR00114322, PA
    if (!details.prospectPersonRegistrationDtls.indigenousPersonInd
      && !details.prospectPersonRegistrationDtls.indigenousGroupCode.equalsIgnoreCase(
        CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOPROSPECTPERSONREGISTRATION.ERR_XFV_INDIGENOUS_PROSPECT_PERSON_INDICATOR_CHECK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00114322, PA
    // END, CR00108252, PA

    // Register Prospect Person
    prospectPersonRegistrationResult.registrationIDDetails = registerProspectPersonObj.registerProspectPerson(
      details.prospectPersonRegistrationDtls);

    // BEGIN, CR00078486, POH
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      prospectPersonRegistrationResult.warnings.dtls.addRef(ecWarningsDtls);
    }
    // END, CR00078486

    // Return details
    return prospectPersonRegistrationResult;
  }

  /**
   * This method reads a given Prospect person record based on the passed
   * ReadProspectPersonKey
   *
   * @param key -
   * The Prospect Person key of the record to be read
   * @return - the prospect person details
   * @throws AppException
   * @throws InformationalException
   */
  public ReadProspectPersonDtls readProspectPerson(ReadProspectPersonKey key)
    throws AppException, InformationalException {

    // Prospect Person maintenance objects
    curam.core.sl.intf.ProspectPersonMaintenance prospectPersonMaintenanceObj = curam.core.sl.fact.ProspectPersonMaintenanceFactory.newInstance();

    // Output structure
    ReadProspectPersonDtls readProspectPersonDtls = new ReadProspectPersonDtls();

    curam.core.sl.struct.ReadProspectPersonDtls readProspectPersonSLDtls = prospectPersonMaintenanceObj.readProspectPerson(
      key.maintainConcernRoleKey);

    // BEGIN, CR00108252, PA
    String regionDescription = null;
    String groupDescription = null;

    StringBuffer stringTypeCode = new StringBuffer();

    StringList indigenousTabList;

    // Check whether this prospect person associated with a Indigenous Group
    if (!readProspectPersonSLDtls.dtls.indigenousGroupCode.equalsIgnoreCase(
      CuramConst.gkEmpty)) {

      indigenousTabList = StringUtil.delimitedText2StringListWithTrim(
        readProspectPersonSLDtls.dtls.indigenousGroupCode,
        CuramConst.gkTabDelimiterChar);
      // Appending region description with group description separating by dash
      // for an Indigenous Group
      for (int j = 0; j < indigenousTabList.size(); j++) {

        if (!indigenousTabList.item(j).equalsIgnoreCase(CuramConst.gkEmpty)) {
          // BEGIN, CR00163098, JC
          regionDescription = CodeTable.getOneItem(
            INDIGENOUSREGIONCODE.TABLENAME,
            CodeTable.getParentCode(INDIGENOUSGROUPCODE.TABLENAME,
            indigenousTabList.item(j)),
            TransactionInfo.getProgramLocale());
          groupDescription = CodeTable.getOneItem(INDIGENOUSGROUPCODE.TABLENAME,
            indigenousTabList.item(j), TransactionInfo.getProgramLocale());
          // END, CR00163098, JC

          stringTypeCode.append(regionDescription);
          stringTypeCode.append(CuramConst.gkDash);
          stringTypeCode.append(groupDescription);

          if (j < indigenousTabList.size() - 1) {
            stringTypeCode.append(CuramConst.gkComma);
          }
        }
        readProspectPersonSLDtls.dtls.indigenousGroupName = stringTypeCode.toString();
      }
    }
    // END, CR00108252, PA

    readProspectPersonDtls.dtls.assign(readProspectPersonSLDtls.dtls);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = readProspectPersonDtls.dtls.concernRoleID;

    readProspectPersonDtls.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);
    
    // BEGIN, CR00386007, VT
    if (CuramConst.gkMinusOne == readProspectPersonDtls.dtls.fromAge) {

      readProspectPersonDtls.dtls.estimatedFromAgeOpt = CuramConst.gkStringZero;

    } else if (CuramConst.gkZero == readProspectPersonDtls.dtls.fromAge) {

      readProspectPersonDtls.dtls.estimatedFromAgeOpt = CuramConst.gkEmpty;

    } else {

      readProspectPersonDtls.dtls.estimatedFromAgeOpt = Integer.toString(
        readProspectPersonDtls.dtls.fromAge);
    }

    if (CuramConst.gkMinusOne == readProspectPersonDtls.dtls.toAge) {

      readProspectPersonDtls.dtls.estimatedToAgeOpt = CuramConst.gkStringZero;

    } else if (CuramConst.gkZero == readProspectPersonDtls.dtls.toAge) {

      readProspectPersonDtls.dtls.estimatedToAgeOpt = CuramConst.gkEmpty;

    } else {

      readProspectPersonDtls.dtls.estimatedToAgeOpt = Integer.toString(
        readProspectPersonDtls.dtls.toAge);
    }
    // END, CR00386007

    // Return details
    return readProspectPersonDtls;
  }

  /**
   * This method modifies the Prospect Person information
   *
   * @param maintainProspectPersonDtls
   * -the updated details of the Prospect Person
   * @return any important messages resulting out due to the modify operation
   * @throws AppException
   * @throws InformationalException
   */
  public InformationalMsgDetailsList modifyProspectPerson(
    MaintainProspectPersonDtls maintainProspectPersonDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00190252, NP
    // Validate prospect person name limits
    ProspectPersonRegistrationDtls prospectPersonDetails = new ProspectPersonRegistrationDtls();

    prospectPersonDetails.assign(maintainProspectPersonDtls.dtls);
    validateProspectPersonName(prospectPersonDetails);
    
    // BEGIN, CR00386007, VT
    validateProspectPersonEstimatedAge(prospectPersonDetails);

    if (CuramConst.gkStringZero.equals(
      prospectPersonDetails.estimatedFromAgeOpt)) {

      maintainProspectPersonDtls.dtls.fromAge = CuramConst.gkMinusOne;

    } else if (prospectPersonDetails.estimatedFromAgeOpt.isEmpty()) {

      maintainProspectPersonDtls.dtls.fromAge = CuramConst.gkZero;

    } else {

      maintainProspectPersonDtls.dtls.fromAge = Integer.parseInt(
        prospectPersonDetails.estimatedFromAgeOpt);

    }

    if (CuramConst.gkStringZero.equals(prospectPersonDetails.estimatedToAgeOpt)) {

      maintainProspectPersonDtls.dtls.toAge = CuramConst.gkMinusOne;

    } else if (maintainProspectPersonDtls.dtls.estimatedToAgeOpt.isEmpty()) {

      maintainProspectPersonDtls.dtls.toAge = CuramConst.gkZero;

    } else {

      maintainProspectPersonDtls.dtls.toAge = Integer.parseInt(
        prospectPersonDetails.estimatedToAgeOpt);
    }
    // END, CR00386007
    
    // END, CR00190252
    // Maintain Prospect Person object.
    curam.core.sl.intf.ProspectPersonMaintenance prospectPersonMaintenanceObj = curam.core.sl.fact.ProspectPersonMaintenanceFactory.newInstance();

    // Details to be returned.
    InformationalMsgDetailsList informationalMsgDetailsList = new InformationalMsgDetailsList();

    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Get the Concern Role ID from the details.
    maintainConcernRoleKey.concernRoleID = maintainProspectPersonDtls.dtls.concernRoleID;

    // BEGIN, CR00108252, PA
    // It checks for the indigenous person indicator, if indicator is true and
    // indigenous group code is empty then throws AppException
    // BEGIN, CR00114322, PA
    if (!maintainProspectPersonDtls.dtls.indigenousPersonInd
      && !maintainProspectPersonDtls.dtls.indigenousGroupCode.equalsIgnoreCase(
        CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOPROSPECTPERSONREGISTRATION.ERR_XFV_INDIGENOUS_PROSPECT_PERSON_INDICATOR_CHECK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // END, CR00114322, PA
    // END, CR00108252, PA

    // Modify the Prospect Person
    prospectPersonMaintenanceObj.modifyProspectPerson(maintainConcernRoleKey,
      maintainProspectPersonDtls.dtls);

    // Create an informational manager
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      informationalMsgDetailsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // Return the details.
    return informationalMsgDetailsList;
  }

  /**
   * This method searches for prospect persons and persons depending on the
   * search criteria contained in the ProspectPersonSearchKey
   *
   * @param key -
   * the search criteria.
   * @return List of Persons and Prospect Persons satisfying the search criteria
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #searchPersons1}. See release note: <CR00229427>
   */
  @Deprecated
  public PersonAndProspectPersonSearchResult searchPersonsAndProspectPersons(
    ProspectPersonSearchKey key) throws AppException, InformationalException {

    // Prospect Person Search object.
    ProspectPersonSearchRouter prospectPersonSearchRouterObj = ProspectPersonSearchRouterFactory.newInstance();

    // Details to be returned.
    PersonAndProspectPersonSearchResult result = new PersonAndProspectPersonSearchResult();
    curam.core.sl.struct.PersonAndProspectPersonSearchResult personAndProspectPersonSearchResult;

    // register the security implementation
    SecurityImplementationFactory.register();

    // Call the search.
    personAndProspectPersonSearchResult = prospectPersonSearchRouterObj.searchPersonsAndProspectPersons(
      key.prospectPersonSearchKey);

    result.personAndProspectPersonSearchResult = personAndProspectPersonSearchResult;
    // BEGIN CR00080155,PN
    result.personIndicator = 0;
    result.prospectPersonIndicator = 0;
    // END CR00080155

    // BEGIN CR00052179, PN
    for (int i = 0; i
      < result.personAndProspectPersonSearchResult.ppDetails.dtls.size(); i++) {

      result.personAndProspectPersonSearchResult.ppDetails.dtls.item(i).personFullName = result.personAndProspectPersonSearchResult.ppDetails.dtls.item(i).forename

        + CuramConst.gkSpace

        + result.personAndProspectPersonSearchResult.ppDetails.dtls.item(i).surname;
      // BEGIN CR00096360, PN
      // BEGIN CR00096008, PN
      // BEGIN, CR00190258, CL
      // BEGIN, CR00222190, ELG
      // BEGIN, CR00340652, KRK
      if (BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(TransactionInfo.getProgramLocale()).equals(
        result.personAndProspectPersonSearchResult.ppDetails.dtls.item(i).address)) {
        // END, CR00340652
        // END, CR00190258
        result.personAndProspectPersonSearchResult.ppDetails.dtls.item(i).address = CuramConst.gkEmpty;
      }
      // END, CR00222190
      // END CR00096008
      // END CR00096360
      // BEGIN, CR00219204, SW
      // BEGIN, CR00340652, KRK
      if (BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(TransactionInfo.getProgramLocale()).equals(
        result.personAndProspectPersonSearchResult.ppDetails.dtls.item(i).city)) {
        // END, CR00340652
        result.personAndProspectPersonSearchResult.ppDetails.dtls.item(i).city = CuramConst.gkEmpty;
      }
      // END, CR00219204

    }
    for (int i = 0; i
      < result.personAndProspectPersonSearchResult.pDetails.dtls.size(); i++) {

      result.personAndProspectPersonSearchResult.pDetails.dtls.item(i).personFullName = result.personAndProspectPersonSearchResult.pDetails.dtls.item(i).forename

        + CuramConst.gkSpace

        + result.personAndProspectPersonSearchResult.pDetails.dtls.item(i).surname;
      // BEGIN CR00096360, PN
      // BEGIN CR00096008, PN
      // BEGIN, CR00104198, ELG
      // BEGIN, CR00340652, KRK
      if (BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(TransactionInfo.getProgramLocale()).equals(
        result.personAndProspectPersonSearchResult.pDetails.dtls.item(i).address)) {
        // END, CR00340652
        // END, CR00104198
        result.personAndProspectPersonSearchResult.pDetails.dtls.item(i).address = CuramConst.gkEmpty;
      }
      // END CR00096008
      // END CR00096360
      // BEGIN, CR00219204, SW
      // BEGIN, CR00340652, KRK
      if (BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(TransactionInfo.getProgramLocale()).equals(
        result.personAndProspectPersonSearchResult.pDetails.dtls.item(i).city)) {
        // END, CR00340652
        result.personAndProspectPersonSearchResult.pDetails.dtls.item(i).city = CuramConst.gkEmpty;
      }
      // END, CR00219204
    }
    // END CR00052179
    if (personAndProspectPersonSearchResult.pDetails.dtls.size() != 0) {
      CatEntry catEntry = BPOPROSPECTPERSONSEARCH.INF_PERSON_TEXT;

      // BEGIN, CR00163471, JC
      result.person = catEntry.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC
    }

    if (personAndProspectPersonSearchResult.ppDetails.dtls.size() != 0) {
      CatEntry catEntry = BPOPROSPECTPERSONSEARCH.INF_PROSPECTPERSON_TEXT;

      // BEGIN, CR00163471, JC
      result.prospectPerson = catEntry.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC
    }
    // BEGIN CR00080155,PN
    if (personAndProspectPersonSearchResult.pDetails.dtls.size() > 0) {
      result.personIndicator = personAndProspectPersonSearchResult.pDetails.dtls.size();
    }
    if (personAndProspectPersonSearchResult.ppDetails.dtls.size() > 0) {
      result.prospectPersonIndicator = personAndProspectPersonSearchResult.ppDetails.dtls.size();
    }
    // END CR00080155
    return result;

  }

  // BEGIN, CR00229427, DJ
  /**
   * This method searches persons depending on the search criteria contained in
   * the PersonSearchKey
   *
   * @param key -
   * the search criteria.
   * @return List of Persons satisfying the search criteria
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #searchPersons1}. See release note: CR00229427
   */
  @Deprecated
  public PersonSearchResult searchPersons(final PersonSearchKey key)
    throws AppException, InformationalException {

    PersonSearchResult personSearchResult;
    Person delegate = PersonFactory.newInstance();

    personSearchResult = delegate.search(key);
    PersonAndProspectPersonSearchResult result = new PersonAndProspectPersonSearchResult();

    result.personAndProspectPersonSearchResult.pDetails.assign(
      personSearchResult.personSearchResult.details);
    personSearchResult.personSearchResult.details.assign(
      result.personAndProspectPersonSearchResult.pDetails);
    return personSearchResult;
  }

  // BEGIN, CR00282028, IBM
  /**
   * This method searches persons depending on the search criteria contained in
   * the PersonSearchKey.
   *
   * @param key
   * - the search criteria.
   * @return List of Persons satisfying the search criteria
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ProspectPerson#searchPersonDetails(PersonSearchKey1)}.
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchPersonDetails(PersonSearchKey1) which returns the
   * informational message along with person details as well. See
   * release note: CS-09152/CR00282028.
   */
  @Deprecated
  public PersonSearchResult1 searchPersons1(final PersonSearchKey1 key)
    throws AppException, InformationalException {
    // END, CR00282028
    PersonSearchResult1 personSearchResult1;
    Person delegate = PersonFactory.newInstance();

    personSearchResult1 = delegate.search1(key);
    return personSearchResult1;
  }

  // END, CR00229427
  /**
   * This method populates the prospect person registration data on the register
   * prospect person as person page
   *
   * @param key -
   * The Prospect Person Key containing the ConcernRoleID
   * @return The captured Prospect Person registration information
   * @throws AppException
   * @throws InformationalException
   */
  public ProspectPersonRegistrationDetails autoPopulateRegistrationFields(
    ReadProspectPersonKey key) throws AppException, InformationalException {

    // Prospect Person Registration object
    curam.core.sl.intf.RegisterProspectPerson registerProspectPersonObj = curam.core.sl.fact.RegisterProspectPersonFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    // Details to be returned
    ProspectPersonRegistrationDetails prospectPersonRegistrationDetails = new ProspectPersonRegistrationDetails();

    prospectPersonRegistrationDetails.prospectPersonRegistrationDtls = registerProspectPersonObj.autoPopulateRegistrationFields(
      key.maintainConcernRoleKey);

    // Return details
    return prospectPersonRegistrationDetails;
  }

  // BEGIN, CR00077847, POH
  // BEGIN, CR00228866, DJ
  /**
   * This method creates a relationship for a Prospect person with another
   * Prospect person
   *
   * @param details -
   * A struct containing the related prospect person details
   * @return CreatedRelationshipDetails List of informationals - if any exist -
   * to be displayed to user
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public CreatedRelationshipDetails createRelationship(
    final  MaintainProspectPersonRelationshipDetails details)
    throws AppException, InformationalException {

    MaintainPersonRelationships maintainPersonRelationships = new MaintainPersonRelationships();

    maintainPersonRelationships.personRelationshipDetails.assign(
      details.prospectPersonRelationshipDetails);
    CreatedRelationshipDetails createdRelationshipDetails = new CreatedRelationshipDetails();
    Person delegate = PersonFactory.newInstance();

    createdRelationshipDetails = delegate.createRelationship(
      maintainPersonRelationships);
    return createdRelationshipDetails;

  }

  /**
   * This method modifies a relationship for a Prospect person with another
   * Prospect person
   *
   * @param details -
   * A struct containing the related prospect person details
   * @return ModifiedRelationshipDetails List of informationals - if any exist -
   * to be displayed to user
   * @throws AppException
   * @throws InformationalException
   */
  public ModifiedRelationshipDetails modifyRelationship(
    final MaintainProspectPersonRelationshipDetails details)
    throws AppException, InformationalException {

    MaintainPersonRelationships maintainPersonRelationships = new MaintainPersonRelationships();

    maintainPersonRelationships.personRelationshipDetails.assign(
      details.prospectPersonRelationshipDetails);
    ModifiedRelationshipDetails modifiedRelationshipDetails = new ModifiedRelationshipDetails();
    Person delegate = PersonFactory.newInstance();

    modifiedRelationshipDetails = delegate.modifyRelationship(
      maintainPersonRelationships);
    return modifiedRelationshipDetails;
  }

  // END, CR00077847
  // END,CR00228866
  /**
   * This method searches for current prospect persons(who are not persons)
   * depending on the ProspectPersonSearchKey.
   *
   * @param key
   * the search criteria.
   *
   * @return List of Prospect Persons
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ProspectPersonSearchResult searchCurrentProspectPersons(
    ProspectPersonSearchKey key) throws AppException, InformationalException {
    key.prospectPersonSearchKey.currentProspectPersons = true;
    return this.searchProspectPersons(key);
  }

  // BEGIN, CR00065868, PCAL
  // ___________________________________________________________________________
  /**
   * Method returns a list of Prospect Person Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * The Prospect Person record the snapshots are associated with.
   *
   * @return The list of Prospect Person snapshot summary details
   */
  public ReadProspectPersonHistoryList listProspectPersonHistory(
    ReadProspectPersonHistoryListKey key) throws AppException,
      InformationalException {

    // Return struct
    ReadProspectPersonHistoryList readProspectPersonHistoryList = new ReadProspectPersonHistoryList();

    // Retrieve the list of snap shot summary details
    MaintainProspectPerson maintainProspectPersonObj = MaintainProspectPersonFactory.newInstance();

    readProspectPersonHistoryList.historyDtls = maintainProspectPersonObj.listProspectPersonHistory(
      key.historyKey);

    // Get the context description of the Prospect Person Snapshots
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.historyKey.concernRoleID;

    readProspectPersonHistoryList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details
    return readProspectPersonHistoryList;
  }

  // END, CR00065868

  // BEGIN, CR00114322, PA
  /**
   * Reads the informational message for a participant.
   *
   * @param key -
   * It holds the concernRoleID
   *
   * @return informationalMsgDtls = It holds Informational details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMsgDetailsList readInformationalMessage(
    MaintainConcernRoleKey key) throws AppException, InformationalException {

    // Instance of return struct
    curam.core.facade.struct.InformationalMsgDetailsList informationalMsgDetailsList = new curam.core.facade.struct.InformationalMsgDetailsList();

    // calling the readInformationalMessage() method on service layer object
    informationalMsgDetailsList.informationalMsgDtlsList = MaintainProspectPersonFactory.newInstance().readInformationalMessage(
      key.maintainConcernRoleKey);

    return informationalMsgDetailsList;

  }

  // BEGIN, CR00228866, DJ
  // ___________________________________________________________________________
  /**
   * Returns the list of race codes.
   *
   * @return RaceCodeList - It holds the list of race codes.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public RaceCodeList listRace() throws AppException, InformationalException {

    RaceCodeList raceCodeList = new RaceCodeList();
    Person delegate = PersonFactory.newInstance();

    raceCodeList = delegate.listRace();
    return raceCodeList;
  }

  // ___________________________________________________________________________
  /**
   * Method returns a list of Indigenous Groups.
   *
   * @param key -
   * This holds the search value, which is used to search Indigenous
   * groups.
   *
   * @return IndigenousGroupList - The list of Indigenous Groups.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public IndigenousGroupList searchIndigenousGroup(
    final IndigenousGroupSearchKey key)
    throws AppException, InformationalException {

    IndigenousGroupList indigenousGroupList = new IndigenousGroupList();
    Person delegate = PersonFactory.newInstance();

    indigenousGroupList = delegate.searchIndigenousGroup(key);
    return indigenousGroupList;
  }

  // END, CR00228866
  // ___________________________________________________________________________
  // END, CR00114322, PA
  /**
   * This method validates the prospect person name data provided on the register
   * prospect person as person page
   *
   * @param prospectPersonDetails -
   * The Prospect Person details
   *
   * @throws InformationalException
   */
  // BEGIN, CR00190252, NP
  // BEGIN, CR00198672, VK
  protected void validateProspectPersonName(
    ProspectPersonRegistrationDtls prospectPersonDetails)
    throws InformationalException {
    // END, CR00198672
    // Create an informational manager
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (prospectPersonDetails.firstForename.toUpperCase().length()
      > CuramConst.kUpperFIRSTNAME) {

      // create the warning string
      curam.util.exception.LocalisableString infoMessage = new curam.util.exception.LocalisableString(
        curam.message.BPOMAINTAINPERSONNAMES.ERR_FV_UPPERFIRST_NAME_EXCEEDED_LIMIT);

      infoMessage.arg(
        prospectPersonDetails.firstForename.toUpperCase().length()
          - CuramConst.kUpperFIRSTNAME);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, curam.util.resources.GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    if (prospectPersonDetails.surname.toUpperCase().length()
      > CuramConst.kUpperSURNAME) {

      // create the warning string
      curam.util.exception.LocalisableString infoMessage = new curam.util.exception.LocalisableString(
        curam.message.BPOMAINTAINPERSONNAMES.ERR_FV_UPPERLAST_NAME_EXCEEDED_LIMIT);

      infoMessage.arg(
        prospectPersonDetails.surname.toUpperCase().length()
          - CuramConst.kUpperSURNAME);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, curam.util.resources.GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    if (prospectPersonDetails.personBirthName.toUpperCase().length()
      > CuramConst.kUpperBIRTHNAME) {

      curam.util.exception.LocalisableString infoMessage = new curam.util.exception.LocalisableString(
        curam.message.BPOMAINTAINPERSONNAMES.ERR_FV_UPPERBIRTH_NAME_EXCEEDED_LIMIT);

      infoMessage.arg(
        prospectPersonDetails.personBirthName.toUpperCase().length()
          - CuramConst.kUpperBIRTHNAME);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, curam.util.resources.GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    if (prospectPersonDetails.motherBirthSurname.toUpperCase().length()
      > CuramConst.kUpperMOTHERBIRTHSURNAME) {

      curam.util.exception.LocalisableString infoMessage = new curam.util.exception.LocalisableString(
        curam.message.BPOMAINTAINPERSONNAMES.ERR_FV_UPPERMOTHER_BIRTH_SURNAME_EXCEEDED_LIMIT);

      infoMessage.arg(
        prospectPersonDetails.motherBirthSurname.toUpperCase().length()
          - CuramConst.kUpperMOTHERBIRTHSURNAME);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, curam.util.resources.GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    informationalManager.failOperation();
  }

  // END, CR00190252


  // BEGIN, CR00228866, DJ
  /**
   * Changes the recordStatus of person alternative name record from Active to
   * Canceled
   *
   * @param key
   * Alternate name identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void cancelAlternativeName(final CancelPersonNameKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelAlternativeName(key);
  }

  /**
   * Sets citizenship record status to canceled.
   *
   * @param key
   * Identifies the citizen's id
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelCitizenship(final CancelCitizenshipKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelCitizenship(key);
  }

  /**
   * Cancels an education record.
   *
   * @param key
   * Identifies the education record to be canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelEducation(final CancelEducationKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelEducation(key);
  }

  /**
   * Sets person employment record status of the Employment from "Active" to
   * "canceled"
   *
   * @param key
   * The person employment identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void cancelEmployment(final CancelEmploymentKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelEmployment(key);

  }

  /**
   * Cancels an employment working hour record.
   *
   * @param key
   * Identifies the employment working hour record to be canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelEmploymentWorkingHour(
    final CancelEmploymentWorkingHourDetails key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelEmploymentWorkingHour(key);
  }

  /**
   * Sets Foreign Residency status to canceled.
   *
   * @param key
   * The Foreign Residency ID of the record to be canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelForeignResidency(final CancelPersonForeignResidencyKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelForeignResidency(key);
  }

  /**
   * Sets Person Relationship status to canceled.
   *
   * @param key
   * contains the Person Relationship ID of the record to be canceled.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelRelationship(final CancelPersonRelationshipDetailsKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelRelationship(key);
  }

  /**
   * Cancels a utility payment for a person.
   *
   * @param key
   * Contains the utility payment Id.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancelUtilityPayment(final CancelUtilityPaymentKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelUtilityPayment(key);
  }

  /**
   * Creates a new name for the person.
   *
   * @param details
   * The details of the person.
   * @return CreatedAlternateNameDetails List of informationals - if any exist -
   * to be displayed to user
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CreatedAlternateNameDetails createAlternativeName(
    final MaintainPersonAlternativeNameDetails details)
    throws AppException, InformationalException {

    CreatedAlternateNameDetails createdAlternateNameDetails = new CreatedAlternateNameDetails();
    Person delegate = PersonFactory.newInstance();

    createdAlternateNameDetails = delegate.createAlternativeName(details);
    return createdAlternateNameDetails;
  }

  /**
   * Creates a new citizenship record for the specified person.
   *
   * @param details
   * contains the citizen's information to be inserted
   * @return CreatedCitizenshipDetails List of informationals - if any exist -
   * to be displayed to user
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CreatedCitizenshipDetails createCitizenship(
    final MaintainCitizenshipDetails details)
    throws AppException, InformationalException {

    CreatedCitizenshipDetails createdCitizenshipDetails = new CreatedCitizenshipDetails();
    Person delegate = PersonFactory.newInstance();

    createdCitizenshipDetails = delegate.createCitizenship(details);
    return createdCitizenshipDetails;
  }

  /**
   * Creates an Education record.
   *
   * @param details
   * contains the education details to be inserted.
   * @return CreatedEducationDetails List of informationals - if any exist - to
   * be displayed to user
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CreatedEducationDetails createEducation(
    final MaintainPersonEducationDetails details)
    throws AppException, InformationalException {

    CreatedEducationDetails createdEducationDetails = new
      CreatedEducationDetails();
    Person delegate = PersonFactory.newInstance();

    createdEducationDetails = delegate.createEducation(details);
    return createdEducationDetails;
  }

  /**
   * Creates a new employment record for the specified person.
   *
   * @param details
   * contains the details of the employment to be inserted.
   *
   * @return Informational messages returned from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationMsgDtlsList createEmployment(
    final MaintainPersonEmploymentDetails details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    Person delegate = PersonFactory.newInstance();

    informationMsgDtlsList = delegate.createEmployment(details);
    return informationMsgDtlsList;
  }

  /**
   * Creates a new employment working hour record.
   *
   * @param dtls
   * contains the details of the employment working hour record to be
   * inserted
   * @return List of informationals
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CreatedEmploymentWorkingHourDetails createEmploymentWorkingHour(
    final CreateEmploymentWorkingHourDetails dtls)
    throws AppException, InformationalException {

    CreatedEmploymentWorkingHourDetails createdEmploymentWorkingHourDetails = new CreatedEmploymentWorkingHourDetails();
    Person delegate = PersonFactory.newInstance();

    createdEmploymentWorkingHourDetails = delegate.createEmploymentWorkingHour(
      dtls);
    return createdEmploymentWorkingHourDetails;
  }

  /**
   * Creates a new Foreign Residency record for the specified person.
   *
   * @param details
   * contains the Foreign Residency information to be inserted.
   * @return CreatedForeignResidencyDetails List of informationals - if any
   * exist - to be displayed to user.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CreatedForeignResidencyDetails createForeignResidency(
    final  MaintainPersonForeignResidencyDetails details)
    throws AppException, InformationalException {

    CreatedForeignResidencyDetails createdForeignResidencyDetails = new CreatedForeignResidencyDetails();
    Person delegate = PersonFactory.newInstance();

    createdForeignResidencyDetails = delegate.createForeignResidency(details);
    return createdForeignResidencyDetails;
  }

  /**
   * Returns a list of active benefit details for a person.
   *
   * @param key
   * Contains the person's concern role identifier.
   *
   * @return List of benefit payment details for person.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListActiveBenefitCaseDetails listActiveBenefitCase(
    final ListActiveBenefitCasesKey key)
    throws AppException, InformationalException {

    ListActiveBenefitCaseDetails listActiveBenefitCaseDetails = new ListActiveBenefitCaseDetails();
    Person delegate = PersonFactory.newInstance();

    listActiveBenefitCaseDetails = delegate.listActiveBenefitCase(key);
    return listActiveBenefitCaseDetails;
  }

  /**
   * Lists all cases for the specified concern role.
   *
   * @param key
   * Identifies the concern role concerned
   *
   * @return The list of cases for the person.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ListCasesByConcernRoleDetails listAllCases(
    final SearchCasesByConcernRoleKey key)
    throws AppException, InformationalException {

    ListCasesByConcernRoleDetails listCasesByConcernRoleDetails = new ListCasesByConcernRoleDetails();
    Person delegate = PersonFactory.newInstance();

    listCasesByConcernRoleDetails = delegate.listAllCases(key);
    return listCasesByConcernRoleDetails;
  }

  /**
   * Retrieves a list of name details for the specified person.
   *
   * @param key
   * contains the person for whom the list of name details will be
   * returned for.
   * @return The list of name details for the person read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PersonNameRMDtlsList listAlternativeName(
    final  ReadPersonAlternativeNameListKey key)
    throws AppException, InformationalException {

    PersonNameRMDtlsList personNameRMDtlsList = new PersonNameRMDtlsList();
    Person delegate = PersonFactory.newInstance();

    personNameRMDtlsList = delegate.listAlternativeName(key);
    return personNameRMDtlsList;
  }

  /**
   * Method returns a list of Alternative Name Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * contains the Alternative Name record the snapshots are
   * associated with.
   *
   * @return The list of Alternative Name snapshot details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadPersonNameHistoryList listAlternativeNameHistory(
    final ReadPersonNameHistoryListKey key)
    throws AppException, InformationalException {

    ReadPersonNameHistoryList readPersonNameHistoryList = new ReadPersonNameHistoryList();
    Person delegate = PersonFactory.newInstance();

    readPersonNameHistoryList = delegate.listAlternativeNameHistory(key);
    return readPersonNameHistoryList;
  }

  /**
   * Retrieves a list of citizenship details.
   *
   * @param key
   * contains the concern role ID that citizenship records will be
   * returned for.
   *
   * @return The list of citizenship records read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadCitizenshipList listCitizenship(final ReadCitizenshipListKey key)
    throws AppException, InformationalException {

    ReadCitizenshipList readCitizenshipList = new ReadCitizenshipList();
    Person delegate = PersonFactory.newInstance();

    readCitizenshipList = delegate.listCitizenship(key);
    return readCitizenshipList;
  }

  /**
   * Method returns a list of Citizenship Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * contains the citizenshipID of the Citizenship record the snapshots
   * are associated with.
   *
   * @return The list of citizenship snapshot summary details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadCitizenshipHistoryList listCitizenshipHistory(
    final ReadCitizenshipHistoryListKey key)
    throws AppException, InformationalException {

    ReadCitizenshipHistoryList readCitizenshipHistoryList = new ReadCitizenshipHistoryList();
    Person delegate = PersonFactory.newInstance();

    readCitizenshipHistoryList = delegate.listCitizenshipHistory(key);
    return readCitizenshipHistoryList;
  }

  /**
   * Searches for education records by concern role ID.
   *
   * @param key
   * contains the concern role ID that education records will be
   * returned for
   *
   * @return The education records read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadEducationDetailsList listEducation(
    final ReadEducationListByConcernKey key)
    throws AppException, InformationalException {

    ReadEducationDetailsList readEducationDetailsList = new ReadEducationDetailsList();
    Person delegate = PersonFactory.newInstance();

    readEducationDetailsList = delegate.listEducation(key);
    return readEducationDetailsList;
  }

  /**
   * Method returns a list of Education Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * contains the educationID of the Education record the snapshots are
   * associated with.
   *
   * @return The list of education snapshot summary details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadEducationHistoryList listEducationHistory(
    final ReadEducationHistoryListKey key)
    throws AppException, InformationalException {

    ReadEducationHistoryList readEducationHistoryList = new ReadEducationHistoryList();
    Person delegate = PersonFactory.newInstance();

    readEducationHistoryList = delegate.listEducationHistory(key);
    return readEducationHistoryList;
  }

  /**
   * Reads a list of existing employments for the person.
   *
   * @param key
   * Identifies the person for whom the employments will be returned
   *
   * @return The list of employments read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00178447, PM
  public ReadEmploymentDetailsWithMsgList listEmployment(
    final ReadPersonEmploymentListKey key)
    throws AppException, InformationalException {

    ReadEmploymentDetailsWithMsgList readEmploymentDetailsWithMsgList = new ReadEmploymentDetailsWithMsgList();
    Person delegate = PersonFactory.newInstance();

    readEmploymentDetailsWithMsgList = delegate.listEmployment1(key);
    return readEmploymentDetailsWithMsgList;
  }

  // END, CR00178447

  /**
   * Method returns a list of Employment Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * contains the Employment record the snapshots are associated with.
   *
   * @return The list of Employment snapshot summary details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadEmploymentHistoryList listEmploymentHistory(
    final ReadEmploymentHistoryListKey key)
    throws AppException, InformationalException {

    ReadEmploymentHistoryList readEmploymentHistoryList = new
      ReadEmploymentHistoryList();
    Person delegate = PersonFactory.newInstance();

    readEmploymentHistoryList = delegate.listEmploymentHistory(key);
    return readEmploymentHistoryList;
  }

  /**
   * Returns a list of employment working hour records.
   *
   * @param key
   * contains the employment working hour key that records will be
   * returned for.
   *
   * @return The list of employment working hour records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public EmploymentWorkingHourList listEmploymentWorkingHour(
    final ListEmploymentWorkingHourKey key)
    throws AppException, InformationalException {

    EmploymentWorkingHourList employmentWorkingHourList = new EmploymentWorkingHourList();
    Person delegate = PersonFactory.newInstance();

    employmentWorkingHourList = delegate.listEmploymentWorkingHour(key);
    return employmentWorkingHourList;
  }

  /**
   * Returns a list of employment working hour records with the versionNo
   * included.
   *
   * @param key
   * The employment working hour key that records will be returned for.
   *
   * @return The list of employment working hour records including versionNo.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public EmploymentWorkingHourAndVersionNoList listEmploymentWorkingHourAndVersionNo(
    final ListEmploymentWorkingHourKey key)
    throws AppException, InformationalException {

    EmploymentWorkingHourAndVersionNoList employmentWorkingHourAndVersionNoList = new EmploymentWorkingHourAndVersionNoList();
    Person delegate = PersonFactory.newInstance();

    employmentWorkingHourAndVersionNoList = delegate.listEmploymentWorkingHourAndVersionNo(
      key);
    return employmentWorkingHourAndVersionNoList;
  }

  /**
   * Method returns a list of Employment Working Hours Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * contains the Employment Working Hour record the snapshots are
   * associated with.
   *
   * @return The list of Employment Working Hour snapshot details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadEmploymentWorkingHourHistoryList listEmploymentWorkingHourHistory(
    final ReadEmploymentWorkingHourHistoryListKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();
    ReadEmploymentWorkingHourHistoryList readEmploymentWorkingHourHistoryList = new ReadEmploymentWorkingHourHistoryList();

    readEmploymentWorkingHourHistoryList = delegate.listEmploymentWorkingHourHistory(
      key);
    return readEmploymentWorkingHourHistoryList;
  }

  /**
   * Retrieves a list of Foreign Residency details.
   *
   * @param key
   * contains the concern role ID that Foreign Residency records will be
   * returned for
   *
   * @return The list of foreign residency details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadPersonForeignResidencyDetailsList listForeignResidency(
    final ReadPersonForeignResidencyListKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();
    ReadPersonForeignResidencyDetailsList readPersonForeignResidencyDetailsList = new ReadPersonForeignResidencyDetailsList();

    readPersonForeignResidencyDetailsList = delegate.listForeignResidency(key);
    return readPersonForeignResidencyDetailsList;
  }

  /**
   * Method returns a list of Foreign Residency Snapshot summary details, and
   * the date-of-creation for each Snapshot record.
   *
   * @param key
   * contains the Foreign Residency record the snapshots are associated with.
   *
   * @return The list of Foreign Residency snapshot details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadPersonForeignResidencyHistoryList listForeignResidencyHistory(
    final ReadPersonForeignResidencyHistoryListKey key)
    throws AppException, InformationalException {

    ReadPersonForeignResidencyHistoryList readPersonForeignResidencyHistoryList = new ReadPersonForeignResidencyHistoryList();
    Person delegate = PersonFactory.newInstance();

    readPersonForeignResidencyHistoryList = delegate.listForeignResidencyHistory(
      key);
    return readPersonForeignResidencyHistoryList;
  }

  /**
   * Method returns a list of Person Snapshot details, and the date-of-creation
   * for each Snapshot record.
   *
   * @param key
   * contains the Person record the snapshots are associated with.
   *
   * @return The list of Person snapshot summary details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadPersonHistoryList listPersonHistory(
    final ReadPersonHistoryListKey key)
    throws AppException, InformationalException {

    ReadPersonHistoryList readPersonHistoryList = new ReadPersonHistoryList();
    Person delegate = PersonFactory.newInstance();

    readPersonHistoryList = delegate.listPersonHistory(key);
    return readPersonHistoryList;
  }

  // ____________________________________________________________________________
  /**
   * Retrieves a list of Person Relationship details.
   *
   * @param key
   * contains the concern role ID that Person Relationship records will
   * be returned for.
   *
   * @return The list of Person Relationship records.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadPersonRelationshipList listRelationship(
    final ReadPersonRelationshipListKey key)
    throws AppException, InformationalException {

    ReadPersonRelationshipList readPersonRelationshipList = new ReadPersonRelationshipList();
    Person delegate = PersonFactory.newInstance();

    readPersonRelationshipList = delegate.listRelationship(key);
    return readPersonRelationshipList;
  }

  // ____________________________________________________________________________
  /**
   * Method returns a list of Relationship Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * contains the Relationship record the snapshots are associated with.
   *
   * @return The list of Relationship snapshot summary details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadRelationshipHistoryList listRelationshipHistory(
    final ReadRelationshipHistoryListKey key)
    throws AppException, InformationalException {

    ReadRelationshipHistoryList readRelationshipHistoryList = new ReadRelationshipHistoryList();
    Person delegate = PersonFactory.newInstance();

    readRelationshipHistoryList = delegate.listRelationshipHistory(key);
    return readRelationshipHistoryList;
  }

  /**
   * Retrieves a list of Utility Payments.
   *
   * @param key
   * Identifies utility payment concerned
   *
   * @return List of utility payments for the specified person.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadUtilityPaymentsList listUtilityPayment(
    final ReadUtilityPaymentsListKey key)
    throws AppException, InformationalException {

    ReadUtilityPaymentsList readUtilityPaymentsList = new
      ReadUtilityPaymentsList();
    Person delegate = PersonFactory.newInstance();

    readUtilityPaymentsList = delegate.listUtilityPayment(key);
    return readUtilityPaymentsList;
  }

  // BEGIN, CR00266421, ZV
  /**
   * Retrieves the list of all the wait list entries for a person.
   *
   * @param concernRoleKey
   * The concern role ID of the person.
   *
   * @return The list of all the wait list entries for a person.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link curam.core.facade.impl.Person#listWaitList()}
   */
  @Deprecated
  public ConcernRoleWaitListDetailsList listWaitListsForConcernRole(
    final ConcernRoleKey key)
    throws AppException, InformationalException {

    ConcernRoleWaitListDetailsList concernRoleWaitListDetailsList = new ConcernRoleWaitListDetailsList();
    Person delegate = PersonFactory.newInstance();

    concernRoleWaitListDetailsList = delegate.listWaitListsForConcernRole(key);
    return concernRoleWaitListDetailsList;
  }

  // END, CR00266421

  /**
   * Modifies an existing name for this person.
   *
   * @param details
   * contains the details of the person to be modified.
   * @return ModifiedAlternateNameDetails List of informationals - if any exist -
   * to be returned to the user
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ModifiedAlternateNameDetails modifyAlternativeName(
    final MaintainPersonAlternativeNameDetails details)
    throws AppException, InformationalException {

    ModifiedAlternateNameDetails modifiedAlternateNameDetails = new
      ModifiedAlternateNameDetails();
    Person delegate = PersonFactory.newInstance();

    modifiedAlternateNameDetails = delegate.modifyAlternativeName(details);
    return modifiedAlternateNameDetails;
  }

  /**
   * Modifies citizenship details.
   *
   * @param details
   * contains the citizenship record that will be modified
   * @return ModifiedCitizenshipDetails List of informationals - if any exist -
   * to be returned to the user
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ModifiedCitizenshipDetails modifyCitizenship(
    final MaintainCitizenshipDetails details)
    throws AppException, InformationalException {

    ModifiedCitizenshipDetails modifiedCitizenshipDetails = new
      ModifiedCitizenshipDetails();
    Person delegate = PersonFactory.newInstance();

    modifiedCitizenshipDetails = delegate.modifyCitizenship(details);
    return modifiedCitizenshipDetails;
  }

  /**
   * Modifies Education details entered.
   *
   * @param details
   * contains the education details to be updated.
   * @return ModifiedEducationDetails List of informationals - if any exist - to
   * be displayed to user
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ModifiedEducationDetails modifyEducation(
    final MaintainPersonEducationDetails details)
    throws AppException, InformationalException {

    ModifiedEducationDetails modifiedEducationDetails = new ModifiedEducationDetails();
    Person delegate = PersonFactory.newInstance();

    modifiedEducationDetails = delegate.modifyEducation(details);
    return modifiedEducationDetails;
  }

  /**
   * Modifies an existing employment of the person.
   *
   * @param details
   * contains the details of employment to be modified.
   * @return ModifedEmploymentDetails List of informationals - if any exist - to
   * be displayed to user
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ModifedEmploymentDetails modifyEmployment(
    final MaintainPersonEmploymentDetails details)
    throws AppException, InformationalException {

    ModifedEmploymentDetails modifedEmploymentDetails = new ModifedEmploymentDetails();
    Person delegate = PersonFactory.newInstance();

    modifedEmploymentDetails = delegate.modifyEmployment(details);
    return modifedEmploymentDetails;
  }

  /**
   * Modifies details of an employment working hour record.
   *
   * @param dtls
   * contains the employment working hour record that will be modified
   * @return ModifiedEmploymentWorkingHourDetails List of informationals - if
   * any exist - to be displayed to user
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ModifiedEmploymentWorkingHourDetails modifyEmploymentWorkingHour(
    final ModifyEmploymentWorkingHourDetails dtls)
    throws AppException, InformationalException {

    ModifiedEmploymentWorkingHourDetails modifiedEmploymentWorkingHourDetails = new ModifiedEmploymentWorkingHourDetails();
    Person delegate = PersonFactory.newInstance();

    modifiedEmploymentWorkingHourDetails = delegate.modifyEmploymentWorkingHour(
      dtls);
    return modifiedEmploymentWorkingHourDetails;
  }

  /**
   * Modifies Foreign Residency details.
   *
   * @param details
   * contains the Foreign Residency details that will be modified.
   *
   * @return ModifiedForeignResidencyDetails.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ModifiedForeignResidencyDetails modifyForeignResidency(
    final MaintainPersonForeignResidencyDetails details)
    throws AppException, InformationalException {

    ModifiedForeignResidencyDetails modifiedForeignResidencyDetails = new ModifiedForeignResidencyDetails();
    Person delegate = PersonFactory.newInstance();

    modifiedForeignResidencyDetails = delegate.modifyForeignResidency(details);
    return modifiedForeignResidencyDetails;
  }

  /**
   * Modifies a person.
   *
   * @param details
   * Identifies person whose details are to be modified
   *
   * @return Informational messages returned from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public InformationalMsgDetailsList modifyPerson(
    final MaintainPersonDetails details)
    throws AppException, InformationalException {

    InformationalMsgDetailsList informationalMsgDetailsList = new InformationalMsgDetailsList();
    Person delegate = PersonFactory.newInstance();

    informationalMsgDetailsList = delegate.modifyPerson(details);
    return informationalMsgDetailsList;
  }

  /**
   * Modifies a Utility Payment.
   *
   * @param details
   * contains the utility payment details to be modified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyUtilityPayment(final MaintainUtilityPaymentsDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.modifyUtilityPayment(details);
  }

  /**
   * Reads an alternate name for the prospect person.
   *
   * @param key
   * Identifies person we have to deal with
   *
   * @return The alternate names read from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadPersonNameDetails readAlternativeName(final ReadPersonNameKey key)
    throws AppException, InformationalException {

    ReadPersonNameDetails readPersonNameDetails = new ReadPersonNameDetails();
    Person delegate = PersonFactory.newInstance();

    readPersonNameDetails = delegate.readAlternativeName(key);
    return readPersonNameDetails;
  }

  /**
   * Searches for a person by primary alternate ID.
   *
   * @param key
   * Identifies the person
   *
   * @return The details of the person read from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0.5.3, replaced by {@link #searchByReferenceNumber()}    
   */
  public PersonReadDtls readByReferenceNumber(
    final PersonAlternateIDSearchKey key)
    throws AppException, InformationalException {

    PersonReadDtls personReadDtls = new PersonReadDtls();
    Person delegate = PersonFactory.newInstance();

    personReadDtls = delegate.readByReferenceNumber(key);
    return personReadDtls;
  }

  /**
   * Searches for people by primary alternate ID.
   *
   * @param key
   * Identifies the person
   *
   * @return A list of people read.
   *
   * @throws AppException Generic Exception Signature.  
   * @throws InformationalException Generic Exception Signature.
   */
  public PersonReadDtlsList searchByReferenceNumber(
    PersonAlternateIDSearchKey key) throws AppException,
      InformationalException {

    PersonReadDtlsList personReadDtlsList = new PersonReadDtlsList();
    Person delegate = PersonFactory.newInstance();

    personReadDtlsList = delegate.searchByReferenceNumber(key);
    return personReadDtlsList;
    
  }

  /**
   * Reads citizenship details.
   *
   * @param key
   * Identifies the citizenship concerned
   *
   * @return The citizenship details of the person read from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadCitizenshipDetails readCitizenship(final ReadCitizenshipKey key)
    throws AppException, InformationalException {

    ReadCitizenshipDetails readCitizenshipDetails = new ReadCitizenshipDetails();
    Person delegate = PersonFactory.newInstance();

    readCitizenshipDetails = delegate.readCitizenship(key);
    return readCitizenshipDetails;
  }

  /**
   * Searches for an education record by education ID.
   *
   * @param key
   * contains the education ID for the education record which will be
   * returned.
   * @return The education record read from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadEducationDetails readEducation(final EducationReadKey key)
    throws AppException, InformationalException {

    ReadEducationDetails readEducationDetails = new ReadEducationDetails();
    Person delegate = PersonFactory.newInstance();

    readEducationDetails = delegate.readEducation(key);
    return readEducationDetails;
  }

  /**
   * Reads an existing employment for the person.
   *
   * @param key
   * Identifies the person for whom the employments will be returned.
   *
   * @return The details of the employment read from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadEmploymentDetails readEmployment(final ReadEmploymentKey key)
    throws AppException, InformationalException {

    ReadEmploymentDetails readEmploymentDetails = new ReadEmploymentDetails();
    Person delegate = PersonFactory.newInstance();

    readEmploymentDetails = delegate.readEmployment(key);
    return readEmploymentDetails;
  }

  /**
   * Reads the details of an employment working hour record.
   *
   * @param key
   * Identifies the employment working hour record concerned.
   *
   * @return The employment working hour details of the person
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadEmploymentWorkingHourDetails readEmploymentWorkingHour(
    final EmploymentWorkingHourKey key) throws AppException,
      InformationalException {

    ReadEmploymentWorkingHourDetails readEmploymentWorkingHourDetails = new ReadEmploymentWorkingHourDetails();
    Person delegate = PersonFactory.newInstance();

    readEmploymentWorkingHourDetails = delegate.readEmploymentWorkingHour(key);
    return readEmploymentWorkingHourDetails;
  }

  /**
   * Read the context description details for employment working hours.
   *
   * @param key
   * contains the employment ID the context description is returned for.
   *
   * @return The employment working hour context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public EmploymentWorkingHourContextDescription readEmploymentWorkingHourContextDescription(
    final EmploymentWorkingHourContextDescriptionKey key)
    throws AppException, InformationalException {

    EmploymentWorkingHourContextDescription employmentWorkingHourContextDescription = new
      EmploymentWorkingHourContextDescription();
    Person delegate = PersonFactory.newInstance();

    employmentWorkingHourContextDescription = delegate.readEmploymentWorkingHourContextDescription(
      key);
    return employmentWorkingHourContextDescription;
  }

  /**
   * Modifies Foreign Residency details.
   *
   * @param key
   * The Foreign Residency ID that details will be returned for
   *
   * @return The foreign residency details read from the database.
   */
  public ReadPersonForeignResidencyDetails readForeignResidency(
    final ReadPersonForeignResidencyKey key)
    throws AppException, InformationalException {

    ReadPersonForeignResidencyDetails readPersonForeignResidencyDetails = new ReadPersonForeignResidencyDetails();
    Person delegate = PersonFactory.newInstance();

    readPersonForeignResidencyDetails = delegate.readForeignResidency(key);
    return readPersonForeignResidencyDetails;
  }

  /**
   * Reads the Further Details for a person.
   *
   * @param key
   * Identifies the person
   *
   * @return The details of the person read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PersonNameAndAddressDetails readFullNameAndAddress(
    final ReadPersonKey key)
    throws AppException, InformationalException {

    PersonNameAndAddressDetails personNameAndAddressDetails = new PersonNameAndAddressDetails();
    Person delegate = PersonFactory.newInstance();

    personNameAndAddressDetails = delegate.readFullNameAndAddress(key);
    return personNameAndAddressDetails;
  }

  /**
   * Reads the Further Details for a person.
   *
   * @param key
   * Identifies the person
   *
   * @return The details of the person read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PersonSearchFurtherDtls readFurtherDetails(
    final PersonSearchMaintainConcernRoleKey key)
    throws AppException, InformationalException {

    PersonSearchFurtherDtls personSearchFurtherDtls = new PersonSearchFurtherDtls();
    Person delegate = PersonFactory.newInstance();

    personSearchFurtherDtls = delegate.readFurtherDetails(key);
    return personSearchFurtherDtls;
  }

  /**
   * Reads the details of the specified person.
   *
   * @param key
   * Identifies the person concerned
   *
   * @return The details of the person read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadPersonDetails readPerson(final ReadPersonKey key)
    throws AppException, InformationalException {

    ReadPersonDetails readPersonDetails = new ReadPersonDetails();
    Person delegate = PersonFactory.newInstance();

    readPersonDetails = delegate.readPerson(key);
    return readPersonDetails;
  }

  /**
   * Modifies Person Relationship details.
   *
   * @param key
   * The Relationship ID that details will be returned for
   *
   * @return The details of the relationship read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadPersonRelationshipDetails readRelationship(
    final ReadPersonRelationshipDetailsKey key)
    throws AppException, InformationalException {

    ReadPersonRelationshipDetails readPersonRelationshipDetails = new ReadPersonRelationshipDetails();
    Person delegate = PersonFactory.newInstance();

    readPersonRelationshipDetails = delegate.readRelationship(key);
    return readPersonRelationshipDetails;

  }

  /**
   * Returns the nickname search indicator set in Property administration.
   *
   * @return SearchWithNicknames, an on/off indicator
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchWithNicknames readSearchWithNicknamesIndicator()
    throws AppException, InformationalException {

    SearchWithNicknames searchWithNicknames = new SearchWithNicknames();
    Person delegate = PersonFactory.newInstance();

    searchWithNicknames = delegate.readSearchWithNicknamesIndicator();
    return searchWithNicknames;
  }

  /**
   * Reads a Utility Payment.
   *
   * @param key
   * Identifies the utility payment
   *
   * @return The details of the utility payment read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadUtilityPaymentDetails readUtilityPayment(
    final ReadUtilityPaymentKey key)
    throws AppException, InformationalException {

    ReadUtilityPaymentDetails readUtilityPaymentDetails = new ReadUtilityPaymentDetails();
    Person delegate = PersonFactory.newInstance();

    readUtilityPaymentDetails = delegate.readUtilityPayment(key);
    return readUtilityPaymentDetails;
  }

  /**
   * Called to register a new person.
   *
   * @param details
   * The details of the person being registered
   *
   * @return The person registration details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PersonRegistrationResult register(
    final PersonRegistrationDetails details)
    throws AppException, InformationalException {

    PersonRegistrationResult personRegistrationResult = new PersonRegistrationResult();
    Person delegate = PersonFactory.newInstance();

    personRegistrationResult = delegate.register(details);
    return personRegistrationResult;
  }

  /**
   * @param key
   * Identifies the person concerned
   *
   * @return The details of the person read from the database.
   * @deprecated -since V6.0
   *
   * Searches for a person by Concern Role ID.
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}
   */
  @Deprecated
  public PersonSearchResult search(final PersonSearchKey key)
    throws AppException, InformationalException {

    PersonSearchResult personSearchResult = new PersonSearchResult();
    Person delegate = PersonFactory.newInstance();

    delegate.search(key);
    return personSearchResult;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Searches for a person by provided search criteria.
   *
   * @param key
   * Contains the person search criteria.
   *
   * @return Details for the list of persons found.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ProspectPerson#searchPersonDetails(PersonSearchKey1)}.
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchPersonDetails(PersonSearchKey1) which returns the
   * informational message along with person details as well. See
   * release note: CS-09152/CR00282028.
   */
  @Deprecated
  public PersonSearchResult1 search1(final PersonSearchKey1 key)
    throws AppException, InformationalException {
    // END, CR00282028
    PersonSearchResult1 personSearchResult1 = new PersonSearchResult1();
    Person delegate = PersonFactory.newInstance();

    delegate.search1(key);
    return personSearchResult1;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Searches for a person by provided search criteria. Does not return names as
   * hyperlinks as this is for popup pages.
   *
   * @param key
   * Contains the person search criteria.
   *
   * @return Details for the list of persons found.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ProspectPerson#searchPersonForPopup(PersonSearchKey1)}.
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchPersonForPopup(PersonSearchKey1) which returns the
   * informational message along with person details as well. See
   * release note: CS-09152/CR00282028.
   */
  @Deprecated
  public PersonSearchResult1 search1ForPopup(final PersonSearchKey1 key)
    throws AppException, InformationalException {
    // END, CR00282028
    PersonSearchResult1 personSearchResult1 = new PersonSearchResult1();
    Person delegate = PersonFactory.newInstance();

    delegate.search1ForPopup(key);
    return personSearchResult1;
  }

  /**
   * @param key
   * Identifies the person concerned
   *
   * @return The cases for the person as read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated -since V6.0
   *
   * Searches for cases for the specified person.
   * @deprecated This method is replaced by {@link #searchCase1()}
   */
  @Deprecated
  public SearchCaseDetails searchCase(final SearchCaseKey_fo key)
    throws AppException, InformationalException {

    SearchCaseDetails searchCaseDetails = new SearchCaseDetails();
    Person delegate = PersonFactory.newInstance();

    delegate.searchCase(key);
    return searchCaseDetails;
  }

  /**
   * Searches for cases for the specified person.
   *
   * @param key
   * Identifies the person concerned
   *
   * @return The cases for the person as read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchCaseDetails1 searchCase1(final SearchCaseKey_fo key)
    throws AppException, InformationalException {

    SearchCaseDetails1 searchCaseDetails1 = new SearchCaseDetails1();
    Person delegate = PersonFactory.newInstance();

    delegate.searchCase1(key);
    return searchCaseDetails1;
  }

  /**
   * @param key
   * Identifies the person concerned
   *
   * @return The cases for the duplicate person as read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated -since V6.0
   *
   * Searches for cases for the specified duplicate person.
   * @deprecated This method is replaced by {@link #searchCaseForDuplicate1()}
   */
  @Deprecated
  public SearchCasesForDuplicateDetails searchCaseForDuplicate(
    final SearchCaseKey_fo key) throws AppException, InformationalException {

    SearchCasesForDuplicateDetails searchCasesForDuplicateDetails = new SearchCasesForDuplicateDetails();
    Person delegate = PersonFactory.newInstance();

    searchCasesForDuplicateDetails = delegate.searchCaseForDuplicate(key);
    return searchCasesForDuplicateDetails;

  }

  /**
   * Searches for cases for the specified duplicate person.
   *
   * @param key
   * Identifies the person concerned
   *
   * @return The cases for the duplicate person as read from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchCasesForDuplicateDetails1 searchCaseForDuplicate1(
    final SearchCaseKey_fo key) throws AppException, InformationalException {

    SearchCasesForDuplicateDetails1 searchCasesForDuplicateDetails1 = new SearchCasesForDuplicateDetails1();
    Person delegate = PersonFactory.newInstance();

    searchCasesForDuplicateDetails1 = delegate.searchCaseForDuplicate1(key);
    return searchCasesForDuplicateDetails1;
  }

  /**
   * Cancels a concern role address record.
   *
   * @param key
   * contains the concern role address which is to be canceled
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void cancelAddress(final CancelParticipantAddressKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelAddress(key);
  }

  /**
   * Cancels a concern role alternate id record.
   *
   * @param key
   * contains the concern role alternate id which is being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void cancelAlternateID(final CancelParticipantAlternateIDKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelAlternateID(key);
  }

  /**
   * Cancels a communication on a case.
   *
   * @param key
   * contains the key to cancel the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  public void cancelCommunication(final CancelCommunicationKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelCommunication(key);
  }

  /**
   * Cancels a concern role communication exception record.
   *
   * @param key
   * contains the ID of the communication exception being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void cancelCommunicationException(
    final CancelParticipantCommunicationExceptionKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelCommunicationException(key);
  }

  /**
   * Cancels a contact record.
   *
   * @param key
   * contains the contact ID for the record being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void cancelContact(final CancelContactKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelContact(key);
  }

  /**
   * Cancel an email address for a participant.
   *
   * @param key
   * contains the ID of the email address being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void cancelEmailAddress(final CancelParticipantEmailAddressKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelEmailAddress(key);
  }

  /**
   * Cancel a note for a participant.
   *
   * @param details
   * contains the details to create a participant note.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void cancelNote(final CancelParticipantNoteDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelNote(details);
  }

  /**
   * Cancel a bank account for a participant.
   * This method handles the cancellation of normal bank account
   * as well as joint accounts.
   *
   * @param key contains the ID of the bank account being canceled.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public InformationMsgDtlsList cancelParticipantBankAccount(
    final CancelParticipantBankAccountKey key)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    Person delegate = PersonFactory.newInstance();

    informationMsgDtlsList = delegate.cancelParticipantBankAccount(key);
    return informationMsgDtlsList;
  }

  /**
   * Cancels a phone number record.
   *
   * @param key
   * contains the concern role phone number ID of the phone record being
   * canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void cancelPhoneNumber(final CancelParticipantPhoneNumberKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelPhoneNumber(key);
  }

  /**
   * Cancel a web address for a participant.
   *
   * @param details
   * contains the details of the web address to cancel
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void cancelWebAddress(final CancelParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelWebAddress(details);
  }

  /**
   * Creates a concern role address record.
   *
   * @param details
   * contains the concern role ID and the address details.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public CreateParticipantAddressDetails createAddress(
    final MaintainParticipantAddressDetails details)
    throws AppException, InformationalException {

    CreateParticipantAddressDetails createParticipantAddressDetails = new CreateParticipantAddressDetails();
    Person delegate = PersonFactory.newInstance();

    createParticipantAddressDetails = delegate.createAddress(details);
    return createParticipantAddressDetails;
  }

  /**
   * Create a administrator for the concernRole specified.
   *
   * @param participantAdministratorDetails
   * The administrator details being entered.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public void createAdministrator(
    final ParticipantAdministratorDetails participantAdministratorDetails)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createAdministrator(participantAdministratorDetails);
  }

  /**
   * Create a new administrator for the concernRole supplied.
   *
   * @param details
   * contains the administrator role details being entered.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#createAdministrator(ParticipantAdministratorDetails)}
   */
  @Deprecated
  public void createAdminRole(final CreateParticipantAdminRoleDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createAdminRole(details);
  }

  /**
   * Creates a concern role alternate id record.
   *
   * @param details
   * contains the concern role ID and alternate id details being
   * entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public CreateParticipantAlternateIDDetails createAlternateID(
    final MaintainParticipantAlternateIDDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();
    CreateParticipantAlternateIDDetails createParticipantAlternateIDDetails = new CreateParticipantAlternateIDDetails();

    createParticipantAlternateIDDetails = delegate.createAlternateID(details);
    return createParticipantAlternateIDDetails;
  }

  /**
   * Cancel a bank account for a participant.
   *
   * @param key
   * contains the ID of the bank account being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void cancelBankAccount(CancelParticipantBankAccountKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.cancelBankAccount(key);
  }

  /**
   * Creates a concern role communication exception record.
   *
   * @param details
   * contains the concern role communication exception details being
   * entered.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void createCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createCommunicationException(details);
  }

  /**
   * Create a contact.
   *
   * @param details
   * contains the contact details being entered
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void createContact(final CreateContactDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createContact(details);
  }

  /**
   * Creates a contact record for a participant who was not previously
   * registered.
   *
   * @param details
   * contains the registration details for the contact
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void createContactFromUnregisteredParticipant(
    final CreateContactFromUnregisteredParticipant details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createContactFromUnregisteredParticipant(details);
  }

  /**
   * Create a new email address for a participant.
   *
   * @param details
   * contains the email address details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public CreateParticipantEmailAddressDetails createEmailAddress(
    final MaintainParticipantEmailAddressDetails details)
    throws AppException, InformationalException {

    CreateParticipantEmailAddressDetails createParticipantEmailAddressDetails = new CreateParticipantEmailAddressDetails();
    Person delegate = PersonFactory.newInstance();

    createParticipantEmailAddressDetails = delegate.createEmailAddress(details);
    return createParticipantEmailAddressDetails;
  }

  /**
   * Creates an email communication.
   *
   * @param details
   * contains the details to create the email communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Communication#createEmail(
   * curam.core.facade.struct.CreateEmailCommDetails)}
   */
  @Deprecated
  public void createEmailCommunication(
    final CreateEmailCommunicationDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createEmailCommunication(details);
  }

  /**
   * Creates a freeform communication.
   *
   * @param details
   * contains the details to create the freeform communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  public void createFreeformCommunincation(
    final CreateFreeformCommunication details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createFreeformCommunincation(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the home phone number is
   * created
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void createHomePhoneNumber(final CreateHomePhoneNumber key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createHomePhoneNumber(key);
  }

  /**
   * This method creates a mailing address for a participant.
   *
   * @param key
   * Identifies the participant for whom the mailing address is created
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void createMailingAddress(final CreateMailingAddress key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createMailingAddress(key);
  }

  /**
   * Create a note for a participant.
   *
   * @param details
   * contains the participant note details being entered.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void createNote(final ParticipantNoteDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createNote(details);
  }

  /**
   * Creates a concern role phone number record.
   *
   * @param details
   * contains the concern role identifier & concern role phone number
   * details
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public CreateParticipantPhoneDetails createPhoneNumber(
    final MaintainParticipantPhoneDetails details)
    throws AppException, InformationalException {

    CreateParticipantPhoneDetails createParticipantPhoneDetails = new CreateParticipantPhoneDetails();
    Person delegate = PersonFactory.newInstance();

    createParticipantPhoneDetails = delegate.createPhoneNumber(details);
    return createParticipantPhoneDetails;
  }

  /**
   * Creates a template communication.
   *
   * @param details
   * contains the details to create the template communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  public void createTemplateCommunication(
    final CreateTemplateCommunication details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createTemplateCommunication(details);
  }

  /**
   * Create a new web address for a participant.
   *
   * @param details
   * contains the web address details being entered
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void createWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createWebAddress(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the work phone number is
   * created.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void createWorkPhoneNumber(final CreateWorkPhoneNumber key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.createWorkPhoneNumber(key);
  }

  /**
   * Display the address given as a single line. The address is formatted base
   * on the ENV_ADDRESSSTRINGFORMAT environment variable.
   *
   * @param OtherAddressData The address formatted with its descriptors i.e.
   * ADD1=Line1, ADD2=Line2, ADD3=Line3 ...
   *
   * @return AddressString, the address given as a single line.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public AddressString displaySingleLineAddress(
    final OtherAddressData otherAddressData)
    throws AppException, InformationalException {

    AddressString addressString = new AddressString();
    Person delegate = PersonFactory.newInstance();

    addressString = delegate.displaySingleLineAddress(otherAddressData);
    return addressString;
  }

  /**
   * Ends all active deductions on a case for a participant.
   *
   * @param details
   * Contains the  concern role ID & the case ID
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void endDeduction(final EndDeductionDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.endDeduction(details);
  }

  /**
   * Formats the bank account details for a participant. The bank details
   * are formatted to display as a single line of text. The formatting is
   * decided by a system variable.
   *
   * @param bankAccountRMDtls bank account details to be formatted
   *
   * @return Formatted string of bank account details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public BankAccountString formatBankAcDetailsString(
    final BankAccountRMDtls bankAccountRMDtls)
    throws AppException, InformationalException {

    BankAccountString bankAccountString = new BankAccountString();
    Person delegate = PersonFactory.newInstance();

    bankAccountString = delegate.formatBankAcDetailsString(bankAccountRMDtls);
    return bankAccountString;
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the primary residence address
   * is created
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void insertPrimaryResidenceAddress(final InsertPrimaryResAddress key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.insertPrimaryResidenceAddress(key);
  }

  /**
   * Retrieves a list of active address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of active addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantActiveAddressList listActiveAddresses(
    final ReadParticipantAddressListKey key)
    throws AppException, InformationalException {

    ReadParticipantActiveAddressList readParticipantActiveAddressList = new ReadParticipantActiveAddressList();
    Person delegate = PersonFactory.newInstance();

    delegate.listActiveAddresses(key);
    return readParticipantActiveAddressList;
  }

  /**
   * Method to list all active bank accounts for a Case Nominee.
   *
   * @param key
   * contains the concernRoleID
   *
   * @return list of all active bank accounts for a participant.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadActiveBankAccountList listActiveBankAccount(
    final ReadParticipantBankAccountListKey key) throws AppException,
      InformationalException {

    ReadActiveBankAccountList readActiveBankAccountList = new ReadActiveBankAccountList();
    Person delegate = PersonFactory.newInstance();

    delegate.listActiveBankAccount(key);
    return readActiveBankAccountList;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains concernRoleID and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam V6.0. This method is replaced by
   * {@link #listActiveBankAccountForRedirection1()}.
   */
  @Deprecated
  public BankAccountListForRedirectionDetails listActiveBankAccountForRedirection(
    final ParticipantBankAccountRedirectionKey key)
    throws AppException, InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails = new BankAccountListForRedirectionDetails();
    Person delegate = PersonFactory.newInstance();

    bankAccountListForRedirectionDetails = delegate.listActiveBankAccountForRedirection(
      key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains bank account id and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public BankAccountListForRedirectionDetails listActiveBankAccountForRedirection1(
    final ParticipantBankAccountRedirectionKey1 key)
    throws AppException, InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails = new BankAccountListForRedirectionDetails();
    Person delegate = PersonFactory.newInstance();

    bankAccountListForRedirectionDetails = delegate.listActiveBankAccountForRedirection1(
      key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Retrieves a list of address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantAddressList listAddress
    (final ReadParticipantAddressListKey key)
    throws AppException, InformationalException {

    ReadParticipantAddressList readParticipantAddressList = new ReadParticipantAddressList();
    Person delegate = PersonFactory.newInstance();

    readParticipantAddressList = delegate.listAddress(key);
    return readParticipantAddressList;
  }

  /**
   * Method returns a list of Address Snapshot details, and the date-of-creation
   * for each Snapshot record.
   *
   * @param key contains the Address record the snapshots are associated with.
   *
   * @return The list of Address snapshot summary details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadAddressHistoryList listAddressHistory(
    final ReadAddressHistoryListKey key)
    throws AppException, InformationalException {

    ReadAddressHistoryList readAddressHistoryList = new ReadAddressHistoryList();
    Person delegate = PersonFactory.newInstance();

    readAddressHistoryList = delegate.listAddressHistory(key);
    return  readAddressHistoryList;
  }

  /**
   * Retrieves a list of address records for a concern role and displays them as
   * strings.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ParticipantAddressStringList listAddressString(
    final ReadParticipantAddressListKey key)
    throws AppException, InformationalException {

    final ParticipantAddressStringList participantAddressStringList = new
      ParticipantAddressStringList();
    Person delegate = PersonFactory.newInstance();

    delegate.listAddressString(key);
    return participantAddressStringList;
  }

  /**
   * Retrieves a list of administrators for the specified concern role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is
   * returned.
   *
   * @return The list of administrators returned from the database.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ParticipantAdministratorDetailsList listAdministrators(
    final ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList = new ParticipantAdministratorDetailsList();
    Person delegate = PersonFactory.newInstance();

    participantAdministratorDetailsList = delegate.listAdministrators(
      readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administrators for the specified duplicate concern
   * role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is returned
   *
   * @return The list of administrators for the duplicate concern role specified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  public ParticipantAdministratorDetailsList listAdministratorsForDuplicateParticipant(
    ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList = new ParticipantAdministratorDetailsList();
    Person delegate = PersonFactory.newInstance();

    participantAdministratorDetailsList = delegate.listAdministratorsForDuplicateParticipant(
      readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administration roles for the specified concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministrators(ReadParticipantAdminRoleListKey)}
   */
  @Deprecated
  public ReadParticipantAdminRoleList listAdminRole(
    final ReadParticipantAdminRoleListKey key)
    throws AppException, InformationalException {

    ReadParticipantAdminRoleList readParticipantAdminRoleList = new ReadParticipantAdminRoleList();
    Person delegate = PersonFactory.newInstance();

    readParticipantAdminRoleList = delegate.listAdminRole(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of administration roles for the specified duplicate
   * concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministratorsForDuplicateParticipant(
   * ReadParticipantAdminRoleListKey)}
   */
  @Deprecated
  public ReadParticipantAdminRoleList listAdminRoleForDuplicate(
    final ReadParticipantAdminRoleListKey key)
    throws AppException, InformationalException {

    ReadParticipantAdminRoleList readParticipantAdminRoleList = new ReadParticipantAdminRoleList();
    Person delegate = PersonFactory.newInstance();

    delegate.listAdminRoleForDuplicate(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of alternate id records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of alternate ID's is
   * returned.
   *
   * @return The list of alternate ID's returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantAlternateIDList listAlternateID(
    final ReadParticipantAlternateIDListKey key)
    throws AppException, InformationalException {

    ReadParticipantAlternateIDList readParticipantAlternateIDList = new ReadParticipantAlternateIDList();
    Person delegate = PersonFactory.newInstance();

    readParticipantAlternateIDList = delegate.listAlternateID(key);
    return readParticipantAlternateIDList;
  }

  /**
   * Method returns a list of AlternateID Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key contains the alternateID of the AlternateID record the snapshots
   * are  associated with.
   *
   * @return The list of AlternateID snapshot details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantAltIDHistoryList listAlternateIDHistory(
    final ReadParticipantAltIDHistoryListKey key)
    throws AppException, InformationalException {

    ReadParticipantAltIDHistoryList readParticipantAltIDHistoryList = new ReadParticipantAltIDHistoryList();
    Person delegate = PersonFactory.newInstance();

    readParticipantAltIDHistoryList = delegate.listAlternateIDHistory(key);
    return readParticipantAltIDHistoryList;
  }

  /**
   * Method returns a list of Assessments for the participant.
   *
   * @param concernRoleKey contains the concern role that the assessments were
   * created for.
   *
   * @return The list of Assessments for the concern role.
   */
  public ParticipantAssessmentsList listAssessments(
    final ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {

    ParticipantAssessmentsList participantAssessmentsList = new ParticipantAssessmentsList();
    Person delegate = PersonFactory.newInstance();

    participantAssessmentsList = delegate.listAssessments(concernRoleKey);
    return participantAssessmentsList;
  }

  /**
   * Retrieves a list of bank accounts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of bank accounts is
   * returned.
   *
   * @return The list of bank accounts returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantBankAccountList listBankAccount(
    final ReadParticipantBankAccountListKey key)
    throws AppException, InformationalException {

    ReadParticipantBankAccountList readParticipantBankAccountList = new  ReadParticipantBankAccountList();
    Person delegate = PersonFactory.newInstance();

    readParticipantBankAccountList = delegate.listBankAccount(key);
    return readParticipantBankAccountList;
  }

  /**
   * Method returns a list of ConcernRole Bank Account Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key contains the ConcernRole Bank Account record the snapshots are
   * associated with.
   *
   * @return The list of ConcernRole Bank Account snapshot details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantBankAcHistoryList listBankAccountHistory(
    final ReadParticipantBankAcHistoryListKey key)
    throws AppException, InformationalException {

    ReadParticipantBankAcHistoryList readParticipantBankAcHistoryList = new ReadParticipantBankAcHistoryList();
    Person delegate = PersonFactory.newInstance();

    readParticipantBankAcHistoryList = delegate.listBankAccountHistory(key);
    return readParticipantBankAcHistoryList;
  }

  /**
   * Lists the formatted bank account details. The bank details
   * are formatted to display as a single line of text.
   *
   * @param key concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ParticipantBankAccountStringList listBankAccountString(
    final MaintainConcernRoleKey key)
    throws AppException, InformationalException {

    ParticipantBankAccountStringList participantBankAccountStringList = new ParticipantBankAccountStringList();
    Person delegate = PersonFactory.newInstance();

    participantBankAccountStringList = delegate.listBankAccountString(key);
    return participantBankAccountStringList;
  }

  /**
   * Lists all communications by case ID.
   *
   * @param key Contains the case identifier.
   * @return List of communications on the case.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public CommunicationDetailList listCommunication(
    final ParticipantCommunicationKey key)
    throws AppException, InformationalException {

    CommunicationDetailList communicationDetailList = new CommunicationDetailList();
    Person delegate = PersonFactory.newInstance();

    communicationDetailList = delegate.listCommunication(key);
    return communicationDetailList;
  }

  /**
   * Retrieves a list of communication exception records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of communication
   * exceptions  are returned.
   *
   * @return The list of communication exceptions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantCommunicationExceptionList listCommunicationException(
    final ReadParticipantCommunicationExceptionListKey key)
    throws AppException, InformationalException {

    ReadParticipantCommunicationExceptionList readParticipantCommunicationExceptionList = new ReadParticipantCommunicationExceptionList();
    Person delegate = PersonFactory.newInstance();

    readParticipantCommunicationExceptionList = delegate.listCommunicationException(
      key);
    return readParticipantCommunicationExceptionList;
  }

  /**
   * Retrieves a list of client role records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantConcernRoleList listConcernRole(
    final ReadParticipantConcernRoleKey key)
    throws AppException, InformationalException {

    ReadParticipantConcernRoleList readParticipantConcernRoleList = new ReadParticipantConcernRoleList();
    Person delegate = PersonFactory.newInstance();

    readParticipantConcernRoleList = delegate.listConcernRole(key);
    return readParticipantConcernRoleList;
  }

  /**
   * Retrieves a list of client role records for a duplicate concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadDuplicateParticipantConcernRoleList listConcernRoleForDuplicate(
    final     ReadParticipantConcernRoleKey key)
    throws AppException, InformationalException {

    ReadDuplicateParticipantConcernRoleList readDuplicateParticipantConcernRoleList = new ReadDuplicateParticipantConcernRoleList();
    Person delegate = PersonFactory.newInstance();

    readDuplicateParticipantConcernRoleList = delegate.listConcernRoleForDuplicate(
      key);
    return readDuplicateParticipantConcernRoleList;
  }

  // BEGIN, CR00294967, MV
  /**
   * A list of contacts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #listConcernContact()}. The
   * return struct of the current method listContact has an
   * aggregation to the struct ConcernContactRMDtls, the attribute
   * statusCode in the struct ConcernContactRMDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct ListConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  // END, CR00294967  
  public ListContactDetails listContact(final ListContactKey key)
    throws AppException, InformationalException {

    ListContactDetails listContactDetails = new ListContactDetails();
    Person delegate = PersonFactory.newInstance();

    listContactDetails = delegate.listContact(key);
    return listContactDetails;
  }
  
  // BEGIN, CR00294967, MV  
  /**
   * Lists the contacts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListConcernContactDetails listConcernContact(final ListContactKey key)
    throws AppException, InformationalException {

    ListConcernContactDetails listConcernContactDetails = new ListConcernContactDetails();
    final Person delegate = PersonFactory.newInstance();

    listConcernContactDetails = delegate.listConcernContact(key);
    return listConcernContactDetails;
  }

  // END, CR00294967

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantDeductionList listDeduction(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ReadParticipantDeductionList readParticipantDeductionList = new ReadParticipantDeductionList();
    Person delegate = PersonFactory.newInstance();

    readParticipantDeductionList = delegate.listDeduction(key);
    return readParticipantDeductionList;
  }

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantDeductionList1 listDeduction1(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ReadParticipantDeductionList1 readParticipantDeductionList1 = new ReadParticipantDeductionList1();
    Person delegate = PersonFactory.newInstance();

    readParticipantDeductionList1 = delegate.listDeduction1(key);
    return readParticipantDeductionList1;
  }

  /**
   * Retrieves a list of deduction records for a duplicate concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadDuplicateParticipantDeductionList listDeductionForDuplicate(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ReadDuplicateParticipantDeductionList readDuplicateParticipantDeductionList = new ReadDuplicateParticipantDeductionList();
    Person delegate = PersonFactory.newInstance();

    readDuplicateParticipantDeductionList = delegate.listDeductionForDuplicate(
      key);
    return readDuplicateParticipantDeductionList;
  }

  /**
   * Retrieves a list of email addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of email addresses
   * is returned.
   *
   * @return The list of email addresses returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantEmailAddressList listEmailAddress(
    final ReadParticipantEmailAddressListKey key)
    throws AppException, InformationalException {

    ReadParticipantEmailAddressList readParticipantEmailAddressList = new ReadParticipantEmailAddressList();
    Person delegate = PersonFactory.newInstance();

    readParticipantEmailAddressList = delegate.listEmailAddress(key);
    return readParticipantEmailAddressList;
  }

  /**
   * Lists all addresses for a participant formatted for use in a pop-up list.
   *
   * @param readParticipantFormattedAddressListKey
   * contains concernRoleID
   *
   * @return List of formatted addresses for participant
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public FormattedAddressList listFormattedAddress(
    final ReadParticipantFormattedAddressListKey
    readParticipantFormattedAddressListKey)
    throws AppException, InformationalException {

    FormattedAddressList formattedAddressList = new FormattedAddressList();
    Person delegate = PersonFactory.newInstance();

    formattedAddressList = delegate.listFormattedAddress(
      readParticipantFormattedAddressListKey);
    return formattedAddressList;
  }

  /**
   * Reads formatted bankAccount data for a Participant.
   *
   * @param readParticipantFormattedBankAccountListKey
   * contains concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public FormattedBankAccountList listFormattedBankAccount(
    final ReadParticipantFormattedBankAccountListKey
    readParticipantFormattedBankAccountListKey)
    throws AppException, InformationalException {

    FormattedBankAccountList formattedBankAccountList = new FormattedBankAccountList();
    Person delegate = PersonFactory.newInstance();

    formattedBankAccountList = delegate.listFormattedBankAccount(
      readParticipantFormattedBankAccountListKey);
    return formattedBankAccountList;
  }

  /**
   * Retrieves a list of clients interaction details.
   *
   * @param key
   * contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListInteractionDetails listInteraction(final ListInteractionKey key)
    throws AppException, InformationalException {

    ListInteractionDetails listInteractionDetails = new ListInteractionDetails();
    Person delegate = PersonFactory.newInstance();

    listInteractionDetails = delegate.listInteraction(key);
    return listInteractionDetails;
  }

  /**
   * Retrieves a list of duplicate client interaction details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListDuplicateParticipantInteractionDetails listInteractionForDuplicate(
    final ListInteractionKey key)
    throws AppException, InformationalException {

    ListDuplicateParticipantInteractionDetails listDuplicateParticipantInteractionDetails = new ListDuplicateParticipantInteractionDetails();
    Person delegate = PersonFactory.newInstance();

    listDuplicateParticipantInteractionDetails = delegate.listInteractionForDuplicate(
      key);
    return listDuplicateParticipantInteractionDetails;
  }

  /**
   * Method returns a list of Investigations for the participant.
   *
   * @param key contains the  concern role that the investigations
   * were created for.
   *
   * @return The list of Investigations for the concern role.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ParticipantInvestigationList listInvestigations(
    final SearchCaseKey_fo key)
    throws AppException, InformationalException {

    ParticipantInvestigationList participantInvestigationList = new ParticipantInvestigationList();
    Person delegate = PersonFactory.newInstance();

    participantInvestigationList = delegate.listInvestigations(key);
    return participantInvestigationList;
  }

  /**
   * Retrieves a list of issued payment instruments for a concern role, where
   * the client is the concern or the nominee.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of payment instruments returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListParticipantIssuedPaymentInstrument listIssuedPaymentInstrument(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ListParticipantIssuedPaymentInstrument listParticipantIssuedPaymentInstrument = new ListParticipantIssuedPaymentInstrument();
    Person delegate = PersonFactory.newInstance();

    listParticipantIssuedPaymentInstrument = delegate.listIssuedPaymentInstrument(
      key);
    return listParticipantIssuedPaymentInstrument;
  }

  /**
   * Retrieves a list of duplicate client issued payment instrument details.
   *
   * @param key Contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListDuplicateParticipantIssuedPaymentInstrument listIssuedPaymentInstrumentForDuplicate(
    ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ListDuplicateParticipantIssuedPaymentInstrument listDuplicateParticipantIssuedPaymentInstrument = new
      ListDuplicateParticipantIssuedPaymentInstrument();
    Person delegate = PersonFactory.newInstance();

    listDuplicateParticipantIssuedPaymentInstrument = delegate.listIssuedPaymentInstrumentForDuplicate(
      key);
    return listDuplicateParticipantIssuedPaymentInstrument;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Retrieve a list of notes for a participant.
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #listNote1()}
   */
  @Deprecated
  public ParticipantNoteList listNote(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList participantNoteList = new ParticipantNoteList();
    Person delegate = PersonFactory.newInstance();

    participantNoteList = delegate.listNote(key);
    return participantNoteList;
  }

  /**
   * Retrieve a list of notes for a participant.
   *
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ParticipantNoteList1 listNote1(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList1 participantNoteList = new ParticipantNoteList1();
    Participant delegate = ParticipantFactory.newInstance();

    participantNoteList = delegate.listNote1(key);
    return participantNoteList;
  }

  // END, CR00231506

  /**
   * Returns a list of financials for a participant.
   *
   * @param key
   * contains the key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  public ListParticipantFinancials listParticipantFinancial(
    final ListParticipantFinancialsKey key) throws AppException,
      InformationalException {
    ListParticipantFinancials listParticipantFinancials = new ListParticipantFinancials();
    Person delegate = PersonFactory.newInstance();

    listParticipantFinancials = delegate.listParticipantFinancial(key);
    return listParticipantFinancials;
  }

  /**
   * Returns a list of financials for a participant.
   *
   * @param key
   * Key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListParticipantFinancials1 listParticipantFinancial1(
    ListParticipantFinancialsKey key)
    throws AppException, InformationalException {

    ListParticipantFinancials1 listParticipantFinancials1 = new  ListParticipantFinancials1();
    Person delegate = PersonFactory.newInstance();

    listParticipantFinancials1 = delegate.listParticipantFinancial1(key);
    return listParticipantFinancials1;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListDuplicateParticipantFinancials listParticipantFinancialForDuplicate(
    final ListParticipantFinancialsKey key)
    throws AppException, InformationalException {

    ListDuplicateParticipantFinancials listDuplicateParticipantFinancials = new ListDuplicateParticipantFinancials();
    Person delegate = PersonFactory.newInstance();

    listDuplicateParticipantFinancials = delegate.listParticipantFinancialForDuplicate(
      key);
    return listDuplicateParticipantFinancials;
  }

  /**
   * Returns a list of tasks for a participant.
   *
   * @param key
   * contains the key to return a list of tasks for a participant.
   *
   * @return List of tasks for a participant.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public TasksForConcernAndCaseDetails listParticipantTask(
    final ListParticipantTaskKey_eo key)
    throws AppException, InformationalException {

    TasksForConcernAndCaseDetails tasksForConcernAndCaseDetails = new TasksForConcernAndCaseDetails();
    Person delegate = PersonFactory.newInstance();

    tasksForConcernAndCaseDetails = delegate.listParticipantTask(key);
    return tasksForConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public TasksForDuplicateConcernAndCaseDetails listParticipantTaskForDuplicate(
    final ListParticipantTaskKey_eo key)
    throws AppException, InformationalException {

    TasksForDuplicateConcernAndCaseDetails tasksForDuplicateConcernAndCaseDetails = new TasksForDuplicateConcernAndCaseDetails();
    Person delegate = PersonFactory.newInstance();

    tasksForDuplicateConcernAndCaseDetails = delegate.listParticipantTaskForDuplicate(
      key);
    return tasksForDuplicateConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of phone number records for a concern role.
   *
   * @param key
   * contains the concern role id for which a list of phone numbers are
   * returned.
   *
   * @return The list of phone numbers returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantPhoneNumberList listPhoneNumber(
    final ReadParticipantPhoneNumberListKey key)
    throws AppException, InformationalException {

    ReadParticipantPhoneNumberList readParticipantPhoneNumberList = new ReadParticipantPhoneNumberList();
    Person delegate = PersonFactory.newInstance();

    readParticipantPhoneNumberList = delegate.listPhoneNumber(key);
    return readParticipantPhoneNumberList;
  }

  /**
   * Lists screening cases for the specified participant.
   *
   * @param key Identifies the concern role
   *
   * @return The screening cases for the participant as read from the database.
   */
  public ParticipantScreeningList listScreeningCases(final SearchCaseKey_fo key)
    throws AppException, InformationalException {

    ParticipantScreeningList participantScreeningList = new ParticipantScreeningList();
    Person delegate = PersonFactory.newInstance();

    participantScreeningList = delegate.listScreeningCases(key);
    return participantScreeningList;
  }

  /**
   * Returns a list of templates based on template type and the participant
   * identifier.
   *
   * @param key
   * contains the key to read the list of templates.
   *
   * @return List of templates for participant.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListTemplateByTypeAndParticpant listTemplateByTypeAndParticipant(
    final ListTemplateByTypeAndParticipantKey key)
    throws AppException, InformationalException {

    ListTemplateByTypeAndParticpant listTemplateByTypeAndParticpant = new ListTemplateByTypeAndParticpant();
    Person delegate = PersonFactory.newInstance();

    listTemplateByTypeAndParticpant = delegate.listTemplateByTypeAndParticipant(
      key);
    return listTemplateByTypeAndParticpant;
  }

  /**
   * Retrieves a list of web addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of web addresses is
   * returned
   * @return The list of web addresses returned from the database
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ParticipantWebAddressList listWebAddress(
    final ParticipantWebAddressListKey key)
    throws AppException, InformationalException {

    ParticipantWebAddressList participantWebAddressList = new ParticipantWebAddressList();
    Person delegate = PersonFactory.newInstance();

    participantWebAddressList = delegate.listWebAddress(key);
    return participantWebAddressList;
  }

  /**
   * Modifies an address record for a concern role.
   *
   * @param details
   * contains the concern role ID and concern role address details.
   *
   * @return ModifiedAddressDetails modified address details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ModifiedAddressDetails modifyAddress(
    final MaintainParticipantAddressDetails details)
    throws AppException, InformationalException {

    ModifiedAddressDetails modifiedAddressDetails = new ModifiedAddressDetails();
    Person delegate = PersonFactory.newInstance();

    modifiedAddressDetails = delegate.modifyAddress(details);
    return modifiedAddressDetails;
  }

  /**
   * Modifies an alternate id record for a concern role.
   *
   * @param details
   * contains the concern role ID and alternate id detail being modified.
   *
   * @return ModifiedAlternateIDDetails modified alternateID details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ModifiedAlternateIDDetails modifyAlternateID(
    final MaintainParticipantAlternateIDDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();
    ModifiedAlternateIDDetails modifiedAlternateIDDetails = new ModifiedAlternateIDDetails();

    modifiedAlternateIDDetails = delegate.modifyAlternateID(details);
    return modifiedAlternateIDDetails;
  }

  /**
   * @param details
   * contains the bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #modifyBankAccountWithTextSortCode()}.
   * Modify the bank account details for a participant.
   */
  @Deprecated
  public InformationMsgDtlsList modifyBankAccount(
    final MaintainParticipantBankAccountDetails details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    Person delegate = PersonFactory.newInstance();

    informationMsgDtlsList = delegate.modifyBankAccount(details);
    return informationMsgDtlsList;
  }

  /**
   * Modify the bank account details for a participant.
   *
   * @param details
   * The bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public InformationMsgDtlsList modifyBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    Person delegate = PersonFactory.newInstance();

    informationMsgDtlsList = delegate.modifyBankAccountWithTextSortCode(details);
    return informationMsgDtlsList;
  }

  /**
   * Modifies the details of a communication.
   *
   * @param details
   * contains the details to modify the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Deprecated
  public void modifyCommunication(final ModifyCommDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.modifyCommunication(details);
  }

  /**
   * Modifies a communication exception record for a concern role.
   *
   * @param details
   * contains the concern role communication exception details being
   * modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void modifyCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.modifyCommunicationException(details);
  }

  // BEGIN, CR00294967, MV
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP3, replaced by
   * {@link #modifyConcernContact()}. The parameter struct of the
   * current method modifyContact has an aggregation to the struct
   * ConcernContactDtls, the attribute statusCode in the struct
   * ConcernContactDtls is modeled with a domain of CONTACTSTATUS
   * code-table, but the corresponding entity attribute
   * ConcernRoleContactDtls.statusCode is modeled with a domain of
   * RECORD_STATUS_CODE. So new method is introduced to have new
   * parameter ModifyConcernContactDetails which has an aggregation
   * to the new struct ConcernContactRMultiDtls where the attribute
   * statusCode is modeled with a domain of RECORD_STATUS_CODE. See
   * release note: CEF-8999.
   */
  // END, CR00294967
  public void modifyContact(final ModifyContactDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.modifyContact(details);
  }
  
  // BEGIN, CR00294967, MV  
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void modifyConcernContact(final ModifyConcernContactDetails details)
    throws AppException, InformationalException {

    final Person delegate = PersonFactory.newInstance();

    delegate.modifyConcernContact(details);
  }

  // END, CR00294967


  /**
   * Modify the details of an email address for a participant.
   *
   * @param details
   * contains the email address details being modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void modifyEmailAddress(
    final MaintainParticipantEmailAddressDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.modifyEmailAddress(details);
  }

  // BEGIN, CR00231506, PDN
  /**
   * Modify the details of a note for a participant.
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #modifyNote1()}
   */
  @Deprecated
  public void modifyNote(final ModifyParticipantNoteDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.modifyNote(details);
  }

  /**
   * Modify the details of a note for a participant.
   *
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void modifyNote1(ModifyParticipantNoteDetails1 details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyNote1(details);
  }

  /**
   * Modifies a phone number record for a concern role.
   *
   * @param details
   * contains the concern role id and concern role phone number details
   * that  will be modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void modifyPhoneNumber(final MaintainParticipantPhoneDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.modifyPhoneNumber(details);
  }

  /**
   * Modifies the details of a sent communication.
   *
   * @param details
   * contains the details of the sent communication to be modified.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void modifySentCommunication(
    final ModifySentCommunicationDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.modifySentCommunication(details);
  }

  /**
   * Modify the details of a web address for a participant.
   *
   * @param details
   * contains the web address details being modified
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void modifyWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.modifyWebAddress(details);
  }

  /**
   * Prints a communication.
   *
   * @param details
   * contains details to print the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void printCommunication(final PrintCommunicationKey details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.printCommunication(details);
  }

  /**
   * Reads an address record for a concern role.
   *
   * @param key
   * contains the concern role address key.
   *
   * @return The address details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantAddressDetails readAddress(
    final ReadParticipantAddressKey key)
    throws AppException, InformationalException {

    ReadParticipantAddressDetails readParticipantAddressDetails = new  ReadParticipantAddressDetails();
    Person delegate = PersonFactory.newInstance();

    readParticipantAddressDetails = delegate.readAddress(key);
    return readParticipantAddressDetails;
  }

  /**
   * Reads an alternate id record for a concern role.
   *
   * @param key
   * contains the concern role alternate id of the record being read.
   *
   * @return The alternate ID details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantAlternateIDDetails readAlternateID(
    final ReadParticipantAlternateIDKey key)
    throws AppException, InformationalException {

    ReadParticipantAlternateIDDetails readParticipantAlternateIDDetails = new ReadParticipantAlternateIDDetails();
    Person delegate = PersonFactory.newInstance();

    readParticipantAlternateIDDetails = delegate.readAlternateID(key);
    return readParticipantAlternateIDDetails;
  }

  /**
   * Read the details of a participants bank account.
   *
   * @param key
   * contains the bank account ID of the record being read.
   *
   * @return The bank account details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantBankAccountDetails readBankAccount(
    final ReadParticipantBankAccountKey key)
    throws AppException, InformationalException {

    ReadParticipantBankAccountDetails readParticipantBankAccountDetails = new ReadParticipantBankAccountDetails();
    Person delegate = PersonFactory.newInstance();

    readParticipantBankAccountDetails = delegate.readBankAccount(key);
    return readParticipantBankAccountDetails;
  }

  /**
   * Reads details of a communication.
   *
   * @param key
   * contains the communication identifier.
   *
   * @return Details of the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Deprecated
  public ReadCommDetails readCommunication(final ReadCommKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();
    ReadCommDetails readCommDetails = new ReadCommDetails();

    readCommDetails = delegate.readCommunication(key);
    return readCommDetails;
  }

  /**
   * Reads details of a communication attachment.
   *
   * @param key
   * contains the key to read the communication attachment details.
   *
   * @return ReadCommunicationAttachmentDetails Details of the communication
   * attachment.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadCommunicationAttachmentDetails readCommunicationAttachment(
    final ReadAttachmentKey key) throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();
    ReadCommunicationAttachmentDetails readCommunicationAttachmentDetails = new ReadCommunicationAttachmentDetails();

    readCommunicationAttachmentDetails = delegate.readCommunicationAttachment(
      key);
    return readCommunicationAttachmentDetails;
  }

  /**
   * Reads a communication exception record for a concern role.
   *
   * @param key
   * contains the communication exception ID of the record being read.
   *
   * @return The communication exception details found returned from the
   * database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantCommunicationExceptionDetails readCommunicationException(
    final ReadParticipantCommunicationExceptionKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();
    ReadParticipantCommunicationExceptionDetails readParticipantCommunicationExceptionDetails = new ReadParticipantCommunicationExceptionDetails();

    readParticipantCommunicationExceptionDetails = delegate.readCommunicationException(
      key);
    return readParticipantCommunicationExceptionDetails;
  }

  /**
   * Reads the concernRoleType for a concernRole.
   *
   * @param key
   * contains the concern role ID for which the concernRoleType is read
   *
   * @return The concernRoleType.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ConcernRoleTypeDetails readConcernRoleType(
    final ReadParticipantConcernRoleKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();
    ConcernRoleTypeDetails concernRoleTypeDetails = new ConcernRoleTypeDetails();

    concernRoleTypeDetails = delegate.readConcernRoleType(key);
    return concernRoleTypeDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #readConcernContact()}. The
   * return struct of the current method readContact has an
   * aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct ReadConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  // END, CR00294967
  public ReadContactDetails readContact(final ReadContactKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();
    ReadContactDetails readContactDetails = new ReadContactDetails();

    readContactDetails = delegate.readContact(key);
    return readContactDetails;
  }
 
  // BEGIN, CR00294967, MV  
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadConcernContactDetails readConcernContact(final ReadContactKey key)
    throws AppException, InformationalException {

    final Person delegate = PersonFactory.newInstance();
    ReadConcernContactDetails readConcernContactDetails = new ReadConcernContactDetails();

    readConcernContactDetails = delegate.readConcernContact(key);
    return readConcernContactDetails;
  }

  // END, CR00294967


  /**
   * Read the context description for a concern role ID.
   *
   * @param key
   * contains the concern role ID for which the description is
   * retrieved.
   *
   * @return The returned description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ParticipantContextDetails readContextDescription(
    final ParticipantContextKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();
    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    participantContextDetails = delegate.readContextDescription(key);
    return participantContextDetails;
  }

  /**
   * Read the details for a participants email address.
   *
   * @param key
   * contains the email address ID of the record being read.
   *
   * @return The email address details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantEmailAddressDetails readEmailAddress(
    final ReadParticipantEmailAddressKey key)
    throws AppException, InformationalException {

    ReadParticipantEmailAddressDetails readParticipantEmailAddressDetails = new ReadParticipantEmailAddressDetails();
    Person delegate = PersonFactory.newInstance();

    readParticipantEmailAddressDetails = delegate.readEmailAddress(key);
    return readParticipantEmailAddressDetails;
  }

  /**
   * Retrieves a person's interaction details.
   *
   * @param key
   * identifies interaction to be found.
   *
   * @return A person's interaction details found.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadInteractionDetails readInteraction(final ReadInteractionKey key)
    throws AppException, InformationalException {

    ReadInteractionDetails readInteractionDetails = new ReadInteractionDetails();
    Person delegate = PersonFactory.newInstance();

    readInteractionDetails = delegate.readInteraction(key);
    return readInteractionDetails;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Read the details of a note for a participant.
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #readNote1()}
   */
  @Deprecated
  public ReadParticipantNoteDetails readNote(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails readParticipantNoteDetails = new ReadParticipantNoteDetails();
    Person delegate = PersonFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote(key);
    return readParticipantNoteDetails;
  }

  /**
   * Read the details of a note for a participant.
   *
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantNoteDetails1 readNote1(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails1 readParticipantNoteDetails = new ReadParticipantNoteDetails1();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote1(key);
    return readParticipantNoteDetails;
  }

  // END, CR00231506

  /**
   * Read the Contact Context Description Details for a Participant.
   *
   * @param key
   * contains the contact ID the context description is returned for.
   *
   * @return The contact context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ContactContextDescriptionDetails readParticipantContactContextDescription(
    final ContactContextDescriptionKey key)
    throws AppException, InformationalException {

    ContactContextDescriptionDetails contactContextDescriptionDetails = new ContactContextDescriptionDetails();
    Person delegate = PersonFactory.newInstance();

    contactContextDescriptionDetails = delegate.readParticipantContactContextDescription(
      key);
    return contactContextDescriptionDetails;
  }

  /**
   * Reads a phone number record for a concern role.
   *
   * @param key contains the concern role phone number ID.
   *
   * @return The phone number details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantPhoneNumberDetails readPhoneNumber(
    final ReadParticipantPhoneNumberKey key)
    throws AppException, InformationalException {

    ReadParticipantPhoneNumberDetails readParticipantPhoneNumberDetails = new  ReadParticipantPhoneNumberDetails();
    Person delegate = PersonFactory.newInstance();

    readParticipantPhoneNumberDetails = delegate.readPhoneNumber(key);
    return readParticipantPhoneNumberDetails;
  }

  /**
   * Read the details for a participants web address.
   *
   * @param key
   * contains the web address ID of the record being read.
   *
   * @return The web address details returned from the database.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadParticipantWebAddressDetails readWebAddress(
    final ParticipantWebAddressKey key)
    throws AppException, InformationalException {

    ReadParticipantWebAddressDetails readParticipantWebAddressDetails = new ReadParticipantWebAddressDetails();
    Person delegate = PersonFactory.newInstance();

    readParticipantWebAddressDetails = delegate.readWebAddress(key);
    return readParticipantWebAddressDetails;
  }

  /**
   * Records an existing communication.
   *
   * @param details
   * contains the details of the existing communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Deprecated
  public void recordExistingCommunication(
    final RecordExistingCommunicationDetails details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.recordExistingCommunication(details);
  }

  /**
   * Removes an address record for a concern role.
   *
   * @param key contains the concern role address key
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void removeAddress(final ReadParticipantAddressKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.removeAddress(key);
  }

  /**
   * Resolves the home page for prospect person and prospect employer.
   *
   * Security checks are not applied in this method as it must be used from
   * the resolve script only.
   *
   * @param key contains the concern Role ID of the record being read.
   *
   * @return The home page name.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ParticipantHomePageName resolveProspectHome(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ParticipantHomePageName participantHomePageName = new ParticipantHomePageName();
    Person delegate = PersonFactory.newInstance();

    participantHomePageName = delegate.resolveProspectHome(key);
    return participantHomePageName;
  }

  // BEGIN, CR00233791, DJ
  // BEGIN, CR00290965, IBM
  /**
   * Searches for all Participants by specified search criteria.
   *
   * @param key Participant search criteria
   *
   * @return Participant details found
   *
   * @throws AppException Application Exception
   *
   * @throws InformationalException Informational Exception
   * @deprecated Since Curam 6.0 SP2, replaced with {@link 
   * ProspectPerson#searchParticipantDetails(AllParticipantSearchKey)}
   *
   * This method is deprecated as informational messages are not returned. This 
   * method is replaced by searchParticipantDetails(AllParticipantSearchKey) 
   * which returns the informational message along with participant details 
   * as well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public AllParticipantSearchResult searchParticipant(
    final AllParticipantSearchKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    AllParticipantSearchResult allParticipantSearchResult = new AllParticipantSearchResult();
    Person delegate = PersonFactory.newInstance();

    allParticipantSearchResult = delegate.searchParticipant(key);
    return allParticipantSearchResult;
  }

  // END, CR00233791

  /**
   * Sends an email communication.
   *
   * @Deprecated
   * @param details
   * contains the details to send the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Deprecated
  public void sendEmailCommunication(final SendEmailCommKey details)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.sendEmailCommunication(details);
  }

  /**
   * Updates the payment details for all cases, where the old bank account was
   * being paid, to the new bank account.
   *
   * @param key
   * contains the concern role ID and the bank
   * account ID of the bank for which payment will now be made to.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void updateBankAccountPaymentDetails(
    final UpdateBankAccPaymentDtlsKey key)
    throws AppException, InformationalException {

    Person delegate = PersonFactory.newInstance();

    delegate.updateBankAccountPaymentDetails(key);
  }

  /**
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createBankAccountWithTextSortCode()}.
   * Create a new bank account for a participant.
   */
  @Deprecated
  public CreateParticipantBankAccountDetails createBankAccount(
    final MaintainParticipantBankAccountDetails details)
    throws AppException, InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails = new CreateParticipantBankAccountDetails();
    Person delegate = PersonFactory.newInstance();

    createParticipantBankAccountDetails = delegate.createBankAccount(details);
    return createParticipantBankAccountDetails;
  }

  /**
   * Create a new bank account for a participant.
   *
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public CreateParticipantBankAccountDetails createBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails = new CreateParticipantBankAccountDetails();
    Person delegate = PersonFactory.newInstance();

    createParticipantBankAccountDetails = delegate.createBankAccountWithTextSortCode(
      details);
    return createParticipantBankAccountDetails;
  }

  // END, CR00228866

  // BEGIN, CR00234515, DJ
  /**
   * Reads a person's home page details and further details
   *
   * @param key
   * Identifies the person concerned
   *
   * @return The home page details of the person.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadPersonHomeDetails readHomePageDetails(ReadPersonHomeKey key)
    throws AppException, InformationalException {

    ReadPersonHomeDetails readPersonHomeDetails = new ReadPersonHomeDetails();
    Person delegate = PersonFactory.newInstance();

    readPersonHomeDetails = delegate.readHomePageDetails(key);
    return readPersonHomeDetails;
  }

  // END, CR00234515

  // BEGIN, CR00282028, IBM
  /**
   * Search person details by provided search criteria.
   *
   * @param personSearchKey1
   * contains the person search criteria.
   *
   * @return person details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PersonSearchDetailsResult searchPersonDetails(final PersonSearchKey1 personSearchKey1)
    throws AppException, InformationalException {
    
    PersonSearchDetailsResult personSearchResult = new PersonSearchDetailsResult();
    
    Person person = PersonFactory.newInstance();

    personSearchResult = person.searchPerson(personSearchKey1);
    
    return personSearchResult;
  }

  /**
   * Search person details by provided search criteria. This is used for popup 
   * pages and does not return names as hyperlinks.
   *
   * @param personSearchKey1
   * contains the person search criteria.
   *
   * @return person details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */           
  public PersonSearchDetailsResult searchPersonForPopup(final PersonSearchKey1 personSearchKey1)
    throws AppException, InformationalException {
    
    PersonSearchDetailsResult personSearchResult = new PersonSearchDetailsResult();
    
    Person person = PersonFactory.newInstance();

    personSearchResult = person.searchPersonForPopup(personSearchKey1);
    
    return personSearchResult;
  }

  // END, CR00282028

  // BEGIN, CR00290965, IBM
  /**
   * Searches for all participants by specified search criteria.
   *
   * @param allParticipantSearchKey contains all participant search key
   *
   * @return participant search details
   *
   * @throws AppException Application Exception
   * @throws InformationalException Informational Exception
   */
  public AllParticipantSearchDetails searchParticipantDetails(
    final AllParticipantSearchKey allParticipantSearchKey) throws AppException, InformationalException {
   
    AllParticipantSearchDetails allParticipantSearchDetails = new AllParticipantSearchDetails();
    
    Person person = PersonFactory.newInstance();

    allParticipantSearchDetails = person.searchParticipantDetails(
      allParticipantSearchKey);
    
    return allParticipantSearchDetails;
  }

  // END, CR00290965
  
  // BEGIN, CR00386007, VT
  /**
   * Validates the estimated from age and estimated to age values.
   *
   * @param prospectPersonRegistrationDtls contains all prospect person registration details
   *
   * @throws InformationalException Informational Exception
   * @throws AppException Application Exception
   */
  public void validateProspectPersonEstimatedAge(ProspectPersonRegistrationDtls prospectPersonRegistrationDtls)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    /**
     * Define the numeric pattern
     */
    final String NUMERIC_PATTERN = "[\\d]*";

    if (!Pattern.matches(NUMERIC_PATTERN,
      prospectPersonRegistrationDtls.estimatedFromAgeOpt)) {

      LocalisableString infoMessage = new LocalisableString(
        BPOPROSPECTPERSONREGISTRATION.ERR_FV_PROSPECT_PERSON_ESTIMATED_FROM_AGE_MUST_BE_A_WHOLE_NUMBER);

      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, GeneralConstants.kEmpty, 
        InformationalElement.InformationalType.kError,
        ValidationManagerConst.kSetOne, 0);
    }

    if (!Pattern.matches(NUMERIC_PATTERN,
      prospectPersonRegistrationDtls.estimatedToAgeOpt)) {
      LocalisableString infoMessage = new LocalisableString(
        BPOPROSPECTPERSONREGISTRATION.ERR_FV_PROSPECT_PERSON_ESTIMATED_TO_AGE_MUST_BE_A_WHOLE_NUMBER);

      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, GeneralConstants.kEmpty, 
        InformationalElement.InformationalType.kError,
        ValidationManagerConst.kSetOne, 0);
    }

    informationalManager.failOperation();

  }
  // END, CR00386007

}
