/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;

import curam.codetable.LOCATIONACCESSTYPE;
import curam.core.sl.struct.ParticipantSearchKey;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.AlternateIDSearchKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ReadServiceSupplierSummaryKey;
import curam.core.struct.SearchMessageDtls;
import curam.core.struct.ServSuppSummaryDetails;
import curam.core.struct.ServSuppSummaryDetailsList;
import curam.core.struct.ServSupplierAltSearchDetails;
import curam.core.struct.ServSupplierAltSearchKey;
import curam.core.struct.ServSupplierReadDtls;
import curam.core.struct.ServiceSupplierDatabaseSearchKey;
import curam.core.struct.ServiceSupplierSearchDtls;
import curam.core.struct.ServiceSupplierSearchKey;
import curam.core.struct.ServiceSupplierSearchResult;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;

/**
 * @deprecated Since Curam 6.0, This class is replaced by
 * {@link curam.core.sl.impl.DatabaseParticipantSearch}
 *
 * Service Supplier search in Database
 *
 */
@Deprecated
public abstract class DatabaseServiceSupplierSearch extends curam.core.base.DatabaseServiceSupplierSearch {

  /**
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.sl.impl.DatabaseParticipantSearch#search(ParticipantSearchKey)}
   *
   * Performs a database search for product provider using the specified search
   * criteria, or performs a database read if the alternate ID is specified.
   *
   * @param key data on which the searched will be based
   *
   * @return The details of any records found
   *
   */
  @Deprecated
  public ServiceSupplierSearchResult search(ServiceSupplierSearchKey key)
    throws AppException, InformationalException {

    ServiceSupplierSearchResult serviceSupplierSearchResult =
      new ServiceSupplierSearchResult();
    ServSuppSummaryDetailsList servSuppSummaryDetailsList =
      new ServSuppSummaryDetailsList();

    ReadServiceSupplierSummaryKey readServiceSupplierSummaryKey =
      new ReadServiceSupplierSummaryKey();

    curam.core.intf.ServiceSupplier serviceSupplierObj =
      curam.core.fact.ServiceSupplierFactory.newInstance();

    // If the reference number is specified no need to process the complicated
    // query
    if (key.referenceNumber.length() == 0) {

      ServiceSupplierDatabaseSearchKey serviceSupplierDatabaseSearchKey =
        calculateKey(key);

      try {
        servSuppSummaryDetailsList =
          serviceSupplierObj.searchByNameOrAddress(
            serviceSupplierDatabaseSearchKey);
      } catch (curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage =
          //BEGIN, CR00163471, JC
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS.getMessageText(TransactionInfo.getProgramLocale());
          //END, CR00163471, JC

        serviceSupplierSearchResult.searchMessageDtlsList.dtls.addRef(
          recordFoundMessage);

      }

      // BEGIN CR00020852, SG
    } else {
      readServiceSupplierSummaryKey.primaryAlternateID = key.referenceNumber;
      try {
        servSuppSummaryDetailsList =
          serviceSupplierObj.readSummaryDetailsByReferenceNumber(
            readServiceSupplierSummaryKey);
      } catch (curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage =
          //BEGIN, CR00163471, JC
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS.getMessageText(TransactionInfo.getProgramLocale());
          //END, CR00163471, JC

        serviceSupplierSearchResult.searchMessageDtlsList.dtls.addRef(
          recordFoundMessage);

      }
    }
    // END CR00020852

    serviceSupplierSearchResult.searchResults.numRecordsFound =
      servSuppSummaryDetailsList.dtls.size();

    for (int i = 0; i < servSuppSummaryDetailsList.dtls.size(); i++) {

      // Search details
      ServiceSupplierSearchDtls serviceSupplierSearchDtls =
        new ServiceSupplierSearchDtls();

      ServSuppSummaryDetails servSuppSummaryDetails =
        servSuppSummaryDetailsList.dtls.item(i);

      serviceSupplierSearchDtls.assign(servSuppSummaryDetails);

      serviceSupplierSearchDtls.address = servSuppSummaryDetails.addressLine1;

      restrictResults(serviceSupplierSearchDtls);

      if (serviceSupplierSearchDtls.referenceNumber != null) {
        serviceSupplierSearchResult.serviceSupplierSearchDtlsLst.dtls.addRef(
          serviceSupplierSearchDtls);
      } else {
        serviceSupplierSearchResult.searchResults.numRecordsFound =
          serviceSupplierSearchResult.searchResults.numRecordsFound - 1;
      }
    }

    return serviceSupplierSearchResult;
  }

  /**
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.sl.impl.DatabaseParticipantSearch#search(ParticipantSearchKey)}
   *
   * Reads service supplier information from database according to the alternate
   * reference number
   *
   * @param key reference number to be searched for
   *
   * @return details found
   *
   */
  @Deprecated
  public ServSupplierReadDtls readByReferenceNumber(AlternateIDSearchKey key)
    throws AppException, InformationalException {

    ServSupplierReadDtls servSupplierReadDtls = new ServSupplierReadDtls();

    // variables for service supplier
    curam.core.intf.ServiceSupplier serviceSupplierObj =
      curam.core.fact.ServiceSupplierFactory.newInstance();
    ServSupplierAltSearchDetails servSupplierAltSearchDetails;
    ServSupplierAltSearchKey servSupplierAltSearchKey =
      new ServSupplierAltSearchKey();

    // concern role variables
    curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // address variables
    curam.core.intf.Address addressObj =
      curam.core.fact.AddressFactory.newInstance();
    AddressDtls addressDtls;
    AddressKey addressKey = new AddressKey();

    OtherAddressData otherAddressData = new OtherAddressData();

    // concern role security entity
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();

    // set search key from parameter
    servSupplierAltSearchKey.primaryAlternateID = key.alternateID;

    // do service supplier search
    servSupplierAltSearchDetails =
      serviceSupplierObj.readByAlternateID(servSupplierAltSearchKey);

    // set search key for concern role according service supplier found
    concernRoleKey.concernRoleID = servSupplierAltSearchDetails.concernRoleID;

    // do concern role search
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // BEGIN, CR00226315, PM
    ParticipantSecurityCheckKey participantSecurityCheckKey =
      new ParticipantSecurityCheckKey();

    // perform concern role sensitivity check
    participantSecurityCheckKey.participantID =
      servSupplierAltSearchDetails.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity
        .checkParticipantSecurity(participantSecurityCheckKey);

    // pass out the indicator
    if (dataBasedSecurityResult.restricted) {

      // Return no details to client if User does not have access
      servSupplierReadDtls.name = CuramConst.gkRestricted;
      servSupplierReadDtls.addressData = CuramConst.gkRestricted;
      servSupplierReadDtls.concernID = 0;
      servSupplierReadDtls.restricted = true;
      return servSupplierReadDtls;

    } else {

      // set search key according the concern role found
      addressKey.addressID = concernRoleDtls.primaryAddressID;

      // do address search
      addressDtls = addressObj.read(addressKey);

      // set the return values
      servSupplierReadDtls.name = servSupplierAltSearchDetails.name;

      otherAddressData.addressData = addressDtls.addressData;

      addressObj.getAddressStrings(otherAddressData);

      servSupplierReadDtls.addressData = otherAddressData.addressData;

      servSupplierReadDtls.concernID = concernRoleDtls.concernID;
    }

    // If the location data security is on then access denied
    if (!dataBasedSecurityResult.result) {
      return null;
    }
    // END, CR00226315

    return servSupplierReadDtls;
  }

  /**
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.sl.impl.DatabaseParticipantSearch#calculateKey(ParticipantSearchKey)}
   *
   * Calculates the details of the database search key based on the key
   *
   * @param key search details
   *
   * @return Key for database search
   *
   */
  @Deprecated
  protected ServiceSupplierDatabaseSearchKey calculateKey(
    ServiceSupplierSearchKey key)
    throws AppException, InformationalException {

    ServiceSupplierDatabaseSearchKey serviceSupplierDatabaseSearchKey =
      new ServiceSupplierDatabaseSearchKey();

    // Assign the key values
    serviceSupplierDatabaseSearchKey.name =
      CuramConst.gkSqlWildcard + key.name.toUpperCase()
      + CuramConst.gkSqlWildcard;

    serviceSupplierDatabaseSearchKey.addressLine1 =
      CuramConst.gkSqlWildcard + key.address.toUpperCase()
      + CuramConst.gkSqlWildcard;

    serviceSupplierDatabaseSearchKey.city =
      CuramConst.gkSqlWildcard + key.city.toUpperCase()
      + CuramConst.gkSqlWildcard;

    // If a parameter is specified set the searchBy indicator for that parameter
    serviceSupplierDatabaseSearchKey.searchByName = (key.name.length() > 0);
    serviceSupplierDatabaseSearchKey.searchByAddressLine1 =
      (key.address.length() > 0);
    serviceSupplierDatabaseSearchKey.searchByCity = (key.city.length() > 0);

    return serviceSupplierDatabaseSearchKey;
  }
}
