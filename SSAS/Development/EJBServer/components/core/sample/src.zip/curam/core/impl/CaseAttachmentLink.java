/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.struct.CancelCaseAttachmentLinkDetails;
import curam.core.struct.CancelCaseAttachmentLinkKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Functions for manipulating Case Attachment Link.
 */
public abstract class CaseAttachmentLink extends curam.core.base.CaseAttachmentLink {

  /*
   * Sets the record status to cancelled
   *
   * @param cancelCaseAttachmentLinkKey Contains the case attachment link id
   * @param cancelCaseAttachmentLinkDetails Contains the version number and record status
   */
  protected void precancel(
    CancelCaseAttachmentLinkKey cancelCaseAttachmentLinkKey,
    CancelCaseAttachmentLinkDetails cancelCaseAttachmentLinkDetails)
    throws AppException, InformationalException {

    // Set the record Status to cancelled
    cancelCaseAttachmentLinkDetails.recordStatus = RECORDSTATUS.CANCELLED;

  }

}
