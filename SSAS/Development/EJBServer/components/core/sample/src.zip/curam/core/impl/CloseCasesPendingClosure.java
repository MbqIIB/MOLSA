/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2002,2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.core.fact.CaseClosureFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.impl.CuramBatch;
import curam.core.struct.BatchProcessDtls;
import curam.core.struct.BatchProcessingDate;
import curam.core.struct.CaseClosureByClosureDateAndStatusKey;
import curam.core.struct.CaseClosureDtls;
import curam.core.struct.CaseClosureDtlsList;
import curam.core.struct.Count;
import curam.message.BPOCASEEVENTS;
import curam.message.BPOCLOSECASEPENDINGCLOSURE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;


/**
 * Batch process for closing all cases pending closure.
 *
 */
public abstract class CloseCasesPendingClosure extends curam.core.base.CloseCasesPendingClosure {
  // BEGIN, CR00342584, AC
  final CuramBatch curamBatchObj = new CuramBatch();

  // END, CR00342584

  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * batch process
   */
  static class MultiCloseCasesPendingClosure extends curam.util.dataaccess.ReadmultiOperation {

    // BEGIN CR00108593, GBA
    // Add injection for using the new CaseTransactionLog API
    public MultiCloseCasesPendingClosure() {
      GuiceWrapper.getInjector().injectMembers(this);
    }

    @Inject
    protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

    // END CR00108593

    // _________________________________________________________________________
    /**
     * The specialized readmulti operation based on
     * <code>CaseClosure.searchForPending</code> function, which closes all
     * the cases returned.
     *
     * @param objDtls
     * The case closure details containing the identifier of the
     * case to be closed
     *
     * @return <code>true</code> to allow it to move onto the next case.
     */
    public boolean operation(Object objDtls) throws AppException,
        InformationalException {

      CaseClosureDtls caseClosureDtls = (CaseClosureDtls) objDtls;

      curam.core.intf.ProcessCaseClosure processCaseClosureObj = curam.core.fact.ProcessCaseClosureFactory.newInstance();

      processCaseClosureObj.processPendingClosure(caseClosureDtls);

      // BEGIN, CR00022728, RR
      if (caseClosureDtls != null && caseClosureDtls.caseID != 0) {
        // Log Transaction Details

        // BEGIN CR00108593, GBA
        LocalisableString description = new LocalisableString(
          BPOCASEEVENTS.PRODUCTDELIVERY_PENDINGCLOSURE);

        caseTransactionLogProvider.get().recordCaseTransaction(
          CASETRANSACTIONEVENTS.PRODUCTDELIVERY_PENDINGCLOSURE, description,
          caseClosureDtls.caseID, caseClosureDtls.caseID);
        // END CR00108593
      }
      // END, CR00022728
      return true;

    }

  }

  // ___________________________________________________________________________
  /**
   * Batch process for closing all the cases and associated records with case
   * status <code>pending closure</code> and closure date of today or before.
   * This batch process takes a processing date.
   *
   * @param batchProcessingDate
   * The business date for which the batch process will be run. If
   * this is set, this is the date that will be returned by any
   * call to <code>getCurrentDate</code>.
   */
  public void closeCasesPendingClosure(BatchProcessingDate batchProcessingDate)
    throws AppException, InformationalException {

    // The closing of cases delivers some notifications to individuals
    // involved in the case. The batch user name needs to be set to ensure
    // that the messages in these notifications are correct.
    if (StringUtil.isNullOrEmpty(TransactionInfo.getProgramUser())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSCANTASKDEADLINES.ERR_BATCH_USERNAME_NOT_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // CaseClosure manipulation variables
    CaseClosureByClosureDateAndStatusKey caseClosureByClosureDateAndStatusKey = new CaseClosureByClosureDateAndStatusKey();

    // read all the cases with status Pending Closure
    caseClosureByClosureDateAndStatusKey.closureDate = curam.util.type.Date.getCurrentDate();

    caseClosureByClosureDateAndStatusKey.statusCode = CASESTATUS.PENDINGCLOSURE;
    // BEGIN, CR00349021, AC
    final BatchProcessDtls batchProcessDtls = new BatchProcessDtls();

    batchProcessDtls.startDateTime = curamBatchObj.startTime;
    sendBatchProcess(batchProcessDtls, CuramConst.gkStringZero,
      batchProcessingDate);
    // END, CR00349021
    // readmulti object as defined above
    // this is used to process the list returned by the search below
    MultiCloseCasesPendingClosure multiCloseCasesPendingClosureObj = new MultiCloseCasesPendingClosure();

    // register the security implementation
    SecurityImplementationFactory.register();

    // search for cases pending closure on this date
    curam.core.fact.CaseClosureFactory.newInstance().searchForPending(
      caseClosureByClosureDateAndStatusKey, multiCloseCasesPendingClosureObj);
  }

  // BEGIN,CR00349021, AC
  // BEGIN, CR00342584, AC
  /**
   * Composes and sends the batch report for this batch program.
   *
   * @param batchProcessDtls
   * contains batchProcess business date for which the batch
   * process will be run. If this is set.
   * @param instanceID
   * contains the batch instance id.
   * @param processingDate
   * contains the batch processing date.
   *
   * @throws InformationalException.
   * @throws AppException.
   */
  public void sendBatchProcess(final BatchProcessDtls batchProcessDtls,
    final String instanceID, final BatchProcessingDate processingDate) throws AppException,
      InformationalException {
    curamBatchObj.setStartTime();
    final int kStringBufferSize = 4096;
    final StringBuffer emailMessage = new StringBuffer(kStringBufferSize);

    final CaseClosureByClosureDateAndStatusKey caseClosureByClosureDateAndStatusKey = new CaseClosureByClosureDateAndStatusKey();

    // If no processingDateTo is specified use the current date
    // BEGIN, CR00349374, AC
    if (processingDate.processingDate.isZero()) {
      processingDate.processingDate = Date.getCurrentDate();
    }
    // END, CR00349374

    caseClosureByClosureDateAndStatusKey.closureDate = processingDate.processingDate;
    caseClosureByClosureDateAndStatusKey.statusCode = CASESTATUS.PENDINGCLOSURE;
    CaseClosureDtlsList caseClosureDtlsList = CaseClosureFactory.newInstance().searchForPending(
      caseClosureByClosureDateAndStatusKey);

    int totalNoOfCasesClosed = caseClosureDtlsList.dtls.size();

    if (totalNoOfCasesClosed >= 0) {

      AppException infTotalClosedCasesProcessedText = new AppException(
        BPOCLOSECASEPENDINGCLOSURE.INF_CLOSECASE_PROCESSED);

      infTotalClosedCasesProcessedText.arg(totalNoOfCasesClosed);

      emailMessage.append(CuramConst.gkNewLine).append(infTotalClosedCasesProcessedText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
        CuramConst.gkNewLine);
    }
    final Count count = CaseClosureFactory.newInstance().countNumberOfPendingCasesbyStatus(
      caseClosureByClosureDateAndStatusKey);

    int totalNoOfPendingCaseProcessed = count.numberOfRecords;

    if (totalNoOfPendingCaseProcessed >= 0) {

      AppException infTotalCasesProcessedText = new AppException(
        BPOCLOSECASEPENDINGCLOSURE.INF_TOTALPENDINGCASES_PROCESSED);

      infTotalCasesProcessedText.arg(totalNoOfPendingCaseProcessed);
      emailMessage.append(CuramConst.gkNewLine).append(infTotalCasesProcessedText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
        CuramConst.gkNewLine);

    }
    curamBatchObj.emailMessage = emailMessage.toString();
    curamBatchObj.setEmailSubject(
      BPOCLOSECASEPENDINGCLOSURE.INF_CLOSECASEPENDINGCLOSURE_SUB);

    curamBatchObj.outputFileID = BPOCLOSECASEPENDINGCLOSURE.INF_CLOSECASEPROCESS_ID.getMessageText(
      ProgramLocale.getDefaultServerLocale());
    curamBatchObj.setEndTime();
    curamBatchObj.sendEmail();
  }
  // END, CR00342584
  // END, CR00349021

}
