/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005, 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import curam.core.struct.BatchProcessingDate;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.GetCaseEventData;
import curam.core.struct.PendingCommunicationsDtls;
import curam.core.struct.PendingCommunicationsKey;
import curam.core.struct.ProFormaDocumentData;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.transaction.TransactionInfo;

/**
 * This is a batch program which will store all case communications during
 * the day.  It will then be run at end of day to print all of the
 * communications.  After each communication has been printed the record will
 * then be deleted from the batch file.
 *
 */
public abstract class GenerateCommunications extends curam.core.base.GenerateCommunications {
    
  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * batch process
   */
  static class ProcessPendingCommunications extends curam.util.dataaccess.ReadmultiOperation {

    // _________________________________________________________________________
    /**
     * Specialized readmulti operation based on PendingCommunications.readAll,
     * which prints all pending communications and deletes them from the batch
     * file.
     *
     * @param objDtls Reference to a PendingCommunicationDtls object
     *
     * @return True
     */
    public boolean operation(Object objDtls) throws AppException, InformationalException {

      // cast incoming object
      PendingCommunicationsDtls pendingCommunicationsDtls =
        (PendingCommunicationsDtls) objDtls;
            

      // variables for generation of document
      curam.core.intf.ConcernRoleDocumentGeneration concernRoleDocumentGenerationObj =
        curam.core.fact.ConcernRoleDocumentGenerationFactory.newInstance();
      GetCaseEventData getCaseEventData = new GetCaseEventData();
      ProFormaDocumentData proFormaDocumentData = new ProFormaDocumentData();

      // in the future there may be non case related communications,
      // when this happens include the following
      // if (dtls.caseID != 0) {

      getCaseEventData.caseID = pendingCommunicationsDtls.caseID;
      getCaseEventData.caseCommunicationType =
        pendingCommunicationsDtls.caseCommunicationType;
      getCaseEventData.eventDate = pendingCommunicationsDtls.eventDate;
      getCaseEventData.concernRoleID = pendingCommunicationsDtls.concernRoleID;

      // populate the reason code
      if (pendingCommunicationsDtls.caseID != 0) {

        CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();

        currentCaseStatusKey.caseID = pendingCommunicationsDtls.caseID;

        curam.core.intf.CaseStatus caseStatusObj =
          curam.core.fact.CaseStatusFactory.newInstance();

        // BEGIN, CR00224271, ZV
        proFormaDocumentData.reason =
          caseStatusObj.readCurrentStatusByCaseID1(currentCaseStatusKey)
            .reasonCode;
        // END, CR00224271

      }
       // BEGIN, CR00146629, SK
      // generate document
      try {
        concernRoleDocumentGenerationObj.getCaseEventData(getCaseEventData,
            proFormaDocumentData);
      

      // remove the current record from the pending communications table
      // now that it has been printed

      // object and struct for removing the current record
      curam.core.intf.PendingCommunications pendingCommunicationsObj =
        curam.core.fact.PendingCommunicationsFactory.newInstance();
      PendingCommunicationsKey pendingCommunicationsKey =
        new PendingCommunicationsKey();

      pendingCommunicationsKey.pendingCommID =
        pendingCommunicationsDtls.pendingCommID;
      pendingCommunicationsObj.remove(pendingCommunicationsKey);
      
      }catch(AppException ae) {
          if(!ae.getCatEntry().equals(
                  curam.message.GENERALCONCERN.
                  ERR_PROFORMATEMPLATE_WITH_LOCALE_FOR_BATCHPROCESSING_RNFE)) {
              throw ae;
          } 
      }
     // END, CR00146629
      return true;
      
    }

  }

  // ___________________________________________________________________________
  /**
   * This is a batch program which will run at the end of day, and print all of
   * the communications that are pending. This process takes a processing date.
   *
   * @param batchProcessingDate The business date for which the batch process
   *                            will be run. If this is set, this is the date
   *                            that will be returned by 'getCurrentDate'.
   *
   */
  public void generateAllCommunications(BatchProcessingDate batchProcessingDate)
    throws AppException, InformationalException {

    // entity object used to search for pending communications
    curam.core.intf.PendingCommunications pendingCommunicationsObj =
      curam.core.fact.PendingCommunicationsFactory.newInstance();

    // instance of readmulti object defined above, used to process list
    // returned from the search below
    ProcessPendingCommunications processPendingCommunicationsObj =
      new ProcessPendingCommunications();

    // register the security implementation
    SecurityImplementationFactory.register();

    // call the search, passing in the readmulti object
    pendingCommunicationsObj.readAll(processPendingCommunicationsObj);
    
    // BEGIN, CR00146629, SK
    HashMap proceedLogMap = new HashMap();
    HashMap errorLogMap = new HashMap();
    final int kStringBufferSize = 4096;
    StringBuffer proceedMessage = new StringBuffer(kStringBufferSize);
    StringBuffer nonProceedMessage = new StringBuffer(kStringBufferSize);
    StringBuffer emailMessage = new StringBuffer(kStringBufferSize);
    if(TransactionInfo.getFacadeScopeObject(
            CuramConst.gkXsltemplateProceed) != null) {
        proceedLogMap.putAll((Map) TransactionInfo.getFacadeScopeObject(
                CuramConst.gkXsltemplateProceed));
        proceedMessage = batchLog(proceedLogMap);
    }
    if(TransactionInfo.getFacadeScopeObject(
            CuramConst.gkXsltemplateNotProceed) != null) {
        errorLogMap.putAll((Map) TransactionInfo.getFacadeScopeObject(
                CuramConst.gkXsltemplateNotProceed));
        nonProceedMessage = batchLog(errorLogMap);
    }
    
    curam.core.impl.CuramBatch curamBatchObj = new curam.core.impl.CuramBatch();
    curamBatchObj.setEndTime(); // set end time for batch processing
    curamBatchObj.emailMessage = emailMessage.append(proceedMessage).
                          append(nonProceedMessage).toString();

    // Constructing the E-mail Subject
    curamBatchObj.setEmailSubject(
      curam.message.BPOCOMMUNICATION.INF_GENERATECOMMUNICATIONS_SUB);

    // Setting output log file id
    curamBatchObj.outputFileID =
      curam.message.BPOCOMMUNICATION.
              INF_GENERATE_COMMUNICATIONS_LOG_FILE_NAME.getMessageText();
                                                           
    // Sending the e-mail
    curamBatchObj.sendEmail();  
   // END, CR00146629
   
  }
  
  // BEGIN, CR00146629, SK
  //___________________________________________________________________________
  /**
   * This method will take the facade object and retrieve the value for each key
   * and send it back for generating batch report.
   *
   * @param batchLogMap      Hash map of the process or non process log.
   * @return                 This messages will be printed on batch report.
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00198672, VK
  protected StringBuffer batchLog(HashMap batchLogMap) 
  throws AppException, InformationalException{
      // END, CR00198672
      final int kStringBufferSize = 4096;
      StringBuffer emailMessage = new StringBuffer(kStringBufferSize);
      
          List batchList = new ArrayList(batchLogMap.entrySet()); 
          
          Iterator iter = batchList.iterator();  
          Map.Entry map;
          ArrayList list;
          
          while(iter.hasNext()){  
              map =(Map.Entry)iter.next();
              list = (ArrayList) map.getValue();
              
          for(int i=0;i<list.size();i++) {
              LocalisableString errorMsg = (LocalisableString) list.get(i);
              emailMessage.append(CuramConst.gkNewLine)
              .append(errorMsg.getMessage()).append(
              CuramConst.gkNewLine);
              }
    
          }  
     return emailMessage;        
  }
  // END, CR00146629
}