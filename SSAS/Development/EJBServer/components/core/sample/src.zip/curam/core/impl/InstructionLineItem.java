/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2007, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.codetable.CREDITDEBIT;
import curam.codetable.ILICATEGORY;
import curam.codetable.ILISTATUS;
import curam.codetable.ILITYPE;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.struct.BatchProcessingIDList;
import curam.core.struct.GetDetailsForGenerateInstrumentsKey;
import curam.core.struct.ILICaseIDAndObjectiveKey;
import curam.core.struct.ILICaseIDNomineeAndObjectiveKey;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.SeachDeductionILIsByNomineeKey;
import curam.core.struct.SearchDeductionILIsByParticipantRoleIDKey;
import curam.core.struct.SearchDetailsForTransferILIsKey;
import curam.core.struct.SearchTaxILIsByNomineeKey;
import curam.core.struct.SearchTaxILIsByParticipantRoleIDKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Pre and post data access routines for InstructionLineItem
 */
public abstract class InstructionLineItem extends curam.core.base.InstructionLineItem {

  // ___________________________________________________________________________
  /**
   * Pre data access for the method readLatestCoverPeriodToForCaseAndObjective.
   * This sets the iliStatusCodes which will be used in the read.
   */
  protected void prereadLatestCoverPeriodToForCaseAndObjective(ILICaseIDAndObjectiveKey key)
    throws AppException, InformationalException {

    key.statusCode = ILISTATUS.CANCELLED;
    key.iliStatusCodeExpired = ILISTATUS.EXPIRED;
    key.iliStatusCodeProcessed = ILISTATUS.PROCESSED;
    key.iliStatusCodeUnprocessed = ILISTATUS.UNPROCESSED;
    key.iliStatusCodeAllocated = ILISTATUS.ALLOCATED;
    // BEGIN, CR00077815, NP
    key.iliStatusCodeTransferred = ILISTATUS.TRANSFERRED;
    // END, CR00077815
  }
  
  // BEGIN, CR00296014, KH
  // ___________________________________________________________________________
  /**
   * Pre data access for the method readLatestCoverPeriodToForCaseAndListObjective.
   * This sets the iliStatusCodes which will be used in the read.
   */
  protected void prereadLatestCoverPeriodToForCaseAndListObjective(ILICaseIDAndObjectiveKey key)
    throws AppException, InformationalException {
    prereadLatestCoverPeriodToForCaseAndObjective(key);
  }

  // END, CR00296014

  // ___________________________________________________________________________
  /**
   * Pre data access for the method getDetailsForGenerateInstruments.
   * This sets the status code to unprocessed, to read all the unprocessed records
   */
  protected void presearchDetailsForGenerateInstruments(GetDetailsForGenerateInstrumentsKey getDetailsForGenerateInstrumentsKey)
    throws AppException, InformationalException {
    getDetailsForGenerateInstrumentsKey.statusCode = ILISTATUS.UNPROCESSED;
  }

  // BEGIN, CR00069071, CW
  // ___________________________________________________________________________
  /**
   * Pre data access for the method getDetailsForGenerateInstruments.
   * This sets the status code to unprocessed, to read all the unprocessed records
   */
  protected void presearchDetailsForTransferILIs(SearchDetailsForTransferILIsKey searchDetailsForTransferILIsKey)
    throws AppException, InformationalException {
    searchDetailsForTransferILIsKey.statusCode = ILISTATUS.UNPROCESSED;
  }

  // END, CR00069071

  // ___________________________________________________________________________
  /**
   * Pre data access for the method seachDeductionILIsByNominee.
   *
   */
  protected void presearchDeductionILIsByNominee(SeachDeductionILIsByNomineeKey seachDeductionILIsByNomineeKey)
    throws AppException, InformationalException {
    
    seachDeductionILIsByNomineeKey.instructLineItemCategory = ILICATEGORY.PAYMENTINSTRUCTIONFORDEDUCTION;
    seachDeductionILIsByNomineeKey.instructionLineItemType = ILITYPE.DEDUCTIONPAYMENT;
    seachDeductionILIsByNomineeKey.statusCode = ILISTATUS.UNPROCESSED;
    seachDeductionILIsByNomineeKey.creditDebitType = CREDITDEBIT.CREDIT;
  }

  // ___________________________________________________________________________
  /**
   * Pre data access for the method searchTaxILIsByNominee.
   *
   */
  protected void presearchTaxILIsByNominee(SearchTaxILIsByNomineeKey searchTaxILIsByNomineeKey)
    throws AppException, InformationalException {

    searchTaxILIsByNomineeKey.instructLineItemCategoryTax = ILICATEGORY.PAYMENTINSTRUCTIONTOTAX;
    searchTaxILIsByNomineeKey.instructLineItemCategoryReversal = ILICATEGORY.REVERSALINSTRUCTION;
    searchTaxILIsByNomineeKey.statusCode = ILISTATUS.UNPROCESSED;
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchDeductionILIsByNominee
   */
  public InstructionLineItemDtlsList seachDeductionILIsByNominee(
    SeachDeductionILIsByNomineeKey seachDeductionILIsByNomineeKey) 
    throws AppException, InformationalException {
    
    return InstructionLineItemFactory.newInstance().searchDeductionILIsByNominee(
      seachDeductionILIsByNomineeKey);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchDetailsForGenerateInstruments
   */
  public BatchProcessingIDList getDetailsForGenerateInstruments(
    GetDetailsForGenerateInstrumentsKey getDetailsForGenerateInstrumentsKey) 
    throws AppException, InformationalException {
    
    return InstructionLineItemFactory.newInstance().searchDetailsForGenerateInstruments(
      getDetailsForGenerateInstrumentsKey);
  }

  // ___________________________________________________________________________
  /**
   * Pre data access for the method prereadLatestCoverPeriodToForCaseNomineeAndObjective.
   * This sets the iliStatusCodes which will be used in the read.
   */
  protected void prereadLatestCoverPeriodToForCaseNomineeAndObjective(ILICaseIDNomineeAndObjectiveKey key)
    throws AppException, InformationalException {

    key.statusCode = ILISTATUS.CANCELLED;
    key.iliStatusCodeExpired = ILISTATUS.EXPIRED;
    key.iliStatusCodeProcessed = ILISTATUS.PROCESSED;
    key.iliStatusCodeUnprocessed = ILISTATUS.UNPROCESSED;
    key.iliStatusCodeAllocated = ILISTATUS.ALLOCATED;
    // BEGIN, CR00077815, NP
    key.iliStatusCodeTransferred = ILISTATUS.TRANSFERRED;
    // END, CR00077815
  }
  
  // BEGIN, CR00296014, KH
  // ___________________________________________________________________________
  /**
   * Pre data access for the method prereadLatestCoverPeriodToForCaseNomineeAndListObjective.
   * This sets the iliStatusCodes which will be used in the read.
   */
  protected void prereadLatestCoverPeriodToForCaseNomineeAndListObjective(ILICaseIDNomineeAndObjectiveKey key)
    throws AppException, InformationalException {
    prereadLatestCoverPeriodToForCaseNomineeAndObjective(key);
  }

  // END, CR00296014

  // BEGIN, CR00021385, SP
  // ___________________________________________________________________________
  /**
   * Pre data access for the method seachDeductionILIsByParticipant. 
   */ 
  protected void presearchDeductionILIsByParticipantRoleID(
    SearchDeductionILIsByParticipantRoleIDKey searchDeductionILIsByParticipantRoleIDKey) 
    throws AppException, InformationalException {
    
    searchDeductionILIsByParticipantRoleIDKey.instructLineItemCategory = ILICATEGORY.PAYMENTINSTRUCTIONFORDEDUCTION; 
    searchDeductionILIsByParticipantRoleIDKey.instructionLineItemType = ILITYPE.DEDUCTIONPAYMENT; 
    searchDeductionILIsByParticipantRoleIDKey.statusCode = ILISTATUS.UNPROCESSED; 
    searchDeductionILIsByParticipantRoleIDKey.creditDebitType = CREDITDEBIT.CREDIT; 
  } 
 
  // ___________________________________________________________________________
  /**
   * Pre data access for the method searchTaxILIsByParticipantRoleID. 
   */ 
  protected void presearchTaxILIsByParticipantRoleID(
    SearchTaxILIsByParticipantRoleIDKey searchTaxILIsByParticipantRoleIDKey) 
    throws AppException, InformationalException { 
 
    searchTaxILIsByParticipantRoleIDKey.instructLineItemCategoryTax = ILICATEGORY.PAYMENTINSTRUCTIONTOTAX; 
    searchTaxILIsByParticipantRoleIDKey.instructLineItemCategoryReversal = ILICATEGORY.REVERSALINSTRUCTION; 
    searchTaxILIsByParticipantRoleIDKey.statusCode = ILISTATUS.UNPROCESSED; 
  } 
 
  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchDeductionILIsByParticipantRoleID 
   */ 
  public InstructionLineItemDtlsList seachDeductionILIsByParticipantRoleID(
    SearchDeductionILIsByParticipantRoleIDKey searchDeductionILIsByParticipantRoleIDKey) 
    throws AppException, InformationalException {
    
    return InstructionLineItemFactory.newInstance().searchDeductionILIsByParticipantRoleID(
      searchDeductionILIsByParticipantRoleIDKey); 
  } 
  // END, CR00021385
}
