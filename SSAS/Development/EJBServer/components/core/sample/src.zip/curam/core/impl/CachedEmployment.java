/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2007, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import org.apache.log4j.Logger;

import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.core.struct.EmploymentDtls;
import curam.core.struct.EmploymentKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * @see curam.core.intf.CachedEmployment 
 */
public abstract class CachedEmployment extends curam.core.base.CachedEmployment {

  protected static ThreadLocal cachedEmploymentThreadLocal = new ThreadLocal();

  // ___________________________________________________________________________

  // Logger for the caching output
  // BEGIN, CR00053248, GM
  public static final String kBatchCachingCategory = Trace.kDefaultTraceCategory
    + ExtensionConst.kBatchCachingCategory;
  // END, CR00053248
  public static final Logger kBatchLauncherCacheLogger = Logger.getLogger(
    kBatchCachingCategory);

  public static final boolean logging;

  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;

  // static to indicate if online caching is enabled
  public static final boolean onlineCachingEnabled;

  // ___________________________________________________________________________
  // static to hold the logging_enabled environmental Variable
  static {

    cachingEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);

    onlineCachingEnabled = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_ONLINE_CACHING_ENABLED);

    String logging_enabled = Configuration.getProperty(
      EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED);

    if (logging_enabled == null) {
      logging_enabled = EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED_DEFAULT;
    }

    if (logging_enabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      logging = true;
    } else {
      logging = false;
    }
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public EmploymentDtls read(EmploymentKey key) throws AppException, InformationalException {
    // variable to hold transaction type
    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    EmploymentCached employmentCached = (EmploymentCached) cachedEmploymentThreadLocal.get();

    boolean reloadCache = true;

    if (employmentCached != null) {

      // If this is a batch transaction or deferred processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if (((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
        || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
        || (transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled))
            && employmentCached.employmentDtls != null
            && employmentCached.employmentDtls.employmentID == key.employmentID) {

        reloadCache = false;

        // if this is a deferred transaction, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != employmentCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    if (reloadCache) {

      // Otherwise we need to read the CaseHeader data
      employmentCached = new EmploymentCached();
      employmentCached.employmentDtls = reloadCache(key);

    }

    return employmentCached.employmentDtls;
  }

  // ___________________________________________________________________________
  /**
   * class used to cache the Employment details
   *
   */
  class EmploymentCached {

    EmploymentDtls employmentDtls = new EmploymentDtls();
    int transactionID = 0;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void clearCache() throws AppException, InformationalException {

    cachedEmploymentThreadLocal.set(null);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public EmploymentDtls reloadCache(EmploymentKey key) 
    throws AppException, InformationalException {

    // variable to hold transaction type
    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    curam.core.intf.Employment employmentObj = curam.core.fact.EmploymentFactory.newInstance();
    EmploymentDtls employmentDtls;
    EmploymentCached employmentCached = new EmploymentCached();

    // Read the case header details
    employmentDtls = employmentObj.read(key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {
      // BEGIN, HARP 71561, MR
      employmentCached.employmentDtls.assign(employmentDtls);
      // END, HARP 71561
      employmentCached.transactionID = TransactionInfo.getIdentifierForThisThread();

      // Populate the cache
      cachedEmploymentThreadLocal.set(employmentCached);
    }

    return employmentDtls;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public EmploymentDtls getCachedDtls() {

    // Create the return object
    EmploymentDtls employmentDtls = new EmploymentDtls();

    // Read the cached details
    EmploymentCached employmentCached = new EmploymentCached();

    employmentCached = (EmploymentCached) cachedEmploymentThreadLocal.get();

    if (employmentCached.employmentDtls == null) {

      employmentCached.employmentDtls = new EmploymentDtls();
    }

    return employmentDtls.assign(employmentCached.employmentDtls);
  }
}
