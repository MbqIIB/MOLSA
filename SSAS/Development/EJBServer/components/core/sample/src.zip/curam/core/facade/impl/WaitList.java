/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import com.google.inject.Inject;

import curam.codetable.impl.WAITLISTREMOVALREASONEntry;
import curam.core.facade.struct.DeferWaitListReviewDetails;
import curam.core.facade.struct.RemoveWaitListDetails;
import curam.core.facade.struct.ViewWaitlistEntryDetails;
import curam.core.struct.WaitListEntryKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.waitlist.impl.WaitListEntry;
import curam.waitlist.impl.WaitListEntryDAO;


/**
 * Contains the implementations for the server calls from the wait list review
 * task action pages.
 */
public abstract class WaitList extends curam.core.facade.base.WaitList {

  /**
   * Reference to Wait List Entry DAO.
   */
  @Inject
  protected WaitListEntryDAO waitListEntryDAO;

  /**
   * Do guice injections referred in the methods below.
   */
  public WaitList() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Defers wait list entry review to a future date.
   *
   * @param deferWaitListReviewDetails
   * Contains the new review date and the new expiry date that need
   * to be set.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void deferWaitListEntryReview(
    DeferWaitListReviewDetails deferWaitListReviewDetails)
    throws AppException, InformationalException {
    WaitListEntry waitListEntry = waitListEntryDAO.get(
      deferWaitListReviewDetails.key.waitListEntryID);

    waitListEntry.setReviewDate(deferWaitListReviewDetails.reviewDate);
    waitListEntry.setExpiryDate(deferWaitListReviewDetails.expiryDate);
    waitListEntry.setTransactionUser(TransactionInfo.getProgramUser());

    waitListEntry.deferReview(waitListEntry.getVersionNo());

  }

  /**
   * Marks the given wait list entry as allocated.
   *
   * @param waitListEntryKey
   * Key to identify the wait list entry.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void markAsAllocated(WaitListEntryKey waitListEntryKey)
    throws AppException, InformationalException {
    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);

    waitListEntry.setTransactionUser(TransactionInfo.getProgramUser());
    waitListEntry.allocate(waitListEntry.getVersionNo());

  }

  /**
   * Removes the wait list entry.
   *
   * @param removeWaitListDetails
   * Contains the details of wait list entry to be removed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void removeWaitListEntry(RemoveWaitListDetails removeWaitListDetails)
    throws AppException, InformationalException {

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      removeWaitListDetails.key.waitListEntryID);

    waitListEntry.setRemovalReason(
      WAITLISTREMOVALREASONEntry.get(removeWaitListDetails.removalReason));
    waitListEntry.setTransactionUser(TransactionInfo.getProgramUser());
    waitListEntry.cancel(waitListEntry.getVersionNo());
  }

  /**
   * Defers the wait list entry.
   *
   * @param waitListEntryKey
   * Key to identify the wait list entry.
   *
   * @return DeferWaitListReviewDetails Contains the review date and the
   * expiry date.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public DeferWaitListReviewDetails viewWaitListEntryToDeferReview(
    WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {
    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);

    DeferWaitListReviewDetails deferWaitListReviewDetails = new DeferWaitListReviewDetails();

    deferWaitListReviewDetails.reviewDate = waitListEntry.getDeferredReviewDate();
    deferWaitListReviewDetails.expiryDate = waitListEntry.getDeferredExpiryDate();
    deferWaitListReviewDetails.key.waitListEntryID = waitListEntry.getID();

    return deferWaitListReviewDetails;
  }

  // BEGIN, CR00369606, PS
  /**
   * Views the wait list entry.
   *
   * @param waitListEntryKey
   * Key to identify the wait list entry.
   *
   * @return The details of the wait list entry to be viewed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ViewWaitlistEntryDetails viewWaitListEntryDetails(
    WaitListEntryKey waitListEntryKey) throws AppException,
      InformationalException {

    WaitListEntry waitListEntry = waitListEntryDAO.get(
      waitListEntryKey.waitListEntryID);

    ViewWaitlistEntryDetails viewWaitlistEntryDetails = new ViewWaitlistEntryDetails();

    viewWaitlistEntryDetails.expiryDate = waitListEntry.getExpiryDate();
    viewWaitlistEntryDetails.reviewDate = waitListEntry.getReviewDate();
    viewWaitlistEntryDetails.position = waitListEntry.getPosition();
    viewWaitlistEntryDetails.priority = waitListEntry.getPriority().toString();

    return viewWaitlistEntryDetails;
  }
  // END, CR00369606

}
