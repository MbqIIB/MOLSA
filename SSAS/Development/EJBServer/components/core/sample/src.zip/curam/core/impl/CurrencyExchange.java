/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.CurrencyExchangeDatesTypeStructRef;
import curam.core.struct.CurrencyExchangeDtls;
import curam.core.struct.CurrencyExchangeSearchDatesStruct;
import curam.core.struct.CurrencyExchangeSummaryStructRefList;
import curam.core.struct.OrganisationKey;
import curam.core.struct.OrganisationKeyStructRef;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Implementation of functions to be executed before insert, modify, etc.
 *
 */
public abstract class CurrencyExchange extends curam.core.base.CurrencyExchange {

  // __________________________________________________________________________
  /**
   * Checks if the input branch sort code has not been input already.
   *
   * @param key Contains organization ID
   */
  protected void presearchByOrganisation(OrganisationKeyStructRef key)
    throws AppException, InformationalException {

    // variables, used to read organization record
    curam.core.intf.Organisation organisationObj = curam.core.fact.OrganisationFactory.newInstance();
    OrganisationKey organisationKey = new OrganisationKey();

    // Check that the input Organization is valid.
    organisationKey.organisationID = key.organisationID;

    // read organization record
    organisationObj.read(organisationKey);

  }

  // __________________________________________________________________________
  /**
   * Checks if input currency exchange will clash before insert and modify
   *
   * @param details Contains details of organization and currency to check on
   */
  protected void autovalidate(CurrencyExchangeDtls details)
    throws AppException, InformationalException {

    // variables, used to read organization record
    curam.core.intf.Organisation organisationObj = curam.core.fact.OrganisationFactory.newInstance();
    OrganisationKey organisationKey = new OrganisationKey();

    // variables to check for duplicate record
    curam.core.intf.CurrencyExchange currencyExchangeObj = curam.core.fact.CurrencyExchangeFactory.newInstance();
    CurrencyExchangeDatesTypeStructRef currencyExchangeDatesTypeStructRef = new CurrencyExchangeDatesTypeStructRef();

    CurrencyExchangeSummaryStructRefList currencyExchangeSummaryStructRefList;

    if (details.statusCode.equals(curam.codetable.RECORDSTATUS.NORMAL)) {

      currencyExchangeDatesTypeStructRef.assign(details);

      currencyExchangeDatesTypeStructRef.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

      // check if the value is already set for that currency exchange type
      // and dates interval
      currencyExchangeSummaryStructRefList = currencyExchangeObj.searchCurrencyExchangesInDateRange(
        currencyExchangeDatesTypeStructRef);

      // if there is more than one matching currency exchange for the period
      if (currencyExchangeSummaryStructRefList.dtls.size() > 1) {

        AppException e = new AppException(
          curam.message.BPOCURRENCYEXCHANGE.ERR_CURRENCYEXCHANGE_MRE_PERIOD_TYPE);

        e.arg(details.currencyTypeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

      }

      // if the only record for the specified currency exchange type and
      // period exists, and it is not the record currently to be updated
      // - select just type of exception
      if ((currencyExchangeSummaryStructRefList.dtls.size() == 1)
        && (details.currencyExchangeID
          != currencyExchangeSummaryStructRefList.dtls.item(0).currencyExchangeID)) {

        // probably user must set end date to previously inserted rate
        // - not obvious overlapping
        boolean currentToDateIsEmpty = (details.rateToDate.isZero());

        boolean prevToDateIsEmpty = (currencyExchangeSummaryStructRefList.dtls.item(0).rateToDate.isZero());

        boolean prevFromDateMoreCurrent = (currencyExchangeSummaryStructRefList.dtls.item(0).rateFromDate.after(
          details.rateFromDate));

        boolean prevFromDateLessCurrent = (currencyExchangeSummaryStructRefList.dtls.item(0).rateFromDate.before(
          details.rateFromDate));

        if (currentToDateIsEmpty && prevFromDateMoreCurrent) {

          AppException e = new AppException(
            curam.message.BPOCURRENCYEXCHANGE.ERR_CURRENCYEXCHANGE_DRE_CURRENT_TO_DATE);

          e.arg(details.currencyTypeCode);

          e.arg(currencyExchangeSummaryStructRefList.dtls.item(0).rateFromDate);
          e.arg(currencyExchangeSummaryStructRefList.dtls.item(0).rateFromDate);
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);

        }

        if (prevToDateIsEmpty && prevFromDateLessCurrent) {

          AppException e = new AppException(
            curam.message.BPOCURRENCYEXCHANGE.ERR_CURRENCYEXCHANGE_DRE_PREVIOUS_TO_DATE);

          e.arg(details.currencyTypeCode);
          e.arg(details.currencyTypeCode);
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);

        }

        // in all other cases it is obvious overlapping
        AppException e = new AppException(
          curam.message.BPOCURRENCYEXCHANGE.ERR_CURRENCYEXCHANGE_DRE_DATES);

        e.arg(details.currencyTypeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

      }

      // Check that the input Organization is valid
      organisationKey.organisationID = details.organisationID;

      organisationObj.read(organisationKey);

    }

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readRateByDateType
   */
  public curam.core.struct.CurrencyExchangeSummaryStructRef getRateByDateType(curam.core.struct.CurrencyExchangeDateTypeStructRef dateTypeCriteria) throws curam.util.exception.AppException, curam.util.exception.InformationalException {
    return readRateByDateType(dateTypeCriteria);
  }

  // BEGIN,CR00050804, NRV
  // BEGIN, HARP 65895, SP
  // ___________________________________________________________________________
  /**
   * Determines whether the input ID fields will be converted to a NULL value
   * for use in SQL and sets the indicator fields accordingly.
   * This avoids the need for database-specific CAST statements in the
   * generated SQL.
   *
   * @param dateCriteria the key struct used for the read
   */
  protected void presearchCurrExchangeRatesByDates(CurrencyExchangeSearchDatesStruct dateCriteria) throws AppException, InformationalException {
    dateCriteria.rateFromDateIsNull = dateCriteria.rateFromDate.isZero();
    dateCriteria.rateToDateIsNull = dateCriteria.rateToDate.isZero();
  }
  // END, HARP 65895
  // END, CR00050804

}
