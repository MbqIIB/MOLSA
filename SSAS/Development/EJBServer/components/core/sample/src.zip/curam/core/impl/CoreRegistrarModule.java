/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;

import java.lang.reflect.Method;

import com.google.inject.AbstractModule;
import com.google.inject.multibindings.MapBinder;

import curam.codetable.CASEEVIDENCE;
import curam.core.fact.AlternateNameFactory;
import curam.core.fact.CitizenshipFactory;
import curam.core.fact.ConcernRoleAddressFactory;
import curam.core.fact.ConcernRoleAlternateIDFactory;
import curam.core.fact.ConcernRoleBankAccountFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ConcernRoleRelationshipFactory;
import curam.core.fact.EducationFactory;
import curam.core.fact.EmployerFactory;
import curam.core.fact.EmploymentFactory;
import curam.core.fact.ForeignResidencyFactory;
import curam.core.fact.PersonFactory;
import curam.core.fact.ProspectPersonFactory;
import curam.core.impl.Registrar.RegistrarType;
import curam.core.sl.entity.fact.EmploymentWorkingHourFactory;
import curam.core.sl.entity.fact.ProspectEmployerFactory;

/**
 * A module class which provides registry for all the evidence hook
 * implementations.
 */
public class CoreRegistrarModule extends AbstractModule {

  /**
   * Registers the hook implementations to a corresponding evidence type.
   */
  @Override
  public void configure() {
    // Register all evidence hook implementations which implement the interface
    // EvidenceInterface.
    registerEvidenceHookImplementations();
  }

  /**
   * Registers all evidence hook implementations which implement the interface
   * EvidenceInterface.
   */
  protected void registerEvidenceHookImplementations() {
    MapBinder<String, Method> evidenceInterfaceMapBinder = MapBinder
        .newMapBinder(binder(), String.class, Method.class, new RegistrarImpl(
            RegistrarType.EVIDENCE));

    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.EMPLOYER).toInstance(
        FactoryMethodHelper.getNewInstanceMethod(EmployerFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.PERSON).toInstance(
        FactoryMethodHelper.getNewInstanceMethod(PersonFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.CONCERNROLE).toInstance(
        FactoryMethodHelper.getNewInstanceMethod(ConcernRoleFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.CITIZENSHIP).toInstance(
        FactoryMethodHelper.getNewInstanceMethod(CitizenshipFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.CONCERNROLEADDRESS)
        .toInstance(FactoryMethodHelper.getNewInstanceMethod(
            ConcernRoleAddressFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.ALTERNATENAME)
        .toInstance(FactoryMethodHelper.getNewInstanceMethod(
            AlternateNameFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.EMPLOYMENT).toInstance(
        FactoryMethodHelper.getNewInstanceMethod(EmploymentFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.EMPLOYMENTWORKINGHR)
        .toInstance(FactoryMethodHelper.getNewInstanceMethod(
            EmploymentWorkingHourFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.EDUCATION).toInstance(
        FactoryMethodHelper.getNewInstanceMethod(EducationFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.CONCERNROLEBANKACC)
        .toInstance(FactoryMethodHelper.getNewInstanceMethod(
            ConcernRoleBankAccountFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.CONCERNROLERELATIONSHIP)
        .toInstance(FactoryMethodHelper.getNewInstanceMethod(
            ConcernRoleRelationshipFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.FOREIGNRESIDENCY)
        .toInstance(FactoryMethodHelper.getNewInstanceMethod(
            ForeignResidencyFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.PROSPECTPERSON)
        .toInstance(FactoryMethodHelper.getNewInstanceMethod(
            ProspectPersonFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.PROSPECTEMPLOYER)
        .toInstance(FactoryMethodHelper.getNewInstanceMethod(
            ProspectEmployerFactory.class));
    evidenceInterfaceMapBinder.addBinding(CASEEVIDENCE.CONCERNROLEALTERNATEID)
        .toInstance(FactoryMethodHelper.getNewInstanceMethod(
            ConcernRoleAlternateIDFactory.class));
  }
}