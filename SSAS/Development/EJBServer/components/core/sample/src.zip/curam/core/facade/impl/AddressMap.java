/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.cefwidgets.docbuilder.impl.XMLBuilder;
import curam.core.facade.struct.GoogleMapXML;
import curam.core.fact.AddressFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.Address;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.AddressKeyStruct;
import curam.core.struct.OtherAddressData;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;


/**
 * This process class provides the functionality for the Participant tab details.
 */
public abstract class AddressMap extends curam.core.facade.base.AddressMap {

  // __________________________________________________________________________
  /**
   * Return a string representation of a document describing an address
   * that can be displayed on a google map.
   *
   * @return GoogleMapXML A string representation of the google map xml
   * document.
   */
  public GoogleMapXML readMap(AddressKeyStruct key)
    throws AppException, InformationalException {

    GoogleMapXML googleMapXML = new GoogleMapXML();

    // Instance of helper class to build the XML
    XMLBuilder xmlBuilder = new XMLBuilder(CuramConst.gkMap);

    xmlBuilder.addAttribute(CuramConst.gkDomain, CuramConst.gkGoogleMapXML);

    // BEGIN, CR00256192, BD
    xmlBuilder.createTag(CuramConst.gkGoogleMapLicense);
    xmlBuilder.addAttribute(CuramConst.gkGoogleMapAPIKey,
      Configuration.getProperty(EnvVars.ENV_GOOGLE_MAPS_API_KEY));
    
    xmlBuilder.addAttribute(CuramConst.gkGoogleMapAPIUrl,
      Configuration.getProperty(EnvVars.ENV_GOOGLE_MAPS_API_URL));
    
    xmlBuilder.closeTag();    
    // END, CR00256192
    
    xmlBuilder.createTag(CuramConst.gkData);
    xmlBuilder.createTag(CuramConst.gkMapAddress);

    Address addressObj = AddressFactory.newInstance();
    AddressKey addressKey = new AddressKey();

    addressKey.addressID = key.addressID;

    AddressDtls addressDtls = addressObj.read(addressKey);

    xmlBuilder.addAttribute(CuramConst.gkLatitude,
      String.valueOf(addressDtls.latitude));
    xmlBuilder.addAttribute(CuramConst.gkLongitude,
      String.valueOf(addressDtls.longitude));

    // BEGIN, CR00256192, BD
    // Format the address into a single line for hover on the map pin.
    Address address = AddressFactory.newInstance();
    OtherAddressData otherAddressData = new OtherAddressData();

    otherAddressData.addressData = addressDtls.addressData;
    
    address.getOneLineAddressString(otherAddressData);
    xmlBuilder.addTagData(otherAddressData.addressData);
    // END, CR00256192

    xmlBuilder.closeTag(); // </address>
    xmlBuilder.closeTag(); // </data>

    googleMapXML.googleMapXML = xmlBuilder.getXmlString();

    return googleMapXML;
  }

}
