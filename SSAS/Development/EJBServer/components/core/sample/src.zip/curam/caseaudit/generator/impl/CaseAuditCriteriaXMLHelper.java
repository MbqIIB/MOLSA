/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.generator.impl;

import org.jdom.Document;

import curam.core.facade.struct.CaseSampleKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

public interface CaseAuditCriteriaXMLHelper {

  // ___________________________________________________________________________
  /**
   * Builds the XML <code>String</code> representation of the data to be
   * to be used in the creation of the case audit sample. 
   *  
   * @param key
   *          The search criteria to be used in the generation of the case
   *          audit sample.
   *           
   * @return An XML <code>String</code> representation of the data to be used 
   *         in the creation of the case audit sample.
   */
  public String buildCriteria(CaseSampleKey key) 
    throws AppException, InformationalException;

  
  // ___________________________________________________________________________
  /**
   * Parses an XML document that represents the data to be used in the 
   * creation of the case audit sample.
   *  
   * @param document
   *         The XML <code>String</code> representation of the data to be used 
   *         in the creation of the case audit sample.
   *           
   * @return The key containing the search criteria.
   */
  public CaseSampleKey parseCriteria(Document document) 
    throws AppException, InformationalException;

}
