/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.codetable.DUPLICATESTATUS;
import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.intf.ParticipantContext;
import curam.core.facade.struct.CancelPeriodKey;
import curam.core.facade.struct.ClientPageLink;
import curam.core.facade.struct.ContributionCancelLineItemKey;
import curam.core.facade.struct.ContributionModifyLineItemDetails;
import curam.core.facade.struct.CreateEmployeeLineItemDetails;
import curam.core.facade.struct.CreateInsuranceReturnHeaderDetails;
import curam.core.facade.struct.CreatePeriodDetails;
import curam.core.facade.struct.InsuranceReturnPeriodControlKey;
import curam.core.facade.struct.ListConsolidationForConcernRoleIDDetails;
import curam.core.facade.struct.ListConsolidationForConcernRoleIDKey;
import curam.core.facade.struct.ListConsolidationForDuplicateConcernRoleDetails;
import curam.core.facade.struct.ListContributionProductDetails;
import curam.core.facade.struct.ModifyInsuranceReturnHeaderDetails;
import curam.core.facade.struct.ModifyPeriodDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ReadAllPeriodsDetails;
import curam.core.facade.struct.ReadByConsolidationIDDetails;
import curam.core.facade.struct.ReadConsolidationDetailsDetails;
import curam.core.facade.struct.ReadConsolidationDetailsKey;
import curam.core.facade.struct.ReadInsuranceHeaderHistoryDetailDetails;
import curam.core.facade.struct.ReadInsuranceHeaderHistoryDetailKey;
import curam.core.facade.struct.ReadInsuranceReturnHomePageDetails;
import curam.core.facade.struct.ReadInsuranceReturnHomePageKey;
import curam.core.facade.struct.ReadLineItemDetailsDetails;
import curam.core.facade.struct.ReadLineItemDetailsKey;
import curam.core.facade.struct.ReadLineItemHistoryDetails;
import curam.core.facade.struct.ReadLineItemHistoryDetailsDetails;
import curam.core.facade.struct.ReadLineItemHistoryDetailsKey;
import curam.core.facade.struct.ReadLineItemHistoryKey;
import curam.core.facade.struct.ReadListOfPeriodsDetails;
import curam.core.facade.struct.ReadPeriodDetails;
import curam.core.facade.struct.ReadPeriodKey;
import curam.core.facade.struct.ReadReturnHeaderDetailsDetails;
import curam.core.facade.struct.ReadReturnHeaderDetailsKey;
import curam.core.facade.struct.ReadReturnHeaderHistoryDetails;
import curam.core.facade.struct.ReadReturnHeaderHistoryKey;
import curam.core.facade.struct.ReadmultiByEmploymentIDDetails;
import curam.core.facade.struct.ReadmultiByEmploymentIDKey;
import curam.core.facade.struct.ReadmultiByHeaderIDDetails;
import curam.core.facade.struct.ReadmultiByHeaderIDKey;
import curam.core.facade.struct.SearchLineItemByConcernRoleIDDetails;
import curam.core.facade.struct.SearchLineItemByConcernRoleIDKey;
import curam.core.facade.struct.SearchLineItemByDuplicateConcernRoleIDDetails;
import curam.core.facade.struct.SearchReturnHeaderByConcernRoleIDDetails;
import curam.core.facade.struct.SearchReturnHeaderByConcernRoleIDKey;
import curam.core.facade.struct.ValidateInsuranceReturnDetails;
import curam.core.facade.struct.ValidateInsuranceReturnKey;
import curam.core.fact.MaintainConsolidationDetailsFactory;
import curam.core.fact.MaintainInsuranceLineItemFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.MaintainConsolidationDetails;
import curam.core.intf.MaintainInsuranceLineItem;
import curam.core.sl.entity.fact.ConcernRoleDuplicateFactory;
import curam.core.sl.entity.intf.ConcernRoleDuplicate;
import curam.core.sl.entity.struct.ConcernRoleDuplicateDtlsList;
import curam.core.sl.entity.struct.SearchByDuplicateConcernRoleIDKey;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ReadContributionProductsKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;


/**
 * This process class provides the functionality for the Contribution
 * presentation layer.
 *
 */
public abstract class Contribution extends curam.core.facade.base.Contribution {

  // BEGIN, CR00100651, CSH
  protected static final String kItem = XmlMetaDataConst.kItem;
  protected static final String kDesc = XmlMetaDataConst.kDesc;
  protected static final String kType = XmlMetaDataConst.kType;
  protected static final String kPageID = XmlMetaDataConst.kPageID;
  protected static final String kName = XmlMetaDataConst.kName;
  protected static final String kValue = XmlMetaDataConst.kValue;
  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;
  protected static final String kParam = XmlMetaDataConst.kParam;
  protected static final String kParamConcernRoleID =
    XmlMetaDataConst.kParamConcernRoleID;
  protected static final String kNavigationMenu =
    XmlMetaDataConst.kNavigationMenu;
  // END, CR00100651

  // ___________________________________________________________________________
  /**
   * Cancels an insurance line item.
   *
   * @param key Key to cancel the insurance line item.
   *
   */
  public void cancelLineItem(ContributionCancelLineItemKey key)
    throws AppException, InformationalException {

    // MaintainInsuranceLineItem manipulation variable
    curam.core.intf.MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      curam.core.fact.MaintainInsuranceLineItemFactory.newInstance();

    // Call MaintainInsuranceLineItem BPO to cancel the line item
    maintainInsuranceLineItemObj.cancelLineItem(key.insReturnLineItemKey);
  }

  // ___________________________________________________________________________
  /**
   * Cancels an insurance period control.
   *
   * @param key Key to cancel an insurance period control.
   *
   */
  public void cancelPeriod(CancelPeriodKey key) throws AppException, InformationalException {

    // MaintainInsurancePeriodControl manipulation variable
    curam.core.intf.MaintainInsurancePeriodControl maintainInsurancePeriodControlObj =
      curam.core.fact.MaintainInsurancePeriodControlFactory.newInstance();

    // Call MaintainInsurancePeriodControl BPO to cancel the period control
    maintainInsurancePeriodControlObj.cancelPeriod(
      key.insReturnPeriodControlCancelKey);
  }

  // ___________________________________________________________________________
  /**
   * Creates an employee insurance line item.
   *
   * @param details Details to create an employee insurance line item.
   *
   * @return Identifier of the created employee line item.
   *
   */
  public curam.core.facade.struct.CreateEmployeeLineItemResult createEmployeeLineItem(CreateEmployeeLineItemDetails details)
    throws AppException, InformationalException {

    // Create return object
    curam.core.facade.struct.CreateEmployeeLineItemResult createEmployeeLineItemResult =
      new curam.core.facade.struct.CreateEmployeeLineItemResult();

    // MaintainInsuranceLineItem manipulation variable
    curam.core.intf.MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      curam.core.fact.MaintainInsuranceLineItemFactory.newInstance();

    // assign person ID entered to concern role ID
    details.createLineItemKey.concernRoleID =
      details.insRetLineItemDtls.personID;

    details.insRetLineItemDtls.concernRoleID =
      details.insRetLineItemDtls.personID;

    // Call MaintainInsuranceLineItem BPO to create the employee line item
    // and assign result to return object
    createEmployeeLineItemResult.result.assign(
      maintainInsuranceLineItemObj.createEmployeeLineItem(
        details.createLineItemKey, details.insRetLineItemDtls));

    return createEmployeeLineItemResult;
  }

  // ___________________________________________________________________________
  /**
   * Creates an insurance return header.
   *
   * @param details Details to create an insurance return header.
   *
   * @return Identifier of the created insurance return header.
   *
   */
  public curam.core.facade.struct.InsuranceReturnHeaderKey createInsuranceReturnHeader(CreateInsuranceReturnHeaderDetails details)
    throws AppException, InformationalException {

    // Create return object
    curam.core.facade.struct.InsuranceReturnHeaderKey insuranceReturnHeaderKey =
      new curam.core.facade.struct.InsuranceReturnHeaderKey();

    // EmployerInsuranceRetHeader manipulation variable
    curam.core.intf.EmployerInsuranceRetHeader employerInsuranceRetHeaderObj =
      curam.core.fact.EmployerInsuranceRetHeaderFactory.newInstance();

    // Call EmployerInsuranceRetHeader to create the employer insurance return
    // header and assign result to return object
    insuranceReturnHeaderKey.key.assign(
      employerInsuranceRetHeaderObj.createInsuranceReturnHdr(
        details.createHeaderKey, details.insuranceReturnHdrDetails));

    return insuranceReturnHeaderKey;
  }

  // ___________________________________________________________________________
  /**
   * Creates an insurance period control.
   *
   * @param details Details to create an insurance period control.
   *
   * @return Identifier of the return period control created.
   *
   */
  public InsuranceReturnPeriodControlKey createPeriod(CreatePeriodDetails
    details) throws AppException, InformationalException {

    // Create return object
    InsuranceReturnPeriodControlKey insuranceReturnPeriodControlKey =
      new InsuranceReturnPeriodControlKey();

    // MaintainInsurancePeriodControl manipulation variable
    curam.core.intf.MaintainInsurancePeriodControl maintainInsurancePeriodControlObj =
      curam.core.fact.MaintainInsurancePeriodControlFactory.newInstance();

    // Call MaintainInsurancePeriodControl to create the insurance period
    // control and assign result to return struct
    insuranceReturnPeriodControlKey.key.assign(
      maintainInsurancePeriodControlObj.createPeriod(
        details.insPeriodControlDtls));

    return insuranceReturnPeriodControlKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the details of an insurance return header.
   *
   * @param details Details to modify the insurance return header.
   *
   */
  public void modifyInsuranceReturnHeader(ModifyInsuranceReturnHeaderDetails
    details) throws AppException, InformationalException {

    // EmployerInsuranceRetHeader manipulation variable
    curam.core.intf.EmployerInsuranceRetHeader employerInsuranceRetHeaderObj =
      curam.core.fact.EmployerInsuranceRetHeaderFactory.newInstance();

    // Call EmployerInsuranceRetHeader BPO to modify the insurance return
    // header details
    employerInsuranceRetHeaderObj.modifyInsuranceRetHeader(
      details.insuranceRetHdrKey, details.insuranceReturnHdrModifyDtls);
  }

  // ___________________________________________________________________________
  /**
   * Modifies an insurance line item.
   *
   * @param details Details to modify an insurance line item.
   *
   */
  public void modifyLineItem(ContributionModifyLineItemDetails details)
    throws AppException, InformationalException {

    // MaintainInsuranceLineItem manipulation variable
    curam.core.intf.MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      curam.core.fact.MaintainInsuranceLineItemFactory.newInstance();

    // Call MaintainInsuranceLineItem BPO to modify the details of the
    // insurance line item
    maintainInsuranceLineItemObj.modifyLineItem(details.insReturnLineItemKey,
      details.insRetLineItemDtls);
  }

  // ___________________________________________________________________________
  /**
   * Modifies an insurance period control.
   *
   * @param details Details to modify the insurance period control.
   *
   */
  public void modifyPeriod(ModifyPeriodDetails details)
    throws AppException, InformationalException {

    // MaintainInsurancePeriodControl manipulation variable
    curam.core.intf.MaintainInsurancePeriodControl maintainInsurancePeriodControlObj =
      curam.core.fact.MaintainInsurancePeriodControlFactory.newInstance();

    // Call MaintainInsurancePeriodControl to modify the insurance period
    // control
    maintainInsurancePeriodControlObj.modifyPeriod(
      details.insReturnPeriodControlKey, details.insPeriodControlDtls);
  }

  // ___________________________________________________________________________
  /**
   * Returns all insurance period controls.
   *
   * @return List of insurance period control records.
   *
   */
  public ReadAllPeriodsDetails listAllPeriod() throws AppException, InformationalException {

    // Create return object
    ReadAllPeriodsDetails readAllPeriodsDetails = new ReadAllPeriodsDetails();

    // MaintainInsurancePeriodControl manipulation variable
    curam.core.intf.MaintainInsurancePeriodControl maintainInsurancePeriodControlObj =
      curam.core.fact.MaintainInsurancePeriodControlFactory.newInstance();

    // Call MaintainInsurancePeriodControl BPO to read all insurance period
    // control records and assign to return object
    readAllPeriodsDetails.insPeriodControlRMDtlsList.assign(
      maintainInsurancePeriodControlObj.readAllPeriods());

    return readAllPeriodsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns an insurance line item by consolidation identifier.
   *
   * @param key Contains the consolidation identifier.
   *
   * @return List of insurance line items.
   *
   */
  public ReadByConsolidationIDDetails listLineItemByConsolidationID(
    curam.core.facade.struct.ReadByConsolidationIDKey key)
    throws AppException, InformationalException {

    // Create return object
    ReadByConsolidationIDDetails readByConsolidationIDDetails =
      new ReadByConsolidationIDDetails();

    // MaintainInsuranceLineItem manipulation variable
    curam.core.intf.MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      curam.core.fact.MaintainInsuranceLineItemFactory.newInstance();

    // Call MaintainInsuranceLineItem BPO to read consolidation details and
    // assign to return object
    readByConsolidationIDDetails.insReturnLineItemRMDtlsList.assign(
      maintainInsuranceLineItemObj.readByConsolidationID(
        key.readLineItemsByConsolKey));

    return readByConsolidationIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads details to populate the insurance return home page.
   *
   * @param key Key to read the insurance return home page details.
   *
   * @return Insurance Return Home Page details.
   *
   */
  public ReadInsuranceReturnHomePageDetails readInsuranceReturnHomePage(
    ReadInsuranceReturnHomePageKey key) throws AppException, InformationalException {

    // Create return object
    ReadInsuranceReturnHomePageDetails readInsuranceReturnHomePageDetails =
      new ReadInsuranceReturnHomePageDetails();

    // MaintainInsuranceLineItem manipulation variable
    curam.core.intf.MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      curam.core.fact.MaintainInsuranceLineItemFactory.newInstance();

    // Call MaintainInsuranceLineItem BPO to read the home page details and
    // assign to return object
    readInsuranceReturnHomePageDetails.readInsurReturnHomePageResult.assign(
      maintainInsuranceLineItemObj.readInsurReturnHomePage(
        key.insRetLineHdrRmKey));

    return readInsuranceReturnHomePageDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads insurance line item details.
   *
   * @param key Key to read the insurance line item details.
   *
   * @return Insurance Line Item details.
   *
   */
  public ReadLineItemDetailsDetails readLineItemDetails(
    ReadLineItemDetailsKey key) throws AppException, InformationalException {

    // Create return object
    ReadLineItemDetailsDetails readLineItemDetailsDetails =
      new ReadLineItemDetailsDetails();

    // MaintainInsuranceLineItem manipulation variable
    curam.core.intf.MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      curam.core.fact.MaintainInsuranceLineItemFactory.newInstance();

    // Call MaintainInsuranceLineItem BPO to read insurance line item details
    // and assign to return object
    readLineItemDetailsDetails.insRetLineItemDtls.assign(
      maintainInsuranceLineItemObj.readLineItemDetails(key.insReturnLineItemKey));

    return readLineItemDetailsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads insurance line item history details.
   *
   * @param key Key to read the line item history details
   *
   * @return List of insurance line item history records.
   *
   */
  public ReadLineItemHistoryDetails listLineItemHistory(
    ReadLineItemHistoryKey key) throws AppException, InformationalException {

    // Create return object
    ReadLineItemHistoryDetails readLineItemHistoryDetails =
      new ReadLineItemHistoryDetails();

    // MaintainInsuranceLineItem manipulation variable
    curam.core.intf.MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      curam.core.fact.MaintainInsuranceLineItemFactory.newInstance();

    // Call MaintainInsuranceLineItem BPO to read the line item history details
    // and assign to return object
    readLineItemHistoryDetails.insReturnLineItemRMDtlsList.assign(
      maintainInsuranceLineItemObj.readLineItemHistory(key.insRetLineItemKey));

    return readLineItemHistoryDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of active period controls.
   *
   * @return List of active period controls.
   *
   */
  public ReadListOfPeriodsDetails listActivePeriod()
    throws AppException, InformationalException {

    // Create return object
    ReadListOfPeriodsDetails readListOfPeriodsDetails =
      new ReadListOfPeriodsDetails();

    // MaintainInsurancePeriodControl manipulation variable
    curam.core.intf.MaintainInsurancePeriodControl maintainInsurancePeriodControlObj =
      curam.core.fact.MaintainInsurancePeriodControlFactory.newInstance();

    // Call MaintainInsurancePeriodControl BPO to read the list of insurance
    // period controls and assign to return object
    readListOfPeriodsDetails.readListOfPeriodsResult.assign(
      maintainInsurancePeriodControlObj.readListOfPeriods());

    return readListOfPeriodsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of insurance line items for a particular employment.
   *
   * @param key Contains the employment identifier.
   *
   * @return List of insurance line items for specified employment.
   *
   */
  public ReadmultiByEmploymentIDDetails listLineItemEmploymentID(
    ReadmultiByEmploymentIDKey key) throws AppException, InformationalException {

    ReadmultiByEmploymentIDDetails readmultiByEmploymentIDDetails =
      new ReadmultiByEmploymentIDDetails();

    // MaintainInsuranceLineItem manipulation variable
    curam.core.intf.MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      curam.core.fact.MaintainInsuranceLineItemFactory.newInstance();

    // Call MaintainInsuranceLineItem BPO to search the insurance line items
    // by employment identifier and assign details to return object
    readmultiByEmploymentIDDetails.insReturnLineItemRMDtlsList.assign(
      maintainInsuranceLineItemObj.readmultiByEmploymentID(
        key.readByEmploymentKey));

    return readmultiByEmploymentIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of insurance line items for a particular header.
   *
   * @param key Contains the header identifier.
   *
   * @return List of insurance line items.
   *
   */
  public ReadmultiByHeaderIDDetails listLineItemForHeaderID(
    ReadmultiByHeaderIDKey key) throws AppException, InformationalException {

    // Create return object
    ReadmultiByHeaderIDDetails readmultiByHeaderIDDetails =
      new ReadmultiByHeaderIDDetails();

    // MaintainInsuranceLineItem manipulation variable
    curam.core.intf.MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      curam.core.fact.MaintainInsuranceLineItemFactory.newInstance();

    // Call MaintainInsuranceLineItem BPO to search for insurance line items
    // by the insurance header identifier and assign details to return object
    readmultiByHeaderIDDetails.readByHeaderIDRMDtlsList.assign(
      maintainInsuranceLineItemObj.readmultiByHeaderID(key.insRetLineHdrRmKey));

    return readmultiByHeaderIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads insurance period details.
   *
   * @param key Key to read the insurance period details.
   *
   * @return Insurance period details.
   *
   */
  public ReadPeriodDetails readPeriod(ReadPeriodKey key)
    throws AppException, InformationalException {

    // Create return object
    ReadPeriodDetails readPeriodDetails = new ReadPeriodDetails();

    // MaintainInsurancePeriodControl manipulation variable
    curam.core.intf.MaintainInsurancePeriodControl maintainInsurancePeriodControlObj =
      curam.core.fact.MaintainInsurancePeriodControlFactory.newInstance();

    // Call MaintainInsurancePeriodControl BPO to read the insurance period
    // details and assign to return object
    readPeriodDetails.insPeriodControlDtls.assign(
      maintainInsurancePeriodControlObj.readPeriod(
        key.insReturnPeriodControlKey));

    return readPeriodDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads insurance return header details.
   *
   * @param key Key to read the insurance return header details.
   *
   * @return Insurance Return Header details.
   *
   */
  public ReadReturnHeaderDetailsDetails listReturnHeaderDetails(
    ReadReturnHeaderDetailsKey key) throws AppException, InformationalException {

    // Create return object
    ReadReturnHeaderDetailsDetails readReturnHeaderDetailsDetails =
      new ReadReturnHeaderDetailsDetails();

    // EmployerInsuranceRetHeader manipulation variable
    curam.core.intf.EmployerInsuranceRetHeader employerInsuranceRetHeaderObj =
      curam.core.fact.EmployerInsuranceRetHeaderFactory.newInstance();

    // Call EmployerInsuranceRetHeader BPO to read the insurance return header
    // details and assign to return object
    readReturnHeaderDetailsDetails.insuranceReturnHdrDetails.assign(
      employerInsuranceRetHeaderObj.readInsRetHdrDtls(key.insuranceRetHdrKey));

    return readReturnHeaderDetailsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads insurance return header history details.
   *
   * @param key Key to read the insurance return header history details.
   *
   * @return Insurance Return header history details.
   *
   */
  public ReadReturnHeaderHistoryDetails readReturnHeaderHistory(
    ReadReturnHeaderHistoryKey key) throws AppException, InformationalException {

    // Create return object
    ReadReturnHeaderHistoryDetails readReturnHeaderHistoryDetails =
      new ReadReturnHeaderHistoryDetails();

    // EmployerInsuranceRetHeader manipulation variable
    curam.core.intf.EmployerInsuranceRetHeader employerInsuranceRetHeaderObj =
      curam.core.fact.EmployerInsuranceRetHeaderFactory.newInstance();

    // Call EmployerInsuranceRetHeader BPO to read the insurance return
    // header details
    readReturnHeaderHistoryDetails.employerReturnHdrRMDtlsList.assign(
      employerInsuranceRetHeaderObj.readHeaderHistory(
        key.insRetHeaderHistoryReadKey));

    return readReturnHeaderHistoryDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of insurance line item details for a concern role.
   *
   * @param key Contains a concern role identifier.
   *
   * @return List of insurance line item details.
   *
   */
  public SearchLineItemByConcernRoleIDDetails listLineItemForConcernRoleID(
    SearchLineItemByConcernRoleIDKey key) 
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return object
    SearchLineItemByConcernRoleIDDetails searchLineItemByConcernRoleIDDetails =
      new SearchLineItemByConcernRoleIDDetails();

    // MaintainInsuranceLineItem manipulation variable
    MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      MaintainInsuranceLineItemFactory.newInstance();

    // BEGIN, CR00102618, CSH
    // ClientMerge manipulation variables
    curam.core.facade.intf.ClientMerge clientMergeObj =
      curam.core.facade.fact.ClientMergeFactory.newInstance();
    curam.core.sl.intf.ClientMerge clientMergeSLObj =
      curam.core.sl.fact.ClientMergeFactory.newInstance();
    // END, CR00102618

    // ParticipantContext manipulation variables
    ParticipantContext participantContextObj =
      ParticipantContextFactory.newInstance();
    ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    // Page variables to link to for the original and duplicate client lists
    ClientPageLink dupPageIdentifier = new ClientPageLink();
    ClientPageLink origPageIdentifier = new ClientPageLink();
    
    // ConcernRole manipulation variables    
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleKey currentKey = new ConcernRoleKey();
    ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = 
      new ConcernRoleIDStatusCodeKey();
    
    // Get concern role ID from key
    participantContextDescriptionKey.concernRoleID =
      key.insRetLineItemRMKey.concernRoleID;

    // Get the context description for the concern role
    searchLineItemByConcernRoleIDDetails.contextDescription =
      participantContextObj.readContextDescription(
        participantContextDescriptionKey);

    // Call MaintainInsuranceLineItem BPO to read the insurance line item
    // details based on concern role identifier and assign to return
    // object
    searchLineItemByConcernRoleIDDetails.insReturnLineItemRMDtlsList.assign(
      maintainInsuranceLineItemObj.readmultiByConcernRoleID(
        key.insRetLineItemRMKey));

    // Display the duplicate client role soft links in a tab format
    
    // Set concernRole
    concernRoleKey.concernRoleID = key.insRetLineItemRMKey.concernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = concernRoleKey.concernRoleID;
    
    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier =
      CuramConst.kPerson_listInsuranceLineItemForDuplicate;
    origPageIdentifier.pageIdentifier =
      CuramConst.kPerson_listInsuranceLineItem;
    
    // Build up the xml data needed for the tab widget    
    searchLineItemByConcernRoleIDDetails.renderXML = 
      clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
 
    // Populate key to check for duplicate
    concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;
    
    // Set an indicator if this concern has duplicates 
    searchLineItemByConcernRoleIDDetails.ind = 
      clientMergeSLObj.isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
    // END, CR00120078 
    
    return searchLineItemByConcernRoleIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of insurance return header details for a concern role.
   *
   * @param key Contains a concern role identifier.
   *
   * @return List of insurance return header details.
   *
   */
  public SearchReturnHeaderByConcernRoleIDDetails listReturnHeaderForConcernRoleID(
    SearchReturnHeaderByConcernRoleIDKey key)
    throws AppException, InformationalException {

    // Create return object
    SearchReturnHeaderByConcernRoleIDDetails searchReturnHeaderByConcernRoleIDDetails =
      new SearchReturnHeaderByConcernRoleIDDetails();

    // EmployerInsuranceRetHeader manipulation variable
    curam.core.intf.EmployerInsuranceRetHeader employerInsuranceRetHeaderObj =
      curam.core.fact.EmployerInsuranceRetHeaderFactory.newInstance();

    // Context object and key
    curam.core.facade.intf.ParticipantContext participantContextObj =
      curam.core.facade.fact.ParticipantContextFactory.newInstance();
    ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    // Get concern role ID from key
    participantContextDescriptionKey.concernRoleID =
      key.insRetReadMultiKey.concernRoleID;

    // Get the context description for the concern role
    searchReturnHeaderByConcernRoleIDDetails.contextDescription =
      participantContextObj.readContextDescription(
        participantContextDescriptionKey);

    // Call EmployerInsuranceRetHeader BPO to read the insurance return
    // header details and assign to return object
    searchReturnHeaderByConcernRoleIDDetails.employerReturnHdrRMDtlsList.assign(
      employerInsuranceRetHeaderObj.readmultiByConcernRoleID(
        key.insRetReadMultiKey));

    return searchReturnHeaderByConcernRoleIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * Validates the insurance return header details.
   *
   * @param key Insurance return header details to be validated.
   *
   * @return List of validation messages.
   *
   */
  public ValidateInsuranceReturnDetails validateInsuranceReturn(
    ValidateInsuranceReturnKey key) throws AppException, InformationalException {

    // Create return object
    ValidateInsuranceReturnDetails validateInsuranceReturnDetails =
      new ValidateInsuranceReturnDetails();

    // EmployerInsuranceRetHeader manipulation variable
    curam.core.intf.EmployerInsuranceRetHeader employerInsuranceRetHeaderObj =
      curam.core.fact.EmployerInsuranceRetHeaderFactory.newInstance();

    // Call EmployerInsuranceRetHeader to validate the insurance return header
    // details
    validateInsuranceReturnDetails.validateInsuranceReturnResult.assign(
      employerInsuranceRetHeaderObj.validateInsuranceReturn(
        key.insuranceRetHdrKey));

    return validateInsuranceReturnDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of insurance consolidations.
   *
   * @param key Contain the concern role identifier.
   *
   * @return List of consolidation details.
   *
   */
  public ListConsolidationForConcernRoleIDDetails listConsolidationForConcernRoleID(
    ListConsolidationForConcernRoleIDKey key) 
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return object
    ListConsolidationForConcernRoleIDDetails 
      listConsolidationForConcernRoleIDDetails =
        new ListConsolidationForConcernRoleIDDetails();

    // MaintainConsolidationDetails manipulation variable
    MaintainConsolidationDetails maintainConsolidationDetailsObj =
      MaintainConsolidationDetailsFactory.newInstance();
    
    // Context manipulation variables
    ParticipantContext participantContextObj =
      ParticipantContextFactory.newInstance();
    ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    // Get concern role ID from key
    participantContextDescriptionKey.concernRoleID =
      key.consolidationRMByConcernKey.concernRoleID;

    // Get the context description for the concern role
    listConsolidationForConcernRoleIDDetails.contextDescription =
      participantContextObj.readContextDescription(
        participantContextDescriptionKey);

    // Call MaintainConsolidationDetails BPO to return the list of
    // insurance consolidations and assign to return object
    listConsolidationForConcernRoleIDDetails.consolidationRMDtlsList.assign(
      maintainConsolidationDetailsObj.readConsolByConcernRoleID(
        key.consolidationRMByConcernKey));

    // Display the duplicate client role soft links in a tab format
    // BEGIN, CR00221607, MC
    if(Configuration.getBooleanProperty(
        EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)){
    
      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      curam.core.facade.intf.ClientMerge clientMergeObj =
        curam.core.facade.fact.ClientMergeFactory.newInstance();
      curam.core.sl.intf.ClientMerge clientMergeSLObj =
        curam.core.sl.fact.ClientMergeFactory.newInstance();
      // END, CR00102618
      
      // Page variables to link to for the original and duplicate client lists
      ClientPageLink dupPageIdentifier = new ClientPageLink();
      ClientPageLink origPageIdentifier = new ClientPageLink();
      
      // ConcernRole manipulation variables    
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      ConcernRoleKey currentKey = new ConcernRoleKey();
      ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = 
        new ConcernRoleIDStatusCodeKey();
      
      // Set concernRole
      concernRoleKey.concernRoleID = 
        key.consolidationRMByConcernKey.concernRoleID;
  
      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;
      
      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier =
        CuramConst.kPerson_listInsuranceConsolidationForDuplicate;
      origPageIdentifier.pageIdentifier =
        CuramConst.kPerson_listInsuranceConsolidation;
      
      // Build up the xml data needed for the tab widget    
      listConsolidationForConcernRoleIDDetails.renderXML = 
        clientMergeObj.getDuplicateMenuRendererData(
          concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
   
      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;
      
      // Set an indicator if this concern has duplicates 
      listConsolidationForConcernRoleIDDetails.ind = 
        clientMergeSLObj.isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
      // END, CR00120078 
    }
    // END, CR00221607
    
    return listConsolidationForConcernRoleIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads insurance consolidation details.
   *
   * @param key Key to read the insurance consolidation details.
   *
   * @return Insurance consolidation details.
   *
   */
  public ReadConsolidationDetailsDetails readConsolidationDetails(
    ReadConsolidationDetailsKey key) throws AppException, InformationalException {

    // Create return object
    ReadConsolidationDetailsDetails readConsolidationDetailsDetails =
      new ReadConsolidationDetailsDetails();

    // MaintainConsolidationDetails manipulation variable
    curam.core.intf.MaintainConsolidationDetails maintainConsolidationDetailsObj =
      curam.core.fact.MaintainConsolidationDetailsFactory.newInstance();

    // Call MaintainConsolidationDetails BPO to read the insurance
    // consolidation details and assign to return object
    readConsolidationDetailsDetails.insurConsolidationReadDtls.assign(
      maintainConsolidationDetailsObj.readConsolidationDetails(
        key.insurConsolidationReadKey));

    return readConsolidationDetailsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads insurance consolidation details.
   *
   * @param key Key to read the insurance consolidation details.
   *
   * @return Insurance consolidation details.
   *
   */
  public ReadInsuranceHeaderHistoryDetailDetails readInsuranceHeaderHistoryDetail(ReadInsuranceHeaderHistoryDetailKey
    key) throws AppException, InformationalException {

    // Create return object
    ReadInsuranceHeaderHistoryDetailDetails readInsuranceHeaderHistoryDetailDetails =
      new ReadInsuranceHeaderHistoryDetailDetails();

    // EmployerInsuranceRetHeader manipulation variable
    curam.core.intf.EmployerInsuranceRetHeader employerInsuranceRetHeaderObj =
      curam.core.fact.EmployerInsuranceRetHeaderFactory.newInstance();

    // Call EmployerInsuranceRetHeader BPO to read the insurance header history
    // details and assign to return object
    readInsuranceHeaderHistoryDetailDetails.insuranceReturnHdrDetails.assign(
      employerInsuranceRetHeaderObj.readHistoryDetail(
        key.insRetHeaderHistoryReadKey));

    return readInsuranceHeaderHistoryDetailDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads insurance consolidation details.
   *
   * @param key Key to read the insurance consolidation details.
   *
   * @return Insurance consolidation details.
   *
   */
  public ReadLineItemHistoryDetailsDetails readLineItemHistoryDetails(
    ReadLineItemHistoryDetailsKey key) throws AppException, InformationalException {

    // Create return object
    ReadLineItemHistoryDetailsDetails readLineItemHistoryDetailsDetails =
      new ReadLineItemHistoryDetailsDetails();

    // MaintainInsuranceLineItem manipulation variable
    curam.core.intf.MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      curam.core.fact.MaintainInsuranceLineItemFactory.newInstance();

    // Call MaintainInsuranceLineItem BPO to read the insurance line item
    // history details and assign to return object
    readLineItemHistoryDetailsDetails.insRetLineItemDtls.assign(
      maintainInsuranceLineItemObj.readHistoryDetail(key.readHistoryRecordKey));

    return readLineItemHistoryDetailsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of contribution products.
   *
   * @return List of contribution products.
   *
   */
  public ListContributionProductDetails listContributionProduct()
    throws AppException, InformationalException {

    // Create return object
    ListContributionProductDetails listContributionProductDetails =
      new ListContributionProductDetails();

    // AdminProduct manipulation variables
    curam.core.intf.AdminProduct adminProductObj =
      curam.core.fact.AdminProductFactory.newInstance();
    ReadContributionProductsKey readContributionProductsKey =
      new ReadContributionProductsKey();

    // Set key to read contribution products and assign to return object
    readContributionProductsKey.contributionProductInd = true;
    readContributionProductsKey.statusCode =
      curam.codetable.RECORDSTATUS.NORMAL;

    // Call AdminProduct BPO to read contributions and assign to return
    // object
    listContributionProductDetails.assign(
      adminProductObj.readContributionsProducts(readContributionProductsKey));

    return listContributionProductDetails;
  }

  // BEGIN, CR00102618, CSH
  // ___________________________________________________________________________
  /**
   * Returns a list of insurance consolidation details for a duplicate
   * concern role.
   *
   * @param key Contains a duplicate concern role identifier.
   *
   * @return List of insurance line item details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ListConsolidationForDuplicateConcernRoleDetails listConsolidationForDuplicateConcernRoleID(
    ListConsolidationForConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return object
    ListConsolidationForDuplicateConcernRoleDetails 
      listConsolidationForDupConcernRoleIDDetails =
        new ListConsolidationForDuplicateConcernRoleDetails();

    // MaintainConsolidationDetails manipulation variable
    MaintainConsolidationDetails maintainConsolidationDetailsObj =
      MaintainConsolidationDetailsFactory.newInstance();

    // Context object and key
    ParticipantContext participantContextObj = 
      ParticipantContextFactory.newInstance();
    ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    // Get the context description for the concern role
    listConsolidationForDupConcernRoleIDDetails.
      duplicateConcernConsolidationList.contextDescription =
        participantContextObj.readContextDescription(
          participantContextDescriptionKey);
    
    // Set the context description key to be the duplicate concern role ID
    participantContextDescriptionKey.concernRoleID =
      key.consolidationRMByConcernKey.concernRoleID;

    // Get the context description for the duplicate concern role
    listConsolidationForDupConcernRoleIDDetails.duplicateContextDesc =
      participantContextObj.readContextDescription(
        participantContextDescriptionKey);

    // Call MaintainConsolidationDetails to return the list of
    // insurance consolidations and assign to return object
    listConsolidationForDupConcernRoleIDDetails.
      duplicateConcernConsolidationList.consolidationRMDtlsList.assign(
        maintainConsolidationDetailsObj.readConsolByConcernRoleID(
          key.consolidationRMByConcernKey));

    // Display the duplicate client role soft links in a tab format
    // BEGIN, CR00221607, MC
    if(Configuration.getBooleanProperty(
        EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)){
    
      // ClientMerge manipulation objects
      curam.core.facade.intf.ClientMerge clientMergeObj =
        curam.core.facade.fact.ClientMergeFactory.newInstance();
      curam.core.sl.intf.ClientMerge clientMergeSLObj =
        curam.core.sl.fact.ClientMergeFactory.newInstance();
      
      // ConcernRoleDuplicate manipulation variables
      ConcernRoleDuplicate concernRoleDuplicateObj =
        ConcernRoleDuplicateFactory.newInstance();
      ConcernRoleDuplicateDtlsList dupList = 
        new ConcernRoleDuplicateDtlsList();
      SearchByDuplicateConcernRoleIDKey dupKey =
        new SearchByDuplicateConcernRoleIDKey();
  
      // Page variables to link to for the original and duplicate client lists
      ClientPageLink dupPageIdentifier = new ClientPageLink();
      ClientPageLink origPageIdentifier = new ClientPageLink();
      
      // ConcernRole manipulation variables    
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      ConcernRoleKey currentKey = new ConcernRoleKey();
      ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = 
        new ConcernRoleIDStatusCodeKey();
      
      // Get original person concern role ID by searching on the duplicate ID
      dupKey.duplicateConcernRoleID =
        key.consolidationRMByConcernKey.concernRoleID;
      dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);
  
      // Set the context description key to be the original concern role ID
      participantContextDescriptionKey.concernRoleID =
        dupList.dtls.item(0).originalConcernRoleID;
      // Set concernRole
      concernRoleKey.concernRoleID =
        dupList.dtls.item(0).originalConcernRoleID;
  
      // Set concernRole to current concernRole
      currentKey.concernRoleID = key.consolidationRMByConcernKey.concernRoleID;
      
      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier = 
        CuramConst.kPerson_listInsuranceConsolidationForDuplicate;
      origPageIdentifier.pageIdentifier = 
        CuramConst.kPerson_listInsuranceConsolidation;
      
      // Build up the xml data needed for the tab widget    
      listConsolidationForDupConcernRoleIDDetails.
        duplicateConcernConsolidationList.renderXML = 
          clientMergeObj.getDuplicateMenuRendererData(
            concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
   
      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;
      
      // Set an indicator if this concern has duplicates 
      listConsolidationForDupConcernRoleIDDetails.
        duplicateConcernConsolidationList.ind = 
          clientMergeSLObj.isConcernRoleOriginalClient(
            concernRoleIDStatusCodeKey);
      // END, CR00120078 
    }
    // END, CR00221607

    return listConsolidationForDupConcernRoleIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of insurance line item details for a duplicate concern role.
   *
   * @param key Contains a duplicate concern role identifier.
   *
   * @return List of insurance line item details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public SearchLineItemByDuplicateConcernRoleIDDetails listLineItemForDuplicateConcernRoleID(
    SearchLineItemByConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return object
    SearchLineItemByDuplicateConcernRoleIDDetails 
      searchLineItemByDupConcernRoleIDDetails =
        new SearchLineItemByDuplicateConcernRoleIDDetails();

    // MaintainInsuranceLineItem manipulation variable
    MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      MaintainInsuranceLineItemFactory.newInstance();

    // ClientMerge manipulation variable
    curam.core.facade.intf.ClientMerge clientMergeObj =
      curam.core.facade.fact.ClientMergeFactory.newInstance();
    curam.core.sl.intf.ClientMerge clientMergeSLObj =
      curam.core.sl.fact.ClientMergeFactory.newInstance();

    // Page variables to link to for the original and duplicate client lists
    ClientPageLink dupPageIdentifier = new ClientPageLink();
    ClientPageLink origPageIdentifier = new ClientPageLink();
    
    // ConcernRole manipulation variables    
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleKey currentKey = new ConcernRoleKey();
    ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = 
      new ConcernRoleIDStatusCodeKey();
    
    // Context object and key
    ParticipantContext participantContextObj =
      ParticipantContextFactory.newInstance();
    ParticipantContextDescriptionKey participantContextDescriptionKey =
      new ParticipantContextDescriptionKey();

    // ConcernRoleDuplicate manipulation variables
    ConcernRoleDuplicate concernRoleDuplicateObj =
      ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = 
      new ConcernRoleDuplicateDtlsList();
    SearchByDuplicateConcernRoleIDKey dupKey =
      new SearchByDuplicateConcernRoleIDKey();

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.insRetLineItemRMKey.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    participantContextDescriptionKey.concernRoleID =
      dupList.dtls.item(0).originalConcernRoleID;

    // Get the context description for the concern role
    searchLineItemByDupConcernRoleIDDetails.duplicateConcernLineItemList.
      contextDescription = participantContextObj.readContextDescription(
        participantContextDescriptionKey);
    
    // Set the context description key to be the duplicate concern role ID
    participantContextDescriptionKey.concernRoleID =
      key.insRetLineItemRMKey.concernRoleID;

    // Get the context description for the duplicate concern role
    searchLineItemByDupConcernRoleIDDetails.duplicateContextDesc = 
      participantContextObj.readContextDescription(
        participantContextDescriptionKey);   

    // Call MaintainInsuranceLineItem to read the insurance line item
    // details based on concern role identifier and assign to return
    // object
    searchLineItemByDupConcernRoleIDDetails.duplicateConcernLineItemList.
      insReturnLineItemRMDtlsList.assign(
        maintainInsuranceLineItemObj.readmultiByConcernRoleID(
          key.insRetLineItemRMKey));

    // Display the duplicate client role soft links in a tab format
    
    // Set concernRole
    concernRoleKey.concernRoleID =
      dupList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.insRetLineItemRMKey.concernRoleID;
    
    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier =
      CuramConst.kPerson_listInsuranceLineItemForDuplicate;
    origPageIdentifier.pageIdentifier =
      CuramConst.kPerson_listInsuranceLineItem;
    
    // Build up the xml data needed for the tab widget    
    searchLineItemByDupConcernRoleIDDetails.duplicateConcernLineItemList.
      renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
 
    // Populate key to check for duplicate
    concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;
    
    // Set an indicator if this concern has duplicates 
    searchLineItemByDupConcernRoleIDDetails.duplicateConcernLineItemList.ind = 
      clientMergeSLObj.isConcernRoleOriginalClient(concernRoleIDStatusCodeKey);
    // END, CR00120078 

    return searchLineItemByDupConcernRoleIDDetails;
  }
  // END, CR00102618
}
