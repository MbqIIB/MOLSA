/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.attendance.impl;

import curam.codetable.impl.ABSENCEREASONASSOCIATETYPEEntry;
import curam.codetable.impl.ATTENDANCEABSENCEREASONEntry;
import curam.util.persistence.StandardEntity;

/**
 * Accessor interface for Absence Reason Configuration 
 * {@linkplain curam.attendance.impl.AbsenceReasonConfiguration}.
 * 
 */
public interface AbsenceReasonConfigurationAccessor extends StandardEntity {
  
  /**
   * Gets Absence reason for which client was absent and did not receive the service.
   * 
   * @return The absence reason.
   */
  ATTENDANCEABSENCEREASONEntry getAbsenceReasoncode();

  /**
   * Gets the Absence Reason Payable indicator.
   * 
   * @return The Absence Reason Payable indicator.
   */
  boolean isAbsenceReasonPayableEnabled();

  /**
   * Gets the Absence Reason Deductible indicator.
   * 
   * @return The Absence Reason Deductible indicator.
   */
  boolean isAbsenceReasonDeductibleEnabled();

  /**
   * Gets the Associate ID.
   * 
   * @return The Associate ID.
   */
  long getAssociateID();

  /**
   * Gets the absence reason unique identifier.
   * 
   * @return Unique identifier for absence reason.
   */
  long getAbsenceReasonID();

  /**
   * This method gets the associate type for the absence reason.
   * 
   * @return Absence reason associate type.
   */
  ABSENCEREASONASSOCIATETYPEEntry getAssociateType();
  
  /**
   * Get the Absence reason acceptable Indicator.
   * 
   * @return The Absence reason acceptance indicator.
   */
  boolean isAcceptable();
  
}
