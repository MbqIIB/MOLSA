/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;

import curam.codetable.BENMETHODOFDELIVERY;
import curam.codetable.CASESTATUS;
import curam.codetable.FINCOMPONENTCATEGORY;
import curam.codetable.FINCOMPONENTSTATUS;
import curam.codetable.METHODOFDELIVERY;
import curam.codetable.PRODUCTADMINCATEGORY;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CaseStatusFactory;
import curam.core.fact.ConcernRoleAddressFactory;
import curam.core.fact.FinancialComponentFactory;
import curam.core.fact.MaintainFinancialCalendarFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.ProductFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.fact.WMInstanceDataFactory;
import curam.core.intf.CachedCaseHeader;
import curam.core.intf.ConcernRoleAddress;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrection;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseIdentifier;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseStatusKey;
import curam.core.struct.ConcernRoleAddressStatusAndEndDate;
import curam.core.struct.ConcernRoleIDDeliveryMethod;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.DeferredProcessInstanceDetails;
import curam.core.struct.DeliveryMethodByNameKey;
import curam.core.struct.ExclusionDtlsList;
import curam.core.struct.FCcaseIDCategoryStatusDate;
import curam.core.struct.FinancialComponentDtlsList;
import curam.core.struct.PaymentMessageList;
import curam.core.struct.PaymentMessageText;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductKey;
import curam.core.struct.WMInstanceDataDtls;
import curam.message.BPOGENERATEPAYMENT;
import curam.message.GENERALCASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.fact.DeferredProcessingFactory;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.KeySet;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.UniqueID;


/**
 * Code to create a payment in a front office environment.
 *
 */
public abstract class GeneratePayment extends curam.core.base.GeneratePayment {
  
  // BEGIN, CR00264219, KH
  /**
   * Reference to Payment Correction interface.
   */
  @Inject
  protected PaymentCorrection paymentCorrection;
  
  // ___________________________________________________________________________
  /**
   * Constructor.
   */
  public GeneratePayment() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00264219

  // BEGIN, CR00148357, KH
  // ___________________________________________________________________________
  /**
   * To generate a payment online.
   *
   * @param caseIdentifier CaseIdentifier
   *
   * @return PaymentMessageList
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public PaymentMessageList generateInteractivePayment
    (CaseIdentifier caseIdentifier)throws AppException, InformationalException {
    // Return struct
    PaymentMessageList messageList = new PaymentMessageList();

    // BEGIN, CR00103023, CW
    // caseHeader manipulation variables
    CachedCaseHeader cachedCaseHeader = CachedCaseHeaderFactory.newInstance();
    // END, CR00103023

    // Read cached case header
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseIdentifier.caseID;

    CaseHeaderDtls caseHeaderDtls = cachedCaseHeader.read(caseHeaderKey);

    // BEGIN, CR00102570, CW
    // No financial components should be processed if the case status
    // is suspended and the curam.miscapp.payuptosuspendeddate property
    // is set to NO.
    Boolean issuePaymentToSuspendDate = Configuration.getBooleanProperty(
      EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE_DEFAULT));

    // No financial components should be processed if the case status
    // is closed and the curam.miscapp.payuptocloseddate property
    // is set to NO.
    Boolean issuePaymentToClosedDate = Configuration.getBooleanProperty(
      EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE_DEFAULT));
    
    // If the property that indicates whether or not a suspended case should
    // be paid up to the suspension date is not true AND the property indicating
    // whether or not a closed case should be paid up to closure date is not 
    // true then we only pay active and pending closure cases.
    if (!issuePaymentToSuspendDate && !issuePaymentToClosedDate) {

      if (!caseHeaderDtls.statusCode.equals(CASESTATUS.ACTIVE)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOGENERATEPAYMENT.ERR_GENPAYMENT_ACTIVEPENDINGCLOSURECASES_ONLY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    } else if (issuePaymentToSuspendDate && !issuePaymentToClosedDate) {
      
      // If the property that indicates whether or not a suspended case should
      // be paid up to the suspension date is true AND the property indicating
      // whether or not a closed case should be paid up to closure date is not 
      // true then we only pay active, suspended and pending closure cases.
      if (!caseHeaderDtls.statusCode.equals(CASESTATUS.ACTIVE)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.SUSPENDED)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {
          
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOGENERATEPAYMENT.ERR_GENPAYMENT_ACTIVESUSPENDEDCASES_ONLY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    } else if (!issuePaymentToSuspendDate && issuePaymentToClosedDate) {
      
      // If the property that indicates whether or not a suspended case should
      // be paid up to the suspension date is not true AND the property 
      // indicating whether or not a closed case should be paid up to closure 
      // date is true then we only pay active, closed and pending closure cases.
      if (!caseHeaderDtls.statusCode.equals(CASESTATUS.ACTIVE)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.CLOSED)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {
          
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOGENERATEPAYMENT.ERR_GENPAYMENT_ACTIVECLOSEDCASES_ONLY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    } else {
      // If the property that indicates whether or not a suspended case should
      // be paid up to the suspension date is true AND the property indicating
      // whether or not a closed case should be paid up to closure date is true
      // then we only pay active, suspended, closed and pending closure cases.
      if (!caseHeaderDtls.statusCode.equals(CASESTATUS.ACTIVE)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.SUSPENDED)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.CLOSED)
        && !caseHeaderDtls.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {
        
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOGENERATEPAYMENT.ERR_GENPAYMENT_ACTIVESUSPENDEDCLOSEDCASES_ONLY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // END, CR00102570

    // BEGIN, CR00226619, PM
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = caseIdentifier.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00226619
    
    // Read productDelivery entity
    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    productDeliveryKey.caseID = caseIdentifier.caseID;

    ProductDeliveryDtls productDeliveryDtls = ProductDeliveryFactory.newInstance().read(
      productDeliveryKey);

    // Read product entity
    ProductKey productKey = new ProductKey();

    productKey.productID = productDeliveryDtls.productID;

    ProductDtls productDtls = ProductFactory.newInstance().read(productKey);

    // BEGIN, CR00264219, KH
    /*
     * This processing should not be used by liability cases or by overpayment
     * style payment correction cases. 
     */
    if (productDtls.adminCategory.equals(PRODUCTADMINCATEGORY.LIABILITY)
      || (productDtls.adminCategory.equals(PRODUCTADMINCATEGORY.CORRECTION)
        && paymentCorrection.isOverPaymentPaymentCorrection(caseHeaderKey))) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGENERATEPAYMENT.ERR_GENPAYMENT_BENEFITPRODUCTS_ONLY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00264219

    // Read the current case status
    CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();

    currentCaseStatusKey.caseID = caseIdentifier.caseID;

    // BEGIN, CR00224271, ZV
    CaseStatusDtls caseStatusDtls = CaseStatusFactory.newInstance().readCurrentStatusByCaseID1(
      currentCaseStatusKey);
    // END, CR00224271
    
    // BEGIN, CR00279194, KRK
    final DeferredProcessInstanceDetails deferredProcessInstanceDetails = new DeferredProcessInstanceDetails();

    deferredProcessInstanceDetails.caseStatus = caseStatusDtls.statusCode;
    // END, CR00279194


    // Set end date on the current status
    CaseStatusKey caseStatusKey = new CaseStatusKey();

    caseStatusKey.caseStatusID = caseStatusDtls.caseStatusID;
    caseStatusDtls.endDate = Date.getCurrentDate();
    
    CaseStatusFactory.newInstance().modify(caseStatusKey, caseStatusDtls);

    // Create a new status of Delayed Processing Pending
    caseStatusDtls.caseStatusID = UniqueIDFactory.newInstance().getNextID();
    caseStatusDtls.caseID = caseIdentifier.caseID;
    caseStatusDtls.statusCode = CASESTATUS.DELAYEDPROC;
    caseStatusDtls.startDate = Date.getCurrentDate();
    caseStatusDtls.endDate = Date.kZeroDate;

    CaseStatusFactory.newInstance().insert(caseStatusDtls);

    // Update case header with new status
    caseHeaderDtls.statusCode = CASESTATUS.DELAYEDPROC;

    // BEGIN, CR00103023, CW
    cachedCaseHeader.modify(caseHeaderKey, caseHeaderDtls);
    // END, CR00103023

    // Set financial component search criteria
    FCcaseIDCategoryStatusDate fcCaseIDCategoryStatusDate = new FCcaseIDCategoryStatusDate();

    fcCaseIDCategoryStatusDate.caseID = caseIdentifier.caseID;
    fcCaseIDCategoryStatusDate.categoryCode = FINCOMPONENTCATEGORY.CLAIM;
    fcCaseIDCategoryStatusDate.statusCode = FINCOMPONENTSTATUS.LIVE;

    // Check for financial exclusion dates
    ExclusionDtlsList exclusionDtlsList = MaintainFinancialCalendarFactory.newInstance().getExclusionDatesForAllMethods();

    if (!exclusionDtlsList.dtls.isEmpty()) {

      int lastRecordPos = (exclusionDtlsList.dtls.size() - 1);
      // BEGIN CR00138876, AK
      Date exclusionDate = exclusionDtlsList.dtls.item(lastRecordPos).exclusionDate;
      Date caseStartDate = caseHeaderDtls.startDate;

      if (!(exclusionDate.before(caseStartDate))) {
        
        fcCaseIDCategoryStatusDate.nextProcessingDate = exclusionDtlsList.dtls.item(lastRecordPos).exclusionDate;
      } else {
        fcCaseIDCategoryStatusDate.nextProcessingDate = Date.getCurrentDate();
      }
      // END CR00138876, AK
    } else {

      fcCaseIDCategoryStatusDate.nextProcessingDate = Date.getCurrentDate();
    }

    // Search the FinancialComponent entity for all possible FCs that could be
    // eligible for processing
    FinancialComponentDtlsList financialComponentDtlsList = FinancialComponentFactory.newInstance().searchByCaseIDCategoryStatusDate(
      fcCaseIDCategoryStatusDate);
    
    // BEGIN, CR00157986, MR
    DeliveryMethodByNameKey deliveryMethodByNameKey = new DeliveryMethodByNameKey();
    
    if (!financialComponentDtlsList.dtls.isEmpty()) {

      for (int i = 0; i < financialComponentDtlsList.dtls.size(); i++) {
        // BEGIN, CR00157011, MC
        ConcernRoleIDDeliveryMethod concernRoleIDDeliveryMethod = new ConcernRoleIDDeliveryMethod();

        concernRoleIDDeliveryMethod.concernRoleID = caseHeaderDtls.concernRoleID;
        concernRoleIDDeliveryMethod.deliveryMethod = financialComponentDtlsList.dtls.item(i).nomineeDelivMethod;
        // END, CR00157011
        validateDetails(concernRoleIDDeliveryMethod);
        // set the delivery method name
        deliveryMethodByNameKey.name = financialComponentDtlsList.dtls.item(i).nomineeDelivMethod;
        // Validate the financial components nominee delivery method
        validateFCsNomineeDeliveryMethod(deliveryMethodByNameKey);
        // END, CR00157986
      }
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOGENERATEPAYMENT.ERR_GENPAYMENT_NOT_DUE_TODAY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    
    // BEGIN, CR00279194, KRK
    deferredProcessInstanceDetails.caseID = caseIdentifier.caseID;
    deferredProcessInstanceDetails.nomineeDeliveryMethod = financialComponentDtlsList.dtls.item(0).nomineeDelivMethod;
    deferredProcessInstanceDetails.ConcernRoleID = caseHeaderDtls.concernRoleID;
    
    // Starts the delayed process.
    startDelayedProcess(deferredProcessInstanceDetails);
    // END, CR00279194

    // Inform the user that this payment has been queued for payment generation
    PaymentMessageText messageText = new PaymentMessageText();

    messageText.message = // BEGIN, CR00163471, JC
      BPOGENERATEPAYMENT.INF_GENPAYMENT_QUEUED_FOR_GENERATION.getMessageText(
      TransactionInfo.getProgramLocale());
    // END, CR00163471, JC

    messageList.dtls.addRef(messageText);

    return messageList;
  }
  
  // ___________________________________________________________________________
  /**
   * This method validates the bank account details and the address details of
   * the concern towards whom the payment is being made.
   *
   * @param concernRoleKey
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00157011, MC
  public void validateDetails
    (ConcernRoleIDDeliveryMethod concernRoleIDDeliveryMethod)
    throws AppException, InformationalException {

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleIDDeliveryMethod.concernRoleID;
    String methodOfDelivery = concernRoleIDDeliveryMethod.deliveryMethod;

    // get concern role Address status Code and end Date
      
    if (METHODOFDELIVERY.CHEQUE.equals(methodOfDelivery)
      || METHODOFDELIVERY.VOUCHER.equals(methodOfDelivery)) {
      ConcernRoleAddress concernRoleAddressObj = ConcernRoleAddressFactory.newInstance();
      ConcernRoleAddressStatusAndEndDate concernRoleAddressStatusAndEndDate = concernRoleAddressObj.readConcernRoleAddressDetailsByConcernRoleID(
        concernRoleKey);

      if (RECORDSTATUS.CANCELLED.equals(
        concernRoleAddressStatusAndEndDate.statusCode)
          || (!concernRoleAddressStatusAndEndDate.endDate.isZero()
            && concernRoleAddressStatusAndEndDate.endDate.before(
              curam.util.type.Date.getCurrentDate()))) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOGENERATEPAYMENT.ERR_GENPAYMENT_ACTIVENONEXPIREDADDRESS_ONLY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
  }

  // END, CR00157011
  
  // BEGIN, CR00157986, MR
  // ___________________________________________________________________________
  /**
   * Validate the financial components nominee delivery method for processing.
   *
   * @param deliveryMethodByNameKey name of the delivery method.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected void validateFCsNomineeDeliveryMethod
    (DeliveryMethodByNameKey deliveryMethodByNameKey)
    throws AppException, InformationalException {

    String methodOfDelivery = deliveryMethodByNameKey.name;

    if (!(BENMETHODOFDELIVERY.CASH.equals(methodOfDelivery)
      || BENMETHODOFDELIVERY.CHEQUE.equals(methodOfDelivery)
      || BENMETHODOFDELIVERY.VOUCHER.equals(methodOfDelivery))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOGENERATEPAYMENT.ERR_GENPAYMENT_INVALID_DELMTHD),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // END, CR00157986
  
  // BEGIN, CR00279194, KRK
  /**
   * Starts the  delayed process for the payment processing.
   *
   * @param deferredProcessInstanceDetails
   * name of the nominee delivery method.
   *
   * @return the deferred process instance data details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WMInstanceDataDtls startDelayedProcess(
    final DeferredProcessInstanceDetails deferredProcessInstanceDetails)
    throws AppException, InformationalException {

    final WMInstanceDataDtls wmInstanceDataDtls = new WMInstanceDataDtls();
    
    wmInstanceDataDtls.caseID = deferredProcessInstanceDetails.caseID;
    wmInstanceDataDtls.caseStatus = deferredProcessInstanceDetails.caseStatus;
    wmInstanceDataDtls.concernRoleID = deferredProcessInstanceDetails.ConcernRoleID;
    wmInstanceDataDtls.deliveryMethod = deferredProcessInstanceDetails.nomineeDeliveryMethod;
    wmInstanceDataDtls.wm_instDataID = UniqueID.nextUniqueID(
      KeySet.kKeySetDeferredProcessingTicket);
    wmInstanceDataDtls.enteredByID = TransactionInfo.getProgramUser();
    wmInstanceDataDtls.eligibilityAssFromDate = Date.getCurrentDate();
    
    WMInstanceDataFactory.newInstance().insert(wmInstanceDataDtls);

    // Start delayed process.     
    DeferredProcessingFactory.newInstance().startProcess(
      DP_const.DP_PROCESS_PAYMENT, wmInstanceDataDtls.wm_instDataID);
    
    return wmInstanceDataDtls;
  }
  // END, CR00279194

  
}
