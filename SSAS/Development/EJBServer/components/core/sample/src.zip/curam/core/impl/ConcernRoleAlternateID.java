/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import java.util.ArrayList;
import java.util.HashMap;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.ENTITYATTRIBUTENAMES;
import curam.codetable.RECORDSTATUS;
import curam.core.events.CONCERNROLEALTERNATEID;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.AlternateIDReadmultiDtlsList;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleAlternateIDDtls;
import curam.core.struct.ConcernRoleAlternateIDKey;
import curam.core.struct.ConcernRoleAlternateIDSnapshotDtls;
import curam.core.struct.ConcernRoleAlternateIDSnapshotKey;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.message.PARTICIPANTDATACASE;
import curam.message.SUMMARYDETAILS;
import curam.pdc.fact.PDCUtilFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;


public abstract class ConcernRoleAlternateID extends curam.core.base.ConcernRoleAlternateID implements ParticipantEvidenceInterface {

  // BEGIN, CR00059195, POH
  protected static ThreadLocal<ConcernRoleAlternateIDCache> cachedReadTL = new ThreadLocal<ConcernRoleAlternateIDCache>();

  // ___________________________________________________________________________
  /**
   * Clear cached data in cachedReadTL
   */
  protected void clearCaches() {
    ConcernRoleAlternateIDCache cache = cachedReadTL.get();

    if (cache != null) {
      cache.map.clear();
    } else {
      cache = new ConcernRoleAlternateIDCache();
      cachedReadTL.set(cache);
    }
    cache.transactionID = TransactionInfo.getIdentifierForThisThread();

  }

  // ___________________________________________________________________________
  /**
   * Caching Details for Improved Performance
   */
  protected class ConcernRoleAlternateIDCache {
    public ConcernRoleAlternateIDCache() {
      map = new HashMap<Long, ConcernRoleAlternateIDDtls>();
      transactionID = 0;
    }
    HashMap<Long, ConcernRoleAlternateIDDtls> map;
    int transactionID;
  }
  // BEGIN, CR00065902, MMC

  // ___________________________________________________________________________
  /**
   * Calculates the AttributionDates For entity,
   * specifically for its use as a ParticipantEvidence.
   *
   * @param caseKey
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return AttributedDateDetails
   */
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey, EIEvidenceKey evKey) throws AppException, InformationalException {

    // return struct
    AttributedDateDetails attributedDateDetails = new AttributedDateDetails();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls = read(evKey);

    // END, CR00240667     

    // populate return struct
    attributedDateDetails.fromDate = concernRoleAlternateIDDtls.startDate;
    attributedDateDetails.toDate = concernRoleAlternateIDDtls.endDate;

    return attributedDateDetails;
  }

  /**
   * Reads the entity details given the evidence record identifier.
   *
   * @param key The evidence record identifier.
   *
   * @return The entity details.
   *
   * @throws InformationalException
   * @throws AppException
   */
  protected ConcernRoleAlternateIDDtls read(EIEvidenceKey key)
    throws AppException, InformationalException {
    
    // manipulation variables
    ConcernRoleAlternateIDKey concernRoleAlternateIDKey = new ConcernRoleAlternateIDKey();
    ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls = new ConcernRoleAlternateIDDtls();

    curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj = curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();

    // populate the key with passed in parameter
    concernRoleAlternateIDKey.concernRoleAlternateID = key.evidenceID;

    // BEGIN, CR00067890, POH
    // read concernRoleAlternateID details
    try {
      concernRoleAlternateIDDtls = concernRoleAlternateIDObj.read(
        concernRoleAlternateIDKey);
    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot concernRoleAlternateID entity
      ConcernRoleAlternateIDSnapshotKey concernRoleAlternateIDSnapshotKey = new ConcernRoleAlternateIDSnapshotKey();

      curam.core.intf.ConcernRoleAlternateIDSnapshot concernRoleAlternateIDSnapshotObj = curam.core.fact.ConcernRoleAlternateIDSnapshotFactory.newInstance();

      // populate the concernRoleAlternateID snapshot key with
      // passed in parameter
      concernRoleAlternateIDSnapshotKey.concernRoleAltIDSnapshotID = key.evidenceID;

      // read concernRoleAlternateID snapshot details
      ConcernRoleAlternateIDSnapshotDtls concernRoleAlternateIDSnapshotDtls = concernRoleAlternateIDSnapshotObj.read(
        concernRoleAlternateIDSnapshotKey);

      concernRoleAlternateIDDtls.assign(concernRoleAlternateIDSnapshotDtls);
    }
    // END, CR00067890
    return concernRoleAlternateIDDtls;
  }

  // ___________________________________________________________________________
  /**
   * Get evidence details for the list display
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @return Evidence details to be displayed on the list page
   */
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key) throws AppException, InformationalException {

    // return struct
    EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls = read(key);

    // END, CR00240667

    // BEGIN, CR00060475, POH
    // set start and end dates
    eiFieldsForListDisplayDtls.startDate = concernRoleAlternateIDDtls.startDate;
    eiFieldsForListDisplayDtls.endDate = concernRoleAlternateIDDtls.endDate;
    // END, CR00060475

    // Set the summary details.
    // BEGIN, CR00241068, CD
    LocalisableString message = new LocalisableString(
      SUMMARYDETAILS.ALTERNATE_ID);

    message.arg(
      CodeTable.getOneItem(curam.codetable.CONCERNROLEALTERNATEID.TABLENAME, 
      concernRoleAlternateIDDtls.typeCode));
    message.arg(concernRoleAlternateIDDtls.alternateID);

    eiFieldsForListDisplayDtls.summary = message.getMessage(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00241068

    return eiFieldsForListDisplayDtls;

  }

  // ___________________________________________________________________________
  /**
   * Inserts evidence details - overrides Participant Evidence inherited abstract method
   *
   * @param dtls Object containing details of entity
   * @param parentKey EIEvidenceKey for parent
   * @return the eiEvidenceKey to access the inserted evidence
   */
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey) throws AppException, InformationalException {

    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ConcernRoleAlternateIDDtls) dtls);

    eiEvidenceKey.evidenceID = ((ConcernRoleAlternateIDDtls) dtls).concernRoleAlternateID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEALTERNATEID;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Inserts ConcernRoleAlternateID evidence on modification
   *
   * @param dtls Object containing details of entity
   * @param origKey EIEvidenceKey for entity to insert
   * @param parentKey EIEvidenceKey for parent
   * @return the EIEvidenceKey to access the inserted evidence
   */
  public EIEvidenceKey insertEvidenceOnModify(Object dtls, EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException, InformationalException {

    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ConcernRoleAlternateIDDtls) dtls);

    eiEvidenceKey.evidenceID = ((ConcernRoleAlternateIDDtls) dtls).concernRoleAlternateID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEALTERNATEID;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modify ConcernRoleAlternateID evidence
   *
   * @param key Evidence key containing evidenceID and evidenceType
   * @param dtls ConcernRoleAlternateID entity details
   */
  public void modifyEvidence(EIEvidenceKey key, Object dtls) throws AppException, InformationalException {
    // ConcernRoleAlternateID entity key
    ConcernRoleAlternateIDKey concernRoleAlternateIDKey = new ConcernRoleAlternateIDKey();

    // Set entity key for modify
    concernRoleAlternateIDKey.concernRoleAlternateID = key.evidenceID;

    // Modify details
    modify(concernRoleAlternateIDKey, (ConcernRoleAlternateIDDtls) dtls);

  }

  // ___________________________________________________________________________
  /**
   * Inserts details into database. The cache is cleared first.
   *
   * @param details  Contains entity details
   */
  @Override
  public void insert(ConcernRoleAlternateIDDtls details) throws AppException, InformationalException {

    this.clearCaches();
    super.insert(details);
  }

  // ___________________________________________________________________________
  /**
   * Modifies details in the database Entity. The cache is cleared first.
   *
   * @param key  Contains key to access entity details
   * @param details  Contains details to modify
   */
  @Override
  public void modify(ConcernRoleAlternateIDKey key, ConcernRoleAlternateIDDtls details) throws AppException, InformationalException {
    // We want to clear the cache in case for some reason the database
    // evidence is required e.g. if the evidence was updated by another user.
    // So to ensure we have the correct evidence, clear the cache and force a
    // read from the database
    this.clearCaches();

    super.modify(key, details);

    // The reason why we have to clear the cache here is a result of how the
    // evidence controller performs the modifying of evidence. PreModifying the
    // record it reads the details (first time it reads the details so will be
    // read from database and cached). The record is modified and post
    // modifying, the evidence controller calls performValidation
    // (validates the record) which requires a read of the evidence. The cached
    // evidence has stored the evidence PRIOR to the modification of the record.
    // Therefore we want to go to the database to read the modified evidence and
    // as a result clear the cache post modification.
    this.clearCaches();
  }

  // ___________________________________________________________________________
  /**
   * reads all ConcernRoleAlternateID Entities by its Parent ID
   *
   * @param key EIEvidenceKey, the evidence key of the parent
   * @return the EIEvidenceKeyList of children
   */
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key) throws AppException, InformationalException {
    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Read evidence details - overrides Participant Evidence inherited abstract method
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @return the Object with the readEvidence details
   */
  public Object readEvidence(EIEvidenceKey key) throws AppException, InformationalException {

    // manipulation variables
    ConcernRoleAlternateIDKey concernRoleAlternateIDKey = new ConcernRoleAlternateIDKey();
    ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls = new ConcernRoleAlternateIDDtls();
    curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj = curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();

    // populate the concernRoleAlternateID key with passed in parameter
    concernRoleAlternateIDKey.concernRoleAlternateID = key.evidenceID;

    try {
      // read concernRoleAlternateID details
      concernRoleAlternateIDDtls = concernRoleAlternateIDObj.read(
        concernRoleAlternateIDKey);

      return concernRoleAlternateIDDtls;

    } catch (RecordNotFoundException recordNotFoundException) {

      // BEGIN, CR00060045, POH
      // If no record has been return for ID passed
      // read from the snapshot concernRoleAlternateID entity
      concernRoleAlternateIDDtls = new ConcernRoleAlternateIDDtls();
      ConcernRoleAlternateIDSnapshotKey concernRoleAlternateIDSnapshotKey = new ConcernRoleAlternateIDSnapshotKey();
      ConcernRoleAlternateIDSnapshotDtls concernRoleAlternateIDSnapshotDtls = new ConcernRoleAlternateIDSnapshotDtls();
      curam.core.intf.ConcernRoleAlternateIDSnapshot concernRoleAlternateIDSnapshotObj = curam.core.fact.ConcernRoleAlternateIDSnapshotFactory.newInstance();

      // populate the concernRoleAlternateID snapshot key with passed in parameter
      concernRoleAlternateIDSnapshotKey.concernRoleAltIDSnapshotID = key.evidenceID;

      // read concernRoleAlternateID snapshot details
      concernRoleAlternateIDSnapshotDtls = concernRoleAlternateIDSnapshotObj.read(
        concernRoleAlternateIDSnapshotKey);

      // replace primary key on concernRoleDtls with concernRoleSnapshot
      // primary key concernRoleSnapshotID
      concernRoleAlternateIDDtls.assign(concernRoleAlternateIDSnapshotDtls);

      return concernRoleAlternateIDDtls;
      // END, CR00060045
    }

  }

  // ___________________________________________________________________________
  /**
   * return list for validation
   *
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return the EIEvidenceKeyList for validation
   */
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey) throws AppException, InformationalException {
    // This evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Validates evidence details
   *
   * @param evKey Evidence key
   * @param evKeyList Evidence key list
   * @param mode Validate mode (insert, delete, applyChanges, modify)
   */
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList, ValidateMode mode) throws AppException, InformationalException {// This evidence interface method is currently not implemented for
    // participant evidence.
  }

  // ___________________________________________________________________________
  /**
   * To create a new snapshot record of the concernRoleAlternateID entity,
   * specifically for its use as a ParticpantEvidence.
   *
   * @param key the key to access the entity for which to create a snapshot
   * @return the key to access the snapshot
   */
  public EIEvidenceKey createSnapshot(EIEvidenceKey key) throws AppException, InformationalException {

    // return struct
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // manipulation variables
    ConcernRoleAlternateIDKey concernRoleAlternateIDKey = new ConcernRoleAlternateIDKey();
    ConcernRoleAlternateIDSnapshotDtls concernRoleAlternateIDSnapshotDtls = new ConcernRoleAlternateIDSnapshotDtls();
    curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj = curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();
    curam.core.intf.ConcernRoleAlternateIDSnapshot concernRoleAlternateIDSnapshotObj = curam.core.fact.ConcernRoleAlternateIDSnapshotFactory.newInstance();

    // populate the key with passed in parameter
    concernRoleAlternateIDKey.concernRoleAlternateID = key.evidenceID;

    // read concernRoleAlternateID details
    ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls = concernRoleAlternateIDObj.read(
      concernRoleAlternateIDKey);

    // BEGIN, CR00060045, POH
    // populate snapshot details
    concernRoleAlternateIDSnapshotDtls.assign(concernRoleAlternateIDDtls);
    // END, CR00060045
    concernRoleAlternateIDSnapshotDtls.creationDateTime = DateTime.getCurrentDateTime();
    // insert snapshot record
    concernRoleAlternateIDSnapshotObj.insert(concernRoleAlternateIDSnapshotDtls);

    // populate return struct
    eiEvidenceKey.evidenceID = concernRoleAlternateIDSnapshotDtls.concernRoleAltIDSnapshotID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEALTERNATEID;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * remove Entity
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @param dtls of entity to remove
   */
  public void removeEvidence(EIEvidenceKey key, Object dtls) throws AppException, InformationalException {

    // Entity key
    ConcernRoleAlternateIDKey concernRoleAlternateIDKey = new ConcernRoleAlternateIDKey();

    // Set entity key for modify
    concernRoleAlternateIDKey.concernRoleAlternateID = key.evidenceID;

    // Modify details
    modify(concernRoleAlternateIDKey, (ConcernRoleAlternateIDDtls) dtls);

  }

  // END, CR00059195

  // ___________________________________________________________________________
  /**
   * Raise a post Insert event
   *
   * @param details details for the concernRoleAlternateID record.
   */    
  @Override
  protected void postinsert(ConcernRoleAlternateIDDtls details)
    throws AppException, InformationalException {

    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLEALTERNATEID.INSERT_CONCERN_ROLE_ALTERNATE_ID;
    // END, CR00047242
    event.primaryEventData = details.concernRoleAlternateID;
    // BEGIN, CR00201195, ZV
    event.secondaryEventData = details.concernRoleID;
    // END, CR00201195
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // ___________________________________________________________________________
  /**
   * Raise a post Modify event
   *
   * @param key  concernRoleAlternateID  to modify
   * @param details for the concernRoleAlternateID record.
   */  
  @Override
  protected void postmodify(ConcernRoleAlternateIDKey key,
    ConcernRoleAlternateIDDtls details) throws AppException,
      InformationalException {

    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLEALTERNATEID.MODIFY_CONCERN_ROLE_ALTERNATE_ID;
    // END, CR00047242

    event.primaryEventData = key.concernRoleAlternateID;
    // BEGIN, CR00201195, ZV
    event.secondaryEventData = details.concernRoleID;
    // END, CR00201195
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // BEGIN, CR00059697, SK
  // ___________________________________________________________________________
  /**
   * Method to search for records on a participant entity by concernRoleID and
   * status.
   *
   * @param key - The unique concernRoleID of the participant.
   *
   * @return A list of EIEvidenceKey objects each containing an evidenceID/evidenceType pair.
   */
  public EIEvidenceKeyList readAllByConcernRoleID(ConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00060045, POH
    // return struct
    EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    // manipulation variables
    EIEvidenceKey eiEvidenceKey;
    // BEGIN, CR00060163, POH
    // BEGIN, CR00066203, AC
    ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();
    AlternateIDReadmultiDtlsList alternateIDReadmultiDtlsList = new AlternateIDReadmultiDtlsList();
    curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj = curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();

    // populate the concernRoleAddress key with passed in parameter
    concernRoleIDStatusCodeKey.concernRoleID = key.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = RECORDSTATUS.NORMAL;

    // read list of concernRoleAddress records for concernRole
    alternateIDReadmultiDtlsList = concernRoleAlternateIDObj.searchByConcernRoleIDAndStatus(
      concernRoleIDStatusCodeKey);
    // END, CR00066203

    // loop through returned list adding each returned ID to returned struct.
    for (int i = 0; i < alternateIDReadmultiDtlsList.dtls.size(); i++) {

      // Instantiate struct
      eiEvidenceKey = new EIEvidenceKey();

      // populate details
      eiEvidenceKey.evidenceID = alternateIDReadmultiDtlsList.dtls.item(i).concernRoleAlternateID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEALTERNATEID;

      // add details to return struct
      eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
    }
    // END, CR00060163
    return eiEvidenceKeyList;
    // END, CR00060045

  }

  // END, CR00059697
  // END, CR00065902

  // BEGIN, CR00069014, JPG
  // ___________________________________________________________________________
  /**
   * Method to compare attributes on two records of the same entity type.
   * It then returns an ArrayList of strings with the names of each attribute that was
   * different between them.
   *
   * @param key - Contains an evidenceID / evidenceType pairing
   * @param dtls - a struct of the same type as the key containing the attributes
   * to be compared against
   *
   * @return A list of Strings. Each represents an attribute name that differed.
   */
  public ArrayList<String> getChangedAttributeList(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Declare the return list to hold the names of the attributes that changed
    ArrayList<String> attributesChanged = new ArrayList<String>();

    // Create ConcernRoleAlternateID structs to allow a comparison of what is
    // in the database and what is in the struct dtls.
    ConcernRoleAlternateIDDtls concernRoleAlternateIDCompareDtls1 = new ConcernRoleAlternateIDDtls();
    ConcernRoleAlternateIDDtls concernRoleAlternateIDCompareDtls2 = new ConcernRoleAlternateIDDtls();

    try {

      curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj = curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();

      ConcernRoleAlternateIDKey concernRoleAlternateIDKey = new ConcernRoleAlternateIDKey();

      concernRoleAlternateIDKey.concernRoleAlternateID = key.evidenceID;

      // read ConcernRoleAlternateID details
      concernRoleAlternateIDCompareDtls1 = concernRoleAlternateIDObj.read(
        concernRoleAlternateIDKey);

      // Populate the ConcernRoleAlternateID struct that will be compared against
      concernRoleAlternateIDCompareDtls2.assign(
        (ConcernRoleAlternateIDDtls) dtls);

    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot ConcernRoleAlternateID entity
      curam.core.intf.ConcernRoleAlternateIDSnapshot concernRoleAlternateIDSnapshotObj = curam.core.fact.ConcernRoleAlternateIDSnapshotFactory.newInstance();

      ConcernRoleAlternateIDSnapshotKey concernRoleAlternateIDSnapshotKey = new ConcernRoleAlternateIDSnapshotKey();

      // populate the ConcernRoleAlternateID snapshot key with passed in parameter
      concernRoleAlternateIDSnapshotKey.concernRoleAltIDSnapshotID = key.evidenceID;

      // Read the ConcernRoleAlternateID snapshot details
      concernRoleAlternateIDCompareDtls2.assign(
        concernRoleAlternateIDSnapshotObj.read(
          concernRoleAlternateIDSnapshotKey));

      // Populate the concernRoleAddress struct that will be compared against
      concernRoleAlternateIDCompareDtls1.assign(
        (ConcernRoleAlternateIDDtls) dtls);
    }

    if (concernRoleAlternateIDCompareDtls1.concernRoleID
      != concernRoleAlternateIDCompareDtls2.concernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEID);
    }
    // BEGIN, CR00090864, CM
    if (!concernRoleAlternateIDCompareDtls1.alternateID.equals(
      concernRoleAlternateIDCompareDtls2.alternateID)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.ALTERNATEID);
    }
    // END, CR00090864
    if (!concernRoleAlternateIDCompareDtls1.typeCode.equals(
      concernRoleAlternateIDCompareDtls2.typeCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.TYPECODE);
    }
    if (!concernRoleAlternateIDCompareDtls1.startDate.equals(
      concernRoleAlternateIDCompareDtls2.startDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STARTDATE);
    }
    if (!concernRoleAlternateIDCompareDtls1.endDate.equals(
      concernRoleAlternateIDCompareDtls2.endDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.ENDDATE);
    }
    if (!concernRoleAlternateIDCompareDtls1.statusCode.equals(
      concernRoleAlternateIDCompareDtls2.statusCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STATUSCODE);
    }
    if (!concernRoleAlternateIDCompareDtls1.comments.equals(
      concernRoleAlternateIDCompareDtls2.comments)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COMMENTS);
    }
    if (concernRoleAlternateIDCompareDtls1.concernRoleAlternateID
      != concernRoleAlternateIDCompareDtls2.concernRoleAlternateID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEALTERNATEID);
    }

    return attributesChanged;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if the attributes that changed during a modify require
   * reassessment to be run when they are applied.
   *
   * @param attributesChanged - A list of Strings. Each represents the name of an
   * attribute that changed
   *
   * @return true if Reassessment required
   */
  public boolean checkForReassessment(ArrayList attributesChanged)
    throws AppException, InformationalException {

    return true;

    /*
     * Implement code here if you wish to only reassess modifications
     * to participant evidence when specified attributes are
     * changed during the modification. Currently this method
     * returns true so any modifications to participant evidence
     * will trigger reassessment.
     * To Implement set an indicator to false and check the attributesChanged
     * list for the attributes that require reassessment. If one is found
     * set the in indicator to true
     */
  }

  // END, CR00069014

  // BEGIN, CR00201195, ZV
  // ___________________________________________________________________________
  /**
   * Ensures that only 'active' alternate IDs are read by the
   * searchActiveAlternateIDAndType method.
   *
   * @param key The concernRoleID and recordStatus to read by
   */
  @Override
  protected void presearchActiveAlternateIDAndType(
    ConcernRoleIDStatusCodeKey key)
    throws AppException, InformationalException {
    key.statusCode = RECORDSTATUS.NORMAL;

  }

  // END, CR00201195
  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    // BEGIN, CR00240667, CD
    return read(evKey).endDate;
    // END, CR00240667
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    // BEGIN, CR00240667, CD
    return read(evKey).startDate;
    // END, CR00240667
  }

  // END, CR002204022

  // BEGIN, CR00346296, PMD
  // ___________________________________________________________________________
  /**
   * When Participant Data Case is enabled an Application Exception will be thrown
   * when this method is called.  
   *
   * @param details Concern Role Alternate ID details to be inserted.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   * @throws InformationalException
   */    
  @Override
  protected void preinsert(ConcernRoleAlternateIDDtls details)
    throws AppException, InformationalException {

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.concernRoleID;
        
    if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {    
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    }       
  }

  // ___________________________________________________________________________
  /**
   * When Participant Data Case is enabled an Application Exception will be thrown
   * when this method is called.  
   *
   * @param key The concern role alternate id.
   * @param details Concern Role Alternate ID details to be modified.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   * @throws InformationalException
   */    
  @Override
  protected void premodify(ConcernRoleAlternateIDKey key,
    ConcernRoleAlternateIDDtls details) 
    throws AppException, InformationalException {

    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.concernRoleID;
        
    if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {    
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    }       
  }

  @Override
  protected void postpdcInsert(ConcernRoleAlternateIDDtls details)
    throws AppException, InformationalException {

    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = CONCERNROLEALTERNATEID.INSERT_CONCERN_ROLE_ALTERNATE_ID;
    event.primaryEventData = details.concernRoleAlternateID;
    event.secondaryEventData = details.concernRoleID;
    curam.util.events.impl.EventService.raiseEvent(event);    
  }

  @Override
  protected void postpdcModify(ConcernRoleAlternateIDKey key,
    ConcernRoleAlternateIDDtls details) 
    throws AppException, InformationalException {

    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = CONCERNROLEALTERNATEID.MODIFY_CONCERN_ROLE_ALTERNATE_ID;
    event.primaryEventData = key.concernRoleAlternateID;
    event.secondaryEventData = details.concernRoleID;
    curam.util.events.impl.EventService.raiseEvent(event);    
  }
  // END, CR00346296
}
