/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;

import curam.codetable.CASETYPECODE;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngine;
import curam.core.sl.struct.DecisionDateDetails;
import curam.core.sl.struct.IsEventDateListEnabledDetailsKey;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseTypeDetails_eo;
import curam.core.struct.ClosureDtls;
import curam.core.struct.WMInstanceDataDtls;
import curam.core.struct.WMInstanceDataKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * Delayed processing code for case closure.
 *
 */
public abstract class DelayedCaseClosure extends curam.core.base.DelayedCaseClosure {

  // BEGIN, CR00211744, VM
  @Inject
  protected AssessmentEngine assessmentEngine;

  // ___________________________________________________________________________
  /**
   * Add injection.
   */
  public DelayedCaseClosure() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00211744

  // ___________________________________________________________________________
  /**
   * Delayed process for closing cases.
   *
   * @param ticketID ticket that started process.
   * @param inst_data_id id for retrieving data needed for case closure
   * @param flag whether ticket closing is deferred
   */
  public void closeCase(long ticketID, long inst_data_id, boolean flag)
    throws AppException, InformationalException {

    // wMInstance manipulation variables
    curam.core.intf.WMInstanceData wmInstanceDataObj = curam.core.fact.WMInstanceDataFactory.newInstance();
    WMInstanceDataKey wmInstanceDataKey = new WMInstanceDataKey();
    WMInstanceDataDtls wmInstanceDataDtls;

    // closeCase manipulation variables
    curam.core.intf.CloseCase closeCaseObj = curam.core.fact.CloseCaseFactory.newInstance();
    ClosureDtls closureDtls = new ClosureDtls();

    // register the security implementation
    SecurityImplementationFactory.register();

    // assign key value
    wmInstanceDataKey.wm_instDataID = inst_data_id;

    // read data needed for case closure
    wmInstanceDataDtls = wmInstanceDataObj.read(wmInstanceDataKey);

    // copy all the relevant data
    closureDtls.assign(wmInstanceDataDtls);

    // close case
    closeCaseObj.closeCase(closureDtls);

    // If the event based date list is being used by the Assessment Engine
    // add a date to the event date list
    curam.core.sl.intf.CaseEligibilityDates caseEligibilityDatesObj = curam.core.sl.fact.CaseEligibilityDatesFactory.newInstance();

    IsEventDateListEnabledDetailsKey isEventDateListEnabledDetailsKey = new IsEventDateListEnabledDetailsKey();

    isEventDateListEnabledDetailsKey.caseID = closureDtls.caseID;

    if (caseEligibilityDatesObj.isEventDateListEnabled(isEventDateListEnabledDetailsKey).result
      && !closureDtls.closureDate.isZero()) {

      curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

      // Create and populate the case header key
      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = closureDtls.caseID;

      // Read the case type code
      CaseTypeDetails_eo caseTypeDetails = caseHeaderObj.readType(caseHeaderKey);

      // Only add a date to the date list if closing a product delivery case
      if (caseTypeDetails.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

        // BEGIN, CR00211744, VM
        // Add a date to the date list
        DecisionDateDetails dateDetails = new DecisionDateDetails();

        dateDetails.caseID = closureDtls.caseID;
        dateDetails.decisionDate = closureDtls.closureDate;

        assessmentEngine.addDecisionDate(dateDetails);
        // END, CR00211744
      }

    }

  }

}
