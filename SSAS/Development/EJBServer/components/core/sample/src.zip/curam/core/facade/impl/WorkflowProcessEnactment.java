/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import org.w3c.dom.Document;

import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.UnimplementedException;
import curam.util.workflow.impl.EnactmentService;


/**
 * Message Style document oriented web service that allows the
 * enactment of workflow processes via web services.
 */
public abstract class WorkflowProcessEnactment extends
  curam.core.facade.base.WorkflowProcessEnactment {

  // ___________________________________________________________________________
  /**
   * Starts a new process instance based on data passed from web service.
   *
   * @param xmlMessage The request message.
   *
   * @return the response message.
   */
  public Document startProcess(final Document xmlMessage)
    throws AppException, InformationalException {

    return EnactmentService.startProcess(xmlMessage);
  }

  // ___________________________________________________________________________
  /**
   * A place holder method so that the correct operations are generated into
   * the WSDL. This WSDL operation is intended to be implemented by the calling
   * BPEL process.
   *
   * @param xmlMessage The request message.
   *
   * @return the response message.
   */
  public Document processCompleted(final Document xmlMessage)
    throws AppException, InformationalException {

    throw new UnimplementedException();
  }
}
