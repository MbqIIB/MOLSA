/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright (c) 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;

import curam.core.facade.struct.AssessmentConfigDetailsList;
import curam.core.sl.fact.AssessmentConfigurationFactory;
import curam.core.sl.intf.AssessmentConfiguration;
import curam.core.struct.AssessmentNameAndTypeKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/*
 * This process class provides the interface to maintain the 
 * assessment configurations
 */
public abstract class Assessments extends curam.core.facade.base.Assessments {
  /**
   * This method is used to search the assessment configurations based on the
   * assessment configuration name or assessment configuration type.
   * @param assessmentNameAndTypeKey search key
   *
   * @return AssessmentConfigurationDetailsList 
   *                  The list of the assessment configurations.
   */
  public AssessmentConfigDetailsList searchAssessmentConfigurations(
    AssessmentNameAndTypeKey assessmentNameAndTypeKey) throws AppException,
      InformationalException {

    AssessmentConfiguration assessmentConfigurationObj 
      = AssessmentConfigurationFactory.newInstance();
    AssessmentConfigDetailsList assessmentConfigDetailsList 
      = assessmentConfigurationObj
          .searchAssessmentConfiguration(assessmentNameAndTypeKey);

    return assessmentConfigDetailsList;
  }

}
