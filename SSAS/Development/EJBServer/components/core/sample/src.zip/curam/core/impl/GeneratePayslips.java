/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import curam.codetable.PAYSLIPINSTRUCTIONSTATUS;
import curam.core.fact.ExtractPaySlipDetailsFactory;
import curam.core.fact.PayslipFactory;
import curam.core.intf.ExtractPaySlipDetails;
import curam.core.sl.infrastructure.fact.FinancialAdapterFactory;
import curam.core.struct.BatchProcessingDate;
import curam.core.struct.PSStatusCode;
import curam.core.struct.PayslipDetailsExtractLines;
import curam.core.struct.PayslipDtls;
import curam.core.struct.ProcessedPaySlipCounters;
import curam.message.BPOGENERATEPAYSLIPS;
import curam.message.EXTERNALERPVALIDATIONS;
import curam.message.GENERALFINANCE;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;


/**
 * Batch process to generate pay slips.
 *
 */
public abstract class GeneratePayslips extends curam.core.base.GeneratePayslips {

  protected static boolean stClientOpenFile = false;
  protected static boolean stNomOpenFile = false;
  protected static boolean stThirdPartyOpenFile = false;
  protected static boolean stUtilityOpenFile = false;
  protected static boolean stParticipantOpenFile = false;

  // based on domain CURAM_AMOUNT
  protected static PrintStream stClient_stream;
  protected static PrintStream stNominee_stream;
  protected static PrintStream stThirdparty_stream;
  protected static PrintStream stUtility_stream;
  protected static PrintStream stParticipant_stream;

  protected static ExtractPaySlipDetails extractPaySlipDetailsObj = ExtractPaySlipDetailsFactory.newInstance();

  protected static int commitCount;

  protected static final int kProcessCommitCount;
  protected static final boolean kCommitCountEnabled;
  // BEGIN, CR00071077, GM
  protected static String eRPAdapterEnabledErrMsg = CuramConst.gkEmpty;
  // END, CR00071077

  // BEGIN, CR00176621, MR
  /**
   * Variable for getting instance of CuramBatch object.
   */
  protected static CuramBatch curamBatchObj = new CuramBatch();
  // END, CR00176621
   
  /**
   * Static initialization which looks up the commit count status from
   * the environment and sets the static members used to control the processing
   */
  static {

    // Get the value of the Commit Count Enabled environment variable
    String commitCountEnabled = (Configuration.getProperty(
      EnvVars.ENV_GENERATEPAYSLIPS_COMMITCOUNTENABLED));

    // If it's not set, use the default
    if (commitCountEnabled == null) {

      commitCountEnabled = EnvVars.ENV_GENERATEPAYSLIPS_COMMITCOUNTENABLED_DEFAULT;

    }

    // If commit count processing is on, look up the commit count value
    // i.e. the number of records to be processed before the results are
    // committed to the database.

    if (commitCountEnabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      kCommitCountEnabled = true;

      // Get the value of the Commit Count environment variable
      String commitCount = (Configuration.getProperty(
        EnvVars.ENV_GENERATEPAYSLIPS_COMMITCOUNT));

      // If it's not set, use the default
      if (commitCount == null) {

        kProcessCommitCount = EnvVars.ENV_GENERATEPAYSLIPS_COMMITCOUNT_DEFAULT;

      } else {

        // Convert string value to integer
        kProcessCommitCount = Integer.parseInt(commitCount);

      }

    } else {

      // Otherwise commit count processing is off
      kCommitCountEnabled = false;
      kProcessCommitCount = 0;

    }

  }

  /**
   * This method increments the commit count, if enabled.
   */
  public static void incrementCommitCount() {

    if (kCommitCountEnabled) {

      commitCount++;

    }

  }

  // BEGIN, CR00176621, MR
  /**
   * This method is called to open the pay slips files.
   *
   * @param payslipFile The type of pay slip file to be opened.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public static void openFile(final String payslipFile) throws AppException,
      InformationalException {
    // END, CR00176621
    
    // open the nominee pay slip file
    if (payslipFile.equals(
      // BEGIN, CR00163236, CL
      new AppException(GENERALFINANCE.INF_NOMINEE).getMessage(
        ProgramLocale.getDefaultServerLocale()))) {

      // open NomineePayslip file for output
      curamBatchObj.outputFileID = new AppException(BPOGENERATEPAYSLIPS.INF_NOMINEE_PAYSLIP_ID).getMessage(
        ProgramLocale.getDefaultServerLocale());
      // END, CR00163236
      curamBatchObj.datFileExt = CuramConst.gkDataFileExt;
      curamBatchObj.setFileName();

      try {
        stNominee_stream = new PrintStream(
          new FileOutputStream(curamBatchObj.outputFilename));
      } catch (FileNotFoundException e) {
        throw new AppRuntimeException(e);
      }

      // check for file open failure
      if (stNominee_stream.checkError()) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOGENERATEPAYSLIPS.ERR_NOMINEE_PAYSLIP_FILE_OPEN),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

      stNomOpenFile = true;
    }

    // open the third party pay slip file
    if (payslipFile.equals(
      // BEGIN, CR00163236, CL
      new AppException(BPOGENERATEPAYSLIPS.INF_THIRD_PARTY).getMessage(
        ProgramLocale.getDefaultServerLocale()))) {

      // open ThirdParty file for output
      curamBatchObj.outputFileID = new AppException(BPOGENERATEPAYSLIPS.INF_THIRD_PARTY_PAYSLIP_ID).getMessage(
        ProgramLocale.getDefaultServerLocale());
      // END, CR00163236

      curamBatchObj.datFileExt = CuramConst.gkDataFileExt;
      curamBatchObj.setFileName();

      try {
        stThirdparty_stream = new PrintStream(
          new FileOutputStream(curamBatchObj.outputFilename));
      } catch (FileNotFoundException e) {
        throw new AppRuntimeException(e);
      }

      // check for file open failure
      if (stThirdparty_stream.checkError()) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOGENERATEPAYSLIPS.ERR_THIRDPARTY_PAYSLIP_FILE_OPEN),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

      stThirdPartyOpenFile = true;
    }

    // open the client pay slip file
    if (payslipFile.equals(
      // BEGIN, CR00163236, CL
      new AppException(BPOGENERATEPAYSLIPS.INF_CLIENT).getMessage(
        ProgramLocale.getDefaultServerLocale()))) {

      // open ClientPayslip file for output
      curamBatchObj.outputFileID = new AppException(BPOGENERATEPAYSLIPS.INF_CLIENT_PAYSLIP_ID).getMessage(
        ProgramLocale.getDefaultServerLocale());
      // END, CR00163236
      curamBatchObj.datFileExt = CuramConst.gkDataFileExt;
      curamBatchObj.setFileName();

      try {
        stClient_stream = new PrintStream(
          new FileOutputStream(curamBatchObj.outputFilename));
      } catch (FileNotFoundException e) {
        throw new AppRuntimeException(e);
      }

      // check for file open failure
      if (stClient_stream.checkError()) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOGENERATEPAYSLIPS.ERR_CLIENT_PAYSLIP_FILE_OPEN),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

      stClientOpenFile = true;
    }

    // open the utility pay slip file
    if (payslipFile.equals(
      // BEGIN, CR00163236, CL
      new AppException(BPOGENERATEPAYSLIPS.INF_UTILITY).getMessage(
        ProgramLocale.getDefaultServerLocale()))) {

      // open ClientPayslip file for output
      curamBatchObj.outputFileID = new AppException(BPOGENERATEPAYSLIPS.INF_UTILITY_PAYSLIP_ID).getMessage(
        ProgramLocale.getDefaultServerLocale());
      // END, CR00163236
      curamBatchObj.datFileExt = CuramConst.gkDataFileExt;
      curamBatchObj.setFileName();

      try {
        stUtility_stream = new PrintStream(
          new FileOutputStream(curamBatchObj.outputFilename));
      } catch (FileNotFoundException e) {
        throw new AppRuntimeException(e);
      }

      // check for file open failure
      if (stUtility_stream.checkError()) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOGENERATEPAYSLIPS.ERR_UTILITY_PAYSLIP_FILE_OPEN),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

      stUtilityOpenFile = true;
    }
    
    // open the participant pay slip file
    if (payslipFile.equals(
      // BEGIN, CR00163236, CL
      new AppException(BPOGENERATEPAYSLIPS.INF_PARTICIPANT).getMessage(
        ProgramLocale.getDefaultServerLocale()))) {

      // open ClientPayslip file for output
      curamBatchObj.outputFileID = new AppException(BPOGENERATEPAYSLIPS.INF_PARTICIPANT_PAYSLIP_ID).getMessage(
        ProgramLocale.getDefaultServerLocale());
      // END, CR00163236
      curamBatchObj.datFileExt = CuramConst.gkDataFileExt;
      curamBatchObj.setFileName();

      try {
        stParticipant_stream = new PrintStream(
          new FileOutputStream(curamBatchObj.outputFilename));
      } catch (FileNotFoundException e) {
        throw new AppRuntimeException(e);
      }

      // check for file open failure
      if (stParticipant_stream.checkError()) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOGENERATEPAYSLIPS.ERR_PARTICIPANT_PAYSLIP_FILE_OPEN),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      stParticipantOpenFile = true;
    }
  }

  /*
   * Definition of the class containing the specialized functions for the
   * ModifyGeneratedPayslips nsmulti operation
   *
   */
  static class ModifyGeneratedPayslips extends curam.util.dataaccess.ReadmultiOperation {

    /**
     * Modify Generated Pay slips read multi operation.
     *
     * @param objDtls Pay slip details
     *
     * @return A flag indicating whether the readmulti should continue
     */
    public boolean operation(Object objDtls) throws AppException,
        InformationalException {

      PayslipDtls payslipDtls = (PayslipDtls) objDtls;

      PayslipDetailsExtractLines details = extractPaySlipDetailsObj.extractDetails(
        payslipDtls);
      
      ProcessedPaySlipCounters paySlipCounters = extractPaySlipDetailsObj.getProcessedPaySlipCounters();

      if (paySlipCounters.clientCount > 0) {
        writeClientPayslip(details.clientDetails);
      }

      if (paySlipCounters.nomineeCount > 0) {
        writeNomineePayslip(details.nomineeDetails);
      }

      if (paySlipCounters.thirdPartyCount > 0) {
        writeThirdPartyPayslip(details.thirdPartyDetails);
      }

      if (paySlipCounters.utilityCount > 0) {
        writeUtilityPayslip(details.utilityDetails);
      }

      if (paySlipCounters.participantCount > 0) {
        writeParticipantPayslip(details.participantDetails);
      }
      
      if (kCommitCountEnabled && commitCount >= kProcessCommitCount) {

        return false;

      }

      return true;

    }

    /**
     * This method is used to write the client pay slip details string to the
     * client pay slip file.
     *
     * @param the client pay slip details string to be written to file
     */
    // BEGIN, CR00198672, VK
    protected void writeClientPayslip(String clientDetails)
      throws AppException, InformationalException {
      // END, CR00198672
      // BEGIN, CR00163236, CL
      if (!stClientOpenFile) {
        openFile(
          new AppException(BPOGENERATEPAYSLIPS.INF_CLIENT).getMessage(
            TransactionInfo.getProgramLocale()));
      }
      // END, CR00163236

      stClient_stream.print(clientDetails);
    }

    /**
     * This method is used to write the nominee pay slip details string to the
     * nominee pay slip file.
     *
     * @param the nominee pay slip details string to be written to file
     */
    // BEGIN, CR00198672, VK
    protected void writeNomineePayslip(String nomineeDetails)
      throws AppException, InformationalException {
      // END, CR00198672
      // BEGIN, CR00163236, CL
      if (!stNomOpenFile) {
        openFile(
          new AppException(GENERALFINANCE.INF_NOMINEE).getMessage(
            TransactionInfo.getProgramLocale()));
      }
      // END, CR00163236

      stNominee_stream.print(nomineeDetails);
    }

    /**
     * This method is used to write the third party details string to the
     * third party pay slip file.
     *
     * @param the third party pay slip details string to be written to file
     */
    // BEGIN, CR00198672, VK
    protected void writeThirdPartyPayslip(String paySlipDetails)
      throws AppException, InformationalException {
      // END, CR00198672
      // BEGIN, CR00163236, CL
      if (!stThirdPartyOpenFile) {
        openFile(
          new AppException(BPOGENERATEPAYSLIPS.INF_THIRD_PARTY).getMessage(
            TransactionInfo.getProgramLocale()));
      }
      // END, CR00163236

      stThirdparty_stream.print(paySlipDetails);
    }

    /**
     * This method is used to write the utility details string to the utility
     * pay slip file.
     *
     * @param the client utility pay slip details string to be written to file
     */
    // BEGIN, CR00198672, VK
    protected void writeUtilityPayslip(String utilityDetails)
      throws AppException, InformationalException {
      // END, CR00198672
      // BEGIN, CR00163236, CL
      if (!stUtilityOpenFile) {
        openFile(
          new AppException(BPOGENERATEPAYSLIPS.INF_UTILITY).getMessage(
            TransactionInfo.getProgramLocale()));
      }
      // END, CR00163236

      stUtility_stream.print(utilityDetails);
    }

    /**
     * This method is used to write the participant details string to the
     * participant pay slip file.
     *
     * @param the
     * client participant pay slip details string to be written to file
     */
    // BEGIN, CR00198672, VK
    protected void writeParticipantPayslip(String participantDetails)
      throws AppException, InformationalException {
      // END, CR00198672
      // BEGIN, CR00163236, CL
      if (!stParticipantOpenFile) {
        openFile(
          new AppException(BPOGENERATEPAYSLIPS.INF_PARTICIPANT).getMessage(
            TransactionInfo.getProgramLocale()));
      }
      // END, CR00163236

      stParticipant_stream.print(participantDetails);
    }
  }

  // BEGIN, CR00176621, MR
  /**
   * This method is used to call the ModifyGeneratedPayslips read multi which
   * determines the pay slips to be issued. This process takes a processing
   * date.
   *
   * @param batchProcessingDate
   * The business date for which the batch process will be run. If this
   * is set, this is the date that will be returned by
   * 'getCurrentDate'.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void generateNewPayslips(final BatchProcessingDate batchProcessingDate)
    throws AppException, InformationalException {
    // END, CR00176621
    
    // BEGIN, CR00073939, JI
    // If the ERP Adapter is enabled do not execute the batch job
    // and write an error message into the log file
    // BEGIN, CR00080249, CW
    if (FinancialAdapterFactory.newInstance().isFinancialAdapterEnabled()) {
      // END, CR00080249
      
      // Construct the error message
      curamBatchObj.setStartTime();
      // BEGIN, CR00077050, CW
      // BEGIN, CR00076996, KH
      eRPAdapterEnabledErrMsg = // BEGIN, CR00163471, JC
        EXTERNALERPVALIDATIONS.ERR_ERP_ADAPTER_ENABLED_BATCH_JOB.getMessageText(
        ProgramLocale.getDefaultServerLocale())
          // END, CR00163471, JC
          + CuramConst.gkNewLine
          + CuramConst.gkNewLine;
      // END, CR00076996
      // END, CR00077050
      curamBatchObj.setEndTime();
    
      // If the ERP Adapter is not enabled run the batch job
    } else {
      // END, CR00073939
      
      // pay slip manipulation variables
      PSStatusCode payslipStatusCode = new PSStatusCode();
  
      // register the security implementation
      SecurityImplementationFactory.register();
  
      payslipStatusCode.statusCode = PAYSLIPINSTRUCTIONSTATUS.PENDINGISSUE;
  
      // set start time for batch processing
      curamBatchObj.setStartTime();
  
      do {
  
        commitCount = 0;
  
        // create instance of read multi class
        ModifyGeneratedPayslips genpayslips = new ModifyGeneratedPayslips();
  
        // Calling read multi operation.
        // Searching for pay slips pending to be issued
  
        PayslipFactory.newInstance().searchByStatusCode(payslipStatusCode,
          genpayslips);
  
        TransactionInfo.getInfo().commit();
        TransactionInfo.getInfo().begin();
  
      } while (commitCount > 0);
  
      // set end time for batch processing
      curamBatchObj.setEndTime();
    }
    // Converting totalPayslipIssued to a string
    String strTotNomineePayslipsIssued;
    String strTotClientPayslipsIssued;
    String strTotThirdPartyPayslipsIssued;
    String strTotUtilityPayslipsIssued;
    String strTotParticipantPayslipsIssued;
   
    ProcessedPaySlipCounters paySlipCounters = extractPaySlipDetailsObj.getProcessedPaySlipCounters();
  
    strTotNomineePayslipsIssued = String.valueOf(paySlipCounters.nomineeCount);
    strTotThirdPartyPayslipsIssued = String.valueOf(
      paySlipCounters.thirdPartyCount);
    strTotClientPayslipsIssued = String.valueOf(paySlipCounters.clientCount);
    strTotUtilityPayslipsIssued = String.valueOf(paySlipCounters.utilityCount);
    strTotParticipantPayslipsIssued = String.valueOf(
      paySlipCounters.participantCount);
  
    final int kStringBufferZeroSize = 0;
    final int kMessageLength = 4096;
    StringBuffer emailMessageString = new StringBuffer(kMessageLength);
  
    // make sure the string buffer is empty
    emailMessageString.setLength(kStringBufferZeroSize);
  
    // BEGIN, CR00163236, CL
    // BEGIN, CR00073939, JI
    emailMessageString.append(eRPAdapterEnabledErrMsg).append(new AppException(BPOGENERATEPAYSLIPS.INF_NOMINEE_PAYSLIPS_PROC).getMessage(ProgramLocale.getDefaultServerLocale())).append(strTotNomineePayslipsIssued).append(CuramConst.gkNewLine).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_THIRD_PARTY_PAYSLIPS_PROC).getMessage(ProgramLocale.getDefaultServerLocale())).append(strTotThirdPartyPayslipsIssued).append(CuramConst.gkNewLine).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_CLIENT_PAYSLIPS_PROC).getMessage(ProgramLocale.getDefaultServerLocale())).append(strTotClientPayslipsIssued).append(CuramConst.gkNewLine).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_UTILITY_PAYSLIPS_PROC).getMessage(ProgramLocale.getDefaultServerLocale())).append(strTotUtilityPayslipsIssued).append(CuramConst.gkNewLine).append(CuramConst.gkNewLine).append(new AppException(BPOGENERATEPAYSLIPS.INF_PARTICIPANT_PAYSLIPS_PROC).getMessage(ProgramLocale.getDefaultServerLocale())).append(strTotParticipantPayslipsIssued).append(CuramConst.gkNewLine).append(
      CuramConst.gkNewLine);
    // END, CR00073939
    // END, CR00163236
      
    curamBatchObj.emailMessage = emailMessageString.toString();
  
    // Constructing the E-mail Subject
    curamBatchObj.setEmailSubject(BPOGENERATEPAYSLIPS.INF_GENERATE_PAYSLIPS_SUB);
  
    // BEGIN, CR00163236, CL
    // Setting output log file id
    curamBatchObj.outputFileID = new AppException(BPOGENERATEPAYSLIPS.INF_GEN_PAYSLIPS_ID).getMessage(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00163236
  
    // Sending the e-mail
    curamBatchObj.sendEmail();
  }
}
