/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.codetable.ALLOCATIONSTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CREDITDEBIT;
import curam.codetable.FINANCIALINSTRUCTION;
import curam.codetable.FININSTRUCTIONSTATUS;
import curam.codetable.ILICATEGORY;
import curam.codetable.ILIRELATIONSHIP;
import curam.codetable.ILISTATUS;
import curam.codetable.ILITYPE;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.AllocationLineFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CreateCancellationFactory;
import curam.core.fact.FinancialInstructionFactory;
import curam.core.fact.FinancialInstructionStatusFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.InstructionLineItemRelationFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.fact.MaintainFinInstructionFactory;
import curam.core.fact.MaintainInstructionLineItemFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.ProcessInstructionLineItemFactory;
import curam.core.fact.ProcessOverUnderPaymentsFactory;
import curam.core.fact.ReversalInstructionFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.AllocationLine;
import curam.core.intf.CaseHeader;
import curam.core.intf.CreateCancellation;
import curam.core.intf.FinancialInstruction;
import curam.core.intf.InstructionLineItem;
import curam.core.intf.InstructionLineItemRelation;
import curam.core.intf.MaintainCase;
import curam.core.intf.MaintainFinInstruction;
import curam.core.intf.MaintainInstructionLineItem;
import curam.core.intf.Notification;
import curam.core.intf.ProcessInstructionLineItem;
import curam.core.intf.UniqueID;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.struct.CaseIDKey;
import curam.core.struct.AllocationLineDtls;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CreditAllocationDetailList;
import curam.core.struct.DebitAllocationDetailList;
import curam.core.struct.FIstatusCode;
import curam.core.struct.FinInstructionID;
import curam.core.struct.FinInstructionIDStatus;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.FinancialInstructionKey;
import curam.core.struct.FinancialInstructionStatusDtls;
import curam.core.struct.ILIFinInstructID;
import curam.core.struct.InstructionLineItemDetails;
import curam.core.struct.InstructionLineItemDtls;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.InstructionLineItemID;
import curam.core.struct.InstructionLineItemKey;
import curam.core.struct.InstructionLineItemRelationDtls;
import curam.core.struct.PrimaryILIidTypeCode;
import curam.core.struct.RelatedILIDetailsList;
import curam.core.struct.RelatedILIidentifier;
import curam.core.struct.ReversalInstructionDetails;
import curam.core.struct.ReversalInstructionDtls;
import curam.core.struct.ReversalInstructionIDs;
import curam.core.struct.ReversalTicketSummary;
import curam.core.struct.ReverseFinInstructionSummary;
import curam.core.struct.ReverseInstructionLineItemSummary;
import curam.core.struct.StatusCodeUnprocessedAmt;
import curam.core.struct.SurchargeArrearsDates;
import curam.message.BPOCASEEVENTS;
import curam.message.BPOCREATEREVERSAL;
import curam.message.GENERALFINANCE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.Money;


/**
 * Code for creating and maintaining reversal instructions.
 */
public abstract class CreateReversal extends curam.core.base.CreateReversal {
  
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;
    
  // BEGIN CR00109704, MR
  // Add injection for using the new CaseTransactionLog API
  public CreateReversal() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END CR00109704

  // ___________________________________________________________________________
  /**
   * To create a reversal instruction and its associated financial
   * instruction and financial instruction status records.
   *
   * @param reversalDetails Reversal instruction details
   *
   * @return Created reversal instruction's identifiers
   */
  public ReversalInstructionIDs createReversalInstruction(
    ReversalInstructionDetails reversalDetails)
    throws AppException, InformationalException {
    
    UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Populate the output struct with the unique IDs
    ReversalInstructionIDs reversalInstructionIDs = new ReversalInstructionIDs();

    reversalInstructionIDs.reversalInstructionID = uniqueIDObj.getNextID();
    reversalInstructionIDs.finInstructionID = uniqueIDObj.getNextID();

    // set the financialInstruction details
    FinancialInstructionDtls financialInstructionDtls = new FinancialInstructionDtls();

    financialInstructionDtls.finInstructionID = reversalInstructionIDs.finInstructionID;
    financialInstructionDtls.typeCode = FINANCIALINSTRUCTION.REVERSAL;
    financialInstructionDtls.concernRoleID = reversalDetails.concernRoleID;
    financialInstructionDtls.statusCode = FININSTRUCTIONSTATUS.DEFAULTCODE;
    financialInstructionDtls.amount = reversalDetails.amount;
    financialInstructionDtls.effectiveDate = reversalDetails.effectiveDate;
    financialInstructionDtls.postingDate = Date.getCurrentDate();
    financialInstructionDtls.creditDebitType = reversalDetails.creditDebitType;
    financialInstructionDtls.currencyTypeCode = reversalDetails.currencyTypeCode;
    financialInstructionDtls.currencyExchangeID = reversalDetails.currencyExchangeID;
    financialInstructionDtls.instrumentGenInd = reversalDetails.instrumentGenInd;
    financialInstructionDtls.comments = reversalDetails.comments;

    FinancialInstructionFactory.newInstance().insert(financialInstructionDtls);

    // set the reversalInstruction details
    ReversalInstructionDtls reversalInstructionDtls = new ReversalInstructionDtls();

    reversalInstructionDtls.assign(reversalDetails);

    reversalInstructionDtls.revInstructionID = reversalInstructionIDs.reversalInstructionID;
    reversalInstructionDtls.finInstructionID = reversalInstructionIDs.finInstructionID;
    reversalInstructionDtls.createdDate = TransactionInfo.getSystemDate();

    ReversalInstructionFactory.newInstance().insert(reversalInstructionDtls);

    // set the financialInstructionStatus details
    FinancialInstructionStatusDtls financialInstructionStatusDtls = new FinancialInstructionStatusDtls();

    financialInstructionStatusDtls.finInstructionStatusID = uniqueIDObj.getNextID();
    financialInstructionStatusDtls.finInstructionID = reversalInstructionIDs.finInstructionID;
    financialInstructionStatusDtls.statusCode = FININSTRUCTIONSTATUS.DEFAULTCODE;
    financialInstructionStatusDtls.statusDate = TransactionInfo.getSystemDate();

    FinancialInstructionStatusFactory.newInstance().insert(
      financialInstructionStatusDtls);

    return reversalInstructionIDs;
  }

  // ___________________________________________________________________________
  /**
   * To reverse a Financial Instruction and all its component parts.
   *
   * @param revFinInstructionSummary Reversal financial instruction summary
   * details
   */
  public void reverseFinInstruction(
    ReverseFinInstructionSummary revFinInstructionSummary)
    throws AppException, InformationalException {

    // financialInstruction manipulation variable.
    FinancialInstructionDtls financialInstructionDtls;

    // Reversal instruction details and identifiers.
    ReversalInstructionDetails reversalInstructionDetails = new ReversalInstructionDetails();
    ReversalInstructionIDs reversalInstructionIDs;

    // instructionLineItem manipulation variables.
    ILIFinInstructID iliFinInstructID = new ILIFinInstructID();
    InstructionLineItemDtlsList instructionLineItemDtlsList;
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

    // Reversal financial instruction identifier.
    FinInstructionID reversalFinInstructionID = new FinInstructionID();

    // Calling validation method for reverseFinInstruction.
    financialInstructionDtls = validateReverseFinInstruction(
      revFinInstructionSummary);

    // Set reversalInstruction details.
    reversalInstructionDetails.assign(revFinInstructionSummary);

    reversalInstructionDetails.concernRoleID = financialInstructionDtls.concernRoleID;
    reversalInstructionDetails.typeCode = FINANCIALINSTRUCTION.REVERSAL;
    reversalInstructionDetails.amount = financialInstructionDtls.amount;
    reversalInstructionDetails.effectiveDate = Date.getCurrentDate();

    if (financialInstructionDtls.creditDebitType.equals(CREDITDEBIT.DEBIT)) {
      reversalInstructionDetails.creditDebitType = CREDITDEBIT.CREDIT;
    } else {
      reversalInstructionDetails.creditDebitType = CREDITDEBIT.DEBIT;
    }

    reversalInstructionDetails.currencyExchangeID = financialInstructionDtls.currencyExchangeID;
    reversalInstructionDetails.currencyTypeCode = financialInstructionDtls.currencyTypeCode;
    reversalInstructionDetails.instrumentGenInd = false;

    // Create reversalInstruction.
    reversalInstructionIDs = createReversalInstruction(
      reversalInstructionDetails);

    // Set key for reversal of the ILIs.
    reversalFinInstructionID.finInstructionID = reversalInstructionIDs.finInstructionID;

    // Set key to read instructionLineItem.
    iliFinInstructID.finInstructionID = financialInstructionDtls.finInstructionID;

    // Search instructionLineItem by finInstructionID.
    instructionLineItemDtlsList = instructionLineItemObj.searchByFinInstructID(
      iliFinInstructID);

    if (instructionLineItemDtlsList.dtls.isEmpty()) {

      AppException e = new AppException(
        GENERALFINANCE.ERR_INSTRUCTIONLINEITEM_XFV_FININSTRUCTIONID);

      ValidationManagerFactory.getManager().throwWithLookup(e,
        ValidationManagerConst.kSetOne, 0);
    }

    // Current case identifier.
    long currentCaseID = 0;

    // BEGIN, CR00198173, SS
    // Initially assigning createReversalObj to the present class and
    // this might be assigned to a subclass of CreateReversal, if it is
    // defined in the property.
    curam.core.intf.CreateReversal createReversalObj = this;

    // Read the class name from property file.
    String financialResolverName = Configuration.getProperty(
      EnvVars.ENV_FINANCIAL_HOOK_CREATEREVERSAL_CLASS);

    // BEGIN, CR00206354, SS

    // BEGIN, CR00265470, ZV
    CreateCancellation createCancellationObj = CreateCancellationFactory.newInstance();

    Object obj = FinancialUtil.getResolverClassName(financialResolverName,
      createCancellationObj.getCaseIDForFinInstructionId(
      revFinInstructionSummary.finInstructionID));

    // END, CR00265470
    if (null != obj) {
      createReversalObj = (curam.core.intf.CreateReversal) obj;
    }
    // END, CR00206354
    // END, CR00198173

    for (int i = 0; i < instructionLineItemDtlsList.dtls.size(); i++) {

      if (instructionLineItemDtlsList.dtls.item(i).statusCode.equals(
        ILISTATUS.REVERSED)) {// Skip this dtls struct and get next InstructionlineItemDtls in list
      } else {

        if (instructionLineItemDtlsList.dtls.item(i).creditDebitType.equals(
          CREDITDEBIT.DEBIT)) {

          reverseDebitILI(instructionLineItemDtlsList.dtls.item(i),
            reversalFinInstructionID);

        } else {
          createReversalObj.reverseCreditILI(
            instructionLineItemDtlsList.dtls.item(i), reversalFinInstructionID);
        }

        // currentCaseID is initialized to 0, so we will do this at least once.
        if (instructionLineItemDtlsList.dtls.item(i).caseID != currentCaseID) {

          // BEGIN, CR00328466, KH
          // Only create a ticket if a case ID is specified for the ILI
          if (0L != instructionLineItemDtlsList.dtls.item(i).caseID) {
            // END, CR00328466

            currentCaseID = instructionLineItemDtlsList.dtls.item(i).caseID;

            // Reversal ticket details.
            ReversalTicketSummary reversalTicketSummary = new ReversalTicketSummary();

            // BEGIN, CR00163098, JC
            reversalTicketSummary.instructionCategory = CodeTable.getOneItem(
              FINANCIALINSTRUCTION.TABLENAME, financialInstructionDtls.typeCode,
              TransactionInfo.getProgramLocale());
            // END, CR00163098, JC

            reversalTicketSummary.caseID = instructionLineItemDtlsList.dtls.item(i).caseID;
            reversalTicketSummary.finInstructionID = instructionLineItemDtlsList.dtls.item(i).finInstructionID;
            reversalTicketSummary.concernRoleID = instructionLineItemDtlsList.dtls.item(i).concernRoleID;

            createReversalTicket(reversalTicketSummary);
          }
        }
      }
    }

    // financialInstruction manipulation variables
    FinInstructionIDStatus finInstructionIDStatus = new FinInstructionIDStatus();
    MaintainFinInstruction maintainFinInstructionObj = MaintainFinInstructionFactory.newInstance();

    // Set financialInstruction details for update
    finInstructionIDStatus.finInstructionID = financialInstructionDtls.finInstructionID;
    finInstructionIDStatus.statusCode = FININSTRUCTIONSTATUS.REVERSED;

    // Update financialInstruction status to Reversed
    maintainFinInstructionObj.updateFinInstructionStatus(finInstructionIDStatus);

    // BEGIN, CR00109704, MR
    // BEGIN, CR00235339, PB
    // Log Transaction Details
    if (0 != currentCaseID) {

      // Case Header Manipulation variables to get Case Reference Number
      CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      CaseSearchKey caseSearchKey = new CaseSearchKey();

      caseSearchKey.caseID = currentCaseID;
      MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();
      CaseIDKey caseIDKey = new CaseIDKey();

      caseIDKey.caseID = currentCaseID;
      CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
        caseIDKey);

      LocalisableString description = new LocalisableString(BPOCASEEVENTS.PAYMENTS_REVERSED).arg(financialInstructionDtls.postingDate).arg(caseReferenceProductNameConcernRoleName.productName).arg(
        caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.PAYMENTS_REVERSAL, description, currentCaseID,
        reversalInstructionIDs.finInstructionID);
    }
    // END, CR00235339
    // END, CR00109704
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of an Instruction Line Item and any of its related
   * Instruction Line Items.
   *
   * @param revILISummary Reversal instruction line item summary details
   */
  public void reverseInstructionLineItem(ReverseInstructionLineItemSummary
    revILISummary) throws AppException, InformationalException {

    // instructionLineItem manipulation variable.
    InstructionLineItemDtls instructionLineItemDtls;

    // Calling validation method for reverseInstructionLineItem.
    instructionLineItemDtls = validateReverseInstructionLineItem(revILISummary);

    // Reversal instruction details and identifiers.
    ReversalInstructionDetails reversalInstructionDetails = new ReversalInstructionDetails();
    ReversalInstructionIDs reversalInstructionIDs;

    // Set reversal details.
    reversalInstructionDetails.assign(revILISummary);

    reversalInstructionDetails.concernRoleID = instructionLineItemDtls.concernRoleID;
    reversalInstructionDetails.typeCode = FINANCIALINSTRUCTION.REVERSAL;
    reversalInstructionDetails.amount = instructionLineItemDtls.amount;
    reversalInstructionDetails.effectiveDate = Date.getCurrentDate();

    if (instructionLineItemDtls.creditDebitType.equals(CREDITDEBIT.DEBIT)) {
      reversalInstructionDetails.creditDebitType = CREDITDEBIT.CREDIT;
    } else {
      reversalInstructionDetails.creditDebitType = CREDITDEBIT.DEBIT;
    }

    reversalInstructionDetails.currencyExchangeID = instructionLineItemDtls.currencyExchangeID;
    reversalInstructionDetails.currencyTypeCode = instructionLineItemDtls.currencyTypeCode;
    reversalInstructionDetails.instrumentGenInd = false;

    // Create reversalInstruction.
    reversalInstructionIDs = createReversalInstruction(
      reversalInstructionDetails);

    // Reversal financial instruction identifier.
    FinInstructionID reversalFinInstructionID = new FinInstructionID();

    // Set key for reversal of the ILIs.
    reversalFinInstructionID.finInstructionID = reversalInstructionIDs.finInstructionID;

    if (instructionLineItemDtls.creditDebitType.equals(CREDITDEBIT.DEBIT)) {
      reverseDebitILI(instructionLineItemDtls, reversalFinInstructionID);
    } else {

      // BEGIN, CR00198173, SS
      // Initially assigning createReversalObj to the present class and
      // this might be assigned to a subclass of CreateReversal, if it is
      // defined in the property.
      curam.core.intf.CreateReversal createReversalObj = this;

      // Read the class name from property file.
      String financialResolverName = Configuration.getProperty(
        EnvVars.ENV_FINANCIAL_HOOK_CREATEREVERSAL_CLASS);

      // BEGIN, CR00206354, SS
      // BEGIN, CR00265470, ZV
      CreateCancellation createCancellationObj = CreateCancellationFactory.newInstance();

      Object obj = FinancialUtil.getResolverClassName(financialResolverName,
        createCancellationObj.getCaseIDForFinInstructionId(
        instructionLineItemDtls.caseID));

      // END, CR00265470
      // END, CR00206354
      if (null != obj) {
        createReversalObj = (curam.core.intf.CreateReversal) obj;
      }

      createReversalObj.reverseCreditILI(instructionLineItemDtls,
        reversalFinInstructionID);
    }
    // END, CR00198173
    // Reversal ticket details
    ReversalTicketSummary reversalTicketSummary = new ReversalTicketSummary();

    // Set details to create the ticket.
    reversalTicketSummary.instructionCategory = // BEGIN, CR00163098, JC
      CodeTable.getOneItem(ILICATEGORY.TABLENAME,
      instructionLineItemDtls.instructLineItemCategory,
      TransactionInfo.getProgramLocale());
    // END, CR00163098, JC

    reversalTicketSummary.caseID = instructionLineItemDtls.caseID;
    reversalTicketSummary.finInstructionID = instructionLineItemDtls.finInstructionID;
    reversalTicketSummary.concernRoleID = instructionLineItemDtls.concernRoleID;

    // Create reversal ticket.
    createReversalTicket(reversalTicketSummary);
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a Credit Instruction Line Item and any of its
   * related Instruction Line Items.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseCreditILI(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    if (iliDtls.instructLineItemCategory.equals(
      ILICATEGORY.PAYMENTRECEIVEDINSTRUCTION)) {

      if (iliDtls.instructionLineItemType.equals(ILITYPE.UNALLOCATEPMTRECVD)) {
        reverseUnallocatedPmtRecvd(iliDtls, revFinInstrID);

      } else {
        if (iliDtls.instructionLineItemType.equals(ILITYPE.ALLOCATEDPMTRECVD)
          || iliDtls.instructionLineItemType.equals(ILITYPE.OVERALLOCATION)) {

          // BEGIN, CR00002146, KH
          reverseAllocatedPmtRecvd(iliDtls, revFinInstrID);
          // END, CR00002146

        } else {
          if (iliDtls.instructionLineItemType.equals(ILITYPE.LOANREPAYMENT)
            || iliDtls.instructionLineItemType.equals(
              ILITYPE.OVERPAYMENTREPAYMENT)) {

            // Loan/overpayment repayment instruction line item
            reverseRepmtPayment(iliDtls, revFinInstrID);
          } else {
            AppException e = new AppException(
              BPOCREATEREVERSAL.ERR_ILI_FV_ILITYPE_UNSUPPORTEDREVERSAL);

            e.arg(iliDtls.instructionLineItemType);
            ValidationManagerFactory.getManager().throwWithLookup(e,
              ValidationManagerConst.kSetOne, 1);
          }
        }
      }
    } else {

      if (iliDtls.instructLineItemCategory.equals(
        ILICATEGORY.PAYMENTINSTRUCTION)) {

        if (iliDtls.instructionLineItemType.equals(ILITYPE.TAXPAYMENT)) {
          reverseTaxDeduction(iliDtls, revFinInstrID);
        } else {
          if (iliDtls.instructionLineItemType.equals(ILITYPE.UTILITYDEDUCTION)) {
            reverseUtilityDeduction(iliDtls, revFinInstrID);
          } else {

            if (iliDtls.instructionLineItemType.equals(
              ILITYPE.REPAYMENTDEDUCTION)
                || iliDtls.instructionLineItemType.equals(
                  ILITYPE.OVERPAYMENTREPAYMENT)) {

              reverseRepmtDeduction(iliDtls, revFinInstrID);
            } else {

              if (iliDtls.instructionLineItemType.equals(ILITYPE.DEDUCTIONITEM)) {
                reverseDeductionItem(iliDtls, revFinInstrID);
              } else {
                AppException e = new AppException(
                  BPOCREATEREVERSAL.ERR_ILI_FV_ILITYPE_UNSUPPORTEDREVERSAL);

                e.arg(iliDtls.instructionLineItemType);
                ValidationManagerFactory.getManager().throwWithLookup(e,
                  ValidationManagerConst.kSetOne, 0);
              }
            }
          }
        }
      } else {

        if (iliDtls.instructLineItemCategory.equals(
          ILICATEGORY.WRITEOFFINSTRUCTION)) {
          reverseWriteOff(iliDtls, revFinInstrID);
        } else {
          AppException e = new AppException(
            BPOCREATEREVERSAL.ERR_ILI_FV_ILICATEGORY_UNSUPPORTEDREVERSAL);

          e.arg(iliDtls.instructLineItemCategory);
          ValidationManagerFactory.getManager().throwWithLookup(e,
            ValidationManagerConst.kSetOne, 1);
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a Debit Instruction Line Item and any of its
   * related Instruction Line Items.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseDebitILI(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    if (iliDtls.instructLineItemCategory.equals(ILICATEGORY.PAYMENTINSTRUCTION)) {

      if (iliDtls.instructionLineItemType.equals(ILITYPE.TAXPAYMENT)) {
        reverseTaxPayment(iliDtls, revFinInstrID);
      } else {
        if (iliDtls.instructionLineItemType.equals(ILITYPE.UTILITYPAYMENT)) {
          reverseUtilityPayment(iliDtls, revFinInstrID);
        } else {
          reverseClaimPayment(iliDtls, revFinInstrID);
        }
      }

    } else {

      if (iliDtls.instructLineItemCategory.equals(
        ILICATEGORY.LIABILITYINSTRUCTION)) {

        if (iliDtls.instructionLineItemType.equals(ILITYPE.REPAYMENTDUE)) {
          reverseRepaymentDue(iliDtls, revFinInstrID);
        } else {
          reverseLiability(iliDtls, revFinInstrID);
        }

      } else {

        // BEGIN, CR00002146, KH
        if (iliDtls.instructLineItemCategory.equals(
          ILICATEGORY.PAYMENTINSTRUCTIONFORDEDUCTION)) {

          // Payments to a third party will contain Deduction Payments
          if (iliDtls.instructionLineItemType.equals(ILITYPE.DEDUCTIONPAYMENT)) {
            reverseDeductionPayment(iliDtls, revFinInstrID);
          }

        } else {

          AppException e = new AppException(
            BPOCREATEREVERSAL.ERR_ILI_FV_ILICATEGORY_UNSUPPORTEDREVERSAL);

          e.arg(iliDtls.instructLineItemCategory);
          ValidationManagerFactory.getManager().throwWithLookup(e,
            ValidationManagerConst.kSetOne, 0);
        }
        // END, CR00002146
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of an unallocated payment received Instruction Line
   * Item.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseUnallocatedPmtRecvd(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    // Set the status of the unallocated Payment Received to indicate it is
    // being reversed and reduce the unallocated amount, as the reversal will
    // be allocated to it

    // zero money amount
    Money zeroAmount = Money.kZeroMoney;

    // instructionLineItem manipulation variables
    StatusCodeUnprocessedAmt iliStatusUnprocAmt = new StatusCodeUnprocessedAmt();
    InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

    // set ILI modification details
    iliStatusUnprocAmt.unprocessedAmount = zeroAmount;
    iliStatusUnprocAmt.statusCode = ILISTATUS.REVERSED;
    iliStatusUnprocAmt.versionNo = iliDtls.versionNo;

    // set ILI key for modification
    instructionLineItemKey.instructLineItemID = iliDtls.instructLineItemID;

    // update the instructionLineItem status to Reversed
    instructionLineItemObj.modifyStatusUnprocessedAmt(instructionLineItemKey,
      iliStatusUnprocAmt);

    if (iliDtls.unprocessedAmount.isPositive()) {

      // Create the reversal ILI that will reverse the unallocated payment
      // received ILI
      // Reversal instruction line item details and identifier
      InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
      InstructionLineItemID reversedILIid;

      // maintainInstructionLineItem manipulation variable
      MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

      // set details for reversal
      reversedILIDetails.assign(iliDtls);

      // the assignment from InstructionLineItemDtls to
      // InstructionLineItemDetails maps amount to amount, we need to
      // overwrite this mapping as follows....
      reversedILIDetails.amount = iliDtls.unprocessedAmount;
      reversedILIDetails.unprocessedAmount = zeroAmount;
      reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reversedILIDetails.instructionLineItemType = ILITYPE.UNALLOCATEDREVERSAL;
      reversedILIDetails.financialCompID = 0;
      reversedILIDetails.coverPeriodFrom = Date.getCurrentDate();
      reversedILIDetails.coverPeriodTo = Date.getCurrentDate();
      reversedILIDetails.effectiveDate = Date.getCurrentDate();
      reversedILIDetails.statusCode = ILISTATUS.ALLOCATED;
      reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
      reversedILIDetails.creditDebitType = CREDITDEBIT.DEBIT;
      reversedILIDetails.adjustmentInd = false;
      // BEGIN, CR00049218, GM
      reversedILIDetails.adjustmentFrequency = CuramConst.gkEmpty;
      // END, CR00049218

      reversedILIDetails.nextAdjustmentDate = Date.kZeroDate;
      reversedILIDetails.instrumentGenInd = false;

      reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedILIDetails);

      // Allocate the reversal ILI (DBT) to the unallocated payment received
      // ILI (CDT) - for consistency with all other allocate Credit to Debits

      // allocationLine manipulation variables
      AllocationLineDtls allocationLineDtls = new AllocationLineDtls();
      AllocationLine allocationLineObj = AllocationLineFactory.newInstance();

      // set allocationLine details
      allocationLineDtls.allocationLineID = UniqueIDFactory.newInstance().getNextID();
      allocationLineDtls.instructLineItemID = iliDtls.instructLineItemID;
      allocationLineDtls.relatedLineItemID = reversedILIid.instructionLineItemID;
      allocationLineDtls.allocationDate = Date.getCurrentDate();
      allocationLineDtls.amount = iliDtls.unprocessedAmount;
      allocationLineDtls.statusCode = ALLOCATIONSTATUS.DEFAULTCODE;

      // insert allocationLine
      allocationLineObj.insert(allocationLineDtls);

      // Relate the reversal ILI to the item being reversed (for consistency
      // with all other reversal relationships)

      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
      // END, CR00077580
    }
  }

  // BEGIN, CR00002146, KH
  // ___________________________________________________________________________
  /**
   * To reverse the effect of an allocated payment received Instruction Line
   * Item.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseAllocatedPmtRecvd(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID)
    throws AppException, InformationalException {

    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
    UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Set key to read for related allocation 
    InstructionLineItemKey allocatedILIKey = new InstructionLineItemKey();

    allocatedILIKey.instructLineItemID = iliDtls.instructLineItemID;

    DebitAllocationDetailList debitAllocationDetailList = instructionLineItemObj.searchCreditAllocations(
      allocatedILIKey);

    // END, CR00002146

    for (int i = 0; i < debitAllocationDetailList.dtls.size(); i++) {

      // Read the debit ILI to which this Payment Received was allocated
      MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

      // Read instructionLineItem entity
      InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();

      relatedILIKey.instructLineItemID = debitAllocationDetailList.dtls.item(i).debitInstructionLineItemID;

      InstructionLineItemDtls relatedILIDtls = instructionLineItemObj.read(
        relatedILIKey);

      // Reverse the related allocation
      
      // BEGIN, CR00327227, KH
      // If the related ILI has no case ID then it is a refund 
      if (0L == relatedILIDtls.caseID) {
        ProcessOverUnderPaymentsFactory.newInstance().createLiabilityForReversedRefund(
          relatedILIDtls);
        
      } 
      
      // BEGIN, CR00330723, CSH
      // Reversal instruction line item details an identifier
      InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();

      reversedILIDetails.assign(relatedILIDtls);
      reversedILIDetails.amount = debitAllocationDetailList.dtls.item(i).allocationAmount;

      // If the iliType is over allocation then it cannot be allocated to or if
      // the related id is not associated with a case it must have resulted from  
      // a refund therefore cannot be allocated to. Set the unprocessed amount 
      // to zero for either of these scenarios.
      if (iliDtls.instructionLineItemType.equals(ILITYPE.OVERALLOCATION)
        || (0L == relatedILIDtls.caseID)) {
        reversedILIDetails.unprocessedAmount = Money.kZeroMoney;
      } else {
        reversedILIDetails.unprocessedAmount = debitAllocationDetailList.dtls.item(i).allocationAmount;
      }

      reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
      reversedILIDetails.financialCompID = 0;
      reversedILIDetails.effectiveDate = debitAllocationDetailList.dtls.item(i).allocationDate;
      reversedILIDetails.statusCode = ILISTATUS.PROCESSED;
      reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
      reversedILIDetails.creditDebitType = CREDITDEBIT.DEBIT;
      reversedILIDetails.instrumentGenInd = false;
      
      InstructionLineItemID reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedILIDetails);

      // Relate this new reversal ILI to the allocated Payment Received ILI
      // being reversed
      InstructionLineItemRelation instructionLineItemRelationObj = InstructionLineItemRelationFactory.newInstance();

      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
      // END, CR00077580
      
      // Relate the new reversal to the liability to which the
      // payment received was allocated
      InstructionLineItemRelationDtls instructionLineItemRelationDtls = new InstructionLineItemRelationDtls();

      instructionLineItemRelationDtls.instructLineItemRelatID = uniqueIDObj.getNextID();
      instructionLineItemRelationDtls.instructLineItemID = debitAllocationDetailList.dtls.item(i).debitInstructionLineItemID;
      instructionLineItemRelationDtls.relatedLineItemID = reversedILIid.instructionLineItemID;
      instructionLineItemRelationDtls.creationDate = TransactionInfo.getSystemDate();
      instructionLineItemRelationDtls.typeCode = ILIRELATIONSHIP.ALLOCATIONREVERSAL;

      instructionLineItemRelationObj.insert(instructionLineItemRelationDtls);

      if (debitAllocationDetailList.dtls.item(i).debitAdjustmentInd) {

        // Surcharges can be applied to this debit
        SurchargeArrearsDates surchargeArreasDates = new SurchargeArrearsDates();

        surchargeArreasDates.arrearsDateFrom = debitAllocationDetailList.dtls.item(i).allocationDate;
        surchargeArreasDates.arrearsDateTo = Date.getCurrentDate();

        // Determine if surcharges should have been applied during the time
        // that this allocation was in place
        InstructionLineItemID surchargeArrearsILIid = ProcessInstructionLineItemFactory.newInstance().calculateSurchargeArrears(
          relatedILIDtls, surchargeArreasDates);

        if (surchargeArrearsILIid.instructionLineItemID != 0) {

          // Surcharges were calculated
          InstructionLineItemRelationDtls iliRelationDtls = new InstructionLineItemRelationDtls();

          iliRelationDtls.instructLineItemRelatID = uniqueIDObj.getNextID();
          iliRelationDtls.instructLineItemID = debitAllocationDetailList.dtls.item(i).debitInstructionLineItemID;
          iliRelationDtls.relatedLineItemID = surchargeArrearsILIid.instructionLineItemID;
          iliRelationDtls.creationDate = TransactionInfo.getSystemDate();
          iliRelationDtls.typeCode = ILIRELATIONSHIP.SURCHARGES;

          instructionLineItemRelationObj.insert(iliRelationDtls);
        }
      }
      // END, CR00330723
      // END, CR00327227
    } // end for i

    // Modify the allocated Payment Received ILI being reversed so that the
    // status indicates that it is now reversed
    MaintainInstructionLineItemFactory.newInstance().setReversedILIStatus(
      iliDtls);
    // END, CR00077580

    // BEGIN, CR00107909, GSP
    // Update the Payment Received Instruction to Cancelled
    FinancialInstruction financialInstructionObj = FinancialInstructionFactory.newInstance();
    
    FinancialInstructionKey financialInstructionKey = new FinancialInstructionKey();

    financialInstructionKey.finInstructionID = iliDtls.finInstructionID;

    FinancialInstructionDtls financialInstructionDtls = financialInstructionObj.read(
      financialInstructionKey);

    FIstatusCode fiStatusCode = new FIstatusCode();

    fiStatusCode.statusCode = FININSTRUCTIONSTATUS.CANCELLED;
    fiStatusCode.versionNo = financialInstructionDtls.versionNo;
    financialInstructionObj.modifyStatus(financialInstructionKey, fiStatusCode);

    FinancialInstructionStatusDtls financialInstructionStatusDtls = new FinancialInstructionStatusDtls();

    financialInstructionStatusDtls.finInstructionStatusID = uniqueIDObj.getNextID();
    financialInstructionStatusDtls.finInstructionID = iliDtls.finInstructionID;
    financialInstructionStatusDtls.statusCode = FININSTRUCTIONSTATUS.CANCELLED;
    financialInstructionStatusDtls.statusDate = TransactionInfo.getSystemDate();

    FinancialInstructionStatusFactory.newInstance().insert(
      financialInstructionStatusDtls);
    // END, CR00107909
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a Tax payment Instruction Line Item and any of
   * its related Instruction Line Items.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseTaxPayment(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    // BEGIN, CR00077580, CW
    // Set the status of the tax payment ILI to indicate it is reversed

    // maintainInstructionLineItem manipulation variable
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    // update the status on the ILI to REVERSED
    maintainInstructionLineItemObj.setReversedILIStatus(iliDtls);
    // END, CR00077580

    // Create the reversal ILI for this tax payment ILI being reversed

    // Reversal instruction line item details an identifier
    InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
    InstructionLineItemID reversedILIid;

    // set the reversal details
    reversedILIDetails.assign(iliDtls);

    reversedILIDetails.unprocessedAmount = iliDtls.amount;
    reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
    reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
    reversedILIDetails.financialCompID = 0;
    reversedILIDetails.effectiveDate = Date.getCurrentDate();
    reversedILIDetails.statusCode = ILISTATUS.PROCESSED;
    reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
    reversedILIDetails.creditDebitType = CREDITDEBIT.CREDIT;
    reversedILIDetails.instrumentGenInd = false;

    reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
      reversedILIDetails);

    // Relate this new reversal ILI to the tax payment ILI being reversed
    // BEGIN, CR00077580, CW
    maintainInstructionLineItemObj.createReversalILIRelationship(
      iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
    // END, CR00077580

    reverseCorrespondingTaxDeduction(iliDtls);
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a Tax deduction Instruction Line Item and any of
   * its related Instruction Line Items.
   *
   * @param iliDtls Reversal financial instruction identifier
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseTaxDeduction(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    // BEGIN, CR00077580, CW
    // maintainInstructionLineItem manipulation variable
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    // update the status on the ILI to REVERSED
    maintainInstructionLineItemObj.setReversedILIStatus(iliDtls);
    // END, CR00077580

    // Create the reversal ILI for this deduction ILI being reversed

    // Reversal instruction line item details an identifier
    InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
    InstructionLineItemID reversedILIid;

    // set reversal details
    reversedILIDetails.assign(iliDtls);

    reversedILIDetails.unprocessedAmount = iliDtls.amount;
    reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
    reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
    reversedILIDetails.financialCompID = 0;
    reversedILIDetails.effectiveDate = Date.getCurrentDate();
    reversedILIDetails.statusCode = ILISTATUS.PROCESSED;
    reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
    reversedILIDetails.creditDebitType = CREDITDEBIT.DEBIT;
    reversedILIDetails.instrumentGenInd = false;

    reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
      reversedILIDetails);

    // Relate this new reversal ILI to the tax deduction ILI being reversed
    // BEGIN, CR00077580, CW
    maintainInstructionLineItemObj.createReversalILIRelationship(
      iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
    // END, CR00077580

    reverseCorrespondingTaxPayment(iliDtls);
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a Utility payment Instruction Line Item and any
   * of its related Instruction Line Items.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseUtilityPayment(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    // Set the status of the utility payment ILI to indicate it is reversed

    // BEGIN, CR00077580, CW
    // maintainInstructionLineItem manipulation variable
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    // update the status on the ILI to REVERSED
    maintainInstructionLineItemObj.setReversedILIStatus(iliDtls);
    // END, CR00077580

    // Create the reversal ILI for this utility payment ILI being reversed

    // Reversal instruction line item details an identifier
    InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
    InstructionLineItemID reversedILIid;

    // set the reversal details
    reversedILIDetails.assign(iliDtls);

    reversedILIDetails.unprocessedAmount = iliDtls.amount;
    reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
    reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
    reversedILIDetails.financialCompID = 0;
    reversedILIDetails.effectiveDate = Date.getCurrentDate();
    reversedILIDetails.statusCode = ILISTATUS.PROCESSED;
    reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
    reversedILIDetails.creditDebitType = CREDITDEBIT.CREDIT;
    reversedILIDetails.instrumentGenInd = false;

    reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
      reversedILIDetails);

    // Relate this new ILI to the utility payment ILI being reversed

    // BEGIN, CR00077580, CW
    maintainInstructionLineItemObj.createReversalILIRelationship(
      iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
    // END, CR00077580

    reverseCorrespondingUtilityDeduction(iliDtls);
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a Utility deduction Instruction Line Item and any
   * of its related Instruction Line Items.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseUtilityDeduction(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    // Set the status of the utility deduction ILI to indicate it is reversed

    // BEGIN, CR00077580, CW
    // maintainInstructionLineItem manipulation variable
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    // update the status on the ILI to REVERSED
    maintainInstructionLineItemObj.setReversedILIStatus(iliDtls);
    // END, CR00077580

    // Create the reversal ILI for this utility deduction ILI being reversed

    // Reversal instruction line item details an identifier
    InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
    InstructionLineItemID reversedILIid;

    // set reversal details
    reversedILIDetails.assign(iliDtls);
    // BEGIN, CR00021325, SP
    // Unprocessed amount should be zero
    reversedILIDetails.unprocessedAmount = Money.kZeroMoney;
    // END, CR00021325
    reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
    reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
    reversedILIDetails.financialCompID = 0;
    reversedILIDetails.effectiveDate = Date.getCurrentDate();
    reversedILIDetails.statusCode = ILISTATUS.PROCESSED;
    reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
    reversedILIDetails.creditDebitType = CREDITDEBIT.DEBIT;
    reversedILIDetails.instrumentGenInd = false;

    reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
      reversedILIDetails);

    // Relate this new ILI to the utility deduction ILI being reversed

    // BEGIN, CR00077580, CW
    maintainInstructionLineItemObj.createReversalILIRelationship(
      iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
    // END, CR00077580

    reverseCorrespondingUtilityPayment(iliDtls);
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of loan repayment deduction Instruction
   * Line Item and any of its related Instruction Line Items.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseRepmtDeduction(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    // Set the status of the loan/overpayment deduction ILI to indicate it is
    // reversed
    // BEGIN, CR00077580, CW
    // maintainInstructionLineItem manipulation variable
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    // update the status on the ILI to REVERSED
    maintainInstructionLineItemObj.setReversedILIStatus(iliDtls);

    // instructionLineItem manipulation variable
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
    // END, CR00077580

    // Create the reversal ILI for this deduction ILI being reversed

    // Reversal instruction line item details an identifier
    InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
    InstructionLineItemID reversedILIid;

    // set reversal details
    reversedILIDetails.assign(iliDtls);

    reversedILIDetails.unprocessedAmount = iliDtls.amount;
    reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
    reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
    reversedILIDetails.financialCompID = 0;
    reversedILIDetails.effectiveDate = Date.getCurrentDate();
    reversedILIDetails.statusCode = ILISTATUS.PROCESSED;
    reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
    reversedILIDetails.creditDebitType = CREDITDEBIT.DEBIT;
    reversedILIDetails.instrumentGenInd = false;

    reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
      reversedILIDetails);

    // Relate this new ILI to the deduction ILI being reversed

    // instructionLineItemRelation manipulation variable
    InstructionLineItemRelation instructionLineItemRelationObj = InstructionLineItemRelationFactory.newInstance();

    // BEGIN, CR00077580, CW
    maintainInstructionLineItemObj.createReversalILIRelationship(
      iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
    // END, CR00077580

    // Find and reverse the corresponding loan repayment ILI
    RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();
    RelatedILIDetailsList relatedILIDetailsList;

    // set key to read instructionLineItem entity
    relatedILIidentifier.instructLineItemID = iliDtls.instructLineItemID;
    relatedILIidentifier.type = ILIRELATIONSHIP.DEBTOVERPAYMENTPAYMENT;

    // search instructionLineItem entity
    relatedILIDetailsList = instructionLineItemObj.searchRelatedILIByInstrLineItemIDType(
      relatedILIidentifier);

    for (int i = 0; i < relatedILIDetailsList.dtls.size(); i++) {

      // Related instruction line item key and details
      InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();
      InstructionLineItemDtls relatedILIDtls;

      // set key to read instructionLineItem entity
      relatedILIKey.instructLineItemID = relatedILIDetailsList.dtls.item(i).instructLineItemID;

      // read instructionLineItem entity
      relatedILIDtls = instructionLineItemObj.read(relatedILIKey);

      // Set the status of this loan repayment ILI to indicate it is reversed
      // BEGIN, CR00077580, CW
      // update the status on the ILI to REVERSED
      maintainInstructionLineItemObj.setReversedILIStatus(relatedILIDtls);
      // END, CR00077580

      // Reverse this loan payment ILI

      // Reversal related instruction line item details an identifier
      InstructionLineItemDetails reversedRelatedILIDetails = new InstructionLineItemDetails();
      InstructionLineItemID reversedRelatedILIid;

      // set reversal details
      reversedRelatedILIDetails.assign(relatedILIDtls);

      reversedRelatedILIDetails.amount = relatedILIDetailsList.dtls.item(i).amount;
      reversedRelatedILIDetails.unprocessedAmount = relatedILIDetailsList.dtls.item(i).amount;
      reversedRelatedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reversedRelatedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
      reversedRelatedILIDetails.financialCompID = 0;
      reversedRelatedILIDetails.effectiveDate = Date.getCurrentDate();
      reversedRelatedILIDetails.statusCode = ILISTATUS.UNPROCESSED;
      reversedRelatedILIDetails.finInstructionID = 0;
      reversedRelatedILIDetails.creditDebitType = CREDITDEBIT.DEBIT;

      reversedRelatedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedRelatedILIDetails);

      // Relate this reversal ILI to the loan deduction ILI it is reversing
      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        relatedILIDtls.instructLineItemID,
        reversedRelatedILIid.instructionLineItemID);
      // END, CR00077580

      // Get the debit ILI to which the repayment was allocated

      // Allocated instruction line item key
      InstructionLineItemKey allocatedILIKey = new InstructionLineItemKey();

      // Debit allocation detail list
      DebitAllocationDetailList debitAllocationDetailList;

      // set key to read instructionLineItem entity
      allocatedILIKey.instructLineItemID = relatedILIDtls.instructLineItemID;

      // read instructionLineItem entity
      debitAllocationDetailList = instructionLineItemObj.searchCreditAllocations(
        allocatedILIKey);

      for (int j = 0; j < debitAllocationDetailList.dtls.size(); j++) {

        if (debitAllocationDetailList.dtls.item(j).debitAdjustmentInd) {

          // i.e. surcharge can be applied
          // the debit to which the repayment was allocated

          // Debit instruction line item key and details
          InstructionLineItemKey debitILIKey = new InstructionLineItemKey();
          InstructionLineItemDtls debitILIDtls;

          // processInstructionLineItem manipulation variable
          ProcessInstructionLineItem processInstructionLineItemObj = ProcessInstructionLineItemFactory.newInstance();

          // set key to read instructionLineItem entity
          debitILIKey.instructLineItemID = debitAllocationDetailList.dtls.item(j).debitInstructionLineItemID;

          // read instructionLineItem entity
          debitILIDtls = instructionLineItemObj.read(debitILIKey);

          // Surcharge arrears dates
          SurchargeArrearsDates surchargeArreasDates = new SurchargeArrearsDates();

          // Surcharge arrears instruction line item identifier
          InstructionLineItemID surchargeArrearsILIid;

          surchargeArreasDates.arrearsDateFrom = debitAllocationDetailList.dtls.item(j).allocationDate;
          surchargeArreasDates.arrearsDateTo = Date.getCurrentDate();

          // calculate surcharge arrears
          surchargeArrearsILIid = processInstructionLineItemObj.calculateSurchargeArrears(
            debitILIDtls, surchargeArreasDates);

          if (surchargeArrearsILIid.instructionLineItemID != 0) {

            // i.e. surcharges were calculated

            // Instruction line item relation details
            InstructionLineItemRelationDtls iliRelationDtls = new InstructionLineItemRelationDtls();

            // set details for insert
            iliRelationDtls.instructLineItemRelatID = UniqueIDFactory.newInstance().getNextID();
            iliRelationDtls.instructLineItemID = debitAllocationDetailList.dtls.item(j).debitInstructionLineItemID;
            iliRelationDtls.relatedLineItemID = surchargeArrearsILIid.instructionLineItemID;
            iliRelationDtls.creationDate = TransactionInfo.getSystemDate();
            iliRelationDtls.typeCode = ILIRELATIONSHIP.SURCHARGES;

            instructionLineItemRelationObj.insert(iliRelationDtls);
          }
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of loan repayment deduction Instruction Line Item
   * and any of its related Instruction Line Items.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseRepmtPayment(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    // instructionLineItem manipulation variables
    StatusCodeUnprocessedAmt iliStatusUnprocAmt = new StatusCodeUnprocessedAmt();
    InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

    // set ILI details for update
    iliStatusUnprocAmt.unprocessedAmount = Money.kZeroMoney;
    iliStatusUnprocAmt.statusCode = ILISTATUS.REVERSED;
    iliStatusUnprocAmt.versionNo = iliDtls.versionNo;

    // set ILI key for update
    instructionLineItemKey.instructLineItemID = iliDtls.instructLineItemID;

    // update instructionLineItem status to Reversed
    instructionLineItemObj.modifyStatusUnprocessedAmt(instructionLineItemKey,
      iliStatusUnprocAmt);

    // Create the reversal ILI that reversed this repayment ILI

    // Reversal instruction line item details and identifier
    InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
    InstructionLineItemID reversedILIid;

    // maintainInstructionLineItem manipulation variable
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    // set reversal details
    reversedILIDetails.assign(iliDtls);

    reversedILIDetails.unprocessedAmount = iliDtls.amount;
    reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
    reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
    reversedILIDetails.financialCompID = 0;
    reversedILIDetails.coverPeriodFrom = Date.getCurrentDate();
    reversedILIDetails.coverPeriodTo = Date.getCurrentDate();
    reversedILIDetails.effectiveDate = Date.getCurrentDate();
    reversedILIDetails.statusCode = ILISTATUS.PROCESSED;
    reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
    reversedILIDetails.creditDebitType = CREDITDEBIT.DEBIT;
    reversedILIDetails.instrumentGenInd = false;

    reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
      reversedILIDetails);

    // Relate this reversal ILI to the repayment ILI that is reversing

    // instructionLineItem manipulation variable
    InstructionLineItemRelation instructionLineItemRelationObj = InstructionLineItemRelationFactory.newInstance();

    // BEGIN, CR00077580, CW
    maintainInstructionLineItemObj.createReversalILIRelationship(
      iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
    // END, CR00077580

    // Get the debit ILI to which the repayment was allocated

    // Allocated instruction line item key
    InstructionLineItemKey allocatedILIKey = new InstructionLineItemKey();

    // Debit allocation detail list
    DebitAllocationDetailList debitAllocationDetailList;

    // set key to read instructionLineItem entity
    allocatedILIKey.instructLineItemID = iliDtls.instructLineItemID;

    // search instructionLineItem entity
    debitAllocationDetailList = instructionLineItemObj.searchCreditAllocations(
      allocatedILIKey);

    for (int i = 0; i < debitAllocationDetailList.dtls.size(); i++) {

      InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();
      InstructionLineItemDtls relatedILIDtls;

      // set key to read instructionLineItem entity
      relatedILIKey.instructLineItemID = debitAllocationDetailList.dtls.item(i).debitInstructionLineItemID;

      // read instructionLineItem entity
      relatedILIDtls = instructionLineItemObj.read(relatedILIKey);

      // Reverse the allocation
      InstructionLineItemDetails reverseILIDetails = new InstructionLineItemDetails();

      // set reversal details
      reverseILIDetails.assign(relatedILIDtls);

      reverseILIDetails.amount = debitAllocationDetailList.dtls.item(i).allocationAmount;
      reverseILIDetails.unprocessedAmount = debitAllocationDetailList.dtls.item(i).allocationAmount;
      reverseILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reverseILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
      reverseILIDetails.financialCompID = 0;
      reverseILIDetails.effectiveDate = debitAllocationDetailList.dtls.item(i).allocationDate;
      reverseILIDetails.statusCode = ILISTATUS.PROCESSED;
      reverseILIDetails.finInstructionID = revFinInstrID.finInstructionID;
      reverseILIDetails.creditDebitType = CREDITDEBIT.DEBIT;
      reverseILIDetails.instrumentGenInd = false;

      reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reverseILIDetails);

      // Relate this new reversal ILI to the Repayment ILI being reversed

      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
      // END, CR00077580

      if (debitAllocationDetailList.dtls.item(i).debitAdjustmentInd) {

        // Related instruction line item key and details
        InstructionLineItemKey debitILIKey = new InstructionLineItemKey();
        InstructionLineItemDtls debitILIDtls;

        // set key to read instructionLineItem entity
        debitILIKey.instructLineItemID = debitAllocationDetailList.dtls.item(i).debitInstructionLineItemID;

        // read instructionLineItem entity
        debitILIDtls = instructionLineItemObj.read(debitILIKey);

        // processInstructionLineItem manipulation variables
        SurchargeArrearsDates surchargeArreasDates = new SurchargeArrearsDates();
        ProcessInstructionLineItem processInstructionLineItemObj = ProcessInstructionLineItemFactory.newInstance();

        // Surcharge arrears instruction line item identifier
        InstructionLineItemID surchargeArrearsILIid;

        surchargeArreasDates.arrearsDateFrom = debitAllocationDetailList.dtls.item(i).allocationDate;
        surchargeArreasDates.arrearsDateTo = Date.getCurrentDate();

        // calculate surcharge arrears
        surchargeArrearsILIid = processInstructionLineItemObj.calculateSurchargeArrears(
          debitILIDtls, surchargeArreasDates);

        if (surchargeArrearsILIid.instructionLineItemID != 0) {

          // i.e. surcharges were calculated

          // instructionLineItemRelation manipulation variable
          InstructionLineItemRelationDtls iliRelationDtls = new InstructionLineItemRelationDtls();

          // set instructionLineItemRelation details
          iliRelationDtls.instructLineItemRelatID = UniqueIDFactory.newInstance().getNextID();
          iliRelationDtls.instructLineItemID = debitAllocationDetailList.dtls.item(i).debitInstructionLineItemID;
          iliRelationDtls.relatedLineItemID = surchargeArrearsILIid.instructionLineItemID;
          iliRelationDtls.creationDate = TransactionInfo.getSystemDate();
          iliRelationDtls.typeCode = ILIRELATIONSHIP.SURCHARGES;

          instructionLineItemRelationObj.insert(iliRelationDtls);
        }
      }
    }

    // Find and reverse the corresponding loan deduction ILI
    RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();
    RelatedILIDetailsList relatedILIDetailsList;

    // set key to read instructionLineItem entity
    relatedILIidentifier.instructLineItemID = iliDtls.instructLineItemID;
    relatedILIidentifier.type = ILIRELATIONSHIP.DEBTOVERPAYMENTPAYMENT;

    // search instructionLineItem entity
    relatedILIDetailsList = instructionLineItemObj.searchRelatedILIByRelatedLineItemIDType(
      relatedILIidentifier);

    for (int j = 0; j < relatedILIDetailsList.dtls.size(); j++) {

      // Related instruction line item key and details
      InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();
      InstructionLineItemDtls relatedILIDtls;

      // set key to read instructionLineItem
      relatedILIKey.instructLineItemID = relatedILIDetailsList.dtls.item(j).instructLineItemID;

      // read instructionLineItem entity
      relatedILIDtls = instructionLineItemObj.read(relatedILIKey);

      // Set the status of this loan deduction ILI to indicate it is reversed

      // BEGIN, CR00077580, CW
      // update the status on the ILI to REVERSED
      maintainInstructionLineItemObj.setReversedILIStatus(relatedILIDtls);
      // END, CR00077580

      // Reversal related instruction line item details an identifier
      InstructionLineItemDetails reversedRelatedILIDetails = new InstructionLineItemDetails();
      InstructionLineItemID reversedRelatedILIid;

      // set reversal details
      reversedRelatedILIDetails.assign(relatedILIDtls);

      reversedRelatedILIDetails.amount = relatedILIDetailsList.dtls.item(j).amount;
      reversedRelatedILIDetails.unprocessedAmount = relatedILIDetailsList.dtls.item(j).amount;
      reversedRelatedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reversedRelatedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
      reversedRelatedILIDetails.financialCompID = 0;
      reversedRelatedILIDetails.effectiveDate = Date.getCurrentDate();
      reversedRelatedILIDetails.statusCode = ILISTATUS.UNPROCESSED;
      reversedRelatedILIDetails.finInstructionID = 0;
      reversedRelatedILIDetails.creditDebitType = CREDITDEBIT.DEBIT;

      reversedRelatedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedRelatedILIDetails);

      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        relatedILIDtls.instructLineItemID,
        reversedRelatedILIid.instructionLineItemID);
      // END, CR00077580
    }
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a WriteOff Instruction Line Item.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseWriteOff(InstructionLineItemDtls iliDtls, FinInstructionID
    revFinInstrID) throws AppException, InformationalException {

    // Modify the write-off ILI being reversed so that the status indicates that
    // it is now reversed

    // BEGIN, CR00077580, CW
    // maintainInstructionLineItem manipulation variable
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    // update the status on the ILI to REVERSED
    maintainInstructionLineItemObj.setReversedILIStatus(iliDtls);

    // instructionLineItem manipulation variable
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
    // END, CR00077580

    // Get the debit ILI to which the write-off was allocated

    // Allocated instruction line item key
    InstructionLineItemKey allocatedILIKey = new InstructionLineItemKey();

    // set key to read instructionLineItem entity
    allocatedILIKey.instructLineItemID = iliDtls.instructLineItemID;

    // search instructionLineItem entity
    DebitAllocationDetailList debitAllocationDetailList = instructionLineItemObj.searchCreditAllocations(
      allocatedILIKey);

    for (int i = 0; i < debitAllocationDetailList.dtls.size(); i++) {

      // Read the details for the debit ILI

      // set key to read instructionLineItem entity
      InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();

      relatedILIKey.instructLineItemID = debitAllocationDetailList.dtls.item(i).debitInstructionLineItemID;

      InstructionLineItemDtls relatedILIDtls = instructionLineItemObj.read(
        relatedILIKey);

      // Reverse the allocation

      // Reversal instruction line item details an identifier
      InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
      InstructionLineItemID reversedILIid;

      // set reversal details
      reversedILIDetails.assign(relatedILIDtls);

      reversedILIDetails.amount = debitAllocationDetailList.dtls.item(i).allocationAmount;
      reversedILIDetails.unprocessedAmount = debitAllocationDetailList.dtls.item(i).allocationAmount;
      reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
      reversedILIDetails.financialCompID = 0;
      reversedILIDetails.effectiveDate = debitAllocationDetailList.dtls.item(i).allocationDate;
      reversedILIDetails.statusCode = ILISTATUS.PROCESSED;
      reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
      reversedILIDetails.creditDebitType = CREDITDEBIT.DEBIT;
      reversedILIDetails.instrumentGenInd = false;

      reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedILIDetails);

      // Relate this new reversal ILI to the write-off ILI being reversed

      // instructionLineItemRelation manipulation variable
      InstructionLineItemRelation instructionLineItemRelationObj = InstructionLineItemRelationFactory.newInstance();

      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
      // END, CR00077580

      if (debitAllocationDetailList.dtls.item(i).debitAdjustmentInd) {

        // surcharge can be applied to debit ILI,
        // to which the write-off was allocated, is

        // processInstructionLineItem manipulation variables
        SurchargeArrearsDates surchargeArrearsDates = new SurchargeArrearsDates();
        ProcessInstructionLineItem processInstructionLineItemObj = ProcessInstructionLineItemFactory.newInstance();

        // Surcharge arrears instruction line item identifier
        InstructionLineItemID surchargeArrearsILIid;

        surchargeArrearsDates.arrearsDateFrom = debitAllocationDetailList.dtls.item(i).allocationDate;
        surchargeArrearsDates.arrearsDateTo = Date.getCurrentDate();

        // calculate surcharge arrears
        surchargeArrearsILIid = processInstructionLineItemObj.calculateSurchargeArrears(
          relatedILIDtls, surchargeArrearsDates);

        if (surchargeArrearsILIid.instructionLineItemID != 0) {

          // i.e. surcharges were calculated
          // Instruction line item relation details
          InstructionLineItemRelationDtls iliRelationDtls = new InstructionLineItemRelationDtls();

          // set instructionLineItemRelation details
          iliRelationDtls.instructLineItemRelatID = UniqueIDFactory.newInstance().getNextID();
          iliRelationDtls.instructLineItemID = debitAllocationDetailList.dtls.item(i).debitInstructionLineItemID;
          iliRelationDtls.relatedLineItemID = surchargeArrearsILIid.instructionLineItemID;
          iliRelationDtls.creationDate = TransactionInfo.getSystemDate();
          iliRelationDtls.typeCode = ILIRELATIONSHIP.SURCHARGES;

          instructionLineItemRelationObj.insert(iliRelationDtls);
        }
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a claim payment Instruction Line Item.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseClaimPayment(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    // Set the status of the payment ILI to indicate it is reversed
    // BEGIN, CR00077580, CW
    // maintainInstructionLineItem manipulation variable
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    // update the status on the ILI to REVERSED
    maintainInstructionLineItemObj.setReversedILIStatus(iliDtls);
    // END, CR00077580

    // Create the reversal ILI for this payment ILI being reversed

    // Reversal instruction line item details an identifier
    InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();

    reversedILIDetails.assign(iliDtls);
    
    // BEGIN, CR00327227, KH
    if (iliDtls.instructionLineItemType.equals(ILITYPE.REFUND)) {

      /*
       * If we're reversing a refund payment then the money must be made
       * available again for later allocation or refund
       */
      reversedILIDetails.unprocessedAmount = iliDtls.amount;
    } else {
      reversedILIDetails.unprocessedAmount = Money.kZeroMoney;
    }
    // END, CR00327227
    reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
    reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
    reversedILIDetails.financialCompID = 0;
    reversedILIDetails.statusCode = ILISTATUS.PROCESSED;
    reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
    reversedILIDetails.creditDebitType = CREDITDEBIT.CREDIT;
    reversedILIDetails.instrumentGenInd = false;

    InstructionLineItemID reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
      reversedILIDetails);

    // Relate this new ILI to the tax payment ILI being reversed
    // BEGIN, CR00077580, CW
    maintainInstructionLineItemObj.createReversalILIRelationship(
      iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
    // END, CR00077580
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a liability Instruction Line Item and any of its
   * related Instruction Line Items.
   *
   * @param iliDtls Instruction line item details
   * @param revFinInstrID Reversal financial instruction identifier
   */
  public void reverseLiability(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    // Get the credit ILIs which were allocated to this liability

    // instructionLineItem manipulation variables
    InstructionLineItemKey allocatedILIKey = new InstructionLineItemKey();
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

    // set key to read instructionLineItem
    allocatedILIKey.instructLineItemID = iliDtls.instructLineItemID;

    // search instructionLineItem
    CreditAllocationDetailList creditAllocationDetailList = instructionLineItemObj.searchDebitAllocations(
      allocatedILIKey);

    for (int i = 0; i < creditAllocationDetailList.dtls.size(); i++) {

      // set key to read instructionLineItem entity
      InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();

      relatedILIKey.instructLineItemID = creditAllocationDetailList.dtls.item(i).creditInstructionLineItemID;

      InstructionLineItemDtls relatedILIDtls = instructionLineItemObj.read(
        relatedILIKey);

      // Reverse the allocation

      // Reversal instruction line item details an identifier
      InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
      InstructionLineItemID reversedILIid;

      // maintainInstructionLineItem manipulation variable
      MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

      // set reversal details
      reversedILIDetails.assign(relatedILIDtls);

      reversedILIDetails.amount = creditAllocationDetailList.dtls.item(i).allocationAmount;
      reversedILIDetails.unprocessedAmount = creditAllocationDetailList.dtls.item(i).allocationAmount;
      reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
      reversedILIDetails.financialCompID = 0;
      reversedILIDetails.effectiveDate = creditAllocationDetailList.dtls.item(i).allocationDate;
      reversedILIDetails.statusCode = ILISTATUS.PROCESSED;
      reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
      reversedILIDetails.creditDebitType = CREDITDEBIT.CREDIT;
      reversedILIDetails.instrumentGenInd = false;

      reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedILIDetails);

      // Relate this new reversal ILI to the liability ILI being reversed

      // instructionLineItemRelation manipulation variables
      InstructionLineItemRelationDtls instructionLineItemRelationDtls = new InstructionLineItemRelationDtls();
      InstructionLineItemRelation instructionLineItemRelationObj = InstructionLineItemRelationFactory.newInstance();

      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
      // END, CR00077580

      // set instructionLineItemRelation details
      instructionLineItemRelationDtls.instructLineItemRelatID = UniqueIDFactory.newInstance().getNextID();
      instructionLineItemRelationDtls.instructLineItemID = creditAllocationDetailList.dtls.item(i).creditInstructionLineItemID;
      instructionLineItemRelationDtls.relatedLineItemID = reversedILIid.instructionLineItemID;
      instructionLineItemRelationDtls.creationDate = TransactionInfo.getSystemDate();
      instructionLineItemRelationDtls.typeCode = ILIRELATIONSHIP.ALLOCATIONREVERSAL;

      instructionLineItemRelationObj.insert(instructionLineItemRelationDtls);
    }

    // Calling createLiabilityILIs method
    createLiabilityILIs(iliDtls, revFinInstrID);

    // If surcharges were charged, get these surcharge ILI and reverse these
    if (iliDtls.adjustmentInd) {

      // Related instruction line item identifier and details list
      RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();
      RelatedILIDetailsList relatedILIDetailsList;

      // set key to read instructionLineItem
      relatedILIidentifier.instructLineItemID = iliDtls.instructLineItemID;
      relatedILIidentifier.type = ILIRELATIONSHIP.SURCHARGES;

      // search instructionLineItem entity
      relatedILIDetailsList = instructionLineItemObj.searchRelatedILIByInstrLineItemIDType(
        relatedILIidentifier);

      for (int j = 0; j < relatedILIDetailsList.dtls.size(); j++) {

        // Surcharged instruction line item key and details
        InstructionLineItemKey surchargedILIKey = new InstructionLineItemKey();
        InstructionLineItemDtls surchargedILIDtls;

        // set key to read instructionLineItem entity
        surchargedILIKey.instructLineItemID = relatedILIDetailsList.dtls.item(j).instructLineItemID;

        // read instructionLineItem entity
        surchargedILIDtls = instructionLineItemObj.read(surchargedILIKey);

        // Surcharges are also liabilities, reverse the surcharge by a
        // recursive call to the method
        reverseLiability(surchargedILIDtls, revFinInstrID);
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * To create a system ticket for a reversal.
   *
   * @param reversalTicketSummary Reversal ticket summary details
   */
  public void createReversalTicket(ReversalTicketSummary reversalTicketSummary)
    throws AppException, InformationalException {

    Notification notificationObj = NotificationFactory.newInstance();

    // WorkAllocationTask service layer object
    StandardManualTaskDtls standardManualDtls = new StandardManualTaskDtls();

    String strGenFinancialItemReversedTicket;

    strGenFinancialItemReversedTicket = Configuration.getProperty(
      EnvVars.ENV_GENFINANCIALITEMREVERSEDTICKET);

    if (strGenFinancialItemReversedTicket == null) {
      // set to the default value
      strGenFinancialItemReversedTicket = EnvVars.ENV_GENFINANCIALITEMREVERSEDTICKET_DEFAULT;
    }

    // check the environment variable
    if (strGenFinancialItemReversedTicket.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {
      return;
    }

    // maintainCase manipulation variables
    MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();

    CaseIDKey caseIDKey = new CaseIDKey();
    CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName;

    // set key to read maintainCase
    caseIDKey.caseID = reversalTicketSummary.caseID;

    // read maintainCase
    caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
      caseIDKey);

    AppException ticketText = new AppException(
      curam.message.BPOCREATEREVERSAL.INF_REVERSED_FINANCIAL_ITEM);

    ticketText.arg(reversalTicketSummary.instructionCategory);

    ticketText.arg(caseReferenceProductNameConcernRoleName.caseReference);
    ticketText.arg(caseReferenceProductNameConcernRoleName.productName);
    ticketText.arg(caseReferenceProductNameConcernRoleName.concernRoleName);

    // BEGIN, CR00163236, CL
    standardManualDtls.dtls.taskDtls.comments = ticketText.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163236

    // set notification details
    standardManualDtls.dtls.concerningDtls.caseID = reversalTicketSummary.caseID;

    AppException subjectText = new AppException(
      curam.message.BPOCREATEREVERSAL.INF_REVERSED_FINANCIAL_ITEM_SUBJECT);

    subjectText.arg(caseReferenceProductNameConcernRoleName.caseReference);
    subjectText.arg(caseReferenceProductNameConcernRoleName.productName);
    subjectText.arg(caseReferenceProductNameConcernRoleName.concernRoleName);

    // BEGIN, CR00163236, CL
    standardManualDtls.dtls.taskDtls.subject = subjectText.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163236
    // BEGIN, CR00023618, SK
    standardManualDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.financialReversalTaskDefinitionID;
    // END, CR00023618

    // create notification
    notificationObj.sendCaseOwnerNotification(standardManualDtls);
  }

  // ___________________________________________________________________________
  /**
   * To validate the Financial Instruction details to be reversed
   *
   * @param revFinInstructionSummary Reverse Financial Instruction Summary
   *
   * @return Financial Instruction Details
   */
  public FinancialInstructionDtls validateReverseFinInstruction(
    ReverseFinInstructionSummary revFinInstructionSummary)
    throws AppException, InformationalException {

    Money zeroAmount = Money.kZeroMoney;

    // Validation section
    if (revFinInstructionSummary.finInstructionID == 0) {

      ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          GENERALFINANCE.ERR_FININSTRUCTION_FININSTRUCTIONID_ZERO),
          ValidationManagerConst.kSetOne,
          0);
    }

    // set key for financialInstruction read
    FinancialInstructionKey financialInstructionKey = new FinancialInstructionKey();

    financialInstructionKey.finInstructionID = revFinInstructionSummary.finInstructionID;

    FinancialInstructionDtls financialInstructionDtls = FinancialInstructionFactory.newInstance().read(
      financialInstructionKey);

    if (financialInstructionDtls.statusCode.equals(
      FININSTRUCTIONSTATUS.REVERSED)
        || financialInstructionDtls.statusCode.equals(
          FININSTRUCTIONSTATUS.CANCELLED)) {

      AppException e = new AppException(
        BPOCREATEREVERSAL.ERR_FININSTRUCTION_FV_FININSTRUCTIONSTATUS_REVERSED);

      ValidationManagerFactory.getManager().throwWithLookup(e,
        ValidationManagerConst.kSetOne, 1);
    }

    if (financialInstructionDtls.typeCode.equals(FINANCIALINSTRUCTION.REVERSAL)) {

      AppException e = new AppException(
        BPOCREATEREVERSAL.ERR_FININSTRUCTION_FV_FININSTRUCTIONSTATUS_REVERSED);

      ValidationManagerFactory.getManager().throwWithLookup(e,
        ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00002272, SPD
    if (financialInstructionDtls.amount.getValue() < zeroAmount.getValue()) {

      AppException e = new AppException(
        GENERALFINANCE.ERR_FININSTRUCTION_AMT_NEGATIVE);

      e.arg(financialInstructionDtls.amount);
      ValidationManagerFactory.getManager().throwWithLookup(e,
        ValidationManagerConst.kSetOne, 1);
    }
    // END, CR00002272

    return financialInstructionDtls;
  }

  // ___________________________________________________________________________
  /**
   * To validate the details of the InstructionLineItem reversal
   *
   * @param revILISummary Reverse Instruction Line Item Summary
   *
   * @return Instruction Line Item Details
   */
  public InstructionLineItemDtls validateReverseInstructionLineItem(
    ReverseInstructionLineItemSummary revILISummary) throws AppException,
      InformationalException {

    Money zeroAmount = Money.kZeroMoney;

    // Validation section
    if (revILISummary.instructionLineItemID == 0) {

      ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCREATEREVERSAL.ERR_ILI_FV_INSTRUCTIONLINEITEMID_ZERO),
          ValidationManagerConst.kSetOne,
          0);
    }

    // set key to read instructionLineItem entity
    InstructionLineItemKey iliKey = new InstructionLineItemKey();

    iliKey.instructLineItemID = revILISummary.instructionLineItemID;

    InstructionLineItemDtls iliDtls = InstructionLineItemFactory.newInstance().read(
      iliKey);

    if (iliDtls.instructLineItemCategory.equals(ILICATEGORY.REVERSALINSTRUCTION)) {

      AppException e = new AppException(
        BPOCREATEREVERSAL.ERR_ILI_FV_ILICATEGORY_REVERSED);

      ValidationManagerFactory.getManager().throwWithLookup(e,
        ValidationManagerConst.kSetOne, 0);
    }

    if (iliDtls.instructLineItemCategory.equals(ILICATEGORY.PAYMENTINSTRUCTION)
      || iliDtls.instructLineItemCategory.equals(
        ILICATEGORY.PAYMENTRECEIVEDINSTRUCTION)
        || iliDtls.instructLineItemCategory.equals(
          ILICATEGORY.WRITEOFFINSTRUCTION)
          || iliDtls.instructLineItemCategory.equals(
            ILICATEGORY.PAYMENTINSTRUCTIONFORUTILITY)
            || iliDtls.instructLineItemCategory.equals(
              ILICATEGORY.PAYMENTINSTRUCTIONTOTAX)) {

      AppException e = new AppException(
        BPOCREATEREVERSAL.ERR_ILI_FV_ILICATEGORY_NOTREVERSEABLE);

      e.arg(iliDtls.instructLineItemCategory);
      ValidationManagerFactory.getManager().throwWithLookup(e,
        ValidationManagerConst.kSetOne, 0);
    }

    if (iliDtls.statusCode.equals(ILISTATUS.REVERSED)) {

      AppException e = new AppException(
        BPOCREATEREVERSAL.ERR_ILI_FV_STATUS_REVERSED);

      ValidationManagerFactory.getManager().throwWithLookup(e,
        ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00002272, SPD
    if (iliDtls.amount.getValue() < zeroAmount.getValue()) {

      AppException e = new AppException(
        GENERALFINANCE.ERR_FININSTRUCTION_AMT_NEGATIVE);

      e.arg(iliDtls.amount);
      ValidationManagerFactory.getManager().throwWithLookup(e,
        ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00002272

    return iliDtls;
  }

  // ___________________________________________________________________________
  /**
   * To reverse the corresponding Tax Deduction of the Tax Payment being
   * reversed
   *
   * @param iliDtls Instruction Line Item Details
   */
  public void reverseCorrespondingTaxDeduction(InstructionLineItemDtls iliDtls)
    throws AppException, InformationalException {

    // instructionLineItem manipulation variables
    RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

    // set key to read instructionLineItem
    relatedILIidentifier.instructLineItemID = iliDtls.instructLineItemID;
    relatedILIidentifier.type = ILIRELATIONSHIP.TAXPAYMENT;

    // search instructionLineItem entity
    RelatedILIDetailsList relatedILIDetailsList = instructionLineItemObj.searchRelatedILIByRelatedLineItemIDType(
      relatedILIidentifier);

    for (int i = 0; i < relatedILIDetailsList.dtls.size(); i++) {

      // Related instruction line item key and details
      InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();

      relatedILIKey.instructLineItemID = relatedILIDetailsList.dtls.item(i).instructLineItemID;

      // read instructionLineItem entity
      InstructionLineItemDtls relatedILIDtls = instructionLineItemObj.read(
        relatedILIKey);

      // Set the status of this tax payment ILI to indicate it is reversed

      // BEGIN, CR00077580, CW
      // maintainInstructionLineItem manipulation variable
      MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

      // update the status on the ILI to REVERSED
      maintainInstructionLineItemObj.setReversedILIStatus(relatedILIDtls);
      // END, CR00077580

      // Reverse this tax payment ILI

      // Reversal related instruction line item details an identifier
      InstructionLineItemDetails reversedRelatedILIDetails = new InstructionLineItemDetails();
      InstructionLineItemID reversedRelatedILIid;

      // set reversal details
      reversedRelatedILIDetails.assign(relatedILIDtls);

      reversedRelatedILIDetails.amount = relatedILIDetailsList.dtls.item(i).amount;
      reversedRelatedILIDetails.unprocessedAmount = relatedILIDetailsList.dtls.item(i).amount;
      reversedRelatedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reversedRelatedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
      reversedRelatedILIDetails.financialCompID = 0;
      reversedRelatedILIDetails.effectiveDate = Date.getCurrentDate();
      reversedRelatedILIDetails.statusCode = ILISTATUS.UNPROCESSED;
      reversedRelatedILIDetails.finInstructionID = 0;
      reversedRelatedILIDetails.creditDebitType = CREDITDEBIT.DEBIT;

      reversedRelatedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedRelatedILIDetails);

      // Relate this new reversal ILI to the tax payment ILI it is reversing

      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        relatedILIDtls.instructLineItemID,
        reversedRelatedILIid.instructionLineItemID);
      // END, CR00077580
    }
  }

  // ___________________________________________________________________________
  /**
   * To reverse the Corresponding Tax Payment of the Tax Deduction
   * being reversed
   *
   * @param iliDtls Instruction Line Item Details
   */
  public void reverseCorrespondingTaxPayment(InstructionLineItemDtls iliDtls)
    throws AppException, InformationalException {

    // instructionLineItem manipulation variables
    RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

    // set key to read instructionLineItem entity
    relatedILIidentifier.instructLineItemID = iliDtls.instructLineItemID;
    relatedILIidentifier.type = ILIRELATIONSHIP.TAXPAYMENT;

    // search instructionLineItem entity
    RelatedILIDetailsList relatedILIDetailsList = instructionLineItemObj.searchRelatedILIByInstrLineItemIDType(
      relatedILIidentifier);

    for (int i = 0; i < relatedILIDetailsList.dtls.size(); i++) {

      // Related instruction line item key and details
      InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();
      InstructionLineItemDtls relatedILIDtls;

      // set key to read instructionLineItem entity
      relatedILIKey.instructLineItemID = relatedILIDetailsList.dtls.item(i).instructLineItemID;

      // read instructionLineItem entity
      relatedILIDtls = instructionLineItemObj.read(relatedILIKey);

      // Set the status of this tax payment ILI to indicate it is reversed

      // BEGIN, CR00077580, CW
      // maintainInstructionLineItem manipulation variable
      MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

      // update the status on the ILI to REVERSED
      maintainInstructionLineItemObj.setReversedILIStatus(relatedILIDtls);
      // END, CR00077580

      // Reverse this tax payment ILI

      // Reversal related instruction line item details an identifier
      InstructionLineItemDetails reversedRelatedILIDetails = new InstructionLineItemDetails();
      InstructionLineItemID reversedRelatedILIid;

      // set reversal details
      reversedRelatedILIDetails.assign(relatedILIDtls);

      reversedRelatedILIDetails.amount = relatedILIDetailsList.dtls.item(i).amount;
      reversedRelatedILIDetails.unprocessedAmount = relatedILIDetailsList.dtls.item(i).amount;
      reversedRelatedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reversedRelatedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
      reversedRelatedILIDetails.financialCompID = 0;
      reversedRelatedILIDetails.effectiveDate = Date.getCurrentDate();
      reversedRelatedILIDetails.statusCode = ILISTATUS.UNPROCESSED;
      reversedRelatedILIDetails.finInstructionID = 0;
      reversedRelatedILIDetails.creditDebitType = CREDITDEBIT.CREDIT;

      reversedRelatedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedRelatedILIDetails);

      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        relatedILIDtls.instructLineItemID,
        reversedRelatedILIid.instructionLineItemID);
      // END, CR00077580
    }
  }

  // ___________________________________________________________________________
  /**
   * To reverse the corresponding Utility Deduction of the Utility
   * Payment being reversed
   *
   * @param iliDtls Instruction Line Item Details
   */
  public void reverseCorrespondingUtilityDeduction(InstructionLineItemDtls
    iliDtls) throws AppException, InformationalException {

    // instructionLineItem manipulation variables
    RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

    // set key to read instructionLineItem
    relatedILIidentifier.instructLineItemID = iliDtls.instructLineItemID;
    relatedILIidentifier.type = ILIRELATIONSHIP.UTILITYPAYMENT;

    // search instructionLineItem
    RelatedILIDetailsList relatedILIDetailsList = instructionLineItemObj.searchRelatedILIByRelatedLineItemIDType(
      relatedILIidentifier);

    for (int i = 0; i < relatedILIDetailsList.dtls.size(); i++) {

      // Related instruction line item key and details
      InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();
      InstructionLineItemDtls relatedILIDtls;

      // set key to read instructionLineItem
      relatedILIKey.instructLineItemID = relatedILIDetailsList.dtls.item(i).instructLineItemID;

      // read instructionLineItem
      relatedILIDtls = instructionLineItemObj.read(relatedILIKey);

      // Set the status of this utility deduction ILI to indicate it is
      // reversed

      // BEGIN, CR00077580, CW
      // maintainInstructionLineItem manipulation variable
      MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

      // update the status on the ILI to REVERSED
      maintainInstructionLineItemObj.setReversedILIStatus(relatedILIDtls);
      // END, CR00077580

      // Reverse this utility payment ILI

      // Reversal related instruction line item details an identifier
      InstructionLineItemDetails reversedRelatedILIDetails = new InstructionLineItemDetails();
      InstructionLineItemID reversedRelatedILIid;

      // set reversal details
      reversedRelatedILIDetails.assign(relatedILIDtls);

      reversedRelatedILIDetails.amount = relatedILIDetailsList.dtls.item(i).amount;
      reversedRelatedILIDetails.unprocessedAmount = relatedILIDetailsList.dtls.item(i).amount;
      reversedRelatedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reversedRelatedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
      reversedRelatedILIDetails.financialCompID = 0;
      reversedRelatedILIDetails.effectiveDate = Date.getCurrentDate();
      reversedRelatedILIDetails.statusCode = ILISTATUS.UNPROCESSED;
      reversedRelatedILIDetails.finInstructionID = 0;
      reversedRelatedILIDetails.creditDebitType = CREDITDEBIT.DEBIT;

      reversedRelatedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedRelatedILIDetails);

      // Relate this reversal ILI to the utility payment ILI it is reversing

      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        relatedILIDtls.instructLineItemID,
        reversedRelatedILIid.instructionLineItemID);
      // END, CR00077580
    }
  }

  // ___________________________________________________________________________
  /**
   * To reverse the corresponding Utility Payment for the Utility
   * Deduction being reversed
   *
   * @param iliDtls Instruction Line Item Details
   */
  public void reverseCorrespondingUtilityPayment(InstructionLineItemDtls iliDtls) 
    throws AppException, InformationalException {

    // Find and reverse the corresponding utility payment ILI
    RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

    // set key to search instructionLineItem entity
    relatedILIidentifier.instructLineItemID = iliDtls.instructLineItemID;
    relatedILIidentifier.type = ILIRELATIONSHIP.UTILITYPAYMENT;

    // search instructionLineItem
    RelatedILIDetailsList relatedILIDetailsList = instructionLineItemObj.searchRelatedILIByInstrLineItemIDType(
      relatedILIidentifier);

    for (int i = 0; i < relatedILIDetailsList.dtls.size(); i++) {

      // Related instruction line item key and details
      InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();
      InstructionLineItemDtls relatedILIDtls;

      // set key to read instructionLineItem entity
      relatedILIKey.instructLineItemID = relatedILIDetailsList.dtls.item(i).instructLineItemID;

      // read instructionLineItem entity
      relatedILIDtls = instructionLineItemObj.read(relatedILIKey);

      // BEGIN, CR00077580, CW
      // maintainInstructionLineItem manipulation variable
      MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

      // update the status on the ILI to REVERSED
      maintainInstructionLineItemObj.setReversedILIStatus(relatedILIDtls);
      // END, CR00077580

      // Reverse this utility payment ILI
      // Reversal related instruction line item details an identifier
      InstructionLineItemDetails reversedRelatedILIDetails = new InstructionLineItemDetails();
      InstructionLineItemID reversedRelatedILIid;

      // set reversal details
      reversedRelatedILIDetails.assign(relatedILIDtls);

      reversedRelatedILIDetails.amount = relatedILIDetailsList.dtls.item(i).amount;
      reversedRelatedILIDetails.unprocessedAmount = relatedILIDetailsList.dtls.item(i).amount;
      reversedRelatedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reversedRelatedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
      reversedRelatedILIDetails.financialCompID = 0;
      reversedRelatedILIDetails.effectiveDate = Date.getCurrentDate();
      reversedRelatedILIDetails.statusCode = ILISTATUS.UNPROCESSED;
      reversedRelatedILIDetails.finInstructionID = 0;
      reversedRelatedILIDetails.creditDebitType = CREDITDEBIT.CREDIT;

      reversedRelatedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedRelatedILIDetails);

      // Relate this reversal ILI to the utility payment ILI it is reversing
      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        relatedILIDtls.instructLineItemID,
        reversedRelatedILIid.instructionLineItemID);
      // END, CR00077580
    }

  }

  // ___________________________________________________________________________
  /**
   * To create reversal ILI's for the allocated or unallocated
   * InstructionLineItems
   *
   * @param iliDtls Instruction Line Item Details
   * @param revFinInstrID Reverse Financial Instruction ID
   */
  public void createLiabilityILIs(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    // zero money amount
    Money zeroAmount = Money.kZeroMoney;

    if (iliDtls.unprocessedAmount.getValue() != 0) {

      // Reverse the unallocated amount
      // Create the reversal ILI for this unallocated amount of this liability
      // ILI being reversed

      // Reversal instruction line item details an identifier
      InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
      InstructionLineItemID reversedILIid;

      // maintainInstructionLineItem manipulation variable
      MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

      // set reversal details
      reversedILIDetails.assign(iliDtls);

      reversedILIDetails.amount = iliDtls.unprocessedAmount;
      reversedILIDetails.unprocessedAmount = zeroAmount;
      reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
      reversedILIDetails.instructionLineItemType = ILITYPE.UNALLOCATEDREVERSAL;
      reversedILIDetails.financialCompID = 0;
      reversedILIDetails.coverPeriodFrom = Date.getCurrentDate();
      reversedILIDetails.coverPeriodTo = Date.getCurrentDate();
      reversedILIDetails.effectiveDate = Date.getCurrentDate();
      reversedILIDetails.statusCode = ILISTATUS.ALLOCATED;
      reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
      reversedILIDetails.creditDebitType = CREDITDEBIT.CREDIT;
      reversedILIDetails.instrumentGenInd = false;

      reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedILIDetails);

      // Relate this new ILI to the liability ILI being reversed
      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
      // END, CR00077580

      // Set the status of the Liability to indicate it is the being reversed
      // and reduce the unallocated amount, as the reversal will be allocated
      // to it

      // Instruction line item date status and key
      StatusCodeUnprocessedAmt iliStatusUnprocAmt = new StatusCodeUnprocessedAmt();
      InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();

      // set details for ILI update
      iliStatusUnprocAmt.unprocessedAmount = zeroAmount;
      iliStatusUnprocAmt.statusCode = curam.codetable.ILISTATUS.REVERSED;
      iliStatusUnprocAmt.versionNo = iliDtls.versionNo;

      // set ILI key for update
      instructionLineItemKey.instructLineItemID = iliDtls.instructLineItemID;

      // update the instructionLineItem
      InstructionLineItemFactory.newInstance().modifyStatusUnprocessedAmt(
        instructionLineItemKey, iliStatusUnprocAmt);

      // Allocate the reversal ILI (CDT) to the unallocated liability (DBT) -
      // for the consistency with all other allocated Credit to Debits.

      // allocationLine manipulation variables
      AllocationLineDtls allocationLineDtls = new AllocationLineDtls();
      curam.core.intf.AllocationLine allocationLineObj = curam.core.fact.AllocationLineFactory.newInstance();

      // set allocation details
      allocationLineDtls.allocationLineID = UniqueIDFactory.newInstance().getNextID();
      allocationLineDtls.instructLineItemID = reversedILIid.instructionLineItemID;
      allocationLineDtls.relatedLineItemID = iliDtls.instructLineItemID;
      allocationLineDtls.allocationDate = Date.getCurrentDate();
      allocationLineDtls.amount = iliDtls.unprocessedAmount;
      allocationLineDtls.statusCode = curam.codetable.ALLOCATIONSTATUS.DEFAULTCODE;

      // insert allocationLine
      allocationLineObj.insert(allocationLineDtls);

    } else {

      // BEGIN, CR00077580, CW
      // No unallocated amount associated with this liability, therefore only
      // need to change the status of the Liability to indicate it is being
      // reversed
      MaintainInstructionLineItemFactory.newInstance().setReversedILIStatus(
        iliDtls);
      // END, CR00077580
    }
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a loan repayment due instruction line item
   * and any of its related instruction line items.
   *
   * @param iliDtls Instruction Line Item Details
   * @param revFinInstrID Financial Instruction ID
   */
  public void reverseRepaymentDue(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    InstructionLineItemKey iliKey = new InstructionLineItemKey();

    PrimaryILIidTypeCode primaryILIIdTypeCode = new PrimaryILIidTypeCode();

    if (iliDtls.unprocessedAmount.isZero()) {

      ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCREATEREVERSAL.ERR_ILI_FV_ILITYPE_ALLOCREVERSALUNSUPPORTED),
          ValidationManagerConst.kSetOne,
          0);
    }

    // reverse liability
    reverseLiability(iliDtls, revFinInstrID);

    // Get related Repayment Expected ILI and reverse it
    primaryILIIdTypeCode.instructLineItemID = iliDtls.instructLineItemID;
    primaryILIIdTypeCode.typeCode = curam.codetable.ILIRELATIONSHIP.LOANREPAYMENT;

    // read instructionLineItemRelation entity
    InstructionLineItemRelationDtls iliRelDtls = InstructionLineItemRelationFactory.newInstance().readByInstLineItemIDTypeCode(
      primaryILIIdTypeCode);

    // set ILI key to read repayment expected ILI
    iliKey.instructLineItemID = iliRelDtls.relatedLineItemID;

    // read repayment expected ILI
    InstructionLineItemDtls rexILIDtls = InstructionLineItemFactory.newInstance().read(
      iliKey);

    // reverse the repayment expected part of the loan
    reverseRepaymentExpected(rexILIDtls, revFinInstrID);
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a loan repayment expected instruction line item
   * and any of its related instruction line items.
   *
   * @param iliDtls Instruction Line Item Details
   * @param revFinInstrID Financial Instruction ID
   */
  public void reverseRepaymentExpected(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
    InstructionLineItemKey allocatedILIKey = new InstructionLineItemKey();

    // debit allocation details list
    DebitAllocationDetailList debitAllocationDetailList;

    // Set the status of the Repayment Expected ILI to indicate it is reversed
    // BEGIN, CR00077580, CW
    // update the status on the ILI to REVERSED
    maintainInstructionLineItemObj.setReversedILIStatus(iliDtls);
    // END, CR00077580

    // Find and reverse the Loan Liability ILI to which the repayment
    // expected was allocated.
    allocatedILIKey.instructLineItemID = iliDtls.instructLineItemID;

    // read instructionLineItem entity
    debitAllocationDetailList = instructionLineItemObj.searchCreditAllocations(
      allocatedILIKey);

    for (int i = 0; i < debitAllocationDetailList.dtls.size(); i++) {

      InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();
      InstructionLineItemDtls relatedILIDtls;

      // set key to read instructionLineItem entity
      relatedILIKey.instructLineItemID = debitAllocationDetailList.dtls.item(i).debitInstructionLineItemID;

      // read instructionLineItem entity
      relatedILIDtls = instructionLineItemObj.read(relatedILIKey);

      // Reverse the allocation
      InstructionLineItemDetails reversedLbyILIDetails = new InstructionLineItemDetails();
      InstructionLineItemID reversedLbyILIid;

      // set reversal details
      reversedLbyILIDetails.assign(relatedILIDtls);

      reversedLbyILIDetails.amount = debitAllocationDetailList.dtls.item(i).allocationAmount;
      reversedLbyILIDetails.unprocessedAmount = debitAllocationDetailList.dtls.item(i).allocationAmount;
      reversedLbyILIDetails.instructLineItemCategory = curam.codetable.ILICATEGORY.REVERSALINSTRUCTION;
      reversedLbyILIDetails.instructionLineItemType = curam.codetable.ILITYPE.ALLOCATEDREVERSAL;
      reversedLbyILIDetails.financialCompID = 0;
      reversedLbyILIDetails.effectiveDate = debitAllocationDetailList.dtls.item(i).allocationDate;
      reversedLbyILIDetails.statusCode = curam.codetable.ILISTATUS.PROCESSED;
      reversedLbyILIDetails.finInstructionID = revFinInstrID.finInstructionID;
      reversedLbyILIDetails.creditDebitType = curam.codetable.CREDITDEBIT.DEBIT;
      reversedLbyILIDetails.instrumentGenInd = false;

      reversedLbyILIid = maintainInstructionLineItemObj.addInstructionLineItem(
        reversedLbyILIDetails);

      // Relate this new reversal ILI to the Loan Liability ILI being reversed
      // BEGIN, CR00077580, CW
      maintainInstructionLineItemObj.createReversalILIRelationship(
        iliDtls.instructLineItemID, reversedLbyILIid.instructionLineItemID);
      // END, CR00077580
    }
  }

  // ___________________________________________________________________________
  /**
   * To reverse the effect of a deduction Item Instruction Line Item and any
   * of its related Instruction Line Items.
   *
   * @param iliDtls Instruction Line Item Details
   * @param revFinInstrID Financial Instruction ID
   */
  public void reverseDeductionItem(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID) throws AppException, InformationalException {

    // maintainInstructionLineItem manipulation variables
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();
    InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
    InstructionLineItemID reversedILIid;

    // set the status of the deduction item ILI to indicate it is reversed.
    // BEGIN, CR00077580, CW
    // update the status on the ILI to REVERSED
    maintainInstructionLineItemObj.setReversedILIStatus(iliDtls);
    // END, CR00077580

    // Create the reversal ILI for this deduction ILI being reversed
    reversedILIDetails.assign(iliDtls);

    // BEGIN, CR00053019, MC
    reversedILIDetails.unprocessedAmount = curam.util.type.Money.kZeroMoney;
    // END, CR00053019

    reversedILIDetails.instructLineItemCategory = curam.codetable.ILICATEGORY.REVERSALINSTRUCTION;
    reversedILIDetails.instructionLineItemType = curam.codetable.ILITYPE.ALLOCATEDREVERSAL;
    reversedILIDetails.financialCompID = 0;
    reversedILIDetails.effectiveDate = curam.util.type.Date.getCurrentDate();
    reversedILIDetails.statusCode = curam.codetable.ILISTATUS.PROCESSED;
    reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
    reversedILIDetails.creditDebitType = curam.codetable.CREDITDEBIT.DEBIT;
    reversedILIDetails.instrumentGenInd = false;

    reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
      reversedILIDetails);

    // Relate this new ILI to the deduction item ILI being reversed.
    // BEGIN, CR00077580, CW
    maintainInstructionLineItemObj.createReversalILIRelationship(
      iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
    // END, CR00077580

    // find and reverse the corresponding deduction payment ILI
    reverseDeductionPayment(iliDtls, revFinInstrID);
  }

  // BEGIN, CR00002146, KH
  // ___________________________________________________________________________
  /**
   * To reverse the effect of a deduction payment Instruction Line Item and
   * any of its related Instruction Line Items.
   *
   * @param iliDtls Instruction Line Item Details
   * @param revFinInstrID Financial Instruction ID
   */
  public void reverseDeductionPayment(InstructionLineItemDtls iliDtls,
    FinInstructionID revFinInstrID)
    throws AppException, InformationalException {

    // instructionLineItem manipulation variables
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
    RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();
    RelatedILIDetailsList relatedILIDetailsList;

    // Is the initial ILI a Third Party Deduction Payment?
    if (iliDtls.instructionLineItemType.equals(ILITYPE.DEDUCTIONPAYMENT)
      && iliDtls.creditDebitType.equals(CREDITDEBIT.DEBIT)) {

      // We are canceling from the 3rd party perspective, therefore we do not
      // want to cancel the related deduction item on the benefit case.

      // BEGIN, CR00018488, KH
      // Reverse the third party deduction payment
      reverseThirdPartyDeductionPayment(iliDtls, revFinInstrID);
      // END, CR00018488

    } else { // It is a Deduction Item (or Applied Deduction Payment)

      // Set key to read related instruction line items
      relatedILIidentifier.instructLineItemID = iliDtls.instructLineItemID;
      relatedILIidentifier.type = ILIRELATIONSHIP.DEDUCTIONPAYMENT;

      // Find the related deduction payment instructionLineItems
      relatedILIDetailsList = instructionLineItemObj.searchRelatedILIByInstrLineItemIDType(
        relatedILIidentifier);

      for (int i = 0; i < relatedILIDetailsList.dtls.size(); i++) {

        // related instruction line item key
        InstructionLineItemKey relatedILIKey = new InstructionLineItemKey();

        // the ILI related to the ILI being reversed
        InstructionLineItemDtls relatedILIDtls;

        // set key to read instructionLineItem entity
        relatedILIKey.instructLineItemID = relatedILIDetailsList.dtls.item(i).instructLineItemID;

        // read instructionLineItem entity
        relatedILIDtls = instructionLineItemObj.read(relatedILIKey);

        // If this is a debit then we are dealing with a third party deduction
        if (relatedILIDtls.creditDebitType.equals(CREDITDEBIT.DEBIT)) {

          // reverse the corresponding third party deduction payment
          reverseCorrespondingThirdPartyDeductionPayment(relatedILIDtls);

        } else { // This is an applied deduction payment

          // Reverse allocated payment received
          reverseAllocatedPmtRecvd(relatedILIDtls, revFinInstrID);
        }
      } // end for i
    }
  }

  // END, CR00002146

  // BEGIN, HARP 60499, RCB
  // ___________________________________________________________________________
  /**
   * This method reverse the corresponding Third Party Deduction Payment for
   * the Third Party Deduction Item being reversed.
   *
   * @param iliDtls Instruction Line Item Details
   *
   * @throws Informational Exception Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void reverseCorrespondingThirdPartyDeductionPayment(
    InstructionLineItemDtls iliDtls)
    throws AppException, InformationalException {

    // Reversal instruction line item details and identifier
    InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
    InstructionLineItemID reversedILIid;

    // MaintainInstructionLineItem object
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    // BEGIN, CR00077580, CW
    // update the status on the ILI to REVERSED
    // BEGIN, CR00313598, DJ
    if (!ILISTATUS.UNPROCESSED.equals(iliDtls.statusCode)) {
      maintainInstructionLineItemObj.setReversedILIStatus(iliDtls);
    }
    // END, CR00313598
    // END, CR00077580

    reversedILIDetails.assign(iliDtls);

    reversedILIDetails.unprocessedAmount = iliDtls.amount;
    reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
    reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
    reversedILIDetails.financialCompID = 0;
    reversedILIDetails.effectiveDate = Date.getCurrentDate();
    reversedILIDetails.statusCode = ILISTATUS.UNPROCESSED;
    reversedILIDetails.finInstructionID = 0;
    reversedILIDetails.creditDebitType = CREDITDEBIT.CREDIT;

    reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
      reversedILIDetails);

    // Relate this reversal ILI to the deduction payment ILI it is reversing
    // BEGIN, CR00077580, CW
    maintainInstructionLineItemObj.createReversalILIRelationship(
      iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
    // END, CR00077580
  }

  // END, HARP 60499

  // BEGIN, CR00018488, KH
  // ___________________________________________________________________________
  /**
   * This method reverses a deduction payment instruction line item without
   * reversing the corresponding deduction item. This is required when
   * canceling a third party payment.
   *
   * @param iliDtls Instruction Line Item Details.
   * @param revFinInstrID ID of the reversal Financial Instruction.
   */
  public void reverseThirdPartyDeductionPayment(
    InstructionLineItemDtls iliDtls, FinInstructionID revFinInstrID)
    throws AppException, InformationalException {
    // END, CR00018488

    // Reversal instruction line item details and identifier
    InstructionLineItemDetails reversedILIDetails = new InstructionLineItemDetails();
    InstructionLineItemID reversedILIid;

    // maintainInstructionLineItem manipulation variable
    MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

    // BEGIN, CR00077580, CW
    // update the status on the ILI to REVERSED
    maintainInstructionLineItemObj.setReversedILIStatus(iliDtls);
    // END, CR00077580

    // Reverse this third party payment ILI

    // Set reversal details
    reversedILIDetails.assign(iliDtls);

    reversedILIDetails.instructLineItemCategory = ILICATEGORY.REVERSALINSTRUCTION;
    reversedILIDetails.instructionLineItemType = ILITYPE.ALLOCATEDREVERSAL;
    reversedILIDetails.financialCompID = 0;
    reversedILIDetails.effectiveDate = Date.getCurrentDate();
    reversedILIDetails.statusCode = ILISTATUS.PROCESSED;
    // BEGIN, CR00018488, KH
    reversedILIDetails.finInstructionID = revFinInstrID.finInstructionID;
    // END, CR00018488
    reversedILIDetails.creditDebitType = CREDITDEBIT.CREDIT;
    reversedILIDetails.instrumentGenInd = false;

    reversedILIid = maintainInstructionLineItemObj.addInstructionLineItem(
      reversedILIDetails);

    // Relate this reversal ILI to the deduction payment ILI it is reversing
    // BEGIN, CR00077580, CW
    maintainInstructionLineItemObj.createReversalILIRelationship(
      iliDtls.instructLineItemID, reversedILIid.instructionLineItemID);
    // END, CR00077580
  }

  // END, CR00002146

  // BEGIN, CR00265470, ZV
  /**
   * This method returns the appropriate caseID for the given finInstructionID.
   * @param finInstructionID
   *
   * @return Associated caseID.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link curam.core.impl.CreateCancellation#getCaseIDForFinInstructionId()}.
   */
  @Deprecated
  protected long getCaseIDForFinInstructionId(long finInstructionID)
    throws AppException, InformationalException {
    ILIFinInstructID iliFinInstructID = new ILIFinInstructID();

    iliFinInstructID.finInstructionID = finInstructionID;

    InstructionLineItemDtlsList originalILIDtlsList = InstructionLineItemFactory.newInstance().searchByFinInstructID(
      iliFinInstructID);
    long finInstructionCaseID = 0;

    // Loop through the ILI list to find the first non zero case id
    for (int i = 0; i < originalILIDtlsList.dtls.size(); i++) {
      if (originalILIDtlsList.dtls.item(i).caseID != 0) {
        finInstructionCaseID = originalILIDtlsList.dtls.item(i).caseID;
        break;
      }
    }
    return finInstructionCaseID;
  }
  // END, CR00265470
}
