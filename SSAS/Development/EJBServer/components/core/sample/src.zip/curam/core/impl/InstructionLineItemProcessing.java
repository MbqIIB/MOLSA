/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CREDITDEBIT;
import curam.codetable.ILISTATUS;
import curam.codetable.ILITYPE;
import curam.core.fact.AllocateCreditFactory;
import curam.core.fact.CaseDeductionItemFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.MaintainInstructionLineItemFactory;
import curam.core.intf.AllocateCredit;
import curam.core.intf.InstructionLineItem;
import curam.core.intf.MaintainInstructionLineItem;
import curam.core.sl.fact.CaseDeductionHistoryFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.struct.CaseDeductionHistoryDetails;
import curam.core.sl.struct.CaseIDKey;
import curam.core.struct.AllocateDeductionDetails;
import curam.core.struct.AllocatedAmt;
import curam.core.struct.CaseDeductionItemDtls;
import curam.core.struct.CaseDeductionItemFinCompID;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseIDStatusCodeCreditDebitType;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.DeductionILIVersionNo;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.ILICaseIDCreditDebitType;
import curam.core.struct.ILIFinInstructIDversNo;
import curam.core.struct.ILIStatusCode;
import curam.core.struct.InstructionLineItemDetails;
import curam.core.struct.InstructionLineItemDtls;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.InstructionLineItemID;
import curam.core.struct.InstructionLineItemKey;
import curam.core.struct.InstructionLineItemRelationDtls;
import curam.core.struct.NextAdjustmentDate;
import curam.core.struct.PaymentReceivedInstructionDtls;
import curam.core.struct.PmtReceivedInstructionDetails;
import curam.core.struct.PmtRecvFinInstructionID;
import curam.core.struct.PrimaryILIidTypeCode;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.StatusCodeUnprocessedAmt;
import curam.core.struct.StatusFinInstructIDUnprocAmt;
import curam.core.struct.SumUnallocatedAmt;
import curam.message.BPOCASEEVENTS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import curam.util.type.Money;


/**
 * This class contains methods used by ProcessInstructionLineItem
 * to process different types of InstructionLineItems.
 *
 */
public abstract class InstructionLineItemProcessing extends curam.core.base.InstructionLineItemProcessing {

  // BEGIN, CR00119605, MR
  // Add injection for using the new CaseTransactionLog API
  public InstructionLineItemProcessing() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;
  // END, CR00119605

  // allocateCredit manipulation variable
  curam.core.intf.AllocateCredit allocateCreditObj = curam.core.fact.AllocateCreditFactory.newInstance();

  // createPaymentReceived manipulation variable
  curam.core.intf.CreatePaymentReceived createPaymentReceivedObj = curam.core.fact.CreatePaymentReceivedFactory.newInstance();

  // instruction line item manipulation variable
  curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();

  // ___________________________________________________________________________
  /**
   * Processes an instruction line item for a payment received. The case that
   * the payment relates to is credited with the amount repaid. If this is
   * the first repayment then a new payment received instruction is created.
   *
   * @param instructionLineItemDtls The repayment instruction line item details
   *
   * @return The number of new payment received instructions that were created
   */
  public int processPaymentReceived(InstructionLineItemDtls
    instructionLineItemDtls)
    throws AppException, InformationalException {

    int countPmtRecvdInstructionsCreated = 0;

    FinancialInstructionDtls financialInstructionDtls = new FinancialInstructionDtls();

    // flag to indicate if a payment received instruction or instrument
    // needs to be created
    boolean firstTimeFlag = true;

    if ((instructionLineItemDtls.instructionLineItemType.equals(
      curam.codetable.ILITYPE.REPAYMENTEXPECTED))
        && (instructionLineItemDtls.amount.getValue()
          != instructionLineItemDtls.unprocessedAmount.getValue())) {

      firstTimeFlag = false;
    }

    if (firstTimeFlag) {

      // Payment received instruction details
      PmtReceivedInstructionDetails pmtReceivedInstructionDetails = new PmtReceivedInstructionDetails();

      // set payment received instruction details
      pmtReceivedInstructionDetails.concernRoleID = instructionLineItemDtls.concernRoleID;
      pmtReceivedInstructionDetails.typeCode = curam.codetable.PMTINSTRMETHODOFRECEIPT.DEDUCTION;
      pmtReceivedInstructionDetails.amount = instructionLineItemDtls.amount;
      pmtReceivedInstructionDetails.effectiveDate = instructionLineItemDtls.effectiveDate;
      pmtReceivedInstructionDetails.receivedDate = curam.util.type.Date.getCurrentDate();
      pmtReceivedInstructionDetails.currencyTypeCode = instructionLineItemDtls.currencyTypeCode;
      pmtReceivedInstructionDetails.currencyExchangeID = instructionLineItemDtls.currencyExchangeID;
      pmtReceivedInstructionDetails.instrumentGenInd = false;

      // BEGIN, CR00049218, GM
      pmtReceivedInstructionDetails.comments = CuramConst.gkEmpty;
      // END, CR00049218
      // create payment received instruction
      financialInstructionDtls = createPaymentReceivedObj.createPaymentReceivedInstruction(
        pmtReceivedInstructionDetails);

      countPmtRecvdInstructionsCreated++;
    }

    // allocate repayment details
    allocateCreditObj.allocateRepayment(instructionLineItemDtls);

    if (firstTimeFlag) {

      // instructionLineItem manipulation variables
      InstructionLineItemKey iliKey = new InstructionLineItemKey();

      // instructionLineItem's financial instruction identifier
      ILIFinInstructIDversNo iliFinInstructID = new ILIFinInstructIDversNo();

      // set details for ILI update
      iliKey.instructLineItemID = instructionLineItemDtls.instructLineItemID;
      iliFinInstructID.finInstructionID = financialInstructionDtls.finInstructionID;
      iliFinInstructID.versionNo = instructionLineItemDtls.versionNo;

      // update instructionLineItem
      instructionLineItemObj.modifyFinInstructID(iliKey, iliFinInstructID);
    }

    return countPmtRecvdInstructionsCreated;

  }

  // _________________________________________________________________________
  /**
   * Processes surcharge for an instruction line item
   *
   * @param instructionLineItemDtls Instruction Line Item Details to process
   *
   * @return A count of the instruction line items created
   */
  public int processSurcharge(InstructionLineItemDtls instructionLineItemDtls)
    throws AppException, InformationalException {

    final double kSurchargeRate = 0.1;

    int countSurILIsCreated = 0;

    // Surcharge date increment by days
    final int kSurchageDateIncrement = 1;

    // surcharge period from
    curam.util.type.Date surchargeDateFrom;

    // surcharge amount
    curam.util.type.Money surchargeAmount = curam.util.type.Money.kZeroMoney;

    // zero value used for attribute initialization
    short stBlankValue = 0;

    // calculate surchargeDateFrom
    surchargeDateFrom = new curam.util.type.FrequencyPattern(instructionLineItemDtls.adjustmentFrequency).getPrevOccurrence(
      instructionLineItemDtls.nextAdjustmentDate);

    // move surchargedateFrom forwards by 1 day
    surchargeDateFrom = surchargeDateFrom.addDays(kSurchageDateIncrement);

    surchargeAmount = new curam.util.type.Money(
      instructionLineItemDtls.amount.getValue() * kSurchargeRate);

    // Instruction line item details and identifier
    InstructionLineItemDetails surILIDetails = new InstructionLineItemDetails();
    InstructionLineItemID surILIID;

    // maintainInstructionLineItem manipulation variable
    curam.core.intf.MaintainInstructionLineItem maintainInstructionLineItemObj = curam.core.fact.MaintainInstructionLineItemFactory.newInstance();

    // set surcharge ILI details
    surILIDetails.amount = surchargeAmount;
    surILIDetails.unprocessedAmount = new curam.util.type.Money(surchargeAmount);
    surILIDetails.instructLineItemCategory = curam.codetable.ILICATEGORY.LIABILITYINSTRUCTION;
    surILIDetails.financialCompID = stBlankValue;
    surILIDetails.instructionLineItemType = curam.codetable.ILITYPE.SURCHARGELIABILITY;
    surILIDetails.coverPeriodFrom = surchargeDateFrom;
    surILIDetails.coverPeriodTo = instructionLineItemDtls.nextAdjustmentDate;
    surILIDetails.effectiveDate = curam.util.type.Date.getCurrentDate();
    surILIDetails.statusCode = curam.codetable.ILISTATUS.UNPROCESSED;
    surILIDetails.caseID = instructionLineItemDtls.caseID;
    surILIDetails.finInstructionID = stBlankValue;
    surILIDetails.concernRoleID = instructionLineItemDtls.concernRoleID;
    surILIDetails.caseNomineeID = instructionLineItemDtls.caseNomineeID;
    surILIDetails.primaryClientID = instructionLineItemDtls.primaryClientID;
    surILIDetails.deliveryMethodType = instructionLineItemDtls.deliveryMethodType;
    surILIDetails.creditDebitType = curam.codetable.CREDITDEBIT.DEBIT;
    surILIDetails.currencyTypeCode = instructionLineItemDtls.currencyTypeCode;
    surILIDetails.currencyExchangeID = instructionLineItemDtls.currencyExchangeID;
    surILIDetails.adjustmentInd = false;
    surILIDetails.adjustmentFrequency = curam.util.type.FrequencyPattern.kZeroFrequencyPattern.toString();

    surILIDetails.nextAdjustmentDate = curam.util.type.Date.kZeroDate;

    surILIDetails.instrumentGenInd = instructionLineItemDtls.instrumentGenInd;
    surILIDetails.fundID = instructionLineItemDtls.fundID;
    // BEGIN, CR00074927, JI
    surILIDetails.dueDate = curam.util.type.Date.getCurrentDate();
    surILIDetails.inRespectOfID = 0;
    // END, CR00074927

    // add surcharge instructionLineItem
    surILIID = maintainInstructionLineItemObj.addInstructionLineItem(
      surILIDetails);

    // Relate the surcharge instruction line item record to the product
    // delivery instruction line item from which it was calculated

    // instructionLineItemRelation manipulation variables
    InstructionLineItemRelationDtls surILIRelationDtls = new InstructionLineItemRelationDtls();
    curam.core.intf.InstructionLineItemRelation instructionLineItemRelationObj = curam.core.fact.InstructionLineItemRelationFactory.newInstance();

    // set surcharge ILI Relation details
    surILIRelationDtls.instructLineItemRelatID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();
    surILIRelationDtls.instructLineItemID = instructionLineItemDtls.instructLineItemID;
    surILIRelationDtls.relatedLineItemID = surILIID.instructionLineItemID;
    surILIRelationDtls.typeCode = curam.codetable.ILIRELATIONSHIP.SURCHARGES;
    surILIRelationDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();

    // insert instructionLineItemRelation
    instructionLineItemRelationObj.insert(surILIRelationDtls);

    // instructionLineItem manipulation variables
    InstructionLineItemKey iliKey = new InstructionLineItemKey();
    curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();

    // Instruction line item next adjustment date
    NextAdjustmentDate iliNextAdjustmentDate = new NextAdjustmentDate();

    // set ILI key
    iliKey.instructLineItemID = instructionLineItemDtls.instructLineItemID;

    // set ILI next adjustment date details
    iliNextAdjustmentDate.nextAdjustmentDate = new curam.util.type.FrequencyPattern(instructionLineItemDtls.adjustmentFrequency).getNextOccurrence(
      instructionLineItemDtls.nextAdjustmentDate);
    iliNextAdjustmentDate.versionNo = instructionLineItemDtls.versionNo;

    // modify instructionLineItem
    instructionLineItemObj.modifyNextAdjustmentDate(iliKey,
      iliNextAdjustmentDate);

    return ++countSurILIsCreated;

  }

  // _________________________________________________________________________
  /**
   * Processes interest for an instruction line item
   *
   * @param instructionLineItemDtls Instruction Line Item Details to process
   *
   * @return A count of the instruction line items created
   */
  public int processInterest(InstructionLineItemDtls instructionLineItemDtls)
    throws AppException, InformationalException {

    int countIntILIsCreated = 0;

    // initialize interestFromDate to zero date
    curam.util.type.Date interestDateFrom = curam.util.type.Date.kZeroDate;

    if (instructionLineItemDtls.nextAdjustmentDate.isZero()) {
      // calculate the interest date
      calculateInterestDate(instructionLineItemDtls);
    } else {

      // caseHeader manipulation variables
      curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      // ProductDelivery manipulation variables
      curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
      ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      ProductDeliveryTypeDetails productDeliveryTypeDetails;

      productDeliveryKey.caseID = instructionLineItemDtls.caseID;

      try {
        // Read product delivery details
        productDeliveryTypeDetails = productDeliveryObj.readProductType(
          productDeliveryKey);

        if (productDeliveryTypeDetails.productType.equals(
          curam.codetable.PRODUCTTYPE.LOAN)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOPROCESSINSTRUCTIONLINEITEM.ERR_PRODUCT_LOAN_UNIMPLEMENTED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);

        }
      } catch (curam.util.exception.RecordNotFoundException e) {// Ignore exception -
        // case can have other than "product delivery" type
      }

      // Read case header
      caseHeaderKey.caseID = instructionLineItemDtls.caseID;
      CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      try {

        // calculate interestDateFrom
        interestDateFrom = new curam.util.type.FrequencyPattern(instructionLineItemDtls.adjustmentFrequency).getPrevOccurrence(
          instructionLineItemDtls.nextAdjustmentDate);

        if (interestDateFrom.before(caseHeaderDtls.startDate)) {
          interestDateFrom = caseHeaderDtls.startDate;
        }

        // calculating number of days for which the daily interest must
        // be applied
        int totalDays;

        totalDays = interestDateFrom.subtract(
          instructionLineItemDtls.nextAdjustmentDate);

        // moving forward date by one day
        interestDateFrom = interestDateFrom.addDays(1);

        // BEGIN, CR00092828, CW
        // Get the interest amount for the ILI being processed
        Money interestAmount = getInterestAmountForILI(instructionLineItemDtls,
          totalDays);
        // END, CR00092828

        // instructionLineItem manipulation variables
        InstructionLineItemDetails intILIDtls = new InstructionLineItemDetails();
        InstructionLineItemID intILIid;

        // set interest ILI details
        // BEGIN, CR00092828, CW
        intILIDtls.amount = interestAmount;
        intILIDtls.unprocessedAmount = interestAmount;
        // END, CR00092828
        intILIDtls.instructLineItemCategory = curam.codetable.ILICATEGORY.LIABILITYINSTRUCTION;
        intILIDtls.financialCompID = 0;
        intILIDtls.instructionLineItemType = curam.codetable.ILITYPE.INTERESTAPPLIED;
        intILIDtls.coverPeriodFrom = interestDateFrom;
        intILIDtls.coverPeriodTo = instructionLineItemDtls.nextAdjustmentDate;
        intILIDtls.effectiveDate = curam.util.type.Date.getCurrentDate();
        intILIDtls.statusCode = curam.codetable.ILISTATUS.PROCESSED;
        intILIDtls.caseID = instructionLineItemDtls.caseID;
        intILIDtls.finInstructionID = 0;
        intILIDtls.concernRoleID = instructionLineItemDtls.concernRoleID;
        intILIDtls.caseNomineeID = instructionLineItemDtls.caseNomineeID;
        intILIDtls.primaryClientID = instructionLineItemDtls.primaryClientID;
        intILIDtls.deliveryMethodType = instructionLineItemDtls.deliveryMethodType;
        intILIDtls.creditDebitType = curam.codetable.CREDITDEBIT.DEBIT;
        intILIDtls.currencyTypeCode = instructionLineItemDtls.currencyTypeCode;
        intILIDtls.currencyExchangeID = instructionLineItemDtls.currencyExchangeID;
        intILIDtls.adjustmentInd = false;
        intILIDtls.adjustmentFrequency = curam.util.type.FrequencyPattern.kZeroFrequencyPattern.toString();
        intILIDtls.nextAdjustmentDate = curam.util.type.Date.kZeroDate;
        intILIDtls.instrumentGenInd = instructionLineItemDtls.instrumentGenInd;
        intILIDtls.fundID = instructionLineItemDtls.fundID;
        // BEGIN, CR00074927, JI
        intILIDtls.dueDate = curam.util.type.Date.getCurrentDate();
        intILIDtls.inRespectOfID = 0;
        // END, CR00074927

        // uniqueID manipulation variable
        curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

        // maintainInstructionLineItem manipulation variable
        curam.core.intf.MaintainInstructionLineItem maintainInstructionLineItemObj = curam.core.fact.MaintainInstructionLineItemFactory.newInstance();

        // instructionLineItemRelation manipulation variable
        curam.core.intf.InstructionLineItemRelation instructionLineItemRelationObj = curam.core.fact.InstructionLineItemRelationFactory.newInstance();

        // add instructionLineItem
        intILIid = maintainInstructionLineItemObj.addInstructionLineItem(
          intILIDtls);

        // relate the interest instruction line item record to the product
        // delivery instruction line item from which it was calculated

        // instructionLineItemRelation manipulation variable
        InstructionLineItemRelationDtls intILIRelDtls = new InstructionLineItemRelationDtls();

        // set interest ILI Relation details
        intILIRelDtls.instructLineItemRelatID = uniqueIDObj.getNextID();
        intILIRelDtls.instructLineItemID = instructionLineItemDtls.instructLineItemID;
        intILIRelDtls.relatedLineItemID = intILIid.instructionLineItemID;
        intILIRelDtls.typeCode = curam.codetable.ILIRELATIONSHIP.INTEREST;
        intILIRelDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();

        // insert instructionLineItemRelation
        instructionLineItemRelationObj.insert(intILIRelDtls);

        // instructionLineItemRelation manipulation variables
        InstructionLineItemKey iliKey = new InstructionLineItemKey();
        curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();
        NextAdjustmentDate iliNextAdjustDate = new NextAdjustmentDate();

        // set ILI key for update
        iliKey.instructLineItemID = instructionLineItemDtls.instructLineItemID;

        // set ILI next adjustment date for update
        iliNextAdjustDate.nextAdjustmentDate = new curam.util.type.FrequencyPattern(instructionLineItemDtls.adjustmentFrequency).getNextOccurrence(
          instructionLineItemDtls.nextAdjustmentDate);
        iliNextAdjustDate.versionNo = instructionLineItemDtls.versionNo;

        // update instructionLineItem
        instructionLineItemObj.modifyNextAdjustmentDate(iliKey,
          iliNextAdjustDate);

        countIntILIsCreated++;

      } catch (curam.util.exception.RecordNotFoundException e) {// If no evidence is recorded, exit here, returning 0.
        // i.e. we did not process any line items
      }
    }

    return countIntILIsCreated;
  }

  // _________________________________________________________________________
  /**
   * Processes a tax group for an instruction line item
   *
   * @param instructionLineItemDtls Instruction Line Item Details
   * @param finInstructionID the financialInstruction id for update
   *
   * @return int A count of the instruction line items created
   */
  public int processTaxGroup(
    InstructionLineItemDtls instructionLineItemDtls,
    long finInstructionID)
    throws AppException, InformationalException {

    int countILIsProcessed = 0;
    // zero money amount
    curam.util.type.Money zeroMoney = curam.util.type.Money.kZeroMoney;

    // instructionLineItem manipulation variables
    InstructionLineItemKey iliKey = new InstructionLineItemKey();
    curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();

    // set ILI key for update
    iliKey.instructLineItemID = instructionLineItemDtls.instructLineItemID;

    // Unprocessed amount date status
    StatusFinInstructIDUnprocAmt statusFIIDUnprocAmt = new StatusFinInstructIDUnprocAmt();

    // set ILI details for update
    statusFIIDUnprocAmt.statusCode = curam.codetable.ILISTATUS.PROCESSED;
    statusFIIDUnprocAmt.unprocessedAmount = zeroMoney;
    statusFIIDUnprocAmt.finInstructionID = finInstructionID;
    statusFIIDUnprocAmt.versionNo = instructionLineItemDtls.versionNo;

    // update instructionLineItem
    instructionLineItemObj.modifyStatusFinInstructIDUnprocAmt(iliKey,
      statusFIIDUnprocAmt);

    return ++countILIsProcessed;
  }

  // _________________________________________________________________________
  /**
   * Deduction Payment Processing for an instruction line item
   *
   * @param instructionLineItemDtls Instruction Line Item Details
   *
   * @return A count of the instruction line items created
   */
  public int processDeductionLineGroup(InstructionLineItemDtls
    instructionLineItemDtls)
    throws AppException, InformationalException {

    int countILIsProcessed = 0;

    // createPaymentReceived manipulation variable
    curam.core.intf.CreatePaymentReceived createPaymentReceivedObj = curam.core.fact.CreatePaymentReceivedFactory.newInstance();

    // instructionLineItem manipulation variable
    curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();

    // financialInstruction manipulation variable
    FinancialInstructionDtls financialInstructionDtls = new FinancialInstructionDtls();

    // initialize firstTimeFlag to true
    boolean firstTimeFlag = true;

    if (instructionLineItemDtls.amount.getValue()
      != instructionLineItemDtls.unprocessedAmount.getValue()) {

      firstTimeFlag = false;
    }

    if (firstTimeFlag) {

      // paymentReceivedInstruction manipulation variable
      PmtReceivedInstructionDetails pmtReceivedInstructionDetails = new PmtReceivedInstructionDetails();

      // set paymentReceivedInstruction details
      pmtReceivedInstructionDetails.concernRoleID = instructionLineItemDtls.concernRoleID;
      pmtReceivedInstructionDetails.typeCode = curam.codetable.PMTINSTRMETHODOFRECEIPT.DEDUCTION;
      pmtReceivedInstructionDetails.amount = instructionLineItemDtls.amount;
      pmtReceivedInstructionDetails.effectiveDate = instructionLineItemDtls.effectiveDate;
      pmtReceivedInstructionDetails.receivedDate = curam.util.type.Date.getCurrentDate();
      pmtReceivedInstructionDetails.currencyTypeCode = instructionLineItemDtls.currencyTypeCode;
      pmtReceivedInstructionDetails.currencyExchangeID = instructionLineItemDtls.currencyExchangeID;
      pmtReceivedInstructionDetails.instrumentGenInd = false;

      // BEGIN, CR00049218, GM
      pmtReceivedInstructionDetails.comments = CuramConst.gkEmpty;
      // END, CR00049218
      // create paymentReceived
      financialInstructionDtls = createPaymentReceivedObj.createPaymentReceivedInstruction(
        pmtReceivedInstructionDetails);

      // BEGIN, CR00119605, MR
      // Log Transaction Details
      if (instructionLineItemDtls.caseID != 0) {

        // populate financial instruction ID to retrieve
        // Payment Received details
        PmtRecvFinInstructionID pmtRecvFinInstructionID = new PmtRecvFinInstructionID();

        pmtRecvFinInstructionID.finInstructionID = financialInstructionDtls.finInstructionID;

        // paymentReceivedInstruction manipulation variables
        curam.core.intf.PaymentReceivedInstruction paymentReceivedInstructionObj = curam.core.fact.PaymentReceivedInstructionFactory.newInstance();
        PaymentReceivedInstructionDtls paymentReceivedInstructionDtls = new PaymentReceivedInstructionDtls();
        // set the paymentInstructionEffectiveDate to default date
        curam.util.type.Date paymentReceivedInstructionReceivedDate = curam.util.type.Date.kZeroDate;

        // get the payment Received Date
        try {
          paymentReceivedInstructionDtls = paymentReceivedInstructionObj.readByFinInstructionID(
            pmtRecvFinInstructionID);
          paymentReceivedInstructionReceivedDate = paymentReceivedInstructionDtls.receivedDate;
        } catch (curam.util.exception.RecordNotFoundException e) {// Ignore exceptions of this type
        }
        // Case Header Manipulation variables to get Case Reference Number
        curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
        CaseSearchKey caseSearchKey = new CaseSearchKey();

        // set caseId
        caseSearchKey.caseID = instructionLineItemDtls.caseID;

        // maintainCase manipulation variables to get product name
        curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();

        CaseIDKey caseIDKey = new CaseIDKey();

        // set key to read maintainCase
        caseIDKey.caseID = instructionLineItemDtls.caseID;

        CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
          caseIDKey);

        LocalisableString description = new LocalisableString(BPOCASEEVENTS.PAYMENTS_RECEIVED).arg(paymentReceivedInstructionReceivedDate).arg(caseReferenceProductNameConcernRoleName.productName).arg(
          caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);

        caseTransactionLogProvider.get().recordCaseTransaction(
          CASETRANSACTIONEVENTS.PAYMENT_RECEIVED, description,
          instructionLineItemDtls.caseID,
          financialInstructionDtls.finInstructionID);
      }
      // END, CR00119605

    }

    DeductionILIVersionNo deductionILIVersionNo = new DeductionILIVersionNo();

    if (instructionLineItemDtls.caseID != 0) {

      AllocateDeductionDetails allocateDeductionDetails = new AllocateDeductionDetails();

      allocateDeductionDetails.iliDtls = instructionLineItemDtls;

      // allocate deduction payment details
      deductionILIVersionNo = allocateDeduction(allocateDeductionDetails);
    }

    if (firstTimeFlag) {

      // instructionLineItem manipulation variables
      InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();
      ILIFinInstructIDversNo iliFinInstructID = new ILIFinInstructIDversNo();

      // set ILI key for update
      instructionLineItemKey.instructLineItemID = instructionLineItemDtls.instructLineItemID;

      // set ILI details for update
      iliFinInstructID.finInstructionID = financialInstructionDtls.finInstructionID;

      // BEGIN, CR00087931, KH
      // If we have allocated to the deduction ILI, use the new version number
      if (deductionILIVersionNo.versionNo != 0) {
        iliFinInstructID.versionNo = deductionILIVersionNo.versionNo;
      } else {
        iliFinInstructID.versionNo = instructionLineItemDtls.versionNo;
      }
      // END, CR00087931

      // update instructionLineItem
      instructionLineItemObj.modifyFinInstructID(instructionLineItemKey,
        iliFinInstructID);
    }

    return ++countILIsProcessed;

  }

  // _________________________________________________________________________
  /**
   * Method to calculate the next interest repayment date
   *
   * @param iliDtls Instruction Line Item Details
   */
  protected void calculateInterestDate(InstructionLineItemDtls iliDtls)
    throws AppException, InformationalException {

    // instructionLineItemRelation manipulation variables
    curam.core.intf.InstructionLineItemRelation instructionLineItemRelationObj = curam.core.fact.InstructionLineItemRelationFactory.newInstance();
    curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();
    PrimaryILIidTypeCode primaryILIidTypeCode = new PrimaryILIidTypeCode();
    InstructionLineItemRelationDtls iliRelDtls;

    // set key to read instructionLineItemRelation entity
    primaryILIidTypeCode.instructLineItemID = iliDtls.instructLineItemID;
    primaryILIidTypeCode.typeCode = curam.codetable.ILIRELATIONSHIP.LOANLIABILITY;

    // read instructionLineItemRelation entity
    iliRelDtls = instructionLineItemRelationObj.readByInstLineItemIDTypeCode(
      primaryILIidTypeCode);

    // instructionLineItem manipulation variables
    InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();
    InstructionLineItemDtls iliLoanPmtDtls;

    // set key to read instructionLineItem entity
    instructionLineItemKey.instructLineItemID = iliRelDtls.relatedLineItemID;

    // read instructionLineItem entity
    iliLoanPmtDtls = instructionLineItemObj.read(instructionLineItemKey);

    // instructionLineItem manipulation variables
    InstructionLineItemKey iliKey = new InstructionLineItemKey();
    NextAdjustmentDate iliNextAdjustmentDate = new NextAdjustmentDate();

    // set ILI key for update
    iliKey.instructLineItemID = iliDtls.instructLineItemID;

    // set ILI next adjustment date for update
    iliNextAdjustmentDate.nextAdjustmentDate = new curam.util.type.FrequencyPattern(iliDtls.adjustmentFrequency).getNextOccurrence(
      iliLoanPmtDtls.effectiveDate);
    iliNextAdjustmentDate.versionNo = iliDtls.versionNo;

    // update instructionLineItem entity
    instructionLineItemObj.modifyNextAdjustmentDate(iliKey,
      iliNextAdjustmentDate);
  }

  // _________________________________________________________________________
  /**
   * Allocates applied deduction against related liability
   *
   * @param details Deduction payment ILI details
   * @return deduction payment ILI version number
   */
  public DeductionILIVersionNo allocateDeduction(
    AllocateDeductionDetails details)
    throws AppException, InformationalException {

    // Return object
    DeductionILIVersionNo deductionILIVersionNo = new DeductionILIVersionNo();

    // AllocateCredit object
    AllocateCredit allocateCreditObj = AllocateCreditFactory.newInstance();

    // InstructionLineItem manipulation variables
    InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
    InstructionLineItemDtlsList iliDtlsList;
    CaseIDStatusCodeCreditDebitType caseIDStatusCodeCreditDebitType = new CaseIDStatusCodeCreditDebitType();
    InstructionLineItemKey iliKey = new InstructionLineItemKey();

    StatusCodeUnprocessedAmt statusCodeUnprocessedAmt = new StatusCodeUnprocessedAmt();

    AllocatedAmt allocatedAmt = new AllocatedAmt();
    AllocatedAmt availableAmt = new AllocatedAmt();

    allocatedAmt.amount = details.iliDtls.unprocessedAmount;
    availableAmt.amount = details.iliDtls.unprocessedAmount;

    // Retrieve debit ILIs
    caseIDStatusCodeCreditDebitType.caseID = details.iliDtls.caseID;
    caseIDStatusCodeCreditDebitType.statusCode = ILISTATUS.PROCESSED;
    caseIDStatusCodeCreditDebitType.creditDebitType = CREDITDEBIT.DEBIT;

    iliDtlsList = instructionLineItemObj.searchByCaseIDStatusCodeCreditDebitType(
      caseIDStatusCodeCreditDebitType);

    int counter = iliDtlsList.dtls.size();
    
    for (int i = 0; i < iliDtlsList.dtls.size(); i++) {

      if (iliDtlsList.dtls.item(i).unprocessedAmount.isPositive()
        && allocatedAmt.amount.isPositive()) {

        if (iliDtlsList.dtls.item(i).unprocessedAmount.getValue()
          < allocatedAmt.amount.getValue()) {

          allocatedAmt.amount = iliDtlsList.dtls.item(i).unprocessedAmount;
        }

        allocateCreditObj.updateDebitAllocations(details.iliDtls,
          iliDtlsList.dtls.item(i), allocatedAmt);
        
        availableAmt.amount = new Money(
          availableAmt.amount.getValue() - allocatedAmt.amount.getValue());
        allocatedAmt.amount = availableAmt.amount;
      }

      counter--;

      if (counter == 0) {

        // We know we're going to over-allocate even if allocatedAmt.amount
        // is positive, so update credit ILI to 'Allocated' with an
        // unprocessed amount of zero
        statusCodeUnprocessedAmt.unprocessedAmount = Money.kZeroMoney;
        statusCodeUnprocessedAmt.statusCode = ILISTATUS.ALLOCATED;
        statusCodeUnprocessedAmt.versionNo = details.iliDtls.versionNo;

        iliKey.instructLineItemID = details.iliDtls.instructLineItemID;

        instructionLineItemObj.modifyStatusUnprocessedAmt(iliKey,
          statusCodeUnprocessedAmt);

        if (allocatedAmt.amount.isPositive()) {

          // Over-allocate deduction payment
          // allocateCreditObj.overallocateCreditTransaction(iliDeductionDtls,
          // iliDtlsList.dtls.item(i), allocatedAmt);
          // maintainInstructionLineItem manipulation variables
          MaintainInstructionLineItem maintainInstructionLineItemObj = MaintainInstructionLineItemFactory.newInstance();

          // instructionLineItem manipulation variables
          InstructionLineItemDetails iliDetails = new InstructionLineItemDetails();
          InstructionLineItemDtls allocatedILI = new InstructionLineItemDtls();
          InstructionLineItemID iliID;

          // Create InstructionLineItem
          iliDetails.amount = allocatedAmt.amount;
          iliDetails.unprocessedAmount = allocatedAmt.amount;
          iliDetails.instructionLineItemType = ILITYPE.OVERALLOCATION;
          iliDetails.statusCode = ILISTATUS.PROCESSED;
          iliDetails.creditDebitType = CREDITDEBIT.CREDIT;

          iliDetails.instructLineItemCategory = details.iliDtls.instructLineItemCategory;
          iliDetails.financialCompID = details.iliDtls.financialCompID;
          iliDetails.effectiveDate = details.iliDtls.effectiveDate;
          iliDetails.finInstructionID = details.iliDtls.finInstructionID;
          iliDetails.concernRoleID = details.iliDtls.concernRoleID;
          iliDetails.deliveryMethodType = details.iliDtls.deliveryMethodType;
          iliDetails.currencyTypeCode = details.iliDtls.currencyTypeCode;
          iliDetails.currencyExchangeID = details.iliDtls.currencyExchangeID;
          iliDetails.adjustmentInd = details.iliDtls.adjustmentInd;
          iliDetails.adjustmentFrequency = details.iliDtls.adjustmentFrequency;
          iliDetails.nextAdjustmentDate = details.iliDtls.nextAdjustmentDate;
          iliDetails.instrumentGenInd = details.iliDtls.instrumentGenInd;
          iliDetails.coverPeriodFrom = iliDtlsList.dtls.item(i).coverPeriodFrom;
          iliDetails.coverPeriodTo = iliDtlsList.dtls.item(i).coverPeriodTo;
          iliDetails.caseID = iliDtlsList.dtls.item(i).caseID;
          iliDetails.caseNomineeID = iliDtlsList.dtls.item(i).caseNomineeID;
          iliDetails.primaryClientID = iliDtlsList.dtls.item(i).primaryClientID;
          iliDetails.fundID = iliDtlsList.dtls.item(i).fundID;
          // BEGIN, CR00074927, JI
          iliDetails.dueDate = curam.util.type.Date.getCurrentDate();
          iliDetails.inRespectOfID = 0;
          // END, CR00074927
 
          // add instructionLineItem
          iliID = maintainInstructionLineItemObj.addInstructionLineItem(
            iliDetails);
          // Mapping one-to-one the from iliDetails to allocatedILI
          allocatedILI.assign(iliDetails);

          // Mapping versionNo to allocatedILI
          allocatedILI.versionNo = iliID.versionNo;
          allocatedILI.instructLineItemID = iliID.instructionLineItemID;
          // Creating an Allocation between this new Payment Received ILI and
          // the debit
          allocateCreditObj.updateDebitAllocations(allocatedILI,
            iliDtlsList.dtls.item(i), allocatedAmt);
        }                           
      }
    }
        
    // BEGIN, CR00172665, JMA
    // Check to see if Liability case has been cleared
    // InstructionLineItem manipulation variables
    ILICaseIDCreditDebitType liabilityILICaseIDCreditDebitType = new ILICaseIDCreditDebitType();

    // Retrieve outstanding balance on specified liability case
    liabilityILICaseIDCreditDebitType.caseID = details.iliDtls.caseID;
    liabilityILICaseIDCreditDebitType.creditDebitType = CREDITDEBIT.DEBIT;

    SumUnallocatedAmt sumUnallocatedAmt = instructionLineItemObj.readSumUnprocessedAmtByCaseIDCreditDebitType(
      liabilityILICaseIDCreditDebitType);
    
    // if outstanding balance is zero liability case has been cleared
    // create a liability cleared deduction history record
    if (sumUnallocatedAmt.amount.isZero()) {
      
      CaseDeductionItemFinCompID caseDeductionItemFinCompID = new CaseDeductionItemFinCompID();

      caseDeductionItemFinCompID.financialCompID = details.iliDtls.financialCompID;
    
      CaseDeductionItemDtls caseDeductionItemDtls = CaseDeductionItemFactory.newInstance().readByFinancialCompID(
        caseDeductionItemFinCompID);          

      // Populate details struct to create a case deduction history record
      CaseDeductionHistoryDetails caseDeductionHistoryDetails = new CaseDeductionHistoryDetails();     
      
      caseDeductionHistoryDetails.dtls.caseDeductionItemID = caseDeductionItemDtls.caseDeductionItemID;
      
      caseDeductionHistoryDetails.dtls.comments = caseDeductionItemDtls.comments;
      caseDeductionHistoryDetails.dtls.priority = caseDeductionItemDtls.priority;
      
      // We want to find the amount of the deduction that was applied to clear the deduction
      if (allocatedAmt.amount.isPositive()) {
        
        // if allocated amount is positive then the deduction was greater 
        // than outstanding liability
        caseDeductionHistoryDetails.dtls.amount = new Money(
          details.iliDtls.amount.getValue() - allocatedAmt.amount.getValue());
        
      } else {
        
        caseDeductionHistoryDetails.dtls.amount = details.iliDtls.amount;
        
      }      
           
      // Create a case deduction history record
      CaseDeductionHistoryFactory.newInstance().createLiabilityClearedHistory(
        caseDeductionHistoryDetails);
      // END, CR00172665            
    }

    deductionILIVersionNo.versionNo = statusCodeUnprocessedAmt.versionNo;

    return deductionILIVersionNo;
  }

  // BEGIN, CR00069071, CW
  // BEGIN, CR00079189, CW
  // _________________________________________________________________________
  /**
   * Pre-transfer processing.
   * Currently does nothing as we do not allocate deductions for ERP systems.
   *
   * @param details Deduction payment ILI details
   * @return deduction payment ILI version number
   */
  public DeductionILIVersionNo allocateDeductionForTransfer(
    AllocateDeductionDetails details) throws AppException,
      InformationalException {

    //
    // Do Nothing:: do not allocate deductions for ERP systems
    //

    // Return dummy object
    DeductionILIVersionNo deductionILIVersionNo = new DeductionILIVersionNo();

    return deductionILIVersionNo;
  }

  // END, CR00079189
  // END, CR00069071

  // BEGIN, CR00069071, CW
  // BEGIN, CR00081370, CW
  // BEGIN, CR00092828, CW
  // _________________________________________________________________________
  /**
   * This method is invoked for ERP systems only.
   * Processes interest for a pre-transfer instruction line item.
   *
   * @param instructionLineItemDtls Instruction Line Item Details to process
   *
   * @return InstructionLineItemDtls the interest instruction line item if one
   * was created.
   */
  public InstructionLineItemDtls processInterestForTransfer
    (InstructionLineItemDtls instructionLineItemDtls)
    throws AppException, InformationalException {

    // return value: this will get populated with interest instruction line item
    // details if an interest ILI is created
    InstructionLineItemDtls interestILI = new InstructionLineItemDtls();
    // END, CR00092828

    // initialize interestFromDate to zero date
    curam.util.type.Date interestDateFrom = curam.util.type.Date.kZeroDate;

    if (instructionLineItemDtls.nextAdjustmentDate.isZero()) {
      // calculate the interest date
      calculateInterestDate(instructionLineItemDtls);
    } else {

      // caseHeader manipulation variables
      curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      // ProductDelivery manipulation variables
      curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
      ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      ProductDeliveryTypeDetails productDeliveryTypeDetails;

      productDeliveryKey.caseID = instructionLineItemDtls.caseID;

      try {
        // Read product delivery details
        productDeliveryTypeDetails = productDeliveryObj.readProductType(
          productDeliveryKey);

        if (productDeliveryTypeDetails.productType.equals(
          curam.codetable.PRODUCTTYPE.LOAN)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOPROCESSINSTRUCTIONLINEITEM.ERR_PRODUCT_LOAN_UNIMPLEMENTED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);

        }
      } catch (curam.util.exception.RecordNotFoundException e) {// Ignore exception -
        // case can have other than "product delivery" type
      }

      // Read case header
      caseHeaderKey.caseID = instructionLineItemDtls.caseID;
      CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      try {

        // calculate interestDateFrom
        interestDateFrom = new curam.util.type.FrequencyPattern(instructionLineItemDtls.adjustmentFrequency).getPrevOccurrence(
          instructionLineItemDtls.nextAdjustmentDate);

        if (interestDateFrom.before(caseHeaderDtls.startDate)) {
          interestDateFrom = caseHeaderDtls.startDate;
        }

        // calculating number of days for which the daily interest must
        // be applied
        int totalDays;

        totalDays = interestDateFrom.subtract(
          instructionLineItemDtls.nextAdjustmentDate);

        // moving forward date by one day
        interestDateFrom = interestDateFrom.addDays(1);

        // BEGIN, CR00092828, CW
        // Get the interest amount for the ILI being processed
        Money interestAmount = getInterestAmountForILI(instructionLineItemDtls,
          totalDays);
        // END, CR00092828

        // instructionLineItem manipulation variables
        InstructionLineItemDetails intILIDtls = new InstructionLineItemDetails();
        InstructionLineItemID intILIid;

        // set interest ILI details
        // BEGIN, CR00092828, CW
        intILIDtls.amount = interestAmount;
        intILIDtls.unprocessedAmount = interestAmount;
        // END, CR00092828
        intILIDtls.instructLineItemCategory = curam.codetable.ILICATEGORY.LIABILITYINSTRUCTION;
        intILIDtls.financialCompID = 0;
        intILIDtls.instructionLineItemType = curam.codetable.ILITYPE.INTERESTAPPLIED;
        intILIDtls.coverPeriodFrom = interestDateFrom;
        intILIDtls.coverPeriodTo = instructionLineItemDtls.nextAdjustmentDate;
        intILIDtls.effectiveDate = curam.util.type.Date.getCurrentDate();
        // Transfer batch process: add the ILI with a status of TRANSFERRED
        intILIDtls.statusCode = curam.codetable.ILISTATUS.TRANSFERRED;
        intILIDtls.caseID = instructionLineItemDtls.caseID;
        intILIDtls.finInstructionID = 0;
        intILIDtls.concernRoleID = instructionLineItemDtls.concernRoleID;
        intILIDtls.caseNomineeID = instructionLineItemDtls.caseNomineeID;
        intILIDtls.primaryClientID = instructionLineItemDtls.primaryClientID;
        intILIDtls.deliveryMethodType = instructionLineItemDtls.deliveryMethodType;
        intILIDtls.creditDebitType = curam.codetable.CREDITDEBIT.DEBIT;
        intILIDtls.currencyTypeCode = instructionLineItemDtls.currencyTypeCode;
        intILIDtls.currencyExchangeID = instructionLineItemDtls.currencyExchangeID;
        intILIDtls.adjustmentInd = false;
        intILIDtls.adjustmentFrequency = curam.util.type.FrequencyPattern.kZeroFrequencyPattern.toString();
        intILIDtls.nextAdjustmentDate = curam.util.type.Date.kZeroDate;
        intILIDtls.instrumentGenInd = instructionLineItemDtls.instrumentGenInd;
        intILIDtls.fundID = instructionLineItemDtls.fundID;

        // uniqueID manipulation variable
        curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

        // maintainInstructionLineItem manipulation variable
        curam.core.intf.MaintainInstructionLineItem maintainInstructionLineItemObj = curam.core.fact.MaintainInstructionLineItemFactory.newInstance();

        // instructionLineItemRelation manipulation variable
        curam.core.intf.InstructionLineItemRelation instructionLineItemRelationObj = curam.core.fact.InstructionLineItemRelationFactory.newInstance();

        // add instructionLineItem
        intILIid = maintainInstructionLineItemObj.addInstructionLineItem(
          intILIDtls);

        // BEGIN, CR00092828, CW
        // Assign the details of the created interest instruction line item to
        // the return struct
        interestILI.assign(intILIDtls);
        interestILI.instructLineItemID = intILIid.instructionLineItemID;
        interestILI.dueDate = Date.getCurrentDate();
        // END, CR00092828

        // relate the interest instruction line item record to the product
        // delivery instruction line item from which it was calculated

        // instructionLineItemRelation manipulation variable
        InstructionLineItemRelationDtls intILIRelDtls = new InstructionLineItemRelationDtls();

        // set interest ILI Relation details
        intILIRelDtls.instructLineItemRelatID = uniqueIDObj.getNextID();
        intILIRelDtls.instructLineItemID = instructionLineItemDtls.instructLineItemID;
        intILIRelDtls.relatedLineItemID = intILIid.instructionLineItemID;
        intILIRelDtls.typeCode = curam.codetable.ILIRELATIONSHIP.INTEREST;
        intILIRelDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();

        // insert instructionLineItemRelation
        instructionLineItemRelationObj.insert(intILIRelDtls);

        // instructionLineItemRelation manipulation variables
        InstructionLineItemKey iliKey = new InstructionLineItemKey();
        curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();
        NextAdjustmentDate iliNextAdjustDate = new NextAdjustmentDate();

        // set ILI key for update
        iliKey.instructLineItemID = instructionLineItemDtls.instructLineItemID;

        // set ILI next adjustment date for update
        iliNextAdjustDate.nextAdjustmentDate = new curam.util.type.FrequencyPattern(instructionLineItemDtls.adjustmentFrequency).getNextOccurrence(
          instructionLineItemDtls.nextAdjustmentDate);
        iliNextAdjustDate.versionNo = instructionLineItemDtls.versionNo;

        // update instructionLineItem
        instructionLineItemObj.modifyNextAdjustmentDate(iliKey,
          iliNextAdjustDate);

      } catch (curam.util.exception.RecordNotFoundException e) {// If no evidence is recorded, exit here, returning 0.
        // i.e. we did not process any line items
      }
    }
    return interestILI;
    // END, CR00081370
  }

  // BEGIN, CR00092828, CW
  // _________________________________________________________________________
  /**
   * Calculate the interest amount for a given instruction line item for a
   * number of days.
   *
   * @param instructionLineItemDtls - the instruction line item on which
   * interest is to be applied.
   * @param totalDays - number of days for which the daily interest must be
   * applied.
   *
   * @return Money the interest amount
   */
  protected Money getInterestAmountForILI(InstructionLineItemDtls
    instructionLineItemDtls, int totalDays) {

    // interest rate
    double appliedInterestRate = 0;

    // initialize interest amount
    double interestAmount = 0;

    // number of days in year
    final int kThreeSixFive = 365;

    // BEGIN, CR00238338, PF
    // calculate the interest amount
    interestAmount = (((instructionLineItemDtls.unprocessedAmount.getValue()
      * appliedInterestRate)
        / (kThreeSixFive * CuramConst.gkOneHundredPercent)))
          * totalDays;
    // BEGIN, CR00238338
    
    // return interest amount in Money value
    return new Money(interestAmount);
  }

  // END, CR00092828

  // END, CR00069071

  // BEGIN, CR00069071, CW
  // BEGIN, CR00081370, CW
  // _________________________________________________________________________
  /**
   * Processes a tax ILI for a pre-transfer instruction line item.
   * Updates the status on the tax ILI to 'Transferred'.
   *
   * @param instructionLineItemDtls Instruction Line Item Details to be
   * processed.
   *
   * @return InstructionLineItemDtls the tax instruction line item with
   * updated status.
   */
  public InstructionLineItemDtls processTaxGroupForTransfer(
    InstructionLineItemDtls instructionLineItemDtls)
    throws AppException, InformationalException {

    // instructionLineItem manipulation variables
    InstructionLineItemKey iliKey = new InstructionLineItemKey();
    curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();

    // set ILI key for update
    iliKey.instructLineItemID = instructionLineItemDtls.instructLineItemID;

    // Update ILI status code to TRANSFERRED
    ILIStatusCode iliStatusCode = new ILIStatusCode();

    iliStatusCode.statusCode = curam.codetable.ILISTATUS.TRANSFERRED;

    iliStatusCode.versionNo = instructionLineItemDtls.versionNo;

    instructionLineItemObj.modifyStatusCode(iliKey, iliStatusCode);

    // Return the tax ILI with updated status code
    return instructionLineItemDtls;
    // END, CR00081370
  }

  // END, CR00069071

  // BEGIN, CR00069071, CW
  // _________________________________________________________________________
  /**
   * Deduction Payment Processing for a pre-transfer instruction line item
   * Currently performs no processing as deductions are not applied for ERP
   * systems.
   *
   * @param instructionLineItemDtls Instruction Line Item Details
   *
   * @return A count of the instruction line items created
   */
  public int processDeductionLineGroupForTransfer(InstructionLineItemDtls
    instructionLineItemDtls)
    throws AppException, InformationalException {

    int countILIsProcessed = 0;

    if (instructionLineItemDtls.caseID != 0) {

      AllocateDeductionDetails allocateDeductionDetails = new AllocateDeductionDetails();

      allocateDeductionDetails.iliDtls = instructionLineItemDtls;

      // Empty method :: ERP system does not currently allocate deduction
      // payment details
      allocateDeductionForTransfer(allocateDeductionDetails);
    }

    return ++countILIsProcessed;
  }

  // END, CR00069071

  // BEGIN, CR00069071, CW
  // BEGIN, CR00081370, CW
  // BEGIN, CR00092828, CW
  // _________________________________________________________________________
  /**
   * Processes surcharge for a pre-transfer instruction line item
   *
   * @param instructionLineItemDtls Instruction Line Item Details to process
   *
   * @return InstructionLineItemDtls the surcharge instruction line item if one
   * was created.
   */
  public InstructionLineItemDtls processSurchargeForTransfer
    (InstructionLineItemDtls instructionLineItemDtls)
    throws AppException, InformationalException {

    // Return value: this will get populated with the surcharge ILI created
    InstructionLineItemDtls surchargeILI = new InstructionLineItemDtls();
    // END, CR00092828

    final double kSurchargeRate = 0.1;
    // Surcharge date increment by days
    final int kSurchageDateIncrement = 1;

    // surcharge period from
    curam.util.type.Date surchargeDateFrom;

    // surcharge amount
    curam.util.type.Money surchargeAmount = curam.util.type.Money.kZeroMoney;

    // zero value used for attribute initialization
    short stBlankValue = 0;

    // calculate surchargeDateFrom
    surchargeDateFrom = new curam.util.type.FrequencyPattern(instructionLineItemDtls.adjustmentFrequency).getPrevOccurrence(
      instructionLineItemDtls.nextAdjustmentDate);

    // move surchargedateFrom forwards by 1 day
    surchargeDateFrom = surchargeDateFrom.addDays(kSurchageDateIncrement);

    surchargeAmount = new curam.util.type.Money(
      instructionLineItemDtls.amount.getValue() * kSurchargeRate);

    // Instruction line item details and identifier
    InstructionLineItemDetails surILIDetails = new InstructionLineItemDetails();
    InstructionLineItemID surILIID;

    // maintainInstructionLineItem manipulation variable
    curam.core.intf.MaintainInstructionLineItem maintainInstructionLineItemObj = curam.core.fact.MaintainInstructionLineItemFactory.newInstance();

    // set surcharge ILI details
    surILIDetails.amount = surchargeAmount;
    surILIDetails.unprocessedAmount = new curam.util.type.Money(surchargeAmount);
    surILIDetails.instructLineItemCategory = curam.codetable.ILICATEGORY.LIABILITYINSTRUCTION;
    surILIDetails.financialCompID = stBlankValue;
    surILIDetails.instructionLineItemType = curam.codetable.ILITYPE.SURCHARGELIABILITY;
    surILIDetails.coverPeriodFrom = surchargeDateFrom;
    surILIDetails.coverPeriodTo = instructionLineItemDtls.nextAdjustmentDate;
    surILIDetails.effectiveDate = curam.util.type.Date.getCurrentDate();
    // Transfer batch process: add the ILI with a status of TRANSFERRED
    surILIDetails.statusCode = curam.codetable.ILISTATUS.TRANSFERRED;
    surILIDetails.caseID = instructionLineItemDtls.caseID;
    surILIDetails.finInstructionID = stBlankValue;
    surILIDetails.concernRoleID = instructionLineItemDtls.concernRoleID;
    surILIDetails.caseNomineeID = instructionLineItemDtls.caseNomineeID;
    surILIDetails.primaryClientID = instructionLineItemDtls.primaryClientID;
    surILIDetails.deliveryMethodType = instructionLineItemDtls.deliveryMethodType;
    surILIDetails.creditDebitType = curam.codetable.CREDITDEBIT.DEBIT;
    surILIDetails.currencyTypeCode = instructionLineItemDtls.currencyTypeCode;
    surILIDetails.currencyExchangeID = instructionLineItemDtls.currencyExchangeID;
    surILIDetails.adjustmentInd = false;
    surILIDetails.adjustmentFrequency = curam.util.type.FrequencyPattern.kZeroFrequencyPattern.toString();

    surILIDetails.nextAdjustmentDate = curam.util.type.Date.kZeroDate;

    surILIDetails.instrumentGenInd = instructionLineItemDtls.instrumentGenInd;
    surILIDetails.fundID = instructionLineItemDtls.fundID;

    // add surcharge instructionLineItem
    surILIID = maintainInstructionLineItemObj.addInstructionLineItem(
      surILIDetails);

    // BEGIN, CR00092828, CW
    // Assign the details of the created surcharge instruction line item to the
    // return struct
    surchargeILI.assign(surILIDetails);
    surchargeILI.instructLineItemID = surILIID.instructionLineItemID;
    surchargeILI.dueDate = Date.getCurrentDate();
    // END, CR00092828


    // Relate the surcharge instruction line item record to the product
    // delivery instruction line item from which it was calculated

    // instructionLineItemRelation manipulation variables
    InstructionLineItemRelationDtls surILIRelationDtls = new InstructionLineItemRelationDtls();
    curam.core.intf.InstructionLineItemRelation instructionLineItemRelationObj = curam.core.fact.InstructionLineItemRelationFactory.newInstance();

    // set surcharge ILI Relation details
    surILIRelationDtls.instructLineItemRelatID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();
    surILIRelationDtls.instructLineItemID = instructionLineItemDtls.instructLineItemID;
    surILIRelationDtls.relatedLineItemID = surILIID.instructionLineItemID;
    surILIRelationDtls.typeCode = curam.codetable.ILIRELATIONSHIP.SURCHARGES;
    surILIRelationDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();

    // insert instructionLineItemRelation
    instructionLineItemRelationObj.insert(surILIRelationDtls);

    // instructionLineItem manipulation variables
    InstructionLineItemKey iliKey = new InstructionLineItemKey();
    curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();

    // Instruction line item next adjustment date
    NextAdjustmentDate iliNextAdjustmentDate = new NextAdjustmentDate();

    // set ILI key
    iliKey.instructLineItemID = instructionLineItemDtls.instructLineItemID;

    // set ILI next adjustment date details
    iliNextAdjustmentDate.nextAdjustmentDate = new curam.util.type.FrequencyPattern(instructionLineItemDtls.adjustmentFrequency).getNextOccurrence(
      instructionLineItemDtls.nextAdjustmentDate);
    iliNextAdjustmentDate.versionNo = instructionLineItemDtls.versionNo;

    // modify instructionLineItem
    instructionLineItemObj.modifyNextAdjustmentDate(iliKey,
      iliNextAdjustmentDate);

    // BEGIN, CR00092828, CW
    return surchargeILI;
    // END, CR00081370
    // END, CR00092828

  }
  // END, CR00069071
}
