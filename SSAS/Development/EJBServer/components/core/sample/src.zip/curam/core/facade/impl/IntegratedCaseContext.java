/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.codetable.PRODUCTCATEGORY;
import curam.core.facade.struct.ICContextDescriptionDetails;
import curam.core.facade.struct.ICContextDescriptionKey_fo;
import curam.core.facade.struct.ICMemberContextDescriptionDetails;
import curam.core.facade.struct.ICMemberContextDescriptionKey;
import curam.core.facade.struct.ICProductDeliveryContextDescription;
import curam.core.facade.struct.ICProductDeliveryContextDescriptionKey;
import curam.core.impl.CuramConst;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHomePageNameAndType;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameTypeAndAlternateID;
import curam.core.struct.ICHomePageNameAndType;
import curam.message.SEPARATOR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * This process class provides the functionality to retrieve context
 * descriptions for an integrated case.
 *
 */
public abstract class IntegratedCaseContext extends curam.core.facade.base.IntegratedCaseContext {

  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by
   * {@link SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.getProgramLocale())}.
   * Replacement reason - static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note <CR00219408>.
   */
  @Deprecated
  // BEGIN, CR00023323, SK
  protected static final String kSeparator =
    //BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();
    //END, CR00163471, JC
  // END, CR00222190

  // BEGIN, CR00098942, SAI
  protected static final String kSpace = CuramConst.gkSpace;
  // END, CR00098942
  // END, CR00023323
  protected static final int kBufSize = 256;

  // ___________________________________________________________________________
  /**
   * Generates the context description for an Integrated Case.
   *
   * @param icContextDescriptionKey Integrated case context description
   identifier.
   *
   * @return A context description for an Integrated Case.
   */
  public ICContextDescriptionDetails readContextDescription(
    ICContextDescriptionKey_fo icContextDescriptionKey)
    throws AppException, InformationalException {

    // Create return object
    ICContextDescriptionDetails icContextDescriptionDetails =
      new ICContextDescriptionDetails();

    // CaseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();

    ICHomePageNameAndType icHomePageNameAndType;

    curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();

    // Read caseHeader
    caseKey.caseID = icContextDescriptionKey.caseID;
    icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(caseKey);

    // Create the context description
    StringBuffer buffer = new StringBuffer(kBufSize);

    // BEGIN, CR00163098, JC
    buffer.append(
      CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
      icHomePageNameAndType.integratedCaseType,TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC
    // BEGIN, CR00098942, SAI
    buffer.append(kSpace);
    // END, CR00098942
    // BEGIN, CR00222190, ELG
    buffer.append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
      .getMessageText(TransactionInfo.getProgramLocale()));
    // END, CR00222190

    buffer.append(icHomePageNameAndType.caseReference);

    // Assign it to the return object
    icContextDescriptionDetails.description = buffer.toString();

    return icContextDescriptionDetails;

  }

  // ___________________________________________________________________________
  /**
   * Generates the context description for a product delivery on an Integrated
   * Case
   *
   * @param icProductDeliveryContextDescriptionKey Contains the case identifier.
   *
   * @return A context description for a product delivery.
   */
  public ICProductDeliveryContextDescription readICProductDeliveryContextDescription(
    ICProductDeliveryContextDescriptionKey
    icProductDeliveryContextDescriptionKey)
    throws AppException, InformationalException {

    // Create the return object
    ICProductDeliveryContextDescription icProductDeliveryContextDescription =
      new ICProductDeliveryContextDescription();

    // CaseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    CaseKey caseKey = new CaseKey();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // ProductDelivery manipulation variables
    curam.core.intf.ProductDelivery productDeliveryObj =
      curam.core.fact.ProductDeliveryFactory.newInstance();

    // ConcernRole manipulation variables
    curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    ConcernRoleNameTypeAndAlternateID concernRoleNameTypeAndAlternateID;

    // Set key to read CaseHeader
    caseHeaderKey.caseID = icProductDeliveryContextDescriptionKey.caseID;

    caseKey.caseID = icProductDeliveryContextDescriptionKey.caseID;

    // Read CaseHeader
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // Read the concern role details.
    concernRoleNameTypeAndAlternateID =
      concernRoleObj.readConcernRoleNameTypeAndAlternateID(concernRoleKey);

    CaseHomePageNameAndType caseHomePageNameAndType;

    // Read productDelivery
    caseHomePageNameAndType =
      productDeliveryObj.readCaseHomePageNameAndType(caseKey);

    // Create the context description
    StringBuffer buffer = new StringBuffer();

    // BEGIN, CR00163098, JC
    buffer.append(curam.util.type.CodeTable.getOneItem
      (curam.codetable.PRODUCTTYPE.TABLENAME, caseHomePageNameAndType.typeCode,
          TransactionInfo.getProgramLocale()));
    // END, CR00163098, JC

    buffer.append(kSpace);

    buffer.append(caseHomePageNameAndType.caseReference);
    // BEGIN, CR00098942, SAI
    buffer.append(kSpace);
    // END, CR00098942

    // BEGIN, CR00222190, ELG
    buffer.append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION
      .getMessageText(TransactionInfo.getProgramLocale()));
    // END, CR00222190

    buffer.append(concernRoleNameTypeAndAlternateID.concernRoleName);
    buffer.append(kSpace);
    buffer.append(concernRoleNameTypeAndAlternateID.primaryAlternateID);

    // Assign it to the return object
    icProductDeliveryContextDescription.description = buffer.toString();

    return icProductDeliveryContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Generates the Integrated Case member context description.
   *
   * @param icMemberContextDescriptionKey Contains the case identifier.
   *
   * @return A context description for an Integrated Case member.
   */
  public ICMemberContextDescriptionDetails readICMemberContextDescription(
    ICMemberContextDescriptionKey icMemberContextDescriptionKey)
    throws AppException, InformationalException {

    // Create return object
    ICMemberContextDescriptionDetails icMemberContextDescriptionDetails =
      new ICMemberContextDescriptionDetails();

    // ConcernRole manipulation variables
    curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    curam.core.struct.ConcernRoleNameDetails concernRoleNameDetails;

    // Set key to read concernRoleName
    concernRoleKey.concernRoleID = icMemberContextDescriptionKey.concernRoleID;

    // Read concernRoleName
    concernRoleNameDetails = concernRoleObj.readConcernRoleName(concernRoleKey);

    // Assign concernRoleName to the return object
    icMemberContextDescriptionDetails.description =
      concernRoleNameDetails.concernRoleName;

    return icMemberContextDescriptionDetails;
  }

}

