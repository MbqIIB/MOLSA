/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 - 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.generator.impl;


import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.xpath.XPath;

import curam.cefwidgets.docbuilder.impl.XMLBuilder;
import curam.codetable.impl.CASECATEGORYEntry;
import curam.codetable.impl.CASEDECISIONRESULTCODEEntry;
import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.GENDEREntry;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.core.facade.struct.CaseSampleKey;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Locale;
import curam.util.type.Date;
import curam.util.type.StringHelper;


public class PDCaseAuditCriteriaXMLHelper 
  implements CaseAuditCriteriaXMLHelper {

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public PDCaseAuditCriteriaXMLHelper() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Builds the XML <code>String</code> representation of the data to be
   * to be used in the creation of the case audit sample. 
   *
   * @param key
   * The search criteria to be used in the generation of the case
   * audit sample.
   *
   * @return An XML <code>String</code> representation of the data to be used 
   * in the creation of the case audit sample.
   */
  public String buildCriteria(final CaseSampleKey key) 
    throws AppException, InformationalException {

    XMLBuilder xmlBuilder = new XMLBuilder(
      CaseAuditCriteriaXMLConst.kCaseSampleKey);
    
    if (key.auditPlanID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAuditPlanID);
      xmlBuilder.addTagData(String.valueOf(key.auditPlanID));
      xmlBuilder.closeTag();
    }

    if (key.totalNumCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kTotalNumCases);
      xmlBuilder.addTagData(String.valueOf(key.totalNumCases));
      xmlBuilder.closeTag();      
    }
    
    if (key.numberOfCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kNumCases);
      xmlBuilder.addTagData(String.valueOf(key.numberOfCases));
      xmlBuilder.closeTag();      
    }
    
    if (key.percentageOfCases > 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kPercentageOfCases);
      xmlBuilder.addTagData(String.valueOf(key.percentageOfCases));
      xmlBuilder.closeTag();      
    }
    
    if (key.selectionQueryID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kSelectionQueryID);
      xmlBuilder.addTagData(String.valueOf(key.selectionQueryID));
      xmlBuilder.closeTag();      
    }
    
    if (key.externalCaseAuditDataID != 0) {
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kExternalCaseAuditDataID);
      xmlBuilder.addTagData(String.valueOf(key.externalCaseAuditDataID));
      xmlBuilder.closeTag();      
    }

    if (key.details != null) {
      
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAlgorithmParameters);
      
      if (key.details.startPoint > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStartPoint);
        xmlBuilder.addTagData(String.valueOf(key.details.startPoint));
        xmlBuilder.closeTag();      
      }
      
      if (key.details.interval > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kInterval);
        xmlBuilder.addTagData(String.valueOf(key.details.interval));
        xmlBuilder.closeTag();      
      }
      xmlBuilder.closeTag();      
    }
      
    if (key.pdDtls != null) {
      
      xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCommonPDSearchCriteria);
      
      if (!key.pdDtls.status.equals(CASESTATUSEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStatus);
        xmlBuilder.addTagData(key.pdDtls.status);
        xmlBuilder.closeTag();      
      }
      
      if (key.pdDtls.age > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kAge);
        xmlBuilder.addTagData(String.valueOf(key.pdDtls.age));
        xmlBuilder.closeTag();      
      }      
      
      if (!StringHelper.isEmpty(key.pdDtls.caseOwner)) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCaseOwner);
        xmlBuilder.addTagData(String.valueOf(key.pdDtls.caseOwner));
        xmlBuilder.closeTag();      
      }      
      
      if (!key.pdDtls.caseTypeCode.equals(
        CASETYPECODEEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCaseTypeCode);
        xmlBuilder.addTagData(String.valueOf(key.pdDtls.caseTypeCode));
        xmlBuilder.closeTag();      
      }      
      
      if (!key.pdDtls.category.equals(CASECATEGORYEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCaseCategory);
        xmlBuilder.addTagData(String.valueOf(key.pdDtls.category));
        xmlBuilder.closeTag();      
      }      
      
      if (!key.pdDtls.endDateFrom.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kEndDateFrom);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.pdDtls.endDateFrom, Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }
      
      if (!key.pdDtls.endDateTo.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kEndDateTo);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.pdDtls.endDateTo, Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }
      
      if (!key.pdDtls.startDateFrom.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStartDateFrom);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.pdDtls.startDateFrom, Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }
      
      if (!key.pdDtls.startDateTo.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kStartDateTo);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.pdDtls.startDateTo, Locale.Date_ymd));
        // END, CR00298436                
        xmlBuilder.closeTag();              
      
      }
      if (!key.pdDtls.gender.equals(GENDEREntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kGender);
        xmlBuilder.addTagData(String.valueOf(key.pdDtls.gender));
        xmlBuilder.closeTag();              
      }
      
      if (key.pdDtls.ownerLocation != 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kOwnerLocation);
        xmlBuilder.addTagData(String.valueOf(key.pdDtls.ownerLocation));
        xmlBuilder.closeTag();              
      }
      
      if (key.pdDtls.filterOptionList.length() > 0) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kFilterOptionList);
        xmlBuilder.addTagData(String.valueOf(key.pdDtls.filterOptionList));
        xmlBuilder.closeTag();              
      }
      
      if (!key.pdDtls.orgObjectType.equals(
        ORGOBJECTTYPEEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kOrgObjectType);
        xmlBuilder.addTagData(String.valueOf(key.pdDtls.orgObjectType));
        xmlBuilder.closeTag();              
      }
      
      if (!key.pdDtls.certificationFromDate.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCertificationFrom);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.pdDtls.certificationFromDate,
          Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }

      if (!key.pdDtls.certificationToDate.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kCertificationTo);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.pdDtls.certificationToDate,
          Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }

      if (!key.pdDtls.timePeriodFromDate.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kTimePeriodFrom);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.pdDtls.timePeriodFromDate,
          Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }

      if (!key.pdDtls.timePeriodToDate.isZero()) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kTimePeriodTo);
        // BEGIN, CR00298436, PMD
        xmlBuilder.addTagData(
          Locale.getFormattedDate(key.pdDtls.timePeriodToDate, Locale.Date_ymd));
        // END, CR00298436        
        xmlBuilder.closeTag();              
      }

      if (!key.pdDtls.decision.equals(
        CASEDECISIONRESULTCODEEntry.NOT_SPECIFIED.getCode())) {
        xmlBuilder.createTag(CaseAuditCriteriaXMLConst.kDecision);
        xmlBuilder.addTagData(String.valueOf(key.pdDtls.decision));
        xmlBuilder.closeTag();              
      }

      xmlBuilder.closeTag();      
    }
    
    return xmlBuilder.getXmlString();
  }

  // ___________________________________________________________________________
  /**
   * Parses an XML document that represents the data to be used in the 
   * creation of the case audit sample.
   *
   * @param document
   * The XML <code>String</code> representation of the data to be used 
   * in the creation of the case audit sample.
   *
   * @return The key containing the search criteria.
   */
  public CaseSampleKey parseCriteria(final Document document) 
    throws AppException, InformationalException {

    CaseSampleKey caseSampleKey = new CaseSampleKey(); 
    
    try { 
    
      XPath xpath = XPath.newInstance("//CaseSampleKey/auditPlanID/text()");
      org.jdom.Text text = (org.jdom.Text) xpath.selectSingleNode(
        document.getRootElement());

      if (text != null) {       
        caseSampleKey.auditPlanID = new Long(text.getText()).longValue();
      }
      
      xpath = XPath.newInstance("//CaseSampleKey/totalNumCases/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.totalNumCases = Integer.parseInt(text.getText());
      }
      
      xpath = XPath.newInstance("//CaseSampleKey/numberOfCases/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.numberOfCases = Integer.parseInt(text.getText());
      }
  
      xpath = XPath.newInstance("//CaseSampleKey/percentageOfCases/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.percentageOfCases = Double.parseDouble(text.getText());
      }
      
      xpath = XPath.newInstance("//CaseSampleKey/selectionQueryID/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.selectionQueryID = new Long(text.getText()).longValue();
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/externalCaseAuditDataID/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.externalCaseAuditDataID = new Long(text.getText()).longValue();
      }
  
      xpath = XPath.newInstance(
        "//CaseSampleKey/algorithmParameters/startPoint/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.details.startPoint = Integer.parseInt(text.getText());
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/algorithmParameters/interval/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.details.interval = Integer.parseInt(text.getText());
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/status/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.pdDtls.status = text.getText();
      }
      
      xpath = XPath.newInstance(
        "" + "//CaseSampleKey/commonPDSearchCriteria/age/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.pdDtls.age = Integer.parseInt(text.getText());
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/caseOwner/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.pdDtls.caseOwner = text.getText();
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/caseTypeCode/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.pdDtls.caseTypeCode = text.getText();
      }
      
      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/category/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.pdDtls.category = text.getText();
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/endDateFrom/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.pdDtls.endDateFrom = Date.fromISO8601(text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/endDateTo/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.pdDtls.endDateTo = Date.fromISO8601(text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/startDateFrom/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.pdDtls.startDateFrom = Date.fromISO8601(text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/startDateTo/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.pdDtls.startDateTo = Date.fromISO8601(text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/gender/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.pdDtls.gender = text.getText();
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/ownerLocation/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.pdDtls.ownerLocation = Long.parseLong(text.getText());
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/filterOptionList/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.pdDtls.filterOptionList = text.getText();
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/orgObjectType/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.pdDtls.orgObjectType = text.getText();
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/certificationFrom/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {      
        // BEGIN, CR00298436, PMD
        caseSampleKey.pdDtls.certificationFromDate = Date.fromISO8601(
          text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/certificationTo/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.pdDtls.certificationToDate = Date.fromISO8601(
          text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/timePeriodFrom/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.pdDtls.timePeriodFromDate = Date.fromISO8601(
          text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/timePeriodTo/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        // BEGIN, CR00298436, PMD
        caseSampleKey.pdDtls.timePeriodToDate = Date.fromISO8601(text.getText());
        // END, CR00298436
      }

      xpath = XPath.newInstance(
        "//CaseSampleKey/commonPDSearchCriteria/decision/text()");
      text = (org.jdom.Text) xpath.selectSingleNode(document.getRootElement());
      if (text != null) {
        caseSampleKey.pdDtls.decision = text.getText();
      }

    } catch (final JDOMException e) {
      throw new AppRuntimeException(e);
    }
    return caseSampleKey;
  }
}
