/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2008, 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.PersonDtls;
import curam.core.struct.PersonKey;
import curam.core.struct.ReadDateOfBirthDetails;
import curam.core.struct.ReadGenderDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * @see curam.core.intf.CachedPerson 
 */
public abstract class CachedPerson extends curam.core.base.CachedPerson {

  protected static ThreadLocal<PersonDtlsCacheRecord> cachedPersonDtls = new ThreadLocal<PersonDtlsCacheRecord>();
  protected static final int kBufferSize = 5;

  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;
  // BEGIN CR00052232, GSP
  // static to indicate if online caching is enabled
  public static final boolean onlineCachingEnabled;
  // END CR00052232

  // ___________________________________________________________________________
  static {

    cachingEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);
    // BEGIN CR00052232, GSP
    onlineCachingEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_ONLINE_CACHING_ENABLED);
    // END CR00052232
  }

  // ___________________________________________________________________________
  /*
   * Class to provide comparator and clear operation for PersonDtls
   */
  static class PersonDtlsBuffer extends CircularBuffer {

    public PersonDtlsBuffer() {
      super(kBufferSize);
    }

    // comparator operation
    public boolean itemsEqual(Object o1, Object o2) {

      PersonDtls personDtls1 = (PersonDtls) o1;
      PersonDtls personDtls2 = (PersonDtls) o2;

      return (personDtls1.concernRoleID == personDtls2.concernRoleID);
    }

    // clear operation
    public void clearItem(Object o) {

      PersonDtls personDtls = (PersonDtls) o;

      personDtls.concernRoleID = 0;
    }

  }


  // ___________________________________________________________________________
  /**
   * class to hold the cached PersonDtlsCacheRecord
   */
  protected class PersonDtlsCacheRecord {
    int transactionID = 0;
    PersonDtlsBuffer personDtlsBuffer = new PersonDtlsBuffer();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public PersonDtls read(PersonKey key) throws AppException, InformationalException {

    PersonDtls personDtls = new PersonDtls();

    boolean reloadCache = true;

    TransactionType transactionType = TransactionInfo.getTransactionType();

    // If this is a batch transaction or deferred processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    // BEGIN CR00052232, GSP
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {
      // END CR00052232
      // try to find the data in the cache
      PersonDtls searchKey = new PersonDtls();

      searchKey.concernRoleID = key.concernRoleID;

      PersonDtlsCacheRecord personDtlsCacheRecord = cachedPersonDtls.get();

      if (personDtlsCacheRecord != null) {

        personDtls = (PersonDtls) personDtlsCacheRecord.personDtlsBuffer.find(
          searchKey);

        if (personDtls != null) {

          reloadCache = false;

          // if this is a deferred transaction, we must also check
          // that the transaction numbers match
          // BEGIN CR00052232, GSP
          if (!reloadCache
            && (transactionType.equals(TransactionType.kDeferred)
              || transactionType.equals(TransactionType.kOnline))
              // END CR00052232
              && TransactionInfo.getIdentifierForThisThread()
                != personDtlsCacheRecord.transactionID) {

            reloadCache = true;
          }
        }
      }

    }
    // BEGIN CR00052232, GSP
    // Otherwise we need to read the Person data
    // END CR00052232
    if (reloadCache) {
      // BEGIN CR00052232, GSP
      personDtls = reloadCache(key);
    }
    // END CR00052232
    
    final PersonDtls result = new PersonDtls();

    return result.assign(personDtls);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void clearCache() throws AppException, InformationalException {

    // clear the thread local
    cachedPersonDtls.set(null);
  }

  // BEGIN CR00052232, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReadDateOfBirthDetails readDateOfBirth(PersonKey key) throws AppException, InformationalException {

    ReadDateOfBirthDetails readDateOfBirthDetails = new ReadDateOfBirthDetails();
    PersonDtls personDtls = new PersonDtls();

    boolean reloadCache = true;

    TransactionType transactionType = TransactionInfo.getTransactionType();

    // If this is a batch transaction or deferred processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {
      // try to find the data in the cache
      PersonDtls searchKey = new PersonDtls();

      searchKey.concernRoleID = key.concernRoleID;
      PersonDtlsCacheRecord personDtlsCacheRecord = cachedPersonDtls.get();

      if (personDtlsCacheRecord != null) {
        personDtls = (PersonDtls) personDtlsCacheRecord.personDtlsBuffer.find(
          searchKey);

        if (personDtls != null) {
          readDateOfBirthDetails.dateOfBirth = personDtls.dateOfBirth;

          reloadCache = false;

          // if this is a deferred transaction, we must also check
          // that the transaction numbers match
          if (!reloadCache
            && (transactionType.equals(TransactionType.kDeferred)
              || transactionType.equals(TransactionType.kOnline))
              && TransactionInfo.getIdentifierForThisThread()
                != personDtlsCacheRecord.transactionID) {

            reloadCache = true;
          }
        }
      }
    }

    // Otherwise we need to read the Person data
    if (reloadCache) {
      personDtls = reloadCache(key);
      readDateOfBirthDetails.dateOfBirth = personDtls.dateOfBirth;
    }

    return readDateOfBirthDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReadGenderDetails readGender(PersonKey key) throws AppException,
      InformationalException {
    ReadGenderDetails readGenderDetails = new ReadGenderDetails();
    PersonDtls personDtls = new PersonDtls();

    boolean reloadCache = true;

    TransactionType transactionType = TransactionInfo.getTransactionType();

    // If this is a batch transaction or deferred processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {

      // try to find the data in the cache
      PersonDtls searchKey = new PersonDtls();

      searchKey.concernRoleID = key.concernRoleID;

      PersonDtlsCacheRecord personDtlsCacheRecord = cachedPersonDtls.get();

      if (personDtlsCacheRecord != null) {

        personDtls = (PersonDtls) personDtlsCacheRecord.personDtlsBuffer.find(
          searchKey);

        if (personDtls != null) {
          readGenderDetails.gender = personDtls.gender;

          reloadCache = false;

          // if this is a deferred transaction, we must also check
          // that the transaction numbers match
          if (!reloadCache
            && (transactionType.equals(TransactionType.kDeferred)
              || transactionType.equals(TransactionType.kOnline))
              && TransactionInfo.getIdentifierForThisThread()
                != personDtlsCacheRecord.transactionID) {

            reloadCache = true;
          }
        }
      }

    }

    // Otherwise we need to read the Person data
    if (reloadCache) {
      personDtls = reloadCache(key);
      readGenderDetails.gender = personDtls.gender;
    }

    return readGenderDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public PersonDtls reloadCache(PersonKey key) throws AppException, InformationalException {

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    PersonDtls personDtls = new PersonDtls();

    // person object
    curam.core.intf.Person personObj = curam.core.fact.PersonFactory.newInstance();

    PersonDtlsCacheRecord personDtlsCacheRecord = new PersonDtlsCacheRecord();

    // read person
    personDtls = personObj.read(key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {

      personDtlsCacheRecord.personDtlsBuffer.insert(personDtls);
      personDtlsCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();

      // Populate the cache
      cachedPersonDtls.set(personDtlsCacheRecord);
    }

    return personDtls;
  }
  // END CR00052232
}
