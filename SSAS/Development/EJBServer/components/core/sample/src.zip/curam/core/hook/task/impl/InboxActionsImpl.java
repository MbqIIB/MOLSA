/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.hook.task.impl;


import java.util.ArrayList;
import java.util.List;

import curam.codetable.TARGETITEMTYPE;
import curam.codetable.TASKCHANGETYPE;
import curam.codetable.WQSUBSORGOBJECTTYPE;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.entity.fact.TaskAssignmentFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.TaskAssignment;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.CanUsersSubscribeToWorkQueue;
import curam.core.sl.entity.struct.CountDetails;
import curam.core.sl.entity.struct.TaskIDAndVersionNoDetails;
import curam.core.sl.entity.struct.TaskIDRelatedIDAndTypeKey;
import curam.core.sl.entity.struct.UserNameAndWorkQueueKey;
import curam.core.sl.entity.struct.UserNameSubscriberAndWorkQueueKey;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.entity.struct.WorkQueueSubscriptionDtls;
import curam.core.sl.fact.InboxFactory;
import curam.core.sl.fact.WorkQueueSubscriptionFactory;
import curam.core.sl.impl.ProcessNextAvailableTaskToReserveReadMulti;
import curam.core.sl.intf.WorkQueueSubscription;
import curam.core.sl.struct.InboxOptionsPreferencesDetails;
import curam.core.sl.struct.ListWorkQueueSubscriptions;
import curam.message.BPOINBOX;
import curam.message.BPOWORKQUEUESUBSCRIPTION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordChangedException;
import curam.util.resources.Configuration;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateTime;
import curam.util.workflow.fact.TaskAdminFactory;
import curam.util.workflow.fact.TaskHistoryAdminFactory;
import curam.util.workflow.intf.TaskAdmin;
import curam.util.workflow.intf.TaskHistoryAdmin;


/**
 * Default implementation of {@link InboxActions}. The default algorithms used 
 * for ascertaining the next task to add to the user's <code>My Tasks</code> 
 * list are defined for each of the supported hook points.
 */
public class InboxActionsImpl implements InboxActions {

  /**
   * Searches for tasks available to the current user and the first available 
   * task returned by the search is the next task that will be added to the 
   * user's <code>My Tasks</code> list.
   * <P> 
   * The order the search returns the tasks is determined by first checking 
   * if the environment variable {@link
   * curam.core.impl.EnvVars#ENV_WORKFLOW_RESERVENEXTTASK_WITH_PRIORITY_FILTER}
   * is set. If it is set, then the tasks returned will be ordered by the
   * priorities specified in the
   * {@link curam.core.impl.EnvVars#ENV_WORKFLOW_TASK_PRIORITY_ORDER}
   * environment variable followed by the least recent task assignment date.
   * If the priority filter environment variable has not been set then the next
   * task is retrieved by the least recent task assignment date.
   * <P>
   * Exceptions are thrown under the following circumstances:
   * <ul>
   * <li>
   * If there are no tasks assigned to the user.
   * </li>
   * </ul> 
   *
   * @param userName The name of the user.
   *
   * @return The identifier of the next task that was added to the user's list
   * of tasks to work on.
   */
  @Override
  public long getNextTask(final String userName)
    throws AppException, InformationalException { 
    
    // This call will attempt to reserve the next available for the specified
    // user.
    return reserveNextTaskFromAvailableTasks(userName, TARGETITEMTYPE.USER, 0);
  }

  /**
   * Searches for tasks available to the specified work queue and the first 
   * available task returned by the search is the next task that will be 
   * added to the users <code>My Tasks</code> list. 
   * <P>
   * The order the search returns the tasks is determined by first checking
   * if the environment variable {@link
   * curam.core.impl.EnvVars#ENV_WORKFLOW_RESERVENEXTTASK_WITH_PRIORITY_FILTER}
   * is set. If it is set, then the tasks returned will be ordered by the
   * priorities specified in the
   * {@link curam.core.impl.EnvVars#ENV_WORKFLOW_TASK_PRIORITY_ORDER}
   * environment variable followed by the least recent task assignment date.
   * If the priority filter environment variable has not been set then the next
   * task is retrieved by the least recent task assignment date.
   * <P>
   * Exceptions are thrown under the following circumstances:
   * <ul>
   * <li>
   * If there are no tasks available to be added from the specified 
   * work queue.
   * </li>
   * </ul>
   *
   * @param userName The name of the user.
   * @param workQueueID The identifier of the work queue from which to get the
   * next task
   *
   * @return The identifier of the next task that was added to the user's list
   * of tasks to work on.
   */
  @Override
  public long getNextTaskFromWorkQueue(
    final String userName,
    final long workQueueID) throws AppException, InformationalException {
    
    // This call will attempt to reserve the next available task from the
    // specified work queue.
    return reserveNextTaskFromAvailableTasks(userName, TARGETITEMTYPE.WORKQUEUE,
      workQueueID);
  }

  /**
   * Searches for tasks available in the user's preferred work queue and the 
   * first available task returned by the search is the next task that will be 
   * added to the user's <code>My Tasks</code> list.
   * <P>
   * The operation first retrieves the identifier of the user's preferred work 
   * queue from their Inbox preferences. If the preferred work queue has not 
   * been set, then this function will throw the appropriate exception. If 
   * the identifier of the preferred work queue has been specified, then this 
   * function delegates to {@link #getNextTaskFromWorkQueue(String, long)}.
   * <P>
   * Exceptions are thrown under the following circumstances:
   * <ul>
   * <li>
   * If the preferred work queue Inbox preference has not been set.
   * </li>
   * <li>
   * If the user is not subscribed to the specified work queue.
   * </li>
   * <li>
   * If there are no tasks available to be added from the specified
   * work queue.
   * </li>
   * </ul> 
   *
   * @param userName The name of the user whose next task from the preferred
   * work queue will be added to the list of tasks to work on.
   *
   * @return The identifier of the next task that was added to the user's 
   * <code>My Tasks</code> list of tasks to work on.
   */
  @Override
  public long getNextTaskFromPreferredWorkQueue(final String userName) 
    throws AppException, InformationalException {
    
    // Get the Inbox preferences for the user.
    final InboxOptionsPreferencesDetails inboxPreferences = InboxFactory.newInstance().getInboxOptionsUserPreferences();
    
    final long workQueueID = inboxPreferences.preferences.preferredWorkQueue.workQueueID;
    
    // If the preferred work queue has not been specified, then an exception
    // is thrown here.
    if (workQueueID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOINBOX.ERR_TASK_XRV_NO_PREFERRED_WORK_QUEUE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    
    // Otherwise, call into the generic function to reserve the next work queue
    // task.
    return getNextTaskFromWorkQueue(userName, workQueueID); 
  }

  /**
   * Searches for tasks available in the user's preferred organization unit 
   * and the first available task returned by the search is the next task that 
   * will be added to the user's <code>My Tasks</code> list. If the preferred 
   * organization unit has not been specified then the appropriate exception 
   * is thrown.
   * <P>
   * The order the search returns the tasks is determined by first checking
   * if the environment variable
   * {@link
   * curam.core.impl.EnvVars#ENV_WORKFLOW_RESERVENEXTTASK_WITH_PRIORITY_FILTER}
   * is set. If it is set, then the tasks returned will be ordered by the
   * priorities specified in the
   * {@link curam.core.impl.EnvVars#ENV_WORKFLOW_TASK_PRIORITY_ORDER}
   * environment variable followed by the least recent task assignment date.
   * If the priority filter environment variable has not been set then the next
   * task is retrieved by the least recent task assignment date.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>
   * If the user has no preferred organization unit specified in
   * their Inbox preferences.
   * </li>
   * <li>
   * If there are no tasks available to be added from the specified
   * organization unit.
   * </li>
   * </ul>
   *
   * @param userName The name of the user.
   *
   * @return The identifier of the next task that was added to the user's list
   * of tasks to work on.
   */
  @Override
  public long getNextTaskFromPreferredOrgUnit(
    final String userName) throws AppException, InformationalException {

    // Get the Inbox preferences for the user.
    final InboxOptionsPreferencesDetails inboxPreferences = InboxFactory.newInstance().getInboxOptionsUserPreferences();
    
    final long orgUnitID = inboxPreferences.preferences.preferredOrgUnit.organisationUnitID;
    
    if (orgUnitID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOINBOX.ERR_TASK_XRV_NO_PREFERRED_ORG_UNIT),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    } 
    
    // This call will attempt to reserve the next available task from the
    // specified organization unit.
    return reserveNextTaskFromAvailableTasks(userName, TARGETITEMTYPE.ORGUNIT,
      orgUnitID);
  }

  /**
   * Subscribes the specified user to the specified work queue.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>
   * If the work queue does not allow users to subscribe or
   * un-subscribe from that work queue as it is an administration 
   * function.
   * </li>
   * <li>
   * If the user is already subscribed to the work queue.
   * </li>
   * </ul>
   *
   * @param userName The name of the user.
   * @param workQueueID The identifier of the work queue that the use is
   * subscribing to.
   */
  @Override
  public void subscribeUserToWorkQueue(final String userName,
    final long workQueueID) throws AppException, InformationalException {

    // Work Queue Subscription manipulation variables
    final curam.core.sl.entity.intf.WorkQueueSubscription workQueueSubscriptionObj = curam.core.sl.entity.fact.WorkQueueSubscriptionFactory.newInstance();

    // Work Queue Subscription manipulation variables
    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();

    final WorkQueueSubscriptionDtls workQueueSubscriptionDtls = new WorkQueueSubscriptionDtls();

    workQueueSubscriptionDtls.userName = userName;
    workQueueSubscriptionDtls.workQueueID = workQueueID;
    workQueueSubscriptionDtls.subscriberType = WQSUBSORGOBJECTTYPE.USER;

    boolean userCanSubscribe = false;

    if (workQueueID != 0) {
      final WorkQueueKey workQueueKey = new WorkQueueKey();

      workQueueKey.workQueueID = workQueueID;

      final CanUsersSubscribeToWorkQueue canUsersSubscribeToWorkQueue = workQueueObj.readCanUsersSubscribeToWorkQueue(
        workQueueKey);

      userCanSubscribe = canUsersSubscribeToWorkQueue.allowUserSubscriptionInd;

    }
    // User Cannot Subscribe
    if (!userCanSubscribe) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOWORKQUEUESUBSCRIPTION.ERR_WORK_QUEUE_SUBSCRIPTION_XRV_USERSUBS_NOT_ALLOWED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check whether user is already subscribed to the workQueue

    // key to count work queue subscriptions by user name and work queue
    final UserNameSubscriberAndWorkQueueKey userNameSubscriberAndWorkQueueKey = new UserNameSubscriberAndWorkQueueKey();

    userNameSubscriberAndWorkQueueKey.userName = userName;
    userNameSubscriberAndWorkQueueKey.workQueueID = workQueueID;
    userNameSubscriberAndWorkQueueKey.subscriberType = WQSUBSORGOBJECTTYPE.USER;
    userNameSubscriberAndWorkQueueKey.searchBySubscriberIDInd = (userNameSubscriberAndWorkQueueKey.subscriberID
      != 0);
    // count work queue subscriptions by user name and work queue
    final CountDetails countDetails = workQueueSubscriptionObj.countBySubscriberAndWorkQueue(
      userNameSubscriberAndWorkQueueKey);

    // check if user is subscribed to specified work queue
    if (countDetails.numberOfRecords == 1) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOINBOX.ERR_WORK_QUEUE_USER_ALREADY_SUBSCRIBED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // subscribe the user
    workQueueSubscriptionObj.insert(workQueueSubscriptionDtls);
  }

  /**
   * Un-subscribes the specified user from the specified work queue.
   * <P>
   * An exception is thrown under the following circumstances:
   * <ul>
   * <li>
   * If the work queue does not allow users to subscribe or
   * un-subscribe from that work queue as it is an administration 
   * function.
   * </li>
   * </ul>
   *
   * @param userName The name of the user.
   * @param workQueueID The identifier of the work queue that the use is
   * un-subscribing from.
   */
  @Override
  public void unsubscribeUserFromWorkQueue(final String userName,
    final long workQueueID) throws AppException, InformationalException {
    // Work Queue Subscription manipulation variables
    final curam.core.sl.entity.intf.WorkQueueSubscription workQueueSubscriptionObj = curam.core.sl.entity.fact.WorkQueueSubscriptionFactory.newInstance();

    // Work Queue Object to read the user subscription field.
    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
    final WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = workQueueID;
    final CanUsersSubscribeToWorkQueue canUsersSubscribeToWorkQueue = workQueueObj.readCanUsersSubscribeToWorkQueue(
      workQueueKey);

    if (!canUsersSubscribeToWorkQueue.allowUserSubscriptionInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOWORKQUEUESUBSCRIPTION.ERR_WORK_QUEUE_UNSUBSCRIBE_XRV_USERUNSUBS_NOT_ALLOWED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    final UserNameAndWorkQueueKey key = new UserNameAndWorkQueueKey();

    key.userName = userName;
    key.workQueueID = workQueueID;

    workQueueSubscriptionObj.removeWorkQueueSubscriptionForUser(key);
  }
  
  /**
   * Retrieves a list of potential tasks that may be added to the list of 
   * tasks to work on. The maximum number of tasks returned from this
   * search is <code>20</code>.
   * <P>
   * The function will search for task assignments for users or organizational
   * objects such as organizational units, positions, jobs or work queues. 
   * <p>
   * The system searches for tasks available to the current assignee type 
   * and a list of tasks returned by the search is processed to determine if
   * any of them may be added to the user's <code>My Tasks</code> list. 
   * The order the search returns the tasks is determined by first checking 
   * if the environment variable
   * {@link
   * curam.core.impl.EnvVars#ENV_WORKFLOW_RESERVENEXTTASK_WITH_PRIORITY_FILTER}
   * is set. If it is set, then the tasks returned will be ordered by the
   * priorities specified in the
   * {@link curam.core.impl.EnvVars#ENV_WORKFLOW_TASK_PRIORITY_ORDER}
   * environment variable followed by the least recent task assignment date.
   * If the priority filter environment variable has not been set then the next
   * task is retrieved by the least recent task assignment date.
   *
   * @param userName The name of the user for which a list of available tasks
   * will be returned.
   *
   * @return A list of tasks that are available to be added to the user's
   * <code>My Tasks</code> list. If not tasks are found matching the 
   * search criteria, then the appropriate exception is thrown.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected List<TaskIDAndVersionNoDetails> getListOfAvailableTasksToReserve(
    final String userName, final String assigneeType, final long assigneeID)
    throws AppException, InformationalException {
    
    // Task user assignment entity object
    final TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();

    // key and details to read task identifiers
    final TaskIDRelatedIDAndTypeKey userNamePriorityAndAssignedDateTimeKey = new TaskIDRelatedIDAndTypeKey();
    final TaskIDRelatedIDAndTypeKey userNameAndAssignedDateTimeKey = new TaskIDRelatedIDAndTypeKey();
    // A flag to indicate whether a function to search by related identifier
    // or related name is required to be invoked.
    boolean searchByRelatedID = false;

    // Specialized readmulti operation.
    final ProcessNextAvailableTaskToReserveReadMulti processNextTaskToReserve = new ProcessNextAvailableTaskToReserveReadMulti();

    // Get the value of the Priority Enabled environment variable
    String priorityEnabled = Configuration.getProperty(
      EnvVars.ENV_WORKFLOW_RESERVENEXTTASK_WITH_PRIORITY_FILTER);

    // If it's not set, use the default
    if (priorityEnabled == null) {
      priorityEnabled = EnvVars.ENV_WORKFLOW_RESERVENEXTTASK_WITH_PRIORITY_FILTER_DEFAULT;
    }

    // If the priority check has been enabled, this will then be used
    // as part of the search key.
    if (priorityEnabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      String priorityOrderString = Configuration.getProperty(
        EnvVars.ENV_WORKFLOW_TASK_PRIORITY_ORDER);

      if (priorityOrderString == null) {
        priorityOrderString = Configuration.getProperty(
          EnvVars.ENV_WORKFLOW_TASK_PRIORITY_ORDER_DEFAULT);
      }

      final String[] priorityArray = priorityOrderString.split(
        CuramConst.gkComma);
      final int numberOfPriorities = priorityArray.length;
      
      // Populate the details to carry out the task assignment search on.
      userNamePriorityAndAssignedDateTimeKey.assigneeType = assigneeType;
     
      if (assigneeType.equals(TARGETITEMTYPE.USER)) {
        userNamePriorityAndAssignedDateTimeKey.relatedName = userName;
      } else {
        userNamePriorityAndAssignedDateTimeKey.relatedID = assigneeID;
        searchByRelatedID = true;
      }
      userNamePriorityAndAssignedDateTimeKey.assignedDateTime = DateTime.getCurrentDateTime();

      for (int i = 0; i < numberOfPriorities; i++) {

        userNamePriorityAndAssignedDateTimeKey.priority = priorityArray[i];
        
        if (searchByRelatedID) {
          taskAssignmentObj.searchUnreservedByRelatedIDPriorityAndLongestAssignedDateTime(
            userNamePriorityAndAssignedDateTimeKey, processNextTaskToReserve);
        } else {
          taskAssignmentObj.searchUnreservedByRelatedNamePriorityAndLongestAssignedDateTime(
            userNamePriorityAndAssignedDateTimeKey, processNextTaskToReserve);          
        }
 
        // One or more tasks with a specified priority have been found.
        if (!processNextTaskToReserve.getPotentialAvailableTasks().isEmpty()) {
          break;
        }
      }

      // Task priorities can now be blank. Therefore a call must be made here 
      // if no tasks can be found by searching for tasks with a priority above
      // to check if there are tasks assigned to the user that have a blank 
      // priority and if so their details should be returned.
      if (processNextTaskToReserve.getPotentialAvailableTasks().isEmpty()) {       
        // Populate the details to carry out the task assignment search on.
        userNameAndAssignedDateTimeKey.assigneeType = assigneeType;
        if (assigneeType.equals(TARGETITEMTYPE.USER)) {
          userNameAndAssignedDateTimeKey.relatedName = userName;
        } else {
          userNameAndAssignedDateTimeKey.relatedID = assigneeID;
          searchByRelatedID = true;
        }
        userNameAndAssignedDateTimeKey.assignedDateTime = curam.util.type.DateTime.getCurrentDateTime();
        
        if (searchByRelatedID) {
          taskAssignmentObj.searchUnreservedByRelatedIDNullPriorityLongestAssignedDateTime(
            userNameAndAssignedDateTimeKey, processNextTaskToReserve);
        } else {
          taskAssignmentObj.searchUnreservedByRelatedNameNullPriorityAndLongestAssignedDateTime(
            userNameAndAssignedDateTimeKey, processNextTaskToReserve);          
        }
      }

      if (processNextTaskToReserve.getPotentialAvailableTasks().isEmpty()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOINBOX.ERR_TASK_XRV_NO_UNRESERVED_TASK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
      }
    } else {

      // Not searching by priority, but just by name and date time.
      userNameAndAssignedDateTimeKey.assigneeType = assigneeType;
     
      if (assigneeType.equals(TARGETITEMTYPE.USER)) {
        userNameAndAssignedDateTimeKey.relatedName = userName;
      } else {
        userNameAndAssignedDateTimeKey.relatedID = assigneeID;
        searchByRelatedID = true;
      }      
      userNameAndAssignedDateTimeKey.assignedDateTime = curam.util.type.DateTime.getCurrentDateTime();

      if (searchByRelatedID) {
        taskAssignmentObj.searchUnreservedByRelatedIDAndLongestAssignedDateTime(
          userNameAndAssignedDateTimeKey, processNextTaskToReserve);
      } else {
        taskAssignmentObj.searchUnreservedByRelatedNameAndLongestAssignedDateTime(
          userNameAndAssignedDateTimeKey, processNextTaskToReserve);          
      }

      if (processNextTaskToReserve.getPotentialAvailableTasks().isEmpty()) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOINBOX.ERR_TASK_XRV_NO_UNRESERVED_TASK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      } // end of read task details by user name and assigned date

    } // end of priority filter check

    // Return the potential list of tasks.
    return processNextTaskToReserve.getPotentialAvailableTasks();
  }
  
  /**
   * Makes a call to retrieve the next list of available tasks that may be
   * added to the user's <code>My Tasks</code> list. Iterates through this list
   * and attempts to add that task. If the task being processed has been 
   * changed by another user, then an attempt will be made to add the next 
   * task in the list. If all of the tasks in the list are processed without 
   * successfully adding any task to the user's <code>My Tasks</code> list, 
   * then a further call is made to retrieve another list of available tasks 
   * to process.
   * <P>
   * A maximum of <code>20</code> has been set for the number of tasks 
   * retrieved each time for processing as it is reasonable to expect that a
   * successful attempt will be made to add one of these tasks to the user's
   * <code>My Tasks</code> list without getting an exception stating that the
   * task has been changed by by another user.
   *
   * @param userName The name of the user for which the identifier of the next
   * task to be added to the list of tasks to work on will be retrieved and 
   * returned.
   * @param assigneeType The type of the task assignee which may be a user
   * or the various organizational objects such as organization units, 
   * positions, jobs and work queues.
   * @param assigneeID If the assignee type is an organizational object, then
   * this will represent the identifier of that organizational object.
   *
   * @return The identifier of the next task that was added to the user's
   * <code>My Tasks</code> list.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected long reserveNextTaskFromAvailableTasks(
    final String userName, final String assigneeType, final long assigneeID) 
    throws AppException, InformationalException {
                  
    TaskIDAndVersionNoDetails taskIDDetails = null; 
    List<TaskIDAndVersionNoDetails> potentialTasksDetails;
    boolean taskReserved = false;

    while (!taskReserved) {
      potentialTasksDetails = new ArrayList<TaskIDAndVersionNoDetails>(
        getListOfAvailableTasksToReserve(userName, assigneeType, assigneeID));
      while (!taskReserved && potentialTasksDetails.size() != 0) {
        try {
          // Reserve the task.
          taskIDDetails = potentialTasksDetails.get(0);
          potentialTasksDetails.remove(0);
          reserveNextTask(userName, taskIDDetails.taskID, 
            taskIDDetails.versionNo);
          taskReserved = true;
        } catch (RecordChangedException e) {
          ;
          // This task has been changed by another user so just attempt to 
          // reserve the next task.
        }
      } 
    }  
    // Return the identifier of the task that was reserved.
    return taskIDDetails.taskID;
  }
  
  /**
   * Adds the specified task to the user's list of tasks to work on and adds
   * a task history record to indicate that this action has occurred.
   *
   * @param userName The identifier of the user for whom the next task will
   * be added to the list of tasks to work on.
   * @param taskID The identifier of the task to be reserved.
   * @param versionNo The optimistic locking version number of the task record
   * that will be updated.
   */
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void reserveNextTask(final String userName, final long taskID,
    final int versionNo) throws AppException, InformationalException {
    
    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();

    // Add the task history details.
    taskHistoryAdminObj.create(taskID, DateTime.getCurrentDateTime(),
      TASKCHANGETYPE.RESERVED, CuramConst.gkEmpty, userName, CuramConst.gkEmpty,
      userName);
    
    // Reserve the specified task.
    taskAdminObj.modifyReservedBy(taskID, userName,
      DateTime.getCurrentDateTime(), versionNo);
  }  

  /**
   * Method to validate details before reserving a task from a work queue that
   * the specified user is subscribed to.
   * <p>
   * Exceptions are thrown under the following circumstances:
   * <ul>
   * <li>
   * If the user is not subscribed to the specified work queue.
   * </li>
   * <li>
   * If there are no tasks assigned to the specified work queue.
   * </li>
   * </ul>
   *
   * @param userName The name of the user.
   * @param workQueueID The identifier of the organization unit from which the
   * next assigned task will be added to the user's list of tasks to work on.
   * @deprecated Since Curam 6.0 SP2. This method is no longer used in the 
   * default flow as the validations performed by the function have been 
   * deemed to be surplus to requirements. The first validation to ensure 
   * that the user is subscribed to the work queue from which the task is 
   * being reserved from is not required as the user picks the work queue 
   * from a list which only displays work queues to which they are subscribed 
   * to. The second validation checked to see if there were any tasks assigned
   * to that work queue. This check is in effect already done when trying to 
   * get the next task from the work queue as if there are no tasks assigned 
   * to that specified work queue, then an appropriate exception is already
   * thrown. See release note CR00290609.
   */
  @Deprecated
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateReserveNextWorkQueueTask(final String userName,
    final long workQueueID) throws AppException, InformationalException {

    // Work queue assignment entity object
    final TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();

    // key to count unreserved tasks by work queue
    final TaskIDRelatedIDAndTypeKey taskIDRelatedIDAndTypeKey = new TaskIDRelatedIDAndTypeKey();

    // Check for the direct and indirect assignments as well
    final WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = workQueueID;
    final WorkQueueSubscription workQueueSubscription = WorkQueueSubscriptionFactory.newInstance();
    final ListWorkQueueSubscriptions listWorkQueueSubscriptions = workQueueSubscription.listAllSubscriptionsForWorkQueue(
      workQueueKey);

    if (listWorkQueueSubscriptions.orgObjectSubscriptionList.dtls.size() == 0
      && listWorkQueueSubscriptions.userSubscriptionList.dtls.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOINBOX.ERR_USER_XRV_UNSUSCRIBED_TO_WORK_QUEUE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // assign key to count unreserved tasks by work queue
    taskIDRelatedIDAndTypeKey.relatedID = workQueueID;
    taskIDRelatedIDAndTypeKey.assigneeType = TARGETITEMTYPE.WORKQUEUE;
    taskIDRelatedIDAndTypeKey.searchByRelatedIDInd = true;

    // count unreserved tasks by work queue
    final CountDetails countDetails = taskAssignmentObj.countUnreservedByTargetRelatedIDType(
      taskIDRelatedIDAndTypeKey);

    // check if there are unreserved tasks for work queue
    if (countDetails.numberOfRecords == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOINBOX.ERR_WORK_QUEUE_XRV_NO_UNRESERVED_TASK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }
  
  /**
   * Method to validate details before reserving a task from a preferred 
   * organization unit that the specified user is a member of.
   * <p>
   * Exceptions are thrown under the following circumstances:
   * <ul>
   * <li>
   * If the preferred organization unit user preference has not been 
   * set.
   * </li>
   * <li>
   * If there are no tasks assigned to the specified organization 
   * unit.
   * </li>
   * </ul>
   *
   * @param orgUnitID The identifier of the organization unit from which the
   * next assigned task will be added to the user's list of tasks to work on.
   * @deprecated Since Curam 6.0 SP2. This method is no longer used in the 
   * default flow as some of validations performed by the function have been 
   * deemed to be surplus to requirements. The first validation to ensure 
   * that an organization unit identifier has been specified has been moved
   * to the {@link #getNextTaskFromPreferredOrgUnit(String)} where it is 
   * required. The second validation checked to see if there were any tasks 
   * assigned to the specified organization unit. This check is in effect 
   * already done when trying to get the next task from the organization unit
   * as if there are no tasks assigned to that specified organization unit, 
   * then an appropriate exception is already thrown. See release 
   * note CR00290609.
   */
  @Deprecated
  @AccessLevel(AccessLevelType.INTERNAL)
  protected void validateReserveNextTaskFromPreferredOrgUnit(
    final long orgUnitID) throws AppException, InformationalException {
    
    // If the preferred organization unit has not been specified, then an 
    // exception is thrown here.
    if (orgUnitID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOINBOX.ERR_TASK_XRV_NO_PREFERRED_ORG_UNIT),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }    

    final TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();
    final TaskIDRelatedIDAndTypeKey taskIDRelatedIDAndTypeKey = new TaskIDRelatedIDAndTypeKey();
    
    taskIDRelatedIDAndTypeKey.relatedID = orgUnitID;
    taskIDRelatedIDAndTypeKey.assigneeType = TARGETITEMTYPE.ORGUNIT;
    taskIDRelatedIDAndTypeKey.searchByRelatedIDInd = true;

    final CountDetails countDetails = taskAssignmentObj.countUnreservedByTargetRelatedIDType(
      taskIDRelatedIDAndTypeKey);
    
    // Throws the appropriate exception if there are no available tasks for
    // the specified organization unit.
    if (countDetails.numberOfRecords == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOINBOX.ERR_PREFERRED_ORG_UNIT_XRV_NO_AVAILABLE_TASKS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }
  
  /**
   * Retrieves the next task to add to the list of tasks to work on. The 
   * function will search for task assignments for users or organizational 
   * objects such as organizational units, positions and jobs. 
   * <p>
   * The system searches for tasks available to the current assignee type 
   * and the first task returned by the search is the next task that will be
   * available to be added to the users "My Tasks" list. The order the search 
   * returns the tasks is determined by first checking if the environment 
   * variable
   * {@link
   * curam.core.impl.EnvVars#ENV_WORKFLOW_RESERVENEXTTASK_WITH_PRIORITY_FILTER}
   * is set. If it is set, then the tasks returned will be ordered by the
   * priorities specified in the
   * {@link curam.core.impl.EnvVars#ENV_WORKFLOW_TASK_PRIORITY_ORDER}
   * environment variable followed by the least recent task assignment date.
   * If the priority filter environment variable has not been set then the next
   * task is retrieved by the least recent task assignment date.
   *
   * @param userName The name of the user for which the identifier of the next
   * task to be added to the list of tasks to work on will be retrieved and 
   * returned.
   * @param assigneeType The type of the task assignee which may be a user
   * or the various organizational objects such as organization units, 
   * positions, jobs and work queues.
   * @param assigneeID If the assignee type is an organizational object, then
   * this will represent the identifier of that organizational object.
   *
   * @return The identifier of the next task to be reserved.
   *
   * @deprecated Since Curam 6.0 SP2. This method has been replaced by
   * {@link #getListOfAvailableTasksToReserve(String, String, long)} because 
   * the algorithm for determining the list of tasks has changed to return 
   * a set number of tasks to process rather than just one. See release note 
   * CR00290609.
   */
  @Deprecated
  @AccessLevel(AccessLevelType.INTERNAL)
  protected TaskIDAndVersionNoDetails getNextTaskToReserve(
    final String userName, final String assigneeType, final long assigneeID)
    throws AppException, InformationalException {
    
    // Task user assignment entity object
    final TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();

    // key and details to read task identifiers
    final TaskIDRelatedIDAndTypeKey userNamePriorityAndAssignedDateTimeKey = new TaskIDRelatedIDAndTypeKey();
    final TaskIDRelatedIDAndTypeKey userNameAndAssignedDateTimeKey = new TaskIDRelatedIDAndTypeKey();

    // Specialized readmulti operation.
    final curam.core.sl.impl.ProcessNextTaskToReserveReadMulti processNextTaskToReserve = new curam.core.sl.impl.ProcessNextTaskToReserveReadMulti();

    // Get the value of the Priority Enabled environment variable
    String priorityEnabled = Configuration.getProperty(
      EnvVars.ENV_WORKFLOW_RESERVENEXTTASK_WITH_PRIORITY_FILTER);

    // If it's not set, use the default
    if (priorityEnabled == null) {
      priorityEnabled = EnvVars.ENV_WORKFLOW_RESERVENEXTTASK_WITH_PRIORITY_FILTER_DEFAULT;
    }

    // If the priority check has been enabled, this will then be used
    // as part of the search key.
    if (priorityEnabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      String priorityOrderString = Configuration.getProperty(
        EnvVars.ENV_WORKFLOW_TASK_PRIORITY_ORDER);

      if (priorityOrderString == null) {
        priorityOrderString = Configuration.getProperty(
          EnvVars.ENV_WORKFLOW_TASK_PRIORITY_ORDER_DEFAULT);
      }

      final String[] priorityArray = priorityOrderString.split(
        CuramConst.gkComma);
      final int numberOfPriorities = priorityArray.length;
      
      // Populate the details to carry out the task assignment search on.
      userNamePriorityAndAssignedDateTimeKey.assigneeType = assigneeType;
     
      if (assigneeType.equals(TARGETITEMTYPE.USER)) {
        userNamePriorityAndAssignedDateTimeKey.relatedName = userName;
        userNamePriorityAndAssignedDateTimeKey.searchByRelatedIDInd = false;
      } else {
        userNamePriorityAndAssignedDateTimeKey.relatedID = assigneeID;
        userNamePriorityAndAssignedDateTimeKey.searchByRelatedIDInd = true;
      }
      userNamePriorityAndAssignedDateTimeKey.assignedDateTime = DateTime.getCurrentDateTime();

      for (int i = 0; i < numberOfPriorities; i++) {

        userNamePriorityAndAssignedDateTimeKey.priority = priorityArray[i];
        taskAssignmentObj.searchUnreservedByAssigneePriorityAndLongestAssignedDateTime(
          userNamePriorityAndAssignedDateTimeKey, processNextTaskToReserve);

        if (processNextTaskToReserve.getNextTaskToBeReserved() != null) {
          // Task with a specified priority has been found.
          break;
        }
      }

      // Task priorities can now be blank. Therefore a call must be made here 
      // if no tasks can be found by searching for tasks with a priority above
      // to check if there are tasks assigned to the user that have a blank 
      // priority and if so their details should be returned.
      if (processNextTaskToReserve.getNextTaskToBeReserved() == null) {       
        // Populate the details to carry out the task assignment search on.
        userNameAndAssignedDateTimeKey.assigneeType = assigneeType;
        if (assigneeType.equals(TARGETITEMTYPE.USER)) {
          userNameAndAssignedDateTimeKey.relatedName = userName;
          userNameAndAssignedDateTimeKey.searchByRelatedIDInd = false;
        } else {
          userNameAndAssignedDateTimeKey.relatedID = assigneeID;
          userNameAndAssignedDateTimeKey.searchByRelatedIDInd = true;
        }
        userNameAndAssignedDateTimeKey.assignedDateTime = curam.util.type.DateTime.getCurrentDateTime();
        taskAssignmentObj.searchUnreservedByAssigneeNullPriorityAndLongestAssignedDateTime(
          userNameAndAssignedDateTimeKey, processNextTaskToReserve);
      }
      
      // If this does not return any results, then the appropriate exception
      // should be raised.
      if (processNextTaskToReserve.getNextTaskToBeReserved() == null) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOINBOX.ERR_TASK_XRV_NO_UNRESERVED_TASK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
      }
    } else {

      // Not searching by priority, but just by name and date time.
      userNameAndAssignedDateTimeKey.assigneeType = assigneeType;
     
      if (assigneeType.equals(TARGETITEMTYPE.USER)) {
        userNameAndAssignedDateTimeKey.relatedName = userName;
        userNameAndAssignedDateTimeKey.searchByRelatedIDInd = false;
      } else {
        userNameAndAssignedDateTimeKey.relatedID = assigneeID;
        userNameAndAssignedDateTimeKey.searchByRelatedIDInd = true;
      }      
      userNameAndAssignedDateTimeKey.assignedDateTime = curam.util.type.DateTime.getCurrentDateTime();

      taskAssignmentObj.searchUnreservedByRelatedIDTypeAndLongestAssignedDateTime(
        userNameAndAssignedDateTimeKey, processNextTaskToReserve);

      if (processNextTaskToReserve.getNextTaskToBeReserved() == null) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOINBOX.ERR_TASK_XRV_NO_UNRESERVED_TASK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

      } // end of read task details by user name and assigned date

    } // end of priority filter check

    // assign task key to reserve new task
    return processNextTaskToReserve.getNextTaskToBeReserved();
  }  
}
