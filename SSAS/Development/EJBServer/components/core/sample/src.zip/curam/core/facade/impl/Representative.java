/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.facade.struct.InformationalMsgDetailsList;
import curam.core.facade.struct.ReadByAlternateIDDetails;
import curam.core.facade.struct.RepresentativeAlternateIDKey;
import curam.core.facade.struct.RepresentativeContextDescriptionDetails;
import curam.core.facade.struct.RepresentativeContextKey;
import curam.core.facade.struct.RepresentativeHomePageDetails;
import curam.core.facade.struct.RepresentativeID;
import curam.core.facade.struct.RepresentativeKey;
import curam.core.facade.struct.RepresentativeList;
import curam.core.facade.struct.RepresentativeRegistrationDetails;
import curam.core.facade.struct.RepresentativeSearchKey;
import curam.core.facade.struct.RepresentativeSummaryDetails;
import curam.core.impl.CuramConst;
import curam.core.sl.fact.RepresentativeFactory;
import curam.core.struct.InformationalMsgDtls;
import curam.message.SEPARATOR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for the Representative
 * presentation layer.
 *
 */
public abstract class Representative extends
  curam.core.facade.base.Representative {

  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by
   * {@link SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.getProgramLocale())}.
   * Constant for the separator used in the context description.
   * Replacement reason - static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note <CR00219408>.
   */
  @Deprecated
  // BEGIN, CR00023323, SK
  protected static final String kSeparator =
    //BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();
    //END, CR00163471, JC
  // END, CR00023323
  // END, CR00222190

  /**
   * Method to register a Representative to the organization.
   *
   * @param representativeRegistrationDetails details of representative
   *
   */
  public RepresentativeID registerRepresentative(
    RepresentativeRegistrationDetails representativeRegistrationDetails)
    throws AppException, InformationalException {

    RepresentativeID representativeID = new RepresentativeID();

    // service layer representative object
    curam.core.sl.intf.Representative representativeObj =
      curam.core.sl.fact.RepresentativeFactory.newInstance();

    representativeObj.registerRepresentative(
      representativeRegistrationDetails.representativeRegistrationDetails);

    representativeID.representativeID =
      representativeRegistrationDetails.representativeRegistrationDetails.representativeDtls.concernRoleID;

    return representativeID;

  }

  // ___________________________________________________________________________
  /**
   * Method to view a Representative's Homepage details.
   *
   * @param representativeKey contains participantRoleID
   *
   * @return details of the representative
   *
   */
  public RepresentativeHomePageDetails viewRepresentativeHomePage(
    RepresentativeKey representativeKey)
    throws AppException, InformationalException {

    // service layer representative object
    curam.core.sl.intf.Representative representativeObj =
      curam.core.sl.fact.RepresentativeFactory.newInstance();

    // return struct
    RepresentativeHomePageDetails representativeHomePageDetails =
      new RepresentativeHomePageDetails();

    // call service layer method
    representativeHomePageDetails.representativeDetails =
      representativeObj.viewRepresentativeDetails(
        representativeKey.representativeKey);

    // read context information
    representativeHomePageDetails.representativeContextDescriptionDetails =
      readRepresentativeContextDescription(representativeHomePageDetails);

    return representativeHomePageDetails;
  }

  // BEGIN, CR00016578, SPD
  // ___________________________________________________________________________
  /**
   * Method to modify a Representative's details.
   *
   * @param representativeSummaryDetails modified representative details
   *
   * @return InformationalMsgDetailsList list of informationals
   */
  public InformationalMsgDetailsList modifyRepresentative(
    RepresentativeSummaryDetails representativeSummaryDetails)
    throws AppException, InformationalException {

    // Informational message list
    InformationalMsgDetailsList informationalMsgDetailsList =
      new InformationalMsgDetailsList();

    // service layer representative object
    curam.core.sl.intf.Representative representativeObj =
      RepresentativeFactory.newInstance();

    // call service layer method
    representativeObj.modifyRepresentativeSummaryDetails(
      representativeSummaryDetails.representativeSummaryDetails);

    // Create an informational manager
    curam.util.exception.InformationalManager informationalManager =
      curam.util.transaction.TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationalMsgDetailsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationalMsgDetailsList;
  }

  // END, CR00016578

  // ___________________________________________________________________________
  /**
   * Method to return a context description for a Representative.
   *
   * @param representativeContextKey contains representative id
   *
   * @return context string
   *
   */
  public RepresentativeContextDescriptionDetails readRepresentativeContextDescription(RepresentativeContextKey
    representativeContextKey)
    throws AppException, InformationalException {

    RepresentativeKey representativeKey = new RepresentativeKey();

    representativeKey.representativeKey.representativeID =
      representativeContextKey.representativeID;

    return readRepresentativeContextDescription(
      viewRepresentativeHomePage(representativeKey));
  }

  // ___________________________________________________________________________
  /**
   * Method to return a context description for a Representative.
   *
   * @param representativeHomePageDetails contains representative details
   *
   * @return context string
   *
   */
  public RepresentativeContextDescriptionDetails readRepresentativeContextDescription(RepresentativeHomePageDetails
    representativeHomePageDetails)
    throws AppException, InformationalException {

    final int kTempBufferSize = 64;
    StringBuffer temp = new StringBuffer(kTempBufferSize);

    // return struct
    RepresentativeContextDescriptionDetails representativeContextDescriptionDetails =
      new RepresentativeContextDescriptionDetails();

    // build context string
    // BEGIN, CR00222190, ELG
    // BEGIN, CR00098942, SAI
    representativeContextDescriptionDetails.description
      = temp.append(representativeHomePageDetails.representativeDetails
          .representativeDetails.representativeName)
          .append(CuramConst.gkSpace)
          .append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
              TransactionInfo.getProgramLocale()))
          .append(representativeHomePageDetails.representativeDetails
              .representativeDetails.alternateID).toString();
    // END, CR00098942
    // END, CR00222190
    return representativeContextDescriptionDetails;

  }

  // ___________________________________________________________________________
  /**
   * Method to check if there is a Representative registered with a specific
   * alternateID.
   *
   * @param representativeAlternateIDKey contains alternate ID
   *
   * @return details of representative
   *
   */
  public ReadByAlternateIDDetails readByAlternateID(RepresentativeAlternateIDKey
    representativeAlternateIDKey)
    throws AppException, InformationalException {

    // service layer representative object
    curam.core.sl.intf.Representative representativeObj =
      curam.core.sl.fact.RepresentativeFactory.newInstance();

    // return struct
    ReadByAlternateIDDetails readByAlternateIDDetails =
      new ReadByAlternateIDDetails();

    // call service layer method
    readByAlternateIDDetails.readByAlternateIDDetails =
      representativeObj.readByAlternateID(
        representativeAlternateIDKey.representativeAlternateIDKey);

    return readByAlternateIDDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to search for matching Representatives.
   *
   * @param key the search key
   *
   * @return list of matching representatives
   *
   */
  public RepresentativeList search(RepresentativeSearchKey key)
    throws AppException, InformationalException {

    // service layer representative object
    curam.core.sl.intf.Representative representativeObj =
      curam.core.sl.fact.RepresentativeFactory.newInstance();

    // return struct
    RepresentativeList representativeList = new RepresentativeList();

    // call service layer method
    representativeList.dtls = representativeObj.search(key.dtls);

    return representativeList;
  }

}

