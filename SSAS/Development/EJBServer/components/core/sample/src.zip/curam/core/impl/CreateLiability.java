/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005, 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;

import curam.core.sl.entity.struct.ClientInteractionDtls;
import curam.core.sl.event.impl.LiabilityInstrumentEvent;
import curam.core.sl.fact.ClientInteractionFactory;
import curam.core.sl.intf.ClientInteraction;
import curam.core.struct.CreateLiabilityInstructionResult;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.FinancialInstructionStatusDtls;
import curam.core.struct.LiabilityInstructionDetails;
import curam.core.struct.LiabilityInstructionDtls;
import curam.core.struct.LiabilityInstrumentDetails;
import curam.core.struct.LiabilityInstrumentDtls;
import curam.core.struct.UniqueIDKeySet;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.transaction.TransactionInfo;


/**
 * Code for creating liabilities
 *
 */
public abstract class CreateLiability extends curam.core.base.CreateLiability {

  // BEGIN, CR00207419, RK
  @Inject
  protected EventDispatcherFactory<LiabilityInstrumentEvent>
    liabilityInstrumentEventsDispatcher;
  
  // ___________________________________________________________________________
  /**
   * Constructor for the class to allow Guice injection.
   */
  public CreateLiability() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  // END, CR00207419
  
  // ___________________________________________________________________________
  /**
   * Create liability instruction by details given.
   *
   * @param liabilityInstructionDetails Input liability instruction details
   *
   * @return Liability Instruction details
   */
  public CreateLiabilityInstructionResult createLiabilityInstruction(
    LiabilityInstructionDetails liabilityInstructionDetails)
    throws AppException, InformationalException {

    // createLiabilityInstructionResult variable
    CreateLiabilityInstructionResult createLiabilityInstructionResult =
      new CreateLiabilityInstructionResult();

    // liabilityInstruction manipulation variables
    curam.core.intf.LiabilityInstruction liabilityInstructionObj =
      curam.core.fact.LiabilityInstructionFactory.newInstance();
    LiabilityInstructionDtls liabilityInstructionDtls =
      new LiabilityInstructionDtls();

    // financialInstruction manipulation variables
    curam.core.intf.FinancialInstructionStatus financialInstructionStatusObj =
      curam.core.fact.FinancialInstructionStatusFactory.newInstance();
    FinancialInstructionStatusDtls finInstructionStatusDtls =
      new FinancialInstructionStatusDtls();

    // financialInstruction manipulation variable
    FinancialInstructionDtls financialInstructionDtls =
      new FinancialInstructionDtls();

    liabilityInstructionDtls.assign(
      createLiabilityInstructionResult.liabilityInstructionDtls);
    financialInstructionDtls.assign(
      createLiabilityInstructionResult.financialInstructionDtls);

    // Create the liability financial instruction
    createLiabilityFinInstruction(liabilityInstructionDetails,
      financialInstructionDtls);

    // liabilityInstruction identifier
    long liabilityInstructionID = 0;

    // generate uniqueID for insert
    liabilityInstructionID =
      curam.core.fact.UniqueIDFactory.newInstance().getNextID();

    // set liabilityInstructionDtls for insert
    liabilityInstructionDtls.assign(liabilityInstructionDetails);

    liabilityInstructionDtls.liabInstructionID = liabilityInstructionID;
    liabilityInstructionDtls.finInstructionID =
      financialInstructionDtls.finInstructionID;
    liabilityInstructionDtls.creationDate =
      curam.util.transaction.TransactionInfo.getSystemDate();

    // insert liabilityInstruction
    liabilityInstructionObj.insert(liabilityInstructionDtls);

    // financialInstructionStatus identifier
    long finInstructionStatusID = 0;

    // generate uniqueID for insert
    finInstructionStatusID =
      curam.core.fact.UniqueIDFactory.newInstance().getNextID();

    // Map structure
    finInstructionStatusDtls.finInstructionID =
      financialInstructionDtls.finInstructionID;

    // set statusCode to 'Created' for update
    finInstructionStatusDtls.statusCode =
      curam.codetable.FININSTRUCTIONSTATUS.CREATED;
    finInstructionStatusDtls.statusDate =
      curam.util.transaction.TransactionInfo.getSystemDate();
    finInstructionStatusDtls.finInstructionStatusID = finInstructionStatusID;

    // insert financialInstruction
    financialInstructionStatusObj.insert(finInstructionStatusDtls);

    // map to output struct
    createLiabilityInstructionResult.liabilityInstructionDtls.assign(
      liabilityInstructionDtls);
    createLiabilityInstructionResult.financialInstructionDtls.assign(
      financialInstructionDtls);

    // BEGIN CR00074870, FOD: create a ClientInteraction of type Liability Issued
    String createClientInteraction =
      curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_INTERACTION_FOR_LIABILITY_FINANCIAL_INSTRUCTION);

    if (createClientInteraction == null) {

      createClientInteraction =
        EnvVars.ENV_INTERACTION_FOR_LIABILITY_FINANCIAL_INSTRUCTION_DEFAULT;
    }
    if (createClientInteraction.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      // BEGIN, CR00192165, VM
      ClientInteractionDtls clientInteractionDtls = new ClientInteractionDtls();
      ClientInteraction clientInteractionObj =
      ClientInteractionFactory.newInstance();
      // END, CR00192165

      clientInteractionDtls.concernRoleID =
        liabilityInstructionDetails.concernRoleID;
      clientInteractionDtls.description =
        //BEGIN, CR00163471, JC
        curam.message.BPOCREATEPAYMENTS.INF_PAYMENT.getMessageText(TransactionInfo.getProgramLocale());
        //END, CR00163471, JC
      clientInteractionDtls.interactionDateTime =
        curam.util.type.DateTime.getCurrentDateTime();
      clientInteractionDtls.interactionTypeCode =
        curam.codetable.INTERACTIONTYPE.LIABILITYISSUED;
      clientInteractionDtls.relatedID =
        financialInstructionDtls.finInstructionID;
      clientInteractionDtls.relatedType =
        curam.codetable.RELATEDINTERACTIONTYPE.PAYMENT;

      // BEGIN, CR00192165, VM
      clientInteractionObj.recordClientInteraction(clientInteractionDtls);
      // END, CR00192165
    }
    // END CR00074870

    return createLiabilityInstructionResult;
  }

  // ___________________________________________________________________________
  /**
   * Create liability instrument by details given.
   *
   * @param liabilityInstrumentDetails Input liability instrument details
   *
   * @return Liability instrument details inserted
   */
  public LiabilityInstrumentDtls createLiabilityInstrument(
    LiabilityInstrumentDetails liabilityInstrumentDetails)
    throws AppException, InformationalException {

    // liabilityInstrument details
    LiabilityInstrumentDtls liabilityInstrumentDtls =
      new LiabilityInstrumentDtls();

    // liabilityInstrument object
    curam.core.intf.LiabilityInstrument liabilityInstrumentObj =
      curam.core.fact.LiabilityInstrumentFactory.newInstance();

    // uniqueID manipulation variables
    curam.core.intf.UniqueID uniqueIDObj =
      curam.core.fact.UniqueIDFactory.newInstance();
    UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    // set liabilityInstrument details
    liabilityInstrumentDtls.assign(liabilityInstrumentDetails);

    liabilityInstrumentDtls.effectiveDate =
      liabilityInstrumentDetails.effectiveDate;

    // liabilityInstruction identifier
    long liabilityInstrumentID = 0;

    // get unique identifier
    uniqueIDKeySet.keySetName = KeySets.KEY_SET_LIABILITY;
    liabilityInstrumentID = uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet);

    liabilityInstrumentDtls.liabInstrumentID = liabilityInstrumentID;
    liabilityInstrumentDtls.creationDate =
      curam.util.transaction.TransactionInfo.getSystemDate();

    // liabilityInstrument insert
    liabilityInstrumentObj.insert(liabilityInstrumentDtls);

    // BEGIN, CR00207419, RK
    liabilityInstrumentEventsDispatcher.get(LiabilityInstrumentEvent.class)
        .overpaymentIssued(liabilityInstrumentDtls);
    // END, CR00207419
    
    return liabilityInstrumentDtls;

  }

  // ___________________________________________________________________________
  /**
   * To create a Financial instruction record for the liability instruction
   *
   * @param liabilityInstructionDetails Liability instruction details
   * @param financialInstructionDtls Financial instruction details
   */
  public void createLiabilityFinInstruction(LiabilityInstructionDetails
    liabilityInstructionDetails, FinancialInstructionDtls
    financialInstructionDtls) throws AppException, InformationalException {

    // financialInstruction identifier
    long financialInstructionID = 0;

    // financialInstruction manipulation variable
    curam.core.intf.FinancialInstruction financialInstructionObj =
      curam.core.fact.FinancialInstructionFactory.newInstance();

    // generate unique ID
    financialInstructionID =
      curam.core.fact.UniqueIDFactory.newInstance().getNextID();

    // set financialInstructionDtls for insert
    financialInstructionDtls.finInstructionID = financialInstructionID;

    // set typeCode to 'Liability' (LBY)
    financialInstructionDtls.typeCode =
      curam.codetable.FINANCIALINSTRUCTION.LIABILITY;
    financialInstructionDtls.concernRoleID =
      liabilityInstructionDetails.concernRoleID;

    // set statusCode to 'Created' (CRE)
    financialInstructionDtls.statusCode =
      curam.codetable.FININSTRUCTIONSTATUS.CREATED;
    financialInstructionDtls.amount = liabilityInstructionDetails.amount;
    financialInstructionDtls.effectiveDate =
      liabilityInstructionDetails.effectiveDate;
    financialInstructionDtls.postingDate =
      curam.util.type.Date.getCurrentDate();

    // set creditDebitType to 'Debit' (DBT)
    financialInstructionDtls.creditDebitType =
      curam.codetable.CREDITDEBIT.DEBIT;
    financialInstructionDtls.currencyTypeCode =
      liabilityInstructionDetails.currencyTypeCode;
    financialInstructionDtls.currencyExchangeID =
      liabilityInstructionDetails.currencyExchangeID;
    financialInstructionDtls.instrumentGenInd =
      liabilityInstructionDetails.instrumentGenInd;
    financialInstructionDtls.comments = liabilityInstructionDetails.comments;

    // financialInstruction insert
    financialInstructionObj.insert(financialInstructionDtls);

  }

}
