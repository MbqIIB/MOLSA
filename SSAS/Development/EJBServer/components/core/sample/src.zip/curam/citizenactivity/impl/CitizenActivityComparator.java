/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.citizenactivity.impl;


import com.google.inject.ImplementedBy;

import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Implementable;

import java.util.Comparator;


/**
 * Used to order citizen activities for display in the Citizen Workspace. The
 * default implementation orders the activities by the start date of their date
 * range.
 *
 * @since 6.0
 */
@ImplementedBy(CitizenActivityComparatorImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
@Implementable
public interface CitizenActivityComparator extends Comparator<CitizenActivity> {}
