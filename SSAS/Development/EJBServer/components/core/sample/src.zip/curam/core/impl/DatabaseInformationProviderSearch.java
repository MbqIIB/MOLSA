/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2009, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

/**
 * InformationProvider search in Database
 *
 */

package curam.core.impl;


import curam.core.sl.struct.ParticipantSearchKey;
import curam.core.struct.InfoProviderSearchDtls;
import curam.core.struct.InfoProviderSearchKey;
import curam.core.struct.InfoProviderSearchResult;
import curam.core.struct.InformationProviderDatabaseSearchKey;
import curam.core.struct.InformationProviderSummaryDetails;
import curam.core.struct.InformationProviderSummaryDetailsList;
import curam.core.struct.ReadInformationProviderSummaryKey;
import curam.core.struct.SearchMessageDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;

/**
 * @deprecated Since Curam 6.0, This class is replaced by
 * {@link curam.core.sl.impl.DatabaseParticipantSearch}
 *
 * Information Provider search in Database.
 */
@Deprecated
public abstract class DatabaseInformationProviderSearch extends curam.core.base.DatabaseInformationProviderSearch {

  // ___________________________________________________________________________
  /**
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.sl.impl.DatabaseParticipantSearch#search(ParticipantSearchKey)}
   *
   * Performs a database search for information providers using the specified
   * search criteria, or performs a database read if the alternate ID is
   * specified.
   *
   * @param key data on which the searched will be based
   *
   * @return The details of any records found
   *
   */
  @Deprecated
  public InfoProviderSearchResult search(InfoProviderSearchKey key)
    throws AppException, InformationalException {

    // Information Provider Object and structs
    InfoProviderSearchResult infoProviderSearchResult =
      new InfoProviderSearchResult();
    InformationProviderSummaryDetailsList informationProviderSummaryDetailsList =
      new InformationProviderSummaryDetailsList();
    ReadInformationProviderSummaryKey readInformationProviderSummaryKey =
      new ReadInformationProviderSummaryKey();
    curam.core.intf.InformationProvider informationProviderObj =
      curam.core.fact.InformationProviderFactory.newInstance();

    // If the reference number is specified no need to process the complicated
    // query
    if (key.referenceNumber.length() == 0) {

      InformationProviderDatabaseSearchKey informationProviderDatabaseSearchKey =
        calculateKey(key);

      try {
        informationProviderSummaryDetailsList =
          informationProviderObj.searchByNameOrAddress(
            informationProviderDatabaseSearchKey);
      } catch (curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage =
          //BEGIN, CR00163471, JC
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS.getMessageText(TransactionInfo.getProgramLocale());
          //END, CR00163471, JC

        infoProviderSearchResult.messages.dtls.addRef(recordFoundMessage);

      }

      // BEGIN CR00020852, SG
    } else {
      // set the search key
      readInformationProviderSummaryKey.primaryAlternateID =
        key.referenceNumber;
      try {
        informationProviderSummaryDetailsList =
          informationProviderObj.readSummaryDetailsByReferenceNumber(
            readInformationProviderSummaryKey);
      } catch (curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage =
          //BEGIN, CR00163471, JC
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS.getMessageText(TransactionInfo.getProgramLocale());
          //END, CR00163471, JC

        infoProviderSearchResult.messages.dtls.addRef(recordFoundMessage);

      }

    }
    // END CR00020852

    infoProviderSearchResult.result.numRecordsFound =
      informationProviderSummaryDetailsList.dtls.size();

    for (int i = 0; i < informationProviderSummaryDetailsList.dtls.size(); i++) {

      // Search details
      InfoProviderSearchDtls infoProviderSearchDtls =
        new InfoProviderSearchDtls();

      InformationProviderSummaryDetails informationProviderSummaryDetails =
        informationProviderSummaryDetailsList.dtls.item(i);

      infoProviderSearchDtls.assign(informationProviderSummaryDetails);
      infoProviderSearchDtls.address =
        informationProviderSummaryDetails.addressLine1;

      restrictResults(infoProviderSearchDtls);

      if (infoProviderSearchDtls.referenceNumber != null) {
        infoProviderSearchResult.details.dtls.addRef(infoProviderSearchDtls);
      }

    }

    return infoProviderSearchResult;
  }

  // ___________________________________________________________________________
  /**
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.sl.impl.DatabaseParticipantSearch#calculateKey(ParticipantSearchKey)}
   *
   * Calculates the details of the database search key based on the key
   *
   * @param key search details
   *
   * @return Key for database search
   *
   */
  @Deprecated
  protected InformationProviderDatabaseSearchKey calculateKey(
    InfoProviderSearchKey key)
    throws AppException, InformationalException {

    InformationProviderDatabaseSearchKey informationProviderDatabaseSearchKey =
      new InformationProviderDatabaseSearchKey();

    // Assign the key values
    informationProviderDatabaseSearchKey.name =
      CuramConst.gkSqlWildcard + key.name.toUpperCase()
      + CuramConst.gkSqlWildcard;

    informationProviderDatabaseSearchKey.addressLine1 =
      CuramConst.gkSqlWildcard + key.address.toUpperCase()
      + CuramConst.gkSqlWildcard;

    informationProviderDatabaseSearchKey.city =
      CuramConst.gkSqlWildcard + key.city.toUpperCase()
      + CuramConst.gkSqlWildcard;

    // If a parameter is specified set the searchBy indicator for that parameter
    informationProviderDatabaseSearchKey.searchByName = (key.name.length() > 0);
    informationProviderDatabaseSearchKey.searchByAddressLine1 =
      (key.address.length() > 0);
    informationProviderDatabaseSearchKey.searchByCity = (key.city.length() > 0);

    return informationProviderDatabaseSearchKey;
  }
}
