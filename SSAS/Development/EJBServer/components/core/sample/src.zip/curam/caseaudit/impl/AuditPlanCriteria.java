/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import com.google.inject.ImplementedBy;

import curam.util.persistence.Insertable;
import curam.util.persistence.Removable;

/**
 * Audit Plan Criteria.
 * 
 */
@ImplementedBy(AuditPlanCriteriaImpl.class)
public interface AuditPlanCriteria 
  extends Insertable, Removable, AuditPlanCriteriaAccessor {

  // ___________________________________________________________________________
  /**
   * Sets the audit plan.
   * 
   * @param auditPlan The audit plan.
   */
  public void setAuditPlan(final AuditPlan auditPlan);

  // ___________________________________________________________________________
  /**
   * Sets the business name of the criteria used by the audit coordinator 
   * to generate the random case sample.
   * 
   * @param name
   *          The business name of the criteria used by the audit coordinator 
   *          to generate the random case sample.
   */
  public void setName(final String name);

  // ___________________________________________________________________________
  /**
   * Sets the criteria value entered by the audit coordinator during random
   * case sample generation.
   * 
   * @param value
   *          The criteria value entered by the audit coordinator during random
   *          case sample generation.
   */
  public void setValue(final String value);

}
