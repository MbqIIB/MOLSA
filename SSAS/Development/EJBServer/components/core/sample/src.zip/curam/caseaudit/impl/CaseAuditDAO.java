/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.List;
import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.CASEAUDITSTATUSEntry;
import curam.codetable.impl.FOCUSAREASATISFIEDEntry;
import curam.core.struct.Count;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;
import curam.util.type.StringList;


/**
 * Data access for {@linkplain curam.caseaudit.impl.CaseAudit}.
 */
@ImplementedBy(CaseAuditDAOImpl.class)
public interface CaseAuditDAO extends StandardDAO<CaseAudit> {

  // ___________________________________________________________________________
  /**
   * Returns a list of CaseAudits for the specified AuditPlan.
   *
   * @param auditPlan
   * the AuditPlan for which CaseAudit records are required
   *
   * @return list of CaseAudit records for an AuditPlan.
   */
  public Set<CaseAudit> searchByAuditPlan(final AuditPlan auditPlan);
  
  // ___________________________________________________________________________
  /**
   * Returns a list of CaseAudits for the specified criteria.
   *
   * @param auditPlan
   * the AuditPlan for which CaseAudit records are required
   * @param caseAuditReference The reference of the case audit
   * @param auditor The auditor of the case audit
   * @param focusAreasMet Whether or not the focus areas were met
   * @param caseAuditStatus Status of the case audit.
   *
   * @return list of CaseAudit records for the criteria.
   */
  public Set<CaseAudit> searchCaseAudits(final AuditPlan auditPlan,
    final String caseAuditReference, final Auditor auditor,
    final FOCUSAREASATISFIEDEntry focusAreasMet,
    final CASEAUDITSTATUSEntry caseAuditStatus)
    throws AppException, InformationalException;
  
  // ___________________________________________________________________________
  /**
   * Returns a list of CaseAudits for the specified Focus Area Type and Audit
   * Plan filtered by whether the focus area has been completed and/or met.
   *
   * @param auditPlan - the AuditPlan for which CaseAudit records are required
   * @param auditPlanFocusArea - the focus area
   * @param focusAreaMet - whether or not the focus area was satisfied
   *
   * @return list of CaseAudit records for the specified Focus Area Type and 
   * Audit Plan.
   */
  public Set<CaseAudit> searchCaseAuditsForFocusArea(final AuditPlan auditPlan,
    final AuditPlanFocusArea auditPlanFocusArea, 
    final FOCUSAREASATISFIEDEntry focusAreaMet)
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Returns a list of CaseAudits for the specified AuditPlan and Case.
   *
   * @param auditPlan
   * the AuditPlan for which CaseAudit records are required
   * @param caseHeader The case in question
   *
   * @return list of CaseAudit records for an AuditPlan and case.
   */
  public List<CaseAudit> searchByAuditPlanAndCase(final AuditPlan auditPlan,
    final CaseHeader caseHeader);
  
  // ___________________________________________________________________________
  /**
   * Returns a list of CaseAudits for the specified AuditPlan and Case Audit 
   * Status.
   *
   * @param auditPlan
   * the AuditPlan for which CaseAudit records are required
   * @param caseAuditStatus The case audit status
   *
   * @return list of CaseAudit records for an AuditPlan and status.
   */
  public List<CaseAudit> searchByAuditPlanAndStatus(final AuditPlan auditPlan,
    final CASEAUDITSTATUSEntry caseAuditStatus);
  
  // ___________________________________________________________________________
  /**
   * Returns a list of CaseAudits for the specified auditor filtered by 
   * audit teams which they are a member of and also by case audit status. 
   *
   * @param assignedToList
   * the list of audit teams which the current user is a member of
   * and which may have been assigned case audits        
   * @param statusList
   * a list of audit status values         
   *
   * @return list of CaseAudit records for an Auditor.
   */
  public List<CaseAudit> searchByAssignedAuditorAndStatus(
    final StringList assignedToList, final StringList statusList)
    throws AppException, InformationalException;
  
  // ___________________________________________________________________________
  /**
   * Returns a list of CaseAudits for the specified search criteria.
   *
   * @param auditPlanRef An Audit Plan Reference
   * @param caseAuditRef A Case Audit Reference
   * @param auditCaseConfig An Audit Case Config object
   * @param caseAuditStatus The status of the case audits
   * @param auditor The username of the auditor assigned to the case audits
   * @param coordinator The username of the coordinator of the audits
   *
   * @return list of CaseAudit records for the search criteria.
   */
  public List<CaseAudit> searchAllCaseAudits(final String auditPlanRef,
    final String caseAuditRef, final AuditCaseConfig auditCaseConfig,
    final CASEAUDITSTATUSEntry caseAuditStatus,
    final String auditor, final String coordinator)
    throws AppException, InformationalException;
  
  // ___________________________________________________________________________
  /**
   * Returns a list of Case Audits for a specified user, that is, where the user
   * is assigned to the case audit or where the user is a member of a team
   * assigned to the case audit.
   *
   * @param userName
   * the user for which CaseAudit records are required
   *
   * @return list of CaseAudit records for the user.
   */
  public Set<CaseAudit> searchByUserName(final String userName)
    throws AppException, InformationalException;
  
  // BEGIN, CR00290965, IBM
  /**
   * Retrieves the total number of case audit plan count with the given 
   * specified search criteria.
   *
   * @param auditPlan contains audit plan for which case audit records are required
   * @param auditPlanFocusArea contains audit plan focus area
   * @param focusAreaMet whether or not the focus area was satisfied
   *
   * @return count of case audit focus area
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  public Count countCaseAuditByFocusArea(final AuditPlan auditPlan,
    final AuditPlanFocusArea auditPlanFocusArea, 
    final FOCUSAREASATISFIEDEntry focusAreaMet)
    throws AppException, InformationalException;
  // END, CR00290965
}
