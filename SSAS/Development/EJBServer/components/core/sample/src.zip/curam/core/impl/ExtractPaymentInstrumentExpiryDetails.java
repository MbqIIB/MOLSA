/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.DateStruct;
import curam.core.struct.FinInstructionID;
import curam.core.struct.FinInstructionIDStatus;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.FinancialInstructionKey;
import curam.core.struct.ILIFinInstructID;
import curam.core.struct.ILIStatusCode;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.InstructionLineItemKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PIExpiredPaymentDtls;
import curam.core.struct.PIReconcilStatusCode;
import curam.core.struct.PaymentInstrumentKey;
import curam.core.struct.PmtInstrumentID;
import curam.core.struct.ReverseFinInstructionSummary;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class provides a method to extract pay slip details in string
 * form, that are suitable for writing the record to a file.
 *
 */

public abstract class ExtractPaymentInstrumentExpiryDetails extends curam.core.base.ExtractPaymentInstrumentExpiryDetails {

  curam.core.intf.PaymentInstrument paymentInstrumentObj =
    curam.core.fact.PaymentInstrumentFactory.newInstance();

  // financialInstruction manipulation variables
  curam.core.intf.FinancialInstruction financialInstructionObj =
    curam.core.fact.FinancialInstructionFactory.newInstance();

  // paymentInstruction manipulation variable
  curam.core.intf.PaymentInstruction paymentInstructionObj =
    curam.core.fact.PaymentInstructionFactory.newInstance();

  // createReversal manipulation variable
  curam.core.intf.CreateReversal createReversalObj =
    curam.core.fact.CreateReversalFactory.newInstance();

  // instructionLineItem manipulation variables
  curam.core.intf.InstructionLineItem instructionLineItemObj =
    curam.core.fact.InstructionLineItemFactory.newInstance();

  // address manipulation variables
  curam.core.intf.Address addressObj =
    curam.core.fact.AddressFactory.newInstance();

  curam.core.intf.MaintainFinInstruction maintainFinInstructionObj =
    curam.core.fact.MaintainFinInstructionFactory.newInstance();

  // __________________________________________________________________________
  /**
   * Given a pay slip details object this method will return extract lines for
   * writing to a file.
   *
   * @param piExpiredPaymentDtls Payment instrument expired payment details
   * @param expiryDate the expiry date
   *
   * @return The extract lines to be written to the output file
   *
   */
  public String extractDetails(
    PIExpiredPaymentDtls piExpiredPaymentDtls,
    DateStruct expiryDate)
    throws AppException, InformationalException {

    PmtInstrumentID pmtInstrumentID = new PmtInstrumentID();
    FinInstructionID finInstructionID;

    ReverseFinInstructionSummary reverseFinInstructionSummary =
      new ReverseFinInstructionSummary();
    PIReconcilStatusCode piStatusCodeVersionNo = new PIReconcilStatusCode();
    PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();

    FinancialInstructionKey financialInstructionKey =
      new FinancialInstructionKey();
    FinancialInstructionDtls financialInstructionDtls;

    ILIFinInstructID iliFinInstructID = new ILIFinInstructID();
    InstructionLineItemDtlsList instructionLineItemDtlsList;
    ILIStatusCode iliStatusCode = new ILIStatusCode();
    InstructionLineItemKey instructionLineItemKey =
      new InstructionLineItemKey();

    AddressKey addressKey = new AddressKey();
    AddressDtls addressDtls;
    OtherAddressData otherAddressData = new OtherAddressData();

    FinInstructionIDStatus finInstructionStatus = new FinInstructionIDStatus();

    pmtInstrumentID.assign(piExpiredPaymentDtls);

    // read Payment Instrument
    finInstructionID =
      paymentInstructionObj.readByPmtInstrumentID(pmtInstrumentID);

    reverseFinInstructionSummary.assign(finInstructionID);
    reverseFinInstructionSummary.assign(piExpiredPaymentDtls);
    reverseFinInstructionSummary.reversalReasonCode =
      curam.codetable.REVERSALREASON.PMTEXPIRED;
    // BEGIN, CR00049218, GM
    reverseFinInstructionSummary.reversalComments = CuramConst.gkEmpty;
    // END, CR00049218

    // reverse financial instruction
    createReversalObj.reverseFinInstruction(reverseFinInstructionSummary);

    // updating the status code of all expired records to expired
    paymentInstrumentKey.pmtInstrumentID = piExpiredPaymentDtls.pmtInstrumentID;
    piStatusCodeVersionNo.reconcilStatusCode =
      curam.codetable.PMTRECONCILIATIONSTATUS.EXPIRED;
    piStatusCodeVersionNo.versionNo = piExpiredPaymentDtls.versionNo;

    // update payment instrument status code
    paymentInstrumentObj.modifyReconcilStatusCode(paymentInstrumentKey,
      piStatusCodeVersionNo);

    // set key to read instructionLineItem
    iliFinInstructID.finInstructionID = finInstructionID.finInstructionID;

    // read instructionLineItem
    instructionLineItemDtlsList =
      instructionLineItemObj.searchByFinInstructID(iliFinInstructID);

    for (int i = 0; i < instructionLineItemDtlsList.dtls.size(); i++) {

      // set the status of the payment ILI to indicate it is canceled
      iliStatusCode.statusCode = curam.codetable.ILISTATUS.EXPIRED;
      iliStatusCode.versionNo =
        instructionLineItemDtlsList.dtls.item(i).versionNo;

      instructionLineItemKey.instructLineItemID =
        instructionLineItemDtlsList.dtls.item(i).instructLineItemID;

      instructionLineItemObj.modifyStatusCode(instructionLineItemKey,
        iliStatusCode);
    }

    // set key to read financialInstruciton entity
    financialInstructionKey.finInstructionID =
      finInstructionID.finInstructionID;

    // read financialInstruction entity
    financialInstructionDtls =
      financialInstructionObj.read(financialInstructionKey);

    // set details for modifying financialInstruction status
    finInstructionStatus.finInstructionID = finInstructionID.finInstructionID;
    finInstructionStatus.statusCode =
      curam.codetable.FININSTRUCTIONSTATUS.EXPIRED;
    finInstructionStatus.versionNo = financialInstructionDtls.versionNo;

    // update financialInstruction status
    maintainFinInstructionObj.updateFinInstructionStatus(finInstructionStatus);

    // string buffer variables
    final int kRecordSize = 4096;
    StringBuffer recIdentifier = new StringBuffer(kRecordSize);

    // set key to read address entity
    addressKey.addressID = piExpiredPaymentDtls.addressID;

    // read address entity
    addressDtls = addressObj.read(addressKey);

    otherAddressData.addressData = addressDtls.addressData;

    addressObj.getOneLineAddressString(otherAddressData);

    curam.util.type.Date effectiveDate = piExpiredPaymentDtls.effectiveDate;

    // creating the output record
    recIdentifier.append(String.valueOf(piExpiredPaymentDtls.pmtInstrumentID))
      .append(CuramConst.gkTabDelimiter)
      .append(piExpiredPaymentDtls.amount.toString()).append(
      CuramConst.gkTabDelimiter);

    // BEGIN, CR00086110, POB
    // format effectiveDate
    recIdentifier.append(effectiveDate.toString()).append(
      CuramConst.gkTabDelimiter);

    // format expiryDate
    recIdentifier.append(expiryDate.date.toString())
      .append(CuramConst.gkTabDelimiter)
      .append(String.valueOf(piExpiredPaymentDtls.concernRoleID))
      .append(CuramConst.gkTabDelimiter).append(piExpiredPaymentDtls.nomineeName)
      .append(CuramConst.gkTabDelimiter).append(otherAddressData.addressData)
      .append(
      CuramConst.gkNewLine);
    // END, CR00086110
    
    return recIdentifier.toString();
  }

}
