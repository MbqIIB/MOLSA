/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2007, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.INSURRETURNTYPE;
import curam.core.intf.EmployerInsuranceRetHeaderAssistant;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CreateHeaderKey;
import curam.core.struct.CreateLineItemKey;
import curam.core.struct.EmployerAltSearchDetails;
import curam.core.struct.EmployerAltSearchKey;
import curam.core.struct.FilePathAndName;
import curam.core.struct.InsRetLineItemDtls;
import curam.core.struct.InsurancePeriodControlDtls;
import curam.core.struct.InsurancePeriodNameKey;
import curam.core.struct.InsuranceRetHdrKey;
import curam.core.struct.InsuranceReturnHdrDetails;
import curam.core.struct.PersonAltSearchKey;
import curam.core.struct.PersonDtls;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductNameStructRef;
import curam.core.struct.TicketInfoDetails;
import curam.core.struct.TicketText;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Locale;
import curam.util.resources.ProgramLocale;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Money;


/**
 * The batch process to transfer the contribution return details received from
 * an employer (in electronic format) to the CURAM database.
 *
 */
public abstract class ElectronicEmployerReturn extends curam.core.base.ElectronicEmployerReturn {

  // __________________________________________________________________________
  /**
   * Batch processing of electronic employer return.
   *
   * @param filePath Path to input file
   */
  public void capture(FilePathAndName filePath) throws AppException, InformationalException {

    // variables for employer
    curam.core.intf.Employer employerObj =
      curam.core.fact.EmployerFactory.newInstance();

    EmployerAltSearchDetails employerAltSearchDetails =
      new EmployerAltSearchDetails();

    EmployerAltSearchKey employerAltSearchKey = new EmployerAltSearchKey();

    // variables used to read insurance period control
    curam.core.intf.InsurancePeriodControl insurancePeriodControlObj =
      curam.core.fact.InsurancePeriodControlFactory.newInstance();

    InsurancePeriodNameKey insurancePeriodNameKey =
      new InsurancePeriodNameKey();

    InsurancePeriodControlDtls insurancePeriodControlDtls =
      new InsurancePeriodControlDtls();

    // variables used to create employer insurance return header
    curam.core.intf.EmployerInsuranceRetHeader employerInsuranceRetHeaderObj =
      curam.core.fact.EmployerInsuranceRetHeaderFactory.newInstance();

    CreateHeaderKey createHeaderKey = new CreateHeaderKey();
    InsuranceReturnHdrDetails insuranceReturnHdrDetails =
      new InsuranceReturnHdrDetails();

    InsuranceRetHdrKey insuranceRetHdrKey = new InsuranceRetHdrKey();

    // variables user to create insurance return line item
    curam.core.intf.MaintainInsuranceLineItem maintainInsuranceLineItemObj =
      curam.core.fact.MaintainInsuranceLineItemFactory.newInstance();

    CreateLineItemKey createLineItemKey = new CreateLineItemKey();
    InsRetLineItemDtls insRetLineItemDtls = new InsRetLineItemDtls();

    // Variables used to read person by alternate ID
    curam.core.intf.Person personObj =
      curam.core.fact.PersonFactory.newInstance();

    PersonDtls personDtls;

    PersonAltSearchKey personAltSearchKey = new PersonAltSearchKey();

    // Variable used to read concern role
    curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    ConcernRoleDtls concernRoleDtls;

    // variables used to read product information
    curam.core.intf.Product productObj =
      curam.core.fact.ProductFactory.newInstance();
    ProductNameStructRef productNameStructRef = new ProductNameStructRef();

    ProductDtls productDtls;

    // Variable to store ticket information
    TicketText ticketText = new TicketText();

    // Variable for batch processing
    curam.core.impl.CuramBatch curamBatchObj = new curam.core.impl.CuramBatch();
    StringBuffer emailMessage = new StringBuffer();
    StringBuffer emailMessageText = new StringBuffer();

    // Timing info....
    curam.util.type.DateTime startTime;
    curam.util.type.DateTime endTime;
    curam.util.type.DateTime elapsedTime =
      curam.util.type.DateTime.kZeroDateTime;

    // variables used to read MaintainInsuranceLineItemAssistant
    curam.core.intf.MaintainInsuranceLineItemAssistant maintainInsuranceLineItemAssistantObj =
      curam.core.fact.MaintainInsuranceLineItemAssistantFactory.newInstance();

    // register the security implementation
    SecurityImplementationFactory.register();

    startTime = curam.util.transaction.TransactionInfo.getSystemDateTime();

    // Variable to store the current date
    // based on domain CURAM_DATE

    curam.util.type.Date currentDate =
      curam.util.transaction.TransactionInfo.getSystemDate();

    // File handle
    java.io.LineNumberReader f;
    // Buffer for reading from the file
    String fileBuffer;
    // number of fields in the header
    final int kNumberHeaderFields = 11;
    // number of fields in details
    final int kNumberDetailsFields = 13;

    // Payment received instrument file line variables
    curam.util.type.StringList vectorOfFields =
      new curam.util.type.StringList();

    // variables for Header
    // BEGIN, CR00049218, GM
    String employerNumber = CuramConst.gkEmpty;
    String insReturnPeriod = CuramConst.gkEmpty;
    // END, CR00049218

    Money totEmployeeConAmt = Money.kZeroMoney;
    Money totEmployerConAmt = Money.kZeroMoney;
    Money totConAmt = Money.kZeroMoney;

    int numCasualEmployees = 0;
    int numPermanentEmployees = 0;
    int totNumEmployees = 0;

    Money totPayroll = Money.kZeroMoney;

    // BEGIN, CR00049218, GM
    String contName = CuramConst.gkEmpty;
    String comments = CuramConst.gkEmpty;
    // END, CR00049218

    // variable to flag empty numeric fields
    boolean bTotConAmt = true;

    // temporary variables for Header
    double tmpTotEmployeeConAmt = 0;
    double tmpTotEmployerConAmt = 0;
    double tmpTotConAmt = 0;
    double tmpTotPayroll = 0;

    curam.core.intf.EmployerInsuranceRetHeaderAssistant employerInsuranceRetHeaderAssistantObj =
      curam.core.fact.EmployerInsuranceRetHeaderAssistantFactory.newInstance();

    // field names for the Header
    String fnTotEmployeeConAmt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_TOTEMPLOYEECONAMT.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnTotEmployerConAmt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_TOTEMPLOYERCONAMT.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnTotConAmt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_TOTCONAMT.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnNumCasualEmployees =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_NUMCASUALEMPLOYEES.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnNumPermanentEmployees =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_NUMPERMANENTEMPLOYEES.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnTotNumEmployees =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_TOTNUMEMPLOYEES.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnTotPayroll =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_TOTPAYROLL.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnComments =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_COMMENTS.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    // Variables for Details
    // Fields

    // BEGIN, CR00049218, GM
    String employeeNumberDt = CuramConst.gkEmpty;
    // END, CR00049218
    String employeeFullNameDt;

    Money incomeAmountDt = Money.kZeroMoney;

    // BEGIN, CR00049218, GM
    String insuranceUnitTypeCodeDt = CuramConst.gkEmpty;
    String productNameDt = CuramConst.gkEmpty;
    // END, CR00049218
    short noofInsuranceUnitsDt = 0;

    // based on domain CURAM_DATE
    curam.util.type.Date fromDateDt = curam.util.type.Date.kZeroDate;
    // based on domain CURAM_DATE
    curam.util.type.Date toDateDt = curam.util.type.Date.kZeroDate;

    Money totConAmtDt = Money.kZeroMoney;
    Money totEmployerConAmtDt = Money.kZeroMoney;
    Money totEmployeeConAmtDt = Money.kZeroMoney;

    // BEGIN, CR00049218, GM
    String employmentTypeDt = CuramConst.gkEmpty;
    String commentsDt = CuramConst.gkEmpty;

    ;
    // END, CR00049218

    // temporary variables for the Details
    double tmpIncomeAmountDt = 0;
    // BEGIN, CR00049218, GM
    String tmpFromDateDt = CuramConst.gkEmpty;
    String tmpToDateDt = CuramConst.gkEmpty;
    // END, CR00049218
    double tmpTotConAmtDt = 0;
    double tmpTotEmployerConAmtDt = 0;
    double tmpTotEmployeeConAmtDt = 0;

    // string representation of numeric fields
    String strIncomeAmountDt;
    String strNoofInsuranceUnitsDt;
    String strFromDateDt;
    String strToDateDt;
    String strTotConAmtDt;
    String strTotEmployerConAmtDt;
    String strTotEmployeeConAmtDt;

    // field names for the Details
    String fnEmployeeNumberDt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLOYEENUMBER.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnEmployeeFullNameDt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLOYEEFULLNAME.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnIncomeAmountDt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_INCOMEAMOUNT.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnInsuranceUnitTypeCodeDt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_INSURANCEUNITTYPECODE.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnProductNameDt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_PRODUCTNAME.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnNoofInsuranceUnitsDt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_NOOFINSURANCEUNITS.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnFromDateDt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_FROMDATE.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnToDateDt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_TODATE.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    String fnEmploymentTypeDt =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLOYMENTTYPE.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC

    // Variables for Details processing
    int dtlRecordNumber = 0;
    int dtlItemsCreated = 0;
    int dtlItemsSkipped = 0;

    Money zeroAmount = Money.kZeroMoney;

    StringBuffer nameValuePairs = new StringBuffer();

    boolean headerCreated = false;

    // full file name
    String inFile = filePath.filePath + filePath.fileName;

    // open input file
    try {
      f = new java.io.LineNumberReader(new java.io.FileReader(inFile));
    } catch (java.io.IOException e) {
      AppException noFile =
        new AppException(
          curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_FILENOTFOUND);

      noFile.arg(inFile);

      // BEGIN, CR00163236, CL
      emailMessage.append(noFile.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
      // END, CR00163236
      emailMessageText.append(emailMessage);
      Trace.kTopLevelLogger.info(emailMessage);

      // calculate elapsed time
      endTime = curam.util.transaction.TransactionInfo.getSystemDateTime();

      elapsedTime =
        new curam.util.type.DateTime((endTime.asLong() - startTime.asLong()));

      AppException runtimeText =
        new AppException(curam.message.GENERALBATCH.INF_JOB_RUNTIME);

      // BEGIN, CR00086110, POB
      // Format start time
      runtimeText.arg(Locale.getFormattedTime(startTime));

      // Format elapsed time
      runtimeText.arg(Locale.getFormattedTime(elapsedTime));
      // END, CR00086110
      
      // BEGIN, CR00163236, CL
      emailMessage.append(runtimeText.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
      // END, CR00163236
      emailMessageText.append(emailMessage);
      Trace.kTopLevelLogger.info(emailMessage);
      curamBatchObj.emailMessage = emailMessageText.toString();
      curamBatchObj.setEmailSubject(
        curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMAILSUBJECT);

      curamBatchObj.outputFileID =
        //BEGIN, CR00163471, JC
        curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELECTRONIC_EMPLOYER_RETURN_EMAIL_ID.getMessageText(TransactionInfo.getProgramLocale());
        //END, CR00163471, JC

      curamBatchObj.sendEmail();

      return;
    }

    // read lines

    int lineNo = 0;

    // Read all lines from the file
    while (true) {

      try {
        fileBuffer = f.readLine();
      } catch (java.io.IOException e) {
        throw new RuntimeException(e.getMessage());
        // C++ does not add any context to this read failure
      }

      if (fileBuffer == null) {
        break;
      }
      // count the lines
      lineNo++;

      // start of processing
      if (lineNo == 1) {
        AppException procFile =
          new AppException(
            curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_PROCESSINGFILE);

        procFile.arg(inFile);
        // BEGIN, CR00163236, CL
        emailMessage.append(procFile.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
        // END, CR00163236
        emailMessageText.append(emailMessage);
        Trace.kTopLevelLogger.info(emailMessage);

        // Extracting fields for the Header
        int varCount = 0;

        vectorOfFields.clear();
        vectorOfFields =
          curam.util.resources.StringUtil.tabText2StringList(fileBuffer);
        if (vectorOfFields.size() != kNumberHeaderFields) {

          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_WRONGRECORDFORMAT);

          ae.arg(fileBuffer);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          break;
        }
        // stream for conversion from string to other types
        String s;

        // Extracting employer number
        employerNumber = vectorOfFields.item(varCount);
        varCount++;

        // Extracting insurance return period
        insReturnPeriod = vectorOfFields.item(varCount);
        varCount++;

        // Extracting Total Employee Contribution Amount...
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {

          totEmployeeConAmt = zeroAmount;
        } else {
          s = vectorOfFields.item(varCount);
          try {
            tmpTotEmployeeConAmt = // BEGIN, HARP 26971 DK
              curam.util.type.Money.doConversion(s);
            // END, 26971
          } catch (java.lang.NumberFormatException e) {
            AppException ae =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_FORMATERR);

            ae.arg(fileBuffer);
            ae.arg(fnTotEmployeeConAmt);
            // BEGIN, CR00163236, CL
            emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

            break;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218
          totEmployeeConAmt = new Money(tmpTotEmployeeConAmt);
        }
        varCount++;

        // Extracting another field...
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {

          totEmployerConAmt = zeroAmount;
        } else {
          s = vectorOfFields.item(varCount);
          try {
            tmpTotEmployerConAmt = // BEGIN, HARP 26971 DK
              curam.util.type.Money.doConversion(s);
            // END, 26971
          } catch (java.lang.NumberFormatException e) {

            AppException ae =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_FORMATERR);

            ae.arg(fileBuffer);
            ae.arg(fnTotEmployerConAmt);
            // BEGIN, CR00163236, CL
            emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

            break;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218
          totEmployerConAmt = new Money(tmpTotEmployerConAmt);
        }
        varCount++;

        // Extracting another field...
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {
          bTotConAmt = false;
          totConAmt = zeroAmount;
        } else {
          s = vectorOfFields.item(varCount);
          try {
            tmpTotConAmt = // BEGIN, HARP 26971 DK
              curam.util.type.Money.doConversion(s);
            // END, 26971
          } catch (java.lang.NumberFormatException e) {
            AppException ae =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_FORMATERR);

            ae.arg(fileBuffer);
            ae.arg(fnTotConAmt);
            // BEGIN, CR00163236, CL
            emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

            break;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218
          totConAmt = new Money(tmpTotConAmt);
        }
        varCount++;

        // Extracting another field...
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {

          numCasualEmployees = 0;
        } else {
          s = vectorOfFields.item(varCount);
          try {
            numCasualEmployees = Integer.parseInt(s);
          } catch (java.lang.NumberFormatException e) {
            AppException ae =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_FORMATERR);

            ae.arg(fileBuffer);
            ae.arg(fnNumCasualEmployees);
            // BEGIN, CR00163236, CL
            emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

            break;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218
        }
        varCount++;

        // Extracting another field...
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {

          numPermanentEmployees = 0;
        } else {
          s = vectorOfFields.item(varCount);
          try {
            numPermanentEmployees = Integer.parseInt(s);
          } catch (java.lang.NumberFormatException e) {
            AppException ae =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_FORMATERR);

            ae.arg(fileBuffer);
            ae.arg(fnNumPermanentEmployees);
            // BEGIN, CR00163236, CL
            emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

            break;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218
        }
        varCount++;

        // Extracting another field...
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {

          totNumEmployees = 0;
        } else {
          s = vectorOfFields.item(varCount);
          try {
            totNumEmployees = Integer.parseInt(s);
          } catch (java.lang.NumberFormatException e) {
            AppException ae =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_FORMATERR);

            ae.arg(fileBuffer);
            ae.arg(fnTotNumEmployees);
            // BEGIN, CR00163236, CL
            emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

            break;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218
        }
        varCount++;

        // Extracting another field...
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {

          totPayroll = zeroAmount;
        } else {
          s = vectorOfFields.item(varCount);
          try {
            tmpTotPayroll = // BEGIN, HARP 26971 DK
              curam.util.type.Money.doConversion(s);
            // END, 26971
          } catch (java.lang.NumberFormatException e) {
            AppException ae =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_FORMATERR);

            ae.arg(fileBuffer);
            ae.arg(fnTotPayroll);
            // BEGIN, CR00163236, CL
            emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

            break;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218

          totPayroll = new Money(tmpTotPayroll);
        }
        varCount++;

        // Extracting another field...
        contName = vectorOfFields.item(varCount);
        varCount++;

        // Extracting another field...
        comments = vectorOfFields.item(varCount);
        varCount++;

        // Validation
        // Validate presence of mandatory fields
        if (curam.util.resources.StringUtil.rtrim(employerNumber).length() == 0) {

          emailMessage.append(
            //BEGIN, CR00163471, JC
            curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLEMPTY.getMessageText(TransactionInfo.getProgramLocale())
            //END, CR00163471, JC
              + CuramConst.gkNewLine);

          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          break;
        }

        if (curam.util.resources.StringUtil.rtrim(insReturnPeriod).length()
          == 0) {

          emailMessage.append(
            //BEGIN, CR00163471, JC
            curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_PERIODEMPTY.getMessageText(TransactionInfo.getProgramLocale())
            //END, CR00163471, JC
              + CuramConst.gkNewLine);

          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          break;
        }

        if (!bTotConAmt) {

          emailMessage.append(
            //BEGIN, CR00163471, JC
            curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_TOTCONAMTEMPTY.getMessageText(TransactionInfo.getProgramLocale())
            //END, CR00163471, JC
              + CuramConst.gkNewLine);

          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          break;
        }

        // Validate that employer number is known to CURAM
        // set search key from parameter
        employerAltSearchKey.primaryAlternateID = employerNumber;

        employerAltSearchKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

        // do employer search
        try {
          employerAltSearchDetails =
            employerObj.readByAlternateID(employerAltSearchKey);

        } catch (curam.util.exception.RecordNotFoundException e) {
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.ERR_EMPLOYER_RNFE_NOPRIMALTID);

          ae.arg(employerAltSearchKey.primaryAlternateID);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          break;
        } catch (curam.util.exception.MultipleRecordException e) {
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.ERR_EMPLOYER_MRE_PRIMALTID);

          ae.arg(employerAltSearchKey.primaryAlternateID);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          break;
        }

        // Validate that the insurance return period is known to CURAM
        insurancePeriodNameKey.periodName = insReturnPeriod;

        insurancePeriodNameKey.recordStatus =
          curam.codetable.RECORDSTATUS.NORMAL;

        try {
          insurancePeriodControlDtls =
            insurancePeriodControlObj.readByPeriodName(insurancePeriodNameKey);

        } catch (curam.util.exception.RecordNotFoundException e) {
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.ERR_INSURANCERETURNPERIOD_RNFE_PERNAME);

          ae.arg(insurancePeriodNameKey.periodName);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          break;
        } catch (curam.util.exception.MultipleRecordException e) {
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.ERR_INSURANCERETURNPERIOD_MRE_PERNAME);

          ae.arg(insurancePeriodNameKey.periodName);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          break;
        }

        // Create an InsuranceReturnHeader record
        // set the values to create header
        // the key
        createHeaderKey.concernRoleID = employerAltSearchDetails.concernRoleID;
        // the details
        insuranceReturnHdrDetails.contactName = contName;
        insuranceReturnHdrDetails.totalContribAmt = totConAmt;
        insuranceReturnHdrDetails.employeeContribAmt = totEmployeeConAmt;
        insuranceReturnHdrDetails.employerContribAmt = totEmployerConAmt;
        insuranceReturnHdrDetails.totalPayroll = totPayroll;
        insuranceReturnHdrDetails.totNumEmployees = totNumEmployees;
        insuranceReturnHdrDetails.numPermanentEmployees = numPermanentEmployees;
        insuranceReturnHdrDetails.numCasualEmployees = numCasualEmployees;
        insuranceReturnHdrDetails.fromDate =
          insurancePeriodControlDtls.fromDate;
        insuranceReturnHdrDetails.toDate = insurancePeriodControlDtls.toDate;
        insuranceReturnHdrDetails.creationDate = currentDate;
        insuranceReturnHdrDetails.comments = comments;
        insuranceReturnHdrDetails.concernRoleID =
          employerAltSearchDetails.concernRoleID;
        insuranceReturnHdrDetails.insuranceReturnPeriodID =
          insurancePeriodControlDtls.insuranceReturnPeriodID;
        insuranceReturnHdrDetails.insuranceReturnType =
          INSURRETURNTYPE.DEFAULTCODE;

        try {
          insuranceRetHdrKey =
            employerInsuranceRetHeaderObj.createInsuranceReturnHdr(
              createHeaderKey, insuranceReturnHdrDetails);

        } catch (curam.util.exception.AppException e) {
          if (!new curam.util.message.INFRASTRUCTURE().getClass().isInstance(
            e.getCatEntry().getCatalog())) {
            // BEGIN, CR00163236, CL
            emailMessage.append(e.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

            break;
          } else {
            // pass the exception straight through
            throw e;
          }

        }
        // match that the header had been created
        headerCreated = true;

      } else {
        // Extraction fields for the Details

        dtlRecordNumber++;
        int varCount = 0;
        TicketInfoDetails ticketInfoDetails = new TicketInfoDetails();

        ticketInfoDetails.employerAltSearchDtls = employerAltSearchDetails;
        ticketInfoDetails.emailMessage = emailMessage.toString();
        ticketInfoDetails.emailMessageText = emailMessageText.toString();
        ticketInfoDetails.dtlRecordNumber = dtlRecordNumber;
        ticketInfoDetails.fileBuffer = fileBuffer;
        ticketInfoDetails.insReturnPeriod = insReturnPeriod;

        vectorOfFields.clear();
        vectorOfFields =
          curam.util.resources.StringUtil.tabText2StringList(fileBuffer);
        if (vectorOfFields.size() != kNumberDetailsFields) {
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_WRONGRECORDFORMAT);

          ae.arg(fileBuffer);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          dtlItemsSkipped++;
          continue;
        }
        // stream for conversion from string to other types
        String s;

        // Extracting employee number
        employeeNumberDt = vectorOfFields.item(varCount);
        varCount++;

        // Extracting employee full name
        employeeFullNameDt = vectorOfFields.item(varCount);
        varCount++;

        // Extracting another field...
        strIncomeAmountDt = vectorOfFields.item(varCount);
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {

          incomeAmountDt = zeroAmount;
        } else {
          s = vectorOfFields.item(varCount);
          try {
            tmpIncomeAmountDt = // BEGIN, HARP 26971 DK
              curam.util.type.Money.doConversion(s);
            // END, 26971
          } catch (java.lang.NumberFormatException e) {
            // create ticket
            createTicket(ticketInfoDetails);
            dtlItemsSkipped++;
            continue;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218

          incomeAmountDt = new Money(tmpIncomeAmountDt);
        }
        varCount++;

        // Extract another field
        insuranceUnitTypeCodeDt = vectorOfFields.item(varCount);
        varCount++;

        // Extract another field
        productNameDt = vectorOfFields.item(varCount);
        varCount++;

        // Extracting another field...
        strNoofInsuranceUnitsDt = vectorOfFields.item(varCount);
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {

          noofInsuranceUnitsDt = 0;
        } else {
          s = vectorOfFields.item(varCount);
          try {
            noofInsuranceUnitsDt = Short.parseShort(s);
          } catch (java.lang.NumberFormatException e) {
            // create ticket
            createTicket(ticketInfoDetails);

            dtlItemsSkipped++;
            continue;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218
        }
        varCount++;

        // Extracting fromDate
        tmpFromDateDt = vectorOfFields.item(varCount);
        strFromDateDt = tmpFromDateDt;
        try {
          fromDateDt = curamBatchObj.formattedString2Date(tmpFromDateDt);
        } catch (DateConversionError e) {
          // create ticket
          createTicket(ticketInfoDetails);

          dtlItemsSkipped++;
          continue;
        }
        varCount++;

        // Extracting toDate
        tmpToDateDt = vectorOfFields.item(varCount);
        strToDateDt = tmpToDateDt;
        try {
          toDateDt = curamBatchObj.formattedString2Date(tmpToDateDt);
        } catch (DateConversionError e) {
          // create ticket
          createTicket(ticketInfoDetails);

          dtlItemsSkipped++;
          continue;
        }
        varCount++;

        // Extracting total contribution amount
        strTotConAmtDt = vectorOfFields.item(varCount);
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {

          totConAmtDt = zeroAmount;
        } else {
          s = vectorOfFields.item(varCount);
          try {
            tmpTotConAmtDt = // BEGIN, HARP 26971 DK
              curam.util.type.Money.doConversion(s);
            // END, 26971
          } catch (java.lang.NumberFormatException e) {
            // create ticket
            createTicket(ticketInfoDetails);

            dtlItemsSkipped++;
            continue;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218
          totConAmtDt = new Money(tmpTotConAmtDt);
        }
        varCount++;

        // Extracting total employer contribution amount
        strTotEmployerConAmtDt = vectorOfFields.item(varCount);
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {

          totEmployerConAmtDt = zeroAmount;
        } else {
          s = vectorOfFields.item(varCount);
          try {
            tmpTotEmployerConAmtDt = // BEGIN, HARP 26971 DK
              curam.util.type.Money.doConversion(s);
            // END, 26971
          } catch (java.lang.NumberFormatException e) {
            createTicket(ticketInfoDetails);

            dtlItemsSkipped++;
            continue;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218
          totEmployerConAmtDt = new Money(tmpTotEmployerConAmtDt);
        }
        varCount++;

        // Extracting total employer contribution amount
        strTotEmployeeConAmtDt = vectorOfFields.item(varCount);
        // flag if field is empty
        if (curam.util.resources.StringUtil.rtrim(vectorOfFields.item(varCount)).length()
          == 0) {
          totEmployeeConAmtDt = zeroAmount;
        } else {
          s = vectorOfFields.item(varCount);

          try {
            tmpTotEmployeeConAmtDt = curam.util.type.Money.doConversion(s);
            // END, 26971
          } catch (java.lang.NumberFormatException e) {
            // create ticket
            createTicket(ticketInfoDetails);

            dtlItemsSkipped++;
            continue;
          }
          // BEGIN, CR00049218, GM
          s = CuramConst.gkEmpty;
          // END, CR00049218
          totEmployeeConAmtDt = new Money(tmpTotEmployeeConAmtDt);
        }
        varCount++;

        // Extract employment type field
        employmentTypeDt = vectorOfFields.item(varCount);
        varCount++;

        // Extract comments field
        comments = vectorOfFields.item(varCount);
        varCount++;

        // Extract nameValuePairs
        nameValuePairs.append(CuramConst.gkNewLine).append(fnEmployeeNumberDt).append(CuramConst.gkEquals).append(employeeNumberDt).append(CuramConst.gkNewLine).append(fnEmployeeFullNameDt).append(CuramConst.gkEquals).append(employeeFullNameDt).append(CuramConst.gkNewLine).append(fnIncomeAmountDt).append(CuramConst.gkEquals).append(strIncomeAmountDt).append(CuramConst.gkNewLine).append(fnInsuranceUnitTypeCodeDt).append(CuramConst.gkEquals).append(insuranceUnitTypeCodeDt).append(CuramConst.gkNewLine).append(fnProductNameDt).append(CuramConst.gkEquals).append(productNameDt).append(CuramConst.gkNewLine).append(fnNoofInsuranceUnitsDt).append(CuramConst.gkEquals).append(strNoofInsuranceUnitsDt).append(CuramConst.gkNewLine).append(fnFromDateDt).append(CuramConst.gkEquals).append(strFromDateDt).append(CuramConst.gkNewLine).append(fnToDateDt).append(CuramConst.gkEquals).append(strToDateDt).append(CuramConst.gkNewLine).append(fnTotConAmt).append(CuramConst.gkEquals).append(strTotConAmtDt).append(CuramConst.gkNewLine).append(fnTotEmployerConAmt).append(CuramConst.gkEquals).append(strTotEmployerConAmtDt).append(CuramConst.gkNewLine).append(fnTotEmployeeConAmt).append(CuramConst.gkEquals).append(strTotEmployeeConAmtDt).append(CuramConst.gkNewLine).append(fnEmploymentTypeDt).append(CuramConst.gkEquals).append(employmentTypeDt).append(CuramConst.gkNewLine).append(fnComments).append(CuramConst.gkEquals).append(commentsDt).append(
          CuramConst.gkNewLine);

        // Do initial population of InsRetLineItemDtls fields to create line item

        // BEGIN, CR00049218, GM
        insRetLineItemDtls.insUnitTypeCode = CuramConst.gkEmpty;
        insRetLineItemDtls.employmentTypeCode = CuramConst.gkEmpty;
        // END, CR00049218
        insRetLineItemDtls.statusCode =
          curam.codetable.INSURRETLINESTATUS.COMPLETE;
        insRetLineItemDtls.productID = 0;
        insRetLineItemDtls.concernRoleID = 0;
        insRetLineItemDtls.insuranceRetHdrID =
          insuranceRetHdrKey.insuranceRetHdrID;
        insRetLineItemDtls.insuranceReturnPeriodID =
          insurancePeriodControlDtls.insuranceReturnPeriodID;
        insRetLineItemDtls.numInsuranceUnits = noofInsuranceUnitsDt;
        insRetLineItemDtls.fromDate = fromDateDt;
        insRetLineItemDtls.toDate = toDateDt;
        insRetLineItemDtls.totalContributionAmt = totConAmtDt;
        insRetLineItemDtls.employeeConAmt = totEmployeeConAmtDt;
        insRetLineItemDtls.employerConAmt = totEmployerConAmtDt;
        insRetLineItemDtls.incomeAmount = incomeAmountDt;
        insRetLineItemDtls.fundID = 0;
        insRetLineItemDtls.comments = commentsDt;
        insRetLineItemDtls.insuranceConsolidationID = 0;

        boolean bCreateTicket = false;

        // Verify employee number is known to CURAM
        if (curam.util.resources.StringUtil.rtrim(employeeNumberDt).length()
          == 0) {
          // create ticket tied to employer

          AppException reasonText =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLOYEEBLANKREASON);

          reasonText.arg(employeeFullNameDt);
          reasonText.arg(employeeNumberDt);
          reasonText.arg(employerNumber);
          reasonText.arg(insReturnPeriod);
          reasonText.arg(nameValuePairs);

          ticketText.subjectText =
            //BEGIN, CR00163471, JC
            curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLOYEEBLANKSUBJECT.getMessageText(TransactionInfo.getProgramLocale());
            //END, CR00163471, JC

          // BEGIN, CR00163236, CL
          ticketText.reasonText = reasonText.getMessage(ProgramLocale.getDefaultServerLocale());
          // END, CR00163236
          employerInsuranceRetHeaderAssistantObj.createTicket(
            insuranceReturnHdrDetails, ticketText);

          dtlItemsSkipped++;
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLOYEEBLANK);

          ae.arg(dtlRecordNumber);
          ae.arg(fileBuffer);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          continue;
        }

        // read the person by alternate ID
        // set search key from parameter
        personAltSearchKey.primaryAlternateID = employeeNumberDt;

        // do person search
        try {
          personDtls = personObj.readByAlternateID(personAltSearchKey);

        } catch (curam.util.exception.RecordNotFoundException e) {
          // create ticket

          AppException reasonText =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_NOSUCHALTIDREASON);

          reasonText.arg(employeeFullNameDt);
          reasonText.arg(employeeNumberDt);
          reasonText.arg(employerNumber);
          reasonText.arg(insReturnPeriod);
          reasonText.arg(nameValuePairs);

          ticketText.subjectText =
            //BEGIN, CR00163471, JC
            curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_NOSUCHALTIDSUBJECT.getMessageText(TransactionInfo.getProgramLocale());
            //END, CR00163471, JC
          // BEGIN, CR00163236, CL
          ticketText.reasonText = reasonText.getMessage(ProgramLocale.getDefaultServerLocale());
          // END, CR00163236
          employerInsuranceRetHeaderAssistantObj.createTicket(
            insuranceReturnHdrDetails, ticketText);

          dtlItemsSkipped++;
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_NOSUCHALTID);

          ae.arg(dtlRecordNumber);
          ae.arg(employerNumber);
          ae.arg(fileBuffer);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          continue;
        } catch (curam.util.exception.MultipleRecordException e) {
          // create ticket

          AppException reasonText =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_MULTALTIDREASON);

          reasonText.arg(employeeNumberDt);
          reasonText.arg(employerNumber);
          reasonText.arg(insReturnPeriod);
          reasonText.arg(nameValuePairs);

          ticketText.subjectText =
            //BEGIN, CR00163471, JC
            curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_MULTALTIDSUBJECT.getMessageText(TransactionInfo.getProgramLocale());
            //END, CR00163471, JC
          // BEGIN, CR00163236, CL
          ticketText.reasonText = reasonText.getMessage(ProgramLocale.getDefaultServerLocale());
          // END, CR00163236
          employerInsuranceRetHeaderAssistantObj.createTicket(
            insuranceReturnHdrDetails, ticketText);

          dtlItemsSkipped++;
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_MULTALTID);

          ae.arg(dtlRecordNumber);
          ae.arg(employerNumber);
          ae.arg(fileBuffer);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          continue;
        }
        // set concern role id
        insRetLineItemDtls.concernRoleID = personDtls.concernRoleID;

        // set key to read concern role
        concernRoleKey.concernRoleID = personDtls.concernRoleID;
        // do concern role read

        try {
          concernRoleDtls = concernRoleObj.read(concernRoleKey);
        } catch (curam.util.exception.RecordNotFoundException e) {
          dtlItemsSkipped++;
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_CONCERNROLENOTFOUND);

          ae.arg(concernRoleKey.concernRoleID);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

          continue;
        }

        // Verify employee's name
        if (!concernRoleDtls.concernRoleName.equals(employeeFullNameDt)) {
          if (!bCreateTicket) {
            bCreateTicket = true;

            AppException reasonText =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_DIFNAMEREASON);

            reasonText.arg(employerNumber);
            reasonText.arg(insReturnPeriod);
            reasonText.arg(employeeNumberDt);
            reasonText.arg(employeeFullNameDt);
            reasonText.arg(concernRoleDtls.concernRoleName);

            ticketText.subjectText =
              //BEGIN, CR00163471, JC
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_DIFNAMESUBJECT.getMessageText(TransactionInfo.getProgramLocale());
              //END, CR00163471, JC
            // BEGIN, CR00163236, CL
            ticketText.reasonText = reasonText.getMessage(ProgramLocale.getDefaultServerLocale());
            // END, CR00163236
          }

          insRetLineItemDtls.statusCode =
            curam.codetable.INSURRETLINESTATUS.INCOMPL;
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_DIFNAME);

          ae.arg(dtlRecordNumber);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

        }

        // Verify Insurance Unit Type Code
        if (curam.util.resources.StringUtil.rtrim(insuranceUnitTypeCodeDt).length()
          == 0) {
          if (!bCreateTicket) {
            bCreateTicket = true;

            AppException reasonText =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_INSUNITTYPEBLANKREASON);

            reasonText.arg(employerAltSearchDetails.tradingName);
            reasonText.arg(insReturnPeriod);

            ticketText.subjectText =
              //BEGIN, CR00163471, JC
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_INSUNITTYPEBLANKSUBJECT.getMessageText(TransactionInfo.getProgramLocale());
              //END, CR00163471, JC
            // BEGIN, CR00163236, CL
            ticketText.reasonText = reasonText.getMessage(ProgramLocale.getDefaultServerLocale());
            // END, CR00163236
          }

          insRetLineItemDtls.statusCode =
            curam.codetable.INSURRETLINESTATUS.INCOMPL;
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_INSUNITTYPEBLANK);

          ae.arg(dtlRecordNumber);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

        } else {
          // check insurance unit type code
          String desc;

          desc =
            //BEGIN, CR00163098, JC
            curam.util.type.CodeTable.getOneItem(
              curam.codetable.INSURANCEUNITTYPE.TABLENAME,
              insuranceUnitTypeCodeDt,TransactionInfo.getProgramLocale());
            //END, CR00163098, JC
          if (desc == null) {
            // insurance unit type code not valid
            if (!bCreateTicket) {
              bCreateTicket = true;

              AppException reasonText =
                new AppException(
                  curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_INSUNITTYPENOTVALIDREASON);

              reasonText.arg(insuranceUnitTypeCodeDt);
              reasonText.arg(employerAltSearchDetails.tradingName);
              reasonText.arg(insReturnPeriod);

              ticketText.subjectText =
                //BEGIN, CR00163471, JC
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_INSUNITTYPENOTVALIDSUBJECT.getMessageText(TransactionInfo.getProgramLocale());
                //END, CR00163471, JC
              // BEGIN, CR00163236, CL
              ticketText.reasonText = reasonText.getMessage(ProgramLocale.getDefaultServerLocale());
              // END, CR00163236
            }

            insRetLineItemDtls.statusCode =
              curam.codetable.INSURRETLINESTATUS.INCOMPL;
            AppException ae =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_INSUNITTYPENOTVALID);

            ae.arg(dtlRecordNumber);
            ae.arg(insuranceUnitTypeCodeDt);
            // BEGIN, CR00163236, CL
            emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

          } else {
            insRetLineItemDtls.insUnitTypeCode = insuranceUnitTypeCodeDt;
          }
        }

        // Verify Employment Type Code
        if (curam.util.resources.StringUtil.rtrim(employmentTypeDt).length()
          == 0) {

          if (!bCreateTicket) {
            bCreateTicket = true;

            AppException reasonText =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLTYPEBLANKREASON);

            reasonText.arg(employerAltSearchDetails.tradingName);
            reasonText.arg(insReturnPeriod);

            ticketText.subjectText =
              //BEGIN, CR00163471, JC
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLTYPEBLANKSUBJECT.getMessageText(TransactionInfo.getProgramLocale());
              //END, CR00163471, JC
            // BEGIN, CR00163236, CL
            ticketText.reasonText = reasonText.getMessage(ProgramLocale.getDefaultServerLocale());
            // END, CR00163236
          }

          insRetLineItemDtls.statusCode =
            curam.codetable.INSURRETLINESTATUS.INCOMPL;
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLTYPEBLANK);

          ae.arg(dtlRecordNumber);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

        } else {
          // check insurance unit type code
          String desc;

          desc =
            //BEGIN, CR00163098, JC
            curam.util.type.CodeTable.getOneItem(
              curam.codetable.EMPLOYMENTTYPE.TABLENAME, employmentTypeDt,
              TransactionInfo.getProgramLocale());
            //END, CR00163098, JC
          if (desc == null) {
            if (!bCreateTicket) {
              bCreateTicket = true;

              AppException reasonText =
                new AppException(
                  curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLTYPENOTVALIDREASON);

              reasonText.arg(employmentTypeDt);
              reasonText.arg(employerAltSearchDetails.tradingName);
              reasonText.arg(insReturnPeriod);

              ticketText.subjectText =
                //BEGIN, CR00163471, JC
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLTYPENOTVALIDSUBJECT.getMessageText(TransactionInfo.getProgramLocale());
                //END, CR00163471, JC
              // BEGIN, CR00163236, CL
              ticketText.reasonText = reasonText.getMessage(ProgramLocale.getDefaultServerLocale());
              // END, CR00163236
            }

            insRetLineItemDtls.statusCode =
              curam.codetable.INSURRETLINESTATUS.INCOMPL;
            AppException ae =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMPLTYPENOTVALID);

            ae.arg(dtlRecordNumber);
            ae.arg(employmentTypeDt);
            // BEGIN, CR00163236, CL
            emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

          } else {
            insRetLineItemDtls.employmentTypeCode = employmentTypeDt;
          }
        }

        // Verify Product
        if (curam.util.resources.StringUtil.rtrim(productNameDt).length() == 0) {

          if (!bCreateTicket) {
            bCreateTicket = true;

            AppException reasonText =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_PRODNAMEBLANKREASON);

            reasonText.arg(employerAltSearchDetails.tradingName);
            reasonText.arg(insReturnPeriod);

            ticketText.subjectText =
              //BEGIN, CR00163471, JC
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_PRODNAMEBLANKSUBJECT.getMessageText(TransactionInfo.getProgramLocale());
              //END, CR00163471, JC
            // BEGIN, CR00163236, CL
            ticketText.reasonText = reasonText.getMessage(ProgramLocale.getDefaultServerLocale());
            // END, CR00163236, CL
          }

          insRetLineItemDtls.statusCode =
            curam.codetable.INSURRETLINESTATUS.INCOMPL;
          AppException ae =
            new AppException(
              curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_PRODNAMEBLANK);

          ae.arg(dtlRecordNumber);
          // BEGIN, CR00163236, CL
          emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

        } else {
          // if product name is not empty
          // read the product from database
          productNameStructRef.name = productNameDt;

          productNameStructRef.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

          try {
            productDtls = productObj.readProductsByName(productNameStructRef);

            insRetLineItemDtls.productID = productDtls.productID;
          } catch (curam.util.exception.RecordNotFoundException e) {

            if (!bCreateTicket) {
              bCreateTicket = true;

              AppException reasonText =
                new AppException(
                  curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_PRODNOTVALIDREASON);

              reasonText.arg(productNameDt);
              reasonText.arg(employerAltSearchDetails.tradingName);
              reasonText.arg(insReturnPeriod);

              ticketText.subjectText =
                //BEGIN, CR00163471, JC
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_PRODNOTVALIDSUBJECT.getMessageText(TransactionInfo.getProgramLocale());
                //END, CR00163471, JC
              // BEGIN, CR00163236, CL
              ticketText.reasonText = reasonText.getMessage(ProgramLocale.getDefaultServerLocale());
              // END, CR00163236
            }

            insRetLineItemDtls.statusCode =
              curam.codetable.INSURRETLINESTATUS.INCOMPL;
            insRetLineItemDtls.productID = 0;

            AppException ae =
              new AppException(
                curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_PRODNOTVALID);

            ae.arg(dtlRecordNumber);
            ae.arg(productNameDt);
            // BEGIN, CR00163236, CL
            emailMessage.append(ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

          }
        }

        // Create the insurance line item and details
        createLineItemKey.concernRoleID = personDtls.concernRoleID;

        try {
          maintainInsuranceLineItemObj.createEmployeeLineItem(createLineItemKey,
            insRetLineItemDtls);

        } catch (curam.util.exception.AppException e) {
          if (!new curam.util.message.INFRASTRUCTURE().getClass().isInstance(
            e.getCatEntry().getCatalog())) {
            // BEGIN, CR00163236, CL
            emailMessage.append(e.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

            dtlItemsSkipped++;
            continue;
          } else {
            // pass the exception straight through
            throw e;
          }
        }

        dtlItemsCreated++;

        if (bCreateTicket) {

          maintainInsuranceLineItemAssistantObj.createTicket(insRetLineItemDtls,
            ticketText);

        }
        // validation
        try {
          maintainInsuranceLineItemAssistantObj.validateLineItem(

            insRetLineItemDtls);

        } catch (curam.util.exception.AppException e) {
          if (!new curam.util.message.INFRASTRUCTURE().getClass().isInstance(
            e.getCatEntry().getCatalog())) {
            // BEGIN, CR00163236, CL
            emailMessage.append(e.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
            // END, CR00163236
            emailMessageText.append(emailMessage);
            Trace.kTopLevelLogger.info(emailMessage);

            continue;
          } else {
            // pass the exception straight through
            throw e;
          }
        }

      }

    }

    if (headerCreated) {
      // Validate insurance return header against all its line item records

      try {
        employerInsuranceRetHeaderObj.validateInsuranceReturn(
          insuranceRetHdrKey);

      } catch (curam.util.exception.AppException e) {
        if (!new curam.util.message.INFRASTRUCTURE().getClass().isInstance(
          e.getCatEntry().getCatalog())) {
          // BEGIN, CR00163236, CL
          emailMessage.append(e.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
          // END, CR00163236
          emailMessageText.append(emailMessage);
          Trace.kTopLevelLogger.info(emailMessage);

        } else {
          // pass the exception straight through
          throw e;
        }
      }

    }

    if (lineNo == 0) {
      // send to log
      AppException emptyFile =
        new AppException(
          curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_FILEEMPTY);

      emptyFile.arg(inFile);
      // BEGIN, CR00163236, CL
      emailMessage.append(emptyFile.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
      // END, CR00163236
      emailMessageText.append(emailMessage);
      Trace.kTopLevelLogger.info(emailMessage);
    }

    try {
      // close file stream
      f.close();
    } catch (java.io.IOException e) {
      throw new RuntimeException(e.getMessage());
      // C++ does not add any context to this read failure
    }

    // Batch information
    AppException recordsRead =
      new AppException(
        curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_RECORDSREAD);

    recordsRead.arg(lineNo);
    recordsRead.arg(dtlItemsCreated);
    recordsRead.arg(dtlItemsSkipped);
    // BEGIN, CR00163236, CL
    emailMessage.append(recordsRead.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
    // END, CR00163236
    emailMessageText.append(emailMessage);
    Trace.kTopLevelLogger.info(emailMessage);

    // calculate elapsed time
    endTime = curam.util.transaction.TransactionInfo.getSystemDateTime();

    elapsedTime =
      new curam.util.type.DateTime((endTime.asLong() - startTime.asLong()));

    AppException runtimeText =
      new AppException(curam.message.GENERALBATCH.INF_JOB_RUNTIME);

    // BEGIN, CR00086110, POB
    // Format start time
    runtimeText.arg(Locale.getFormattedTime(startTime));

    // Format elapsed time
    runtimeText.arg(Locale.getFormattedTime(elapsedTime));
    // END, CR00086110
    
    // BEGIN, CR00163236, CL
    emailMessage.append(runtimeText.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine);
    // END, CR00163236
    emailMessageText.append(emailMessage);
    Trace.kTopLevelLogger.info(emailMessage);
    curamBatchObj.emailMessage = emailMessageText.toString();
    curamBatchObj.setEmailSubject(
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_EMAILSUBJECT);

    curamBatchObj.outputFileID =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELECTRONIC_EMPLOYER_RETURN_EMAIL_ID.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC
    curamBatchObj.sendEmail();
  }

  // __________________________________________________________________________
  /**
   * Method for setting TicketText details
   * @param ticketInfoDetails Struct containing details for ticket
   */
  protected void createTicket(TicketInfoDetails ticketInfoDetails
    ) throws AppException, InformationalException {
    // create ticket
    InsuranceReturnHdrDetails insuranceReturnHdrDetails =
      new InsuranceReturnHdrDetails();

    insuranceReturnHdrDetails.concernRoleID =
      ticketInfoDetails.employerAltSearchDtls.concernRoleID;

    TicketText ticketText = new TicketText();
    EmployerInsuranceRetHeaderAssistant employerInsuranceRetHeaderAssistantObj =
      curam.core.fact.EmployerInsuranceRetHeaderAssistantFactory.newInstance();

    AppException reasonText =
      new AppException(
        curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_ERRFIELDTICKETREASON);

    reasonText.arg(ticketInfoDetails.employerAltSearchDtls.tradingName);
    reasonText.arg(ticketInfoDetails.insReturnPeriod);
    reasonText.arg(ticketInfoDetails.dtlRecordNumber);
    reasonText.arg(ticketInfoDetails.fileBuffer);

    ticketText.subjectText =
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_ERRFIELDTICKETSUBJECT.getMessageText(TransactionInfo.getProgramLocale());
      //END, CR00163471, JC
    // BEGIN, CR00163236, CL
    ticketText.reasonText = reasonText.getMessage(ProgramLocale.getDefaultServerLocale());
    // END, CR00163236
    employerInsuranceRetHeaderAssistantObj.createTicket(
      insuranceReturnHdrDetails, ticketText);

    // log the error
    AppException ae =
      new AppException(
        curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_FORMATERRDTLS);

    ae.arg(ticketInfoDetails.dtlRecordNumber);
    ae.arg(ticketInfoDetails.fileBuffer);
    ae.arg(
      //BEGIN, CR00163471, JC
      curam.message.BPOELECTRONICEMPLOYERRETURN.INF_ELEMPLOYERRETURN_INCOMEAMOUNT.getMessageText(TransactionInfo.getProgramLocale()));
      //END, CR00163471, JC
    // BEGIN, CR00163236, CL
    ticketInfoDetails.emailMessage += ae.getMessage(ProgramLocale.getDefaultServerLocale()) + CuramConst.gkNewLine;
    // END, CR00163236
    ticketInfoDetails.emailMessageText += ticketInfoDetails.emailMessage;

    Trace.kTopLevelLogger.info(ticketInfoDetails.emailMessage);
  }

}
