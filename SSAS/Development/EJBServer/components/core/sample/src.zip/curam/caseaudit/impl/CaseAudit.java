/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import com.google.inject.ImplementedBy;

import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.OptimisticLockRemovable;

/**
 * CaseAudit.
 * 
 */
@ImplementedBy(CaseAuditImpl.class)
public interface CaseAudit extends Insertable, OptimisticLockModifiable,
  OptimisticLockRemovable, CaseAuditAccessor {

  // ___________________________________________________________________________
  /**
   * Sets the case for this case audit.
   * 
   * @param caseHeader
   *          The associated case
   */
  public void setCase(final CaseHeader caseHeader);

  // ____________________________________________________________________________
  /**
   * Sets the AuditPlan record associated with this CaseAudit.
   * 
   * @param auditPlan
   *          The AuditPlan record associated with this CaseAudit
   */
  public void setAuditPlan(final AuditPlan auditPlan);

  // ___________________________________________________________________________
  /**
   * Sets the the textual description of the case audit.
   * 
   * @param comments
   *          The textual description of the case audit.
   */
  public void setComments(final String comments);

  // ____________________________________________________________________________
  /**
   * Assigns the case audit to an auditor. This causes the status to change to
   * 'Assigned' and sets the dateAssigned field to the current date.
   * 
   * @param auditor
   *          The auditor or audit team to whom the case will be assigned.
   * @param versionNo
   *          The version of the record being modified.
   * 
   * @throws InformationalException
   */
  public void assign(final Auditor auditor, int versionNo) throws AppException,
    InformationalException;

  // ____________________________________________________________________________
  /**
   * Removed the auditor from the case audit. This causes the status to revert
   * to 'Open'
   * 
   * @param versionNo
   *          The version of the record being modified.
   * 
   * @throws InformationalException
   */
  public void removeAuditor(final int versionNo) throws AppException,
    InformationalException;

  // ____________________________________________________________________________
  /**
   * Completes the CaseAudit Findings. The status will either transition to
   * 'Findings Complete' or 'Findings Complete & Awaiting Feedback' depending on
   * the user access chosen on the Audit Plan itself. Appropriate tasks will
   * also be created for the case owner and supervisor if feedback is required.
   * 
   * @param versionNo
   *          The version of the case audit whose findings area being completed
   * 
   * @throws AppException
   * @throws InformationalException
   */
  public void completeFindings(final int versionNo) throws AppException,
    InformationalException;

  // ____________________________________________________________________________
  /**
   * Method to call when feedback has been received. This will either transition
   * the state to 'Feedback Received' or 'Feedback Complete' depending on
   * whether any further feedback is required.
   * 
   * @param versionNo
   *          The version of the case audit
   * 
   * @throws InformationalException
   */
  public void feedbackReceived(final int versionNo)
    throws InformationalException;

  // ____________________________________________________________________________
  /**
   * Manually completes the CaseAudit from status 'Findings Complete' or any of
   * the feedback states. This allows the auditor or coordinator to intervene
   * when enough feedback has already been received. Any remaining feedback
   * tasks for case owners or supervisors will be automatically closed.
   * 
   * @param versionNo
   *          The version of the case audit being completed
   * 
   * @throws AppException
   * @throws InformationalException
   */
  public void complete(final int versionNo) throws AppException,
    InformationalException;

  // ____________________________________________________________________________
  /**
   * Method to set the case audit findings.
   * 
   * @param findings
   *          The findings for this case audit
   */
  public void setCaseAuditFindings(String findings) throws AppException,
    InformationalException;
}
