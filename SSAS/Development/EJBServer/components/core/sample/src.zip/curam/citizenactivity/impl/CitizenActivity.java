/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.citizenactivity.impl;


import java.io.ByteArrayOutputStream;
import java.util.List;

import com.google.inject.ImplementedBy;

import curam.citizenactivity.codetable.impl.CITIZENACTIVITYTYPEEntry;
import curam.codetable.impl.COMMENTRELATEDTYPEEntry;
import curam.participant.impl.ConcernRole;
import curam.piwrapper.user.impl.User;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateRange;
import curam.util.type.Implementable;


/**
 * Represents the data to be displayed by the Citizen Account My Activities
 * list. Citizen 'activities' are gathered from a range of entities, such as
 * ServiceDelivery in CPM.
 *
 * @since 6.0
 */
@ImplementedBy(CitizenActivityImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
@Implementable
public interface CitizenActivity {

  /**
   * Returns the name to be displayed for this Citizen Activity.
   *
   * @return the name to be displayed for this Citizen Activity.
   */
  String getName();

  /**
   * The period of this activity. This is displayed as a String in the Period
   * field on the My Activities page. It is also used to sort the activities.
   *
   * @return period of this activity.
   */
  DateRange getPeriod();

  /**
   * Returns a formatted string representing the frequency and duration of this
   * activity.
   *
   * @return a formatted string representing the frequency and duration of this
   * activity.
   */
  String getParticipation();

  /**
   * Returns a {@link User} representing the Agency Contact for this activity.
   *
   * @return
   */
  User getAgencyContact();

  /**
   * Returns a code table entry representing the type of this activity i.e.
   * which entity it came from.
   *
   * @return a code table entry representing the type of this activity i.e.
   * which entity it came from.
   */
  CITIZENACTIVITYTYPEEntry getType();

  /**
   * Returns the primary key for this activity database record, as a Long.
   *
   * @return the primary key for this activity database record, as a Long.
   */
  Long getID();

  /**
   * Returns the name of the Provider, or an empty String if none is specified
   * for this Citizen Activity.
   *
   * @return the name of the Provider, if any is specified for this Citizen
   * Activity.
   */
  String getProviderName();

  /**
   * Returns the CPM ProviderOffering ID for this activity, if it is related to
   * a CPM ServiceDelivery or another Citizen Activity type that is related to a
   * CPM ProviderOffering.
   *
   * @return the CPM ProviderOffering ID for this activity.
   */
  Long getProviderOfferingID();

  /**
   * Lists the ConcernRoles associated with this citizen activity. In general,
   * only one concern will be associated with a citizen activity, however, some
   * types of activities can involve multiple participants.
   *
   * @return the ConcernRoles associated with this citizen activity.
   */
  List<ConcernRole> listConcernRoles();

  /**
   * Returns whether or not this citizen activity has an associated referral
   * letter.
   *
   * @return whether or not this citizen activity has an associated referral
   * letter.
   */
  Boolean hasReferralLetter();

  /**
   * Returns the referral document as a ByteArrayOutputStream.
   *
   * @return the referral document as a ByteArrayOutputStream.
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  public ByteArrayOutputStream getReferralDocument()
    throws InformationalException, AppException;

  /**
   * Adds a comment relating to this citizen activity to the ParticipantComment
   * table.
   *
   * @param comment
   * the comment the citizen has added relating to this citizen
   * activity.
   *
   * @param concernRole
   * the participant making this comment.
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  public void addComment(String comment, ConcernRole concernRole)
    throws AppException, InformationalException;

  /**
   * A participant can comment on many different things, i.e. different types
   * of record. This method returns the type of record that this comment is
   * related to, taken from the CommentRelatedType codetable.
   *
   * @return the type of record that this comment is related to, taken from
   * the CommentRelatedType codetable.
   */
  public COMMENTRELATEDTYPEEntry getCommentRelatedType();

}
