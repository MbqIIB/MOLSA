/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.List;
import java.util.SortedSet;

import com.google.inject.Inject;

import curam.caseaudit.entity.struct.ExternalCaseAuditDataDtls;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.core.struct.Count;
import curam.message.impl.ENTEXTERNALCASEAUDITDATAExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.StringHelper;


/**
 * Implementation for ExternalCaseAuditData.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.ExternalCaseAuditData
 */
public class ExternalCaseAuditDataImpl extends SingleTableEntityImpl<ExternalCaseAuditDataDtls> 
  implements ExternalCaseAuditData {
 
  @Inject
  protected ExternalCaseAuditDataDAO externalCaseAuditDataDAO;

  @Inject
  protected ExternalCaseAuditDataItemDAO externalCaseAuditDataItemDAO;

  // ___________________________________________________________________________
  /*
   * no-arg constructor for use only by Guice
   */
  protected ExternalCaseAuditDataImpl() {
    // no-arg constructor for use only by Guice
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the external case audit data.
   *
   */
  @Override
  public void insert() throws InformationalException {
    
    super.insert();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// None Required   
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {
    
    if (StringHelper.isEmpty(getDtls().name)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTEXTERNALCASEAUDITDATAExceptionCreator.ERR_FV_MANDATORY_NAME_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getName() {
    return getDtls().name;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setName(final String name) {

    SortedSet<ExternalCaseAuditData> externalCaseAuditDataList = externalCaseAuditDataDAO.searchByName(
      name);
    
    if (externalCaseAuditDataList.size() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTEXTERNALCASEAUDITDATAExceptionCreator.ERR_FV_NAME_ALREADY_EXISTS(
          name),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    } else {
      getDtls().name = name;  
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<ExternalCaseAuditDataItem> getExternalCaseAuditDataItemsByType(
    final CASETYPECODEEntry caseType, final CASECATTYPECODEEntry category) 
    throws AppException, InformationalException {
    return externalCaseAuditDataItemDAO.searchByExternalCaseAuditDataAndCaseType(
      this, caseType, category);
  }

  // BEGIN, CR00290965, IBM
  /**
   * Retrieves the total number of external case audit data items of a specified 
   * case type that are associated with an external case audit data record.
   *
   * @param casetypecodeEntry the type of case.
   * @param casecattypecodeEntry the category of case.
   *
   * @return total number of specified case type that are associated with 
   * an external case audit data record.
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   */
  public Count countExternalCaseAuditDataItemsByType(
    final CASETYPECODEEntry casetypecodeEntry,
    final CASECATTYPECODEEntry casecattypecodeEntry) throws AppException,
      InformationalException {

    return externalCaseAuditDataItemDAO.countExternalCaseAuditDataByCaseType(
      this, casetypecodeEntry, casecattypecodeEntry);
    // END, CR00290965
  }

}
