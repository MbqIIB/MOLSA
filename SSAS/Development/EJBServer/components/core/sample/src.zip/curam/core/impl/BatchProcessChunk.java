/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.codetable.BATCHPROCESSCHUNKSTATUS;
import curam.core.fact.BatchProcessChunkFactory;
import curam.core.struct.BatchProcessChunkDtlsList;
import curam.core.struct.ReadBatchProcessChunkByStatusKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * The custom methods for the BatchProcessChunk entity
 */
public abstract class BatchProcessChunk extends curam.core.base.BatchProcessChunk {

  // ___________________________________________________________________________
  /**
   * Set the status field to read the unprocessed records
   *
   * @param key The key for this operation
   */
  protected void presearchUnProcessedBatchProcessChunk(ReadBatchProcessChunkByStatusKey key)
    throws AppException, InformationalException {

    key.status = BATCHPROCESSCHUNKSTATUS.UNPROCESSED;

  }

  // ___________________________________________________________________________
  /**
   * Set the status field to read the processed records
   *
   * @param key The key for this operation
   */
  protected void presearchProcessedBatchProcessChunk(ReadBatchProcessChunkByStatusKey key)
    throws AppException, InformationalException {

    key.status = BATCHPROCESSCHUNKSTATUS.PROCESSED;

  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchProcessedBatchProcessChunk
   */
  public BatchProcessChunkDtlsList readProcessedBatchProcessChunk(ReadBatchProcessChunkByStatusKey key) throws curam.util.exception.AppException, curam.util.exception.InformationalException {
    return BatchProcessChunkFactory.newInstance().searchProcessedBatchProcessChunk(
      key);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchUnProcessedBatchProcessChunk
   */
  public BatchProcessChunkDtlsList readUnProcessedBatchProcessChunk(ReadBatchProcessChunkByStatusKey key) throws curam.util.exception.AppException, curam.util.exception.InformationalException {
    return BatchProcessChunkFactory.newInstance().searchUnProcessedBatchProcessChunk(
      key);
  }

}
