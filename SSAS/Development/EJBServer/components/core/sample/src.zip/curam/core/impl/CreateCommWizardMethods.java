/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.WizardScreensRequiredIn;
import curam.core.struct.WizardScreensRequiredOut;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Methods used in the creation of a new communication.
 *
 */
public abstract class CreateCommWizardMethods extends curam.core.base.CreateCommWizardMethods {

  // ___________________________________________________________________________
  /**
   * This method will return details of which wizard screens require input
   * depending on the attributes of the input structure
   *
   * @param key WizardScreensRequiredIn - struct with attributes to determine
   *                          which screens are required
   *
   * @return Details of which screens are required
   */
  public WizardScreensRequiredOut checkWizardScreensRequired(
    WizardScreensRequiredIn key) throws AppException, InformationalException {

    // wizardScreensRequiredOut variable
    WizardScreensRequiredOut wizardScreensRequiredOut =
      new WizardScreensRequiredOut();

    if (key.communicationMethodCode.equals(
      curam.codetable.COMMUNICATIONMETHOD.HARDCOPY)) {

      wizardScreensRequiredOut.commTypeScreenRequiredInd = true;

      if (key.communicationTypeCode.equals(
        curam.codetable.COMMUNICATIONTYPE.LETTER)) {

        wizardScreensRequiredOut.useLetterTemplateScreenRequiredInd = true;
      }

    }

    if (key.communicationMethodCode.equals(
      curam.codetable.COMMUNICATIONMETHOD.EMAIL)) {

      wizardScreensRequiredOut.emailScreenRequiredInd = true;
    }

    if (key.communicationMethodCode.equals(
      curam.codetable.COMMUNICATIONMETHOD.PHONE)) {

      wizardScreensRequiredOut.commTextScreenRequiredInd = true;
    }

    if (key.communicationMethodCode.equals(
      curam.codetable.COMMUNICATIONMETHOD.DATATRANSFER)) {

      wizardScreensRequiredOut.commTypeScreenRequiredInd = true;
      wizardScreensRequiredOut.emailScreenRequiredInd = true;
    }

    if (key.communicationMethodCode.equals(
      curam.codetable.COMMUNICATIONMETHOD.FAX)) {

      wizardScreensRequiredOut.commTypeScreenRequiredInd = true;
    }

    return wizardScreensRequiredOut;
  }

}
