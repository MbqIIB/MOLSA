/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalrequest.impl;

import java.util.List;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;

/**
 * 
 * DAO for approval request mutable object retrieval.
 */
@ImplementedBy(ApprovalRequestLinkDAOImpl.class)
interface ApprovalRequestLinkDAO extends StandardDAO<ApprovalRequestLink> {

  /**
   * Returns immutable list of ApprovalRequestLink records for a given related
   * identifier and related type.
   * 
   * @param relatedID
   *          The identifier for the related type.
   * @param relatedType
   *          The type of linked record.
   * @return Immutable list of ApprovalRequestLink objects for the related
   *         identifier and related type provided.
   */
  public List<ApprovalRequestLink> readByRelatedIDAndRelatedType(
      final long relatedID, final APPROVALRELATEDTYPEEntry relatedType);

  /**
   * Returns the approval request identifier from the approval request link
   * record for the specified relatedID and relatedType.  This method expects 
   * that only one approval request link record will have a status of
   * APPROVALREQUESTSTATUSEntry.SUBMITTED for the given relatedID and relatedType.
   * 
   * @param relatedID
   *          identifier of the record the approval link relates to.
   * @param relatedType
   *          code table code for the record the approval link relates to.
   * @return long the identifier of the approval request link record.
   * @throws InformationalException
   *           if no approval request link is found
   */
  public long getApprovalRequestID(final long relatedID,
      final APPROVALRELATEDTYPEEntry relatedType) throws InformationalException;

  /**
   * Returns the approval request link for the specified relatedID and
   * relatedType.
   * 
   * @param relatedID
   *          identifier of the record the approval link relates to.
   * @param relatedType
   *          code table code for the record the approval link relates to.
   * @return ApprovalRequestLink The approval request link record. Null is
   *         returned if no record in state SUBMITTED is found.
   */
  public ApprovalRequestLink getApprovalRequestLink(final long relatedID,
      final APPROVALRELATEDTYPEEntry relatedType);

  /**
   * Returns immutable list of ApprovalRequestLink records for a given related
   * identifier and related type.
   * 
   * @param relatedID
   *          The identifier for the related type.
   * @param relatedType
   *          The type of linked record.
   * @return Immutable list of ApprovalRequestLink objects for the related
   *         identifier and related type provided.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  public List<ApprovalRequestLink> readByRelatedIDAndRelatedType(
      final long relatedID, final String relatedType)
      throws InformationalException;
}
