/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import java.util.Collections;
import java.util.Comparator;

import curam.codetable.CASECATEGORY;
import curam.codetable.CASESEARCHSTATUS;
import curam.codetable.CASESTATUS;
import curam.codetable.ORGOBJECTTYPE;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectRefType;
import curam.core.sl.fact.ParticipantSearchFactory;
import curam.core.sl.intf.ParticipantSearch;
import curam.core.sl.struct.BooleanResult;
import curam.core.sl.struct.CharCount;
import curam.core.sl.struct.SearchCriteriaString;
import curam.core.struct.CaseCategoryAndStatusDetails;
import curam.core.struct.CaseOwnerTabList;
import curam.core.struct.CaseReferenceSearchKey;
import curam.core.struct.CaseSearchClientNameDetails;
import curam.core.struct.CaseSearchCriteria;
import curam.core.struct.CaseSearchCriteria1;
import curam.core.struct.CaseSearchDetails;
import curam.core.struct.CaseSearchDetails1;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseSearchList;
import curam.core.struct.CaseSearchList1;
import curam.core.struct.InvestigationSearchCriteria;
import curam.core.struct.InvestigationSearchDetails;
import curam.core.struct.InvestigationSearchDetailsList;
import curam.core.struct.ReadByPrimaryAlternateIDDtls;
import curam.core.struct.SearchByPrimaryAlternateIDKey;
import curam.core.struct.SearchCriteriaDateRanges;
import curam.core.struct.UsersKey;
import curam.message.BPOCASESEARCH;
import curam.message.BPOPERSONSEARCH;
import curam.message.GENERALSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.NotFoundIndicator;
import curam.util.type.StringList;


/**
 * Provides methods which will route case searches to the appropriate
 * search engine based on environment settings
 *
 */
public abstract class CaseSearchRouter extends curam.core.base.CaseSearchRouter {

  // BEGIN, CR00098528, NP
  // ___________________________________________________________________________
  /**
   * Checks if the lucene environmental variable is enable to determine if the search
   * will be a database or lucene index search.
   *
   * @return caseSearchObj
   */
  // BEGIN, CR00198672, VK
  protected curam.core.intf.CaseSearch getCaseSearchObj() {
    // END, CR00198672
    curam.core.intf.CaseSearch caseSearchObj;

    if (((Configuration.getBooleanProperty(
      EnvVars.ENV_LUCENE_ENHANCED_SEARCH_ENABLED)))
        && ((Configuration.getBooleanProperty(
          EnvVars.ENV_LUCENE_ENHANCED_CASE_SEARCH_ENABLED)))) {

      caseSearchObj = curam.core.fact.IndexCaseSearchFactory.newInstance();

    } else {

      caseSearchObj = curam.core.fact.DatabaseCaseSearchFactory.newInstance();
    }
    return caseSearchObj;
  }

  // END, CR00098528


  // ___________________________________________________________________________
  /**
   * Method to perform an case search, based solely on the case ID
   *
   * @param key caseSearchKey number
   *
   * @return caseSearchDetails case details
   */
  public CaseSearchDetails readByCaseID(CaseSearchKey key)
    throws AppException, InformationalException {
    // BEGIN, CR00098528, NP
    return getCaseSearchObj().readByCaseID(key);
    // END, CR00098528
  }

  // ___________________________________________________________________________
  /**
   * Method to perform an case search, based solely on the alternate ID
   *
   * @param key alternate ID  number
   *
   * @return readByPrimaryAlternateIDDtls employer details
   */
  public ReadByPrimaryAlternateIDDtls readByPrimaryAlternateID(
    SearchByPrimaryAlternateIDKey key) throws AppException,
      InformationalException {
    // BEGIN, CR00098528, NP
    return getCaseSearchObj().readByPrimaryAlternateID(key);
    // END, CR00098528
  }

  // ___________________________________________________________________________
  /**
   * Method to perform an case search, based solely on the case reference
   *
   * @param key caseReferenceSearchKey number
   *
   * @return caseSearchDetails case details
   */
  public CaseSearchDetails readByCaseReference(CaseReferenceSearchKey key)
    throws AppException, InformationalException {
    // BEGIN, CR00098528, NP
    return getCaseSearchObj().readByCaseReference(key);
    // END, CR00098528
  }

  // BEGIN, CR00201195, ZV
  // BEGIN, CR00077040, PMD
  // ___________________________________________________________________________
  /**
   * @param caseSearchCriteria data on which the search will be based
   *
   * @return The details of any records found
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}. This method
   * has been deprecated to introduce new case search enhancements.
   *
   * Method which routes Case Search calls to the appropriate
   * implementation
   */
  @Deprecated
  public CaseSearchList search(CaseSearchCriteria caseSearchCriteria)
    throws AppException, InformationalException {

    // Validate the case search criteria
    validateSearchCriteria(caseSearchCriteria);
    // BEGIN, CR00098528, NP
    return getCaseSearchObj().search(caseSearchCriteria);
    // END, CR00098528
  }

  // END, CR00201195

  // BEGIN, CR00121404, BD
  // ___________________________________________________________________________
  /**
   * Method which searches for Cases owned by the current user.
   *
   * @param caseSearchCriteria data on which the search will be based
   *
   * @return The details of any records found
   */
  public CaseSearchList searchCurrentUserCasesOnly(CaseSearchCriteria caseSearchCriteria)
    throws AppException, InformationalException {

    // Currently the 'user owned cases only searches' are not supported by the Indexed
    // Search because they allow no search criteria to be entered. If this is done outside
    // the context of the current user the result set would be too large to support.
    curam.core.intf.CaseSearch caseSearchObj = curam.core.fact.DatabaseCaseSearchFactory.newInstance();

    validateSearchCriteriaEntered(caseSearchCriteria);

    return caseSearchObj.searchCurrentUserCasesOnly(caseSearchCriteria);

  }

  // BEGIN, CR00201195, ZV
  // ___________________________________________________________________________
  /**
   * @param caseSearchCriteria search criteria to be validated
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #validateSearchCriteriaEntered1()}. This method has been deprecated
   * to introduce new case search enhancements.
   *
   * Method to validate that at least one case search criteria was entered
   */
  @Deprecated
  protected void validateSearchCriteriaEntered(
    CaseSearchCriteria caseSearchCriteria)
    throws AppException, InformationalException {

    if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.primaryAlternateID.length() == 0
      && caseSearchCriteria.category.length() == 0
      && caseSearchCriteria.type.length() == 0
      && caseSearchCriteria.startDate.isZero()
      && caseSearchCriteria.endDate.isZero()
      && caseSearchCriteria.status.length() == 0
      && !caseSearchCriteria.searchWithAppeals
      && !caseSearchCriteria.searchWithIssues
      && !caseSearchCriteria.searchWithServicePlans // BEGIN, CR00113482, JMA
      && !caseSearchCriteria.searchWithInvestigations) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCASESEARCH.ERR_BPOCASESEARCH_NO_CRITERIA_SPECIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);

    }
  }

  // END, CR00121404
  // END, CR00201195

  // BEGIN, CR00201195, ZV
  // ___________________________________________________________________________
  /**
   * @param caseSearchCriteria search criteria to be validated
   *
   * @deprecated Since Curam 6.0, replaced by {@link #validateSearchCriteria1()}.
   * This method has been deprecated to introduce new case search enhancements.
   *
   * Method to validate the case search criteria
   */
  @Deprecated
  @Override
  protected void validateSearchCriteria(CaseSearchCriteria caseSearchCriteria)
    throws AppException, InformationalException {

    validateSearchCriteriaEntered(caseSearchCriteria);

    if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.primaryAlternateID.length() == 0
      && caseSearchCriteria.category.length() == 0
      && caseSearchCriteria.type.length() == 0
      && caseSearchCriteria.startDate.isZero()
      && caseSearchCriteria.endDate.isZero()
      && caseSearchCriteria.status.length() != 0
      && !caseSearchCriteria.searchWithAppeals
      && !caseSearchCriteria.searchWithIssues
      && !caseSearchCriteria.searchWithServicePlans // BEGIN, CR00113482,  JMA
      && !caseSearchCriteria.searchWithInvestigations) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCASESEARCH.ERR_BPOCASESEARCH_ADDITIONAL_CRITERIA),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);

    } else if (caseSearchCriteria.category.length() != 0
      && caseSearchCriteria.type.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(curam.message.BPOCASESEARCH.ERR_BPOCASESEARCH_NO_TYPE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    } else if (caseSearchCriteria.type.length() != 0
      && caseSearchCriteria.category.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCASESEARCH.ERR_BPOCASESEARCH_NO_CATEGORY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.primaryAlternateID.length() == 0
      && caseSearchCriteria.category.length() != 0
      && caseSearchCriteria.type.length() != 0
      && caseSearchCriteria.startDate.isZero()
      && caseSearchCriteria.endDate.isZero()
      && caseSearchCriteria.status.length() == 0
      && !caseSearchCriteria.searchWithAppeals
      && !caseSearchCriteria.searchWithIssues
      && !caseSearchCriteria.searchWithServicePlans // BEGIN, CR00113482, JMA
      && !caseSearchCriteria.searchWithInvestigations) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          10);

    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.primaryAlternateID.length() == 0
      && caseSearchCriteria.category.length() == 0
      && caseSearchCriteria.type.length() == 0
      && !caseSearchCriteria.startDate.isZero()
      && caseSearchCriteria.endDate.isZero()
      && caseSearchCriteria.status.length() == 0
      && !caseSearchCriteria.searchWithAppeals
      && !caseSearchCriteria.searchWithIssues
      && !caseSearchCriteria.searchWithServicePlans // BEGIN, CR00113482, JMA
      && !caseSearchCriteria.searchWithInvestigations) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          11);

    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.primaryAlternateID.length() == 0
      && caseSearchCriteria.category.length() == 0
      && caseSearchCriteria.type.length() == 0
      && caseSearchCriteria.startDate.isZero()
      && !caseSearchCriteria.endDate.isZero()
      && caseSearchCriteria.status.length() == 0
      && !caseSearchCriteria.searchWithAppeals
      && !caseSearchCriteria.searchWithIssues
      && !caseSearchCriteria.searchWithServicePlans // BEGIN, CR00113482, JMA
      && !caseSearchCriteria.searchWithInvestigations) {
      // END, CR00113482

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          12);

    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.primaryAlternateID.length() == 0
      && caseSearchCriteria.category.length() == 0
      && caseSearchCriteria.type.length() == 0
      && caseSearchCriteria.startDate.isZero()
      && caseSearchCriteria.endDate.isZero()
      && caseSearchCriteria.status.length() == 0
      && caseSearchCriteria.searchWithAppeals) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          14);

    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.primaryAlternateID.length() == 0
      && caseSearchCriteria.category.length() == 0
      && caseSearchCriteria.type.length() == 0
      && caseSearchCriteria.startDate.isZero()
      && caseSearchCriteria.endDate.isZero()
      && caseSearchCriteria.status.length() == 0
      && caseSearchCriteria.searchWithIssues) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          15);

    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.primaryAlternateID.length() == 0
      && caseSearchCriteria.category.length() == 0
      && caseSearchCriteria.type.length() == 0
      && caseSearchCriteria.startDate.isZero()
      && caseSearchCriteria.endDate.isZero()
      && caseSearchCriteria.status.length() == 0
      && caseSearchCriteria.searchWithServicePlans) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          16);
    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.primaryAlternateID.length() == 0
      && caseSearchCriteria.category.length() == 0
      && caseSearchCriteria.type.length() == 0
      && caseSearchCriteria.startDate.isZero()
      && caseSearchCriteria.endDate.isZero()
      && caseSearchCriteria.status.length() == 0
      && caseSearchCriteria.searchWithInvestigations) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          13);

    }
    // END, CR00113482
  }

  // END, CR00077040
  // END, CR00201195

  // BEGIN, CR00201195, ZV
  // BEGIN, CR00150153, ZV
  // BEGIN, CR00204411, ZV
  // ___________________________________________________________________________
  /**
   * Method to validate the search criteria start and end date ranges
   *
   * @param details search criteria date ranges to be validated
   *
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_XFV_START_DATE_FROM_END_DATE_FROM} -
   * If the start date from is after end date from.
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_XFV_START_DATE_FROM_START_DATE_TO} -
   * If the start date to is after start date from.
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_FV_START_DATE_TO_LARGE} -
   * If the start date to is in the future.
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_XFV_START_DATE_TO_END_DATE_TO} -
   * If the start date to is after end date to.
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_FV_START_DATE_FROM_LARGE} -
   * If the start date from is in the future.
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_XFV_END_DATE_FROM_END_DATE_TO} -
   * If the end date to is after end date from.
   */
  @Override
  protected void validateDateRanges(SearchCriteriaDateRanges details)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    Date currentDate = Date.getCurrentDate();

    // Validations to prevent date ranges be set in future
    if (details.startDateFrom.after(currentDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOCASESEARCH.ERR_BPOCASESEARCH_FV_START_DATE_FROM_LARGE),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (details.startDateTo.after(currentDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_FV_START_DATE_TO_LARGE),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Validations to check if from date value is before to date value
    if (!details.startDateFrom.isZero() && !details.startDateTo.isZero()
      && details.startDateFrom.after(details.startDateTo)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOCASESEARCH.ERR_BPOCASESEARCH_XFV_START_DATE_FROM_START_DATE_TO),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (!details.endDateTo.isZero()
      && details.endDateFrom.after(details.endDateTo)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOCASESEARCH.ERR_BPOCASESEARCH_XFV_END_DATE_FROM_END_DATE_TO),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Validations to check if start date values are before end date values
    if (!details.startDateFrom.isZero() && !details.endDateFrom.isZero()
      && details.startDateFrom.after(details.endDateFrom)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOCASESEARCH.ERR_BPOCASESEARCH_XFV_START_DATE_FROM_END_DATE_FROM),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    if (!details.startDateTo.isZero() && !details.endDateTo.isZero()
      && details.startDateTo.after(details.endDateTo)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOCASESEARCH.ERR_BPOCASESEARCH_XFV_START_DATE_TO_END_DATE_TO),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // END, CR00204411
  // END, CR00150153
  // END, CR00201195

  // BEGIN, CR00201195, ZV
  // ___________________________________________________________________________
  /**
   * Method which routes Case Search calls to the appropriate
   * implementation
   *
   * @param caseSearchCriteria data on which the search will be based
   *
   * @return The details of any records found
   *
   * @throws AppException
   * {@link BPOCASESEARCH#INF_BPOCASESEARCH_NO_MATCH} -
   * If there are no records found.
   */
  public CaseSearchList1 search1(CaseSearchCriteria1 caseSearchCriteria)
    throws AppException, InformationalException {

    String ownerList = caseSearchCriteria.ownerList;

    validateSearchCriteria1(caseSearchCriteria);

    if (ownerList.length() > CuramConst.gkZero) {

      CaseOwnerTabList ownerTabList = new CaseOwnerTabList();

      ownerTabList.ownerList = caseSearchCriteria.ownerList;

      caseSearchCriteria.ownerList = processOwnerList(ownerTabList).ownerList;

      // cases are searched by owner(s) where there are no org object link
      // entry created therefore no cases can exist for such owner(s)
      if (caseSearchCriteria.ownerList.length() == CuramConst.gkZero) {
        // BEGIN, CR00327929, ZV
        caseSearchCriteria.ownerList = ownerList;
        // END, CR00327929
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOCASESEARCH.INF_BPOCASESEARCH_NO_MATCH),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
      }
    }

    CaseSearchList1 caseSearchList = getCaseSearchObj().search1(
      caseSearchCriteria);

    // restore original owner list
    caseSearchCriteria.ownerList = ownerList;

    // If no search results are found, alert user
    // BEGIN, CR00231396, ZV
    if (caseSearchList.searchDtls.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOCASESEARCH.INF_BPOCASESEARCH_NO_MATCH),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    } else {
      // sort case details list by status and start date descending
      CompositeComparator compComparator = new CompositeComparator();

      // Sort the active record to be first.
      compComparator.setMajor(new CaseStatusComparator());
      // Sort by the start date descending.
      compComparator.setMinor(new CaseStartDateComparator());

      // Do the composite sort
      Collections.sort(caseSearchList.searchDtls, compComparator);
    }
    // END, CR00231396

    return caseSearchList;
  }

  // ___________________________________________________________________________
  /**
   * Method to validate the case search criteria
   *
   * @param caseSearchCriteria search criteria to be validated
   *
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_MISSING_CRITERIA} -
   * If additional select criteria is required.
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_NO_CATEGORY} -
   * If case type is selected without case category.
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_ADDITIONAL_CRITERIA} -
   * If only case status is selected.
   * @throws InformationalException
   * {@link BPOPERSONSEARCH#INF_PERSONSEARCH_EXACT_MATCH} -
   * If an exact match has been performed on first name and/or last name because 
   * only a single character was entered into the search field.
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_NO_TYPE} -
   * If case category is selected without case type.
   */
  public void validateSearchCriteria1(CaseSearchCriteria1 caseSearchCriteria)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    validateSearchCriteriaEntered1(caseSearchCriteria);
    // BEGIN, CR00379119, SS
    final SearchCriteriaString caseReference = new SearchCriteriaString();

    caseReference.string = caseSearchCriteria.caseReference;
    validateCaseReferenceNumber(caseReference);
    // END, CR00379119
    
    if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.clientFirstName.length() == 0
      && caseSearchCriteria.clientSurname.length() == 0
      && caseSearchCriteria.alternateID.length() == 0
      && caseSearchCriteria.categoryTypeList.length() == 0
      && caseSearchCriteria.startDateFrom.isZero()
      && caseSearchCriteria.startDateTo.isZero()
      && caseSearchCriteria.endDateFrom.isZero()
      && caseSearchCriteria.endDateTo.isZero()
      && caseSearchCriteria.orgObjectLinkID == 0
      && caseSearchCriteria.ownerList.length() == 0
      && caseSearchCriteria.statusList.length() != 0
      && !caseSearchCriteria.searchWithAppeals
      && !caseSearchCriteria.searchWithIssues
      && !caseSearchCriteria.searchWithServicePlans
      && !caseSearchCriteria.searchWithInvestigations) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_ADDITIONAL_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.alternateID.length() == 0
      && caseSearchCriteria.clientFirstName.length() == 0
      && caseSearchCriteria.clientSurname.length() == 0
      && caseSearchCriteria.categoryTypeList.length() != 0
      && caseSearchCriteria.startDateFrom.isZero()
      && caseSearchCriteria.startDateTo.isZero()
      && caseSearchCriteria.endDateFrom.isZero()
      && caseSearchCriteria.endDateTo.isZero()
      && caseSearchCriteria.orgObjectLinkID == 0
      && caseSearchCriteria.ownerList.length() == 0
      && caseSearchCriteria.statusList.length() == 0
      && !caseSearchCriteria.searchWithAppeals
      && !caseSearchCriteria.searchWithIssues
      && !caseSearchCriteria.searchWithServicePlans
      && !caseSearchCriteria.searchWithInvestigations) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 9);
    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.clientFirstName.length() == 0
      && caseSearchCriteria.clientSurname.length() == 0
      && caseSearchCriteria.alternateID.length() == 0
      && caseSearchCriteria.categoryTypeList.length() == 0
      && (!caseSearchCriteria.startDateFrom.isZero()
        || !caseSearchCriteria.startDateTo.isZero())
        && caseSearchCriteria.endDateFrom.isZero()
        && caseSearchCriteria.endDateTo.isZero()
        && caseSearchCriteria.orgObjectLinkID == 0
        && caseSearchCriteria.ownerList.length() == 0
        && caseSearchCriteria.statusList.length() == 0
        && !caseSearchCriteria.searchWithAppeals
        && !caseSearchCriteria.searchWithIssues
        && !caseSearchCriteria.searchWithServicePlans
        && !caseSearchCriteria.searchWithInvestigations) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 5);
    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.clientFirstName.length() == 0
      && caseSearchCriteria.clientSurname.length() == 0
      && caseSearchCriteria.alternateID.length() == 0
      && caseSearchCriteria.categoryTypeList.length() == 0
      && caseSearchCriteria.startDateFrom.isZero()
      && caseSearchCriteria.startDateTo.isZero()
      && (!caseSearchCriteria.endDateFrom.isZero()
        || !caseSearchCriteria.endDateTo.isZero())
        && caseSearchCriteria.orgObjectLinkID == 0
        && caseSearchCriteria.ownerList.length() == 0
        && caseSearchCriteria.statusList.length() == 0
        && !caseSearchCriteria.searchWithAppeals
        && !caseSearchCriteria.searchWithIssues
        && !caseSearchCriteria.searchWithServicePlans
        && !caseSearchCriteria.searchWithInvestigations) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 8);
    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.clientFirstName.length() == 0
      && caseSearchCriteria.clientSurname.length() == 0
      && caseSearchCriteria.alternateID.length() == 0
      && caseSearchCriteria.categoryTypeList.length() == 0
      && caseSearchCriteria.startDateFrom.isZero()
      && caseSearchCriteria.startDateTo.isZero()
      && caseSearchCriteria.endDateFrom.isZero()
      && caseSearchCriteria.endDateTo.isZero()
      && caseSearchCriteria.orgObjectLinkID == 0
      && caseSearchCriteria.ownerList.length() == 0
      && caseSearchCriteria.statusList.length() == 0
      && caseSearchCriteria.searchWithAppeals) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.clientFirstName.length() == 0
      && caseSearchCriteria.clientSurname.length() == 0
      && caseSearchCriteria.alternateID.length() == 0
      && caseSearchCriteria.categoryTypeList.length() == 0
      && caseSearchCriteria.startDateFrom.isZero()
      && caseSearchCriteria.startDateTo.isZero()
      && caseSearchCriteria.endDateFrom.isZero()
      && caseSearchCriteria.endDateTo.isZero()
      && caseSearchCriteria.orgObjectLinkID == 0
      && caseSearchCriteria.ownerList.length() == 0
      && caseSearchCriteria.statusList.length() == 0
      && caseSearchCriteria.searchWithIssues) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.clientFirstName.length() == 0
      && caseSearchCriteria.clientSurname.length() == 0
      && caseSearchCriteria.alternateID.length() == 0
      && caseSearchCriteria.categoryTypeList.length() == 0
      && caseSearchCriteria.startDateFrom.isZero()
      && caseSearchCriteria.startDateTo.isZero()
      && caseSearchCriteria.endDateFrom.isZero()
      && caseSearchCriteria.endDateTo.isZero()
      && caseSearchCriteria.orgObjectLinkID == 0
      && caseSearchCriteria.ownerList.length() == 0
      && caseSearchCriteria.statusList.length() == 0
      && caseSearchCriteria.searchWithServicePlans) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    } else if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.clientFirstName.length() == 0
      && caseSearchCriteria.clientSurname.length() == 0
      && caseSearchCriteria.alternateID.length() == 0
      && caseSearchCriteria.categoryTypeList.length() == 0
      && caseSearchCriteria.startDateFrom.isZero()
      && caseSearchCriteria.startDateTo.isZero()
      && caseSearchCriteria.endDateFrom.isZero()
      && caseSearchCriteria.endDateTo.isZero()
      && caseSearchCriteria.orgObjectLinkID == 0
      && caseSearchCriteria.ownerList.length() == 0
      && caseSearchCriteria.statusList.length() == 0
      && caseSearchCriteria.searchWithInvestigations) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 7);
    }

    SearchCriteriaDateRanges searchCriteriaDateRanges = new SearchCriteriaDateRanges();

    searchCriteriaDateRanges.assign(caseSearchCriteria);

    validateDateRanges(searchCriteriaDateRanges);

    // BEGIN, CR00202080, ZV
    validateTypeAndStatus(caseSearchCriteria);
    // END, CR00202080

    // BEGIN, CR00338327, ZV
    CaseSearchClientNameDetails clientNameDetails = new CaseSearchClientNameDetails();

    clientNameDetails.assign(caseSearchCriteria);

    validateClientNames(clientNameDetails);
    
    informationalManager.failOperation();
    
    if ((caseSearchCriteria.clientFirstName.length() == 1
      && caseSearchCriteria.clientSurname.isEmpty()) 
        || caseSearchCriteria.clientSurname.length() == 1) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOPERSONSEARCH.INF_PERSONSEARCH_EXACT_MATCH),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    // END, CR00338327
    
  }

  // ___________________________________________________________________________
  /**
   * Method to validate that at least one case search criteria was entered
   *
   * @param caseSearchCriteria search criteria to be validated
   *
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_NO_CRITERIA_SPECIFIED} -
   * If there is no criteria specified.
   */
  @Override
  protected void validateSearchCriteriaEntered1(
    CaseSearchCriteria1 caseSearchCriteria)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (caseSearchCriteria.caseReference.length() == 0
      && caseSearchCriteria.concernRoleID == 0
      && caseSearchCriteria.alternateID.length() == 0
      && caseSearchCriteria.clientFirstName.length() == 0
      && caseSearchCriteria.clientSurname.length() == 0
      && caseSearchCriteria.categoryTypeList.length() == 0
      && caseSearchCriteria.startDateFrom.isZero()
      && caseSearchCriteria.startDateTo.isZero()
      && caseSearchCriteria.endDateFrom.isZero()
      && caseSearchCriteria.endDateTo.isZero()
      && caseSearchCriteria.orgObjectLinkID == 0
      && caseSearchCriteria.ownerList.length() == 0
      && caseSearchCriteria.statusList.length() == 0
      && !caseSearchCriteria.searchWithAppeals
      && !caseSearchCriteria.searchWithIssues
      && !caseSearchCriteria.searchWithServicePlans
      && !caseSearchCriteria.searchWithInvestigations) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_NO_CRITERIA_SPECIFIED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // END, CR00201195

  // BEGIN, CR00202080, ZV
  // ___________________________________________________________________________
  /**
   * Method to validate case categories against case status codes.
   *
   * @param caseSearchCriteria search criteria to be validated
   *
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_XFV_STATUS_TYPE} -
   * If case category and status combination is not valid.
   */
  public void validateTypeAndStatus(CaseSearchCriteria1 caseSearchCriteria)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    CaseCategoryAndStatusDetails caseCategoryAndStatusDetails = new CaseCategoryAndStatusDetails();

    if (caseSearchCriteria.categoryTypeList.length() > CuramConst.gkZero
      && caseSearchCriteria.statusList.length() > CuramConst.gkZero) {

      StringList categoryTypeList = StringUtil.tabText2StringListWithTrim(
        caseSearchCriteria.categoryTypeList);

      for (int i = 0; i < categoryTypeList.size(); i++) {

        StringList categoryType = StringUtil.delimitedText2StringListWithTrim(
          categoryTypeList.item(i), CuramConst.gkPipeDelimiterChar);

        if (categoryType.size() > CuramConst.gkOne) {
          // get case category
          caseCategoryAndStatusDetails.category = categoryType.item(0);

          StringList statusList = StringUtil.tabText2StringListWithTrim(
            caseSearchCriteria.statusList);

          for (int j = 0; j < statusList.size(); j++) {

            boolean statusValidInd = false;

            if (statusList.item(j).length() > 0) {

              caseCategoryAndStatusDetails.status = statusList.item(j);

              statusValidInd = isCaseCategoryStatusValid(caseCategoryAndStatusDetails).booleanResult;

            } // if (statusList.item(j).length() > 0)

            if (!statusValidInd) {

              for (int k = 0; k < categoryTypeList.size(); k++) {
                StringList secondCategoryType = StringUtil.delimitedText2StringListWithTrim(
                  categoryTypeList.item(k), CuramConst.gkPipeDelimiterChar);

                if (i != k) {
                  if (secondCategoryType.size() > CuramConst.gkOne) {
                    caseCategoryAndStatusDetails.category = secondCategoryType.item(
                      0);

                    statusValidInd = isCaseCategoryStatusValid(caseCategoryAndStatusDetails).booleanResult;

                    if (statusValidInd) {
                      break;
                    }
                  } // if (secondCategoryType.size() > CuramConst.gkOne)
                } // if (i != k)
              } // for k

              if (!statusValidInd) {
                AppException ae = new AppException(
                  BPOCASESEARCH.ERR_BPOCASESEARCH_XFV_STATUS_TYPE);

                ae.arg(
                  new CodeTableItemIdentifier(CASESEARCHSTATUS.TABLENAME,
                  caseCategoryAndStatusDetails.status));

                curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
                  ae, CuramConst.gkEmpty,
                  InformationalElement.InformationalType.kError,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  0);
                return;

              }

            } // if (statusInvalidInd)

          } // for j
        } // if (categoryType.size() > CuramConst.gkOne)
      } // for i
    } // if (caseSearchCriteria.categoryTypeList.length() > CuramConst.gkZero
    // && caseSearchCriteria.statusList.length() > CuramConst.gkZero)
  }

  // ___________________________________________________________________________
  /**
   * Method to determine if case category and status combination is valid.
   *
   * @param details case category and status details
   *
   * @return true if case category and status combination is valid
   */
  @Override
  protected BooleanResult isCaseCategoryStatusValid(
    CaseCategoryAndStatusDetails details)
    throws AppException, InformationalException {

    BooleanResult result = new BooleanResult();

    result.booleanResult = true;

    if (details.category.equals(CASECATEGORY.INTEGRATEDCASE)
      && !(details.status.equals(CASESEARCHSTATUS.OPEN)
        || details.status.equals(CASESEARCHSTATUS.CLOSED)
        || details.status.equals(CASESEARCHSTATUS.PENDINGCLOSURE))) {
      result.booleanResult = false;
    } else if (details.category.equals(CASECATEGORY.PRODUCTDELIVERY)
      && !(details.status.equals(CASESEARCHSTATUS.OPEN)
        || details.status.equals(CASESEARCHSTATUS.COMPLETED)
        || details.status.equals(CASESEARCHSTATUS.APPROVED)
        || details.status.equals(CASESEARCHSTATUS.DELAYEDPROC)
        || details.status.equals(CASESEARCHSTATUS.REJECTED)
        || details.status.equals(CASESEARCHSTATUS.ACTIVE)
        || details.status.equals(CASESEARCHSTATUS.SUSPENDED)
        || details.status.equals(CASESEARCHSTATUS.CLOSED)
        || details.status.equals(CASESEARCHSTATUS.PENDINGCLOSURE))) {
      result.booleanResult = false;
    }

    return result;
  }

  // END, CR00202080

  // BEGIN, CR00202673, ZV
  // ___________________________________________________________________________
  /**
   * Method to process owner list before performing case search. Converts
   * user name or organization object reference into organization object link
   * id.
   *
   * @param details case search criteria containing owner list
   *
   * @return organization object link id tab list
   */
  @Override
  protected CaseOwnerTabList processOwnerList(CaseOwnerTabList details)
    throws AppException, InformationalException {

    CaseOwnerTabList returnOwnerList = new CaseOwnerTabList();

    if (details.ownerList.length() > 0) {

      OrgObjectLink orgObjectLinkObj = OrgObjectLinkFactory.newInstance();
      OrgObjectRefType orgObjectRefType = new OrgObjectRefType();
      UsersKey usersKey = new UsersKey();
      NotFoundIndicator orgObjectNotFoundInd = new NotFoundIndicator();

      StringList ownerList = StringUtil.tabText2StringListWithTrim(
        details.ownerList);

      for (int i = 0; i < ownerList.size(); i++) {

        StringList orgObjectTypeOwner = StringUtil.delimitedText2StringListWithTrim(
          ownerList.item(i), CuramConst.gkPipeDelimiterChar);

        if (orgObjectTypeOwner.size() > CuramConst.gkOne) {

          orgObjectRefType.orgObjectType = orgObjectTypeOwner.item(
            CuramConst.gkZero);

          OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();

          orgObjectNotFoundInd.setNotFound(true);

          if (orgObjectRefType.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

            usersKey.userName = orgObjectTypeOwner.item(CuramConst.gkOne);

            orgObjectLinkDtls = orgObjectLinkObj.readByUsername(
              orgObjectNotFoundInd, usersKey);

          } else { // if (orgObjectRefType.orgObjectType.equals(
            // ORGOBJECTTYPE.USER))
            orgObjectRefType.orgObjectReference = Long.parseLong(
              orgObjectTypeOwner.item(CuramConst.gkOne));

            orgObjectLinkDtls = orgObjectLinkObj.readByOrgObjectReferenceType(
              orgObjectNotFoundInd, orgObjectRefType);

          } // if (orgObjectRefType.orgObjectType.equals(ORGOBJECTTYPE.USER))

          if (!orgObjectNotFoundInd.isNotFound()) {
            returnOwnerList.ownerList += String.valueOf(
              orgObjectLinkDtls.orgObjectLinkID)
                + CuramConst.gkTabDelimiter;
          }

        } // if (orgObjectTypeOwner.size() > CuramConst.gkOne)
      } // for i
      if (returnOwnerList.ownerList.length() > CuramConst.gkZero) {
        returnOwnerList.ownerList = returnOwnerList.ownerList.substring(
          CuramConst.gkZero,
          returnOwnerList.ownerList.length()
            - CuramConst.gkTabDelimiter.length());
      }
    } // if (details.ownerList.length() > 0)

    return returnOwnerList;

  }

  // END, CR00202673

  // BEGIN, CR00204411, ZV
  // ___________________________________________________________________________
  /**
   * Method which routes Case Search calls to the appropriate
   * implementation
   *
   * @param searchCriteria data on which the search will be based
   *
   * @return The details of any records found
   *
   * @throws AppException
   * {@link BPOCASESEARCH#INF_BPOCASESEARCH_INVESTIGATION_NO_MATCH} -
   * If there are no records found.
   */
  public InvestigationSearchDetailsList investigationSearch(
    InvestigationSearchCriteria searchCriteria)
    throws AppException, InformationalException {

    String ownerList = searchCriteria.ownerList;

    validateInvestigationSearchCriteria(searchCriteria);

    if (ownerList.length() > CuramConst.gkZero) {

      CaseOwnerTabList ownerTabList = new CaseOwnerTabList();

      ownerTabList.ownerList = searchCriteria.ownerList;

      searchCriteria.ownerList = processOwnerList(ownerTabList).ownerList;

      // investigations are searched by owner(s) where there are no
      // org object link entry created therefore no cases can exist
      // for such owner(s)
      if (searchCriteria.ownerList.length() == CuramConst.gkZero) {
        // BEGIN, CR00327929, ZV
        searchCriteria.ownerList = ownerList;
        // END, CR00327929
        
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOCASESEARCH.INF_BPOCASESEARCH_INVESTIGATION_NO_MATCH),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    InvestigationSearchDetailsList investigationSearchList = getInvestigationSearchObj().investigationSearch(
      searchCriteria);

    // BEGIN, CR00230649, JMA
    for (InvestigationSearchDetails details
      : investigationSearchList.searchDtls) {

      details.contextPanelName = CuramConst.InvestigationPreviewPage;

      details.contextPanelName += CuramConst.kQuestion
        + CuramConst.gkPageParameterCaseID + CuramConst.gkEqualsNoSpaces
        + details.caseID;
    }
    // END, CR00230649
    // restore original owner list
    searchCriteria.ownerList = ownerList;

    // If no search results are found, alert user
    // BEGIN, CR00231396, ZV
    if (investigationSearchList.searchDtls.isEmpty()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOCASESEARCH.INF_BPOCASESEARCH_INVESTIGATION_NO_MATCH),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    } else {

      // Sort investigation details list
      CompositeComparator compComparator = new CompositeComparator();

      // Sort the active record to be first.
      compComparator.setMajor(new InvestigationStatusComparator());
      // Sort by the start date.
      compComparator.setMinor(new InvestigationStartDateComparator());

      // Do the composite sort
      Collections.sort(investigationSearchList.searchDtls, compComparator);

    }
    // END, CR00231396

    return investigationSearchList;
  }

  // END, CR00204411

  // BEGIN, CR00204411, ZV
  // ___________________________________________________________________________
  /**
   * Method to validate the investigation search criteria
   *
   * @param searchCriteria search criteria to be validated
   *
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_ADDITIONAL_CRITERIA} -
   * If only investigation status is selected.
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_MISSING_CRITERIA} -
   * If additional select criteria is required.
   * @throws InformationalException
   * {@link BPOPERSONSEARCH#INF_PERSONSEARCH_EXACT_MATCH} -
   * If an exact match has been performed on first name and/or last name because 
   * only a single character was entered into the search field.
   */
  public void validateInvestigationSearchCriteria(
    InvestigationSearchCriteria searchCriteria)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    validateInvestigationSearchCriteriaEntered(searchCriteria);
    // BEGIN, CR00379119, SS
    final SearchCriteriaString caseReference = new SearchCriteriaString();

    caseReference.string = searchCriteria.caseReference;
    validateCaseReferenceNumber(caseReference);
    // END, CR00379119
    if (searchCriteria.caseReference.length() == 0
      && searchCriteria.concernRoleID == 0
      && searchCriteria.clientFirstName.length() == 0
      && searchCriteria.clientSurname.length() == 0
      && searchCriteria.alternateID.length() == 0
      && searchCriteria.typeList.length() == 0
      && searchCriteria.subtypeList.length() == 0
      && searchCriteria.startDateFrom.isZero()
      && searchCriteria.startDateTo.isZero()
      && searchCriteria.endDateFrom.isZero()
      && searchCriteria.endDateTo.isZero()
      && searchCriteria.ownerList.length() == 0
      && searchCriteria.statusList.length() != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_ADDITIONAL_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    } else if (searchCriteria.caseReference.length() == 0
      && searchCriteria.concernRoleID == 0
      && searchCriteria.alternateID.length() == 0
      && searchCriteria.clientFirstName.length() == 0
      && searchCriteria.clientSurname.length() == 0
      && searchCriteria.typeList.length() != 0
      && searchCriteria.subtypeList.length() == 0
      && searchCriteria.startDateFrom.isZero()
      && searchCriteria.startDateTo.isZero()
      && searchCriteria.endDateFrom.isZero()
      && searchCriteria.endDateTo.isZero()
      && searchCriteria.ownerList.length() == 0
      && searchCriteria.statusList.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 6);
    } else if (searchCriteria.caseReference.length() == 0
      && searchCriteria.concernRoleID == 0
      && searchCriteria.clientFirstName.length() == 0
      && searchCriteria.clientSurname.length() == 0
      && searchCriteria.alternateID.length() == 0
      && searchCriteria.typeList.length() == 0
      && searchCriteria.subtypeList.length() == 0
      && (!searchCriteria.startDateFrom.isZero()
        || !searchCriteria.startDateTo.isZero())
        && searchCriteria.endDateFrom.isZero()
        && searchCriteria.endDateTo.isZero()
        && searchCriteria.ownerList.length() == 0
        && searchCriteria.statusList.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    } else if (searchCriteria.caseReference.length() == 0
      && searchCriteria.concernRoleID == 0
      && searchCriteria.clientFirstName.length() == 0
      && searchCriteria.clientSurname.length() == 0
      && searchCriteria.alternateID.length() == 0
      && searchCriteria.typeList.length() == 0
      && searchCriteria.subtypeList.length() == 0
      && searchCriteria.startDateFrom.isZero()
      && searchCriteria.startDateTo.isZero()
      && (!searchCriteria.endDateFrom.isZero()
        || !searchCriteria.endDateTo.isZero())
        && searchCriteria.ownerList.length() == 0
        && searchCriteria.statusList.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_MISSING_CRITERIA),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 4);
    }

    SearchCriteriaDateRanges searchCriteriaDateRanges = new SearchCriteriaDateRanges();

    searchCriteriaDateRanges.assign(searchCriteria);

    validateDateRanges(searchCriteriaDateRanges);

    // BEGIN, CR00338327, ZV
    CaseSearchClientNameDetails clientNameDetails = new CaseSearchClientNameDetails();

    clientNameDetails.assign(searchCriteria);

    validateClientNames(clientNameDetails);
    
    informationalManager.failOperation();
    
    if ((searchCriteria.clientFirstName.length() == 1
      && searchCriteria.clientSurname.isEmpty()) 
        || searchCriteria.clientSurname.length() == 1) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOPERSONSEARCH.INF_PERSONSEARCH_EXACT_MATCH),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }
    // END, CR00338327
    
  }

  // BEGIN, CR00379119, SS
  /**
   * Validates the case reference number entered.
   *
   * @param SearchCriteriaString
   * Contains the case reference number.
   *
   * @throws InformationalException
   * {@link GENERALSEARCH#ERR_SEARCH_FV_REFERENCE_NUMBER_SHORT} -
   * Reference field must contain at least %1n alphanumerical
   * character(s).
   */
  protected void validateCaseReferenceNumber(SearchCriteriaString caseReference)
    throws AppException, InformationalException {
    final ParticipantSearch participantSearchObj = ParticipantSearchFactory.newInstance();
    CharCount count;

    if (0 < caseReference.string.length()) {
      count = participantSearchObj.countAlphaNumChar(caseReference);
      if (1 > count.count) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          new AppException(GENERALSEARCH.ERR_SEARCH_FV_REFERENCE_NUMBER_SHORT).arg(
            1),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
  }

  // END, CR00379119

  // ___________________________________________________________________________
  /**
   * Method to validate that at least one investigation search criteria was
   * entered
   *
   * @param searchCriteria search criteria to be validated
   *
   * @throws InformationalException
   * {@link BPOCASESEARCH#ERR_BPOCASESEARCH_NO_CRITERIA_SPECIFIED} -
   * If there is no criteria specified.
   */
  @Override
  protected void validateInvestigationSearchCriteriaEntered(
    InvestigationSearchCriteria searchCriteria)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (searchCriteria.caseReference.length() == 0
      && searchCriteria.concernRoleID == 0
      && searchCriteria.alternateID.length() == 0
      && searchCriteria.clientFirstName.length() == 0
      && searchCriteria.clientSurname.length() == 0
      && searchCriteria.typeList.length() == 0
      && searchCriteria.subtypeList.length() == 0
      && searchCriteria.startDateFrom.isZero()
      && searchCriteria.startDateTo.isZero()
      && searchCriteria.endDateFrom.isZero()
      && searchCriteria.endDateTo.isZero()
      && searchCriteria.ownerList.length() == 0
      && searchCriteria.statusList.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(BPOCASESEARCH.ERR_BPOCASESEARCH_NO_CRITERIA_SPECIFIED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
  }

  // ___________________________________________________________________________
  /**
   * Checks if the lucene environmental variable is enable to determine if the
   * search will be a database or lucene index search.
   *
   * @return Investigation search object
   */
  protected curam.core.intf.CaseSearch getInvestigationSearchObj() {

    curam.core.intf.CaseSearch investigationSearchObj;

    if (((Configuration.getBooleanProperty(
      EnvVars.ENV_LUCENE_ENHANCED_SEARCH_ENABLED)))
        && ((Configuration.getBooleanProperty(
          EnvVars.ENV_LUCENE_ENHANCED_INVESTIGATION_SEARCH_ENABLED)))) {

      investigationSearchObj = curam.core.fact.IndexCaseSearchFactory.newInstance();

    } else {

      investigationSearchObj = curam.core.fact.DatabaseCaseSearchFactory.newInstance();
    }
    return investigationSearchObj;
  }
  // END, CR00204411

  // BEGIN, CR00231396, ZV
  /*
   * Generic mechanism to combine two different sorts. This Comparator is used
   * when we want to order a list based on two different fields. We define a
   * generic CompositeComparator that combines the logic of two individual
   * Comparators.
   * We refer to the two Comparators as the major and minor comparators.
   * The major comparator has priority over the minor comparator. If the major
   * comparator returns < 0 or > 0, then that result is passed back. The minor
   * comparator's result is used only if the major comparator returns 0
   */
  protected class CompositeComparator implements Comparator<Object> {
    protected Comparator<Object> major;
    protected Comparator<Object> minor;

    /**
     * Constructor.
     *
     * @param major The major comparator
     * @param minor The minor comparator
     */
    public CompositeComparator(final Comparator<Object> major,
      final Comparator<Object> minor) {
      this.major = major;
      this.minor = minor;
    }

    /**
     * Default Constructor.
     */
    public CompositeComparator() {// Default constructor
    }

    /**
     * Compare the cases.
     *
     * @param o1 The first object to compare
     * @param o2 The second object to compare
     *
     * @return The result of the comparison
     */
    public int compare(final Object o1, final Object o2) {
      int result = major.compare(o1, o2);

      if (result != 0) {
        return result;
      } else {
        return minor.compare(o1, o2);
      }
    }

    /**
     * Sets major comparator.
     *
     * @param major The major comparator
     */
    public void setMajor(final Comparator<Object> major) {
      this.major = major;
    }

    /**
     * Sets minor comparator.
     *
     * @param minor The minor comparator
     */
    public void setMinor(final Comparator<Object> minor) {
      this.minor = minor;
    }
  }


  /**
   * Comparator to sort case list by case status
   */
  protected class CaseStatusComparator
    implements Comparator<Object> {

    /**
     * Constructor.
     */
    public CaseStatusComparator() {
      super();
    }

    /**
     * Compare the case details by status code.
     *
     * @param o1 The first case
     * @param o2 The second case
     *
     * @return The result of the comparison
     */
    public int compare(final Object o1, final Object o2) {

      CaseSearchDetails1 case1 = (CaseSearchDetails1) o1;
      CaseSearchDetails1 case2 = (CaseSearchDetails1) o2;

      if (case1.statusCode.equals(case2.statusCode)) {
        return 0;
      } else if (case1.statusCode.equals(CASESTATUS.OPEN)) {
        return -1;
      } else if (case1.statusCode.equals(CASESTATUS.APPROVED)
        && !case2.statusCode.equals(CASESTATUS.OPEN)) {
        return -1;
      } else if (case1.statusCode.equals(CASESTATUS.COMPLETED)
        && !(case2.statusCode.equals(CASESTATUS.OPEN)
          || case2.statusCode.equals(CASESTATUS.APPROVED))) {
        return -1;
      } else if (case1.statusCode.equals(CASESTATUS.SUSPENDED)
        && !(case2.statusCode.equals(CASESTATUS.OPEN)
          || case2.statusCode.equals(CASESTATUS.APPROVED)
          || case2.statusCode.equals(CASESTATUS.COMPLETED))) {
        return -1;
      } else if (case1.statusCode.equals(CASESTATUS.ACTIVE)
        && !(case2.statusCode.equals(CASESTATUS.OPEN)
          || case2.statusCode.equals(CASESTATUS.APPROVED)
          || case2.statusCode.equals(CASESTATUS.COMPLETED)
          || case2.statusCode.equals(CASESTATUS.SUSPENDED))) {
        return -1;
      } else if (case1.statusCode.equals(CASESTATUS.PENDINGCLOSURE)
        && !(case2.statusCode.equals(CASESTATUS.OPEN)
          || case2.statusCode.equals(CASESTATUS.APPROVED)
          || case2.statusCode.equals(CASESTATUS.COMPLETED)
          || case2.statusCode.equals(CASESTATUS.SUSPENDED)
          || case2.statusCode.equals(CASESTATUS.ACTIVE))) {
        return -1;
      } else if (case1.statusCode.equals(CASESTATUS.CLOSED)) {
        return 1;
      } else {
        return 1;
      }
    }
  }


  /**
   * Comparator to sort case list by case start date descending
   */
  protected class CaseStartDateComparator
    implements Comparator<Object> {

    /**
     * Constructor.
     */
    public CaseStartDateComparator() {
      super();
    }

    /**
     * Compare the case details by start date descending.
     *
     * @param o1 The first case
     * @param o2 The second case
     *
     * @return The result of the comparison
     */
    public int compare(final Object o1,
      final Object o2) {

      CaseSearchDetails1 case1 = (CaseSearchDetails1) o1;
      CaseSearchDetails1 case2 = (CaseSearchDetails1) o2;

      if (case1.startDate.after(case2.startDate)) {
        return -1;
      } else if (case1.startDate.before(case2.startDate)) {
        return 1;
      } else {
        return 0;
      }
    }
  }


  /**
   * Comparator to sort investigation list by case status
   */
  protected class InvestigationStatusComparator
    implements Comparator<Object> {

    /**
     * Constructor.
     */
    public InvestigationStatusComparator() {
      super();
    }

    /**
     * Compare the case details by status code.
     *
     * @param o1 The first investigation
     * @param o2 The second investigation
     *
     * @return The result of the comparison
     */
    public int compare(final Object o1, final Object o2) {

      InvestigationSearchDetails investigation1 = (InvestigationSearchDetails) o1;
      InvestigationSearchDetails investigation2 = (InvestigationSearchDetails) o2;

      if (investigation1.statusCode.equals(investigation2.statusCode)) {
        return 0;
      } else if (investigation1.statusCode.equals(CASESTATUS.OPEN)) {
        return -1;
      } else if (investigation1.statusCode.equals(CASESTATUS.APPROVED)
        && !investigation2.statusCode.equals(CASESTATUS.OPEN)) {
        return -1;
      } else if (investigation1.statusCode.equals(CASESTATUS.COMPLETED)
        && !(investigation2.statusCode.equals(CASESTATUS.OPEN)
          || investigation2.statusCode.equals(CASESTATUS.APPROVED))) {
        return -1;
      } else if (investigation1.statusCode.equals(CASESTATUS.REJECTED)
        && !(investigation2.statusCode.equals(CASESTATUS.OPEN)
          || investigation2.statusCode.equals(CASESTATUS.APPROVED)
          || investigation2.statusCode.equals(CASESTATUS.COMPLETED))) {
        return -1;
      } else if (investigation1.statusCode.equals(CASESTATUS.CLOSED)) {
        return 1;
      } else {
        return 1;
      }
    }
  }


  /**
   * Comparator to sort investigation list by investigation start date
   * descending
   */
  protected class InvestigationStartDateComparator
    implements Comparator<Object> {

    /**
     * Constructor.
     */
    public InvestigationStartDateComparator() {
      super();
    }

    /**
     * Compare the case details by start date descending.
     *
     * @param o1 The first investigation
     * @param o2 The second investigation
     *
     * @return The result of the comparison
     */
    public int compare(final Object o1, final Object o2) {

      InvestigationSearchDetails investigation1 = (InvestigationSearchDetails) o1;
      InvestigationSearchDetails investigation2 = (InvestigationSearchDetails) o2;

      if (investigation1.startDate.after(investigation2.startDate)) {
        return -1;
      } else if (investigation1.startDate.before(investigation2.startDate)) {
        return 1;
      } else {
        return 0;
      }
    }
  }
  // END, CR00231396

  // BEGIN, CR00338327, ZV
  // ___________________________________________________________________________
  /**
   * Method to validate the search criteria client names
   *
   * @param details search criteria client names to be validated
   *
   * @throws InformationalException
   * {@link BPOPERSONSEARCH#ERR_PERSONSEARCH_FV_FIRST_NAME_SHORT} -
   * If first name contains less than 1 alphanumerical character.
   * @throws InformationalException
   * {@link BPOPERSONSEARCH#ERR_PERSONSEARCH_FV_LAST_NAME_SHORT} -
   * If last name contains less than 1 alphanumerical character.
   * @throws InformationalException
   * {@link BPOPERSONSEARCH#ERR_PERSONSEARCH_FV_FIRST_NAME_SHORT_PARTIAL_MATCH} -
   * If first name contains 1 alphanumerical character for partial match search.
   * @throws InformationalException
   * {@link BPOPERSONSEARCH#ERR_PERSONSEARCH_FV_LAST_NAME_SHORT_PARTIAL_MATCH} -
   * If last name contains 1 alphanumerical character for partial match search.
   */
  @Override
  protected void validateClientNames(CaseSearchClientNameDetails details)
    throws AppException, InformationalException {

    ParticipantSearch participantSearchObj = ParticipantSearchFactory.newInstance();
    SearchCriteriaString searchCriteriaString = new SearchCriteriaString();
    CharCount count;

    if (details.clientFirstName.length() > 0) {

      searchCriteriaString.string = details.clientFirstName;
      count = participantSearchObj.countAlphaNumChar(searchCriteriaString);

      if (count.count < 1) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          new AppException(BPOPERSONSEARCH.ERR_PERSONSEARCH_FV_FIRST_NAME_SHORT).arg(
            1),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      } else if (count.count == 1 && count.containsWildcardIndOpt
        && details.clientSurname.isEmpty()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          new AppException(BPOPERSONSEARCH.ERR_PERSONSEARCH_FV_FIRST_NAME_SHORT_PARTIAL_MATCH).arg(
            2),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }

    }

    if (details.clientSurname.length() > 0) {

      searchCriteriaString.string = details.clientSurname;
      count = participantSearchObj.countAlphaNumChar(searchCriteriaString);

      if (count.count < 1) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          new AppException(BPOPERSONSEARCH.ERR_PERSONSEARCH_FV_LAST_NAME_SHORT).arg(
            1),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      } else if (count.count == 1 && count.containsWildcardIndOpt) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          new AppException(BPOPERSONSEARCH.ERR_PERSONSEARCH_FV_LAST_NAME_SHORT_PARTIAL_MATCH).arg(
            2),
            CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }
    }

  }
  // END, CR00338327
}
