/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;

import curam.core.facade.struct.SchoolDistrictSearchDetailsList;
import curam.core.facade.struct.SchoolDistrictSearchKey;
import curam.core.sl.fact.SchoolDistrictFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

public class SchoolDistrict extends curam.core.facade.base.SchoolDistrict {

  /**
   * This method searches the School District with respect to the criteria
   * entered by the user.
   * 
   * @param key
   *          of type SchoolDistrictSearchKey
   * @return SchoolDistrictSearchDetailsList
   * 
   * @throws AppException
   *           Application Exception
   * @throws InformationalException
   *           Informational Exception
   */
  public SchoolDistrictSearchDetailsList search(SchoolDistrictSearchKey key)
      throws AppException, InformationalException {
    SchoolDistrictSearchDetailsList SchoolDistrictSearchDetailsList = 
      new SchoolDistrictSearchDetailsList();
    curam.core.sl.intf.SchoolDistrict maintainSchoolDistrictObj = SchoolDistrictFactory
        .newInstance();
    curam.core.sl.struct.SchoolDistrictSearchKey schoolDistrictSearchKeySL = 
      new curam.core.sl.struct.SchoolDistrictSearchKey();
    schoolDistrictSearchKeySL.assign(key);
    curam.core.sl.struct.SchoolDistrictSearchDetailsList 
      schoolDistrictSearchDetailsListSL = 
        maintainSchoolDistrictObj.search(schoolDistrictSearchKeySL);
    SchoolDistrictSearchDetailsList.assign(schoolDistrictSearchDetailsListSL);
    return SchoolDistrictSearchDetailsList;
  }
}
