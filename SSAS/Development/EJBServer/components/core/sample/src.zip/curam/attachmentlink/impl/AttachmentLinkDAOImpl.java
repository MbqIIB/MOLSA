/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008,2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attachmentlink.impl;

import java.util.List;

import com.google.inject.Singleton;

import curam.attachmentlink.struct.AttachmentLinkDtls;
import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.util.persistence.StandardDAOImpl;

/**
 * Data access implementation for
 * {@linkplain curam.attachmentlink.impl.AttachmentLink}.
 * 
 * For public method JavaDoc
 * 
 * @see curam.attachmentlink.impl.AttachmentLinkDAO
 */
@Singleton
// BEGIN, CR00183334, PS
public class AttachmentLinkDAOImpl extends
    StandardDAOImpl<AttachmentLink, AttachmentLinkDtls> implements
    AttachmentLinkDAO {
  // END, CR00183334

  // ___________________________________________________________________________
  /**
   * Instance of the AttachmentLink entity adapter.
   */
  protected static final AttachmentLinkAdapter adapter = new AttachmentLinkAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected AttachmentLinkDAOImpl() {
    // END, CR00183334
    super(adapter, AttachmentLink.class);
  }

  // ___________________________________________________________________________
  public List<AttachmentLink> searchByRelatedIDAndType(
      final long relatedObjectID,
      final ATTACHMENTOBJECTLINKTYPEEntry relatedObjectType) {
    return newList(adapter.searchByRelatedIDAndType(relatedObjectID,
        relatedObjectType.getCode()));
  }

  // ___________________________________________________________________________
  public List<AttachmentLink> searchByRelatedIDTypeAndStatus(
      final long relatedObjectID,
      final ATTACHMENTOBJECTLINKTYPEEntry relatedObjectType,
      final RECORDSTATUSEntry recordStatus) {
    return newList(adapter.searchByRelatedIDTypeAndStatus(relatedObjectID,
        relatedObjectType.getCode(), recordStatus.getCode()));
  }
}
