/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2009, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.google.inject.Inject;

import curam.caseaudit.entity.struct.AuditPlanKey;
import curam.caseaudit.entity.struct.AuditTeamDtls;
import curam.caseaudit.entity.struct.AuditTeamKey;
import curam.caseaudit.entity.struct.AuditorKey;
import curam.caseaudit.fact.CaseAuditSecurityManagementFactory;
import curam.caseaudit.impl.AuditPlan;
import curam.caseaudit.impl.AuditPlanDAO;
import curam.caseaudit.impl.AuditTeam;
import curam.caseaudit.impl.AuditTeamDAO;
import curam.caseaudit.impl.AuditTeamMember;
import curam.caseaudit.impl.AuditTeamMemberDAO;
import curam.caseaudit.impl.AuditorDAO;
import curam.caseaudit.impl.CaseAuditConst;
import curam.caseaudit.struct.CaseAuditSecurityKey;
import curam.core.facade.fact.OrganizationFactory;
import curam.core.facade.intf.Organization;
import curam.core.facade.struct.AuditTeamDetails;
import curam.core.facade.struct.AuditTeamDetailsList;
import curam.core.facade.struct.AuditTeamDtlsList;
import curam.core.facade.struct.AuditUserSearchDetails;
import curam.core.facade.struct.AuditorDetails;
import curam.core.facade.struct.AuditorDetailsList;
import curam.core.facade.struct.AuditorFilter;
import curam.core.facade.struct.AuditorHomePageName;
import curam.core.facade.struct.AuditorRemovalDetails;
import curam.core.facade.struct.CreateAuditTeamDetails;
import curam.core.facade.struct.CreateAuditorsDetails;
import curam.core.facade.struct.ModifyAuditTeamDetails;
import curam.core.facade.struct.NewOrExistingTeamDetails;
import curam.core.facade.struct.ReadUserDetails_fo;
import curam.core.facade.struct.ReadUserKey;
import curam.core.facade.struct.RemoveAuditorDetails;
import curam.core.facade.struct.SearchOrCreateAuditorsDetails;
import curam.core.facade.struct.UserSearchDetails;
import curam.core.facade.struct.UserSearchKey;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.UserSearchDetailsRef;
import curam.core.struct.UsersKey;
import curam.message.FACADECASEAUDIT;
import curam.message.GENERALSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringHelper;
import curam.util.type.StringList;


/**
 * Facade Class for the Auditor implementation.
 *
 */
public abstract class Auditor extends curam.core.facade.base.Auditor {

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected AuditorDAO auditorDAO;

  @Inject
  protected AuditTeamDAO auditTeamDAO;

  @Inject
  protected AuditTeamMemberDAO auditTeamMemberDAO;

  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public Auditor() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * UserSearchDetailsRef Comparator.
   */
  protected class UserSearchDetailsRefComparator implements
    Comparator<UserSearchDetailsRef> {

    public UserSearchDetailsRefComparator() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sort based on the user's surname and first name.
     */
    public int compare(final UserSearchDetailsRef o1,
      final UserSearchDetailsRef o2) {

      int surNameComparison = o1.surname.compareTo(o2.surname);
      int firstNameComparison = o1.firstname.compareTo(o2.firstname);

      if (surNameComparison == 0) {
        return firstNameComparison;
      }
      return surNameComparison;
    }
  }

  // ___________________________________________________________________________
  /**
   * Creates an audit team for an audit plan. Verifies that user has selected at
   * least one auditor for the new audit plan. Creates audit team member records
   * for each of the auditors on the new audit team.
   *
   * @param details Contains the audit team creation details.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link FACADECASEAUDIT#ERR_CASE_AUDIT_FV_AUDIT_TEAM_NO_MEMBERS} -
   * If the audit team being created contains no auditors</li>
   * <li>
   * </ul>
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void createAuditTeam(final CreateAuditTeamDetails details)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // An audit team must consist of at least one auditor
    if (StringHelper.isEmpty(details.selectedAuditors)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          FACADECASEAUDIT.ERR_CASE_AUDIT_FV_AUDIT_TEAM_NO_MEMBERS),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      informationalManager.failOperation();
    }

    AuditPlan auditPlanObj = auditPlanDAO.get(details.auditPlanID);

    // create the audit team record - this will also
    // insert an auditor record for the team on the audit plan
    AuditTeam auditTeamObj = auditTeamDAO.newInstance();

    auditTeamObj.setName(details.name);
    auditTeamObj.insert(auditPlanObj);

    // create the audit team member records
    AuditTeamMember auditTeamMemberObj;
    long auditorID;
    curam.caseaudit.impl.Auditor auditorObj;
    StringList auditorIDList = StringUtil.tabText2StringList(
      details.selectedAuditors);

    final int auditorIDListSize = auditorIDList.size();

    for (int i = 0; i < auditorIDListSize; i++) {

      auditorID = Long.parseLong(auditorIDList.item(i));
      auditorObj = auditorDAO.get(auditorID);

      auditTeamMemberObj = auditTeamMemberDAO.newInstance();
      auditTeamMemberObj.setAuditor(auditorObj);
      auditTeamMemberObj.setAuditTeam(auditTeamObj);
      auditTeamMemberObj.insert();
    }
  }

  // ___________________________________________________________________________
  /**
   * Modifies an audit team for an audit plan.
   *
   * @param details Contains the audit team details.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link FACADECASEAUDIT#ERR_CASE_AUDIT_FV_AUDIT_TEAM_NO_MEMBERS} -
   * If the audit team being modified contains no auditors</li>
   * <li>
   * </ul>
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void modifyAuditTeam(final ModifyAuditTeamDetails details)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // An audit team must consist of at least one auditor
    if (StringHelper.isEmpty(details.newAuditorList)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          FACADECASEAUDIT.ERR_CASE_AUDIT_FV_AUDIT_TEAM_NO_MEMBERS),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      informationalManager.failOperation();
    }

    // get the auditor record
    curam.caseaudit.impl.Auditor auditorAuditTeamObj = auditorDAO.get(
      details.auditorID);

    // get the audit team record
    AuditTeam auditTeamObj = auditorAuditTeamObj.getAuditTeam();

    // Audit team can not have the same name as an existing team.
    if (auditorAuditTeamObj.isTeam()) {

      AuditPlan auditPlan = auditorAuditTeamObj.getAuditPlan();
      AuditPlanKey key = new AuditPlanKey();

      key.auditPlanID = auditPlan.getID();

      AuditTeamDtlsList auditTeamList = getAuditTeamsOnPlan(key);

      for (int i = 0; i < auditTeamList.dtlsList.size(); i++) {

        if (auditTeamList.dtlsList.item(i).name.equals(details.teamName)) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            new AppException(
              FACADECASEAUDIT.ERR_CASE_AUDIT_FV_AUDIT_TEAM_CANNOT_HAVE_THE_SAME_NAME),
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
          informationalManager.failOperation();

        }
      }
    }
    auditTeamObj.setName(details.teamName);

    // get the modified list of auditors who should be members after the modify
    StringList newAuditorList = StringUtil.tabText2StringList(
      details.newAuditorList);

    // create empty auditor list
    List<curam.caseaudit.impl.Auditor> auditorList = new ArrayList<curam.caseaudit.impl.Auditor>();

    final int newAuditorListSize = newAuditorList.size();

    // create list of auditor records
    for (int i = 0; i < newAuditorListSize; i++) {
      long newAuditorID = Long.parseLong(newAuditorList.item(i));

      curam.caseaudit.impl.Auditor auditorObj = auditorDAO.get(newAuditorID);

      auditorList.add(auditorObj);
    }

    auditTeamObj.setMembers(auditorList);
    auditTeamObj.modify(details.teamVersionNo);
  }

  // ___________________________________________________________________________
  /**
   * Removes an auditor or audit team from an audit plan.
   *
   * @param details The audit plan identifier and a list of user names.
   * @throws InformationalException
   * @throws AppException
   */
  public void removeAuditorFromPlan(final RemoveAuditorDetails details)
    throws InformationalException, AppException {

    curam.core.facade.intf.CaseAudit caseAuditObj = curam.core.facade.fact.CaseAuditFactory.newInstance();

    // Get the auditor
    curam.caseaudit.impl.Auditor auditorObj = auditorDAO.get(details.auditorID);

    caseAuditObj.unassignCaseAudits(details);

    if (auditorObj.isTeam()) {

      // remove all the associated member records
      List<AuditTeamMember> memberList = auditorObj.getAuditTeam().getMembers();

      for (AuditTeamMember member : memberList) {
        member.remove();
      }

      // remove the audit team record
      AuditTeam auditTeamObj = auditorObj.getAuditTeam();

      auditTeamObj.remove(details.teamVersionNo);

    } else {

      // the auditor represents an individual user
      // remove the auditor from any teams that they are members on
      List<AuditTeamMember> memberList = auditTeamMemberDAO.searchByAuditor(
        auditorObj);

      for (AuditTeamMember member : memberList) {

        // get the audit team details
        AuditTeam checkAuditTeam = member.getAuditTeam();
        int versionNo = checkAuditTeam.getVersionNo();

        // get auditor details associated with the audit team
        curam.caseaudit.impl.Auditor auditTeamAuditorObj = auditorDAO.readByAuditTeam(
          checkAuditTeam);
        int auditorVersionNo = auditTeamAuditorObj.getVersionNo();

        // remove the audit team member record
        member.remove();

        // if auditor was last member on the team then also
        // remove the audit team and associated auditor records
        List<AuditTeamMember> checkMemberList = checkAuditTeam.getMembers();

        if (checkMemberList.size() < 1) {

          // un-assign any remaining case audits assigned to the team
          RemoveAuditorDetails removeAuditorDetails = new RemoveAuditorDetails();

          removeAuditorDetails.auditorID = auditTeamAuditorObj.getID();
          removeAuditorDetails.auditorVersionNo = auditTeamAuditorObj.getVersionNo();
          removeAuditorDetails.auditPlanID = details.auditPlanID;
          removeAuditorDetails.auditTeamID = checkAuditTeam.getID();

          caseAuditObj.unassignCaseAudits(removeAuditorDetails);

          checkAuditTeam.remove(versionNo);
          auditTeamAuditorObj.remove(auditorVersionNo);
        }
      }
    }

    // remove the auditor from the plan
    auditorObj.remove(details.auditorVersionNo);
  }

  // ___________________________________________________________________________
  /**
   * Adds a list of users to an audit plan as auditors. Returns a list of the
   * auditors that have been added to the Audit plan, users that where already
   * auditors on the audit plan are filtered out of the return list.
   *
   * @param details The audit plan identifier and a list of user names.
   *
   * @return the list of auditors that where added to the plan
   *
   * @throws InformationalException
   * @throws AppException
   */
  public AuditorDetailsList createAuditors(final CreateAuditorsDetails details)
    throws InformationalException, AppException {

    validateSelectCriteria(details);

    AuditorDetailsList returnAuditorList = new AuditorDetailsList();

    StringList userNames = StringUtil.tabText2StringList(details.selectedUsers);
    final int numUserNames = userNames.size();

    curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      details.auditPlanID);
    curam.caseaudit.impl.Auditor auditorObj;

    // filter existing auditors out of the return list
    List<curam.caseaudit.impl.Auditor> auditorList = auditorDAO.searchByAuditPlan(
      auditPlanObj);

    for (int i = 0; i < numUserNames; i++) {

      boolean alreadyOnPlan = false;
      String newUserName = userNames.get(i).toString();

      for (curam.caseaudit.impl.Auditor existingAuditor : auditorList) {
        if (newUserName.equals(existingAuditor.getAuditorName())) {
          alreadyOnPlan = true;
          break;
        }
      }

      if (!alreadyOnPlan) {

        AuditorDetails auditorDetails = new AuditorDetails();

        auditorObj = auditorDAO.newInstance();
        auditorObj.setAuditPlan(auditPlanObj);
        auditorObj.setAuditorName(newUserName);
        auditorObj.insert();

        // Set the auditor user return details
        auditorDetails.auditorID = auditorObj.getID();
        auditorDetails.username = newUserName;
        returnAuditorList.dtls.addRef(auditorDetails);
      }
    }

    return returnAuditorList;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of auditors associated with an audit plan.
   *
   * @param key The audit plan identifier.
   * @return The list of auditors.
   * @throws InformationalException
   * @throws AppException
   */
  public AuditorDetailsList getAuditorsOnPlan(final AuditPlanKey key)
    throws AppException, InformationalException {

    curam.caseaudit.impl.AuditPlan auditPlanObj = auditPlanDAO.get(
      key.auditPlanID);

    List<curam.caseaudit.impl.Auditor> auditorList = auditorDAO.searchByAuditPlan(
      auditPlanObj);

    AuditorDetailsList auditorDetailsList = new AuditorDetailsList();
    AuditorDetails auditorDetails;
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    for (curam.caseaudit.impl.Auditor auditor : auditorList) {
      // only get auditors with user names as the others represent teams
      if (auditor.isUser()) {
        auditorDetails = new AuditorDetails();
        auditorDetails.auditorID = auditor.getID();
        auditorDetails.username = auditor.getAuditorName();
        usersKey.userName = auditorDetails.username;

        auditorDetails.name = userAccessObj.getFullName(usersKey).fullname;

        auditorDetailsList.dtls.addRef(auditorDetails);
      }
    }
    return auditorDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Displays a list which includes the current user and any Audit Teams they
   * are a member of.
   *
   * @return the list of auditors and audit teams
   * @throws InformationalException
   * @throws AppException
   */
  public AuditorFilter listAuditorAndTeams()
    throws AppException, InformationalException {

    AuditorFilter auditorFilter = new AuditorFilter();
    StringBuffer defaultSelection = new StringBuffer();
    AuditorDetailsList auditorDetailsList = new AuditorDetailsList();
    UserAccess userAccessObj = UserAccessFactory.newInstance();

    String userName = userAccessObj.getUserDetails().userName;

    // Find an auditor record for the current user
    List<curam.caseaudit.impl.Auditor> auditorList = auditorDAO.searchByUserName(
      userName);

    if (auditorList.size() > 0) {

      for (curam.caseaudit.impl.Auditor auditor : auditorList) {

        AuditorDetails auditorDtls = new AuditorDetails();

        auditorDtls.auditorID = auditor.getID();
        // BEGIN, CR00329210, ZV
        auditorDtls.name = new LocalisableString(GENERALSEARCH.INF_SEARCH_CURRENT_USER).getMessage(
          TransactionInfo.getProgramLocale());
        // END, CR00329210
        auditorDtls.username = userName;
        auditorDetailsList.dtls.addRef(auditorDtls);
        defaultSelection.append(String.valueOf(auditorDtls.auditorID));
        defaultSelection.append(CuramConst.gkTabDelimiterChar);
        break;
      }
    } else {
      AuditorDetails auditorDtls = new AuditorDetails();

      auditorDtls.auditorID = 0;
      // BEGIN, CR00329210, ZV
      auditorDtls.name = new LocalisableString(GENERALSEARCH.INF_SEARCH_CURRENT_USER).getMessage(
        TransactionInfo.getProgramLocale());
      // END, CR00329210
      auditorDtls.username = userName;
      auditorDetailsList.dtls.addRef(auditorDtls);
      defaultSelection.append(String.valueOf(auditorDtls.auditorID));
      defaultSelection.append(CuramConst.gkTabDelimiterChar);
    }

    // For each auditor record which corresponds to the user
    // retrieve any teams the auditor is a member of
    for (curam.caseaudit.impl.Auditor auditor : auditorList) {

      List<AuditTeamMember> memberTeamList = auditTeamMemberDAO.searchByAuditor(
        auditor);

      for (AuditTeamMember member : memberTeamList) {

        AuditTeam auditTeamObj = auditTeamDAO.get(member.getAuditTeam().getID());

        curam.caseaudit.impl.Auditor auditTeamAuditorObj = auditorDAO.readByAuditTeam(
          auditTeamObj);

        AuditorDetails auditorTeamDtls = new AuditorDetails();

        auditorTeamDtls.name = auditTeamObj.getName();
        auditorTeamDtls.auditorID = auditTeamAuditorObj.getID();

        auditorDetailsList.dtls.addRef(auditorTeamDtls);
        defaultSelection.append(String.valueOf(auditorTeamDtls.auditorID));
        defaultSelection.append(CuramConst.gkTabDelimiterChar);
      }
    }

    auditorFilter.auditorDtlsList = auditorDetailsList;

    if (defaultSelection.length() > 0) {
      auditorFilter.defaultSelection = defaultSelection.substring(0,
        defaultSelection.length() - 1);
    }

    return auditorFilter;
  }

  // ___________________________________________________________________________
  /**
   * Returns auditor details for display on a confirmation screen.
   *
   * @param key The ID of the auditor
   *
   * @return Details of the auditor for display
   * @throws InformationalException
   * @throws AppException
   */
  public AuditorRemovalDetails readAuditorForRemoval(final AuditorKey key)
    throws AppException, InformationalException {

    AuditorRemovalDetails auditorRemovalDetails = new AuditorRemovalDetails();

    curam.caseaudit.impl.Auditor auditorObj = auditorDAO.get(key.auditorID);

    auditorRemovalDetails.auditorID = auditorObj.getID();
    auditorRemovalDetails.auditorVersionNo = auditorObj.getVersionNo();
    auditorRemovalDetails.name = auditorObj.getName();
    auditorRemovalDetails.type = auditorObj.getAuditorType().toUserLocaleString();

    LocalisableString confirmMessage = new LocalisableString(
      FACADECASEAUDIT.INF_CONFIRM_REMOVE_AUDITOR);

    confirmMessage.arg(auditorRemovalDetails.type);

    auditorRemovalDetails.confirmMessage = confirmMessage.getMessage(
      TransactionInfo.getProgramLocale());

    if (auditorObj.isTeam()) {
      auditorRemovalDetails.auditTeamID = auditorObj.getAuditTeam().getID();
      auditorRemovalDetails.teamVersionNo = auditorObj.getAuditTeam().getVersionNo();
    }

    return auditorRemovalDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns audit team details for display.
   *
   * @param key The ID of the auditor that represents the audit team
   *
   * @return Details of the audit team for display
   * @throws InformationalException
   * @throws AppException
   */
  public AuditTeamDetails readAuditTeam(final AuditorKey key)
    throws AppException, InformationalException {

    AuditTeamDetails auditTeamDetails = new AuditTeamDetails();

    AuditTeam auditTeam = auditorDAO.get(key.auditorID).getAuditTeam();

    auditTeamDetails.teamVersionNo = auditTeam.getVersionNo();
    auditTeamDetails.teamName = auditTeam.getName();

    List<AuditTeamMember> teamMembers = auditTeam.getMembers();

    // the initial values for the multi select on the modify
    StringBuffer auditorList = new StringBuffer();
    // allows the modify to remove members and their associated auditors
    StringBuffer auditorAndMemberList = new StringBuffer();

    for (AuditTeamMember member : teamMembers) {

      AuditorDetails auditorDetails = new AuditorDetails();

      auditorDetails.auditorID = member.getAuditor().getID();
      auditorDetails.username = member.getAuditor().getAuditorName();
      auditorDetails.name = member.getAuditor().getName();

      auditTeamDetails.memberList.addRef(auditorDetails);

      auditorList.append(auditorDetails.auditorID);
      auditorList.append(CuramConst.gkTabDelimiter);

      auditorAndMemberList.append(auditorDetails.auditorID);
      auditorAndMemberList.append(CuramConst.gkPipeDelimiter);
      auditorAndMemberList.append(member.getID());
      auditorAndMemberList.append(CuramConst.gkTabDelimiter);
    }

    // trim the trailing tab character
    auditorAndMemberList.trimToSize();

    auditorList.trimToSize();
    if (auditorList.length() > 2) {
      auditTeamDetails.auditorList = auditorList.substring(0,
        auditorList.length() - 1);
    }

    return auditTeamDetails;
  }

  // ___________________________________________________________________________
  /**
   * Resolves the auditor home page.
   *
   * @param key The ID of the auditor
   *
   * @return Details of the auditor home page
   * @throws InformationalException
   * @throws AppException
   */
  public AuditorHomePageName resolveAuditorHomePage(final AuditorKey key)
    throws AppException, InformationalException {

    AuditorHomePageName auditorHomePageName = new AuditorHomePageName();

    curam.caseaudit.impl.Auditor auditor = auditorDAO.get(key.auditorID);

    if (auditor.isTeam()) {
      auditorHomePageName.pageName = UimConst.kAuditTeamHomePage
        + "?auditorID=" + auditor.getID();
    } else {
      auditorHomePageName.pageName = UimConst.kUserHomePage + "?userName="
        + auditor.getAuditorName();
    }
    return auditorHomePageName;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Returns a list of audit teams associated with an audit plan.
   *
   * @param key The audit plan identifier.
   * @return The list of audit teams.
   * @throws InformationalException
   * @throws AppException
   *
   * @deprecated Since Curam 6.0 SP2, replaced with 
   * {@link Auditor#getAuditTeamsOnPlanList(AuditPlanKey)}.
   *
   * This method is deprecated as informational messages are not returned. This 
   * method is replaced by getAuditTeamsOnPlanList(AuditPlanKey) which returns 
   * the informational message along with person details as well. 
   * See release note: CS-09152/CR00290965.
   */
  public AuditTeamDtlsList getAuditTeamsOnPlan(final AuditPlanKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    AuditPlan auditPlanObj = auditPlanDAO.get(key.auditPlanID);

    List<AuditTeam> auditTeamList = auditTeamDAO.searchByAuditPlan(auditPlanObj);

    AuditTeamDtlsList auditTeamDtlsList = new AuditTeamDtlsList();

    for (AuditTeam team : auditTeamList) {

      AuditTeamDtls auditTeamDtls = new AuditTeamDtls();

      auditTeamDtls.name = team.getName();
      auditTeamDtls.auditTeamID = team.getID();
      auditTeamDtls.versionNo = team.getVersionNo();

      auditTeamDtlsList.dtlsList.addRef(auditTeamDtls);
    }
    return auditTeamDtlsList;
  }

  // BEGIN, CR00266672, GD
  // ___________________________________________________________________________
  /**
   * Delegates between searching for potential auditors and adding new auditors.
   *
   * @param details The user search criteria and the add auditor details.
   *
   * @return A list of user records.
   * @throws InformationalException
   * @throws AppException
   *
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #searchExistingAuditorsOrCreateNewAuditor()}. New method delegates
   * to new search method {@link #searchAvailableAuditors()} as the old search
   * method {@link #potentialAuditorSearch()} is now deprecated. See release
   * note <CR00266672>.
   */
  @Deprecated
  // END, CR00266672
  public AuditUserSearchDetails searchOrCreateAuditors(
    final SearchOrCreateAuditorsDetails details)
    throws AppException, InformationalException {

    AuditUserSearchDetails userSearchDetails = new AuditUserSearchDetails();

    if (details.actionIDProperty.equals(ClientActionConst.kSelectActionID)) {
      createAuditors(details.createAuditorDetails);
    } else if (details.actionIDProperty.equals(
      ClientActionConst.kSearchActionID)) {
      AuditPlanKey auditPlanKey = new AuditPlanKey();

      auditPlanKey.auditPlanID = details.createAuditorDetails.auditPlanID;
      userSearchDetails.userList = potentialAuditorSearch(details.userSearchKey,
        auditPlanKey);
    } else if (details.actionIDProperty.equals(ClientActionConst.kSelectAndAdd)) {
      validateSelectCriteria(details.createAuditorDetails);
    }

    return userSearchDetails;
  }

  // BEGIN, CR00266672, GD
  // ___________________________________________________________________________
  /**
   * Delegates between searching for existing auditors or creating a new
   * auditor.
   *
   * @param details The user search criteria and the add auditor details.
   *
   * @return A list of user records.
   * @throws InformationalException
   * @throws AppException
   */
  public AuditUserSearchDetails searchExistingAuditorsOrCreateNewAuditor(
    final SearchOrCreateAuditorsDetails details)
    throws AppException, InformationalException {

    AuditUserSearchDetails userSearchDetails = new AuditUserSearchDetails();

    if (details.actionIDProperty.equals(ClientActionConst.kSelectActionID)) {
      createAuditors(details.createAuditorDetails);
    } else if (details.actionIDProperty.equals(
      ClientActionConst.kSearchActionID)) {
      AuditPlanKey auditPlanKey = new AuditPlanKey();

      auditPlanKey.auditPlanID = details.createAuditorDetails.auditPlanID;
      userSearchDetails.userList = searchAvailableAuditors(
        details.userSearchKey, auditPlanKey);
    } else if (details.actionIDProperty.equals(ClientActionConst.kSelectAndAdd)) {
      validateSelectCriteria(details.createAuditorDetails);
    }

    return userSearchDetails;
  }

  // END, CR00266672

  // BEGIN, CR00266672, GD
  // ___________________________________________________________________________
  /**
   * Wraps the user search in a filter for auditor and audit coordinator roles.
   *
   * @param key The user search criteria.
   * @param auditPlanKey The audit plan id
   *
   * @return A list of user records.
   * @throws InformationalException
   * @throws AppException
   *
   * @deprecated Since Curam 6.0 SP1, replaced by
   * {@link #searchAvailableAuditors()}. New method filters out auditors / audit
   * coordinators that don't have the the security access to the case audit
   * type. See release note <CR00266672>.
   */
  @Deprecated
  // END, CR00266672
  protected UserSearchDetails potentialAuditorSearch(
    final UserSearchKey key, final AuditPlanKey auditPlanKey)
    throws AppException, InformationalException {

    Organization organizationObj = OrganizationFactory.newInstance();

    // create an ordered set
    Set<UserSearchDetailsRef> potentialAuditorUserList = new TreeSet<UserSearchDetailsRef>(
      new UserSearchDetailsRefComparator());

    // add all the coordinators to the list
    key.userSearchCriteria.criteria.roleName = CaseAuditConst.kCoordinatorUserRoleName;
    UserSearchDetails coordinators = organizationObj.userSearch(key);

    potentialAuditorUserList.addAll(
      coordinators.userSearchResultsList.userSearchDetailsRefList.dtls);

    // add all the auditors to the list
    key.userSearchCriteria.criteria.roleName = CaseAuditConst.kAuditorUserRoleName;
    UserSearchDetails auditors = organizationObj.userSearch(key);

    potentialAuditorUserList.addAll(
      auditors.userSearchResultsList.userSearchDetailsRefList.dtls);

    //
    // filter existing auditors out of the return list
    //

    AuditPlan auditPlanObj = auditPlanDAO.get(auditPlanKey.auditPlanID);
    List<curam.caseaudit.impl.Auditor> auditorList = auditorDAO.searchByAuditPlan(
      auditPlanObj);
    UserSearchDetails result = new UserSearchDetails();

    boolean addToList;

    for (UserSearchDetailsRef userSearchDetailsRef : potentialAuditorUserList) {
      addToList = true;
      for (curam.caseaudit.impl.Auditor auditor : auditorList) {
        if (auditor.getAuditorName().equals(userSearchDetailsRef.username)) {
          addToList = false;
          // BEGIN, CR00202947, GD
          break;
          // END, CR00202947
        }
      }
      if (addToList) {
        result.userSearchResultsList.userSearchDetailsRefList.dtls.addRef(
          userSearchDetailsRef);
      }
    }

    return result;
  }

  // BEGIN, CR00266672, GD
  // ___________________________________________________________________________
  /**
   * Performs a user search for all auditors and audit coordinators that match
   * the specified criteria and that are not currently auditors on the audit
   * plan. Only users that have the security access to the case audit type are
   * returned.
   *
   * @param key The user search criteria.
   * @param auditPlanKey The audit plan id
   *
   * @return A list of user records.
   * @throws InformationalException
   * @throws AppException
   */
  protected UserSearchDetails searchAvailableAuditors(
    final UserSearchKey key, final AuditPlanKey auditPlanKey)
    throws AppException, InformationalException {

    Organization organizationObj = OrganizationFactory.newInstance();

    // create an ordered set
    Set<UserSearchDetailsRef> potentialAuditorUserList = new TreeSet<UserSearchDetailsRef>(
      new UserSearchDetailsRefComparator());

    UserSearchDetails result = new UserSearchDetails();

    // Create security object to verify auditor has access to audit plan
    curam.caseaudit.intf.CaseAuditSecurityManagement securityObj = CaseAuditSecurityManagementFactory.newInstance();

    CaseAuditSecurityKey caseAuditSecurityKey = new CaseAuditSecurityKey();

    // BEGIN, CR00385977, KRK
    // Check the security roles are restricted for assignments.
    final boolean isUserRoleRestricted = Configuration.getBooleanProperty(
      EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES_DEFAULT));   
    
    if (isUserRoleRestricted) {
      // Add all the coordinators to the list.
      key.userSearchCriteria.criteria.roleName = CaseAuditConst.kCoordinatorUserRoleName;
      final UserSearchDetails coordinators = organizationObj.userSearch(key);

      potentialAuditorUserList.addAll(
        coordinators.userSearchResultsList.userSearchDetailsRefList.dtls);

      // Add all the auditors to the list.
      key.userSearchCriteria.criteria.roleName = CaseAuditConst.kAuditorUserRoleName;
      final UserSearchDetails auditors = organizationObj.userSearch(key);

      potentialAuditorUserList.addAll(
        auditors.userSearchResultsList.userSearchDetailsRefList.dtls);
    } else {   
      final UserSearchDetails userSearchDetails = organizationObj.userSearch(
        key);

      potentialAuditorUserList.addAll(
        userSearchDetails.userSearchResultsList.userSearchDetailsRefList.dtls); 
    }
    // END, CR00385977 

    //
    // filter users that are already auditors on the audit plan out of the list
    //
    AuditPlan auditPlanObj = auditPlanDAO.get(auditPlanKey.auditPlanID);
    List<curam.caseaudit.impl.Auditor> auditorList = auditorDAO.searchByAuditPlan(
      auditPlanObj);

    boolean addToList;

    for (UserSearchDetailsRef userSearchDetailsRef : potentialAuditorUserList) {
      addToList = false;

      // verify this user has access to the audit plan
      caseAuditSecurityKey.auditPlanID = auditPlanKey.auditPlanID;
      caseAuditSecurityKey.userName = userSearchDetailsRef.username;
      try {
        securityObj.checkCaseAuditSecurity(caseAuditSecurityKey);
        addToList = true;

        for (curam.caseaudit.impl.Auditor auditor : auditorList) {
          if (auditor.getAuditorName().equals(userSearchDetailsRef.username)) {
            addToList = false;
            break;
          }
        }

        if (addToList) {
          result.userSearchResultsList.userSearchDetailsRefList.dtls.addRef(
            userSearchDetailsRef);
        }
      } catch (AppException e) {// invalid security don't add auditor to list
      } catch (InformationalException e) {// invalid security don't add auditor to list
      }
    }

    return result;
  }

  // END, CR00266672

  // ___________________________________________________________________________
  /**
   * Returns a parsed list of previously selected auditor users so that they can
   * be added to an audit team for a specified audit plan.
   *
   * @param details The audit plan identifier and a string selected users.
   * @return The list of user details.
   * @throws InformationalException
   * @throws AppException
   */
  public UserSearchDetails listSelectedAuditors(
    final CreateAuditorsDetails details)
    throws AppException, InformationalException {

    Organization organizationObj = OrganizationFactory.newInstance();
    UserSearchDetails auditorUserDetails = new UserSearchDetails();

    StringList userNames = StringUtil.tabText2StringList(details.selectedUsers);
    final int numUserNames = userNames.size();

    ReadUserKey key = new ReadUserKey();
    ReadUserDetails_fo userDetails = new ReadUserDetails_fo();

    for (int i = 0; i < numUserNames; i++) {

      UserSearchDetailsRef user = new UserSearchDetailsRef();

      key.userKeyStruct.userName = userNames.get(i).toString();
      userDetails = organizationObj.readUser(key);

      user.username = userDetails.userDetails.userName;
      user.fullName = userDetails.userDetails.fullName;

      auditorUserDetails.userSearchResultsList.userSearchDetailsRefList.dtls.addRef(
        user);
    }

    return auditorUserDetails;
  }

  // ___________________________________________________________________________
  /**
   * Creates a new audit team for the selected users or else adds the selected
   * users to an existing audit team depending on whether the user has selected
   * an existing audit plan.
   *
   * @param details The string list of selected users, the audit plan identifier
   * and new or existing audit team details.
   * @throws InformationalException
   * @throws AppException
   */
  public void addToNewOrExistingAuditTeam(
    final NewOrExistingTeamDetails details)
    throws AppException, InformationalException {

    validateSelectedTeam(details);

    // Create auditor records for the selected users
    CreateAuditorsDetails createAuditorsDetails = new CreateAuditorsDetails();

    createAuditorsDetails.selectedUsers = details.createDtls.selectedAuditors;
    createAuditorsDetails.auditPlanID = details.createDtls.auditPlanID;
    AuditorDetailsList auditorList = createAuditors(createAuditorsDetails);

    // Build a string of these auditor IDs
    StringBuffer sbuf = new StringBuffer();
    final int auditorListSize = auditorList.dtls.size();

    for (int i = 0; i < auditorListSize; i++) {
      sbuf.append(auditorList.dtls.item(i).auditorID);
      sbuf.append(CuramConst.gkTabDelimiterChar);
    }

    details.createDtls.selectedAuditors = sbuf.substring(0, sbuf.length() - 1);

    // if an existing team has not been selected
    if (details.auditTeamID == 0) {

      // then new team will be created
      createAuditTeam(details.createDtls);

    } else {

      // add to existing team
      ModifyAuditTeamDetails modifyTeamDetails = new ModifyAuditTeamDetails();

      // read the team details
      AuditTeam auditTeamObj = auditTeamDAO.get(details.auditTeamID);

      // TODO need to return this from the client
      details.versionNo = auditTeamObj.getVersionNo();

      // get the audit plan details
      AuditPlan auditPlanObj = auditPlanDAO.get(details.createDtls.auditPlanID);

      AuditTeamKey key = new AuditTeamKey();

      key.auditTeamID = details.auditTeamID;

      List<curam.caseaudit.impl.Auditor> auditors = auditorDAO.searchByAuditPlanAndTeam(
        auditPlanObj, key);

      for (curam.caseaudit.impl.Auditor auditor : auditors) {

        // should only be one record in this list
        modifyTeamDetails.auditorID = auditor.getID();
        break;
      }

      // Get the list of existing auditors on the team
      List<AuditTeamMember> currentMembers = auditTeamObj.getMembers();

      // Build a string of these auditor IDs
      StringBuffer currentMemberBuf = new StringBuffer();
      final int currentMemberListSize = currentMembers.size();

      for (int i = 0; i < currentMemberListSize; i++) {
        currentMemberBuf.append(CuramConst.gkTabDelimiterChar);
        currentMemberBuf.append(currentMembers.get(i).getAuditor().getID());
      }

      details.createDtls.selectedAuditors = details.createDtls.selectedAuditors
        + currentMemberBuf;

      modifyTeamDetails.teamName = auditTeamObj.getName();
      modifyTeamDetails.newAuditorList = details.createDtls.selectedAuditors;
      modifyTeamDetails.teamVersionNo = details.versionNo;

      modifyAuditTeam(modifyTeamDetails);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates that either new or existing audit team details have been
   * entered when a user selects to add users to both an audit plan and audit
   * team as part of the same action.
   *
   * @param details The audit plan, audit team and selected user details
   *
   * @throws InformationalException
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link FACADECASEAUDIT#ERR_CASE_AUDIT_FV_AUDIT_TEAM_BOTH_NEW_AND_EXISTING_TEAM_SELECTED} -
   * If the values for a new and existing audit team are entered together.</li>
   * <li>
   * <li>
   * {@link FACADECASEAUDIT#ERR_CASE_AUDIT_FV_AUDIT_TEAM_NEW_OR_EXISTING_TEAM_MUST_BE_SELECTED} -
   * If no values for either new or existing audit team are entered.</li>
   * <li>
   * </ul>
   */
  protected void validateSelectedTeam(final NewOrExistingTeamDetails details)
    throws InformationalException {
    if ((details.auditTeamID != 0) && (details.createDtls.name.length() > 0)) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          FACADECASEAUDIT.ERR_CASE_AUDIT_FV_AUDIT_TEAM_BOTH_NEW_AND_EXISTING_TEAM_SELECTED),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      informationalManager.failOperation();
    } else if ((details.auditTeamID == 0)
      && (details.createDtls.name.length() == 0)) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          FACADECASEAUDIT.ERR_CASE_AUDIT_FV_AUDIT_TEAM_NEW_OR_EXISTING_TEAM_MUST_BE_SELECTED),
          CuramConst.gkEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      informationalManager.failOperation();
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates that an auditor has been selected for addition to the audit plan.
   *
   * @param details The auditor details
   *
   * @throws InformationalException
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   *
   * {@link FACADECASEAUDIT#ERR_RV_NO_AUDITOR_SELECTED} -
   * If no values are entered.</li>
   */
  protected void validateSelectCriteria(
    final CreateAuditorsDetails details)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (StringHelper.isEmpty(details.selectedUsers)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(FACADECASEAUDIT.ERR_RV_NO_AUDITOR_SELECTED),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      informationalManager.failOperation();
    }
  }
  
  // BEGIN, CR00290965, IBM
  /**
   * Searches the list of audit teams by specified search criteria.
   *
   * @param key contains audit plan identifier.
   *
   * @return list of audit teams.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public AuditTeamDetailsList getAuditTeamsOnPlanList(final AuditPlanKey auditPlanKey)
    throws AppException, InformationalException {
    
    AuditPlan auditPlanObj = auditPlanDAO.get(auditPlanKey.auditPlanID);

    List<AuditTeam> auditTeamList = auditTeamDAO.searchByAuditPlan(auditPlanObj);

    AuditTeamDetailsList auditTeamDetailsList = new AuditTeamDetailsList();

    for (AuditTeam team : auditTeamList) {

      AuditTeamDtls auditTeamDtls = new AuditTeamDtls();

      auditTeamDtls.name = team.getName();
      auditTeamDtls.auditTeamID = team.getID();
      auditTeamDtls.versionNo = team.getVersionNo();

      auditTeamDetailsList.dtlsList.addRef(auditTeamDtls);
    }
    
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    String[] infos = informationalManager.obtainInformationalAsString();

    for (String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      auditTeamDetailsList.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }
    
    return auditTeamDetailsList;
  }
  // END, CR00290965
}
