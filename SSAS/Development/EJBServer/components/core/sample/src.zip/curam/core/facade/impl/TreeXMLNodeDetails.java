/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


/**
 * This class handles the last accessed node for
 * the XML Tree Widget for Rules components.
 *
 */
public class TreeXMLNodeDetails {
      
  /**
   * The ID of the last accessed node. *
   */
  protected long stLastAccessedNodeId = 0L;

  /**
   * Default constructor. 
   */
  public TreeXMLNodeDetails() {// Empty Default Constructor
  }
    
  /**
   * Returns the stLastAccessedNodeId.
   *
   * @return the stLastAccessedNodeId.
   */
  public long getStLastAccessedNodeId() {

    return stLastAccessedNodeId;
  }

  /**
   * Sets the Node last accessed in the Tree XML widget.
   *
   * @param lastAccessedNodeId The stLastAccessedNodeId to set.
   */
  public void setStLastAccessedNodeId(final long lastAccessedNodeId) {

    stLastAccessedNodeId = lastAccessedNodeId;
  }

}

