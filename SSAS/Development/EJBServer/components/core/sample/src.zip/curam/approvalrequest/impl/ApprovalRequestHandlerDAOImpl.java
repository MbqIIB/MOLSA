/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.approvalrequest.impl;


import com.google.inject.Inject;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.message.impl.BPOAPPROVALREQUESTExceptionCreator;
import curam.util.exception.AppRuntimeException;
import java.util.Map;


/**
 * Implementation of the {@link ApprovalRequestHandlerDAO} interface.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
class ApprovalRequestHandlerDAOImpl implements ApprovalRequestHandlerDAO {

  @Inject
  protected Map<APPROVALRELATEDTYPEEntry, ApprovalRequestHandler> concreteApprovalRequestHandlerMap;

  /**
   * {@inheritDoc}
   */
  public ApprovalRequestHandler get(
    final APPROVALRELATEDTYPEEntry approvalRelatedTypeEntry) {

    ApprovalRequestHandler approvalRequestHandler = concreteApprovalRequestHandlerMap.get(
      approvalRelatedTypeEntry);

    if (null == approvalRequestHandler) {
      throw new AppRuntimeException(
        BPOAPPROVALREQUESTExceptionCreator.ERR_FV_UNIMPLEMENTED_APPROVAL_REQUEST_TYPE(
          approvalRelatedTypeEntry.toUserLocaleString()));
    }
    return approvalRequestHandler;
  }

}
