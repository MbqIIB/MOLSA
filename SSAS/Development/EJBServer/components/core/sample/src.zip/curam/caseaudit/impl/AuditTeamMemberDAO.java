/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import java.util.List;

import com.google.inject.ImplementedBy;

import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;

/**
 * Data access for {@linkplain curam.caseaudit.impl.AuditTeamMember}.
 */
@ImplementedBy(AuditTeamMemberDAOImpl.class)
public interface AuditTeamMemberDAO extends StandardDAO<AuditTeamMember> {

  // ___________________________________________________________________________
  /**
   * Retrieves a list of member records for a specified audit team.
   *
   * @param auditTeam
   *          the team to search on.
   *
   * @return all the instances that are associated with the team.
   */
  public List<AuditTeamMember> searchByAuditTeam(final AuditTeam auditTeam);

  // ___________________________________________________________________________
  /**
   * Retrieves a list of member records for a specified auditor.
   *
   * @param auditor
   *          the auditor to search on.
   *
   * @return all the instances that are associated with the auditor.
   */
  public List<AuditTeamMember> searchByAuditor(final Auditor auditor);

  //___________________________________________________________________________
  /**
   * Retrieves a list of member records for a specified user name.
   *
   * @param userName
   *          the user to search on.
   *
   * @return all the instances that are associated with the user.
   */
  public List<AuditTeamMember> searchByUserName(final String userName)
    throws AppException, InformationalException;

}
