/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005, 2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import org.apache.log4j.Logger;

import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.core.struct.CaseRelByCaseIDStatusReasonTypeKey;
import curam.core.struct.CaseRelationshipByCaseAndStatusKey;
import curam.core.struct.CaseRelationshipDtls;
import curam.core.struct.CaseRelationshipDtlsList;
import curam.core.struct.CaseRelationshipKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * @see curam.core.intf.CachedCaseRelationship
 */
public abstract class CachedCaseRelationship extends curam.core.base.CachedCaseRelationship {

  protected static ThreadLocal cachedCaseRelationshipDtlsList = new ThreadLocal();
  protected static ThreadLocal cachedCaseRelationshipDtls = new ThreadLocal();
  // ___________________________________________________________________________

  // BEGIN, CR00023323, CR00051622, SK
  // Logger for the caching output
  public static final String kBatchCachingCategory = Trace.kDefaultTraceCategory
    + ExtensionConst.kBatchCachingCategory;

  public static final Logger kBatchLauncherCacheLogger = Logger.getLogger(
    kBatchCachingCategory);
  // END, CR00023323,CR00051622

  // ___________________________________________________________________________
  /**
   * class to hold the cached CaseRelationshipDtlsList
   */
  protected class CaseRelationshipDtlsListCacheRecord {
    public long caseID = 0;
    // BEGIN, CR00049218, GM
    public String statusCode = CuramConst.gkEmpty;
    // END, CR00049218

    public CaseRelationshipDtlsList caseRelationshipDtlsList = new CaseRelationshipDtlsList();
    public int transactionID = 0;
  }


  // ___________________________________________________________________________
  /**
   * class to hold the cached CaseRelationshipDtlsList
   */
  protected class CaseRelationshipDtlsCacheRecord {
    public int transactionID = 0;
    public CaseRelationshipDtls caseRelationshipDtls = new CaseRelationshipDtls();
  }

  public static final boolean logging;
  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;

  // ___________________________________________________________________________
  // static to hold the logging_enabled environmental Variable
  static {

    cachingEnabled = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);

    String logging_enabled = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED);

    if (logging_enabled == null) {
      logging_enabled = EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED_DEFAULT;
    }
    if (logging_enabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      logging = true;

    } else {
      logging = false;
    }
  }
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseRelationshipDtlsList searchByCaseIDStatusReasonType(CaseRelByCaseIDStatusReasonTypeKey key)
    throws AppException, InformationalException {

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    CaseRelationshipDtlsList caseRelationshipDtlsList;

    // If this is a batch transaction or deferred processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    if ((transactionType.equals(TransactionType.kBatch)
      || transactionType.equals(TransactionType.kDeferred))
        && cachingEnabled) {

      CaseRelationshipDtlsListCacheRecord caseRelationshipDtlsListCacheRecord = (CaseRelationshipDtlsListCacheRecord) cachedCaseRelationshipDtlsList.get();

      // if this is a deferred transaction, we must also check
      // that the transaction numbers match
      if (caseRelationshipDtlsListCacheRecord != null
        && transactionType.equals(TransactionType.kDeferred)
        && TransactionInfo.getIdentifierForThisThread()
          != caseRelationshipDtlsListCacheRecord.transactionID) {

        caseRelationshipDtlsListCacheRecord = null;
      }

      // Try to find the data in the cache
      if (caseRelationshipDtlsListCacheRecord != null
        && caseRelationshipDtlsListCacheRecord.caseID == key.caseID
        && caseRelationshipDtlsListCacheRecord.statusCode.equals(key.statusCode)) {

        caseRelationshipDtlsList = new CaseRelationshipDtlsList();

        caseRelationshipDtlsList.dtls.ensureCapacity(
          caseRelationshipDtlsListCacheRecord.caseRelationshipDtlsList.dtls.size());
        caseRelationshipDtlsList.assign(
          caseRelationshipDtlsListCacheRecord.caseRelationshipDtlsList);

        return getCaseRelationshipDtlsList(caseRelationshipDtlsList, key);
      }

    }
    // otherwise reload the data
    caseRelationshipDtlsList = reloadDtlsListCache(key);

    return getCaseRelationshipDtlsList(caseRelationshipDtlsList, key);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseRelationshipDtls read(CaseRelationshipKey key)
    throws AppException, InformationalException {

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    // If this is a batch transaction or deferred processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    if ((transactionType.equals(TransactionType.kBatch)
      || transactionType.equals(TransactionType.kDeferred))
        && cachingEnabled) {

      CaseRelationshipDtlsCacheRecord caseRelationshipDtlsCacheRecord = (CaseRelationshipDtlsCacheRecord) cachedCaseRelationshipDtls.get();

      if (caseRelationshipDtlsCacheRecord != null) {

        CaseRelationshipDtls caseRelationshipDtls = caseRelationshipDtlsCacheRecord.caseRelationshipDtls;

        // if this is a deferred transaction, we must also check
        // that the transaction numbers match
        if (caseRelationshipDtls != null
          && transactionType.equals(TransactionType.kDeferred)
          && TransactionInfo.getIdentifierForThisThread()
            != caseRelationshipDtlsCacheRecord.transactionID) {

          caseRelationshipDtls = null;
        }

        if (caseRelationshipDtls != null
          && caseRelationshipDtls.caseRelationshipID == key.caseRelationshipID) {

          return caseRelationshipDtls;
        }
      }
    }

    return reloadDtlsCache(key);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseRelationshipDtlsList reloadDtlsListCache(CaseRelByCaseIDStatusReasonTypeKey key) throws AppException, InformationalException {

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    CaseRelationshipDtlsList caseRelationshipDtlsList;

    // CaseRelationshipDtlsList manipulation variables
    curam.core.intf.CaseRelationship caseRelationshipObj = curam.core.fact.CaseRelationshipFactory.newInstance();

    CaseRelationshipByCaseAndStatusKey caseRelationshipByCaseAndStatusKey = new CaseRelationshipByCaseAndStatusKey();

    caseRelationshipByCaseAndStatusKey.caseID = key.caseID;
    caseRelationshipByCaseAndStatusKey.statusCode = key.statusCode;

    caseRelationshipDtlsList = caseRelationshipObj.searchByCaseIDStatus(
      caseRelationshipByCaseAndStatusKey);

    caseRelationshipDtlsList.dtls.trimToSize();

    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((transactionType.equals(TransactionInfo.TransactionType.kBatch)
      || transactionType.equals(TransactionType.kDeferred))
        && cachingEnabled) {

      CaseRelationshipDtlsListCacheRecord caseRelationshipDtlsListCacheRecord = new CaseRelationshipDtlsListCacheRecord();

      // set the cached record
      cachedCaseRelationshipDtlsList.set(caseRelationshipDtlsListCacheRecord);

      caseRelationshipDtlsListCacheRecord.caseID = key.caseID;
      caseRelationshipDtlsListCacheRecord.statusCode = key.statusCode;
      caseRelationshipDtlsListCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();

      caseRelationshipDtlsListCacheRecord.caseRelationshipDtlsList.dtls.ensureCapacity(
        caseRelationshipDtlsList.dtls.size());

      caseRelationshipDtlsListCacheRecord.caseRelationshipDtlsList.assign(
        caseRelationshipDtlsList);

    }

    return caseRelationshipDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseRelationshipDtls reloadDtlsCache(CaseRelationshipKey key) throws AppException, InformationalException {

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    CaseRelationshipDtls caseRelationshipDtls;

    // CaseRelationship manipulation variables
    curam.core.intf.CaseRelationship caseRelationshipObj = curam.core.fact.CaseRelationshipFactory.newInstance();

    caseRelationshipDtls = caseRelationshipObj.read(key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((transactionType.equals(TransactionType.kBatch)
      || transactionType.equals(TransactionType.kDeferred))
        && cachingEnabled) {

      CaseRelationshipDtlsCacheRecord caseRelationshipDtlsCacheRecord = new CaseRelationshipDtlsCacheRecord();

      caseRelationshipDtlsCacheRecord.caseRelationshipDtls = caseRelationshipDtls;
      caseRelationshipDtlsCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();

      cachedCaseRelationshipDtls.set(caseRelationshipDtlsCacheRecord);
    }
    return caseRelationshipDtls;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseRelationshipDtls getDtlsCache() {

    CaseRelationshipDtlsCacheRecord caseRelationshipDtlsCacheRecord = (CaseRelationshipDtlsCacheRecord) cachedCaseRelationshipDtls.get();

    if (caseRelationshipDtlsCacheRecord.caseRelationshipDtls != null) {

      // return a copy of the Dtls struct
      return caseRelationshipDtlsCacheRecord.caseRelationshipDtls;
    }
    return null;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void clearDtlsListCache() throws AppException, InformationalException {

    cachedCaseRelationshipDtlsList.set(null);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void clearDtlsCache() throws AppException, InformationalException {

    cachedCaseRelationshipDtls.set(null);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void clearCache() throws AppException, InformationalException {

    cachedCaseRelationshipDtls.set(null);
    cachedCaseRelationshipDtlsList.set(null);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseRelationshipDtlsList getCaseRelationshipDtlsList(CaseRelationshipDtlsList caseRelationshipDtlsList, CaseRelByCaseIDStatusReasonTypeKey key) {

    CaseRelationshipDtlsList caseRelshipDtlsList = new CaseRelationshipDtlsList();

    // Filter out the records from CaseRelationshipDtlsList
    // that match the passed key values
    for (int i = caseRelationshipDtlsList.dtls.size(); --i >= 0;) {
      if (caseRelationshipDtlsList.dtls.item(i).typeCode.equals(key.typeCode)
        && caseRelationshipDtlsList.dtls.item(i).reasonCode.equals(
          key.reasonCode)) {

        caseRelshipDtlsList.dtls.addRef(caseRelationshipDtlsList.dtls.item(i));
      }
    }

    return caseRelshipDtlsList;

  }

}
