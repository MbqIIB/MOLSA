/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import java.util.SortedSet;

import com.google.inject.Inject;

import curam.caseaudit.entity.struct.AuditPlanCriteriaDtls;
import curam.caseaudit.entity.struct.AuditPlanKey;
import curam.caseaudit.impl.AuditPlan;
import curam.caseaudit.impl.AuditPlanCriteriaDAO;
import curam.caseaudit.impl.AuditPlanDAO;
import curam.codetable.impl.AUDITPLANSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SELECTIONQUERYTYPEEntry;
import curam.core.facade.struct.AuditPlanCriteriaListDetails;
import curam.core.facade.struct.ListSelectionCriteriaPageName;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.selectionquery.impl.SelectionQuery;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * Facade Class for the Audit Plan Criteria implementation.
 *
 */
public abstract class AuditPlanCriteria extends curam.core.facade.base.AuditPlanCriteria {

  @Inject
  protected AuditPlanCriteriaDAO auditPlanCriteriaDAO;
  
  @Inject
  protected AuditPlanDAO auditPlanDAO;
  
  // ___________________________________________________________________________
  /**
   * Add injection for using the new API.
   */
  public AuditPlanCriteria() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * Returns the list of selected criteria for a given audit plan.
   *
   * @param key The audit plan id.
   *
   * @return AuditPlanCriteriaListDetails The list of criteria.
   */
  public AuditPlanCriteriaListDetails listAuditPlanCriteria(
    final AuditPlanKey key) throws AppException, InformationalException {
    
    AuditPlanCriteriaListDetails auditPlanCriteriaListDetails = new AuditPlanCriteriaListDetails();
    
    AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);
    
    SortedSet<curam.caseaudit.impl.AuditPlanCriteria> auditPlanCriteriaSet = auditPlanCriteriaDAO.searchByAuditPlan(
      auditPlan);
    
    for (curam.caseaudit.impl.AuditPlanCriteria auditPlanCriteria : 
      auditPlanCriteriaSet) {
      
      AuditPlanCriteriaDtls auditPlanCriteriaDtls = new AuditPlanCriteriaDtls();

      auditPlanCriteriaDtls.auditPlanCriteriaID = auditPlanCriteria.getID();
      auditPlanCriteriaDtls.auditPlanID = auditPlanCriteria.getAuditPlan().getID();
      auditPlanCriteriaDtls.name = auditPlanCriteria.getName();
      auditPlanCriteriaDtls.value = auditPlanCriteria.getValue();
      auditPlanCriteriaListDetails.dtlsList.addRef(auditPlanCriteriaDtls);
    }
    
    if (auditPlanCriteriaListDetails.dtlsList.size() > 0) {
      
      SelectionQuery selectionQuery = auditPlan.getSelectionQuery();
      
      // Dynamically display the 'Change Criteria' link
      if (selectionQuery.getType().equals(SELECTIONQUERYTYPEEntry.DYNAMIC)
        || selectionQuery.getType().equals(SELECTIONQUERYTYPEEntry.PREDEFINED)) {
                
        if (auditPlan.getLifecycleState().equals(AUDITPLANSTATUSEntry.PENDING) 
          && auditPlan.getRecordStatus().equals(RECORDSTATUSEntry.NORMAL)
          && !auditPlan.areCasesUserSelected()) {
          auditPlanCriteriaListDetails.displayChangeCriteriaLink = true;  
        }
      }
    }    
    return auditPlanCriteriaListDetails;   
  }

  // ___________________________________________________________________________
  /**
   * Returns the name of the list selection criteria page to display.
   * If the cases were randomly selected the criteria used to generate the case
   * list are displayed. If the cases were manually selected, there are no
   * criteria to display. 
   *
   * @param key The audit plan id.
   *
   * @return ListSelectionCriteriaPageName The name of the page to display.
   */
  public ListSelectionCriteriaPageName resolveListSelectionCriteriaPageName(
    final AuditPlanKey key) throws AppException, InformationalException {

    ListSelectionCriteriaPageName listSelectionCriteriaPageName = new ListSelectionCriteriaPageName();
    
    AuditPlan auditPlan = auditPlanDAO.get(key.auditPlanID);

    if (auditPlan.areCasesUserSelected()) {
      listSelectionCriteriaPageName.pageName = UimConst.kListManualSampleSelectionCriteria; 
    } else {
      listSelectionCriteriaPageName.pageName = UimConst.kListRandomSampleSelectionCriteria;
    }

    return listSelectionCriteriaPageName;
  }

  // ___________________________________________________________________________
  /**
   * Creates an Audit Plan Criteria record.
   *
   * @param details The Audit Plan Criteria details to be inserted
   */
  public void createAuditPlanCriteria(final AuditPlanCriteriaDtls details)
    throws AppException, InformationalException {
       
    curam.caseaudit.impl.AuditPlanCriteria auditPlanCriteria = auditPlanCriteriaDAO.newInstance();

    AuditPlan auditPlan = auditPlanDAO.get(details.auditPlanID);       

    auditPlanCriteria.setName(details.name);
    auditPlanCriteria.setValue(details.value);
    auditPlanCriteria.setAuditPlan(auditPlan);
    auditPlanCriteria.insert();
  }

}
