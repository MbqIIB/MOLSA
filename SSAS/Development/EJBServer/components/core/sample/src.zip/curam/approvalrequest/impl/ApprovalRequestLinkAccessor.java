/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalrequest.impl;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.APPROVALREQUESTSTATUSEntry;
import curam.util.persistence.StandardEntity;
import curam.util.persistence.helper.Lifecycle;


/**
 * 
 * DAO for Approval Request Link accessor objects and lists.
 */
@ImplementedBy(ApprovalRequestLinkImpl.class)
public interface ApprovalRequestLinkAccessor extends StandardEntity,
    Lifecycle<APPROVALREQUESTSTATUSEntry> {
  
  // no operations.

  
  /**
   * Returns the approval request identifier for the approval request link.
   * @return long approval request identifier.
   */
  public long getApprovalRequestID();
  
  /**
   * Returns the status for the approval request link.
   * @return Status for approval request link.
   */
  public APPROVALREQUESTSTATUSEntry getStatus();
}
