/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.clientdiary.impl;

import com.google.inject.ImplementedBy;

import curam.clientdiary.message.CLIENTDIARY;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.intf.Activity;
import curam.participant.impl.ConcernRole;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.StandardEntity;
import curam.util.persistence.helper.Lifecycle;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;

/**
 * The client diary records details of
 * {@link curam.outcomeplanning.outcomeplan.impl.OutcomePlanAction actions},
 * {@link curam.servicedelivery.impl.ServiceDelivery services},
 * {@link curam.referral.impl.Referral referrals} and {@link Activity calendar
 * activities} scheduled for a client.
 * <p>
 * The following exceptions may be raised by this entity: <br/>
 * {@link CLIENTDIARY#ERR_FV_CONCERN_ROLE_MANDATORY} - if the
 * {@link ConcernRole} has not been set.<br/>
 * {@link CLIENTDIARY#ERR_FV_RELATED_ID_MANDATORY} - if the related ID has not
 * been set.<br/>
 * {@link CLIENTDIARY#ERR_FV_RELATED_TYPE_MANDATORY} - if the
 * {@link CLIENTDIARYRELATETYPEEntry} has not been set.<br/>
 * {@link CLIENTDIARY#ERR_FV_START_DATE_MANDATORY} - if the start date has not
 * been set.<br/>
 * {@link CLIENTDIARY#ERR_XRV_DUPLICATE} - if a client diary record already
 * exists for the given concern role, related ID and related Type.<br/>
 * </p>
 * 
 * @see curam.clientdiary.entity.intf.ClientDiary
 * @curam.nonimplementable
 * @since 6.0
 */
@ImplementedBy(ClientDiaryImpl.class)
interface ClientDiary extends StandardEntity, DateRanged, Insertable,
    OptimisticLockModifiable, LogicallyDeleteable,
    Lifecycle<RECORDSTATUSEntry>, Comparable<ClientDiary> {

  /**
   * Returns the {@link ConcernRole} that this {@link ClientDiary} record refers
   * to.
   * 
   * @return The concern role that this client diary record refers to
   */
  ConcernRole getConcernRole();

  /**
   * Returns the details of the {@link ScheduledAppointment} for that this
   * {@link ClientDiary} record refers to. This may be one of
   * {@link curam.outcomeplanning.outcomeplan.impl.OutcomePlanAction},
   * {@link curam.servicedelivery.impl.ServiceDelivery},
   * {@link curam.referral.impl.Referral} or {@link Activity}.
   * 
   * @return The scheduled appointment that this client diary record refers to
   */
  ScheduledAppointment getScheduledAppointment();

  /**
   * Sets the {@link ConcernRole} that this {@link ClientDiary} record refers
   * to.
   * 
   * @param concernRole
   *          The concern role that this client diary record refers to
   */
  void setConcernRole(final ConcernRole concernRole);

  /**
   * Sets the {@link DateRange} for this {@link ClientDiary}. This should be the
   * date range of the related
   * {@link curam.outcomeplanning.outcomeplan.impl.OutcomePlanAction},
   * {@link curam.servicedelivery.impl.ServiceDelivery},
   * {@link curam.referral.impl.Referral} or {@link Activity}.
   * 
   * @param dateRange
   *          The start and end date of the client diary record. Start date is
   *          mandatory.
   */
  void setDateRange(final DateRange dateRange);

  /**
   * Sets the {@link ScheduledAppointment} that this {@link ClientDiary} record
   * refers to. This may be one of
   * {@link curam.outcomeplanning.outcomeplan.impl.OutcomePlanAction},
   * {@link curam.servicedelivery.impl.ServiceDelivery},
   * {@link curam.referral.impl.Referral} or {@link Activity}.
   * 
   * @param scheduledAppointment
   *          The scheduled appointment that this client diary record refers to
   */
  void setScheduledAppointment(final ScheduledAppointment scheduledAppointment);

}
