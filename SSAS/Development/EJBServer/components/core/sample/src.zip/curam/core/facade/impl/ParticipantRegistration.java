/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2010, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.COUNTRY;
import curam.core.facade.fact.EducationalInstituteFactory;
import curam.core.facade.fact.EmployerFactory;
import curam.core.facade.fact.ExternalPartyFactory;
import curam.core.facade.fact.InformationProviderFactory;
import curam.core.facade.fact.PersonFactory;
import curam.core.facade.fact.ProductProviderFactory;
import curam.core.facade.fact.ProspectEmployerFactory;
import curam.core.facade.fact.ProspectPersonFactory;
import curam.core.facade.fact.ServiceSupplierFactory;
import curam.core.facade.fact.UtilityFactory;
import curam.core.facade.intf.ProductProvider;
import curam.core.facade.intf.Utility;
import curam.core.facade.struct.ActionIDProperty;
import curam.core.facade.struct.AddProspectEmployerState;
import curam.core.facade.struct.AddProspectPersonState;
import curam.core.facade.struct.ConcernRoleTypeDetails;
import curam.core.facade.struct.EducationalInstituteRegistrationDetails;
import curam.core.facade.struct.EducationalInstituteSearchKey;
import curam.core.facade.struct.EducationalInstituteSearchWizardKey;
import curam.core.facade.struct.EmployerRegistrationResult;
import curam.core.facade.struct.EmployerSearchDetailsResult;
import curam.core.facade.struct.EmployerSearchKey1;
import curam.core.facade.struct.EmployerSearchResult1;
import curam.core.facade.struct.EmployerSearchWizardKey;
import curam.core.facade.struct.ExternalPartyRegistrationDetails;
import curam.core.facade.struct.ExternalPartyRegistrationResult;
import curam.core.facade.struct.ExternalPartySearchKey1;
import curam.core.facade.struct.ExternalPartySearchWizardKey;
import curam.core.facade.struct.InformationProviderRegistrationDetails;
import curam.core.facade.struct.InformationProviderRegistrationResult;
import curam.core.facade.struct.InformationProviderSearchWizardKey;
import curam.core.facade.struct.ParticipantRegistrationWizardResult;
import curam.core.facade.struct.ParticipantRegistrationWizardSearchDetails;
import curam.core.facade.struct.ParticipantRegistrationWizardSearchResult;
import curam.core.facade.struct.ParticipantSearchDetails;
import curam.core.facade.struct.ParticipantSearchKey;
import curam.core.facade.struct.ParticipantSearchResult;
import curam.core.facade.struct.ParticipantSearchWizardKey;
import curam.core.facade.struct.PersonRegistrationResult;
import curam.core.facade.struct.PersonSearchDetailsResult;
import curam.core.facade.struct.PersonSearchKey1;
import curam.core.facade.struct.PersonSearchResult1;
import curam.core.facade.struct.PersonSearchWizardKey;
import curam.core.facade.struct.ProspectEmployerRegistrationDetails;
import curam.core.facade.struct.ProspectEmployerRegistrationResult;
import curam.core.facade.struct.ProspectPersonRegistrationDetails;
import curam.core.facade.struct.ProspectPersonRegistrationResult;
import curam.core.facade.struct.RegisterEducationalInstituteState;
import curam.core.facade.struct.RegisterEmployerState;
import curam.core.facade.struct.RegisterEmployerWizardSearchDetails;
import curam.core.facade.struct.RegisterEmployerWizardSearchResult;
import curam.core.facade.struct.RegisterExternalPartyState;
import curam.core.facade.struct.RegisterInformationProviderState;
import curam.core.facade.struct.RegisterInformationProviderWizardSearchDetails;
import curam.core.facade.struct.RegisterInformationProviderWizardSearchResult;
import curam.core.facade.struct.RegisterPersonState;
import curam.core.facade.struct.RegisterPersonWizardSearchDetails;
import curam.core.facade.struct.RegisterPersonWizardSearchResult;
import curam.core.facade.struct.RegisterProductProviderDetails;
import curam.core.facade.struct.RegisterProductProviderState;
import curam.core.facade.struct.RegisterProductProviderWithTextBankAccountSortCodeDetails;
import curam.core.facade.struct.RegisterServiceSupplierState;
import curam.core.facade.struct.RegisterUtilityState;
import curam.core.facade.struct.ServiceSupplierRegistrationResult;
import curam.core.facade.struct.ServiceSupplierRegistrationWithTextBankAccountSortCodeDetails;
import curam.core.facade.struct.UtilityRegistrationResult;
import curam.core.facade.struct.UtilityRegistrationWithTextBankAccountSortCodeDetails;
import curam.core.facade.struct.UtilitySearchKey;
import curam.core.facade.struct.UtilitySearchWizardKey;
import curam.core.facade.struct.WizardProperties;
import curam.core.facade.struct.WizardStartPage;
import curam.core.fact.AddressDataFactory;
import curam.core.fact.MaintainConcernRoleDetailsFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.AddressData;
import curam.core.intf.MaintainConcernRoleDetails;
import curam.core.sl.struct.ExternalPartyDetails;
import curam.core.sl.struct.WizardStateID;
import curam.core.struct.AddressFieldDetails;
import curam.core.struct.AddressSearchKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmployerRegistrationDetails;
import curam.core.struct.LayoutKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ParticipantRoleTypeList;
import curam.core.struct.PersonRegistrationDetails;
import curam.pdc.fact.PDCUtilFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.wizardpersistence.impl.WizardPersistentState;


public abstract class ParticipantRegistration extends curam.core.facade.base.ParticipantRegistration {

  // ___________________________________________________________________________
  /**
   * Get the prospect employer registration details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return ProspectEmployerRegistrationDetails
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ProspectEmployerRegistrationDetails getAddProspectEmployerDetails(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    ProspectEmployerRegistrationDetails prospectEmployerRegistrationDetails = new ProspectEmployerRegistrationDetails();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    // If the wizard state is specified then read the record, otherwise
    // create a wizard record.
    if (wizardStateID.wizardStateID != 0) {

      AddProspectEmployerState addProspectEmployerState = (AddProspectEmployerState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      prospectEmployerRegistrationDetails.prospectEmployerRegistrationDtls = addProspectEmployerState.registrationDtls;
    }

    return prospectEmployerRegistrationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get the prospect employer Search Criteria details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return EmployerSearchWizardKey
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public EmployerSearchWizardKey getAddProspectEmployerSearchCriteria(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    EmployerSearchWizardKey employerSearchWizardKey = new EmployerSearchWizardKey();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    // If the wizard state is specified then read the record, otherwise
    // create a wizard record.
    if (wizardStateID.wizardStateID != 0) {

      AddProspectEmployerState addProspectEmployerState = (AddProspectEmployerState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      employerSearchWizardKey.searchKey = addProspectEmployerState.searchKey.searchKey;
      employerSearchWizardKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      employerSearchWizardKey.addressData = getAddressDataFromFields(employerSearchWizardKey.searchKey.key.addressDtls).addressData;

    } else {
      employerSearchWizardKey.stateID.wizardStateID = wizardPersistentState.create(
        new AddProspectEmployerState());
    }

    return employerSearchWizardKey;
  }

  // ___________________________________________________________________________
  /**
   * Returns the wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getAddProspectEmployerWizard() throws AppException,
      InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kAddProspectEmployerWizardProperties;

    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Get the prospect person registration details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return ProspectPersonRegistrationDetails
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ProspectPersonRegistrationDetails getAddProspectPersonDetails(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    ProspectPersonRegistrationDetails prospectPersonRegistrationDetails = new ProspectPersonRegistrationDetails();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    if (wizardStateID.wizardStateID != 0) {

      AddProspectPersonState addProspectPersonState = (AddProspectPersonState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      prospectPersonRegistrationDetails = addProspectPersonState.registrationDtls;
    }

    return prospectPersonRegistrationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get the prospect employer Search Criteria details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return EmployerSearchWizardKey
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public PersonSearchWizardKey getAddProspectPersonSearchCriteria(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    PersonSearchWizardKey personSearchWizardKey = new PersonSearchWizardKey();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    // If the wizard state is specified then read the record, otherwise
    // create a wizard record.
    if (wizardStateID.wizardStateID != 0) {

      AddProspectPersonState addProspectPersonState = (AddProspectPersonState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      personSearchWizardKey.searchKey = addProspectPersonState.searchKey.searchKey;
      personSearchWizardKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      personSearchWizardKey.addressData = getAddressDataFromFields(personSearchWizardKey.searchKey.addressDtls).addressData;
    } else {
      personSearchWizardKey.stateID.wizardStateID = wizardPersistentState.create(
        new AddProspectPersonState());
    }

    return personSearchWizardKey;
  }

  // ___________________________________________________________________________
  /**
   * Returns the wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getAddProspectPersonWizard() throws AppException,
      InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    // BEGIN, CR00356064, BD
    if (PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {
      wizardProperties.wizardMenu = CuramConst.kAddProspectPersonForPDCWizardProperties;
    } else {
      wizardProperties.wizardMenu = CuramConst.kAddProspectPersonWizardProperties;  
    }
    // END, CR00356064
    

    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Get the Educational Institute registration details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return EducationalInstituteRegistrationDetails
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public EducationalInstituteRegistrationDetails getRegisterEducationalInstituteDetails(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    curam.core.facade.struct.EducationalInstituteRegistrationDetails educationalInstituteRegistrationDetails = new curam.core.facade.struct.EducationalInstituteRegistrationDetails();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    if (wizardStateID.wizardStateID != 0) {

      RegisterEducationalInstituteState registerEducationalInstituteState = (RegisterEducationalInstituteState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      educationalInstituteRegistrationDetails = registerEducationalInstituteState.registrationDtls;
    }

    return educationalInstituteRegistrationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get the Educational Institute Search Criteria details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return EducationalInstituteSearchWizardKey
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public EducationalInstituteSearchWizardKey getRegisterEducationalInstituteSearchCriteria(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    EducationalInstituteSearchWizardKey educationalInstituteSearchWizardKey = new EducationalInstituteSearchWizardKey();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    // If the wizard state is specified then read the record, otherwise
    // create a wizard record.
    if (wizardStateID.wizardStateID != 0) {

      RegisterEducationalInstituteState registerEducationalInstitute = (RegisterEducationalInstituteState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerEducationalInstitute.searchKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      // BEGIN, CR00264348, JAF
      educationalInstituteSearchWizardKey.instituteType.assign(
        registerEducationalInstitute.searchKey.instituteType);
      // END, CR00264348, JAF

      educationalInstituteSearchWizardKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      educationalInstituteSearchWizardKey.addressData = getAddressDataFromFields(educationalInstituteSearchWizardKey.instituteType.key.key.addressDtls).addressData;
      wizardPersistentState.create(new RegisterEducationalInstituteState());
    } else {
      educationalInstituteSearchWizardKey.stateID.wizardStateID = wizardPersistentState.create(
        new RegisterEducationalInstituteState());
    }

    return educationalInstituteSearchWizardKey;
  }

  // ___________________________________________________________________________
  /**
   * Returns the wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getRegisterEducationalInstituteWizard()
    throws AppException, InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kRegisterEducationalInstituteWizardProperties;

    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Get the Employer registration details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return EmployerRegistrationDetails
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public EmployerRegistrationDetails getRegisterEmployerDetails(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    EmployerRegistrationDetails employerRegistrationDetails = new EmployerRegistrationDetails();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    if (wizardStateID.wizardStateID != 0) {

      RegisterEmployerState registerEmployerState = (RegisterEmployerState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      employerRegistrationDetails = registerEmployerState.registrationDtls;
    }

    return employerRegistrationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get the Employer Search Criteria details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return EmployerSearchWizardKey
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public EmployerSearchWizardKey getRegisterEmployerSearchCriteria(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    EmployerSearchWizardKey employerSearchWizardKey = new EmployerSearchWizardKey();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    // If the wizard state is specified then read the record, otherwise
    // create a wizard record.
    if (wizardStateID.wizardStateID != 0) {

      RegisterEmployerState registerEmployerState = (RegisterEmployerState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      employerSearchWizardKey.searchKey = registerEmployerState.searchKey.searchKey;
      employerSearchWizardKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      employerSearchWizardKey.addressData = getAddressDataFromFields(employerSearchWizardKey.searchKey.key.addressDtls).addressData;
    } else {
      employerSearchWizardKey.stateID.wizardStateID = wizardPersistentState.create(
        new RegisterEmployerState());
    }

    return employerSearchWizardKey;
  }

  // ___________________________________________________________________________
  /**
   * Returns the wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getRegisterEmployerWizard() throws AppException,
      InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kRegisterEmployerWizardProperties;

    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Get the External Party registration details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return ExternalPartyDetails
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ExternalPartyDetails getRegisterExternalPartyDetails(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    ExternalPartyDetails externalPartyDetails = new ExternalPartyDetails();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    if (wizardStateID.wizardStateID != 0) {

      RegisterExternalPartyState registerExternalPartyState = (RegisterExternalPartyState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      externalPartyDetails = registerExternalPartyState.registrationDtls;
    }

    return externalPartyDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get the External Party Search Criteria details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return ExternalPartySearchWizardKey
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ExternalPartySearchWizardKey getRegisterExternalPartySearchCriteria(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    ExternalPartySearchWizardKey externalPartySearchWizardKey = new ExternalPartySearchWizardKey();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    // If the wizard state is specified then read the record, otherwise
    // create a wizard record.
    if (wizardStateID.wizardStateID != 0) {

      RegisterExternalPartyState registerExternalPartyState = (RegisterExternalPartyState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      externalPartySearchWizardKey.searchKey = registerExternalPartyState.searchKey.searchKey;
      externalPartySearchWizardKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      externalPartySearchWizardKey.addressData = getAddressDataFromFields(externalPartySearchWizardKey.searchKey.key.key.addressDtls).addressData;
    } else {
      externalPartySearchWizardKey.stateID.wizardStateID = wizardPersistentState.create(
        new RegisterExternalPartyState());
    }

    return externalPartySearchWizardKey;
  }

  // ___________________________________________________________________________
  /**
   * Returns the wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getRegisterExternalPartyWizard() throws AppException,
      InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kRegisterExternalPartyWizardProperties;

    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Get the Person registration details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return PersonRegistrationDetails
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public PersonRegistrationDetails getRegisterPersonDetails(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    PersonRegistrationDetails personRegistrationDetails = new PersonRegistrationDetails();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    if (wizardStateID.wizardStateID != 0) {

      RegisterPersonState registerPersonState = (RegisterPersonState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      personRegistrationDetails = registerPersonState.registrationDtls;
    }

    return personRegistrationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get the Person Search Criteria details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return PersonSearchWizardKey
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public PersonSearchWizardKey getRegisterPersonSearchCriteria(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    PersonSearchWizardKey personSearchWizardKey = new PersonSearchWizardKey();

    personSearchWizardKey.stateID = wizardStateID;

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    // If the wizard state is specified then read the record, otherwise
    // create a wizard record.
    if (wizardStateID.wizardStateID != 0) {

      RegisterPersonState registerPersonState = (RegisterPersonState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      personSearchWizardKey.searchKey = registerPersonState.searchKey.searchKey;
      personSearchWizardKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      personSearchWizardKey.addressData = getAddressDataFromFields(personSearchWizardKey.searchKey.addressDtls).addressData;

    } else {
      personSearchWizardKey.stateID.wizardStateID = wizardPersistentState.create(
        new RegisterPersonState());
    }

    return personSearchWizardKey;
  }

  // ___________________________________________________________________________
  /**
   * Utility method to parse the address fields into an AddressData string.
   *
   * @param AddressSearchKey the address elements used in the search
   *
   * @return OtherAddressData A formatted string representation of an address.
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected OtherAddressData getAddressDataFromFields(
    final AddressSearchKey addressSearchKey) throws AppException, InformationalException {

    OtherAddressData otherAddressData = new OtherAddressData();
    AddressData addressDataObj = AddressDataFactory.newInstance();
    AddressFieldDetails addressFieldDetails = new AddressFieldDetails();

    LayoutKey layoutKey = addressDataObj.getLayoutForLocale(null);

    addressFieldDetails.addressLayoutType = layoutKey.addressLayoutType;

    addressFieldDetails.addressLine1 = addressSearchKey.addressLine1;
    addressFieldDetails.addressLine2 = addressSearchKey.addressLine2;
    addressFieldDetails.city = addressSearchKey.city;
    addressFieldDetails.stateCode = addressSearchKey.state;

    addressFieldDetails.countryCode = COUNTRY.getDefaultCode();

    otherAddressData = addressDataObj.parseFieldsToData(addressFieldDetails);

    return otherAddressData;
  }

  // ___________________________________________________________________________
  /**
   * Returns the wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getRegisterPersonWizard() throws AppException,
      InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    // BEGIN, CR00356064, BD
    if (PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {
      wizardProperties.wizardMenu = CuramConst.kRegisterPersonForPDCWizardProperties;
    } else {
      wizardProperties.wizardMenu = CuramConst.kRegisterPersonWizardProperties;
    }
    // END, CR00356064
    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Get the Product Provider registration details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return ProdProvRegistrationDetails
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public RegisterProductProviderWithTextBankAccountSortCodeDetails getRegisterProductProviderDetails(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    RegisterProductProviderWithTextBankAccountSortCodeDetails productProviderRegistrationDetails = new RegisterProductProviderWithTextBankAccountSortCodeDetails();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    if (wizardStateID.wizardStateID != 0) {

      RegisterProductProviderState registerProductProviderState = (RegisterProductProviderState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      productProviderRegistrationDetails = registerProductProviderState.registrationDtls;
    }

    return productProviderRegistrationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get the Product Provider Search Criteria details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return ParticipantSearchWizardKey
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantSearchWizardKey getRegisterProductProviderSearchCriteria(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    ParticipantSearchWizardKey participantSearchWizardKey = new ParticipantSearchWizardKey();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    // If the wizard state is specified then read the record, otherwise
    // create a wizard record.
    if (wizardStateID.wizardStateID != 0) {

      RegisterProductProviderState registerProductProviderState = (RegisterProductProviderState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      participantSearchWizardKey.searchKey = registerProductProviderState.searchKey.searchKey;
      participantSearchWizardKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      participantSearchWizardKey.addressData = getAddressDataFromFields(participantSearchWizardKey.searchKey.addressDtls).addressData;
    } else {
      participantSearchWizardKey.stateID.wizardStateID = wizardPersistentState.create(
        new RegisterProductProviderState());
    }

    return participantSearchWizardKey;
  }

  // ___________________________________________________________________________
  /**
   * Returns the wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getRegisterProductProviderWizard()
    throws AppException, InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kRegisterProductProviderWizardProperties;

    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Get the Service Supplier registration details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return ServSuppRegistrationDetails
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ServiceSupplierRegistrationWithTextBankAccountSortCodeDetails getRegisterServiceSupplierDetails(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    ServiceSupplierRegistrationWithTextBankAccountSortCodeDetails serviceSupplierRegistrationDetails = new ServiceSupplierRegistrationWithTextBankAccountSortCodeDetails();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    if (wizardStateID.wizardStateID != 0) {

      RegisterServiceSupplierState registerServiceSupplierState = (RegisterServiceSupplierState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      serviceSupplierRegistrationDetails = registerServiceSupplierState.registrationDtls;
    }

    return serviceSupplierRegistrationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get the Service Supplier Search Criteria details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return ParticipantSearchWizardKey
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantSearchWizardKey getRegisterServiceSupplierSearchCriteria(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    ParticipantSearchWizardKey participantSearchWizardKey = new ParticipantSearchWizardKey();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    // If the wizard state is specified then read the record, otherwise
    // create a wizard record.
    if (wizardStateID.wizardStateID != 0) {

      RegisterServiceSupplierState registerServiceSupplierState = (RegisterServiceSupplierState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      participantSearchWizardKey.searchKey = registerServiceSupplierState.searchKey.searchKey;
      participantSearchWizardKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      participantSearchWizardKey.addressData = getAddressDataFromFields(participantSearchWizardKey.searchKey.addressDtls).addressData;
    } else {
      participantSearchWizardKey.stateID.wizardStateID = wizardPersistentState.create(
        new RegisterServiceSupplierState());
    }

    return participantSearchWizardKey;
  }

  // ___________________________________________________________________________
  /**
   * Returns the wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getRegisterServiceSupplierWizard()
    throws AppException, InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kRegisterServiceSupplierWizardProperties;

    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Get the Utility registration details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return UtilityRegistrationDetails
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public UtilityRegistrationWithTextBankAccountSortCodeDetails getRegisterUtilityDetails(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    UtilityRegistrationWithTextBankAccountSortCodeDetails utilityRegistrationDetails = new UtilityRegistrationWithTextBankAccountSortCodeDetails();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    if (wizardStateID.wizardStateID != 0) {

      RegisterUtilityState registerUtilityState = (RegisterUtilityState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      utilityRegistrationDetails = registerUtilityState.registrationDtls;
    }

    return utilityRegistrationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get the Utility Search Criteria details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return UtilitySearchWizardKey
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public UtilitySearchWizardKey getRegisterUtilitySearchCriteria(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    UtilitySearchWizardKey utilitySearchWizardKey = new UtilitySearchWizardKey();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    // If the wizard state is specified then read the record, otherwise
    // create a wizard record.
    if (wizardStateID.wizardStateID != 0) {

      RegisterUtilityState registerUtilityState = (RegisterUtilityState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      // BEGIN, CR00264348, JAF
      utilitySearchWizardKey.type.assign(registerUtilityState.searchKey.type);
      // END, CR00264348, JAF

      utilitySearchWizardKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      utilitySearchWizardKey.addressData = getAddressDataFromFields(utilitySearchWizardKey.type.key.key.addressDtls).addressData;
      wizardPersistentState.create(new RegisterUtilityState());
    } else {
      utilitySearchWizardKey.stateID.wizardStateID = wizardPersistentState.create(
        new RegisterUtilityState());
    }

    return utilitySearchWizardKey;
  }

  // ___________________________________________________________________________
  /**
   * Returns the wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getRegisterUtilityWizard() throws AppException,
      InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kRegisterUtilityWizardProperties;

    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Set the participant registration details.
   *
   * @param registrationDtls The participant registration details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardResult setAddProspectEmployerDetails(
    final ProspectEmployerRegistrationDetails registrationDtls,
    final WizardStateID stateID, final ActionIDProperty actionID) throws AppException,
      InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardResult participantRegistrationWizardResult = new ParticipantRegistrationWizardResult();

    participantRegistrationWizardResult.wizardStateID = wizardStateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kSaveAction)) {

      AddProspectEmployerState addProspectEmployerState = (AddProspectEmployerState) wizardPersistentState.read(
        stateID.wizardStateID);

      addProspectEmployerState.registrationDtls = registrationDtls.prospectEmployerRegistrationDtls;

      ProspectEmployerRegistrationDetails details = new ProspectEmployerRegistrationDetails();

      details.prospectEmployerRegistrationDtls = addProspectEmployerState.registrationDtls;

      ProspectEmployerRegistrationResult registrationResult = ProspectEmployerFactory.newInstance().registerProspectEmployer(
        details);

      participantRegistrationWizardResult.registrationResult = registrationResult.registrationIDDetails;

      wizardPersistentState.remove(stateID.wizardStateID);
    }

    return participantRegistrationWizardResult;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Set the participant duplicate check search criteria.
   *
   * @param searchKey
   * The participant search details.
   * @param stateID
   * The identifier for the wizard persistence record
   * @param actionID
   * The ID for the action that called this method
   *
   * @return AddProspectEmployerState The serialized wizard persistence struct.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ParticipantRegistration#setAddProspectEmployerSearchCriteriaDetails(EmployerSearchWizardKey, WizardStateID, ActionIDProperty)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * setAddProspectEmployerSearchCriteria(EmployerSearchWizardKey,
   * WizardStateID, ActionIDProperty) which returns the
   * informational message along with search employer wizard search
   * details as well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public RegisterEmployerWizardSearchResult setAddProspectEmployerSearchCriteria(
    final EmployerSearchWizardKey searchKey, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {
    // END, CR00282028
    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    RegisterEmployerWizardSearchResult registerEmployerWizardSearchResult = new RegisterEmployerWizardSearchResult();

    registerEmployerWizardSearchResult.wizardStateID = stateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kNextPageAction)) {

      AddProspectEmployerState addProspectEmployerState = (AddProspectEmployerState) wizardPersistentState.read(
        stateID.wizardStateID);

      addProspectEmployerState.searchKey = searchKey;
      addProspectEmployerState.searchKey.stateID = stateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        addProspectEmployerState);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kSearchAction)) {
      registerEmployerWizardSearchResult.searchResult = searchProspectEmployer(
        searchKey);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kResetAction)) {

      AddProspectEmployerState addProspectEmployerState = (AddProspectEmployerState) wizardPersistentState.read(
        stateID.wizardStateID);

      addProspectEmployerState.searchKey = new EmployerSearchWizardKey();

      wizardPersistentState.modify(stateID.wizardStateID,
        addProspectEmployerState);
    }

    return registerEmployerWizardSearchResult;
  }

  // ___________________________________________________________________________
  /**
   * Set the participant registration details.
   *
   * @param registrationDtls The participant registration details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardResult setAddProspectPersonDetails(
    final ProspectPersonRegistrationDetails registrationDtls, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardResult participantRegistrationWizardResult = new ParticipantRegistrationWizardResult();

    participantRegistrationWizardResult.wizardStateID = wizardStateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kSaveAction)) {

      AddProspectPersonState addProspectPersonState = (AddProspectPersonState) wizardPersistentState.read(
        stateID.wizardStateID);

      addProspectPersonState.registrationDtls = registrationDtls;

      ProspectPersonRegistrationDetails details = new ProspectPersonRegistrationDetails();

      details = addProspectPersonState.registrationDtls;

      ProspectPersonRegistrationResult registrationResult = ProspectPersonFactory.newInstance().registerProspectPerson(
        details);

      participantRegistrationWizardResult.registrationResult = registrationResult.registrationIDDetails;

      wizardPersistentState.remove(stateID.wizardStateID);
    }

    return participantRegistrationWizardResult;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Set the participant duplicate check search criteria.
   *
   * @param searchKey
   * The participant search details.
   * @param stateID
   * The identifier for the wizard persistence record
   * @param actionID
   * The ID for the action that called this method
   *
   * @return AddProspectPersonState The serialized wizard persistence struct.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ParticipantRegistration#setAddProspectPersonSearchCriteriaDetails(PersonSearchWizardKey, WizardStateID, ActionIDProperty)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * setAddProspectPersonSearchCriteriaDetails
   * (PersonSearchWizardKey, WizardStateID, ActionIDProperty) which
   * returns the informational message along with person details as
   * well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public RegisterPersonWizardSearchResult setAddProspectPersonSearchCriteria(
    final PersonSearchWizardKey searchKey, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {
    // END, CR00282028
    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);
    RegisterPersonWizardSearchResult registerPersonWizardSearchResult = new RegisterPersonWizardSearchResult();

    registerPersonWizardSearchResult.wizardStateID = stateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kNextPageAction)) {

      AddProspectPersonState addProspectPersonState = (AddProspectPersonState) wizardPersistentState.read(
        stateID.wizardStateID);

      addProspectPersonState.searchKey = searchKey;
      addProspectPersonState.searchKey.stateID = stateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        addProspectPersonState);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kSearchAction)) {
      registerPersonWizardSearchResult.searchResult = searchPerson(searchKey);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kResetAction)) {

      AddProspectPersonState addProspectPersonState = (AddProspectPersonState) wizardPersistentState.read(
        stateID.wizardStateID);

      addProspectPersonState.searchKey = new PersonSearchWizardKey();

      wizardPersistentState.modify(stateID.wizardStateID,
        addProspectPersonState);
    }

    return registerPersonWizardSearchResult;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Set the participant duplicate check search criteria.
   *
   * @param searchKey The participant search details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return RegisterEducationalInstituteState The serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with {@link
   * ParticipantRegistration#setRegisterEducationalInstituteSearchCriteriaDetails(EducationalInstituteSearchWizardKey, WizardStateID, ActionIDProperty)}
   *
   * This method is deprecated as informational messages are not returned.
   * This method is replaced by setRegisterEducationalInstituteSearchCriteriaDetails(EducationalInstituteSearchWizardKey, WizardStateID, ActionIDProperty)
   * which returns the informational message along with educational institute details as well.
   * See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantRegistrationWizardSearchResult setRegisterEducationalInstituteSearchCriteria(
    final EducationalInstituteSearchWizardKey searchKey, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {
    // END, CR00290965
    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardSearchResult participantRegistrationWizardSearchResult = new ParticipantRegistrationWizardSearchResult();

    participantRegistrationWizardSearchResult.wizardStateID = stateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kNextPageAction)) {

      RegisterEducationalInstituteState registerEducationalInstituteState = (RegisterEducationalInstituteState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerEducationalInstituteState.searchKey = searchKey;
      registerEducationalInstituteState.searchKey.stateID = stateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerEducationalInstituteState);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kSearchAction)) {
      participantRegistrationWizardSearchResult.searchResult = searchEducationInstitute(
        searchKey);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kResetAction)) {

      RegisterEducationalInstituteState registerEducationalInstituteState = (RegisterEducationalInstituteState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerEducationalInstituteState.searchKey = new EducationalInstituteSearchWizardKey();

      wizardPersistentState.modify(stateID.wizardStateID,
        registerEducationalInstituteState);
    }

    return participantRegistrationWizardSearchResult;
  }

  // ___________________________________________________________________________
  /**
   * Set the participant registration details.
   *
   * @param registrationDtls The participant registration details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardResult setRegisterEducationalInstituteDetails(
    final EducationalInstituteRegistrationDetails registrationDtls,
    final WizardStateID stateID, final ActionIDProperty actionID) throws AppException,
      InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardResult participantRegistrationWizardResult = new ParticipantRegistrationWizardResult();

    participantRegistrationWizardResult.wizardStateID = wizardStateID;
    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kSaveAction)) {

      RegisterEducationalInstituteState registerEducationalInstituteState = (RegisterEducationalInstituteState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerEducationalInstituteState.registrationDtls = registrationDtls;

      curam.core.facade.struct.EducationalInstituteRegistrationDetails details = new curam.core.facade.struct.EducationalInstituteRegistrationDetails();

      details.assign(registerEducationalInstituteState.registrationDtls);

      InformationProviderRegistrationResult registrationResult = EducationalInstituteFactory.newInstance().registerEducationalInstitute(
        details);

      participantRegistrationWizardResult.registrationResult = registrationResult.registrationIDDetails;

      wizardPersistentState.remove(stateID.wizardStateID);
    }

    return participantRegistrationWizardResult;
  }

  // ___________________________________________________________________________
  /**
   * Set the participant registration details.
   *
   * @param registrationDtls The participant registration details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardResult setRegisterEmployerDetails(
    final EmployerRegistrationDetails registrationDtls, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardResult participantRegistrationWizardResult = new ParticipantRegistrationWizardResult();

    participantRegistrationWizardResult.wizardStateID = wizardStateID;
    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kSaveAction)) {

      RegisterEmployerState registerEmployerState = (RegisterEmployerState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerEmployerState.registrationDtls = registrationDtls;

      curam.core.facade.struct.EmployerRegistrationDetails details = new curam.core.facade.struct.EmployerRegistrationDetails();

      details.employerRegistrationDetails = registerEmployerState.registrationDtls;

      EmployerRegistrationResult registrationResult = EmployerFactory.newInstance().register(
        details);

      participantRegistrationWizardResult.registrationResult = registrationResult.registrationIDDetails;

      wizardPersistentState.remove(stateID.wizardStateID);
    }

    return participantRegistrationWizardResult;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Set the participant duplicate check search criteria.
   *
   * @param searchKey
   * The participant search details.
   * @param stateID
   * The identifier for the wizard persistence record
   * @param actionID
   * The ID for the action that called this method
   *
   * @return RegisterEmployerState The serialized wizard persistence struct.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ParticipantRegistration#setRegisterEmployerSearchCriteriaDetails(EmployerSearchWizardKey, WizardStateID, ActionIDProperty)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * setRegisterEmployerSearchCriteriaDetails
   * (EmployerSearchWizardKey, WizardStateID, ActionIDProperty)
   * which returns the informational message along with search
   * employer wizard search details as well.
   * See release note:CS-09152/CR00282028.
   */
  @Deprecated
  public RegisterEmployerWizardSearchResult setRegisterEmployerSearchCriteria(
    final EmployerSearchWizardKey searchKey, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {
    // END, CR00282028
    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    RegisterEmployerWizardSearchResult registerEmployerWizardSearchResult = new RegisterEmployerWizardSearchResult();

    registerEmployerWizardSearchResult.wizardStateID = stateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kNextPageAction)) {

      RegisterEmployerState registerEmployerState = (RegisterEmployerState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerEmployerState.searchKey = searchKey;
      registerEmployerState.searchKey.stateID = stateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerEmployerState);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kSearchAction)) {
      registerEmployerWizardSearchResult.searchResult = searchEmployer(
        searchKey);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kResetAction)) {

      RegisterEmployerState registerEmployerState = (RegisterEmployerState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerEmployerState.searchKey = new EmployerSearchWizardKey();

      wizardPersistentState.modify(stateID.wizardStateID, registerEmployerState);
    }

    return registerEmployerWizardSearchResult;
  }

  // ___________________________________________________________________________
  /**
   * Set the participant registration details.
   *
   * @param registrationDtls The participant registration details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardResult setRegisterExternalPartyDetails(
    final ExternalPartyRegistrationDetails registrationDtls, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardResult participantRegistrationWizardResult = new ParticipantRegistrationWizardResult();

    participantRegistrationWizardResult.wizardStateID = wizardStateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kSaveAction)) {

      RegisterExternalPartyState registerExternalPartyState = (RegisterExternalPartyState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerExternalPartyState.registrationDtls = registrationDtls.externalPartyRegistrationDetails;

      ExternalPartyRegistrationDetails details = new ExternalPartyRegistrationDetails();

      details.externalPartyRegistrationDetails = registerExternalPartyState.registrationDtls;

      ExternalPartyRegistrationResult registrationResult = ExternalPartyFactory.newInstance().registerExternalParty(
        details);

      participantRegistrationWizardResult.registrationResult.concernRoleID = registrationResult.externalPartyRegistrationIDDetails.concernRoleID;
      participantRegistrationWizardResult.registrationResult.alternateID = registrationResult.externalPartyRegistrationIDDetails.alternateID;

      wizardPersistentState.remove(stateID.wizardStateID);
    }

    return participantRegistrationWizardResult;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Set the participant duplicate check search criteria.
   *
   * @param searchKey The participant search details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return RegisterExternalPartyState The serialized wizard persistence struct.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with {@link
   * ParticipantRegistration#setRegisterExternalPartySearchCriteriaDetails(ExternalPartySearchWizardKey, WizardStateID, ActionIDProperty)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by setRegisterExternalPartySearchCriteriaDetails(ExternalPartySearchWizardKey, WizardStateID, ActionIDProperty)
   * which returns the informational message along with external party details
   * as well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantRegistrationWizardSearchResult setRegisterExternalPartySearchCriteria(
    final ExternalPartySearchWizardKey searchKey, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {
    // END, CR00290965
    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardSearchResult participantRegistrationWizardSearchResult = new ParticipantRegistrationWizardSearchResult();

    participantRegistrationWizardSearchResult.wizardStateID = stateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kNextPageAction)) {

      RegisterExternalPartyState registerExternalPartyState = (RegisterExternalPartyState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerExternalPartyState.searchKey = searchKey;
      registerExternalPartyState.searchKey.stateID = stateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerExternalPartyState);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kSearchAction)) {
      participantRegistrationWizardSearchResult.searchResult = searchExternalParty(
        searchKey);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kResetAction)) {

      RegisterExternalPartyState registerExternalPartyState = (RegisterExternalPartyState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerExternalPartyState.searchKey = new ExternalPartySearchWizardKey();

      wizardPersistentState.modify(stateID.wizardStateID,
        registerExternalPartyState);
    }

    return participantRegistrationWizardSearchResult;
  }

  // BEGIN, CR00356064, BD
  // ___________________________________________________________________________
  /**
   * Set the participant registration details for Participant Data Cases.
   *
   * @param registrationDtls The participant registration details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardResult setRegisterPersonForPDCDetails(
    final PersonRegistrationDetails registrationDtls, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardResult participantRegistrationWizardResult = new ParticipantRegistrationWizardResult();

    participantRegistrationWizardResult.wizardStateID = wizardStateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kSaveAction)) {

      RegisterPersonState registerPersonState = (RegisterPersonState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerPersonState.registrationDtls = registrationDtls;
      curam.core.facade.struct.PersonRegistrationDetails details = new curam.core.facade.struct.PersonRegistrationDetails();

      details.personRegistrationDetails = registerPersonState.registrationDtls;

      PersonRegistrationResult registrationResult = PersonFactory.newInstance().register(
        details);

      participantRegistrationWizardResult.registrationResult = registrationResult.registrationIDDetails;

      wizardPersistentState.remove(stateID.wizardStateID);
    }

    return participantRegistrationWizardResult;
  }

  // END, CR00356064
  
  // ___________________________________________________________________________
  /**
   * Set the participant registration details.
   *
   * @param registrationDtls The participant registration details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardResult setRegisterPersonDetails(
    final PersonRegistrationDetails registrationDtls, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardResult participantRegistrationWizardResult = new ParticipantRegistrationWizardResult();

    participantRegistrationWizardResult.wizardStateID = wizardStateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kSaveAction)) {

      RegisterPersonState registerPersonState = (RegisterPersonState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerPersonState.registrationDtls = registrationDtls;
      curam.core.facade.struct.PersonRegistrationDetails details = new curam.core.facade.struct.PersonRegistrationDetails();

      details.personRegistrationDetails = registerPersonState.registrationDtls;

      PersonRegistrationResult registrationResult = PersonFactory.newInstance().register(
        details);

      participantRegistrationWizardResult.registrationResult = registrationResult.registrationIDDetails;

      wizardPersistentState.remove(stateID.wizardStateID);
    }

    return participantRegistrationWizardResult;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Set the participant duplicate check search criteria.
   *
   * @param searchKey
   * The participant search details.
   * @param stateID
   * The identifier for the wizard persistence record
   * @param actionID
   * The ID for the action that called this method
   *
   * @return RegisterPersonState The serialized wizard persistence struct.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ParticipantRegistration#setRegisterPersonSearchCriteriaDetails(PersonSearchWizardKey, WizardStateID, ActionIDProperty)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * setRegisterPersonSearchCriteriaDetails(PersonSearchWizardKey,
   * WizardStateID, ActionIDProperty) which returns the
   * informational message along with person details as well. See
   * release note: CS-09152/CR00282028.
   */
  @Deprecated
  public RegisterPersonWizardSearchResult setRegisterPersonSearchCriteria(
    final PersonSearchWizardKey searchKey, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {
    // END, CR00282028
    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    RegisterPersonWizardSearchResult registerPersonWizardSearchResult = new RegisterPersonWizardSearchResult();

    registerPersonWizardSearchResult.wizardStateID = stateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kNextPageAction)) {

      RegisterPersonState registerPersonState = (RegisterPersonState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerPersonState.searchKey = searchKey;
      registerPersonState.searchKey.stateID = stateID;

      wizardPersistentState.modify(stateID.wizardStateID, registerPersonState);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kSearchAction)) {
      registerPersonWizardSearchResult.searchResult = searchPerson(searchKey);

    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kResetAction)) {

      RegisterPersonState registerPersonState = (RegisterPersonState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerPersonState.searchKey = new PersonSearchWizardKey();

      wizardPersistentState.modify(stateID.wizardStateID, registerPersonState);
    }

    return registerPersonWizardSearchResult;
  }

  // ___________________________________________________________________________
  /**
   * Set the participant registration details.
   *
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @param registrationDtls The participant registration details.
   * @return wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardResult setRegisterProductProviderDetails(
    final WizardStateID stateID, final ActionIDProperty actionID,
    final RegisterProductProviderWithTextBankAccountSortCodeDetails registrationDtls) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardResult participantRegistrationWizardResult = new ParticipantRegistrationWizardResult();

    participantRegistrationWizardResult.wizardStateID = wizardStateID;
    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kSaveAction)) {

      RegisterProductProviderState registerProductProviderState = (RegisterProductProviderState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerProductProviderState.registrationDtls = registrationDtls;
      ProductProvider productProviderObj = ProductProviderFactory.newInstance();

      RegisterProductProviderDetails registrationResult = productProviderObj.registerProductProviderWithTextBankAccountSortCode(
        registrationDtls);

      participantRegistrationWizardResult.registrationResult = registrationResult.registrationIDDetails;

      wizardPersistentState.remove(stateID.wizardStateID);
    }

    return participantRegistrationWizardResult;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Set the participant duplicate check search criteria.
   *
   * @param searchKey The participant search details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return RegisterProductProviderState The serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with {@link
   * ParticipantRegistration#setRegisterProductProviderSearchCriteriaDetails(ParticipantSearchWizardKey, WizardStateID, ActionIDProperty)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by setRegisterProductProviderSearchCriteriaDetails(ParticipantSearchWizardKey, WizardStateID, ActionIDProperty)
   * which returns the informational message along with product provider
   * details as well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantRegistrationWizardSearchResult setRegisterProductProviderSearchCriteria(
    final ParticipantSearchWizardKey searchKey, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {
    // END, CR00290965
    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardSearchResult participantRegistrationWizardSearchResult = new ParticipantRegistrationWizardSearchResult();

    participantRegistrationWizardSearchResult.wizardStateID = stateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kNextPageAction)) {

      RegisterProductProviderState registerProductProviderState = (RegisterProductProviderState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerProductProviderState.searchKey = searchKey;
      registerProductProviderState.searchKey.stateID = stateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerProductProviderState);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kSearchAction)) {
      participantRegistrationWizardSearchResult.searchResult = searchProductProvider(
        searchKey);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kResetAction)) {

      RegisterProductProviderState registerProductProviderState = (RegisterProductProviderState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerProductProviderState.searchKey = new ParticipantSearchWizardKey();

      wizardPersistentState.modify(stateID.wizardStateID,
        registerProductProviderState);
    }

    return participantRegistrationWizardSearchResult;
  }

  // ___________________________________________________________________________
  /**
   * Set the participant registration details.
   *
   * @param registrationDtls The participant registration details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardResult setRegisterServiceSupplierDetails(
    final ServiceSupplierRegistrationWithTextBankAccountSortCodeDetails registrationDtls, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardResult participantRegistrationWizardResult = new ParticipantRegistrationWizardResult();

    participantRegistrationWizardResult.wizardStateID = wizardStateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kSaveAction)) {

      RegisterServiceSupplierState registerServiceSupplierState = (RegisterServiceSupplierState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerServiceSupplierState.registrationDtls = registrationDtls;

      curam.core.facade.intf.ServiceSupplier serviceSupplierObj = ServiceSupplierFactory.newInstance();

      ServiceSupplierRegistrationResult registrationResult = serviceSupplierObj.registerWithTextBankAccountSortCode(
        registrationDtls);

      participantRegistrationWizardResult.registrationResult = registrationResult.registrationIDDetails;

      wizardPersistentState.remove(stateID.wizardStateID);
    }

    return participantRegistrationWizardResult;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Set the participant duplicate check search criteria.
   *
   * @param searchKey The participant search details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return RegisterServiceSupplierState The serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with {@link
   * ParticipantRegistration#setRegisterServiceSupplierSearchCriteriaDetails(ParticipantSearchWizardKey, WizardStateID, ActionIDProperty)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by setRegisterServiceSupplierSearchCriteriaDetails(ParticipantSearchWizardKey, WizardStateID, ActionIDProperty)
   * which returns the informational message along with service supplier details as well.
   * See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantRegistrationWizardSearchResult setRegisterServiceSupplierSearchCriteria(
    final ParticipantSearchWizardKey searchKey, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {
    // END, CR00290965
    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardSearchResult participantRegistrationWizardSearchResult = new ParticipantRegistrationWizardSearchResult();

    participantRegistrationWizardSearchResult.wizardStateID = stateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kNextPageAction)) {

      RegisterServiceSupplierState registerServiceSupplierState = (RegisterServiceSupplierState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerServiceSupplierState.searchKey = searchKey;
      registerServiceSupplierState.searchKey.stateID = stateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerServiceSupplierState);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kSearchAction)) {
      participantRegistrationWizardSearchResult.searchResult = searchServiceSupplier(
        searchKey);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kResetAction)) {

      RegisterServiceSupplierState registerServiceSupplierState = (RegisterServiceSupplierState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerServiceSupplierState.searchKey = new ParticipantSearchWizardKey();

      wizardPersistentState.modify(stateID.wizardStateID,
        registerServiceSupplierState);
    }

    return participantRegistrationWizardSearchResult;
  }

  // ___________________________________________________________________________
  /**
   * Set the participant registration details.
   *
   * @param registrationDtls The participant registration details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardResult setRegisterUtilityDetails(
    final UtilityRegistrationWithTextBankAccountSortCodeDetails registrationDtls, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardResult participantRegistrationWizardResult = new ParticipantRegistrationWizardResult();

    participantRegistrationWizardResult.wizardStateID = wizardStateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kSaveAction)) {

      RegisterUtilityState registerUtilityState = (RegisterUtilityState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerUtilityState.registrationDtls = registrationDtls;
      Utility utilityObj = UtilityFactory.newInstance();

      UtilityRegistrationResult registrationResult = utilityObj.registerWithTextBankAccountSortCode(
        registrationDtls);

      participantRegistrationWizardResult.registrationResult = registrationResult.registrationIDDetails;

      wizardPersistentState.remove(stateID.wizardStateID);
    }

    return participantRegistrationWizardResult;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Set the participant duplicate check search criteria.
   *
   * @param searchKey The participant search details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return RegisterUtilityState The serialized wizard persistence struct.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with {@link ParticipantRegistration#setRegisterUtilitySearchCriteriaDetails(UtilitySearchWizardKey, WizardStateID, ActionIDProperty)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by setRegisterUtilitySearchCriteriaDetails(UtilitySearchWizardKey, WizardStateID, ActionIDProperty)
   * which returns the informational message along with utility details as well.
   * See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantRegistrationWizardSearchResult setRegisterUtilitySearchCriteria(
    final UtilitySearchWizardKey searchKey, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {
    // END, CR00290965
    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardSearchResult participantRegistrationWizardSearchResult = new ParticipantRegistrationWizardSearchResult();

    participantRegistrationWizardSearchResult.wizardStateID = stateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kNextPageAction)) {

      RegisterUtilityState registerUtilityState = (RegisterUtilityState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerUtilityState.searchKey = searchKey;
      registerUtilityState.searchKey.stateID = stateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerUtilityState);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kSearchAction)) {
      participantRegistrationWizardSearchResult.searchResult = searchUtility(
        searchKey);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kResetAction)) {

      RegisterUtilityState registerUtilityState = (RegisterUtilityState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerUtilityState.searchKey = new UtilitySearchWizardKey();

      wizardPersistentState.modify(stateID.wizardStateID, registerUtilityState);
    }

    return participantRegistrationWizardSearchResult;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Wrapper method for the Person search method.
   *
   * @param key
   * The wizard and search criteria.
   * @return PersonSearchResult1 the search results.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ParticipantRegistration#searchPersonDetails(PersonSearchWizardKey)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchPersonDetails(PersonSearchWizardKey) which returns the
   * informational message along with person details as well. See
   * release note: CS-09152/CR00282028.
   */
  @Deprecated
  public PersonSearchResult1 searchPerson(final PersonSearchWizardKey key)
    throws AppException, InformationalException {
    // END, CR00282028
    PersonSearchResult1 personSearchResult1 = new PersonSearchResult1();

    PersonSearchKey1 personSearchKey1 = new PersonSearchKey1();

    personSearchKey1.personSearchKey = key.searchKey;
    personSearchResult1 = PersonFactory.newInstance().search1(personSearchKey1);

    return personSearchResult1;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Wrapper method for the Educational Institute search method.
   *
   * @param key The wizard and search criteria.
   * @return PersonSearchResult1 the search results.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ParticipantRegistration#searchEducationInstituteDetails(EducationalInstituteSearchWizardKey)}
   *
   * This method is deprecated as informational messages are not returned.
   * This method is replaced by
   * searchEducationInstituteDetails(EducationalInstituteSearchWizardKey) which
   * returns the informational message along with educational institute details as well.
   * See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantSearchResult searchEducationInstitute(
    final EducationalInstituteSearchWizardKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    ParticipantSearchResult participantSearchResult = new ParticipantSearchResult();

    EducationalInstituteSearchKey educationalInstituteSearchKey = new EducationalInstituteSearchKey();

    educationalInstituteSearchKey = key.instituteType;

    participantSearchResult = EducationalInstituteFactory.newInstance().search1(
      educationalInstituteSearchKey);

    return participantSearchResult;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Wrapper method for the Employer search method.
   *
   * @param key
   * The wizard and search criteria.
   * @return PersonSearchResult1 the search results.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ParticipantRegistration#searchEmployerDetails(EmployerSearchWizardKey)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchEmployer(EmployerSearchWizardKey) which returns the
   * informational message along with search employer wizard search
   * details as well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public EmployerSearchResult1 searchEmployer(final EmployerSearchWizardKey key)
    throws AppException, InformationalException {
    // END, CR00282028
    EmployerSearchResult1 employerSearchResult1 = new EmployerSearchResult1();

    EmployerSearchKey1 employerSearchKey1 = new EmployerSearchKey1();

    employerSearchKey1 = key.searchKey;

    employerSearchResult1 = EmployerFactory.newInstance().search1(
      employerSearchKey1);

    return employerSearchResult1;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Wrapper method for the External Party search method.
   *
   * @param key The wizard and search criteria.
   * @return PersonSearchResult1 the search results.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with {@link ParticipantRegistration#searchExternalPartyDetails(ExternalPartySearchWizardKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by searchExternalPartyDetails(ExternalPartySearchWizardKey)
   * which returns the informational message along with external party details
   * as well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantSearchResult searchExternalParty(
    final ExternalPartySearchWizardKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    ParticipantSearchResult participantSearchResult = new ParticipantSearchResult();

    ExternalPartySearchKey1 externalPartySearchKey1 = new ExternalPartySearchKey1();

    externalPartySearchKey1 = key.searchKey;

    participantSearchResult = ExternalPartyFactory.newInstance().searchExternalParty1(
      externalPartySearchKey1);

    return participantSearchResult;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Wrapper method for the Product Provider search method.
   *
   * @param key The wizard and search criteria.
   * @return PersonSearchResult1 the search results.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with {@link
   * ParticipantRegistration#searchProductProviderDetails(ParticipantSearchWizardKey)
   *
   * This method is deprecated as informational messages are not returned.
   * This method is replaced by searchProductProviderDetails(ParticipantSearchWizardKey)
   * which returns the informational message along with product provider details as well.
   * See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantSearchResult searchProductProvider(
    final ParticipantSearchWizardKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    ParticipantSearchResult participantSearchResult = new ParticipantSearchResult();

    ParticipantSearchKey participantSearchKey = new ParticipantSearchKey();

    participantSearchKey.key = key.searchKey;

    participantSearchResult = ProductProviderFactory.newInstance().search1(
      participantSearchKey);

    return participantSearchResult;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Wrapper method for the Prospect Employer search method.
   *
   * @param key
   * The wizard and search criteria.
   * @return PersonSearchResult1 the search results.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ParticipantRegistration#searchProspectEmployerDetails(EmployerSearchWizardKey)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchProspectEmployerDetails(EmployerSearchWizardKey) which
   * returns the informational message along with search employer
   * details as well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public EmployerSearchResult1 searchProspectEmployer(
    final EmployerSearchWizardKey key)
    throws AppException, InformationalException {
    // END, CR00282028
    EmployerSearchResult1 employerSearchResult1 = new EmployerSearchResult1();

    EmployerSearchKey1 employerSearchKey = new EmployerSearchKey1();

    employerSearchKey.key = key.searchKey.key;

    employerSearchResult1 = ProspectEmployerFactory.newInstance().search1(
      employerSearchKey);

    return employerSearchResult1;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Wrapper method for the Prospect Person search method.
   *
   * @param key
   * The wizard and search criteria.
   * @return PersonSearchResult1 the search results.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link ParticipantRegistration#searchProspectPersonDetails(PersonSearchWizardKey)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchProspectPersonDetails(PersonSearchWizardKey) which
   * returns the informational message along with prospect person
   * details as well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public PersonSearchResult1 searchProspectPerson(
    final PersonSearchWizardKey key)
    throws AppException, InformationalException {
    // END, CR00282028
    PersonSearchResult1 personSearchResult1 = new PersonSearchResult1();

    PersonSearchKey1 personSearchKey1 = new PersonSearchKey1();

    personSearchKey1.personSearchKey = key.searchKey;

    personSearchResult1 = PersonFactory.newInstance().search1(personSearchKey1);

    return personSearchResult1;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Wrapper method for the Service Supplier search method.
   *
   * @param key The wizard and search criteria.
   * @return PersonSearchResult1 the search results.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with {@link ParticipantRegistration#searchServiceSupplierDetails(ParticipantSearchWizardKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by searchServiceSupplierDetails(ParticipantSearchWizardKey)
   * which returns the informational message along with service supplier
   * details as well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantSearchResult searchServiceSupplier(
    final ParticipantSearchWizardKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    ParticipantSearchResult participantSearchResult = new ParticipantSearchResult();

    ParticipantSearchKey participantSearchKey = new ParticipantSearchKey();

    participantSearchKey.key = key.searchKey;

    participantSearchResult = ServiceSupplierFactory.newInstance().search1(
      participantSearchKey);

    return participantSearchResult;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Wrapper method for the Utility search method.
   *
   * @param key The wizard and search criteria.
   * @return PersonSearchResult1 the search results.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with {@link ParticipantRegistration#searchUtilityDetails(UtilitySearchWizardKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by searchUtilityDetails(UtilitySearchWizardKey) which
   * returns the informational message along with utility details as well.
   * See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantSearchResult searchUtility(final UtilitySearchWizardKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    ParticipantSearchResult participantSearchResult = new ParticipantSearchResult();

    UtilitySearchKey utilitySearchKey = new UtilitySearchKey();

    utilitySearchKey.key.key = key.type.key.key;

    participantSearchResult = UtilityFactory.newInstance().search1(
      utilitySearchKey);

    return participantSearchResult;
  }

  // ___________________________________________________________________________
  /**
   * Return the start page for the Add Prospect Employer wizard.
   *
   * @return WizardStartPage
   */
  public WizardStartPage getAddProspectEmployerStartPage() throws AppException,
      InformationalException {

    WizardStartPage wizardStartPage = new WizardStartPage();

    wizardStartPage.startPageName = CuramConst.kAddProspectEmployerWizardStartPage;

    return wizardStartPage;
  }

  // ___________________________________________________________________________
  /**
   * Return the start page for the Add Prospect Person wizard.
   *
   * @return WizardStartPage
   */
  public WizardStartPage getAddProspectPersonStartPage() throws AppException,
      InformationalException {

    WizardStartPage wizardStartPage = new WizardStartPage();

    // BEGIN, CR00356064, BD
    if (PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {
      wizardStartPage.startPageName = CuramConst.kAddProspectPersonForPDCWizardStartPage;
    } else {
      wizardStartPage.startPageName = CuramConst.kAddProspectPersonWizardStartPage;
    }
    // END, CR00356064
    return wizardStartPage;
  }

  // ___________________________________________________________________________
  /**
   * Return the start page for the Register Educational Institute wizard.
   *
   * @return WizardStartPage
   */
  public WizardStartPage getRegisterEducationalInstituteStartPage()
    throws AppException, InformationalException {

    WizardStartPage wizardStartPage = new WizardStartPage();

    wizardStartPage.startPageName = CuramConst.kRegisterEducationalInstituteWizardStartPage;

    return wizardStartPage;
  }

  // ___________________________________________________________________________
  /**
   * Return the start page for the Register Employer wizard.
   *
   * @return WizardStartPage
   */
  public WizardStartPage getRegisterEmployerStartPage() throws AppException,
      InformationalException {

    WizardStartPage wizardStartPage = new WizardStartPage();

    wizardStartPage.startPageName = CuramConst.kRegisterEmployerWizardStartPage;

    return wizardStartPage;
  }

  // ___________________________________________________________________________
  /**
   * Return the start page for the Register External Party wizard.
   *
   * @return WizardStartPage
   */
  public WizardStartPage getRegisterExternalPartyStartPage()
    throws AppException, InformationalException {

    WizardStartPage wizardStartPage = new WizardStartPage();

    wizardStartPage.startPageName = CuramConst.kRegisterExternalPartyWizardStartPage;

    return wizardStartPage;
  }

  // ___________________________________________________________________________
  /**
   * Return the start page for the Register Person wizard.
   *
   * @return WizardStartPage
   */
  public WizardStartPage getRegisterPersonStartPage() throws AppException,
      InformationalException {

    WizardStartPage wizardStartPage = new WizardStartPage();

    // BEGIN, CR00356064, BD
    if (PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {
      wizardStartPage.startPageName = CuramConst.kRegisterPersonForPDCWizardStartPage;

    } else {
      wizardStartPage.startPageName = CuramConst.kRegisterPersonWizardStartPage;
  
    }
    // END, CR00356064
    

    return wizardStartPage;
  }

  // ___________________________________________________________________________
  /**
   * Return the start page for the Register Product Provider wizard.
   *
   * @return WizardStartPage
   */
  public WizardStartPage getRegisterProductProviderStartPage()
    throws AppException, InformationalException {

    WizardStartPage wizardStartPage = new WizardStartPage();

    wizardStartPage.startPageName = CuramConst.kRegisterProductProviderWizardStartPage;

    return wizardStartPage;
  }

  // ___________________________________________________________________________
  /**
   * Return the start page for the Register Service Supplier wizard.
   *
   * @return WizardStartPage
   */
  public WizardStartPage getRegisterServiceSupplierStartPage()
    throws AppException, InformationalException {

    WizardStartPage wizardStartPage = new WizardStartPage();

    wizardStartPage.startPageName = CuramConst.kRegisterServiceSupplierWizardStartPage;

    return wizardStartPage;
  }

  // ___________________________________________________________________________
  /**
   * Get the Information Provider registration details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return InformationProviderRegistrationDetails
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public InformationProviderRegistrationDetails getRegisterInformationProviderDetails(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    curam.core.facade.struct.InformationProviderRegistrationDetails informationProviderRegistrationDetails = new curam.core.facade.struct.InformationProviderRegistrationDetails();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    if (wizardStateID.wizardStateID != 0) {

      RegisterInformationProviderState registerInformationProviderState = (RegisterInformationProviderState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      informationProviderRegistrationDetails = registerInformationProviderState.registrationDtls;
    }

    return informationProviderRegistrationDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get the Educational Institute Search Criteria details.
   *
   * @param wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @return EducationalInstituteSearchWizardKey
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public InformationProviderSearchWizardKey getRegisterInformationProviderSearchCriteria(
    final WizardStateID wizardStateID) throws AppException, InformationalException {

    InformationProviderSearchWizardKey informationProviderSearchWizardKey = new InformationProviderSearchWizardKey();

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    // If the wizard state is specified then read the record, otherwise
    // create a wizard record.
    if (wizardStateID.wizardStateID != 0) {

      RegisterInformationProviderState registerInformationProviderState = (RegisterInformationProviderState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerInformationProviderState.searchKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      informationProviderSearchWizardKey = registerInformationProviderState.searchKey;
      informationProviderSearchWizardKey.stateID.wizardStateID = wizardStateID.wizardStateID;

      informationProviderSearchWizardKey.addressData = getAddressDataFromFields(informationProviderSearchWizardKey.searchKey.addressDtls).addressData;
    } else {
      informationProviderSearchWizardKey.stateID.wizardStateID = wizardPersistentState.create(
        new RegisterInformationProviderState());
    }

    return informationProviderSearchWizardKey;
  }

  // ___________________________________________________________________________
  /**
   * Return the start page for the Register Information Provider wizard.
   *
   * @return WizardStartPage
   */
  public WizardStartPage getRegisterInformationProviderStartPage()
    throws AppException, InformationalException {

    WizardStartPage wizardStartPage = new WizardStartPage();

    wizardStartPage.startPageName = CuramConst.kRegisterInformationProviderWizardStartPage;

    return wizardStartPage;
  }

  // ___________________________________________________________________________
  /**
   * Returns the wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getRegisterInformationProviderWizard()
    throws AppException, InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kRegisterInformationProviderWizardProperties;

    return wizardProperties;
  }

  // ___________________________________________________________________________
  /**
   * Set the participant registration details.
   *
   * @param registrationDtls The participant registration details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return wizardStateID The identifier for the serialized wizard persistence
   * struct.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardResult setRegisterInformationProviderDetails(
    final InformationProviderRegistrationDetails registrationDtls,
    final WizardStateID stateID, final ActionIDProperty actionID) throws AppException,
      InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    ParticipantRegistrationWizardResult participantRegistrationWizardResult = new ParticipantRegistrationWizardResult();

    participantRegistrationWizardResult.wizardStateID = wizardStateID;
    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kSaveAction)) {

      RegisterInformationProviderState registerInformationProviderState = (RegisterInformationProviderState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerInformationProviderState.registrationDtls = registrationDtls;

      InformationProviderRegistrationDetails details = new InformationProviderRegistrationDetails();

      details.infoProvRegistrationDetails = registerInformationProviderState.registrationDtls.infoProvRegistrationDetails;

      InformationProviderRegistrationResult registrationResult = InformationProviderFactory.newInstance().register(
        details);

      participantRegistrationWizardResult.registrationResult.concernRoleID = registrationResult.registrationIDDetails.concernRoleID;
      participantRegistrationWizardResult.registrationResult.alternateID = registrationResult.registrationIDDetails.alternateID;

      wizardPersistentState.remove(stateID.wizardStateID);
    }

    return participantRegistrationWizardResult;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Set the participant duplicate check search criteria.
   *
   * @param searchKey The participant search details.
   * @param stateID The identifier for the wizard persistence record
   * @param actionID The ID for the action that called this method
   *
   * @return RegisterPersonState The serialized wizard persistence struct.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with {@link ParticipantRegistration#setRegisterInformationProviderSearchCriteriaDetails(InformationProviderSearchWizardKey, WizardStateID, ActionIDProperty)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by setRegisterInformationProviderSearchCriteriaDetails(InformationProviderSearchWizardKey, WizardStateID, ActionIDProperty)
   * which returns the informational message along with information provider
   * details as well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public RegisterInformationProviderWizardSearchResult setRegisterInformationProviderSearchCriteria(
    final InformationProviderSearchWizardKey searchKey, final WizardStateID stateID,
    final ActionIDProperty actionID) throws AppException, InformationalException {
    // END, CR00290965
    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateID = new WizardStateID();

    wizardStateID.assign(stateID);

    RegisterInformationProviderWizardSearchResult registerInformationProviderWizardSearchResult = new RegisterInformationProviderWizardSearchResult();

    registerInformationProviderWizardSearchResult.wizardStateID = stateID;

    if (actionID.actionIDProperty.equalsIgnoreCase(CuramConst.kNextPageAction)) {

      RegisterInformationProviderState registerInformationProviderState = (RegisterInformationProviderState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerInformationProviderState.searchKey = searchKey;
      registerInformationProviderState.searchKey.stateID = stateID;

      wizardPersistentState.modify(stateID.wizardStateID,
        registerInformationProviderState);
    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kSearchAction)) {

      ParticipantSearchKey participantSearchKey = new ParticipantSearchKey();

      participantSearchKey.key = searchKey.searchKey;

      ParticipantSearchResult participantSearchResult = InformationProviderFactory.newInstance().search1(
        participantSearchKey);

      registerInformationProviderWizardSearchResult.searchResult = participantSearchResult;

    } else if (actionID.actionIDProperty.equalsIgnoreCase(
      CuramConst.kResetAction)) {

      // BEGIN, CR00304371, PS
      final RegisterInformationProviderState registerInformationProviderState = (RegisterInformationProviderState) wizardPersistentState.read(
        stateID.wizardStateID);

      registerInformationProviderState.searchKey = new InformationProviderSearchWizardKey();

      wizardPersistentState.modify(stateID.wizardStateID,
        registerInformationProviderState);

      // END, CR00304371
    }

    return registerInformationProviderWizardSearchResult;
  }

  // ___________________________________________________________________________
  /**
   * Return the start page for the Register Utility wizard.
   *
   * @return WizardStartPage
   */
  public WizardStartPage getRegisterUtilityStartPage() throws AppException,
      InformationalException {

    WizardStartPage wizardStartPage = new WizardStartPage();

    wizardStartPage.startPageName = CuramConst.kRegisterUtilityWizardStartPage;

    return wizardStartPage;
  }

  // ___________________________________________________________________________
  /**
   * When the wizard is cancelled the wizard state should be removed.
   *
   * @param WizardStateID
   */
  public void cancelWizardState(final WizardStateID wizardStateID,
    final ActionIDProperty actionID)
    throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    wizardPersistentState.remove(wizardStateID.wizardStateID);

  }

  // BEGIN, CR00232051, ZV
  // ___________________________________________________________________________
  /**
   * Method to return participant role type list on registering new participant
   * role for existing participant. List should exclude already registered
   * participant role type.
   *
   * @param key Contains existing concern role id
   *
   * @return Participant role type list to register new participant role
   */
  public ParticipantRoleTypeList getRegisterParticipantRoleTypeList(
    final ConcernRoleKey key)
    throws AppException, InformationalException {

    MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory.newInstance();

    return maintainConcernRoleDetailsObj.getRegisterParticipantRoleTypeList(key);
  }

  // ___________________________________________________________________________
  /**
   * Method to set participant role type for registering new participant for
   * existing one.
   *
   * @param key Contains selected concern role type
   *
   * @return Selected concern role type for new participant registration
   */
  public ConcernRoleTypeDetails setRegisterParticipantRoleType(
    final ConcernRoleTypeDetails details)
    throws AppException, InformationalException {

    return details;
  }

  // END, CR00232051

  // BEGIN, CR00243194, MC
  // __________________________________________________________________________
  /**
   * Returns the Register Prospect as Person wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getRegisterProspectAsPersonWizard()
    throws AppException, InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    // BEGIN, CR00356064, BD
    if (PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {
      wizardProperties.wizardMenu = CuramConst.kRegisterProspectAsPersonForPDCWizard;
    } else {
      wizardProperties.wizardMenu = CuramConst.kRegisterProspectAsPersonWizard;  
    }
    // END, CR00356064

    return wizardProperties;
  }

  // END, CR00243194
  // BEGIN, CR00243789, MC
  // __________________________________________________________________________
  /**
   * Returns the Register Prospect as Employer wizard properties file.
   *
   * @return The wizard properties file.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public WizardProperties getRegisterProspectAsEmployerWizard()
    throws AppException, InformationalException {

    WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kRegisterProspectAsEmployerWizard;

    return wizardProperties;
  }

  // END, CR00243789

  // BEGIN, CR00282028, IBM
  /**
   * Search prospect employer details by specified search criteria.
   *
   * @param employerSearchWizardKey
   * contains employer search wizard key
   *
   * @return employer details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public EmployerSearchDetailsResult searchProspectEmployerDetails(
    final EmployerSearchWizardKey employerSearchWizardKey) throws AppException, InformationalException {

    EmployerSearchDetailsResult employerSearchDetailsResult = new EmployerSearchDetailsResult();

    EmployerSearchKey1 employerSearchKey1 = new EmployerSearchKey1();

    employerSearchKey1.key = employerSearchWizardKey.searchKey.key;

    employerSearchDetailsResult = ProspectEmployerFactory.newInstance().searchEmployerDetails(
      employerSearchKey1);

    return employerSearchDetailsResult;
  }

  /**
   * Set the prospect employer search details.
   *
   * @param employerSearchWizardKey
   * contains participant search key.
   * @param wizardStateID
   * contains wizard state Id
   * @param actionIDProperty
   * contains action Id property details
   *
   * @return employer wizard search details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RegisterEmployerWizardSearchDetails setAddProspectEmployerSearchCriteriaDetails(
    final EmployerSearchWizardKey employerSearchWizardKey, final WizardStateID wizardStateID,
    final ActionIDProperty actionIDProperty) throws AppException,
      InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateIDObj = new WizardStateID();

    wizardStateIDObj.assign(wizardStateID);

    RegisterEmployerWizardSearchDetails registerEmployerWizardSearchDetails = new RegisterEmployerWizardSearchDetails();

    registerEmployerWizardSearchDetails.wizardStateID = wizardStateID;

    if (CuramConst.kNextPageAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      AddProspectEmployerState addProspectEmployerState = (AddProspectEmployerState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      addProspectEmployerState.searchKey = employerSearchWizardKey;
      addProspectEmployerState.searchKey.stateID = wizardStateID;

      wizardPersistentState.modify(wizardStateIDObj.wizardStateID,
        addProspectEmployerState);
    } else if (CuramConst.kSearchAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      registerEmployerWizardSearchDetails.searchResult = searchProspectEmployerDetails(
        employerSearchWizardKey);
    } else if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      AddProspectEmployerState addProspectEmployerState = (AddProspectEmployerState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      addProspectEmployerState.searchKey = new EmployerSearchWizardKey();

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        addProspectEmployerState);
    }
    return registerEmployerWizardSearchDetails;
  }

  /**
   * Search employer details by specified search criteria.
   *
   * @param employerSearchWizardKey
   * contains employer search wizard key
   *
   * @return employer details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public EmployerSearchDetailsResult searchEmployerDetails(
    final EmployerSearchWizardKey employerSearchWizardKey)
    throws AppException, InformationalException {

    EmployerSearchDetailsResult employerSearchDetailsResult = new EmployerSearchDetailsResult();

    EmployerSearchKey1 employerSearchKey1 = new EmployerSearchKey1();

    employerSearchKey1 = employerSearchWizardKey.searchKey;

    employerSearchDetailsResult = EmployerFactory.newInstance().searchEmployer(
      employerSearchKey1);

    return employerSearchDetailsResult;
  }

  /**
   * Set the employer search details.
   *
   * @param employerSearchWizardKey
   * contains participant search key.
   * @param wizardStateID
   * contains wizard state Id
   * @param actionIDProperty
   * contains action Id property details
   *
   * @return employer details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RegisterEmployerWizardSearchDetails setRegisterEmployerSearchCriteriaDetails(
    final EmployerSearchWizardKey employerSearchWizardKey, final WizardStateID wizardStateID,
    final ActionIDProperty actionIDProperty) throws AppException,
      InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateIDObj = new WizardStateID();

    wizardStateIDObj.assign(wizardStateID);

    RegisterEmployerWizardSearchDetails registerEmployerWizardSearchDetails = new RegisterEmployerWizardSearchDetails();

    registerEmployerWizardSearchDetails.wizardStateID = wizardStateID;

    if (CuramConst.kNextPageAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterEmployerState registerEmployerState = (RegisterEmployerState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerEmployerState.searchKey = employerSearchWizardKey;
      registerEmployerState.searchKey.stateID = wizardStateID;

      wizardPersistentState.modify(wizardStateIDObj.wizardStateID,
        registerEmployerState);
    } else if (CuramConst.kSearchAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      registerEmployerWizardSearchDetails.searchResult = searchEmployerDetails(
        employerSearchWizardKey);
    } else if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterEmployerState registerEmployerState = (RegisterEmployerState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerEmployerState.searchKey = new EmployerSearchWizardKey();

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerEmployerState);
    }

    return registerEmployerWizardSearchDetails;
  }

  /**
   * Search person details by provided search criteria.
   *
   * @param personSearchWizardKey
   * contains person search wizard key
   *
   * @return person search details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PersonSearchDetailsResult searchPersonDetails(
    final PersonSearchWizardKey personSearchWizardKey) throws AppException,
      InformationalException {

    PersonSearchDetailsResult personSearchResult = new PersonSearchDetailsResult();

    PersonSearchKey1 personSearchKey1 = new PersonSearchKey1();

    personSearchKey1.personSearchKey = personSearchWizardKey.searchKey;

    personSearchResult = PersonFactory.newInstance().searchPerson(
      personSearchKey1);

    return personSearchResult;
  }

  /**
   * Search prospect person details by given search wizard key.
   *
   * @param personSearchWizardKey
   * contains person search criteria
   *
   * @return person search details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PersonSearchDetailsResult searchProspectPersonDetails(
    final PersonSearchWizardKey personSearchWizardKey) throws AppException, InformationalException {

    PersonSearchDetailsResult personSearchResult = new PersonSearchDetailsResult();

    PersonSearchKey1 personSearchKey1 = new PersonSearchKey1();

    personSearchKey1.personSearchKey = personSearchWizardKey.searchKey;

    personSearchResult = PersonFactory.newInstance().searchPerson(
      personSearchKey1);

    return personSearchResult;
  }

  /**
   * Set the search key for given person search wizard.
   *
   * @param actionIDProperty
   * contains action Id property details
   *
   * @param personSearchWizardKey
   * contains participant search key.
   * @param wizardStateID
   * contains wizard state Id
   * @return person wizard details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RegisterPersonWizardSearchDetails setAddProspectPersonSearchCriteriaDetails(
    final PersonSearchWizardKey personSearchWizardKey, final WizardStateID wizardStateID, final ActionIDProperty actionID)
    throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateIDObj = new WizardStateID();

    wizardStateIDObj.assign(wizardStateID);
    RegisterPersonWizardSearchDetails registerPersonWizardSearchResult = new RegisterPersonWizardSearchDetails();

    registerPersonWizardSearchResult.wizardStateID = wizardStateID;

    if (CuramConst.kNextPageAction.equalsIgnoreCase(actionID.actionIDProperty)) {

      AddProspectPersonState addProspectPersonState = (AddProspectPersonState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      addProspectPersonState.searchKey = personSearchWizardKey;
      addProspectPersonState.searchKey.stateID = wizardStateID;

      wizardPersistentState.modify(wizardStateIDObj.wizardStateID,
        addProspectPersonState);
    } else if (CuramConst.kSearchAction.equalsIgnoreCase(
      actionID.actionIDProperty)) {
      registerPersonWizardSearchResult.searchResult = searchPersonDetails(
        personSearchWizardKey);
    } else if (CuramConst.kResetAction.equalsIgnoreCase(
      actionID.actionIDProperty)) {

      AddProspectPersonState addProspectPersonState = (AddProspectPersonState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      addProspectPersonState.searchKey = new PersonSearchWizardKey();

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        addProspectPersonState);
    }

    return registerPersonWizardSearchResult;
  }

  /**
   * Sets the register person details by given search wizard.
   *
   * @param personSearchWizardKey
   * contains participant search key.
   * @param wizardStateID
   * contains wizard state Id
   * @param actionIDProperty
   * contains action Id property details
   *
   * @return person wizard details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RegisterPersonWizardSearchDetails setRegisterPersonSearchCriteriaDetails(
    final PersonSearchWizardKey personSearchWizardKey, final WizardStateID wizardStateID,
    final ActionIDProperty actionIDProperty) throws AppException,
      InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateIDObj = new WizardStateID();

    wizardStateIDObj.assign(wizardStateID);

    RegisterPersonWizardSearchDetails registerPersonWizardSearchResult = new RegisterPersonWizardSearchDetails();

    registerPersonWizardSearchResult.wizardStateID = wizardStateID;

    if (CuramConst.kNextPageAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterPersonState registerPersonState = (RegisterPersonState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerPersonState.searchKey = personSearchWizardKey;
      registerPersonState.searchKey.stateID = wizardStateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerPersonState);
    } else if (CuramConst.kSearchAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      registerPersonWizardSearchResult.searchResult = searchPersonDetails(
        personSearchWizardKey);

    } else if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterPersonState registerPersonState = (RegisterPersonState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerPersonState.searchKey = new PersonSearchWizardKey();

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerPersonState);
    }

    return registerPersonWizardSearchResult;
  }

  // END, CR00282028

  // BEGIN, CR00290965, IBM
  /**
   * Searches for an educational institute details by specified search criteria.
   *
   * @param educationalInstituteSearchWizardKey contains education institute search key
   *
   * @return participant search details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantSearchDetails searchEducationInstituteDetails(
    final EducationalInstituteSearchWizardKey educationalInstituteSearchWizardKey)
    throws AppException, InformationalException {

    ParticipantSearchDetails participantSearchDetails = new ParticipantSearchDetails();

    EducationalInstituteSearchKey educationalInstituteSearchKey = new EducationalInstituteSearchKey();

    educationalInstituteSearchKey = educationalInstituteSearchWizardKey.instituteType;

    participantSearchDetails = EducationalInstituteFactory.newInstance().searchEducationalInstitute(
      educationalInstituteSearchKey);

    return participantSearchDetails;
  }

  /**
   * Set the educational institute details for given search wizard key.
   *
   * @param educationalInstituteSearchWizardKey contains educational institute search key.
   * @param wizardStateID contains wizard state Id
   * @param actionIDProperty contains action Id property details
   *
   * @return educational institute search details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardSearchDetails setRegisterEducationalInstituteSearchCriteriaDetails(
    final EducationalInstituteSearchWizardKey educationalInstituteSearchWizardKey,
    final WizardStateID wizardStateID, final ActionIDProperty actionIDProperty)
    throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateIDObj = new WizardStateID();

    wizardStateIDObj.assign(wizardStateID);

    ParticipantRegistrationWizardSearchDetails participantRegistrationWizardSearchDetails = new ParticipantRegistrationWizardSearchDetails();

    participantRegistrationWizardSearchDetails.wizardStateID = wizardStateID;

    if (CuramConst.kNextPageAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterEducationalInstituteState registerEducationalInstituteState = (RegisterEducationalInstituteState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerEducationalInstituteState.searchKey = educationalInstituteSearchWizardKey;
      registerEducationalInstituteState.searchKey.stateID = wizardStateID;

      wizardPersistentState.modify(wizardStateIDObj.wizardStateID,
        registerEducationalInstituteState);
    } else if (CuramConst.kSearchAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      participantRegistrationWizardSearchDetails.searchResult = searchEducationInstituteDetails(
        educationalInstituteSearchWizardKey);
    } else if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterEducationalInstituteState registerEducationalInstituteState = (RegisterEducationalInstituteState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerEducationalInstituteState.searchKey = new EducationalInstituteSearchWizardKey();

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerEducationalInstituteState);
    }

    return participantRegistrationWizardSearchDetails;
  }

  /**
   * Search product provider details by specified search criteria.
   *
   * @param participantSearchWizardKey contains product provider search key.
   *
   * @return participant search details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantSearchDetails searchProductProviderDetails(
    final ParticipantSearchWizardKey participantSearchWizardKey) throws AppException,
      InformationalException {

    ParticipantSearchDetails participantSearchDetails = new ParticipantSearchDetails();

    ParticipantSearchKey participantSearchKey = new ParticipantSearchKey();

    participantSearchKey.key = participantSearchWizardKey.searchKey;

    participantSearchDetails = ProductProviderFactory.newInstance().searchProductProvider(
      participantSearchKey);

    return participantSearchDetails;
  }

  /**
   * Set the information provider details for given an information provider search wizard.
   *
   * @param informationProviderSearchWizardKey contains information provider search key.
   * @param wizardStateID contains wizard state Id
   * @param actionIDProperty contains action Id property details
   *
   * @return information provider details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public RegisterInformationProviderWizardSearchDetails setRegisterInformationProviderSearchCriteriaDetails(
    final InformationProviderSearchWizardKey informationProviderSearchWizardKey, final WizardStateID wizardStateID,
    final ActionIDProperty actionIDProperty) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateIDObj = new WizardStateID();

    wizardStateIDObj.assign(wizardStateID);

    RegisterInformationProviderWizardSearchDetails registerInformationProviderWizardSearchDetails = new RegisterInformationProviderWizardSearchDetails();

    registerInformationProviderWizardSearchDetails.wizardStateID = wizardStateID;

    if (CuramConst.kNextPageAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterInformationProviderState registerInformationProviderState = (RegisterInformationProviderState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerInformationProviderState.searchKey = informationProviderSearchWizardKey;
      registerInformationProviderState.searchKey.stateID = wizardStateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerInformationProviderState);
    } else if (CuramConst.kSearchAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      ParticipantSearchKey participantSearchKey = new ParticipantSearchKey();

      participantSearchKey.key = informationProviderSearchWizardKey.searchKey;

      ParticipantSearchDetails participantSearchDetails = InformationProviderFactory.newInstance().searchInformationProvider(
        participantSearchKey);

      registerInformationProviderWizardSearchDetails.searchResult = participantSearchDetails;

    } else if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      // BEGIN, CR00304371, PS
      final RegisterInformationProviderState registerInformationProviderState = (RegisterInformationProviderState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerInformationProviderState.searchKey = new InformationProviderSearchWizardKey();

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerInformationProviderState);

      // END, CR00304371
    }

    return registerInformationProviderWizardSearchDetails;
  }

  /**
   * Set the product provider details for given product provider search wizard.
   *
   * @param participantSearchWizardKey contains product provider search key
   * @param wizardStateID contains wizard state Id
   * @param actionIDProperty contains action Id property details
   *
   * @return product provider details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardSearchDetails setRegisterProductProviderSearchCriteriaDetails(
    final ParticipantSearchWizardKey participantSearchWizardKey, final WizardStateID wizardStateID,
    final ActionIDProperty actionIDProperty) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateIDObj = new WizardStateID();

    wizardStateIDObj.assign(wizardStateID);

    ParticipantRegistrationWizardSearchDetails participantRegistrationWizardSearchDetails = new ParticipantRegistrationWizardSearchDetails();

    participantRegistrationWizardSearchDetails.wizardStateID = wizardStateID;

    if (CuramConst.kNextPageAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterProductProviderState registerProductProviderState = (RegisterProductProviderState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerProductProviderState.searchKey = participantSearchWizardKey;
      registerProductProviderState.searchKey.stateID = wizardStateID;

      wizardPersistentState.modify(wizardStateIDObj.wizardStateID,
        registerProductProviderState);

    } else if (CuramConst.kSearchAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      participantRegistrationWizardSearchDetails.searchResult = searchProductProviderDetails(
        participantSearchWizardKey);
    } else if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterProductProviderState registerProductProviderState = (RegisterProductProviderState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerProductProviderState.searchKey = new ParticipantSearchWizardKey();

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerProductProviderState);
    }
    return participantRegistrationWizardSearchDetails;
  }

  /**
   * Searches for a service supplier by specified search criteria.
   *
   * @param participantSearchWizardKey contains participant search wizard key
   *
   * @return participant search details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantSearchDetails searchServiceSupplierDetails(
    final ParticipantSearchWizardKey participantSearchWizardKey) throws AppException,
      InformationalException {

    ParticipantSearchDetails participantSearchDetails = new ParticipantSearchDetails();

    ParticipantSearchKey participantSearchKey = new ParticipantSearchKey();

    participantSearchKey.key = participantSearchWizardKey.searchKey;

    participantSearchDetails = ServiceSupplierFactory.newInstance().searchServiceSupplier(
      participantSearchKey);

    return participantSearchDetails;
  }

  /**
   * Searches for an utility details by specified search criteria.
   *
   * @param utilitySearchWizardKey contains participant search wizard key
   *
   * @return participant search details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantSearchDetails searchUtilityDetails(
    final UtilitySearchWizardKey utilitySearchWizardKey) throws AppException, InformationalException {

    ParticipantSearchDetails participantSearchDetails = new ParticipantSearchDetails();

    UtilitySearchKey utilitySearchKey = new UtilitySearchKey();

    utilitySearchKey.key.key = utilitySearchWizardKey.type.key.key;

    participantSearchDetails = UtilityFactory.newInstance().searchUtility(
      utilitySearchKey);

    return participantSearchDetails;
  }

  /**
   * Set the service supplier details for given service supplier search wizard.
   *
   * @param participantSearchWizardKey contains service supplier search key
   * @param wizardStateID contains wizard state Id
   * @param actionIDProperty contains action Id property details
   *
   * @return participant service supplier details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardSearchDetails setRegisterServiceSupplierSearchCriteriaDetails(
    ParticipantSearchWizardKey participantSearchWizardKey, WizardStateID wizardStateID, ActionIDProperty actionIDProperty)
    throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateIDObj = new WizardStateID();

    wizardStateIDObj.assign(wizardStateID);

    ParticipantRegistrationWizardSearchDetails participantRegistrationWizardSearchDetails = new ParticipantRegistrationWizardSearchDetails();

    participantRegistrationWizardSearchDetails.wizardStateID = wizardStateID;

    if (CuramConst.kNextPageAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterServiceSupplierState registerServiceSupplierState = (RegisterServiceSupplierState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerServiceSupplierState.searchKey = participantSearchWizardKey;
      registerServiceSupplierState.searchKey.stateID = wizardStateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerServiceSupplierState);
    } else if (CuramConst.kSearchAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      participantRegistrationWizardSearchDetails.searchResult = searchServiceSupplierDetails(
        participantSearchWizardKey);
    } else if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterServiceSupplierState registerServiceSupplierState = (RegisterServiceSupplierState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerServiceSupplierState.searchKey = new ParticipantSearchWizardKey();

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerServiceSupplierState);
    }

    return participantRegistrationWizardSearchDetails;
  }

  /**
   * Set the utility details for given utility search wizard.
   *
   * @param participantSearchWizardKey contains utility search key
   * @param wizardStateID contains wizard state Id
   * @param actionIDProperty contains action Id property details
   *
   * @return participant utility details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardSearchDetails setRegisterUtilitySearchCriteriaDetails(
    final UtilitySearchWizardKey utilitySearchWizardKey, final WizardStateID wizardStateID,
    final ActionIDProperty actionIDProperty) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateIDObj = new WizardStateID();

    wizardStateIDObj.assign(wizardStateID);

    ParticipantRegistrationWizardSearchDetails participantRegistrationWizardSearchDetails = new ParticipantRegistrationWizardSearchDetails();

    participantRegistrationWizardSearchDetails.wizardStateID = wizardStateID;

    if (CuramConst.kNextPageAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterUtilityState registerUtilityState = (RegisterUtilityState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerUtilityState.searchKey = utilitySearchWizardKey;
      registerUtilityState.searchKey.stateID = wizardStateID;

      wizardPersistentState.modify(wizardStateIDObj.wizardStateID,
        registerUtilityState);
    } else if (CuramConst.kSearchAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      participantRegistrationWizardSearchDetails.searchResult = searchUtilityDetails(
        utilitySearchWizardKey);
    } else if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterUtilityState registerUtilityState = (RegisterUtilityState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerUtilityState.searchKey = new UtilitySearchWizardKey();

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerUtilityState);
    }

    return participantRegistrationWizardSearchDetails;
  }

  /**
   * Searches for an external party by specified search criteria.
   *
   * @param externalPartySearchWizardKey contains external party search key
   *
   * @return external party search details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantSearchDetails searchExternalPartyDetails(
    final ExternalPartySearchWizardKey externalPartySearchWizardKey) throws AppException,
      InformationalException {

    ParticipantSearchDetails participantSearchDetails = new ParticipantSearchDetails();

    ExternalPartySearchKey1 externalPartySearchKey1 = new ExternalPartySearchKey1();

    externalPartySearchKey1 = externalPartySearchWizardKey.searchKey;

    participantSearchDetails = ExternalPartyFactory.newInstance().searchExternalPartyDetails(
      externalPartySearchKey1);

    return participantSearchDetails;
  }

  /**
   * Set the external party details for given search wizard details.
   *
   * @param externalPartySearchWizardKey contains external party search key
   * @param wizardStateID contains wizard state Id
   * @param actionIDProperty contains action Id property details
   *
   * @return external party search details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantRegistrationWizardSearchDetails setRegisterExternalPartySearchCriteriaDetails(
    final ExternalPartySearchWizardKey externalPartySearchWizardKey, final WizardStateID wizardStateID,
    final ActionIDProperty actionIDProperty) throws AppException, InformationalException {

    WizardPersistentState wizardPersistentState = new WizardPersistentState();

    WizardStateID wizardStateIDObj = new WizardStateID();

    wizardStateIDObj.assign(wizardStateID);

    ParticipantRegistrationWizardSearchDetails participantRegistrationWizardSearchDetails = new ParticipantRegistrationWizardSearchDetails();

    participantRegistrationWizardSearchDetails.wizardStateID = wizardStateID;

    if (CuramConst.kNextPageAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterExternalPartyState registerExternalPartyState = (RegisterExternalPartyState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerExternalPartyState.searchKey = externalPartySearchWizardKey;
      registerExternalPartyState.searchKey.stateID = wizardStateID;

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerExternalPartyState);
    } else if (CuramConst.kSearchAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      participantRegistrationWizardSearchDetails.searchResult = searchExternalPartyDetails(
        externalPartySearchWizardKey);
    } else if (CuramConst.kResetAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {

      RegisterExternalPartyState registerExternalPartyState = (RegisterExternalPartyState) wizardPersistentState.read(
        wizardStateID.wizardStateID);

      registerExternalPartyState.searchKey = new ExternalPartySearchWizardKey();

      wizardPersistentState.modify(wizardStateID.wizardStateID,
        registerExternalPartyState);
    }
    return participantRegistrationWizardSearchDetails;
  }
  // END, CR00290965
}
