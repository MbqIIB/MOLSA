/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalrequest.impl;


import com.google.inject.Inject;

import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.APPROVALREQUESTSTATUSEntry;
import curam.codetable.impl.REJECTIONREASONEntry;
import curam.core.fact.UsersFactory;
import curam.core.sl.entity.fact.ApprovalRequestFactory;
import curam.core.sl.entity.struct.ApprovalDetails;
import curam.core.sl.entity.struct.ApprovalRequestDtls;
import curam.core.sl.entity.struct.ApprovalRequestKey;
import curam.core.struct.UsersKey;
import curam.piwrapper.user.impl.UserDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.Date;


/**
 * Implementation class for ApprovalRequest processing. This class implements
 * the mutator and accessor interfaces for ApprovalRequest. Pre and post events
 * are sent for the updates made via this implementation class.
 */
// BEGIN, CR00183334, PS
public class ApprovalRequestImpl extends SingleTableEntityImpl<ApprovalRequestDtls> implements ApprovalRequest {
  // END, CR00183334

  // BEGIN, CR00238677, POH
  @Inject
  protected ApprovalRequestHandlerDAO approvalRequestHandlerDAO;

  @Inject
  protected UserDAO userDAO;
  // END, CR00238677

  @Inject
  protected ApprovalRequestLinkDAO approvalRequestLinkDAO;

  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice.
   */
  protected ApprovalRequestImpl() {// no-arg constructor for use only by Guice.
  }

  // END, CR00183334

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// no implementation.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// no implementation.
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// no implementation.
  }

  /**
   * {@inheritDoc}
   */
  public void submit(final String requestedByUser, final long relatedID,
    final APPROVALRELATEDTYPEEntry relatedType)
    throws InformationalException, AppException {

    // set details
    getDtls().automaticallyApprovedInd = false;
    getDtls().requestedByUser = requestedByUser;
    getDtls().requestedDate = Date.getCurrentDate();
    getDtls().status = APPROVALREQUESTSTATUSEntry.SUBMITTED.getCode();
    getDtls().versionNo = 0;

    // BEGIN, CR00238677, POH
    // invoke the pre submit processing
    approvalRequestHandlerDAO.get(relatedType).preSubmit(
      userDAO.get(requestedByUser), relatedID);
    // END, CR00238677

    // create approval request and approval request link with status
    // SUBMITTED
    // not using persistence infrastructure to update as this is an existing
    // core
    // entity
    curam.core.sl.entity.intf.ApprovalRequest approvalRequest = ApprovalRequestFactory.newInstance();
    ApprovalRequestDtls approvalRequestDtls = new ApprovalRequestDtls();

    approvalRequestDtls.requestedByUser = requestedByUser;
    approvalRequestDtls.requestedDate = Date.getCurrentDate();
    approvalRequestDtls.automaticallyApprovedInd = false;
    approvalRequestDtls.status = APPROVALREQUESTSTATUSEntry.SUBMITTED.getCode();
    approvalRequestDtls.versionNo = 0;
    approvalRequest.insert(approvalRequestDtls);

    getDtls().approvalRequestID = approvalRequestDtls.approvalRequestID;

    // create the approval request link
    approvalRequestLinkDAO.newInstance().createApprovalRequestLink(this,
      relatedID, relatedType);
   
    // BEGIN, CR00238677, POH
    // invoke the post submit processing
    approvalRequestHandlerDAO.get(relatedType).postSubmit(
      userDAO.get(requestedByUser), relatedID);
    // END, CR00238677

  }

  /**
   * {@inheritDoc}
   */
  public void approve(final String approvedByUser, final long relatedID,
    final APPROVALRELATEDTYPEEntry relatedType)
    throws InformationalException, AppException {

    getDtls().status = APPROVALREQUESTSTATUSEntry.APPROVED.getCode();
    getDtls().approvalDecisionByUser = approvedByUser;
    getDtls().approvalDecisionDate = Date.getCurrentDate();
    getDtls().approvalRequestID = approvalRequestLinkDAO.getApprovalRequestID(
      relatedID, relatedType);

    // BEGIN, CR00238677, POH
    // invoke the pre approve processing
    approvalRequestHandlerDAO.get(relatedType).preApprove(
      userDAO.get(approvedByUser), relatedID);
    // END, CR00238677

    // update the approval request state to approved
    // not using persistence infrastructure to update as this is an existing
    // core
    // entity
    curam.core.sl.entity.intf.ApprovalRequest approvalRequest = ApprovalRequestFactory.newInstance();
    ApprovalRequestKey approvalRequestKey = new ApprovalRequestKey();
    ApprovalDetails approvalDetails = new ApprovalDetails();

    approvalRequestKey.approvalRequestID = getDtls().approvalRequestID;
    approvalDetails.approvalDecisionByUser = approvedByUser;
    approvalDetails.approvalDecisionDate = Date.getCurrentDate();
    approvalDetails.automaticallyApprovedInd = false;
    approvalDetails.status = APPROVALREQUESTSTATUSEntry.APPROVED.getCode();
    approvalDetails.versionNo = 1;

    approvalRequest.approve(approvalRequestKey, approvalDetails);

    // approve the approval request link
    approvalRequestLinkDAO.getApprovalRequestLink(relatedID, relatedType).approve();

    // BEGIN, CR00238677, POH
    // invoke the post approve processing
    approvalRequestHandlerDAO.get(relatedType).postApprove(relatedID);
    // END, CR00238677
  }

  /**
   * {@inheritDoc}
   */
  public APPROVALREQUESTSTATUSEntry getStatus() {
    return APPROVALREQUESTSTATUSEntry.get(getDtls().status);
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// None required
  }

  /**
   * {@inheritDoc}
   */
  public APPROVALREQUESTSTATUSEntry getLifecycleState() {
    return APPROVALREQUESTSTATUSEntry.get(getDtls().status);
  }

  /**
   * {@inheritDoc}
   */
  public String getDecision() throws InformationalException, AppException {
    return getDtls().status;
  }

  /**
   * {@inheritDoc}
   */
  public String getDecisionByUserName() {
    return getDtls().approvalDecisionByUser;
  }

  /**
   * {@inheritDoc}
   */
  public Date getDecisionDate() {
    return getDtls().approvalDecisionDate;
  }

  /**
   * {@inheritDoc}
   */
  public String getDecisionUserFullName() throws InformationalException,
      AppException {
    UsersKey usersKey = new UsersKey();

    usersKey.userName = getDtls().approvalDecisionByUser;
    return UsersFactory.newInstance().getFullName(usersKey).fullname;
  }

  /**
   * {@inheritDoc}
   */
  public Date getRequestDate() {
    return getDtls().requestedDate;
  }

  /**
   * {@inheritDoc}
   */
  public String getRequestedByFullname() throws InformationalException,
      AppException {
    UsersKey usersKey = new UsersKey();

    usersKey.userName = getDtls().requestedByUser;
    return UsersFactory.newInstance().getFullName(usersKey).fullname;
  }

  /**
   * {@inheritDoc}
   */
  public String getRequestedByUsername() {
    return getDtls().requestedByUser;
  }

  /**
   * {@inheritDoc}
   */
  public void reject(final String rejectedByUser, final long relatedID,
    final APPROVALRELATEDTYPEEntry relatedType,
    final REJECTIONREASONEntry rejectionReason, final String rejectionComments)
    throws InformationalException, AppException {

    getDtls().status = APPROVALREQUESTSTATUSEntry.REJECTED.getCode();
    getDtls().approvalDecisionByUser = rejectedByUser;
    getDtls().approvalDecisionDate = Date.getCurrentDate();

    // BEGIN, CR00238677, POH
    // invoke the pre reject processing
    approvalRequestHandlerDAO.get(relatedType).preReject(
      userDAO.get(rejectedByUser), relatedID);
    // END, CR00238677

    // modify the approval request to state approved
    // not using persistence infrastructure to update as this is an existing
    // core
    // entity
    curam.core.sl.entity.intf.ApprovalRequest approvalRequest = ApprovalRequestFactory.newInstance();
    ApprovalRequestKey approvalRequestKey = new ApprovalRequestKey();
    ApprovalRequestDtls approvalRequestDtls = new ApprovalRequestDtls();

    approvalRequestKey.approvalRequestID = getDtls().approvalRequestID;
    approvalRequestDtls.approvalRequestID = getDtls().approvalRequestID;
    approvalRequestDtls.approvalDecisionByUser = rejectedByUser;
    approvalRequestDtls.approvalDecisionDate = Date.getCurrentDate();
    approvalRequestDtls.requestedByUser = getDtls().requestedByUser;
    approvalRequestDtls.requestedDate = getDtls().requestedDate;
    approvalRequestDtls.automaticallyApprovedInd = false;
    approvalRequestDtls.status = APPROVALREQUESTSTATUSEntry.REJECTED.getCode();
    approvalRequestDtls.rejectionReason = rejectionReason.getCode();
    approvalRequestDtls.rejectionComments = rejectionComments;
    approvalRequestDtls.versionNo = 1;

    approvalRequest.modify(approvalRequestKey, approvalRequestDtls);

    // reject the approval request link
    approvalRequestLinkDAO.getApprovalRequestLink(relatedID, relatedType).reject();

    // BEGIN, CR00238677, POH
    // invoke the post reject processing
    approvalRequestHandlerDAO.get(relatedType).postReject(relatedID);
    // END, CR00238677
  }

  /**
   * {@inheritDoc}
   */
  public String getApprovalRejectionComments() {
    return getDtls().rejectionComments;
  }

  /**
   * {@inheritDoc}
   */
  public REJECTIONREASONEntry getApprovalRejectionReason() {
    return REJECTIONREASONEntry.get(getDtls().rejectionReason);
  }

  /**
   * Override needed here as persistence infrastructure is not being used to
   * perform updates.
   */
  @Override
  public Long getID() {
    return getDtls().approvalRequestID;
  }
}
