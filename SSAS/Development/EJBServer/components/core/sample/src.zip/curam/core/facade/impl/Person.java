/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.ASSESSMENTTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUSSEARCH;
import curam.codetable.CASETYPECODE;
import curam.codetable.DUPLICATESTATUS;
import curam.codetable.INDIGENOUSGROUPCODE;
import curam.codetable.INDIGENOUSREGIONCODE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RACECODE;
import curam.codetable.SCREENINGNAMECODE;
import curam.codetable.impl.PRODUCTTYPEEntry;
import curam.core.facade.fact.ClientMergeFactory;
import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.fact.ProductDeliveryFactory;
import curam.core.facade.intf.ClientMerge;
import curam.core.facade.intf.Participant;
import curam.core.facade.struct.ActiveBenefitCaseDetails;
import curam.core.facade.struct.AddressString;
import curam.core.facade.struct.AllParticipantSearchDetails;
import curam.core.facade.struct.AllParticipantSearchKey;
import curam.core.facade.struct.AllParticipantSearchResult;
import curam.core.facade.struct.BankAccountListForRedirectionDetails;
import curam.core.facade.struct.BankAccountString;
import curam.core.facade.struct.CancelCommunicationKey;
import curam.core.facade.struct.CancelContactKey;
import curam.core.facade.struct.CancelEducationKey;
import curam.core.facade.struct.CancelEmploymentWorkingHourDetails;
import curam.core.facade.struct.CancelParticipantAddressKey;
import curam.core.facade.struct.CancelParticipantAlternateIDKey;
import curam.core.facade.struct.CancelParticipantBankAccountKey;
import curam.core.facade.struct.CancelParticipantCommunicationExceptionKey;
import curam.core.facade.struct.CancelParticipantEmailAddressKey;
import curam.core.facade.struct.CancelParticipantNoteDetails;
import curam.core.facade.struct.CancelParticipantPhoneNumberKey;
import curam.core.facade.struct.CancelParticipantWebAddressDetails;
import curam.core.facade.struct.CancelPersonForeignResidencyKey;
import curam.core.facade.struct.CancelPersonRelationshipDetailsKey;
import curam.core.facade.struct.CasesByConcernRoleDetails;
import curam.core.facade.struct.ClientPageLink;
import curam.core.facade.struct.CommunicationDetailList;
import curam.core.facade.struct.ConcernRoleIDKey;
import curam.core.facade.struct.ConcernRoleKeyStruct;
import curam.core.facade.struct.ConcernRoleTypeDetails;
import curam.core.facade.struct.ConcernRoleWaitListDetailsList;
import curam.core.facade.struct.ConcernRoleWaitListStructList;
import curam.core.facade.struct.ContactContextDescriptionDetails;
import curam.core.facade.struct.ContactContextDescriptionKey;
import curam.core.facade.struct.CreateContactDetails;
import curam.core.facade.struct.CreateContactFromUnregisteredParticipant;
import curam.core.facade.struct.CreateEmailCommunicationDetails;
import curam.core.facade.struct.CreateEmploymentWorkingHourDetails;
import curam.core.facade.struct.CreateFreeformCommunication;
import curam.core.facade.struct.CreateHomePhoneNumber;
import curam.core.facade.struct.CreateMailingAddress;
import curam.core.facade.struct.CreateParticipantAddressDetails;
import curam.core.facade.struct.CreateParticipantAdminRoleDetails;
import curam.core.facade.struct.CreateParticipantAlternateIDDetails;
import curam.core.facade.struct.CreateParticipantBankAccountDetails;
import curam.core.facade.struct.CreateParticipantEmailAddressDetails;
import curam.core.facade.struct.CreateParticipantPhoneDetails;
import curam.core.facade.struct.CreateTemplateCommunication;
import curam.core.facade.struct.CreateWorkPhoneNumber;
import curam.core.facade.struct.CreatedAlternateNameDetails;
import curam.core.facade.struct.CreatedCitizenshipDetails;
import curam.core.facade.struct.CreatedEducationDetails;
import curam.core.facade.struct.CreatedEmploymentWorkingHourDetails;
import curam.core.facade.struct.CreatedForeignResidencyDetails;
import curam.core.facade.struct.CreatedRelationshipDetails;
import curam.core.facade.struct.EmploymentWorkingHourAndVersionNoList;
import curam.core.facade.struct.EmploymentWorkingHourContextDescription;
import curam.core.facade.struct.EmploymentWorkingHourContextDescriptionKey;
import curam.core.facade.struct.EmploymentWorkingHourKey;
import curam.core.facade.struct.EmploymentWorkingHourList;
import curam.core.facade.struct.EndDeductionDetails;
import curam.core.facade.struct.FormattedAddressList;
import curam.core.facade.struct.FormattedBankAccountList;
import curam.core.facade.struct.IndigenousGroupList;
import curam.core.facade.struct.IndigenousGroupSearchKey;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.InformationalMsgDetailsList;
import curam.core.facade.struct.InsertPrimaryResAddress;
import curam.core.facade.struct.ListActiveBenefitCaseDetails;
import curam.core.facade.struct.ListActiveBenefitCasesKey;
import curam.core.facade.struct.ListCasesByConcernRoleDetails;
import curam.core.facade.struct.ListConcernContactDetails;
import curam.core.facade.struct.ListContactDetails;
import curam.core.facade.struct.ListContactKey;
import curam.core.facade.struct.ListDuplicateParticipantFinancials;
import curam.core.facade.struct.ListDuplicateParticipantInteractionDetails;
import curam.core.facade.struct.ListDuplicateParticipantIssuedPaymentInstrument;
import curam.core.facade.struct.ListEmploymentWorkingHourKey;
import curam.core.facade.struct.ListInteractionDetails;
import curam.core.facade.struct.ListInteractionKey;
import curam.core.facade.struct.ListParticipantFinancials;
import curam.core.facade.struct.ListParticipantFinancials1;
import curam.core.facade.struct.ListParticipantFinancialsKey;
import curam.core.facade.struct.ListParticipantIssuedPaymentInstrument;
import curam.core.facade.struct.ListParticipantTaskKey_eo;
import curam.core.facade.struct.ListTemplateByTypeAndParticipantKey;
import curam.core.facade.struct.ListTemplateByTypeAndParticpant;
import curam.core.facade.struct.MaintainCitizenshipDetails;
import curam.core.facade.struct.MaintainConcernRoleKey;
import curam.core.facade.struct.MaintainParticipantAddressDetails;
import curam.core.facade.struct.MaintainParticipantAlternateIDDetails;
import curam.core.facade.struct.MaintainParticipantBankAccountDetails;
import curam.core.facade.struct.MaintainParticipantBankAccountWithTextSortCodeDetails;
import curam.core.facade.struct.MaintainParticipantCommunicationExceptionDetails;
import curam.core.facade.struct.MaintainParticipantEmailAddressDetails;
import curam.core.facade.struct.MaintainParticipantPhoneDetails;
import curam.core.facade.struct.MaintainPersonAlternativeNameDetails;
import curam.core.facade.struct.MaintainPersonDetails;
import curam.core.facade.struct.MaintainPersonEducationDetails;
import curam.core.facade.struct.MaintainPersonEmploymentDetails;
import curam.core.facade.struct.MaintainPersonForeignResidencyDetails;
import curam.core.facade.struct.MaintainPersonRelationships;
import curam.core.facade.struct.MaintainUtilityPaymentsDetails;
import curam.core.facade.struct.ModifedEmploymentDetails;
import curam.core.facade.struct.ModifiedAddressDetails;
import curam.core.facade.struct.ModifiedAlternateIDDetails;
import curam.core.facade.struct.ModifiedAlternateNameDetails;
import curam.core.facade.struct.ModifiedCitizenshipDetails;
import curam.core.facade.struct.ModifiedEducationDetails;
import curam.core.facade.struct.ModifiedEmploymentWorkingHourDetails;
import curam.core.facade.struct.ModifiedForeignResidencyDetails;
import curam.core.facade.struct.ModifiedRelationshipDetails;
import curam.core.facade.struct.ModifyCommDetails;
import curam.core.facade.struct.ModifyConcernContactDetails;
import curam.core.facade.struct.ModifyContactDetails;
import curam.core.facade.struct.ModifyEmploymentWorkingHourDetails;
import curam.core.facade.struct.ModifyParticipantNoteDetails;
import curam.core.facade.struct.ModifyParticipantNoteDetails1;
import curam.core.facade.struct.ModifySentCommunicationDetails;
import curam.core.facade.struct.ParticipantAddressStringList;
import curam.core.facade.struct.ParticipantAdministratorDetails;
import curam.core.facade.struct.ParticipantAdministratorDetailsList;
import curam.core.facade.struct.ParticipantAssessmentsList;
import curam.core.facade.struct.ParticipantBankAccountRedirectionKey;
import curam.core.facade.struct.ParticipantBankAccountRedirectionKey1;
import curam.core.facade.struct.ParticipantBankAccountStringList;
import curam.core.facade.struct.ParticipantCommunicationKey;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ParticipantContextDetails;
import curam.core.facade.struct.ParticipantContextKey;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.facade.struct.ParticipantInvestigationList;
import curam.core.facade.struct.ParticipantKey;
import curam.core.facade.struct.ParticipantNoteDetails;
import curam.core.facade.struct.ParticipantNoteKey;
import curam.core.facade.struct.ParticipantNoteList;
import curam.core.facade.struct.ParticipantNoteList1;
import curam.core.facade.struct.ParticipantScreeningList;
import curam.core.facade.struct.ParticipantWebAddressDetails;
import curam.core.facade.struct.ParticipantWebAddressKey;
import curam.core.facade.struct.ParticipantWebAddressList;
import curam.core.facade.struct.ParticipantWebAddressListKey;
import curam.core.facade.struct.PersonAlternateIDSearchKey;
import curam.core.facade.struct.PersonDetails;
import curam.core.facade.struct.PersonNameAndAddressDetails;
import curam.core.facade.struct.PersonNameRMDtlsList;
import curam.core.facade.struct.PersonRegistrationResult;
import curam.core.facade.struct.PersonSearchDetailsResult;
import curam.core.facade.struct.PersonSearchKey1;
import curam.core.facade.struct.PersonSearchMaintainConcernRoleKey;
import curam.core.facade.struct.PersonSearchResult1;
import curam.core.facade.struct.PrintCommunicationKey;
import curam.core.facade.struct.RaceCodeList;
import curam.core.facade.struct.ReadActiveBankAccountList;
import curam.core.facade.struct.ReadAddressHistoryList;
import curam.core.facade.struct.ReadAddressHistoryListKey;
import curam.core.facade.struct.ReadAttachmentKey;
import curam.core.facade.struct.ReadCitizenshipDetails;
import curam.core.facade.struct.ReadCitizenshipHistoryList;
import curam.core.facade.struct.ReadCitizenshipHistoryListKey;
import curam.core.facade.struct.ReadCitizenshipList;
import curam.core.facade.struct.ReadCitizenshipListKey;
import curam.core.facade.struct.ReadCommDetails;
import curam.core.facade.struct.ReadCommKey;
import curam.core.facade.struct.ReadCommunicationAttachmentDetails;
import curam.core.facade.struct.ReadConcernContactDetails;
import curam.core.facade.struct.ReadContactDetails;
import curam.core.facade.struct.ReadContactKey;
import curam.core.facade.struct.ReadDuplicateParticipantConcernRoleList;
import curam.core.facade.struct.ReadDuplicateParticipantDeductionList;
import curam.core.facade.struct.ReadEducationDetails;
import curam.core.facade.struct.ReadEducationDetailsList;
import curam.core.facade.struct.ReadEducationHistoryList;
import curam.core.facade.struct.ReadEducationHistoryListKey;
import curam.core.facade.struct.ReadEducationListByConcernKey;
import curam.core.facade.struct.ReadEmploymentDetails;
import curam.core.facade.struct.ReadEmploymentDetailsList;
import curam.core.facade.struct.ReadEmploymentDetailsWithMsgList;
import curam.core.facade.struct.ReadEmploymentHistoryList;
import curam.core.facade.struct.ReadEmploymentHistoryListKey;
import curam.core.facade.struct.ReadEmploymentWorkingHourDetails;
import curam.core.facade.struct.ReadEmploymentWorkingHourHistoryList;
import curam.core.facade.struct.ReadEmploymentWorkingHourHistoryListKey;
import curam.core.facade.struct.ReadInteractionDetails;
import curam.core.facade.struct.ReadInteractionKey;
import curam.core.facade.struct.ReadParticipantActiveAddressList;
import curam.core.facade.struct.ReadParticipantAddressDetails;
import curam.core.facade.struct.ReadParticipantAddressKey;
import curam.core.facade.struct.ReadParticipantAddressList;
import curam.core.facade.struct.ReadParticipantAddressListKey;
import curam.core.facade.struct.ReadParticipantAdminRoleList;
import curam.core.facade.struct.ReadParticipantAdminRoleListKey;
import curam.core.facade.struct.ReadParticipantAltIDHistoryList;
import curam.core.facade.struct.ReadParticipantAltIDHistoryListKey;
import curam.core.facade.struct.ReadParticipantAlternateIDDetails;
import curam.core.facade.struct.ReadParticipantAlternateIDKey;
import curam.core.facade.struct.ReadParticipantAlternateIDList;
import curam.core.facade.struct.ReadParticipantAlternateIDListKey;
import curam.core.facade.struct.ReadParticipantBankAcHistoryList;
import curam.core.facade.struct.ReadParticipantBankAcHistoryListKey;
import curam.core.facade.struct.ReadParticipantBankAccountDetails;
import curam.core.facade.struct.ReadParticipantBankAccountKey;
import curam.core.facade.struct.ReadParticipantBankAccountList;
import curam.core.facade.struct.ReadParticipantBankAccountListKey;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionDetails;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionKey;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionList;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionListKey;
import curam.core.facade.struct.ReadParticipantConcernRoleKey;
import curam.core.facade.struct.ReadParticipantConcernRoleList;
import curam.core.facade.struct.ReadParticipantDeductionList;
import curam.core.facade.struct.ReadParticipantDeductionList1;
import curam.core.facade.struct.ReadParticipantEmailAddressDetails;
import curam.core.facade.struct.ReadParticipantEmailAddressKey;
import curam.core.facade.struct.ReadParticipantEmailAddressList;
import curam.core.facade.struct.ReadParticipantEmailAddressListKey;
import curam.core.facade.struct.ReadParticipantFormattedAddressListKey;
import curam.core.facade.struct.ReadParticipantFormattedBankAccountListKey;
import curam.core.facade.struct.ReadParticipantNoteDetails;
import curam.core.facade.struct.ReadParticipantNoteDetails1;
import curam.core.facade.struct.ReadParticipantPhoneNumberDetails;
import curam.core.facade.struct.ReadParticipantPhoneNumberKey;
import curam.core.facade.struct.ReadParticipantPhoneNumberList;
import curam.core.facade.struct.ReadParticipantPhoneNumberListKey;
import curam.core.facade.struct.ReadParticipantWebAddressDetails;
import curam.core.facade.struct.ReadPersonAlternativeNameListKey;
import curam.core.facade.struct.ReadPersonDetails;
import curam.core.facade.struct.ReadPersonEmploymentListKey;
import curam.core.facade.struct.ReadPersonForeignResidencyDetails;
import curam.core.facade.struct.ReadPersonForeignResidencyDetailsList;
import curam.core.facade.struct.ReadPersonForeignResidencyHistoryList;
import curam.core.facade.struct.ReadPersonForeignResidencyHistoryListKey;
import curam.core.facade.struct.ReadPersonForeignResidencyKey;
import curam.core.facade.struct.ReadPersonForeignResidencyListKey;
import curam.core.facade.struct.ReadPersonHistoryList;
import curam.core.facade.struct.ReadPersonHistoryListKey;
import curam.core.facade.struct.ReadPersonHomeDetails;
import curam.core.facade.struct.ReadPersonHomeDetailsShowTasks;
import curam.core.facade.struct.ReadPersonHomeKey;
import curam.core.facade.struct.ReadPersonKey;
import curam.core.facade.struct.ReadPersonNameDetails;
import curam.core.facade.struct.ReadPersonNameHistoryList;
import curam.core.facade.struct.ReadPersonNameHistoryListKey;
import curam.core.facade.struct.ReadPersonRelationshipDetails;
import curam.core.facade.struct.ReadPersonRelationshipDetailsKey;
import curam.core.facade.struct.ReadPersonRelationshipList;
import curam.core.facade.struct.ReadPersonRelationshipListKey;
import curam.core.facade.struct.ReadRelationshipHistoryList;
import curam.core.facade.struct.ReadRelationshipHistoryListKey;
import curam.core.facade.struct.ReadUtilityPaymentDetails;
import curam.core.facade.struct.ReadUtilityPaymentKey;
import curam.core.facade.struct.ReadUtilityPaymentsList;
import curam.core.facade.struct.ReadUtilityPaymentsListKey;
import curam.core.facade.struct.RecordExistingCommunicationDetails;
import curam.core.facade.struct.SearchCaseDetails;
import curam.core.facade.struct.SearchCaseDetails1;
import curam.core.facade.struct.SearchCaseKey_fo;
import curam.core.facade.struct.SearchCasesByConcernRoleKey;
import curam.core.facade.struct.SearchCasesForDuplicateDetails;
import curam.core.facade.struct.SearchCasesForDuplicateDetails1;
import curam.core.facade.struct.SearchWithNicknames;
import curam.core.facade.struct.SendEmailCommKey;
import curam.core.facade.struct.TasksForConcernAndCaseDetails;
import curam.core.facade.struct.TasksForDuplicateConcernAndCaseDetails;
import curam.core.facade.struct.UpdateBankAccPaymentDtlsKey;
import curam.core.fact.AdminIntegratedCaseFactory;
import curam.core.fact.AlternateNameSnapshotFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CitizenshipSnapshotFactory;
import curam.core.fact.ConcernRoleRelSnapshotFactory;
import curam.core.fact.ConcernRoleRelationshipFactory;
import curam.core.fact.EducationSnapshotFactory;
import curam.core.fact.EmploymentFactory;
import curam.core.fact.EmploymentSnapshotFactory;
import curam.core.fact.ForeignResidencyFactory;
import curam.core.fact.ForeignResidencySnapshotFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.fact.MaintainCitizenshipFactory;
import curam.core.fact.MaintainConcernRoleRelationshipsFactory;
import curam.core.fact.MaintainForeignResidencyFactory;
import curam.core.fact.MaintainPersonEducationFactory;
import curam.core.fact.MaintainPersonEmploymentFactory;
import curam.core.fact.MaintainPersonFactory;
import curam.core.fact.MaintainPersonNamesFactory;
import curam.core.fact.PersonFactory;
import curam.core.fact.PersonSearchRouterFactory;
import curam.core.fact.ProductFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.AdminIntegratedCase;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRoleRelationship;
import curam.core.intf.Employment;
import curam.core.intf.MaintainCase;
import curam.core.intf.MaintainCitizenship;
import curam.core.intf.MaintainConcernRoleRelationships;
import curam.core.intf.MaintainForeignResidency;
import curam.core.intf.MaintainPerson;
import curam.core.intf.MaintainPersonEducation;
import curam.core.intf.MaintainPersonEmployment;
import curam.core.intf.MaintainPersonNames;
import curam.core.intf.PersonSearchRouter;
import curam.core.intf.ProductDelivery;
import curam.core.sl.entity.fact.AssessmentDeliveryFactory;
import curam.core.sl.entity.fact.ConcernRoleDuplicateFactory;
import curam.core.sl.entity.fact.InvestigationDeliveryFactory;
import curam.core.sl.entity.fact.IssueDeliveryFactory;
import curam.core.sl.entity.fact.ScreeningFactory;
import curam.core.sl.entity.intf.AssessmentDelivery;
import curam.core.sl.entity.intf.ConcernRoleDuplicate;
import curam.core.sl.entity.intf.InvestigationDelivery;
import curam.core.sl.entity.intf.IssueDelivery;
import curam.core.sl.entity.intf.Screening;
import curam.core.sl.entity.struct.AssessmentDeliveryKey;
import curam.core.sl.entity.struct.AssessmentTypeDetails;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.ConcernRoleDuplicateDtlsList;
import curam.core.sl.entity.struct.InvestigationDeliveryKey;
import curam.core.sl.entity.struct.InvestigationTypeCode;
import curam.core.sl.entity.struct.IssueDeliveryKey;
import curam.core.sl.entity.struct.IssueTypeCode;
import curam.core.sl.entity.struct.ScreeningName;
import curam.core.sl.entity.struct.SearchByDuplicateConcernRoleIDKey;
import curam.core.sl.fact.EmploymentWorkingHourFactory;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.struct.ECWarningsDtls;
import curam.core.sl.intf.EmploymentWorkingHour;
import curam.core.struct.AdminIntegratedCaseDtls;
import curam.core.struct.AdminIntegratedCaseKey;
import curam.core.struct.AlternateIDSearchKey;
import curam.core.struct.AlternateNameDtls;
import curam.core.struct.AlternateNameKey;
import curam.core.struct.AlternateNameSnapshotDtls;
import curam.core.struct.AlternateNameSnapshotKey;
import curam.core.struct.BankAccountRMDtls;
import curam.core.struct.CaseByConcernRoleIDNotStatusAndStartDateKey;
import curam.core.struct.CaseHeaderConcernRoleDetails1;
import curam.core.struct.CaseHeaderConcernRoleDetailsList1;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderDtlsList;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CasesByConcernRoleIDKey;
import curam.core.struct.CitizenshipDtls;
import curam.core.struct.CitizenshipKey;
import curam.core.struct.CitizenshipSnapshotDtls;
import curam.core.struct.CitizenshipSnapshotKey;
import curam.core.struct.ConcernRoleAlternateReadKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleRelSnapshotDtls;
import curam.core.struct.ConcernRoleRelSnapshotKey;
import curam.core.struct.ConcernRoleRelationshipDtls;
import curam.core.struct.ConcernRoleRelationshipKey;
import curam.core.struct.EducationDtls;
import curam.core.struct.EducationKey;
import curam.core.struct.EducationSnapshotDtls;
import curam.core.struct.EducationSnapshotKey;
import curam.core.struct.EmployerEmployeeNameDetails;
import curam.core.struct.EmployerRepresentativeID;
import curam.core.struct.EmploymentDtls;
import curam.core.struct.EmploymentKey;
import curam.core.struct.EmploymentSnapshotDtls;
import curam.core.struct.EmploymentSnapshotKey;
import curam.core.struct.ForeignResidencyDtls;
import curam.core.struct.ForeignResidencyKey;
import curam.core.struct.ForeignResidencySnapshotDtls;
import curam.core.struct.ForeignResidencySnapshotKey;
import curam.core.struct.GetClientUtilityPaymentItemKey;
import curam.core.struct.HouseholdBudgetItemDtls;
import curam.core.struct.HouseholdBudgetItemKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.IntegratedCaseTypeStruct;
import curam.core.struct.MaintainCitizenshipKey;
import curam.core.struct.MaintainConcernRoleRelationshipDetails;
import curam.core.struct.MaintainConcernRoleRelationshipKey;
import curam.core.struct.MaintainForeignResidencyKey;
import curam.core.struct.MaintainPersonEmploymentKey;
import curam.core.struct.MaintainPersonNameKey;
import curam.core.struct.ModifyClientEvidenceDetails;
import curam.core.struct.ModifyPersonEvidenceDetails;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PersonEmploymentDetails;
import curam.core.struct.PersonKey;
import curam.core.struct.PersonReadDtlsList;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.ProductKey;
import curam.core.struct.ReadClientEvidenceDetails;
import curam.core.struct.ReadConcernRoleKey;
import curam.core.struct.ReadPersonEvidenceDetails;
import curam.core.struct.ReadPersonResult;
import curam.core.struct.RelationshipsByConcernRoleIDKey;
import curam.message.BPOADDRESS;
import curam.message.BPOPERSONREGISTRATION;
import curam.message.GENERALSEARCH;
import curam.message.SEPARATOR;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.entity.struct.ServicePlanTypeStruct;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.CodeTable;
import curam.util.type.StringList;


/**
 * This process class provides the functionality for the Person presentation
 * layer.
 */
public abstract class Person extends curam.core.facade.base.Person {

  // BEGIN, CR00099881, CSH
  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kParamConcernRoleID = XmlMetaDataConst.kParamConcernRoleID;

  // END, CR00099881

  // BEGIN, CR00228524, DJ
  protected static final String kCommaSpace = CuramConst.gkComma
    + CuramConst.gkSpace;
  @Deprecated
  protected static final String kSeparator = SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();
  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;
  protected static final int kMinimumPhoneNumberLength = 3;
  // END, CR00228524

  /**
   * Method returns a list of Person Snapshot details, and the date-of-creation
   * for each Snapshot record.
   *
   * @param key
   * The Person record the snapshots are associated with.
   *
   * @return The list of Person snapshot summary details
   */
  public ReadPersonHistoryList listPersonHistory(ReadPersonHistoryListKey key)
    throws AppException, InformationalException {

    // Return struct
    ReadPersonHistoryList readPersonHistoryList = new ReadPersonHistoryList();

    // Retrieve the list of snap shot summary details
    MaintainPerson maintainPersonObj = MaintainPersonFactory.newInstance();

    readPersonHistoryList.historyDtls = maintainPersonObj.listPersonHistory(
      key.historyKey);

    // Get the context description of the Person Snapshots
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.historyKey.concernRoleID;

    readPersonHistoryList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details
    return readPersonHistoryList;
  }

  // END, CR00061467

  // BEGIN, CR00061307, PCAL
  /**
   * Method returns a list of Relationship Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * The Relationship record the snapshots are associated with.
   *
   * @return The list of Relationship snapshot summary details
   */
  public ReadRelationshipHistoryList listRelationshipHistory(
    ReadRelationshipHistoryListKey key) throws AppException,
      InformationalException {

    // Return struct
    ReadRelationshipHistoryList readRelationshipHistoryList = new ReadRelationshipHistoryList();

    // BEGIN, CR00075874, CR00101199, SSK, VM
    // Read the concern role relationship details to get the concernRoleID
    ConcernRoleRelationshipKey concernRoleRelationshipKey = new ConcernRoleRelationshipKey();
    ConcernRoleRelationship concernRoleRelationshipObj = ConcernRoleRelationshipFactory.newInstance();

    concernRoleRelationshipKey.concernRoleRelationshipID = key.historyKey.concernRoleRelationshipID;

    try {
      ConcernRoleRelationshipDtls concernRoleRelationshipDtls = concernRoleRelationshipObj.read(
        concernRoleRelationshipKey);

      key.historyKey.concernRoleID = concernRoleRelationshipDtls.concernRoleID;

      // BEGIN, CR00227172, PB
      key.historyKey.concernRoleRelationshipID = concernRoleRelationshipDtls.concernRoleRecipRelationID;
      // END, CR00227172


    } catch (RecordNotFoundException rnfe) {

      ConcernRoleRelSnapshotKey concernRoleRelSnapshotKey = new ConcernRoleRelSnapshotKey();

      concernRoleRelSnapshotKey.concernRoleRelshipSnapshotID = key.historyKey.concernRoleRelationshipID;

      ConcernRoleRelSnapshotDtls concernRoleRelSnapshotDtls = ConcernRoleRelSnapshotFactory.newInstance().read(
        concernRoleRelSnapshotKey);

      key.historyKey.concernRoleID = concernRoleRelSnapshotDtls.concernRoleID;
    }
    // END, CR00075874, CR00101199

    // Retrieve the list of snap shot summary details
    MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = MaintainConcernRoleRelationshipsFactory.newInstance();

    readRelationshipHistoryList.historyDtls = maintainConcernRoleRelationshipsObj.listRelationshipHistory(
      key.historyKey);

    // Get the context description of the Relationship Snapshots
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.historyKey.concernRoleID;

    readRelationshipHistoryList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details
    return readRelationshipHistoryList;
  }

  /**
   * Method returns a list of Employment Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * The Employment record the snapshots are associated with.
   *
   * @return The list of Employment snapshot summary details
   */
  public ReadEmploymentHistoryList listEmploymentHistory(
    ReadEmploymentHistoryListKey key) throws AppException,
      InformationalException {

    // Return struct
    ReadEmploymentHistoryList readEmploymentHistoryList = new ReadEmploymentHistoryList();

    // BEGIN, CR00075874, CR00101199, SSK, VM
    // Read the employment details to get the concernRoleID
    Employment employmentObj = EmploymentFactory.newInstance();
    EmploymentKey employmentKey = new EmploymentKey();

    employmentKey.employmentID = key.historyKey.employmentID;

    try {
      EmploymentDtls employmentDtls = employmentObj.read(employmentKey);

      key.historyKey.concernRoleID = employmentDtls.concernRoleID;

    } catch (RecordNotFoundException rnfe) {

      EmploymentSnapshotKey employmentSnapshotKey = new EmploymentSnapshotKey();

      employmentSnapshotKey.employmentSnapshotID = employmentKey.employmentID = key.historyKey.employmentID;

      EmploymentSnapshotDtls employmentSnapshotDtls = EmploymentSnapshotFactory.newInstance().read(
        employmentSnapshotKey);

      key.historyKey.concernRoleID = employmentSnapshotDtls.concernRoleID;
    }
    // END, CR00075874, CR00101199

    // Retrieve the list of snap shot summary details
    MaintainPersonEmployment maintainPersonEmploymentObj = MaintainPersonEmploymentFactory.newInstance();

    readEmploymentHistoryList.historyDtls = maintainPersonEmploymentObj.listEmploymentHistory(
      key.historyKey);

    // Get the context description of the Employment Snapshots
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.historyKey.concernRoleID;

    readEmploymentHistoryList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details
    return readEmploymentHistoryList;
  }

  // END, CR00061307

  // BEGIN, CR00060810, PCAL
  /**
   * Method returns a list of Alternative Name Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * The Alternative Name record the snapshots are associated with.
   *
   * @return The list of Alternative Name snapshot details.
   */
  public ReadPersonNameHistoryList listAlternativeNameHistory(
    ReadPersonNameHistoryListKey key) throws AppException,
      InformationalException {

    // Return struct
    ReadPersonNameHistoryList readPersonNameHistoryList = new ReadPersonNameHistoryList();

    // BEGIN, CR00075874, CR00101199, SSK, VM
    // Read the alternate name details to get the concernRoleID
    AlternateNameKey alternateNameKey = new AlternateNameKey();
    curam.core.intf.AlternateName alternateNameObj = curam.core.fact.AlternateNameFactory.newInstance();

    alternateNameKey.alternateNameID = key.historyKey.alternateNameID;

    try {
      AlternateNameDtls alternateNameDtls = alternateNameObj.read(
        alternateNameKey);

      key.historyKey.concernRoleID = alternateNameDtls.concernRoleID;

    } catch (RecordNotFoundException rnfe) {

      AlternateNameSnapshotKey alternateNameSnapshotKey = new AlternateNameSnapshotKey();

      alternateNameSnapshotKey.alternateNameSnapshotID = key.historyKey.alternateNameID;

      AlternateNameSnapshotDtls alternateNameSnapshotDtls = AlternateNameSnapshotFactory.newInstance().read(
        alternateNameSnapshotKey);

      key.historyKey.concernRoleID = alternateNameSnapshotDtls.concernRoleID;
    }
    // END, CR00075874, CR00101199

    // Retrieve the list of snap shot summary details
    MaintainPersonNames maintainPersonNamesObj = MaintainPersonNamesFactory.newInstance();

    readPersonNameHistoryList.historyDtls = maintainPersonNamesObj.listPersonNameHistory(
      key.historyKey);

    // Get the context description of the Alternate Name records
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.historyKey.concernRoleID;

    readPersonNameHistoryList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details
    return readPersonNameHistoryList;
  }

  /**
   * Method returns a list of Foreign Residency Snapshot summary details, and
   * the date-of-creation for each Snapshot record.
   *
   * @param key
   * The Foreign Residency record the snapshots are associated with.
   *
   * @return The list of Foreign Residency snapshot details
   */
  public ReadPersonForeignResidencyHistoryList listForeignResidencyHistory(
    ReadPersonForeignResidencyHistoryListKey key) throws AppException,
      InformationalException {

    // Return struct
    ReadPersonForeignResidencyHistoryList readPersonForeignResidencyHistoryList = new ReadPersonForeignResidencyHistoryList();

    // BEGIN, CR00075874, CR00101199, SSK, VM
    // Read the foreign residency details to get the concernRoleID
    ForeignResidencyKey foreignResidencyKey = new ForeignResidencyKey();
    curam.core.intf.ForeignResidency foreignResidencyObj = ForeignResidencyFactory.newInstance();

    foreignResidencyKey.foreignResidencyID = key.historyKey.foreignResidencyID;

    try {
      ForeignResidencyDtls foreignResidencyDtls = foreignResidencyObj.read(
        foreignResidencyKey);

      key.historyKey.concernRoleID = foreignResidencyDtls.concernRoleID;

    } catch (RecordNotFoundException rnfe) {

      ForeignResidencySnapshotKey foreignResidencySnapshotKey = new ForeignResidencySnapshotKey();

      foreignResidencySnapshotKey.foreignResSnapshotID = key.historyKey.foreignResidencyID;

      ForeignResidencySnapshotDtls foreignResidencySnapshotDtls = ForeignResidencySnapshotFactory.newInstance().read(
        foreignResidencySnapshotKey);

      key.historyKey.concernRoleID = foreignResidencySnapshotDtls.concernRoleID;
    }
    // END, CR00075874, CR00101199

    // Retrieve the list of snap shot summary details
    MaintainForeignResidency maintainForeignResidencyObj = MaintainForeignResidencyFactory.newInstance();

    readPersonForeignResidencyHistoryList.historyDtls = maintainForeignResidencyObj.listForeignResidencyHistory(
      key.historyKey);

    // Get the context description of the Foreign Residency records.
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.historyKey.concernRoleID;

    readPersonForeignResidencyHistoryList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details
    return readPersonForeignResidencyHistoryList;
  }

  // END, CR00060810

  // BEGIN, CR00060424, PCAL
  /**
   * Method returns a list of Education Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * The educationID of the Education record the snapshots are
   * associated with.
   *
   * @return The list of education snapshot summary details
   */
  public ReadEducationHistoryList listEducationHistory(
    ReadEducationHistoryListKey key) throws AppException,
      InformationalException {

    // Return struct
    ReadEducationHistoryList readEducationHistoryList = new ReadEducationHistoryList();

    // BEGIN, CR00075874, CR00101199, SSK, VM
    // Read the education details to get the concernRoleID
    EducationKey educationKey = new EducationKey();
    curam.core.intf.Education educationObj = curam.core.fact.EducationFactory.newInstance();

    educationKey.educationID = key.historyKey.educationID;

    try {
      EducationDtls educationDtls = educationObj.read(educationKey);

      key.historyKey.concernRoleID = educationDtls.concernRoleID;

    } catch (RecordNotFoundException rnfe) {

      EducationSnapshotKey educationSnapshotKey = new EducationSnapshotKey();

      educationSnapshotKey.educationSnapshotID = key.historyKey.educationID;

      EducationSnapshotDtls educationSnapshotDtls = EducationSnapshotFactory.newInstance().read(
        educationSnapshotKey);

      key.historyKey.concernRoleID = educationSnapshotDtls.concernRoleID;
    }
    // END, CR00075874, CR00101199

    // Retrieve the list of snap shot summary details
    MaintainPersonEducation maintainPersonEducationObj = MaintainPersonEducationFactory.newInstance();

    readEducationHistoryList.historyList = maintainPersonEducationObj.listEducationHistory(
      key.historyKey);

    // Get the context description of the Education record
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.historyKey.concernRoleID;

    readEducationHistoryList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details
    return readEducationHistoryList;
  }

  // END, CR00060424

  /**
   * Sets citizenship record status to canceled.
   *
   * @param key
   * Identifies the citizen's id
   */
  public void cancelCitizenship(
    curam.core.facade.struct.CancelCitizenshipKey key) throws AppException,
      InformationalException {

    // Maintain Citizenship object.
    curam.core.intf.MaintainCitizenship maintainCitizenshipObj = curam.core.fact.MaintainCitizenshipFactory.newInstance();

    // Cancel the citizenship.
    maintainCitizenshipObj.cancelCitizenship(key.cancelCitizenshipKey);

  }

  // BEGIN, CR00077847, POH
  /**
   * Creates a new citizenship record for the specified person.
   *
   * @param details
   * The citizen's information to be inserted
   * @return CreatedCitizenshipDetails List of informationals - if any exist -
   * to be displayed to user
   */
  public CreatedCitizenshipDetails createCitizenship(
    MaintainCitizenshipDetails details) throws AppException,
      InformationalException {

    // return struct
    CreatedCitizenshipDetails createdCitizenshipDetails = new CreatedCitizenshipDetails();

    // Maintain Citizenship object and key.
    curam.core.intf.MaintainCitizenship maintainCitizenshipObj = curam.core.fact.MaintainCitizenshipFactory.newInstance();

    MaintainCitizenshipKey maintainCitizenshipKey = new MaintainCitizenshipKey();

    // Get the Concern Role ID from the key.
    maintainCitizenshipKey.concernRoleID = details.citizenshipDetails.concernRoleID;

    // Create the citizenship record.
    maintainCitizenshipObj.createCitizenship(maintainCitizenshipKey,
      details.citizenshipDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      createdCitizenshipDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return createdCitizenshipDetails;
    // END, CR00077847
  }

  /**
   * Retrieves a list of citizenship details.
   *
   * @param key
   * The concern role ID that citizenship records will be returned for.
   *
   * @return The list of citizenship records read from the database.
   */
  public ReadCitizenshipList listCitizenship(ReadCitizenshipListKey key)
    throws AppException, InformationalException {

    // Maintain Citizenship object.
    curam.core.intf.MaintainCitizenship maintainCitizenshipObj = curam.core.fact.MaintainCitizenshipFactory.newInstance();

    // Details to be returned.
    ReadCitizenshipList readCitizenshipList = new ReadCitizenshipList();

    // Read the list of citizenship records.
    readCitizenshipList.citizenshipRMDtlsList = maintainCitizenshipObj.readmultiByConcernRole(
      key.maintainCitizenshipKey);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.maintainCitizenshipKey.concernRoleID;

    readCitizenshipList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readCitizenshipList;

  }

  // BEGIN, CR00077847, POH
  /**
   * Modifies citizenship details.
   *
   * @param details
   * The citizenship record that will be modified
   * @return ModifiedCitizenshipDetails List of informationals - if any exist -
   * to be returned to the user
   */
  public ModifiedCitizenshipDetails modifyCitizenship(
    MaintainCitizenshipDetails details) throws AppException,
      InformationalException {

    // return struct
    ModifiedCitizenshipDetails modifiedCitizenshipDetails = new ModifiedCitizenshipDetails();

    // Maintain Citizenship object and key.
    curam.core.intf.MaintainCitizenship maintainCitizenshipObj = curam.core.fact.MaintainCitizenshipFactory.newInstance();
    MaintainCitizenshipKey maintainCitizenshipKey = new MaintainCitizenshipKey();

    // Get the concern role ID from the key.
    maintainCitizenshipKey.concernRoleID = details.citizenshipDetails.concernRoleID;

    // Modify the citizenship record.
    maintainCitizenshipObj.modifyCitizenship(maintainCitizenshipKey,
      details.citizenshipDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      modifiedCitizenshipDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return modifiedCitizenshipDetails;
    // END, CR00077847
  }

  /**
   * Reads citizenship details.
   *
   * @param key
   * Identifies the citizenship concerned
   *
   * @return The citizenship details of the person read from the database
   */
  public ReadCitizenshipDetails readCitizenship(
    curam.core.facade.struct.ReadCitizenshipKey key) throws AppException,
      InformationalException {

    // Maintain Citizenship object.
    curam.core.intf.MaintainCitizenship maintainCitizenshipObj = curam.core.fact.MaintainCitizenshipFactory.newInstance();

    // Details to be returned.
    ReadCitizenshipDetails readCitizenshipDetails = new ReadCitizenshipDetails();

    // Read the citizenship details.
    readCitizenshipDetails.citizenshipDetails = maintainCitizenshipObj.readCitizenship(
      key.readCitizenshipKey);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = readCitizenshipDetails.citizenshipDetails.concernRoleID;

    readCitizenshipDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readCitizenshipDetails;

  }

  /**
   * Changes the recordStatus of person alternative name record from Active to
   * Canceled
   *
   * @param key
   * Alternate name identifier.
   */
  public void cancelAlternativeName(
    curam.core.facade.struct.CancelPersonNameKey key) throws AppException,
      InformationalException {

    // Maintain Person Names object.
    curam.core.intf.MaintainPersonNames maintainPersonNamesObj = curam.core.fact.MaintainPersonNamesFactory.newInstance();

    // Cancel the name.
    maintainPersonNamesObj.cancelName(key.cancelPersonNameKey);

  }

  // BEGIN, CR00079172, POH
  /**
   * Creates a new name for the person.
   *
   * @param details
   * The details of the person.
   * @return CreatedAlternateNameDetails List of informationals - if any exist -
   * to be displayed to user
   */
  public CreatedAlternateNameDetails createAlternativeName(
    MaintainPersonAlternativeNameDetails details) throws AppException,
      InformationalException {

    // return struct
    CreatedAlternateNameDetails createdAlternateNameDetails = new CreatedAlternateNameDetails();

    // Maintain Person Names object and key.
    curam.core.intf.MaintainPersonNames maintainPersonNamesObj = curam.core.fact.MaintainPersonNamesFactory.newInstance();

    MaintainPersonNameKey maintainPersonNameKey = new MaintainPersonNameKey();

    // Get the Concern Role ID from the key.
    maintainPersonNameKey.concernRoleID = details.nameDetails.concernRoleID;

    // Create the Alternative Name
    maintainPersonNamesObj.createName(maintainPersonNameKey,
      details.nameDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      createdAlternateNameDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return createdAlternateNameDetails;
    // END, CR00079172
  }

  /**
   * Retrieves a list of name details for the specified person.
   *
   * @param key
   * The person for whom the list of name details will be returned for.
   * @return The list of name details for the person read from the database.
   */
  public PersonNameRMDtlsList listAlternativeName(
    ReadPersonAlternativeNameListKey key) throws AppException,
      InformationalException {

    // Maintain Person Names object.
    curam.core.intf.MaintainPersonNames maintainPersonNamesObj = curam.core.fact.MaintainPersonNamesFactory.newInstance();

    // Details to be returned.
    PersonNameRMDtlsList personNameRMDtlsList = new PersonNameRMDtlsList();

    personNameRMDtlsList.nameRMDtlsList = maintainPersonNamesObj.readmultiByConcernRole(
      key.maintainPersonNameKey);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.maintainPersonNameKey.concernRoleID;

    personNameRMDtlsList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return personNameRMDtlsList;

  }

  // BEGIN, CR00079172, POH
  /**
   * Modifies an existing name for this person.
   *
   * @param details
   * The details of the person to be modified.
   * @return ModifiedAlternateNameDetails List of informationals - if any
   * exist - to be returned to the user
   */
  public ModifiedAlternateNameDetails modifyAlternativeName(
    MaintainPersonAlternativeNameDetails details) throws AppException,
      InformationalException {

    // return struct
    ModifiedAlternateNameDetails modifiedAlternateNameDetails = new ModifiedAlternateNameDetails();
    // Maintain Person Names object and key.
    curam.core.intf.MaintainPersonNames maintainPersonNamesObj = curam.core.fact.MaintainPersonNamesFactory.newInstance();

    MaintainPersonNameKey maintainPersonNameKey = new MaintainPersonNameKey();

    // Get the Concern Role ID from the details.
    maintainPersonNameKey.concernRoleID = details.nameDetails.concernRoleID;

    // Modify the Alternative Name
    maintainPersonNamesObj.modifyName(maintainPersonNameKey,
      details.nameDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      modifiedAlternateNameDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return modifiedAlternateNameDetails;
    // END, CR00079172
  }

  /**
   * Reads an alternate name for the person.
   *
   * @param key
   * Identifies person we have to deal with
   *
   * @return The alternate names read from the database.
   */
  public ReadPersonNameDetails readAlternativeName(
    curam.core.facade.struct.ReadPersonNameKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00060810, PCAL
    // Details to be returned.
    ReadPersonNameDetails readPersonNameDetails = new ReadPersonNameDetails();

    // Read the Name Details
    curam.core.intf.MaintainPersonNames maintainPersonNamesObj = curam.core.fact.MaintainPersonNamesFactory.newInstance();

    readPersonNameDetails.nameDetails = maintainPersonNamesObj.readName(
      key.readPersonNameKey);

    // Get the context description for the concern role
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = readPersonNameDetails.nameDetails.concernRoleID;

    readPersonNameDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readPersonNameDetails;
  }

  /**
   * Sets Foreign Residency status to canceled.
   *
   * @param key
   * The Foreign Residency ID of the record to be canceled.
   */
  public void cancelForeignResidency(CancelPersonForeignResidencyKey key)
    throws AppException, InformationalException {

    // Maintain Foreign Residency object.
    curam.core.intf.MaintainForeignResidency maintainForeignResidencyObj = curam.core.fact.MaintainForeignResidencyFactory.newInstance();

    // Cancel the Foreign Residency.
    maintainForeignResidencyObj.cancelForeignResidency(
      key.cancelForeignResidencyKey);

  }

  // BEGIN, CR00077847, POH
  /**
   * Creates a new Foreign Residency record for the specified person.
   *
   * @param details
   * The Foreign Residency information to be inserted.
   * @return CreatedForeignResidencyDetails List of informationals - if any
   * exist - to be displayed to user
   */
  public CreatedForeignResidencyDetails createForeignResidency(
    MaintainPersonForeignResidencyDetails details) throws AppException,
      InformationalException {

    // return struct
    CreatedForeignResidencyDetails createdForeignResidencyDetails = new CreatedForeignResidencyDetails();

    // Maintain Foreign Residency object and key.
    curam.core.intf.MaintainForeignResidency maintainForeignResidencyObj = curam.core.fact.MaintainForeignResidencyFactory.newInstance();
    MaintainForeignResidencyKey maintainForeignResidencyKey = new MaintainForeignResidencyKey();

    // Get the Concern Role ID from the key.
    maintainForeignResidencyKey.concernRoleID = details.foreignResidencyDetails.concernRoleID;

    // Create the Foreign Residency record.
    maintainForeignResidencyObj.createForeignResidency(
      maintainForeignResidencyKey, details.foreignResidencyDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      createdForeignResidencyDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return createdForeignResidencyDetails;
  }

  // END, CR00077847

  /**
   * Retrieves a list of Foreign Residency details.
   *
   * @param key
   * The concern role ID that Foreign Residency records will be
   * returned for
   *
   * @return The list of foreign residency details.
   */
  public ReadPersonForeignResidencyDetailsList listForeignResidency(
    ReadPersonForeignResidencyListKey key) throws AppException,
      InformationalException {

    // Maintain Foreign Residency object.
    curam.core.intf.MaintainForeignResidency maintainForeignResidencyObj = curam.core.fact.MaintainForeignResidencyFactory.newInstance();

    // Details to be returned.
    ReadPersonForeignResidencyDetailsList readPersonForeignResidencyDetailsList = new ReadPersonForeignResidencyDetailsList();

    // Read the list of Foreign Residency records.
    readPersonForeignResidencyDetailsList.foreignResidencyRMDtlsList = maintainForeignResidencyObj.readmultiByConcernRole(
      key.maintainForeignResidencyKey);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.maintainForeignResidencyKey.concernRoleID;

    readPersonForeignResidencyDetailsList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readPersonForeignResidencyDetailsList;
  }

  // BEGIN, CR00077847, POH
  /**
   * Modifies Foreign Residency details.
   *
   * @param details
   * The Foreign Residency details that will be modified.
   */
  public ModifiedForeignResidencyDetails modifyForeignResidency(
    MaintainPersonForeignResidencyDetails details) throws AppException,
      InformationalException {

    // return struct
    ModifiedForeignResidencyDetails modifiedForeignResidencyDetails = new ModifiedForeignResidencyDetails();

    // Maintain Foreign Residency object and key.
    curam.core.intf.MaintainForeignResidency maintainForeignResidencyObj = curam.core.fact.MaintainForeignResidencyFactory.newInstance();
    MaintainForeignResidencyKey maintainForeignResidencyKey = new MaintainForeignResidencyKey();

    // Get the concern role ID from the key.
    maintainForeignResidencyKey.concernRoleID = details.foreignResidencyDetails.concernRoleID;

    // Modify the Foreign Residency record.
    maintainForeignResidencyObj.modifyForeignResidency(
      maintainForeignResidencyKey, details.foreignResidencyDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      modifiedForeignResidencyDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return modifiedForeignResidencyDetails;

  }

  // END, CR00077847

  /**
   * Modifies Foreign Residency details.
   *
   * @param key
   * The Foreign Residency ID that details will be returned for
   *
   * @return The foreign residency details read from the database.
   */
  public ReadPersonForeignResidencyDetails readForeignResidency(
    ReadPersonForeignResidencyKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00060810, PCAL
    // Details to be returned.
    ReadPersonForeignResidencyDetails readPersonForeignResidencyDetails = new ReadPersonForeignResidencyDetails();

    // Read the Foreign Residency details.
    curam.core.intf.MaintainForeignResidency maintainForeignResidencyObj = curam.core.fact.MaintainForeignResidencyFactory.newInstance();

    readPersonForeignResidencyDetails.foreignResidencyDetails = maintainForeignResidencyObj.readForeignResidency(
      key.readForeignResidencyKey);

    // Get the context description for the concern role
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = readPersonForeignResidencyDetails.foreignResidencyDetails.concernRoleID;

    readPersonForeignResidencyDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readPersonForeignResidencyDetails;
  }

  // BEGIN, CR00077847, POH
  /**
   * Creates an Education record.
   *
   * @param details
   * The education details to be inserted.
   * @return CreatedEducationDetails List of informationals - if any exist - to
   * be displayed to user
   */
  public CreatedEducationDetails createEducation(
    MaintainPersonEducationDetails details) throws AppException,
      InformationalException {

    // return struct
    CreatedEducationDetails createdEducationDetails = new CreatedEducationDetails();

    // Maintain Person Education object.
    curam.core.intf.MaintainPersonEducation maintainPersonEducationObj = curam.core.fact.MaintainPersonEducationFactory.newInstance();

    // Create the education record.
    maintainPersonEducationObj.createEducation(details.educationDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      createdEducationDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return createdEducationDetails;

  }

  /**
   * Modifies Education details entered.
   *
   * @param details
   * The education details to be updated.
   * @return ModifiedEducationDetails List of informationals - if any exist - to
   * be displayed to user
   */
  public ModifiedEducationDetails modifyEducation(
    MaintainPersonEducationDetails details) throws AppException,
      InformationalException {

    // return struct
    ModifiedEducationDetails modifiedEducationDetails = new ModifiedEducationDetails();
    // Maintain Person Education object
    curam.core.intf.MaintainPersonEducation maintainPersonEducationObj = curam.core.fact.MaintainPersonEducationFactory.newInstance();

    // Modify the education record.
    maintainPersonEducationObj.modifyEducation(details.educationDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      modifiedEducationDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return modifiedEducationDetails;
  }

  // END, CR00077847

  /**
   * Cancels an education record.
   *
   * @param key
   * Identifies the education record to be canceled.
   */
  public void cancelEducation(CancelEducationKey key) throws AppException,
      InformationalException {

    // Maintain Person Education object.
    curam.core.intf.MaintainPersonEducation maintainPersonEducationObj = curam.core.fact.MaintainPersonEducationFactory.newInstance();

    // Cancel the education record.
    maintainPersonEducationObj.cancelEducation(key.educationReadKey);

  }

  /**
   * Searches for education records by concern role ID.
   *
   * @param key
   * The concern role ID that education records will be returned for
   *
   * @return The education records read from the database.
   */
  public ReadEducationDetailsList listEducation(
    ReadEducationListByConcernKey key) throws AppException,
      InformationalException {

    // Maintain Person Education object.
    curam.core.intf.MaintainPersonEducation maintainPersonEducationObj = curam.core.fact.MaintainPersonEducationFactory.newInstance();

    // Details to be returned.
    ReadEducationDetailsList readEducationDetailsList = new ReadEducationDetailsList();

    // Read the list of education records.
    readEducationDetailsList.educationDetailsList = maintainPersonEducationObj.readByConcernRole(
      key.educationByConcernKey);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.educationByConcernKey.concernRoleID;

    readEducationDetailsList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readEducationDetailsList;

  }

  /**
   * Searches for an education record by education ID.
   *
   * @param key
   * The education ID for the education record which will be returned.
   * @return The education record read from the database.
   */
  public ReadEducationDetails readEducation(
    curam.core.facade.struct.EducationReadKey key) throws AppException,
      InformationalException {

    // Maintain Person Education object.
    curam.core.intf.MaintainPersonEducation maintainPersonEducationObj = curam.core.fact.MaintainPersonEducationFactory.newInstance();

    // Details to be returned.
    ReadEducationDetails readEducationDtls = new ReadEducationDetails();

    // Read the education details.
    readEducationDtls.educationDetails = maintainPersonEducationObj.readEducationDetails(
      key.educationReadKey);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = readEducationDtls.educationDetails.concernRoleID;

    readEducationDtls.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readEducationDtls;

  }

  /**
   * Sets person employment record status of the Employment from "Active" to
   * "canceled"
   *
   * @param key
   * The person employment identifier.
   */
  public void cancelEmployment(curam.core.facade.struct.CancelEmploymentKey key)
    throws AppException, InformationalException {

    // Maintain Person Employment object.
    curam.core.intf.MaintainPersonEmployment maintainPersonEmploymentObj = curam.core.fact.MaintainPersonEmploymentFactory.newInstance();

    // Cancel the Employment
    maintainPersonEmploymentObj.cancelEmployment(key.cancelEmploymentKey);

  }

  /**
   * Creates a new employment record for the specified person.
   *
   * @param details
   * The details of the employment to be inserted.
   *
   * @return Informational messages returned from the database.
   */
  public InformationMsgDtlsList createEmployment(
    MaintainPersonEmploymentDetails details) throws AppException,
      InformationalException {

    // Maintain Person Employment object and key.
    curam.core.intf.MaintainPersonEmployment maintainPersonEmploymentObj = curam.core.fact.MaintainPersonEmploymentFactory.newInstance();

    MaintainPersonEmploymentKey maintainPersonEmploymentKey = new MaintainPersonEmploymentKey();

    // Details to be returned.
    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // BEGIN, CR00394680, JMA
    // Employment details
    PersonEmploymentDetails employmentDetails = new PersonEmploymentDetails();

    // Concern role entity objects
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    EmployerRepresentativeID employerRepresentativeID = new EmployerRepresentativeID();

    // Assign employment details
    employmentDetails.assign(details.employmentDetails);

    // Get the employer concern role id from the key
    concernRoleKey.concernRoleID = details.employmentDetails.employerConcernRoleID;

    if (concernRoleKey.concernRoleID != 0) {
      // Read primary alternate ID from ConcernRole
      concernRoleDtls = concernRoleObj.read(concernRoleKey);
      employmentDetails.employerAlternateID = concernRoleDtls.primaryAlternateID;
    }

    // Get the Concern Role ID from the details.
    maintainPersonEmploymentKey.concernRoleID = details.employmentDetails.concernRoleID;

    // Create the Employment Record
    informationMsgDtlsList.informationalMsgDtlsList = maintainPersonEmploymentObj.createEmploymentForPerson(maintainPersonEmploymentKey, employmentDetails, employerRepresentativeID).list;
    // END, CR00394680
    // Return the details.
    return informationMsgDtlsList;
  }

  // BEGIN, CR00077847, POH
  /**
   * Modifies an existing employment of the person.
   *
   * @param details
   * The details of employment to be modified.
   * @return ModifedEmploymentDetails List of informationals - if any exist - to
   * be displayed to user
   */
  public ModifedEmploymentDetails modifyEmployment(
    MaintainPersonEmploymentDetails details) throws AppException,
      InformationalException {

    // return struct
    ModifedEmploymentDetails modifedEmploymentDetails = new ModifedEmploymentDetails();

    // Maintain Person Employment object and key.
    curam.core.intf.MaintainPersonEmployment maintainPersonEmploymentObj = curam.core.fact.MaintainPersonEmploymentFactory.newInstance();

    MaintainPersonEmploymentKey maintainPersonEmploymentKey = new MaintainPersonEmploymentKey();

    // Employment details
    PersonEmploymentDetails employmentDetails = new PersonEmploymentDetails();

    // Concern role entity objects
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // Assign employment details
    employmentDetails.assign(details.employmentDetails);

    // Get the employer concern role id from the key
    concernRoleKey.concernRoleID = details.employmentDetails.employerConcernRoleID;

    // Read primary alternate ID from ConcernRole
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    employmentDetails.employerAlternateID = concernRoleDtls.primaryAlternateID;

    // Get the Concern Role ID from the details.
    maintainPersonEmploymentKey.concernRoleID = details.employmentDetails.concernRoleID;

    // Modify the Employment Record
    maintainPersonEmploymentObj.modifyPersonEmployment(
      maintainPersonEmploymentKey, employmentDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      modifedEmploymentDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return modifedEmploymentDetails;
  }

  // END, CR00077847

  // BEGIN, CR00178447, PM
  /**
   * Reads a list of existing employments for the person.
   *
   * @param key
   * Identifies the person for whom the employments will be returned
   *
   * @return The list of employments read from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated since Curam 5.2 SP3, replaced with {@link
   * Person#listEmployment1(ReadPersonEmploymentListKey)}.
   * <p>
   * This method is being deprecated because it is not returning any
   * informational message. So the new method listEmployment1() displays an
   * informational message if the end date has passed on the primary employment
   * record. See release note: CS-07331/CR00178447.
   */
  @Deprecated
  // END, CR00178447
  public ReadEmploymentDetailsList listEmployment(
    ReadPersonEmploymentListKey key) throws AppException,
      InformationalException {

    // Maintain Person Employment object.
    MaintainPersonEmployment maintainPersonEmploymentObj = MaintainPersonEmploymentFactory.newInstance();

    // Details to be returned.
    ReadEmploymentDetailsList readEmploymentDetailsList = new ReadEmploymentDetailsList();

    // Read list of employments.
    readEmploymentDetailsList.readMultiByConcernRoleIDEmplResult = maintainPersonEmploymentObj.readmultiByConcernRoleID(
      key.maintainPersonEmploymentKey);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.maintainPersonEmploymentKey.concernRoleID;

    readEmploymentDetailsList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readEmploymentDetailsList;
  }

  // BEGIN, CR00178447, PM
  /**
   * This method replaces the deprecated method {@link
   * Person#listEmployment(ReadPersonEmploymentListKey)}.
   * <p>
   * This method lists all the employment records which belongs to the specified
   * person. It also displays an informational message if the end date has
   * passed on the primary employment record.
   *
   * @param key
   * Identifies the person for whom the employments will be returned.
   *
   * @return The list of employments with informational messages read from
   * the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReadEmploymentDetailsWithMsgList listEmployment1(
    ReadPersonEmploymentListKey key) throws AppException,
      InformationalException {

    curam.core.intf.MaintainPersonEmployment maintainPersonEmploymentObj = curam.core.fact.MaintainPersonEmploymentFactory.newInstance();

    ReadEmploymentDetailsWithMsgList readEmploymentDetailsWIthMsgList = new ReadEmploymentDetailsWithMsgList();

    // Read list of employments.
    readEmploymentDetailsWIthMsgList.readMultiByConcernRoleIDEmplResult = maintainPersonEmploymentObj.readmultiByConcernRoleID(
      key.maintainPersonEmploymentKey);

    ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.maintainPersonEmploymentKey.concernRoleID;
    // Get the context description for the concern role.
    readEmploymentDetailsWIthMsgList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Read all the informational messages present for each Employment record
    // Retrieved from the database.
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (String warning : warnings) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warning;
      readEmploymentDetailsWIthMsgList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    return readEmploymentDetailsWIthMsgList;

  }

  // END, CR00178447

  /**
   * Reads an existing employment for the person.
   *
   * @param key
   * Identifies the person for whom the employments will be returned.
   *
   * @return The details of the employment read from the database.
   */
  public ReadEmploymentDetails readEmployment(
    curam.core.facade.struct.ReadEmploymentKey key) throws AppException,
      InformationalException {

    // Maintain Person Employment object.
    curam.core.intf.MaintainPersonEmployment maintainPersonEmploymentObj = curam.core.fact.MaintainPersonEmploymentFactory.newInstance();

    // Details to be returned.
    ReadEmploymentDetails readEmploymentDetails = new ReadEmploymentDetails();

    // Employment Details
    curam.core.struct.EmploymentDetails employmentDetails;

    // Concern role entity objects
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleAlternateReadKey concernRoleAlternateReadKey = new ConcernRoleAlternateReadKey();
    ConcernRoleDtls concernRoleDtls;

    // Read the employment details.
    employmentDetails = maintainPersonEmploymentObj.readEmployment(
      key.readEmploymentKey);

    // Assign the employment details to the output
    readEmploymentDetails.employmentDetails.assign(employmentDetails);
      
    // Get the employer concern role id
    Employment employmentObj = EmploymentFactory.newInstance();
    EmploymentKey employmentKey = new EmploymentKey();

    employmentKey.employmentID = employmentDetails.employmentID;
      
    EmploymentDtls employmentDtls = employmentObj.read(employmentKey);
      
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = employmentDtls.employerConcernRoleID;

    curam.core.struct.ConcernRoleTypeDetails concernRoleTypeDetails = concernRoleObj.readConcernRoleType(
      concernRoleKey);
          
    // Set the employer concern role ID
    readEmploymentDetails.employmentDetails.employerConcernRoleID = employmentDtls.employerConcernRoleID;
    // Set the employer concern role type
    readEmploymentDetails.employmentDetails.concernRoleType = concernRoleTypeDetails.concernRoleType;

    // Context key
    // BEGIN, CR00061307, PCAL
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = employmentDetails.concernRoleID;

    readEmploymentDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readEmploymentDetails;

  }
  
  /**
   * Searches for a person by primary alternate ID.
   *
   * @param key
   * Identifies the person
   *
   * @return The details of the person read from the database.
   * @deprecated Since Curam 6.0.5.3, replaced by {@link #searchByReferenceNumber()} 
   */
  public curam.core.facade.struct.PersonReadDtls readByReferenceNumber(
    PersonAlternateIDSearchKey key) throws AppException,
      InformationalException {

    // Person Search object.
    curam.core.intf.PersonSearchRouter personSearchRouterObj = curam.core.fact.PersonSearchRouterFactory.newInstance();
    AlternateIDSearchKey alternateIDSearchKey = new AlternateIDSearchKey();

    // Details to be returned.
    curam.core.facade.struct.PersonReadDtls personReadDtls = new curam.core.facade.struct.PersonReadDtls();

    // Get the alternate ID from the search key.
    alternateIDSearchKey.alternateID = key.alternateIDSearchKey.alternateID;

    personReadDtls.personReadDtls = personSearchRouterObj.readByReferenceNumber(
      alternateIDSearchKey);

    // Return the details.
    return personReadDtls;

  }

  /**
   * Searches for a person by primary alternate ID.
   *
   * @param key
   * Identifies the person
   *
   * @return The list of person details.
   */
  public PersonReadDtlsList searchByReferenceNumber(
    PersonAlternateIDSearchKey key) throws AppException,
      InformationalException {

    PersonReadDtlsList personReadDtlsList = new PersonReadDtlsList();
    
    curam.core.intf.PersonSearchRouter personSearchRouterObj = curam.core.fact.PersonSearchRouterFactory.newInstance();
    AlternateIDSearchKey alternateIDSearchKey = new AlternateIDSearchKey();

    // Details to be returned.
    curam.core.facade.struct.PersonReadDtls personReadDtls = new curam.core.facade.struct.PersonReadDtls();

    // Get the alternate ID from the search key.
    alternateIDSearchKey.alternateID = key.alternateIDSearchKey.alternateID;

    personReadDtlsList = personSearchRouterObj.searchByReferenceNumber(
      alternateIDSearchKey);

    return personReadDtlsList;
  }

  /**
   * Reads the Further Details for a person.
   *
   * @param key
   * Identifies the person
   *
   * @return The details of the person read from the database.
   */
  public curam.core.facade.struct.PersonSearchFurtherDtls readFurtherDetails(
    PersonSearchMaintainConcernRoleKey key) throws AppException,
      InformationalException {

    // Person Search object and key.
    curam.core.intf.PersonSearchRouter personSearchRouterObj = curam.core.fact.PersonSearchRouterFactory.newInstance();
    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Details to be returned.
    curam.core.facade.struct.PersonSearchFurtherDtls personSearchFurtherDtls = new curam.core.facade.struct.PersonSearchFurtherDtls();

    // Get the concern role ID from the search key.
    maintainConcernRoleKey.concernRoleID = key.maintainConcernRoleKey.concernRoleID;

    personSearchFurtherDtls.personSearchFurtherDtls = personSearchRouterObj.readFurtherDetails(
      maintainConcernRoleKey);

    // Return the details.
    return personSearchFurtherDtls;

  }

  /**
   * @param key
   * Identifies the person concerned
   *
   * @return The details of the person read from the database.
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}
   *
   * Searches for a person by Concern Role ID.
   */
  @Deprecated
  public curam.core.facade.struct.PersonSearchResult search(
    curam.core.facade.struct.PersonSearchKey key) throws AppException,
      InformationalException {

    // Person Search object and key.
    curam.core.intf.PersonSearchRouter personSearchRouterObj = curam.core.fact.PersonSearchRouterFactory.newInstance();
    curam.core.struct.PersonSearchKey personSearchKey;

    // Details to be returned.
    curam.core.facade.struct.PersonSearchResult personSearchResult = new curam.core.facade.struct.PersonSearchResult();

    // Get the details for the search from the search key.
    personSearchKey = key.personSearchKey;

    personSearchResult.personSearchResult = personSearchRouterObj.search(
      personSearchKey);

    for (int i = 0; i
      < personSearchResult.personSearchResult.details.dtls.size(); i++) {

      personSearchResult.personSearchResult.details.dtls.item(i).personFullName = personSearchResult.personSearchResult.details.dtls.item(i).forename
        + CuramConst.gkSpace
        + personSearchResult.personSearchResult.details.dtls.item(i).surname;
      // BEGIN CR00096008, PN
      // BEGIN, CR00214655, PB
      // BEGIN, CR00340652, KRK
      if (BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(TransactionInfo.getProgramLocale()).equals(
        personSearchResult.personSearchResult.details.dtls.item(i).address)) {
        // END, CR00340652
        // END, CR00214655
        personSearchResult.personSearchResult.details.dtls.item(i).address = CuramConst.gkEmpty;
      }
      // END CR00096008
    }

    // Return the details.
    return personSearchResult;

  }

  /**
   * Sets Person Relationship status to canceled.
   *
   * @param key
   * The Person Relationship ID of the record to be canceled.
   */
  public void cancelRelationship(CancelPersonRelationshipDetailsKey key)
    throws AppException, InformationalException {

    // Maintain Concern Role Relationships object.
    curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Cancel the Person Relationship.
    maintainConcernRoleRelationshipsObj.cancelRelationship(
      key.cancelRelationshipDetailsKey);

  }

  // BEGIN, CR00077847, POH
  /**
   * Creates a new Person Relationship record for the specified person.
   *
   * @param details
   * The Person Relationship information to be inserted.
   * @return CreatedRelationshipDetails List of informationals - if any exist -
   * to be displayed to user
   */
  public CreatedRelationshipDetails createRelationship(
    MaintainPersonRelationships details) throws AppException,
      InformationalException {

    // return struct
    CreatedRelationshipDetails createdRelationshipDetails = new CreatedRelationshipDetails();

    // Maintain Concern Role Relationships object and key.
    curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    RelationshipsByConcernRoleIDKey relationshipsByConcernRoleIDKey = new RelationshipsByConcernRoleIDKey();

    MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails = new MaintainConcernRoleRelationshipDetails();

    // Get the Concern Role ID from the key.
    relationshipsByConcernRoleIDKey.concernRoleID = details.personRelationshipDetails.concernRoleID;

    maintainConcernRoleRelationshipDetails.assign(
      details.personRelationshipDetails);

    // Create the Relationship record.
    maintainConcernRoleRelationshipsObj.createRelationshipByAltID(
      maintainConcernRoleRelationshipDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      createdRelationshipDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return createdRelationshipDetails;
  }

  // END, CR00077847

  /**
   * Retrieves a list of Person Relationship details.
   *
   * @param key
   * The concern role ID that Person Relationship records will be
   * returned for.
   *
   * @return The list of Person Relationship records.
   */
  public ReadPersonRelationshipList listRelationship(
    ReadPersonRelationshipListKey key) throws AppException,
      InformationalException {

    // Maintain Concern Role Relationships object.
    curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Details to be returned.
    ReadPersonRelationshipList readPersonRelationshipList = new ReadPersonRelationshipList();

    // Read the list of Person Relationship records.
    readPersonRelationshipList.maintainConcernRoleRelationshipList = maintainConcernRoleRelationshipsObj.readmultiByConcernRoleID(
      key.relationshipsByConcernRoleIDKey);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.relationshipsByConcernRoleIDKey.concernRoleID;

    readPersonRelationshipList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readPersonRelationshipList;

  }

  // BEGIN, CR00077847, POH
  /**
   * Modifies Person Relationship details.
   *
   * @param details
   * The Person Relationship details that will be modified.
   * @return ModifiedRelationshipDetails List of informationals - if any exist -
   * to be displayed to user
   */
  public ModifiedRelationshipDetails modifyRelationship(
    MaintainPersonRelationships details) throws AppException,
      InformationalException {

    // return struct
    ModifiedRelationshipDetails modifiedRelationshipDetails = new ModifiedRelationshipDetails();
    // Maintain Concern Role Relationships object.
    curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();
    MaintainConcernRoleRelationshipKey maintainConcernRoleRelationshipKey = new MaintainConcernRoleRelationshipKey();

    MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails = new MaintainConcernRoleRelationshipDetails();

    maintainConcernRoleRelationshipDetails.assign(
      details.personRelationshipDetails);

    // Get the concern role ID from the key.
    maintainConcernRoleRelationshipKey.concernRoleRelationshipID = details.personRelationshipDetails.concernRoleRelationshipID;

    // Modify the Relationship record.
    maintainConcernRoleRelationshipsObj.modifyRelationshipByAltID(
      maintainConcernRoleRelationshipKey,
      maintainConcernRoleRelationshipDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      modifiedRelationshipDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return modifiedRelationshipDetails;
  }

  // END, CR00077847

  /**
   * Modifies Person Relationship details.
   *
   * @param key
   * The Relationship ID that details will be returned for
   *
   * @return The details of the relationship read from the database.
   */
  public ReadPersonRelationshipDetails readRelationship(
    ReadPersonRelationshipDetailsKey key) throws AppException,
      InformationalException {

    // Maintain Concern Role Relationship object.
    curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Details to be returned.
    ReadPersonRelationshipDetails readPersonRelationshipDetails = new ReadPersonRelationshipDetails();

    MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails;

    // Read the Relationship details.
    maintainConcernRoleRelationshipDetails = maintainConcernRoleRelationshipsObj.readRelationship(
      key.maintainConcernRoleRelationshipKey);

    // Assign relationship details to output
    readPersonRelationshipDetails.personRelationshipDetails.assign(
      maintainConcernRoleRelationshipDetails);

    // Context key
    // BEGIN, CR00061307, PCAL
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = maintainConcernRoleRelationshipDetails.concernRoleID;

    readPersonRelationshipDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readPersonRelationshipDetails;

  }

  /**
   * Modifies a person.
   *
   * @param details
   * Identifies person whose details are to be modified
   *
   * @return Informational messages returned from the database.
   */
  public InformationalMsgDetailsList modifyPerson(MaintainPersonDetails details)
    throws AppException, InformationalException {

    // Maintain Person object.
    curam.core.intf.MaintainPerson maintainPersonObj = curam.core.fact.MaintainPersonFactory.newInstance();

    // Details to be returned.
    InformationalMsgDetailsList informationalMsgDetailsList = new InformationalMsgDetailsList();

    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Get the Concern Role ID from the details.
    maintainConcernRoleKey.concernRoleID = details.personModifyDtls.concernRoleID;

    // BEGIN, CR00108252, PA
    // BEGIN, CR00114322, PA
    // It checks for the indigenous person indicator, if indicator is true and
    // indigenous group code is empty then throws AppException
    if (!details.personModifyDtls.indigenousPersonInd
      && !details.personModifyDtls.indigenousGroupCode.equalsIgnoreCase(
        CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPERSONREGISTRATION.ERR_XFV_INDIGENOUS_PERSON_INDICATOR_CHECK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }
    // END, CR00114322, PA
    // END, CR00108252, PA

    // Modify the Person
    maintainPersonObj.modifyPerson(maintainConcernRoleKey,
      details.personModifyDtls);

    // BEGIN, CR00016578, SPD
    // Create an informational manager
    curam.util.exception.InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      informationalMsgDetailsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00016578

    // Return the details.
    return informationalMsgDetailsList;
  }

  /**
   * Retrieves a list of Utility Payments.
   *
   * @param key
   * Identifies utility payment concerned
   *
   * @return List of utility payments for the specified person.
   */
  public ReadUtilityPaymentsList listUtilityPayment(
    ReadUtilityPaymentsListKey key) throws AppException,
      InformationalException {

    // Maintain Utility Payments object.
    curam.core.intf.MaintainUtilityPayments maintainUtilityPaymentsObj = curam.core.fact.MaintainUtilityPaymentsFactory.newInstance();

    // Details to be returned.
    ReadUtilityPaymentsList readUtilityPaymentsList = new ReadUtilityPaymentsList();

    // Read the Utility Payments
    readUtilityPaymentsList.getClientUtilityPaymentsList = maintainUtilityPaymentsObj.getClientUtilityPayments(
      key.getClientUtilityPaymentsKey);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.getClientUtilityPaymentsKey.concernRoleID;

    readUtilityPaymentsList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readUtilityPaymentsList;
  }

  /**
   * Modifies a Utility Payment.
   *
   * @param details
   * The utility payment details to be modified.
   */
  public void modifyUtilityPayment(MaintainUtilityPaymentsDetails details)
    throws AppException, InformationalException {

    // Maintain Utility Payments object.
    curam.core.intf.MaintainUtilityPayments maintainUtilityPaymentsObj = curam.core.fact.MaintainUtilityPaymentsFactory.newInstance();

    // Get Client Utility Payment Item Key.
    GetClientUtilityPaymentItemKey getClientUtilityPaymentItemKey = new GetClientUtilityPaymentItemKey();

    // Get the id from the details.
    getClientUtilityPaymentItemKey.householdBudgetID = details.maintainUtilityPaymentDetails.householdBudgetID;

    // Read the Utility Payment Details.
    curam.core.struct.MaintainUtilityPaymentDetails maintainUtilityPaymentDetails = maintainUtilityPaymentsObj.readUtilityPayment(
      getClientUtilityPaymentItemKey);

    // Assign the details.
    maintainUtilityPaymentDetails.customerAccName = details.maintainUtilityPaymentDetails.customerAccName;
    maintainUtilityPaymentDetails.customerAccNumber = details.maintainUtilityPaymentDetails.customerAccNumber;
    maintainUtilityPaymentDetails.amount = details.maintainUtilityPaymentDetails.amount;
    maintainUtilityPaymentDetails.startDate = details.maintainUtilityPaymentDetails.startDate;
    maintainUtilityPaymentDetails.endDate = details.maintainUtilityPaymentDetails.endDate;
    maintainUtilityPaymentDetails.versionNo = details.maintainUtilityPaymentDetails.versionNo;

    // Modify the Utility Payment.
    maintainUtilityPaymentsObj.modifyUtilityPayment(
      maintainUtilityPaymentDetails);
  }

  /**
   * Reads a Utility Payment.
   *
   * @param key
   * Identifies the utility payment
   *
   * @return The details of the utility payment read from the database.
   */
  public ReadUtilityPaymentDetails readUtilityPayment(ReadUtilityPaymentKey key)
    throws AppException, InformationalException {

    // Maintain Utility Payments Object.
    curam.core.intf.MaintainUtilityPayments maintainUtilityPaymentsObj = curam.core.fact.MaintainUtilityPaymentsFactory.newInstance();

    // Household budget item object and key.
    curam.core.intf.HouseholdBudgetItem householdBudgetItemObj = curam.core.fact.HouseholdBudgetItemFactory.newInstance();

    HouseholdBudgetItemKey householdbudgetItemKey = new HouseholdBudgetItemKey();

    // Details returned from household budget item read
    HouseholdBudgetItemDtls householdBudgetItemDtls;

    // Details to be returned.
    ReadUtilityPaymentDetails readUtilityPaymentDetails = new ReadUtilityPaymentDetails();

    // Struct that contains the details.
    curam.core.struct.MaintainUtilityPaymentDetails maintainUtilityPaymentDetails;

    // Read the Utility Payment
    maintainUtilityPaymentDetails = maintainUtilityPaymentsObj.readUtilityPayment(
      key.getClientUtilityPaymentItemKey);

    // Assign the details
    readUtilityPaymentDetails.maintainUtilityPaymentDetails.assign(
      maintainUtilityPaymentDetails);

    // Get the id from the key
    householdbudgetItemKey.householdBudgetID = key.getClientUtilityPaymentItemKey.householdBudgetID;

    // Read the household budget item
    householdBudgetItemDtls = householdBudgetItemObj.read(
      householdbudgetItemKey);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = householdBudgetItemDtls.concernRoleID;

    readUtilityPaymentDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details.
    return readUtilityPaymentDetails;
  }

  // BEGIN, CR00266778, MC
  // __________________________________________________________________________
  /**
   * Reads a person's home page details and further details including an indicator
   * which is used to show or hide the person tasks.
   *
   * @param ReadPersonHomeKey key Identifies the person concerned
   *
   * @return ReadPersonHomeDetailsShowTasks The home page details of the person.
   */
  public ReadPersonHomeDetailsShowTasks readHomePageDetailsShowTasks(
    ReadPersonHomeKey key)
    throws AppException, InformationalException {
    
    ReadPersonHomeDetailsShowTasks readPersonHomeDetailsShowTasks = new ReadPersonHomeDetailsShowTasks();
    
    readPersonHomeDetailsShowTasks.homePageDtls = readHomePageDetails(key);
    
    readPersonHomeDetailsShowTasks.showParticipantTasksInd = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_SHOWHOMEPAGETASKS);

    return readPersonHomeDetailsShowTasks;
  }

  // END, CR00266778  
  
  // __________________________________________________________________________
  /**
   * Reads a person's home page details and further details
   *
   * @param key
   * Identifies the person concerned
   *
   * @return The home page details of the person.
   */
  public ReadPersonHomeDetails readHomePageDetails(ReadPersonHomeKey key)
    throws AppException, InformationalException {

    // Person Home Page object.
    curam.core.intf.PersonHomePage personHomePageObj = curam.core.fact.PersonHomePageFactory.newInstance();

    // Details to be returned.
    ReadPersonHomeDetails readPersonHomeDetails = new ReadPersonHomeDetails();

    // Struct returned from PersonHomePage read.
    ReadPersonResult readPersonResult;

    // Read the Person Home Page details
    readPersonResult = personHomePageObj.read(key.concernRoleHomePageKey);

    // BEGIN, CR00108252, PA
    // BEGIN, CR00238568, CD
    // call out to extracted methods (which are re-used elsewhere)
    readPersonResult.details.indigenousGroupCode = getIndigenousGroupTabList(
      readPersonResult.details.indigenousGroupCode);
    readPersonResult.details.race = getRaceTypeTabList(
      readPersonResult.details.race);
    // END, CR00238568
    // END, CR00108252, PA

    readPersonHomeDetails.personHomeDetails.assign(readPersonResult.details);
    readPersonHomeDetails.informationalMsgDtlsList = readPersonResult.messages;

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    readPersonHomeDetails.participantContextDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // BEGIN, CR00100055, CSH
    // Create an informational manager
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Read any informationals returned from service layer
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      readPersonHomeDetails.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00100055

    // Return the details
    return readPersonHomeDetails;
  }

  /**
   * Converts a tab delimited list of race type codes into a comma separated
   * list of race type descriptions.
   *
   * @param race
   * A tab delimited list of race type codes.
   *
   * @return A comma separated list of race type descriptions.
   */
  protected String getRaceTypeTabList(String race)
    throws AppException, InformationalException {
    StringBuffer stringTypeCode = new StringBuffer();
    StringList raceTypeTabList;

    raceTypeTabList = StringUtil.delimitedText2StringListWithTrim(race,
      CuramConst.gkTabDelimiterChar);
    // Appending all the races description and separating with Comma
    for (int j = 0; j < raceTypeTabList.size(); j++) {
      // BEGIN, CR00163098, JC
      stringTypeCode.append(
        CodeTable.getOneItem(RACECODE.TABLENAME, raceTypeTabList.item(j),
        TransactionInfo.getProgramLocale()));
      // END, CR00163098, JC
      if (j < raceTypeTabList.size() - 1) {
        stringTypeCode.append(CuramConst.gkComma);
      }
    }
    return stringTypeCode.toString();
  }

  // ___________________________________________________________________________
  /**
   * Converts a tab delimited list of indigenous group codes into a displayable
   * informational which also incorporates the associated region code
   * descriptions.
   *
   * @param indigenousGroupCode
   * A tab delimited list of indigenous group codes.
   *
   * @return A displayable informational which lists all the indigenous groups
   * and their associated regions, i.e. "<region> - <indigenous group>".
   */
  protected String getIndigenousGroupTabList(String indigenousGroupCode)
    throws AppException, InformationalException {

    // Check whether this prospect person associated with a Indigenous Group
    if (indigenousGroupCode.equalsIgnoreCase(CuramConst.gkEmpty)) {
      return indigenousGroupCode;
    }

    String regionDescription = null;
    String groupDescription = null;
    StringBuffer stringTypeCode = new StringBuffer();

    StringList indigenousTabList = StringUtil.delimitedText2StringListWithTrim(
      indigenousGroupCode, CuramConst.gkTabDelimiterChar);

    // Appending region description with group description separating by dash
    // for an Indigenous Group
    for (int j = 0; j < indigenousTabList.size(); j++) {

      if (!indigenousTabList.item(j).equalsIgnoreCase(CuramConst.gkEmpty)) {

        // BEGIN, CR00163098, JC
        regionDescription = CodeTable.getOneItem(INDIGENOUSREGIONCODE.TABLENAME,
          CodeTable.getParentCode(INDIGENOUSGROUPCODE.TABLENAME,
          indigenousTabList.item(j)),
          TransactionInfo.getProgramLocale());

        groupDescription = CodeTable.getOneItem(INDIGENOUSGROUPCODE.TABLENAME,
          indigenousTabList.item(j), TransactionInfo.getProgramLocale());
        // END, CR00163098, JC

        stringTypeCode.append(regionDescription);
        stringTypeCode.append(CuramConst.gkDash);
        stringTypeCode.append(groupDescription);

        if (j < indigenousTabList.size() - 1) {
          stringTypeCode.append(CuramConst.gkComma);
        }
      }
    }
    return stringTypeCode.toString();
  }

  // ___________________________________________________________________________
  /**
   * Called to register a new person.
   *
   * @param details
   * The details of the person being registered
   *
   * @return The person registration details.
   */
  public PersonRegistrationResult register(
    curam.core.facade.struct.PersonRegistrationDetails details)
    throws AppException, InformationalException {

    // Person Registration object
    curam.core.intf.PersonRegistration personRegistrationObj = curam.core.fact.PersonRegistrationFactory.newInstance();

    // Concern role entity objects
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // BEGIN, CR00108252, PA
    // BEGIN, CR00114322, PA
    // It checks for the indigenous person indicator, if indicator is true and
    // indigenous group code is empty then throws AppException
    if (!details.personRegistrationDetails.indigenousPersonInd
      && !details.personRegistrationDetails.indigenousGroupCode.equalsIgnoreCase(
        CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPERSONREGISTRATION.ERR_XFV_INDIGENOUS_PERSON_INDICATOR_CHECK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // END, CR00114322, PA
    // END, CR00108252, PA

    // Read concern ID from ConcernRole, if necessary
    if (details.personRegistrationDetails.relatedConcernRoleID != 0) {
      concernRoleKey.concernRoleID = details.personRegistrationDetails.relatedConcernRoleID;
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      // Set concern ID in registration details
      details.personRegistrationDetails.concernID = concernRoleDtls.concernID;
    }

    // Details to be returned
    PersonRegistrationResult personRegistrationResult = new PersonRegistrationResult();

    // Set the addressType to private
    details.personRegistrationDetails.addressType = curam.codetable.CONCERNROLEADDRESSTYPE.PRIVATE;

    // Register Person
    personRegistrationResult.registrationIDDetails = personRegistrationObj.registerPerson(
      details.personRegistrationDetails);

    // BEGIN, CR00078486, POH
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      personRegistrationResult.warnings.dtls.addRef(ecWarningsDtls);
    }
    // END, CR00078486

    // Return details
    return personRegistrationResult;
  }

  /**
   * Reads the details of the specified person.
   *
   * @param key
   * Identifies the person concerned
   *
   * @return The details of the person read from the database.
   */
  public ReadPersonDetails readPerson(ReadPersonKey key) throws AppException,
      InformationalException {

    // Person maintenance objects
    curam.core.intf.MaintainPerson maintainPersonObj = curam.core.fact.MaintainPersonFactory.newInstance();

    // Output structure
    ReadPersonDetails readPersonDetails = new ReadPersonDetails();

    // Read the person's details
    readPersonDetails.personFurtherDetails = maintainPersonObj.readFurtherDetails(
      key.maintainConcernRoleKey);

    // BEGIN, CR00108252, PA
    // BEGIN, CR00238568, CD
    // call out to extracted method (which is re-used elsewhere)
    readPersonDetails.personFurtherDetails.indigenousGroupName = getIndigenousGroupTabList(
      readPersonDetails.personFurtherDetails.indigenousGroupCode);
    // END, CR00238568
    // END, CR00108252, PA

    // Context key
    // BEGIN, CR00061467, PCAL
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = readPersonDetails.personFurtherDetails.concernRoleID;

    readPersonDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return details
    return readPersonDetails;
  }

  /**
   * @param key
   * Identifies the person concerned
   *
   * @return The cases for the person as read from the database.
   * @deprecated This method is replaced by {@link #searchCase1()}
   * @deprecated -since V6.0
   *
   * Searches for cases for the specified person.
   */
  @Deprecated
  public SearchCaseDetails searchCase(SearchCaseKey_fo key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD

    // Output structure
    SearchCaseDetails searchCaseDetails = new SearchCaseDetails();

    // BEGIN, CR00221180, ZV
    searchCaseDetails.assign(searchCase1(key));
    // END, CR00221180

    // Return details
    return searchCaseDetails;
  }

  /**
   * Lists all cases for the specified concern role.
   *
   * @param key
   * Identifies the concern role concerned
   *
   * @return The list of cases for the person.
   */
  public ListCasesByConcernRoleDetails listAllCases(
    SearchCasesByConcernRoleKey key) throws AppException,
      InformationalException {

    // Create return object
    ListCasesByConcernRoleDetails listCasesByConcernRoleDetails = new ListCasesByConcernRoleDetails();

    // MaintainCase manipulation variables
    curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
    CasesByConcernRoleIDKey casesByConcernRoleIDKey = new CasesByConcernRoleIDKey();

    // Get details from key
    casesByConcernRoleIDKey.assign(key);

    // Set key to display all cases
    casesByConcernRoleIDKey.statusCode = curam.codetable.CASESTATUSSEARCH.ALL;

    // Call getCasesByConcernRoleID operation
    // BEGIN, CR00221180, ZV
    CaseHeaderConcernRoleDetailsList1 caseHeaderConcernRoleDetailsList = maintainCaseObj.getCasesByConcernRoleID1(
      casesByConcernRoleIDKey);

    // END, CR00221180

    // Check if the list is populated
    if (!caseHeaderConcernRoleDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listCasesByConcernRoleDetails.dtls.ensureCapacity(
        caseHeaderConcernRoleDetailsList.dtls.size());

      CasesByConcernRoleDetails casesByConcernRoleDetails;

      // Iterate through the list returned
      for (int i = 0; i < caseHeaderConcernRoleDetailsList.dtls.size(); i++) {

        casesByConcernRoleDetails = new CasesByConcernRoleDetails();

        // Assign details
        casesByConcernRoleDetails.assign(
          caseHeaderConcernRoleDetailsList.dtls.item(i));
        // BEGIN, CR00049218, GM
        String productTypeDesc = CuramConst.gkEmpty;
        // END, CR00049218
        String caseTypeCode = caseHeaderConcernRoleDetailsList.dtls.item(i).caseTypeCode;

        // BEGIN, CR00364740, JMA
        if ((caseTypeCode.equals(CASETYPECODE.PARTICIPANTDATACASE))) {
          continue;
        }        
        // END, CR00364740
        
        // Check if the case is a product delivery, liability, integrated case
        // or screening case
        if ((caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY))
          || (caseTypeCode.equals(CASETYPECODE.LIABILITY))) {

          // ProductDelivery manipulation variables
          curam.core.facade.intf.ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
          ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
          ProductDeliveryTypeDetails productDeliveryTypeDetails = new ProductDeliveryTypeDetails();

          // populate key for read
          productDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

          // read back productType for the case
          productDeliveryTypeDetails = productDeliveryObj.readProductType(
            productDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
            productDeliveryTypeDetails.productType,
            TransactionInfo.getProgramLocale());

        } else {

          if (caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {
            // CaseHeader manipulation variables
            CaseHeaderDtls caseHeaderDtls;

            // Set key to read caseHeader
            curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
            CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

            caseHeaderKey.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

            caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

            productTypeDesc = CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
              caseHeaderDtls.integratedCaseType,
              TransactionInfo.getProgramLocale());

          } else if (caseTypeCode.equals(CASETYPECODE.SCREENINGCASE)) {

            // Screening manipulation variables
            Screening screeningObj = ScreeningFactory.newInstance();
            CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
            ScreeningName screeningName;

            // Set key to read read Screening entity
            caseKeyStruct.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

            // Read Screening
            screeningName = screeningObj.readName(caseKeyStruct);

            productTypeDesc = CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
              screeningName.name, TransactionInfo.getProgramLocale());

          } else if (caseTypeCode.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

            // assessmentDelivery manipulation variables
            AssessmentDelivery assessmentDeliveryObj = AssessmentDeliveryFactory.newInstance();
            AssessmentDeliveryKey assessmentDeliveryKey = new AssessmentDeliveryKey();
            AssessmentTypeDetails assessmentTypeDetails;

            // Set key to read Assessment type
            assessmentDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

            // Read AssessmentType
            assessmentTypeDetails = assessmentDeliveryObj.readAssessmentType(
              assessmentDeliveryKey);

            productTypeDesc = CodeTable.getOneItem(ASSESSMENTTYPE.TABLENAME,
              assessmentTypeDetails.assessmentType,
              TransactionInfo.getProgramLocale());

          } else if (caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

            // ServicePlan manipulation variables
            ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
            ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
            ServicePlanTypeStruct servicePlanTypeStruct = new ServicePlanTypeStruct();

            // populate key for read
            servicePlanDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

            // read back servicePlanType
            servicePlanTypeStruct = servicePlanDeliveryObj.readServicePlanType(
              servicePlanDeliveryKey);

            productTypeDesc = CodeTable.getOneItem(
              curam.codetable.SERVICEPLANTYPE.TABLENAME,
              servicePlanTypeStruct.servicePlanType,
              TransactionInfo.getProgramLocale());

          } else if (caseTypeCode.equals(CASETYPECODE.ISSUE)) {

            // IssueDelivery manipulation variables
            IssueDelivery issueDeliveryObj = IssueDeliveryFactory.newInstance();
            IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();
            IssueTypeCode issueTypeCode = new IssueTypeCode();

            // populate key for read
            issueDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

            // read back issueTyoe
            issueTypeCode = issueDeliveryObj.readIssueType(issueDeliveryKey);

            productTypeDesc = CodeTable.getOneItem(
              curam.codetable.ISSUECONFIGURATIONTYPE.TABLENAME,
              issueTypeCode.issueType, TransactionInfo.getProgramLocale());

          } else if (caseTypeCode.equals(CASETYPECODE.INVESTIGATIONCASE)) {

            // InvestigationDelivery manipulation variables
            InvestigationDelivery investigationDelivery = InvestigationDeliveryFactory.newInstance();
            InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
            InvestigationTypeCode investigationTypeCode = new InvestigationTypeCode();

            // populate key for read
            investigationDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

            // read back issueTyoe
            investigationTypeCode = investigationDelivery.readInvestigationType(
              investigationDeliveryKey);

            productTypeDesc = CodeTable.getOneItem(
              curam.codetable.INVESTIGATECONFIGTYPE.TABLENAME,
              investigationTypeCode.investigationType,
              TransactionInfo.getProgramLocale());
          }
        }

        // BEGIN, CR00163098, JC
        if (productTypeDesc == null || productTypeDesc.length() == 0) {
          productTypeDesc = CodeTable.getOneItem(CASETYPECODE.TABLENAME,
            caseTypeCode, TransactionInfo.getProgramLocale());
        }
        // END, CR00163098, JC

        casesByConcernRoleDetails.productTypeDesc = productTypeDesc;

        // Add to return object
        listCasesByConcernRoleDetails.dtls.addRef(casesByConcernRoleDetails);
      }
    }

    // Return Details
    return listCasesByConcernRoleDetails;
  }

  /**
   * Returns the person's full name and address.
   *
   * @param key
   * Contains the person's concern role identifier.
   *
   * @return PersonNameAndAddressDetails The person's full name and address.
   */
  public PersonNameAndAddressDetails readFullNameAndAddress(ReadPersonKey key)
    throws AppException, InformationalException {

    // Create return object
    PersonNameAndAddressDetails personNameAndAddressDetails = new PersonNameAndAddressDetails();

    // MaintainConcernRoleDetails manipulation variables
    curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
    ReadConcernRoleKey readConcernRoleKey = new ReadConcernRoleKey();
    curam.core.struct.ReadContactDetails readContactDetails;

    // Set key to read concern role details
    readConcernRoleKey.concernRoleID = key.maintainConcernRoleKey.concernRoleID;

    // Call MaintainConcernRoleDetails BPO to read employer's full name and
    // address
    readContactDetails = maintainConcernRoleDetailsObj.readAllContactDetails(
      readConcernRoleKey);

    // Assign details to return object
    personNameAndAddressDetails.assign(readContactDetails);

    return personNameAndAddressDetails;
  }

  /**
   * Returns a list of active benefit details for a person.
   *
   * @param key
   * Contains the person's concern role identifier.
   *
   * @return List of benefit payment details for person.
   */
  public ListActiveBenefitCaseDetails listActiveBenefitCase(
    ListActiveBenefitCasesKey key) throws AppException,
      InformationalException {

    // Create return object
    ListActiveBenefitCaseDetails listActiveBenefitCaseDetails = new ListActiveBenefitCaseDetails();

    // caseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseByConcernRoleIDNotStatusAndStartDateKey caseByConcernRoleIDNotStatusAndStartDateKey = new
      CaseByConcernRoleIDNotStatusAndStartDateKey();
    CaseHeaderDtlsList caseHeaderDtlsList;

    // Set key to read the cases for the concern
    caseByConcernRoleIDNotStatusAndStartDateKey.concernRoleID = key.concernRoleID;
    caseByConcernRoleIDNotStatusAndStartDateKey.statusCode = curam.codetable.CASESTATUS.CLOSED;
    caseByConcernRoleIDNotStatusAndStartDateKey.startDateFrom = curam.util.type.Date.kZeroDate;
    caseByConcernRoleIDNotStatusAndStartDateKey.startDateTo = curam.util.type.Date.kZeroDate;

    // read data from database
    // BEGIN, CR00221227, ZV
    caseHeaderDtlsList = caseHeaderObj.searchByConcernRoleIDNotStatusAndStartDate1(
      caseByConcernRoleIDNotStatusAndStartDateKey);
    // END, CR00221227

    // Check if the list is empty
    if (!caseHeaderDtlsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listActiveBenefitCaseDetails.activeBenefitCaseList.dtls.ensureCapacity(
        caseHeaderDtlsList.dtls.size());

      // ProductDelivery manipulation variables
      curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
      ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      ProductDeliveryDtls productDeliveryDtls;

      ActiveBenefitCaseDetails activeBenefitCaseDetails;
      // BEGIN, CR00049218, GM
      String productTypeDesc = CuramConst.gkEmpty;

      // END, CR00049218

      // BEGIN, CR00388708, KRK
      for (final CaseHeaderDtls caseHeaderDtls : caseHeaderDtlsList.dtls.items()) {

        activeBenefitCaseDetails = new ActiveBenefitCaseDetails();

        if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

          // Set key to read productDelivery
          productDeliveryKey.caseID = caseHeaderDtls.caseID;

          productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);
          
          if (!PRODUCTTYPEEntry.PAYMENTCORRECTION.getCode().equals(
            productDeliveryDtls.productType)
              && !PRODUCTTYPEEntry.BENEFITUNDERPAYMENT.getCode().equals(
                productDeliveryDtls.productType)) {
            
            // BEGIN, CR00163098, JC
            productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
              productDeliveryDtls.productType,
              TransactionInfo.getProgramLocale());
            // END, CR00163098, JC

            if (productTypeDesc != null) {

              activeBenefitCaseDetails.productTypeDesc = productTypeDesc;
            }

            activeBenefitCaseDetails.caseID = caseHeaderDtls.caseID;
            activeBenefitCaseDetails.statusCode = caseHeaderDtls.statusCode;
            activeBenefitCaseDetails.caseReference = caseHeaderDtls.caseReference;

            // Add to list
            listActiveBenefitCaseDetails.activeBenefitCaseList.dtls.addRef(
              activeBenefitCaseDetails);
          }      
          // END, CR00388708
        }
      }
    }

    return listActiveBenefitCaseDetails;
  }

  /**
   * Cancels an employment working hour record.
   *
   * @param key
   * Identifies the employment working hour record to be canceled
   */
  public void cancelEmploymentWorkingHour(
    CancelEmploymentWorkingHourDetails key)
    throws AppException, InformationalException {

    // employment working hour object.
    curam.core.sl.intf.EmploymentWorkingHour employmentWorkingHourObj = curam.core.sl.fact.EmploymentWorkingHourFactory.newInstance();

    // cancel the employment working hour record
    employmentWorkingHourObj.cancelEmploymentWorkingHour(key.details);

  }

  // BEGIN, CR00077847
  /**
   * Creates a new employment working hour record.
   *
   * @param dtls
   * Details of the employment working hour record to be inserted
   * @return CreatedEmploymentWorkingHourDetails List of informationals - if any
   * exist - to be displayed to user
   */
  public CreatedEmploymentWorkingHourDetails createEmploymentWorkingHour(
    CreateEmploymentWorkingHourDetails dtls) throws AppException,
      InformationalException {

    // return struct
    CreatedEmploymentWorkingHourDetails createdEmploymentWorkingHourDetails = new CreatedEmploymentWorkingHourDetails();
    // Maintain Employment Working Hour object.
    curam.core.sl.intf.EmploymentWorkingHour employmentWorkingHourObj = curam.core.sl.fact.EmploymentWorkingHourFactory.newInstance();

    // Create the employment working hour
    employmentWorkingHourObj.createEmploymentWorkingHour(dtls.details);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      createdEmploymentWorkingHourDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return createdEmploymentWorkingHourDetails;
  }

  // END, CR00077847

  /**
   * Returns a list of employment working hour records.
   *
   * @param key
   * The employment working hour key that records will be returned for.
   *
   * @return The list of employment working hour records
   */
  public EmploymentWorkingHourList listEmploymentWorkingHour(
    ListEmploymentWorkingHourKey key) throws AppException,
      InformationalException {

    // details to be returned
    EmploymentWorkingHourList employmentWorkingHourList = new EmploymentWorkingHourList();

    // context description key.
    EmploymentWorkingHourContextDescriptionKey contextDescriptionKey = new EmploymentWorkingHourContextDescriptionKey();

    // employment working hour object.
    curam.core.sl.intf.EmploymentWorkingHour employmentWorkingHourObj = curam.core.sl.fact.EmploymentWorkingHourFactory.newInstance();

    // read the list of employment working hour records
    employmentWorkingHourList.detailsList = employmentWorkingHourObj.listEmploymentWorkingHour(
      key.detailsListKey);

    // get the context description.
    contextDescriptionKey.employmentID = key.detailsListKey.employmentWorkingHourRMKey.employmentID;
    employmentWorkingHourList.contextDescription = readEmploymentWorkingHourContextDescription(
      contextDescriptionKey);

    return employmentWorkingHourList;
  }

  // BEGIN, CR00219450, JF
  /**
   * Returns a list of employment working hour records with the versionNo
   * included.
   *
   * @param key
   * The employment working hour key that records will be returned for.
   *
   * @return The list of employment working hour records including versionNo
   */
  public EmploymentWorkingHourAndVersionNoList listEmploymentWorkingHourAndVersionNo(
    ListEmploymentWorkingHourKey key) throws AppException,
      InformationalException {
    // details to be returned
    EmploymentWorkingHourAndVersionNoList employmentWorkingHourAndVersionNoList = new EmploymentWorkingHourAndVersionNoList();

    // employment working hour object.
    curam.core.sl.intf.EmploymentWorkingHour employmentWorkingHourObj = curam.core.sl.fact.EmploymentWorkingHourFactory.newInstance();

    // read the list of employment working hour records
    employmentWorkingHourAndVersionNoList.detailsList = employmentWorkingHourObj.listEmploymentWorkingHourAndVersionNo(
      key.detailsListKey);

    return employmentWorkingHourAndVersionNoList;
  }

  // END, CR00219450


  // BEGIN, CR00077847, POH
  /**
   * Modifies details of an employment working hour record.
   *
   * @param dtls
   * The employment working hour record that will be modified
   * @return ModifiedEmploymentWorkingHourDetails List of informationals - if
   * any exist - to be displayed to user
   */
  public ModifiedEmploymentWorkingHourDetails modifyEmploymentWorkingHour(
    ModifyEmploymentWorkingHourDetails dtls) throws AppException,
      InformationalException {

    // return struct
    ModifiedEmploymentWorkingHourDetails modifiedEmploymentWorkingHourDetails = new ModifiedEmploymentWorkingHourDetails();

    // employment working hour object.
    curam.core.sl.intf.EmploymentWorkingHour employmentWorkingHourObj = curam.core.sl.fact.EmploymentWorkingHourFactory.newInstance();

    // modify the employment working hour record
    employmentWorkingHourObj.modifyEmploymentWorkingHour(dtls.details);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      modifiedEmploymentWorkingHourDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return modifiedEmploymentWorkingHourDetails;
  }

  // END, CR00077847

  /**
   * Reads the details of an employment working hour record.
   *
   * @param key
   * Identifies the employment working hour record concerned.
   *
   * @return The employment working hour details of the person
   */
  public ReadEmploymentWorkingHourDetails readEmploymentWorkingHour(
    EmploymentWorkingHourKey key)
    throws AppException, InformationalException {

    // return employment working hour details
    ReadEmploymentWorkingHourDetails readEmploymentWorkingHourDetails = new ReadEmploymentWorkingHourDetails();

    // context description key.
    EmploymentWorkingHourContextDescriptionKey contextDescriptionKey = new EmploymentWorkingHourContextDescriptionKey();

    // employment working hour object
    curam.core.sl.intf.EmploymentWorkingHour employmentWorkingHourObj = curam.core.sl.fact.EmploymentWorkingHourFactory.newInstance();

    // read the employment working hour details
    readEmploymentWorkingHourDetails.details = employmentWorkingHourObj.readEmploymentWorkingHour(
      key.workingHourKey.key);

    // get the context description.
    contextDescriptionKey.employmentID = readEmploymentWorkingHourDetails.details.employmentID;
    readEmploymentWorkingHourDetails.contextDescription = readEmploymentWorkingHourContextDescription(
      contextDescriptionKey);

    return readEmploymentWorkingHourDetails;
  }

  /**
   * Read the context description details for employment working hours.
   *
   * @param key
   * The employment ID the context description is returned for.
   *
   * @return The employment working hour context description.
   */
  public EmploymentWorkingHourContextDescription readEmploymentWorkingHourContextDescription(
    EmploymentWorkingHourContextDescriptionKey key) throws AppException,
      InformationalException {

    // return the context description
    EmploymentWorkingHourContextDescription contextDescription = new EmploymentWorkingHourContextDescription();

    // MaintainPersonEmployment manipulation variables
    curam.core.intf.MaintainPersonEmployment maintainPersonEmploymentObj = curam.core.fact.MaintainPersonEmploymentFactory.newInstance();
    curam.core.struct.ReadEmploymentKey readEmploymentKey = new curam.core.struct.ReadEmploymentKey();

    // set the employment key
    readEmploymentKey.employmentID = key.employmentID;

    // read the employer and employee name.
    EmployerEmployeeNameDetails employerEmployeeNameDetails = maintainPersonEmploymentObj.readEmployerEmployeeName(
      readEmploymentKey);

    LocalisableString description = new LocalisableString(
      curam.message.FACADEPERSON.INF_EMPLOYMENT_WITH);

    description.arg(
      employerEmployeeNameDetails.employerEmployeeNameStruct.employeeName);
    description.arg(
      employerEmployeeNameDetails.employerEmployeeNameStruct.employerName);

    // BEGIN, CR00163236, CL
    // Assign the string to the description
    contextDescription.description = description.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163236

    return contextDescription;
  }

  /**
   * Cancels a utility payment for a person.
   *
   * @param key
   * Contains the utility payment Id.
   */
  public void cancelUtilityPayment(
    curam.core.facade.struct.CancelUtilityPaymentKey key)
    throws AppException, InformationalException {

    // MaintainUtilityPayments manipulation variable
    curam.core.intf.MaintainUtilityPayments maintainUtilityPaymentsObj = curam.core.fact.MaintainUtilityPaymentsFactory.newInstance();

    maintainUtilityPaymentsObj.cancelUtilityPayment(key.key);

  }

  // BEGIN, CR00059389, PCAL
  /**
   * Method returns a list of Citizenship Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * The citizenshipID of the Citizenship record the snapshots are
   * associated with.
   *
   * @return The list of citizenship snapshot summary details
   */
  public ReadCitizenshipHistoryList listCitizenshipHistory(
    ReadCitizenshipHistoryListKey key) throws AppException,
      InformationalException {

    // Return struct
    ReadCitizenshipHistoryList readCitizenshipHistoryList = new ReadCitizenshipHistoryList();

    // BEGIN, CR00075874, CR00101199, SSK, VM
    // Read the citizenship details to get the concernRoleID
    CitizenshipKey citizenshipKey = new CitizenshipKey();
    curam.core.intf.Citizenship citizenshipObj = curam.core.fact.CitizenshipFactory.newInstance();

    citizenshipKey.citizenshipID = key.listHistoryKey.citizenshipID;

    try {
      CitizenshipDtls citizenshipDtls = citizenshipObj.read(citizenshipKey);

      key.listHistoryKey.concernRoleID = citizenshipDtls.concernRoleID;

    } catch (RecordNotFoundException rnfe) {

      CitizenshipSnapshotKey citizenSnapshotKey = new CitizenshipSnapshotKey();

      citizenSnapshotKey.citizenshipSnapshotID = key.listHistoryKey.citizenshipID;

      CitizenshipSnapshotDtls citizenSnapshotDtls = CitizenshipSnapshotFactory.newInstance().read(
        citizenSnapshotKey);

      key.listHistoryKey.concernRoleID = citizenSnapshotDtls.concernRoleID;
    }
    // END, CR00075874, CR00101199

    // Retrieve the list of snap shot summary details
    MaintainCitizenship maintainCitizenshipObj = MaintainCitizenshipFactory.newInstance();

    readCitizenshipHistoryList.historyDtls = maintainCitizenshipObj.listCitizenshipHistory(
      key.listHistoryKey);

    // Get the context description of the Citizenship record
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.listHistoryKey.concernRoleID;

    readCitizenshipHistoryList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details
    return readCitizenshipHistoryList;
  }

  // END, CR00059389

  // BEGIN, CR00060981, PCAL
  /**
   * Method returns a list of Employment Working Hours Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key
   * The Employment Working Hour record the snapshots are associated
   * with.
   *
   * @return The list of Employment Working Hour snapshot details.
   */
  public ReadEmploymentWorkingHourHistoryList listEmploymentWorkingHourHistory(
    ReadEmploymentWorkingHourHistoryListKey key) throws AppException,
      InformationalException {

    // Return struct
    ReadEmploymentWorkingHourHistoryList readEmploymentWorkingHourHistoryList = new ReadEmploymentWorkingHourHistoryList();

    // Retrieve the list of snap shot summary details
    EmploymentWorkingHour employmentWorkingHourObj = EmploymentWorkingHourFactory.newInstance();

    readEmploymentWorkingHourHistoryList.historyDtls = employmentWorkingHourObj.listEmploymentWorkingHoursHistory(
      key.historyKey);

    // Get the context description by reading the employmentID of the Employment
    // Working Hour record associated with the list of Snapshots
    curam.core.sl.entity.struct.EmploymentWorkingHourKey employmentWorkingHourKey = new curam.core.sl.entity.struct.EmploymentWorkingHourKey();

    employmentWorkingHourKey.employmentWorkingHourID = key.historyKey.employmentWorkingHourID;
    EmploymentWorkingHourContextDescriptionKey contextDescriptionKey = new EmploymentWorkingHourContextDescriptionKey();

    contextDescriptionKey.employmentID = employmentWorkingHourObj.readEmploymentWorkingHour(employmentWorkingHourKey).employmentID;
    readEmploymentWorkingHourHistoryList.contextDescription.description = readEmploymentWorkingHourContextDescription(contextDescriptionKey).description;

    // Return the details
    return readEmploymentWorkingHourHistoryList;
  }

  // END, CR00060981

  // BEGIN, CR00102618, CSH
  /**
   * @param key
   * Identifies the person concerned
   *
   * @return The cases for the duplicate person as read from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated This method is replaced by {@link #searchCaseForDuplicate1()}
   * @deprecated -since V6.0
   *
   * Searches for cases for the specified duplicate person.
   */
  @Deprecated
  public SearchCasesForDuplicateDetails searchCaseForDuplicate(
    SearchCaseKey_fo key) throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Output structure
    SearchCasesForDuplicateDetails searchCasesForDuplicateDetails = new SearchCasesForDuplicateDetails();

    // BEGIN, CR00221180, ZV
    searchCasesForDuplicateDetails.assign(searchCaseForDuplicate1(key));
    // END, CR00221180

    // Return details
    return searchCasesForDuplicateDetails;
    // END, CR00102618
  }

  // BEGIN, CR00100777, BD

  /**
   * Returns the nickname search indicator set in Property administration.
   *
   * @return SearchWithNicknames, an on/off indicator
   */
  public SearchWithNicknames readSearchWithNicknamesIndicator()
    throws AppException, InformationalException {

    // Return struct
    SearchWithNicknames searchWithNicknames = new SearchWithNicknames();

    searchWithNicknames.dtls = PersonSearchRouterFactory.newInstance().readSearchNicknamesIndicator();

    // Return the details
    return searchWithNicknames;
  }

  // END, CR00100777

  // BEGIN, CR00108252, PA

  /**
   * Returns the list of race codes.
   *
   * @return RaceCodeList - It holds the list of race codes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public RaceCodeList listRace() throws AppException, InformationalException {

    // Return struct
    RaceCodeList raceCodeList = new RaceCodeList();

    raceCodeList.list = MaintainPersonFactory.newInstance().listRace();

    // Return the list
    return raceCodeList;
  }

  /**
   * Method returns a list of Indigenous Groups.
   *
   * @param key -
   * This holds the search value, which is used to search Indigenous
   * groups.
   *
   * @return IndigenousGroupList - The list of Indigenous Groups.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public IndigenousGroupList searchIndigenousGroup(IndigenousGroupSearchKey key)
    throws AppException, InformationalException {

    // Return struct
    IndigenousGroupList indigenousGroupList = new IndigenousGroupList();

    indigenousGroupList.list = MaintainPersonFactory.newInstance().searchIndigenousGroup(
      key.key);

    // Return the list
    return indigenousGroupList;
  }

  // END, CR00108252, PA

  // BEGIN, CR00114322, PA
  /**
   * Reads the informational message for a participant.
   *
   * @param key -
   * It holds the concernRoleID
   *
   * @return informationalMsgDtls = It holds Informational details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public InformationalMsgDetailsList readInformationalMessage(
    MaintainConcernRoleKey key) throws AppException, InformationalException {
    // Instance of return struct
    curam.core.facade.struct.InformationalMsgDetailsList informationalMsgDetailsList = new curam.core.facade.struct.InformationalMsgDetailsList();

    // calling the readInformationalMessage() method on service layer object
    informationalMsgDetailsList.informationalMsgDtlsList = MaintainPersonFactory.newInstance().readInformationalMessage(
      key.maintainConcernRoleKey);

    return informationalMsgDetailsList;
  }

  // END, CR00114322, PA

  // BEGIN, CR00218133, ZV
  // BEGIN, CR00282028,IBM
  /**
   * Searches for a person by provided search criteria.
   *
   * @param key
   * Contains the person search criteria.
   *
   * @return Details for the list of persons found.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Person#searchPerson(PersonSearchKey1)}.
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchPerson(PersonSearchKey1) which returns the informational
   * message along with person details as well. See release note:
   * CS-09152/CR00282028.
   */
  @Deprecated
  public PersonSearchResult1 search1(PersonSearchKey1 key)
    throws AppException, InformationalException {
    // END, CR00282028
    PersonSearchRouter personSearchRouterObj = PersonSearchRouterFactory.newInstance();

    PersonSearchResult1 personSearchResult = new PersonSearchResult1();

    personSearchResult.personSearchResult = personSearchRouterObj.search1(
      key.personSearchKey);

    return personSearchResult;

  }

  // END, CR00218133

  // BEGIN, CR00219812, ZV
  // BEGIN, CR00282028, IBM
  /**
   * Searches for a person by provided search criteria. Does not return names as
   * hyperlinks as this is for popup pages.
   *
   * @param key
   * Contains the person search criteria.
   *
   * @return Details for the list of persons found.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Person#searchPersonForPopup(PersonSearchKey1)}.
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchPersonForPopup(PersonSearchKey1) which returns the
   * informational message along with person details as well. See
   * release note: CS-09152/CR00282028.
   */
  @Deprecated
  public PersonSearchResult1 search1ForPopup(PersonSearchKey1 key)
    throws AppException, InformationalException {
    // END, CR00282028
    PersonSearchRouter personSearchRouterObj = PersonSearchRouterFactory.newInstance();

    PersonSearchResult1 personSearchResult = new PersonSearchResult1();

    key.personSearchKey.disableLinkInd = true;

    personSearchResult.personSearchResult = personSearchRouterObj.search1(
      key.personSearchKey);

    return personSearchResult;

  }

  // END, CR00219812

  // BEGIN, CR00221180, ZV
  /**
   * Searches for cases for the specified person.
   *
   * @param key
   * Identifies the person concerned
   *
   * @return The cases for the person as read from the database.
   */
  public SearchCaseDetails1 searchCase1(SearchCaseKey_fo key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD

    // Output structure
    SearchCaseDetails1 searchCaseDetails = new SearchCaseDetails1();

    // Case Search object
    MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.casesByConcernRoleIDKey.concernRoleID;

    searchCaseDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Set status code for search
    key.casesByConcernRoleIDKey.statusCode = CASESTATUSSEARCH.ALL;

    CaseHeaderConcernRoleDetailsList1 caseHeaderConcernRoleDetailsList;

    // BEGIN CR00087300, SPD
    // retrieve the environment variable for listing additional cases for
    // which the participant is a case member
    // BEGIN CR00151514, SPD
    boolean displayCaseMemberCases = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_INCLUDENONPRIMARYCLIENTCASES);

    // END, CR00151514

    if (displayCaseMemberCases) {

      // Perform additional case search for case members
      caseHeaderConcernRoleDetailsList = maintainCaseObj.listCasesForParticipantAndTypes(
        key.casesByConcernRoleIDKey);

      // BEGIN, CR00163646, SPD
      caseHeaderConcernRoleDetailsList.displayCaseMemberInd = true;
      // END, CR00163646
    } else {

      // Perform standard case search by primary client
      caseHeaderConcernRoleDetailsList = maintainCaseObj.getCasesByConcernRoleID1(
        key.casesByConcernRoleIDKey);

      // BEGIN, CR00163646, SPD
      caseHeaderConcernRoleDetailsList.displayCaseMemberInd = false;
      // END, CR00163646
    }
    // END, CR00087300

    // Check if the list is populated
    if (!caseHeaderConcernRoleDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      searchCaseDetails.caseHeaderConcernRoleDetailsList.dtls.ensureCapacity(
        caseHeaderConcernRoleDetailsList.dtls.size());

      CaseHeaderConcernRoleDetails1 caseHeaderConcernRoleDetails;

      // Iterate through the list returned
      for (int i = 0; i < caseHeaderConcernRoleDetailsList.dtls.size(); i++) {

        caseHeaderConcernRoleDetails = new CaseHeaderConcernRoleDetails1();

        // Assign details
        caseHeaderConcernRoleDetails.assign(
          caseHeaderConcernRoleDetailsList.dtls.item(i));

        String caseTypeCode = caseHeaderConcernRoleDetailsList.dtls.item(i).caseTypeCode;

        // Check if the case is a product delivery, liability, integrated case
        // or screening case
        if ((caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY))
          || (caseTypeCode.equals(CASETYPECODE.LIABILITY))) {

          // BEGIN, CR00142634, JMA
          // Read Product to see if we should display the case
          curam.core.intf.Product productObj = ProductFactory.newInstance();
          ProductKey productKey = new ProductKey();

          productKey.productID = caseHeaderConcernRoleDetails.productID;

          if (productObj.read(productKey).programListInd) {

            caseHeaderConcernRoleDetails.productTypeDesc = CodeTable.getOneItem(
              PRODUCTTYPE.TABLENAME,
              caseHeaderConcernRoleDetailsList.dtls.item(i).productType);

            // Add to return object
            searchCaseDetails.caseHeaderConcernRoleDetailsList.dtls.addRef(
              caseHeaderConcernRoleDetails);
          }
          // END, CR00142634
        } else if (caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {
          // BEGIN, CR00142634, JMA
          AdminIntegratedCase adminIntegratedCaseObj = AdminIntegratedCaseFactory.newInstance();
          AdminIntegratedCaseKey adminIntegratedCaseKey = new AdminIntegratedCaseKey();
          IntegratedCaseTypeStruct integratedCaseTypeStruct = new IntegratedCaseTypeStruct();

          integratedCaseTypeStruct.integratedCaseType = caseHeaderConcernRoleDetailsList.dtls.item(i).integratedCaseType;

          AdminIntegratedCaseDtls adminIntegratedCaseDtls = adminIntegratedCaseObj.readAdminIntegratedCaseByType(
            integratedCaseTypeStruct);

          adminIntegratedCaseKey.adminIntegratedCaseID = adminIntegratedCaseDtls.adminIntegratedCaseID;

          if (adminIntegratedCaseObj.read(adminIntegratedCaseKey).programListInd) {

            // CaseHeader manipulation variables
            CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
            CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
            CaseHeaderDtls caseHeaderDtls;

            // Set key to read caseHeader
            caseHeaderKey.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

            caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

            caseHeaderConcernRoleDetails.productTypeDesc = CodeTable.getOneItem(
              PRODUCTCATEGORY.TABLENAME, caseHeaderDtls.integratedCaseType);

            caseHeaderConcernRoleDetails.caseParticipantRoleTypeDesc = CodeTable.getOneItem(
              CASEPARTICIPANTROLETYPE.TABLENAME,
              caseHeaderConcernRoleDetails.caseParticipantRoleType);

            // Add to return object
            searchCaseDetails.caseHeaderConcernRoleDetailsList.dtls.addRef(
              caseHeaderConcernRoleDetails);
            // END, CR00142634

          }
        }
      }
    }

    // BEGIN, CR00163646, SPD
    // Populate indicator to determine what case listing to display for
    // participant
    searchCaseDetails.caseHeaderConcernRoleDetailsList.displayCaseMemberInd = caseHeaderConcernRoleDetailsList.displayCaseMemberInd;
    // END, CR00163646

    // BEGIN, CR00221607, MC
    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      ClientMerge clientMergeObj = ClientMergeFactory.newInstance();
      curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();
      // END, CR00102618

      // Page variables to link to for the original and duplicate client lists
      ClientPageLink dupPageIdentifier = new ClientPageLink();
      ClientPageLink origPageIdentifier = new ClientPageLink();

      // ConcernRole manipulation variables
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      ConcernRoleKey currentKey = new ConcernRoleKey();
      ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      // Set concernRole
      concernRoleKey.concernRoleID = key.casesByConcernRoleIDKey.concernRoleID;

      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listCaseForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listCase;

      // Build up the xml data needed for the tab widget
      searchCaseDetails.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      searchCaseDetails.ind = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);
      // END, CR00120078
    }
    // END, CR00221607

    // Return details
    return searchCaseDetails;
  }

  /**
   * Searches for cases for the specified duplicate person.
   *
   * @param key
   * Identifies the person concerned
   *
   * @return The cases for the duplicate person as read from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public SearchCasesForDuplicateDetails1 searchCaseForDuplicate1(
    SearchCaseKey_fo key) throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Output structure
    SearchCasesForDuplicateDetails1 searchCasesForDuplicateDetails = new SearchCasesForDuplicateDetails1();

    // Case Search object
    MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();

    // ClientMerge manipulation variable
    ClientMerge clientMergeObj = ClientMergeFactory.newInstance();
    // END, CR00102618

    // Page variables to link to for the original and duplicate client lists
    ClientPageLink dupPageIdentifier = new ClientPageLink();
    ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleKey currentKey = new ConcernRoleKey();

    // Context key
    // ConcernRoleDuplicate manipulation variables
    ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.casesByConcernRoleIDKey.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    searchCasesForDuplicateDetails.duplicatesCases.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // also need to get context for the duplicate to display on list page
    participantContextDescriptionKey.concernRoleID = key.casesByConcernRoleIDKey.concernRoleID;

    searchCasesForDuplicateDetails.duplicateContextDesc = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Set status code for search
    key.casesByConcernRoleIDKey.statusCode = CASESTATUSSEARCH.ALL;

    CaseHeaderConcernRoleDetailsList1 caseHeaderConcernRoleDetailsList;

    // BEGIN, CR00163646, SPD
    // Retrieve the environment variable for listing additional cases for
    // which the participant is a case member
    boolean displayCaseMemberCases = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_INCLUDENONPRIMARYCLIENTCASES);

    if (displayCaseMemberCases) {

      // Perform additional case search for case members
      caseHeaderConcernRoleDetailsList = maintainCaseObj.listCasesForParticipantAndTypes(
        key.casesByConcernRoleIDKey);

      caseHeaderConcernRoleDetailsList.displayCaseMemberInd = true;
    } else {

      // Perform standard case search by primary client
      caseHeaderConcernRoleDetailsList = maintainCaseObj.getCasesByConcernRoleID1(
        key.casesByConcernRoleIDKey);

      caseHeaderConcernRoleDetailsList.displayCaseMemberInd = false;
    }
    // END, CR00163646

    // Check if the list is populated
    if (!caseHeaderConcernRoleDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      searchCasesForDuplicateDetails.duplicatesCases.caseHeaderConcernRoleDetailsList.dtls.ensureCapacity(
        caseHeaderConcernRoleDetailsList.dtls.size());

      CaseHeaderConcernRoleDetails1 caseHeaderConcernRoleDetails;

      // Iterate through the list returned
      for (int i = 0; i < caseHeaderConcernRoleDetailsList.dtls.size(); i++) {

        caseHeaderConcernRoleDetails = new CaseHeaderConcernRoleDetails1();

        // Assign details
        caseHeaderConcernRoleDetails.assign(
          caseHeaderConcernRoleDetailsList.dtls.item(i));
        String productTypeDesc = CuramConst.gkEmpty;

        String caseTypeCode = caseHeaderConcernRoleDetailsList.dtls.item(i).caseTypeCode;

        // Check if the case is a product delivery, liability, integrated case
        // or screening case
        if ((caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY))
          || (caseTypeCode.equals(CASETYPECODE.LIABILITY))) {

          // ProductDelivery manipulation variables
          ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
          ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
          ProductDeliveryTypeDetails productDeliveryTypeDetails = new ProductDeliveryTypeDetails();

          // populate key for read
          productDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

          // read back productType for the case
          productDeliveryTypeDetails = productDeliveryObj.readProductType(
            productDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
            productDeliveryTypeDetails.productType,
            TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {

          // CaseHeader manipulation variables
          CaseHeaderDtls caseHeaderDtls;

          // Set key to read caseHeader
          curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
          CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

          caseHeaderKey.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

          caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

          productTypeDesc = CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
            caseHeaderDtls.integratedCaseType,
            TransactionInfo.getProgramLocale());
        }

        if (productTypeDesc == null || productTypeDesc.length() == 0) {

          // BEGIN, CR00163098, JC
          productTypeDesc = CodeTable.getOneItem(CASETYPECODE.TABLENAME,
            caseTypeCode);
        }

        caseHeaderConcernRoleDetails.productTypeDesc = productTypeDesc;

        // Add to return object
        searchCasesForDuplicateDetails.duplicatesCases.caseHeaderConcernRoleDetailsList.dtls.addRef(
          caseHeaderConcernRoleDetails);
      }

    }

    // BEGIN, CR00163646, SPD
    // Populate indicator to determine what case listing to display for
    // participant
    searchCasesForDuplicateDetails.duplicatesCases.caseHeaderConcernRoleDetailsList.displayCaseMemberInd = caseHeaderConcernRoleDetailsList.displayCaseMemberInd;
    // END, CR00163646

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.casesByConcernRoleIDKey.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listCaseForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listCase;

    // Build up the xml data needed for the tab widget
    searchCasesForDuplicateDetails.duplicatesCases.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
    // END, CR00120078

    // Return details
    return searchCasesForDuplicateDetails;
    // END, CR00102618
  }

  // END, CR00221180

  // BEGIN, CR00266421, ZV
  // BEGIN, CR00227186, SK
  /**
   * Retrieves the list of all the wait list entries for a person.
   *
   * @param concernRoleKey
   * The concern role ID of the person.
   *
   * @return The list of all the wait list entries for a person.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP1, replaced by {@link #listWaitList()}
   */
  @Deprecated
  public ConcernRoleWaitListDetailsList listWaitListsForConcernRole(
    final ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {

    ConcernRoleWaitListDetailsList listConcernRoleWaitListDetailsList = new ConcernRoleWaitListDetailsList();

    MaintainPerson maintainPersonObj = MaintainPersonFactory.newInstance();

    listConcernRoleWaitListDetailsList.details = maintainPersonObj.listWaitListsForPerson(
      concernRoleKey);

    return listConcernRoleWaitListDetailsList;
  }

  // END, CR00227186
  // END, CR00266421

  // BEGIN, CR00228524, DJ
  /**
   * Cancels a concern role address record.
   *
   * @param key
   * contains the concern role address which is to be canceled
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelAddress(final CancelParticipantAddressKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelAddress(key);
  }

  /**
   * Cancels a concern role alternate id record.
   *
   * @param key
   * contains the concern role alternate id which is being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelAlternateID(final CancelParticipantAlternateIDKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelAlternateID(key);
  }

  /**
   * Cancels a communication on a case.
   *
   * @param key
   * contains the key to cancel the communication.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  public void cancelCommunication(final CancelCommunicationKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelCommunication(key);
  }

  /**
   * Cancels a concern role communication exception record.
   *
   * @param key
   * contains the ID of the communication exception being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelCommunicationException(
    final CancelParticipantCommunicationExceptionKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelCommunicationException(key);
  }

  /**
   * Cancels a contact record.
   *
   * @param key
   * contains the contact ID for the record being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelContact(final CancelContactKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelContact(key);
  }

  /**
   * Cancel an email address for a participant.
   *
   * @param key
   * contains the ID of the email address being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelEmailAddress(final CancelParticipantEmailAddressKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelEmailAddress(key);
  }

  /**
   * Cancel a note for a participant.
   *
   * @param details
   * contains the details to create a participant note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelNote(final CancelParticipantNoteDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelNote(details);
  }

  /**
   * Cancel a bank account for a participant.
   * This method handles the cancellation of normal bank account
   * as well as joint accounts.
   *
   * @param key contains the ID of the bank account being canceled.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public InformationMsgDtlsList cancelParticipantBankAccount(
    final CancelParticipantBankAccountKey key)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList = delegate.cancelParticipantBankAccount(key);
    return informationMsgDtlsList;
  }

  /**
   * Cancels a phone number record.
   *
   * @param key
   * contains the concern role phone number ID of the phone record being
   * canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelPhoneNumber(final CancelParticipantPhoneNumberKey key)
    throws AppException, InformationalException {
    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelPhoneNumber(key);
  }

  /**
   * Cancel a web address for a participant.
   *
   * @param details
   * contains the details of the web address to cancel
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelWebAddress(final CancelParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelWebAddress(details);
  }

  /**
   * Creates a concern role address record.
   *
   * @param details
   * contains the concern role ID and the address details.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantAddressDetails createAddress(
    final MaintainParticipantAddressDetails details)
    throws AppException, InformationalException {

    CreateParticipantAddressDetails createParticipantAddressDetails = new CreateParticipantAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    createParticipantAddressDetails = delegate.createAddress(details);
    return createParticipantAddressDetails;
  }

  /**
   * Create a administrator for the concernRole specified.
   *
   * @param participantAdministratorDetails
   * The administrator details being entered.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public void createAdministrator(
    final ParticipantAdministratorDetails participantAdministratorDetails)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createAdministrator(participantAdministratorDetails);
  }

  /**
   * Create a new administrator for the concernRole supplied.
   *
   * @param details
   * contains the administrator role details being entered.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#createAdministrator(ParticipantAdministratorDetails)}
   */
  @Deprecated
  public void createAdminRole(final CreateParticipantAdminRoleDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createAdminRole(details);
  }

  /**
   * Creates a concern role alternate id record.
   *
   * @param details
   * contains the concern role ID and alternate id details being
   * entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantAlternateIDDetails createAlternateID(
    final MaintainParticipantAlternateIDDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    CreateParticipantAlternateIDDetails createParticipantAlternateIDDetails = new CreateParticipantAlternateIDDetails();

    createParticipantAlternateIDDetails = delegate.createAlternateID(details);
    return createParticipantAlternateIDDetails;
  }

  /**
   * Cancel a bank account for a participant.
   *
   * @param key
   * contains the ID of the bank account being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelBankAccount(CancelParticipantBankAccountKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    // BEGIN, CR00247430, MR
    delegate.cancelParticipantBankAccount(key);
    // END, CR00247430
  }

  /**
   * Creates a concern role communication exception record.
   *
   * @param details
   * contains the concern role communication exception details being
   * entered.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createCommunicationException(details);
  }

  /**
   * Create a contact.
   *
   * @param details
   * contains the contact details being entered
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createContact(final CreateContactDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createContact(details);
  }

  /**
   * Creates a contact record for a participant who was not previously
   * registered.
   *
   * @param details
   * contains the registration details for the contact
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createContactFromUnregisteredParticipant(
    final CreateContactFromUnregisteredParticipant details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createContactFromUnregisteredParticipant(details);
  }

  /**
   * Create a new email address for a participant.
   *
   * @param details
   * contains the email address details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantEmailAddressDetails createEmailAddress(
    final MaintainParticipantEmailAddressDetails details)
    throws AppException, InformationalException {

    CreateParticipantEmailAddressDetails createParticipantEmailAddressDetails = new CreateParticipantEmailAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    createParticipantEmailAddressDetails = delegate.createEmailAddress(details);
    return createParticipantEmailAddressDetails;
  }

  /**
   * Creates an email communication.
   *
   * @param details
   * contains the details to create the email communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Communication#createEmail(
   * curam.core.facade.struct.CreateEmailCommDetails)}
   */
  @Deprecated
  public void createEmailCommunication(
    final CreateEmailCommunicationDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createEmailCommunication(details);
  }

  /**
   * Creates a freeform communication.
   *
   * @param details
   * contains the details to create the freeform communication.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  public void createFreeformCommunincation(
    final CreateFreeformCommunication details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createFreeformCommunincation(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the home phone number is
   * created
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createHomePhoneNumber(final CreateHomePhoneNumber key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createHomePhoneNumber(key);
  }

  /**
   * This method creates a mailing address for a participant.
   *
   * @param key
   * Identifies the participant for whom the mailing address is created
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createMailingAddress(final CreateMailingAddress key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createMailingAddress(key);
  }

  /**
   * Create a note for a participant.
   *
   * @param details
   * contains the participant note details being entered.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createNote(final ParticipantNoteDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createNote(details);
  }

  /**
   * Creates a concern role phone number record.
   *
   * @param details
   * contains the concern role identifier & concern role phone number
   * details
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantPhoneDetails createPhoneNumber(
    final MaintainParticipantPhoneDetails details)
    throws AppException, InformationalException {

    CreateParticipantPhoneDetails createParticipantPhoneDetails = new CreateParticipantPhoneDetails();
    Participant delegate = ParticipantFactory.newInstance();

    createParticipantPhoneDetails = delegate.createPhoneNumber(details);
    return createParticipantPhoneDetails;
  }

  /**
   * Creates a template communication.
   *
   * @param details
   * contains the details to create the template communication.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  public void createTemplateCommunication(
    final CreateTemplateCommunication details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createTemplateCommunication(details);
  }

  /**
   * Create a new web address for a participant.
   *
   * @param details
   * contains the web address details being entered
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createWebAddress(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the work phone number is
   * created.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createWorkPhoneNumber(final CreateWorkPhoneNumber key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createWorkPhoneNumber(key);
  }

  /**
   * Display the address given as a single line. The address is formatted base
   * on the ENV_ADDRESSSTRINGFORMAT environment variable.
   *
   * @param OtherAddressData The address formatted with its descriptors i.e.
   * ADD1=Line1, ADD2=Line2, ADD3=Line3 ...
   *
   * @return AddressString, the address given as a single line.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public AddressString displaySingleLineAddress(
    final OtherAddressData otherAddressData)
    throws AppException, InformationalException {

    AddressString addressString = new AddressString();
    Participant delegate = ParticipantFactory.newInstance();

    addressString = delegate.displaySingleLineAddress(otherAddressData);
    return addressString;
  }

  /**
   * Ends all active deductions on a case for a participant.
   *
   * @param details
   * Contains the  concern role ID & the case ID
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void endDeduction(final EndDeductionDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.endDeduction(details);
  }

  /**
   * Formats the bank account details for a participant. The bank details
   * are formatted to display as a single line of text. The formatting is
   * decided by a system variable.
   *
   * @param bankAccountRMDtls bank account details to be formatted
   *
   * @return Formatted string of bank account details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public BankAccountString formatBankAcDetailsString(
    final BankAccountRMDtls bankAccountRMDtls)
    throws AppException, InformationalException {

    BankAccountString bankAccountString = new BankAccountString();
    Participant delegate = ParticipantFactory.newInstance();

    bankAccountString = delegate.formatBankAcDetailsString(bankAccountRMDtls);
    return bankAccountString;
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the primary residence address
   * is created
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void insertPrimaryResidenceAddress(final InsertPrimaryResAddress key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.insertPrimaryResidenceAddress(key);
  }

  /**
   * Retrieves a list of active address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of active addresses returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantActiveAddressList listActiveAddresses(
    final ReadParticipantAddressListKey key)
    throws AppException, InformationalException {

    final ReadParticipantActiveAddressList readParticipantActiveAddressList = new ReadParticipantActiveAddressList();
    Participant delegate = ParticipantFactory.newInstance();

    delegate.listActiveAddresses(key);
    return readParticipantActiveAddressList;
  }

  /**
   * Method to list all active bank accounts for a Case Nominee.
   *
   * @param key
   * contains the concernRoleID
   *
   * @return list of all active bank accounts for a participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadActiveBankAccountList listActiveBankAccount(
    final ReadParticipantBankAccountListKey key) throws AppException,
      InformationalException {

    final ReadActiveBankAccountList readActiveBankAccountList = new ReadActiveBankAccountList();
    Participant delegate = ParticipantFactory.newInstance();

    delegate.listActiveBankAccount(key);
    return readActiveBankAccountList;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains concernRoleID and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated since Curam V6.0. This method is replaced by
   * {@link #listActiveBankAccountForRedirection1()}.
   */
  @Deprecated
  public BankAccountListForRedirectionDetails listActiveBankAccountForRedirection(
    final ParticipantBankAccountRedirectionKey key)
    throws AppException, InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails = new BankAccountListForRedirectionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    bankAccountListForRedirectionDetails = delegate.listActiveBankAccountForRedirection(
      key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains bank account id and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public BankAccountListForRedirectionDetails listActiveBankAccountForRedirection1(
    ParticipantBankAccountRedirectionKey1 key)
    throws AppException, InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails = new BankAccountListForRedirectionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    bankAccountListForRedirectionDetails = delegate.listActiveBankAccountForRedirection1(
      key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Retrieves a list of address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAddressList listAddress(final ReadParticipantAddressListKey key)
    throws AppException, InformationalException {

    ReadParticipantAddressList readParticipantAddressList = new
      ReadParticipantAddressList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAddressList = delegate.listAddress(key);
    return readParticipantAddressList;
  }

  /**
   * Method returns a list of Address Snapshot details, and the date-of-creation
   * for each Snapshot record.
   *
   * @param key contains the Address record the snapshots are associated with.
   *
   * @return The list of Address snapshot summary details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadAddressHistoryList listAddressHistory(final ReadAddressHistoryListKey key)
    throws AppException, InformationalException {

    ReadAddressHistoryList readAddressHistoryList = new ReadAddressHistoryList();
    Participant delegate = ParticipantFactory.newInstance();

    readAddressHistoryList = delegate.listAddressHistory(key);
    return  readAddressHistoryList;
  }

  /**
   * Retrieves a list of address records for a concern role and displays them as
   * strings.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantAddressStringList listAddressString(
    final ReadParticipantAddressListKey key)
    throws AppException, InformationalException {

    final ParticipantAddressStringList participantAddressStringList = new
      ParticipantAddressStringList();
    final Participant delegate = ParticipantFactory.newInstance();

    delegate.listAddressString(key);
    return participantAddressStringList;
  }

  /**
   * Retrieves a list of administrators for the specified concern role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is
   * returned.
   *
   * @return The list of administrators returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ParticipantAdministratorDetailsList listAdministrators(
    ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList = new ParticipantAdministratorDetailsList();
    Participant delegate = ParticipantFactory.newInstance();

    participantAdministratorDetailsList = delegate.listAdministrators(
      readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administrators for the specified duplicate concern
   * role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is
   * returned
   *
   * @return The list of administrators for the duplicate concern role
   * specified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public ParticipantAdministratorDetailsList listAdministratorsForDuplicateParticipant(
    ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList = new ParticipantAdministratorDetailsList();
    Participant delegate = ParticipantFactory.newInstance();

    participantAdministratorDetailsList = delegate.listAdministratorsForDuplicateParticipant(
      readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administration roles for the specified concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministrators(ReadParticipantAdminRoleListKey)}
   */
  @Deprecated
  public ReadParticipantAdminRoleList listAdminRole(
    final ReadParticipantAdminRoleListKey key)
    throws AppException, InformationalException {

    ReadParticipantAdminRoleList readParticipantAdminRoleList = new ReadParticipantAdminRoleList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAdminRoleList = delegate.listAdminRole(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of administration roles for the specified duplicate
   * concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministratorsForDuplicateParticipant(
   * ReadParticipantAdminRoleListKey)}
   */
  @Deprecated
  public ReadParticipantAdminRoleList listAdminRoleForDuplicate(
    final ReadParticipantAdminRoleListKey key)
    throws AppException, InformationalException {

    ReadParticipantAdminRoleList readParticipantAdminRoleList = new ReadParticipantAdminRoleList();
    Participant delegate = ParticipantFactory.newInstance();

    delegate.listAdminRoleForDuplicate(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of alternate id records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of alternate ID's is
   * returned.
   *
   * @return The list of alternate ID's returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAlternateIDList listAlternateID(
    final ReadParticipantAlternateIDListKey key)
    throws AppException, InformationalException {

    ReadParticipantAlternateIDList readParticipantAlternateIDList = new ReadParticipantAlternateIDList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAlternateIDList = delegate.listAlternateID(key);
    return readParticipantAlternateIDList;
  }

  /**
   * Method returns a list of AlternateID Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key contains the alternateID of the AlternateID record the snapshots
   * are  associated with.
   *
   * @return The list of AlternateID snapshot details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAltIDHistoryList listAlternateIDHistory(
    final ReadParticipantAltIDHistoryListKey key)
    throws AppException, InformationalException {

    ReadParticipantAltIDHistoryList readParticipantAltIDHistoryList = new ReadParticipantAltIDHistoryList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAltIDHistoryList = delegate.listAlternateIDHistory(key);
    return readParticipantAltIDHistoryList;
  }

  /**
   * Method returns a list of Assessments for the participant.
   *
   * @param concernRoleKey contains the concern role that the assessments were
   * created for.
   *
   * @return The list of Assessments for the concern role.
   */
  public ParticipantAssessmentsList listAssessments(
    final ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {

    ParticipantAssessmentsList participantAssessmentsList = new ParticipantAssessmentsList();
    Participant delegate = ParticipantFactory.newInstance();

    participantAssessmentsList = delegate.listAssessments(concernRoleKey);
    return participantAssessmentsList;
  }

  /**
   * Retrieves a list of bank accounts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of bank accounts is
   * returned.
   *
   * @return The list of bank accounts returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantBankAccountList listBankAccount(
    ReadParticipantBankAccountListKey key)
    throws AppException, InformationalException {

    ReadParticipantBankAccountList readParticipantBankAccountList = new  ReadParticipantBankAccountList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAccountList = delegate.listBankAccount(key);
    return readParticipantBankAccountList;
  }

  /**
   * Method returns a list of ConcernRole Bank Account Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key contains the ConcernRole Bank Account record the snapshots are
   * associated with.
   *
   * @return The list of ConcernRole Bank Account snapshot details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantBankAcHistoryList listBankAccountHistory(
    ReadParticipantBankAcHistoryListKey key)
    throws AppException, InformationalException {

    ReadParticipantBankAcHistoryList readParticipantBankAcHistoryList = new ReadParticipantBankAcHistoryList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAcHistoryList = delegate.listBankAccountHistory(key);
    return readParticipantBankAcHistoryList;
  }

  /**
   * Lists the formatted bank account details. The bank details
   * are formatted to display as a single line of text.
   *
   * @param key concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantBankAccountStringList listBankAccountString(
    MaintainConcernRoleKey key) throws AppException, InformationalException {

    ParticipantBankAccountStringList participantBankAccountStringList = new ParticipantBankAccountStringList();
    Participant delegate = ParticipantFactory.newInstance();

    participantBankAccountStringList = delegate.listBankAccountString(key);
    return participantBankAccountStringList;
  }

  /**
   * Lists all communications by case ID.
   *
   * @param key Contains the case identifier.
   * @return List of communications on the case.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CommunicationDetailList listCommunication(
    ParticipantCommunicationKey key)
    throws AppException, InformationalException {

    CommunicationDetailList communicationDetailList = new CommunicationDetailList();
    Participant delegate = ParticipantFactory.newInstance();

    communicationDetailList = delegate.listCommunication(key);
    return communicationDetailList;
  }

  /**
   * Retrieves a list of communication exception records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of communication
   * exceptions  are returned.
   *
   * @return The list of communication exceptions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantCommunicationExceptionList listCommunicationException(
    ReadParticipantCommunicationExceptionListKey key)
    throws AppException, InformationalException {

    ReadParticipantCommunicationExceptionList readParticipantCommunicationExceptionList = new ReadParticipantCommunicationExceptionList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantCommunicationExceptionList = delegate.listCommunicationException(
      key);
    return readParticipantCommunicationExceptionList;
  }

  /**
   * Retrieves a list of client role records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantConcernRoleList listConcernRole(
    ReadParticipantConcernRoleKey key)
    throws AppException, InformationalException {

    ReadParticipantConcernRoleList readParticipantConcernRoleList = new ReadParticipantConcernRoleList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantConcernRoleList = delegate.listConcernRole(key);
    return readParticipantConcernRoleList;
  }

  /**
   * Retrieves a list of client role records for a duplicate concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadDuplicateParticipantConcernRoleList listConcernRoleForDuplicate(
    ReadParticipantConcernRoleKey key)
    throws AppException, InformationalException {

    ReadDuplicateParticipantConcernRoleList readDuplicateParticipantConcernRoleList = new ReadDuplicateParticipantConcernRoleList();
    Participant delegate = ParticipantFactory.newInstance();

    readDuplicateParticipantConcernRoleList = delegate.listConcernRoleForDuplicate(
      key);
    return readDuplicateParticipantConcernRoleList;
  }
  
  // BEGIN, CR00294967, MV
  /**
   * A list of contacts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #listConcernContact()}. The
   * return struct of the current method listContact has an
   * aggregation to the struct ConcernContactRMDtls, the attribute
   * statusCode in the struct ConcernContactRMDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct ListConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  // END, CR00294967
  public ListContactDetails listContact(ListContactKey key)
    throws AppException, InformationalException {

    ListContactDetails listContactDetails = new ListContactDetails();
    Participant delegate = ParticipantFactory.newInstance();

    listContactDetails = delegate.listContact(key);
    return listContactDetails;
  }
 
  // BEGIN, CR00294967, MV
  /**
   * Lists the contacts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListConcernContactDetails listConcernContact(final ListContactKey key)
    throws AppException, InformationalException {

    ListConcernContactDetails listConcernContactDetails = new ListConcernContactDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    listConcernContactDetails = delegate.listConcernContact(key);
    return listConcernContactDetails;
  }

  // END, CR00294967

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantDeductionList listDeduction(ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ReadParticipantDeductionList readParticipantDeductionList = new ReadParticipantDeductionList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantDeductionList = delegate.listDeduction(key);
    return readParticipantDeductionList;
  }

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantDeductionList1 listDeduction1(ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ReadParticipantDeductionList1 readParticipantDeductionList1 = new ReadParticipantDeductionList1();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantDeductionList1 = delegate.listDeduction1(key);
    return readParticipantDeductionList1;
  }

  /**
   * Retrieves a list of deduction records for a duplicate concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadDuplicateParticipantDeductionList listDeductionForDuplicate(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ReadDuplicateParticipantDeductionList readDuplicateParticipantDeductionList = new ReadDuplicateParticipantDeductionList();
    Participant delegate = ParticipantFactory.newInstance();

    readDuplicateParticipantDeductionList = delegate.listDeductionForDuplicate(
      key);
    return readDuplicateParticipantDeductionList;
  }

  /**
   * Retrieves a list of email addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of email addresses
   * is returned.
   *
   * @return The list of email addresses returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantEmailAddressList listEmailAddress(
    ReadParticipantEmailAddressListKey key)
    throws AppException, InformationalException {

    ReadParticipantEmailAddressList readParticipantEmailAddressList = new ReadParticipantEmailAddressList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantEmailAddressList = delegate.listEmailAddress(key);
    return readParticipantEmailAddressList;
  }

  /**
   * Lists all addresses for a participant formatted for use in a pop-up list.
   *
   * @param readParticipantFormattedAddressListKey
   * contains concernRoleID
   *
   * @return List of formatted addresses for participant
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public FormattedAddressList listFormattedAddress(
    ReadParticipantFormattedAddressListKey
    readParticipantFormattedAddressListKey)
    throws AppException, InformationalException {

    FormattedAddressList formattedAddressList = new FormattedAddressList();
    Participant delegate = ParticipantFactory.newInstance();

    formattedAddressList = delegate.listFormattedAddress(
      readParticipantFormattedAddressListKey);
    return formattedAddressList;
  }

  /**
   * Reads formatted bankAccount data for a Participant.
   *
   * @param readParticipantFormattedBankAccountListKey
   * contains concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public FormattedBankAccountList listFormattedBankAccount(
    ReadParticipantFormattedBankAccountListKey
    readParticipantFormattedBankAccountListKey)
    throws AppException, InformationalException {

    FormattedBankAccountList formattedBankAccountList = new FormattedBankAccountList();
    Participant delegate = ParticipantFactory.newInstance();

    formattedBankAccountList = delegate.listFormattedBankAccount(
      readParticipantFormattedBankAccountListKey);
    return formattedBankAccountList;
  }

  /**
   * Retrieves a list of clients interaction details.
   *
   * @param key
   * contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListInteractionDetails listInteraction(final ListInteractionKey key)
    throws AppException, InformationalException {

    ListInteractionDetails listInteractionDetails = new ListInteractionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    listInteractionDetails = delegate.listInteraction(key);
    return listInteractionDetails;
  }

  /**
   * Retrieves a list of duplicate client interaction details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListDuplicateParticipantInteractionDetails listInteractionForDuplicate(
    final ListInteractionKey key)
    throws AppException, InformationalException {

    ListDuplicateParticipantInteractionDetails listDuplicateParticipantInteractionDetails = new ListDuplicateParticipantInteractionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantInteractionDetails = delegate.listInteractionForDuplicate(
      key);
    return listDuplicateParticipantInteractionDetails;
  }

  /**
   * Method returns a list of Investigations for the participant.
   *
   * @param key contains the  concern role that the investigations
   * were created for.
   *
   * @return The list of Investigations for the concern role.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantInvestigationList listInvestigations(
    final SearchCaseKey_fo key)
    throws AppException, InformationalException {

    ParticipantInvestigationList participantInvestigationList = new ParticipantInvestigationList();
    Participant delegate = ParticipantFactory.newInstance();

    participantInvestigationList = delegate.listInvestigations(key);
    return participantInvestigationList;
  }

  /**
   * Retrieves a list of issued payment instruments for a concern role, where
   * the client is the concern or the nominee.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of payment instruments returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListParticipantIssuedPaymentInstrument listIssuedPaymentInstrument(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ListParticipantIssuedPaymentInstrument listParticipantIssuedPaymentInstrument = new ListParticipantIssuedPaymentInstrument();
    Participant delegate = ParticipantFactory.newInstance();

    listParticipantIssuedPaymentInstrument = delegate.listIssuedPaymentInstrument(
      key);
    return listParticipantIssuedPaymentInstrument;
  }

  /**
   * Retrieves a list of duplicate client issued payment instrument details.
   *
   * @param key Contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListDuplicateParticipantIssuedPaymentInstrument listIssuedPaymentInstrumentForDuplicate(
    ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ListDuplicateParticipantIssuedPaymentInstrument listDuplicateParticipantIssuedPaymentInstrument = new
      ListDuplicateParticipantIssuedPaymentInstrument();
    Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantIssuedPaymentInstrument = delegate.listIssuedPaymentInstrumentForDuplicate(
      key);
    return listDuplicateParticipantIssuedPaymentInstrument;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Retrieve a list of notes for a participant.
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated - replaced by {@link #listNote1()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  public ParticipantNoteList listNote(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList participantNoteList = new ParticipantNoteList();
    Participant delegate = ParticipantFactory.newInstance();

    participantNoteList = delegate.listNote(key);
    return participantNoteList;
  }

  /**
   * Retrieve a list of notes for a participant.
   *
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantNoteList1 listNote1(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList1 participantNoteList = new ParticipantNoteList1();
    Participant delegate = ParticipantFactory.newInstance();

    participantNoteList = delegate.listNote1(key);
    return participantNoteList;
  }

  // END, CR00231506

  /**
   * @param key
   * contains the key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listParticipantFinancial1()}.
   * Returns a list of financials for a participant.
   */
  @Deprecated
  public ListParticipantFinancials listParticipantFinancial(
    final ListParticipantFinancialsKey key) throws AppException,
      InformationalException {
    ListParticipantFinancials listParticipantFinancials = new ListParticipantFinancials();
    Participant delegate = ParticipantFactory.newInstance();

    listParticipantFinancials = delegate.listParticipantFinancial(key);
    return listParticipantFinancials;
  }

  /**
   * Returns a list of financials for a participant.
   *
   * @param key
   * Key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListParticipantFinancials1 listParticipantFinancial1(
    ListParticipantFinancialsKey key)
    throws AppException, InformationalException {

    ListParticipantFinancials1 listParticipantFinancials1 = new  ListParticipantFinancials1();
    Participant delegate = ParticipantFactory.newInstance();

    listParticipantFinancials1 = delegate.listParticipantFinancial1(key);
    return listParticipantFinancials1;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListDuplicateParticipantFinancials listParticipantFinancialForDuplicate(
    final ListParticipantFinancialsKey key)
    throws AppException, InformationalException {

    ListDuplicateParticipantFinancials listDuplicateParticipantFinancials = new ListDuplicateParticipantFinancials();
    Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantFinancials = delegate.listParticipantFinancialForDuplicate(
      key);
    return listDuplicateParticipantFinancials;
  }

  /**
   * Returns a list of tasks for a participant.
   *
   * @param key
   * contains the key to return a list of tasks for a participant.
   *
   * @return List of tasks for a participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public TasksForConcernAndCaseDetails listParticipantTask(
    final ListParticipantTaskKey_eo key)
    throws AppException, InformationalException {

    TasksForConcernAndCaseDetails tasksForConcernAndCaseDetails = new TasksForConcernAndCaseDetails();
    Participant delegate = ParticipantFactory.newInstance();

    tasksForConcernAndCaseDetails = delegate.listParticipantTask(key);
    return tasksForConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public TasksForDuplicateConcernAndCaseDetails listParticipantTaskForDuplicate(
    final ListParticipantTaskKey_eo key)
    throws AppException, InformationalException {

    TasksForDuplicateConcernAndCaseDetails tasksForDuplicateConcernAndCaseDetails = new TasksForDuplicateConcernAndCaseDetails();
    Participant delegate = ParticipantFactory.newInstance();

    tasksForDuplicateConcernAndCaseDetails = delegate.listParticipantTaskForDuplicate(
      key);
    return tasksForDuplicateConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of phone number records for a concern role.
   *
   * @param key
   * contains the concern role id for which a list of phone numbers are
   * returned.
   *
   * @return The list of phone numbers returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantPhoneNumberList listPhoneNumber(
    final ReadParticipantPhoneNumberListKey key)
    throws AppException, InformationalException {

    ReadParticipantPhoneNumberList readParticipantPhoneNumberList = new ReadParticipantPhoneNumberList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantPhoneNumberList = delegate.listPhoneNumber(key);
    return readParticipantPhoneNumberList;
  }

  /**
   * Lists screening cases for the specified participant.
   *
   * @param key Identifies the concern role
   *
   * @return The screening cases for the participant as read from the database.
   */
  public ParticipantScreeningList listScreeningCases(final SearchCaseKey_fo key)
    throws AppException, InformationalException {

    ParticipantScreeningList participantScreeningList = new ParticipantScreeningList();
    Participant delegate = ParticipantFactory.newInstance();

    participantScreeningList = delegate.listScreeningCases(key);
    return participantScreeningList;
  }

  /**
   * Returns a list of templates based on template type and the participant
   * identifier.
   *
   * @param key
   * contains the key to read the list of templates.
   *
   * @return List of templates for participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListTemplateByTypeAndParticpant listTemplateByTypeAndParticipant(
    final ListTemplateByTypeAndParticipantKey key)
    throws AppException, InformationalException {

    ListTemplateByTypeAndParticpant listTemplateByTypeAndParticpant = new ListTemplateByTypeAndParticpant();
    Participant delegate = ParticipantFactory.newInstance();

    listTemplateByTypeAndParticpant = delegate.listTemplateByTypeAndParticipant(
      key);
    return listTemplateByTypeAndParticpant;
  }

  /**
   * Retrieves a list of web addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of web addresses is
   * returned
   * @return The list of web addresses returned from the database
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantWebAddressList listWebAddress(
    final ParticipantWebAddressListKey key)
    throws AppException, InformationalException {

    ParticipantWebAddressList participantWebAddressList = new ParticipantWebAddressList();
    Participant delegate = ParticipantFactory.newInstance();

    participantWebAddressList = delegate.listWebAddress(key);
    return participantWebAddressList;
  }

  /**
   * Modifies an address record for a concern role.
   *
   * @param details
   * contains the concern role ID and concern role address details.
   *
   * @return ModifiedAddressDetails modified address details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ModifiedAddressDetails modifyAddress(
    final MaintainParticipantAddressDetails details)
    throws AppException, InformationalException {

    ModifiedAddressDetails modifiedAddressDetails = new
      ModifiedAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    modifiedAddressDetails = delegate.modifyAddress(details);
    return modifiedAddressDetails;
  }

  /**
   * Modifies an alternate id record for a concern role.
   *
   * @param details
   * contains the concern role ID and alternate id detail being
   * modified.
   *
   * @return ModifiedAlternateIDDetails modified alternateID details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ModifiedAlternateIDDetails modifyAlternateID(
    final MaintainParticipantAlternateIDDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ModifiedAlternateIDDetails modifiedAlternateIDDetails = new ModifiedAlternateIDDetails();

    modifiedAlternateIDDetails = delegate.modifyAlternateID(details);
    return modifiedAlternateIDDetails;
  }

  /**
   * @param details
   * contains the bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #modifyBankAccountWithTextSortCode()}.
   * Modify the bank account details for a participant.
   */
  @Deprecated
  public InformationMsgDtlsList modifyBankAccount(
    final MaintainParticipantBankAccountDetails details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList = delegate.modifyBankAccount(details);
    return informationMsgDtlsList;
  }

  /**
   * Modifies the details of a communication.
   *
   * @param details
   * contains the details to modify the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Deprecated
  public void modifyCommunication(final ModifyCommDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyCommunication(details);
  }

  /**
   * Modifies a communication exception record for a concern role.
   *
   * @param details
   * contains the concern role communication exception details being
   * modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyCommunicationException(details);
  }

  // BEGIN, CR00294967, MV
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #modifyConcernContact()}.
   * The parameter struct of the current method modifyContact has
   * an aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to have new parameter ModifyConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  // END, CR00294967
  public void modifyContact(final ModifyContactDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyContact(details);
  }
  
  // BEGIN, CR00294967, MV
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyConcernContact(final ModifyConcernContactDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyConcernContact(details);
  }

  // END, CR00294967

  /**
   * Modify the details of an email address for a participant.
   *
   * @param details
   * contains the email address details being modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyEmailAddress(
    final MaintainParticipantEmailAddressDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyEmailAddress(details);
  }

  // BEGIN, CR00231506, PDN
  /**
   * Modify the details of a note for a participant.
   *
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  public void modifyNote(final ModifyParticipantNoteDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyNote(details);
  }

  /**
   * Modify the details of a note for a participant.
   *
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyNote1(ModifyParticipantNoteDetails1 details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyNote1(details);
  }

  /**
   * Modifies a phone number record for a concern role.
   *
   * @param details
   * contains the concern role id and concern role phone number details
   * that  will be modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyPhoneNumber(final MaintainParticipantPhoneDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyPhoneNumber(details);
  }

  /**
   * Modifies the details of a sent communication.
   *
   * @param details
   * contains the details of the sent communication to be modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifySentCommunication(
    final ModifySentCommunicationDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifySentCommunication(details);
  }

  /**
   * Modify the details of a web address for a participant.
   *
   * @param details
   * contains the web address details being modified
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyWebAddress(details);
  }

  /**
   * Prints a communication.
   *
   * @param details
   * contains details to print the communication.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void printCommunication(final PrintCommunicationKey details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.printCommunication(details);
  }

  /**
   * Reads an address record for a concern role.
   *
   * @param key
   * contains the concern role address key.
   *
   * @return The address details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAddressDetails readAddress(
    final ReadParticipantAddressKey key)
    throws AppException, InformationalException {

    ReadParticipantAddressDetails readParticipantAddressDetails = new  ReadParticipantAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAddressDetails = delegate.readAddress(key);
    return readParticipantAddressDetails;
  }

  /**
   * Reads an alternate id record for a concern role.
   *
   * @param key
   * contains the concern role alternate id of the record being read.
   *
   * @return The alternate ID details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAlternateIDDetails readAlternateID(
    final ReadParticipantAlternateIDKey key)
    throws AppException, InformationalException {

    ReadParticipantAlternateIDDetails readParticipantAlternateIDDetails = new ReadParticipantAlternateIDDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAlternateIDDetails = delegate.readAlternateID(key);
    return readParticipantAlternateIDDetails;
  }

  /**
   * Read the details of a participants bank account.
   *
   * @param key
   * contains the bank account ID of the record being read.
   *
   * @return The bank account details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantBankAccountDetails readBankAccount(
    final ReadParticipantBankAccountKey key)
    throws AppException, InformationalException {

    ReadParticipantBankAccountDetails readParticipantBankAccountDetails = new ReadParticipantBankAccountDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAccountDetails = delegate.readBankAccount(key);
    return readParticipantBankAccountDetails;
  }

  /**
   * Reads details of a communication.
   *
   * @param key
   * contains the communication identifier.
   *
   * @return Details of the communication.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated
   */
  @Deprecated
  public ReadCommDetails readCommunication(final ReadCommKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ReadCommDetails readCommDetails = new ReadCommDetails();

    readCommDetails = delegate.readCommunication(key);
    return readCommDetails;
  }

  /**
   * Reads details of a communication attachment.
   *
   * @param key
   * contains the key to read the communication attachment details.
   *
   * @return ReadCommunicationAttachmentDetails Details of the communication
   * attachment.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadCommunicationAttachmentDetails readCommunicationAttachment(
    final ReadAttachmentKey key) throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ReadCommunicationAttachmentDetails readCommunicationAttachmentDetails = new ReadCommunicationAttachmentDetails();

    readCommunicationAttachmentDetails = delegate.readCommunicationAttachment(
      key);
    return readCommunicationAttachmentDetails;
  }

  /**
   * Reads a communication exception record for a concern role.
   *
   * @param key
   * contains the communication exception ID of the record being read.
   *
   * @return The communication exception details found returned from the
   * database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantCommunicationExceptionDetails readCommunicationException(
    final ReadParticipantCommunicationExceptionKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ReadParticipantCommunicationExceptionDetails readParticipantCommunicationExceptionDetails = new ReadParticipantCommunicationExceptionDetails();

    readParticipantCommunicationExceptionDetails = delegate.readCommunicationException(
      key);
    return readParticipantCommunicationExceptionDetails;
  }

  /**
   * Reads the concernRoleType for a concernRole.
   *
   * @param key
   * contains the concern role ID for which the concernRoleType is read
   *
   * @return The concernRoleType.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ConcernRoleTypeDetails readConcernRoleType(
    final ReadParticipantConcernRoleKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ConcernRoleTypeDetails concernRoleTypeDetails = new ConcernRoleTypeDetails();

    concernRoleTypeDetails = delegate.readConcernRoleType(key);
    return concernRoleTypeDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #readConcernContact()}. The
   * return struct of the current method readContact has an
   * aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct ReadConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  // END, CR00294967
  public ReadContactDetails readContact(final ReadContactKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ReadContactDetails readContactDetails = new ReadContactDetails();

    readContactDetails = delegate.readContact(key);
    return readContactDetails;
  }
  
  // BEGIN, CR00294967, MV
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadConcernContactDetails readConcernContact(final ReadContactKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadConcernContactDetails readConcernContactDetails = new ReadConcernContactDetails();

    readConcernContactDetails = delegate.readConcernContact(key);
    return readConcernContactDetails;
  }

  // END, CR00294967

  /**
   * Read the context description for a concern role ID.
   *
   * @param key
   * contains the concern role ID for which the description is
   * retrieved.
   *
   * @return The returned description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantContextDetails readContextDescription(
    final ParticipantContextKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    participantContextDetails = delegate.readContextDescription(key);
    return participantContextDetails;
  }

  /**
   * Read the details for a participants email address.
   *
   * @param key
   * contains the email address ID of the record being read.
   *
   * @return The email address details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantEmailAddressDetails readEmailAddress(
    final ReadParticipantEmailAddressKey key)
    throws AppException, InformationalException {

    ReadParticipantEmailAddressDetails readParticipantEmailAddressDetails = new ReadParticipantEmailAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantEmailAddressDetails = delegate.readEmailAddress(key);
    return readParticipantEmailAddressDetails;
  }

  /**
   * Retrieves a person's interaction details.
   *
   * @param key
   * identifies interaction to be found.
   *
   * @return A person's interaction details found.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadInteractionDetails readInteraction(final ReadInteractionKey key)
    throws AppException, InformationalException {

    ReadInteractionDetails readInteractionDetails = new ReadInteractionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readInteractionDetails = delegate.readInteraction(key);
    return readInteractionDetails;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Read the details of a note for a participant.
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated - replaced by {@link #readNote1()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  public ReadParticipantNoteDetails readNote(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails readParticipantNoteDetails = new ReadParticipantNoteDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote(key);
    return readParticipantNoteDetails;
  }

  /**
   * Read the details of a note for a participant.
   *
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantNoteDetails1 readNote1(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails1 readParticipantNoteDetails = new ReadParticipantNoteDetails1();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote1(key);
    return readParticipantNoteDetails;
  }

  // END, CR00231506

  /**
   * Read the Contact Context Description Details for a Participant.
   *
   * @param key
   * contains the contact ID the context description is returned for.
   *
   * @return The contact context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ContactContextDescriptionDetails readParticipantContactContextDescription(
    final ContactContextDescriptionKey key)
    throws AppException, InformationalException {

    ContactContextDescriptionDetails contactContextDescriptionDetails = new ContactContextDescriptionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    contactContextDescriptionDetails = delegate.readParticipantContactContextDescription(
      key);
    return contactContextDescriptionDetails;
  }

  /**
   * Reads a phone number record for a concern role.
   *
   * @param key contains the concern role phone number ID.
   *
   * @return The phone number details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantPhoneNumberDetails readPhoneNumber(
    final ReadParticipantPhoneNumberKey key)
    throws AppException, InformationalException {

    ReadParticipantPhoneNumberDetails readParticipantPhoneNumberDetails = new  ReadParticipantPhoneNumberDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantPhoneNumberDetails = delegate.readPhoneNumber(key);
    return readParticipantPhoneNumberDetails;
  }

  /**
   * Read the details for a participants web address.
   *
   * @param key
   * contains the web address ID of the record being read.
   *
   * @return The web address details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantWebAddressDetails readWebAddress(
    final ParticipantWebAddressKey key)
    throws AppException, InformationalException {

    ReadParticipantWebAddressDetails readParticipantWebAddressDetails = new ReadParticipantWebAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantWebAddressDetails = delegate.readWebAddress(key);
    return readParticipantWebAddressDetails;
  }

  /**
   * Records an existing communication.
   *
   * @param details
   * contains the details of the existing communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Deprecated
  public void recordExistingCommunication(
    final RecordExistingCommunicationDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.recordExistingCommunication(details);
  }

  /**
   * Removes an address record for a concern role.
   *
   * @param key contains the concern role address key
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void removeAddress(final ReadParticipantAddressKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.removeAddress(key);
  }

  /**
   * Resolves the home page for prospect person and prospect employer.
   *
   * Security checks are not applied in this method as it must be used from
   * the resolve script only.
   *
   * @param key contains the concern Role ID of the record being read.
   *
   * @return The home page name.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantHomePageName resolveProspectHome(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ParticipantHomePageName participantHomePageName = new ParticipantHomePageName();
    Participant delegate = ParticipantFactory.newInstance();

    participantHomePageName = delegate.resolveProspectHome(key);
    return participantHomePageName;
  }

  // BEGIN, CR00233791, DJ
  // BEGIN, CR00290965, IBM
  /**
   * Searches for all Participants by specified search criteria.
   *
   * @param key Participant search criteria
   *
   * @return Participant details found
   *
   * @throws InformationalException Informational Exception
   * @throws AppException Application Exception
   *
   * @deprecated Since Curam 6.0 SP2, replaced with {@link 
   * Person#searchParticipantDetails(AllParticipantSearchKey)}
   *
   * This method is deprecated as informational messages are not returned. This 
   * method is replaced by searchParticipantDetails(AllParticipantSearchKey) 
   * which returns the informational message along with participant details as 
   * well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public AllParticipantSearchResult searchParticipant(
    AllParticipantSearchKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    AllParticipantSearchResult allParticipantSearchResult = new AllParticipantSearchResult();
    Participant delegate = ParticipantFactory.newInstance();

    allParticipantSearchResult = delegate.searchParticipant(key);
    return allParticipantSearchResult;
  }

  // END, CR00233791
  /**
   * Sends an email communication.
   *
   * @Deprecated
   * @param details
   * contains the details to send the communication.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  public void sendEmailCommunication(final SendEmailCommKey details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.sendEmailCommunication(details);
  }

  /**
   * Updates the payment details for all cases, where the old bank account was
   * being paid, to the new bank account.
   *
   * @param key
   * contains the concern role ID and the bank
   * account ID of the bank for which payment will now be made to.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void updateBankAccountPaymentDetails(
    final UpdateBankAccPaymentDtlsKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.updateBankAccountPaymentDetails(key);
  }

  /**
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createBankAccountWithTextSortCode()}.
   * Create a new bank account for a participant.
   */
  @Deprecated
  public CreateParticipantBankAccountDetails createBankAccount(
    MaintainParticipantBankAccountDetails details)
    throws AppException, InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails = new CreateParticipantBankAccountDetails();
    Participant delegate = ParticipantFactory.newInstance();

    createParticipantBankAccountDetails = delegate.createBankAccount(details);
    return createParticipantBankAccountDetails;
  }

  /**
   * Create a new bank account for a participant.
   *
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantBankAccountDetails createBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails = new CreateParticipantBankAccountDetails();
    Participant delegate = ParticipantFactory.newInstance();

    createParticipantBankAccountDetails = delegate.createBankAccountWithTextSortCode(
      details);
    return createParticipantBankAccountDetails;
  }

  /**
   * Modify the bank account details for a participant.
   *
   * @param details
   * The bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public InformationMsgDtlsList modifyBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList = delegate.modifyBankAccountWithTextSortCode(details);
    return informationMsgDtlsList;
  }

  // END, CR00228524

  // ___________________________________________________________________________
  /**
   * Reads Person Details participant evidence.
   *
   * @param details
   * Identifies person whose details are to be modified
   *
   * @return Person Details participant evidence.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadPersonEvidenceDetails readPersonEvidence(ReadPersonKey key)
    throws AppException, InformationalException {

    // Person maintenance objects
    curam.core.intf.MaintainPerson maintainPersonObj = curam.core.fact.MaintainPersonFactory.newInstance();

    // Output structure
    ReadPersonEvidenceDetails readPersonEvidenceDetails = maintainPersonObj.readPersonEvidence(
      key.maintainConcernRoleKey);

    readPersonEvidenceDetails.indigenousGroupCode = getIndigenousGroupTabList(
      readPersonEvidenceDetails.indigenousGroupCode);
    readPersonEvidenceDetails.race = getRaceTypeTabList(
      readPersonEvidenceDetails.race);

    return readPersonEvidenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads Person Details participant evidence for the modify page.
   *
   * @param details
   * Identifies person whose details are to be modified
   *
   * @return Person Details participant evidence.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadPersonEvidenceDetails readPersonEvidenceForModify(
    ReadPersonKey key) throws AppException, InformationalException {

    // Person maintenance objects
    curam.core.intf.MaintainPerson maintainPersonObj = curam.core.fact.MaintainPersonFactory.newInstance();

    // Output structure
    ReadPersonEvidenceDetails readPersonEvidenceDetails = maintainPersonObj.readPersonEvidence(
      key.maintainConcernRoleKey);

    readPersonEvidenceDetails.indigenousGroupName = getIndigenousGroupTabList(
      readPersonEvidenceDetails.indigenousGroupCode);

    return readPersonEvidenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads Client Details participant evidence.
   *
   * @param details
   * Identifies client whose details are to be modified
   *
   * @return Client Details participant evidence.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadClientEvidenceDetails readClientEvidence(ReadPersonKey key)
    throws AppException, InformationalException {

    // Person maintenance objects
    curam.core.intf.MaintainPerson maintainPersonObj = curam.core.fact.MaintainPersonFactory.newInstance();

    // Output structure
    ReadClientEvidenceDetails readClientEvidenceDetails = maintainPersonObj.readClientEvidence(
      key.maintainConcernRoleKey);

    return readClientEvidenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modifies Person Details participant evidence.
   *
   * @param details
   * Identifies person whose details are to be modified
   *
   * @return Informational messages returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public InformationalMsgDetailsList modifyPersonEvidence(
    ModifyPersonEvidenceDetails details) throws AppException,
      InformationalException {

    // Maintain Person object.
    curam.core.intf.MaintainPerson maintainPersonObj = curam.core.fact.MaintainPersonFactory.newInstance();

    // Details to be returned.
    InformationalMsgDetailsList informationalMsgDetailsList = new InformationalMsgDetailsList();

    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Get the Concern Role ID from the details.
    maintainConcernRoleKey.concernRoleID = details.concernRoleID;

    // It checks for the indigenous person indicator, if indicator is true and
    // indigenous group code is empty then throws AppException
    if (!details.indigenousPersonInd
      && !details.indigenousGroupCode.equalsIgnoreCase(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPERSONREGISTRATION.ERR_XFV_INDIGENOUS_PERSON_INDICATOR_CHECK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Modify the Person
    maintainPersonObj.modifyPersonEvidence(maintainConcernRoleKey, details);

    // Create an informational manager
    curam.util.exception.InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      informationalMsgDetailsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // Return the details.
    return informationalMsgDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies Client Details participant evidence.
   *
   * @param details
   * Identifies client whose details are to be modified
   *
   * @return Informational messages returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public InformationalMsgDetailsList modifyClientEvidence(
    ModifyClientEvidenceDetails details) throws AppException,
      InformationalException {

    // Maintain Person object.
    curam.core.intf.MaintainPerson maintainPersonObj = curam.core.fact.MaintainPersonFactory.newInstance();

    // Details to be returned.
    InformationalMsgDetailsList informationalMsgDetailsList = new InformationalMsgDetailsList();

    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Get the Concern Role ID from the details.
    maintainConcernRoleKey.concernRoleID = details.concernRoleID;

    // Modify the Person
    maintainPersonObj.modifyClientEvidence(maintainConcernRoleKey, details);

    // Create an informational manager
    curam.util.exception.InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      informationalMsgDetailsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // Return the details.
    return informationalMsgDetailsList;
  }

  // BEGIN, CR00264512, ZV
  // BEGIN, CR00282028, IBM
  /**
   * Searches for a person by provided search criteria. Excludes prospect
   * persons. Does not return names as hyperlinks as this is for popup pages.
   *
   * @param key
   * Contains the person search criteria.
   *
   * @return Details for the list of persons found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Person#searchPersonWithoutProspectForPopup(PersonSearchKey1)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchPersonWithoutProspectForPopup(PersonSearchKey1) which
   * returns the informational message along with person details as
   * well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public PersonSearchResult1 searchWithoutProspectForPopup(PersonSearchKey1 key)
    throws AppException, InformationalException {
    // END, CR00282028
    PersonSearchRouter personSearchRouterObj = PersonSearchRouterFactory.newInstance();

    PersonSearchResult1 personSearchResult = new PersonSearchResult1();

    key.personSearchKey.disableLinkInd = true;

    personSearchResult.personSearchResult = personSearchRouterObj.search1(
      key.personSearchKey);

    for (int i = 0; i < personSearchResult.personSearchResult.dtlsList.size(); i++) {
      if (personSearchResult.personSearchResult.dtlsList.item(i).prospectPersonInd) {
        personSearchResult.personSearchResult.dtlsList.remove(i--);
      }
    }

    // BEGIN, CR00264925, ZV
    // If no search results are found, alert user
    if (personSearchResult.personSearchResult.dtlsList.isEmpty()) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(GENERALSEARCH.INF_SEARCH_NORECORDSFOUND),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

      informationalManager.failOperation();

    }
    // END, CR00264925

    return personSearchResult;
  }

  // END, CR00264512

  // BEGIN, CR00266421, ZV
  // ___________________________________________________________________________
  /**
   * Retrieves the list of all the wait list entries for a person.
   *
   * @param concernRoleKey
   * The concern role ID of the person.
   *
   * @return The list of all the wait list entries for a person.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ConcernRoleWaitListStructList listWaitList(
    ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {

    ConcernRoleWaitListStructList concernRoleWaitListStructList = new ConcernRoleWaitListStructList();

    MaintainPerson maintainPersonObj = MaintainPersonFactory.newInstance();

    concernRoleWaitListStructList.details = maintainPersonObj.listWaitList(
      concernRoleKey);

    return concernRoleWaitListStructList;
  }

  // END, CR00266421

  // BEGIN, CR00282028, IBM
  /**
   * Search person details by provided search criteria.
   *
   * @param personSearchKey1 contains the person search criteria.
   *
   * @return person details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public PersonSearchDetailsResult searchPerson(
    final PersonSearchKey1 personSearchKey1) throws AppException,
      InformationalException {
    
    PersonSearchRouter personSearchRouterObj = PersonSearchRouterFactory.newInstance();

    PersonSearchDetailsResult personSearchResult = new PersonSearchDetailsResult();

    personSearchResult.personSearchResult = personSearchRouterObj.search1(
      personSearchKey1.personSearchKey);

    collectInformationalMsgs(personSearchResult.informationalMsgDtls);
    
    return personSearchResult;
  }

  /**
   * Search persons details by provided search criteria. This is used for popup 
   * pages and does not return names as hyperlinks.
   *
   * @param personSearchKey1
   * contains the person search criteria.
   *
   * @return person details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PersonSearchDetailsResult searchPersonForPopup(final PersonSearchKey1 personSearchKey1)
    throws AppException, InformationalException {
    
    PersonSearchRouter personSearchRouterObj = PersonSearchRouterFactory.newInstance();

    PersonSearchDetailsResult personSearchResult = new PersonSearchDetailsResult();

    personSearchKey1.personSearchKey.disableLinkInd = true;

    personSearchResult.personSearchResult = personSearchRouterObj.search1(
      personSearchKey1.personSearchKey);
    
    collectInformationalMsgs(personSearchResult.informationalMsgDtls);
    
    return personSearchResult;
  }

  /**
   * Search persons details by provided search criteria. Excludes
   * prospect persons. This is used for popup pages and 
   * does not return names as hyperlinks.
   *
   * @param personSearchKey1 contains the person search criteria.
   *
   * @return person details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PersonSearchDetailsResult searchPersonWithoutProspectForPopup(
    final PersonSearchKey1 personSearchKey1) throws AppException, InformationalException {

    PersonSearchRouter personSearchRouterObj = PersonSearchRouterFactory.newInstance();

    PersonSearchDetailsResult personSearchResult = new PersonSearchDetailsResult();

    personSearchKey1.personSearchKey.disableLinkInd = true;

    personSearchResult.personSearchResult = personSearchRouterObj.search1(
      personSearchKey1.personSearchKey);

    // Remove from person search details list if prospect person indicator is true.
    for (int i = 0; i < personSearchResult.personSearchResult.dtlsList.size(); i++) {
      if (personSearchResult.personSearchResult.dtlsList.item(i).prospectPersonInd) {
        personSearchResult.personSearchResult.dtlsList.remove(i--);
      }
    }

    if (personSearchResult.personSearchResult.dtlsList.isEmpty()) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(GENERALSEARCH.INF_SEARCH_NORECORDSFOUND),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      informationalManager.failOperation();

    }
    
    collectInformationalMsgs(personSearchResult.informationalMsgDtls);
    
    return personSearchResult;
  }

  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList msgDtlsList) {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    String[] infos = informationalManager.obtainInformationalAsString();

    for (String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      msgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00282028

  // BEGIN, CR00290965, IBM
  /**
   * Searches for all participants by specified search criteria.
   *
   * @param allParticipantSearchKey contains all participant search key
   *
   * @return participant search details
   *
   * @throws InformationalException Informational Exception
   * @throws AppException Application Exception
   */
  public AllParticipantSearchDetails searchParticipantDetails(
    final AllParticipantSearchKey allParticipantSearchKey) throws AppException, InformationalException {

    AllParticipantSearchDetails allParticipantSearchDetails = new AllParticipantSearchDetails();
    
    Participant participant = ParticipantFactory.newInstance();

    allParticipantSearchDetails = participant.searchParticipantDetails(
      allParticipantSearchKey);
    
    return allParticipantSearchDetails;
  }

  // END, CR00290965
  
  // BEGIN, CR00409050, SG
  /**
   * Reads the details of the specified person.
   *
   * @param key Holds the concern role ID.
   *
   * @return The details of the person.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public PersonDetails readPersonDetails(final ConcernRoleIDKey key)
    throws AppException, InformationalException {
    
    final PersonDetails personDetails = new PersonDetails();
    
    final PersonKey personKey = new PersonKey();

    personKey.concernRoleID = key.concernRoleID;
    
    personDetails.dtls = PersonFactory.newInstance().read(personKey);
    
    return personDetails;
    
  }
  // END, CR00409050
  
}

