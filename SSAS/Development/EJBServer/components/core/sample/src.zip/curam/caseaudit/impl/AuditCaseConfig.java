/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import java.util.List;
import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.AUDITCASETYPECODEEntry;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.SAMPLINGSTRATEGYEntry;
import curam.selectionquery.impl.SelectionQuery;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;

/**
 * AuditCaseConfig.
 * 
 */
@ImplementedBy(AuditCaseConfigImpl.class)
public interface AuditCaseConfig extends Insertable, OptimisticLockModifiable,
  AuditCaseConfigAccessor {

  // ___________________________________________________________________________
  /**
   * Sets the case type.
   * 
   * @param value
   *          The case type.
   */
  public void setCaseType(final AUDITCASETYPECODEEntry value);

  // ___________________________________________________________________________
  /**
   * Sets the case category.
   * 
   * @param value
   *          The case category.
   */
  public void setCaseCategory(final CASECATTYPECODEEntry value);

  // ___________________________________________________________________________
  /**
   * Sets the audit algorithm.
   * 
   * @param auditAlgorithm
   *          The audit algorithm.
   */
  public void setAuditAlgorithm(final SAMPLINGSTRATEGYEntry auditAlgorithm);
  
  // ___________________________________________________________________________
  /**
   * Sets the manual case selection indicator.
   * 
   * @param value
   *          The manual case selection indicator.
   */
  public void setManualCaseSelectionInd(final boolean value);

  // ___________________________________________________________________________
  /**
   * Sets the case audit type SID.
   * 
   * @param value
   *          The case audit type SID.
   */
  public void setCaseAuditTypeSID(final String value);
  
  // ___________________________________________________________________________
  /**
   * Gets the selected focus areas.
   * 
   * @return The selected focus areas.
   *          
   */
  public Set<AuditCaseFocusArea> getSelectedFocusAreas();

  // ___________________________________________________________________________
  /**
   * Gets the fixed queries associated with this configuration.
   * 
   * @return The fixed queries associated with this configuration.
   *          
   */
  public List<SelectionQuery> getFixedQueries();

  // ___________________________________________________________________________
  /**
   * Gets the dynamic query associated with this configuration.
   * 
   * @return The dynamic query associated with this configuration.
   *          
   */
  public SelectionQuery getDynamicQuery();

}
