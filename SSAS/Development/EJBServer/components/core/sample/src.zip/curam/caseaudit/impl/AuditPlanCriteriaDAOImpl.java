/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.Comparator;
import java.util.SortedSet;
import java.util.TreeSet;

import com.google.inject.Singleton;

import curam.caseaudit.entity.impl.AuditPlanCriteriaAdapter;
import curam.caseaudit.entity.struct.AuditPlanCriteriaDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Data access Implementation for 
 * {@linkplain curam.caseaudit.impl.AuditPlanCriteria}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditPlanCriteriaDAO
 */
@Singleton
public class AuditPlanCriteriaDAOImpl extends StandardDAOImpl<AuditPlanCriteria, AuditPlanCriteriaDtls> 
  implements AuditPlanCriteriaDAO {

  protected static final AuditPlanCriteriaAdapter adapter = new AuditPlanCriteriaAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  protected AuditPlanCriteriaDAOImpl() {
    super(adapter, AuditPlanCriteria.class);
  }

  // ___________________________________________________________________________
  /**
   * Audit Plan Criteria Comparator.
   */
  protected class AuditPlanCriteriaComparator implements 
    Comparator<AuditPlanCriteria> {

    public AuditPlanCriteriaComparator() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sorts audit plan criteria list based on name.
     */
    public int compare(final AuditPlanCriteria o1, final AuditPlanCriteria o2) {
      return o1.getName().compareTo(o2.getName());      
    }
  }
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public SortedSet<AuditPlanCriteria> searchByAuditPlan(
    final AuditPlan auditPlan) {
    
    SortedSet<AuditPlanCriteria> sortedCriteria = new TreeSet<AuditPlanCriteria>(
      new AuditPlanCriteriaComparator());

    sortedCriteria.addAll(newList(adapter.searchByAuditPlan(auditPlan.getID())));
    
    return sortedCriteria;
  }

}
