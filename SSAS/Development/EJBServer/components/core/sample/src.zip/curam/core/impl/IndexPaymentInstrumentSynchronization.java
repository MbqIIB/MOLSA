/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.events.PAYMENTINSTRUMENT;
import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.struct.EffectiveDateReconcilStatusVersionNo;
import curam.core.struct.PIAmountEffectDate;
import curam.core.struct.PIInvalidatedVersionNo;
import curam.core.struct.PIReconcilStatusCode;
import curam.core.struct.PIReconcilStatusCodeInvalidatedVersionNo;
import curam.core.struct.PIStatusAmountEffectDate;
import curam.core.struct.PaymentInstrumentDtls;
import curam.core.struct.PaymentInstrumentKey;
import curam.core.struct.SynchronizeEventsDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Raises events to create/modify indexes as a result of all PaymentInstrument 
 * entity updates.
 * 
 * These indexes can then be used with the Lucene Search engine. 
 * 
 */
public abstract class IndexPaymentInstrumentSynchronization extends curam.core.base.IndexPaymentInstrumentSynchronization {

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment instrument entity insert operation
   * 
   * @param paymentInstrumentDtls The payment issued instrument details
   *
   */
  public void insert(final PaymentInstrumentDtls paymentInstrumentDtls) throws AppException, InformationalException { // BEGIN, CR00091575, CPD    
     
    final SynchronizeEvents synchronizeEventsObj = 
      SynchronizeEventsFactory.newInstance();
    
    SynchronizeEventsDetails synchronizeEventsDetails = 
      new SynchronizeEventsDetails();
    
    synchronizeEventsDetails.eventKey.eventClass = 
      PAYMENTINSTRUMENT.INSERT_PAYMENTISSUED.eventClass;
    synchronizeEventsDetails.eventKey.eventType = 
      PAYMENTINSTRUMENT.INSERT_PAYMENTISSUED.eventType;
    
    synchronizeEventsDetails.primaryEventData =
      paymentInstrumentDtls.pmtInstrumentID;
    
    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);    

  }
  
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment instrument entity modify operations
   * 
   * @param paymentInstrumentKey The payment instrument key
   *
   */
  // BEGIN, CR00198672, VK
  protected void modify(final PaymentInstrumentKey paymentInstrumentKey) throws AppException, InformationalException {
    // END, CR00198672
    final SynchronizeEvents synchronizeEventsObj = 
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails = 
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = 
      PAYMENTINSTRUMENT.MODIFY_PAYMENTISSUED.eventClass;
    synchronizeEventsDetails.eventKey.eventType = 
      PAYMENTINSTRUMENT.MODIFY_PAYMENTISSUED.eventType;
    
    synchronizeEventsDetails.primaryEventData =
      paymentInstrumentKey.pmtInstrumentID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);   
    
  }  
  
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment instrument instruction entity modify amount operation
   * 
   * @param paymentInstrumentKey The payment instrument key
   * @param piAmountEffectDate The amount effective date
   *
   */
  public void modifyAmountEffectDate(final PaymentInstrumentKey paymentInstrumentKey, 
    final PIAmountEffectDate piAmountEffectDate) throws AppException, InformationalException {

    modify(paymentInstrumentKey);    
  }
  
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment received instrument entity modify 
   * effective date status operation
   * 
   * @param paymentInstrumentKey The payment instrument key
   * @param effectiveDateReconcilStatusVersionNo The invalidated version number
   *
   */
  public void modifyEffectiveDateReconilStatus(final PaymentInstrumentKey paymentInstrumentKey, 
    final EffectiveDateReconcilStatusVersionNo effectiveDateReconcilStatusVersionNo) 
    throws AppException, InformationalException {

    modify(paymentInstrumentKey);   
  }
  
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment received instrument entity modify invalidate operation
   * 
   * @param paymentInstrumentKey The payment instrument key
   * @param piInvalidatedVersionNo The invalidated version number
   *
   */
  public void modifyInvalidatedInd(final PaymentInstrumentKey paymentInstrumentKey, final PIInvalidatedVersionNo piInvalidatedVersionNo) 
    throws AppException, InformationalException {

    modify(paymentInstrumentKey);   
  }
  
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment received instrument entity modify 
   * reconciliation status code operation
   * 
   * @param paymentInstrumentKey The payment instrument key
   * @param pIReconcilStatusCode The status code
   *
   */
  public void modifyReconcilStatusCode(final PaymentInstrumentKey paymentInstrumentKey, 
    final PIReconcilStatusCode pIReconcilStatusCode) throws AppException, InformationalException {

    modify(paymentInstrumentKey); 
  }
  
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment received instrument entity modify 
   * reconciliation status operation
   * 
   * @param paymentInstrumentKey The payment instrument key
   * @param piReconcilStatusCodeInvalidatedVersionNo The status code invalidated version number
   *
   */
  public void modifyReconcilStatusCodeInvalidateInd(final PaymentInstrumentKey paymentInstrumentKey, 
    final PIReconcilStatusCodeInvalidatedVersionNo piReconcilStatusCodeInvalidatedVersionNo) 
    throws AppException, InformationalException {

    modify(paymentInstrumentKey); 
  }
  
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment received instrument entity modify status 
   * amount effective date operation
   * 
   * @param paymentInstrumentKey The payment instrument key
   * @param piStatusAmountEffectDate The status amount effective date
   *
   */
  public void modifyStatusAmountEffectDate(final PaymentInstrumentKey paymentInstrumentKey, 
    final PIStatusAmountEffectDate piStatusAmountEffectDate) throws AppException, InformationalException {

    modify(paymentInstrumentKey); 
  }
  
}
