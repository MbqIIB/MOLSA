/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2003, 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;

import curam.codetable.BUSINESSOBJECTTYPE;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.struct.CRSecurityDetails;
import curam.core.struct.CaseCount;
import curam.core.struct.ConcernRoleAlternateIDDtls;
import curam.core.struct.ConcernRoleCommExcRMDtlsList;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleHomePageKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CountCasesByConcernRoleKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.EmployerDtls;
import curam.core.struct.EmployerKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.ReadActiveCommExcKey;
import curam.core.struct.ReadBasicContactDetailsKey;
import curam.core.struct.ReadBasicContactDetailsResult;
import curam.core.struct.ReadEmployerResult;
import curam.core.struct.SearchForAltIDKey;
import curam.message.GENERALCASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.workflow.impl.BusinessObjectAssociationSearch;
import curam.util.workflow.struct.BizObjectTypeKey;
import curam.util.workflow.struct.TaskCount;

/**
 * Employer home page retrieves details for display on employer home page
 *
 */
public abstract class EmployerHomePage extends curam.core.base.EmployerHomePage {

  // ___________________________________________________________________________
  /**
   * Called to retrieve employer's details to be displayed on the employer
   * home page.
   *
   * @param key identifies employer to be found
   *
   * @return Details of employer and list of informational messages
   */
  public ReadEmployerResult read(ConcernRoleHomePageKey key)
    throws AppException, InformationalException {

    ReadEmployerResult readEmployerResult = new ReadEmployerResult();

    // employer manipulation variables
    curam.core.intf.Employer employerObj =
      curam.core.fact.EmployerFactory.newInstance();
    EmployerKey employerKey = new EmployerKey();
    EmployerDtls employerDtls;

    // maintainContractAssistant object
    curam.core.intf.MaintainContractAssistant maintainContractAssistantObj =
      curam.core.fact.MaintainContractAssistantFactory.newInstance();

    // currentDate manipulation variable
    curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    InformationalMsgDtls informationalMsgDtls;

    // concernRoleCommException manipulation variables
    curam.core.intf.ConcernRoleCommException concernRoleCommExceptionObj =
      curam.core.fact.ConcernRoleCommExceptionFactory.newInstance();
    ReadActiveCommExcKey readActiveCommExcKey = new ReadActiveCommExcKey();
    ConcernRoleCommExcRMDtlsList concernRoleCommExcRMDtlsList;

    // concernRole manipulation variables
    curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // caseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    CountCasesByConcernRoleKey caseCountKey = new CountCasesByConcernRoleKey();
    CaseCount caseCount;

    // readBasicContactDetails variables
    ReadBasicContactDetailsKey readBasicContactDetailsKey =
      new ReadBasicContactDetailsKey();
    ReadBasicContactDetailsResult readBasicContactDetailsResult;

    // concernRoleAlternateID manipulation variables
    curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj =
      curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();
    SearchForAltIDKey searchForAltIDKey = new SearchForAltIDKey();
    ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls;

    // security details
    CRSecurityDetails cRoleSecurityDetails = new CRSecurityDetails();
    curam.core.intf.ConcernRoleSecurity concernRoleSecurityObj =
      curam.core.fact.ConcernRoleSecurityFactory.newInstance();

    // set key to read concernRole
    concernRoleKey.concernRoleID = key.concernRoleID;

    // read concernRole
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    if (!concernRoleDtls.sensitivity.equals(
      curam.codetable.SENSITIVITY.DEFAULTCODE)) {

      // set key to check security
      cRoleSecurityDetails.sensitivity = concernRoleDtls.sensitivity;

      // call security link
      concernRoleSecurityObj.checkSecurity(cRoleSecurityDetails);

      // pass out the indicator
      if (!cRoleSecurityDetails.result) {

        throw new AppException(
          curam.message.GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
      }
    }
    
    // BEGIN, CR00227042, PM
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    ParticipantSecurityCheckKey participantSecurityCheckKey =
      new ParticipantSecurityCheckKey();

    participantSecurityCheckKey.participantID = key.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity
        .checkParticipantSecurity(participantSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {

      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else {
        throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227042

    // set key to read employer
    employerKey.concernRoleID = key.concernRoleID;

    // read employer
    employerDtls = employerObj.read(employerKey);

    // put data found into result record
    readEmployerResult.details.assign(employerDtls);

    // put data found into result record
    readEmployerResult.details.assign(concernRoleDtls);

    // set the details for a readActive
    readActiveCommExcKey.assign(employerDtls);
    readActiveCommExcKey.emptyDate = curam.util.type.Date.kZeroDate;
    readActiveCommExcKey.currentDate = currentDate;
    readActiveCommExcKey.status = curam.codetable.RECORDSTATUS.NORMAL;

    // retrieve records
    concernRoleCommExcRMDtlsList =
      concernRoleCommExceptionObj.searchActiveExceptions(readActiveCommExcKey);

    if (!concernRoleCommExcRMDtlsList.dtls.isEmpty()) {
      readEmployerResult.details.commExceptionInd = true;
    } else {
      readEmployerResult.details.commExceptionInd = false;
    }

    // pass values to key structure
    readBasicContactDetailsKey.concernRoleID = key.concernRoleID;
    readBasicContactDetailsKey.primaryAddressID =
      concernRoleDtls.primaryAddressID;
    readBasicContactDetailsKey.primaryPhoneNumberID =
      concernRoleDtls.primaryPhoneNumberID;

    // read basic contact details
    readBasicContactDetailsResult =
      maintainContractAssistantObj.readBasicContactDetails(
        readBasicContactDetailsKey);

    readEmployerResult.details.assign(
      readBasicContactDetailsResult.basicContactDetails);

    // pass values returned from readBasicContactDetails messageList
    // to messages struct
    readEmployerResult.messages.dtls.ensureCapacity(
      readBasicContactDetailsResult.messageList.dtls.size());

    for (int i = 0; i < readBasicContactDetailsResult.messageList.dtls.size(); i++) {

      informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt =
        readBasicContactDetailsResult.messageList.dtls.item(i).informationMsgTxt;

      readEmployerResult.messages.dtls.addRef(informationalMsgDtls);
    }

    // set cases count key
    caseCountKey.concernRoleID = key.concernRoleID;
    caseCountKey.statusCode = curam.codetable.CASESTATUS.CLOSED;

    // read number of closed cases
    caseCount = caseHeaderObj.countCasesByConcernRole(caseCountKey);

    // put the number of cases into return structure
    readEmployerResult.details.assign(caseCount);

    // Count the open tasks.
    BizObjectTypeKey bizObjectTypeKey = new BizObjectTypeKey();
    bizObjectTypeKey.bizObjectID = key.concernRoleID;
    bizObjectTypeKey.bizObjectType = BUSINESSOBJECTTYPE.PERSON;
    TaskCount taskCount = BusinessObjectAssociationSearch.
      countOpenTasksByBizObjectTypeAndID(bizObjectTypeKey);
    // put the number of found open tickets to the result structure
    readEmployerResult.details.numberOfOpenTickets = (int) taskCount.count;

    String getHomePagePrimaryWarnings =
      curam.util.resources.Configuration.getProperty(
        EnvVars.ENV_HOMEPAGEPRIMARYWARNINGS);

    if (getHomePagePrimaryWarnings == null) {

      getHomePagePrimaryWarnings = EnvVars.ENV_HOMEPAGEPRIMARYWARNINGS_DEFAULT;
    }

    if (getHomePagePrimaryWarnings.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      // set key to read concernRoleAlternateID
      searchForAltIDKey.alternateID = employerDtls.primaryAlternateID;
      searchForAltIDKey.concernRoleID = key.concernRoleID;
      searchForAltIDKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

      // search for primary alternate ID for client
      try {
        concernRoleAlternateIDDtls =
          concernRoleAlternateIDObj.readForAltID(searchForAltIDKey);

        // check date of primary alternate ID
        if ((!concernRoleAlternateIDDtls.endDate.isZero())
          && (concernRoleAlternateIDDtls.endDate.before(currentDate))) {

          // add an informational if date of primary alternate ID is not
          // correct

          informationalMsgDtls = new InformationalMsgDtls();

          informationalMsgDtls.informationMsgTxt =
            //BEGIN, CR00163471, JC
            curam.message.GENERALCONCERN.ERR_CONCERNROLEALTID_FV_DATE_PASSED.getMessageText(TransactionInfo.getProgramLocale());
            //END, CR00163471, JC

          readEmployerResult.messages.dtls.addRef(informationalMsgDtls);
        }

      } catch (curam.util.exception.RecordNotFoundException e) {

        // add an informational if primary alternate ID was not found

        informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt =
          //BEGIN, CR00163471, JC
          curam.message.GENERALCONCERN.ERR_CONCERNROLEALTID_RNFE_PRIMARY.getMessageText(TransactionInfo.getProgramLocale());
          //END, CR00163471, JC

        readEmployerResult.messages.dtls.addRef(informationalMsgDtls);
      }

      if (!concernRoleDtls.endDate.isZero()) {

        informationalMsgDtls = new InformationalMsgDtls();

        informationalMsgDtls.informationMsgTxt =
          //BEGIN, CR00163471, JC
          curam.message.GENERALCONCERN.INF_EMPLOYER_FV_ENDDATE_SET.getMessageText(TransactionInfo.getProgramLocale());
          //END, CR00163471, JC

        readEmployerResult.messages.dtls.addRef(informationalMsgDtls);

      }

    }

    return readEmployerResult;
  }

}
