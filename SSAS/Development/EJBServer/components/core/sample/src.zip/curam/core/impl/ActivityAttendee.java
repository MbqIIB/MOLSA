/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.List;

import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.clientdiary.impl.ScheduledAppointmentHandler;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.struct.ActivityAttendeeDtls;
import curam.core.struct.ActivityAttendeeDtlsList;
import curam.core.struct.ActivityAttendeeKey;
import curam.core.struct.ActivityAttendeeRecordStatusDetails;
import curam.core.struct.AttendeeByActivityConcernRoleKey;
import curam.core.struct.AttendeeRecurrenceKey;
import curam.core.struct.MaintainAttendeeActivityKey;
import curam.core.struct.ReadByActivityAttendeeKey;
import curam.participant.impl.ConcernRoleDAO;
import curam.piwrapper.activity.impl.Activity;
import curam.piwrapper.activity.impl.ActivityDAO;
import curam.piwrapper.activity.impl.ActivityRecurrence;
import curam.piwrapper.activity.impl.ActivityRecurrenceDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Definition: Attendees who are invited to attend an activity.
 */
public abstract class ActivityAttendee extends curam.core.base.ActivityAttendee {

  // BEGIN, CR00210549, MR
  @Inject
  protected Provider<ScheduledAppointmentHandler> scheduledAppointmentHandlerProvider;

  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  @Inject
  protected ActivityDAO activityDAO;

  @Inject
  protected ActivityRecurrenceDAO activityRecurrenceDAO;

  public ActivityAttendee() {
    // Default constructor used to inject Guice bindings
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00210549

  // ___________________________________________________________________________
  /**
   * Sets record status code to "NORMAL"
   *
   * @param key
   * Contains activity unique identification, attendee unique
   * identification and record status code.
   */
  protected void prereadByActivityAttendee(ReadByActivityAttendeeKey key)
    throws AppException, InformationalException {

    key.recordStatusCode = RECORDSTATUS.NORMAL;

  }

  // BEGIN, CR00210549, MR

  
  // ___________________________________________________________________________
  /**
   * Remove activity attendees by recurrence identifier.
   *
   * @param key The recurrence identifier.
   */
  public void removeByRecurrence(AttendeeRecurrenceKey key)
    throws AppException, InformationalException {
    
    // find all activities for this recurrence
    ActivityRecurrence activityRecurrence = activityRecurrenceDAO.get(
      key.recurrenceID);
    List<Activity> activityList = activityDAO.listByRecurrence(
      activityRecurrence);

    // Cancel the activity
    for (Activity activity : activityList) {
      scheduledAppointmentHandlerProvider.get().cancel(activity);
    }   
    
    // Remove the activity attendee
    ActivityAttendeeDtlsList activityAttendeeDtlsList = searchByRecurrence(key);
    ActivityAttendeeKey activityAttendeeKey = new ActivityAttendeeKey();

    for (ActivityAttendeeDtls o : activityAttendeeDtlsList.dtls) {
      activityAttendeeKey.attendeeID = o.attendeeID;
      remove(activityAttendeeKey);
    }
    
  }

  // ___________________________________________________________________________
  /**
   * Calls insert on the {@link ScheduledAppointmentHandler}. This causes a
   * corresponding record to be inserted into the
   * {@link curam.clientdiary.entity.intf.ClientDiary} table for this activity
   * attendee. This is only done for activity attendees who have a concern role.
   *
   * @param details
   * Contains details of the activity attendee to be inserted.
   */
  protected void postinsert(ActivityAttendeeDtls details) throws AppException,
      InformationalException {

    // only interested in concern role attendees
    if (details.concernRoleID == 0) {
      return;
    }

    Activity activity = activityDAO.get(details.activityID);
    DateRange dateRange = new DateRange(
      new Date(activity.getDateTimeRange().start()),
      new Date(activity.getDateTimeRange().end()));

    // insert the client diary record
    scheduledAppointmentHandlerProvider.get().insert(
      concernRoleDAO.get(details.concernRoleID), activity, dateRange);
  }

  // ___________________________________________________________________________
  /**
   * Calls cancel on the {@link ScheduledAppointmentHandler}, if the record
   * status of the activity attendee is {@link RECORDSTATUSEntry#CANCELLED}.
   * This causes a corresponding record to be logically deleted in the
   * {@link curam.clientdiary.entity.intf.ClientDiary} table for this activity
   * attendee. This is only done for activity attendees who have a concern role.
   *
   * @param details
   * Contains details of the activity attendee to be modified.
   */
  protected void postmodify(
    @SuppressWarnings("unused") ActivityAttendeeKey key,
    ActivityAttendeeDtls details) throws AppException, InformationalException {
    // only interested in concern role attendees
    if (details.concernRoleID == 0) {
      return;
    }

    Activity activity = activityDAO.get(details.activityID);

    // only update we are interested in is cancel
    if (details.recordStatusCode.equals(RECORDSTATUSEntry.CANCELLED.getCode())) {
      scheduledAppointmentHandlerProvider.get().cancel(
        concernRoleDAO.get(details.concernRoleID), activity);
    }
  }

  // ___________________________________________________________________________
  /**
   * Calls cancel on the {@link ScheduledAppointmentHandler}, if the record
   * status of the activity attendee is {@link RECORDSTATUSEntry#CANCELLED}.
   * This causes a corresponding record to be modified or logically deleted in
   * the {@link curam.clientdiary.entity.intf.ClientDiary} table for this
   * activity attendee. This is only done for activity attendees who have a
   * concern role.
   *
   * @param details
   * Contains details of the activity attendee to be modified.
   */
  protected void postmodifyStatusByActivityAndConcernRole(
    AttendeeByActivityConcernRoleKey key,
    ActivityAttendeeRecordStatusDetails details) throws AppException,
      InformationalException {

    Activity activity = activityDAO.get(key.activityID);

    // only update we are interested in is cancel
    if (details.recordStatusCode.equals(RECORDSTATUSEntry.CANCELLED.getCode())) {
      scheduledAppointmentHandlerProvider.get().cancel(
        concernRoleDAO.get(key.concernRoleID), activity);
    }
  }

  // ___________________________________________________________________________
  /**
   * Calls cancel on the {@link ScheduledAppointmentHandler} for the given
   * {@link Activity}. This causes all corresponding records to be logically
   * deleted in the {@link curam.clientdiary.entity.intf.ClientDiary} table for
   * the activity attendees.
   *
   * @param key
   * The activity for which all activity attendees should be removed
   */
  protected void preremoveByActivity(MaintainAttendeeActivityKey key)
    throws AppException, InformationalException {

    Activity activity = activityDAO.get(key.activityID);

    scheduledAppointmentHandlerProvider.get().cancel(activity);
  }

  // ___________________________________________________________________________
  /**
   * Calls cancel on the {@link ScheduledAppointmentHandler} for all
   * {@link Activity} for the given {@link ActivityRecurrence}. This causes all
   * {@link curam.clientdiary.entity.intf.ClientDiary} table for the activity
   * attendees.
   *
   * @param key
   * The recurrence for which all activity attendees should be removed
   */
  protected void preremoveByRecurrence(AttendeeRecurrenceKey key)
    throws AppException, InformationalException {

    // find all activities for this recurrence
    ActivityRecurrence activityRecurrence = activityRecurrenceDAO.get(
      key.recurrenceID);
    List<Activity> activityList = activityDAO.listByRecurrence(
      activityRecurrence);

    for (Activity activity : activityList) {
      scheduledAppointmentHandlerProvider.get().cancel(activity);
    }
  }
  // END, CR00210549

}
