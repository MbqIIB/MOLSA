/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.codetable.ADMINROLESTATUS;
import curam.codetable.BANKACCOUNTFORMAT;
import curam.codetable.BANKACCOUNTTYPE;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASESTATUSSEARCH;
import curam.codetable.CASETYPECODE;
import curam.codetable.COMMUNICATIONFORMAT;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONSTATUS;
import curam.codetable.CONCERNROLESTATUS;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.CONTACTTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.DUPLICATESTATUS;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SCREENINGNAMECODE;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.DUPLICATESTATUSEntry;
import curam.codetable.impl.INVESTIGATECONFIGTYPEEntry;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.core.facade.fact.AttachmentFactory;
import curam.core.facade.fact.CommunicationFactory;
import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.struct.AddressString;
import curam.core.facade.struct.AllParticipantSearchDetails;
import curam.core.facade.struct.AllParticipantSearchKey;
import curam.core.facade.struct.AllParticipantSearchResult;
import curam.core.facade.struct.BankAcDetails;
import curam.core.facade.struct.BankAccountListForRedirectionDetails;
import curam.core.facade.struct.BankAccountString;
import curam.core.facade.struct.CancelCommunicationKey;
import curam.core.facade.struct.CancelContactKey;
import curam.core.facade.struct.CancelParticipantAddressKey;
import curam.core.facade.struct.CancelParticipantAlternateIDKey;
import curam.core.facade.struct.CancelParticipantBankAccountKey;
import curam.core.facade.struct.CancelParticipantCommunicationExceptionKey;
import curam.core.facade.struct.CancelParticipantEmailAddressKey;
import curam.core.facade.struct.CancelParticipantPhoneNumberKey;
import curam.core.facade.struct.CancelParticipantWebAddressDetails;
import curam.core.facade.struct.ClientPageLink;
import curam.core.facade.struct.CommunicationAndListRowActionDetails;
import curam.core.facade.struct.CommunicationDetailList;
import curam.core.facade.struct.ConcernRoleKeyStruct;
import curam.core.facade.struct.ConcernRoleTypeDetails;
import curam.core.facade.struct.ContactContextDescriptionDetails;
import curam.core.facade.struct.ContactContextDescriptionKey;
import curam.core.facade.struct.CreateConcernContactDetails;
import curam.core.facade.struct.CreateContactDetails;
import curam.core.facade.struct.CreateEmailCommunicationDetails;
import curam.core.facade.struct.CreateFreeformCommunication;
import curam.core.facade.struct.CreateParticipantAddressDetails;
import curam.core.facade.struct.CreateParticipantAlternateIDDetails;
import curam.core.facade.struct.CreateParticipantBankAccountDetails;
import curam.core.facade.struct.CreateParticipantEmailAddressDetails;
import curam.core.facade.struct.CreateParticipantPhoneDetails;
import curam.core.facade.struct.CreateTemplateCommunication;
import curam.core.facade.struct.EndDeductionDetails;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.InternationalBankAccountIndicator;
import curam.core.facade.struct.ListConcernContactDetails;
import curam.core.facade.struct.ListContactDetails;
import curam.core.facade.struct.ListContactKey;
import curam.core.facade.struct.ListDuplicateParticipantFinancials;
import curam.core.facade.struct.ListDuplicateParticipantInteractionDetails;
import curam.core.facade.struct.ListDuplicateParticipantIssuedPaymentInstrument;
import curam.core.facade.struct.ListInteractionDetails;
import curam.core.facade.struct.ListInteractionKey;
import curam.core.facade.struct.ListParticipantFinancials;
import curam.core.facade.struct.ListParticipantFinancials1;
import curam.core.facade.struct.ListParticipantFinancialsKey;
import curam.core.facade.struct.ListParticipantIssuedPaymentInstrument;
import curam.core.facade.struct.ListParticipantTaskKey_eo;
import curam.core.facade.struct.ListTemplateByTypeAndParticipantKey;
import curam.core.facade.struct.ListTemplateByTypeAndParticpant;
import curam.core.facade.struct.MaintainParticipantAddressDetails;
import curam.core.facade.struct.MaintainParticipantAlternateIDDetails;
import curam.core.facade.struct.MaintainParticipantBankAccountDetails;
import curam.core.facade.struct.MaintainParticipantBankAccountWithTextSortCodeDetails;
import curam.core.facade.struct.MaintainParticipantCommunicationExceptionDetails;
import curam.core.facade.struct.MaintainParticipantEmailAddressDetails;
import curam.core.facade.struct.MaintainParticipantPhoneDetails;
import curam.core.facade.struct.ModifiedAddressDetails;
import curam.core.facade.struct.ModifiedAlternateIDDetails;
import curam.core.facade.struct.ModifyCommDetails;
import curam.core.facade.struct.ModifyConcernContactDetails;
import curam.core.facade.struct.ModifyContactDetails;
import curam.core.facade.struct.ModifyParticipantNoteDetails1;
import curam.core.facade.struct.ModifySentCommunicationDetails;
import curam.core.facade.struct.ParticipantAddressStringList;
import curam.core.facade.struct.ParticipantAdministratorDetails;
import curam.core.facade.struct.ParticipantAdministratorDetailsList;
import curam.core.facade.struct.ParticipantAssessmentsList;
import curam.core.facade.struct.ParticipantBankAccountRedirectionKey;
import curam.core.facade.struct.ParticipantBankAccountRedirectionKey1;
import curam.core.facade.struct.ParticipantBankAccountStringList;
import curam.core.facade.struct.ParticipantCommunicationKey;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ParticipantContextDetails;
import curam.core.facade.struct.ParticipantContextKey;
import curam.core.facade.struct.ParticipantFinancials;
import curam.core.facade.struct.ParticipantFinancials1;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.facade.struct.ParticipantInvestigationList;
import curam.core.facade.struct.ParticipantNoteDetails;
import curam.core.facade.struct.ParticipantScreeningList;
import curam.core.facade.struct.ParticipantWebAddressDetails;
import curam.core.facade.struct.ParticipantWebAddressKey;
import curam.core.facade.struct.ParticipantWebAddressList;
import curam.core.facade.struct.ParticipantWebAddressListKey;
import curam.core.facade.struct.PersonAndProspectPersonSearchDetails;
import curam.core.facade.struct.PrintCommunicationKey;
import curam.core.facade.struct.ReadActiveBankAccountList;
import curam.core.facade.struct.ReadAddressHistoryList;
import curam.core.facade.struct.ReadAddressHistoryListKey;
import curam.core.facade.struct.ReadAttachmentKey;
import curam.core.facade.struct.ReadCommDetails;
import curam.core.facade.struct.ReadCommKey;
import curam.core.facade.struct.ReadCommunicationAttachmentDetails;
import curam.core.facade.struct.ReadConcernContactDetails;
import curam.core.facade.struct.ReadContactKey;
import curam.core.facade.struct.ReadDuplicateParticipantConcernRoleList;
import curam.core.facade.struct.ReadDuplicateParticipantDeductionList;
import curam.core.facade.struct.ReadParticipantActiveAddressList;
import curam.core.facade.struct.ReadParticipantAddressDetails;
import curam.core.facade.struct.ReadParticipantAddressKey;
import curam.core.facade.struct.ReadParticipantAddressList;
import curam.core.facade.struct.ReadParticipantAddressListKey;
import curam.core.facade.struct.ReadParticipantAdminRoleList;
import curam.core.facade.struct.ReadParticipantAdminRoleListKey;
import curam.core.facade.struct.ReadParticipantAltIDHistoryList;
import curam.core.facade.struct.ReadParticipantAltIDHistoryListKey;
import curam.core.facade.struct.ReadParticipantAlternateIDDetails;
import curam.core.facade.struct.ReadParticipantAlternateIDKey;
import curam.core.facade.struct.ReadParticipantAlternateIDList;
import curam.core.facade.struct.ReadParticipantAlternateIDListKey;
import curam.core.facade.struct.ReadParticipantBankAcHistoryList;
import curam.core.facade.struct.ReadParticipantBankAcHistoryListKey;
import curam.core.facade.struct.ReadParticipantBankAccountDetails;
import curam.core.facade.struct.ReadParticipantBankAccountKey;
import curam.core.facade.struct.ReadParticipantBankAccountList;
import curam.core.facade.struct.ReadParticipantBankAccountListKey;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionDetails;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionKey;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionList;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionListKey;
import curam.core.facade.struct.ReadParticipantConcernRoleKey;
import curam.core.facade.struct.ReadParticipantConcernRoleList;
import curam.core.facade.struct.ReadParticipantDeductionList;
import curam.core.facade.struct.ReadParticipantDeductionList1;
import curam.core.facade.struct.ReadParticipantEmailAddressDetails;
import curam.core.facade.struct.ReadParticipantEmailAddressKey;
import curam.core.facade.struct.ReadParticipantEmailAddressList;
import curam.core.facade.struct.ReadParticipantEmailAddressListKey;
import curam.core.facade.struct.ReadParticipantFormattedAddressListKey;
import curam.core.facade.struct.ReadParticipantFormattedBankAccountListKey;
import curam.core.facade.struct.ReadParticipantPhoneNumberDetails;
import curam.core.facade.struct.ReadParticipantPhoneNumberKey;
import curam.core.facade.struct.ReadParticipantPhoneNumberList;
import curam.core.facade.struct.ReadParticipantPhoneNumberListKey;
import curam.core.facade.struct.ReadParticipantWebAddressDetails;
import curam.core.facade.struct.ReadProFormaCommKey;
import curam.core.facade.struct.RecordExistingCommunicationDetails;
import curam.core.facade.struct.SearchCaseKey_fo;
import curam.core.facade.struct.SearchPersonAndProspectPersonKey;
import curam.core.facade.struct.SendEmailCommKey;
import curam.core.facade.struct.TasksForConcernAndCaseDetails;
import curam.core.facade.struct.TasksForDuplicateConcernAndCaseDetails;
import curam.core.facade.struct.TemplatesByTypeAndParticipantDetails;
import curam.core.facade.struct.UpdateBankAccPaymentDtlsKey;
import curam.core.fact.AddressFactory;
import curam.core.fact.BankFactory;
import curam.core.fact.ConcernRoleAddressSnapshotFactory;
import curam.core.fact.ConcernRoleAlternateIDSnapshotFactory;
import curam.core.fact.ConcernRoleBankAccountSnapshotFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.FinancialInstructionFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.MaintainAdminConcernRoleFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.fact.MaintainConcernRoleAddressFactory;
import curam.core.fact.MaintainConcernRoleAltIDFactory;
import curam.core.fact.MaintainConcernRoleBankAcFactory;
import curam.core.fact.MaintainConcernRoleDetailsFactory;
import curam.core.fact.MaintainContactsFactory;
import curam.core.fact.MaintainDeductionItemsFactory;
import curam.core.fact.ViewConcernAccountFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.Address;
import curam.core.intf.Bank;
import curam.core.intf.ConcernRole;
import curam.core.intf.InstructionLineItem;
import curam.core.intf.MaintainAdminConcernRole;
import curam.core.intf.MaintainCase;
import curam.core.intf.MaintainConcernRoleAddress;
import curam.core.intf.MaintainConcernRoleAltID;
import curam.core.intf.MaintainConcernRoleBankAc;
import curam.core.intf.MaintainConcernRoleDetails;
import curam.core.intf.MaintainContacts;
import curam.core.intf.MaintainDeductionItems;
import curam.core.intf.ViewConcernAccount;
import curam.core.sl.entity.fact.ConcernRoleDuplicateFactory;
import curam.core.sl.entity.fact.InvestigationDeliveryFactory;
import curam.core.sl.entity.fact.ScreeningFactory;
import curam.core.sl.entity.intf.ConcernRoleDuplicate;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.ClientInteractionDtls;
import curam.core.sl.entity.struct.ClientInteractionKey;
import curam.core.sl.entity.struct.ConcernRoleDuplicateDtlsList;
import curam.core.sl.entity.struct.InvestigationDeliveryDtls;
import curam.core.sl.entity.struct.InvestigationDeliveryKey;
import curam.core.sl.entity.struct.ScreeningName;
import curam.core.sl.entity.struct.SearchByDuplicateConcernRoleIDKey;
import curam.core.sl.entity.struct.SearchParticipantNoteByParticipantDetails1;
import curam.core.sl.fact.ClientInteractionFactory;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.fact.DatabaseParticipantSearchFactory;
import curam.core.sl.fact.ParticipantSearchFactory;
import curam.core.sl.fact.ParticipantSearchRouterFactory;
import curam.core.sl.fact.WorkAllocationTaskFactory;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorModifyDtls;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.EIEvidenceModifyDtls;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.struct.ECWarningsDtls;
import curam.core.sl.infrastructure.struct.ECWarningsDtlsList;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.intf.AssessmentDelivery;
import curam.core.sl.intf.ClientInteraction;
import curam.core.sl.intf.ClientMerge;
import curam.core.sl.intf.DatabaseParticipantSearch;
import curam.core.sl.intf.ParticipantSearchRouter;
import curam.core.sl.intf.WorkAllocationTask;
import curam.core.sl.struct.AddressRegionDetailsList;
import curam.core.sl.struct.CommunicationDetailsList;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.sl.struct.SearchTaskForConcernOrCaseKey;
import curam.core.struct.AddressDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressForConcernRoleKey;
import curam.core.struct.AddressKey;
import curam.core.struct.AdminConcernRoleDetails;
import curam.core.struct.BankAccountDetails;
import curam.core.struct.BankAccountRMDtls;
import curam.core.struct.BankBranchKey;
import curam.core.struct.BankNameStruct;
import curam.core.struct.CancelConcernRoleCommKey;
import curam.core.struct.CaseHeaderConcernRoleDetails;
import curam.core.struct.CaseHeaderConcernRoleDetailsList1;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseIDThirdPartyID;
import curam.core.struct.CommunicationContactKey;
import curam.core.struct.ConcernContactRMDtls;
import curam.core.struct.ConcernContactRMultiDtls;
import curam.core.struct.ConcernRoleAddressDtls;
import curam.core.struct.ConcernRoleAddressKey;
import curam.core.struct.ConcernRoleAddressSnapshotDtls;
import curam.core.struct.ConcernRoleAddressSnapshotKey;
import curam.core.struct.ConcernRoleAlternateIDDtls;
import curam.core.struct.ConcernRoleAlternateIDKey;
import curam.core.struct.ConcernRoleAlternateIDSnapshotDtls;
import curam.core.struct.ConcernRoleAlternateIDSnapshotKey;
import curam.core.struct.ConcernRoleBankAccountDtls;
import curam.core.struct.ConcernRoleBankAccountKey;
import curam.core.struct.ConcernRoleBankAccountSnapshotDtls;
import curam.core.struct.ConcernRoleBankAccountSnapshotKey;
import curam.core.struct.ConcernRoleCommRMDtls;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleCommunicationKey;
import curam.core.struct.ConcernRoleContactDtls;
import curam.core.struct.ConcernRoleContactKey;
import curam.core.struct.ConcernRoleDocumentDetails;
import curam.core.struct.ConcernRoleDocumentKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.ConcernRolePhoneDetails;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.CuramInd;
import curam.core.struct.EmailAddressDtls;
import curam.core.struct.EmailAddressKey;
import curam.core.struct.FinInstructionID;
import curam.core.struct.FinancialAccountIdentifier;
import curam.core.struct.FinancialInstructionDetails;
import curam.core.struct.ILIFinInstructID;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.MaintainAddressKey;
import curam.core.struct.MaintainAdminConcernRoleDetails;
import curam.core.struct.MaintainAdminConcernRoleKey;
import curam.core.struct.MaintainAdminConcernRoleRMDtls;
import curam.core.struct.MaintainBankAccountKey;
import curam.core.struct.MaintainCommExceptionKey;
import curam.core.struct.MaintainCommunicationKey;
import curam.core.struct.MaintainConcernRoleAltIDKey;
import curam.core.struct.MaintainConcernRoleKey;
import curam.core.struct.MaintainEmailKey;
import curam.core.struct.MaintainPhoneNumberKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ParticipantDeductionDetails;
import curam.core.struct.ParticipantDeductionDetails1;
import curam.core.struct.PhoneForConcernRoleKey;
import curam.core.struct.ReadConcernRoleBankAcHistoryListDtls;
import curam.core.struct.ReadConcernRoleCommKey;
import curam.core.struct.ReadConcernRoleKey;
import curam.core.struct.ReadConcernRolePhoneKey;
import curam.core.struct.ReadMultiByConcRoleIDResult;
import curam.core.struct.ReadmultiByConcernRoleForNomineeWizardResult;
import curam.core.struct.SearchTemplatesByConcernAndTypeResult;
import curam.core.struct.SearchTemplatesKey;
import curam.core.struct.ViewConcAccountSummaryResult;
import curam.message.BPOADDRESS;
import curam.message.GENERAL;
import curam.message.SEPARATOR;
import curam.pdc.fact.PDCPhoneNumberFactory;
import curam.pdc.intf.PDCPhoneNumber;
import curam.pdc.struct.ParticipantPhoneDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.Configuration;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.wizard.util.impl.CodetableUtil;


/**
 * This process class provides the functionality for the Participant
 * presentation layer.
 */
public abstract class Participant extends curam.core.facade.base.Participant {

  // BEGIN, CR00222190, ELG
  /**
   * Constant for the separator used in the context description.
   *
   * @deprecated Since Curam 5.2 SP4, replaced by
   * {@link SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
   * TransactionInfo.getProgramLocale())}.
   * Constant for the separator used in the context description.
   * Replacement reason - static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note <CR00219408>.
   */
  @Deprecated
  // BEGIN, CR00023323, SK
  protected static final String kSeparator = SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();
  // END, CR00023323
  // END, CR00222190

  // BEGIN, CR00098567, DJ
  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;
  // END, CR00098567
  /**
   * Constant for the minimum length of a Phone Number.
   */
  // BEGIN, CR00333379, PB
  protected static final int kMinimumPhoneNumberLength = 1;
  // END, CR00333379
  // BEGIN, CR00100651, CSH
  protected static final String kItem = XmlMetaDataConst.kItem;
  protected static final String kDesc = XmlMetaDataConst.kDesc;
  protected static final String kType = XmlMetaDataConst.kType;
  protected static final String kPageID = XmlMetaDataConst.kPageID;
  protected static final String kName = XmlMetaDataConst.kName;
  protected static final String kValue = XmlMetaDataConst.kValue;
  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;
  protected static final String kParam = XmlMetaDataConst.kParam;
  protected static final String kParamConcernRoleID = XmlMetaDataConst.kParamConcernRoleID;
  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;
  // END, CR00100651

  // BEGIN, CR00149694, ZV
  protected static final String kCommaSpace = CuramConst.gkComma
    + CuramConst.gkSpace;
  // END, CR00149694


  // BEGIN, CR00176534, RPB
  /**
   * Create a administrator for the concernRole specified.
   *
   * @param participantAdministratorDetails
   * The administrator details being entered.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public void createAdministrator(
    final ParticipantAdministratorDetails participantAdministratorDetails)
    throws AppException, InformationalException {

    final curam.core.intf.MaintainAdminConcernRole maintainAdminConcernRole = curam.core.fact.MaintainAdminConcernRoleFactory.newInstance();
    final MaintainAdminConcernRoleKey maintainAdminConcernRoleKey = new MaintainAdminConcernRoleKey();

    maintainAdminConcernRoleKey.concernRoleID = participantAdministratorDetails.concernRoleID;
    final AdminConcernRoleDetails adminConcernRoleDetails = new AdminConcernRoleDetails();

    adminConcernRoleDetails.concernRoleID = participantAdministratorDetails.concernRoleID;
    adminConcernRoleDetails.orgObjectType = participantAdministratorDetails.orgObjectType;
    if (StringUtil.isNullOrEmpty(participantAdministratorDetails.orgObjectType)) {
      adminConcernRoleDetails.orgObjectType = ORGOBJECTTYPEEntry.USER.getCode();
    }
    // BEGIN, CR00177505, RPB
    if (!ORGOBJECTTYPEEntry.USER.getCode().equalsIgnoreCase(
      adminConcernRoleDetails.orgObjectType)) {
      adminConcernRoleDetails.orgObjectReference = participantAdministratorDetails.participantOwnerName;
    }
    // END, CR00177505
    if (ORGOBJECTTYPEEntry.USER.getCode().equalsIgnoreCase(
      adminConcernRoleDetails.orgObjectType)) {
      if (!StringUtil.isNullOrEmpty(participantAdministratorDetails.userName)) {
        adminConcernRoleDetails.userName = participantAdministratorDetails.userName;
      } else {
        adminConcernRoleDetails.userName = participantAdministratorDetails.participantOwnerName;
      }
    }

    maintainAdminConcernRole.createConcernRoleOwner(maintainAdminConcernRoleKey,
      adminConcernRoleDetails);

  }

  /**
   * Retrieves a list of administrators for the specified concern role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is
   * returned.
   *
   * @return The list of administrators returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public ParticipantAdministratorDetailsList listAdministrators(
    final ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    final ParticipantAdministratorDetailsList participantAdministratorDetailsList = new ParticipantAdministratorDetailsList();
    final MaintainAdminConcernRole maintainAdminConcernRole = MaintainAdminConcernRoleFactory.newInstance();

    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantAdministratorDetailsList.adminConcernRoleDetailsList = maintainAdminConcernRole.readAdministratorsForConcernRole(
      readParticipantAdminRoleListKey.maintainAdminConcernRoleKey);

    participantContextDescriptionKey.concernRoleID = readParticipantAdminRoleListKey.maintainAdminConcernRoleKey.concernRoleID;

    final curam.core.facade.intf.ParticipantContext participantContext = ParticipantContextFactory.newInstance();

    participantAdministratorDetailsList.participantContextDescription = participantContext.readContextDescription(
      participantContextDescriptionKey);

    // BEGIN, CR00221607, MC
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRoleKey currentKey = new ConcernRoleKey();
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      final ClientMerge clientMergeSLObj = ClientMergeFactory.newInstance();

      concernRoleKey.concernRoleID = readParticipantAdminRoleListKey.maintainAdminConcernRoleKey.concernRoleID;
      currentKey.concernRoleID = readParticipantAdminRoleListKey.maintainAdminConcernRoleKey.concernRoleID;

      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listAdminRoleForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listAdminRole;

      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      concernRoleIDStatusCodeKey.concernRoleID = readParticipantAdminRoleListKey.maintainAdminConcernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;
      participantAdministratorDetailsList.ind = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);

      // BEGIN, CR00177505, RPB
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();

      participantAdministratorDetailsList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
      // END, CR00177505
    }
    // END, CR00221607

    final CompositeComparator compComparator = new CompositeComparator();

    compComparator.setMajor(new AdminRoleStatusComparator());
    compComparator.setMinor(new StartDateComparator());

    return participantAdministratorDetailsList;
  }

  // END, CR00176534

  // BEGIN, CR00177505, RPB

  /**
   * Retrieves a list of administrators for the specified duplicate concern
   * role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is returned
   *
   * @return The list of administrators for the duplicate concern role
   * specified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public ParticipantAdministratorDetailsList listAdministratorsForDuplicateParticipant(
    final ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList = new ParticipantAdministratorDetailsList();
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
    final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList concernRoleDuplicateDtlsList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey searchByDuplicateConcernRoleIDKey = new SearchByDuplicateConcernRoleIDKey();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();
    final ConcernRoleKey currentConcernRoleKey = new ConcernRoleKey();

    participantAdministratorDetailsList = listAdministrators(
      readParticipantAdminRoleListKey);
    searchByDuplicateConcernRoleIDKey.duplicateConcernRoleID = readParticipantAdminRoleListKey.maintainAdminConcernRoleKey.concernRoleID;

    concernRoleDuplicateDtlsList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(
      searchByDuplicateConcernRoleIDKey);

    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = readParticipantAdminRoleListKey.maintainAdminConcernRoleKey.concernRoleID;

    final curam.core.facade.intf.ParticipantContext participantContext = ParticipantContextFactory.newInstance();

    participantAdministratorDetailsList.participantContextDescription = participantContext.readContextDescription(
      participantContextDescriptionKey);
    concernRoleKey.concernRoleID = concernRoleDuplicateDtlsList.dtls.item(0).originalConcernRoleID;
    currentConcernRoleKey.concernRoleID = readParticipantAdminRoleListKey.maintainAdminConcernRoleKey.concernRoleID;

    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listAdminRoleForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listAdminRole;

    participantAdministratorDetailsList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentConcernRoleKey, dupPageIdentifier,
      origPageIdentifier);

    concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUSEntry.UNMARKED.getCode();

    participantAdministratorDetailsList.ind = clientMergeSLObj.isConcernRoleOriginalClient(
      concernRoleIDStatusCodeKey);

    return participantAdministratorDetailsList;

  }

  // END, CR00177505



  // BEGIN, CR00061467, PCAL

  /**
   * Method returns a list of Address Snapshot details, and the date-of-creation
   * for each Snapshot record.
   *
   * @param key
   * The Address record the snapshots are associated with.
   *
   * @return The list of Address snapshot summary details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ReadAddressHistoryList listAddressHistory
    (final ReadAddressHistoryListKey key)
    throws AppException, InformationalException {

    // Return struct
    final ReadAddressHistoryList readAddressHistoryList = new ReadAddressHistoryList();

    // BEGIN, CR00075874, CR00101199 SSK, VM
    // Read the concern role address details to get the concernRoleID
    final ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();
    final curam.core.intf.ConcernRoleAddress concernRoleAddressObj = curam.core.fact.ConcernRoleAddressFactory.newInstance();

    concernRoleAddressKey.concernRoleAddressID = key.historyKey.concernRoleAddressID;

    try {
      final ConcernRoleAddressDtls concernRoleAddressDtls = concernRoleAddressObj.read(
        concernRoleAddressKey);

      key.historyKey.concernRoleID = concernRoleAddressDtls.concernRoleID;

    } catch (final RecordNotFoundException rnfe) {

      final ConcernRoleAddressSnapshotKey concernRoleAddressSnapshotKey = new ConcernRoleAddressSnapshotKey();

      concernRoleAddressSnapshotKey.concernRoleAddressSnapshotID = key.historyKey.concernRoleAddressID;
      final ConcernRoleAddressSnapshotDtls concernRoleAddressSnapshotDtls = ConcernRoleAddressSnapshotFactory.newInstance().read(
        concernRoleAddressSnapshotKey);

      key.historyKey.concernRoleID = concernRoleAddressSnapshotDtls.concernRoleID;
    }
    // END, CR00075874, CR00101199

    // Retrieve the list of snap shot summary details
    final MaintainConcernRoleAddress maintainConcernRoleAddressObj = MaintainConcernRoleAddressFactory.newInstance();

    readAddressHistoryList.historyDtls = maintainConcernRoleAddressObj.listAddressHistory(
      key.historyKey);

    // Get the context description of the Address Snapshots
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.historyKey.concernRoleID;
    readAddressHistoryList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return the details
    return readAddressHistoryList;
  }

  // END, CR00061467

  // BEGIN, CR00142634, JMA
  /**
   * Method returns a list of Investigations for the participant
   *
   * @param concernRoleKey
   * The concern role that the investigations were created for.
   *
   * @param key
   * key information for case search.
   * @return The list of Investigations for the concern role.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ParticipantInvestigationList listInvestigations(final SearchCaseKey_fo key)
    throws AppException, InformationalException {

    // Return structure
    final ParticipantInvestigationList participantInvestigationList = new ParticipantInvestigationList();

    // Case Search object
    final MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.casesByConcernRoleIDKey.concernRoleID;

    // Get the context description for the concern role
    participantInvestigationList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Set status code for search
    key.casesByConcernRoleIDKey.statusCode = CASESTATUSSEARCH.ALL;

    // BEGIN, CR00221180, ZV
    final CaseHeaderConcernRoleDetailsList1 caseHeaderConcernRoleDetailsList = maintainCaseObj.getCasesByConcernRoleID1(
      key.casesByConcernRoleIDKey);

    // END, CR00221180

    // Check if the list is populated
    if (!caseHeaderConcernRoleDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      participantInvestigationList.caseHeaderConcernRoleDetailsList.dtls.ensureCapacity(
        caseHeaderConcernRoleDetailsList.dtls.size());

      CaseHeaderConcernRoleDetails caseHeaderConcernRoleDetails;

      // Iterate through the list returned
      for (int i = 0; i < caseHeaderConcernRoleDetailsList.dtls.size(); i++) {

        caseHeaderConcernRoleDetails = new CaseHeaderConcernRoleDetails();

        // Assign details
        caseHeaderConcernRoleDetails.assign(
          caseHeaderConcernRoleDetailsList.dtls.item(i));

        final String caseTypeCode = caseHeaderConcernRoleDetailsList.dtls.item(i).caseTypeCode;

        // Check if the case is a investigation
        if (caseTypeCode.equals(CASETYPECODE.INVESTIGATIONCASE)) {

          // Screening manipulation variables
          final curam.core.sl.entity.intf.InvestigationDelivery investigationObj = InvestigationDeliveryFactory.newInstance();
          final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

          // Set key to read read Investigation entity
          investigationDeliveryKey.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

          // Read Investigation
          final InvestigationDeliveryDtls investigationDeliveryDtls = investigationObj.read(
            investigationDeliveryKey);

          caseHeaderConcernRoleDetails.productTypeDesc = CodeTable.getOneItem(
            INVESTIGATECONFIGTYPEEntry.TABLENAME,
            investigationDeliveryDtls.investigationType);

          // Add to return object
          participantInvestigationList.caseHeaderConcernRoleDetailsList.dtls.addRef(
            caseHeaderConcernRoleDetails);
        }
      }
    }

    // BEGIN, CR00221607, MC
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // Display the duplicate client role soft links in a tab format
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

      // Page variables to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      // Set concernRole
      concernRoleKey.concernRoleID = key.casesByConcernRoleIDKey.concernRoleID;

      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listCaseForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listCase;

      // Build up the xml data needed for the tab widget
      participantInvestigationList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      participantInvestigationList.ind = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);
    }
    // END, CR00221607
    // Return details
    return participantInvestigationList;

  }

  /**
   * Method returns a list of Assessments for the participant
   *
   * @param concernRoleKey
   * The concern role that the assessments were created for.
   *
   * @return The list of Assessments for the concern role.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ParticipantAssessmentsList listAssessments(
    final ConcernRoleKey concernRoleKey) throws AppException,
      InformationalException {

    // Return object
    final ParticipantAssessmentsList participantAssessmentsList = new ParticipantAssessmentsList();

    // ClientMerge manipulation variables
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
    final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    final ConcernRoleKey currentKey = new ConcernRoleKey();

    final AssessmentDelivery assessmentDeliveryObj = curam.core.sl.fact.AssessmentDeliveryFactory.newInstance();

    participantAssessmentsList.assessmentForConcernDetailsList = assessmentDeliveryObj.listAssessmentCasesByConcernRoleID(
      concernRoleKey);

    // Get the context description of the Address Snapshots
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = concernRoleKey.concernRoleID;
    participantAssessmentsList.participantContextDescriptionDetails.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = concernRoleKey.concernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = concernRoleKey.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listCaseForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listCase;

    // Build up the xml data needed for the tab widget
    participantAssessmentsList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

    // Populate key to check for duplicate
    concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

    // Set an indicator if this concern has duplicates
    participantAssessmentsList.ind = clientMergeSLObj.isConcernRoleOriginalClient(
      concernRoleIDStatusCodeKey);

    return participantAssessmentsList;
  }

  /**
   * Lists screening cases for the specified participant.
   *
   * @param key
   * Identifies the concern role
   *
   * @return The screening cases for the participant as read from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ParticipantScreeningList listScreeningCases(final SearchCaseKey_fo key)
    throws AppException, InformationalException {

    // Return structure
    final ParticipantScreeningList participantScreeningList = new ParticipantScreeningList();

    // Case Search object
    final MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();

    // ClientMerge manipulation variables
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
    final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.casesByConcernRoleIDKey.concernRoleID;

    // Get the context description for the concern role
    participantScreeningList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Set status code for search
    key.casesByConcernRoleIDKey.statusCode = CASESTATUSSEARCH.ALL;

    // BEGIN, CR00221180, ZV
    final CaseHeaderConcernRoleDetailsList1 caseHeaderConcernRoleDetailsList = maintainCaseObj.getCasesByConcernRoleID1(
      key.casesByConcernRoleIDKey);

    // END, CR00221180

    // Check if the list is populated
    if (!caseHeaderConcernRoleDetailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      participantScreeningList.caseHeaderConcernRoleDetailsList.dtls.ensureCapacity(
        caseHeaderConcernRoleDetailsList.dtls.size());

      CaseHeaderConcernRoleDetails caseHeaderConcernRoleDetails;

      // Iterate through the list returned
      for (int i = 0; i < caseHeaderConcernRoleDetailsList.dtls.size(); i++) {

        caseHeaderConcernRoleDetails = new CaseHeaderConcernRoleDetails();

        // Assign details
        caseHeaderConcernRoleDetails.assign(
          caseHeaderConcernRoleDetailsList.dtls.item(i));

        final String caseTypeCode = caseHeaderConcernRoleDetailsList.dtls.item(i).caseTypeCode;

        // Check if the case is a or screening case
        if (caseTypeCode.equals(CASETYPECODE.SCREENINGCASE)) {

          // Screening manipulation variables
          final curam.core.sl.entity.intf.Screening screeningObj = ScreeningFactory.newInstance();
          final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
          ScreeningName screeningName;

          // Set key to read read Screening entity
          caseKeyStruct.caseID = caseHeaderConcernRoleDetailsList.dtls.item(i).caseID;

          // Read Screening
          screeningName = screeningObj.readName(caseKeyStruct);

          caseHeaderConcernRoleDetails.productTypeDesc = CodeTable.getOneItem(
            SCREENINGNAMECODE.TABLENAME, screeningName.name);

          // Add to return object
          participantScreeningList.caseHeaderConcernRoleDetailsList.dtls.addRef(
            caseHeaderConcernRoleDetails);
        }
      }
    }

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = key.casesByConcernRoleIDKey.concernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = concernRoleKey.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listCaseForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listCase;

    // Build up the xml data needed for the tab widget
    participantScreeningList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

    // Populate key to check for duplicate
    concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

    // Set an indicator if this concern has duplicates
    participantScreeningList.ind = clientMergeSLObj.isConcernRoleOriginalClient(
      concernRoleIDStatusCodeKey);

    // Return details
    return participantScreeningList;
  }

  // END, CR00142634

  /**
   * Cancels a phone number record
   *
   * @param key
   * The concern role phone number ID of the phone record being
   * canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelPhoneNumber(final CancelParticipantPhoneNumberKey key)
    throws AppException, InformationalException {

    // Phone number maintenance object
    final curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory.newInstance();

    // Cancel the phone number
    maintainConcernRolePhoneObj.cancelPhoneNumber(key.cancelConcernRolePhoneKey);
  }

  /**
   * Creates a concern role phone number record
   *
   * @param details
   * Concern role identifier & concern role phone number details
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantPhoneDetails createPhoneNumber(
    final MaintainParticipantPhoneDetails details) throws AppException,
      InformationalException {

    // Phone number maintenance object and key
    final curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory.newInstance();
    final MaintainPhoneNumberKey maintainPhoneNumberKey = new MaintainPhoneNumberKey();

    // Details to be returned
    final CreateParticipantPhoneDetails createParticipantPhoneDetails = new CreateParticipantPhoneDetails();

    // Get concern role ID from key
    maintainPhoneNumberKey.concernRoleID = details.concernRolePhoneDetails.concernRoleID;

    // Create phone number
    createParticipantPhoneDetails.informationalMsgDtlsList = maintainConcernRolePhoneObj.createPhoneNumber(
      maintainPhoneNumberKey, details.concernRolePhoneDetails);

    // Return details
    return createParticipantPhoneDetails;
  }

  /**
   * Retrieves a list of phone number records for a concern role
   *
   * @param key
   * The concern role id for which a list of phone numbers are
   * returned.
   *
   * @return The list of phone numbers returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantPhoneNumberList listPhoneNumber(
    final ReadParticipantPhoneNumberListKey key) throws AppException,
      InformationalException {

    // Phone number maintenance object
    final curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory.newInstance();

    // Details to be returned
    final ReadParticipantPhoneNumberList readParticipantPhoneNumberList = new ReadParticipantPhoneNumberList();

    // Read list of phone numbers
    readParticipantPhoneNumberList.readMultiByConcernRoleIDPhoneResult = maintainConcernRolePhoneObj.readmultiByConcernRole(
      key.maintainPhoneNumberKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.maintainPhoneNumberKey.concernRoleID;
    // Get the context description for the concern role
    readParticipantPhoneNumberList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      readParticipantPhoneNumberList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // Return details
    return readParticipantPhoneNumberList;
  }

  /**
   * Modifies a phone number record for a concern role
   *
   * @param details
   * The concern role id and concern role phone number details that
   * will be modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyPhoneNumber(final MaintainParticipantPhoneDetails details)
    throws AppException, InformationalException {

    // Phone number maintenance object and key
    final curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory.newInstance();
    final MaintainPhoneNumberKey maintainPhoneNumberKey = new MaintainPhoneNumberKey();

    // Get concern role ID from key
    maintainPhoneNumberKey.concernRoleID = details.concernRolePhoneDetails.concernRoleID;

    // Modify the phone number
    maintainConcernRolePhoneObj.modifyPhoneNumber(maintainPhoneNumberKey,
      details.concernRolePhoneDetails);
  }

  /**
   * Reads a phone number record for a concern role
   *
   * @param key The concern role phone number ID.
   *
   * @return The phone number details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantPhoneNumberDetails readPhoneNumber(
    final ReadParticipantPhoneNumberKey key) throws AppException,
      InformationalException {

    // Phone number maintenance object
    final curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory.newInstance();

    // Details to be returned
    final ReadParticipantPhoneNumberDetails readParticipantPhoneNumberDetails = new ReadParticipantPhoneNumberDetails();

    // Read the phone number
    readParticipantPhoneNumberDetails.concernRolePhoneDetails = maintainConcernRolePhoneObj.readPhoneNumber(
      key.readConcernRolePhoneKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = readParticipantPhoneNumberDetails.concernRolePhoneDetails.concernRoleID;
    // Get the context description for the concern role
    readParticipantPhoneNumberDetails.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return details
    return readParticipantPhoneNumberDetails;
  }

  /**
   * Creates a concern role address record
   *
   * @param details
   * The concern role ID and the address details.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantAddressDetails createAddress(
    final MaintainParticipantAddressDetails details) throws AppException,
      InformationalException {

    // Address maintenance object and key
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();
    final MaintainAddressKey maintainAddressKey = new MaintainAddressKey();

    // Details to be returned
    final CreateParticipantAddressDetails createParticipantAddressDetails = new CreateParticipantAddressDetails();

    // Get concern role ID from key
    maintainAddressKey.concernRoleID = details.addressDetails.concernRoleID;

    // Create Address
    createParticipantAddressDetails.informationalMsgDtlsList = maintainConcernRoleAddressObj.createAddress(
      maintainAddressKey, details.addressDetails);

    // Return details
    return createParticipantAddressDetails;
  }

  /**
   * Modifies an address record for a concern role
   *
   * @param details
   * The concern role ID and concern role address details.
   *
   * @return ModifiedAddressDetails modified address details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ModifiedAddressDetails modifyAddress
    (final MaintainParticipantAddressDetails details)
    throws AppException, InformationalException {

    final ModifiedAddressDetails modifiedAddressDetails = new ModifiedAddressDetails();

    // Address maintenance object and key
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();
    final MaintainAddressKey maintainAddressKey = new MaintainAddressKey();

    // Get concern role ID from key
    maintainAddressKey.concernRoleID = details.addressDetails.concernRoleID;

    // Modify Address
    maintainConcernRoleAddressObj.modifyAddress(maintainAddressKey,
      details.addressDetails);

    // BEGIN, CR00077092, BF
    // Return all messages from the evidence Controller.
    final EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final ECWarningsDtlsList ecWarningsDtlsList = evidenceControllerObj.getWarnings();

    for (int i = 0; i < ecWarningsDtlsList.dtls.size(); i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls = ecWarningsDtlsList.dtls.item(i);
      modifiedAddressDetails.warnings.dtls.addRef(ecWarningsDtls);
    }
    // END, CR00077092

    // return all informational messages
    return modifiedAddressDetails;

  }

  /**
   * Removes an address record for a concern role
   *
   * @param key The concern role address key
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void removeAddress(final ReadParticipantAddressKey key)
    throws AppException, InformationalException {

    // Address maintenance object
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();

    // Remove the Address
    maintainConcernRoleAddressObj.removeAddress(key.readConcernRoleAddressKey);
  }

  // BEGIN, CR00143201, JMA

  /**
   * Retrieves a list of address records for a concern role and displays them as
   * strings.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ParticipantAddressStringList listAddressString(
    final ReadParticipantAddressListKey key) throws AppException,
      InformationalException {

    // Address maintenance object
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();

    // BEGIN, CR00181398, MC
    final Address addressObj = AddressFactory.newInstance();

    // Details to be returned
    final ParticipantAddressStringList participantAddressStringList = new ParticipantAddressStringList();

    // Read list of addresses
    final ReadMultiByConcRoleIDResult readMultiByConcRoleIDResult = maintainConcernRoleAddressObj.readmultiByConcernRoleID(
      key.maintainAddressKey);

    AddressString addressString;
    OtherAddressData otherAddressData;
    AddressKey addressKey;

    for (int j = 0; j < readMultiByConcRoleIDResult.details.dtls.size(); j++) {

      // BEGIN, CR00183340, JMA
      if (!readMultiByConcRoleIDResult.details.dtls.item(j).statusCode.equals(
        RECORDSTATUS.CANCELLED)) {

        // BEGIN, CR00149694, ZV
        // BEGIN, CR00340652, KRK
        if (!readMultiByConcRoleIDResult.details.dtls.item(j).addressLine1.equals(
          BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE.getMessageText(
            TransactionInfo.getProgramLocale()))) {
          // END, CR00340652

          addressString = new AddressString();
          addressKey = new AddressKey();
          otherAddressData = new OtherAddressData();

          addressKey.addressID = readMultiByConcRoleIDResult.details.dtls.item(j).addressID;

          final AddressDtls addressDtls = addressObj.read(addressKey);

          otherAddressData.addressData = addressDtls.addressData;

          addressString = displaySingleLineAddress(otherAddressData);

          addressString.addressID = readMultiByConcRoleIDResult.details.dtls.item(j).addressID;
          participantAddressStringList.addressStringDtls.addRef(addressString);

        }
        // END, CR00181398
        // END, CR00149694
      }
      // END, CR00183340
    }

    // Return details
    return participantAddressStringList;

  }

  // END, CR00143201

  // BEGIN, CR00181398, MC
  
  /**
   * Display the address given as a single line. The address is formatted based
   * on the ENV_ADDRESSSTRINGFORMAT environment variable.
   *
   * @param OtherAddressData The address formatted with its descriptors i.e.
   * ADD1=Line1, ADD2=Line2, ADD3=Line3 ...
   *
   * @return AddressString, the address given as a single line.
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public AddressString displaySingleLineAddress(
    final OtherAddressData otherAddressData) throws AppException,
      InformationalException {

    final AddressString addressString = new AddressString();

    // BEGIN, CR00353168, SPD
    Address addressObj = AddressFactory.newInstance();

    addressString.addressString = addressObj.getShortFormat(otherAddressData).addressData;
    // END, CR00353168

    return addressString;
  }

  // END, CR00181398


  /**
   * Retrieves a list of address records for a concern role.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAddressList listAddress(
    final ReadParticipantAddressListKey key) throws AppException,
      InformationalException {

    // Address maintenance object
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();

    // Details to be returned
    final ReadParticipantAddressList readParticipantAddressList = new ReadParticipantAddressList();

    // Read list of addresses
    readParticipantAddressList.readMultiByConcRoleIDResult = maintainConcernRoleAddressObj.readmultiByConcernRoleID(
      key.maintainAddressKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.maintainAddressKey.concernRoleID;

    // Get the context description for the concern role
    readParticipantAddressList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      readParticipantAddressList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // Return details
    return readParticipantAddressList;
  }

  /**
   * Cancels a concern role address record
   *
   * @param key
   * The concern role address which is to be canceled
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelAddress(final CancelParticipantAddressKey key)
    throws AppException, InformationalException {

    // Address maintenance object
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();

    // Cancel the Address
    maintainConcernRoleAddressObj.cancelAddress(key.cancelConcernRoleAddressKey);
  }

  /**
   * Reads an address record for a concern role
   *
   * @param key
   * The concern role address key.
   *
   * @return The address details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAddressDetails readAddress
    (final ReadParticipantAddressKey key)
    throws AppException, InformationalException {

    // Address maintenance object
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();

    // Details to be returned
    final ReadParticipantAddressDetails readParticipantAddressDetails = new ReadParticipantAddressDetails();

    // Read the address
    readParticipantAddressDetails.addressDetails = maintainConcernRoleAddressObj.readAddress(
      key.readConcernRoleAddressKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = readParticipantAddressDetails.addressDetails.concernRoleID;
    // Get the context description for the concern role
    readParticipantAddressDetails.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return details
    return readParticipantAddressDetails;
  }

  /**
   * Retrieves a list of administration roles for the specified concern role.
   *
   * @param key
   * The concern role ID for which a list of admin roles is returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link Participant#listAdministrators(ReadParticipantAdminRoleListKey)}.
   */
  @Deprecated
  @SuppressWarnings(value = CuramConst.gkUnchecked)
  public ReadParticipantAdminRoleList listAdminRole(
    final ReadParticipantAdminRoleListKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00120078, SPD
    // Details to be returned
    final ReadParticipantAdminRoleList readParticipantAdminRoleList = new ReadParticipantAdminRoleList();

    // AdminRole maintenance object
    final MaintainAdminConcernRole maintainAdminConcernRole = MaintainAdminConcernRoleFactory.newInstance();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    // ClientMerge manipulation variables
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
    final ClientMerge clientMergeSLObj = ClientMergeFactory.newInstance();

    // Set concern role
    concernRoleKey.concernRoleID = key.maintainAdminConcernRoleKey.concernRoleID;

    // Set current concern role
    currentKey.concernRoleID = key.maintainAdminConcernRoleKey.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listAdminRoleForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listAdminRole;

    // Read list of AdminRoles
    readParticipantAdminRoleList.maintainAdminConcernRoleReadMultiDtlsList = maintainAdminConcernRole.readmultiByConcernRole(
      key.maintainAdminConcernRoleKey);

    // Populate context description key
    participantContextKey.participantContextDescriptionKey.concernRoleID = key.maintainAdminConcernRoleKey.concernRoleID;

    // Get the context description for the concern role
    readParticipantAdminRoleList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Display the duplicate client role soft links in a tab format

    // Set concernRole to current concernRole
    currentKey.concernRoleID = concernRoleKey.concernRoleID;

    // Build up the xml data needed for the tab widget
    readParticipantAdminRoleList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

    // Populate key to check for duplicate
    concernRoleIDStatusCodeKey.concernRoleID = key.maintainAdminConcernRoleKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

    // Set an indicator if this concern has duplicates
    readParticipantAdminRoleList.ind = clientMergeSLObj.isConcernRoleOriginalClient(
      concernRoleIDStatusCodeKey);
    // END, CR00120078

    // BEGIN, CR00161028, MC
    // Need to sort the list of admin roles returned according to the start date
    // displaying the active record first.

    // Sort by start date ascending
    final CompositeComparator compComparator = new CompositeComparator();

    // Sort the active record to be first.
    compComparator.setMajor(new AdminRoleStatusComparator());
    // Sort by the start date.
    compComparator.setMinor(new StartDateComparator());

    // Do the composite sort
    Collections.sort(
      readParticipantAdminRoleList.maintainAdminConcernRoleReadMultiDtlsList.dtls,
      compComparator);
    // END, CR00161028

    // Return details
    return readParticipantAdminRoleList;
  }

  // BEGIN, CR00177505, RPB
  /**
   * Retrieves a list of administration roles for the specified duplicate
   * concern role.
   *
   * @param key The concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link Participant#listAdministratorsForDuplicateParticipant(
   * ReadParticipantAdminRoleListKey)}.
   */
  @Deprecated
  public ReadParticipantAdminRoleList listAdminRoleForDuplicate(
    final ReadParticipantAdminRoleListKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Return struct
    ReadParticipantAdminRoleList adminRoleList = new ReadParticipantAdminRoleList();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ClientMerge manipulation variables
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
    final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

    // ContextDescription variables
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();
    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList concernRoleDupDtlsList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new
      ConcernRoleIDStatusCodeKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    // Retrieve list of administration roles for the specified concern role
    adminRoleList = listAdminRole(key);

    // Populate key to read concernRoleID
    dupKey.duplicateConcernRoleID = key.maintainAdminConcernRoleKey.concernRoleID;

    // Get original person concern role ID by searching on the duplicate ID
    concernRoleDupDtlsList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(
      dupKey);

    // Set the context description key to be the original concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = key.maintainAdminConcernRoleKey.concernRoleID;

    // Get the context description for the original concern role
    participantContextDetails = readContextDescription(participantContextKey);

    adminRoleList.participantContextDescriptionDetails.description = participantContextDetails.participantContextDescriptionDetails.description;

    // Display the duplicate client role soft links in a tab format

    concernRoleKey.concernRoleID = concernRoleDupDtlsList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.maintainAdminConcernRoleKey.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listAdminRoleForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listAdminRole;

    // Build up the xml data needed for the tab widget
    adminRoleList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

    // Populate key to check for duplicate
    concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

    // Set an indicator if this concern has duplicates
    adminRoleList.ind = clientMergeSLObj.isConcernRoleOriginalClient(
      concernRoleIDStatusCodeKey);
    // END, CR00120078

    return adminRoleList;
  }

  // END, CR00177505

  /**
   * Create a new administrator for the concernRole supplied
   *
   * @param details
   * The administrator role details being entered.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link Participant#createAdministrator(ParticipantAdministratorDetails)}.
   */
  @Deprecated
  public void createAdminRole(
    final curam.core.facade.struct.CreateParticipantAdminRoleDetails details)
    throws AppException, InformationalException {

    // AdminRole maintenance object and key
    final curam.core.intf.MaintainAdminConcernRole maintainAdminConcernRole = curam.core.fact.MaintainAdminConcernRoleFactory.newInstance();
    final MaintainAdminConcernRoleKey maintainAdminConcernRoleKey = new MaintainAdminConcernRoleKey();

    // Get concern role ID from key
    maintainAdminConcernRoleKey.concernRoleID = details.createParticipantAdminRoleDetails.concernRoleID;

    // Prepare details to be passed into create method
    final MaintainAdminConcernRoleDetails maintainAdminConcernRoleDetails = new MaintainAdminConcernRoleDetails();

    maintainAdminConcernRoleDetails.concernRoleID = details.createParticipantAdminRoleDetails.concernRoleID;
    maintainAdminConcernRoleDetails.userName = details.createParticipantAdminRoleDetails.userName;

    // Create AdminRole
    maintainAdminConcernRole.createNewConcernRoleOwner(
      maintainAdminConcernRoleKey, maintainAdminConcernRoleDetails);
  }

  /**
   * Read the context description for a concern role ID.
   *
   * @param key
   * The concern role ID for which the description is retrieved.
   *
   * @return The returned description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since 6.0, the method is a duplicate method of
   * {@link ParticipantContext.readContextDescription(
   * ParticipantContextDescriptionKey)}.
   */
  @Deprecated
  public ParticipantContextDetails readContextDescription(
    final ParticipantContextKey key)
    throws AppException, InformationalException {

    // Concern Role object and key.
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    // Details returned from the concern role read.
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    // Details to be returned.
    final ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    // Get the concern role ID from the key.
    concernRoleKey.concernRoleID = key.participantContextDescriptionKey.concernRoleID;

    // Read the concern role details.
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    if (concernRoleDtls.concernRoleType.equals(CONCERNROLETYPE.PROSPECTPERSON)) {
      // Set the context description for prospect.
      // BEGIN, CR00020655, NH
      if (concernRoleDtls.primaryAlternateID.length() == 0) {

        // Set the context description.
        participantContextDetails.participantContextDescriptionDetails.description = concernRoleDtls.concernRoleName;
      } else {

        // Set the context description.
        // BEGIN, CR00098567, DJ
        // Added kSpace
        participantContextDetails.participantContextDescriptionDetails.// BEGIN, CR00222190, ELG
          description = concernRoleDtls.concernRoleName + kSpace
          + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
          TransactionInfo.getProgramLocale())
          + concernRoleDtls.primaryAlternateID;
        // END, CR00222190
      }

      // END, CR00098567
    } else {

      if (concernRoleDtls.primaryAlternateID.length() == 0) {

        // Set the context description.
        participantContextDetails.participantContextDescriptionDetails.description = concernRoleDtls.concernRoleName;
      } else {

        // Set the context description.
        // BEGIN, CR00098567, DJ
        // Added kSpace
        participantContextDetails.participantContextDescriptionDetails.// BEGIN, CR00222190, ELG
          description = concernRoleDtls.concernRoleName + kSpace
          + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
          TransactionInfo.getProgramLocale())
          + concernRoleDtls.primaryAlternateID;
        // END, CR00222190
        // END, CR00098567
      }
    }

    return participantContextDetails;
  }

  /**
   * Creates a concern role alternate id record.
   *
   * @param details
   * The concern role ID and alternate id details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantAlternateIDDetails createAlternateID(
    final MaintainParticipantAlternateIDDetails details) throws AppException,
      InformationalException {

    // Alternate ID maintenance object and key
    final curam.core.intf.MaintainConcernRoleAltID maintainConcernRoleAltIDObj = curam.core.fact.MaintainConcernRoleAltIDFactory.newInstance();
    final MaintainConcernRoleAltIDKey maintainConcernRoleAltIDKey = new MaintainConcernRoleAltIDKey();

    // Details to be returned
    final CreateParticipantAlternateIDDetails createParticipantAlternateIDDetails = new CreateParticipantAlternateIDDetails();

    // Get concern role ID from key
    maintainConcernRoleAltIDKey.concernRoleID = details.alternateIDDetails.concernRoleID;

    // Create alternate ID
    createParticipantAlternateIDDetails.informationalMsgDtlsList = maintainConcernRoleAltIDObj.createAlternateID(
      maintainConcernRoleAltIDKey, details.alternateIDDetails);

    // Return details
    return createParticipantAlternateIDDetails;
  }

  /**
   * Modifies an alternate id record for a concern role.
   *
   * @param details
   * The concern role ID and alternate id detail being modified.
   *
   * @return ModifiedAlternateIDDetails modified alternateID details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ModifiedAlternateIDDetails modifyAlternateID(final MaintainParticipantAlternateIDDetails details)
    throws AppException, InformationalException {

    final ModifiedAlternateIDDetails modifiedAlternateIDDetails = new ModifiedAlternateIDDetails();

    // Alternate ID maintenance object and key
    final curam.core.intf.MaintainConcernRoleAltID maintainConcernRoleAltIDObj = curam.core.fact.MaintainConcernRoleAltIDFactory.newInstance();
    final MaintainConcernRoleAltIDKey maintainConcernRoleAltIDKey = new MaintainConcernRoleAltIDKey();

    // Get concern role ID from key
    maintainConcernRoleAltIDKey.concernRoleID = details.alternateIDDetails.concernRoleID;

    // Modify the alternate ID
    maintainConcernRoleAltIDObj.modifyAlternateID(maintainConcernRoleAltIDKey,
      details.alternateIDDetails);

    // BEGIN, CR00077092, BF
    // Return all messages from the evidence Controller.
    final EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final ECWarningsDtlsList ecWarningsDtlsList = evidenceControllerObj.getWarnings();

    for (int i = 0; i < ecWarningsDtlsList.dtls.size(); i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls = ecWarningsDtlsList.dtls.item(i);
      modifiedAlternateIDDetails.warnings.dtls.addRef(ecWarningsDtls);
    }
    return modifiedAlternateIDDetails;
    // END, CR00077092
  }

  /**
   * Reads an alternate id record for a concern role.
   *
   * @param key
   * The concern role alternate id of the record being read.
   *
   * @return The alternate ID details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAlternateIDDetails readAlternateID(
    final ReadParticipantAlternateIDKey key) throws AppException,
      InformationalException {

    // Alternate ID maintenance object
    final curam.core.intf.MaintainConcernRoleAltID maintainConcernRoleAltIDObj = curam.core.fact.MaintainConcernRoleAltIDFactory.newInstance();

    // Details to be returned
    final ReadParticipantAlternateIDDetails readParticipantAlternateIDDetails = new ReadParticipantAlternateIDDetails();

    // Read the alternate ID
    readParticipantAlternateIDDetails.alternateIDDetails = maintainConcernRoleAltIDObj.readAlternateID(
      key.readConcernRoleAltIDKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = readParticipantAlternateIDDetails.alternateIDDetails.concernRoleID;
    // Get the context description for the concern role
    readParticipantAlternateIDDetails.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return details
    return readParticipantAlternateIDDetails;
  }

  /**
   * Cancels a concern role alternate id record.
   *
   * @param key
   * The concern role alternate id which is being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelAlternateID(final CancelParticipantAlternateIDKey key)
    throws AppException, InformationalException {

    // Alternate ID maintenance object
    final curam.core.intf.MaintainConcernRoleAltID maintainConcernRoleAltIDObj = curam.core.fact.MaintainConcernRoleAltIDFactory.newInstance();

    // Cancel the Alternate ID
    maintainConcernRoleAltIDObj.cancelAlternateID(key.cancelConcernRoleAltIDKey);
  }

  /**
   * Retrieves a list of alternate id records for a concern role.
   *
   * @param key
   * The concern role ID for which a list of alternate ID's is
   * returned.
   *
   * @return The list of alternate ID's returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAlternateIDList listAlternateID(
    final ReadParticipantAlternateIDListKey key) throws AppException,
      InformationalException {

    // Alternate ID maintenance object
    final curam.core.intf.MaintainConcernRoleAltID maintainConcernRoleAltIDObj = curam.core.fact.MaintainConcernRoleAltIDFactory.newInstance();

    // Details to be returned
    final ReadParticipantAlternateIDList readParticipantAlternateIDList = new ReadParticipantAlternateIDList();

    // Read list of alternate IDs
    readParticipantAlternateIDList.readmultiByConcernRoleIDAltIDResult = maintainConcernRoleAltIDObj.readmultiByConcernRoleID(
      key.maintainConcernRoleAltIDKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.maintainConcernRoleAltIDKey.concernRoleID;
    // Get the context description for the concern role
    readParticipantAlternateIDList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      readParticipantAlternateIDList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // Return details
    return readParticipantAlternateIDList;
  }

  // BEGIN, CR00231961, ZV
  /**
   * Create a new bank account for a participant.
   *
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createBankAccountWithTextSortCode()}. See release note: CR00231961
   */
  @Deprecated
  public CreateParticipantBankAccountDetails createBankAccount(
    final MaintainParticipantBankAccountDetails details) throws AppException,
      InformationalException {

    final MaintainParticipantBankAccountWithTextSortCodeDetails bankAccountDetails = new MaintainParticipantBankAccountWithTextSortCodeDetails();

    bankAccountDetails.participantBankAccountDetails.assign(
      details.participantBankAccountDetails);
    bankAccountDetails.bankSortCode = details.participantBankAccountDetails.bankSortCode;

    return createBankAccountWithTextSortCode(bankAccountDetails);
  }

  /**
   * Modify the bank account details for a participant.
   *
   * @param details
   * The bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #modifyBankAccountWithTextSortCode()}. See release note: CR00231961
   */
  @Deprecated
  public InformationMsgDtlsList modifyBankAccount(
    final MaintainParticipantBankAccountDetails details) throws AppException,
      InformationalException {

    final MaintainParticipantBankAccountWithTextSortCodeDetails bankAccountDetails = new MaintainParticipantBankAccountWithTextSortCodeDetails();

    bankAccountDetails.participantBankAccountDetails.assign(
      details.participantBankAccountDetails);
    bankAccountDetails.bankSortCode = details.participantBankAccountDetails.bankSortCode;

    return modifyBankAccountWithTextSortCode(bankAccountDetails);
  }

  // END, CR00231961

  /**
   * Read the details of a participants bank account.
   *
   * @param key
   * The bank account ID of the record being read.
   *
   * @return The bank account details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantBankAccountDetails readBankAccount(
    final ReadParticipantBankAccountKey key) throws AppException,
      InformationalException {

    // Bank account maintenance object
    final curam.core.intf.MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = curam.core.fact.MaintainConcernRoleBankAcFactory.newInstance();

    // Details to be returned
    final ReadParticipantBankAccountDetails readParticipantBankAccountDetails = new ReadParticipantBankAccountDetails();

    // Details returned from the read
    BankAccountDetails bankAccountDetails = new BankAccountDetails();

    // Read the bank account
    bankAccountDetails = maintainConcernRoleBankAcObj.readBankAccount(
      key.readConcernRoleBankAcKey);

    // Assign the details
    readParticipantBankAccountDetails.participantBankAccountDetails.assign(
      bankAccountDetails);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = readParticipantBankAccountDetails.participantBankAccountDetails.concernRoleID;
    // Get the context description for the concern role
    readParticipantBankAccountDetails.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return details
    return readParticipantBankAccountDetails;
  }

  /**
   * Retrieves a list of bank accounts for a participant.
   *
   * @param key
   * The concern role ID for which a list of bank accounts is returned.
   *
   * @return The list of bank accounts returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantBankAccountList listBankAccount(
    final ReadParticipantBankAccountListKey key) throws AppException,
      InformationalException {

    // Bank account maintenance object
    final curam.core.intf.MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = curam.core.fact.MaintainConcernRoleBankAcFactory.newInstance();

    // Details to be returned
    final ReadParticipantBankAccountList readParticipantBankAccountList = new ReadParticipantBankAccountList();

    // Read list of bank accounts
    readParticipantBankAccountList.readMultiByConcernRoleIDBankAcResult = maintainConcernRoleBankAcObj.readmultiByConcernRole(
      key.maintainBankAccountKey);
    
    // BEGIN, CR00371769, VT
    // BEGIN, CR00372632, VT
    // Bank Account values should be displayed based on following logic
    // 1. If IBAN is entered, Bank Account field will populate the IBAN.
    // 2. If Basic Bank Account Number (BBAN) is entered, Bank Account field
    // will populate the BBAN.
    // 3. If IBAN and BBAN are entered, Bank Account field will populate the
    // IBAN value.

    for (BankAccountRMDtls bankAccountRMDtls : readParticipantBankAccountList.readMultiByConcernRoleIDBankAcResult.details.dtls) {
      if (0 != bankAccountRMDtls.ibanOpt.length()) {
        bankAccountRMDtls.bankAccountNumberOpt = bankAccountRMDtls.ibanOpt;
      } else {
        bankAccountRMDtls.bankAccountNumberOpt = bankAccountRMDtls.accountNumber;
      }
    }
    // END, CR00372632
    // END, CR00371769

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.maintainBankAccountKey.concernRoleID;
    // Get the context description for the concern role
    readParticipantBankAccountList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      readParticipantBankAccountList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    // Return details
    return readParticipantBankAccountList;
  }

  // BEGIN, CR00247430, MR
  /**
   * Cancel a bank account for a participant.
   *
   * @param key
   * The ID of the bank account being canceled.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 5.2 SP4, replaced with {@link
   * Participant#cancelParticipantBankAccount(
   * CancelParticipantBankAccountKey)}.
   * This method is not handling the cancellation of joint accounts.
   * So the new method cancelParticipantBankAccount() handles the
   * cancellation of normal bank account as well as joint accounts.
   * See release note: CR00247430.
   */
  @Deprecated
  // END, CR00247430
  public void cancelBankAccount(final CancelParticipantBankAccountKey key)
    throws AppException, InformationalException {

    // Bank account maintenance object
    final curam.core.intf.MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = curam.core.fact.MaintainConcernRoleBankAcFactory.newInstance();

    // Cancel the bank account
    maintainConcernRoleBankAcObj.cancelConcernBankAccount(
      key.cancelConcernRoleBankAccountKey);
  }

  // BEGIN, CR00156614, MR

  // BEGIN, CR00247430, MR
  /**
   * Replaces the deprecated method {@link
   * Participant#cancelBankAccount(CancelParticipantBankAccountKey)}.
   * <P>
   * Cancel a bank account for a participant.
   *
   * This method handles the cancellation of normal bank account
   * as well as joint accounts.
   *
   * @param key The ID of the bank account being canceled.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  // END, CR00247430
  public InformationMsgDtlsList cancelParticipantBankAccount
    (final CancelParticipantBankAccountKey key)
    throws AppException, InformationalException {

    // create return object.
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    // Bank account maintenance object
    final curam.core.intf.MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = curam.core.fact.MaintainConcernRoleBankAcFactory.newInstance();

    // Cancel the bank account
    maintainConcernRoleBankAcObj.cancelParticipantBankAccount(
      key.cancelConcernRoleBankAccountKey);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // return all informational messages
    return informationMsgDtlsList;
  }

  // END, CR00156614

  /**
   * Creates a concern role communication exception record.
   *
   * @param details
   * The concern role communication exception details being entered.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    // Communication Exception maintenance object and key
    final curam.core.intf.MaintainConcernRoleCommException maintainConcernRoleCommExceptionObj = curam.core.fact.MaintainConcernRoleCommExceptionFactory.newInstance();
    final MaintainCommExceptionKey maintainCommExceptionKey = new MaintainCommExceptionKey();

    // Get concern role ID from key
    maintainCommExceptionKey.concernRoleID = details.commExceptionDetails.concernRoleID;

    // Create communication exception
    maintainConcernRoleCommExceptionObj.createCommException(
      maintainCommExceptionKey, details.commExceptionDetails);
  }

  /**
   * Modifies a communication exception record for a concern role.
   *
   * @param details
   * The concern role communication exception details being modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    // Communication Exception maintenance object and key
    final curam.core.intf.MaintainConcernRoleCommException maintainConcernRoleCommExceptionObj = curam.core.fact.MaintainConcernRoleCommExceptionFactory.newInstance();
    final MaintainCommExceptionKey maintainCommExceptionKey = new MaintainCommExceptionKey();

    // Get concern role ID from key
    maintainCommExceptionKey.concernRoleID = details.commExceptionDetails.concernRoleID;

    // Modify the communication exception
    maintainConcernRoleCommExceptionObj.modifyCommException(
      maintainCommExceptionKey, details.commExceptionDetails);
  }

  /**
   * Reads a communication exception record for a concern role.
   *
   * @param key
   * The communication exception ID of the record being read.
   *
   * @return The communication exception details found returned from the
   * database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantCommunicationExceptionDetails readCommunicationException(
    final ReadParticipantCommunicationExceptionKey key) throws AppException,
      InformationalException {

    // Communication Exception maintenance object
    final curam.core.intf.MaintainConcernRoleCommException maintainConcernRoleCommExceptionObj = curam.core.fact.MaintainConcernRoleCommExceptionFactory.newInstance();

    // Details to be returned
    final ReadParticipantCommunicationExceptionDetails readParticipantCommunicationExceptionDetails = new ReadParticipantCommunicationExceptionDetails();

    // Read the communication exception
    readParticipantCommunicationExceptionDetails.commExceptionDetails = maintainConcernRoleCommExceptionObj.readCommException(
      key.readConcernRoleCommExcKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = readParticipantCommunicationExceptionDetails.commExceptionDetails.concernRoleID;
    // Get the context description for the concern role
    readParticipantCommunicationExceptionDetails.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return details
    return readParticipantCommunicationExceptionDetails;
  }

  /**
   * Retrieves a list of communication exception records for a concern role.
   *
   * @param key
   * The concern role ID for which a list of communication exceptions
   * are returned.
   *
   * @return The list of communication exceptions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantCommunicationExceptionList listCommunicationException(
    final ReadParticipantCommunicationExceptionListKey key) throws AppException,
      InformationalException {

    // Communication Exception maintenance object
    final curam.core.intf.MaintainConcernRoleCommException maintainConcernRoleCommExceptionObj = curam.core.fact.MaintainConcernRoleCommExceptionFactory.newInstance();

    // Details to be returned
    final ReadParticipantCommunicationExceptionList readParticipantCommunicationExceptionList = new ReadParticipantCommunicationExceptionList();

    // Read list of communication exceptions
    readParticipantCommunicationExceptionList.commExceptionReadMultiDtlsList = maintainConcernRoleCommExceptionObj.readmultiByConcernRole(
      key.maintainCommExceptionKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.maintainCommExceptionKey.concernRoleID;
    // Get the context description for the concern role
    readParticipantCommunicationExceptionList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return details
    return readParticipantCommunicationExceptionList;
  }

  /**
   * Cancels a concern role communication exception record.
   *
   * @param key
   * The ID of the communication exception being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelCommunicationException(
    final CancelParticipantCommunicationExceptionKey key) throws AppException,
      InformationalException {

    // Communication Exception maintenance object
    final curam.core.intf.MaintainConcernRoleCommException maintainConcernRoleCommExceptionObj = curam.core.fact.MaintainConcernRoleCommExceptionFactory.newInstance();

    // Cancel the communication exception
    maintainConcernRoleCommExceptionObj.cancelCommException(
      key.cancelConcernRoleCommExcKey);
  }

  /**
   * Create a new email address for a participant.
   *
   * @param details
   * The email address details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantEmailAddressDetails createEmailAddress(
    final MaintainParticipantEmailAddressDetails details) throws AppException,
      InformationalException {

    // Email address maintenance object and key
    final curam.core.intf.MaintainConcernRoleEmail maintainConcernRoleEmailObj = curam.core.fact.MaintainConcernRoleEmailFactory.newInstance();
    final MaintainEmailKey maintainEmailKey = new MaintainEmailKey();

    // Details to be returned
    final CreateParticipantEmailAddressDetails createParticipantEmailAddressDetails = new CreateParticipantEmailAddressDetails();

    // Get concern role ID from key
    maintainEmailKey.concernRoleID = details.concernRoleEmailDetails.concernRoleID;

    // Create email address
    createParticipantEmailAddressDetails.informationalMsgDtlsList = maintainConcernRoleEmailObj.createEmailAddress(
      maintainEmailKey, details.concernRoleEmailDetails);

    // Return details
    return createParticipantEmailAddressDetails;
  }

  /**
   * Modify the details of an email address for a participant.
   *
   * @param details
   * The email address details being modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyEmailAddress(
    final MaintainParticipantEmailAddressDetails details)
    throws AppException, InformationalException {

    // Email address maintenance object
    final curam.core.intf.MaintainConcernRoleEmail maintainConcernRoleEmailObj = curam.core.fact.MaintainConcernRoleEmailFactory.newInstance();
    final MaintainEmailKey maintainEmailKey = new MaintainEmailKey();

    // Get concern role ID from key
    maintainEmailKey.concernRoleID = details.concernRoleEmailDetails.concernRoleID;

    // Modify the email address
    maintainConcernRoleEmailObj.modifyEmailAddress(maintainEmailKey,
      details.concernRoleEmailDetails);
  }

  /**
   * Read the details for a participants email address.
   *
   * @param key
   * The email address ID of the record being read.
   *
   * @return The email address details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantEmailAddressDetails readEmailAddress(
    final ReadParticipantEmailAddressKey key) throws AppException,
      InformationalException {

    // Email address maintenance object
    final curam.core.intf.MaintainConcernRoleEmail maintainConcernRoleEmailObj = curam.core.fact.MaintainConcernRoleEmailFactory.newInstance();

    // Details to be returned
    final ReadParticipantEmailAddressDetails readParticipantEmailAddressDetails = new ReadParticipantEmailAddressDetails();

    // Read the email address
    readParticipantEmailAddressDetails.concernRoleEmailDetails = maintainConcernRoleEmailObj.readEmailAddress(
      key.readConcernRoleEmailKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = readParticipantEmailAddressDetails.concernRoleEmailDetails.concernRoleID;
    // Get the context description for the concern role
    readParticipantEmailAddressDetails.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return details
    return readParticipantEmailAddressDetails;
  }

  /**
   * Retrieves a list of email addresses for a participant.
   *
   * @param key
   * The concern role ID for which a list of email addresses is
   * returned.
   *
   * @return The list of email addresses returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantEmailAddressList listEmailAddress(
    final ReadParticipantEmailAddressListKey key) throws AppException,
      InformationalException {

    // Email address maintenance object
    final curam.core.intf.MaintainConcernRoleEmail maintainConcernRoleEmailObj = curam.core.fact.MaintainConcernRoleEmailFactory.newInstance();

    // Details to be returned
    final ReadParticipantEmailAddressList readParticipantEmailAddressList = new ReadParticipantEmailAddressList();

    // Read list of email addresses
    readParticipantEmailAddressList.readMultiByConcernRoleEmailResult = maintainConcernRoleEmailObj.readmultiByConcernRole(
      key.maintainEmailKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.maintainEmailKey.concernRoleID;
    // Get the context description for the concern role
    readParticipantEmailAddressList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      readParticipantEmailAddressList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // Return details
    return readParticipantEmailAddressList;
  }

  /**
   * Cancel an email address for a participant.
   *
   * @param key
   * The ID of the email address being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelEmailAddress(final CancelParticipantEmailAddressKey key)
    throws AppException, InformationalException {

    // Email address maintenance object and key
    final curam.core.intf.MaintainConcernRoleEmail maintainConcernRoleEmailObj = curam.core.fact.MaintainConcernRoleEmailFactory.newInstance();

    // Cancel the email address
    maintainConcernRoleEmailObj.cancelEmailAddress(
      key.cancelConcernRoleEmailKey);
  }

  // BEGIN, CR00081067, POH
  /**
   * Reads the concernRoleType for a concernRole.
   *
   * @param key
   * The concern role ID for which the concernRoleType is read
   *
   * @return The concernRoleType.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  // BEGIN, CR00409050, SG
  @AccessLevel(AccessLevelType.EXTERNAL)
  // END, CR00409050
  public ConcernRoleTypeDetails readConcernRoleType
    (final ReadParticipantConcernRoleKey key)
    throws AppException, InformationalException {

    // return details
    final ConcernRoleTypeDetails concernRoleTypeDetails = new ConcernRoleTypeDetails();

    // Manipulation variables
    // BEGIN, CR00296773, ZV
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // populate key
    concernRoleKey.concernRoleID = key.readConcernRoleKey.concernRoleID;
    // read concern role details and populate the return struct
    concernRoleTypeDetails.concernRoleType = concernRoleObj.readConcernRoleType(concernRoleKey).concernRoleType;
    // END, CR00296773

    return concernRoleTypeDetails;
  }

  // END, CR00081067


  /**
   * Retrieves a list of client role records for a concern role.
   *
   * @param key
   * The concern role ID for which a list of client roles is returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantConcernRoleList listConcernRole(
    final ReadParticipantConcernRoleKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00120078, SPD
    // Details to be returned
    final ReadParticipantConcernRoleList readParticipantConcernRoleList = new ReadParticipantConcernRoleList();

    // Concern Role maintenance object
    final MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory.newInstance();

    // Context Description key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    // Page identifier variables
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // Read list of client roles
    readParticipantConcernRoleList.concernRolesDetailsList = maintainConcernRoleDetailsObj.readListOfConcernRoles(
      key.readConcernRoleKey);

    // Populate context description key
    participantContextKey.participantContextDescriptionKey.concernRoleID = key.readConcernRoleKey.concernRoleID;

    // Get the context description for the concern role
    readParticipantConcernRoleList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // BEGIN, CR00221607, MC
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();
      // END, CR00102618

      // ConcernRole manipulation variables
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRoleKey currentKey = new ConcernRoleKey();
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      // Set menu data for displaying any duplicate client roles
      concernRoleKey.concernRoleID = key.readConcernRoleKey.concernRoleID;

      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listRoleForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listRole;

      // Display the duplicate client role soft links in a tab format

      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Build up the xml data needed for the tab widget
      readParticipantConcernRoleList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      readParticipantConcernRoleList.ind = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);
      // END, CR00120078
    }
    // END, CR00221607
    // Return details
    return readParticipantConcernRoleList;
  }

  /**
   * Cancel a note for a participant.
   *
   * @param details
   * Identifies a participant note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelNote(
    final curam.core.facade.struct.CancelParticipantNoteDetails details)
    throws AppException, InformationalException {

    // Note maintenance object
    final curam.core.sl.intf.ParticipantNote participantNoteObj = curam.core.sl.fact.ParticipantNoteFactory.newInstance();

    // Cancel the Note
    participantNoteObj.cancel(details.details);
  }

  /**
   * Create a note for a participant.
   *
   * @param details
   * The participant note details being entered.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createNote(final ParticipantNoteDetails details)
    throws AppException, InformationalException {

    // Note maintenance object
    final curam.core.sl.intf.ParticipantNote participantNoteObj = curam.core.sl.fact.ParticipantNoteFactory.newInstance();

    participantNoteObj.insert(details.details);

  }

  // BEGIN, CR00231506, PDN
  /**
   * Retrieve a list of notes for a participant.
   *
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated - replaced by {@link #listNote1()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  public curam.core.facade.struct.ParticipantNoteList listNote(
    final curam.core.facade.struct.ParticipantKey key) throws AppException,
      InformationalException {

    // Details to be returned
    final curam.core.facade.struct.ParticipantNoteList participantNoteList = new curam.core.facade.struct.ParticipantNoteList();

    curam.core.facade.struct.ParticipantNoteList1 participantNoteList1 = listNote1(
      key);

    participantNoteList.assign(participantNoteList1);

    // Return details
    return participantNoteList;
  }

  /**
   * Retrieve a list of notes for a participant.
   *
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public curam.core.facade.struct.ParticipantNoteList1 listNote1(
    final curam.core.facade.struct.ParticipantKey key) throws AppException,
      InformationalException {

    // Note maintenance object
    final curam.core.sl.intf.ParticipantNote participantNoteObj = curam.core.sl.fact.ParticipantNoteFactory.newInstance();

    // Details to be returned
    final curam.core.facade.struct.ParticipantNoteList1 participantNoteList1 = new curam.core.facade.struct.ParticipantNoteList1();

    // Retrieve the list of notes
    participantNoteList1.list = participantNoteObj.list1(key.key);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.key.key.participantID;
    // Get the context description for the concern role
    participantNoteList1.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // BEGIN, CR00142625, PDN
    // Need to sort the list of Notes returned according to the modified time.
    // Construct a new comparator class that sorts the array list by modified
    // time.
    Collections.sort(participantNoteList1.list.details,
      new Comparator<SearchParticipantNoteByParticipantDetails1>() {

      public int compare(final SearchParticipantNoteByParticipantDetails1 note1,
        final SearchParticipantNoteByParticipantDetails1 note2) {

        if (note1.modifiedDateTime.after(note2.modifiedDateTime)) {
          return -1;
        } else if (note1.modifiedDateTime.before(note2.modifiedDateTime)) {
          return 1;
        } else {
          return 0;
        }
      }

    });
    // END, CR00142625

    // Return details
    return participantNoteList1;
  }

  /**
   * Modify the details of a note for a participant.
   * @param details
   * The participant note details to modify the note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated - replaced by {@link #modifyNote1()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  public void modifyNote(
    final curam.core.facade.struct.ModifyParticipantNoteDetails details)
    throws AppException, InformationalException {

    // Note maintenance object
    final curam.core.sl.intf.ParticipantNote participantNoteObj = curam.core.sl.fact.ParticipantNoteFactory.newInstance();

    participantNoteObj.modify(details.details);
  }

  /**
   * Modify the details of a note for a participant.
   *
   * @param details
   * The participant note details to modify the note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyNote1(final ModifyParticipantNoteDetails1 details)
    throws AppException, InformationalException {

    // Note maintenance object
    final curam.core.sl.intf.ParticipantNote participantNoteObj = curam.core.sl.fact.ParticipantNoteFactory.newInstance();

    participantNoteObj.modify1(details.details);
  }

  // END, CR00231506


  /**
   * Read the details of a note for a participant.
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated - replaced by {@link #readNote1()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  public curam.core.facade.struct.ReadParticipantNoteDetails readNote(
    final curam.core.facade.struct.ParticipantNoteKey key) throws AppException,
      InformationalException {

    // Details to be returned
    final curam.core.facade.struct.ReadParticipantNoteDetails readParticipantNoteDetails = new curam.core.facade.struct.ReadParticipantNoteDetails();

    curam.core.facade.struct.ReadParticipantNoteDetails1 readParticipantNoteDetails1 = readNote1(
      key);

    readParticipantNoteDetails.assign(readParticipantNoteDetails1);

    // Return details
    return readParticipantNoteDetails;
  }

  /**
   * Read the details of a note for a participant.
   *
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public curam.core.facade.struct.ReadParticipantNoteDetails1 readNote1(
    final curam.core.facade.struct.ParticipantNoteKey key) throws AppException,
      InformationalException {

    // Note maintenance object
    final curam.core.sl.intf.ParticipantNote participantNoteObj = curam.core.sl.fact.ParticipantNoteFactory.newInstance();

    // Details to be returned
    final curam.core.facade.struct.ReadParticipantNoteDetails1 readParticipantNoteDetails1 = new curam.core.facade.struct.ReadParticipantNoteDetails1();

    final curam.core.facade.intf.ParticipantContext participantContextObj = ParticipantContextFactory.newInstance();

    readParticipantNoteDetails1.noteDetails = participantNoteObj.read1(key.key);

    // Context key
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = readParticipantNoteDetails1.noteDetails.noteDetails.participantID;

    // Get the context description for the concern role
    readParticipantNoteDetails1.participantContextDescriptionDetails.description = participantContextObj.readContextDescription(participantContextDescriptionKey).description;

    // Return details
    return readParticipantNoteDetails1;
  }

  // END, CR00231506

  /**
   * Read the Contact Context Description Details for a Participant.
   *
   * @param key
   * The contact ID the context description is returned for.
   *
   * @return The contact context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ContactContextDescriptionDetails readParticipantContactContextDescription(
    final ContactContextDescriptionKey key) throws AppException,
      InformationalException {

    // Concern Role Contact Maintenance Object
    final curam.core.intf.ConcernRoleContact concernRoleContactObj = curam.core.fact.ConcernRoleContactFactory.newInstance();

    // Instance of Concern Role Contact Key
    final ConcernRoleContactKey concernRoleContactKey = new ConcernRoleContactKey();

    // Set the Contact ID
    concernRoleContactKey.contactID = key.contactID;

    // Read the Concern Role Contact Dtls
    final ConcernRoleContactDtls concernRoleContactDtls = concernRoleContactObj.read(
      concernRoleContactKey);

    // Concern Role Maintenance Object
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // Instance of Concern Role Key
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set the Concern Role ID
    concernRoleKey.concernRoleID = concernRoleContactDtls.concernRoleID;

    // Read the Concern Role Dtls
    final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // The Object to be returned
    final ContactContextDescriptionDetails contactContextDescriptionDetails = new ContactContextDescriptionDetails();

    final LocalisableString description = new LocalisableString(
      curam.message.BPOPARTICIPANT.INF_CONTACT_FOR);

    description.arg(concernRoleContactDtls.name);
    description.arg(concernRoleDtls.concernRoleName);

    // BEGIN, CR00163236, CL
    // Assign the String to the description
    contactContextDescriptionDetails.description = description.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163236

    // Return the Object
    return contactContextDescriptionDetails;

  }

  /**
   * Cancels a contact record.
   *
   * @param key
   * The contact ID for the record being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelContact(final CancelContactKey key) throws AppException,
      InformationalException {

    // Contact maintenance object and key
    final curam.core.intf.MaintainContacts maintainContactsObj = curam.core.fact.MaintainContactsFactory.newInstance();

    // Cancel the record.
    maintainContactsObj.cancelContact(key.contactCancelKey);
  }

  // BEGIN, CR00294967, MV
  /**
   * Create a contact.
   *
   * @param details
   * The contact details being entered
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by
   * {@link #createConcernContact()}. The parameter struct of the
   * current method createConcernRoleContact has an attribute
   * statusCode is modeled with a domain of CONTACTSTATUS
   * code-table, but the corresponding entity attribute
   * ConcernRoleContactDtls.statusCode is modeled with a domain of
   * RECORD_STATUS_CODE. So new method is introduced to have new
   * parameter ConcernContactRMultiDtls where the attribute
   * statusCode is modeled with a domain of RECORD_STATUS_CODE. See
   * release note: CEF-8999.
   */
  @Deprecated
  // END, CR00294967
  public void createContact(final CreateContactDetails details)
    throws AppException, InformationalException {

    // Contact maintenance object and key.
    final curam.core.intf.MaintainContacts maintainContactsObj = curam.core.fact.MaintainContactsFactory.newInstance();

    // Concern Role object and key to get concern name.
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    // Check to ensure a Contact has been entered
    if (details.concernContactDtls.contactConRoleID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINCONTACTS.ERR_CONTACTS_FV_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Set the key a read the concern role details
    concernRoleKey.concernRoleID = details.concernContactDtls.contactConRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    details.concernContactDtls.name = concernRoleDtls.concernRoleName;

    // Create the Contact.
    maintainContactsObj.createContact(details.concernContactDtls);
  }

  // BEGIN, CR00294967, MV
  /**
   * Create a contact.
   *
   * @param details
   * The contact details being entered
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createConcernContact(final CreateConcernContactDetails details)
    throws AppException, InformationalException {

    final MaintainContacts maintainContactsObj = MaintainContactsFactory.newInstance();

    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    if (0 == details.concernContactRMultiDtls.contactConRoleID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINCONTACTS.ERR_CONTACTS_FV_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    concernRoleKey.concernRoleID = details.concernContactRMultiDtls.contactConRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    details.concernContactRMultiDtls.name = concernRoleDtls.concernRoleName;

    maintainContactsObj.createConcernContact(details.concernContactRMultiDtls);
  }

  /**
   * A list of contacts for a participant.
   *
   * @param key
   * The concern role ID for which a list of contacts is returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP3, replaced by {@link listConcernContact()}
   * .The return struct of the current method listContact has an
   * aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct ListConcernContactDetails which
   * has an aggregation to the new struct ConcernContactRMultiDtls
   * where the attribute statusCode is modeled with a domain of
   * RECORD_STATUS_CODE. See release note: CEF-8999.
   */
  @Deprecated
  // END, CR00294967
  public ListContactDetails listContact(final ListContactKey key)
    throws AppException, InformationalException {

    // Contact maintenance object and key
    final curam.core.intf.MaintainContacts maintainContactsObj = curam.core.fact.MaintainContactsFactory.newInstance();

    // Concern Role object and key.
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    // Details to be returned
    final ListContactDetails listContactDetails = new ListContactDetails();

    // Read list of contacts
    listContactDetails.concernContactRMDtlsList = maintainContactsObj.readmultiByConcernRoleID(
      key.contactRMByConcernKey);

    if (!listContactDetails.concernContactRMDtlsList.dtls.isEmpty()) {
      // Read the concern role for each contact and set the concern role type.
      for (int i = 0; i
        < listContactDetails.concernContactRMDtlsList.dtls.size(); i++) {
        // BEGIN, CR00280979, PB
        ConcernContactRMDtls participantContactTypeCode = listContactDetails.concernContactRMDtlsList.dtls.item(
          i);

        concernRoleKey.concernRoleID = participantContactTypeCode.contactConRoleID;
        concernRoleDtls = concernRoleObj.read(concernRoleKey);
        participantContactTypeCode.contactConcernRoleType = concernRoleDtls.concernRoleType;

        // Get the concern role type for the selected concern role.
        ReadParticipantConcernRoleKey readParticipantConcernRoleKey = new ReadParticipantConcernRoleKey();
        ConcernRoleTypeDetails concernRoleTypeDetails = new ConcernRoleTypeDetails();

        readParticipantConcernRoleKey.readConcernRoleKey.concernRoleID = key.contactRMByConcernKey.concernRoleID;
        concernRoleTypeDetails = readConcernRoleType(
          readParticipantConcernRoleKey);

        // Check the participant to handle the contact type.
        if (!(CONCERNROLETYPE.PERSON.equals(
          concernRoleTypeDetails.concernRoleType)
            || CONCERNROLETYPE.PROSPECTPERSON.equals(
              concernRoleTypeDetails.concernRoleType))) {
          participantContactTypeCode.companyContactTypeCode = participantContactTypeCode.contactTypeCode;

          participantContactTypeCode.contactTypeCode = CuramConst.gkEmpty;
        } else {
          participantContactTypeCode.companyContactTypeCode = CuramConst.gkEmpty;
        }
        // END, CR00280979
      }
    }

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.contactRMByConcernKey.concernRoleID;
    // Get the context description for the concern role
    listContactDetails.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return details
    return listContactDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Lists the contacts for a participant.
   *
   * @param key
   * The concern role ID for which a list of contacts is returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListConcernContactDetails listConcernContact(final ListContactKey key)
    throws AppException, InformationalException {

    final MaintainContacts maintainContactsObj = MaintainContactsFactory.newInstance();

    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    final ListConcernContactDetails listContactDetails = new ListConcernContactDetails();

    listContactDetails.concernContactRMultiDtlsList = maintainContactsObj.readmultiConcernContactByConcernRoleID(
      key.contactRMByConcernKey);

    if (!listContactDetails.concernContactRMultiDtlsList.dtls.isEmpty()) {
      for (ConcernContactRMultiDtls concernContactRMultiDtls :
        listContactDetails.concernContactRMultiDtlsList.dtls) {

        ConcernContactRMultiDtls participantContactTypeCode = concernContactRMultiDtls;

        concernRoleKey.concernRoleID = participantContactTypeCode.contactConRoleID;
        concernRoleDtls = concernRoleObj.read(concernRoleKey);
        participantContactTypeCode.contactConcernRoleType = concernRoleDtls.concernRoleType;

        ReadParticipantConcernRoleKey readParticipantConcernRoleKey = new ReadParticipantConcernRoleKey();
        ConcernRoleTypeDetails concernRoleTypeDetails = new ConcernRoleTypeDetails();

        readParticipantConcernRoleKey.readConcernRoleKey.concernRoleID = key.contactRMByConcernKey.concernRoleID;
        concernRoleTypeDetails = readConcernRoleType(
          readParticipantConcernRoleKey);

        // Check the participant to handle the contact type.
        // BEGIN, CR00304525, MV
        if (!(CONCERNROLETYPE.PERSON.equals(
          concernRoleTypeDetails.concernRoleType)
            || CONCERNROLETYPE.PROSPECTPERSON.equals(
              concernRoleTypeDetails.concernRoleType))
                || CONCERNROLETYPE.EXTERNALPARTY.equals(
                  concernRoleTypeDetails.concernRoleType)) {
          // END, CR00304525
          participantContactTypeCode.companyContactTypeCode = participantContactTypeCode.contactTypeCode;

          participantContactTypeCode.contactTypeCode = CuramConst.gkEmpty;
        } else {
          participantContactTypeCode.companyContactTypeCode = CuramConst.gkEmpty;
        }
      }
    }

    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.contactRMByConcernKey.concernRoleID;
    listContactDetails.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    return listContactDetails;
  }

  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * The contact details and key.
   *
   * @throws InformationalException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #modifyConcernContact()}.
   * The parameter struct of the current method modifyContact has
   * an aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to have new parameter ModifyConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  @Deprecated
  // END,CR00294967
  public void modifyContact(final ModifyContactDetails details)
    throws AppException, InformationalException {

    // Contact maintenance object.
    final curam.core.intf.MaintainContacts maintainContactsObj = curam.core.fact.MaintainContactsFactory.newInstance();

    // BEGIN, CR00096719,GM
    if (details.concernContactDtls.companyContactTypeCode != null
      && details.concernContactDtls.companyContactTypeCode.length() > 0) {
      details.concernContactDtls.contactTypeCode = details.concernContactDtls.companyContactTypeCode;

    }

    // END CR00096719

    // Modify the contact details.
    maintainContactsObj.modifyContact(details.contactReadKey,
      details.concernContactDtls);

  }

  // BEGIN, CR00294967, MV
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * The contact details and key.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyConcernContact(final ModifyConcernContactDetails details)
    throws AppException, InformationalException {

    final MaintainContacts maintainContactsObj = MaintainContactsFactory.newInstance();

    if (null != details.concernContactRMultiDtls.companyContactTypeCode
      && 0 < details.concernContactRMultiDtls.companyContactTypeCode.length()) {
      details.concernContactRMultiDtls.contactTypeCode = details.concernContactRMultiDtls.companyContactTypeCode;
    }
    maintainContactsObj.modifyConcernContact(details.contactReadKey,
      details.concernContactRMultiDtls);
  }

  /**
   * Reads a contact for a participant.
   *
   * @param key
   * The contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #readConcernContact()}. The
   * return struct of the current method readContact has an
   * aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct ReadConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  @Deprecated
  // END, CR00294967
  public curam.core.facade.struct.ReadContactDetails readContact(
    final ReadContactKey key) throws AppException, InformationalException {

    // The details returned.
    final curam.core.facade.struct.ReadContactDetails readContactDetails = new curam.core.facade.struct.ReadContactDetails();

    // Contact maintenance object and key.
    final curam.core.intf.MaintainContacts maintainContactsObj = curam.core.fact.MaintainContactsFactory.newInstance();

    // Concern Role object and key to get concern name.
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    // Read the contact details.
    readContactDetails.concernContactDtls = maintainContactsObj.readContact(
      key.contactReadKey);

    // Set the key and read the concern role details
    concernRoleKey.concernRoleID = readContactDetails.concernContactDtls.contactConRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    readContactDetails.concernContactDtls.contactConcernRoleType = concernRoleDtls.concernRoleType;

    // The contact ID the description is returned for.
    final ContactContextDescriptionKey contactContextDescriptionKey = new ContactContextDescriptionKey();

    // Set the key for description.
    contactContextDescriptionKey.contactID = key.contactReadKey.contactID;

    // Get the contact description.
    readContactDetails.contactContextDescriptionDetails = readParticipantContactContextDescription(
      contactContextDescriptionKey);

    // The contact details returned.
    return readContactDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * The contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadConcernContactDetails readConcernContact(
    final ReadContactKey key) throws AppException, InformationalException {

    final ReadConcernContactDetails readConcernContactDetails = new ReadConcernContactDetails();

    final MaintainContacts maintainContactsObj = MaintainContactsFactory.newInstance();
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    readConcernContactDetails.concernContactRMultiDtls = maintainContactsObj.readConcernContact(
      key.contactReadKey);
    // BEGIN, CR00304525, MV
    concernRoleKey.concernRoleID = readConcernContactDetails.concernContactRMultiDtls.concernRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    readConcernContactDetails.concernContactRMultiDtls.contactConcernRoleType = concernRoleDtls.concernRoleType;
    final ContactContextDescriptionKey contactContextDescriptionKey = new ContactContextDescriptionKey();

    if (!(CONCERNROLETYPE.PERSON.equals(concernRoleDtls.concernRoleType)
      || CONCERNROLETYPE.PROSPECTPERSON.equals(concernRoleDtls.concernRoleType))
        || CONCERNROLETYPE.EXTERNALPARTY.equals(concernRoleDtls.concernRoleType)) {

      readConcernContactDetails.concernContactRMultiDtls.companyContactTypeCode = readConcernContactDetails.concernContactRMultiDtls.contactTypeCode;

      readConcernContactDetails.concernContactRMultiDtls.contactTypeCode = CuramConst.gkEmpty;
    } else {
      readConcernContactDetails.concernContactRMultiDtls.companyContactTypeCode = CuramConst.gkEmpty;
    }
    // END, CR00304525

    contactContextDescriptionKey.contactID = key.contactReadKey.contactID;
    readConcernContactDetails.contactContextDescriptionDetails = readParticipantContactContextDescription(
      contactContextDescriptionKey);
    return readConcernContactDetails;
  }

  // END, CR00294967

  /**
   * Lists all addresses for a participant formatted for use in a pop-up list.
   *
   * @param readParticipantFormattedAddressListKey
   * Contains concernRoleID
   *
   * @return List of formatted addresses for participant
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public curam.core.facade.struct.FormattedAddressList listFormattedAddress(
    final ReadParticipantFormattedAddressListKey
    readParticipantFormattedAddressListKey)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // return structure
    final curam.core.facade.struct.FormattedAddressList formattedAddressList = new curam.core.facade.struct.FormattedAddressList();

    // read list from service layer into return struct
    formattedAddressList.formattedAddressList = caseNomineeObj.listFormattedAddress(
      readParticipantFormattedAddressListKey.readParticipantFormattedAddressListKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = readParticipantFormattedAddressListKey.readParticipantFormattedAddressListKey.maintainAddressKey.concernRoleID;
    // Get the context description for the concern role
    formattedAddressList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    return formattedAddressList;
  }

  /**
   * Reads formatted bankAccount data for a Participant.
   *
   * @param readParticipantFormattedBankAccountListKey
   * Contains concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public curam.core.facade.struct.FormattedBankAccountList listFormattedBankAccount(
    final ReadParticipantFormattedBankAccountListKey
    readParticipantFormattedBankAccountListKey)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // return structure
    final curam.core.facade.struct.FormattedBankAccountList formattedBankAccountList = new curam.core.facade.struct.FormattedBankAccountList();

    // read list from service layer into return struct
    formattedBankAccountList.formattedBankAccountList = caseNomineeObj.listFormattedBankAccount(
      readParticipantFormattedBankAccountListKey.readParticipantFormattedBankAccountListKey);

    // read context description
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = readParticipantFormattedBankAccountListKey.readParticipantFormattedBankAccountListKey.maintainBankAccountKey.concernRoleID;

    formattedBankAccountList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    return formattedBankAccountList;
  }

  /**
   * Creates a contact record for a participant who was not previously
   * registered.
   *
   * @param details
   * Registration details for the contact
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createContactFromUnregisteredParticipant(
    final curam.core.facade.struct.CreateContactFromUnregisteredParticipant
    details) throws AppException, InformationalException {

    // Contact maintenance object and key.
    final curam.core.intf.MaintainContacts maintainContactsObj = curam.core.fact.MaintainContactsFactory.newInstance();
    // BEGIN, CR00294967, MV
    final ConcernContactRMultiDtls concernContactDtls = new ConcernContactRMultiDtls();
    // END, CR00294967
    // Concern Role object and key to get concern name.
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // current date
    final curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // Representative maintenance object
    final curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

    // Struct passed to Representative::registerRepresentative
    final curam.core.sl.struct.RepresentativeRegistrationDetails representativeRegistrationDetails = new curam.core.sl.struct.RepresentativeRegistrationDetails();

    // Check to ensure the Contact Name has been entered
    if (details.createContactFromUnregisteredParticipant.name.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINCONTACTS.ERR_CONTACTS_FV_NAME_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check that phone number is at least three digits if not empty,
    if ((details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber.length()
      < kMinimumPhoneNumberLength)
        && (details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber.length()
          > 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINCONTACTPHONENUMBER.ERR_CONTACTPHONE_FV_SHORT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check for mandatory provision of phone number with extension
    if (details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension.length()
      > 0
        && details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber.length()
          == 0) {
      final AppException e = new AppException(
        curam.message.BPOMAINTAINCONTACTPHONENUMBER.ERR_CONTACT_XFV_EXTENSION_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Check for mandatory provision of phone number with country code
    if (details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode.length()
      > 0
        && details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber.length()
          == 0) {
      final AppException e = new AppException(
        curam.message.BPOMAINTAINCONTACTPHONENUMBER.ERR_CONTACT_XFV_COUNTRYCODE_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Check for mandatory provision of phone number with area code
    if (details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode.length()
      > 0
        && details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber.length()
          == 0) {
      final AppException e = new AppException(
        curam.message.BPOMAINTAINCONTACTPHONENUMBER.ERR_CONTACT_XFV_AREACODE_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Read Concern Role record for the Concern for which
    // the contact is being created
    concernRoleKey.concernRoleID = details.createContactFromUnregisteredParticipant.concernRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    representativeRegistrationDetails.representativeDtls.representativeName = details.createContactFromUnregisteredParticipant.name;

    representativeRegistrationDetails.representativeRegistrationDetails.addressData = details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.addressData;
    representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode = details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneCountryCode;
    representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode = details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneAreaCode;
    representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber = details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneNumber;
    representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension = details.representativeRegistrationDetails.representativeRegistrationDetails.representativeRegistrationDetails.phoneExtension;
    representativeRegistrationDetails.representativeRegistrationDetails.registrationDate = currentDate;
    representativeRegistrationDetails.representativeRegistrationDetails.sensitivity = concernRoleDtls.sensitivity;

    representativeRegistrationDetails.representativeDtls.representativeType = curam.codetable.REPRESENTATIVETYPE.CONTACT;

    // Call registerRepresentative
    representativeObj.registerRepresentative(representativeRegistrationDetails);

    // Set the key and read the concern role details for the contact
    concernRoleKey.concernRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    concernContactDtls.concernRoleID = details.createContactFromUnregisteredParticipant.concernRoleID;
    concernContactDtls.contactConRoleID = representativeRegistrationDetails.representativeDtls.concernRoleID;
    concernContactDtls.name = concernRoleDtls.concernRoleName;
    concernContactDtls.contactTypeCode = details.createContactFromUnregisteredParticipant.contactTypeCode;
    // BEGIN, CR00280979, PB
    concernContactDtls.companyContactTypeCode = details.createContactFromUnregisteredParticipant.companyContactTypeCode;
    // END, CR00280979
    // BEGIN, CR00096719, GM
    if (details.createContactFromUnregisteredParticipant.companyContactTypeCode
      != null
        && details.createContactFromUnregisteredParticipant.companyContactTypeCode.length()
          > 0) {
      concernContactDtls.contactTypeCode = details.createContactFromUnregisteredParticipant.companyContactTypeCode;
    }
    // END, CR00096719
    concernContactDtls.startDate = details.createContactFromUnregisteredParticipant.startDate;
    concernContactDtls.endDate = details.createContactFromUnregisteredParticipant.endDate;

    // BEGIN, CR00021339, CMB
    // BEGIN, HARP 64088, PAD
    concernContactDtls.comments = details.createContactFromUnregisteredParticipant.comments;
    // END, HARP 64088
    // END, CR00021339

    // BEGIN, CR00294967, MV
    // Create the Contact.
    maintainContactsObj.createConcernContact(concernContactDtls);
    // END, CR00294967
  }

  // BEGIN, CR00182977, MC
  // __________________________________________________________________________
  /**
   * @param key
   * Key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listParticipantFinancial1()}.
   *
   * Returns a list of financials for a participant.
   */
  @Deprecated
  public ListParticipantFinancials listParticipantFinancial(
    final ListParticipantFinancialsKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListParticipantFinancials listParticipantFinancials = new ListParticipantFinancials();

    final ListParticipantFinancials1 listParticipantFinancials1 = listParticipantFinancial1(
      key);

    listParticipantFinancials.concernRoleName = listParticipantFinancials1.concernRoleName;
    listParticipantFinancials.contextDescription = listParticipantFinancials1.contextDescription;
    listParticipantFinancials.ind = listParticipantFinancials1.ind;
    listParticipantFinancials.renderXML = listParticipantFinancials1.renderXML;

    ParticipantFinancials participantFinancials;

    for (int i = 0; i
      < listParticipantFinancials1.participantFinancialsList.dtls.size(); i++) {

      participantFinancials = new ParticipantFinancials();
      participantFinancials.assign(
        listParticipantFinancials1.participantFinancialsList.dtls.item(i));

      listParticipantFinancials.participantFinancialsList.dtls.addRef(
        participantFinancials);
    }

    return listParticipantFinancials;
  }

  // __________________________________________________________________________
  /**
   * Returns a list of financials for a participant.
   *
   * @param key
   * Key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListParticipantFinancials1 listParticipantFinancial1(
    final ListParticipantFinancialsKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return object
    final ListParticipantFinancials1 listParticipantFinancials = new ListParticipantFinancials1();

    // Get the concern role ID from the key
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;

    // Read the concern role name
    ConcernRoleNameDetails concernRoleNameDetails = ConcernRoleFactory.newInstance().readConcernRoleName(
      concernRoleKey);

    listParticipantFinancials.concernRoleName = concernRoleNameDetails.concernRoleName;

    ParticipantFinancials participantFinancials;
    ParticipantFinancials1 participantFinancials1;

    // Assign key details to search for the concern's financials
    final FinancialAccountIdentifier financialAccountIdentifier = new FinancialAccountIdentifier();

    financialAccountIdentifier.assign(key);

    // Call ViewConcernAccount to return the concern's financial records
    ViewConcAccountSummaryResult viewConcernRoleAccountSummary = ViewConcernAccountFactory.newInstance().viewConcernRoleAccountSummary(
      financialAccountIdentifier);

    // Iterate through the list if it's populated
    if (!viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.isEmpty()) {

      final InstructionLineItem iliObj = InstructionLineItemFactory.newInstance();

      // Reserve space in the output object
      listParticipantFinancials.participantFinancialsList.dtls.ensureCapacity(
        viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.size());

      for (int i = 0; i
        < viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.size(); i++) {

        participantFinancials = new ParticipantFinancials();
        participantFinancials1 = new ParticipantFinancials1();

        participantFinancials.assign(
          viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.item(i));
        participantFinancials1.assign(participantFinancials);

        // BEGIN, CR00250758, KH
        final ILIFinInstructID fiIDKey = new ILIFinInstructID();

        fiIDKey.finInstructionID = participantFinancials1.finInstructionID;
        InstructionLineItemDtlsList iliDtlsList = iliObj.searchByFinInstructID(
          fiIDKey);

        /*
         * We can take the delivery method from the first ILI, all ILIs must
         * have the same delivery method or they could not be rolled together.
         */
        participantFinancials1.deliveryMethodType = iliDtlsList.dtls.item(0).deliveryMethodType;
        
        /*
         * Record the ILI type for use later in case this is a manual payment.
         * Manual payment ILIs will all have the same type so use the first.
         */
        participantFinancials1.instructionLineItemType = iliDtlsList.dtls.item(0).instructionLineItemType;
        // END, CR00250758

        // BEGIN, CR00317416, CSH
        // Record the credit/debit type for later use in display details
        participantFinancials1.creditDebitType = iliDtlsList.dtls.item(0).creditDebitType;
        // END, CR00317416

        // BEGIN, CR00411908, CW
        // Populate the nominee display name with the nominee that is on the payment
        if (iliDtlsList.dtls.item(0).caseNomineeID != 0) {

          curam.core.sl.entity.struct.CaseNomineeDetails caseNomineeDetails;
          final curam.core.sl.entity.intf.CaseNominee caseNomineeEntObj = curam.core.sl.entity.fact.CaseNomineeFactory.newInstance();
          final curam.core.sl.entity.struct.CaseNomineeViewKey caseNomineeViewKey = new curam.core.sl.entity.struct.CaseNomineeViewKey();

          caseNomineeViewKey.caseNomineeID = iliDtlsList.dtls.item(0).caseNomineeID;

          try {
            caseNomineeDetails = caseNomineeEntObj.readCaseNomineeDetails(
              caseNomineeViewKey);
            participantFinancials1.caseNomineeName = caseNomineeDetails.concernRoleName;
          } catch (Exception e) {

            // Default to the current participant
            participantFinancials1.caseNomineeName = concernRoleNameDetails.concernRoleName;
          }
        } else {

          // Default to the current participant
          participantFinancials1.caseNomineeName = concernRoleNameDetails.concernRoleName;
        }
        // END, CR00411908

        // Set up the issued date field
        final FinInstructionID finInstructionID = new FinInstructionID();

        finInstructionID.finInstructionID = participantFinancials1.finInstructionID;
        participantFinancials1.dueDate = FinancialInstructionFactory.newInstance().readPaymentDateDetailsByInstructionID(finInstructionID).paymentDate;

        /*
         * Amounts are always stored on the database in the base currency and
         * always read back as such. The base currency is returned here for
         * display purposes. The amounts in the money field(s) on each row
         * will be shown in the following format: "USD 1000".
         */
        participantFinancials.currencyType = viewConcernRoleAccountSummary.concernRoleAccSummHeader.currencyType;
        participantFinancials1.currencyType = viewConcernRoleAccountSummary.concernRoleAccSummHeader.currencyType;

        // Add details to the list
        listParticipantFinancials.participantFinancialsList.dtls.addRef(
          participantFinancials1);
      }
    }

    // Get the context description for the concern role
    final ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    listParticipantFinancials.contextDescription = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // BEGIN, CR00221607, MC
    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();
      // BEGIN, CR00102338

      // BEGIN, CR00102618, CSH
      // Set menu data for displaying any duplicate client payment instruments
      // set the pages to link to for the original and duplicate client
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listFinancialForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listFinancial;

      // Set concernRole to current concernRole
      final ConcernRoleKey currentKey = new ConcernRoleKey();

      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Display the duplicate client role soft links in a tab format
      // Build up the xml data needed for the tab widget
      listParticipantFinancials.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      listParticipantFinancials.ind = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);
      // END, CR00120078
    }
    // END, CR00221607

    final FinancialListHelper financialListHelper = new FinancialListHelper();

    // Remove the reversals from the list
    int listSize = listParticipantFinancials.participantFinancialsList.dtls.size()
      - 1;

    for (int i = listSize; i >= 0; i--) {
      participantFinancials1 = listParticipantFinancials.participantFinancialsList.dtls.item(
        i);

      FinancialInstructionDetails financialInstructionDetails = new FinancialInstructionDetails();

      financialInstructionDetails.assign(participantFinancials1);

      // BEGIN, CR00317416, CSH
      financialInstructionDetails = financialListHelper.setListRowActionDisplayIndicators(
        financialInstructionDetails);

      financialInstructionDetails = financialListHelper.setTypeStatus(
        financialInstructionDetails);

      participantFinancials1.assign(financialInstructionDetails);
      // END, CR00317416
    }

    return listParticipantFinancials;
  }

  // END, CR00182977
  // __________________________________________________________________________
  /**
   * Creates an email communication.
   *
   * @param details
   * Details to create the email communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link Communication#createEmail(
   * curam.core.facade.struct.CreateEmailCommDetails)}.
   */
  @Deprecated
  public void createEmailCommunication(
    final CreateEmailCommunicationDetails details)
    throws AppException, InformationalException {

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    final curam.core.struct.CommunicationDetails communicationDetails = new curam.core.struct.CommunicationDetails();
    final MaintainCommunicationKey maintainCommunicationKey = new MaintainCommunicationKey();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // Ensure that two IDs for the correspondent are not passed.
    if ((details.participantRoleID != 0) && (details.participantID != 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINCONCERNROLECOMMASSISTANT.ERR_COMM_INCORRECT_CORRESPONDENT_SUPPLIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Need to set here when creating comm for concernRoleID
    communicationDetails.assign(details);
    maintainCommunicationKey.concernRoleID = details.concernRoleID;

    ConcernRoleNameDetails concernRoleNameDetails;

    // Read the concernRoleDetails and set the correspondent name to the
    // concern role name.
    if (details.concernRoleID != 0) {

      concernRoleKey.concernRoleID = details.concernRoleID;
      concernRoleNameDetails = concernRoleObj.readConcernRoleName(
        concernRoleKey);

      communicationDetails.correspondentName = concernRoleNameDetails.concernRoleName;
    }

    // Set the concernRoleID for the correspondent.
    if ((details.participantID != 0) && (details.caseID != 0)) {
      details.concernRoleID = details.participantID;
    }

    if ((details.participantID == 0) && (details.caseID != 0)) {
      details.concernRoleID = details.participantRoleID;
    }

    if (details.caseID != 0) {
      // Assign details to create the email communication
      communicationDetails.assign(details);
    }

    if (details.concernRoleID != 0) {

      // Need to read the concern's name and email address
      final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
      final ReadConcernRoleKey readConcernRoleKey = new ReadConcernRoleKey();
      curam.core.struct.ReadContactDetails readContactDetails;

      // Set key to read concernRole contact details
      readConcernRoleKey.concernRoleID = details.concernRoleID;

      // Read concernRole contact details
      readContactDetails = maintainConcernRoleDetailsObj.readAllContactDetails(
        readConcernRoleKey);

      // Map concernRoleName and emailAddress to communication details
      // object
      communicationDetails.correspondentName = readContactDetails.concernRoleName;
      communicationDetails.emailAddress = readContactDetails.emailAddress;
    }

    communicationDetails.existingCommunicationInd = false;
    communicationDetails.proFormaInd = false;
    communicationDetails.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // Set correspondent method type to Hard Copy
    communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.EMAIL;

    // Set key to create email communication
    maintainCommunicationKey.caseID = details.caseID;

    if (details.caseID != 0) {
      maintainCommunicationKey.concernRoleID = details.concernRoleID;
    }

    // Call MaintainConcernRoleComm BPO to create the communication
    maintainConcernRoleCommObj.createCommunication(maintainCommunicationKey,
      communicationDetails);
  }

  /**
   * Creates a template communication.
   *
   * @param details
   * Details to create the template communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.
   */
  @Deprecated
  public void createTemplateCommunication(
    final CreateTemplateCommunication details) throws AppException,
      InformationalException {

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    final curam.core.struct.CommunicationDetails communicationDetails = new curam.core.struct.CommunicationDetails();
    final MaintainCommunicationKey maintainCommunicationKey = new MaintainCommunicationKey();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // Need to set here when creating comm for concernRoleID
    communicationDetails.assign(details);
    maintainCommunicationKey.concernRoleID = details.concernRoleID;

    // Read the concernRoleDetails and set the correspondent name to the
    // concern role name.
    if (details.concernRoleID != 0) {
      concernRoleKey.concernRoleID = details.concernRoleID;
      final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(
        concernRoleKey);

      communicationDetails.correspondentName = concernRoleDtls.concernRoleName;
    }

    // Ensure that two IDs the correspondent are not passed in.
    if ((details.participantRoleID != 0) && (details.participantID != 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINCONCERNROLECOMMASSISTANT.ERR_COMM_INCORRECT_CORRESPONDENT_SUPPLIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Set the concernRoleID for the correspondent.
    if (details.participantID != 0) {
      details.concernRoleID = details.participantID;
    } else {
      details.concernRoleID = details.participantRoleID;
    }

    if (details.caseID != 0) {
      // Assign details to create the email communication
      communicationDetails.assign(details);
    }

    if (details.concernRoleID != 0) {

      // Need to read the concern's address, phone and email information
      final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
      final ReadConcernRoleKey readConcernRoleKey = new ReadConcernRoleKey();
      curam.core.struct.ReadContactDetails readContactDetails;

      // Set key to read concernRole contact details
      readConcernRoleKey.concernRoleID = details.concernRoleID;

      // Read concernRole contact details
      readContactDetails = maintainConcernRoleDetailsObj.readAllContactDetails(
        readConcernRoleKey);

      // Map concernRole details to communication details
      communicationDetails.correspondentName = readContactDetails.concernRoleName;
      communicationDetails.assign(readContactDetails);
    }

    // Set saveAsDraftInd based on printInd value
    if (details.printInd == true) {

      communicationDetails.saveAsDraftInd = false;

    } else {

      communicationDetails.saveAsDraftInd = true;
    }

    // communicationDetails.saveAsDraftInd = true;
    communicationDetails.existingCommunicationInd = false;
    communicationDetails.proFormaInd = true;
    communicationDetails.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // Set correspondent method type to Hard Copy
    communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;

    // Set key to create template communication
    maintainCommunicationKey.caseID = details.caseID;

    if (details.caseID != 0) {
      maintainCommunicationKey.concernRoleID = details.concernRoleID;
    }
    // BEGIN, CR00169646, AK
    // Add locale identifier
    communicationDetails.localeIdentifier = TransactionInfo.getProgramLocale();
    // END, CR00169646

    // Call MaintainConcernRoleComm BPO to create the communication
    maintainConcernRoleCommObj.createCommunication(maintainCommunicationKey,
      communicationDetails);

  }

  /**
   * Records an existing communication.
   *
   * @param details
   * Details of the existing communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.
   */
  @Deprecated
  public void recordExistingCommunication(
    final RecordExistingCommunicationDetails details) throws AppException,
      InformationalException {

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    final curam.core.struct.CommunicationDetails communicationDetails = new curam.core.struct.CommunicationDetails();
    final MaintainCommunicationKey maintainCommunicationKey = new MaintainCommunicationKey();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // Ensure that two IDs the correspondent are not passed in.
    if ((details.participantRoleID != 0) && (details.participantID != 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOMAINTAINCONCERNROLECOMMASSISTANT.ERR_COMM_INCORRECT_CORRESPONDENT_SUPPLIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    // If user selects communication method of phone.then the blank
    // option in communication type must also be selected, as no communication
    // type exist for method 'phone'.
    if (details.methodTypeCode.equals(COMMUNICATIONMETHOD.PHONE)) {
      if (details.typeCode.length() != 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOMAINTAINCONCERNROLECOMMASSISTANT.ERR_COMM_METHOD_PHONE_NEED_TYPECODE_BLANK),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    } // If HardCopy/DataTransfer/Email or Fax is selected then ensure the
    // user selects a communication type (and not the blank option).
    else {
      if (details.typeCode.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOMAINTAINCONCERNROLECOMMASSISTANT.ERR_COMM_TYPE_CODE_BLANK),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    }

    // Need to set here when creating comm for concernRoleID
    communicationDetails.assign(details);
    maintainCommunicationKey.concernRoleID = details.concernRoleID;

    // Read the concernRoleDetails and set the correspondent name to the
    // concern role name.
    if (details.concernRoleID != 0) {
      concernRoleKey.concernRoleID = details.concernRoleID;
      final ConcernRoleDtls concernRoleDtls = concernRoleObj.read(
        concernRoleKey);

      communicationDetails.correspondentName = concernRoleDtls.concernRoleName;
    }

    // Set the concernRoleID for the correspondent if it is not already set.
    if (details.concernRoleID == 0) {

      if (details.participantID != 0) {
        details.concernRoleID = details.participantID;
      } else {
        details.concernRoleID = details.participantRoleID;
      }
    }

    if (details.caseID != 0) {
      // Assign details to create the email communication
      communicationDetails.assign(details);
    }

    // Set type to Client is specified by the user
    if (details.concernRoleID != 0) {

      // Need to read the concern's address, phone and email information
      final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
      final ReadConcernRoleKey readConcernRoleKey = new ReadConcernRoleKey();
      curam.core.struct.ReadContactDetails readContactDetails;

      // Set key to read concernRole contact details
      readConcernRoleKey.concernRoleID = details.concernRoleID;

      // Read concernRole contact details
      readContactDetails = maintainConcernRoleDetailsObj.readAllContactDetails(
        readConcernRoleKey);

      // Map concernRole details to communication details
      communicationDetails.correspondentName = readContactDetails.concernRoleName;
      communicationDetails.assign(readContactDetails);
    }

    // Set incomingInd flag based on communication direction code
    if (details.communicationDirection.equals(
      curam.codetable.COMMUNICATIONDIRECTION.INCOMING)) {
      // END, HARP, 35558
      communicationDetails.incomingInd = true;

    } else {

      communicationDetails.incomingInd = false;
    }

    communicationDetails.existingCommunicationInd = true;
    communicationDetails.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // Set communication key for recording
    maintainCommunicationKey.caseID = details.caseID;

    if (details.caseID != 0) {
      maintainCommunicationKey.concernRoleID = details.concernRoleID;
    }

    // Call MaintainConcernRoleComm BPO to create the communication
    maintainConcernRoleCommObj.createCommunication(maintainCommunicationKey,
      communicationDetails);

  }

  /**
   * Returns a list of templates based on template type and the participant
   * identifier.
   *
   * @param key
   * Key to read the list of templates.
   *
   * @return List of templates for participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListTemplateByTypeAndParticpant listTemplateByTypeAndParticipant(
    final ListTemplateByTypeAndParticipantKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListTemplateByTypeAndParticpant listTemplateByTypeAndParticpant = new ListTemplateByTypeAndParticpant();

    // MaintainXSLTemplate manipulation variables
    final curam.core.intf.MaintainXSLTemplate maintainXSLTemplateObj = curam.core.fact.MaintainXSLTemplateFactory.newInstance();
    final SearchTemplatesKey searchTemplatesKey = new SearchTemplatesKey();
    SearchTemplatesByConcernAndTypeResult searchTemplatesByConcernAndTypeResult;

    if ((key.concernRoleID == 0) && (key.caseID != 0)) {

      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
      CaseHeaderDtls caseHeaderDtls;

      // Set key to read caseHeader to retrieve the concernRoleID
      caseHeaderKey.caseID = key.caseID;

      // Read caseHeader
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      // Map concernRoleID to the comm creation object
      key.concernRoleID = caseHeaderDtls.concernRoleID;
    }

    // Set key details to retrieve the list of templates
    searchTemplatesKey.concernRoleID = key.concernRoleID;
    searchTemplatesKey.templateType = key.templateType;
    searchTemplatesKey.caseID = key.caseID;

    // Call MaintainXSLTemplate BPO to retrieve the list of templates
    searchTemplatesByConcernAndTypeResult = maintainXSLTemplateObj.searchTemplatesByConcernAndType(
      searchTemplatesKey);

    // Check to see if any templates were returned
    if (!searchTemplatesByConcernAndTypeResult.xslTemplateDetailsListOut.dtls.isEmpty()) {

      // Reserve space in the return object
      listTemplateByTypeAndParticpant.dtls.ensureCapacity(
        searchTemplatesByConcernAndTypeResult.xslTemplateDetailsListOut.dtls.size());

      TemplatesByTypeAndParticipantDetails templatesByTypeAndParticipantDetails;

      for (int i = 0; i
        < searchTemplatesByConcernAndTypeResult.xslTemplateDetailsListOut.dtls.size(); i++) {

        templatesByTypeAndParticipantDetails = new TemplatesByTypeAndParticipantDetails();

        // Assign template details
        templatesByTypeAndParticipantDetails.templateID = searchTemplatesByConcernAndTypeResult.xslTemplateDetailsListOut.dtls.item(i).templateID;
        templatesByTypeAndParticipantDetails.templateName = searchTemplatesByConcernAndTypeResult.xslTemplateDetailsListOut.dtls.item(i).templateName;
        templatesByTypeAndParticipantDetails.templateType = key.templateType;

        // Assign details to return object
        listTemplateByTypeAndParticpant.dtls.addRef(
          templatesByTypeAndParticipantDetails);
      }

    }

    return listTemplateByTypeAndParticpant;
  }

  /**
   * Modifies the details of a communication.
   *
   * @param details
   * Details to modify the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.
   */
  @Deprecated
  public void modifyCommunication(final ModifyCommDetails details)
    throws AppException, InformationalException {

    // ConcernRoleCommuncation manipulation variables
    final curam.core.intf.ConcernRoleCommunication concernRoleCommunicationObj = curam.core.fact.ConcernRoleCommunicationFactory.newInstance();
    final ConcernRoleCommunicationKey concernRoleCommunicationKey = new ConcernRoleCommunicationKey();
    ConcernRoleCommunicationDtls concernRoleCommunicationDtls;

    // set the key to read the communication details
    final ReadConcernRoleCommKey readConcernRoleCommKey = new ReadConcernRoleCommKey();

    readConcernRoleCommKey.communicationID = details.communicationID;

    // Set key to read concernRoleCommunication
    concernRoleCommunicationKey.communicationID = details.communicationID;

    // Read communication details
    concernRoleCommunicationDtls = concernRoleCommunicationObj.read(
      concernRoleCommunicationKey);

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    curam.core.struct.CommunicationDetails communicationDetails = new curam.core.struct.CommunicationDetails();

    // read the communication details
    communicationDetails = maintainConcernRoleCommObj.readCommunication(
      readConcernRoleCommKey);

    final String addressData = communicationDetails.addressData;

    // Assign details to modify the communication
    communicationDetails.assign(details);
    communicationDetails.addressData = addressData;
    communicationDetails.proFormaID = concernRoleCommunicationDtls.proFormaID;
    communicationDetails.typeCode = concernRoleCommunicationDtls.typeCode;
    communicationDetails.correspondentName = concernRoleCommunicationDtls.correspondentName;
    communicationDetails.subjectText = concernRoleCommunicationDtls.subjectText;
    communicationDetails.versionNo = concernRoleCommunicationDtls.versionNo;
    communicationDetails.statusCode = concernRoleCommunicationDtls.statusCode;
    communicationDetails.ticketID = concernRoleCommunicationDtls.ticketID;
    communicationDetails.userName = concernRoleCommunicationDtls.userName;
    communicationDetails.caseID = concernRoleCommunicationDtls.caseID;
    communicationDetails.proFormaVersionNo = concernRoleCommunicationDtls.proFormaVersionNo;
    communicationDetails.saveAsDraftInd = true;

    // Call MaintainConcernRoleComm BPO to modify the communication
    maintainConcernRoleCommObj.modifyCommunication(communicationDetails);

  }

  /**
   * Modifies the details of a sent communication.
   *
   * @param details
   * Details of the sent communication to be modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifySentCommunication(
    final ModifySentCommunicationDetails details)
    throws AppException, InformationalException {

    // ConcernRoleCommuncation manipulation variables
    final curam.core.intf.ConcernRoleCommunication concernRoleCommunicationObj = curam.core.fact.ConcernRoleCommunicationFactory.newInstance();
    final ConcernRoleCommunicationKey concernRoleCommunicationKey = new ConcernRoleCommunicationKey();
    ConcernRoleCommunicationDtls concernRoleCommunicationDtls;

    // Set key to read concernRoleCommunication
    concernRoleCommunicationKey.communicationID = details.communicationID;

    // Read communication details
    concernRoleCommunicationDtls = concernRoleCommunicationObj.read(
      concernRoleCommunicationKey);

    // Assign modified details for the sent communication
    concernRoleCommunicationDtls.comments = details.comments;
    concernRoleCommunicationDtls.documentLocation = details.documentLocation;
    concernRoleCommunicationDtls.documentRefNumber = details.documentRefNumber;
    concernRoleCommunicationDtls.fileLocation = details.fileLocation;
    concernRoleCommunicationDtls.fileReferenceNumber = details.fileReferenceNumber;
    concernRoleCommunicationDtls.versionNo = concernRoleCommunicationDtls.versionNo;

    // Call the modify operation on the entity
    concernRoleCommunicationObj.modify(concernRoleCommunicationKey,
      concernRoleCommunicationDtls);
  }

  /**
   * Reads details of a communication.
   *
   * @param key
   * Contains the communication identifier.
   *
   * @return Details of the communication.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0.
   */
  @Deprecated
  public ReadCommDetails readCommunication(final ReadCommKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadCommDetails readCommDetails = new ReadCommDetails();

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    final ReadConcernRoleCommKey readConcernRoleCommKey = new ReadConcernRoleCommKey();

    // Set key to read the case communication details
    readConcernRoleCommKey.communicationID = key.communicationID;

    // Call MaintainConcernRoleComm BPO to read the communication details
    // and assign to return object
    readCommDetails.assign(
      maintainConcernRoleCommObj.readCommunication(readConcernRoleCommKey));

    return readCommDetails;
  }

  /**
   * Prints a communication.
   *
   * @param details
   * Details to print the communication.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void printCommunication(final PrintCommunicationKey details)
    throws AppException, InformationalException {

    // ConcernRoleDocuments manipulation variables
    final curam.core.intf.ConcernRoleDocuments concernRoleDocumentsObj = curam.core.fact.ConcernRoleDocumentsFactory.newInstance();
    final ConcernRoleDocumentKey concernRoleDocumentKey = new ConcernRoleDocumentKey();
    final ConcernRoleDocumentDetails concernRoleDocumentDetails = new ConcernRoleDocumentDetails();

    // ConcernRoleCommunication manipulation variables
    final curam.core.intf.ConcernRoleCommunication concernRoleCommunicationObj = curam.core.fact.ConcernRoleCommunicationFactory.newInstance();
    final ConcernRoleCommunicationKey concernRoleCommunicationKey = new ConcernRoleCommunicationKey();
    ConcernRoleCommunicationDtls concernRoleCommunicationDtls;

    // Set key to read ConcernRoleCommunication
    concernRoleCommunicationKey.communicationID = details.communicationID;

    // Read ConcernRoleCommunication
    concernRoleCommunicationDtls = concernRoleCommunicationObj.read(
      concernRoleCommunicationKey);

    // Assign key to print document
    concernRoleDocumentKey.caseID = concernRoleCommunicationDtls.caseID;
    concernRoleDocumentKey.concernRoleID = concernRoleCommunicationDtls.concernRoleID;
    concernRoleDocumentKey.documentID = concernRoleCommunicationDtls.proFormaID;

    // Assign details to print document
    concernRoleDocumentDetails.comments = concernRoleCommunicationDtls.comments;
    concernRoleDocumentDetails.documentID = concernRoleCommunicationDtls.proFormaID;
    concernRoleDocumentDetails.subject = concernRoleCommunicationDtls.subjectText;
    concernRoleDocumentDetails.versionNo = concernRoleCommunicationDtls.proFormaVersionNo;
    // END, 26164

    // Call ConcernRoleDocuments BPO to print the document
    concernRoleDocumentsObj.printDocument(concernRoleDocumentKey,
      concernRoleDocumentDetails);
  }

  /**
   * Sends an email communication.
   *
   * @param details
   * Details to send the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.
   */
  @Deprecated
  public void sendEmailCommunication(final SendEmailCommKey details)
    throws AppException, InformationalException {

    // MaintainConcernRoleCommAssistant manipulation variables
    final curam.core.intf.MaintainConcernRoleCommAssistant maintainConcernRoleCommAssistantObj = curam.core.fact.MaintainConcernRoleCommAssistantFactory.newInstance();
    final curam.core.struct.CommunicationDetails communicationDetails = new curam.core.struct.CommunicationDetails();

    // ConcernRoleCommunication manipulation variables
    final curam.core.intf.ConcernRoleCommunication concernRoleCommunicationObj = curam.core.fact.ConcernRoleCommunicationFactory.newInstance();
    final ConcernRoleCommunicationKey concernRoleCommunicationKey = new ConcernRoleCommunicationKey();
    ConcernRoleCommunicationDtls concernRoleCommunicationDtls;
    final CommunicationContactKey communicationContactKey = new CommunicationContactKey();

    // Set key to read ConcernRoleCommunication
    concernRoleCommunicationKey.communicationID = details.communicationID;

    // Read ConcernRoleCommunication
    concernRoleCommunicationDtls = concernRoleCommunicationObj.read(
      concernRoleCommunicationKey);

    // Assign details to send an email
    communicationDetails.subjectText = concernRoleCommunicationDtls.subjectText;
    communicationDetails.communicationText = concernRoleCommunicationDtls.communicationText;

    // if email record for concern role exists, read its details
    if (concernRoleCommunicationDtls.emailAddressID != 0) {

      // EmailAddress manipulation variables
      final curam.core.intf.EmailAddress emailAddressObj = curam.core.fact.EmailAddressFactory.newInstance();
      final EmailAddressKey emailAddressKey = new EmailAddressKey();
      EmailAddressDtls emailAddressDtls;

      // Set key to read emailAddress
      emailAddressKey.emailAddressID = concernRoleCommunicationDtls.emailAddressID;

      // Read emailAddress
      emailAddressDtls = emailAddressObj.read(emailAddressKey);

      // Map emailAddress
      communicationDetails.emailAddress = emailAddressDtls.emailAddress;

      // Call MaintainConcernRoleCommAssistant operation to send the
      // mail
      maintainConcernRoleCommAssistantObj.sendEmail(communicationDetails);

      // Setting up data to modify the communication details
      communicationDetails.assign(concernRoleCommunicationDtls);
      communicationDetails.saveAsDraftInd = false;
      communicationDetails.proFormaInd = false;

      // modify other contact details of communications
      maintainConcernRoleCommAssistantObj.modifyCommDetails(
        communicationDetails, communicationContactKey);
    }

  }

  /**
   * Cancels a communication on a case.
   *
   * @param key
   * Key to cancel the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.
   */
  @Deprecated
  public void cancelCommunication(final CancelCommunicationKey key)
    throws AppException, InformationalException {

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    final CancelConcernRoleCommKey cancelConcernRoleCommKey = new CancelConcernRoleCommKey();

    // Assign key details to cancel the communication
    cancelConcernRoleCommKey.assign(key);

    // Call MaintainConcernRoleComm BPO to cancel the communication
    maintainConcernRoleCommObj.cancelCommunication(cancelConcernRoleCommKey);
  }

  /**
   * Creates a freeform communication.
   *
   * @param details
   * Details to create the freeform communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0.
   */
  @Deprecated
  public void createFreeformCommunincation(
    final CreateFreeformCommunication details)
    throws AppException, InformationalException {

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    final curam.core.struct.CommunicationDetails communicationDetails = new curam.core.struct.CommunicationDetails();
    final MaintainCommunicationKey maintainCommunicationKey = new MaintainCommunicationKey();

    if ((details.concernRoleID == 0) && (details.caseID != 0)) {

      // CaseHeader manipulation variables
      final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
      CaseHeaderDtls caseHeaderDtls;

      // Set key to read caseHeader to retrieve the concernRoleID
      caseHeaderKey.caseID = details.caseID;

      // Read caseHeader
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      // Map concernRoleID to the comm creation object
      details.concernRoleID = caseHeaderDtls.concernRoleID;
    }

    // Assign details to create the email communication
    communicationDetails.assign(details);

    if (details.clientIsCorrespondentInd == true) {

      communicationDetails.correspondentTypeCode = CORRESPONDENT.CLIENT;

      // Need to read the concern's address, phone and email information
      final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
      final ReadConcernRoleKey readConcernRoleKey = new ReadConcernRoleKey();
      curam.core.struct.ReadContactDetails readContactDetails;

      // Set key to read concernRole contact details
      readConcernRoleKey.concernRoleID = details.concernRoleID;

      // Read concernRole contact details
      readContactDetails = maintainConcernRoleDetailsObj.readAllContactDetails(
        readConcernRoleKey);

      // Map concernRole details to communication details
      communicationDetails.correspondentName = readContactDetails.concernRoleName;
      communicationDetails.assign(readContactDetails);
    }

    communicationDetails.saveAsDraftInd = true;
    communicationDetails.existingCommunicationInd = false;
    communicationDetails.proFormaInd = false;
    communicationDetails.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    communicationDetails.communicationDate = curam.util.type.Date.kZeroDate;

    // Set correspondent method type to Hard Copy
    communicationDetails.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;

    // Set key to create template communication
    maintainCommunicationKey.caseID = details.caseID;
    maintainCommunicationKey.concernRoleID = details.concernRoleID;

    // Call MaintainConcernRoleComm BPO to create the communication
    maintainConcernRoleCommObj.createCommunication(maintainCommunicationKey,
      communicationDetails);
  }

  /**
   * Reads details of a communication attachment.
   *
   * @param key
   * Key to read the communication attachment details.
   *
   * @return ReadCommunicationAttachmentDetails Details of the communication
   * attachment.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadCommunicationAttachmentDetails readCommunicationAttachment(
    final ReadAttachmentKey key) throws AppException, InformationalException {

    // Details to be returned
    final ReadCommunicationAttachmentDetails readCommunicationAttachmentDetails = new ReadCommunicationAttachmentDetails();

    // MaintainAttachment manipulation variable
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory.newInstance();

    // Call MaintainAttachment BPO to read the attachment details
    readCommunicationAttachmentDetails.readCommunicationAttachmentDtls = maintainAttachmentObj.readCommunicationAttachment(
      key.readAttachmentIn);

    return readCommunicationAttachmentDetails;
  }

  /**
   * Returns a list of tasks for a participant.
   *
   * @param key
   * Key to return a list of tasks for a participant.
   *
   * @return List of tasks for a participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public TasksForConcernAndCaseDetails listParticipantTask(
    final ListParticipantTaskKey_eo key) throws AppException,
      InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return object
    final TasksForConcernAndCaseDetails tasksForConcernAndCaseDetails = new TasksForConcernAndCaseDetails();

    // WorkAllocationTask manipulation variables
    final WorkAllocationTask workAllocationTaskObj = WorkAllocationTaskFactory.newInstance();
    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new SearchTaskForConcernOrCaseKey();

    // ContextDescription manipulation variables
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();
    ParticipantContextDetails participantContextDetails;

    // Set key to call BPO operation
    searchTaskForConcernOrCaseKey.details.linkedID = key.concernRoleTasksKey.concernRoleID;

    // Call BPO to return a list of tasks for the participant
    tasksForConcernAndCaseDetails.detailsList = workAllocationTaskObj.listConcernRoleTasks(
      searchTaskForConcernOrCaseKey);

    // Iterate through the list and set the reservedBy flag
    for (int i = 0; i
      < tasksForConcernAndCaseDetails.detailsList.dtls.dtls.size(); i++) {

      if (tasksForConcernAndCaseDetails.detailsList.dtls.dtls.item(i).reservedBy.length()
        > 0) {

        tasksForConcernAndCaseDetails.detailsList.dtls.dtls.item(i).reservedByExistsInd = true;
      }
    }

    // Set key to retrieve context description
    participantContextKey.participantContextDescriptionKey.concernRoleID = key.concernRoleTasksKey.concernRoleID;

    // Read the context description
    participantContextDetails = readContextDescription(participantContextKey);

    // Set context description in return object
    tasksForConcernAndCaseDetails.contextDescription.participantContextDescriptionDetails.description = participantContextDetails.participantContextDescriptionDetails.description;

    // Display the duplicate client role soft links in a tab format
    // BEGIN, CR00221607, MC
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();
      // END, CR00102618

      // Page variables to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      // ConcernRole manipulation variables
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRoleKey currentKey = new ConcernRoleKey();
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      // Set concernRole
      concernRoleKey.concernRoleID = key.concernRoleTasksKey.concernRoleID;

      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listTaskForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listTask;

      // Build up the xml data needed for the tab widget
      tasksForConcernAndCaseDetails.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      tasksForConcernAndCaseDetails.ind = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);
      // END, CR00120078
    }
    // END, CR00221607

    return tasksForConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of clients interaction details.
   *
   * @param key
   * Contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListInteractionDetails listInteraction(final ListInteractionKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Details to be returned
    final ListInteractionDetails listInteractionDetails = new ListInteractionDetails();

    // Context Description variables
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();
    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // BEGIN, CR00192165, VM
    final ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();

    concernRoleKey.concernRoleID = key.listInteractionKey.concernRoleID;

    listInteractionDetails.details = clientInteractionObj.listForParticipant(
      concernRoleKey);
    // END, CR00192165

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.listInteractionKey.concernRoleID;

    // Get the context description for the concern role
    participantContextDetails = readContextDescription(participantContextKey);

    // Set context description
    listInteractionDetails.participantContextDescriptionDetails.description = participantContextDetails.participantContextDescriptionDetails.description;

    // Display the duplicate client role soft links in a tab format
    // BEGIN, CR00221607, MC
    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();
      // END, CR00102618

      // Page variables to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      // ConcernRole manipulation variables
      final ConcernRoleKey currentKey = new ConcernRoleKey();
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      // Set concernRole
      concernRoleKey.concernRoleID = key.listInteractionKey.concernRoleID;

      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listInteractionForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listInteraction;

      // Build up the xml data needed for the tab widget
      listInteractionDetails.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      listInteractionDetails.ind = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);
      // END, CR00120078
    }
    // END, CR00221607

    // Return the details
    return listInteractionDetails;
  }

  /**
   * Retrieves a person's interaction details.
   *
   * @param key
   * identifies interaction to be found.
   *
   * @return A person's interaction details found.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public curam.core.facade.struct.ReadInteractionDetails readInteraction(
    final curam.core.facade.struct.ReadInteractionKey key) throws AppException,
      InformationalException {

    // details to be returned
    final curam.core.facade.struct.ReadInteractionDetails readInteractionDetails = new curam.core.facade.struct.ReadInteractionDetails();

    // BEGIN, CR00192165, VM
    final ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();
    final ClientInteractionKey clientInteractionKey = new ClientInteractionKey();

    clientInteractionKey.clientInteractionID = key.readInteractionKey.clientInteractionID;

    final ClientInteractionDtls clientInteractionDtls = clientInteractionObj.view(
      clientInteractionKey);

    readInteractionDetails.readInteractionDetails.assign(clientInteractionDtls);
    // END, CR00192165

    // context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = readInteractionDetails.readInteractionDetails.concernRoleID;

    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    // get the context description for the concern role
    participantContextDetails = readContextDescription(participantContextKey);

    readInteractionDetails.participantContextDescriptionDetails.description = participantContextDetails.participantContextDescriptionDetails.description;

    // return the details
    return readInteractionDetails;
  }

  /**
   * This method creates a home phone number for a participant
   *
   * @param key
   * Identifies the participant for whom the home phone number is
   * created
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createHomePhoneNumber(
    final curam.core.facade.struct.CreateHomePhoneNumber key)
    throws AppException, InformationalException {

    // MaintainConcernRolePhoneNumber manipulation variables
    final curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory.newInstance();
    final MaintainPhoneNumberKey maintainPhoneNumberKey = new MaintainPhoneNumberKey();
    final ConcernRolePhoneDetails concernRolePhoneDetails = new ConcernRolePhoneDetails();

    // Map the key to create the phone number
    maintainPhoneNumberKey.concernRoleID = key.participantRoleID;

    // Map the details to create the phone number
    concernRolePhoneDetails.concernRoleID = key.participantRoleID;
    concernRolePhoneDetails.phoneAreaCode = key.phoneAreaCode;
    concernRolePhoneDetails.phoneCountryCode = key.phoneCountryCode;
    concernRolePhoneDetails.phoneNumber = key.phoneNumber;
    concernRolePhoneDetails.primaryPhoneInd = true;
    concernRolePhoneDetails.startDate = curam.util.type.Date.getCurrentDate();
    concernRolePhoneDetails.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    concernRolePhoneDetails.typeCode = curam.codetable.PHONETYPE.PERSONAL;

    // Create the home phone number
    maintainConcernRolePhoneObj.createPhoneNumber(maintainPhoneNumberKey,
      concernRolePhoneDetails);

  }

  /**
   * This method creates a mailing address for a participant
   *
   * @param key
   * Identifies the participant for whom the mailing address is created
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createMailingAddress(
    final curam.core.facade.struct.CreateMailingAddress key)
    throws AppException, InformationalException {

    // MaintainConcernRoleAddress manipulation variables
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();
    final MaintainAddressKey maintainAddressKey = new MaintainAddressKey();
    final AddressDetails addressDetails = new AddressDetails();

    // ConcernRoleAddress manipulation variables
    final curam.core.intf.ConcernRoleAddress concernRoleAddressObj = curam.core.fact.ConcernRoleAddressFactory.newInstance();
    final AddressForConcernRoleKey addressForConcernRoleKey = new AddressForConcernRoleKey();
    ConcernRoleAddressDtls concernRoleAddressDtls;
    final ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();

    // Check if the phone number ID input is zero
    if (key.mailingAddressID != 0) {

      // Set the key to read the concern role address
      addressForConcernRoleKey.addressID = key.mailingAddressID;
      addressForConcernRoleKey.concernRoleID = key.participantRoleID;

      // Perform a concern role address read
      concernRoleAddressDtls = concernRoleAddressObj.readAddressForConcernRole(
        addressForConcernRoleKey);

      // Set the key and details to perform the modify
      concernRoleAddressKey.concernRoleAddressID = concernRoleAddressDtls.concernRoleAddressID;

      // Set the endDate to today on the address record
      concernRoleAddressDtls.endDate = curam.util.type.Date.getCurrentDate();

      // Modify the address
      // BEGIN, CR00061099, POH
      // modify an existing citizenship record
      // Evidence key struct.
      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = concernRoleAddressKey.concernRoleAddressID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLEADDRESS;

      // Evidence descriptor object
      final EvidenceDescriptorModifyDtls evidenceDescriptorModifyDtls = new EvidenceDescriptorModifyDtls();

      evidenceDescriptorModifyDtls.receivedDate = Date.getCurrentDate();

      // Modify details object
      final EIEvidenceModifyDtls eiEvidenceModifyDtls = new EIEvidenceModifyDtls();

      eiEvidenceModifyDtls.descriptor.assign(evidenceDescriptorModifyDtls);
      eiEvidenceModifyDtls.parentKey.evidenceID = 0;
      eiEvidenceModifyDtls.evidenceObject = concernRoleAddressDtls;

      // EvidenceController business object
      final EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

      // call evidence controller modify evidence method
      evidenceControllerObj.modifyEvidence(eiEvidenceKey, eiEvidenceModifyDtls);
      // END, CR00061099, POH
    }

    // Map the key to create the address
    maintainAddressKey.concernRoleID = key.participantRoleID;

    // Map the details to create the address
    addressDetails.addressData = key.addressData;
    addressDetails.concernRoleID = key.participantRoleID;
    addressDetails.primaryAddressInd = false;
    addressDetails.startDate = curam.util.type.Date.getCurrentDate();
    addressDetails.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    addressDetails.typeCode = curam.codetable.CONCERNROLEADDRESSTYPE.MAILING;

    // Create the new mailing address
    maintainConcernRoleAddressObj.createAddress(maintainAddressKey,
      addressDetails);

  }

  /**
   * This method creates a home phone number for a participant
   *
   * @param key
   * Identifies the participant for whom the work phone number is
   * created
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createWorkPhoneNumber(
    final curam.core.facade.struct.CreateWorkPhoneNumber key)
    throws AppException, InformationalException {

    // MaintainConcernRolePhoneNumber manipulation variables
    final curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory.newInstance();
    final MaintainPhoneNumberKey maintainPhoneNumberKey = new MaintainPhoneNumberKey();
    final ConcernRolePhoneDetails concernRolePhoneDetails = new ConcernRolePhoneDetails();
    
    // ConcernRolePhoneNumber manipulation variables
    final curam.core.intf.ConcernRolePhoneNumber concernRolePhoneNumberObj = curam.core.fact.ConcernRolePhoneNumberFactory.newInstance();
    final PhoneForConcernRoleKey phoneForConcernRoleKey = new PhoneForConcernRoleKey();
    
    // BEGIN, CR00360875, ELG
    final PDCPhoneNumber pdcPhoneNumberObj = PDCPhoneNumberFactory.newInstance();
    final ParticipantPhoneDetails participantPhoneDetails = new ParticipantPhoneDetails();

    // Check if the phone number ID input is zero
    if (key.phoneNumberID != 0) {

      // Set the key to perform the concern role phone number read
      phoneForConcernRoleKey.concernRoleID = key.participantRoleID;
      phoneForConcernRoleKey.phoneNumberID = key.phoneNumberID;

      final ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls = concernRolePhoneNumberObj.readPhoneForConcernRole(
        phoneForConcernRoleKey);
      
      final ReadConcernRolePhoneKey readConcernRolePhoneKey = new ReadConcernRolePhoneKey();

      readConcernRolePhoneKey.concernRolePhoneNumberID = concernRolePhoneNumberDtls.concernRolePhoneNumberID;
      
      final ConcernRolePhoneDetails concernRolePhoneDetailsRead = maintainConcernRolePhoneObj.readPhoneNumber(
        readConcernRolePhoneKey);

      participantPhoneDetails.assign(concernRolePhoneDetailsRead);
      
      // Set the end date to today
      participantPhoneDetails.endDate = curam.util.type.Date.getCurrentDate();

      // Update the concern role phone number end date to today
      pdcPhoneNumberObj.modify(participantPhoneDetails);
    
    }
    // END, CR00360875

    // Map the key to create the phone number
    maintainPhoneNumberKey.concernRoleID = key.participantRoleID;

    // Map the details to create the phone number
    concernRolePhoneDetails.concernRoleID = key.participantRoleID;
    concernRolePhoneDetails.phoneAreaCode = key.phoneAreaCode;
    concernRolePhoneDetails.phoneCountryCode = key.phoneCountryCode;
    concernRolePhoneDetails.phoneNumber = key.phoneNumber;
    concernRolePhoneDetails.phoneExtension = key.phoneExtension;
    concernRolePhoneDetails.primaryPhoneInd = false;
    concernRolePhoneDetails.startDate = curam.util.type.Date.getCurrentDate();
    concernRolePhoneDetails.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    concernRolePhoneDetails.typeCode = curam.codetable.PHONETYPE.BUSINESS;

    // Create the home phone number
    maintainConcernRolePhoneObj.createPhoneNumber(maintainPhoneNumberKey,
      concernRolePhoneDetails);

  }

  /**
   * This method creates a home phone number for a participant
   *
   * @param key
   * Identifies the participant for whom the primary residence address
   * is created
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void insertPrimaryResidenceAddress(
    final curam.core.facade.struct.InsertPrimaryResAddress key)
    throws AppException, InformationalException {

    // MaintainConcernRoleAddress manipulation variables
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();
    final MaintainAddressKey maintainAddressKey = new MaintainAddressKey();
    final AddressDetails addressDetails = new AddressDetails();

    // Map the key to create the address
    maintainAddressKey.concernRoleID = key.concernRoleID;

    // Map the details to create the address
    addressDetails.addressData = key.addressData;
    addressDetails.concernRoleID = key.concernRoleID;
    addressDetails.primaryAddressInd = true;
    addressDetails.startDate = curam.util.type.Date.getCurrentDate();
    addressDetails.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    addressDetails.typeCode = curam.codetable.CONCERNROLEADDRESSTYPE.PRIVATE;

    // Create the new residence address
    maintainConcernRoleAddressObj.createAddress(maintainAddressKey,
      addressDetails);

  }

  /**
   * Updates the payment details for all cases, where the old bank account was
   * being paid, to the new bank account.
   *
   * @param key
   * UpdateBankAccPaymentDtlsKey the concern role ID and the bank
   * account ID of the bank for which payment will now be made to.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void updateBankAccountPaymentDetails(
    final UpdateBankAccPaymentDtlsKey key)
    throws AppException, InformationalException {

    // Bank account maintenance object and key
    final curam.core.intf.MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = curam.core.fact.MaintainConcernRoleBankAcFactory.newInstance();

    maintainConcernRoleBankAcObj.updateBankAccountPaymentDetails(key.key);

  }

  /**
   * Method to list all active bank accounts for a Case Nominee
   *
   * @param key
   * contains concernRoleID
   *
   * @return list of all active bank accounts for a participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadActiveBankAccountList listActiveBankAccount(
    final ReadParticipantBankAccountListKey key) throws AppException,
      InformationalException {

    final ReadActiveBankAccountList readActiveBankAccountList = new ReadActiveBankAccountList();

    // Bank account maintenance object
    final curam.core.intf.MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = curam.core.fact.MaintainConcernRoleBankAcFactory.newInstance();
    final MaintainConcernRoleKey maintainConcernRoleKey = new MaintainConcernRoleKey();

    maintainConcernRoleKey.concernRoleID = key.maintainBankAccountKey.concernRoleID;

    readActiveBankAccountList.dtls = maintainConcernRoleBankAcObj.readmultiByConcernRoleForNomineeWizard(
      maintainConcernRoleKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.maintainBankAccountKey.concernRoleID;

    // Get the context description for the concern role
    readActiveBankAccountList.contextDescription = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    return readActiveBankAccountList;
  }

  // BEGIN, CR00129218, ELG
  // BEGIN, CR00224677, ZV
  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains concernRoleID and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listActiveBankAccountForRedirection1()}.
   */
  @Deprecated
  public BankAccountListForRedirectionDetails listActiveBankAccountForRedirection(
    final ParticipantBankAccountRedirectionKey key) throws AppException,
      InformationalException {

    // return structure
    final BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails = new BankAccountListForRedirectionDetails();

    final ReadParticipantBankAccountListKey readParticipantBankAccountListKey = new ReadParticipantBankAccountListKey();

    ReadActiveBankAccountList readActiveBankAccountList;

    readParticipantBankAccountListKey.maintainBankAccountKey = key.maintainBankAccountKey;

    // retrieve list of accounts and context description
    readActiveBankAccountList = listActiveBankAccount(
      readParticipantBankAccountListKey);

    bankAccountListForRedirectionDetails.dtls = readActiveBankAccountList.dtls;
    bankAccountListForRedirectionDetails.contextDescription = readActiveBankAccountList.contextDescription;

    final LocalisableString redirectionContext = new LocalisableString(
      curam.message.BPOPARTICIPANT.INF_BANKACCOUNT_REDIRECTION_CONTEXT);

    redirectionContext.arg(key.accountNumber);

    // BEGIN, CR00163236, CL
    bankAccountListForRedirectionDetails.redirectionDescription.description = redirectionContext.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163236

    return bankAccountListForRedirectionDetails;
  }

  // END, CR00224677
  // END, CR00129218

  /**
   * Retrieves a list of active address records for a concern role.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of active addresses returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantActiveAddressList listActiveAddresses(
    final ReadParticipantAddressListKey key) throws AppException,
      InformationalException {

    // Address maintenance object
    final curam.core.intf.MaintainConcernRoleAddress maintainConcernRoleAddressObj = curam.core.fact.MaintainConcernRoleAddressFactory.newInstance();

    // Details to be returned
    final ReadParticipantActiveAddressList readParticipantActiveAddressList = new ReadParticipantActiveAddressList();

    // Read list of active addresses
    readParticipantActiveAddressList.readActiveAddressesByConcernRoleResult = maintainConcernRoleAddressObj.searchByConcernRoleStatus(
      key.maintainAddressKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.maintainAddressKey.concernRoleID;

    // Get the context description for the concern role
    readParticipantActiveAddressList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return active address details
    return readParticipantActiveAddressList;

  }

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced with
   * {@link Participant#listDeduction1(ConcernRoleKeyStruct)}.
   */
  @Deprecated
  public ReadParticipantDeductionList listDeduction(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    final ReadParticipantDeductionList readParticipantDeductionList = new ReadParticipantDeductionList();

    final ReadParticipantDeductionList1 readParticipantDeductionList1 = listDeduction1(
      key);

    readParticipantDeductionList.ind = readParticipantDeductionList1.ind;
    readParticipantDeductionList.participantContextDescriptionDetails = readParticipantDeductionList1.participantContextDescriptionDetails;
    readParticipantDeductionList.renderXML = readParticipantDeductionList1.renderXML;

    ParticipantDeductionDetails participantDeductionDetails;

    for (int i = 0; i
      < readParticipantDeductionList1.deductionDtls.dtlsList.size(); i++) {
      participantDeductionDetails = new ParticipantDeductionDetails();

      participantDeductionDetails.assign(
        readParticipantDeductionList1.deductionDtls.dtlsList.item(i));

    }

    // Return the list of deductions
    return readParticipantDeductionList;
  }

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantDeductionList1 listDeduction1(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    final ReadParticipantDeductionList1 readParticipantDeductionList = new ReadParticipantDeductionList1();
    // MaintainDeductionItems manipulation variables
    final MaintainDeductionItems maintainDeductionItemsObj = MaintainDeductionItemsFactory.newInstance();

    final ConcernRoleID concernRoleID = new ConcernRoleID();

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    // Set the concern role identifier
    concernRoleID.concernRoleID = key.concernRoleID;

    // Get the deductions for this concern
    final ReadParticipantDeductionList readParticipantDeductions = new ReadParticipantDeductionList();

    readParticipantDeductions.deductionDtls = maintainDeductionItemsObj.listParticipantDeductionDetails(
      concernRoleID);

    // Populate context description key
    participantContextKey.participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Get the context description for the concern role
    readParticipantDeductionList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // BEGIN, CR00221607, MC
    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();
      // END, CR00102618

      // Page variables to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      // ConcernRole manipulation variables
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRoleKey currentKey = new ConcernRoleKey();
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      // Set concernRole
      concernRoleKey.concernRoleID = key.concernRoleID;

      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Set page identifiers for user to navigate to
      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listDeductionForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listDeduction;

      // Build up the xml data needed for the tab widget
      readParticipantDeductionList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      readParticipantDeductionList.ind = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);
      // END, CR00120078
    }
    // END, CR00221607

    // Display the product type and case reference as a single field.
    // BEGIN, CR00323134, MV
    LocalisableString caseDescriptionText = null;
    // END, CR00323134

    ParticipantDeductionDetails participantDeductionDetails;
    ParticipantDeductionDetails1 participantDeductionDetails1;

    for (int i = 0; i < readParticipantDeductions.deductionDtls.dtlsList.size(); i++) {
      // BEGIN, CR00323134, MV
      caseDescriptionText = new LocalisableString(GENERAL.INF_CASETYPE_CASEREF);
      // END, CR00323134
      participantDeductionDetails1 = new ParticipantDeductionDetails1();
      participantDeductionDetails = readParticipantDeductions.deductionDtls.dtlsList.item(
        i);

      caseDescriptionText.arg(
        new CodeTableItemIdentifier(PRODUCTTYPE.TABLENAME,
        participantDeductionDetails.productType));
      caseDescriptionText.arg(participantDeductionDetails.caseReference);

      participantDeductionDetails1.assign(participantDeductionDetails);

      participantDeductionDetails1.caseDescriptionText = caseDescriptionText.toClientFormattedText();

      readParticipantDeductionList.deductionDtls.dtlsList.addRef(
        participantDeductionDetails1);
    }

    // Return the list of deductions
    return readParticipantDeductionList;
  }

  /**
   * Retrieves a list of issued payment instruments for a concern role, where
   * the client is the concern or the nominee.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of payment instruments returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListParticipantIssuedPaymentInstrument listIssuedPaymentInstrument(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Return struct
    final ListParticipantIssuedPaymentInstrument listParticipantIssuedPaymentInstrument = new ListParticipantIssuedPaymentInstrument();

    // ViewConcernAccount manipulation variables
    final ViewConcernAccount viewConcernAccountObj = ViewConcernAccountFactory.newInstance();

    // ConcernRole identifier
    final ConcernRoleID concernRoleID = new ConcernRoleID();

    concernRoleID.concernRoleID = key.concernRoleID;

    // Get the list of payment instruments
    listParticipantIssuedPaymentInstrument.instrumentDtls = viewConcernAccountObj.listConcernNomineeIssuedPaymentInstrument(
      concernRoleID);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Get the context description for the concern role
    listParticipantIssuedPaymentInstrument.description = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Display the duplicate client role soft links in a tab format
    // BEGIN, CR00221607, MC
    // Display the duplicate client role soft links in a tab format
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();
      // END, CR00102618

      // Page variables to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      // ConcernRole manipulation variables
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      final ConcernRoleKey currentKey = new ConcernRoleKey();
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new ConcernRoleIDStatusCodeKey();

      // Assign the key
      concernRoleID.concernRoleID = key.concernRoleID;

      concernRoleKey.concernRoleID = key.concernRoleID;

      // Set concernRole to current concernRole
      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listFinancialInstrumentForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listFinancialInstrument;

      // Build up the xml data needed for the tab widget
      listParticipantIssuedPaymentInstrument.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);

      // Populate key to check for duplicate
      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;

      // Set an indicator if this concern has duplicates
      listParticipantIssuedPaymentInstrument.ind = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);
      // END, CR00120078
    }
    // Return the list of payment instruments
    return listParticipantIssuedPaymentInstrument;
  }

  /**
   * Create a new web address for a participant.
   *
   * @param details
   * The web address details being entered
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    // Web address object and key
    final curam.core.sl.intf.WebAddress webAddressObj = curam.core.sl.fact.WebAddressFactory.newInstance();
    final ConcernRoleIDKey concernRoleIDKey = new ConcernRoleIDKey();

    // Get concern role ID from key
    concernRoleIDKey.concernRoleID = details.details.dtls.concernRoleID;

    // Create web address
    webAddressObj.create(concernRoleIDKey, details.details);

  }

  /**
   * Modify the details of a web address for a participant.
   *
   * @param details
   * The web address details being modified
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    // Web address object and key
    final curam.core.sl.intf.WebAddress webAddressObj = curam.core.sl.fact.WebAddressFactory.newInstance();
    final ConcernRoleIDKey concernRoleIDKey = new ConcernRoleIDKey();

    // Get concern role ID from key
    concernRoleIDKey.concernRoleID = details.details.dtls.concernRoleID;

    // Modify the web address
    webAddressObj.modify(concernRoleIDKey, details.details);

  }

  /**
   * Cancel a web address for a participant.
   *
   * @param details
   * The details of the web address to cancel
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelWebAddress(final CancelParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    // Web address object and key
    final curam.core.sl.intf.WebAddress webAddressObj = curam.core.sl.fact.WebAddressFactory.newInstance();

    // Cancel the web address
    webAddressObj.cancel(details.details);

  }

  /**
   * Read the details for a participants web address.
   *
   * @param key
   * The web address ID of the record being read
   * @return The web address details returned from the database
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantWebAddressDetails readWebAddress(
    final ParticipantWebAddressKey key)
    throws AppException, InformationalException {

    // Web address object
    final curam.core.sl.intf.WebAddress webAddressObj = curam.core.sl.fact.WebAddressFactory.newInstance();

    // Details to be returned
    final ReadParticipantWebAddressDetails readParticipantWebAddressDetails = new ReadParticipantWebAddressDetails();

    // Read the web address
    readParticipantWebAddressDetails.details = webAddressObj.read(key.key);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = readParticipantWebAddressDetails.details.dtls.concernRoleID;
    // Get the context description for the concern role
    readParticipantWebAddressDetails.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return details
    return readParticipantWebAddressDetails;

  }

  /**
   * Retrieves a list of web addresses for a participant.
   *
   * @param key
   * The concern role ID for which a list of web addresses is returned
   * @return The list of web addresses returned from the database
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantWebAddressList listWebAddress(
    final ParticipantWebAddressListKey key) throws AppException,
      InformationalException {

    // Web address object
    final curam.core.sl.intf.WebAddress webAddressObj = curam.core.sl.fact.WebAddressFactory.newInstance();

    // Details to be returned
    final ParticipantWebAddressList participantWebAddressList = new ParticipantWebAddressList();

    // Read list of web addresses
    participantWebAddressList.list = webAddressObj.list(key.key);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.key.concernRoleID;
    // Get the context description for the concern role
    participantWebAddressList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // BEGIN , CR00123062 , DJ

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      participantWebAddressList.messagelist.dtls.addRef(informationalMsgDtls);

    }
    // END , CR00123062
    // Return details
    return participantWebAddressList;

  }

  // BEGIN, CR00016578, SPD

  /**
   * Ends all active deductions on a case for a participant.
   *
   * @param details
   * The concern role ID & the case ID
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void endDeduction(final EndDeductionDetails details)
    throws AppException, InformationalException {

    // MaintainDeductionItems manipulation variables
    final MaintainDeductionItems maintainDeductionItemsObj = MaintainDeductionItemsFactory.newInstance();
    CaseIDThirdPartyID caseIDThirdPartyID = new CaseIDThirdPartyID();

    // populate service layer details
    caseIDThirdPartyID = details.details;

    // call down to service layer to end case deductions for a participant
    maintainDeductionItemsObj.endThirdPartyActiveDeductions(caseIDThirdPartyID);
  }

  // END, CR00016578

  /**
   * Resolves the home page for prospect person and prospect employer.
   *
   * Security checks are not applied in this method as it must be used from
   * the resolve script only.
   *
   * @param key The concern Role ID of the record being read.
   * @return The home page name.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantHomePageName resolveProspectHome(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    // Return Struct
    final ParticipantHomePageName result = new ParticipantHomePageName();

    // BEGIN, CR00101909, ELG
    // Concern Role object
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;

    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // If the concern role is of type prospect person
    if (concernRoleDtls.concernRoleType.equals(CONCERNROLETYPE.PROSPECTPERSON)) {

      // If prospect person status is current
      if (concernRoleDtls.statusCode.equals(CONCERNROLESTATUS.CURRENT)) {

        // BEGIN, CR00023312, GM
        result.participantHomePageName = UimConst.kparticipantHomePageName;
        // END, CR00023312

      } // If prospect person status is transferred to person status
      else if (concernRoleDtls.statusCode.equals(CONCERNROLESTATUS.TRANSFERRED)) {

        // BEGIN, CR00023312, GM
        result.participantHomePageName = UimConst.kProspectPersonRegisteredAsPersonHomePageName;
        // END, CR00023312

      }

    } // If the concern role is of type prospect employer
    else if (concernRoleDtls.concernRoleType.equals(
      CONCERNROLETYPE.PROSPECTEMPLOYER)) {

      // If prospect employer status is current
      if (concernRoleDtls.statusCode.equals(CONCERNROLESTATUS.CURRENT)) {

        // BEGIN, CR00051657, GM
        result.participantHomePageName = UimConst.ProspectEmployerHomePage;
        // END, CR00051657

      } // If prospect employer status is transferred to employer status
      else if (concernRoleDtls.statusCode.equals(CONCERNROLESTATUS.TRANSFERRED)) {

        // BEGIN, CR00023312, GM
        result.participantHomePageName = UimConst.ProspectEmployerRegisteredAsEmployer;
        // END, CR00023312

      }

    } // BEGIN, CR00129241, AKr
    // If the concern role ID did not match any of the prospects, they could
    // have been registered as person/employer.
    else if (CONCERNROLETYPEEntry.PERSON.getCode().equals(
      concernRoleDtls.concernRoleType)) {
      // BEGIN, CR00354096, BD
      result.participantHomePageName = UimConst.PersonResolveHomePage;
      // END, CR00354096
    } else if (CONCERNROLETYPEEntry.EMPLOYER.getCode().equals(
      concernRoleDtls.concernRoleType)) {

      result.participantHomePageName = UimConst.kEmployerHomePageName;
    }
    // END, CR00129241
    // END, CR00101909

    // return details
    return result;
  }

  // BEGIN, CR00060595, PCAL

  /**
   * Method returns a list of AlternateID Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key The alternateID of the AlternateID record the snapshots are
   * associated with.
   *
   * @return The list of AlternateID snapshot details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAltIDHistoryList listAlternateIDHistory(
    final ReadParticipantAltIDHistoryListKey key)
    throws AppException, InformationalException {

    // Return struct
    final ReadParticipantAltIDHistoryList readParticipantAltIDHistoryList = new ReadParticipantAltIDHistoryList();

    // BEGIN, CR00075874, CR00101199 SSK, VM
    // Read the alternate ID details to get the concernRoleID
    final ConcernRoleAlternateIDKey concernRoleAlternateIDKey = new ConcernRoleAlternateIDKey();
    final curam.core.intf.ConcernRoleAlternateID concernRoleAlternateIDObj = curam.core.fact.ConcernRoleAlternateIDFactory.newInstance();

    concernRoleAlternateIDKey.concernRoleAlternateID = key.historyKey.concernRoleAlternateID;

    try {
      final ConcernRoleAlternateIDDtls concernRoleAlternateIDDtls = concernRoleAlternateIDObj.read(
        concernRoleAlternateIDKey);

      key.historyKey.concernRoleID = concernRoleAlternateIDDtls.concernRoleID;

    } catch (final RecordNotFoundException rnfe) {

      final ConcernRoleAlternateIDSnapshotKey concernRoleAlternateIDSnapshotKey = new ConcernRoleAlternateIDSnapshotKey();

      concernRoleAlternateIDSnapshotKey.concernRoleAltIDSnapshotID = key.historyKey.concernRoleAlternateID;

      final ConcernRoleAlternateIDSnapshotDtls concernRoleAlternateIDSnapshotDtls = ConcernRoleAlternateIDSnapshotFactory.newInstance().read(
        concernRoleAlternateIDSnapshotKey);

      key.historyKey.concernRoleID = concernRoleAlternateIDSnapshotDtls.concernRoleID;
    }
    // END, CR00075874, CR00101199

    // Retrieve the list of snap shot summary details
    final MaintainConcernRoleAltID maintainConcernRoleAltIDObj = MaintainConcernRoleAltIDFactory.newInstance();

    readParticipantAltIDHistoryList.historyDtls = maintainConcernRoleAltIDObj.listAlternateIDHistory(
      key.historyKey);

    // Get the context description of the AlternateID record
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.historyKey.concernRoleID;
    readParticipantAltIDHistoryList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return the details
    return readParticipantAltIDHistoryList;
  }

  // END, CR00060595

  // BEGIN, CR00060981, PCAL

  /**
   * Method returns a list of ConcernRole Bank Account Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key The ConcernRole Bank Account record the snapshots are
   * associated with.
   *
   * @return The list of ConcernRole Bank Account snapshot details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantBankAcHistoryList listBankAccountHistory(
    final ReadParticipantBankAcHistoryListKey key)
    throws AppException, InformationalException {

    // Return struct
    final ReadParticipantBankAcHistoryList readConcernRoleBankAcHistoryList = new ReadParticipantBankAcHistoryList();

    // BEGIN, CR00075874, CR00101199 SSK, VM
    // Read the concern role bank account details to get the concernRoleID
    final ConcernRoleBankAccountKey concernRoleBankAccountKey = new ConcernRoleBankAccountKey();
    final curam.core.intf.ConcernRoleBankAccount concernRoleBankAccountObj = curam.core.fact.ConcernRoleBankAccountFactory.newInstance();

    concernRoleBankAccountKey.concernRoleBankAccountID = key.historyKey.concernRoleBankAccountID;

    try {
      final ConcernRoleBankAccountDtls concernRoleBankAccountDtls = concernRoleBankAccountObj.read(
        concernRoleBankAccountKey);

      key.historyKey.concernRoleID = concernRoleBankAccountDtls.concernRoleID;

    } catch (final RecordNotFoundException rnfe) {

      final ConcernRoleBankAccountSnapshotKey concernRoleBankAccountSnapshotKey = new ConcernRoleBankAccountSnapshotKey();

      concernRoleBankAccountSnapshotKey.concernRoleBnkAccSnapshotID = key.historyKey.concernRoleBankAccountID;

      final ConcernRoleBankAccountSnapshotDtls concernRoleBankAccountSnapshotDtls = ConcernRoleBankAccountSnapshotFactory.newInstance().read(
        concernRoleBankAccountSnapshotKey);

      key.historyKey.concernRoleID = concernRoleBankAccountSnapshotDtls.concernRoleID;
    }
    // END, CR00075874, CR00101199

    // Retrieve the list of snap shot summary details
    final MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = MaintainConcernRoleBankAcFactory.newInstance();

    readConcernRoleBankAcHistoryList.historyDtls = maintainConcernRoleBankAcObj.listBankAccountHistory(
      key.historyKey);
    
    // BEGIN, CR00378468, VT
    for (final ReadConcernRoleBankAcHistoryListDtls concernRoleBankAcHistoryList : readConcernRoleBankAcHistoryList.historyDtls.listDtls) {
      if (!concernRoleBankAcHistoryList.ibanOpt.isEmpty()) {
        concernRoleBankAcHistoryList.bankAccountNumberOpt = concernRoleBankAcHistoryList.ibanOpt;
      } else {
        concernRoleBankAcHistoryList.bankAccountNumberOpt = concernRoleBankAcHistoryList.accountNumber;
      }
    }
    // END, CR00378468

    // BEGIN, CR00372378, VT
    // BEGIN, CR00372632, VT
    for (final ReadConcernRoleBankAcHistoryListDtls concernRoleBankAcHistoryList : readConcernRoleBankAcHistoryList.historyDtls.listDtls) {
      if (!concernRoleBankAcHistoryList.ibanOpt.isEmpty()) {
        concernRoleBankAcHistoryList.bankAccountNumberOpt = concernRoleBankAcHistoryList.ibanOpt;
      } else {
        concernRoleBankAcHistoryList.bankAccountNumberOpt = concernRoleBankAcHistoryList.accountNumber;
      }
    }
    // END, CR00372632
    // END, CR00372378

    // Get the context description of the ConcernRole Bank Account record
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    participantContextKey.participantContextDescriptionKey.concernRoleID = key.historyKey.concernRoleID;

    readConcernRoleBankAcHistoryList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Return the details
    return readConcernRoleBankAcHistoryList;
  }

  // END, CR00060981

  // BEGIN, CR00102618, CSH

  /**
   * Retrieves a list of client role records for a duplicate concern role.
   *
   * @param key
   * The concern role ID for which a list of client roles is returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadDuplicateParticipantConcernRoleList listConcernRoleForDuplicate(final ReadParticipantConcernRoleKey key)
    throws AppException, InformationalException {

    // Concern Roles maintenance object
    final curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();

    // ClientMerge manipulation objects
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();

    // Details to be returned
    final ReadDuplicateParticipantConcernRoleList readDupParticipantCRList = new ReadDuplicateParticipantConcernRoleList();

    // Read list of client roles
    readDupParticipantCRList.duplicateParticipantConcernRoleList.concernRolesDetailsList = maintainConcernRoleDetailsObj.readListOfConcernRoles(
      key.readConcernRoleKey);

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // BEGIN, CR00120078, SPD
    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.readConcernRoleKey.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Get the context description for the original concern role
    readDupParticipantCRList.duplicateParticipantConcernRoleList.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Set the context description key to be the duplicate concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = key.readConcernRoleKey.concernRoleID;

    // Get the context description for the duplicate concern role
    readDupParticipantCRList.duplicateContextDesc = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.readConcernRoleKey.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listRoleForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listRole;

    // Build up the xml data needed for the tab widget
    readDupParticipantCRList.duplicateParticipantConcernRoleList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
    // END, CR00120078

    // Return details
    return readDupParticipantCRList;
  }

  /**
   * Retrieves a list of deduction records for a duplicate concern role.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadDuplicateParticipantDeductionList listDeductionForDuplicate(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Return struct
    final ReadDuplicateParticipantDeductionList readDupParticipantDedList = new ReadDuplicateParticipantDeductionList();

    // MaintainDeductionItems manipulation variables
    final MaintainDeductionItems maintainDeductionItemsObj = MaintainDeductionItemsFactory.newInstance();

    // Concern role identifier
    final ConcernRoleID concernRoleID = new ConcernRoleID();

    // ClientMerge manipulation objects
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // Set the concern role identifier
    concernRoleID.concernRoleID = key.concernRoleID;

    // Get the deductions for this concern
    readDupParticipantDedList.duplicateParticipantDeductions.deductionDtls = maintainDeductionItemsObj.listParticipantDeductionDetails(
      concernRoleID);

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Get the context description for the original concern role
    readDupParticipantDedList.duplicateParticipantDeductions.participantContextDescriptionDetails = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Populate context description key for duplicate concern role
    participantContextKey.participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Get the context description for the duplicate concern role
    readDupParticipantDedList.duplicateContextDesc = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listDeductionForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listDeduction;

    // Build up the xml data needed for the tab widget
    readDupParticipantDedList.duplicateParticipantDeductions.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
    // END, CR00120078

    // Return the list of deductions
    return readDupParticipantDedList;
  }

  /**
   * Retrieves a list of duplicate client interaction details.
   *
   * @param key Contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListDuplicateParticipantInteractionDetails listInteractionForDuplicate(
    final ListInteractionKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Return struct
    final ListDuplicateParticipantInteractionDetails listInteractionDetails = new ListDuplicateParticipantInteractionDetails();

    // ClientMerge manipulation variable
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();

    // BEGIN, CR00192165, VM
    final ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.listInteractionKey.concernRoleID;

    listInteractionDetails.duplicateParticipantDetails.details = clientInteractionObj.listForParticipant(
      concernRoleKey);
    // END, CR00192165

    // Context description variables
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();
    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList concernRoleDupDtlsList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.listInteractionKey.concernRoleID;
    concernRoleDupDtlsList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(
      dupKey);

    // Set the context description key to be the original concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = concernRoleDupDtlsList.dtls.item(0).originalConcernRoleID;

    // get the context description for the original concern role
    participantContextDetails = readContextDescription(participantContextKey);

    listInteractionDetails.duplicateParticipantDetails.participantContextDescriptionDetails = participantContextDetails.participantContextDescriptionDetails;

    // Set the context description key to be the duplicate concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = key.listInteractionKey.concernRoleID;

    // get the context description for the duplicate concern role
    listInteractionDetails.duplicateContextDesc = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = concernRoleDupDtlsList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.listInteractionKey.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listInteractionForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listInteraction;

    // Build up the xml data needed for the tab widget
    listInteractionDetails.duplicateParticipantDetails.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
    // END, CR00120078

    // Return the details
    return listInteractionDetails;
  }

  /**
   * Retrieves a list of duplicate client issued payment instrument details.
   *
   * @param key Contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListDuplicateParticipantIssuedPaymentInstrument listIssuedPaymentInstrumentForDuplicate(final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Return struct
    final ListDuplicateParticipantIssuedPaymentInstrument listDuplicateParticipantIssuedPmntInst = new ListDuplicateParticipantIssuedPaymentInstrument();

    // ViewConcernAccount manipulation variables
    final ViewConcernAccount viewConcernAccountObj = ViewConcernAccountFactory.newInstance();
    final ConcernRoleID concernRoleID = new ConcernRoleID();

    // ClientMerge manipulation variable
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    // Context description key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // Assign the key
    concernRoleID.concernRoleID = key.concernRoleID;

    // Get the list of payment instruments
    listDuplicateParticipantIssuedPmntInst.duplicateParticipantIssuedPmntInst.instrumentDtls = viewConcernAccountObj.listConcernNomineeIssuedPaymentInstrument(
      concernRoleID);

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Get the context description for the concern role
    listDuplicateParticipantIssuedPmntInst.duplicateParticipantIssuedPmntInst.description = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Set the context description key to be the duplicate concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Get the context description for the concern role
    listDuplicateParticipantIssuedPmntInst.duplicateContextDesc = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listFinancialInstrumentForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listFinancialInstrument;

    // Build up the xml data needed for the tab widget
    listDuplicateParticipantIssuedPmntInst.duplicateParticipantIssuedPmntInst.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
    // END, CR00120078

    // Return the list of payment instruments
    return listDuplicateParticipantIssuedPmntInst;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key Contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */

  public ListDuplicateParticipantFinancials listParticipantFinancialForDuplicate(
    final ListParticipantFinancialsKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return object
    final ListDuplicateParticipantFinancials listDuplicateParticipantFinancials = new ListDuplicateParticipantFinancials();

    // ViewConcernAccount manipulation variables
    final curam.core.intf.ViewConcernAccount viewConcernAccountObj = curam.core.fact.ViewConcernAccountFactory.newInstance();
    ViewConcAccountSummaryResult viewConcernRoleAccountSummary;
    final FinancialAccountIdentifier financialAccountIdentifier = new FinancialAccountIdentifier();

    // ClientMerge manipulation objects
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    // Context key
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // Assign key details to search for the concern's financials
    financialAccountIdentifier.assign(key);

    // Call ViewConcernAccount BPO to return the concern's financial records
    viewConcernRoleAccountSummary = viewConcernAccountObj.viewConcernRoleAccountSummary(
      financialAccountIdentifier);

    // Iterate through the list if it's populated
    if (!viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.isEmpty()) {

      // Reserve space in the output object
      listDuplicateParticipantFinancials.duplicateParticipantFinancials.participantFinancialsList.dtls.ensureCapacity(
        viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.size());

      // ConcernFinancials object
      ParticipantFinancials participantFinancials;

      for (int i = 0; i
        < viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.size(); i++) {

        participantFinancials = new ParticipantFinancials();

        participantFinancials.assign(
          viewConcernRoleAccountSummary.concernRoleAccSummaryList.dtls.item(i));

        // Amounts are always stored on the database in the base currency and
        // always read back as such. The base currency is returned here for
        // display purposes. The amounts in the money field(s) on each row will
        // be shown in the following format: "USD 1000"
        participantFinancials.currencyType = viewConcernRoleAccountSummary.concernRoleAccSummHeader.currencyType;

        // Add details to the list
        listDuplicateParticipantFinancials.duplicateParticipantFinancials.participantFinancialsList.dtls.addRef(
          participantFinancials);
      }
    } // end if

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Get the context description for the concern role
    listDuplicateParticipantFinancials.duplicateParticipantFinancials.contextDescription = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Set the context description key to be the duplicate concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = key.concernRoleID;

    // Get the context description for the duplicate concern role
    listDuplicateParticipantFinancials.duplicateContextDesc = readContextDescription(participantContextKey).participantContextDescriptionDetails;

    // Get the concern role ID from the key.
    concernRoleKey.concernRoleID = key.concernRoleID;

    // Read the concern role name.
    ConcernRoleNameDetails concernRoleNameDetails;

    concernRoleNameDetails = concernRoleObj.readConcernRoleName(concernRoleKey);

    listDuplicateParticipantFinancials.duplicateParticipantFinancials.concernRoleName = concernRoleNameDetails.concernRoleName;

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listFinancialForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listFinancial;

    // Build up the xml data needed for the tab widget
    listDuplicateParticipantFinancials.duplicateParticipantFinancials.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
    // END, CR00120078

    return listDuplicateParticipantFinancials;

  }

  /**
   * Retrieves a list of duplicate client task details.
   *
   * @param key
   * Contains the concern role identifier.
   *
   * @return A list of client task records and context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public TasksForDuplicateConcernAndCaseDetails listParticipantTaskForDuplicate(
    final ListParticipantTaskKey_eo key)
    throws AppException, InformationalException {

    // BEGIN, CR00120078, SPD
    // Create return object
    final TasksForDuplicateConcernAndCaseDetails tasksForDupConcernAndCaseDetails = new TasksForDuplicateConcernAndCaseDetails();

    // WorkAllocationTask manipulation variables
    final WorkAllocationTask workAllocationTaskObj = WorkAllocationTaskFactory.newInstance();
    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new SearchTaskForConcernOrCaseKey();

    // ClientMerge manipulation objects
    final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();

    // Page variables to link to for the original and duplicate client lists
    final ClientPageLink dupPageIdentifier = new ClientPageLink();
    final ClientPageLink origPageIdentifier = new ClientPageLink();

    // ConcernRole manipulation variables
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey currentKey = new ConcernRoleKey();

    // ContextDescription manipulation variables
    final ParticipantContextKey participantContextKey = new ParticipantContextKey();

    // ConcernRoleDuplicate manipulation variables
    final ConcernRoleDuplicate concernRoleDuplicateObj = ConcernRoleDuplicateFactory.newInstance();
    ConcernRoleDuplicateDtlsList dupList = new ConcernRoleDuplicateDtlsList();
    final SearchByDuplicateConcernRoleIDKey dupKey = new SearchByDuplicateConcernRoleIDKey();

    // Set key to call BPO operation
    searchTaskForConcernOrCaseKey.details.linkedID = key.concernRoleTasksKey.concernRoleID;

    // Call BPO to return a list of tasks for the participant
    tasksForDupConcernAndCaseDetails.tasksForDuplicateConcern.detailsList = workAllocationTaskObj.listConcernRoleTasks(
      searchTaskForConcernOrCaseKey);

    // Iterate through the list and set the reservedBy flag
    for (int i = 0; i
      < tasksForDupConcernAndCaseDetails.tasksForDuplicateConcern.detailsList.dtls.dtls.size(); i++) {

      if (tasksForDupConcernAndCaseDetails.tasksForDuplicateConcern.detailsList.dtls.dtls.item(i).reservedBy.length()
        > 0) {

        tasksForDupConcernAndCaseDetails.tasksForDuplicateConcern.detailsList.dtls.dtls.item(i).reservedByExistsInd = true;
      }
    }

    // Get original person concern role ID by searching on the duplicate ID
    dupKey.duplicateConcernRoleID = key.concernRoleTasksKey.concernRoleID;
    dupList = concernRoleDuplicateObj.searchByDuplicateConcernRoleID(dupKey);

    // Set the context description key to be the original concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Read the context description
    tasksForDupConcernAndCaseDetails.tasksForDuplicateConcern.contextDescription = readContextDescription(
      participantContextKey);

    // Set the context description key to be the duplicate concern role ID
    participantContextKey.participantContextDescriptionKey.concernRoleID = key.concernRoleTasksKey.concernRoleID;

    // Read the context description
    tasksForDupConcernAndCaseDetails.duplicateContextDesc = readContextDescription(
      participantContextKey);

    // Display the duplicate client role soft links in a tab format

    // Set concernRole
    concernRoleKey.concernRoleID = dupList.dtls.item(0).originalConcernRoleID;

    // Set concernRole to current concernRole
    currentKey.concernRoleID = key.concernRoleTasksKey.concernRoleID;

    // Set page identifiers for user to navigate to
    dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listTaskForDuplicate;
    origPageIdentifier.pageIdentifier = CuramConst.kPerson_listTask;

    // Build up the xml data needed for the tab widget
    tasksForDupConcernAndCaseDetails.tasksForDuplicateConcern.renderXML = clientMergeObj.getDuplicateMenuRendererData(
      concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
    // END, CR00120078

    return tasksForDupConcernAndCaseDetails;
  }
  // END, CR00102618
  // BEGIN, CR00161028, MC

  /*
   * Generic mechanism to combine two different sorts. This Comparator is used
   * when we want to order a list based on two different fields. We define a
   * generic CompositeComparator that combines the logic of two individual
   * Comparators.
   * We refer to the two Comparators as the major and minor comparators.
   * The major comparator has priority over the minor comparator. If the major
   * comparator returns < 0 or > 0, then that result is passed back. The minor
   * comparator's result is used only if the major comparator returns 0
   */
  public class CompositeComparator implements Comparator {
    protected Comparator major;
    protected Comparator minor;
    public CompositeComparator(final Comparator major, final Comparator minor) {
      this.major = major;
      this.minor = minor;
    }

    public CompositeComparator() {// Default constructor
    }

    public int compare(final Object o1, final Object o2) {
      final int result = major.compare(o1, o2);

      if (result != 0) {
        return result;
      } else {
        return minor.compare(o1, o2);
      }
    }

    public void setMajor(final Comparator major) {
      this.major = major;
    }

    public void setMinor(final Comparator minor) {
      this.minor = minor;
    }
  }


  /**
   * Comparator to return the active record as first in the list
   */
  public class AdminRoleStatusComparator implements Comparator {

    public AdminRoleStatusComparator() {
      super();
    }

    public int compare(final Object o1, final Object o2) {

      final MaintainAdminConcernRoleRMDtls role1 = (MaintainAdminConcernRoleRMDtls) o1;
      final MaintainAdminConcernRoleRMDtls role2 = (MaintainAdminConcernRoleRMDtls) o2;

      if (role1.statusCode.equals(ADMINROLESTATUS.ACTIVE)
        && !role2.statusCode.equals(ADMINROLESTATUS.ACTIVE)) {
        return -1;
      } else if (!role1.statusCode.equals(ADMINROLESTATUS.ACTIVE)
        && role2.statusCode.equals(ADMINROLESTATUS.ACTIVE)) {
        return 1;
      } else {
        return 0;
      }
    }
  }


  /**
   * Comparator to sort the admin roles by start date descending
   */
  public class StartDateComparator implements Comparator {

    public StartDateComparator() {
      super();
    }

    public int compare(final Object o1, final Object o2) {

      final MaintainAdminConcernRoleRMDtls role1 = (MaintainAdminConcernRoleRMDtls) o1;
      final MaintainAdminConcernRoleRMDtls role2 = (MaintainAdminConcernRoleRMDtls) o2;

      if (role1.startDate.after(role2.startDate)) {
        return -1;
      } else if (role1.startDate.before(role2.startDate)) {
        return 1;
      } else {
        return 0;
      }
    }
  }

  // BEGIN, CR00175612, SPD
  
  /**
   * Lists the formatted bank account details. The bank details
   * are formatted to display as a single line of text.
   *
   * @param key concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantBankAccountStringList listBankAccountString(
    final curam.core.facade.struct.MaintainConcernRoleKey key)
    throws AppException, InformationalException {

    // Return struct
    final ParticipantBankAccountStringList participantBankAccountStringList = new ParticipantBankAccountStringList();

    // Bank Account maintenance object
    final MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = MaintainConcernRoleBankAcFactory.newInstance();

    // Read list of bank accounts
    final ReadmultiByConcernRoleForNomineeWizardResult bankAcDetailsList = maintainConcernRoleBankAcObj.readmultiByConcernRoleForNomineeWizard(
      key.maintainConcernRoleKey);

    participantBankAccountStringList.bankAcDetails.ensureCapacity(
      bankAcDetailsList.nomineeBankAccountList.dtls.size());

    for (int i = 0; i < bankAcDetailsList.nomineeBankAccountList.dtls.size(); i++) {

      BankAccountRMDtls bankAccountRMDtls = new BankAccountRMDtls();
      final BankAcDetails bankAcDetails = new BankAcDetails();

      // Populate struct for easy reading of code
      bankAccountRMDtls = bankAcDetailsList.nomineeBankAccountList.dtls.item(i);

      bankAcDetails.bankAccountID = bankAccountRMDtls.bankAccountID;
      bankAcDetails.concernRoleBankAccountID = bankAccountRMDtls.concernRoleBankAccountID;
      bankAcDetails.bankAccountString = formatBankAcDetailsString(bankAccountRMDtls).text;

      participantBankAccountStringList.bankAcDetails.addRef(bankAcDetails);
    }

    // Return details
    return participantBankAccountStringList;
  }

  /**
   * Formats the bank account details for a participant. The bank details
   * are formatted to display as a single line of text. The formatting is
   * decided by a system variable.
   *
   * @param bankAccountRMDtls bank account details to be formatted
   *
   * @return Formatted string of bank account details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public BankAccountString formatBankAcDetailsString(
    final BankAccountRMDtls bankAccountRMDtls)
    throws AppException, InformationalException {

    // Return struct
    final BankAccountString bankAccountString = new BankAccountString();

    // Bank manipulation variables
    final Bank bankObj = BankFactory.newInstance();
    final BankBranchKey bankBranchKey = new BankBranchKey();
    BankNameStruct bankNameStruct = new BankNameStruct();

    // BEGIN, CR00176147, SPD
    // Read back formatting pattern for bank account string
    String bankAcFormatString = (Configuration.getProperty(
      EnvVars.ENV_PARTICIPANT_BANKACCOUNTSTRINGFORMAT));

    if (bankAcFormatString == null) {
      bankAcFormatString = (Configuration.getProperty(
        EnvVars.ENV_PARTICIPANT_BANKACCOUNTSTRINGFORMAT_DEFAULT));
    }

    // Copy system variable contents so that codetable values can be replaced
    String copyFormatStr = bankAcFormatString;

    copyFormatStr = copyFormatStr.trim();

    // Determine the bank name
    bankBranchKey.bankBranchID = bankAccountRMDtls.bankBranchID;
    bankNameStruct = bankObj.readBankNameByBankBranchID(bankBranchKey);

    // Determine the description for the account type
    final String accountTypeDesc = CodeTable.getOneItem(
      BANKACCOUNTTYPE.TABLENAME, bankAccountRMDtls.typeCode);

    final Map<String, String> bankAcMap = new HashMap<String, String>();

    bankAcMap.put(BANKACCOUNTFORMAT.ACCOUNTNAME, bankAccountRMDtls.name);
    bankAcMap.put(BANKACCOUNTFORMAT.ACCOUNTNUMBER,
      bankAccountRMDtls.accountNumber);
    bankAcMap.put(BANKACCOUNTFORMAT.ACCOUNTTYPE, accountTypeDesc);
    bankAcMap.put(BANKACCOUNTFORMAT.BANKNAME, bankNameStruct.bankName);
    bankAcMap.put(BANKACCOUNTFORMAT.BANKBRANCHNAME,
      bankAccountRMDtls.bankBranchName);
    bankAcMap.put(BANKACCOUNTFORMAT.SORTCODE, bankAccountRMDtls.bankSortCode);

    // Replace all codetable values with actual values. This allows for
    // formatting introduced by the user to remain
    for (final String ctValue: bankAcMap.keySet()) {

      if (copyFormatStr.contains(ctValue)) {
        copyFormatStr = copyFormatStr.replaceAll(ctValue,
          bankAcMap.get(ctValue));
      }
    }

    bankAccountString.text = copyFormatStr;
    // END, CR00176147

    return bankAccountString;
  }

  // BEGIN, CR00218851, ZV
  // BEGIN, CR00233791, DJ
  // BEGIN, CR00290965, IBM
  /**
   * Searches for all Participants by specified search criteria.
   *
   * @param key Participant search criteria
   *
   * @return Participant details found
   *
   * @throws InformationalException Informational Exception
   *
   * @deprecated Since Curam 6.0 SP2, replaced with {@link
   * Participant#searchParticipantDetails(AllParticipantSearchKey)}
   *
   * This method is deprecated as informational messages are not returned. This
   * method is replaced by searchParticipantDetails(AllParticipantSearchKey)
   * which returns the informational message along with participant details
   * as well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public AllParticipantSearchResult searchParticipant(
    final AllParticipantSearchKey key)
    throws AppException, InformationalException {
    // END, CR00290965

    final ParticipantSearchRouter participantSearchRouterObj = ParticipantSearchRouterFactory.newInstance();

    final AllParticipantSearchResult participantSearchResult = new AllParticipantSearchResult();

    participantSearchResult.dtls = participantSearchRouterObj.searchAll(key.key);

    return participantSearchResult;
  }

  // END, CR00233791
  // END, CR00218851


  // BEGIN, CR00222438, MC
  
  /**
   * Lists all communications by case ID.
   *
   * @param key Contains the case identifier.
   * @return List of communications on the case.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public CommunicationDetailList listCommunication(
    final ParticipantCommunicationKey key) throws AppException,
      InformationalException {

    final CommunicationDetailList communicationDetailList = new CommunicationDetailList();
    // BEGIN, CR00399621, KRK
    final ReadProFormaCommKey readProFormaCommKey = new ReadProFormaCommKey();
    // END, CR00399621

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj = curam.core.sl.fact.CommunicationFactory.newInstance();

    // Call service layer method to list a participants communications.
    final CommunicationDetailsList communicationDtlsList = communicationObj.listCommunication(
      key.participantCommKey);

    // Assign the details returned to a new struct that also contains the
    // display indicators and fields required for the actions
    String communicationFormat = "";
    CommunicationAndListRowActionDetails communicationDtls;

    // BEGIN, CR00294269, IBM
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.participantCommKey.concernRoleID;
    CuramInd duplicateInd = isParticipantDuplicate(concernRoleKey);

    for (final ConcernRoleCommRMDtls concernRoleCommRMDtls :
      communicationDtlsList.concernRoleCommList.dtls.items()) {
      // END, CR00294269

      communicationDtls = new CommunicationAndListRowActionDetails();

      // BEGIN, CR00294269, IBM
      communicationDtls.assign(concernRoleCommRMDtls);

      // BEGIN, CR00303767, IBM
      communicationDtls.duplicateAndCancelIndOpt = duplicateInd.statusInd;
      // END, CR00303767

      if (RECORDSTATUS.CANCELLED.equals(communicationDtls.statusCode)) {
        // END, CR00294269
        communicationDtls.canceledInd = true;

        // BEGIN, CR00303767, IBM
        // BEGIN, CR00399621, KRK
        if (COMMUNICATIONFORMAT.MSWORD.equals(
          communicationDtls.communicationFormat)) {
          communicationDtls.msWordInd = true;
        
        } else if (COMMUNICATIONFORMAT.PROFORMA.equals(
          communicationDtls.communicationFormat)) {        
          readProFormaCommKey.proFormaCommKey.communicationID = communicationDtls.communicationID;
          communicationDtls.localeIdentifier = CommunicationFactory.newInstance().readProForma1(readProFormaCommKey).readProFormaCommDetails.localeIdentifier;
        }
        // END, CR00399621
        // END, CR00303767

      } else {
        communicationFormat = communicationDtls.communicationFormat;

        // BEGIN, CR00294269, IBM
        if (COMMUNICATIONFORMAT.EMAIL.equals(communicationFormat)
          && COMMUNICATIONSTATUS.DRAFT.equals(
            communicationDtls.communicationStatus)) {
          // END, CR00294269

          communicationDtls.draftEmailInd = true;

          // BEGIN, CR00294269, IBM
        } else if (COMMUNICATIONFORMAT.MSWORD.equals(communicationFormat)) {
          // END, CR00294269
          communicationDtls.msWordInd = true;

          final AttachmentLinkKey attachmentLinkKey = new AttachmentLinkKey();

          attachmentLinkKey.attachmentLinkID = communicationDtls.communicationID;

          AttachmentLinkDetails attachmentLinkDetails;

          try {
            attachmentLinkDetails = AttachmentFactory.newInstance().readAttachment(
              attachmentLinkKey);

            communicationDtls.attachmentDtls.attachmentName = attachmentLinkDetails.attachmentDtls.attachmentName;
            communicationDtls.attachmentDtls.attachmentContents = attachmentLinkDetails.attachmentDtls.attachmentContents;

          } catch (final RecordNotFoundException rnfe) {// Do nothing there are no attachments associated with this
            // communication
          }

          // BEGIN, CR00294269, IBM
        } else if (COMMUNICATIONFORMAT.PROFORMA.equals(communicationFormat)) {
          // END, CR00294269

          communicationDtls.proFormaInd = true;         
          // BEGIN, CR00399621, KRK
          readProFormaCommKey.proFormaCommKey.communicationID = communicationDtls.communicationID;
          communicationDtls.localeIdentifier = CommunicationFactory.newInstance().readProForma1(readProFormaCommKey).readProFormaCommDetails.localeIdentifier;
        }       
      }
      // Get the delete page link
      communicationDtls.deletePage.deletePageName = curam.core.facade.fact.CommunicationFactory.newInstance().getDeletePageName(communicationDtls).deletePageName;
      // END, CR00399621
      // Add this list item to the return struct
      communicationDetailList.communicationDtls.addRef(communicationDtls);
    }
    // BEGIN, CR00221607, MC
    // Display the duplicate soft link
    if (Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_CLIENT_MERGE_SOFTLINKS_ENABLED)) {

      // BEGIN, CR00102618, CSH
      // ClientMerge manipulation variables
      final curam.core.facade.intf.ClientMerge clientMergeObj = curam.core.facade.fact.ClientMergeFactory.newInstance();
      final curam.core.sl.intf.ClientMerge clientMergeSLObj = curam.core.sl.fact.ClientMergeFactory.newInstance();

      // END, CR00102618

      // BEGIN, CR00102618, CSH
      concernRoleKey.concernRoleID = key.participantCommKey.concernRoleID;

      // set the pages to link to for the original and duplicate client lists
      final ClientPageLink dupPageIdentifier = new ClientPageLink();
      final ClientPageLink origPageIdentifier = new ClientPageLink();

      dupPageIdentifier.pageIdentifier = CuramConst.kPerson_listCommunicationForDuplicate;
      origPageIdentifier.pageIdentifier = CuramConst.kPerson_listCommunication;

      // BEGIN, CR00102900, CSH
      // Display the duplicate soft links in a tab format

      // Set value of currently selected concern
      final ConcernRoleKey currentKey = new ConcernRoleKey();

      currentKey.concernRoleID = concernRoleKey.concernRoleID;

      // Build up the xml data needed for the tab widget
      communicationDetailList.renderXML = clientMergeObj.getDuplicateMenuRendererData(
        concernRoleKey, currentKey, dupPageIdentifier, origPageIdentifier);
      // END, CR00102900

      // Set an indicator if this concern has duplicates
      // Check for duplicates
      final ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey = new
        ConcernRoleIDStatusCodeKey();

      concernRoleIDStatusCodeKey.concernRoleID = concernRoleKey.concernRoleID;
      concernRoleIDStatusCodeKey.statusCode = DUPLICATESTATUS.UNMARKED;
      communicationDetailList.clientMergeInd = clientMergeSLObj.isConcernRoleOriginalClient(
        concernRoleIDStatusCodeKey);
      // END, CR00102618
    }
    // END, CR00221607

    return communicationDetailList;
  }

  // END, CR00161028

  // BEGIN, CR00224677, ZV
  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains bank account id and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public BankAccountListForRedirectionDetails listActiveBankAccountForRedirection1(
    final ParticipantBankAccountRedirectionKey1 key)
    throws AppException, InformationalException {

    // return structure
    final BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails = new BankAccountListForRedirectionDetails();

    final ReadParticipantBankAccountListKey readParticipantBankAccountListKey = new ReadParticipantBankAccountListKey();

    ReadActiveBankAccountList readActiveBankAccountList;

    readParticipantBankAccountListKey.maintainBankAccountKey = key.maintainBankAccountKey;

    // retrieve list of accounts and context description
    readActiveBankAccountList = listActiveBankAccount(
      readParticipantBankAccountListKey);

    for (int i = 0; i
      < readActiveBankAccountList.dtls.nomineeBankAccountList.dtls.size(); i++) {

      if (readActiveBankAccountList.dtls.nomineeBankAccountList.dtls.item(i).bankAccountID
        == key.bankAccountID) {

        readActiveBankAccountList.dtls.nomineeBankAccountList.dtls.remove(i);
      }
    }

    bankAccountListForRedirectionDetails.dtls = readActiveBankAccountList.dtls;
    
    // BEGIN, CR00371769, VT
    // Bank Account values should be displayed based on following logic
    // 1. If IBAN is entered, Bank Account field will populate the IBAN.
    // 2. If Basic Bank Account Number (BBAN) is entered, Bank Account field
    // will populate the BBAN.
    // 3. If IBAN and BBAN are entered, Bank Account field will populate the
    // IBAN value.

    for (final BankAccountRMDtls bankAccountRMDtls : bankAccountListForRedirectionDetails.dtls.nomineeBankAccountList.dtls) {
      if (0 != bankAccountRMDtls.ibanOpt.length()) {
        bankAccountRMDtls.bankAccountNumberOpt = bankAccountRMDtls.ibanOpt;
      } else {
        bankAccountRMDtls.bankAccountNumberOpt = bankAccountRMDtls.accountNumber; 
      }
    }
    // END, CR00371769
    bankAccountListForRedirectionDetails.contextDescription = readActiveBankAccountList.contextDescription;

    // BEGIN, CR00229497, ZV
    final LocalisableString redirectionContext = new LocalisableString(
      curam.message.BPOPARTICIPANT.INF_BANKACCOUNT_REDIRECTION_CONTEXT_1);

    // END, CR00229497

    // BEGIN, CR00163236, CL
    bankAccountListForRedirectionDetails.redirectionDescription.description = redirectionContext.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163236

    return bankAccountListForRedirectionDetails;
  }

  // END, CR00224677


  // BEGIN, CR00231961, ZV
  /**
   * Create a new bank account for a participant.
   *
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public CreateParticipantBankAccountDetails createBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    final curam.core.intf.MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = curam.core.fact.MaintainConcernRoleBankAcFactory.newInstance();
    final MaintainBankAccountKey maintainBankAccountKey = new MaintainBankAccountKey();

    final CreateParticipantBankAccountDetails createParticipantBankAccountDetails = new CreateParticipantBankAccountDetails();

    final BankAccountDetails bankAccountDetails = new BankAccountDetails();

    maintainBankAccountKey.concernRoleID = details.participantBankAccountDetails.concernRoleID;

    bankAccountDetails.assign(details.participantBankAccountDetails);
    bankAccountDetails.bankSortCode = details.bankSortCode;
    // BEGIN, CR00371769, VT
    bankAccountDetails.bicOpt = details.bicOpt;
    // END, CR00371769

    createParticipantBankAccountDetails.informationalMsgDtlsList = maintainConcernRoleBankAcObj.createBankAccount(
      maintainBankAccountKey, bankAccountDetails);

    return createParticipantBankAccountDetails;
  }

  /**
   * Modify the bank account details for a participant.
   *
   * @param details
   * The bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public InformationMsgDtlsList modifyBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    final curam.core.intf.MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = curam.core.fact.MaintainConcernRoleBankAcFactory.newInstance();
    final MaintainBankAccountKey maintainBankAccountKey = new MaintainBankAccountKey();

    final BankAccountDetails bankAccountDetails = new BankAccountDetails();

    maintainBankAccountKey.concernRoleID = details.participantBankAccountDetails.concernRoleID;

    bankAccountDetails.assign(details.participantBankAccountDetails);
    bankAccountDetails.bankSortCode = details.bankSortCode;
    // BEGIN, CR00371769, VT
    bankAccountDetails.bicOpt = details.bicOpt;
    // END, CR00371769

    maintainConcernRoleBankAcObj.modifyBankAccount(maintainBankAccountKey,
      bankAccountDetails);

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // Return all messages from the evidence Controller.
    final EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final ECWarningsDtlsList ecWarningsDtlsList = evidenceControllerObj.getWarnings();

    for (int i = 0; i < ecWarningsDtlsList.dtls.size(); i++) {
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = ecWarningsDtlsList.dtls.item(i).msg;
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // END, CR00231961

  // BEGIN, CR00285272, ZV
  /**
   * Return address region details list for default address layout.
   *
   *
   * @return Address region details list.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public AddressRegionDetailsList getAddressRegionList() throws AppException,
      InformationalException {

    return ParticipantSearchFactory.newInstance().getAddressRegionList();
  }

  // END, CR00285272

  // BEGIN, CR00289903, ZV
  /**
   * Returns true if participant is marked as duplicate.
   *
   * @param key Concern role key to determine if participant is duplicate.
   *
   * @return Boolean value depending on duplicate participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Override
  public CuramInd isParticipantDuplicate(ConcernRoleKey key)
    throws AppException, InformationalException {

    ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    return clientMergeObj.isConcernRoleDuplicate(key);
  }

  // END, CR00289903

  // BEGIN, CR00290965, IBM
  /**
   * Searches for all participants by specified search criteria.
   *
   * @param allParticipantSearchKey contains all participant search key
   *
   * @return participant search details
   *
   * @throws AppException Application Exception
   * @throws InformationalException Informational Exception
   */
  public AllParticipantSearchDetails searchParticipantDetails(
    final AllParticipantSearchKey allParticipantSearchKey) throws AppException, InformationalException {

    ParticipantSearchRouter participantSearchRouter = ParticipantSearchRouterFactory.newInstance();

    AllParticipantSearchDetails allParticipantSearchDetails = new AllParticipantSearchDetails();

    allParticipantSearchDetails.dtls = participantSearchRouter.searchAll(
      allParticipantSearchKey.key);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] infos = informationalManager.obtainInformationalAsString();

    for (String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      allParticipantSearchDetails.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }

    return allParticipantSearchDetails;
  }

  // END, CR00290965

  // BEGIN, CR00306021, LB
  /**
   * Searches person and prospect person based on the search criteria.
   *
   * @param personAndProspectPersonkey contains all participant search key
   *
   * @return
   * PersonAndProspectPersonSearchDetails, contains participant search results
   *
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  public PersonAndProspectPersonSearchDetails listPersonAndProspectPerson(
    SearchPersonAndProspectPersonKey personAndProspectPersonkey) throws AppException, InformationalException {

    DatabaseParticipantSearch databaseParticipantSearch = DatabaseParticipantSearchFactory.newInstance();

    PersonAndProspectPersonSearchDetails personAndProspectPersonSearchDetails = new PersonAndProspectPersonSearchDetails();

    curam.core.sl.struct.SearchPersonAndProspectPersonKey personKey = new curam.core.sl.struct.SearchPersonAndProspectPersonKey();

    personAndProspectPersonkey.assign(personKey);

    personAndProspectPersonSearchDetails.dtls = databaseParticipantSearch.searchPersonAndProspectPerson(
      personKey);

    return personAndProspectPersonSearchDetails;

  }

  // END, CR00306021
  // BEGIN, CR00320919, DJ
  /**
   * Lists the details of the contacts for a participant. The name will be listed
   * in the format, contact name (contact type).
   *
   * @param listContactKey Contains the participant concern role ID.
   *
   * @return the details of the participant contacts.
   *
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  public ListConcernContactDetails listConcernContactsForCommunication(
    final ListContactKey listContactKey) throws AppException, InformationalException {

    final ListConcernContactDetails listConcernContactDetails = listConcernContact(
      listContactKey);
    // BEGIN, CR00341363, DJ
    String contactType = null;

    // END, CR00341363

    for (final ConcernContactRMultiDtls concernContactRMultiDtls: listConcernContactDetails.concernContactRMultiDtlsList.dtls) {
      // BEGIN, CR00341363, DJ
      if (0 != concernContactRMultiDtls.contactTypeCode.length()) {
        contactType = CodetableUtil.getCodetableDescription(
          CONTACTTYPE.TABLENAME, concernContactRMultiDtls.contactTypeCode);
      } else {
        contactType = CodetableUtil.getCodetableDescription(
          CONTACTTYPE.TABLENAME,
          concernContactRMultiDtls.companyContactTypeCode);
      }
      // END, CR00341363
      concernContactRMultiDtls.name = concernContactRMultiDtls.name.concat(CuramConst.gkEmpty).concat("(").concat(contactType).concat(
        ")");
    }
    return listConcernContactDetails;
  }  

  // END, CR00320919
  
  // BEGIN, CR00371769, VT
  /**
   * Reads the international bank account number application property value.
   *
   * @return InternationalBankAccountIndicator Contains the international bank
   * account number application property value.
   *
   * @throws InformationalException
   * Generic Exception Signature
   * @throws AppException
   * Generic Exception Signature
   */
  public InternationalBankAccountIndicator readIban() throws AppException,
      InformationalException {

    final InternationalBankAccountIndicator internationalBankAccountIndicator = new InternationalBankAccountIndicator();

    internationalBankAccountIndicator.ibanInd = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_ENABLE_IBAN_FUNCTIONALITY);

    return internationalBankAccountIndicator;
  }
  // END, CR00371769

}

