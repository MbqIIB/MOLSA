/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.ArrayList;

import org.apache.log4j.Logger;

import curam.core.sl.entity.struct.RateCellByColumnIDKey;
import curam.core.sl.entity.struct.RateCellDtls;
import curam.core.sl.entity.struct.RateCellDtlsList;
import curam.core.sl.entity.struct.RateCellReadmultiKey1;
import curam.core.sl.entity.struct.RateCellSearchByHeaderIDIn;
import curam.core.sl.entity.struct.RateCellValue;
import curam.core.sl.entity.struct.RateColumnDtls;
import curam.core.sl.entity.struct.RateColumnDtlsList;
import curam.core.sl.entity.struct.RateColumnSearchByHeaderIDIn;
import curam.core.sl.entity.struct.RateHeaderByTableTypeStatusKey;
import curam.core.sl.entity.struct.RateHeaderDtls;
import curam.core.sl.entity.struct.RateHeaderDtlsList;
import curam.core.sl.entity.struct.RateRowDtls;
import curam.core.sl.entity.struct.RateRowDtlsList;
import curam.core.sl.entity.struct.RateRowSearchByHeaderIDIn;
import curam.core.sl.entity.struct.ReadValueByColumnAndRowKey;
import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * @see curam.core.intf.CachedRateTable
 */
public abstract class CachedRateTable extends curam.core.base.CachedRateTable {

  protected static ThreadLocal cachedRateHeaderList = new ThreadLocal();

  // ___________________________________________________________________________

  // BEGIN, CR00023323, CR00051622, SK
  // Logger for the caching output
  public static final String kBatchCachingCategory = Trace.kDefaultTraceCategory
    + ExtensionConst.kBatchCachingCategory;

  public static final Logger kBatchLauncherCacheLogger = Logger.getLogger(
    kBatchCachingCategory);

  // END, CR00023323,CR00051622

  public static final boolean logging;

  public static int kBufferSize;

  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;

  // ___________________________________________________________________________
  static {

    cachingEnabled = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);

    // static to hold the logging_enabled environmental variable
    String logging_enabled = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED);

    if (logging_enabled == null) {
      logging_enabled = EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED_DEFAULT;
    }

    if (logging_enabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      logging = true;

    } else {
      logging = false;
    }

    // static to hold the kBufferSize environmental variable
    String bufferSizeStr = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_BATCH_PROCESS_CACHE_BUFFERSIZE);

    if (bufferSizeStr == null) {

      bufferSizeStr = curam.core.impl.EnvVars.ENV_BATCH_PROCESS_CACHE_BUFFERSIZE_DEFAULT;

    }

    try {
      kBufferSize = Integer.parseInt(bufferSizeStr);
    } catch (NumberFormatException e) {//
    }

  }

  // ___________________________________________________________________________
  /**
   * class used to cache the RateHeader details, the columns and rows for the
   * headerID and a 2-d array with the rateCells
   *
   */
  class RateHeaderCache {

    RateHeaderDtls rateHeaderDtls = new RateHeaderDtls();

    RateColumnDtlsList rateColumnDtlsList = new RateColumnDtlsList();

    RateRowDtlsList rateRowDtlsList = new RateRowDtlsList();

    RateCellValue[][] rateCells = new RateCellValue[0][0];
  }


  // ___________________________________________________________________________
  /**
   * class used to cache the list and the key used
   *
   */
  class RateHeaderCacheListRecord {

    ArrayList<RateHeaderCache> rateHeaderCacheList = new ArrayList<RateHeaderCache>();

    // BEGIN, CR00049218, GM
    String rateStatus = CuramConst.gkEmpty;

    String rateTableType = CuramConst.gkEmpty;
    // END, CR00049218
  }


  // ___________________________________________________________________________
  /**
   * class to provide comparator and clear operation for
   * RateHeaderCacheListRecord
   *
   */
  class RateHeaderCacheListBuffer extends CircularBuffer {

    /**
     * Constructor
     *
     */
    public RateHeaderCacheListBuffer() {

      super(kBufferSize);

    }

    // _________________________________________________________________________
    /**
     * method providing comparison between instances of the class
     *
     * @param o1
     * reference to first Object for comparison
     * @param o2
     * reference to second Object for comparison
     *
     * @return if contents of objects are equivalent, false otherwise
     */
    public boolean itemsEqual(Object o1, Object o2) {

      RateHeaderCacheListRecord rateHeaderCacheListRecord1 = (RateHeaderCacheListRecord) o1;
      RateHeaderCacheListRecord rateHeaderCacheListRecord2 = (RateHeaderCacheListRecord) o2;

      return (rateHeaderCacheListRecord1.rateTableType.equals(
        rateHeaderCacheListRecord2.rateTableType)
          && rateHeaderCacheListRecord1.rateStatus.equals(
            rateHeaderCacheListRecord2.rateStatus));
    }

    // _________________________________________________________________________
    /**
     * method providing facility to restore data members to default values
     *
     * @param o
     * reference to Object to be cleared
     */
    public void clearItem(Object o) {

      RateHeaderCacheListRecord rateHeaderCacheListRecord = (RateHeaderCacheListRecord) o;

      // BEGIN, CR00049218, GM
      rateHeaderCacheListRecord.rateTableType = CuramConst.gkEmpty;
      rateHeaderCacheListRecord.rateStatus = CuramConst.gkEmpty;
      // END, CR00049218
    }
  }


  // ___________________________________________________________________________
  /**
   * class used to cache the circular buffer and transactionID
   *
   */
  class RateHeaderCacheRecord {

    RateHeaderCacheListBuffer rateHeaderCacheListBuffer = new RateHeaderCacheListBuffer();

    int transactionID = 0;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RateCellValue readValueByColumnAndRow(ReadValueByColumnAndRowKey key)
    throws AppException, InformationalException {

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    // List to hold the cached records
    ArrayList rateHeaderCacheList = null;

    // The return struct
    RateCellValue rateCellValue = new RateCellValue();

    boolean reloadCache = true;

    // If this is a batch transaction or deferred processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    if ((transactionType.equals(TransactionType.kBatch)
      || transactionType.equals(TransactionType.kDeferred)
      || (transactionType.equals(TransactionType.kOnline)
        && curam.util.resources.Configuration.getBooleanProperty(
          EnvVars.ENV_ONLINE_CACHING_ENABLED)))
            && cachingEnabled) {

      RateHeaderCacheRecord rateHeaderCacheRecord = (RateHeaderCacheRecord) cachedRateHeaderList.get();

      if (rateHeaderCacheRecord != null) {

        RateHeaderCacheListBuffer rateHeaderCacheListBuffer = rateHeaderCacheRecord.rateHeaderCacheListBuffer;

        // if this is a deferred, batch or online transaction, we must also
        // check
        // that the transaction numbers match
        if (rateHeaderCacheListBuffer != null
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kBatch)
            || transactionType.equals(TransactionType.kOnline))
            && rateHeaderCacheRecord.transactionID
              != TransactionInfo.getIdentifierForThisThread()) {

          rateHeaderCacheListBuffer = null;
        }

        if (rateHeaderCacheListBuffer != null) {

          // Try to find the data in the cache
          RateHeaderCacheListRecord searchKey = new RateHeaderCacheListRecord();
          RateHeaderCacheListRecord foundRecord;

          searchKey.rateTableType = key.rateTableType;
          searchKey.rateStatus = key.rateStatus;

          foundRecord = (RateHeaderCacheListRecord) rateHeaderCacheListBuffer.find(
            searchKey);

          if (foundRecord != null) {

            rateHeaderCacheList = foundRecord.rateHeaderCacheList;
            // found so no need to reload the data
            reloadCache = false;

          }// not in cache so read the data
        }// no records in the buffer
      }

      RateHeaderCache rateHeaderCache;
      RateColumnDtlsList rateColumnDtlsList;
      RateRowDtlsList rateRowDtlsList;
      RateCellValue[][] rateCells;
      RateColumnDtls rateColumnDtls;
      RateRowDtls rateRowDtls;
      RateCellDtls rateCellDtls;
      RateCellValue rateCellCacheValue;

      // load the RateCells into the cache
      // RELOADCACHE
      if (reloadCache) {

        curam.core.sl.entity.intf.RateCell rateCellObj = curam.core.sl.entity.fact.RateCellFactory.newInstance();

        RateHeaderDtlsList rateHeaderDtlsList = reloadRateHeaderDtlsList(key);

        // record to store in the buffer
        RateHeaderCacheListRecord rateHeaderCacheListRecord = new RateHeaderCacheListRecord();

        rateHeaderCacheListRecord.rateStatus = key.rateStatus;
        rateHeaderCacheListRecord.rateTableType = key.rateTableType;

        for (int i = rateHeaderDtlsList.dtls.size(); --i >= 0;) {
          RateHeaderDtls rateHeaderDtls = rateHeaderDtlsList.dtls.item(i);

          // obtain the RateHeaderCache records for
          // rateHeaderCacheListRecord.rateHeaderCacheList
          rateHeaderCache = new RateHeaderCache();
          rateHeaderCache.rateHeaderDtls.assign(rateHeaderDtls);

          rateColumnDtlsList = searchRateColumn(rateHeaderDtls);
          rateRowDtlsList = searchRateRow(rateHeaderDtls);

          rateRowDtlsList.dtls.trimToSize();
          rateColumnDtlsList.dtls.trimToSize();
          int numberOfRows = rateRowDtlsList.dtls.size();
          int numberOfColumns = rateColumnDtlsList.dtls.size();

          // ensureCapacity();
          rateHeaderCache.rateColumnDtlsList.dtls.ensureCapacity(
            numberOfColumns);
          rateHeaderCache.rateRowDtlsList.dtls.ensureCapacity(numberOfRows);

          // assign
          rateHeaderCache.rateColumnDtlsList.assign(rateColumnDtlsList);
          rateHeaderCache.rateRowDtlsList.assign(rateRowDtlsList);

          // RELOAD RATECELLS
          // 2-d array to hold the rateCells
          rateCells = new RateCellValue[numberOfRows][numberOfColumns];

          // load the rate cells for this rate header
          RateCellSearchByHeaderIDIn headerIDKey = new RateCellSearchByHeaderIDIn();

          headerIDKey.rateHeaderID = rateHeaderDtls.rateHeaderID;
          RateCellDtlsList rateCellDtlsList = rateCellObj.searchByHeaderID(
            headerIDKey);

          rateCellDtlsList.dtls.trimToSize();

          // build the matrix
          // (not the most efficient way to do it...)
          for (int col = 0; col < numberOfColumns; col++) {

            rateColumnDtls = rateColumnDtlsList.dtls.item(col);

            for (int row = 0; row < numberOfRows; row++) {

              rateRowDtls = rateRowDtlsList.dtls.item(row);

              boolean found = false;

              // find a matching cell for the column and for the
              // row
              for (int cell = rateCellDtlsList.dtls.size(); --cell >= 0
                && !found;) {

                rateCellDtls = rateCellDtlsList.dtls.item(cell);
                if (rateCellDtls.rateRowID == rateRowDtls.rateRowID
                  && rateCellDtls.rateColumnID == rateColumnDtls.rateColumnID) {

                  rateCellCacheValue = new RateCellValue();
                  rateCellCacheValue.rateCellID = rateCellDtls.rateCellID;
                  rateCellCacheValue.rateCellValue = rateCellDtls.rateCellValue;

                  // populate the 2-d array rateCells
                  // use the index of the column and row
                  // BEGIN CR00051407, GSP
                  // BEGIN HARP, 67065, PN
                  rateCells[row][col] = rateCellCacheValue;
                  // END HARP,67065
                  // END, CR00051407
                  found = true;
                }
              }
            }
          }// END RELOAD RATE CELLS

          rateHeaderCache.rateCells = rateCells;
          rateHeaderCacheListRecord.rateHeaderCacheList.add(rateHeaderCache);

        }// end iteration on rateHeaderDtlsList

        rateHeaderCacheListRecord.rateHeaderCacheList.trimToSize();
        rateHeaderCacheList = rateHeaderCacheListRecord.rateHeaderCacheList;

        // insert the RateHeaderCacheListRecord into the cache
        RateHeaderCacheRecord newRateHeaderCacheRecord = null;
        Object obj = cachedRateHeaderList.get();

        if (obj == null) {
          newRateHeaderCacheRecord = new RateHeaderCacheRecord();
          cachedRateHeaderList.set(newRateHeaderCacheRecord);
        }

        newRateHeaderCacheRecord = (RateHeaderCacheRecord) cachedRateHeaderList.get();

        RateHeaderCacheListBuffer rateHeaderCacheListBuffer = newRateHeaderCacheRecord.rateHeaderCacheListBuffer;

        rateHeaderCacheListBuffer.insert(rateHeaderCacheListRecord);

        newRateHeaderCacheRecord.rateHeaderCacheListBuffer = rateHeaderCacheListBuffer;
        newRateHeaderCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();

        cachedRateHeaderList.set(newRateHeaderCacheRecord);

      }// END RELOADCACHE

      if (rateHeaderCacheList == null) {
        rateHeaderCacheList = new ArrayList();
      }

      // find the records where effectiveDate <= to the key's effectiveDate
      // find the RateHeaderDtls record with the max effectiveDate

      RateHeaderDtls maxRateHeaderDtls = new RateHeaderDtls();

      for (int i = rateHeaderCacheList.size(); --i >= 0;) {

        rateHeaderCache = (RateHeaderCache) rateHeaderCacheList.get(i);

        if (rateHeaderCache.rateHeaderDtls.effectiveDate.compareTo(
          key.effectiveDate)
            <= 0) {
          if (rateHeaderCache.rateHeaderDtls.effectiveDate.after(
            maxRateHeaderDtls.effectiveDate)) {
            maxRateHeaderDtls = rateHeaderCache.rateHeaderDtls;
          }
        }
      }

      // find the records where the keys effectiveDate =
      // maxRateHeaderDtls.effectiveDate
      for (int i = rateHeaderCacheList.size(); --i >= 0;) {

        rateHeaderCache = (RateHeaderCache) rateHeaderCacheList.get(i);

        if (rateHeaderCache.rateHeaderDtls.effectiveDate.equals(
          maxRateHeaderDtls.effectiveDate)) {

          rateColumnDtlsList = rateHeaderCache.rateColumnDtlsList;
          rateRowDtlsList = rateHeaderCache.rateRowDtlsList;

          int columnIndex = -1, rowIndex = -1;

          // search through the columns for the record where
          // columnType = key.rateColumnType and find its index
          // BEGIN CR00051407, GSP
          // BEGIN, HARP 67065, PN
          for (int col = rateColumnDtlsList.dtls.size(); col > 0;) {
            if (rateColumnDtlsList.dtls.item(--col).rateColumnType.equals(
              key.rateColumnType)) {
              columnIndex = col;
              break;
            }

          }
          // find the rowIndex of the Row with a rowType = key.rateRowType
          for (int row = rateRowDtlsList.dtls.size(); row > 0;) {
            if (rateRowDtlsList.dtls.item(--row).rateRowType.equals(
              key.rateRowType)) {
              rowIndex = row;
              break;
            }

          }

          // Using the row and column index above we can locate the object in
          // the rateCells array
          if (columnIndex >= 0 && rowIndex >= 0) {

            rateCellValue.assign(
              rateHeaderCache.rateCells[rowIndex][columnIndex]);

            return rateCellValue;
          }
          // END HARP, 67065
          // END, CR00051407
        }// end comparison with maxRateHeaderDtls.effectiveDate

      }

    }// Caching is not in use so read the data from the entity

    curam.core.sl.entity.intf.RateCell rateCellObj = curam.core.sl.entity.fact.RateCellFactory.newInstance();

    // Create and populate the key to read the rate table item
    ReadValueByColumnAndRowKey readValueByColumnAndRowKey = new ReadValueByColumnAndRowKey();

    readValueByColumnAndRowKey.rateRowType = key.rateRowType;
    readValueByColumnAndRowKey.rateTableType = key.rateTableType;
    readValueByColumnAndRowKey.rateColumnType = key.rateColumnType;
    readValueByColumnAndRowKey.effectiveDate = key.effectiveDate;
    readValueByColumnAndRowKey.rateStatus = key.rateStatus;

    // Read the rate table cell from the entity
    rateCellValue = rateCellObj.readValueByColumnAndRow(
      readValueByColumnAndRowKey);

    return rateCellValue;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RateHeaderDtlsList reloadRateHeaderDtlsList(
    ReadValueByColumnAndRowKey key) throws AppException,
      InformationalException {

    RateHeaderDtlsList rateHeaderDtlsList;

    // RateHeader manipulation variables
    curam.core.sl.entity.intf.RateHeader rateHeaderObj = curam.core.sl.entity.fact.RateHeaderFactory.newInstance();

    RateHeaderByTableTypeStatusKey rateHeaderByTableTypeStatusKey = new RateHeaderByTableTypeStatusKey();

    rateHeaderByTableTypeStatusKey.rateTableType = key.rateTableType;
    rateHeaderByTableTypeStatusKey.rateStatus = key.rateStatus;

    rateHeaderDtlsList = rateHeaderObj.searchByRateTableTypeStatus(
      rateHeaderByTableTypeStatusKey);

    rateHeaderDtlsList.dtls.trimToSize();
    return rateHeaderDtlsList;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void clearCache() throws AppException, InformationalException {

    cachedRateHeaderList.set(null);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RateColumnDtlsList searchRateColumn(RateHeaderDtls rateHeaderDtls)
    throws AppException, InformationalException {
    // RateColumn manipulation variables
    curam.core.sl.entity.intf.RateColumn rateColumnObj = curam.core.sl.entity.fact.RateColumnFactory.newInstance();

    RateColumnSearchByHeaderIDIn rateColumnSearchByHeaderIDIn = new RateColumnSearchByHeaderIDIn();

    rateColumnSearchByHeaderIDIn.rateHeaderID = rateHeaderDtls.rateHeaderID;

    RateColumnDtlsList rateColumnDtlsList = rateColumnObj.searchByHeaderID(
      rateColumnSearchByHeaderIDIn);

    rateColumnDtlsList.dtls.trimToSize();

    return rateColumnDtlsList;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RateRowDtlsList searchRateRow(RateHeaderDtls rateHeaderDtls)
    throws AppException, InformationalException {
    // RateRow manipulation variables
    curam.core.sl.entity.intf.RateRow rateRowObj = curam.core.sl.entity.fact.RateRowFactory.newInstance();

    RateRowSearchByHeaderIDIn rateRowSearchByHeaderIDIn = new RateRowSearchByHeaderIDIn();

    rateRowSearchByHeaderIDIn.rateHeaderID = rateHeaderDtls.rateHeaderID;

    RateRowDtlsList rateRowDtlsList = rateRowObj.searchByHeaderID(
      rateRowSearchByHeaderIDIn);

    rateRowDtlsList.dtls.trimToSize();

    return rateRowDtlsList;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RateCellDtlsList searchRateCellByColumn(RateColumnDtls rateColumnDtls)
    throws AppException, InformationalException {

    RateCellByColumnIDKey rateCellByColumnIDKey = new RateCellByColumnIDKey();

    rateCellByColumnIDKey.rateColumnID = rateColumnDtls.rateColumnID;

    // RateCell manipulation variables
    curam.core.sl.entity.intf.RateCell rateCellObj = curam.core.sl.entity.fact.RateCellFactory.newInstance();

    RateCellDtlsList rateCellDtlsList = rateCellObj.searchByColumn(
      rateCellByColumnIDKey);

    rateCellDtlsList.dtls.trimToSize();

    return rateCellDtlsList;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RateCellDtlsList searchRateCellByRow(RateRowDtls rateRowDtls)
    throws AppException, InformationalException {

    RateCellReadmultiKey1 rateCellReadmultiKey1 = new RateCellReadmultiKey1();

    rateCellReadmultiKey1.rateRowID = rateRowDtls.rateRowID;

    // RateCell manipulation variables
    curam.core.sl.entity.intf.RateCell rateCellObj = curam.core.sl.entity.fact.RateCellFactory.newInstance();

    RateCellDtlsList rateCellDtlsList = rateCellObj.searchByRateRowID(
      rateCellReadmultiKey1);

    rateCellDtlsList.dtls.trimToSize();

    return rateCellDtlsList;

  }

}
