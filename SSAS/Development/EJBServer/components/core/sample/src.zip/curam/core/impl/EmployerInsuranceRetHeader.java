/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2005, 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.LOCATIONACCESSTYPE;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CreateHeaderKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.EmployerReturnHdrRMDtls;
import curam.core.struct.EmployerReturnHdrRMDtlsList;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InsRetHdrRMKey;
import curam.core.struct.InsRetHeaderHistoryRMKey;
import curam.core.struct.InsRetHeaderHistoryReadKey;
import curam.core.struct.InsRetLineRMByHeaderIDKey;
import curam.core.struct.InsRetReadMultiKey;
import curam.core.struct.InsurRetLineItemRMDtls;
import curam.core.struct.InsurancePeriodControlDtls;
import curam.core.struct.InsurancePeriodControlKey;
import curam.core.struct.InsuranceRetHdrKey;
import curam.core.struct.InsuranceRetLineItemDetailDtls;
import curam.core.struct.InsuranceRetLineItemDetailKey;
import curam.core.struct.InsuranceReturnHdrDetails;
import curam.core.struct.InsuranceReturnHdrModifyDtls;
import curam.core.struct.InsuranceReturnHeaderDetailDtls;
import curam.core.struct.InsuranceReturnHeaderDetailDtlsList;
import curam.core.struct.InsuranceReturnHeaderDetailKey;
import curam.core.struct.InsuranceReturnHeaderDtls;
import curam.core.struct.InsuranceReturnHeaderDtlsList;
import curam.core.struct.InsuranceReturnHeaderKey;
import curam.core.struct.ValidateInsuranceReturnResult;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * Code for creating and maintaining employer insurance return headers.
 */
public abstract class EmployerInsuranceRetHeader extends curam.core.base.EmployerInsuranceRetHeader {

  // Globals

  // based on domain CONCERN_ROLE_ID
  protected static long stConcernRoleID = 0;
  protected static int stLineItemTotalEmployees = 0;
  protected static int stLineItemTotalCasualEmployees = 0;
  protected static int stLineItemTotalPermanentEmployees = 0;

  // based on domain CURAM_AMOUNT
  protected static curam.util.type.Money stLineItemTotalContribAmt = curam.util.type.Money.kZeroMoney;
  // based on domain CURAM_AMOUNT
  protected static curam.util.type.Money stLineItemTotalEmployerContribAmt = curam.util.type.Money.kZeroMoney;
  // based on domain CURAM_AMOUNT
  protected static curam.util.type.Money stLineItemTotalEmployeeContribAmt = curam.util.type.Money.kZeroMoney;
  // based on domain CURAM_AMOUNT
  protected static curam.util.type.Money stLineItemTotalIncomeAmount = curam.util.type.Money.kZeroMoney;

  // ___________________________________________________________________________
  /**
   * This process is used to enter a new insurance return header for an
   * employer
   *
   * @param key create header key
   * @param dtls insurance return header details
   *
   * @return contains created insurance return header's ID
   */
  public InsuranceRetHdrKey createInsuranceReturnHdr(
    CreateHeaderKey key,
    InsuranceReturnHdrDetails dtls)
    throws AppException, InformationalException {

    InsuranceRetHdrKey insuranceRetHdrKey = new InsuranceRetHdrKey();

    // Employer insurance return header unique identifiers
    // based on domain INSURANCE_RET_HDR_ID
    long insuranceRetHdrID = 0;
    // based on domain INSURANCE_RET_HDR_DTLS_ID
    long insuranceRetHdrDtlsID = 0;

    // Insurance return header details
    curam.core.intf.InsuranceReturnHeader insuranceRetHdrObj = curam.core.fact.InsuranceReturnHeaderFactory.newInstance();
    InsuranceReturnHeaderDtls insuranceReturnHeaderDtls = new InsuranceReturnHeaderDtls();

    // Details of insurance return header details
    curam.core.intf.InsuranceReturnHeaderDetail insuranceReturnHeaderDetailObj = curam.core.fact.InsuranceReturnHeaderDetailFactory.newInstance();
    InsuranceReturnHeaderDetailDtls insuranceReturnHeaderDetailDtls = new InsuranceReturnHeaderDetailDtls();

    // Variables to store the current date
    // based on domain CURAM_DATE
    curam.util.type.Date currentDate = curam.util.transaction.TransactionInfo.getSystemDate();

    curam.core.intf.EmployerInsuranceRetHeaderAssistant employerInsuranceRetHeaderAssistantObj = curam.core.fact.EmployerInsuranceRetHeaderAssistantFactory.newInstance();

    // Validation - concern role id must not be blank
    if (dtls.concernRoleID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADER.ERR_INSRETHEADER_FV_CONCERNROLEID_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    
    // BEGIN, CR00227859, PM
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    ParticipantSecurityCheckKey participantKey = new ParticipantSecurityCheckKey();

    participantKey.participantID = dtls.concernRoleID;
    participantKey.type = LOCATIONACCESSTYPE.MAINTAIN;

    DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
      participantKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859


    // Call the validation method
    if (!(curam.util.transaction.TransactionInfo.getTransactionType().equals(
      curam.util.transaction.TransactionInfo.TransactionType.kBatch))) {

      employerInsuranceRetHeaderAssistantObj.validateEmployerInsRetHeader(dtls);

    }

    // Unique IDs generator
    insuranceRetHdrID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();

    insuranceRetHdrDtlsID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();

    // Set the details for inserting an insurance return header details record
    insuranceReturnHeaderDetailDtls.assign(dtls);
    insuranceReturnHeaderDetailDtls.comments = dtls.comments;
    insuranceReturnHeaderDetailDtls.insuranceRetHdrDtlsID = insuranceRetHdrDtlsID;
    insuranceReturnHeaderDetailDtls.insuranceRetHdrID = insuranceRetHdrID;
    insuranceReturnHeaderDetailDtls.insuranceReturnType = curam.codetable.INSURRETURNTYPE.EMPLOYER;
    insuranceReturnHeaderDetailDtls.creationDate = currentDate;

    if (dtls.receiptDate.isZero()) {
      insuranceReturnHeaderDetailDtls.receiptDate = currentDate;
    }

    insuranceReturnHeaderDetailDtls.recordStatus = curam.codetable.CONTRIBRECORDSTATUS.NORMAL;
    insuranceReturnHeaderDetailDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.PROCESSING;

    // To catch if the same record details are entered more than once
    insuranceReturnHeaderDetailObj.insert(insuranceReturnHeaderDetailDtls);

    // Set the details for inserting an insurance return header record
    insuranceReturnHeaderDtls.insuranceRetHdrID = insuranceRetHdrID;
    insuranceReturnHeaderDtls.insuranceRetHdrDetailsID = insuranceRetHdrDtlsID;
    insuranceReturnHeaderDtls.concernRoleID = dtls.concernRoleID;
    insuranceReturnHeaderDtls.insuranceReturnPeriodID = dtls.insuranceReturnPeriodID;
    insuranceReturnHeaderDtls.recordStatus = curam.codetable.CONTRIBRECORDSTATUS.NORMAL;
    insuranceReturnHeaderDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.PROCESSING;

    // To catch if the same record header is entered more than once
    insuranceRetHdrObj.insert(insuranceReturnHeaderDtls);

    insuranceRetHdrKey.insuranceRetHdrID = insuranceRetHdrID;

    return insuranceRetHdrKey;

  }

  // ___________________________________________________________________________
  /**
   * This process is used to modify an insurance return header for an employer.
   *
   * @param key insurance return header key
   * @param dtls insurance return header modify details
   */
  public void modifyInsuranceRetHeader(
    InsuranceRetHdrKey key,
    InsuranceReturnHdrModifyDtls dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00216411, PM
    if (CuramConst.gkZero != dtls.concernRoleID) {
      DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
      ParticipantSecurityCheckKey participantKey = new ParticipantSecurityCheckKey();

      participantKey.participantID = dtls.concernRoleID;
      participantKey.type = LOCATIONACCESSTYPE.MAINTAIN;

      DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
        participantKey);

      if (!dataBasedSecurityResult.result) {
        if (dataBasedSecurityResult.readOnly) {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
        } else if (dataBasedSecurityResult.restricted) {
          throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
        } else {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
        }
      }
    }
    // END, CR00216411
    
    // based on domain INSURANCE_RET_HDR_DTLS_ID
    long insuranceRetHdrDetailsID = 0;

    // Insurance return header entity, details and key
    curam.core.intf.InsuranceReturnHeader insuranceRetHdrObj = curam.core.fact.InsuranceReturnHeaderFactory.newInstance();
    InsuranceReturnHeaderDtls insuranceReturnHeaderDtls;
    InsuranceReturnHeaderKey insuranceReturnHeaderKey = new InsuranceReturnHeaderKey();

    // Insurance return header detail entity, details and key
    curam.core.intf.InsuranceReturnHeaderDetail insuranceReturnHeaderDetailObj = curam.core.fact.InsuranceReturnHeaderDetailFactory.newInstance();
    InsuranceReturnHeaderDetailDtls insuranceReturnHeaderDetailDtls;
    InsuranceReturnHeaderDetailKey insuranceReturnHeaderDetailKey = new InsuranceReturnHeaderDetailKey();
    InsuranceReturnHdrDetails insuranceReturnHdrDetails = new InsuranceReturnHdrDetails();

    // Details for the insurance return header details insert struct
    InsuranceReturnHeaderDetailDtls insuranceReturnHeaderInsertDtls = new InsuranceReturnHeaderDetailDtls();

    curam.core.intf.EmployerInsuranceRetHeaderAssistant employerInsuranceRetHeaderAssistantObj = curam.core.fact.EmployerInsuranceRetHeaderAssistantFactory.newInstance();

    insuranceReturnHdrDetails.assign(dtls);

    // Validation - Receipt Date must not be blank
    if (dtls.receiptDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADER.ERR_INSRETHEADER_FV_RECEIPT_DATE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Call the validation method
    employerInsuranceRetHeaderAssistantObj.validateEmployerInsRetHeader(
      insuranceReturnHdrDetails);

    // Set the key for the insurance return header read
    insuranceReturnHeaderKey.insuranceRetHdrID = key.insuranceRetHdrID;

    insuranceReturnHeaderDtls = insuranceRetHdrObj.read(
      insuranceReturnHeaderKey);

    // Validation - Insurance return period must not be modified
    if (dtls.insuranceReturnPeriodID
      != insuranceReturnHeaderDtls.insuranceReturnPeriodID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOEMPLOYERINSURANCERETHEADER.ERR_INSRETHEADER_XFV_INSRETPERIOD_MODIFIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Unique IDs generator
    insuranceRetHdrDetailsID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();

    // Set the key for the insurance header details read
    insuranceReturnHeaderDetailKey.insuranceRetHdrDtlsID = insuranceReturnHeaderDtls.insuranceRetHdrDetailsID;

    insuranceReturnHeaderDetailDtls = insuranceReturnHeaderDetailObj.read(
      insuranceReturnHeaderDetailKey);

    // Set the key for modifying the insurance return header details
    insuranceReturnHeaderDetailKey.insuranceRetHdrDtlsID = insuranceReturnHeaderDetailDtls.insuranceRetHdrDtlsID;

    // Set the record status to superseded
    insuranceReturnHeaderDetailDtls.recordStatus = curam.codetable.CONTRIBRECORDSTATUS.SUPERSEDED;

    // Modify an existing insurance return header
    insuranceReturnHeaderDetailObj.modify(insuranceReturnHeaderDetailKey,
      insuranceReturnHeaderDetailDtls);

    insuranceReturnHeaderInsertDtls.assign(dtls);

    // Set the details for the insurance return header insert
    insuranceReturnHeaderInsertDtls.insuranceRetHdrDtlsID = insuranceRetHdrDetailsID;
    insuranceReturnHeaderInsertDtls.insuranceRetHdrID = key.insuranceRetHdrID;

    insuranceReturnHeaderInsertDtls.recordStatus = curam.codetable.CONTRIBRECORDSTATUS.NORMAL;
    insuranceReturnHeaderInsertDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.PROCESSING;

    // To catch if the same record header is entered more than once
    insuranceReturnHeaderDetailObj.insert(insuranceReturnHeaderInsertDtls);

    // Set the details for modifying the insurance return header
    insuranceReturnHeaderDtls.insuranceRetHdrDetailsID = insuranceRetHdrDetailsID;

    // Modify the insurance return header
    insuranceRetHdrObj.modify(insuranceReturnHeaderKey,
      insuranceReturnHeaderDtls);

  }

  // ___________________________________________________________________________
  /**
   * Description:
   * This process is used to read a insurance return header for an employer
   *
   * @param key insurance return header key (in)
   *
   * @return InsuranceReturnHdrDetails
   */
  public InsuranceReturnHdrDetails readInsRetHdrDtls(InsuranceRetHdrKey key)
    throws AppException, InformationalException {

    InsuranceReturnHdrDetails insuranceReturnHdrDetails = new InsuranceReturnHdrDetails();

    // Insurance return header entity, list and key
    curam.core.intf.InsuranceReturnHeader insuranceRetHdrObj = curam.core.fact.InsuranceReturnHeaderFactory.newInstance();
    InsuranceReturnHeaderKey insuranceReturnHeaderKey = new InsuranceReturnHeaderKey();
    InsuranceReturnHeaderDtls insuranceReturnHeaderDtls;

    // Insurance return header detail entity, key and details
    curam.core.intf.InsuranceReturnHeaderDetail insuranceRetHdrDtlsObj = curam.core.fact.InsuranceReturnHeaderDetailFactory.newInstance();
    InsuranceReturnHeaderDetailKey insuranceReturnHeaderDetailKey = new InsuranceReturnHeaderDetailKey();
    InsuranceReturnHeaderDetailDtls insuranceReturnHeaderDetailDtls;

    // Insurance period control entity
    curam.core.intf.InsurancePeriodControl insurancePeriodControlObj = curam.core.fact.InsurancePeriodControlFactory.newInstance();
    InsurancePeriodControlDtls insurancePeriodControlDtls;
    InsurancePeriodControlKey insurancePeriodControlKey = new InsurancePeriodControlKey();

    // Concern role key and details
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // Set the key for reading the insurance return header
    insuranceReturnHeaderKey.insuranceRetHdrID = key.insuranceRetHdrID;

    insuranceReturnHeaderDtls = insuranceRetHdrObj.read(
      insuranceReturnHeaderKey);

    // Set the details
    insuranceReturnHdrDetails.assign(insuranceReturnHeaderDtls);

    // Set the key for reading the insurance return header details
    insuranceReturnHeaderDetailKey.insuranceRetHdrDtlsID = insuranceReturnHeaderDtls.insuranceRetHdrDetailsID;

    insuranceReturnHeaderDetailDtls = insuranceRetHdrDtlsObj.read(
      insuranceReturnHeaderDetailKey);

    insuranceReturnHdrDetails.assign(insuranceReturnHeaderDetailDtls);

    // Set the key for the control period read
    insurancePeriodControlKey.insuranceReturnPeriodID = insuranceReturnHeaderDtls.insuranceReturnPeriodID;

    insurancePeriodControlDtls = insurancePeriodControlObj.read(
      insurancePeriodControlKey);

    // Set the period name from the above read
    insuranceReturnHdrDetails.periodName = insurancePeriodControlDtls.periodName;

    // Perform a concern role read
    concernRoleKey.concernRoleID = insuranceReturnHeaderDtls.concernRoleID;

    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // set the employer name from the above read
    insuranceReturnHdrDetails.employerName = concernRoleDtls.concernRoleName;

    return insuranceReturnHdrDetails;

  }

  // ___________________________________________________________________________
  /**
   * Retrieves a list of insurance return header details for the specified
   * concern role.
   *
   * @param key insurance return read multi key
   *
   * @return EmployerReturnHdrRMDtlsList
   */
  public EmployerReturnHdrRMDtlsList readmultiByConcernRoleID(
    InsRetReadMultiKey key) throws AppException, InformationalException {

    EmployerReturnHdrRMDtlsList employerReturnHdrRMDtlsList = new EmployerReturnHdrRMDtlsList();

    // Insurance return header entity, list and key
    curam.core.intf.InsuranceReturnHeader insuranceRetHdrObj = curam.core.fact.InsuranceReturnHeaderFactory.newInstance();
    InsRetHdrRMKey insRetHdrRMKey = new InsRetHdrRMKey();
    InsuranceReturnHeaderDtlsList insuranceReturnHeaderDtlsList;

    // Employer return header readmulti details

    EmployerReturnHdrRMDtls employerReturnHdrRMDtls;

    // Insurance return header detail entity, key and details
    curam.core.intf.InsuranceReturnHeaderDetail insuranceRetHdrDtlsObj = curam.core.fact.InsuranceReturnHeaderDetailFactory.newInstance();
    InsuranceReturnHeaderDetailKey insuranceReturnHeaderDetailKey = new InsuranceReturnHeaderDetailKey();
    InsuranceReturnHeaderDetailDtls insuranceReturnHeaderDetailDtls;

    // Insurance period control entity
    curam.core.intf.InsurancePeriodControl insurancePeriodControlObj = curam.core.fact.InsurancePeriodControlFactory.newInstance();
    InsurancePeriodControlDtls insurancePeriodControlDtls;
    InsurancePeriodControlKey insurancePeriodControlKey = new InsurancePeriodControlKey();

    // Set the key for the readmulti
    insRetHdrRMKey.concernRoleID = key.concernRoleID;

    // Perform the read multi
    insuranceReturnHeaderDtlsList = insuranceRetHdrObj.searchByConcern(
      insRetHdrRMKey);

    // reserve output space
    employerReturnHdrRMDtlsList.dtls.ensureCapacity(
      insuranceReturnHeaderDtlsList.dtls.size());

    // assign obtained information to output structure
    for (int i = 0; i < insuranceReturnHeaderDtlsList.dtls.size(); i++) {

      employerReturnHdrRMDtls = new EmployerReturnHdrRMDtls();

      employerReturnHdrRMDtls.assign(insuranceReturnHeaderDtlsList.dtls.item(i));

      // Set the key for the read
      insuranceReturnHeaderDetailKey.insuranceRetHdrDtlsID = insuranceReturnHeaderDtlsList.dtls.item(i).insuranceRetHdrDetailsID;

      insuranceReturnHeaderDetailDtls = insuranceRetHdrDtlsObj.read(
        insuranceReturnHeaderDetailKey);

      // Map the details
      employerReturnHdrRMDtls.totalContribAmt = insuranceReturnHeaderDetailDtls.totalContribAmt;
      employerReturnHdrRMDtls.receiptDate = insuranceReturnHeaderDetailDtls.receiptDate;
      employerReturnHdrRMDtls.insuranceRetHdrDtlsID = insuranceReturnHeaderDtlsList.dtls.item(i).insuranceRetHdrDetailsID;

      // set the key for reading the insurance period record
      insurancePeriodControlKey.insuranceReturnPeriodID = insuranceReturnHeaderDtlsList.dtls.item(i).insuranceReturnPeriodID;
      // Read the insurance period control record
      insurancePeriodControlDtls = insurancePeriodControlObj.read(
        insurancePeriodControlKey);

      // return the period name from the read above
      employerReturnHdrRMDtls.periodName = insurancePeriodControlDtls.periodName;

      // return the details to the client

      employerReturnHdrRMDtlsList.dtls.addRef(employerReturnHdrRMDtls);

    }

    return employerReturnHdrRMDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * Definition of the class containing the specialized functions for the
   * readMultiByHeaderID nsmulti operation
   *
   */
  static class ReadMultiByHdrID extends curam.util.dataaccess.ReadmultiOperation {

    // _________________________________________________________________________
    /**
     * This operation gets called once before operation
     *
     */
    public void pre() throws AppException, InformationalException {

      // set to zero all values
      stConcernRoleID = 0;
      stLineItemTotalEmployees = 0;
      stLineItemTotalCasualEmployees = 0;
      stLineItemTotalPermanentEmployees = 0;

      // based on domain CURAM_AMOUNT
      curam.util.type.Money zeroAmount = curam.util.type.Money.kZeroMoney;

      stLineItemTotalContribAmt = zeroAmount;
      stLineItemTotalEmployerContribAmt = zeroAmount;
      stLineItemTotalEmployeeContribAmt = zeroAmount;
      stLineItemTotalIncomeAmount = zeroAmount;

    }

    // _________________________________________________________________________
    /**
     * This operation gets called for each record
     *
     * @param objDtls contains processing record
     *
     * @return true
     */
    public boolean operation(Object objDtls) throws AppException,
        InformationalException {

      InsurRetLineItemRMDtls insurRetLineItemRMDtls = (InsurRetLineItemRMDtls) objDtls;

      // Insurance return line item details
      curam.core.intf.InsuranceRetLineItemDetail insuranceRetLineItemDetailObj = curam.core.fact.InsuranceRetLineItemDetailFactory.newInstance();
      InsuranceRetLineItemDetailKey insuranceRetLineItemDetailKey = new InsuranceRetLineItemDetailKey();
      InsuranceRetLineItemDetailDtls insuranceRetLineItemDetailDtls;

      // read line item details
      // set the key
      insuranceRetLineItemDetailKey.insRetLineItemDtlID = insurRetLineItemRMDtls.insRetLineItemDtlID;
      // read
      insuranceRetLineItemDetailDtls = insuranceRetLineItemDetailObj.read(
        insuranceRetLineItemDetailKey);

      if (!insuranceRetLineItemDetailDtls.recordStatus.equals(
        curam.codetable.CONTRIBRECORDSTATUS.CANCELLED)) {

        if (insurRetLineItemRMDtls.concernRoleID != stConcernRoleID) {
          // total number of employees
          stLineItemTotalEmployees++;

          // find the number of casual and permanent employees
          if (insuranceRetLineItemDetailDtls.employmentTypeCode.equals(
            curam.codetable.EMPLOYMENTTYPE.CASUAL)) {
            stLineItemTotalCasualEmployees++;
          } else {
            stLineItemTotalPermanentEmployees++;
          }

        }

        // total employer contribution amount
        stLineItemTotalEmployerContribAmt = new curam.util.type.Money(
          stLineItemTotalEmployerContribAmt.getValue()
            + insuranceRetLineItemDetailDtls.employerConAmt.getValue());
        // total employee contribution amount
        stLineItemTotalEmployeeContribAmt = new curam.util.type.Money(
          stLineItemTotalEmployeeContribAmt.getValue()
            + insuranceRetLineItemDetailDtls.employeeConAmt.getValue());
        // total contribution amount
        stLineItemTotalContribAmt = new curam.util.type.Money(
          stLineItemTotalContribAmt.getValue()
            + insuranceRetLineItemDetailDtls.totalContributionAmt.getValue());
        // total income amount
        stLineItemTotalIncomeAmount = new curam.util.type.Money(
          stLineItemTotalIncomeAmount.getValue()
            + insuranceRetLineItemDetailDtls.incomeAmount.getValue());

        // save the last value of concern role ID
        stConcernRoleID = insurRetLineItemRMDtls.concernRoleID;

      }

      // continue to process
      return true;

    }

  }

  // ___________________________________________________________________________
  /**
   * This method will validate an insurance return header
   *
   * @param key insurance return header id
   *
   * @return ValidateInsuranceReturnResult
   */
  public ValidateInsuranceReturnResult validateInsuranceReturn(
    InsuranceRetHdrKey key) throws AppException, InformationalException {

    ValidateInsuranceReturnResult validateInsuranceReturnResult = new ValidateInsuranceReturnResult();

    // Insurance return header
    curam.core.intf.InsuranceReturnHeader insuranceRetHdrObj = curam.core.fact.InsuranceReturnHeaderFactory.newInstance();
    InsuranceReturnHeaderKey insuranceReturnHeaderKey = new InsuranceReturnHeaderKey();
    InsuranceReturnHeaderDtls insuranceReturnHeaderDtls;

    // Insurance return header details
    curam.core.intf.InsuranceReturnHeaderDetail insRetHdrDetailsObj = curam.core.fact.InsuranceReturnHeaderDetailFactory.newInstance();
    InsuranceReturnHeaderDetailKey insRetHdrDetailsKey = new InsuranceReturnHeaderDetailKey();
    InsuranceReturnHeaderDetailDtls insRetHdrDetailsDtls;

    // key for read multi
    InsRetLineRMByHeaderIDKey insRetLineRMByHeaderIDKey = new InsRetLineRMByHeaderIDKey();
    // read multi operation
    ReadMultiByHdrID readMultiByHdrIDObj = new ReadMultiByHdrID();

    // informational field
    InformationalMsgDtls informationalMsgDtls;

    // based on domain CURAM_AMOUNT
    curam.util.type.Money zeroAmount = curam.util.type.Money.kZeroMoney;

    boolean zeroField = false;

    // based on domain INSURANCE_RET_HDR_DTLS_ID
    long insuranceRetHdrDtlsID = 0;

    // set the key to read insurance return header
    insuranceReturnHeaderKey.insuranceRetHdrID = key.insuranceRetHdrID;

    // read insurance return header
    insuranceReturnHeaderDtls = insuranceRetHdrObj.read(
      insuranceReturnHeaderKey, true);

    // set the key to read insurance return header details
    insRetHdrDetailsKey.insuranceRetHdrDtlsID = insuranceReturnHeaderDtls.insuranceRetHdrDetailsID;

    // read insurance return header details
    insRetHdrDetailsDtls = insRetHdrDetailsObj.read(insRetHdrDetailsKey, true);

    validateInsuranceReturnResult.validationChangeDtls.employerContribAmt = insRetHdrDetailsDtls.employerContribAmt;
    validateInsuranceReturnResult.validationChangeDtls.employeeContribAmt = insRetHdrDetailsDtls.employeeContribAmt;

    // set the key for read multi operation
    insRetLineRMByHeaderIDKey.insuranceRetHdrID = key.insuranceRetHdrID;
    // Call the appropriate nsmulti operation
    curam.core.fact.InsuranceReturnLineItemFactory.newInstance().searchByHeaderID(
      insRetLineRMByHeaderIDKey, readMultiByHdrIDObj);

    // set the status code to COMPLETE assuming everything will be Valid
    insuranceReturnHeaderDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.COMPLETE;

    // check the integrity
    // employee contribution amount
    if ((!insRetHdrDetailsDtls.employeeContribAmt.isZero())
      && (insRetHdrDetailsDtls.employeeContribAmt.getValue()
        != stLineItemTotalEmployeeContribAmt.getValue())) {

      informationalMsgDtls = new InformationalMsgDtls();

      // push the message to client
      informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
        curam.message.BPOEMPLOYERINSURANCERETHEADER.INF_INSRETHEADER_EMPLOYEECONTRIBAMT.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC

      validateInsuranceReturnResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

      // set status code to incomplete
      insuranceReturnHeaderDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.INCOMPL;
    }

    // employer contribution amount
    if ((!insRetHdrDetailsDtls.employerContribAmt.isZero())
      && (insRetHdrDetailsDtls.employerContribAmt.getValue()
        != stLineItemTotalEmployerContribAmt.getValue())) {

      informationalMsgDtls = new InformationalMsgDtls();

      // push the message to client
      informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
        curam.message.BPOEMPLOYERINSURANCERETHEADER.INF_INSRETHEADER_EMPLOYERCONTRIBAMT.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC

      validateInsuranceReturnResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

      // set status code to incomplete
      insuranceReturnHeaderDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.INCOMPL;
    }

    // total contribution amount
    if ((!insRetHdrDetailsDtls.totalContribAmt.isZero())
      && (insRetHdrDetailsDtls.totalContribAmt.getValue()
        != stLineItemTotalContribAmt.getValue())) {

      informationalMsgDtls = new InformationalMsgDtls();

      // push the message to client
      informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
        curam.message.BPOEMPLOYERINSURANCERETHEADER.INF_INSRETHEADER_TOTCONTRIBAMT.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC

      validateInsuranceReturnResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

      // set status code to incomplete
      insuranceReturnHeaderDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.INCOMPL;
    }

    // sum of the contribution amounts not equal to the total
    // contribution amount
    if ((stLineItemTotalEmployerContribAmt.getValue()
      + stLineItemTotalEmployeeContribAmt.getValue())
        != zeroAmount.getValue()) {

      if (insRetHdrDetailsDtls.totalContribAmt.getValue()
        != (stLineItemTotalEmployerContribAmt.getValue()
          + stLineItemTotalEmployeeContribAmt.getValue())) {

        informationalMsgDtls = new InformationalMsgDtls();

        // push the message to client
        informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
          curam.message.BPOEMPLOYERINSURANCERETHEADER.INF_INSRETHEADER_TOTCONTRIBAMTS.getMessageText(
          TransactionInfo.getProgramLocale());
        // END, CR00163471, JC

        validateInsuranceReturnResult.informationalMsgDtlsList.dtls.addRef(
          informationalMsgDtls);

        // set status code to incomplete
        insuranceReturnHeaderDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.INCOMPL;
      }

    }

    // number of permanent employees
    if ((insRetHdrDetailsDtls.numPermanentEmployees != 0)
      && (insRetHdrDetailsDtls.numPermanentEmployees
        != stLineItemTotalPermanentEmployees)) {

      informationalMsgDtls = new InformationalMsgDtls();

      // push the message to client
      informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
        curam.message.BPOEMPLOYERINSURANCERETHEADER.INF_INSRETHEADER_NUMPERMANENTEMPLOYEES.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC

      validateInsuranceReturnResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

      // set status code to incomplete
      insuranceReturnHeaderDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.INCOMPL;
    }

    // number of casual employees
    if ((insRetHdrDetailsDtls.numCasualEmployees != 0)
      && (insRetHdrDetailsDtls.numCasualEmployees
        != stLineItemTotalCasualEmployees)) {

      informationalMsgDtls = new InformationalMsgDtls();

      // push the message to client
      informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
        curam.message.BPOEMPLOYERINSURANCERETHEADER.INF_INSRETHEADER_NUMCASUALEMPLOYEES.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC

      validateInsuranceReturnResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

      // set status code to incomplete
      insuranceReturnHeaderDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.INCOMPL;
    }

    // number of employees
    if ((insRetHdrDetailsDtls.totNumEmployees != 0)
      && (insRetHdrDetailsDtls.totNumEmployees != stLineItemTotalEmployees)) {

      informationalMsgDtls = new InformationalMsgDtls();

      // push the message to client
      informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
        curam.message.BPOEMPLOYERINSURANCERETHEADER.INF_INSRETHEADER_TOTNUMEMPLOYEES.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC

      validateInsuranceReturnResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

      // set status code to incomplete
      insuranceReturnHeaderDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.INCOMPL;
    }

    if ((!insRetHdrDetailsDtls.totalPayroll.isZero())
      && (insRetHdrDetailsDtls.totalPayroll.getValue()
        != stLineItemTotalIncomeAmount.getValue())) {

      informationalMsgDtls = new InformationalMsgDtls();

      // push the message to client
      informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
        curam.message.BPOEMPLOYERINSURANCERETHEADER.INF_INSRETHEADER_TOTALPAYROLL.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC

      validateInsuranceReturnResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

      // set status code to incomplete
      insuranceReturnHeaderDtls.statusCode = curam.codetable.INSURRETHDRSTATUS.INCOMPL;
    }

    // set the key to modify insurance return header
    insuranceReturnHeaderKey.insuranceRetHdrID = key.insuranceRetHdrID;
    // modify insurance return header
    insuranceRetHdrObj.modify(insuranceReturnHeaderKey,
      insuranceReturnHeaderDtls);

    // modify insurance return header detail
    insRetHdrDetailsDtls.statusCode = insuranceReturnHeaderDtls.statusCode;
    insRetHdrDetailsObj.modify(insRetHdrDetailsKey, insRetHdrDetailsDtls);

    // set the informational message
    if (insuranceReturnHeaderDtls.statusCode.equals(
      curam.codetable.INSURRETHDRSTATUS.INCOMPL)) {

      informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
        curam.message.BPOEMPLOYERINSURANCERETHEADER.INF_INSRETHEADER_INCOMPL.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC

      validateInsuranceReturnResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    } else {

      informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = // BEGIN, CR00163471, JC
        curam.message.BPOEMPLOYERINSURANCERETHEADER.INF_INSRETHEADER_COMPL.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC

      validateInsuranceReturnResult.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // check the integrity
    // employee contribution amount
    if (insRetHdrDetailsDtls.employeeContribAmt.isZero()) {
      zeroField = true;
      insRetHdrDetailsDtls.employeeContribAmt = stLineItemTotalEmployeeContribAmt;
    }

    // employer contribution amount
    if (insRetHdrDetailsDtls.employerContribAmt.isZero()) {
      zeroField = true;
      insRetHdrDetailsDtls.employerContribAmt = stLineItemTotalEmployerContribAmt;
    }

    // total contribution amount
    if (insRetHdrDetailsDtls.totalContribAmt.isZero()) {
      zeroField = true;
      insRetHdrDetailsDtls.totalContribAmt = stLineItemTotalContribAmt;
    }

    // number of permanent employees
    if (insRetHdrDetailsDtls.numPermanentEmployees == 0) {
      zeroField = true;
      insRetHdrDetailsDtls.numPermanentEmployees = stLineItemTotalPermanentEmployees;
    }

    // number of casual employees
    if (insRetHdrDetailsDtls.numCasualEmployees == 0) {
      zeroField = true;
      insRetHdrDetailsDtls.numCasualEmployees = stLineItemTotalCasualEmployees;
    }

    // number of employees
    if (insRetHdrDetailsDtls.totNumEmployees == 0) {
      zeroField = true;
      insRetHdrDetailsDtls.totNumEmployees = stLineItemTotalEmployees;
    }

    // payroll amount
    if (insRetHdrDetailsDtls.totalPayroll.isZero()) {
      zeroField = true;
      insRetHdrDetailsDtls.totalPayroll = stLineItemTotalIncomeAmount;
    }

    if (zeroField) {

      // generate unique ID
      insuranceRetHdrDtlsID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();

      insRetHdrDetailsDtls.insuranceRetHdrDtlsID = insuranceRetHdrDtlsID;
      // insert new record
      insRetHdrDetailsDtls.statusCode = insuranceReturnHeaderDtls.statusCode;

      insRetHdrDetailsObj.insert(insRetHdrDetailsDtls);

      // set the key to modify insurance return header
      insuranceReturnHeaderKey.insuranceRetHdrID = key.insuranceRetHdrID;
      insuranceReturnHeaderDtls.insuranceRetHdrDetailsID = insuranceRetHdrDtlsID;
      // modify insurance return header
      insuranceRetHdrObj.modify(insuranceReturnHeaderKey,
        insuranceReturnHeaderDtls);

    }

    validateInsuranceReturnResult.validationChangeDtls.statusCode = insuranceReturnHeaderDtls.statusCode;

    if (validateInsuranceReturnResult.validationChangeDtls.statusCode.equals(
      curam.codetable.INSURRETHDRSTATUS.COMPLETE)) {
      validateInsuranceReturnResult.validationChangeDtls.employerContribAmt = insRetHdrDetailsDtls.employerContribAmt;
      validateInsuranceReturnResult.validationChangeDtls.employeeContribAmt = insRetHdrDetailsDtls.employeeContribAmt;
    }

    return validateInsuranceReturnResult;

  }

  // ___________________________________________________________________________
  /**
   * This method will read the history details for a specific header
   *
   * @param key employer return header history readmulti key
   *
   * @return employer return header history list
   */
  public EmployerReturnHdrRMDtlsList readHeaderHistory(
    InsRetHeaderHistoryReadKey key) throws AppException,
      InformationalException {

    EmployerReturnHdrRMDtlsList employerReturnHdrRMDtlsList = new EmployerReturnHdrRMDtlsList();

    // variables for reading insurance return header
    curam.core.intf.InsuranceReturnHeader insuranceRetHdrObj = curam.core.fact.InsuranceReturnHeaderFactory.newInstance();
    InsuranceReturnHeaderDtls insuranceReturnHeaderDtls;
    InsuranceReturnHeaderKey insuranceReturnHeaderKey = new InsuranceReturnHeaderKey();

    EmployerReturnHdrRMDtls employerReturnHdrRMDtls;

    // insurance return header detail entity, key and details
    curam.core.intf.InsuranceReturnHeaderDetail insuranceRetHdrDtlsObj = curam.core.fact.InsuranceReturnHeaderDetailFactory.newInstance();
    InsRetHeaderHistoryRMKey insRetHeaderHistoryRMKey = new InsRetHeaderHistoryRMKey();
    InsuranceReturnHeaderDetailDtlsList insRetHeaderDetailDtlsList;

    // variables for reading insurance period control
    curam.core.intf.InsurancePeriodControl insurancePeriodControlObj = curam.core.fact.InsurancePeriodControlFactory.newInstance();
    InsurancePeriodControlDtls insurancePeriodControlDtls;
    InsurancePeriodControlKey insurancePeriodControlKey = new InsurancePeriodControlKey();

    // set the key for reading the insurance return header record
    insuranceReturnHeaderKey.insuranceRetHdrID = key.insuranceRetHdrID;

    // read the insurance return header record
    insuranceReturnHeaderDtls = insuranceRetHdrObj.read(
      insuranceReturnHeaderKey);

    // set the key for the readmulti
    insRetHeaderHistoryRMKey.insuranceRetHdrID = key.insuranceRetHdrID;

    // read the insurance return header details record
    insRetHeaderDetailDtlsList = insuranceRetHdrDtlsObj.searchByInsuranceReturnHeaderID(
      insRetHeaderHistoryRMKey);

    // reserve output space
    employerReturnHdrRMDtlsList.dtls.ensureCapacity(
      insRetHeaderDetailDtlsList.dtls.size());

    // assign obtained information to output structure
    for (int i = 0; i < insRetHeaderDetailDtlsList.dtls.size(); i++) {

      employerReturnHdrRMDtls = new EmployerReturnHdrRMDtls();

      employerReturnHdrRMDtls.assign(insRetHeaderDetailDtlsList.dtls.item(i));

      // set the key for reading the insurance period name
      insurancePeriodControlKey.insuranceReturnPeriodID = insuranceReturnHeaderDtls.insuranceReturnPeriodID;

      // read the insurance period control record
      insurancePeriodControlDtls = insurancePeriodControlObj.read(
        insurancePeriodControlKey);
      // return the insurance period name
      employerReturnHdrRMDtls.periodName = insurancePeriodControlDtls.periodName;

      // map the details
      employerReturnHdrRMDtls.assign(insuranceReturnHeaderDtls);
      employerReturnHdrRMDtls.insuranceRetHdrDtlsID = insRetHeaderDetailDtlsList.dtls.item(i).insuranceRetHdrDtlsID;

      // return the details to the client

      employerReturnHdrRMDtlsList.dtls.addRef(employerReturnHdrRMDtls);

    }

    return employerReturnHdrRMDtlsList;

  }

  // ___________________________________________________________________________
  /**
   * This method reads the details of a superseded record
   *
   * @param key insurance return header history readmulti key
   *
   * @return insurance return header details
   */
  public InsuranceReturnHdrDetails readHistoryDetail(
    InsRetHeaderHistoryReadKey key) throws AppException,
      InformationalException {

    InsuranceReturnHdrDetails insuranceReturnHdrDetails = new InsuranceReturnHdrDetails();

    // variables for reading insurance return header
    curam.core.intf.InsuranceReturnHeader insuranceRetHdrObj = curam.core.fact.InsuranceReturnHeaderFactory.newInstance();
    InsuranceReturnHeaderDtls insuranceReturnHeaderDtls;
    InsuranceReturnHeaderKey insuranceReturnHeaderKey = new InsuranceReturnHeaderKey();

    // variables for reading concern role
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // variables for reading insurance return header details
    curam.core.intf.InsuranceReturnHeaderDetail insuranceRetHdrDtlsObj = curam.core.fact.InsuranceReturnHeaderDetailFactory.newInstance();
    InsuranceReturnHeaderDetailKey insuranceReturnHeaderDetailKey = new InsuranceReturnHeaderDetailKey();
    InsuranceReturnHeaderDetailDtls insuranceReturnHeaderDetailDtls;

    // variables for reading insurance period control
    curam.core.intf.InsurancePeriodControl insurancePeriodControlObj = curam.core.fact.InsurancePeriodControlFactory.newInstance();
    InsurancePeriodControlDtls insurancePeriodControlDtls;
    InsurancePeriodControlKey insurancePeriodControlKey = new InsurancePeriodControlKey();

    // set the key for reading the insurance return header details
    insuranceReturnHeaderDetailKey.insuranceRetHdrDtlsID = key.insuranceRetHdrDetailsID;

    // read the insurance return header details
    insuranceReturnHeaderDetailDtls = insuranceRetHdrDtlsObj.read(
      insuranceReturnHeaderDetailKey);

    // map the details
    insuranceReturnHdrDetails.assign(insuranceReturnHeaderDetailDtls);

    // set the key for reading the insurance return header record
    insuranceReturnHeaderKey.insuranceRetHdrID = insuranceReturnHeaderDetailDtls.insuranceRetHdrID;

    // read the insurance return header record
    insuranceReturnHeaderDtls = insuranceRetHdrObj.read(
      insuranceReturnHeaderKey);

    // map the details
    insuranceReturnHdrDetails.assign(insuranceReturnHeaderDtls);

    // set the key for the reading the employer name
    concernRoleKey.concernRoleID = insuranceReturnHeaderDtls.concernRoleID;

    // read the concern role record
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // set the employer name from the above read
    insuranceReturnHdrDetails.employerName = concernRoleDtls.concernRoleName;

    // set the key for the insurance period control read
    insurancePeriodControlKey.insuranceReturnPeriodID = insuranceReturnHeaderDtls.insuranceReturnPeriodID;

    // read the insurance period control record
    insurancePeriodControlDtls = insurancePeriodControlObj.read(
      insurancePeriodControlKey);

    // set the period name from the above read
    insuranceReturnHdrDetails.periodName = insurancePeriodControlDtls.periodName;

    return insuranceReturnHdrDetails;

  }

}
