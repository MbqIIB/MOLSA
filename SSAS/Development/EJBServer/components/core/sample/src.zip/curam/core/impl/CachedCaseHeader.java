/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2008, 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import org.apache.log4j.Logger;

import curam.core.fact.CaseHeaderFactory;
import curam.core.intf.CaseHeader;
import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHeaderReadByICKey;
import curam.core.struct.CaseHeaderReadmultiDetails1List;
import curam.core.struct.CaseHeaderReadmultiKey1;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseStartDate;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CaseTypeDetails_eo;
import curam.core.struct.CaseTypeStartDateEndDateExpectedEndDateList;
import curam.core.struct.IntegratedCaseKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * @see curam.core.intf.CachedCaseHeader;
 */
public abstract class CachedCaseHeader extends curam.core.base.CachedCaseHeader {

  protected static ThreadLocal<CaseHeaderCached> cachedCaseHeaderThreadLocal = new ThreadLocal<CaseHeaderCached>();

  // ___________________________________________________________________________
  // BEGIN, CR00069782, GSP
  protected static ThreadLocal<IntegratedCaseHeaderCached> integCachedCaseHeaderThreadLocal = new ThreadLocal<IntegratedCaseHeaderCached>();
  // END, CR00069782
  
  // BEGIN, CR00023323, SK
  public static final Logger kBatchLauncherCacheLogger = Logger.getLogger(
    ExtensionConst.kBatchCachingCategory);
  // END, CR0002332
  
  public static final boolean logging;

  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;

  // BEGIN, CR00052232, GSP
  // static to indicate if online caching is enabled
  public static final boolean onlineCachingEnabled;
  // END, CR00052232

  // ___________________________________________________________________________
  // static to hold the logging_enabled environmental Variable
  static {

    cachingEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);

    // BEGIN, CR00052232, GSP
    onlineCachingEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_ONLINE_CACHING_ENABLED);
    // END, CR00052232

    String logging_enabled = Configuration.getProperty(
      EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED);

    if (logging_enabled == null) {
      logging_enabled = EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED_DEFAULT;
    }

    if (logging_enabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      logging = true;

    } else {
      logging = false;
    }
  }

  // ___________________________________________________________________________
  /**
   * class used to cache the CaseHeader details
   *
   */
  class CaseHeaderCached {

    CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();
    int transactionID = 0;
  }


  // BEGIN, CR00069782, GSP
  // ___________________________________________________________________________
  /**
   * class used to cache the details of the cases corresponding to an
   * IntegratedCase
   *
   */
  class IntegratedCaseHeaderCached {

    IntegratedCaseKey integCasekey = new IntegratedCaseKey();
    CaseHeaderReadmultiDetails1List caseHeaderRdmultiDtls1Lst = new CaseHeaderReadmultiDetails1List();
    CaseTypeStartDateEndDateExpectedEndDateList caseTypStDtEndDtExpEndDtLst = new CaseTypeStartDateEndDateExpectedEndDateList();
    int transactionID = 0;

  }
  // END, CR00069782
  
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseHeaderDtls read(CaseHeaderKey key) throws AppException, InformationalException {

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    CaseHeaderCached caseHeaderCached = cachedCaseHeaderThreadLocal.get();

    boolean reloadCache = true;

    if (caseHeaderCached != null) {
      // BEGIN, CR00052232, GSP
      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if (((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
        || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
        || (transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled))
            && caseHeaderCached.caseHeaderDtls != null
            && caseHeaderCached.caseHeaderDtls.caseID == key.caseID) {

        reloadCache = false;

        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if ((transactionType.equals(TransactionType.kDeferred)
          || transactionType.equals(TransactionType.kOnline))
            // END, CR00052232
            && TransactionInfo.getIdentifierForThisThread()
              != caseHeaderCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    if (reloadCache) {

      // Otherwise we need to read the CaseHeader data
      caseHeaderCached = new CaseHeaderCached();
      caseHeaderCached.caseHeaderDtls = reloadCache(key);

    }
    // BEGIN, CR00284485, ZV
    CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();
    
    return caseHeaderDtls.assign(caseHeaderCached.caseHeaderDtls);
    // END, CR00284485
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void clearCache() throws AppException, InformationalException {

    cachedCaseHeaderThreadLocal.set(null);
    // BEGIN, CR00069782, GSP
    integCachedCaseHeaderThreadLocal.set(null);
    // END, CR00069782
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void modify(CaseHeaderKey key, CaseHeaderDtls dtls)
    throws AppException, InformationalException {
    // BEGIN, CR00052232, GSP
    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();
    // END, CR00052232
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    caseHeaderObj.modify(key, dtls);
    // BEGIN, CR00052232, GSP
    // If this is a batch transaction or deferred or online processing
    // (and caching is enabled), and we've hit
    // the cache we do not need to reload the cache
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {
      // END, CR00052232
      CaseHeaderCached caseHeaderCached = new CaseHeaderCached();

      // BEGIN, CR00069782, GSP
      caseHeaderCached.caseHeaderDtls.assign(dtls);
      // END, CR00069782
      caseHeaderCached.transactionID = TransactionInfo.getIdentifierForThisThread();

      cachedCaseHeaderThreadLocal.set(caseHeaderCached);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public IntegratedCaseKey readIntegratedCaseIDByCaseID(CaseKey key)
    throws AppException, InformationalException {
    
    IntegratedCaseKey integratedCaseKey = new IntegratedCaseKey();

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();
   
    CaseHeaderCached caseHeaderCached = cachedCaseHeaderThreadLocal.get();

    boolean reloadCache = true;

    if (caseHeaderCached != null) {
      // BEGIN, CR00052232, GSP
      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if (((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
        || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
        || (transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled))
            // END, CR00052232
            && caseHeaderCached.caseHeaderDtls != null
            && caseHeaderCached.caseHeaderDtls.caseID == key.caseID) {

        integratedCaseKey.integratedCaseID = caseHeaderCached.caseHeaderDtls.integratedCaseID;
        reloadCache = false;
        
        // BEGIN, CR00052232, GSP
        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline)) // END, CR00052232
            && TransactionInfo.getIdentifierForThisThread()
              != caseHeaderCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadCache) {

      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;
      // BEGIN, CR00279909, SG
      CaseHeaderDtls caseHeaderDtls = reloadCache(caseHeaderKey);

      // END, CR00279909
      integratedCaseKey.integratedCaseID = caseHeaderDtls.integratedCaseID;
    }

    return integratedCaseKey;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseTypeDetails_eo readType(CaseHeaderKey key)
    throws AppException, InformationalException {

    CaseTypeDetails_eo caseTypeDetails_eo = new CaseTypeDetails_eo();
    
    CaseHeaderCached caseHeaderCached = cachedCaseHeaderThreadLocal.get();

    boolean reloadCache = true;

    if (caseHeaderCached != null) {

      // variable to hold transaction type
      TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

      // BEGIN, CR00052232, GSP
      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if (((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
        || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
        || (transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled)) // END, CR00052232
            && caseHeaderCached.caseHeaderDtls != null
            && caseHeaderCached.caseHeaderDtls.caseID == key.caseID) {

        caseTypeDetails_eo.caseTypeCode = caseHeaderCached.caseHeaderDtls.caseTypeCode;
        caseTypeDetails_eo.versionNo = caseHeaderCached.caseHeaderDtls.versionNo;

        reloadCache = false;
        
        // BEGIN, CR00052232, GSP
        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline)) // END, CR00052232
            && TransactionInfo.getIdentifierForThisThread()
              != caseHeaderCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadCache) {

      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;
      // BEGIN, CR00279909, SG
      CaseHeaderDtls caseHeaderDtls = reloadCache(caseHeaderKey);

      // END, CR00279909
      caseTypeDetails_eo.caseTypeCode = caseHeaderDtls.caseTypeCode;
      caseTypeDetails_eo.versionNo = caseHeaderDtls.versionNo;
    }

    return caseTypeDetails_eo;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseHeaderDtls reloadCache(CaseHeaderKey key) throws AppException, InformationalException {

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderDtls caseHeaderDtls;
    CaseHeaderCached caseHeaderCached = new CaseHeaderCached();

    // Read the case header details
    caseHeaderDtls = caseHeaderObj.read(key);
    // BEGIN, CR00052232, GSP
    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {
      // END, CR00052232
      
      // BEGIN, CR00069782, GSP
      caseHeaderCached.caseHeaderDtls.assign(caseHeaderDtls);
      // END, CR00069782
      caseHeaderCached.transactionID = TransactionInfo.getIdentifierForThisThread();

      // Populate the cache
      cachedCaseHeaderThreadLocal.set(caseHeaderCached);
    }

    return caseHeaderDtls;
  }

  // BEGIN, CR00069782, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseHeaderReadmultiDetails1List reloadCaseDtlsByICCache(
    CaseHeaderReadmultiKey1 key) throws AppException, InformationalException {

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderReadmultiDetails1List caseHeaderRdMultiDtlsLst;
    IntegratedCaseHeaderCached integCaseHeaderCached = new IntegratedCaseHeaderCached();

    // Search by Integrated Case
    caseHeaderRdMultiDtlsLst = caseHeaderObj.searchByIntegratedCaseID(key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {

      integCaseHeaderCached.integCasekey.integratedCaseID = key.integratedCaseID;
      integCaseHeaderCached.caseHeaderRdmultiDtls1Lst.assign(
        caseHeaderRdMultiDtlsLst);
      integCaseHeaderCached.transactionID = TransactionInfo.getIdentifierForThisThread();

      // Populate the integrated cache
      integCachedCaseHeaderThreadLocal.set(integCaseHeaderCached);
    }

    return caseHeaderRdMultiDtlsLst;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseTypeStartDateEndDateExpectedEndDateList reloadCaseTypStEndExpEndDtDtlsCache(CaseHeaderReadByICKey key)
    throws AppException, InformationalException {

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    CaseTypeStartDateEndDateExpectedEndDateList caseTypStDtEndDtExpEndDtLst;
    IntegratedCaseHeaderCached integCaseHeaderCached = new IntegratedCaseHeaderCached();

    // Search by Integrated Case
    caseTypStDtEndDtExpEndDtLst = caseHeaderObj.searchCaseTypeStartEndAndExpectedEndDatesByIntegratedCase(
      key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {

      integCaseHeaderCached.integCasekey.integratedCaseID = key.integratedCaseID;
      integCaseHeaderCached.caseTypStDtEndDtExpEndDtLst.assign(
        caseTypStDtEndDtExpEndDtLst);
      integCaseHeaderCached.transactionID = TransactionInfo.getIdentifierForThisThread();

      // Populate the integrated cache
      integCachedCaseHeaderThreadLocal.set(integCaseHeaderCached);
    }

    return caseTypStDtEndDtExpEndDtLst;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseHeaderReadmultiDetails1List searchByIntegratedCaseID(
    CaseHeaderReadmultiKey1 key) throws AppException, InformationalException {

    CaseHeaderReadmultiDetails1List caseHeaderRdmultiDtlsLst = new CaseHeaderReadmultiDetails1List();

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    IntegratedCaseHeaderCached integCaseHeaderCached = integCachedCaseHeaderThreadLocal.get();

    boolean reloadIntegCache = true;

    if (integCaseHeaderCached != null) {

      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if (((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
        || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
        || (transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled))
            && integCaseHeaderCached.caseHeaderRdmultiDtls1Lst != null
            && integCaseHeaderCached.integCasekey.integratedCaseID
              == key.integratedCaseID) {

        caseHeaderRdmultiDtlsLst.assign(
          integCaseHeaderCached.caseHeaderRdmultiDtls1Lst);

        reloadIntegCache = false;

        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadIntegCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != integCaseHeaderCached.transactionID) {

          reloadIntegCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadIntegCache) {
      caseHeaderRdmultiDtlsLst.assign(reloadCaseDtlsByICCache(key));
    }

    return caseHeaderRdmultiDtlsLst;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseTypeStartDateEndDateExpectedEndDateList searchCaseTypeStartEndAndExpectedEndDatesByIntegratedCase(
    CaseHeaderReadByICKey key) throws AppException, InformationalException {

    CaseTypeStartDateEndDateExpectedEndDateList caseTypStDtEndDtExpEndDtLst = new CaseTypeStartDateEndDateExpectedEndDateList();

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    IntegratedCaseHeaderCached integCaseHeaderCached = integCachedCaseHeaderThreadLocal.get();

    boolean reloadIntegCache = true;

    if (integCaseHeaderCached != null) {

      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if (((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
        || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
        || (transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled))
            && integCaseHeaderCached.caseTypStDtEndDtExpEndDtLst != null
            && integCaseHeaderCached.integCasekey.integratedCaseID
              == key.integratedCaseID) {

        caseTypStDtEndDtExpEndDtLst.assign(
          integCaseHeaderCached.caseTypStDtEndDtExpEndDtLst);

        reloadIntegCache = false;

        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadIntegCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != integCaseHeaderCached.transactionID) {

          reloadIntegCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadIntegCache) {
      caseTypStDtEndDtExpEndDtLst.assign(
        reloadCaseTypStEndExpEndDtDtlsCache(key));
    }

    return caseTypStDtEndDtExpEndDtLst;
  }

  // END, CR00069782
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseHeaderDtls getCachedDtls() {

    // Create the return object
    CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();

    // Read the cached details
    CaseHeaderCached caseHeaderCached = new CaseHeaderCached();

    caseHeaderCached = cachedCaseHeaderThreadLocal.get();

    if (caseHeaderCached.caseHeaderDtls == null) {

      caseHeaderCached.caseHeaderDtls = new CaseHeaderDtls();
    }

    return caseHeaderDtls.assign(caseHeaderCached.caseHeaderDtls);
  }

  // BEGIN, CR00052232, GSP
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseTypeCode readCaseTypeCode(CaseKey key) throws AppException, InformationalException {

    CaseTypeCode caseTypeCode = new CaseTypeCode();

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    CaseHeaderCached caseHeaderCached = cachedCaseHeaderThreadLocal.get();

    boolean reloadCache = true;

    if (caseHeaderCached != null) {

      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if (((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
        || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
        || (transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled))
            && caseHeaderCached.caseHeaderDtls != null
            && caseHeaderCached.caseHeaderDtls.caseID == key.caseID) {

        caseTypeCode.caseTypeCode = caseHeaderCached.caseHeaderDtls.caseTypeCode;
        reloadCache = false;

        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != caseHeaderCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadCache) {

      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;
      // BEGIN, CR00279909, SG
      CaseHeaderDtls caseHeaderDtls = reloadCache(caseHeaderKey);

      // END, CR00279909
      caseTypeCode.caseTypeCode = caseHeaderDtls.caseTypeCode;
    }

    return caseTypeCode;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseStartDate readStartDate(CaseHeaderKey key) throws AppException, InformationalException {

    CaseStartDate caseStartDate = new CaseStartDate();
    
    CaseHeaderCached caseHeaderCached = cachedCaseHeaderThreadLocal.get();

    boolean reloadCache = true;

    if (caseHeaderCached != null) {

      // variable to hold transaction type
      TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

      // If this is a batch transaction or deferred or online processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if (((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
        || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
        || (transactionType.equals(TransactionType.kOnline)
          && onlineCachingEnabled))
            && caseHeaderCached.caseHeaderDtls != null
            && caseHeaderCached.caseHeaderDtls.caseID == key.caseID) {

        caseStartDate.startDate = caseHeaderCached.caseHeaderDtls.startDate;

        reloadCache = false;

        // if this is a deferred transaction or online, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != caseHeaderCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    // Otherwise we need to read the CaseHeader data
    if (reloadCache) {
      // BEGIN, CR00279909, SG
      CaseHeaderDtls caseHeaderDtls = reloadCache(key);

      // END, CR00279909
      caseStartDate.startDate = caseHeaderDtls.startDate;
    }

    return caseStartDate;
  }
  // END, CR00052232
}
