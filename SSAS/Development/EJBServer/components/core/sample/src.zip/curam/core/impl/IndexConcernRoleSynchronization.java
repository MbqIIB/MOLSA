/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.sl.entity.struct.RepresentativeDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameAndVersion;
import curam.core.struct.RepresentativeConcernRoleKey;
import curam.core.struct.RepresentativeSummaryDetails;
import curam.core.struct.SynchronizeEventsDetails;
import curam.events.CONCERNROLE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class performs updates to the Search Server staging database when 
 * modifications are made to the Concern Role entity
 */
public abstract class IndexConcernRoleSynchronization extends
  curam.core.base.IndexConcernRoleSynchronization {

  // ___________________________________________________________________________
  /**
   * Post an event indicating that the specific concern role has been updated
   *
   * @param representativeConcernRoleKey The Representative concern role key
   * @param representativeDtls The representative details
   *
   */
  public void modifyRepresentativeSummaryDetails(
    final RepresentativeConcernRoleKey representativeConcernRoleKey,
    final RepresentativeSummaryDetails representativeSummaryDetails,
    final RepresentativeDtls representativeDtls) throws AppException,
      InformationalException {

    // BEGIN, CR00091119, DMC
    final SynchronizeEvents synchronizeEventsObj =
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails = 
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = 
      CONCERNROLE.MODIFY_CONCERN_ROLE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = 
      CONCERNROLE.MODIFY_CONCERN_ROLE.eventType;
    synchronizeEventsDetails.primaryEventData = 
      representativeConcernRoleKey.concernRoleID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
    // END, CR00091119
  }

  // ___________________________________________________________________________
  /**
   * Post an event indicating that the specific concern role has been updated
   *
   * @param dtls Data on which the searched will be based
   *
   */
  public void insert(final ConcernRoleDtls dtls) throws AppException,
      InformationalException {

    // BEGIN, CR00091119, DMC
    final SynchronizeEvents synchronizeEventsObj = 
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails = 
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = 
      CONCERNROLE.INSERT_CONCERN_ROLE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = 
      CONCERNROLE.INSERT_CONCERN_ROLE.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.concernRoleID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
    // END, CR00091119
  }

  // ___________________________________________________________________________
  /**
   * Post an event indicating that the specific concern role has been updated
   *
   * @param key Data on which the searched will be based
   *
   */
  public void modify(final ConcernRoleKey key, final ConcernRoleDtls dtls)
    throws AppException, InformationalException {
    
    sendModifyEvent(key);
  }

  // ___________________________________________________________________________
  /**
   * Post an event indicating that the specific concern role has been updated
   *
   * @param key Data on which the searched will be based
   * @param concernRoleNameAndVersion The concern role name and version
   *
   */
  public void modifyConcernRoleName(final ConcernRoleKey key,
    final ConcernRoleNameAndVersion concernRoleNameAndVersion) throws AppException,
      InformationalException {
    
    sendModifyEvent(key);
    
  }
  
  // ___________________________________________________________________________
  /**
   * Send a modify event indicating that the concern role has been updated
   *
   * @param key the concern role key
   */  
  // BEGIN, CR00198672, VK
  protected void sendModifyEvent(final ConcernRoleKey key) 
    throws AppException, InformationalException {
    // END, CR00198672
    final SynchronizeEvents synchronizeEventsObj = 
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails = 
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = 
      CONCERNROLE.MODIFY_CONCERN_ROLE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = 
      CONCERNROLE.MODIFY_CONCERN_ROLE.eventType;
    synchronizeEventsDetails.primaryEventData = key.concernRoleID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
  }
}
