/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.hook.impl;


import curam.codetable.CONCERNROLETYPE;
import curam.core.impl.MaintainAdminIntegratedCaseHookManager;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.infrastructure.impl.ImageIconConst;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.struct.AdminIntegratedCaseDetails;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.ICParticipantHomePageKey;
import curam.core.struct.ICParticipantHomePageName;
import curam.core.struct.ReadByCaseParticipantRoleIDKey;
import curam.message.BPOMAINTAINADMININTEGRATEDCASEHOOKREGISTRAR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.CodeTableItemIdentifier;


public class MaintainICParticipant extends curam.core.hook.base.MaintainICParticipant {

  /**
   * Returns the participant home page name.
   *
   * @param icParticipantHomePageKey to read the participant home page name.
   *
   * @return Participant home page name for the Integrated Case.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ICParticipantHomePageName getICParticipantHomePageName(
    ICParticipantHomePageKey icParticipantHomePageKey)
    throws AppException, InformationalException {

    ICParticipantHomePageName icParticipantHomePageName = new ICParticipantHomePageName();

    curam.core.intf.AdminIntegratedCase adminIntegratedCaseObj = curam.core.fact.AdminIntegratedCaseFactory.newInstance();

    AdminIntegratedCaseDetails adminIntegratedCaseDetails;

    curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    curam.core.intf.CachedCaseParticipantRole cachedCaseParticipantRoleObj = curam.core.fact.CachedCaseParticipantRoleFactory.newInstance();

    CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();
    CaseParticipantRoleDtlsList caseParticipantRoleDtlsList;

    boolean memberInd = false;
    boolean employerInd = false;
    boolean informationProviderInd = false;
    boolean productProviderInd = false;
    boolean personInd = false;
    boolean serviceSupplierInd = false;
    boolean utilityInd = false;
    // BEGIN CR00020910, SG
    boolean prospectPersonInd = false;
    // END CR00020910
    // BEGIN, CR00143128, SS
    boolean representativeInd = false;
    // END, CR00143128
    
    // BEGIN, CR00289968, ELG
    boolean prospectEmployerInd = false;
    // END, CR00289968

    ReadByCaseParticipantRoleIDKey readByCaseParticipantRoleIDKey = new ReadByCaseParticipantRoleIDKey();

    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    CaseParticipantRoleDtls caseParticipantRoleDtls;

    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleTypeDetails concernRoleTypeDetails;

    readByCaseParticipantRoleIDKey.caseParticipantRoleID = icParticipantHomePageKey.caseParticipantRoleID;

    adminIntegratedCaseDetails = adminIntegratedCaseObj.readByCaseParticipantRoleID(
      readByCaseParticipantRoleIDKey);

    caseParticipantRoleKey.caseParticipantRoleID = icParticipantHomePageKey.caseParticipantRoleID;

    caseParticipantRoleDtls = cachedCaseParticipantRoleObj.read(
      caseParticipantRoleKey);

    concernRoleKey.concernRoleID = caseParticipantRoleDtls.participantRoleID;
    concernRoleTypeDetails = concernRoleObj.readConcernRoleType(concernRoleKey);
    
    if (concernRoleTypeDetails.concernRoleType.equals(CONCERNROLETYPE.EMPLOYER)) {
      employerInd = true;
    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.INFORMATIONPROVIDER)) {
      informationProviderInd = true;
    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.PRODUCTPROVIDER)) {
      productProviderInd = true;
    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.SERVICESUPPLIER)) {
      serviceSupplierInd = true;

    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.UTILITY)) {
      utilityInd = true;
    } // BEGIN, CR00143128, SS 
    else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.REPRESENTATIVE)) {
      representativeInd = true;
    } // END, CR00143128
    else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.PERSON)
        || // BEGIN CR00020910, SG
        concernRoleTypeDetails.concernRoleType.equals(
          CONCERNROLETYPE.PROSPECTPERSON)) {
      // END CR00020910
      caseIDParticipantRoleKey.participantRoleID = caseParticipantRoleDtls.participantRoleID;
      caseIDParticipantRoleKey.caseID = caseParticipantRoleDtls.caseID;

      caseParticipantRoleDtlsList = caseParticipantRoleObj.searchByParticipantRoleAndCase(
        caseIDParticipantRoleKey);

      if (!caseParticipantRoleDtlsList.dtls.isEmpty()) {

        for (int i = 0; i < caseParticipantRoleDtlsList.dtls.size(); i++) {

          // set key to CaseParticipantRole update
          if ((caseParticipantRoleDtlsList.dtls.item(i).typeCode.equals(
            curam.codetable.CASEPARTICIPANTROLETYPE.DEFAULTCODE))
              || (caseParticipantRoleDtlsList.dtls.item(i).typeCode.equals(
                curam.codetable.CASEPARTICIPANTROLETYPE.MEMBER))
                || (caseParticipantRoleDtlsList.dtls.item(i).typeCode.equals(
                  curam.codetable.CASEPARTICIPANTROLETYPE.PLANPARTICIPANT))) {
            memberInd = true;
            break;
          }
        }
      }

      if (memberInd == false) {
        // BEGIN CR00020910, SG
        if (concernRoleTypeDetails.concernRoleType.equals(
          CONCERNROLETYPE.PERSON)) {
          personInd = true;
        } else {
          prospectPersonInd = true;
        }
        // END CR00020910
      }
      // BEGIN, CR00289968, ELG      
    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.PROSPECTEMPLOYER)) {
      prospectEmployerInd = true;  
    }
    // END, CR00289968
        
    if (memberInd == true) {
      icParticipantHomePageName.participantHomePageName = adminIntegratedCaseDetails.memberHomePageName;
      icParticipantHomePageName.participantIconName = ImageIconConst.kTypeMember;
    } else if (personInd == true) {
      icParticipantHomePageName.participantHomePageName = adminIntegratedCaseDetails.personHomePageName;
      icParticipantHomePageName.participantIconName = ImageIconConst.kTypePerson;
    } else if (employerInd == true) {
      icParticipantHomePageName.participantHomePageName = adminIntegratedCaseDetails.employerHomePageName;
      icParticipantHomePageName.participantIconName = ImageIconConst.kTypeEmployer;
    } else if (productProviderInd == true) {
      icParticipantHomePageName.participantHomePageName = adminIntegratedCaseDetails.productProviderHomePageName;
      icParticipantHomePageName.participantIconName = ImageIconConst.kTypeProductProvider;
    } else if (serviceSupplierInd == true) {
      icParticipantHomePageName.participantHomePageName = adminIntegratedCaseDetails.serviceSupplierHomePageName;
      icParticipantHomePageName.participantIconName = ImageIconConst.kTypeServiceSupplier;
    } else if (informationProviderInd == true) {
      icParticipantHomePageName.participantHomePageName = adminIntegratedCaseDetails.infoProviderHomePageName;
      icParticipantHomePageName.participantIconName = ImageIconConst.kTypeInfoProvider;
    } else if (utilityInd == true) {
      icParticipantHomePageName.participantHomePageName = adminIntegratedCaseDetails.utilityHomePageName;
      icParticipantHomePageName.participantIconName = ImageIconConst.kTypeUtility;
    } // BEGIN CR00020910, SG
    else if (prospectPersonInd == true) {
      icParticipantHomePageName.participantHomePageName = adminIntegratedCaseDetails.ppHomePageName;
      icParticipantHomePageName.participantIconName = ImageIconConst.kTypeProspectPerson;
    } // END CR00020910
    // BEGIN, CR00143128, SS
    else if (representativeInd == true) {
      icParticipantHomePageName.participantHomePageName = adminIntegratedCaseDetails.representativeHomePageName;
      icParticipantHomePageName.participantIconName = ImageIconConst.kTypeRepresentative;
      // BEGIN, CR00289968, ELG  
    } else if (prospectEmployerInd) {
      icParticipantHomePageName.participantHomePageName = UimConst.kResolveScriptForCaseParticipantHome;
      icParticipantHomePageName.participantIconName = ImageIconConst.kTypeProspectEmployer;
      // END, CR00289968  
    } else {
     
      // BEGIN, CR00289968, ELG
      curam.core.hook.intf.MaintainICParticipant maintainICParticipantHook = MaintainAdminIntegratedCaseHookManager.getHook(
        concernRoleTypeDetails.concernRoleType);
      
      if (maintainICParticipantHook.getClass().equals(this.getClass())) {
        
        AppException ae = new AppException(
          BPOMAINTAINADMININTEGRATEDCASEHOOKREGISTRAR.ERR_REGISTRAR_HOOK_UNAVAILABLE_FOR_CONCERNROLE_TYPE);

        ae.arg(
          new CodeTableItemIdentifier(CONCERNROLETYPE.TABLENAME,
          concernRoleTypeDetails.concernRoleType));
        throw new RuntimeException(ae); 
         
      } else {
        icParticipantHomePageName = maintainICParticipantHook.getICParticipantHomePageName(
          icParticipantHomePageKey);
      }
      // END, CR00289968

    }
    // END, CR00143128
    return icParticipantHomePageName;
  }
}
