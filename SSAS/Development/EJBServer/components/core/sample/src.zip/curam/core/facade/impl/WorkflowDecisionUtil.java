/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.facade.struct.AnswerDetails;
import curam.core.facade.struct.FreeFormAnswer;
import curam.core.facade.struct.MultipleChoiceAnswer;
import curam.core.facade.struct.QuestionDetails;
import curam.core.facade.struct.TaskIdentifier;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.workflow.impl.WorkflowDecisionAdmin;
import curam.util.workflow.struct.TaskKey;


/**
 * Utilities required by the decision activity task screen.
 *
 * Note: This interface should not be modified, as it is required by decision
 * activity tasks that are automatically created by the Workflow Engine.
 */
public abstract class WorkflowDecisionUtil extends curam.core.facade.base.WorkflowDecisionUtil {

  // ___________________________________________________________________________
  /**
   * Returns the details of a question for the decision activity task screen.
   *
   * @param taskIdentifier The task identifier associated with the question.
   * @return The details of the question and (optional) answers to be displayed.
   */
  public QuestionDetails readQuestionDetails(
    TaskIdentifier taskIdentifier) throws AppException, InformationalException {

    TaskKey taskKey = new TaskKey();

    taskKey.taskID = taskIdentifier.taskID;
    curam.util.workflow.struct.QuestionDetails questionDetailsInf = WorkflowDecisionAdmin.readQuestionDetails(
      taskKey);

    QuestionDetails questionDetailsApp = new QuestionDetails();

    questionDetailsApp.questionText = questionDetailsInf.questionText;

    final int size = questionDetailsInf.answers.size();

    for (int i = 0; i < size; i++) {
      AnswerDetails answerDetailsApp = new AnswerDetails();
      curam.util.workflow.struct.AnswerDetails answerDetailsInf = questionDetailsInf.answers.get(
        i);

      answerDetailsApp.answer = answerDetailsInf.answer;
      answerDetailsApp.answerID = answerDetailsInf.answerID;
      questionDetailsApp.answers.add(answerDetailsApp);
    }

    return questionDetailsApp;
  }

  // ___________________________________________________________________________
  /**
   * Inform the workflow engine of the answer to the question associated with
   * the task.
   *
   * @param taskIdentifier The task identifier associated with the question.
   * @param multipleChoiceAnswer The tab delimited list of answers selected.
   */
  public void answerMultipleChoiceQuestion(TaskIdentifier taskIdentifier,
    MultipleChoiceAnswer multipleChoiceAnswer)
    throws AppException, InformationalException {

    TaskKey taskKey = new TaskKey();

    taskKey.taskID = taskIdentifier.taskID;
    WorkflowDecisionAdmin.answerMultipleChoiceQuestion(taskKey,
      multipleChoiceAnswer.answerSelections);
  }

  // ___________________________________________________________________________
  /**
   * Inform the workflow engine of the answer to the question associated with
   * the task.
   *
   * @param taskIdentifier The task identifier associated with the question.
   * @param freeFormAnswer The free form text of the answer.
   */
  public void answerFreeFormQuestion(TaskIdentifier taskIdentifier,
    FreeFormAnswer freeFormAnswer)
    throws AppException, InformationalException {

    TaskKey taskKey = new TaskKey();

    taskKey.taskID = taskIdentifier.taskID;
    WorkflowDecisionAdmin.answerFreeFormQuestion(taskKey,
      freeFormAnswer.freeFormText);
  }
}
