/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.CASESTATUS;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.VERIFICATIONSTATUS;
import curam.codetable.VERIFICATIONTYPE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.struct.IsUserSupervisor;
import curam.core.sl.struct.OwnerInd;
import curam.core.struct.ActiveCasesConcernRoleIDAndTypeKey;
import curam.core.struct.BatchProcessingIDList;
import curam.core.struct.CaseAppealIndicatorDetails;
import curam.core.struct.CaseExpectedDatesAndOutcomesModifyDetails;
import curam.core.struct.CaseHeaderByStatusAndProduct;
import curam.core.struct.CaseHeaderByStatusKey;
import curam.core.struct.CaseHeaderDateDetails;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderDtlsList;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHeaderStatus;
import curam.core.struct.CaseHeaderStatusAndFromDateDtls;
import curam.core.struct.CaseIDAndRecordStatus;
import curam.core.struct.CaseIDConcernRoleID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReceivedDateVersionDetails;
import curam.core.struct.CaseSecurityCheck;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseSecurityCheckResult;
import curam.core.struct.CaseStartDateDetails;
import curam.core.struct.CheckProductSecurityDetails;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.IntegratedCaseTabKey;
import curam.core.struct.OwnerOrgObjectLinkID;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductSecurityKey;
import curam.core.struct.ReadICFinancialsByKey;
import curam.core.struct.RoleByCaseStatusTypeKey;
import curam.core.struct.UserNameKey;
import curam.core.struct.UserNameTypeAndStatusCode;
import curam.events.CASE;
import curam.message.BPOCASEHEADER;
import curam.message.GENERALCASE;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.type.Date;


/**
 * CaseHeader Definition: An interaction a concern has with the Social Security
 * Agency.
 *
 */
public abstract class CaseHeader extends curam.core.base.CaseHeader {

  // ___________________________________________________________________________
  /**
   * Post insert case header details record
   *
   * @param details Record details to be inserted onto database.
   */
  @Override
  protected void postinsert(CaseHeaderDtls details) throws AppException, InformationalException {

    // Synchronize the indexed staging database with the update to the CaseHeader entity.
    curam.core.intf.IndexCaseHeaderSynchronization indexCaseHeaderSynchronization = curam.core.fact.IndexCaseHeaderSynchronizationFactory.newInstance();

    indexCaseHeaderSynchronization.insert(details);
    
    // BEGIN, CR00305960, HAR
    final Event event = new Event();

    event.eventKey.eventClass = CASE.CASE_CREATED.eventClass;
    event.eventKey.eventType = CASE.CASE_CREATED.eventType;
    event.primaryEventData = details.caseID;
    EventService.raiseEvent(event);
    // END, CR00305960
  }

  // ___________________________________________________________________________
  /**
   * Post modify case header status
   *
   * @param key Contains the case header identifier.
   * @param dtls Record details to be inserted onto database.
   */
  @Override
  protected void postmodifyCaseHeaderStatus(CaseHeaderKey key, CaseHeaderStatusAndFromDateDtls dtls)
    throws AppException, InformationalException {

    // Synchronize the indexed staging database with the update to the CaseHeader entity.
    curam.core.intf.IndexCaseHeaderSynchronization indexCaseHeaderSynchronization = curam.core.fact.IndexCaseHeaderSynchronizationFactory.newInstance();

    indexCaseHeaderSynchronization.modifyCaseHeaderStatus(key, dtls);
  }

  // BEGIN, CR00295972, GD
  // ___________________________________________________________________________
  /**
   * Modify case header case owner details
   *
   * @param key Contains the case header identifier.
   * @param dtls Owner org object link details inserted on to database.
   */
  public void modifyCaseOwner(CaseIDConcernRoleID key,
    OwnerOrgObjectLinkID dtls) throws AppException, InformationalException {

    CaseHeaderDtlsList caseHeaderDtlsList = searchByCaseIDConcernRoleID(key);
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    
    for (int i = 0; i < caseHeaderDtlsList.dtls.size(); i++) {
      caseHeaderKey.caseID = caseHeaderDtlsList.dtls.item(i).caseID;
      modifyCaseOwner(caseHeaderKey, dtls);
    }
        
    curam.core.intf.IndexCaseHeaderSynchronization indexCaseHeaderSynchronization = curam.core.fact.IndexCaseHeaderSynchronizationFactory.newInstance();

    indexCaseHeaderSynchronization.modifyCaseOwner(key, dtls);
  }

  // END, CR00295972

  // ___________________________________________________________________________
  /**
   * Post modify appeal indicator
   *
   * @param key Contains the case header identifier.
   * @param dtls Case Appeal details.
   */
  @Override
  protected void postmodifyAppealIndicator(final CaseHeaderKey key, final CaseAppealIndicatorDetails dtls)
    throws AppException, InformationalException {

    // Synchronize the indexed staging database with the update to the CaseHeader entity.
    curam.core.intf.IndexCaseHeaderSynchronization indexCaseHeaderSynchronization = curam.core.fact.IndexCaseHeaderSynchronizationFactory.newInstance();

    indexCaseHeaderSynchronization.modifyAppealIndicator(key, dtls);
  }

  // ___________________________________________________________________________
  /**
   * Post modify expected dates and outcomes details
   *
   * @param key Contains the case header identifier
   * @param details Case expected dates and outcome modify details
   */
  @Override
  protected void postmodifyExpectedDatesAndOutcomes(CaseHeaderKey key, CaseExpectedDatesAndOutcomesModifyDetails details)
    throws AppException, InformationalException {

    // Synchronize the indexed staging database with the update to the CaseHeader entity.
    curam.core.intf.IndexCaseHeaderSynchronization indexCaseHeaderSynchronization = curam.core.fact.IndexCaseHeaderSynchronizationFactory.newInstance();

    indexCaseHeaderSynchronization.modifyExpectedDatesAndOutcomes(key, details);
  }

  // ___________________________________________________________________________
  /**
   * Post modify case header status details record
   *
   * @param key Contains the case header identifier.
   * @param details Record details to be inserted onto database.
   */
  @Override
  protected void postmodifyStatus(CaseHeaderKey key, CaseHeaderStatus details)
    throws AppException, InformationalException {

    // Synchronize the indexed staging database with the update to the CaseHeader entity.
    curam.core.intf.IndexCaseHeaderSynchronization indexCaseHeaderSynchronization = curam.core.fact.IndexCaseHeaderSynchronizationFactory.newInstance();

    indexCaseHeaderSynchronization.modifyStatus(key, details);

  }

  // ___________________________________________________________________________
  /**
   * Description: Method to check that user has appropriate privileges to create
   * the case
   *
   * @param key
   * case security key
   *
   * @return true if the user has the correct privileges
   */
  public CaseSecurityCheckResult creationSecurityCheck(CaseSecurityCheck key)
    throws AppException, InformationalException {

    CaseSecurityCheckResult caseSecurityCheckResult = new CaseSecurityCheckResult();

    // If the transaction is not online, no checks required!
    if (!(curam.util.transaction.TransactionInfo.getTransactionType().equals(
      curam.util.transaction.TransactionInfo.TransactionType.kOnline))) {
      caseSecurityCheckResult.result = true;
      return caseSecurityCheckResult;
    }

    // declarations for user security privilege checks
    curam.core.intf.CheckProductSecurity checkProductSecurityObj = curam.core.fact.CheckProductSecurityFactory.newInstance();
    ProductSecurityKey productSecurityKey = new ProductSecurityKey();
    CheckProductSecurityDetails checkProductSecurityDetails;
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;
    curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();

    caseHeaderKey.caseID = key.caseID;

    // Get the client ID
    caseHeaderDtls = read(caseHeaderKey);

    // we need to perform a product delivery read in order to return the
    // productID which is needed in the case security check to check that our
    // user has creation rights to it
    if ((caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.PRODUCTDELIVERY))
        || (caseHeaderDtls.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.LIABILITY))) {

      if (key.userName.length() > 0) {
        productSecurityKey.userName = key.userName;
      }

      productDeliveryKey.caseID = key.caseID;

      if (key.productID == 0) {

        productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

        productSecurityKey.productID = productDeliveryDtls.productID;

      } else {

        productSecurityKey.productID = key.productID;
      }

      checkProductSecurityDetails = checkProductSecurityObj.checkUserCreate(
        productSecurityKey);

      caseSecurityCheckResult.result = checkProductSecurityDetails.result;
    } else {

      caseSecurityCheckResult.result = true;
    }

    return caseSecurityCheckResult;
  }

  // ___________________________________________________________________________
  /**
   * Description: Method to check that user has appropriate privileges to
   * approve the case
   *
   * @param key
   * case security key
   *
   * @return true if the user has the correct privileges
   */
  public CaseSecurityCheckResult approvalSecurityCheck(CaseSecurityCheck key)
    throws AppException, InformationalException {

    CaseSecurityCheckResult caseSecurityCheckResult = new CaseSecurityCheckResult();

    // If the transaction is not online, no checks required!
    if (!(curam.util.transaction.TransactionInfo.getTransactionType().equals(
      curam.util.transaction.TransactionInfo.TransactionType.kOnline))) {
      caseSecurityCheckResult.result = true;
      return caseSecurityCheckResult;
    }

    // declarations for user security privilege checks
    curam.core.intf.CheckProductSecurity checkProductSecurityObj = curam.core.fact.CheckProductSecurityFactory.newInstance();
    ProductSecurityKey productKeyStruct = new ProductSecurityKey();
    CheckProductSecurityDetails checkProductSecurityDetails;

    if ((key.caseTypeCode.equals(curam.codetable.CASETYPECODE.PRODUCTDELIVERY))
      || (key.caseTypeCode.equals(curam.codetable.CASETYPECODE.LIABILITY))) {

      if (key.userName.length() > 0) {
        productKeyStruct.userName = key.userName;
      }

      productKeyStruct.productID = key.productID;
      checkProductSecurityDetails = checkProductSecurityObj.checkUserApprove(
        productKeyStruct);

      caseSecurityCheckResult.result = checkProductSecurityDetails.result;
    } else {

      caseSecurityCheckResult.result = true;
    }

    return caseSecurityCheckResult;
  }

  // ___________________________________________________________________________
  /**
   * Description: Method to check that user has appropriate privileges to read
   * the case
   *
   * @param key
   * case security key
   *
   * @return true if the user has the correct privileges
   */
  public CaseSecurityCheckResult readSecurityCheck(CaseSecurityCheck key)
    throws AppException, InformationalException {

    CaseSecurityCheckResult caseSecurityCheckResult = new CaseSecurityCheckResult();

    // If the transaction is not online, no checks required!
    if (!curam.util.transaction.TransactionInfo.getTransactionType().equals(
      curam.util.transaction.TransactionInfo.TransactionType.kOnline)) {
      caseSecurityCheckResult.result = true;
      caseSecurityCheckResult.approveRights = true;
      caseSecurityCheckResult.maintainRights = true;
      return caseSecurityCheckResult;
    }

    // declarations for user security privilege checks
    curam.core.intf.CheckProductSecurity checkProductSecurityObj = curam.core.fact.CheckProductSecurityFactory.newInstance();
    ProductSecurityKey productSecurityKey = new ProductSecurityKey();

    CheckProductSecurityDetails checkProductSecurityDetails;

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;
    curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();

    caseHeaderKey.caseID = key.caseID;

    // Get the client ID
    caseHeaderDtls = read(caseHeaderKey);

    // we need to perform a product delivery read in order to return the
    // productID which is needed in our the case security check to check that
    // our user has read rights to it
    if ((caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.PRODUCTDELIVERY))
        || (caseHeaderDtls.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.LIABILITY))) {

      if (key.userName.length() > 0) {
        productSecurityKey.userName = key.userName;
      }

      productDeliveryKey.caseID = key.caseID;

      if (key.productID == 0) {

        productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

        productSecurityKey.productID = productDeliveryDtls.productID;

      } else {

        productSecurityKey.productID = key.productID;
      }

      checkProductSecurityDetails = checkProductSecurityObj.checkUserReadWrite(
        productSecurityKey);

      caseSecurityCheckResult.result = checkProductSecurityDetails.result;
      caseSecurityCheckResult.approveRights = checkProductSecurityDetails.approveRights;
      caseSecurityCheckResult.maintainRights = checkProductSecurityDetails.maintainRights;

    } else {

      caseSecurityCheckResult.result = true;
      caseSecurityCheckResult.approveRights = true;
      caseSecurityCheckResult.maintainRights = true;
    }

    return caseSecurityCheckResult;
  }

  // ___________________________________________________________________________
  /**
   * Description: Method to check that user has appropriate privileges to
   * maintain the case
   *
   * @param key
   * case security key
   *
   * @return true if the user has the correct privileges
   */
  public CaseSecurityCheckResult maintainSecurityCheck(CaseSecurityCheck key)
    throws AppException, InformationalException {

    // result of user security privilege checks
    CaseSecurityCheckResult caseSecurityCheckResult = new CaseSecurityCheckResult();

    // If the transaction is not online, no checks required!
    if (!curam.util.transaction.TransactionInfo.getTransactionType().equals(
      curam.util.transaction.TransactionInfo.TransactionType.kOnline)) {
      caseSecurityCheckResult.result = true;
      return caseSecurityCheckResult;
    }

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // if there is no caseTypeCode make sure that case exists
    if (key.caseTypeCode.length() == 0) {
      caseHeaderKey.caseID = key.caseID;

      // Get the client ID
      caseHeaderDtls = read(caseHeaderKey);
    } else {
      caseHeaderDtls = null;

    }

    // we need to perform a product delivery read in order to return
    // the productID which is needed in the case security check to check
    // that our user has maintenance rights to it
    if (caseHeaderDtls != null
      && (caseHeaderDtls.caseTypeCode.equals(
        curam.codetable.CASETYPECODE.PRODUCTDELIVERY)
          || caseHeaderDtls.caseTypeCode.equals(
            curam.codetable.CASETYPECODE.LIABILITY))) {

      curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();

      // declarations for user security privilege checks
      curam.core.intf.CheckProductSecurity checkProductSecurityObj = curam.core.fact.CheckProductSecurityFactory.newInstance();

      ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      ProductSecurityKey productSecurityKey = new ProductSecurityKey();

      // CaseUserRole object, search key and details list
      curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

      // BEGIN, CR00060051, PMD
      // Set the userNameKey to be the current user
      UserNameKey userNameKey = new UserNameKey();

      userNameKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

      // Check if the current user is the case owner or is
      // part of an organization object that owns the case
      OwnerInd isUserOwner = caseUserRoleObj.isUserCaseOwner(userNameKey,
        caseHeaderKey);

      // Check if the current user is a supervisor
      IsUserSupervisor isUserSupervisor = caseUserRoleObj.isUserSupervisor(
        caseHeaderKey, userNameKey);

      if (!isUserOwner.ownerInd && !isUserSupervisor.isUserSupervisor) {

        // BEGIN, CR00074064, CSH
        // Find the value for ownerID using the OrgObjectLinkID
        OrgObjectLink orgObjectLinkObj = OrgObjectLinkFactory.newInstance();

        // Set the OrgObjectLinkKey
        OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();

        orgObjectLinkKey.orgObjectLinkID = caseHeaderDtls.ownerOrgObjectLinkID;

        // Read the CaseOrgObjectLink record
        OrgObjectLinkDtls orgObjectLinkDtls = orgObjectLinkObj.read(
          orgObjectLinkKey);

        // If the owner is a user, set the ownerID to be the userName
        if (orgObjectLinkDtls.orgObjectType.equals(ORGOBJECTTYPE.USER)) {
          productSecurityKey.ownerID = orgObjectLinkDtls.userName;
        }
        // END, CR00074064
      }

      // END, CR00060051

      if (key.productID == 0) {

        ProductDeliveryDtls productDeliveryDtls = productDeliveryObj.read(
          productDeliveryKey);

        productSecurityKey.productID = productDeliveryDtls.productID;

      } else {

        productSecurityKey.productID = key.productID;
      }

      if (key.userName.length() > 0) {
        productSecurityKey.userName = key.userName;
      }

      CheckProductSecurityDetails checkProductSecurityDetails = checkProductSecurityObj.checkUserMaintain(
        productSecurityKey);

      caseSecurityCheckResult.result = checkProductSecurityDetails.result;
      caseSecurityCheckResult.maintainRights = checkProductSecurityDetails.maintainRights;
      caseSecurityCheckResult.approveRights = checkProductSecurityDetails.approveRights;

    } else {

      caseSecurityCheckResult.result = true;
      caseSecurityCheckResult.maintainRights = true;
      caseSecurityCheckResult.approveRights = true;

    }
    return caseSecurityCheckResult;
  }

  // ___________________________________________________________________________
  /**
   * Sets the required details to retrieve the case owner
   *
   * @param key
   * Identifies the case
   */
  @Override
  protected void prereadCaseOwnerByTypeAndStatus(RoleByCaseStatusTypeKey key)
    throws AppException, InformationalException {

    key.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    key.typeCode = curam.codetable.CASEUSERROLETYPE.OWNER;

  }

  // ___________________________________________________________________________
  /**
   * Sets the required details to retrieve the case supervisor
   *
   * @param key
   * Identifies the case
   */
  @Override
  protected void prereadCaseSupervisor(RoleByCaseStatusTypeKey key)
    throws AppException, InformationalException {

    key.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
    key.typeCode = curam.codetable.CASEUSERROLETYPE.SUPERVISOR;

  }

  // ___________________________________________________________________________
  /**
   * Set the key to include open records
   *
   * @param key
   * the UserNameTypeAndStatusCode key
   */
  @Override
  protected void precountNumberOpenCasesForUser(UserNameTypeAndStatusCode key)
    throws AppException, InformationalException {

    key.statusCode = curam.codetable.CASESTATUS.OPEN;

  }

  // ___________________________________________________________________________
  /**
   * Reads the case type, concern and owner or object link id for the case.
   *
   * @param key
   * Identifies the case
   */
  protected void prereadTypeConcernAndOwnerOrgObjectLinkID(
    CaseIDAndRecordStatus key) throws AppException,
      InformationalException {

    key.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;
  }

  // ___________________________________________________________________________
  /**
   * Calls validate method prior to modification
   *
   * @param key
   * Identifies the case
   * @param dtls
   * The case received date details to be modified
   */
  @Override
  protected void premodifyReceivedDate(CaseKey key,
    CaseReceivedDateVersionDetails dtls) throws AppException,
      InformationalException {

    modifyReceivedDateValidate(dtls);
  }

  // ___________________________________________________________________________
  /**
   * Handles receipt date modification validation
   *
   * @param dtls
   * The case received date details to be validated
   */
  @Override
  protected void modifyReceivedDateValidate(CaseReceivedDateVersionDetails dtls)
    throws AppException, InformationalException {

    // Today's date
    Date currentDate = Date.getCurrentDate();

    // received date
    if (dtls.receivedDate.after(currentDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCASEHEADER.ERR_CASEHEADER_FV_MODIFIEDRECEIVEDDATEINVALID),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Determines whether the input ID field will be converted to a NULL value for
   * use in SQL and sets the indicator field accordingly. This avoids the need
   * for database-specific CAST statements in the generated SQL.
   *
   * @param key
   * the key struct used for the read
   */
  @Override
  protected void presearchFinancialInstructionsForIC(ReadICFinancialsByKey key)
    throws AppException, InformationalException {
    key.concernRoleIDIsNull = (key.concernRoleID == 0);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readCaseSupervisor
   */
  public curam.core.struct.OrgObjectLinkIDAndCaseRef getCaseSupervisor(
    curam.core.struct.RoleByCaseStatusTypeKey key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {
    return CaseHeaderFactory.newInstance().readCaseSupervisor(key);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readCaseOwnerByTypeAndStatus
   */
  public curam.core.sl.entity.struct.OrgObjectLinkKey getCaseOwner(
    curam.core.struct.RoleByCaseStatusTypeKey key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {
    return CaseHeaderFactory.newInstance().readCaseOwnerByTypeAndStatus(key);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyEffectiveDate
   */
  public void setEffectiveDate(curam.core.struct.CaseHeaderKey key,
    curam.core.struct.EffectiveDateKey details)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {
    CaseHeaderFactory.newInstance().modifyEffectiveDate(key, details);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyStatus
   */
  public void updateStatus(curam.core.struct.CaseHeaderKey key,
    curam.core.struct.CaseHeaderStatus details)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {
    CaseHeaderFactory.newInstance().modifyStatus(key, details);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by modifyCaseStartDate
   */
  public void updateCaseStartDate(curam.core.struct.CaseHeaderKey key,
    curam.core.struct.CaseStartDateDetails details)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {
    CaseHeaderFactory.newInstance().modifyCaseStartDate(key, details);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchProductDeliveryEligibilityByStatusAndProduct
   */
  public BatchProcessingIDList getDetailsForDetermineProdDelEligByStatusAndProduct(
    CaseHeaderByStatusAndProduct caseHeaderByStatusAndProduct)
    throws AppException,
      InformationalException {
    return CaseHeaderFactory.newInstance().searchProductDeliveryEligibilityByStatusAndProduct(
      caseHeaderByStatusAndProduct);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchProductDeliveryEligibilityByStatus
   */
  public curam.core.struct.BatchProcessingIDList getDetailsForDetermineProdDelEligByStatus(
    CaseHeaderByStatusKey caseHeaderByStatusKey)
    throws AppException,
      InformationalException {
    return CaseHeaderFactory.newInstance().searchProductDeliveryEligibilityByStatus(
      caseHeaderByStatusKey);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchConcernRoleIDType
   * The name searchActiveCasesByTypeConcernRoleID was misleading as no filtering was performed on the case status.
   */
  public curam.core.struct.CaseHeaderDtlsList searchActiveCasesByTypeConcernRoleID(ActiveCasesConcernRoleIDAndTypeKey key)
    throws AppException,
      InformationalException {
    return CaseHeaderFactory.newInstance().searchByConcernRoleIDType(key);
  }

  // ___________________________________________________________________________
  /**
   * Calls ProductDeliveryPlanItemLink to ensure that the dates on Case Header
   * and on possible associated Planned Item are the same.
   *
   * @param key
   * unique case identifier
   * @param details
   * modification details
   */
  @Override
  protected void premodify(CaseHeaderKey key, CaseHeaderDtls details)
    throws AppException, InformationalException {

    // Product Delivery Planned Item link entity object
    curam.core.sl.entity.intf.ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = curam.core.sl.entity.fact.ProductDeliveryPlanItemLinkFactory.newInstance();
    curam.core.sl.entity.struct.PlannedItemModifyDatesDetails plannedItemModifyDatesDetails = new curam.core.sl.entity.struct.PlannedItemModifyDatesDetails();
    curam.core.sl.entity.struct.PlannedItemModifyStartDateDetails plannedItemModifyStartDateDetails = new curam.core.sl.entity.struct.PlannedItemModifyStartDateDetails();

    // read current case status
    curam.core.struct.CaseStatusCode caseStatusCode = readCaseStatus(key);

    // Activation process uses modify method to update case status to ACTIVE.
    // If the case is activated actual start date for associated PI must be
    // set and status must be changed to "In Progress".

    if ((!caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE))
      && (details.statusCode.equals(CASESTATUS.ACTIVE))) {

      plannedItemModifyStartDateDetails.plannedItemActualStartDate = details.startDate;

      // modify planned item start date (it takes care of PI status)
      productDeliveryPlanItemLinkObj.modifyPlannedItemStartDate(key,
        plannedItemModifyStartDateDetails);

    } else if (((caseStatusCode.statusCode.equals(CASESTATUS.CLOSED))
      || (caseStatusCode.statusCode.equals(CASESTATUS.PENDINGCLOSURE)))
        && (!((details.statusCode.equals(CASESTATUS.CLOSED))
          || (details.statusCode.equals(CASESTATUS.PENDINGCLOSURE))))) {// do nothing as in this case appropriated method is called from
      // reactivateCase
    } else {

      if (details.startDate.before(details.expectedStartDate)) {
        plannedItemModifyDatesDetails.plannedItemExpectedStartDate = details.startDate;
        details.expectedStartDate = details.startDate;
      } else {
        plannedItemModifyDatesDetails.plannedItemExpectedStartDate = details.expectedStartDate;
      }

      plannedItemModifyDatesDetails.plannedItemActualStartDate = details.startDate;
      plannedItemModifyDatesDetails.plannedItemActualEndDate = details.endDate;
      plannedItemModifyDatesDetails.plannedItemExpectedEndDate = details.expectedEndDate;

      // modify associated planned item dates
      productDeliveryPlanItemLinkObj.modifyPlannedItemDates(key,
        plannedItemModifyDatesDetails);
    }
    // BEGIN, CR00227042, PM
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();
    DataBasedSecurityResult dataBasedSecurityResult;

    // map values to internal struct
    if (details.caseID != 0) {
      caseSecurityCheckKey.caseID = details.caseID;
      caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

      // check if the user is allowed to access this case
      try {
        dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
          caseSecurityCheckKey);

        if (!dataBasedSecurityResult.result) {
          throw new AppException(
            GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
        }
      } catch (RecordNotFoundException rnfe) {// Do Nothing
      }
      // END, CR00227042
    }

  }

  // ___________________________________________________________________________
  /**
   * Calls ProductDeliveryPlanItemLink to ensure that the dates on Case Header
   * and on possible associated Planned Item are the same.
   *
   * @param key
   * unique case identifier
   * @param dtls
   * modification details
   */
  @Override
  protected void premodifyCaseHeaderDates(CaseHeaderKey key,
    CaseHeaderDateDetails dtls)
    throws AppException, InformationalException {

    // Product Delivery Planned Item link entity object
    curam.core.sl.entity.intf.ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = curam.core.sl.entity.fact.ProductDeliveryPlanItemLinkFactory.newInstance();
    curam.core.sl.entity.struct.PlannedItemModifyDatesDetails plannedItemModifyDatesDetails = new curam.core.sl.entity.struct.PlannedItemModifyDatesDetails();

    plannedItemModifyDatesDetails.plannedItemActualStartDate = dtls.startDate;
    plannedItemModifyDatesDetails.plannedItemActualEndDate = dtls.endDate;
    plannedItemModifyDatesDetails.plannedItemExpectedStartDate = dtls.expectedStartDate;
    plannedItemModifyDatesDetails.plannedItemExpectedEndDate = dtls.expectedEndDate;

    // modify associated planned item dates
    productDeliveryPlanItemLinkObj.modifyPlannedItemDates(key,
      plannedItemModifyDatesDetails);

  }

  // ___________________________________________________________________________
  /**
   * Calls ProductDeliveryPlanItemLink to ensure that the dates on Case Header
   * and on possible associated Planned Item are the same.
   *
   * @param key
   * unique case identifier
   * @param details
   * modification details
   */
  @Override
  protected void premodifyCaseStartDate(CaseHeaderKey key,
    CaseStartDateDetails details)
    throws AppException, InformationalException {

    // Product Delivery Planned Item link entity object
    curam.core.sl.entity.intf.ProductDeliveryPlanItemLink productDeliveryPlanItemLinkObj = curam.core.sl.entity.fact.ProductDeliveryPlanItemLinkFactory.newInstance();
    curam.core.sl.entity.struct.PlannedItemModifyStartDateDetails plannedItemModifyStartDateDetails = new curam.core.sl.entity.struct.PlannedItemModifyStartDateDetails();

    plannedItemModifyStartDateDetails.plannedItemActualStartDate = details.startDate;

    // modify associated planned item dates
    productDeliveryPlanItemLinkObj.modifyPlannedItemStartDate(key,
      plannedItemModifyStartDateDetails);

  }

  // ___________________________________________________________________________
  /**
   * Invokes validation after the insertion of case header details.
   *
   * @param key
   * unique case identifier
   * @param details
   * modification details
   */
  @Override
  protected void postmodify(CaseHeaderKey key, CaseHeaderDtls details) throws AppException, InformationalException {
    // Synchronize the indexed staging database with the update to the CaseHeader entity.
    curam.core.intf.IndexCaseHeaderSynchronization indexCaseHeaderSynchronization = curam.core.fact.IndexCaseHeaderSynchronizationFactory.newInstance();

    indexCaseHeaderSynchronization.modify(key, details);

  }

  // ___________________________________________________________________________
  /**
   * Invokes validation after the insertion of case header dates.
   *
   * @param key
   * unique case identifier
   * @param dtls
   * date details
   */
  @Override
  protected void postmodifyCaseHeaderDates(CaseHeaderKey key, CaseHeaderDateDetails dtls) throws AppException, InformationalException {
    // Synchronize the indexed staging database with the update to the CaseHeader entity.
    curam.core.intf.IndexCaseHeaderSynchronization indexCaseHeaderSynchronization = curam.core.fact.IndexCaseHeaderSynchronizationFactory.newInstance();

    indexCaseHeaderSynchronization.modifyCaseHeaderDates(key, dtls);

  }

  // ___________________________________________________________________________
  /**
   * Invokes validation after the insertion of start date details.
   *
   * @param key
   * unique case identifier
   * @param details
   * modification details
   */
  @Override
  protected void postmodifyCaseStartDate(CaseHeaderKey key, CaseStartDateDetails details) throws AppException, InformationalException {

    // Synchronize the indexed staging database with the update to the CaseHeader entity.
    curam.core.intf.IndexCaseHeaderSynchronization indexCaseHeaderSynchronization = curam.core.fact.IndexCaseHeaderSynchronizationFactory.newInstance();

    indexCaseHeaderSynchronization.modifyCaseStartDate(key, details);

  }

  // BEGIN, CR00194814, ZV
  // ___________________________________________________________________________
  /**
   * This method is called before reading integrated case tab details.
   * Sets default read key values.
   *
   * @param key - Contains the integrated case id and read values.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected void prereadIntegratedCaseTabDetails(
    IntegratedCaseTabKey key) throws AppException, InformationalException {
    key.cancelledCaseStatus = CASESTATUS.CANCELED;
    key.closedCaseStatus = CASESTATUS.CLOSED;
    key.evidenceDescriptorActive = EVIDENCEDESCRIPTORSTATUS.ACTIVE;
    key.evidenceDescriptorInedit = EVIDENCEDESCRIPTORSTATUS.INEDIT;
    key.integratedCaseLinkType = VERIFICATIONTYPE.INTEGRATEDCASE;
    key.nonVerifiedStatus = VERIFICATIONSTATUS.NOTVERIFIED;
  }
  // END, CR00194814
}

