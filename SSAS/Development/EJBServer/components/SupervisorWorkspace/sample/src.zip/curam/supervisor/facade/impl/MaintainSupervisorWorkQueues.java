/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * Copyright (c) 2007, 2009, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.supervisor.facade.impl;


import java.util.Iterator;

import curam.codetable.TASKSTATUS;
import curam.codetable.VIEWTASKSOPTION;
import curam.codetable.WORKQUEUETASKOPTIONPAGE;
import curam.core.facade.struct.ActionIDProperty;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.WorkQueueDetailsList;
import curam.core.sl.entity.struct.WorkQueueDtls;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.entity.struct.WorkQueueSensitivityAndAllowUserSubscriptionDetails;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.struct.WorkQueueSearchKey;
import curam.core.sl.supervisor.fact.UserWorkspaceFactory;
import curam.core.sl.supervisor.fact.WorkQueueWorkspaceFactory;
import curam.core.sl.supervisor.intf.UserWorkspace;
import curam.core.sl.supervisor.intf.WorkQueueWorkspace;
import curam.core.sl.supervisor.struct.UserSubscriptionToWorkQueueDetails;
import curam.core.struct.SensitivityCode;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.message.BPOSUPERVISORUSER;
import curam.message.BPOWORKQUEUE;
import curam.message.GENERALSEARCH;
import curam.supervisor.facade.struct.ListDeferredTasksReservedByWorkQueueUserDetails;
import curam.supervisor.facade.struct.ListOpenTasksReservedByWorkQueueUserDetails;
import curam.supervisor.facade.struct.ListWorkQueueTasksDueByWeekDetails;
import curam.supervisor.facade.struct.ListWorkQueueTasksDueOnDateDetails;
import curam.supervisor.facade.struct.ReserveWorkQueueTasksToUserKey;
import curam.supervisor.facade.struct.ResolveWorkQueuePageDetails;
import curam.supervisor.facade.struct.ResolveWorkQueueReservedTaskPageKey;
import curam.supervisor.facade.struct.ResolveWorkQueueTaskOptionPageKey;
import curam.supervisor.facade.struct.UserNameAndWorkQueueIDKey;
import curam.supervisor.facade.struct.UserOrgObjectWorkQueueTaskCountList;
import curam.supervisor.facade.struct.WorkQueueAssignedTasksSummaryDetailsList;
import curam.supervisor.facade.struct.WorkQueueIDAndTaskOptionKey;
import curam.supervisor.facade.struct.WorkQueueReservedTasksByUserDueByWeekDetailsList;
import curam.supervisor.facade.struct.WorkQueueReservedTasksByUserDueOnDateDetailsList;
import curam.supervisor.facade.struct.WorkQueueReservedTasksByUserKey;
import curam.supervisor.facade.struct.WorkQueueReservedTasksDetails;
import curam.supervisor.facade.struct.WorkQueueSearchCriteria;
import curam.supervisor.facade.struct.WorkQueueSubscribersScheduleDetails;
import curam.supervisor.facade.struct.WorkQueueTasksDueOnDateKey;
import curam.supervisor.facade.struct.WorkQueueWorkspaceDtls;
import curam.supervisor.facade.struct.WorkqueueUsersScheduleDetailsList;
import curam.supervisor.sl.fact.MaintainSupervisorWorkQueuesFactory;
import curam.supervisor.sl.fact.SupervisorApplicationPageContextDescriptionFactory;
import curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription;
import curam.supervisor.sl.struct.SubscribeUserWorkQueueKey;
import curam.supervisor.sl.struct.SupervisorApplicationPageContextDetails;
import curam.supervisor.sl.struct.WorkQueueReservedTasksByUserDueOnDateDetails;
import curam.supervisor.sl.struct.WorkQueueTabDetails;
import curam.supervisor.sl.struct.WorkqueueIDAndStartDateKey;
import curam.util.codetable.TASKRESERVEDSEARCHSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * Facade layer class for Supervisor Work queue activities
 *
 */
public abstract class MaintainSupervisorWorkQueues extends curam.supervisor.facade.base.MaintainSupervisorWorkQueues {

  // ___________________________________________________________________________
  /**
   * Returns a list of work queues the supervisor is an administrator of and
   * work queues subscribed to by the supervisor's subordinates.
   *
   * @return A list of work queues along with the number of open tasks currently
   * in each queue. The work queues returned are the work queues the
   * supervisor is an administrator of and work queues subscribed to by
   * the supervisor's subordinates
   *
   * @deprecated Since Curam 6.0. Replaced by
   * {@link #listSupervisorAndOrgObjectWorkQueues}. See release notes for
   * CR00221722. The new method also returns the work queues subscribed to by
   * the supervisor's organization objects.
   */
  @Deprecated
  public curam.supervisor.facade.struct.WorkQueueAndTaskCountDetailsList listWorkQueues() throws
      AppException, InformationalException {

    WorkQueueWorkspace workspace = WorkQueueWorkspaceFactory.newInstance();
    curam.supervisor.facade.struct.WorkQueueAndTaskCountDetailsList countDetailsList = new curam.supervisor.facade.struct.WorkQueueAndTaskCountDetailsList();
    UserNameKey key = new UserNameKey();
    SystemUser systemUser = SystemUserFactory.newInstance();

    key.userName = systemUser.getUserDetails().userName;
    countDetailsList.detailsList = workspace.listWorkQueues(key);

    SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    SupervisorApplicationPageContextDetails contextDetails = contextDescription.readLoggedInUserName();

    countDetailsList.contextDescription = contextDetails;

    return countDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of work queues the supervisor is an administrator of and
   * work queues subscribed to by the supervisor's subordinates as well as work
   * queues subscribed to by the supervisor's organization objects. The number
   * of open tasks currently in each queue is also returned.
   *
   * @return A list of work queues along with the number of open tasks currently
   * in each queue. The work queues returned are the work queues the
   * supervisor is an administrator of and work queues subscribed to by
   * the supervisor's subordinates as well as work queues subscribed to
   * by the supervisor's organization objects
   */
  public UserOrgObjectWorkQueueTaskCountList listSupervisorAndOrgObjectWorkQueues() throws
      AppException, InformationalException {

    WorkQueueWorkspace workspace = WorkQueueWorkspaceFactory.newInstance();
    UserOrgObjectWorkQueueTaskCountList countDetailsList = new UserOrgObjectWorkQueueTaskCountList();
    UserNameKey key = new UserNameKey();
    SystemUser systemUser = SystemUserFactory.newInstance();

    key.userName = systemUser.getUserDetails().userName;
    countDetailsList.detailsList = workspace.listSupervisorAndOrgObjectWorkQueues(
      key);

    SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    SupervisorApplicationPageContextDetails contextDetails = contextDescription.readLoggedInUserName();

    countDetailsList.contextDescription = contextDetails;

    return countDetailsList;
  }

  /**
   * This method allows the supervisor to read the Work Queue workspace
   * details  to manage tasks and cases by work queue.
   *
   * @param key
   * WorkQueueIDAndTaskOptionKey key
   * @return WorkQueueWorkspaceDetails workspace details
   * @throws InformationalException
   * @throws AppException
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorWorkQueues#readWorkQueueWorkspaceDtls(
   * WorkQueueIDAndTaskOptionKey)}.
   * In addition to the current functionality, the new method return struct
   * contains the struct WorkQueueSubscriberOrgObjDetails. Also, the new method
   * return struct has WorkQueueSubscriberUserDtls struct which contains all the
   * fields of WorkQueueSubscriberUserDetails along with fields subscriberType,
   * subscriptionDateTime, pageTitle and unsubscribePageText.
   * See release note : <CR00215999>
   */
  // BEGIN, CR00215999, LP
  @Deprecated
  public curam.supervisor.facade.struct.WorkQueueWorkspaceDetails readWorkQueueWorkspaceDetails(WorkQueueIDAndTaskOptionKey key)
    throws AppException, InformationalException {

    curam.supervisor.facade.struct.WorkQueueWorkspaceDetails workspaceDetails = new curam.supervisor.facade.struct.WorkQueueWorkspaceDetails();

    WorkQueueWorkspaceDtls wqWorkSpaceDtls = readWorkQueueWorkspaceDtls(key);

    workspaceDetails.taskOption = wqWorkSpaceDtls.taskOption;
    workspaceDetails.contextDescription = wqWorkSpaceDtls.contextDescription;

    curam.supervisor.sl.struct.WorkQueueWorkspaceDetails wsDetails = new curam.supervisor.sl.struct.WorkQueueWorkspaceDetails();

    curam.supervisor.sl.struct.WorkQueueWorkspaceDtls wqWSpaceDtls = wqWorkSpaceDtls.details;

    curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList subscriptionDetailsList = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList();

    curam.supervisor.sl.struct.WorkQueueSubscriberUserDtlsList subscripDetailsList = wqWSpaceDtls.subscriptionDetailsList;

    Iterator<curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls> itr = subscripDetailsList.dtlsList.iterator();

    while (itr.hasNext()) {
      curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls wqUserDtls = itr.next();

      curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails wqUserDetails = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails();

      wqUserDetails.userFullName = wqUserDtls.userFullName;
      wqUserDetails.userEmailID = wqUserDtls.userEmailID;
      wqUserDetails.userEmailLink = wqUserDtls.userEmailLink;
      wqUserDetails.userPhoneNumber = wqUserDtls.userPhoneNumber;
      wqUserDetails.userName = wqUserDtls.userName;
      subscriptionDetailsList.dtlsList.add(wqUserDetails);
    }
    wsDetails.subscriptionDetailsList = subscriptionDetailsList;

    wsDetails.barChartXML = wqWSpaceDtls.barChartXML;
    wsDetails.workQueueDetails = wqWSpaceDtls.workQueueDetails;
    workspaceDetails.details = wsDetails;

    return workspaceDetails;
  }

  // END, CR00215999

  /**
   * This method allows the supervisor to fetch the page name based on
   * selected task option.
   *
   * @param key
   * ResolveWorkQueueTaskOptionPageKey
   * @return ResolveWorkQueuePageDetails
   * @throws InformationalException
   * @throws AppException,
   * InformationalException
   */

  public ResolveWorkQueuePageDetails resolveWorkQueueWorkspacePage(
    ResolveWorkQueueTaskOptionPageKey key) throws AppException,
      InformationalException {

    ResolveWorkQueuePageDetails resolveWorkQueuePageDetails = new ResolveWorkQueuePageDetails();
    String taskOptionCode = key.taskOptionCode;
    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(WORKQUEUETASKOPTIONPAGE.TABLENAME,
      WORKQUEUETASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTMONTH)) {
      if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.RESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.DUEBYWEEK_RESERVED,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.UNRESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.DUEBYWEEK_ASSIGNED,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.ALL)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.DUEBYWEEK_ALL,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    } else if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTWEEK)) {
      if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.RESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.DUEONDATE_RESERVED,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.UNRESERVED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.DUEONDATE_ASSIGNED,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKRESERVEDSEARCHSTATUS.ALL)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.DUEONDATE_ALL,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKSTATUS.NOTSTARTED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.WORKQUEUERESERVEDTASK_OPEN,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKSTATUS.DEFERRED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.WORKQUEUERESERVEDTASK_DEFERRED,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    }
    resolveWorkQueuePageDetails.pageName = pageName;

    return resolveWorkQueuePageDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the tasks assigned to work
   * queues, which have not yet been reserved.
   *
   * @param key -
   * WorkQueueKey
   * @return WorkQueueAssignedTasksSummaryDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  public WorkQueueAssignedTasksSummaryDetailsList listWorkQueueAssignedTasks(
    curam.supervisor.facade.struct.WorkQueueKey key) throws
      AppException, InformationalException {

    // Create OrgUnitAssignedTasksDetailsList object
    WorkQueueAssignedTasksSummaryDetailsList workQueueAssignedTasksSummaryDetailsList = new WorkQueueAssignedTasksSummaryDetailsList();

    // Create curam.supervisor.sl.intf.MaintainSupervisorWorkQueues object
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();

    // Create OrgUnitTasksDetailsList to populate the details list
    curam.supervisor.sl.struct.WorkQueueAssignedTasksSummaryDetailsList workQueueAssignedTasksDetailsList = new curam.supervisor.sl.struct.WorkQueueAssignedTasksSummaryDetailsList();

    WorkQueueKey workQueueKey = new WorkQueueKey();

    SupervisorApplicationPageContextDetails pageContextDetails = new SupervisorApplicationPageContextDetails();

    curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // Assign key values
    workQueueKey.assign(key.key);

    workQueueAssignedTasksDetailsList = maintainSupervisorWorkQueues.listWorkQueueAssignedTasks(
      workQueueKey);
    workQueueAssignedTasksSummaryDetailsList.assignedTaskDetails = workQueueAssignedTasksDetailsList;

    pageContextDetails.description = pageContextDescription.readWorkQueuePageContextDescription(workQueueKey).description;

    workQueueAssignedTasksSummaryDetailsList.pageContext = pageContextDetails;

    return workQueueAssignedTasksSummaryDetailsList;
  }

  /**
   * This method allows the supervisor to view the list of work queue tasks
   * due during a specified week.
   *
   * @param key
   * WorkQueueTasksDueOnDateKey
   * @return ListWorkQueueTasksDueByWeekDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ListWorkQueueTasksDueByWeekDetails listWorkQueueTasksByWeek(
    WorkQueueTasksDueOnDateKey key) throws AppException,
      InformationalException {
    // Create ListWorkQueueTasksDueByWeekDetails object
    ListWorkQueueTasksDueByWeekDetails listWorkQueueTasksDueByWeekDetails = new ListWorkQueueTasksDueByWeekDetails();

    // Create MaintainSupervisorWorkQueues object to get tasks due by date
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();

    listWorkQueueTasksDueByWeekDetails.details = maintainSupervisorWorkQueues.listWorkQueueTasksByWeek(
      key.dueDateKey);

    return listWorkQueueTasksDueByWeekDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the work queue task records due
   * on the specified date.
   *
   * @param key -
   * WorkQueueTasksDueOnDateKey
   * @return ListWorkQueueTasksDueOnDateDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ListWorkQueueTasksDueOnDateDetails listWorkQueueTasksDueOnDate(
    WorkQueueTasksDueOnDateKey key) throws AppException,
      InformationalException {
    // Create ListWorkQueueTasksDueOnDateDetails object
    ListWorkQueueTasksDueOnDateDetails listWorkQueueTasksDueOnDateDetails = new ListWorkQueueTasksDueOnDateDetails();

    // Create MaintainSupervisorWorkQueues object to get tasks due by date
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();

    listWorkQueueTasksDueOnDateDetails.details = maintainSupervisorWorkQueues.listWorkQueueTasksDueOnDate(
      key.dueDateKey);

    return listWorkQueueTasksDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch list of the tasks reserved to
   * the work queue.
   *
   * @param key -
   * WorkQueueKey
   * @return WorkQueueReservedTasksDetails
   * @throws InformationalException
   * @throws AppException
   */
  public WorkQueueReservedTasksDetails readWorkQueueReservedTasksDetails(
    curam.supervisor.facade.struct.WorkQueueKey key) throws
      AppException, InformationalException {
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();
    WorkQueueReservedTasksDetails workQueueReservedTasksDetails = new WorkQueueReservedTasksDetails();

    workQueueReservedTasksDetails.reservedTaskDetails = maintainSupervisorWorkQueues.readWorkQueueReservedTasksDetails(
      key.key);
    WorkQueue workQueue = WorkQueueFactory.newInstance();
    WorkQueueDtls workQueueDtls = workQueue.read(key.key);

    workQueueReservedTasksDetails.pageContext.description = workQueueDtls.name;
    return workQueueReservedTasksDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to reserve work queue tasks to the
   * selected user.
   *
   * @param key -
   * ReserveOrgUnitTasksToUserKey
   * @throws InformationalException
   * @throws AppException
   */
  public void reserveWorkQueueTasksToUser(ReserveWorkQueueTasksToUserKey key)
    throws AppException, InformationalException {

    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueue = MaintainSupervisorWorkQueuesFactory.newInstance();

    maintainSupervisorWorkQueue.reserveWorkQueueTasksToUser(key.reserveTask);

  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to fetch page for Open and Deferred
   * pages  from work queue Reserved tasks.
   *
   * @param key -
   * ResolveWorkQueueReservedTaskPageKey - Task Status
   * @return ResolveWorkQueuePageDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ResolveWorkQueuePageDetails resolveWorkQueueReservedTasksPage(
    ResolveWorkQueueReservedTaskPageKey key) throws AppException,
      InformationalException {

    ResolveWorkQueuePageDetails resolveWorkQueuePages = new ResolveWorkQueuePageDetails();

    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(WORKQUEUETASKOPTIONPAGE.TABLENAME,
      WORKQUEUETASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    // Task Status should be Open
    if (key.taskType.equals(TASKSTATUS.NOTSTARTED)) {

      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(WORKQUEUETASKOPTIONPAGE.TABLENAME,
        WORKQUEUETASKOPTIONPAGE.WORKQUEUETASK_OPEN,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    } else if (key.taskType.equals(TASKSTATUS.DEFERRED)) {
      // Tasks Status Should be deferred
      pageName = // BEGIN, CR00163098, JC
        curam.util.type.CodeTable.getOneItem(WORKQUEUETASKOPTIONPAGE.TABLENAME,
        WORKQUEUETASKOPTIONPAGE.WORKQUEUETASK_DEFERRED,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }
    resolveWorkQueuePages.pageName = pageName;

    return resolveWorkQueuePages;

  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the tasks that have been
   * reserved, and then deferred by members of the work queue.
   *
   * @param key -
   * UserNameAndWorkQueueIDKey
   * @return ListDeferredTasksReservedByWorkQueueUserDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ListDeferredTasksReservedByWorkQueueUserDetails listDeferredTasksReservedByWorkQueueUser(
    UserNameAndWorkQueueIDKey key) throws AppException,
      InformationalException {
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();
    ListDeferredTasksReservedByWorkQueueUserDetails details = new ListDeferredTasksReservedByWorkQueueUserDetails();

    details.details = maintainSupervisorWorkQueues.listDeferredTasksReservedByWorkQueueUser(
      key.key);
    return details;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to list the tasks reserved by members
   * of  the work queue, which are open.
   *
   * @param key -
   * UserNameAndWorkQueueIDKey
   * @return ListDeferredTasksReservedByWorkQueueUserDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ListOpenTasksReservedByWorkQueueUserDetails listOpenTasksReservedByWorkQueueUser(
    UserNameAndWorkQueueIDKey key) throws AppException,
      InformationalException {
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();
    ListOpenTasksReservedByWorkQueueUserDetails details = new ListOpenTasksReservedByWorkQueueUserDetails();

    details.details = maintainSupervisorWorkQueues.listOpenTasksReservedByWorkQueueUser(
      key.key);
    return details;
  }

  /**
   * This method allows the supervisor to list the tasks assigned to work
   * queues, which are reserved.
   *
   * @param key -
   * WorkQueueKey
   * @return WorkQueueAssignedTasksSummaryDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  public WorkQueueAssignedTasksSummaryDetailsList listWorkQueueReserveAssignedTasks(
    curam.supervisor.facade.struct.WorkQueueKey key) throws
      AppException, InformationalException {
    // Create OrgUnitAssignedTasksDetailsList object
    WorkQueueAssignedTasksSummaryDetailsList workQueueAssignedTasksSummaryDetailsList = new WorkQueueAssignedTasksSummaryDetailsList();

    // Create curam.supervisor.sl.intf.MaintainSupervisorWorkQueues object
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();

    // Create OrgUnitTasksDetailsList to populate the details list
    curam.supervisor.sl.struct.WorkQueueAssignedTasksSummaryDetailsList workQueueAssignedTasksDetailsList = new curam.supervisor.sl.struct.WorkQueueAssignedTasksSummaryDetailsList();

    WorkQueueKey workQueueKey = new WorkQueueKey();

    SupervisorApplicationPageContextDetails pageContextDetails = new SupervisorApplicationPageContextDetails();

    curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // Assign key values
    workQueueKey.assign(key.key);

    workQueueAssignedTasksDetailsList = maintainSupervisorWorkQueues.listWorkQueueReserveAssignedTasks(
      workQueueKey);
    workQueueAssignedTasksSummaryDetailsList.assignedTaskDetails = workQueueAssignedTasksDetailsList;

    pageContextDetails.description = pageContextDescription.readWorkQueuePageContextDescription(workQueueKey).description;

    workQueueAssignedTasksSummaryDetailsList.pageContext = pageContextDetails;

    return workQueueAssignedTasksSummaryDetailsList;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to read the work queue Schedule Details.
   *
   * @param key -
   * WorkQueueKey
   * @return WorkQueueSubscribersScheduleDetails
   * @throws InformationalException
   * @throws AppException
   */

  public WorkQueueSubscribersScheduleDetails readWorkQueueSubscribersScheduleDetails(
    curam.supervisor.facade.struct.WorkQueueKey key) throws
      AppException, InformationalException {

    // create WorkQueueSubscribersScheduleDetails object
    WorkQueueSubscribersScheduleDetails workQueueSubscribersScheduleDetails = new WorkQueueSubscribersScheduleDetails();

    // create pageContext description object to read the page context
    curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    WorkQueueKey workQueueKey = new WorkQueueKey();

    // assign key values
    workQueueKey.workQueueID = key.key.workQueueID;

    // get Page context
    workQueueSubscribersScheduleDetails.pageContext = pageContextDescription.readWorkQueuePageContextDescription(
      workQueueKey);

    return workQueueSubscribersScheduleDetails;
  }

  // _________________________________________________________________________
  /**
   * This method allows the supervisor to read the work queue subscribed Users
   * and their Activity Schedule Details.
   *
   * @param key -
   * WorkqueueIDAndStartDateKey
   * @return WorkqueueUsersScheduleDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  public WorkqueueUsersScheduleDetailsList readWorkQueueUsersScheduleDetails(
    WorkqueueIDAndStartDateKey key) throws AppException,
      InformationalException {

    WorkqueueUsersScheduleDetailsList workqueueUsersScheduleDetailsList = new WorkqueueUsersScheduleDetailsList();
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();

    // To get the Activity count and subscribers details from service layer
    workqueueUsersScheduleDetailsList.activityCountDetailsList = maintainSupervisorWorkQueues.readWorkQueueUsersScheduleDetails(
      key);

    SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    WorkQueueKey workQueueKey = new WorkQueueKey();

    // To get page context details
    workQueueKey.workQueueID = key.workQueueID;
    workqueueUsersScheduleDetailsList.contextDescription = pageContextDescription.readWorkQueuePageContextDescription(
      workQueueKey);

    return workqueueUsersScheduleDetailsList;
  }

  // _______________________________________________________________________
  /**
   * This method listDeferredWorkQueueReservedTasksDueByWeek lets the
   * supervisor  view the details of the deferred reserved tasks in a
   * work queue for a week.
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @return ListDeferredTasksReservedByWorkQueueUserDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ListDeferredTasksReservedByWorkQueueUserDetails listDeferredWorkQueueReservedTasksDueByWeek(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    // Create Work queue objects
    ListDeferredTasksReservedByWorkQueueUserDetails listDeferredTasksReservedByWorkQueueUserDetails = new ListDeferredTasksReservedByWorkQueueUserDetails();
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();

    // Calling the service layer method
    listDeferredTasksReservedByWorkQueueUserDetails.details = maintainSupervisorWorkQueues.listDeferredWorkQueueReservedTasksDueByWeek(
      key.dueDateKey);
    return listDeferredTasksReservedByWorkQueueUserDetails;
  }

  // _________________________________________________________________________
  /**
   * This method listDeferredWorkQueueReservedTasksDueOnDate gets the list of
   * Deferred Reserved Tasks Due on Date
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @return ListDeferredTasksReservedByWorkQueueUserDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ListDeferredTasksReservedByWorkQueueUserDetails listDeferredWorkQueueReservedTasksDueOnDate(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    // Objects to retrieve the data
    ListDeferredTasksReservedByWorkQueueUserDetails listDeferredTasksReservedByWorkQueueUserDetails = new ListDeferredTasksReservedByWorkQueueUserDetails();
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();

    // Call to SL method
    listDeferredTasksReservedByWorkQueueUserDetails.details = maintainSupervisorWorkQueues.listDeferredWorkQueueReservedTasksDueOnDate(
      key.dueDateKey);

    return listDeferredTasksReservedByWorkQueueUserDetails;
  }

  // __________________________________________________________________________
  /**
   * This method listOpenWorkQueueReservedTasksDueByWeek lets the supervisor
   * view the details of the reserved tasks which are open in a work queue for
   * a week.
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @return ListOpenTasksReservedByWorkQueueUserDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ListOpenTasksReservedByWorkQueueUserDetails listOpenWorkQueueReservedTasksDueByWeek(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    // Create Work queue objects
    ListOpenTasksReservedByWorkQueueUserDetails listOpenTasksReservedByWorkQueueUserDetails = new ListOpenTasksReservedByWorkQueueUserDetails();
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();

    // Calling the service layer method
    listOpenTasksReservedByWorkQueueUserDetails.details = maintainSupervisorWorkQueues.listOpenWorkQueueReservedTasksDueByWeek(
      key.dueDateKey);
    return listOpenTasksReservedByWorkQueueUserDetails;
  }

  // _________________________________________________________________________
  /**
   * This method listOpenWorkQueueReservedTasksDueOnDate gets the list of Open
   * Reserved Tasks Due on Date
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @return ListOpenTasksReservedByWorkQueueUserDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ListOpenTasksReservedByWorkQueueUserDetails listOpenWorkQueueReservedTasksDueOnDate(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    // Objects to retrieve the data
    ListOpenTasksReservedByWorkQueueUserDetails listOpenTasksReservedByWorkQueueUserDetails = new ListOpenTasksReservedByWorkQueueUserDetails();
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();

    // Call to SL method
    listOpenTasksReservedByWorkQueueUserDetails.details = maintainSupervisorWorkQueues.listOpenWorkQueueReservedTasksDueOnDate(
      key.dueDateKey);

    return listOpenTasksReservedByWorkQueueUserDetails;
  }

  // __________________________________________________________________________
  /**
   * This method readWorkqueueReservedTasksByUserDueByWeek lets the supervisor
   * view the open and deferred reserved tasks in a work queue reserved by user
   * in a week in a bar chart representation.
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @return WorkQueueReservedTasksByUserDueByWeekDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  public WorkQueueReservedTasksByUserDueByWeekDetailsList readWorkqueueReservedTasksByUserDueByWeek(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    // Create WorkQueue objects
    WorkQueueReservedTasksByUserDueByWeekDetailsList workQueueReservedTasksByUserDueByWeekDetailsList = new WorkQueueReservedTasksByUserDueByWeekDetailsList();
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();

    // Calling the service layer method
    workQueueReservedTasksByUserDueByWeekDetailsList.detailsList = maintainSupervisorWorkQueues.readWorkqueueReservedTasksByUserDueByWeek(
      key.dueDateKey);

    // To get page context details
    SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.dueDateKey.dueKey.workQueueID;
    workQueueReservedTasksByUserDueByWeekDetailsList.pageContext = pageContextDescription.readWorkQueuePageContextDescription(
      workQueueKey);
    return workQueueReservedTasksByUserDueByWeekDetailsList;
  }

  // _________________________________________________________________________
  /**
   * This method readWorkqueueReservedTasksByUserDueOnDate gets Reserved Tasks
   * Due on Date count for Work queue subscriber's schedule details
   *
   * @param key -
   * WorkqueueIDAndStartDateKey
   * @return WorkqueueUsersScheduleDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  public WorkQueueReservedTasksByUserDueOnDateDetailsList readWorkqueueReservedTasksByUserDueOnDate(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    // Create MaintainSupervisorWorkQueues object to get tasks due by date
    curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueues = MaintainSupervisorWorkQueuesFactory.newInstance();

    WorkQueueReservedTasksByUserDueOnDateDetails workQueueReservedTasksByUserDueOnDateDetails = new WorkQueueReservedTasksByUserDueOnDateDetails();

    WorkQueueReservedTasksByUserDueOnDateDetailsList workQueueReservedTasksByUserDueOnDateDetailsList = new WorkQueueReservedTasksByUserDueOnDateDetailsList();

    // Call to SL method
    workQueueReservedTasksByUserDueOnDateDetails = maintainSupervisorWorkQueues.readWorkqueueReservedTasksByUserDueOnDate(
      key.dueDateKey);

    workQueueReservedTasksByUserDueOnDateDetailsList.detailsList = workQueueReservedTasksByUserDueOnDateDetails;

    // To get page context details
    SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.dueDateKey.dueKey.workQueueID;
    workQueueReservedTasksByUserDueOnDateDetailsList.pageContext = pageContextDescription.readWorkQueuePageContextDescription(
      workQueueKey);

    return workQueueReservedTasksByUserDueOnDateDetailsList;
  }

  // _________________________________________________________________________
  /**
   * This method resolveWorkQueueReserveTaskDueOnDateOption resolves the page
   * name from Reserved Tasks bar chart.
   *
   * @param key -
   * ResolveWorkQueueReservedTaskPageKey
   * @return ResolveWorkQueuePageDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ResolveWorkQueuePageDetails resolveWorkQueueReserveTaskDueOnDateOption(
    ResolveWorkQueueReservedTaskPageKey key) throws AppException,
      InformationalException {
    ResolveWorkQueuePageDetails resolveWorkQueuePageDetails = new ResolveWorkQueuePageDetails();
    String taskOptionCode = key.taskOptionCode;
    String pageName = // BEGIN, CR00163098, JC
      curam.util.type.CodeTable.getOneItem(WORKQUEUETASKOPTIONPAGE.TABLENAME,
      WORKQUEUETASKOPTIONPAGE.DEFAULTCODE, TransactionInfo.getProgramLocale());

    // END, CR00163098, JC

    if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTMONTH)) {
      if (key.taskType.equals(TASKSTATUS.NOTSTARTED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.WORKQUEUERESERVEDTASKWEEK_OPEN,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKSTATUS.DEFERRED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.WORKQUEUERESERVEDTASKWEEK_DEFERRED,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      }
    } else if (taskOptionCode.equals(VIEWTASKSOPTION.NEXTWEEK)) {
      if (key.taskType.equals(TASKSTATUS.NOTSTARTED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.WORKQUEUERESERVEDTASK_OPEN,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } else if (key.taskType.equals(TASKSTATUS.DEFERRED)) {
        pageName = // BEGIN, CR00163098, JC
          curam.util.type.CodeTable.getOneItem(
          WORKQUEUETASKOPTIONPAGE.TABLENAME,
          WORKQUEUETASKOPTIONPAGE.WORKQUEUERESERVEDTASK_DEFERRED,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JCs
      }
    }
    resolveWorkQueuePageDetails.pageName = pageName;

    return resolveWorkQueuePageDetails;
  }

  // BEGIN, CR00215999, LP
  /**
   * This method allows the supervisor to read the Work Queue workspace details
   * to manage tasks and cases by work queue.
   *
   * @param key
   * WorkQueueIDAndTaskOptionKey key
   * @return WorkQueueWorkspaceDetails workspace details
   * @throws InformationalException
   * @throws AppException
   */
  public WorkQueueWorkspaceDtls readWorkQueueWorkspaceDtls(
    final WorkQueueIDAndTaskOptionKey key) throws AppException,
      InformationalException {

    final WorkQueueWorkspaceDtls workspaceDetails = new WorkQueueWorkspaceDtls();

    final curam.supervisor.sl.intf.MaintainSupervisorWorkQueues maintainSupervisorWorkQueue = MaintainSupervisorWorkQueuesFactory.newInstance();

    curam.supervisor.sl.struct.WorkQueueWorkspaceDtls workQueueWorkspaceDetails = new curam.supervisor.sl.struct.WorkQueueWorkspaceDtls();
    final WorkQueueKey workQueueKey = new WorkQueueKey();

    if (key.taskOption.equalsIgnoreCase(VIEWTASKSOPTION.NEXTMONTH)) {
      workQueueKey.workQueueID = key.workQueueID;
      workQueueWorkspaceDetails = maintainSupervisorWorkQueue.readWorkQueueWorkspaceMonthDtls(
        workQueueKey);
    } else {
      workQueueKey.workQueueID = key.workQueueID;
      workQueueWorkspaceDetails = maintainSupervisorWorkQueue.readWorkQueueWorkspaceWeekDtls(
        workQueueKey);
    }

    workspaceDetails.details = workQueueWorkspaceDetails;

    final curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription contextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    workspaceDetails.contextDescription = contextDescription.readWorkQueuePageContextDescription(
      workQueueKey);

    if (key.taskOption.equalsIgnoreCase(CuramConst.gkEmpty)) {

      workspaceDetails.taskOption = VIEWTASKSOPTION.DEFAULTCODE;
    } else {
      workspaceDetails.taskOption = key.taskOption;
    }

    return workspaceDetails;
  }

  // END, CR00215999

  // BEGIN, CR00232351, ZV
  // ___________________________________________________________________________
  /**
   * Reads the Work Queue tab display details for supervisor workspace.
   *
   * @param key Key of work queue to be read
   *
   * @return Work queue tab display details
   *
   * @throws InformationalException
   * @throws AppException
   */
  public WorkQueueTabDetails readWorkQueueTabDetails(final WorkQueueKey key)
    throws AppException, InformationalException {
    return MaintainSupervisorWorkQueuesFactory.newInstance().readWorkQueueTabDetails(
      key);
  }

  // END, CR00232351
  
  // BEGIN, CR00427278, MV  
  /**
   * Retrieves a list of work queues with a given search criteria.
   *
   * @actionIDProperty to find the action is for SEARCH or SAVE
   *
   * @param workQueueSearchCriteria
   * search criteria to search the work queue.
   * @return A list of work queues.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WorkQueueDetailsList listWorkQueuesByWorkQueueName(
    final WorkQueueSearchCriteria workQueueSearchCriteria,
    final ActionIDProperty actionIDProperty) throws AppException,
      InformationalException {
    WorkQueueDetailsList workQueueDetailsList = new WorkQueueDetailsList();

    if (CuramConst.kSearchAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      if (workQueueSearchCriteria.name.equals(CuramConst.gkEmpty)) {
        throw (new AppException(GENERALSEARCH.ERR_FV_SEARCH_CRITERIA_MISSING));

      }
      final WorkQueueSearchKey workQueueSearchKey = new WorkQueueSearchKey();

      workQueueSearchKey.name = workQueueSearchCriteria.name;
      workQueueSearchKey.upperAdministratorUserName = workQueueSearchCriteria.userName;
      workQueueDetailsList = MaintainSupervisorWorkQueuesFactory.newInstance().listWorkQueuesByWorkQueueName(
        workQueueSearchKey);
      if (0 == workQueueDetailsList.dtls.size()) {
        throw (new AppException(BPOWORKQUEUE.INF_WORK_QUEUE_NO_MATCH_FOUND));
      }
    }
    
    if (CuramConst.kSaveAction.equalsIgnoreCase(
      actionIDProperty.actionIDProperty)) {
      final String[] workQueueIDs = workQueueSearchCriteria.selectedQueueIDs.split(
        CuramConst.gkTabDelimiter);
      final UserWorkspace userWorkspaceObj = UserWorkspaceFactory.newInstance();
      UserSubscriptionToWorkQueueDetails userSubscriptionToWorkQueueDetails = null;
      WorkQueueKey workQueueKeyObj = null;
      SubscribeUserWorkQueueKey subscribeUserWorkQueueKey = null;
      WorkQueue workQueueObj = WorkQueueFactory.newInstance();

      userSubscriptionToWorkQueueDetails = new UserSubscriptionToWorkQueueDetails();
      workQueueKeyObj = new WorkQueueKey();
      
      for (int i = 0; i < workQueueIDs.length; i++) {
        
        userSubscriptionToWorkQueueDetails.userName = workQueueSearchCriteria.userName;
        userSubscriptionToWorkQueueDetails.workQueueID = new Long(
          workQueueIDs[i]);
        workQueueKeyObj.workQueueID = userSubscriptionToWorkQueueDetails.workQueueID;
        userSubscriptionToWorkQueueDetails.workQueueName = workQueueObj.read(workQueueKeyObj).name;
        
        subscribeUserWorkQueueKey = new SubscribeUserWorkQueueKey();
        subscribeUserWorkQueueKey.userName = workQueueSearchCriteria.userName;
        subscribeUserWorkQueueKey.workQueueID = workQueueKeyObj.workQueueID;
        subscribeUserWorkQueueKey.workQueueName = userSubscriptionToWorkQueueDetails.workQueueName;
        
        validateSubscribe(subscribeUserWorkQueueKey);
        
        userWorkspaceObj.subscribeUserToWorkQueue(
          userSubscriptionToWorkQueueDetails);
      }
    }
    return workQueueDetailsList;
  }

  // END, CR00427278
  
  // BEGIN, CR00427278, MV
  /**
   * Validates the work queue while subscribing to the users.
   *
   * @param key
   * SubscribeUserWorkQueueKey Work queue un-subscription details
   * @throws InformationalException
   * @throws AppException
   */
  public void validateSubscribe(final SubscribeUserWorkQueueKey key)
    throws AppException, InformationalException {

    // Work Queue manipulation variables
    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
    final WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.workQueueID;

    final UsersKey userKey = new UsersKey();

    userKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    final SensitivityCode userSensitivityCode = UserAccessFactory.newInstance().readSensitivityCodeForUser(
      userKey);

    int userSensitivity = Integer.parseInt(userSensitivityCode.sensitivity);

    // Retrieve the sensitivity level for the specified work queue.
    WorkQueueSensitivityAndAllowUserSubscriptionDetails details = new WorkQueueSensitivityAndAllowUserSubscriptionDetails();

    details = workQueueObj.readSensitivityLevelAndAllowUserSubscriptionByWorkQueueID(
      workQueueKey);
    int workQueueSensitivity = Integer.parseInt(details.sensitivity);

    // Check with WorkQueue sensitivity level and supervisor sensitivity level
    if (workQueueSensitivity > userSensitivity) {

      ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_SUBSCRIBE_SUPERVISOR_SENSITIVITY_CHECK),
          ValidationManagerConst.kSetOne,
          0);
    }
  }
  // END, CR00427278
}
