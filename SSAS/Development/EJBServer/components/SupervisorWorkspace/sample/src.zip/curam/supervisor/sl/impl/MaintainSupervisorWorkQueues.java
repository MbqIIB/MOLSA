/*
 * Licensed Materials - Property of IBM
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * Copyright (c) 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.supervisor.sl.impl;


import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Locale;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import curam.codetable.RECORDSTATUS;
import curam.codetable.TASKSTATUS;
import curam.codetable.VIEWTASKSOPTION;
import curam.codetable.WQSUBSORGOBJECTTYPE;
import curam.core.fact.EmailAddressFactory;
import curam.core.fact.PhoneNumberFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.EmailAddress;
import curam.core.intf.PhoneNumber;
import curam.core.intf.SystemUser;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.OrgUnitParentLinkFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.OrgUnitAndStatusKey;
import curam.core.sl.entity.struct.OrganisationStructureIDDtls;
import curam.core.sl.entity.struct.OrganisationUnitIDDtls;
import curam.core.sl.entity.struct.ReadWorkQueueDetails;
import curam.core.sl.entity.struct.SearchSubscriptionsByWorkQueueIDKey;
import curam.core.sl.entity.struct.WorkQueueDetailsList;
import curam.core.sl.entity.struct.WorkQueueDtls;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.entity.struct.WorkQueueNameDetails;
import curam.core.sl.entity.struct.WorkQueueNameStruct;
import curam.core.sl.entity.struct.WorkQueueSubscriptionFullDetailsList;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.fact.WorkQueueSubscriptionFactory;
import curam.core.sl.infrastructure.impl.BarChartConst;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.WorkQueueSearchKey;
import curam.core.sl.supervisor.fact.TaskManagementFactory;
import curam.core.sl.supervisor.fact.WorkQueueWorkspaceFactory;
import curam.core.sl.supervisor.intf.TaskManagement;
import curam.core.sl.supervisor.intf.WorkQueueWorkspace;
import curam.core.sl.supervisor.struct.ReserveTaskDetailsForUser;
import curam.core.sl.supervisor.struct.WorkQueueCountReservedTasksByUserDetails;
import curam.core.sl.supervisor.struct.WorkQueueCountReservedTasksByUserDetailsList;
import curam.core.sl.supervisor.struct.WorkQueueReservedTasksDueOnDateKey;
import curam.core.sl.supervisor.struct.WorkQueueReservedTasksForUserKey;
import curam.core.sl.supervisor.struct.WorkQueueTasksDueInTheNextMonthKey;
import curam.core.sl.supervisor.struct.WorkQueueTasksDueInTheNextTimePeriodDetails;
import curam.core.sl.supervisor.struct.WorkQueueTasksDueInTheNextTimePeriodDetailsList;
import curam.core.sl.supervisor.struct.WorkQueueTasksDueInTheNextWeekKey;
import curam.core.struct.EmailAddressDtls;
import curam.core.struct.EmailAddressKey;
import curam.core.struct.PhoneNumberDtls;
import curam.core.struct.PhoneNumberKey;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.core.struct.WorkqueueIDDateTimeAndStatusKey;
import curam.message.BPOSUPERVISORWORKQUEUE;
import curam.message.BPOWORKQUEUESUBSCRIPTION;
import curam.message.SUPERVISORCONST;
import curam.supervisor.sl.struct.ListDeferredTasksReservedByWorkQueueUserDetails;
import curam.supervisor.sl.struct.ListOpenTasksReservedByWorkQueueUserDetails;
import curam.supervisor.sl.struct.ListWorkQueueTasksDueByWeekDetails;
import curam.supervisor.sl.struct.ListWorkQueueTasksDueOnDateDetails;
import curam.supervisor.sl.struct.ReserveWorkQueueTasksToUserKey;
import curam.supervisor.sl.struct.UserNameAndWorkQueueIDKey;
import curam.supervisor.sl.struct.WorkQueueAssignedTasksSummaryDetailsList;
import curam.supervisor.sl.struct.WorkQueueDetails;
import curam.supervisor.sl.struct.WorkQueueReservedTasksByUserDueByWeekDetails;
import curam.supervisor.sl.struct.WorkQueueReservedTasksByUserDueOnDateDetails;
import curam.supervisor.sl.struct.WorkQueueReservedTasksByUserKey;
import curam.supervisor.sl.struct.WorkQueueReservedTasksDetails;
import curam.supervisor.sl.struct.WorkQueueSubscriberOrgObjDetails;
import curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls;
import curam.supervisor.sl.struct.WorkQueueSubscriberUserDtlsList;
import curam.supervisor.sl.struct.WorkQueueTabDetails;
import curam.supervisor.sl.struct.WorkQueueTasksDueOnDateKey;
import curam.supervisor.sl.struct.WorkQueueWorkspaceDtls;
import curam.supervisor.sl.struct.WorkqueueIDAndStartDateKey;
import curam.supervisor.sl.struct.WorkqueueUsersScheduleDetails;
import curam.util.codetable.TASKRESERVEDSEARCHSTATUS;
import curam.util.dataaccess.CuramValueList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.message.CatEntry;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.StringList;
import curam.util.workflow.fact.TaskAdminFactory;
import curam.util.workflow.intf.TaskAdmin;
import curam.util.workflow.struct.TaskDetailsWithoutSnapshot;
import curam.util.workflow.struct.TaskKey;


/**
 * Service layer Class for Supervisor Work queues.
 */
public abstract class MaintainSupervisorWorkQueues extends curam.supervisor.sl.base.MaintainSupervisorWorkQueues {

  /**
   * Identifier for holding the Organization Unit ID for Bar chart
   */
  protected static final String kID = SupervisorConst.kID;

  /**
   * Identifier for holding the User Name for Bar chart
   */
  protected static final String kUserName = SupervisorConst.kUserName;

  /**
   * Identifier for holding the Full Name for Bar chart creation
   */
  protected static final String kFullName = SupervisorConst.kFullName;

  /**
   * Identifier for holding the type of chart
   */
  protected static final String kBarChart = BarChartConst.kBarChart;

  /**
   * Identifier for holding the element type
   */
  protected static final String kUnit = BarChartConst.kUnit;

  /**
   * Identifier for holding the element caption
   */
  protected static final String kCaption = BarChartConst.kCaption;

  /**
   * Identifier for holding the element caption text
   */
  protected static final String kText = BarChartConst.kText;

  /**
   * Identifier for holding the element block
   */
  protected static final String kBlock = BarChartConst.kBlock;

  /**
   * Identifier for holding the navigation option
   */
  protected static final String kType = BarChartConst.kType;

  /**
   * Identifier for holding the due date
   */
  protected static final String kDueDate = BarChartConst.kDueDate;

  /**
   * Identifier for holding the start date
   */
  protected static final String kStartDate = SupervisorConst.kStartDate;

  /**
   * Identifier for holding the task option code
   */
  protected static final String kTaskOptionCode = SupervisorConst.kTaskOptionCode;

  /**
   * Identifier for holding the bar graph length
   */
  protected static final String kLength = BarChartConst.kLength;

  /**
   * Identifier for holding the Number of weeks for task due
   */
  protected static final int kNumberOfWeeks = SupervisorConst.kNumberOfWeeks;

  /**
   * Identifier for holding the hyperlink on email id
   */
  protected static final String kMailLink = SupervisorConst.kMailLink;

  /**
   * Identifier for holding the work queue Name
   */
  protected static final String kWorkQueueName = SupervisorConst.kWorkQueueName;

  // BEGIN, CR00190772, CL
  /**
   * Used as the separator in a date format
   *
   * @deprecated -since 5.2 SP3, This constant is replaced by
   * curam.util.exception.LocalisableString(
   * curam.message.SUPERVISORCONST.INF_SUPERVISORCONST_KCODE_DATE_SEPARATOR)
   * .getMessage(TransactionInfo(getProgramLocale()).
   * This constant is deprecated because it did not facilitate localization.
   * See release note CR00183504.
   *
   * @deprecated
   */
  @Deprecated
  public static final String kSlash = SupervisorConst.kSlash;
  // END, CR00190772

  /**
   * Identifier for holding the value of Date Format to be displayed as the
   * Caption in the bar chart.
   */
  // BEGIN, CR00085608 SK
  protected static final String kDateFormat = SupervisorConst.kDateFormat;
  // END, CR00085608 SK

  // BEGIN, CR00124642, GSP
  protected static final String kGanttDateFormat = curam.util.resources.Locale.Date_ymd_ext;
  // END, CR00124642

  // BEGIN, CR00161962, BK
  // Localisable Page Title
  LocalisableString userPageTitle = new LocalisableString(
    BPOWORKQUEUESUBSCRIPTION.MSG_UNSUBSCRIBE_WORK_QUEUE_USER_PAGE_TITLE);
  LocalisableString orgUnitPageTitle = new LocalisableString(
    BPOWORKQUEUESUBSCRIPTION.MSG_UNSUBSCRIBE_WORK_QUEUE_ORG_UNIT_PAGE_TITLE);
  LocalisableString positionPageTitle = new LocalisableString(
    BPOWORKQUEUESUBSCRIPTION.MSG_UNSUBSCRIBE_WORK_QUEUE_POSITION_PAGE_TITLE);
  LocalisableString jobPageTitle = new LocalisableString(
    BPOWORKQUEUESUBSCRIPTION.MSG_UNSUBSCRIBE_WORK_QUEUE_JOB_PAGE_TITLE);

  // Localisable Unsubscribe Page Text
  LocalisableString userPageText = new LocalisableString(
    BPOWORKQUEUESUBSCRIPTION.MSG_UNSUBSCRIBE_WORK_QUEUE_USER_PAGE_TEXT_SUP);
  LocalisableString orgUnitPageText = new LocalisableString(
    BPOWORKQUEUESUBSCRIPTION.MSG_UNSUBSCRIBE_WORK_QUEUE_ORG_UNIT_PAGE_TEXT_SUP);
  LocalisableString positionPageText = new LocalisableString(
    BPOWORKQUEUESUBSCRIPTION.MSG_UNSUBSCRIBE_WORK_QUEUE_POSITION_PAGE_TEXT_SUP);
  LocalisableString jobPageText = new LocalisableString(
    BPOWORKQUEUESUBSCRIPTION.MSG_UNSUBSCRIBE_WORK_QUEUE_JOB_PAGE_TEXT_SUP);
  // END, CR00161962

  // ___________________________________________________________________________
  /**
   * Read work queue workspace details on week basis
   * @param key
   * WorkQueueKey
   * @return WorkQueueWorkspaceDetails workQueueWorkspaceDetails
   * @throws AppException
   * @throws InformationalException
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorWorkQueues#readWorkQueueWorkspaceWeekDtls(
   * WorkQueueKey)}.
   * In addition to the current functionality, the new method return struct
   * contains the struct WorkQueueSubscriberOrgObjDetails. Also, the new method
   * return struct has WorkQueueSubscriberUserDtls struct which contains all
   * the fields of WorkQueueSubscriberUserDetails along with fields
   * subscriberType, subscriptionDateTime, pageTitle and unsubscribePageText.
   * See release note : <CR00215999>
   */
  // BEGIN, CR00215999, LP
  @Deprecated
  public curam.supervisor.sl.struct.WorkQueueWorkspaceDetails readWorkQueueWorkspaceWeekDetails(WorkQueueKey key)
    throws AppException, InformationalException {

    curam.supervisor.sl.struct.WorkQueueWorkspaceDetails workspaceDetails = new curam.supervisor.sl.struct.WorkQueueWorkspaceDetails();

    WorkQueueWorkspaceDtls wqWorkSpaceDtls = readWorkQueueWorkspaceWeekDtls(key);

    workspaceDetails.barChartXML = wqWorkSpaceDtls.barChartXML;
    workspaceDetails.workQueueDetails = wqWorkSpaceDtls.workQueueDetails;

    curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList subscriptionDetailsList = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList();

    WorkQueueSubscriberUserDtlsList subscripDetailsList = wqWorkSpaceDtls.subscriptionDetailsList;

    Iterator itr = subscripDetailsList.dtlsList.iterator();

    while (itr.hasNext()) {
      curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls wqUserDtls = (curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls) itr.next();

      curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails wqUserDetails = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails();

      wqUserDetails.userFullName = wqUserDtls.userFullName;
      wqUserDetails.userEmailID = wqUserDtls.userEmailID;
      wqUserDetails.userEmailLink = wqUserDtls.userEmailLink;
      wqUserDetails.userPhoneNumber = wqUserDtls.userPhoneNumber;
      wqUserDetails.userName = wqUserDtls.userName;
      subscriptionDetailsList.dtlsList.add(wqUserDetails);
    }
    workspaceDetails.subscriptionDetailsList = subscriptionDetailsList;
    return workspaceDetails;
  }

  // END, CR00215999

  // BEGIN, CR00161962, BK
  /**
   * Get the list of subscribed users and organization objects (like
   * organization unit, position , job) for WorkQueue
   *
   * @param WorkQueueKey
   * Work Queue ID
   * @return WorkQueueSubscriberUserDetailsList
   * List of Work Queue subscribers for a Work Queue.
   * @deprecated Since Curam 6.0, replaced with
   * {@link MaintainSupervisorWorkQueues#getSubscriptionDtlsList(WorkQueueKey)}.
   * In addition to the current functionality, the new method return struct
   * contains the struct WorkQueueSubscriberOrgObjDetails. Also, the new method
   * return struct has WorkQueueSubscriberUserDtls struct which contains all the
   * fields of WorkQueueSubscriberUserDetails along with fields subscriberType,
   * subscriptionDateTime, pageTitle and unsubscribePageText.
   * See release note : <CR00215999>
   */
  // BEGIN, CR00215999, LP
  @Deprecated
  // BEGIN, CR00198672, VK
  protected curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList getSubscriptionDetailsList(WorkQueueKey key)
    throws AppException, InformationalException {
    // END, CR00198672
    curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList detailsList = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList();

    // users list
    detailsList.dtlsList.addAll(getSubscribedUserList(key).dtlsList);

    WorkQueueSubscriberUserDtlsList wqSubsUserDtlsList = getSubscriptionDtlsList(
      key);

    Iterator<curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls> itr = wqSubsUserDtlsList.dtlsList.iterator();

    while (itr.hasNext()) {
      curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls wqUserDtls = itr.next();

      curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails wqUserDetails = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails();

      wqUserDetails.userFullName = wqUserDtls.userFullName;
      wqUserDetails.userEmailID = wqUserDtls.userEmailID;
      wqUserDetails.userEmailLink = wqUserDtls.userEmailLink;
      wqUserDetails.userPhoneNumber = wqUserDtls.userPhoneNumber;
      wqUserDetails.userName = wqUserDtls.userName;
      detailsList.dtlsList.add(wqUserDetails);
    }
    return detailsList;
  }

  // END, CR00161962
  // END, CR00215999

  /**
   * Get Subscribed User list
   *
   * @param WorkQueueKey
   * Work Queue ID.
   * @return WorkQueueSubscriberUserDetailsList
   * List of Work Queue user subscribers for a Work Queue.
   * @throws AppException
   * @throws InformationalException
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorWorkQueues#getSubscribedUserDtlsList(WorkQueueKey
   * key)}.
   * In addition to the current functionality, the new method return struct
   * contains the struct WorkQueueSubscriberOrgObjDetails. Also, the new method
   * return struct has WorkQueueSubscriberUserDtls struct which contains all the
   * fields of WorkQueueSubscriberUserDetails along with fields subscriberType,
   * subscriptionDateTime, pageTitle and unsubscribePageText.
   * See release note : <CR00215999>
   */
  // BEGIN, CR00215999, LP
  @Deprecated
  // BEGIN, CR00198672, VK
  protected curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList getSubscribedUserList(WorkQueueKey key)
    throws AppException, InformationalException {
    // END, CR00198672

    curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList detailsList = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList();

    WorkQueueSubscriberUserDtlsList wqSubsUserDtlsList = getSubscribedUserDtlsList(
      key);

    Iterator<curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls> itr = wqSubsUserDtlsList.dtlsList.iterator();

    while (itr.hasNext()) {
      curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls wqUserDtls = itr.next();

      curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails wqUserDetails = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails();

      wqUserDetails.userFullName = wqUserDtls.userFullName;
      wqUserDetails.userEmailID = wqUserDtls.userEmailID;
      wqUserDetails.userEmailLink = wqUserDtls.userEmailLink;
      wqUserDetails.userPhoneNumber = wqUserDtls.userPhoneNumber;
      wqUserDetails.userName = wqUserDtls.userName;
      detailsList.dtlsList.add(wqUserDetails);
    }

    return detailsList;
  }

  // END, CR00215999

  // BEGIN, CR00161962, BK
  /**
   * Gets Organization Object list of subscribers for a Work Queue.
   * The List will contain the details of the Org objects that are subscribed
   * to the Work Queue.The Organization Objects include org unit, position, job.
   *
   * @param WorkQueueKey
   * Work Queue ID.
   * @return WorkQueueSubscriberUserDetailsList
   * List of Work Queue Org Object subscribers for a Work Queue.
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorWorkQueues#getSubscribedOrgObjectDtlsList(
   * WorkQueueKey key)}.
   * In addition to the current functionality, the new method return struct
   * contains the struct WorkQueueSubscriberOrgObjDetails. Also, the new method
   * return struct has WorkQueueSubscriberUserDtls struct which contains all the
   * fields of WorkQueueSubscriberUserDetails along with fields subscriberType,
   * subscriptionDateTime, pageTitle and unsubscribePageText.
   * See release note : <CR00215999>
   */
  // BEGIN, CR00215999, LP
  @Deprecated
  // BEGIN, CR00198672, VK
  protected curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList getSubscribedOrgObjectList(WorkQueueKey key)
    throws AppException, InformationalException {
    // END, CR00198672

    curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList detailsList = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList();

    WorkQueueSubscriberUserDtlsList wqSubsUserDtlsList = getSubscribedOrgObjectDtlsList(
      key);

    Iterator<curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls> itr = wqSubsUserDtlsList.dtlsList.iterator();

    while (itr.hasNext()) {
      curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls wqUserDtls = itr.next();

      curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails wqUserDetails = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails();

      wqUserDetails.userFullName = wqUserDtls.userFullName;
      wqUserDetails.userEmailID = wqUserDtls.userEmailID;
      wqUserDetails.userEmailLink = wqUserDtls.userEmailLink;
      wqUserDetails.userPhoneNumber = wqUserDtls.userPhoneNumber;
      wqUserDetails.userName = wqUserDtls.userName;
      detailsList.dtlsList.add(wqUserDetails);
    }

    return detailsList;
  }

  // END, CR00215999

  /**
   * Populate dynamic page title & confirmation text fields for unsubscribe page
   *
   * @param WorkQueueSubscriberOrgObjDetails
   * Contains the subscriber details.
   */
  // BEGIN, CR00198672, VK
  protected void populatePageTitleAndTexts(WorkQueueSubscriberOrgObjDetails details)
    throws AppException, InformationalException {
    // END, CR00198672
    // For Org unit
    if (details.subscriberType.equals(WQSUBSORGOBJECTTYPE.ORGUNIT)) {
      details.pageTitle = orgUnitPageTitle.getMessage();
      details.unsubscribePageText = orgUnitPageText.getMessage();
    } // For Position
    else if (details.subscriberType.equals(WQSUBSORGOBJECTTYPE.POSITION)) {

      details.pageTitle = positionPageTitle.getMessage();
      details.unsubscribePageText = positionPageText.getMessage();
    } // For Job
    else if (details.subscriberType.equals(WQSUBSORGOBJECTTYPE.JOB)) {

      details.pageTitle = jobPageTitle.getMessage();
      details.unsubscribePageText = jobPageText.getMessage();
    }
  }

  /**
   * Resolves the Org object homepage URL based on the organization object.
   * The home page is created based on the subscriber type.
   *
   * @param WorkQueueSubscriberOrgObjDetails
   * Contains the subscriber details.
   */
  // BEGIN, CR00198672, VK
  protected void populateOrgObjectHomePage(WorkQueueSubscriberOrgObjDetails details)
    throws AppException, InformationalException {
    // END, CR00198672

    if (details.subscriberType.equals(WQSUBSORGOBJECTTYPE.ORGUNIT)) {

      // Initializing the object to retrieve "organization Structure ID"
      curam.core.sl.entity.intf.OrgUnitParentLink OrgUnitParentLinkobj = OrgUnitParentLinkFactory.newInstance();

      // Input key to read Organization Structure
      OrgUnitAndStatusKey orgUnitAndStatusKey = new OrgUnitAndStatusKey();

      curam.core.sl.entity.struct.OrganisationUnitIDDtls organisationUnitIDDtls = new OrganisationUnitIDDtls();

      organisationUnitIDDtls.organisationUnitID = details.subscriberID;

      orgUnitAndStatusKey.organisationUnitID = organisationUnitIDDtls.organisationUnitID;

      OrganisationStructureIDDtls organisationStructureIDDtls = new OrganisationStructureIDDtls();

      orgUnitAndStatusKey.organisationUnitID = details.subscriberID;
      orgUnitAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

      organisationStructureIDDtls = OrgUnitParentLinkobj.readOrgStructureID(
        orgUnitAndStatusKey);

      details.organisationStructureID = organisationStructureIDDtls.organisationStructureID;
      details.organisationUnitID = organisationUnitIDDtls.organisationUnitID;
      details.objectType = CuramConst.kOrganisationUnit;

    } else if (details.subscriberType.equals(WQSUBSORGOBJECTTYPE.POSITION)) {

      // Users manipulation variables
      curam.core.sl.entity.intf.Position positionObj = curam.core.sl.entity.fact.PositionFactory.newInstance();
      curam.core.sl.entity.struct.PositionKey positionKey = new curam.core.sl.entity.struct.PositionKey();

      // Set key for read
      positionKey.positionID = details.subscriberID;

      curam.core.sl.entity.struct.OrganisationUnitIDDtls organisationUnitIDDtls = new OrganisationUnitIDDtls();

      organisationUnitIDDtls.assign(
        positionObj.readOrganisationUnitID(positionKey));

      // Initializing the object to retrieve "organization Structure ID"
      curam.core.sl.entity.intf.OrgUnitParentLink OrgUnitParentLinkobj = OrgUnitParentLinkFactory.newInstance();

      // Input key to read Organization Structure
      OrgUnitAndStatusKey orgUnitAndStatusKey = new OrgUnitAndStatusKey();

      // initializing the key with org unit ID
      orgUnitAndStatusKey.organisationUnitID = organisationUnitIDDtls.organisationUnitID;

      orgUnitAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

      OrganisationStructureIDDtls organisationStructureIDDtls = new OrganisationStructureIDDtls();

      organisationStructureIDDtls = OrgUnitParentLinkobj.readOrgStructureID(
        orgUnitAndStatusKey);

      details.organisationStructureID = organisationStructureIDDtls.organisationStructureID;
      details.organisationUnitID = organisationUnitIDDtls.organisationUnitID;
      details.objectType = CuramConst.kPosition;

    } else if (details.subscriberType.equals(WQSUBSORGOBJECTTYPE.JOB)) {

      details.objectType = CuramConst.kJob;
    }
  }

  // END, CR00161962

  /**
   * This method returns the work queue details for the WorkqueueID
   *
   * @param key
   * WorkQueueKey
   * @return ReadWorkQueueDetails
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00198672, VK
  protected ReadWorkQueueDetails getWorkQueueDetails(WorkQueueKey key)
    throws AppException, InformationalException {
    // END, CR00198672
    WorkQueue workQueueObj = WorkQueueFactory.newInstance();

    return workQueueObj.readWorkQueueDetails(key);

  }

  /**
   * This method returns the number of days in the week defined in the
   * property configuration.
   *
   * @return int
   */
  // BEGIN, CR00198672, VK
  protected int getNumberOfDaysInWeek() {
    // END, CR00198672
    String noOfDaysInaWeekString = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_NO_OF_DAYS_IN_A_WEEK);

    int noOfDaysInaWeek = 0;

    if (noOfDaysInaWeekString == null) {
      noOfDaysInaWeek = EnvVars.ENV_SUPERVISOR_NO_OF_DAYS_IN_A_WEEK_DEFAULT;
    } else {
      noOfDaysInaWeek = Integer.parseInt(noOfDaysInaWeekString);
    }
    return noOfDaysInaWeek;
  }

  /**
   * This methods read the work queue workspace details for the next month
   * @param key
   * WorkQueueKey
   * @return WorkQueueWorkspaceDetails
   * @throws AppException
   * @throws InformationalException
   * @deprecated Since Curam 6.0 , replaced with
   * {@link MaintainSupervisorWorkQueues#readWorkQueueWorkspaceMonthDtls(
   * WorkQueueKey key)}.
   * In addition to the current functionality, the new method return struct
   * contains the struct WorkQueueSubscriberOrgObjDetails. Also, the new method
   * return struct has WorkQueueSubscriberUserDtls struct which contains all the
   * fields of WorkQueueSubscriberUserDetails along with fields subscriberType,
   * subscriptionDateTime, pageTitle and unsubscribePageText.
   * See release note : <CR00215999>
   */
  // BEGIN, CR00215999, LP
  @Deprecated
  public curam.supervisor.sl.struct.WorkQueueWorkspaceDetails readWorkQueueWorkspaceMonthDetails(WorkQueueKey key)
    throws AppException, InformationalException {

    curam.supervisor.sl.struct.WorkQueueWorkspaceDetails workspaceDetails = new curam.supervisor.sl.struct.WorkQueueWorkspaceDetails();

    WorkQueueWorkspaceDtls wqWspaceDtls = readWorkQueueWorkspaceMonthDtls(key);

    workspaceDetails.barChartXML = wqWspaceDtls.barChartXML;
    workspaceDetails.workQueueDetails = wqWspaceDtls.workQueueDetails;

    curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList subscriptionDetailsList = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetailsList();

    WorkQueueSubscriberUserDtlsList subscripDetailsList = wqWspaceDtls.subscriptionDetailsList;

    Iterator itr = subscripDetailsList.dtlsList.iterator();

    while (itr.hasNext()) {
      curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls wqUserDtls = (curam.supervisor.sl.struct.WorkQueueSubscriberUserDtls) itr.next();

      curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails wqUserDetails = new curam.supervisor.sl.struct.WorkQueueSubscriberUserDetails();

      wqUserDetails.userFullName = wqUserDtls.userFullName;
      wqUserDetails.userEmailID = wqUserDtls.userEmailID;
      wqUserDetails.userEmailLink = wqUserDtls.userEmailLink;
      wqUserDetails.userPhoneNumber = wqUserDtls.userPhoneNumber;
      wqUserDetails.userName = wqUserDtls.userName;
      subscriptionDetailsList.dtlsList.add(wqUserDetails);
    }
    workspaceDetails.subscriptionDetailsList = subscriptionDetailsList;

    return workspaceDetails;
  }

  // END, CR00215999
  // _________________________________________________________________________
  /**
   * This constructBarChartFromDetailsList is used to construct bar chart from
   * the details list.
   *
   * @param key - workQueueKey
   * @param String - workQueueName
   * @param detailsList -WorkQueueTasksDueInTheNextTimePeriodDetailsList
   * @param taskOptionCode -String
   * @return String - of bar chart xml values
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartFromDetailsList(WorkQueueKey workQueueKey,
    WorkQueueTasksDueInTheNextTimePeriodDetailsList detailsList,
    String taskOptionCode, String workQueueName) {
    // END, CR00198672
    Element barChartElement = new Element(kBarChart);
    XMLOutputter outputter = new XMLOutputter();

    int listSize = detailsList.dtls.size();

    // BEGIN, CR00190772, CL
    // Get the current locale
    String currentLocale = TransactionInfo.getProgramLocale();

    Locale locale;
    SimpleDateFormat simpleDateFormat;

    String localeLanguage = currentLocale.substring(0, 2);
    String localeCountry = new String();

    // Create a Locale object based on the user's locale and format the date
    if (currentLocale.length() > 2) {
      localeCountry = currentLocale.substring(3);
      locale = new Locale(localeLanguage, localeCountry);
      simpleDateFormat = new SimpleDateFormat(kDateFormat, locale);
    } else {
      locale = new Locale(localeLanguage);
      simpleDateFormat = new SimpleDateFormat(kDateFormat, locale);
    }

    // BEGIN, CR00263925, ZV
    // sort work queue task details list by deadline date
    Comparator<WorkQueueTasksDueInTheNextTimePeriodDetails> taskDetailsComparator = new WorkQueueTaskDetailsComparator();

    Collections.sort(detailsList.dtls, taskDetailsComparator);
    // END, CR00263925

    // BEGIN, CR00263925, ZV
    for (int i = 0; i < listSize; i++) {
      // END, CR00263925

      WorkQueueTasksDueInTheNextTimePeriodDetails periodDetails = detailsList.dtls.item(
        i);

      Element unitElement = new Element(kUnit);
      Element captionElement = new Element(kCaption);

      // END, CR00190772

      captionElement.setAttribute(kText,
        simpleDateFormat.format(
        periodDetails.deadlineDate.getCalendar().getTime()));

      // BEGIN, CR00124642, GSP
      captionElement.setAttribute(kStartDate,
        curam.util.resources.Locale.getFormattedDate(periodDetails.deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642

      captionElement.setAttribute(kTaskOptionCode, taskOptionCode);
      captionElement.setAttribute(kID, Long.toString(workQueueKey.workQueueID));

      unitElement.addContent(captionElement);

      Element blockElement = new Element(kBlock);

      blockElement.setAttribute(kID, Long.toString(workQueueKey.workQueueID));
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(periodDetails.deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.RESERVED);
      // blockElement.setAttribute(kText, taskOptionCode);
      blockElement.setAttribute(kWorkQueueName, workQueueName);
      blockElement.setAttribute(kLength,
        periodDetails.tasksReservedCount + CuramConst.gkEmpty);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(periodDetails.deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642

      unitElement.addContent(blockElement);
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);

      blockElement = new Element(kBlock);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(periodDetails.deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642
      blockElement.setAttribute(kID, Long.toString(workQueueKey.workQueueID));
      // BEGIN, CR00331373, ZV
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.UNRESERVED);
      // END, CR00331373
      // blockElement.setAttribute(kText, taskOptionCode);
      blockElement.setAttribute(kWorkQueueName, workQueueName);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(periodDetails.deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642
      blockElement.setAttribute(kLength,
        periodDetails.tasksAssignedCount + CuramConst.gkEmpty);
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);

      unitElement.addContent(blockElement);
      barChartElement.addContent(unitElement);
    }

    if (barChartElement.getChildren().isEmpty()) {

      return CuramConst.gkEmpty;

    } else {
      return outputter.outputString(barChartElement);
    }
  }

  // _______________________________________________________________________
  /**
   * This method allows the supervisor to view and manage the tasks from the
   * work queue that are reserved.
   *
   * @param key -
   * WorkQueueKey
   * @return WorkQueueReservedTasksDetails
   * @throws AppException
   * @throws InformationalException
   */
  public WorkQueueReservedTasksDetails readWorkQueueReservedTasksDetails(
    curam.core.sl.entity.struct.WorkQueueKey key) throws AppException,
      InformationalException {

    // Validate Sensitivity level between Supervisor and Work queue
    validateSensitivity(key, TransactionInfo.getProgramUser(),
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);

    WorkQueueWorkspace workQueueWorkspace = WorkQueueWorkspaceFactory.newInstance();
    WorkQueueReservedTasksDetails workQueueReservedTasksDetails = new WorkQueueReservedTasksDetails();
    WorkQueueCountReservedTasksByUserDetailsList workQueueCountReservedTasksByUserDetailsList = workQueueWorkspace.countWorkQueueReservedTasksByUser(
      key);

    org.jdom.Element barChartElement = new org.jdom.Element(kBarChart);
    XMLOutputter outputter = new XMLOutputter();

    // BEGIN, CR00263925, ZV
    // sort work queue reserved task details list by user name
    Comparator<WorkQueueCountReservedTasksByUserDetails> taskDetailsComparator = new WorkQueueReservedTaskDetailsComparator();

    Collections.sort(workQueueCountReservedTasksByUserDetailsList.dtls,
      taskDetailsComparator);
    // END, CR00263925

    for (int i = 0; i
      < workQueueCountReservedTasksByUserDetailsList.dtls.size(); i++) {

      org.jdom.Element unitElement = new org.jdom.Element(kUnit);
      org.jdom.Element captionElement = new org.jdom.Element(kCaption);

      captionElement.setAttribute(kText,
        workQueueCountReservedTasksByUserDetailsList.dtls.item(i).userFullName);
      captionElement.setAttribute(kUserName,
        workQueueCountReservedTasksByUserDetailsList.dtls.item(i).userName);
      captionElement.setAttribute(kTaskOptionCode, VIEWTASKSOPTION.NEXTWEEK);

      unitElement.addContent(captionElement);
      org.jdom.Element blockElement = new org.jdom.Element(kBlock);

      blockElement.setAttribute(kLength,
        workQueueCountReservedTasksByUserDetailsList.dtls.item(i).openTasksCountForUser
        + CuramConst.gkEmpty);
      blockElement.setAttribute(kID, Long.toString(key.workQueueID));
      blockElement.setAttribute(kUserName,
        workQueueCountReservedTasksByUserDetailsList.dtls.item(i).userName);
      blockElement.setAttribute(kFullName,
        workQueueCountReservedTasksByUserDetailsList.dtls.item(i).userFullName);
      blockElement.setAttribute(kType, TASKSTATUS.NOTSTARTED);
      blockElement.setAttribute(kTaskOptionCode, VIEWTASKSOPTION.NEXTWEEK);
      unitElement.addContent(blockElement);

      blockElement = new org.jdom.Element(kBlock);
      blockElement.setAttribute(kLength,
        workQueueCountReservedTasksByUserDetailsList.dtls.item(i).deferredTasksCountForUser
        + CuramConst.gkEmpty);
      blockElement.setAttribute(kID, Long.toString(key.workQueueID));
      blockElement.setAttribute(kUserName,
        workQueueCountReservedTasksByUserDetailsList.dtls.item(i).userName);
      blockElement.setAttribute(kFullName,
        workQueueCountReservedTasksByUserDetailsList.dtls.item(i).userFullName);
      blockElement.setAttribute(kType, TASKSTATUS.DEFERRED);
      blockElement.setAttribute(kTaskOptionCode, VIEWTASKSOPTION.NEXTWEEK);
      unitElement.addContent(blockElement);

      barChartElement.addContent(unitElement);
    }

    if (barChartElement.getChildren().isEmpty()) {

      workQueueReservedTasksDetails.reservedTasksXMLString = CuramConst.gkEmpty;

    } else {

      workQueueReservedTasksDetails.reservedTasksXMLString = outputter.outputString(
        barChartElement);
    }

    return workQueueReservedTasksDetails;
  }

  // _________________________________________________________________________
  /**
   * This reserveOrgUnitTasksToUser allows to reserve all or some, of the
   * assigned tasks assigned to an work queue, to a user.
   *
   * @param key -
   * ReserveWorkQueueTasksToUserKey
   * @throws AppException
   * @throws InformationalException
   */
  public void reserveWorkQueueTasksToUser(ReserveWorkQueueTasksToUserKey key)
    throws AppException, InformationalException {

    // Create StringList from taskIds
    StringList reserveTaskIDKeyList = StringUtil.delimitedText2StringList(
      key.reserveTaskIDs, '\t');

    // Create taskManagement object
    TaskManagement taskManagement = TaskManagementFactory.newInstance();

    // ReserveTaskDetailsForUser Key object
    ReserveTaskDetailsForUser reserveTaskDetailsForUser = new ReserveTaskDetailsForUser();
    // TaskKey
    TaskKey taskKey = new TaskKey();

    if (((key.userName.length() == 0) || (key.userName == null))
      && ((key.supervisorUserName.length() == 0)
        || (key.supervisorUserName == null))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORWORKQUEUE.SUPERVISOR_RESERVE_WORKQUEUE_USER_SELECTION_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if ((key.userName != null && key.userName.length() > 0)
      && (key.supervisorUserName != null && key.supervisorUserName.length() > 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORWORKQUEUE.SUPERVISOR_RESERVE_WORKQUEUE_USER_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check the Sensitivity level of the user

    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.workQueueID;

    String reservedToUser = key.userName;

    if (reservedToUser == null || reservedToUser.trim().length() == 0) {
      reservedToUser = key.supervisorUserName;
    }

    validateSensitivity(workQueueKey, reservedToUser,
      BPOSUPERVISORWORKQUEUE.RESERVE_WORKQUEUE_TASKS_FOR_USER_SENSITIVITY_MISMATCH);

    // Check task selection is empty
    if (reserveTaskIDKeyList.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORWORKQUEUE.SUPERVISOR_RESERVE_WORKQUEUE_TASKS_NO_TASK_SELECTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // iterate through selected task ids

    for (int i = 0; i < reserveTaskIDKeyList.size(); i++) {

      taskKey.taskID = Long.parseLong(reserveTaskIDKeyList.item(i));
      validateReserve(taskKey);
      reserveTaskDetailsForUser.taskID = Long.parseLong(
        reserveTaskIDKeyList.item(i));

      if (key.userName.length() == 0 || key.userName == null) {
        reserveTaskDetailsForUser.username = key.supervisorUserName;
      } else {
        reserveTaskDetailsForUser.username = key.userName;
      }
      taskManagement.reserve(reserveTaskDetailsForUser);
    }

  }

  // _________________________________________________________________________
  /**
   * This validateReserve validates the selected task is already reserved or
   * not.
   *
   * @param key -
   * TaskKey
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00198672, VK
  protected void validateReserve(TaskKey key) throws AppException,
      InformationalException {
    // END, CR00198672
    // creating users Object
    UserAccess userAccessObj = UserAccessFactory.newInstance();

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskDetailsWithoutSnapshot taskReservedByDetails = taskAdminObj.readDetails(
      key.taskID);

    if (taskReservedByDetails.reservedBy.length() > 0
      && !(taskReservedByDetails.reservedBy == null)) {
      UserFullname userFullName = new UserFullname();
      UsersKey usersKey = new UsersKey();

      usersKey.userName = taskReservedByDetails.reservedBy;

      userFullName.fullname = userAccessObj.getFullName(usersKey).fullname;

      AppException ae = new AppException(
        BPOSUPERVISORWORKQUEUE.SUPERVISOR_RESERVE_WORKQUEUE_SELECTED_TASK_MUST_NOT_BE_RESERVED);

      ae.arg(key.taskID);
      ae.arg(userFullName.fullname);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // __________________________________________________________________________
  /**
   * This method gets list of tasks reserved from a work queue, and then
   * deferred, by a particular user.
   *
   * @param key -
   * UserNameAndWorkQueueIDKey
   * @return ListDeferredTasksReservedByWorkQueueUserDetails
   * @throws AppException
   * @throws InformationalException
   */
  public ListDeferredTasksReservedByWorkQueueUserDetails listDeferredTasksReservedByWorkQueueUser(
    UserNameAndWorkQueueIDKey key) throws AppException,
      InformationalException {

    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.workQueueID;
    // Validate Sensitivity level between Supervisor and Work queue
    validateSensitivity(workQueueKey, TransactionInfo.getProgramUser(),
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);

    WorkQueueWorkspace workQueueWorkspace = WorkQueueWorkspaceFactory.newInstance();
    ListDeferredTasksReservedByWorkQueueUserDetails details = new ListDeferredTasksReservedByWorkQueueUserDetails();
    WorkQueueReservedTasksForUserKey workQueueReservedTasksForUserKey = new WorkQueueReservedTasksForUserKey();

    workQueueReservedTasksForUserKey.username = key.userName;
    workQueueReservedTasksForUserKey.workQueueID = key.workQueueID;
    workQueueReservedTasksForUserKey.taskStatus = TASKSTATUS.DEFERRED;

    details.deferredTaskList = workQueueWorkspace.getWorkQueueReservedTasksForUser(
      workQueueReservedTasksForUserKey);

    WorkQueue workQueue = WorkQueueFactory.newInstance();

    workQueueKey.workQueueID = key.workQueueID;
    WorkQueueDtls workQueueDtls = workQueue.read(workQueueKey);

    details.workQueueName = workQueueDtls.name;
    return details;

  }

  // _________________________________________________________________________
  /**
   * This method gets list of tasks reserved from a work queue by a particular
   * user, that are open
   *
   * @param key -
   * UserNameAndWorkQueueIDKey
   * @return ListDeferredTasksReservedByWorkQueueUserDetails
   * @throws AppException
   * @throws InformationalException
   */
  public ListOpenTasksReservedByWorkQueueUserDetails listOpenTasksReservedByWorkQueueUser(
    UserNameAndWorkQueueIDKey key) throws AppException,
      InformationalException {

    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.workQueueID;
    WorkQueueWorkspace workQueueWorkspace = WorkQueueWorkspaceFactory.newInstance();
    ListOpenTasksReservedByWorkQueueUserDetails details = new ListOpenTasksReservedByWorkQueueUserDetails();
    WorkQueueReservedTasksForUserKey workQueueReservedTasksForUserKey = new WorkQueueReservedTasksForUserKey();

    // Validate Sensitivity level between Supervisor and Work queue
    validateSensitivity(workQueueKey, TransactionInfo.getProgramUser(),
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);

    workQueueReservedTasksForUserKey.username = key.userName;
    workQueueReservedTasksForUserKey.workQueueID = key.workQueueID;
    workQueueReservedTasksForUserKey.taskStatus = TASKSTATUS.NOTSTARTED;

    details.openTaskDetailsList = workQueueWorkspace.getWorkQueueReservedTasksForUser(
      workQueueReservedTasksForUserKey);
    WorkQueue workQueue = WorkQueueFactory.newInstance();

    workQueueKey.workQueueID = key.workQueueID;
    WorkQueueDtls workQueueDtls = workQueue.read(workQueueKey);

    details.workQueueName = workQueueDtls.name;
    return details;
  }

  // _________________________________________________________________________
  /**
   * This method lists the Due on date tasks records for the Work Queues.
   *
   * @param key -
   * WorkQueueTasksDueOnDateKey
   * @return ListWorkQueueTasksDueByWeekDetails
   * @throws AppException
   * @throws InformationalException
   */
  public ListWorkQueueTasksDueByWeekDetails listWorkQueueTasksByWeek(
    WorkQueueTasksDueOnDateKey key) throws AppException,
      InformationalException {
    // Create ListWorkQueueTasksDueByWeekDetails object
    ListWorkQueueTasksDueByWeekDetails listWorkQueueTasksDueByWeekDetails = new ListWorkQueueTasksDueByWeekDetails();

    // Create WorkQueueWorkspace object to get tasks due by week
    curam.core.sl.supervisor.intf.WorkQueueWorkspace workQueueWorkspace = WorkQueueWorkspaceFactory.newInstance();
    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.dueKey.workQueueID;
    validateSensitivity(workQueueKey, TransactionInfo.getProgramUser(),
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);
    listWorkQueueTasksDueByWeekDetails.dueByWeekDetails = workQueueWorkspace.getWorkQueueTasksDueByWeek(
      key.dueKey);

    return listWorkQueueTasksDueByWeekDetails;
  }

  // _________________________________________________________________________
  /**
   * This method is to check the Work Queue Sensitivity against
   * Supervisor's Sensitivity.
   *
   * @param key -
   * WorkQueueTasksDueOnDateKey
   * @param userName -
   * String
   * @param exceptionMsg
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00198672, VK
  protected void validateSensitivity(WorkQueueKey key, String userName,
    CatEntry exceptionMsg) throws AppException, InformationalException {
    // END, CR00198672
    // Create Work Queue object to obtain Sensitivity
    WorkQueue workQueue = WorkQueueFactory.newInstance();
    WorkQueueDtls workQueueDtls = workQueue.read(key);

    // Get the value of Sensitivity of the Supervisor

    curam.core.intf.Users usersObj = UsersFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    usersKey.userName = userName;
    UsersDtls usersDtls = usersObj.read(usersKey);

    int supervisorSensitivity = Integer.parseInt(usersDtls.sensitivity);
    int workQueueSensitivity = Integer.parseInt(workQueueDtls.sensitivity);

    /*
     * If Work queue sensitivity more than supervisor sensitivity throw
     exception*/
    if (workQueueSensitivity > supervisorSensitivity) {
      throw new AppException(exceptionMsg);
    }
  }

  // _________________________________________________________________________
  /**
   * This method lists the Due on date tasks records for the Work Queues.
   *
   * @param key -
   * WorkQueueTasksDueOnDateKey
   * @return ListWorkQueueTasksDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  public ListWorkQueueTasksDueOnDateDetails listWorkQueueTasksDueOnDate(
    WorkQueueTasksDueOnDateKey key) throws AppException,
      InformationalException {
    // Create ListWorkQueueTasksDueOnDateDetails object
    ListWorkQueueTasksDueOnDateDetails listWorkQueueTasksDueOnDateDetails = new ListWorkQueueTasksDueOnDateDetails();

    // Create WorkQueueWorkspace object to get tasks due by date
    curam.core.sl.supervisor.intf.WorkQueueWorkspace workQueueWorkspace = WorkQueueWorkspaceFactory.newInstance();
    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.dueKey.workQueueID;

    validateSensitivity(workQueueKey, TransactionInfo.getProgramUser(),
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);
    listWorkQueueTasksDueOnDateDetails.dueByDateDetails = workQueueWorkspace.getWorkQueueTasksDueOnDate(
      key.dueKey);

    return listWorkQueueTasksDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This listWorkQueueAssignedTasks - lists work queue assigned tasks.
   *
   * @param key -
   * WorkQueueKey
   * @return WorkQueueAssignedTasksSummaryDetailsList
   * @throws AppException
   * @throws InformationalException
   */
  public WorkQueueAssignedTasksSummaryDetailsList listWorkQueueAssignedTasks(
    WorkQueueKey key) throws AppException, InformationalException {

    // Create WorkQueueAssignedTasksSummaryDetailsList object
    WorkQueueAssignedTasksSummaryDetailsList workQueueAssignedTasksSummaryDetailsList = new WorkQueueAssignedTasksSummaryDetailsList();

    // Create WorkQueueWorkspace object
    WorkQueueWorkspace workQueueWorkspace = WorkQueueWorkspaceFactory.newInstance();

    // Validate Sensitivity level between Supervisor and Work queue
    validateSensitivity(key, TransactionInfo.getProgramUser(),
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);

    /*
     * Create WorkQueueAssignedTasksSummaryDetailsList to populate the
     details list */
    curam.core.sl.supervisor.struct.WorkQueueAssignedTasksSummaryDetailsList workQueueAssingedTasksDetailsList = new curam.core.sl.supervisor.struct.WorkQueueAssignedTasksSummaryDetailsList();

    workQueueAssingedTasksDetailsList = workQueueWorkspace.getAssignedWorkQueueTasks(
      key);

    workQueueAssignedTasksSummaryDetailsList.assignedTaskDetails = workQueueAssingedTasksDetailsList;

    return workQueueAssignedTasksSummaryDetailsList;
  }

  // _________________________________________________________________________
  /**
   * This listWorkQueueAssignedTasks - lists work queue assigned tasks.
   *
   * @param key -
   * WorkQueueKey
   * @return WorkQueueAssignedTasksSummaryDetailsList
   * @throws AppException
   * @throws InformationalException
   */
  public WorkQueueAssignedTasksSummaryDetailsList listWorkQueueReserveAssignedTasks(
    WorkQueueKey key) throws AppException, InformationalException {

    // Create WorkQueueAssignedTasksSummaryDetailsList object
    WorkQueueAssignedTasksSummaryDetailsList workQueueAssignedTasksSummaryDetailsList = new WorkQueueAssignedTasksSummaryDetailsList();

    // Create WorkQueueWorkspace object
    WorkQueueWorkspace workQueueWorkspace = WorkQueueWorkspaceFactory.newInstance();

    WorkQueue workQueue = WorkQueueFactory.newInstance();
    WorkQueueDtls workQueueDtls = workQueue.read(key);
    SystemUser systemUser = SystemUserFactory.newInstance();
    String supervisorUserName = systemUser.getSystemUserDetails().userName;

    if (!workQueueDtls.administratorUserName.equals(supervisorUserName)) {
      // Validate Sensitivity level between Supervisor and Work queue
      validateSensitivity(key, TransactionInfo.getProgramUser(),
        BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);

      // If subscriptions are not allowed to the work queue
      if (!workQueueDtls.allowUserSubscriptionInd) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_TASKS_FOR_USER_NO_ALLOW_SUBSCRIPTION_INDICATOR),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // Create WorkQueueAssignedTasksSummaryDetailsList to populate the
    // details list
    curam.core.sl.supervisor.struct.WorkQueueAssignedTasksSummaryDetailsList workQueueAssingedTasksDetailsList = new curam.core.sl.supervisor.struct.WorkQueueAssignedTasksSummaryDetailsList();

    workQueueAssingedTasksDetailsList = workQueueWorkspace.getAssignedWorkQueueTasks(
      key);

    workQueueAssignedTasksSummaryDetailsList.assignedTaskDetails = workQueueAssingedTasksDetailsList;

    return workQueueAssignedTasksSummaryDetailsList;
  }

  // _________________________________________________________________________
  /**
   * This readWorkQueueUsersScheduleDetails - lists all the subscribers
   * associated to a work queue and count of activities for every subscribers
   *
   * @param key -
   * WorkqueueIDAndStartDateKey
   * @return WorkqueueUsersScheduleDetails
   * @throws AppException
   * @throws InformationalException
   */
  public WorkqueueUsersScheduleDetails readWorkQueueUsersScheduleDetails(
    WorkqueueIDAndStartDateKey key) throws AppException,
      InformationalException {

    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.workQueueID;
    SystemUser systemUser = SystemUserFactory.newInstance();

    // Validate Sensitivity level between Supervisor and Work queue
    validateSensitivity(workQueueKey, systemUser.getUserDetails().userName,
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);

    WorkqueueUsersScheduleDetails workqueueUsersScheduleDetails = new WorkqueueUsersScheduleDetails();

    // This will get number of days in a week based of Environment variable
    int numberOfDays = getNumberOfDaysInWeek();

    // This will calculate start-date and end-date for given date.
    workqueueUsersScheduleDetails = populateWeekStartAndEndDate(
      key.weekBeginDate, numberOfDays);

    WorkqueueIDDateTimeAndStatusKey workqueueIDDateTimeAndStatusKey = new WorkqueueIDDateTimeAndStatusKey();

    // To set the intake key values for the query
    workqueueIDDateTimeAndStatusKey.workQueueID = key.workQueueID;
    workqueueIDDateTimeAndStatusKey.startDateTime = workqueueUsersScheduleDetails.previousDate.getDateTime();

    workqueueIDDateTimeAndStatusKey.endDateTime = workqueueUsersScheduleDetails.nextDate.getDateTime();
    workqueueIDDateTimeAndStatusKey.recordStatusCode = RECORDSTATUS.NORMAL;

    /*
     * The method countActivityForWorkqueueSubscribers from Activity class
     * returns Count of activities and subscribers result set from query
     */

    workqueueUsersScheduleDetails.workQueueScheduleDetails = UserAccessFactory.newInstance().countActivityForWorkqueueSubscribers(
      workqueueIDDateTimeAndStatusKey);

    // Setting previous and next date for the previous and next date links
    Date previousDate = workqueueUsersScheduleDetails.previousDate.addDays(-7);
    Date nextDate = workqueueUsersScheduleDetails.previousDate.addDays(7);

    workqueueUsersScheduleDetails.nextDate = nextDate;
    workqueueUsersScheduleDetails.previousDate = previousDate;

    return workqueueUsersScheduleDetails;
  }

  /**
   * Utility method for populating start and end dates of week
   *
   * @param key -
   * Date , number of days in a week
   * @param numberOfDays
   * @return WorkqueueUsersScheduleDetails
   */
  // BEGIN, CR00198672, VK
  protected WorkqueueUsersScheduleDetails populateWeekStartAndEndDate(Date key,
    int numberOfDays) {
    // END, CR00198672
    WorkqueueUsersScheduleDetails newStartEndDates = new WorkqueueUsersScheduleDetails();

    if (key.isZero()) {
      int checkDate = Date.getCurrentDate().getCalendar().get(
        java.util.Calendar.DAY_OF_WEEK);

      if (checkDate == 2) {
        newStartEndDates.previousDate = Date.getCurrentDate();
        newStartEndDates.nextDate = newStartEndDates.previousDate.addDays(
          numberOfDays);
      } else {
        newStartEndDates.previousDate = Date.getCurrentDate().addDays(
          2 - checkDate);
        newStartEndDates.nextDate = newStartEndDates.previousDate.addDays(
          numberOfDays);
      }
    } else {
      newStartEndDates.previousDate = key;
      newStartEndDates.nextDate = newStartEndDates.previousDate.addDays(
        numberOfDays);
    }
    newStartEndDates.weekBeginDate = newStartEndDates.previousDate;
    return newStartEndDates;
  }

  // __________________________________________________________________________
  /**
   * This listDeferredWorkQueueReservedTasksDueByWeek - lists the details of
   * the  deferred tasks reserved by user due in a week in a work queue.
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @return ListDeferredTasksReservedByWorkQueueUserDetails
   * @throws AppException
   * @throws InformationalException
   */

  public ListDeferredTasksReservedByWorkQueueUserDetails listDeferredWorkQueueReservedTasksDueByWeek(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    ListDeferredTasksReservedByWorkQueueUserDetails listDeferredTasksReservedByWorkQueueUserDetails = new ListDeferredTasksReservedByWorkQueueUserDetails();
    WorkQueueWorkspace workQueueWorkspace = WorkQueueWorkspaceFactory.newInstance();
    WorkQueueReservedTasksDueOnDateKey workQueueReservedTasksDueOnDateKey = new WorkQueueReservedTasksDueOnDateKey();
    WorkQueueKey workQueueKey = new WorkQueueKey();
    SystemUser systemUser = SystemUserFactory.newInstance();

    // Assign key values
    workQueueReservedTasksDueOnDateKey.deadlineDate = key.dueKey.deadlineDate;
    workQueueReservedTasksDueOnDateKey.workQueueID = key.dueKey.workQueueID;
    workQueueReservedTasksDueOnDateKey.reservedBy = key.dueKey.reservedBy;

    workQueueKey.workQueueID = key.dueKey.workQueueID;

    // Validate Sensitivity level between Supervisor and Work queue
    validateSensitivity(workQueueKey, systemUser.getUserDetails().userName,
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);

    // Create Entity layer method to retrieve the reserved tasks details.
    listDeferredTasksReservedByWorkQueueUserDetails.deferredTaskList = workQueueWorkspace.getDeferredWorkQueueReservedTasksDueByWeek(
      workQueueReservedTasksDueOnDateKey);

    return listDeferredTasksReservedByWorkQueueUserDetails;
  }

  // __________________________________________________________________________
  /**
   * This listOpenWorkQueueReservedTasksDueByWeek - lists the details of the
   * open tasks reserved by user due in a week in a work queue.
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @return ListOpenTasksReservedByWorkQueueUserDetails
   * @throws AppException
   * @throws InformationalException
   */

  public ListOpenTasksReservedByWorkQueueUserDetails listOpenWorkQueueReservedTasksDueByWeek(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    ListOpenTasksReservedByWorkQueueUserDetails listOpenTasksReservedByWorkQueueUserDetails = new ListOpenTasksReservedByWorkQueueUserDetails();
    WorkQueueWorkspace workQueueWorkspace = WorkQueueWorkspaceFactory.newInstance();
    WorkQueueReservedTasksDueOnDateKey workQueueReservedTasksDueOnDateKey = new WorkQueueReservedTasksDueOnDateKey();
    WorkQueueKey workQueueKey = new WorkQueueKey();
    SystemUser systemUser = SystemUserFactory.newInstance();

    // Assign key values
    workQueueReservedTasksDueOnDateKey.deadlineDate = key.dueKey.deadlineDate;
    workQueueReservedTasksDueOnDateKey.workQueueID = key.dueKey.workQueueID;
    workQueueReservedTasksDueOnDateKey.reservedBy = key.dueKey.reservedBy;

    workQueueKey.workQueueID = key.dueKey.workQueueID;

    // Validate Sensitivity level between Supervisor and Work queue
    validateSensitivity(workQueueKey, systemUser.getUserDetails().userName,
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);

    // Create Entity layer method to retrieve the reserved tasks details.
    listOpenTasksReservedByWorkQueueUserDetails.openTaskDetailsList = workQueueWorkspace.getOpenWorkQueueReservedTasksDueByWeek(
      workQueueReservedTasksDueOnDateKey);

    return listOpenTasksReservedByWorkQueueUserDetails;
  }

  // _________________________________________________________________________
  /**
   * This listDeferredWorkQueueReservedTasksDueOnDate is used to list the
   * Deferred Reserved Tasks Due On Date details list.
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @return listDeferredTasksReservedByWorkQueueUserDetails -
   * ListDeferredTasksReservedByWorkQueueUserDetails
   * @throws AppException
   * @throws InformationalException
   */
  public ListDeferredTasksReservedByWorkQueueUserDetails listDeferredWorkQueueReservedTasksDueOnDate(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    // Create Entity layer method to retrieve the reserved tasks details.
    curam.core.sl.supervisor.intf.WorkQueueWorkspace workQueueWorkspace = curam.core.sl.supervisor.fact.WorkQueueWorkspaceFactory.newInstance();

    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.dueKey.workQueueID;
    SystemUser systemUser = SystemUserFactory.newInstance();

    // Validate Sensitivity level between Supervisor and Work queue
    validateSensitivity(workQueueKey, systemUser.getUserDetails().userName,
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);

    ListDeferredTasksReservedByWorkQueueUserDetails listDeferredTasksReservedByWorkQueueUserDetails = new ListDeferredTasksReservedByWorkQueueUserDetails();

    WorkQueueReservedTasksDueOnDateKey workQueueReservedTasksDueOnDateKey = new WorkQueueReservedTasksDueOnDateKey();

    workQueueReservedTasksDueOnDateKey.deadlineDate = key.dueKey.deadlineDate;
    workQueueReservedTasksDueOnDateKey.workQueueID = key.dueKey.workQueueID;
    workQueueReservedTasksDueOnDateKey.reservedBy = key.dueKey.reservedBy;

    // The call to entity layer method
    listDeferredTasksReservedByWorkQueueUserDetails.deferredTaskList = workQueueWorkspace.getDeferredWorkQueueReservedTasksDueOnDate(
      workQueueReservedTasksDueOnDateKey);

    return listDeferredTasksReservedByWorkQueueUserDetails;
  }

  // _________________________________________________________________________
  /**
   * This listOpenWorkQueueReservedTasksDueOnDate is used to list the Open
   * Reserved Tasks Due On Date details list.
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @return listOpenTasksReservedByWorkQueueUserDetails -
   * ListOpenTasksReservedByWorkQueueUserDetails
   * @throws AppException
   * @throws InformationalException
   */
  public ListOpenTasksReservedByWorkQueueUserDetails listOpenWorkQueueReservedTasksDueOnDate(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    // Create Entity layer method to retrieve the reserved tasks details.
    curam.core.sl.supervisor.intf.WorkQueueWorkspace workQueueWorkspace = curam.core.sl.supervisor.fact.WorkQueueWorkspaceFactory.newInstance();

    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.dueKey.workQueueID;
    SystemUser systemUser = SystemUserFactory.newInstance();

    // Validate Sensitivity level between Supervisor and Work queue
    validateSensitivity(workQueueKey, systemUser.getUserDetails().userName,
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);

    ListOpenTasksReservedByWorkQueueUserDetails listOpenTasksReservedByWorkQueueUserDetails = new ListOpenTasksReservedByWorkQueueUserDetails();

    WorkQueueReservedTasksDueOnDateKey workQueueReservedTasksDueOnDateKey = new WorkQueueReservedTasksDueOnDateKey();

    workQueueReservedTasksDueOnDateKey.deadlineDate = key.dueKey.deadlineDate;
    workQueueReservedTasksDueOnDateKey.workQueueID = key.dueKey.workQueueID;
    workQueueReservedTasksDueOnDateKey.reservedBy = key.dueKey.reservedBy;

    // The call to entity layer method
    listOpenTasksReservedByWorkQueueUserDetails.openTaskDetailsList = workQueueWorkspace.getOpenWorkQueueReservedTasksDueOnDate(
      workQueueReservedTasksDueOnDateKey);

    return listOpenTasksReservedByWorkQueueUserDetails;
  }

  // _______________________________________________________________________
  /**
   * This readWorkqueueReservedTasksByUserDueByWeek- displays the bar chart
   * representation of the open and deferred reserved tasks in a work queue in
   * a  week.
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @return WorkQueueReservedTasksByUserDueByWeekDetails
   * @throws AppException
   * @throws InformationalException
   */

  public WorkQueueReservedTasksByUserDueByWeekDetails readWorkqueueReservedTasksByUserDueByWeek(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    WorkQueueReservedTasksByUserDueByWeekDetails workQueueReservedTasksByUserDueByWeekDetails = new WorkQueueReservedTasksByUserDueByWeekDetails();
    SystemUser systemUser = SystemUserFactory.newInstance();
    WorkQueue workQueueObj = WorkQueueFactory.newInstance();
    WorkQueueWorkspace workQueueWorkspace = WorkQueueWorkspaceFactory.newInstance();

    // Assign values to key
    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.dueKey.workQueueID;

    // Create Entity layer method to retrieve the reserved tasks details.
    WorkQueueNameDetails nameDetails = workQueueObj.readWorkQueueName(
      workQueueKey);

    // Validate Sensitivity level between Supervisor and Work queue
    validateSensitivity(workQueueKey, systemUser.getUserDetails().userName,
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);
    WorkQueueCountReservedTasksByUserDetailsList workQueueCountReservedTasksByUserDetailsList = workQueueWorkspace.countWorkQueueReservedTasksByUserDueByWeek(
      key.dueKey);

    workQueueReservedTasksByUserDueByWeekDetails.barChartXML = constructBarChartXML(
      key, workQueueCountReservedTasksByUserDetailsList,
      VIEWTASKSOPTION.NEXTMONTH, nameDetails.name);

    return workQueueReservedTasksByUserDueByWeekDetails;

  }

  // _________________________________________________________________________
  /**
   * This constructBarChartXML is used to construct bar chart from the details
   * list, which represents the open and deferred tasks.
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @param workQueueCountReservedTasksByUserDetailsList -
   * WorkQueueCountReservedTasksByUserDetailsList
   * @param taskOptionCode String
   * @param workQueueName  String
   *
   * @return String - of bar chart xml values
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartXML(
    WorkQueueReservedTasksByUserKey key,
    WorkQueueCountReservedTasksByUserDetailsList
    workQueueCountReservedTasksByUserDetailsList,
    String taskOptionCode, String workQueueName) {
    // END, CR00198672
    Element barChartElement = new Element(kBarChart);
    XMLOutputter outputter = new XMLOutputter();
    int listSize = workQueueCountReservedTasksByUserDetailsList.dtls.size();

    // BEGIN, CR00263925, ZV
    // sort work queue reserved task details list by user name
    Comparator<WorkQueueCountReservedTasksByUserDetails> taskDetailsComparator = new WorkQueueReservedTaskDetailsComparator();

    Collections.sort(workQueueCountReservedTasksByUserDetailsList.dtls,
      taskDetailsComparator);
    // END, CR00263925

    for (int i = 0; i < listSize; i++) {
      WorkQueueCountReservedTasksByUserDetails workQueueDetails = workQueueCountReservedTasksByUserDetailsList.dtls.item(
        i);
      Element unitElement = new Element(kUnit);
      Element captionElement = new Element(kCaption);

      captionElement.setAttribute(kText, workQueueDetails.userFullName);
      captionElement.setAttribute(kUserName, workQueueDetails.userName);
      captionElement.setAttribute(kTaskOptionCode, taskOptionCode);

      unitElement.addContent(captionElement);

      Element blockElement = new Element(kBlock);

      blockElement.setAttribute(kType, TASKSTATUS.NOTSTARTED);
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      blockElement.setAttribute(kID, Long.toString(key.dueKey.workQueueID));
      blockElement.setAttribute(kLength,
        workQueueDetails.openTasksCountForUser + CuramConst.gkEmpty);
      blockElement.setAttribute(kUserName, workQueueDetails.userName);
      blockElement.setAttribute(kFullName, workQueueDetails.userFullName);
      blockElement.setAttribute(kWorkQueueName, workQueueName);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.dueKey.deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642
      unitElement.addContent(blockElement);

      blockElement = new Element(kBlock);
      blockElement.setAttribute(kType, TASKSTATUS.DEFERRED);
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      blockElement.setAttribute(kID, Long.toString(key.dueKey.workQueueID));
      blockElement.setAttribute(kLength,
        workQueueDetails.deferredTasksCountForUser + CuramConst.gkEmpty);
      blockElement.setAttribute(kUserName, workQueueDetails.userName);
      blockElement.setAttribute(kFullName, workQueueDetails.userFullName);
      blockElement.setAttribute(kWorkQueueName, workQueueName);
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.dueKey.deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642
      unitElement.addContent(blockElement);

      barChartElement.addContent(unitElement);

    }

    if (barChartElement.getChildren().isEmpty()) {

      return CuramConst.gkEmpty;

    } else {
      return outputter.outputString(barChartElement);
    }
  }

  // _________________________________________________________________________
  /**
   * This readWorkqueueReservedTasksByUserDueOnDate is used to construct bar
   * chart from the details list.
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey
   * @return workQueueReservedTasksByUserDueOnDateDetails -
   * WorkQueueReservedTasksByUserDueOnDateDetails
   * @throws AppException
   * @throws InformationalException
   */
  public WorkQueueReservedTasksByUserDueOnDateDetails readWorkqueueReservedTasksByUserDueOnDate(
    WorkQueueReservedTasksByUserKey key) throws AppException,
      InformationalException {

    // Create Entity layer method to retrieve the reserved tasks details.
    curam.core.sl.supervisor.intf.WorkQueueWorkspace workQueueWorkspace = curam.core.sl.supervisor.fact.WorkQueueWorkspaceFactory.newInstance();

    WorkQueueKey workQueueKey = new WorkQueueKey();

    workQueueKey.workQueueID = key.dueKey.workQueueID;
    SystemUser systemUser = SystemUserFactory.newInstance();

    // Validate Sensitivity level between Supervisor and Work queue
    validateSensitivity(workQueueKey, systemUser.getUserDetails().userName,
      BPOSUPERVISORWORKQUEUE.SUPERVISOR_WORKQUEUE_SENSITIVITY_MISMATCH);

    WorkQueueReservedTasksByUserDueOnDateDetails workQueueReservedTasksByUserDueOnDateDetails = new WorkQueueReservedTasksByUserDueOnDateDetails();
    WorkQueueCountReservedTasksByUserDetailsList workQueueCountReservedTasksByUserDetailsList = new WorkQueueCountReservedTasksByUserDetailsList();

    // The call to entity layer method
    workQueueCountReservedTasksByUserDetailsList = workQueueWorkspace.countWorkQueueReservedTasksByUserDueOnDate(
      key.dueKey);

    workQueueReservedTasksByUserDueOnDateDetails.dueOnDateDtls = workQueueCountReservedTasksByUserDetailsList;

    WorkQueue workQueueObj = WorkQueueFactory.newInstance();
    WorkQueueNameDetails nameDetails = workQueueObj.readWorkQueueName(
      workQueueKey);

    // The call to constructBarChartForReservedTasksDetailsList to create
    // bar chart
    workQueueReservedTasksByUserDueOnDateDetails.barChartXML = constructBarChartForReservedTasksDetailsList(
      key, workQueueCountReservedTasksByUserDetailsList,
      VIEWTASKSOPTION.NEXTWEEK, nameDetails.name);

    return workQueueReservedTasksByUserDueOnDateDetails;
  }

  // _________________________________________________________________________
  /**
   * This constructBarChartFromDetailsList is used to construct bar chart from
   * the details list.
   *
   * @param key -
   * WorkQueueReservedTasksByUserKey,
   * @param detailsList -
   * WorkQueueCountReservedTasksByUserDetailsList
   * @param taskOptionCode
   * String
   * @param workQueueName
   * @return String - of bar chart xml values
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartForReservedTasksDetailsList(
    WorkQueueReservedTasksByUserKey key,
    WorkQueueCountReservedTasksByUserDetailsList detailsList,
    String taskOptionCode, String workQueueName) {
    // END, CR00198672
    Element barChartElement = new Element(kBarChart);
    XMLOutputter outputter = new XMLOutputter();

    int listSize = detailsList.dtls.size();

    // BEGIN, CR00263925, ZV
    // sort work queue reserved task details list by user full name
    Comparator<WorkQueueCountReservedTasksByUserDetails> reservedTaskDetailsComparator = new WorkQueueReservedTaskDetailsComparator();

    Collections.sort(detailsList.dtls, reservedTaskDetailsComparator);
    // END, CR00263925

    for (int i = 0; i < listSize; i++) {

      curam.core.sl.supervisor.struct.WorkQueueCountReservedTasksByUserDetails taskDetails = detailsList.dtls.item(
        i);

      Element unitElement = new Element(kUnit);
      Element captionElement = new Element(kCaption);

      captionElement.setAttribute(kText, taskDetails.userFullName.toString());
      captionElement.setAttribute(kUserName, taskDetails.userName.toString());
      captionElement.setAttribute(kTaskOptionCode, taskOptionCode);

      unitElement.addContent(captionElement);

      Element blockElement = new Element(kBlock);

      blockElement.setAttribute(kID, Long.toString(key.dueKey.workQueueID));
      blockElement.setAttribute(kType, TASKSTATUS.NOTSTARTED);
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      blockElement.setAttribute(kWorkQueueName, workQueueName);
      blockElement.setAttribute(kUserName, taskDetails.userName.toString());
      blockElement.setAttribute(kFullName, taskDetails.userFullName.toString());
      blockElement.setAttribute(kLength,
        Long.toString(taskDetails.openTasksCountForUser) + CuramConst.gkEmpty);

      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.dueKey.deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642

      unitElement.addContent(blockElement);

      blockElement = new Element(kBlock);
      blockElement.setAttribute(kID, Long.toString(key.dueKey.workQueueID));
      blockElement.setAttribute(kType, TASKSTATUS.DEFERRED);
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      blockElement.setAttribute(kWorkQueueName, workQueueName);
      blockElement.setAttribute(kFullName, taskDetails.userFullName.toString());
      blockElement.setAttribute(kUserName, taskDetails.userName.toString());

      blockElement.setAttribute(kLength,
        Long.toString(taskDetails.deferredTasksCountForUser)
        + CuramConst.gkEmpty);

      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(key.dueKey.deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642

      unitElement.addContent(blockElement);

      barChartElement.addContent(unitElement);

    }

    if (barChartElement.getChildren().isEmpty()) {

      return CuramConst.gkEmpty;

    } else {

      return outputter.outputString(barChartElement);
    }
  }

  // BEGIN, CR00215999, LP
  /**
   * Read work queue workspace details on week basis
   *
   * @param key
   * WorkQueueKey
   * @return WorkQueueWorkspaceDtls workQueueWorkspaceDetails
   * @throws AppException
   * @throws InformationalException
   */
  public WorkQueueWorkspaceDtls readWorkQueueWorkspaceWeekDtls(
    final WorkQueueKey key) throws AppException, InformationalException {

    final WorkQueueWorkspaceDtls workspaceDetails = new WorkQueueWorkspaceDtls();
    final WorkQueueWorkspace workspace = WorkQueueWorkspaceFactory.newInstance();
    final WorkQueueTasksDueInTheNextWeekKey weekKey = new WorkQueueTasksDueInTheNextWeekKey();

    // assigning key values
    weekKey.workQueueID = key.workQueueID;
    // BEGIN, CR00274837 ZV
    weekKey.deadlineDate = Date.getCurrentDate();
    // END, CR00274837
    weekKey.numberOfDays = getNumberOfDaysInWeek();

    final WorkQueueTasksDueInTheNextTimePeriodDetailsList detailsList = workspace.countWorkQueueTasksDueInTheNextWeek(
      weekKey);

    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
    final WorkQueueNameStruct nameDetails = workQueueObj.readWorkQueueNameByWorkQueueID(
      key);

    workspaceDetails.barChartXML = constructBarChartFromDetailsList(key,
      detailsList, VIEWTASKSOPTION.NEXTWEEK, nameDetails.name);
    workspaceDetails.workQueueDetails = getWorkQueueDetails(key);
    workspaceDetails.subscriptionDetailsList = getSubscriptionDtlsList(key);
    return workspaceDetails;
  }

  // END, CR00215999

  // BEGIN, CR00215999, LP
  /**
   * This methods read the work queue workspace details for the next month
   *
   * @param key
   * WorkQueueKey
   * @return WorkQueueWorkspaceDtls
   * @throws AppException
   * @throws InformationalException
   */
  public WorkQueueWorkspaceDtls readWorkQueueWorkspaceMonthDtls(
    final WorkQueueKey key) throws AppException, InformationalException {
    final WorkQueueWorkspaceDtls workspaceDetails = new WorkQueueWorkspaceDtls();

    final WorkQueueWorkspace workspace = WorkQueueWorkspaceFactory.newInstance();
    final WorkQueueTasksDueInTheNextMonthKey monthKey = new WorkQueueTasksDueInTheNextMonthKey();

    // assigning key values
    monthKey.workQueueID = key.workQueueID;
    // BEGIN, CR00274837 ZV
    monthKey.deadlineDate = Date.getCurrentDate();
    // END, CR00274837
    monthKey.numberOfWeeks = kNumberOfWeeks;

    final WorkQueueTasksDueInTheNextTimePeriodDetailsList detailsList = workspace.countWorkQueueTasksDueInTheNextMonth(
      monthKey);

    final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
    final WorkQueueNameStruct nameDetails = workQueueObj.readWorkQueueNameByWorkQueueID(
      key);

    workspaceDetails.barChartXML = constructBarChartFromDetailsList(key,
      detailsList, VIEWTASKSOPTION.NEXTMONTH, nameDetails.name);
    workspaceDetails.workQueueDetails = getWorkQueueDetails(key);
    workspaceDetails.subscriptionDetailsList = getSubscriptionDtlsList(key);

    return workspaceDetails;
  }

  // END, CR00215999

  // BEGIN, CR00215999, LP
  /**
   * Get the list of subscribed users and organization objects (like
   * organization unit, position , job) for WorkQueue
   *
   * @param WorkQueueKey
   * Work Queue ID
   * @return WorkQueueSubscriberUserDetailsList List of Work Queue subscribers
   * for a Work Queue.
   */

  protected WorkQueueSubscriberUserDtlsList getSubscriptionDtlsList(
    final WorkQueueKey key) throws AppException, InformationalException {

    final WorkQueueSubscriberUserDtlsList detailsList = new WorkQueueSubscriberUserDtlsList();

    // users list
    detailsList.dtlsList.addAll(getSubscribedUserDtlsList(key).dtlsList);

    // org objects list
    detailsList.orgDtlsList.addAll(
      getSubscribedOrgObjectDtlsList(key).orgDtlsList);

    return detailsList;
  }

  // END, CR00215999

  // BEGIN, CR00215999, LP
  /**
   * Get Subscribed User list
   *
   * @param WorkQueueKey
   * Work Queue ID.
   * @return WorkQueueSubscriberUserDetailsList List of Work Queue user
   * subscribers for a Work Queue.
   * @throws AppException
   * @throws InformationalException
   */

  protected WorkQueueSubscriberUserDtlsList getSubscribedUserDtlsList(
    final WorkQueueKey key) throws AppException, InformationalException {

    final SearchSubscriptionsByWorkQueueIDKey subscriptionsByWorkQueueIDKey = new SearchSubscriptionsByWorkQueueIDKey();

    final WorkQueueSubscriberUserDtlsList detailsList = new WorkQueueSubscriberUserDtlsList();
    final Users usersObj = UsersFactory.newInstance();

    final UsersKey usersKey = new UsersKey();

    subscriptionsByWorkQueueIDKey.workQueueID = key.workQueueID;
    final WorkQueueSubscriptionFullDetailsList subscriptionDetailsList = UserAccessFactory.newInstance().searchUserSubscriptionsByWorkQueueID(
      subscriptionsByWorkQueueIDKey);

    for (int i = 0; i < subscriptionDetailsList.dtls.size(); i++) {

      final WorkQueueSubscriberUserDtls details = new WorkQueueSubscriberUserDtls();

      details.userFullName = subscriptionDetailsList.dtls.item(i).subscriberName;
      details.userName = subscriptionDetailsList.dtls.item(i).userName;
      details.subscriberType = WQSUBSORGOBJECTTYPE.USER;
      details.subscriptionDateTime = subscriptionDetailsList.dtls.item(i).subscriptionDateTime;

      // populating unsubscribe page title and confirmation texts
      details.pageTitle = userPageTitle.getMessage();

      details.unsubscribePageText = userPageText.getMessage();

      usersKey.userName = subscriptionDetailsList.dtls.item(i).userName;
      final UsersDtls userDetails = usersObj.read(usersKey);
      EmailAddressDtls emailAddressDtls = new EmailAddressDtls();

      if (userDetails.businessEmailID != 0) {
        // Get the Email address
        final EmailAddress emailAddressObj = EmailAddressFactory.newInstance();
        final EmailAddressKey emailAddressKey = new EmailAddressKey();

        emailAddressKey.emailAddressID = userDetails.businessEmailID;
        emailAddressDtls = emailAddressObj.read(emailAddressKey);
        details.userEmailID = emailAddressDtls.emailAddress;
        details.userEmailLink = kMailLink + emailAddressDtls.emailAddress;
      }

      // Get the ID for the phone record inserted
      PhoneNumberDtls phoneNumberDtls = new PhoneNumberDtls();

      if (userDetails.businessPhoneID != 0) {
        final PhoneNumber phoneNumberObj = PhoneNumberFactory.newInstance();
        final PhoneNumberKey phoneNumberKey = new PhoneNumberKey();

        phoneNumberKey.phoneNumberID = userDetails.businessPhoneID;
        phoneNumberDtls = phoneNumberObj.read(phoneNumberKey);

        details.userPhoneNumber = SupervisorConst.kPlus
          + phoneNumberDtls.phoneAreaCode + CuramConst.gkSpace
          + phoneNumberDtls.phoneNumber;

      }

      details.userEmailLink = kMailLink + emailAddressDtls.emailAddress;
      detailsList.dtlsList.addRef(details);
    }

    return detailsList;
  }

  // END, CR00215999

  // BEGIN, CR00215999, LP
  /**
   * Gets Organization Object list of subscribers for a Work Queue.
   * The List will contain the details of the Org objects that are subscribed
   * to the Work Queue.The Organization Objects include org unit, position,
   * job.
   *
   * @param WorkQueueKey
   * Work Queue ID.
   * @return WorkQueueSubscriberUserDtlsList
   * List of Work Queue Org Object subscribers for a Work Queue.
   */
  protected WorkQueueSubscriberUserDtlsList getSubscribedOrgObjectDtlsList
    (WorkQueueKey key) throws AppException, InformationalException {

    WorkQueueSubscriberUserDtlsList detailsList = new WorkQueueSubscriberUserDtlsList();

    // calling the API from WorkQueue subscription
    // BEGIN, CR00225579, LP
    WorkQueueSubscriptionFullDetailsList subscriptionDetailsList = WorkQueueSubscriptionFactory.newInstance().listOrgObjectSubscriptionsForWorkQueue(
      key);

    // END, CR00225579

    for (int i = 0; i < subscriptionDetailsList.dtls.size(); i++) {

      WorkQueueSubscriberOrgObjDetails details = new WorkQueueSubscriberOrgObjDetails();

      details.subscriberID = subscriptionDetailsList.dtls.item(i).subscriberID;
      details.subscriberType = subscriptionDetailsList.dtls.item(i).subscriberType;
      details.orgFullName = subscriptionDetailsList.dtls.item(i).subscriberName;
      details.subscriptionDateTime = subscriptionDetailsList.dtls.item(i).subscriptionDateTime;

      // populates the org object home page parameters
      populateOrgObjectHomePage(details);

      // populate dynamic page title and confirmation text fields for unsubscribe
      // page
      populatePageTitleAndTexts(details);

      detailsList.orgDtlsList.addRef(details);
    }

    return detailsList;
  }

  // END, CR00215999

  // BEGIN, CR00232351, ZV
  // ___________________________________________________________________________
  /**
   * Reads the Work Queue tab display details for supervisor workspace.
   *
   * @param key Key of work queue to be read
   *
   * @return Work queue tab display details
   *
   * @throws AppException
   * @throws InformationalException
   */
  public WorkQueueTabDetails readWorkQueueTabDetails(final WorkQueueKey key)
    throws AppException, InformationalException {

    WorkQueueTabDetails workQueueTabDetails = new WorkQueueTabDetails();

    WorkQueue workQueueObj = WorkQueueFactory.newInstance();

    ReadWorkQueueDetails readWorkQueueDetails = workQueueObj.readWorkQueueDetails(
      key);

    workQueueTabDetails.assign(readWorkQueueDetails);

    return workQueueTabDetails;
  }
  // END, CR00232351

  // BEGIN, CR00263925 ZV
  /**
   * Comparator used to order work queue reserved task details list by user full name.
   */
  protected class WorkQueueReservedTaskDetailsComparator implements Comparator<WorkQueueCountReservedTasksByUserDetails> {

    /**
     * Default constructor.
     */
    public WorkQueueReservedTaskDetailsComparator() {
      super();
    }

    /**
     * Compare two task details structs.
     */
    public int compare(WorkQueueCountReservedTasksByUserDetails o1, WorkQueueCountReservedTasksByUserDetails o2) {
      // BEGIN, CR00264571 ZV
      return o2.userFullName.compareTo(o1.userFullName);
      // END, CR00264571
    }
  }


  /**
   * Comparator used to order work queue task details list by deadline date.
   */
  protected class WorkQueueTaskDetailsComparator implements Comparator<WorkQueueTasksDueInTheNextTimePeriodDetails> {

    /**
     * Default constructor.
     */
    public WorkQueueTaskDetailsComparator() {
      super();
    }

    /**
     * Compare two task details structs.
     */
    public int compare(WorkQueueTasksDueInTheNextTimePeriodDetails o1, WorkQueueTasksDueInTheNextTimePeriodDetails o2) {
      // BEGIN, CR00264571 ZV
      return o2.deadlineDate.compareTo(o1.deadlineDate);
      // END, CR00264571
    }
  }
  // END, CR00263925

  // BEGIN, CR00427278, MV
  /**
   * Retrieves a list of work queues with a given search criteria.
   *
   * @param workQueueSearchKey
   * work queue search queue
   *
   * @return A list of work queues.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public WorkQueueDetailsList listWorkQueuesByWorkQueueName(
    final WorkQueueSearchKey workQueueSearchKey) throws AppException, InformationalException {

    final WorkQueueDetailsList workQueueDetailsList = new WorkQueueDetailsList();

    workQueueSearchKey.name = workQueueSearchKey.name.toUpperCase().concat(
      CuramConst.gkSqlWildcard);
    final StringBuffer sBuf = new StringBuffer();

    sBuf.append("SELECT workQueueID,    name ");
    sBuf.append(" INTO :workQueueID,    :name ");
    sBuf.append(" FROM WorkQueue WQ WHERE");
    sBuf.append(" WQ.upperName LIKE :name AND ");
    sBuf.append(
      " ((WQ.administratorUserName = :upperAdministratorUserName) OR ");
    sBuf.append(
      "  (WQ.allowUserSubscriptionInd = '1' AND (WQ.sensitivity <= ( ");
    sBuf.append(
      "   SELECT  sensitivity FROM Users WHERE userName = :upperAdministratorUserName))))");

    final CuramValueList<curam.core.sl.entity.struct.WorkQueueDetails> curamValueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
      curam.core.sl.entity.struct.WorkQueueDetails.class, workQueueSearchKey,
      false, sBuf.toString());

    for (int i = 0; i < curamValueList.size(); i++) {
      workQueueDetailsList.dtls.addRef(curamValueList.get(i));
    }
    return workQueueDetailsList;
  }
  // END, CR00427278
}
