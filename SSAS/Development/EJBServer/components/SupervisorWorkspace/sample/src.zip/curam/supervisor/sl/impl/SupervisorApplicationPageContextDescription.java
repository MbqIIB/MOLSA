/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * Copyright (c) 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.supervisor.sl.impl;


import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.SCREENINGNAMECODE;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.OrganisationUnitName;
import curam.core.sl.entity.struct.ScreeningName;
import curam.core.sl.entity.struct.WorkQueueDtls;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.CaseIDKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ICHomePageNameAndType;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.UserFullname;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.supervisor.sl.struct.SupervisorApplicationPageContextDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * Service Layer implementation for Supervisor PageContextDescription
 *
 */

public abstract class SupervisorApplicationPageContextDescription extends
  curam.supervisor.sl.base.SupervisorApplicationPageContextDescription {
  
  /**
   * Identifier for separator
   */
  protected static final String kSeparator = SupervisorConst.kSeparator;

  /**
   * Identifier for space
   */

  protected static final String kSpace = CuramConst.gkSpace;
  
  /**
   * Identifier for blank string
   */
 
  protected static final String kBlankString = CuramConst.gkEmpty;

  // ___________________________________________________________________________
  /**
   * This method builds the supervisor cases' related pages context description
   * @param key - CaseIDKey
   * @return SupervisorApplicationPageContextDetails
   * @throws AppException 
   * @throws InformationalException 
   */
  public SupervisorApplicationPageContextDetails readCasePageContextDescription(
    CaseIDKey key) throws AppException, InformationalException {
    
    // object creation
    SupervisorApplicationPageContextDetails caseContextDescription =
      new SupervisorApplicationPageContextDetails();  
    curam.core.intf.CaseHeader caseHeaderObj =
      curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();    
    curam.core.intf.ConcernRole concernRoleObj = 
      curam.core.fact.ConcernRoleFactory.newInstance();   
    ConcernRoleDtls concernRoleDtls;   
  
    String productTypeDesc = CuramConst.gkEmpty;   
    final int kBufSize = SupervisorConst.kBufSize;
    
    // register the security implementation
    SecurityImplementationFactory.register();
    
    // Set key to read CaseHeader
    caseHeaderKey.caseID = key.caseID;
    
    // Read CaseHeader
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);
    
    // Set key to read ConcernRole
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;
    
    // Read ConcernRole
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    
    if ((caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.PRODUCTDELIVERY))
        || (caseHeaderDtls.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.LIABILITY))) {      
      // ProductDelivery manipulation variables
      curam.core.intf.ProductDelivery productDeliveryObj = 
        curam.core.fact.ProductDeliveryFactory.newInstance();
      ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      ProductDeliveryDtls productDeliveryDtls;
      
      // Set key to read productDelivery
      productDeliveryKey.caseID = key.caseID;
      
      // Read ProductDelivery
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);
      
      productTypeDesc =
        //BEGIN, CR00163098, JC
        CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
        productDeliveryDtls.productType,
        TransactionInfo.getProgramLocale());
        //END, CR00163098, JC
      
    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SCREENINGCASE)) {
      
      // ProductDelivery manipulation variables
      curam.core.sl.entity.intf.Screening screeningObj =
        curam.core.sl.entity.fact.ScreeningFactory.newInstance();
      CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
      ScreeningName screeningName;
      
      // Set key to read Screening
      caseKeyStruct.caseID = key.caseID;
      
      // Read Screening
      screeningName = screeningObj.readName(caseKeyStruct);
      
      productTypeDesc = // BEGIN, HARP 44761, POH
        //BEGIN, CR00163098, JC
        CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME, screeningName.name,
            TransactionInfo.getProgramLocale());
        //END, CR00163098, JC
      
    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.INTEGRATEDCASE)) {
      
      ICHomePageNameAndType icHomePageNameAndType;
      curam.core.struct.CaseKey caseKey = new curam.core.struct.CaseKey();
      
      // Read caseHeader
      caseKey.caseID = key.caseID;
      icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(caseKey);
      
      productTypeDesc =
        //BEGIN, CR00163098, JC
        CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
        icHomePageNameAndType.integratedCaseType,
        TransactionInfo.getProgramLocale());
        //END, CR00163098, JC
    }
    
    // Create and initialize StringBuffer
    StringBuffer contextDescription = new StringBuffer(kBufSize);
    
    // If case type is integrated case there will be no product type in the
    // context description.
    if ((caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.PRODUCTDELIVERY))
        || (caseHeaderDtls.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.LIABILITY))
          || (caseHeaderDtls.caseTypeCode.equals(
            curam.codetable.CASETYPECODE.SCREENINGCASE))
            || (caseHeaderDtls.caseTypeCode.equals(
              curam.codetable.CASETYPECODE.SERVICEPLAN))
              || (caseHeaderDtls.caseTypeCode.equals(
                curam.codetable.CASETYPECODE.INTEGRATEDCASE))) {
      
      contextDescription.append(productTypeDesc).append(kSpace).append(kSeparator).append(kSpace).append(caseHeaderDtls.caseReference).append(kSpace).append(kSeparator).append(kSpace).append(
        concernRoleDtls.concernRoleName);
      
    }
    caseContextDescription.description = contextDescription.toString();
    
    return caseContextDescription;
    
  }  

  // ___________________________________________________________________________
  /**
   * Retrieves the UserFullName for the PageContextDescription from the 
   * UserName.
   * @param key  - UserNameKey.
   * @return SupervisorApplicationPageContextDetails - 
   * (the page context details for the supervisor application.)
   * @throws AppException 
   * @throws InformationalException 
   */
  
  public SupervisorApplicationPageContextDetails readUserNamePageContextDescription(UserNameKey key) 
    throws AppException, InformationalException {
    
    // object creation
    SupervisorApplicationPageContextDetails pageContextDetails = 
      new SupervisorApplicationPageContextDetails();   
    UserAccess userAccessObj = UserAccessFactory.newInstance();    
    UsersKey usersKey = new UsersKey();
    
    // set username to get the user full name
    usersKey.userName = key.userName;
    UserFullname userFullName = userAccessObj.getFullName(usersKey);

    // set user full name to the page context description
    pageContextDetails.description = userFullName.fullname;
    
    return pageContextDetails;
    
  }  

  // ___________________________________________________________________________  
  /**
   * Retrieves the UserFullName for the PageContextDescription from the UserName
   * who logged in.
   * @return SupervisorApplicationPageContextDetails
   * @throws AppException 
   * @throws InformationalException 
   */
  
  public SupervisorApplicationPageContextDetails readLoggedInUserName()
    throws AppException, InformationalException {
   
    // object creation
    SupervisorApplicationPageContextDetails pageContextDetails = 
      new SupervisorApplicationPageContextDetails();    
    UserAccess userAccessObj = UserAccessFactory.newInstance();    
    UsersKey usersKey = new UsersKey();
    SystemUser systemUser = SystemUserFactory.newInstance();
    
    // set username to get the user full name  
    usersKey.userName = systemUser.getUserDetails().userName;
    
    UserFullname userFullName = userAccessObj.getFullName(usersKey);

    // set user full name to the page context description
    pageContextDetails.description = userFullName.fullname;
   
    return pageContextDetails;
    
  }  

  // ___________________________________________________________________________
  /**
   * Method for reading organization unit page context detail
   * @param key - OrganisationUnitKey
   * @return SupervisorApplicationPageContextDetails
   * @throws AppException 
   * @throws InformationalException 
   */
  public SupervisorApplicationPageContextDetails readOrgUnitNamePageContext(
    OrganisationUnitKey key) throws AppException,
      InformationalException {
    
    SupervisorApplicationPageContextDetails pageContextDetails =
      new SupervisorApplicationPageContextDetails();    
    // Create organisationUnit object to read organization unit name
    OrganisationUnit organisationUnitObj =
      OrganisationUnitFactory.newInstance();    
    OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();
    
    organisationUnitKey.organisationUnitID = key.organisationUnitID;    
    OrganisationUnitName organisationUnitName =
      organisationUnitObj.readOrgUnitName(organisationUnitKey);    

    pageContextDetails.description = organisationUnitName.name.toString();
    
    return pageContextDetails;
  }
  
  // ____________________________________________________________________________
  /**
   * Read work queue Page Context
   * @param key - WorkQueueKey
   * @return SupervisorApplicationPageContextDetails
   * @throws AppException
   * @throws InformationalException 
   */
  public SupervisorApplicationPageContextDetails readWorkQueuePageContextDescription(WorkQueueKey key) 
    throws AppException, InformationalException {
    
    SupervisorApplicationPageContextDetails pageContextDetails = 
      new SupervisorApplicationPageContextDetails();    
    WorkQueue workQueueObj = WorkQueueFactory.newInstance();
    
    WorkQueueDtls workQueueDtls = workQueueObj.read(key);

    pageContextDetails.description = workQueueDtls.name;
    
    return pageContextDetails;
  }
  
}
