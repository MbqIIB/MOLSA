/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.verification.sl.infrastructure.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.VERIFICATIONWAIVER;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.verification.sl.infrastructure.entity.struct.CancelVerificationWaiverDetails;
import curam.verification.sl.infrastructure.entity.struct.ModifyVerificationWaiverDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationIDAndDateKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverKey;


/**
 * */
public class VerificationWaiver extends curam.verification.sl.infrastructure.entity.base.VerificationWaiver {

  /**
   * */
  @Override
  protected void preinsert(VerificationWaiverDtls details) throws AppException,
      InformationalException {
    details.recordStatus = RECORDSTATUS.NORMAL;
    validateDate(details.startDate, details.endDate);
  }

  protected void validateDate(Date startDate, Date endDate)
    throws AppException, InformationalException {

    if (startDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(VERIFICATIONWAIVER.ERR_STARTDATE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    if (!endDate.isZero() && startDate.after(endDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(VERIFICATIONWAIVER.ERR_ENDDATE_BEFORE_STARTDATE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  @Override
  protected void premodify(VerificationWaiverKey key,
    VerificationWaiverDtls details) throws AppException,
      InformationalException {

    validateModify(key);
    validateDate(details.startDate, details.endDate);
  }

  @Override
  protected void premodifyPeriod(VerificationWaiverKey key,
    ModifyVerificationWaiverDetails details) throws AppException,
      InformationalException {

    validateModify(key);
    validateDate(details.startDate, details.endDate);
  }

  protected void validateModify(VerificationWaiverKey key)
    throws AppException, InformationalException {

    VerificationWaiverDtls verificationWaiverDtls = this.read(key);

    if (verificationWaiverDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(VERIFICATIONWAIVER.ERR_CANCELLED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  @Override
  protected void precancel(VerificationWaiverKey key,
    CancelVerificationWaiverDetails details) throws AppException,
      InformationalException {

    details.recordStatus = RECORDSTATUS.CANCELLED;
    validateModify(key);
  }

  // BEGIN, CR00414265, AKr
  @Override
  protected void presearchCurrentActiveByVerificationID(
    VerificationIDAndDateKey key) throws AppException,
      InformationalException {

    key.currentDate = Date.getCurrentDate();

  }
  // END, CR00414265

}
