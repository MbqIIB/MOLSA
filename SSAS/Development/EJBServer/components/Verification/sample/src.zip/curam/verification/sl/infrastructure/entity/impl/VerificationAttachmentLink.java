/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.verification.sl.infrastructure.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.ReadStatusCodeDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.verification.sl.infrastructure.entity.struct.CancelVerificationAttachmentLinkDtls;
import curam.verification.sl.infrastructure.entity.struct.EvidenceDescriptorDetails;
import curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentLinkDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationAttachmentLinkKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationItemProvidedKey;


/**
 * This process class provides the functionality for the Verification Attachment Link
 * entity layer.
 */
public abstract class VerificationAttachmentLink extends curam.verification.sl.infrastructure.entity.base.VerificationAttachmentLink {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the logical delete
   *
   * @param key - VerificationAttachmentLinkKey
   * @param cancelVerificationAttachmentLinkDtls - CancelVerificationAttachmentLinkDtls
   */
  protected void precancel(VerificationAttachmentLinkKey key, 
    CancelVerificationAttachmentLinkDtls cancelVerificationAttachmentLinkDtls) 
    throws AppException, InformationalException {
    
    curam.verification.sl.infrastructure.entity.intf.VerificationAttachmentLink verificationAttachmentLink = curam.verification.sl.infrastructure.entity.fact.VerificationAttachmentLinkFactory.newInstance();
    VerificationItemProvidedKey verificationItemProvidedKey = new VerificationItemProvidedKey();

    verificationItemProvidedKey.verificationItemProvidedID = verificationAttachmentLink.readProvidedIDByAttachmentID(key).verificationItemProvidedID;
    validateAttachmentLink(verificationItemProvidedKey);
    validateCancel(cancelVerificationAttachmentLinkDtls);
    cancelVerificationAttachmentLinkDtls.recordStatus = RECORDSTATUS.CANCELLED;

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details - VerificationAttachmentLinkDtls
   */
  protected void preinsert(VerificationAttachmentLinkDtls details) 
    throws AppException, InformationalException {
    
    VerificationItemProvidedKey verificationItemProvidedKey = new VerificationItemProvidedKey();

    verificationItemProvidedKey.verificationItemProvidedID = details.verificationItemProvidedID;
    
    validateAttachmentLink(verificationItemProvidedKey);
    
    validateInsert(details);

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key - VerificationAttachmentLinkKey
   * @param details - VerificationAttachmentLinkDtls
   */
  protected void premodify(VerificationAttachmentLinkKey key, VerificationAttachmentLinkDtls details) 
    throws AppException, InformationalException { 
    
    curam.verification.sl.infrastructure.entity.intf.VerificationAttachmentLink verificationAttachmentLink = curam.verification.sl.infrastructure.entity.fact.VerificationAttachmentLinkFactory.newInstance();
    
    VerificationItemProvidedKey verificationItemProvidedKey = new VerificationItemProvidedKey();

    verificationItemProvidedKey.verificationItemProvidedID = verificationAttachmentLink.readProvidedIDByAttachmentID(key).verificationItemProvidedID;
    
    validateAttachmentLink(verificationItemProvidedKey);
    
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.ENTVERIFICATIONATTACHMENT.ERR_MODIFYATTACHMENT_CANCELLED_OR_SUPERSEDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Item Provided details before the logical delete
   *
   * @param cancelVerificationAttachmentLinkDtls
   */
  public void validateCancel(CancelVerificationAttachmentLinkDtls cancelVerificationAttachmentLinkDtls) 
    throws AppException, InformationalException {
    
    if (cancelVerificationAttachmentLinkDtls.recordStatus.equals(
      RECORDSTATUS.CANCELLED)) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.ENTVERIFICATIONATTACHMENT.ERR_DELETEATTACHMENT_CANCELLED_OR_SUPERSEDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  public void validateDetails(VerificationAttachmentLinkDtls dtls) 
    throws AppException, InformationalException {//
  }

  public void validateInsert(VerificationAttachmentLinkDtls dtls) 
    throws AppException, InformationalException {//
  }

  public void validateModify(VerificationAttachmentLinkDtls arg0) 
    throws AppException, InformationalException {//
  }

  // ___________________________________________________________________________
  /**
   * Validates if the evidence is in use. Cannot add attachment if evidence is 
   * not in use.
   *
   * @param key - VerificationItemProvidedKey
   */
  public void validateAttachmentLink(VerificationItemProvidedKey key) 
    throws AppException, InformationalException {

    curam.verification.sl.infrastructure.entity.intf.VerificationAttachmentLink verificationAttachmentLink = curam.verification.sl.infrastructure.entity.fact.VerificationAttachmentLinkFactory.newInstance();
    
    EvidenceDescriptorDetails evidenceDescriptorDetails = new  EvidenceDescriptorDetails();
    EvidenceDescriptor evidenceDescriptor = EvidenceDescriptorFactory.newInstance();
    
    EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();
    ReadStatusCodeDetails readStatusCodeDetails = new ReadStatusCodeDetails();

    evidenceDescriptorDetails = verificationAttachmentLink.readEvidenceDescriptorIDByProvidedID(
      key);
    
    evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDetails.evidenceDescriptorID;
    readStatusCodeDetails = evidenceDescriptor.readStatusCode(
      evidenceDescriptorKey);
    
    if ((readStatusCodeDetails.statusCode.equals(
      curam.codetable.EVIDENCEDESCRIPTORSTATUS.CANCELED))
        || (readStatusCodeDetails.statusCode.equals(
          curam.codetable.EVIDENCEDESCRIPTORSTATUS.SUPERSEDED))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.ENTVERIFICATIONATTACHMENT.ERR_CASEATTACHMENT_XRV_DESCRIPTORSTATUS_CANCELLED_OR_SUPERSEDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

}
