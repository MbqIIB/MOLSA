/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.evidence.impl;


import com.google.inject.AbstractModule;
import com.google.inject.multibindings.MapBinder;

import curam.codetable.impl.EVIDENCENATUREEntry;
import curam.verification.bom.impl.VerificationAdminModule;
import curam.verification.sl.infrastructure.impl.EvidenceVerificationWaiver;


/**
 * A custom guice module which derives from AbstractModule, configures the map
 * binders which are basically hash map look up for the objects based on the key
 * i.e evidence nature type.
 */
public class VerificationEvidenceModule extends AbstractModule {

  /**
   * {@inheritDoc}
   */
  @Override
  public void configure() {

    // BEGIN, CR00260487, KR
    // Load the verification BOM implementation module class.
    install(new VerificationAdminModule());
    // END, CR00260487, KR

    // Request the static injection to inject the static map of
    // VerificationEvidenceInterface in VerificationEvidenceFactory class.
    requestStaticInjection(VerificationEvidenceFactory.class);

    // Create map for VerificationEvidenceInterface implementations to evidence
    // nature types.
    final MapBinder<EVIDENCENATUREEntry, VerificationEvidenceInterface> verificationEvidenceMapbinder = MapBinder.newMapBinder(
      binder(), EVIDENCENATUREEntry.class, VerificationEvidenceInterface.class);

    verificationEvidenceMapbinder.addBinding(EVIDENCENATUREEntry.STATIC).to(
      VerificationStaticEvidenceImpl.class);

    // BEGIN, CR00260117, FM
    registerEvidenceVerificationWaiverImplementations();
    // END, CR00260117
  }

  // BEGIN, CR00260117, FM
  /**
   * Register all implementations for the interface Evidence Verification Waiver
   * All implementations for the interface Evidence Verification Waiver should
   * be bound using Guice MapBinder class. The key to bind the implementation
   * should be of the format
   * <Case Type Code>.<Case Sub Type Code>.<Evidence Type Code>
   * where
   * - Case Type Code is code from Code Table "CaseTypeCode"
   * - Case Sub Type Code depends on type of case and the codes are from Code Tables like
   * - "ProductCategory" - Integrated Case Type, when Case Type is Integrated Case,
   * - "ProductType" - Product Type when Case Type is Product Delivery Case,
   * - "InvestigateConfigType" - Investigation Configuration Type when Case Type is Investigation Case,
   * - "ScreeningNameCode" - Screening Name Code when Case Type is Screening Case
   * - Evidence Type Code is the code from Code Table "CaseEvidenceTypeCode"
   * - these codes should be separated by period i.e., "."
   * or
   * <Concern Role Type>.<Evidence Type Code>
   * where
   * - Concern Role Type is code from Code Table "ConcernRoleType"
   * - Evidence Type Code is the code from Code Table "CaseEvidenceTypeCode"
   * - these codes should be separated by period i.e., "."
   */
  protected void registerEvidenceVerificationWaiverImplementations() {

    MapBinder<String, EvidenceVerificationWaiver> mapbinder = MapBinder.newMapBinder(
      binder(), String.class, EvidenceVerificationWaiver.class);
    // No default implementations
  }
  // END, CR00260117
}
