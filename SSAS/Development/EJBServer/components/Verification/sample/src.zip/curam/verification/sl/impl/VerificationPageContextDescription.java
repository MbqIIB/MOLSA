/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.impl;


import curam.codetable.VERIFIABLEITEMNAME;
import curam.codetable.VERIFICATIONCATEGORYNAME;
import curam.codetable.VERIFICATIONDEPENDENTITEMNAME;
import curam.codetable.VERIFICATIONITEMNAME;
import curam.codetable.VERIFICATIONREQUIREMENTNAME;
import curam.codetable.VERIFICATIONREQUUSAGENAME;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.transaction.TransactionInfo;
import curam.verification.sl.entity.fact.DependentDataItemFactory;
import curam.verification.sl.entity.fact.VerificationItemFactory;
import curam.verification.sl.entity.intf.DependentDataItem;
import curam.verification.sl.entity.struct.DependentDataItemKey;
import curam.verification.sl.entity.struct.VerifiableDataItemKey;
import curam.verification.sl.entity.struct.VerificationCategoryKey;
import curam.verification.sl.entity.struct.VerificationItemKey;
import curam.verification.sl.entity.struct.VerificationRequirementKey;
import curam.verification.sl.entity.struct.VerificationRequirementUsageKey;
import curam.verification.sl.struct.VerificationPageContextDetails;


/**
 * The VerificationPageContextDescription class provides a number of methods 
 * to Reads page title context description for Verification Admin Entities.
 */

public abstract class VerificationPageContextDescription extends
  curam.verification.sl.base.VerificationPageContextDescription {

  // ___________________________________________________________________________
  /**
   * Reads page title context description for Verification Item entity
   *
   * @param key identifies the Verification Item
   *
   * @return Page title context description for Verification Item
   */
  public VerificationPageContextDetails readVerificationItemPageContextDescription(
    VerificationItemKey key) throws AppException, InformationalException {

    curam.verification.sl.entity.intf.VerificationItem verificationItem =
      VerificationItemFactory.newInstance();

    // code table variables
    curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    verificationPageContextDetails.description =
      verificationItem.readNameByID(key).name;

    ctitemKey.code = verificationItem.readNameByID(key).name;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFICATIONITEMNAME.TABLENAME;
    //BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    //END, CR00163098, JC

    verificationPageContextDetails.description = ctitem.description;

    return verificationPageContextDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads page title context description for Verification Category entity
   *
   * @param key identifies the Verification Category
   *
   * @return Page title context description for Verification Category
   */
  public VerificationPageContextDetails readVerificationCategoryPageContextDescription(
    VerificationCategoryKey key) throws AppException,
      InformationalException {

    curam.verification.sl.entity.intf.VerificationCategory verificationCategory =
      curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();

    // code table variables
    curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    ctitemKey.code = verificationCategory.readNameByID(key).name;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFICATIONCATEGORYNAME.TABLENAME;
    //BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    //END, CR00163098, JC

    verificationPageContextDetails.description = ctitem.description;

    return verificationPageContextDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads page title context description for Verifiable Data Item entity
   *
   * @param key identifies the Verifiable Data Item
   *
   * @return Page title context description for Verifiable Data Item
   */
  public VerificationPageContextDetails readVerifiableDataItemPageContextDescription(
    VerifiableDataItemKey key) throws AppException, InformationalException {

    curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItem =
      curam.verification.sl.entity.fact.VerifiableDataItemFactory.newInstance();

    // code table variables
    curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    ctitemKey.code = verifiableDataItem.readNameByID(key).name;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFIABLEITEMNAME.TABLENAME;
    //BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    //END, CR00163098, JC
    verificationPageContextDetails.description = ctitem.description;

    return verificationPageContextDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads page title context description for Verification Requirement entity
   *
   * @param key identifies the Verification Requirement
   *
   * @return Page title context description for Verification Requirement
   */
  public VerificationPageContextDetails readVerificationRequirementPageContextDescription(
    VerificationRequirementKey key) throws AppException,
      InformationalException {

    curam.verification.sl.entity.intf.VerificationRequirement verificationRequirement =
      curam.verification.sl.entity.fact.VerificationRequirementFactory.newInstance();

    // code table variables
    curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    ctitemKey.code = verificationRequirement.readNameByID(key).name;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFICATIONREQUIREMENTNAME.TABLENAME;
    //BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    //END, CR00163098, JC
    verificationPageContextDetails.description = ctitem.description;

    return verificationPageContextDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads page title context description for Verification Requirement Usage
   * entity
   * @param key identifies the Verification Requirement Usage
   *
   * @return Page title context description for Verification Requirement Usage
   */
  public VerificationPageContextDetails readVerificationRequirementUsagePageContextDescription(
    VerificationRequirementUsageKey key) throws AppException,
      InformationalException {

    curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage =
      curam.verification.sl.entity.fact.VerificationRequirementUsageFactory.newInstance();

    // code table variables
    curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    CTItemKey ctitemKey = new CTItemKey();
    CTItem cTItem = new CTItem();

    VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    verificationPageContextDetails.description =
      verificationRequirementUsage.readNameByID(key).name;
    
    ctitemKey.code = verificationRequirementUsage.readNameByID(key).name;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFICATIONREQUUSAGENAME.TABLENAME;
    //BEGIN, CR00163098, JC
    cTItem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    //END, CR00163098, JC
    verificationPageContextDetails.description = cTItem.description;
    
    return verificationPageContextDetails;
    
  }

  // ___________________________________________________________________________
  /**
   * Reads page title context description for Dependant Data Item
   * entity
   * @param key identifies the Dependant Data Item
   *
   * @return Page title context description for Dependant Data Item
   */
  public VerificationPageContextDetails readDependantDataItemPageContextDescription(DependentDataItemKey key) throws AppException, InformationalException {

    DependentDataItem dependantDataItem =
      DependentDataItemFactory.newInstance();
     
    // code table variables
    curam.util.internal.codetable.intf.CodeTable codeTableInterface =
      CodeTableFactory.newInstance();
    CTItemKey ctitemKey = new CTItemKey();
    CTItem cTItem = new CTItem();

    VerificationPageContextDetails verificationPageContextDetails =
      new VerificationPageContextDetails();

    verificationPageContextDetails.description =
      dependantDataItem.readNameByID(key).name;
     
    ctitemKey.code = dependantDataItem.readNameByID(key).name;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = VERIFICATIONDEPENDENTITEMNAME.TABLENAME;
    //BEGIN, CR00163098, JC
    cTItem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    //END, CR00163098, JC
    verificationPageContextDetails.description = cTItem.description;

    return verificationPageContextDetails;
     
  }

}
