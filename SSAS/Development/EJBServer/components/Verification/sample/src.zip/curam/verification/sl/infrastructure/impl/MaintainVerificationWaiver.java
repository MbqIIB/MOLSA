/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
package curam.verification.sl.infrastructure.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.UsersKey;
import curam.message.VERIFICATIONWAIVER;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.verification.sl.infrastructure.entity.fact.VerificationWaiverFactory;
import curam.verification.sl.infrastructure.entity.intf.VerificationWaiver;
import curam.verification.sl.infrastructure.entity.struct.ModifyVerificationWaiverDetails;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationIDAndDateKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverDtlsList;
import curam.verification.sl.infrastructure.entity.struct.VerificationWaiverKey;
import curam.verification.sl.infrastructure.struct.CancelVerificationWaiverDetails;
import curam.verification.sl.infrastructure.struct.EvidenceVerificationDetails;
import curam.verification.sl.infrastructure.struct.ValidateOverlapVerificationWaiverDetails;
import curam.verification.sl.infrastructure.struct.VerificationWaiverDetails;
import curam.verification.sl.infrastructure.struct.VerificationWaiverDetailsList;


public class MaintainVerificationWaiver extends curam.verification.sl.infrastructure.base.MaintainVerificationWaiver {

  /**
   * Creates a waiver for a Verification
   *
   * @param details contains the waiver details
   * @return result returns the generated ID for the waiver record created
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public VerificationWaiverKey create(VerificationWaiverDtls details)
    throws AppException, InformationalException {

    VerificationWaiverKey result = new VerificationWaiverKey();
    VerificationWaiver verificationWaiverObj = VerificationWaiverFactory.newInstance();

    verificationWaiverObj.insert(details);
    result.verificationWaiverID = details.verificationWaiverID;

    return result;
  }

  /**
   * Creates a waiver for a Verification if no other waiver exists for that
   * verification for the period provided
   *
   * @param details contains the waiver details
   * @return result returns the generated ID for the waiver record created
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public VerificationWaiverKey createWithNoOverlapping(
    VerificationWaiverDtls details)
    throws AppException, InformationalException {

    ValidateOverlapVerificationWaiverDetails verificationWaiverDetails = new ValidateOverlapVerificationWaiverDetails();

    verificationWaiverDetails.startDate = details.startDate;
    verificationWaiverDetails.endDate = details.endDate;
    verificationWaiverDetails.verificationID = details.verificationID;
    verificationWaiverDetails.verificationWaiverID = details.verificationWaiverID;

    validateForOverlappingWaivers(verificationWaiverDetails);

    return create(details);
  }

  /**
   * Returns a list of waiver records for a verification
   *
   * @param details contains verification ID
   * @return result returns a list of waiver records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public VerificationWaiverDtlsList listByVerificationID(VerificationKey key)
    throws AppException, InformationalException {

    VerificationWaiverDtlsList result = new VerificationWaiverDtlsList();
    VerificationWaiver verificationWaiverObj = VerificationWaiverFactory.newInstance();

    result.assign(verificationWaiverObj.searchByVerificationID(key));

    return result;
  }

  /**
   * Returns a list of active waiver records for a verification
   *
   * @param details contains verification ID
   * @return result returns a list of waiver records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public VerificationWaiverDtlsList listActiveByVerificationID(
    VerificationKey key) throws AppException, InformationalException {

    VerificationWaiverDtlsList result = new VerificationWaiverDtlsList();
    VerificationWaiver verificationWaiverObj = VerificationWaiverFactory.newInstance();

    result.assign(verificationWaiverObj.searchActiveByVerificationID(key));

    return result;
  }

  /**
   * Cancels the waiver record.
   *
   * @param details contains waiver ID and version number
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void cancel(CancelVerificationWaiverDetails details)
    throws AppException, InformationalException {

    VerificationWaiver verificationWaiverObj = VerificationWaiverFactory.newInstance();
    VerificationWaiverKey verificationWaiverKey = new VerificationWaiverKey();

    verificationWaiverKey.verificationWaiverID = details.verificationWaiverID;
    curam.verification.sl.infrastructure.entity.struct.CancelVerificationWaiverDetails cancelVerificationWaiverDetails = new curam.verification.sl.infrastructure.entity.struct.CancelVerificationWaiverDetails();

    cancelVerificationWaiverDetails.verificationWaiverID = details.verificationWaiverID;
    cancelVerificationWaiverDetails.versionNo = details.versionNo;

    verificationWaiverObj.cancel(verificationWaiverKey,
      cancelVerificationWaiverDetails);

  }

  /**
   * Modifies the period of waiver and allows to add a comment
   *
   * @param details contain start & end dates and comment with waiver ID
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyPeriod(ModifyVerificationWaiverDetails details)
    throws AppException, InformationalException {

    VerificationWaiver verificationWaiverObj = VerificationWaiverFactory.newInstance();
    VerificationWaiverKey verificationWaiverKey = new VerificationWaiverKey();

    verificationWaiverKey.verificationWaiverID = details.verificationWaiverID;

    verificationWaiverObj.modifyPeriod(verificationWaiverKey, details);

  }

  /**
   * Modifies the period of waiver and allows to add a comment if no other
   * waiver exists for the period for that verification
   *
   * @param details contain start & end dates and comment with waiver ID
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyPeriodWithNoOverlapping(
    ModifyVerificationWaiverDetails details) throws AppException,
      InformationalException {

    ValidateOverlapVerificationWaiverDetails verificationWaiverDetails = new ValidateOverlapVerificationWaiverDetails();

    verificationWaiverDetails.startDate = details.startDate;
    verificationWaiverDetails.endDate = details.endDate;
    verificationWaiverDetails.verificationWaiverID = details.verificationWaiverID;

    validateForOverlappingWaivers(verificationWaiverDetails);

    modifyPeriod(details);
  }

  /**
   * Reads the waiver record to be displayed.
   *
   * @param key contains waiver ID
   * @return result contain the waiver details like period, status, comments etc
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public VerificationWaiverDtls view(VerificationWaiverKey key)
    throws AppException, InformationalException {

    VerificationWaiver verificationWaiverObj = VerificationWaiverFactory.newInstance();

    return verificationWaiverObj.read(key);
  }

  /**
   * Checks if there are overlapping waivers for the Verification
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateForOverlappingWaivers(
    ValidateOverlapVerificationWaiverDetails details) throws AppException,
      InformationalException {

    if (details.verificationID == 0 && details.verificationWaiverID != 0) {
      VerificationWaiver verificationWaiverObj = VerificationWaiverFactory.newInstance();
      VerificationWaiverKey verificationWaiverKey = new VerificationWaiverKey();

      verificationWaiverKey.verificationWaiverID = details.verificationWaiverID;
      details.verificationID = verificationWaiverObj.read(verificationWaiverKey).verificationWaiverID;
    }
    VerificationKey verificationKey = new VerificationKey();

    verificationKey.verificationID = details.verificationID;
    VerificationWaiver verificationWaiverObj = VerificationWaiverFactory.newInstance();
    VerificationWaiverDtlsList verificationWaiverDtlsList;

    verificationWaiverDtlsList = verificationWaiverObj.searchActiveByVerificationID(
      verificationKey);
    // verificationWaiverObj.searchActiveForPeriodByVerificationID(periodVerificationIDKey);
    boolean overlappingWaiverExists = false;

    for (VerificationWaiverDtls verificationWaiverDtls : verificationWaiverDtlsList.dtls) {

      if (verificationWaiverDtls.verificationWaiverID
        != details.verificationWaiverID) {
        // overlappingWaiverExists = true;
        overlappingWaiverExists = isOverlapping(
          verificationWaiverDtls.startDate, verificationWaiverDtls.endDate, 
          details.startDate, details.endDate);
        break;
      }
    }
    if (overlappingWaiverExists) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(VERIFICATIONWAIVER.ERR_WAIVER_OVERLAPPING),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }
  
  /**
   * Checks if the Date Range overlaps
   * @param startDate
   * @param endDate
   * @param newStartDate
   * @param newEndDate
   * @return
   * @throws AppException
   * @throws InformationalException
   */
  protected boolean isOverlapping(Date startDate,
    Date endDate, Date newStartDate, Date newEndDate) throws AppException,
      InformationalException {
    
    boolean overlap = false;

    if (newEndDate.isZero()) {
      if (endDate.isZero()) {
        overlap = true;
      } else {
        if (endDate.equals(newStartDate) || endDate.after(newStartDate)) {
          overlap = true;
        }
      }
    } else { // new end date is not zero date
      if (endDate.isZero()) {
        if (startDate.before(newEndDate) || startDate.equals(newEndDate)) {
          overlap = true;
        }
      } else {
        if ((endDate.equals(newStartDate) || endDate.after(newStartDate)) 
          && (endDate.before(newEndDate) || endDate.equals(newEndDate))) {
          overlap = true;
        }
      }
    }
    return overlap;
  }

  /**
   * Returns a list of Waivers for an Evidence Verification
   *
   * @param key evidence and verification details
   * @return returns a list of waivers
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public VerificationWaiverDetailsList listEvidenceVerificationWaiver(
    EvidenceVerificationDetails key) throws AppException,
      InformationalException {

    // Get the Waiver Details
    VerificationWaiverDetailsList result = new VerificationWaiverDetailsList();
    VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();

    vdiedLinkKey.VDIEDLinkID = key.vdIEDLinkID;
    VerificationWaiver verificationWaiverObj = VerificationWaiverFactory.newInstance();

    VerificationWaiverDtlsList verificationWaiverDtlsList = verificationWaiverObj.searchByVerifiableDataItemEvidenceDescriptorLink(
      vdiedLinkKey);

    VerificationWaiverDetails verificationWaiverDetails;

    // Users key
    UsersKey usersKey = new UsersKey();
    UserAccess userAccessObj = UserAccessFactory.newInstance();

    for (VerificationWaiverDtls verificationWaiverDtls : verificationWaiverDtlsList.dtls) {
      verificationWaiverDetails = new VerificationWaiverDetails();
      verificationWaiverDetails.assign(verificationWaiverDtls);
      verificationWaiverDetails.modifiableInd = verificationWaiverDtls.recordStatus.equals(
        RECORDSTATUS.NORMAL);

      // set user name key
      usersKey.userName = verificationWaiverDtls.lastUpdatedBy;
      // get full user name
      verificationWaiverDetails.lastModifiedByUserFullName = userAccessObj.getFullName(usersKey).fullname;

      result.dtls.add(verificationWaiverDetails);
    }
    return result;
  }
  
  // BEGIN, CR00414265, AKr
  /**
   * Returns a list of active waiver records for a verification that are valid on the current date.
   *
   * @param details contains verification ID
   * @return result returns a list of waiver records
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public VerificationWaiverDtlsList listCurrentActiveByVerificationID(VerificationKey key)
    throws AppException, InformationalException {

    VerificationWaiverDtlsList result = new VerificationWaiverDtlsList();
    VerificationWaiver verificationWaiverObj = VerificationWaiverFactory.newInstance();
    VerificationIDAndDateKey verificationIDAndDateKey = new VerificationIDAndDateKey();

    verificationIDAndDateKey.verificationID = key.verificationID;
    result.assign(
      verificationWaiverObj.searchCurrentActiveByVerificationID(
        verificationIDAndDateKey));

    return result;
  }
  // END, CR00414265
}
