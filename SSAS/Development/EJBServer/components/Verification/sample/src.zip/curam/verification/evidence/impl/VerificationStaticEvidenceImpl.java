/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.verification.evidence.impl;


import java.lang.reflect.Field;

import curam.core.sl.infrastructure.impl.EIEvidenceModifyDtls;
import curam.core.sl.infrastructure.impl.EIEvidenceReadDtls;
import curam.util.type.Blob;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.Money;
import curam.verification.sl.infrastructure.impl.VerificationConst;


/**
 * Implementation of {@link VerificationEvidenceInterface} for static evidence.
 * It assumes that only static evidence are present in the system. This
 * implementation is made part of the Verification Engine to ensure that the
 * system operates normally without the Dynamic Evidence component.
 * <p>
 * When Dynamic Evidence component is installed, it will provide its own
 * implementation of {@link VerificationEvidenceInterface} to guarantee that the
 * Verification Engine will work with both static and dynamic evidence.
 *
 */
public class VerificationStaticEvidenceImpl implements
  VerificationEvidenceInterface {

  /**
   * default constructor for guice.
   */
  public VerificationStaticEvidenceImpl() {// Default constructor for guice
  }

  // ___________________________________________________________________________
  /**
   * Check if the field is empty.
   *
   * @param dataItem
   * as String
   * @param evidenceObject
   * as Object
   * @param evidenceType
   * as String
   * @return true if the field is empty
   * @see curam.verification.evidence.impl.VerificationEvidenceInterface
   * #isFieldEmpty(java.lang.String, java.lang.Object)
   */
  public boolean isFieldEmpty(String dataItem, Object evidenceObject,
    String evidenceType) {

    try {
      final Field fl = evidenceObject.getClass().getDeclaredField(dataItem);

      // BEGIN, CR00069996, SK
      if (fl.getType().getName().equals(VerificationConst.kTypeMoney)) {
        // BEGIN, CR00069996, SK
        final Money money = (Money) fl.get(evidenceObject);

        return isFieldEmpty(money);
      }
      // BEGIN, CR00077795, AL
      if (fl.getType().getName().equals(VerificationConst.kTypeDate)) {
        // BEGIN, CR00077795, AL
        final Date date = (Date) fl.get(evidenceObject);

        return isFieldEmpty(date);
      }
      // BEGIN, CR00077795, AL
      if (fl.getType().getName().equals(VerificationConst.kTypeString)) {
        // BEGIN, CR00077795, AL
        final String string = (String) fl.get(evidenceObject);

        return isFieldEmpty(string);
      }
      
      // BEGIN, CR00343732, VKR
      if (fl.getType().getName().equals(VerificationConst.kTypeDateTime)) {
      
        final DateTime dateTimeData = (DateTime) fl.get(evidenceObject);

        return isFieldEmpty(dateTimeData);
      }
      
      if (fl.getType().getName().equals(VerificationConst.kTypeShort)) {
      
        final short shortData = (Short) fl.get(evidenceObject);

        return isFieldEmpty(shortData);
      }
      
      if (fl.getType().getName().equals(VerificationConst.kTypeInt)) {
     
        final int intData = (Integer) fl.get(evidenceObject);

        return isFieldEmpty(intData);
      }
      
      if (fl.getType().getName().equals(VerificationConst.kTypeLong)) {
     
        final long longData = (Long) fl.get(evidenceObject);

        return isFieldEmpty(longData);
      }      
      
      if (fl.getType().getName().equals(VerificationConst.kTypeDouble)) {
    
        final double doubleData = (Double) fl.get(evidenceObject);

        return isFieldEmpty(doubleData);
      }

      if (fl.getType().getName().equals(VerificationConst.kTypeBoolean)) {
    
        final boolean booleanData = (Boolean) fl.get(evidenceObject);

        return isFieldEmpty(booleanData);
      }
      
      if (fl.getType().getName().equals(VerificationConst.kTypeBlob)) {
     
        final Blob blobData = (Blob) fl.get(evidenceObject);

        return isFieldEmpty(blobData);
      }      
      // END, CR00343732

    } catch (NoSuchFieldException e) { // Do Nothing
      return true;
    } catch (IllegalAccessException e) {// Do Nothing
    }

    return false;
  }

  // BEGIN, CR00021355, NK
  // ___________________________________________________________________________
  /**
   * Method to compare fields.
   *
   * @param dataItem
   * as String
   * @param modifiedEvidences
   * as Object
   * @param previousEvidence
   * as Object
   * @param evidenceType
   * as String
   * @return true if the fields compared are different
   * @see curam.verification.evidence.impl.VerificationEvidenceInterface
   * #compareFields(java.lang.String, java.lang.Object, java.lang.Object)
   */
  public boolean compareFields(String dataItem, Object modifiedEvidences,
    Object previousEvidence, String evidenceType) {

    try {
      
      final Field fl = modifiedEvidences.getClass().getDeclaredField(dataItem);

      // BEGIN, CR00069996, SK
      if (fl.getType().getName().equals(VerificationConst.kTypeMoney)) {
        // END, CR00069996
        final Money money1 = (Money) fl.get(modifiedEvidences);
        final Money money2 = (Money) fl.get(previousEvidence);

        return compareField(money1, money2);
      }
      // BEGIN, CR00069996, SK
      if (fl.getType().getName().equals(VerificationConst.kTypeDate)) {
        // END, CR00069996
        final Date date1 = (Date) fl.get(modifiedEvidences);
        final Date date2 = (Date) fl.get(previousEvidence);

        return compareField(date1, date2);
      }
      // BEGIN, CR00069996, SK
      if (fl.getType().getName().equals(VerificationConst.kTypeString)) {
        // END, CR00069996
        final String string1 = (String) fl.get(modifiedEvidences);
        final String string2 = (String) fl.get(previousEvidence);

        return compareField(string1, string2);
      }
      
      // BEGIN, CR00343732, VKR
      if (fl.getType().getName().equals(VerificationConst.kTypeDateTime)) {
        final DateTime dateTime1 = (DateTime) fl.get(modifiedEvidences);
        final DateTime dateTime2 = (DateTime) fl.get(previousEvidence);
     
        return compareField(dateTime1, dateTime2);
      }
      
      if (fl.getType().getName().equals(VerificationConst.kTypeShort)) {
        final short shortData1 = (Short) fl.get(modifiedEvidences);
        final short shortData2 = (Short) fl.get(previousEvidence);
     
        return compareField(shortData1, shortData2);
      }
      
      if (fl.getType().getName().equals(VerificationConst.kTypeInt)) {
        final int intData1 = (Integer) fl.get(modifiedEvidences);
        final int intData2 = (Integer) fl.get(previousEvidence);
     
        return compareField(intData1, intData2);
      }
      
      if (fl.getType().getName().equals(VerificationConst.kTypeLong)) {
        final long longData1 = (Long) fl.get(modifiedEvidences);
        final long longData2 = (Long) fl.get(previousEvidence);
    
        return compareField(longData1, longData2);
      }
      
      if (fl.getType().getName().equals(VerificationConst.kTypeDouble)) {
        final double doubleData1 = (Double) fl.get(modifiedEvidences);
        final double doubleData2 = (Double) fl.get(previousEvidence);
    
        return compareField(doubleData1, doubleData2);
      }
      
      if (fl.getType().getName().equals(VerificationConst.kTypeBoolean)) {
        final boolean booleanData1 = (Boolean) fl.get(modifiedEvidences);
        final boolean booleanData2 = (Boolean) fl.get(previousEvidence);
     
        return compareField(booleanData1, booleanData2);
      }
      
      if (fl.getType().getName().equals(VerificationConst.kTypeBlob)) {
        final Blob blobData1 = (Blob) fl.get(modifiedEvidences);
        final Blob blobData2 = (Blob) fl.get(previousEvidence);
    
        return compareField(blobData1, blobData2);
      }
      // END, CR00343732

    } catch (NoSuchFieldException e) {// Do Nothing
    } catch (IllegalAccessException e) {// Do Nothing
    } 

    return false;
  }

  // END, CR00021355



  /**
   * Check if the data item value has changed.
   *
   * @param dataItem
   * as String
   * @param eiEvidenceModifyDtls
   * contains evidence modify details
   * @param eiEvidenceReadDtls
   * contains evidence read details
   * @param evidenceType
   * as String
   * @return true if the data item value has been changed
   * @see curam.verification.evidence.impl.VerificationEvidenceInterface
   * #checkDataItemValueChanged(java.lang.String,
   * curam.core.sl.infrastructure.impl.EIEvidenceModifyDtls,
   * curam.core.sl.infrastructure.impl.EIEvidenceReadDtls)
   */
  public boolean checkDataItemValueChanged(String dataItem,
    EIEvidenceModifyDtls eiEvidenceModifyDtls,
    EIEvidenceReadDtls eiEvidenceReadDtls, String evidenceType) {

    try {

      final Field fl = eiEvidenceModifyDtls.evidenceObject.getClass().getDeclaredField(
        dataItem);

      final Object modified = fl.get(eiEvidenceModifyDtls.evidenceObject);

      final Object previous = fl.get(eiEvidenceReadDtls.evidenceObject);

      if (modified != null) {

        return !(modified.equals(previous));
      } else {

        return !(previous == null);
      }

    } catch (IllegalAccessException e) {// Do Nothing
    } catch (NoSuchFieldException e) {// Do Nothing
    }

    return false;
  }

  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field of type money for empty.
   *
   * @param money
   * field of type money
   * @return true if the field is empty
   */
  protected boolean isFieldEmpty(Money money) {
    if (money.getValue() == 0) {
      return true;
    }

    return false;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00108051,GM
  /**
   * The isFieldEmpty method checks the field of type date for empty.
   *
   * @param date
   * field of type date
   * @return true if the field is empty
   */
  protected boolean isFieldEmpty(Date date) {
    if (date.isZero()) {
      return true;
    }

    return false;
  }

  // END CR00108051

  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field of type string for empty.
   *
   * @param string
   * field of type string
   * @return true if the field is empty
   */
  protected boolean isFieldEmpty(String string) {
    if (string.trim().length() == 0) {
      return true;
    }

    return false;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00343732, VKR
  /**
   * The isFieldEmpty method checks the field of type DateTime for empty.
   *
   * @param dateTimeData
   * field of type DateTime
   * @return true if the field is empty
   */
  protected boolean isFieldEmpty(DateTime dateTimeData) {
    if (dateTimeData.isZero()) {
      return true;
    }
    
    return false;
  }

  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field of type short for empty.
   *
   * @param shortData
   * field of type short
   * @return true if the field is empty
   */
  protected boolean isFieldEmpty(short shortData) {
    if (shortData == 0) {
      return true;
    }
    
    return false;
  }

  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field of type int for empty.
   *
   * @param intData
   * field of type int
   * @return true if the field is empty
   */
  protected boolean isFieldEmpty(int intData) {
    if (intData == 0) {
      return true;
    }

    return false;
  }
 
  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field of type long for empty.
   *
   * @param longData
   * field of type long
   * @return true if the field is empty
   */  
  protected boolean isFieldEmpty(long longData) {
    if (longData == 0) {
      return true;
    }

    return false;
  }
  
  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field of type double for empty.
   *
   * @param doubleData
   * field of type double
   * @return true if the field is empty
   */
  protected boolean isFieldEmpty(double doubleData) {
    if (doubleData == 0) {
      return true;
    }

    return false;
  }

  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field of type boolean is set to default.
   *
   * @param booleanData
   * field of type boolean
   * @return true if the field is set to default
   */
  protected boolean isFieldEmpty(boolean booleanData) {
    if (!booleanData) {
      return true;
    }

    return false;
  }
  
  // ___________________________________________________________________________
  /**
   * The isFieldEmpty method checks the field of type Blob for empty.
   *
   * @param blobData
   * field of type Blob
   * @return true if the field is empty
   */
  protected boolean isFieldEmpty(Blob blobData) {
    if (blobData.length() == 0) {
      return true;
    }

    return false;
  }

  // END, CR00343732  
  
  // ___________________________________________________________________________
  /**
   * The compare field method compares the two dates for equals.
   *
   * @param date1
   * date to compare with other date field
   * @param date2
   * date to compare with other date field
   * @return true if the fields compared are different
   */
  protected boolean compareField(Date date1, Date date2) {
    // BEGIN, CR00282100, AKr
    if (date1.compareTo(date2) != 0) {
      // END, CR00282100
      return true;
    }

    return false;
  }

  // BEGIN, CR00021355, NK
  // ___________________________________________________________________________
  /**
   * The compare field method compares the two money fields for equals.
   *
   * @param money1
   * money to compare with other money field
   * @param money2
   * money to compare with other money field
   * @return true if the money fields compared are different
   */
  protected boolean compareField(Money money1, Money money2) {
    if (money1.getValue() != money2.getValue()) {
      return true;
    }

    return false;
  }

  // END, CR00021355

  // BEGIN, CR00021355, NK
  // ___________________________________________________________________________
  /**
   * The compare field method compares the two strings for equals.
   *
   * @param string1
   * string to compare with other string field
   * @param string2
   * string to compare with other string field
   * @return true if the string fields compared are different
   */
  protected boolean compareField(String string1, String string2) {
    if (!string1.trim().equalsIgnoreCase(string2.trim())) {
      return true;
    }

    return false;
  }

  // END, CR00021355
  
  // ___________________________________________________________________________
  // BEGIN, CR00343732, VKR
  /**
   * The compare field method compares the two DateTime for equals.
   *
   * @param dateTime1
   * DateTime to compare with other DateTime field
   * @param dateTime2
   * DateTime to compare with other DateTime field
   * @return true if the fields compared are different
   */
  protected boolean compareField(DateTime dateTime1, DateTime dateTime2) {
    if (dateTime1.compareTo(dateTime2) != 0) {
      return true;
    }
  
    return false;
  }
  
  // ___________________________________________________________________________
  /**
   * The compare field method compares the two short for equals.
   *
   * @param shortData1
   * short value to compare with other short value field
   * @param shortData2
   * short value to compare with other short value field
   * @return true if the fields compared are different
   */
  protected boolean compareField(short shortData1, short shortData2) {
    if (shortData1 != shortData2) {
      return true;
    }
  
    return false;
  }
  
  // ___________________________________________________________________________
  /**
   * The compare field method compares the two int for equals.
   *
   * @param intData1
   * int value to compare with other int value field
   * @param intData2
   * int value to compare with other int value field
   * @return true if the fields compared are different
   */
  protected boolean compareField(int intData1, int intData2) {
    if (intData1 != intData2) {
      return true;
    }

    return false;
  }
  
  // ___________________________________________________________________________
  /**
   * The compare field method compares the two long for equals.
   *
   * @param longData1
   * long value to compare with other long value field
   * @param longData2
   * long value to compare with other long value field
   * @return true if the fields compared are different
   */
  protected boolean compareField(long longData1, long longData2) {
    if (longData1 != longData2) {
      return true;
    }

    return false;
  }
  
  // ___________________________________________________________________________
  /**
   * The compare field method compares the two double for equals.
   *
   * @param doubleData1
   * double value to compare with other double value field
   * @param doubleData2
   * double value to compare with other double value field
   * @return true if the fields compared are different
   */
  protected boolean compareField(double doubleData1, double doubleData2) {
    if (doubleData1 != doubleData2) {
      return true;
    }

    return false;
  }

  // ___________________________________________________________________________
  /**
   * The compare field method compares the two boolean for equals.
   *
   * @param booleanData1
   * boolean value to compare with other boolean value field
   * @param booleanData2
   * boolean value to compare with other boolean value field
   * @return true if the fields compared are different
   */
  protected boolean compareField(boolean booleanData1, boolean booleanData2) {
    if (booleanData1 != booleanData2) {
      return true;
    }

    return false;
  }

  // ___________________________________________________________________________
  /**
   * The compare field method compares the two Blob for equals.
   *
   * @param blobData1
   * Blob to compare with other Blob field
   * @param blobData2
   * Blob to compare with other Blob field
   * @return true if the fields compared are different
   */
  protected boolean compareField(Blob blobData1, Blob blobData2) {
    if (!blobData1.equals(blobData2)) {
      return true;
    }

    return false;
  }
  // END, CR00343732
  
}
