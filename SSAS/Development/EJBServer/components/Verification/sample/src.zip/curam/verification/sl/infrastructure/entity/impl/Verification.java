/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2006, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.infrastructure.entity.impl;


import java.util.Map;

import com.google.inject.Inject;

import curam.codetable.CASETYPECODE;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.VERIFICATIONSTATUS;
import curam.codetable.VERIFICATIONTYPE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.sl.impl.CaseTypeEvidence;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.ReadRelatedIDParticipantIDAndEvidenceTypeDetails;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.message.ENTVERIFICATION;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.verification.sl.entity.fact.VerificationRequirementFactory;
import curam.verification.sl.entity.struct.VerificationRequirementDtls;
import curam.verification.sl.entity.struct.VerificationRequirementKey;
import curam.verification.sl.infrastructure.entity.fact.VDIEDLinkFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationFactory;
import curam.verification.sl.infrastructure.entity.intf.VDIEDLink;
import curam.verification.sl.infrastructure.entity.struct.EvidenceDescriptorDetails;
import curam.verification.sl.infrastructure.entity.struct.EvidenceDescriptorIDAndVerStatusKey;
import curam.verification.sl.infrastructure.entity.struct.ReadByVerIDAndVerLinkedTypeKey;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkIDMandatoryKey;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationRequirementModifyDueDateDtls;
import curam.verification.sl.infrastructure.fact.VerificationControllerFactory;
import curam.verification.sl.infrastructure.impl.EvidenceVerificationWaiver;
import curam.verification.sl.infrastructure.intf.VerificationController;


/**
 * This process class provides the functionality for the Verification
 * entity layer.
 */
public abstract class Verification extends curam.verification.sl.infrastructure.entity.base.Verification {

  // BEGIN, CR00260117, FM
  /**
   * A hash map reference of the case evidence type module which is registered
   * in the registry.
   */
  @Inject
  private Map<String, CaseTypeEvidence> caseTypeEvidenceMap;

  /**
   * Reference to Evidence Verification Waiver.
   */
  @Inject
  private Map<String, EvidenceVerificationWaiver> evidenceVerificationWaiverMap;

  /**
   * Constructor to inject members.
   */
  public Verification() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Override
  protected void postinsert(VerificationDtls details) throws AppException,
      InformationalException {

    // Check if mandatory requirement
    VerificationRequirementKey requirementKey = new VerificationRequirementKey();

    requirementKey.verificationRequirementID = details.verificationRequirementID;

    // Read the verification details
    VerificationRequirementDtls requirementDtls = VerificationRequirementFactory.newInstance().read(
      requirementKey);

    // Process only if mandatory
    if (requirementDtls.mandatory) {
      // Get the Evidence Type
      VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();

      vdiedLinkKey.VDIEDLinkID = details.VDIEDLinkID;
      EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = VDIEDLinkFactory.newInstance().read(vdiedLinkKey).evidenceDescriptorID;
      EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();
      ReadRelatedIDParticipantIDAndEvidenceTypeDetails relatedIDParticipantIDAndEvidenceTypeDetails = EvidenceDescriptorFactory.newInstance().readRelatedIDParticipantIDAndEvidenceType(
        evidenceDescriptorKey);

      eiEvidenceKey.evidenceID = relatedIDParticipantIDAndEvidenceTypeDetails.relatedID;
      eiEvidenceKey.evidenceType = relatedIDParticipantIDAndEvidenceTypeDetails.evidenceType;
      String mapKey = CuramConst.gkEmpty;

      if (details.verificationLinkedType.equals(VERIFICATIONTYPE.NONCASEDATA)) {
        // Get the Concern Role Type
        ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        concernRoleKey.concernRoleID = details.verificationLinkedID;
        ConcernRoleTypeDetails concernRoleTypeDetails = ConcernRoleFactory.newInstance().readConcernRoleType(
          concernRoleKey);

        mapKey = concernRoleTypeDetails.concernRoleType + CuramConst.gkDotChar
          + eiEvidenceKey.evidenceType;
      } else {
        // Get the Case Type & SubType
        CaseKey caseKey = new CaseKey();

        caseKey.caseID = details.verificationLinkedID;
        CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance().readCaseTypeCode(
          caseKey);

        mapKey = caseTypeCode.caseTypeCode + CuramConst.gkDotChar
          + getCaseSubTypeCode(caseKey, caseTypeCode) + CuramConst.gkDotChar
          + eiEvidenceKey.evidenceType;
      }
      EvidenceVerificationWaiver evidenceVerificationWaiver = evidenceVerificationWaiverMap.get(
        mapKey);

      if (evidenceVerificationWaiver != null) {
        evidenceVerificationWaiver.process(details, eiEvidenceKey);
      }

    }
  }

  /**
   * Function to determine the case type code based on the ID of the case.
   *
   * @param key
   * caseKey containing the case id.
   *
   * @return boolean indicating true if we are using the centralized table and
   * false if we are not.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected String getCaseSubTypeCode(final CaseKey key, CaseTypeCode caseTypeCode) throws AppException,
      InformationalException {

    CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
      caseTypeCode.caseTypeCode);

    if (null == caseTypeEvidence) {
      AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, caseTypeCode.caseTypeCode,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 9);
    }
    return caseTypeEvidence.getCaseTypeCode(key);
  }

  // END, CR00260117

  /**
   * This method sets mandatory to true for the key
   *
   * @param key contains VDIEDLinkID and mandatory condition
   */
  protected void presearchMandatoryVerificationRequirementsAndVerificationStatus
    (VDIEDLinkIDMandatoryKey key) throws AppException, InformationalException {

    key.mandatory = true;
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key Verification Identifier
   * @param dtls VerificationRequirementDueDate details
   */
  protected void premodifyDueDate(VerificationKey key,
    VerificationRequirementModifyDueDateDtls dtls)
    throws AppException, InformationalException {

    validateModify(dtls, key);
    validateDetails(dtls);
  }

  // ___________________________________________________________________________
  /**
   * Performs the validations common to all operations
   *
   * @param details verification details
   */
  public void validateDetails(VerificationRequirementModifyDueDateDtls details)
    throws AppException, InformationalException {//
  }

  // ___________________________________________________________________________
  /**
   * Validates the due date details before the data modification
   *
   * @param details verification requirement modify due date details
   * @param key verification key
   */
  public void validateModify(VerificationRequirementModifyDueDateDtls details,
    VerificationKey key) throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // BEGIN, CR00021575, NK
    curam.verification.sl.infrastructure.entity.intf.Verification verification = VerificationFactory.newInstance();

    VDIEDLinkKey vDIEDlinkKey = new VDIEDLinkKey();
    VDIEDLink vDIEDlinkObj = VDIEDLinkFactory.newInstance();

    EvidenceDescriptorDtls evidenceDescriptorDtls = new EvidenceDescriptorDtls();
    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    EvidenceDescriptorDetails evidenceDescriptorDetails = new EvidenceDescriptorDetails();
    EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    // Get the VDIEDLinkKey
    vDIEDlinkKey = verification.readVDIEDLinkByVerificationID(key);
    // Get the EvidenceDescriptor Details
    evidenceDescriptorDetails = vDIEDlinkObj.readEvidenceDescriptorIDByVDIEDLink(
      vDIEDlinkKey);
    evidenceDescriptorKey.evidenceDescriptorID = evidenceDescriptorDetails.evidenceDescriptorID;
    evidenceDescriptorDtls = evidenceDescriptorObj.read(evidenceDescriptorKey);
    if (evidenceDescriptorDtls.statusCode.equals(
      EVIDENCEDESCRIPTORSTATUS.CANCELED)) {

      AppException appException = new AppException(
        ENTVERIFICATION.ERR_EVIDENCE_ASSOCIATED_XRV_VERIFICATION_MUST_NOT_BE_CANCELLED_OR_SUPERSEDED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00021575

    // The Due Date must be later than the current date
    if (details.dueDate.before(curam.util.type.Date.getCurrentDate()) // BEGIN, CR00021550, NK
      || details.dueDate.equals(curam.util.type.Date.getCurrentDate())) {
      // END, CR00021550

      AppException appException = new AppException(
        curam.message.ENTVERIFICATION.ERR_DUEDATE_FV_BEFORE_CURRENT_DATE);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

  protected void prereadCaseID(ReadByVerIDAndVerLinkedTypeKey key) throws AppException, InformationalException {

    // BEGIN, CR00075395, BF
    // BEGIN, CR00074026, BF
    // We want to always set the verificationLnkedType to NonCaseData here
    // Reading the caseID on a verification record and the code is checking for a verification where
    // verificationLnkedType is not equal to NONCASEDATA i.e. case
    key.verificationLinkedType = VERIFICATIONTYPE.NONCASEDATA;
    // END, CR00074026
    // END, CR00075395
  }
  
  // BEGIN, CR00417399, AKr
  /**
   * sets the value of the verification Status to NOTVERIFIED, as the purpose of 
   * the operation is to read the outstanding verifications.
   *
   * @param evidenceDescriptorIDAndVerStatusKey Details of the evidence descriptorID and the verification status.
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationException Generic Exception Signature.
   */
  protected void presearchOutstandingVerificationsByEvidenceDescriptorID(final EvidenceDescriptorIDAndVerStatusKey evidenceDescriptorIDAndVerStatusKey)
    throws curam.util.exception.AppException, curam.util.exception.InformationalException {

    evidenceDescriptorIDAndVerStatusKey.verificationStatus = VERIFICATIONSTATUS.NOTVERIFIED;
  }
  // END, CR00417399

}
