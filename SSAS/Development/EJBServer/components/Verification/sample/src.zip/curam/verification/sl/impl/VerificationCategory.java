/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.verification.sl.entity.struct.VerificationCategoryKey;
import curam.verification.sl.struct.CancelVerificationCategoryDetails;
import curam.verification.sl.struct.CreateVerificationCategoryDetails;
import curam.verification.sl.struct.ListVerificationCategoryDetailsList;
import curam.verification.sl.struct.ModifyVerificationCategoryDetails;
import curam.verification.sl.struct.ReadVerificationCategoryDetails;


/**
 * This process class provides the functionality for the Verification Category
 * service layer.
 */
public abstract class VerificationCategory extends curam.verification.sl.base.VerificationCategory {

  // ___________________________________________________________________________
  /**
   * Cancels a Verification Category record
   *
   * @param cancelDetails Verification Category details
   */
  public void cancelVerificationCategory(CancelVerificationCategoryDetails cancelDetails) 
    throws AppException, InformationalException {
    
    // create objects and structures at entity level
    curam.verification.sl.entity.intf.VerificationCategory verificationCategoryObj =
      curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();
    
    // Create and populate the Verification Category key
    VerificationCategoryKey verificationCategoryKey =
      new VerificationCategoryKey();

    verificationCategoryKey.verificationCategoryID =
      cancelDetails.cancelDtls.verificationCategoryID;

    // Cancel a Verification Category record
    verificationCategoryObj.cancel(verificationCategoryKey,
      cancelDetails.cancelDtls);
  }

  // ___________________________________________________________________________
  /**
   * Creates a Verification Category record
   *
   * @param details Verification Category details
   */
  public VerificationCategoryKey createVerificationCategory(CreateVerificationCategoryDetails details) throws AppException, InformationalException {

    // create objects and structures at entity level
    curam.verification.sl.entity.intf.VerificationCategory verificationCategoryObj =
      curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();

    details.createDtls.dateCreated = Date.getCurrentDate();
    
    details.createDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    // Create a Verification Category  record
    verificationCategoryObj.insert(details.createDtls);

    // Create and populate the return struct
    VerificationCategoryKey verificationCategoryKey =
      new VerificationCategoryKey();

    verificationCategoryKey.verificationCategoryID =
      details.createDtls.verificationCategoryID;

    return verificationCategoryKey;
  }

  // ___________________________________________________________________________
  /**
   * Lists a Verification Category Details
   *
   * @return List Verification Category List details
   */

  public ListVerificationCategoryDetailsList listVerificationCategory() throws AppException, InformationalException {

    // create objects and structures at entity level
    curam.verification.sl.entity.intf.VerificationCategory verificationCategoryObj =
      curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();

    // create return structure
    ListVerificationCategoryDetailsList listVerificationCategoryDetailsList =
      new ListVerificationCategoryDetailsList();

    // get list Verification Category Details
    listVerificationCategoryDetailsList.listDtls =
      verificationCategoryObj.searchVerificationCategoryListDetails();

    return listVerificationCategoryDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies a Verification Category record
   *
   * @param modifyDetails Verification Category details
   */
  public void modifyVerificationCategory(ModifyVerificationCategoryDetails modifyDetails) 
    throws AppException, InformationalException {

    // create object at entity level
    curam.verification.sl.entity.intf.VerificationCategory verificationCategoryObj =
      curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();
    // Create and populate the Verification Category key
    VerificationCategoryKey verificationCategoryKey =
      new VerificationCategoryKey();

    verificationCategoryKey.verificationCategoryID =
      modifyDetails.modifyDtls.verificationCategoryID;
    // Create a Verification category record
    verificationCategoryObj.modify(verificationCategoryKey,
      modifyDetails.modifyDtls);
  }

  // ___________________________________________________________________________
  /**
   * Reads a Verification Category record
   *
   * @param key Verification Category Details
   * @return details Verification Category Details
   */

  public ReadVerificationCategoryDetails readVerificationCategory(VerificationCategoryKey key) throws AppException, InformationalException {

    // create objects and structures at entity level
    curam.verification.sl.entity.intf.VerificationCategory verificationCategoryObj =
      curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();

    // create return structure
    ReadVerificationCategoryDetails readVerificationCategoryDetails =
      new ReadVerificationCategoryDetails();

    // Read the Verification Category Record
    readVerificationCategoryDetails.readDtls =
      verificationCategoryObj.read(key);

    return readVerificationCategoryDetails;

  }

}
