/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.util.persistence.ReaderDAO;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * Read only date access interface for the
 * {@link curam.serviceplans.sl.entity.intf.Goal} entity.
 */
// BEGIN, CR00309529, POH
@AccessLevel(AccessLevelType.EXTERNAL)
@ImplementedBy(GoalDAOImpl.class)
public interface GoalDAO extends ReaderDAO<Long, Goal> {
  // END, CR00309529

  /**
   * Retrieves an immutable list of active goals linked to a service plan.
   *
   * @param servicePlan
   * The service plan to use in the search.
   * @return An immutable list of active goals, or an empty list if none are
   * found.
   */
  List<Goal> listActiveByServicePlan(ServicePlan servicePlan);

}
