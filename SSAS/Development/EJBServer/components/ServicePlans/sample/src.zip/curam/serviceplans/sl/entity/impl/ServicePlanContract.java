/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.codetable.CASESTATUS;
import curam.codetable.SERVICEPLANCONTRACTSTATUS;
import curam.core.sl.struct.RecordCount;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.events.SERVICEPLANS;
import curam.serviceplans.sl.entity.struct.CheckMultipleContractDetails;
import curam.serviceplans.sl.entity.struct.ReadMultipleContractsAllowedByCaseIDKey;
import curam.serviceplans.sl.entity.struct.ServicePlanContractDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanContractKey;
import curam.serviceplans.sl.entity.struct.ServicePlanContractStatusCode;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryAndContractStatusKey;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryIssuedAndAcceptStatus;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * A contract represents a formal agreement between the organization and the
 * plan participant, or a nominated representative, to undertake the planItems listed
 * on the service plan. A Service Plan is used to describe a plan by which a client
 * will change his. The plan will contain goals which the client will strive to
 * achieve, each goal consists of a number of sub goals and the sub goal
 * contain planItems that the client must perform in order to complete their
 * sub goal.
 *
 * For example, a service plan might exist to get the client back to work.
 * The goal is to return to work, one sub goal is to improve his interviewing
 * skills.  An appropriate plan item might be to buy a suit.
 */
public abstract class ServicePlanContract extends curam.serviceplans.sl.entity.base.ServicePlanContract {

  // ___________________________________________________________________________
  /**
   * Ensures that multiple contracts are allowed on inserted/modification
   *
   * @param checkMultipleContractsDetails Contains service plan status and case id.
   */
  public void checkForMultipleContracts(
    CheckMultipleContractDetails checkMultipleContractsDetails)
    throws AppException, InformationalException {

    // Service Plan Manipulation Variables
    curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();
    ReadMultipleContractsAllowedByCaseIDKey readMultipleContractsAllowedByCaseIDKey = new ReadMultipleContractsAllowedByCaseIDKey();
    ServicePlanDeliveryAndContractStatusKey servicePlanDeliveryAndContractStatusKey = new ServicePlanDeliveryAndContractStatusKey();

    // Read the MultipleContractsAllowed indicator for the service plan
    readMultipleContractsAllowedByCaseIDKey.caseID = checkMultipleContractsDetails.caseID;

    boolean multipleContractsInd = servicePlanObj.readMultipleContractsAllowedInd(readMultipleContractsAllowedByCaseIDKey).multipleContractsAllowedInd;

    if (multipleContractsInd) {
      if (checkMultipleContractsDetails.contractStatus.equals(
        SERVICEPLANCONTRACTSTATUS.ISSUED)) {
        servicePlanDeliveryAndContractStatusKey.caseID = checkMultipleContractsDetails.caseID;
        servicePlanDeliveryAndContractStatusKey.contractStatus = SERVICEPLANCONTRACTSTATUS.ISSUED;

        RecordCount countIssued = countIssuedContractsByCaseID(
          servicePlanDeliveryAndContractStatusKey);

        if (countIssued.count > 0) {
          if (checkMultipleContractsDetails.insertingContractInd) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              new AppException(
                curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_RV_INSERT_CONTRACT_ISSUED_ALREADY_EXIST_NOT_RETURNED),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                0);
          }
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_RV_MODIFY_CONTRACT_ISSUED_ALREADY_EXIST_NOT_RETURNED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }
    } else if ((checkMultipleContractsDetails.contractStatus.equals(
      SERVICEPLANCONTRACTSTATUS.ISSUED))
        || (checkMultipleContractsDetails.contractStatus.equals(
          curam.codetable.SERVICEPLANCONTRACTSTATUS.ACCEPTED))) // end if multiple indicator set?
    {
      ServicePlanDeliveryIssuedAndAcceptStatus servicePlanDeliveryIssuedAndAcceptStatus = new ServicePlanDeliveryIssuedAndAcceptStatus();

      servicePlanDeliveryIssuedAndAcceptStatus.caseID = checkMultipleContractsDetails.caseID;
      servicePlanDeliveryIssuedAndAcceptStatus.contractStatusAccepted = SERVICEPLANCONTRACTSTATUS.ACCEPTED;
      servicePlanDeliveryIssuedAndAcceptStatus.contractStatusIssued = SERVICEPLANCONTRACTSTATUS.ISSUED;

      RecordCount countIssuedAndAccepted = countIssuAndAccContractsByCaseID(
        servicePlanDeliveryIssuedAndAcceptStatus);

      if (countIssuedAndAccepted.count > 0) {
        if (checkMultipleContractsDetails.insertingContractInd) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_RV_INSERT_CONTRACT_MULTI_CONRACT_NOT_ALLOWED),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
        }
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_RV_MODIFY_CONTRACT_MULTI_CONRACT_NOT_ALLOWED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

  }

  // _________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details Details to be inserted.
   */
  protected void preinsert(ServicePlanContractDtls details)
    throws AppException, InformationalException {

    // Set status and creation date
    details.status = curam.codetable.SERVICEPLANCONTRACTSTATUS.ISSUED;
    details.creationDate = curam.util.type.Date.getCurrentDate();

    // Validate details
    validateInsert(details);

  }

  // _____________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key Unique Identifier of the service plan contract
   * @param details Details to be modified
   */
  protected void premodify(
    ServicePlanContractKey key,
    ServicePlanContractDtls details)
    throws AppException, InformationalException {

    validateModify(details);

    // Has date accepted been modified then set status
    // to accepted
    if (!details.dateAccepted.equals(curam.util.type.Date.kZeroDate)) {
      details.status = SERVICEPLANCONTRACTSTATUS.ACCEPTED;

      // Service plans workflow raise event integration
      curam.util.events.struct.Event event = new curam.util.events.struct.Event();
      
      // BEGIN, CR00021588, TV
      // BEGIN,HARP 65061,SRK 
      event.eventKey = SERVICEPLANS.ACCEPTCONTRACT;
      // END, HARP 65061 
      // END, CR00021588 
      

      event.primaryEventData = key.servicePlanContractID;
      curam.util.events.impl.EventService.raiseEvent(event);

    } // Has date rejected been modified then set status
    // to rejected
    else if (!details.dateRejected.equals(curam.util.type.Date.kZeroDate)) {
      details.status = curam.codetable.SERVICEPLANCONTRACTSTATUS.REJECTED;

      // Service plans workflow raise event integration
      curam.util.events.struct.Event event = new curam.util.events.struct.Event();
      
      // BEGIN, CR00021588, TV
      // BEGIN,HARP 65061,SRK 
      event.eventKey = SERVICEPLANS.REJECTCONTRACT;
      // END, HARP 65061 
      // END, CR00021588 

      event.primaryEventData = key.servicePlanContractID;
      curam.util.events.impl.EventService.raiseEvent(event);

    } // Has date cancelled been modified then set status
    // to cancelled
    else if (!details.dateCanceled.equals(curam.util.type.Date.kZeroDate)) {
      details.status = curam.codetable.SERVICEPLANCONTRACTSTATUS.CANCELLED;

      // Service plans workflow raise event integration
      curam.util.events.struct.Event event = new curam.util.events.struct.Event();
      
      // BEGIN, CR00021588, TV
      // BEGIN,HARP 65061,SRK 
      event.eventKey = SERVICEPLANS.CANCELCONTRACT;
      // END, HARP 65061 
      // END, CR00021588 

      event.primaryEventData = key.servicePlanContractID;
      curam.util.events.impl.EventService.raiseEvent(event);

    } // If none of above 3 set then set status to issued
    else {

      // Have to check if acceptance, cancel or reject dates have been removed.
      // If any of these have these been removed on modify then the status of contract
      // will be set to issued. So we have to check and ensure there is not already
      // a contract with a status of issued.
      ServicePlanContractDtls servicePlanContractDtls = read(key);

      // Check what has been modified
      if ((!servicePlanContractDtls.dateAccepted.isZero()
        && details.dateAccepted.isZero())
          || (!servicePlanContractDtls.dateRejected.isZero()
            && details.dateRejected.isZero())
            || (!servicePlanContractDtls.dateCanceled.isZero()
              && details.dateCanceled.isZero())) {
        ServicePlanDeliveryAndContractStatusKey servicePlanDeliveryAndContractStatusKey = new ServicePlanDeliveryAndContractStatusKey();

        servicePlanDeliveryAndContractStatusKey.caseID = details.caseID;
        servicePlanDeliveryAndContractStatusKey.contractStatus = curam.codetable.SERVICEPLANCONTRACTSTATUS.ISSUED;
        RecordCount recordCount;

        recordCount = countIssuedContractsByCaseID(
          servicePlanDeliveryAndContractStatusKey);
        if (recordCount.count > 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV__MODIFY_ISSUED_CONRTACT_ALREADY_EXISTS),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }

        details.status = curam.codetable.SERVICEPLANCONTRACTSTATUS.ISSUED;
        // Service plans workflow raise event integration
        curam.util.events.struct.Event event = new curam.util.events.struct.Event();
        
        // BEGIN, CR00021588, TV
        // BEGIN,HARP 65061,SRK 
        event.eventKey = SERVICEPLANS.ISSUECONTRACT;
        // END, HARP 65061 
        // END, CR00021588 

        event.primaryEventData = key.servicePlanContractID;
        curam.util.events.impl.EventService.raiseEvent(event);

      }
    }
  }

  // _____________________________________________________________________
  /**
   * Validates the dates to be modified
   *
   * @param details Contains the dates to be modified.
   */
  public void validateDates(ServicePlanContractDtls details)
    throws AppException, InformationalException {

    // Ensure only one of date accepted, date rejected and date cancelled
    // have been entered
    if (((!details.dateCanceled.equals(curam.util.type.Date.kZeroDate))
      && (!details.dateAccepted.equals(curam.util.type.Date.kZeroDate)))
        || ((!details.dateCanceled.equals(curam.util.type.Date.kZeroDate))
          && (!details.dateRejected.equals(curam.util.type.Date.kZeroDate)))
          || ((!details.dateRejected.equals(curam.util.type.Date.kZeroDate))
            && (!details.dateAccepted.equals(curam.util.type.Date.kZeroDate)))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_DUPLICATE_DATES_ENTERED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Ensure issue date not before contract creation date
    if (details.dateIssued.before(details.creationDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_ISSUEDATE_ENTERED_BEFORE_CONTRACT_CREATION_DATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Ensure that when for each date (i.e. either accepted, rejected or cancelled)
    // entered that:
    // 1. issue date is entered
    // 2. date entered not before issue date
    // 3. date entered
    // have to do individually as different error depending on date set by user


    // Validate details when date cancelled is entered
    if (!details.dateCanceled.equals(curam.util.type.Date.kZeroDate)) {
      // issue date has to be specified
      if (details.dateIssued.equals(curam.util.type.Date.kZeroDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_CANCELDATE_ENTERED_ISSUE_DATE_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      if (details.dateCanceled.before(details.dateIssued)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_XFV_CANCELDATE_EARLIER_THAN_ISSUEDATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      if (details.dateCanceled.after(curam.util.type.Date.getCurrentDate())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_XFV_CANCELDATE_AFTER_TODAYS_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      if (details.cancelReason.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_DATE_ENTERED_CANCEL_REASON_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // Validate details when date rejected is entered
    if (!details.dateRejected.equals(curam.util.type.Date.kZeroDate)) {
      // issue date has to be specified
      if (details.dateIssued.equals(curam.util.type.Date.kZeroDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_REJECTDATE_ENTERED_ISSUE_DATE_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      if (details.dateRejected.before(details.dateIssued)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_XFV_REJECTDATE_EARLIER_THAN_ISSUEDATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      if (details.dateRejected.after(curam.util.type.Date.getCurrentDate())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_XFV_REJECEDDATE_AFTER_TODAYS_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      if (details.rejectReason.length() == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_DATE_ENTERED_REJECT_REASON_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // Validate details when date accepted is entered
    if (!details.dateAccepted.equals(curam.util.type.Date.kZeroDate)) {
      // issue date has to be specified
      if (details.dateIssued.equals(curam.util.type.Date.kZeroDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_ACCEPTDATE_ENTERED_ISSUE_DATE_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      if (details.dateAccepted.before(details.dateIssued)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_XFV_ACCEPTDATE_EARLIER_THAN_ISSUEDATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      if (details.dateAccepted.after(curam.util.type.Date.getCurrentDate())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_XFV_ACCEPTDATE_AFTER_TODAYS_DATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      if ((details.rejectReason.length() != 0)
        || (details.cancelReason.length() != 0)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_XFV_DATEACCEPTED_ENTERED_CANCEL_REJECTED_INFO_ALSO_ENTERED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // Ensure that if cancel comments or cancel reason is entered,
    // that cancel date is entered
    if ((details.cancelReason.length() != 0)
      || (details.cancelComments.length() != 0)) {
      if (details.dateCanceled.equals(curam.util.type.Date.kZeroDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_COMMENTSORREASON_ENTERED_CANCEL_DATE_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // Ensure that if reject comments or reject reason is entered,
    // that reject date is entered
    if ((details.rejectReason.length() != 0)
      || (details.rejectionComments.length() != 0)) {
      if (details.dateRejected.equals(curam.util.type.Date.kZeroDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_COMMENTSORREASON_ENTERED_REJECT_DATE_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

  }

  // _____________________________________________________________________
  /**
   * Validates the details to be inserted.
   *
   * @param servicePlanContractDtls Contains the dates to be inserted.
   */
  public void validateInsert(ServicePlanContractDtls servicePlanContractDtls)
    throws AppException, InformationalException {

    if (servicePlanContractDtls.issuedToParticipantRole == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_CLIENT_NAME_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Then must not be earlier than today
    if (!servicePlanContractDtls.dateIssued.equals(
      curam.util.type.Date.kZeroDate)) {

      if (servicePlanContractDtls.dateIssued.before(
        curam.util.type.Date.getCurrentDate())) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_XFV_ISSUEDATE_TODAY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    validateDetails(servicePlanContractDtls);

  }

  // _____________________________________________________________________
  /**
   * Validates the details to be modified.
   *
   * @param servicePlanContractDtls Contains the dates to be inserted.
   */
  public void validateModify(ServicePlanContractDtls servicePlanContractDtls)
    throws AppException, InformationalException {

    validateDates(servicePlanContractDtls);
    validateDetails(servicePlanContractDtls);

    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    ServicePlanContractKey servicePlanContractKey = new ServicePlanContractKey();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // read case header and ensure not set to closed
    // Ensure service plan is not closed
    caseHeaderKey.caseID = servicePlanContractDtls.caseID;
    CaseStatusCode caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // If closed than return error.

    if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_MODIFY_CONTRACT_RV_SERPLAN_MUST_NOT_BE_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // If status has been modified to issued or accepted - check multiple contracts
    // of this type are allowed
    // Read contract status and first check to see has it been modified
    ServicePlanContractStatusCode contractStatusCode;

    servicePlanContractKey.servicePlanContractID = servicePlanContractDtls.servicePlanContractID;
    contractStatusCode = readContractStatus(servicePlanContractKey);

    // if been modified to issued or accepted
    if (!(contractStatusCode.status.equals(servicePlanContractDtls.status))) {

      if (servicePlanContractDtls.status.equals(
        curam.codetable.SERVICEPLANCONTRACTSTATUS.ISSUED)
          || servicePlanContractDtls.status.equals(
            curam.codetable.SERVICEPLANCONTRACTSTATUS.ACCEPTED)) {

        CheckMultipleContractDetails checkMultipleContractDetails = new CheckMultipleContractDetails();

        checkMultipleContractDetails.caseID = servicePlanContractDtls.caseID;
        checkMultipleContractDetails.contractStatus = curam.codetable.SERVICEPLANCONTRACTSTATUS.ISSUED;
        checkMultipleContractDetails.insertingContractInd = false;

        checkForMultipleContracts(checkMultipleContractDetails);
      }
    }
  }

  // _____________________________________________________________________
  /**
   * Validates the details to be modified or inserted.
   *
   * @param servicePlanContractDtls Contains the dates to be inserted.
   */
  public void validateDetails(ServicePlanContractDtls servicePlanContractDtls)
    throws AppException, InformationalException {

    // Issue date specified
    if (servicePlanContractDtls.dateIssued.equals(
      curam.util.type.Date.kZeroDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_ISSUE_DATE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // is address entered?
    if (servicePlanContractDtls.addressID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_ADDRESS_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // is reason entered?
    if (servicePlanContractDtls.issueReason.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_CREATE_REASON_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // is client specified?
    if (servicePlanContractDtls.issuedToParticipantRole == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSERVICEPLANCONTRACT.ERR_SERPLAN_CONTRACT_FV_CLIENT_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // _____________________________________________________________________
  /**
   * Set the contract status to accepted and issued.
   *
   * @param servicePlanDeliveryIssuedAndAcceptStatus Contains a status of
   * accepted and issued
   */
  protected void precountIssuAndAccContractsByCaseID(ServicePlanDeliveryIssuedAndAcceptStatus servicePlanDeliveryIssuedAndAcceptStatus)
    throws AppException, InformationalException {

    servicePlanDeliveryIssuedAndAcceptStatus.contractStatusAccepted = SERVICEPLANCONTRACTSTATUS.ACCEPTED;
    servicePlanDeliveryIssuedAndAcceptStatus.contractStatusIssued = SERVICEPLANCONTRACTSTATUS.ISSUED;

  }

  // _____________________________________________________________________
  /**
   * Set the contract status to issued.
   *
   * @param servicePlanDeliveryAndContractStatusKey Contains a status of issued
   */
  protected void precountIssuedContractsByCaseID(ServicePlanDeliveryAndContractStatusKey servicePlanDeliveryAndContractStatusKey)
    throws AppException, InformationalException {

    servicePlanDeliveryAndContractStatusKey.contractStatus = SERVICEPLANCONTRACTSTATUS.ISSUED;

  }
}
