/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam Software Inc
 * ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in accordance
 * with the terms of the license agreement you entered into with Curam Software Inc.
 *
 */
 
package curam.serviceplans.sl.impl;
 
 
import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.codetable.DOCUMENTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.AttachmentFactory;
import curam.core.fact.CachedCaseParticipantRoleFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.MaintainAttachmentAssistantFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.Attachment;
import curam.core.intf.CachedCaseParticipantRole;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.MaintainAttachmentAssistant;
import curam.core.sl.entity.struct.CaseIDAndParticipantRoleIDDetails;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataConst;
import curam.core.sl.infrastructure.cmis.impl.CMSMetadataInterface;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentHeaderDetails;
import curam.core.struct.AttachmentKey;
import curam.core.struct.AttachmentNameStruct;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameDetails;
import curam.message.BPOMAINTAINATTACHMENT;
import curam.message.GENERAL;
import curam.serviceplans.sl.entity.fact.SPGDeliveryAttachmentLinkFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryFactory;
import curam.serviceplans.sl.entity.intf.SPGDelivery;
import curam.serviceplans.sl.entity.intf.SPGDeliveryAttachmentLink;
import curam.serviceplans.sl.entity.struct.AttachmentIdKey;
import curam.serviceplans.sl.entity.struct.IntegratedCaseIDKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryAttachmentLinkDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryAttachmentLinkDtlsList;
import curam.serviceplans.sl.entity.struct.SPGDeliveryAttachmentLinkKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryAttachmentLinkStatusDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.struct.SPGDAttachmenDetails;
import curam.serviceplans.sl.struct.SPGDAttachmentList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.UniqueID;


/**
 * This service layer class is used to maintain the functionality 
 * related to the attachments in service plan group delivery.
 *
 */
public class MaintainSPGDeliveryAttachment extends curam.serviceplans.sl.base.MaintainSPGDeliveryAttachment {

  // BEGIN, CR00354960, CD
  @Inject
  private Provider<CMSMetadataInterface> cmsMetadataProvider;
  // END, CR00354960
  
  /**
   * Service layer method to add the attachment to the service plan group
   * delivery.
   *
   * @param spgAttachmentDetails
   * Details of the attachment needs to be added
   *
   * @return AttachmentKey - ID of the attachment created
   */
  public AttachmentKey addAttachment(SPGDAttachmenDetails spgAttachmentDetails)
    throws AppException, InformationalException {

    validateAttachment(spgAttachmentDetails, false);

    // BEGIN, CR00354960, CD
    GuiceWrapper.getInjector().injectMembers(this);

    CaseParticipantRole cpr = CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = spgAttachmentDetails.spgAttachmentDtls.caseParticipantRoleID;
    CaseIDAndParticipantRoleIDDetails readCaseIDandParticipantID = cpr.readCaseIDandParticipantID(
      caseParticipantRoleKey);
    
    // set up some meta data about the attachment
    CMSMetadataInterface cmsMetadata = cmsMetadataProvider.get();

    cmsMetadata.add(CMSMetadataConst.kCaseID,
      Long.toString(readCaseIDandParticipantID.caseID));
    cmsMetadata.add(CMSMetadataConst.kParticipantID,
      Long.toString(readCaseIDandParticipantID.participantRoleID));  
    // END, CR00354960  

    Attachment attachmentObj = AttachmentFactory.newInstance();
    AttachmentKey attachmentKey = new AttachmentKey();
    AttachmentDtls attachmentDtls = new AttachmentDtls();

    // create attachment uniqueKeyID
    attachmentKey.attachmentID = UniqueIDFactory.newInstance().getNextID();

    // insert attachment details
    attachmentDtls.attachmentID = attachmentKey.attachmentID;
    attachmentDtls.attachmentStatus = curam.codetable.ATTACHMENTSTATUS.ACTIVE;

    attachmentDtls.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
    AttachmentNameStruct attachmentNameStruct = new AttachmentNameStruct();
    MaintainAttachmentAssistant maintainAttachmentAssistantObj = MaintainAttachmentAssistantFactory.newInstance();

    attachmentNameStruct.attachmentName = spgAttachmentDetails.attachmentDtls.attachmentName;

    // parse attachmentName from path of attachment, leaving just the base
    // name
    maintainAttachmentAssistantObj.parseAttachmentFileName(attachmentNameStruct);

    attachmentDtls.attachmentName = attachmentNameStruct.attachmentName;
    attachmentDtls.attachmentContents = spgAttachmentDetails.attachmentDtls.attachmentContents;

    attachmentDtls.fileLocation = spgAttachmentDetails.attachmentDtls.fileLocation;
    attachmentDtls.fileReference = spgAttachmentDetails.attachmentDtls.fileReference;
    attachmentDtls.documentType = spgAttachmentDetails.attachmentDtls.documentType;
    attachmentDtls.receiptDate = spgAttachmentDetails.attachmentDtls.receiptDate;

    attachmentObj.insert(attachmentDtls);
    // Create the link between the attachment and service plan group
    SPGDeliveryAttachmentLink spgDeliveryAttachmentLinkObj = SPGDeliveryAttachmentLinkFactory.newInstance();

    spgAttachmentDetails.spgAttachmentDtls.attachmentId = attachmentDtls.attachmentID;
    spgAttachmentDetails.spgAttachmentDtls.status = RECORDSTATUS.NORMAL;
    spgAttachmentDetails.spgAttachmentDtls.deliveryAttachmentLinkId = UniqueID.nextUniqueID();
    spgAttachmentDetails.spgAttachmentDtls.attachmentDate = Date.getCurrentDate();
    spgDeliveryAttachmentLinkObj.insert(spgAttachmentDetails.spgAttachmentDtls);

    return attachmentKey;
  }

  /**
   * This method is used to validate the attachment creation.
   *
   * @param spgAttachmentDetails
   * - Details of the attachment
   */
  protected void validateAttachment(
    SPGDAttachmenDetails spgAttachmentDetails, boolean isModify)
    throws AppException, InformationalException {
    
    AttachmentKey attachmentKey = new AttachmentKey();
    Attachment attachmentObj = AttachmentFactory.newInstance();
    AttachmentDtls attachmentDtls = null;

    // set attachment key for read
    attachmentKey.attachmentID = spgAttachmentDetails.attachmentDtls.attachmentID;
    try { 
      attachmentDtls = attachmentObj.read(attachmentKey, true);
    } catch (RecordNotFoundException rnfe) {
      attachmentDtls = null;
    }
    
    boolean atachmentNameProvided = (spgAttachmentDetails.attachmentDtls.attachmentName.length()
      != 0);

    boolean locationANDReferenceProvided = ((
      spgAttachmentDetails.attachmentDtls.fileLocation.length() != 0) && (
      spgAttachmentDetails.attachmentDtls.fileReference.length() != 0));

    boolean locationORReferenceProvided = (
      (spgAttachmentDetails.attachmentDtls.fileLocation.length() != 0)
      || (spgAttachmentDetails.attachmentDtls.fileReference.length() != 0));

    if (atachmentNameProvided && locationORReferenceProvided) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_OR_LOCATION_REFERENCE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          8);
    }
    
    if (!atachmentNameProvided && !locationANDReferenceProvided && !isModify) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_LOCATION_REFERENCE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          9);
    }
    
    if (isModify
      && (!atachmentNameProvided && !locationANDReferenceProvided
      && (null != attachmentDtls && attachmentDtls.attachmentName.length() == 0))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_LOCATION_REFERENCE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          6);
    }
    
    if (isModify
      && (null != attachmentDtls && attachmentDtls.attachmentName.length() != 0) 
      && locationORReferenceProvided) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_OR_LOCATION_REFERENCE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          9);
    }
    if (!atachmentNameProvided && !locationORReferenceProvided && !isModify) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_LOCATION_REFERENCE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          7);
    }
    if (isModify && !atachmentNameProvided
      && (null != attachmentDtls && attachmentDtls.attachmentName.length() == 0)
      && !locationORReferenceProvided) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_XRV_FILENAME_LOCATION_REFERENCE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          8);
    }
    AttachmentNameStruct attachmentNameStruct = new AttachmentNameStruct();
    MaintainAttachmentAssistant maintainAttachmentAssistantObj = MaintainAttachmentAssistantFactory.newInstance();

    if (atachmentNameProvided) {
      attachmentNameStruct.attachmentName = spgAttachmentDetails.attachmentDtls.attachmentName;

      // parse attachmentName from path of attachment, leaving just the base
      // name
      maintainAttachmentAssistantObj.parseAttachmentFileName(
        attachmentNameStruct);

      if (attachmentNameStruct.attachmentName.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_FV_NAME_EMPTY),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            4);
      }
    }

    // // validate attachment details
    if (spgAttachmentDetails.spgAttachmentDtls.description.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_FV_EMPTY_DESCRIPTION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);
    }

    if (spgAttachmentDetails.spgAttachmentDtls.description.trim().length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_FV_BLANK_DESCRIPTION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          4);
    }

    if (spgAttachmentDetails.attachmentDtls.receiptDate.after(
      Date.getCurrentDate())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINATTACHMENT.ERR_CASEATTACHMENT_FV_RECEIPTDATE_LATER_THAN_TODAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          4);
    }
     
  }

  /**
   * This method is used to display all the attachments in the service plan
   * group delivery.
   *
   * @param spgDeliveryKey
   * ID of the service plan group delivery key.
   */
  public SPGDAttachmentList listAttachment(SPGDeliveryKey spgDeliveryKey)
    throws AppException, InformationalException {

    SPGDAttachmentList spgdAttachmentList = new SPGDAttachmentList();
    SPGDeliveryAttachmentLink spgDeliveryAttachmentLinkObj = SPGDeliveryAttachmentLinkFactory.newInstance();
    Attachment attachmentObj = AttachmentFactory.newInstance();
    AttachmentDtls attachmentDtls = new AttachmentDtls();
    SPGDAttachmenDetails spgdAttachmentDetails = null;
   
    // Get the list of all the attachment links for the service plan group
    // delivery
    SPGDeliveryAttachmentLinkDtlsList spgDeliveryAttachmentLinkDtlsList = spgDeliveryAttachmentLinkObj.searchByServicePlanGroupDeliveryId(
      spgDeliveryKey);
    AttachmentKey attachmentKey = new AttachmentKey();
  
    // Iterate over all the attachment links and get details of each attachment
    // and add it to the return list
    final int sizeOfTheList = spgDeliveryAttachmentLinkDtlsList.dtls.size();

    for (int attchmentListIter = 0; attchmentListIter < sizeOfTheList; attchmentListIter++) {
      attachmentKey.attachmentID = spgDeliveryAttachmentLinkDtlsList.dtls.item(attchmentListIter).attachmentId;
      // BEGIN, CR00295922, CD
      AttachmentHeaderDetails attachmentHeaderDetails = attachmentObj.readHeader(
        attachmentKey);

      attachmentDtls.assign(attachmentHeaderDetails);
      // END, CR00295922
      spgdAttachmentDetails = new SPGDAttachmenDetails();
      spgdAttachmentDetails.attachmentDtls.assign(attachmentDtls);
      spgdAttachmentDetails.spgAttachmentDtls.assign(
        spgDeliveryAttachmentLinkDtlsList.dtls.item(attchmentListIter));
      spgdAttachmentList.dtls.addRef(spgdAttachmentDetails);

    }
  
    // Get the integrated case id to fetch the list of case 
    // participant to pass to the create page
    SPGDelivery spgDeliveryObj = SPGDeliveryFactory.newInstance();
    IntegratedCaseIDKey integratedCaseIDKey = spgDeliveryObj.readCaseIdByServicePlanGroupDeliveryId(
      spgDeliveryKey);

    spgdAttachmentList.integratedCaseID = integratedCaseIDKey.integratedCaseID;
    
    return spgdAttachmentList;
  }

  /**
   * This method is used to modify the attachment details.
   *
   * @param spgAttachmentDetails
   * details of the attachment.
   */
  public void modifyAttachment(SPGDAttachmenDetails details)
    throws AppException, InformationalException {

    SPGDeliveryAttachmentLink spgAttachmentLinkObj = SPGDeliveryAttachmentLinkFactory.newInstance();
    SPGDeliveryAttachmentLinkKey spgAttachmentKey = new SPGDeliveryAttachmentLinkKey();

    spgAttachmentKey.deliveryAttachmentLinkId = details.spgAttachmentDtls.deliveryAttachmentLinkId;
    
    SPGDeliveryAttachmentLinkDtls spgdeliveryAttachmentLinkDtls = spgAttachmentLinkObj.read(
      spgAttachmentKey);

    if (spgdeliveryAttachmentLinkDtls.status.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_GENERAL_FV_NO_MODIFY_RECORD_CANCELLED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 80);
      
    }
    
    // Validate the attachment modification
    validateAttachment(details, true);
   
    AttachmentKey attachmentKey = new AttachmentKey();
    AttachmentDtls attachmentDtls = new AttachmentDtls();
    AttachmentNameStruct attachmentNameStruct = new AttachmentNameStruct();

    // Set attachment key for read
    Attachment attachmentObj = AttachmentFactory.newInstance();

    attachmentKey.attachmentID = details.attachmentDtls.attachmentID;
    attachmentDtls = attachmentObj.read(attachmentKey, true);

    // Modify the attachment details
    if (details.attachmentDtls.attachmentContents.length() > 0) {

      attachmentNameStruct.attachmentName = details.attachmentDtls.attachmentName;
      attachmentDtls.attachmentContents = details.attachmentDtls.attachmentContents;
    } else {

      attachmentNameStruct.attachmentName = attachmentDtls.attachmentName;
      attachmentDtls.attachmentContents = attachmentDtls.attachmentContents;
    }
    MaintainAttachmentAssistant maintainAttachmentAssistantObj = MaintainAttachmentAssistantFactory.newInstance();

    // parse attachmentName from path of attachment
    maintainAttachmentAssistantObj.parseAttachmentFileName(attachmentNameStruct);

    attachmentDtls.attachmentName = attachmentNameStruct.attachmentName;
    attachmentDtls.fileLocation = details.attachmentDtls.fileLocation;
    attachmentDtls.fileReference = details.attachmentDtls.fileReference;
    attachmentDtls.receiptDate = details.attachmentDtls.receiptDate;
    attachmentDtls.documentType = details.attachmentDtls.documentType;

    attachmentObj.modify(attachmentKey, attachmentDtls);
    
    // Update the description
    
    SPGDeliveryAttachmentLinkKey attachmentLinkKey = new SPGDeliveryAttachmentLinkKey();

    attachmentLinkKey.deliveryAttachmentLinkId = details.spgAttachmentDtls.deliveryAttachmentLinkId;
    details.spgAttachmentDtls.attachmentId = attachmentDtls.attachmentID;
    
    spgAttachmentLinkObj.modify(attachmentLinkKey, details.spgAttachmentDtls);
  }

  /**
   * This method is used to remove the attachment details.
   *
   * @param spgAttachmentDetails
   * - details of the attachment
   */
  public void removeAttachment(SPGDAttachmenDetails details)
    throws AppException, InformationalException {

    // Attachment manipulation variables
    Attachment attachmentObj = AttachmentFactory.newInstance();
    AttachmentKey attachmentKey = new AttachmentKey();
    AttachmentDtls attachmentDtls;

    attachmentKey.attachmentID = details.attachmentDtls.attachmentID;

    attachmentDtls = attachmentObj.read(attachmentKey, true);

    // check to see if it has been canceled already
    if (attachmentDtls.statusCode.equals(curam.codetable.RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_GENERAL_FV_RECORD_ALREADY_CANCELLED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 73);
    }

    // change the attachment record status
    attachmentDtls.statusCode = curam.codetable.RECORDSTATUS.CANCELLED;

    // pass versionNo to make sure that the record hasn't changed
    attachmentDtls.versionNo = details.attachmentDtls.versionNo;

    attachmentObj.modify(attachmentKey, attachmentDtls);

    SPGDeliveryAttachmentLink spgDeliveryAttachmentLinkObj = SPGDeliveryAttachmentLinkFactory.newInstance();
    SPGDeliveryAttachmentLinkKey spdgAttachmentKey = new SPGDeliveryAttachmentLinkKey();

    spdgAttachmentKey.deliveryAttachmentLinkId = details.spgAttachmentDtls.deliveryAttachmentLinkId;
    SPGDeliveryAttachmentLinkDtls spgdeliveryAttachmentLinkDtls = spgDeliveryAttachmentLinkObj.read(
      spdgAttachmentKey);

    // check to see if it has been canceled already
    if (spgdeliveryAttachmentLinkDtls.status.equals(
      curam.codetable.RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_GENERAL_FV_RECORD_ALREADY_CANCELLED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 72);
    }

    SPGDeliveryAttachmentLinkStatusDtls spgdeliveryAttachmentLinkStatusDtls = new SPGDeliveryAttachmentLinkStatusDtls();

    spgdeliveryAttachmentLinkStatusDtls.status = RECORDSTATUS.CANCELLED;
    spgDeliveryAttachmentLinkObj.cancelLink(spdgAttachmentKey,
      spgdeliveryAttachmentLinkStatusDtls);

  }

  /**
   * This method is used to view the attachment details.
   *
   * @param spgAttachmentDetails 
   * details of the attachment.
   */
  public SPGDAttachmenDetails viewAttachment(AttachmentKey key)
    throws AppException, InformationalException {
    
    Attachment attachmentObj = AttachmentFactory.newInstance();
    AttachmentDtls attachmentDtls = attachmentObj.read(key);
    SPGDAttachmenDetails spgdAttachmenDetails = new SPGDAttachmenDetails();

    spgdAttachmenDetails.attachmentDtls.assign(attachmentDtls);
    SPGDeliveryAttachmentLink spgDeliveryAttachmentLinkObj = SPGDeliveryAttachmentLinkFactory.newInstance();

    AttachmentIdKey attachmentIDKey = new AttachmentIdKey();

    attachmentIDKey.attachmentId = key.attachmentID;
   
    // Get the attachment id from the link
    SPGDeliveryAttachmentLinkDtls spgDeliveryAttachmentLinkDtls = spgDeliveryAttachmentLinkObj.readByAttachmentID(
      attachmentIDKey);
    SPGDeliveryKey spgDeliveryKey = new SPGDeliveryKey();

    spgDeliveryKey.servicePlanGroupDeliveryId = spgDeliveryAttachmentLinkDtls.servicePlanGroupDeliveryId;
    SPGDelivery spgDeliveryObj = SPGDeliveryFactory.newInstance();
    
    // Read the integrated case ID to get the participant role id
    IntegratedCaseIDKey integratedCaseIDKey = spgDeliveryObj.readCaseIdByServicePlanGroupDeliveryId(
      spgDeliveryKey);
    
    // Read the participant role details
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = integratedCaseIDKey.integratedCaseID;
    CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    spgdAttachmenDetails.caseDtls.caseID = caseHeaderDtls.caseID;
    spgdAttachmenDetails.caseDtls.participantRoleID = caseHeaderDtls.concernRoleID;
 
    // CaseParticipantRole manipulation variables
    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();
    CachedCaseParticipantRole cachedCaseParticipantRoleObj = CachedCaseParticipantRoleFactory.newInstance();
    CaseIDAndParticipantRoleIDDetails caseIDAndParticipantRoleIDDetails;
   
    // ConcernRole manipulation variables
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleNameDetails concernRoleNameDtls;

    spgdAttachmenDetails.spgAttachmentDtls.assign(spgDeliveryAttachmentLinkDtls);
    caseParticipantRoleKey.caseParticipantRoleID = spgdAttachmenDetails.spgAttachmentDtls.caseParticipantRoleID;

    // there will be no case participant role ID for creating an
    // attachment on a communication
    if (spgdAttachmenDetails.spgAttachmentDtls.caseParticipantRoleID != 0) {
      // Reads caseParticipantRoleID
      caseIDAndParticipantRoleIDDetails = cachedCaseParticipantRoleObj.readCaseIDAndParticipantRoleIDDetails(
        caseParticipantRoleKey);

      concernRoleKey.concernRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;

      // read concern role to get participant name
      concernRoleNameDtls = concernRoleObj.readConcernRoleName(concernRoleKey);

      spgdAttachmenDetails.caseDtls.caseParticipantName = concernRoleNameDtls.concernRoleName;

      spgdAttachmenDetails.caseDtls.participantRoleID = caseIDAndParticipantRoleIDDetails.participantRoleID;
       
    }
    
    spgdAttachmenDetails.caseDtls.caseID = integratedCaseIDKey.integratedCaseID;

    return spgdAttachmenDetails;
  }

}
