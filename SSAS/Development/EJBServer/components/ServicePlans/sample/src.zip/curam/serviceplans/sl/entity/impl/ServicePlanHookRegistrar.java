/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.google.inject.Inject;

import curam.codetable.PLANITEMTYPE;
import curam.core.impl.Registrar;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.message.BPOSERVICEPLANHOOKREGISTRAR;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.type.CodeTableItemIdentifier;

/**
 * Interface implemented by classes which register plan level hooks.
 * These classes are dynamically created by the ServicePlanHookManager at
 * runtime. The names of the classes to be dynamically created are taken
 * from the 'curam.case.serviceplanhook.registrars' environment variable.
 */
public interface ServicePlanHookRegistrar {

  /**
   * The HookMap class is a generic plan name to Curam factory
   * class mapping.
   */
  public final class HookMap {

    // BEGIN, CR00198200, GYH 
    /**
     * Internal storage of the hook factory classes in a concurrent hash map.
     */
    protected Map<String, Method> hookMap = 
      new ConcurrentHashMap<String, Method>();

    /**
     * Registers all the maps of Service Plan Item Hook implementations from
     * corresponding module class during the process of this class instance
     * creation.
     * 
     * @param moduleEvidenceMap
     *          Contains all the maps of Service Plan Item Hook implementations.
     */
     @Inject(optional = true)
     void registerPlanItemHooks(final @Registrar(
         Registrar.RegistrarType.SERVICE_PLAN_ITEM_HOOK) 
         Map<String, Method> planItemHookMap){
       
       // Register all the maps of Service Plan Item Hook implementations.
       hookMap.putAll(planItemHookMap);
     }
     
     /**
     * Registers all the maps of Service Planned Item Hook implementations from
     * corresponding module class during the process of this class instance
     * creation.
     * 
     * @param moduleEvidenceMap
     *          Contains all the maps of Service Planned Item Hook
     *          implementations.
     */
      @Inject(optional = true)
      void registerPlannedItemHooks(final @Registrar(
          Registrar.RegistrarType.SERVICE_PLANNED_ITEM_HOOK) 
          Map<String, Method> plannedItemHookMap){
        
        // Register all the maps of Service Planned Item Hook implementations.
        hookMap.putAll(plannedItemHookMap);
      }
     // END, CR00198200 

    /**
     * Add a mapping for the specified plan to the specified factory
     * class.
     *
     * @param planType The type of the plan
     * @param factory The factory class which can create the hook
     */
    public void addMapping(final String planType, final Class factory) {
      Method newInstance = null;
      
      try {
        newInstance =
          factory.getMethod(ReflectionConst.kNewInstance, new Class[0]);
      } catch (NoSuchMethodException e) {

        AppException ae =
          new AppException(
              BPOSERVICEPLANHOOKREGISTRAR.ERR_REGISTRAR_NEW_INSTANCE_UNIMPLEMENTED);

        ae.arg(factory.getName());
        ae.arg(new CodeTableItemIdentifier(PLANITEMTYPE.TABLENAME, planType));

        throw new AppRuntimeException(ae);
      }

      hookMap.put(planType, newInstance);
    }

    /**
     * Creates an instance of the hook for the specified plan.
     *
     * @param planType The type of the plan.
     * @param intf The type that the hook should implement.
     *
     * @return The created hook object
     */
    public Object createHookInstance(final String planType, final Class intf) 
    throws AppException {
      Method newInstance = hookMap.get(planType);

      if (newInstance == null) {
        return null;
      }

      try {
        Object bpoObject = newInstance.invoke(null, new Object[0]);

        // Check that the created Business Process Object can be safely cast
        // to the type intf
        if (!(intf.isInstance(bpoObject))) {

          AppException e =
            new AppException(
                BPOSERVICEPLANHOOKREGISTRAR.ERR_REGISTRAR_INCORRECT_BPOCLASS);

          e.arg(bpoObject.getClass().getName());
          e.arg(new CodeTableItemIdentifier(PLANITEMTYPE.TABLENAME, planType));
          e.arg(intf.getName());
          curam.core.sl.infrastructure.impl.ValidationManagerFactory
            .getManager()
              .throwWithLookup(
                e,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                    0);
        }

        return bpoObject;
      } catch (Exception e) {

        AppException ae =
          new AppException(
              BPOSERVICEPLANHOOKREGISTRAR.ERR_REGISTRAR_HOOK_INSTANTIATION_FAILED);

        ae.arg(new CodeTableItemIdentifier(PLANITEMTYPE.TABLENAME, planType));
        ae.arg(e.getLocalizedMessage());
        throw ae;
      }
    }
  }
  
  /**
   * Implementors should use this method to add details of the hooks to use
   * for registering planned item hooks.
   */
  public void registerPlannedItemDataHooks();
  
  /**
   * Implementors should use this method to add details of the hooks to use
   * for registering plan item hooks.
   */
  public void registerPlanItemDataHooks();
}
