/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.codetable.APPROVALREQUESTSTATUS;
import curam.codetable.BASELINETYPE;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SERVICEPLANTYPE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.struct.ApprovalRequestStatusDetails;
import curam.core.sl.entity.struct.CurrentUserDetails;
import curam.core.sl.entity.struct.ReadByCaseStatusTypeKey;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.struct.OwnerInd;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusAndEventTypeDetails1;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.ReadIntegratedCaseIDAndParticipantDetails;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.events.SERVICEPLANS;
import curam.message.BPOCASEEVENTS;
import curam.message.BPOPAAPPROVALREQUEST;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.BPOSPAPPROVALREQUEST;
import curam.message.GENERALCASE;
import curam.serviceplans.sl.entity.fact.SPApprovalRequestFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.SPApprovalRequest;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.struct.ApprovalRequestIDCaseIDKey;
import curam.serviceplans.sl.entity.struct.BaselineNameAndIDDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemCountDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.SPApprovalRequestID;
import curam.serviceplans.sl.entity.struct.ServicePlanSecurityIndicatorsDetails;
import curam.serviceplans.sl.fact.ServicePlanApprovalCheckFactory;
import curam.serviceplans.sl.intf.ServicePlanApprovalCheck;
import curam.serviceplans.sl.struct.ApprovalChecksList;
import curam.serviceplans.sl.struct.ApprovalRequestCaseIDKey;
import curam.serviceplans.sl.struct.PlannedItemIDList;
import curam.serviceplans.sl.struct.SPApprovalRequestDetailsList;
import curam.serviceplans.sl.struct.SPApprovalRequestKey;
import curam.serviceplans.sl.struct.SPKey;
import curam.serviceplans.sl.struct.ServicePlanAndParticipantDetails;
import curam.serviceplans.sl.struct.ServicePlanApprovalCheckList;
import curam.serviceplans.sl.struct.ServicePlanApprovalRequestFullDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanDeliveryReadDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryRejectDetails;
import curam.serviceplans.sl.struct.ServicePlanKey;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.serviceplans.sl.struct.UserApprovalCheckSearchKey;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;


/**
 * This process class provides the functionality for service Plans
 * Approval Request at the service layer.
 */
public abstract class ServicePlanApprovalRequest extends curam.serviceplans.sl.base.ServicePlanApprovalRequest {

  // BEGIN, CR00071077, GM
  protected static final String kServicePlanStandardTask = TaskDefinitionIDConst.standardCaseTaskDefinitionID;
  // END, CR00071077
  
  // BEGIN CR00108818, GBA
  // Add injection for using the new CaseTransactionLog API
  public ServicePlanApprovalRequest() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;
  // END CR00108818  

  /**
   * Lists all approval requests associated with a specific Service Plan.
   *
   * @param key
   * Identifies the Service Plan Approval requests.
   *
   * @return A list of all approval requests associated with the Service Plan.
   *
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_VIEW_SERVICEPLAN_CHECK_FAILED} -
   * if the user does not have appropriate privileges to view this
   * approval request.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SPApprovalRequestDetailsList list(ApprovalRequestCaseIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // CaseHeader manipulation variables
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Service plan Delivery manipulation variables
    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // set SevicePlandDelivery Key
    servicePlanDeliveryKey.key.caseID = key.approvalRequestCaseIDKey.caseID;

    // set case headers key
    caseHeaderKey.caseID = servicePlanDeliveryObj.read(servicePlanDeliveryKey.key).caseID;

    // set SecurityKey details
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey.key).servicePlanID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.read(caseHeaderKey).concernRoleID;

    // check service plan security if maintain rights are defined
    // Also check sensitivity check for user
    // Below check will do both:
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (AppException e) {
      if (e.equals(
        curam.message.BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSPAPPROVALREQUEST.ERR_VIEW_SERVICEPLAN_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSPAPPROVALREQUEST.ERR_VIEW_SERVICEPLAN_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // create return value
    SPApprovalRequestDetailsList spApprovalRequestDetailsList = new SPApprovalRequestDetailsList();

    // Service Plan ApprovalRequest entity object
    SPApprovalRequest spApprovalRequestObj = SPApprovalRequestFactory.newInstance();

    // search for all service plan approval request details
    spApprovalRequestDetailsList.list = spApprovalRequestObj.searchApprovalRequestByCaseID(
      key.approvalRequestCaseIDKey);

    // return approval request list
    return spApprovalRequestDetailsList;
  }

  /**
   * Reads an approval request associated with a specific service plan.
   *
   * @param spApprovalRequestKey
   * Identifies the service plan approval request.
   *
   * @return Details on an approval request associated with the service plan.
   *
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_VIEW_SERVICEPLAN_CHECK_FAILED} -
   * if the user does not have appropriate privileges to view this
   * approval request.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ServicePlanApprovalRequestFullDetails read(
    SPApprovalRequestKey spApprovalRequestKey) throws AppException,
      InformationalException {

    // create Service Plan Approval Request Object
    curam.serviceplans.sl.entity.intf.SPApprovalRequest spApprovalRequestObj = curam.serviceplans.sl.entity.fact.SPApprovalRequestFactory.newInstance();

    // ApprovalRequest entity manipulation variables
    curam.core.sl.entity.intf.ApprovalRequest approvalRequestObj = curam.core.sl.entity.fact.ApprovalRequestFactory.newInstance();

    // create approval Request key
    curam.core.sl.entity.struct.ApprovalRequestKey approvalRequestKey = new curam.core.sl.entity.struct.ApprovalRequestKey();

    // create return value
    ServicePlanApprovalRequestFullDetails servicePlanApprovalRequestFullDetails = new ServicePlanApprovalRequestFullDetails();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // CaseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    // Service plan Delivery manipulation variables
    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // read spApprovalRequest details
    servicePlanApprovalRequestFullDetails.spApprovalRequestDtls = spApprovalRequestObj.read(
      spApprovalRequestKey.spApprovalRequestKey);

    // set SevicePlandDelivery Key
    servicePlanDeliveryKey.key.caseID = servicePlanApprovalRequestFullDetails.spApprovalRequestDtls.caseID;

    // set SecurityKey key
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey.key).servicePlanID;

    // set case headers key
    caseHeaderKey.caseID = servicePlanDeliveryObj.read(servicePlanDeliveryKey.key).caseID;

    // set securityKey details
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.read(caseHeaderKey).concernRoleID;

    // check service plan security
    // Also check sensitivity check for user
    // Below check will do both:
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSPAPPROVALREQUEST.ERR_VIEW_SERVICEPLAN_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSPAPPROVALREQUEST.ERR_VIEW_SERVICEPLAN_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Set approvalRequestKey
    approvalRequestKey.approvalRequestID = servicePlanApprovalRequestFullDetails.spApprovalRequestDtls.approvalRequestID;

    // Read the approval request record
    servicePlanApprovalRequestFullDetails.approvalRequestDtls = approvalRequestObj.read(
      approvalRequestKey);

    // baseline name and ID details
    BaselineNameAndIDDetails baselineNameAndIDDetails;

    // readSubmitBaselineDetails
    baselineNameAndIDDetails = spApprovalRequestObj.readSubmitBaselineDetails(
      spApprovalRequestKey.spApprovalRequestKey);

    servicePlanApprovalRequestFullDetails.spSubmissionBaselineDetails.baselineID = baselineNameAndIDDetails.baseLineID;
    servicePlanApprovalRequestFullDetails.spSubmissionBaselineDetails.baselineName = baselineNameAndIDDetails.name;

    // readApproveBaselineDetails (if plan is rejected or submitted there will
    // be no approve baseline)
    try {
      baselineNameAndIDDetails = spApprovalRequestObj.readApproveBaselineDetails(
        spApprovalRequestKey.spApprovalRequestKey);
    } catch (RecordNotFoundException e) {
      baselineNameAndIDDetails = null;
    }

    if (baselineNameAndIDDetails != null) {

      servicePlanApprovalRequestFullDetails.spApprovalBaselineDetails.baselineID = baselineNameAndIDDetails.baseLineID;
      servicePlanApprovalRequestFullDetails.spApprovalBaselineDetails.baselineName = baselineNameAndIDDetails.name;
    }

    curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    UsersKey requestedUsersKey = new UsersKey();

    // Set the full name of the requested user
    requestedUsersKey.userName = servicePlanApprovalRequestFullDetails.approvalRequestDtls.requestedByUser;
    servicePlanApprovalRequestFullDetails.requestedByUserFullName = usersObj.getFullName(requestedUsersKey).fullname;

    // for submitted approval requests approvalDecisionByUser field is empty
    if (servicePlanApprovalRequestFullDetails.approvalRequestDtls.approvalDecisionByUser.length()
      > 0) {

      // Set the full name of user decision made by
      UsersKey decisionUsersKey = new UsersKey();

      decisionUsersKey.userName = servicePlanApprovalRequestFullDetails.approvalRequestDtls.approvalDecisionByUser;
      servicePlanApprovalRequestFullDetails.decisionMadeByUserFullName = usersObj.getFullName(decisionUsersKey).fullname;
    }

    // Return the planned item approval request record and the related approval
    // request record.
    return servicePlanApprovalRequestFullDetails;
  }

  // ___________________________________________________________________________
  /**
   * Part of approval process for service plans
   *
   * checks to see if service plan is automatically approved, if so updates
   * current approval request and service plan approval request records.  If not
   * creates an approval request and service plan approval request records with
   * appropriate details.
   *
   * @param key Identifies the service plan delivery.
   */
  public void approve(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // ApprovalRequest manipulation variables
    curam.core.sl.entity.intf.ApprovalRequest approvalRequestObj = curam.core.sl.entity.fact.ApprovalRequestFactory.newInstance();
    curam.core.sl.entity.struct.ApprovalDetails approvalDetails = new curam.core.sl.entity.struct.ApprovalDetails();
    curam.core.sl.entity.struct.ApprovalRequestKey approvalRequestKey = new curam.core.sl.entity.struct.ApprovalRequestKey();
    curam.core.sl.entity.struct.ApprovalRequestIDAndVersionNoDetails approvalRequestIDAndVersionNoDetails;

    // Maintain Case business object
    curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
    // BEGIN, CR00220971, ZV
    CaseStatusAndEventTypeDetails1 caseStatusAndEventTypeDetails = new CaseStatusAndEventTypeDetails1();
    // END, CR00220971

    // Baseline manipulation variables
    curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();
    curam.serviceplans.sl.struct.CreateBaselineDetails createBaselineDetails = new curam.serviceplans.sl.struct.CreateBaselineDetails();

    // SPApprovalRequest manipulation variables
    curam.serviceplans.sl.entity.intf.SPApprovalRequest spApprovalRequestObj = curam.serviceplans.sl.entity.fact.SPApprovalRequestFactory.newInstance();
    curam.serviceplans.sl.entity.struct.SPApprovalRequestKey spApprovalRequestKey = new curam.serviceplans.sl.entity.struct.SPApprovalRequestKey();
    curam.serviceplans.sl.entity.struct.ModifyApprovalBaselineDetails modifyApprovalBaselineDetails = new curam.serviceplans.sl.entity.struct.ModifyApprovalBaselineDetails();
    curam.serviceplans.sl.entity.struct.ModifySubmitApprovalBaselineDetails modifySubmitApprovalBaselineDetails = new curam.serviceplans.sl.entity.struct.ModifySubmitApprovalBaselineDetails();
    curam.serviceplans.sl.entity.struct.SPApprovalRequestIDSubmitBaselineIDVersionNo spApprovalRequestIDSubmitBaselineIDVersionNo = new curam.serviceplans.sl.entity.struct.SPApprovalRequestIDSubmitBaselineIDVersionNo();

    // PlannedItem entity manipulation variables
    curam.serviceplans.sl.entity.intf.PlannedItem plannedItemEntityObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
    curam.serviceplans.sl.entity.struct.PlannedItemStatusAndCaseIDKey plannedItemStatusAndCaseIDKey = new curam.serviceplans.sl.entity.struct.PlannedItemStatusAndCaseIDKey();

    // PlannedItemApprovalRequest business process manipulation variables
    curam.serviceplans.sl.intf.PlannedItemApprovalRequest plannedItemApprovalRequestObj = curam.serviceplans.sl.fact.PlannedItemApprovalRequestFactory.newInstance();

    // BEGIN, CR00076062 SPD
    curam.core.sl.intf.UserRecentAction userRecentActionObj = curam.core.sl.fact.UserRecentActionFactory.newInstance();
    curam.core.sl.struct.UserRecentActionDetails userRecentActionDetails = new curam.core.sl.struct.UserRecentActionDetails();

    // END, CR00076062

    // validate approval
    validateApproveDetails(key);

    // Set the key for reading Approval Request
    curam.serviceplans.sl.entity.struct.CaseIDAndApprovalRequestStatusKey caseIDAndApprovalRequestStatusKey = new curam.serviceplans.sl.entity.struct.CaseIDAndApprovalRequestStatusKey();

    caseIDAndApprovalRequestStatusKey.caseID = key.key.caseID;
    caseIDAndApprovalRequestStatusKey.status = APPROVALREQUESTSTATUS.SUBMITTED;
    // boolean approvalRequestFound = true;
    
    // BEGIN, CR00227859, PM
    // Security variables
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = key.key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    // read approval request ID and versionNo for modify
    try {
      approvalRequestIDAndVersionNoDetails = spApprovalRequestObj.readApprovalRequestIDAndVersionNoByCaseIDAndApprovalRequestStatus(
        caseIDAndApprovalRequestStatusKey);
    } catch (RecordNotFoundException e) {
      // approvalRequestFound = false;
      approvalRequestIDAndVersionNoDetails = null;
    }

    // read service plan approval request ID, version number and approval
    // request status
    spApprovalRequestIDSubmitBaselineIDVersionNo = spApprovalRequestObj.readSPApprovalRequestIDSubmitBaselineIDVersionNoDetails(
      caseIDAndApprovalRequestStatusKey);

    // modify approval request - set status to 'approved'.
    approvalRequestKey.approvalRequestID = approvalRequestIDAndVersionNoDetails.approvalRequestID;
    approvalDetails.status = APPROVALREQUESTSTATUS.APPROVED;
    approvalDetails.approvalDecisionDate = Date.getCurrentDate();
    approvalDetails.approvalDecisionByUser = curam.util.transaction.TransactionInfo.getProgramUser();
    approvalDetails.automaticallyApprovedInd = false;
    approvalDetails.versionNo = approvalRequestIDAndVersionNoDetails.versionNo;
    approvalRequestObj.approve(approvalRequestKey, approvalDetails);

    // BEGIN, CR00076062 SPD
    // populate details for UserRecentAction record
    userRecentActionDetails.dtls.referenceNo = key.key.caseID;

    // create a UserRecentAction record of type 'Approved'
    userRecentActionObj.createCaseActionApprove(userRecentActionDetails);
    // END, CR00076062

    // read environment variable

    boolean createBaselineAutomatically_default = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_BASELINES_CREATE_AUTOMATICALLY_DEFAULT);

    boolean createBaselineAutomatically = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_BASELINES_CREATE_AUTOMATICALLY,
      createBaselineAutomatically_default);

    curam.serviceplans.sl.struct.BaselineIDDetails baselineIDDetails = new curam.serviceplans.sl.struct.BaselineIDDetails();

    if (createBaselineAutomatically) {

      // create approval baseline
      createBaselineDetails.caseID = key.key.caseID;
      createBaselineDetails.typeCode = BASELINETYPE.APPROVAL;
      baselineIDDetails = baselineObj.create(createBaselineDetails);
    }

    if ((spApprovalRequestIDSubmitBaselineIDVersionNo.submitBaselineID == 0)) {
      // if there is no submitBaselineID it means there is no approval
      // request record. It means that the service plan has not been
      // submitted and therefore this is automatically approval.

      // modify existing service plan approval request record and set both baseline
      // IDs equal to newly created baseline ID

      if (createBaselineAutomatically) {
        // create data for service plan approval request update
        spApprovalRequestKey.servicePlanApprovalRequestID = spApprovalRequestIDSubmitBaselineIDVersionNo.servicePlanApprovalRequestID;
        modifySubmitApprovalBaselineDetails.submitBaselineID = baselineIDDetails.baselineIDDetails.baseLineID;
        modifySubmitApprovalBaselineDetails.approvalBaselineID = baselineIDDetails.baselineIDDetails.baseLineID;
        modifySubmitApprovalBaselineDetails.versionNo = spApprovalRequestIDSubmitBaselineIDVersionNo.versionNo;

        // update submit and approval baseline ID's if it was created during submitting
        try {
          spApprovalRequestObj.modifySubmitApprovalBaselineID(
            spApprovalRequestKey, modifySubmitApprovalBaselineDetails);
        } catch (curam.util.exception.RecordNotFoundException e) {// do nothing: baseline when submitting was not created
        }
      }

    } else {
      // if only one service plan approval record to be found, this means
      // that the case has been manually approved

      if (createBaselineAutomatically) {
        // create data for service plan approval request update
        spApprovalRequestKey.servicePlanApprovalRequestID = spApprovalRequestIDSubmitBaselineIDVersionNo.servicePlanApprovalRequestID;
        modifyApprovalBaselineDetails.approvalBaselineID = baselineIDDetails.baselineIDDetails.baseLineID;
        modifyApprovalBaselineDetails.versionNo = spApprovalRequestIDSubmitBaselineIDVersionNo.versionNo;

        // update approval baseline ID if it was created during submitting
        try {
          spApprovalRequestObj.modifyApprovalBaselineID(spApprovalRequestKey,
            modifyApprovalBaselineDetails);
        } catch (curam.util.exception.RecordNotFoundException e) {// do nothing: baseline when submitting was not created
        }
      }

    }

    // populate input struct to create case status and event
    caseStatusAndEventTypeDetails.caseID = key.key.caseID;
    caseStatusAndEventTypeDetails.eventTypeCode = CASEEVENTTYPE.PLANAPPROVED;
    caseStatusAndEventTypeDetails.statusCode = CASESTATUS.APPROVED;

    // No reason required when approving a service plan
    // BEGIN, CR00052924, GM
    caseStatusAndEventTypeDetails.reasonCode = CuramConst.gkEmpty;
    // END, CR00052924

    caseStatusAndEventTypeDetails.relatedID = spApprovalRequestIDSubmitBaselineIDVersionNo.servicePlanApprovalRequestID;

    // change case status to 'approved' and create 'plan approved' event
    // BEGIN, CR00220971, ZV
    maintainCaseObj.changeCaseStatus1(caseStatusAndEventTypeDetails);
    // END, CR00220971

    // search for all planItems with the status of 'unapproved'.
    plannedItemStatusAndCaseIDKey.caseID = key.key.caseID;
    
    plannedItemStatusAndCaseIDKey.status = PLANNEDITEMSTATUS.UNAPPROVED;
    curam.serviceplans.sl.entity.struct.PlannedItemKeyList plannedItemKeyList = plannedItemEntityObj.searchIDByStatusAndCaseID(
      plannedItemStatusAndCaseIDKey);

    // BEGIN, CR00161962, LJ
    if (plannedItemKeyList.dtls.size() > 0) {

      // Set up the details for the planned item key list to be approved
      final PlannedItemIDList plannedItemIDList = new PlannedItemIDList();

      // Obtain size of list
      final int plannedItemKeyListSize = plannedItemKeyList.dtls.size();

      for (int i = 0; i < plannedItemKeyListSize; i++) {

        final curam.serviceplans.sl.struct.PlannedItemKey plannedItemKey = new curam.serviceplans.sl.struct.PlannedItemKey();

        // Set planned item id
        plannedItemKey.plannedItemID = plannedItemKeyList.dtls.item(i).plannedItemID;

        // Add reference to list
        plannedItemIDList.key.addRef(plannedItemKey);

      }

      // Make the call to submit and approve the planned item list
      plannedItemApprovalRequestObj.submitPlannedItemList(plannedItemIDList);

    }
    // END, CR00161962
    // BEGIN, CR00118860, MC
    // Check for planned items which are already in a Not Started status but are not
    // associated with a concerning participant.
    
    plannedItemStatusAndCaseIDKey.status = PLANNEDITEMSTATUS.NOTSTARTED;
    
    plannedItemKeyList = plannedItemEntityObj.searchIDByStatusAndCaseID(
      plannedItemStatusAndCaseIDKey);
    
    PlannedItemKey plannedItemKey = new PlannedItemKey();
    
    for (int i = 0; i < plannedItemKeyList.dtls.size(); i++) {

      plannedItemKey.plannedItemID = plannedItemKeyList.dtls.item(i).plannedItemID;
      PlannedItemDtls plannedItemDtls = plannedItemEntityObj.read(
        plannedItemKey);

      if (plannedItemDtls.concerningID == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPAAPPROVALREQUEST.ERR_PLANNED_ITEM_CONCERNING_NOT_PRESENT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // END CR00118860
  
    // notify owner
    notifyOwnerOfApproval(key);

    // BEGIN, CR00116772, ANK
    // Raise an workflow event upon approval of Service Plan based on the 
    // environment configuration 
    boolean raiseServicePlanApprovalEvent_default = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_RAISE_EVENT_ON_SERVICEPLAN_APPROVAL_DEFAULT);
    
    boolean raiseServicePlanApprovalEvent = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_RAISE_EVENT_ON_SERVICEPLAN_APPROVAL,
      raiseServicePlanApprovalEvent_default);    

    if (raiseServicePlanApprovalEvent) {
      
      // Service plans workflow raise event integration
      curam.util.events.struct.Event event = new curam.util.events.struct.Event();
      
      // BEGIN, CR00021588, TV
      // BEGIN,HARP 65061,SRK
      event.eventKey = curam.events.SERVICEPLANS.APPROVEPLAN;
      // END, HARP 65061
      // END, CR00021588
      event.primaryEventData = key.key.caseID;
      curam.util.events.impl.EventService.raiseEvent(event);    
    }
    // END, CR00116772
    
    // BEGIN CR00108818, GBA
    // Log Transaction Details
    if (key.key != null && key.key.caseID != 0) {

      // CaseHeader manipulation variable to get IntegratedCaseID
      curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      // Set the case header key
      caseHeaderKey.caseID = key.key.caseID;
      ReadIntegratedCaseIDAndParticipantDetails readIntegIDAndPartDtls = caseHeaderObj.readIntegratedCaseIDAndParticipantDetails(
        caseHeaderKey);

      // ConcernRole manipulation variables to get Case Member name
      ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      curam.core.struct.ConcernRoleKey concernRoleKeyObj = new curam.core.struct.ConcernRoleKey();

      concernRoleKeyObj.concernRoleID = readIntegIDAndPartDtls.concernRoleID;

      // ServicePlanDelivery manipulation variables
      curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
      curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servPlanDelKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

      servPlanDelKey.caseID = key.key.caseID;
      CodeTableItemIdentifier SPTypeCodeIdentifier = new CodeTableItemIdentifier(
        SERVICEPLANTYPE.TABLENAME, 
        servicePlanDeliveryObj.readServicePlanType(servPlanDelKey).servicePlanType);

      LocalisableString description = new LocalisableString(BPOCASEEVENTS.SERVICEPLAN_APPROVED).arg(SPTypeCodeIdentifier).arg(
        concernRoleObj.read(concernRoleKeyObj).concernRoleName);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.SERVICEPLAN_APPROVED, description,
        readIntegIDAndPartDtls.integratedCaseID, CuramConst.kDefaultRelatedID);
    }
    // END CR00108818
  }

  /**
   * Validates service plan details for approval.
   *
   * @param key
   * Contains service plan delivery unique ID.
   *
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_SERVICE_PLAN_NOT_SUBMITTED} - if
   * the service plan cannot be approved as the service plan status is
   * not submitted.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_NO_PLANNED_ITEM_EXISTS} - if the
   * service plan cannot be approved until a goal and at least one
   * sub-goal and plan item have been defined.
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_APPROVE_SECURITY_CHECK_FAILED} -
   * if the user does not have appropriate privileges to approve this
   * service plan.
   */
  public void validateApproveDetails(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387
    
    ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // CaseStatus manipulation variables
    curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    curam.core.struct.CurrentCaseStatusKey currentCaseStatusKey = new curam.core.struct.CurrentCaseStatusKey();

    // ServicePlanDelivery process class
    curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // PlannedItem entity
    curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // read service plan ID and case participant roleID
    ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = servicePlanDeliveryObj.readServicePlanIDAndConcernRoleID(
      key);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = servicePlanAndParticipantDetails.concernRoleID;

    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kApproveSecurityCheck;

    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanAndParticipantDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)
          || e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSPAPPROVALREQUEST.ERR_APPROVE_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // read current status
    currentCaseStatusKey.caseID = key.key.caseID;
    // BEGIN, CR00224271, ZV
    curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // END, CR00224271

    // service plan delivery must be submitted
    if (!caseStatusDtls.statusCode.equals(CASESTATUS.PLANSUBMITTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSPAPPROVALREQUEST.ERR_SERVICE_PLAN_NOT_SUBMITTED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // count planned items for the service plan delivery
    PlannedItemCountDetails plannedItemCountDetails = plannedItemObj.countByCaseID(
      key.key);

    // there must be at lest one planned item
    if (plannedItemCountDetails.recordCount == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSPAPPROVALREQUEST.ERR_NO_PLANNED_ITEM_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

  }

  /**
   * Part of submission process for a service plan. Creates service plan
   * approval request and approval request records for a specific service plan.
   *
   * @param key
   * Identifies the service plan delivery.
   *
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have maintenance rights for this case. Please contact
   * your security administrator.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   */
  public void submit(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // ServicePlanDelivery manipulation variables
    curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // ApprovalRequest manipulation variables
    curam.core.sl.entity.intf.ApprovalRequest approvalRequestObj = curam.core.sl.entity.fact.ApprovalRequestFactory.newInstance();
    curam.core.sl.entity.struct.ApprovalRequestDtls approvalRequestDtls = new curam.core.sl.entity.struct.ApprovalRequestDtls();

    // SPApprovalRequest entity manipulation variables
    curam.serviceplans.sl.entity.intf.SPApprovalRequest spApprovalRequestObj = curam.serviceplans.sl.entity.fact.SPApprovalRequestFactory.newInstance();
    curam.serviceplans.sl.entity.struct.SPApprovalRequestDtls spApprovalRequestDtls = new curam.serviceplans.sl.entity.struct.SPApprovalRequestDtls();

    ApprovalRequestIDCaseIDKey approvalRequestIDCaseIDKey = new ApprovalRequestIDCaseIDKey();
    SPApprovalRequestID spApprovalRequestID = new SPApprovalRequestID();

    // Baseline manipulation variables
    curam.serviceplans.sl.intf.Baseline baselineObj = curam.serviceplans.sl.fact.BaselineFactory.newInstance();
    curam.serviceplans.sl.struct.CreateBaselineDetails createBaselineDetails = new curam.serviceplans.sl.struct.CreateBaselineDetails();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387
    
    curam.serviceplans.sl.struct.ServicePlanSecurityKey spSecurityKey = new curam.serviceplans.sl.struct.ServicePlanSecurityKey();

    // MaintainCase manipulation variables
    curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
    // BEGIN, CR00220971, ZV
    CaseStatusAndEventTypeDetails1 caseStatusAndEventTypeDetails = new CaseStatusAndEventTypeDetails1();
    // END, CR00220971

    // BEGIN, CR00107061 MR
    
    // CaseUserRole manipulation variable
    curam.core.sl.entity.intf.CaseUserRole caseUserRoleObj = curam.core.sl.entity.fact.CaseUserRoleFactory.newInstance();

    // Service Plan Approval Checks and User Approval Checks variables
    ServicePlanApprovalCheck servicePlanApprovalCheckObj = ServicePlanApprovalCheckFactory.newInstance();
    ServicePlanApprovalCheckList serviceplanApprovalchecklist = new ServicePlanApprovalCheckList();
    ApprovalChecksList approvalChecksList = new  ApprovalChecksList();

    // ServicePlan entity manipulation variables
    curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();
    CurrentUserDetails currentUserDetails = new CurrentUserDetails();
    SPKey spkey = new SPKey();
    ServicePlanKey serviceplankey;
    ReadByCaseStatusTypeKey readByCaseStatusTypeKey = new ReadByCaseStatusTypeKey();
    curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = new curam.serviceplans.sl.entity.struct.ServicePlanKey();
    UserApprovalCheckSearchKey userApprovalCheckSearchKey = new UserApprovalCheckSearchKey();

    // END, CR00107061
    
    // validate submit details
    validateSubmitDetails(key);

    // does current user have approval rights for this service plan?
    spSecurityKey.securityCheckType = ServicePlanSecurity.kApproveSecurityCheck;
    spSecurityKey.servicePlanID = servicePlanDeliveryObj.readServicePlanID(key).key.servicePlanID;

    // BEGIN, CR00227859, PM
    // Security variables
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = key.key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    
    // current user approval rights indicator
    boolean approvalRightInd = true;
    
    // BEGIN, CR00107061 MR
    
    int percentageServiceplan = CuramConst.gkZero;
    int percentageUser = CuramConst.gkZero;
    // BEGIN, CR00238338, PF
    int kMaxPercentageValue = CuramConst.gkOneHundredPercent;
    // END, CR00238338
    String userRoleName = CuramConst.gkEmpty;
    String serviceplanOwner = CuramConst.gkEmpty;

    // END, CR00107061
    
    try {
      servicePlanSecurity.servicePlanSecurityCheck(spSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        approvalRightInd = false;
      } else {
        throw e;
      }
    }
    
    if (approvalRightInd == false) {

      // BEGIN, CR00081187, SPD
      // Create a manual task for the case supervisor

      // Initialize an event
      Event manuallyApproveSP = new Event();

      // Set event to be of type ApproveServicePlan
      manuallyApproveSP.eventKey = SERVICEPLANS.MANUALAPPROVESERVICEPLAN;

      // Populate data needed for workflow
      manuallyApproveSP.primaryEventData = key.key.caseID;

      // Trigger event to call workflow
      EventService.raiseEvent(manuallyApproveSP);
      // END, CR00081187
    }

    // indicates whether or not plan can be automatically approved
    boolean automaticallyApprovedInd = false;

    // decide whether to submit or automatically approve
  
    // BEGIN, CR00107061 MR
   
    // read Service Plan details
    ServicePlanDeliveryReadDetails servicePlanDeliveryDtls = new ServicePlanDeliveryReadDetails();
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.key.caseID = key.key.caseID;
    servicePlanDeliveryDtls = servicePlanDeliveryObj.read(
      servicePlanDeliveryKey);
    
    // Service Plan Owner
    serviceplanOwner = servicePlanDeliveryDtls.ownerDetails.userName;
    
    // for service plan approval check
    serviceplankey = servicePlanDeliveryObj.readServicePlanID(key);
    spkey.spKey.servicePlanID = serviceplankey.key.servicePlanID; 
    serviceplanApprovalchecklist = servicePlanApprovalCheckObj.listSPApprovalChecks(
      spkey);
    
    // Service Plan approval indicator
    boolean serviceplanApprovalCheck = false;
    
    // get the Service Plan percentage
    for (int i = 0; i < serviceplanApprovalchecklist.detailsList.dtls.size(); i++) {
      if (serviceplanApprovalchecklist.detailsList.dtls.item(i).statusCode.equalsIgnoreCase(
        RECORDSTATUS.NORMAL)) {
        percentageServiceplan = serviceplanApprovalchecklist.detailsList.dtls.item(i).percentage;
        serviceplanApprovalCheck = true;
      }
    }
    
    // for user approval checks
    userApprovalCheckSearchKey.searchKey.servicePlanID = serviceplankey.key.servicePlanID;
    userApprovalCheckSearchKey.searchKey.userName = servicePlanDeliveryDtls.ownerDetails.userName;
    approvalChecksList = servicePlanApprovalCheckObj.listUserApprovalChecks(
      userApprovalCheckSearchKey);
    
    // User approval indicator
    boolean userApprovalCheck = false;
    
    // get the user percentage
    for (int i = 0; i < approvalChecksList.approvalChecks.dtls.size(); i++) {
      if (approvalChecksList.approvalChecks.dtls.item(i).statusCode.equalsIgnoreCase(
        RECORDSTATUS.NORMAL)) {
        percentageUser = approvalChecksList.approvalChecks.dtls.item(i).percentage;
        userApprovalCheck = true;
      }
    }
    
    // read service plan supervisor details
    readByCaseStatusTypeKey.caseID = key.key.caseID;
    readByCaseStatusTypeKey.recordStatus = RECORDSTATUS.NORMAL;
    readByCaseStatusTypeKey.typeCode = CASEUSERROLETYPE.SUPERVISOR;
    
    // read the current case supervisor
    try {
      currentUserDetails = caseUserRoleObj.readActiveUserDetails(
        readByCaseStatusTypeKey);
    } catch (RecordNotFoundException rnfe) {// do nothing, as a case without a supervisor is a valid scenario
    }   
    userRoleName = currentUserDetails.userName;
    
    // set the key for reading security indicators
    servicePlanKey.servicePlanID = serviceplankey.key.servicePlanID;

    // read service plan security indicators
    ServicePlanSecurityIndicatorsDetails servicePlanSecurityIndicatorDetails = servicePlanObj.readSecurityIndicators(
      servicePlanKey);
 
    // Check Approve rights and Maintain rights, if specified in service plan 
    // admin, and the user has them, approve Service Plan. If the user does not 
    // have them, set status to Submitted. 
    if (servicePlanSecurityIndicatorDetails.approveRights.length() == 0
      || servicePlanSecurityIndicatorDetails.maintainRights.length() == 0) {
      // Perform check on whether user is supervisor of the case. 
      // If the user is a supervisor service plan status is automatically
      // approved. 

      if (approvalRightInd && serviceplanOwner.equalsIgnoreCase(userRoleName)) {
        automaticallyApprovedInd = true;
      } // If the user is not a supervisor Perform Approval Check record check.
      else if (approvalRightInd
        && !serviceplanOwner.equalsIgnoreCase(userRoleName)) {
       
        // If user approval check records found, based on the random number 
        // status is set to either Approved or Submitted. i.e user 
        // percentage is either in between 0-100.
        if (userApprovalCheck) {
          // set random number
          int randNum = new Double(Math.random() * kMaxPercentageValue).intValue();

          // set output parameter
          automaticallyApprovedInd = (percentageUser <= randNum);
        } // If Service Plan approval check records found, based on the   
        // random number status is set to either Approved or Submitted.  
        // i.e Service Plan percentage is either in between 0-100.
        else if (serviceplanApprovalCheck) {
          // set random number
          int randNum = new Double(Math.random() * kMaxPercentageValue).intValue();

          // set output parameter
          automaticallyApprovedInd = (percentageServiceplan <= randNum);
        }
      }
    } else  if (approvalRightInd) {
      automaticallyApprovedInd = true;
    }

    // END, CR00107061

    if (!automaticallyApprovedInd) {

      // read environment variable

      boolean createBaselineAutomatically_default = Configuration.getBooleanProperty(
        EnvVars.ENV_SERVICEPLANS_BASELINES_CREATE_AUTOMATICALLY_DEFAULT);

      boolean createBaselineAutomatically = Configuration.getBooleanProperty(
        EnvVars.ENV_SERVICEPLANS_BASELINES_CREATE_AUTOMATICALLY,
        createBaselineAutomatically_default);

      if (createBaselineAutomatically) {

        // create submission baseline
        createBaselineDetails.caseID = key.key.caseID;
        createBaselineDetails.typeCode = BASELINETYPE.APPROVALSUBMISSION;
        curam.serviceplans.sl.struct.BaselineIDDetails baselineIDDetails = baselineObj.create(
          createBaselineDetails);

        // create SPApprovalRequestDetails
        spApprovalRequestDtls.submitBaselineID = baselineIDDetails.baselineIDDetails.baseLineID;
      }

    }

    // create approval request details
    approvalRequestDtls.requestedByUser = curam.util.transaction.TransactionInfo.getProgramUser();
    approvalRequestDtls.requestedDate = curam.util.type.Date.getCurrentDate();
    approvalRequestDtls.status = APPROVALREQUESTSTATUS.SUBMITTED;

    // insert approval request
    approvalRequestObj.insert(approvalRequestDtls);

    // create service plan approval record
    spApprovalRequestDtls.caseID = key.key.caseID;
    spApprovalRequestDtls.approvalRequestID = approvalRequestDtls.approvalRequestID;

    // insert service plan approval request
    spApprovalRequestObj.insert(spApprovalRequestDtls);

    // set key to read SPApprovalRequestID
    approvalRequestIDCaseIDKey.approvalRequestID = approvalRequestDtls.approvalRequestID;
    approvalRequestIDCaseIDKey.caseID = key.key.caseID;

    // read SPApprovalRequestID in order to relate the submitted event
    // to the SPApprovalRequest details
    spApprovalRequestID = spApprovalRequestObj.readSPApprovalRequestIDByCaseIDApprovalRequestID(
      approvalRequestIDCaseIDKey);

    // populate input struct to create case status and event
    caseStatusAndEventTypeDetails.caseID = key.key.caseID;
    caseStatusAndEventTypeDetails.eventTypeCode = CASEEVENTTYPE.PLANSUBMITTED;
    caseStatusAndEventTypeDetails.statusCode = CASESTATUS.PLANSUBMITTED;

    // No reason required when submitting a service plan
    // BEGIN, CR00052924, GM
    caseStatusAndEventTypeDetails.reasonCode = CuramConst.gkEmpty;
    // END, CR00052924

    caseStatusAndEventTypeDetails.relatedID = spApprovalRequestID.servicePlanApprovalRequestID;

    // change case status to 'submitted' and create 'plan submitted' event
    // BEGIN, CR00220971, ZV
    maintainCaseObj.changeCaseStatus1(caseStatusAndEventTypeDetails);
    // END, CR00220971

    if (automaticallyApprovedInd) {

      // approve service plan
      approve(key);

    }

    // Service plans workflow raise event integration
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.SUBMITPLAN;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = key.key.caseID;

    curam.util.events.impl.EventService.raiseEvent(event);
    
    // BEGIN CR00108818, GBA
    // Log Transaction Details
    if (servicePlanDeliveryDtls != null) {

      // Get Service Plan Case Type 
      CodeTableItemIdentifier SPTypeCodeIdentifier = new CodeTableItemIdentifier(
        SERVICEPLANTYPE.TABLENAME, 
        servicePlanDeliveryDtls.servicePlanTypeStruct.servicePlanType);

      LocalisableString description = new LocalisableString(BPOCASEEVENTS.SERVICEPLAN_SUBMITTED).arg(
        SPTypeCodeIdentifier);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.SERVICEPLAN_SUBMITTED, description,
        servicePlanDeliveryDtls.participantCaseAndUserDetails.integratedCaseID,
        CuramConst.kDefaultRelatedID);
    }
    // END CR00108818

  }

  /**
   * Validates service plan details for submit for approval.
   *
   * @param key
   * Contains service plan delivery unique ID.
   *
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_SUBMIT_STATUS_CODE_CHECK_FAILED}
   * - if the service plan cannot be submitted for approval as it is
   * not in an open or approved state.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_NO_PLANNED_ITEM_EXISTS} - if the
   * service plan cannot be approved until a goal and at least one
   * sub-goal and plan item have been defined.
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_SUBMIT_SECURITY_CHECK_FAILED} -
   * if the user does not have appropriate privileges to submit this
   * service plan for approval.
   */
  public void validateSubmitDetails(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387
    
    ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // ServicePlanDelivery business object
    curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // CaseStatus manipulation variables
    curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    curam.core.struct.CurrentCaseStatusKey currentCaseStatusKey = new curam.core.struct.CurrentCaseStatusKey();

    // PlannedItem entity
    curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // read service plan ID and case participant roleID
    ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = servicePlanDeliveryObj.readServicePlanIDAndConcernRoleID(
      key);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = servicePlanAndParticipantDetails.concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanAndParticipantDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)
          || e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSPAPPROVALREQUEST.ERR_SUBMIT_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // read current status
    currentCaseStatusKey.caseID = key.key.caseID;
    // BEGIN, CR00224271, ZV
    curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // END, CR00224271

    // service plan delivery must be 'open' or 'approved'.
    if (!(caseStatusDtls.statusCode.equals(CASESTATUS.OPEN)
      || caseStatusDtls.statusCode.equals(CASESTATUS.APPROVED))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSPAPPROVALREQUEST.ERR_SUBMIT_STATUS_CODE_CHECK_FAILED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // count planned items for the service plan delivery
    PlannedItemCountDetails plannedItemCountDetails = plannedItemObj.countByCaseID(
      key.key);

    // There must be at lest one planned item.
    if (plannedItemCountDetails.recordCount == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSPAPPROVALREQUEST.ERR_NO_PLANNED_ITEM_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Rejects service plan delivery.
   *
   * @param details Contains service plan delivery unique ID and rejection
   * reason.
   */
  public void reject(ServicePlanDeliveryRejectDetails details)
    throws AppException, InformationalException {
    
    // BEGIN, CR00227859, PM
    // Security variables
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();    

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = details.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);
    
    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSPAPPROVALREQUEST.ERR_REJECT_SECURITY_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    // ApprovalRequest manipulation variables
    curam.core.sl.entity.intf.ApprovalRequest approvalRequestObj = curam.core.sl.entity.fact.ApprovalRequestFactory.newInstance();
    curam.core.sl.entity.struct.ModifyStatusRejectReasonAndCommentsDetails modifyStatusRejectReasonAndCommentsDetails = new curam.core.sl.entity.struct.ModifyStatusRejectReasonAndCommentsDetails();
    curam.core.sl.entity.struct.ApprovalRequestKey approvalRequestKey = new curam.core.sl.entity.struct.ApprovalRequestKey();
    curam.core.sl.entity.struct.ApprovalRequestIDAndVersionNoDetails approvalRequestIDAndVersionNoDetails;

    // SPApprovalRequest manipulation variables
    curam.serviceplans.sl.entity.intf.SPApprovalRequest spApprovalRequestObj = curam.serviceplans.sl.entity.fact.SPApprovalRequestFactory.newInstance();
    curam.serviceplans.sl.entity.struct.ApprovalRequestIDCaseIDKey approvalRequestIDCaseIDKey = new curam.serviceplans.sl.entity.struct.ApprovalRequestIDCaseIDKey();
    curam.serviceplans.sl.entity.struct.SPApprovalRequestID spApprovalRequestID = new curam.serviceplans.sl.entity.struct.SPApprovalRequestID();

    // Maintain Case business object
    curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
    // BEGIN, CR00220971, ZV
    CaseStatusAndEventTypeDetails1 caseStatusAndEventTypeDetails = new CaseStatusAndEventTypeDetails1();
    // END, CR00220971

    // Service plan delivery key
    curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.key.caseID = details.caseID;

    // validate details
    validateRejectDetails(details);

    // Set the key for reading Approval Request and SP Approval Request details
    curam.serviceplans.sl.entity.struct.CaseIDAndApprovalRequestStatusKey caseIDAndApprovalRequestStatusKey = new curam.serviceplans.sl.entity.struct.CaseIDAndApprovalRequestStatusKey();

    caseIDAndApprovalRequestStatusKey.caseID = details.caseID;
    caseIDAndApprovalRequestStatusKey.status = APPROVALREQUESTSTATUS.SUBMITTED;
    boolean approvalRequestFound = true;

    // read approval request ID and versionNo for modify
    try {
      approvalRequestIDAndVersionNoDetails = spApprovalRequestObj.readApprovalRequestIDAndVersionNoByCaseIDAndApprovalRequestStatus(
        caseIDAndApprovalRequestStatusKey);
    } catch (RecordNotFoundException e) {
      approvalRequestFound = false;
      approvalRequestIDAndVersionNoDetails = null;
    }

    // expect only one record
    if (approvalRequestFound) {

      // modify approval request - set status to 'rejected'.
      approvalRequestKey.approvalRequestID = approvalRequestIDAndVersionNoDetails.approvalRequestID;
      modifyStatusRejectReasonAndCommentsDetails.status = APPROVALREQUESTSTATUS.REJECTED;
      modifyStatusRejectReasonAndCommentsDetails.approvalDecisionDate = Date.getCurrentDate();
      modifyStatusRejectReasonAndCommentsDetails.approvalDecisionByUser = curam.util.transaction.TransactionInfo.getProgramUser();
      modifyStatusRejectReasonAndCommentsDetails.versionNo = approvalRequestIDAndVersionNoDetails.versionNo;
      modifyStatusRejectReasonAndCommentsDetails.rejectionComments = details.rejectionComments;
      modifyStatusRejectReasonAndCommentsDetails.rejectionReason = details.rejectionReason;

      approvalRequestObj.modifyStatusRejectionReasonAndComments(
        approvalRequestKey, modifyStatusRejectReasonAndCommentsDetails);

    }

    // set key to read SPApprovalRequestID
    approvalRequestIDCaseIDKey.approvalRequestID = approvalRequestIDAndVersionNoDetails.approvalRequestID;
    approvalRequestIDCaseIDKey.caseID = details.caseID;

    // read SPApprovalRequestID in order to relate the rejected event
    // to the SPApprovalRequest details
    spApprovalRequestID = spApprovalRequestObj.readSPApprovalRequestIDByCaseIDApprovalRequestID(
      approvalRequestIDCaseIDKey);

    // change case status to 'rejected'.
    caseStatusAndEventTypeDetails.caseID = details.caseID;
    caseStatusAndEventTypeDetails.eventTypeCode = CASEEVENTTYPE.PLANREJECTED;
    caseStatusAndEventTypeDetails.statusCode = CASESTATUS.OPEN;

    caseStatusAndEventTypeDetails.reasonCode = details.rejectionReason;

    // BEGIN, 49095, SPD
    caseStatusAndEventTypeDetails.relatedID = spApprovalRequestID.servicePlanApprovalRequestID;
    // END, 49095

    // BEGIN, CR00220971, ZV
    maintainCaseObj.changeCaseStatus1(caseStatusAndEventTypeDetails);
    // END, CR00220971

    // notify owner
    notifyOwnerOfRejection(servicePlanDeliveryKey);

    // Service plans workflow raise event integration
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.REJECTPLAN;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = servicePlanDeliveryKey.key.caseID;

    curam.util.events.impl.EventService.raiseEvent(event);
    
    // BEGIN CR00108818, GBA
    // Log Transaction Details
    if (details != null && details.caseID != 0) {

      // CaseHeader manipulation variable to get IntegratedCaseID
      curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
      CaseKey caseKey = new CaseKey();

      // Set the case header key
      caseKey.caseID = details.caseID;

      // ServicePlanDelivery manipulation variables
      curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
      curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servPlanDelKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

      servPlanDelKey.caseID = details.caseID;
      CodeTableItemIdentifier SPTypeCodeIdentifier = new CodeTableItemIdentifier(
        SERVICEPLANTYPE.TABLENAME, 
        servicePlanDeliveryObj.readServicePlanType(servPlanDelKey).servicePlanType);

      LocalisableString description = new LocalisableString(BPOCASEEVENTS.SERVICEPLAN_REJECTED).arg(
        SPTypeCodeIdentifier);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.SERVICEPLAN_REJECTED, description,
        caseHeaderObj.readIntegratedCaseIDByCaseID(caseKey).integratedCaseID, 
        CuramConst.kDefaultRelatedID);
    }
    // END CR00108818

  }

  /**
   * Validates service plan details for rejection.
   *
   * @param details
   * Contains service plan delivery unique ID and rejection reason.
   *
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_REJECT_SECURITY_CHECK_FAILED} -
   * if the user does not have appropriate privileges to reject this
   * service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_REJECT_SERVICE_PLAN_NOT_SUBMITTED}
   * - if the service plan cannot be rejected as the service plan
   * status is not submitted.
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_FV_REJECT_REASON_CODE_EMPTY} - if
   * the reject reason code is not specified.
   */
  public void validateRejectDetails(ServicePlanDeliveryRejectDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387
    
    ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // CaseStatus manipulation variables
    curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    curam.core.struct.CurrentCaseStatusKey currentCaseStatusKey = new curam.core.struct.CurrentCaseStatusKey();

    // ServicePlanDelivery business object
    curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    // ServicePlanDeliveryKey
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    if (details.rejectionReason.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSPAPPROVALREQUEST.ERR_FV_REJECT_REASON_CODE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    servicePlanDeliveryKey.key.caseID = details.caseID;

    // read service plan ID and case participant roleID
    ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = servicePlanDeliveryObj.readServicePlanIDAndConcernRoleID(
      servicePlanDeliveryKey);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = servicePlanAndParticipantDetails.concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kApproveSecurityCheck;
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanAndParticipantDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)
          || e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSPAPPROVALREQUEST.ERR_REJECT_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // read current status
    currentCaseStatusKey.caseID = details.caseID;
    // BEGIN, CR00224271, ZV
    curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // END, CR00224271

    // service plan delivery must be submitted
    if (!caseStatusDtls.statusCode.equals(CASESTATUS.PLANSUBMITTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSPAPPROVALREQUEST.ERR_REJECT_SERVICE_PLAN_NOT_SUBMITTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Reads approval request ID and version number
   *
   * @param key Service plan approval request unique identifier
   *
   * @return approval request ID and version number
   */
  public curam.serviceplans.sl.struct.RejectionDetailsForModify readDetailsForModify(SPApprovalRequestKey key)
    throws AppException, InformationalException {

    // return value
    curam.serviceplans.sl.struct.RejectionDetailsForModify rejectionDetailsForModify = new curam.serviceplans.sl.struct.RejectionDetailsForModify();

    // SPApprovalRequest entity object
    curam.serviceplans.sl.entity.intf.SPApprovalRequest spApprovalRequestObj = curam.serviceplans.sl.entity.fact.SPApprovalRequestFactory.newInstance();

    // call validation
    validateReadDetailsForModify(key);

    // read approval request details
    rejectionDetailsForModify.dtls = spApprovalRequestObj.readSPApprovalRequestDetailsForModify(
      key.spApprovalRequestKey);

    return rejectionDetailsForModify;
  }

  /**
   * On display validation for modify.
   *
   * @param key
   * Contains the Service plan approval request unique identifier.
   *
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_APPROVAL_NOT_REJECTED} - if this
   * approval request is modified. Only rejected approval requests may
   * be modified.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSPAPPROVALREQUEST#ERR_UPDATE_SERVICEPLAN_CHECK_FAILED}
   * - if the user does not have appropriate privileges to update this
   * approval request.
   */
  public void validateReadDetailsForModify(SPApprovalRequestKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387
    
    ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // ServicePlanDelivery manipulation variables
    curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();
    curam.serviceplans.sl.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.struct.ServicePlanDeliveryKey();

    // SPApprovalRequest entity object
    curam.serviceplans.sl.entity.intf.SPApprovalRequest spApprovalRequestObj = curam.serviceplans.sl.entity.fact.SPApprovalRequestFactory.newInstance();

    // set service plan delivery key
    servicePlanDeliveryKey.key.caseID = spApprovalRequestObj.read(key.spApprovalRequestKey).caseID;

    // read service plan ID and concern role ID
    ServicePlanAndParticipantDetails servicePlanAndParticipantDetails = servicePlanDeliveryObj.readServicePlanIDAndConcernRoleID(
      servicePlanDeliveryKey);

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = servicePlanAndParticipantDetails.concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanAndParticipantDetails.servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)
          || e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSPAPPROVALREQUEST.ERR_UPDATE_SERVICEPLAN_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // read approval check status
    ApprovalRequestStatusDetails approvalRequestStatusDetails = spApprovalRequestObj.readApprovalRequestStatus(
      key.spApprovalRequestKey);

    // approval must be rejected
    if (!approvalRequestStatusDetails.status.equals(
      APPROVALREQUESTSTATUS.REJECTED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSPAPPROVALREQUEST.ERR_APPROVAL_NOT_REJECTED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Sends a notification about service plan delivery approval to the owner.
   *
   * @param key Contains service plan delivery unique ID.
   */
  public void notifyOwnerOfApproval(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // CaseUserRole manipulation variables
    curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // Notification variables
    curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();

    // BEGIN, CR00074750, CM
    // check the environment variable
    String genSPApprovedTicket = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENSERVICEPLANAPPROVEDTICKET);

    // check that the variable has been populated, if not, use default variable
    if (genSPApprovedTicket == null) {

      genSPApprovedTicket = EnvVars.ENV_GENSERVICEPLANAPPROVEDTICKET_DEFAULT;
    }

    // check the notification environment variable when approving a service plan
    if (genSPApprovedTicket.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {

      return;
    }
    // END, CR00074750

    // BEGIN, CR00060051, PMD
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Set the case header key
    caseHeaderKey.caseID = key.key.caseID;

    // Set the user name key to be the current user
    UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // Check if the user is the owner of the case or part of
    // any organization object that owns the case
    OwnerInd isUserOwner = caseUserRoleObj.isUserCaseOwner(userNameKey,
      caseHeaderKey);

    // only create notification if current user is not a service plan delivery owner
    if (!isUserOwner.ownerInd) {

      curam.core.facade.struct.StandardManualTaskDtls standardManualTaskDtls = new curam.core.facade.struct.StandardManualTaskDtls();

      // Set Notification details
      standardManualTaskDtls.dtls.concerningDtls.caseID = key.key.caseID;

      AppException reasonText = new AppException(
        BPOSPAPPROVALREQUEST.INF_APPROVAL_APPROVEREASON);

      reasonText.arg(curam.util.type.Date.getCurrentDate());

      // BEGIN, CR00163659, CL
      standardManualTaskDtls.dtls.taskDtls.comments = reasonText.getMessage(
        TransactionInfo.getProgramLocale());
      // END, CR00163659
      standardManualTaskDtls.dtls.taskDtls.subject = // BEGIN, CR00163471, JC
        BPOSPAPPROVALREQUEST.INF_APPROVAL_APPROVESUBJECT.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC
      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = kServicePlanStandardTask;

      // BEGIN, CR00069238, MG
      standardManualTaskDtls.dtls.concerningDtls.caseID = key.key.caseID;

      // create notification
      notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
    }
    // END, CR00060051
  }

  // ___________________________________________________________________________
  /**
   * Sends a notification about service plan delivery rejection to the owner.
   *
   * @param key Contains service plan delivery unique ID.
   */
  public void notifyOwnerOfRejection(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // CaseUserRole manipulation variables
    curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // Notification variables
    curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();

    // BEGIN, CR00074750, CM
    // check the environment variable
    String genSPRejectedTicket = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENSERVICEPLANREJECTEDTICKET);

    // check that the variable has been populated, if not, use default variable
    if (genSPRejectedTicket == null) {

      genSPRejectedTicket = EnvVars.ENV_GENSERVICEPLANREJECTEDTICKET_DEFAULT;
    }

    // check the notification environment variable when rejecting
    // a service plan
    if (genSPRejectedTicket.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {

      return;
    }
    // END, CR00074750

    // BEGIN, CR00060051, PMD
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Set the case header key
    caseHeaderKey.caseID = key.key.caseID;

    // Set the user name key to be the current user
    UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // Check if the user is the owner of the case or part of
    // any organization object that owns the case
    OwnerInd isUserOwner = caseUserRoleObj.isUserCaseOwner(userNameKey,
      caseHeaderKey);

    // only create notification if current user is not a service plan delivery owner
    if (!isUserOwner.ownerInd) {

      curam.core.facade.struct.StandardManualTaskDtls standardManualTaskDtls = new curam.core.facade.struct.StandardManualTaskDtls();

      // Set Notification details
      standardManualTaskDtls.dtls.concerningDtls.caseID = key.key.caseID;

      AppException reasonText = new AppException(
        BPOSPAPPROVALREQUEST.INF_APPROVAL_REJECTEASON);

      reasonText.arg(curam.util.type.Date.getCurrentDate());

      // BEGIN, CR00163659, CL
      standardManualTaskDtls.dtls.taskDtls.comments = reasonText.getMessage(
        TransactionInfo.getProgramLocale());
      // END, CR00163659
      standardManualTaskDtls.dtls.taskDtls.subject = // BEGIN, CR00163471, JC
        BPOSPAPPROVALREQUEST.INF_APPROVAL_REJECTSUBJECT.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC
      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = kServicePlanStandardTask;

      notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
    }
    // END, CR00060051
  }

}
