/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;

import com.google.inject.Singleton;

import curam.serviceplans.sl.entity.fact.PlannedGoalFactory;
import curam.serviceplans.sl.entity.impl.PlannedGoalAdapter;
import curam.serviceplans.sl.entity.struct.PlannedGoalDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;

/**
 * Standard implementation of the {@link PlannedGoalDAO} interface.
 */
@Singleton
// BEGIN, CR00183334, PS
public class PlannedGoalDAOImpl extends
    StandardDAOImpl<PlannedGoal, PlannedGoalDtls> implements PlannedGoalDAO {
  // END, CR00183334
  private static final PlannedGoalAdapter plannedGoalAdapter = new PlannedGoalAdapter();

  private static final curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalEntity = PlannedGoalFactory
      .newInstance();

  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected PlannedGoalDAOImpl() {
    // END, CR00183334
    super(plannedGoalAdapter, PlannedGoal.class);
  }

  /**
   * {@inheritDoc}
   */
  public PlannedGoal readByServicePlanDelivery(
      final ServicePlanDelivery servicePlanDelivery) {

    // Set the key for the read
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
    servicePlanDeliveryKey.caseID = servicePlanDelivery.getID();

    // Read the planned goal details by case id
    try {
      return get(plannedGoalEntity.readIDByCaseID(servicePlanDeliveryKey).plannedGoalID);
    } catch (final curam.util.exception.RecordNotFoundException e) {
      return null;
    } catch (final curam.util.exception.AppException e) {
      throw new curam.util.exception.AppRuntimeException(e);
    } catch (final InformationalException e) {
      throw new curam.util.exception.AppRuntimeException(e);
    }
  }
}
