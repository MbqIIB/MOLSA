/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.facade.impl;

import curam.core.fact.UsersFactory;
import curam.core.intf.Users;
import curam.core.struct.UsersKey;
import curam.serviceplans.facade.struct.CancelServicePlanGroupApprovalCheckKey;
import curam.serviceplans.facade.struct.ServicePlanGroupApprovalCheckDetails;
import curam.serviceplans.facade.struct.ServicePlanGroupApprovalCheckDetailsList;
import curam.serviceplans.facade.struct.ServicePlanGroupApprovalCheckID;
import curam.serviceplans.facade.struct.ServicePlanGroupApprovalCheckUsernameID;
import curam.serviceplans.sl.fact.ServicePlanGroupApprovalCheckFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 *  Process class that implements the facade functionality for the
 *
 *  service plan group approval check.
 */
public class ServicePlanGroupApprovalCheck extends
    curam.serviceplans.facade.base.ServicePlanGroupApprovalCheck {

  //___________________________________________________________________________
  /**
   * Cancel a service plan group approval check.
   *
   * @param key
   *          Unique ID and versionNo of entry to delete
   *
   * @throws AppException, InformationalException
   */
  public void cancelServicePlanGroupApprovalCheck(
    final CancelServicePlanGroupApprovalCheckKey key)
    throws AppException, InformationalException {

    curam.serviceplans.sl.intf.ServicePlanGroupApprovalCheck spgAppCheckObj =
      ServicePlanGroupApprovalCheckFactory.newInstance();

    spgAppCheckObj.cancelServicePlanGroupApprovalCheck(key.key);
  }

  //___________________________________________________________________________
  /**
   * Create a new service plan group approval check entry.
   *
   * @param details
   *            Details used to create the entry
   *
   * @throws AppException, InformationalException
   */
  public void createServicePlanGroupApprovalCheck(
      ServicePlanGroupApprovalCheckDetails details) throws AppException,
      InformationalException {

    curam.serviceplans.sl.intf.ServicePlanGroupApprovalCheck spgAppCheckObj =
      ServicePlanGroupApprovalCheckFactory.newInstance();

    spgAppCheckObj.createServicePlanGroupApprovalCheck(details.details);
  }

  //___________________________________________________________________________
  /**
   * Modify and existing service plan group approval check entry.
   *
   * @param details
   *           Details used to modify the entry
   *
   * @throws AppException, InformationalException
   */
  public void modifyServicePlanGroupApprovalCheck(
      ServicePlanGroupApprovalCheckDetails details) throws AppException,
      InformationalException {

    curam.serviceplans.sl.intf.ServicePlanGroupApprovalCheck spgAppCheckObj =
      ServicePlanGroupApprovalCheckFactory.newInstance();

    spgAppCheckObj.modifyServicePlanGroupApprovalCheck(details.details);
  }

  //___________________________________________________________________________
  /**
   * Read a service plan group approval check entry.
   *
   * @param key
   *          Unique reference to the entry
   * @return ServicePlanGroupApprovalCheckDetails
   *          Details for the relevant service plan group approval check entry
   *
   * @throws AppException, InformationalException
   */
  public ServicePlanGroupApprovalCheckDetails
    readServicePlanGroupApprovalCheck(ServicePlanGroupApprovalCheckID key)
    throws AppException, InformationalException {

    curam.serviceplans.sl.intf.ServicePlanGroupApprovalCheck spgAppCheckObj =
      ServicePlanGroupApprovalCheckFactory.newInstance();

    ServicePlanGroupApprovalCheckDetails details =
      new ServicePlanGroupApprovalCheckDetails();

    details.details.assign(spgAppCheckObj
        .readServicePlanGroupApprovalCheck(key.key));
    details.contextDescription.contextDescription =
      getServicePlanGroupApprovalCheckContextDescription
      (details.details.dtls.userName);

    return details;
  }

  //___________________________________________________________________________
  /**
   * List all service plan group approval check entries for a given username.
   *
   * @param key
   *          Username to search against
   * @return ServicePlanGroupApprovalCheckDetailsList
   *          List of service plan group approval check records for the
   *          given username
   * @throws AppException, InformationalException
   *
   */
  public ServicePlanGroupApprovalCheckDetailsList
    listServicePlanGroupApprovalCheck(
    ServicePlanGroupApprovalCheckUsernameID key)
  throws AppException, InformationalException {

    curam.serviceplans.sl.intf.ServicePlanGroupApprovalCheck spgAppCheckObj =
      ServicePlanGroupApprovalCheckFactory.newInstance();

    ServicePlanGroupApprovalCheckDetailsList list =
      new ServicePlanGroupApprovalCheckDetailsList();

    list.detailList.assign(spgAppCheckObj
        .listServicePlanGroupApprovalChecks(key.key));

    list.contextDescription.contextDescription =
      getServicePlanGroupApprovalCheckContextDescription(key.key.userName);

    return list;
  }

  // __________________________________________________________________________
  /**
   * Reads service plan group approval check context description.
   *
   * @param strUserName
   *
   * @return String containing the context description
   *
   * @throws AppException, InformationalException
   *
   */
  protected String getServicePlanGroupApprovalCheckContextDescription(
      String strUserName) throws AppException, InformationalException {

    String contextDescription = null;

    // reading the user surname for context description
    Users usersObj = UsersFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    usersKey.userName = strUserName;

    contextDescription = usersObj.getFullName(usersKey).fullname;

    return contextDescription;
  }
}
