/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2006, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOPLANTEMPLATESUBGOAL;
import curam.serviceplans.sl.entity.fact.PlanTemplateFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory;
import curam.serviceplans.sl.entity.intf.PlanTemplate;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem;
import curam.serviceplans.sl.entity.struct.PlanTemplateAndSubGoalModifyDetails;
import curam.serviceplans.sl.entity.struct.PlanTemplateAndSubGoalReadDetails;
import curam.serviceplans.sl.entity.struct.PlanTemplateKey;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateStatus;
import curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalCount;
import curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalReadDetails;
import curam.serviceplans.sl.entity.struct.SubGoalAndPlanTemplateKey;
import curam.serviceplans.sl.entity.struct.TemplatePlanItemDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * The plan template sub goal links a sub goal to a plan template.
 */
public abstract class PlanTemplateSubGoal extends curam.serviceplans.sl.entity.base.PlanTemplateSubGoal {
  // ___________________________________________________________________________
  /**
   * Performs operations before inserting the plan template sub goal details
   *
   * @param details the plan template sub goal details
   */
  protected void preinsert(PlanTemplateSubGoalDtls details)
    throws AppException, InformationalException {

    // validate details
    validateInsert(details);
  }

  // ___________________________________________________________________________
  /**
   * Performs operations before canceling the plan template sub goal
   *
   * @param key the plan template sub goal key
   */
  protected void preremove(PlanTemplateSubGoalKey key)
    throws AppException, InformationalException {

    // validate
    validateCancel(key);
  }

  // ___________________________________________________________________________
  /**
   * Validate the details for insert
   *
   * @param details the plan template sub goal details
   */
  public void validateInsert(PlanTemplateSubGoalDtls details)
    throws AppException, InformationalException {

    // Plan Template key and entity object
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    // Sub Goal and Plan Template Sub Goal key
    SubGoalAndPlanTemplateKey subGoalAndPlanTemplateKey = new SubGoalAndPlanTemplateKey();

    // sub goal ID must not be blank
    if (details.subGoalID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATESUBGOAL.ERR_FV_SUBGOAL_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // set keys
    subGoalAndPlanTemplateKey.subGoalID = details.subGoalID;
    subGoalAndPlanTemplateKey.planTemplateID = details.planTemplateID;
    planTemplateKey.planTemplateID = details.planTemplateID;

    // check if plan template is canceled
    PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatus(
      planTemplateKey);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATESUBGOAL.ERR_PT_SUBGOAL_ADD_TO_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validate the details for cancel
   *
   * @param key the plan template sub goal key
   */
  public void validateCancel(PlanTemplateSubGoalKey key)
    throws AppException, InformationalException {

    // Plan Template PlanItem entity object
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem planTemplatePlanItemObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory.newInstance();

    // Plan Template entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    // check if plan template is canceled
    PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatusByPlanTemplateSubGoalID(
      key);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATESUBGOAL.ERR_PT_SUBGOAL_DELETE_FROM_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00000028, PMD
    // Check if there are any associated plan items, if so remove them
    TemplatePlanItemDetailsList templatePlanItemDetailsList = planTemplatePlanItemObj.searchByPlanTemplateSubGoalID(
      key);

    for (int i = 0; i < templatePlanItemDetailsList.dtls.size(); i++) {

      PlanTemplatePlanItemKey planTemplatePlanItemKey = new PlanTemplatePlanItemKey();

      planTemplatePlanItemKey.planTemplatePlanItemID = templatePlanItemDetailsList.dtls.item(i).planTemplatePlanItemID;

      planTemplatePlanItemObj.remove(planTemplatePlanItemKey);
    }
    // END, CR00000028

  }

  // ___________________________________________________________________________

  // BEGIN, CR00233815, GP
  /**
   * Validate the details for modify
   *
   * @param details the plan template sub goal details
   * @deprecated Since Curam 6.0, replaced with {@link PlanTemplateSubGoal#
   * validateModify(PlanTemplateSubGoalKey,PlanTemplateAndSubGoalModifyDetails)}.
   * as part of implementing localization for PlanTemplateSubGoal description.
   * See release note CR00233815.
   */
  @Deprecated
  // END, CR00233815
  // BEGIN, CR00000038, CSH
  public void validateModify(curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalModifyDetails details, PlanTemplateSubGoalKey key)
    throws AppException, InformationalException {

    // Plan Template key and entity object
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    // Plan Template Plan Item entity object
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem planTemplatePlanItemObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory.newInstance();

    // Sub Goal and Plan Template Sub Goal key
    SubGoalAndPlanTemplateKey subGoalAndPlanTemplateKey = new SubGoalAndPlanTemplateKey();

    // sub goal ID must not be blank
    if (details.subGoalID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATESUBGOAL.ERR_FV_SUBGOAL_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // set keys
    subGoalAndPlanTemplateKey.subGoalID = details.subGoalID;
    subGoalAndPlanTemplateKey.planTemplateID = details.planTemplateID;
    planTemplateKey.planTemplateID = details.planTemplateID;

    // check if plan template is canceled
    PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatus(
      planTemplateKey);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATESUBGOAL.ERR_PT_SUBGOAL_ADD_TO_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Read sub-goal details
    PlanTemplateSubGoalReadDetails planTemplateSubGoalReadDetails = readDetails(
      key);

    // If sub-goal is modified, the new sub-goal must not already be assigned to template
    if (planTemplateSubGoalReadDetails.subGoalID != details.subGoalID) {

      // check if the sub goal is already assigned to the plan
      PlanTemplateSubGoalCount planTemplateSubGoalCount = countForSubGoalIDAndTemplateID(
        subGoalAndPlanTemplateKey);

      if (planTemplateSubGoalCount.count > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANTEMPLATESUBGOAL.ERR_XFV_PLANTEMPLATE_SUBGOAL_EXISTS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      // sub goal cannot be modified if plan items have been added
      if (planTemplatePlanItemObj.countForPlanTemplateSubGoalID(key).count > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANTEMPLATESUBGOAL.ERR_CANNOT_MODIFY_AS_PLAN_ITEM_EXISTS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }
    }
  }

  // BEGIN, CR00228796, GP
  /**
   * Validate the details to modify a PlanTemplate SubGoal.
   *
   * @param contains the details the plan template sub goal details.
   * @param key contains the key holding details of which plan template
   * subgoal to be modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException
   * {@link BPOPLANTEMPLATESUBGOAL#ERR_FV_SUBGOAL_BLANK
   * ERR_FV_SUBGOAL_BLANK} - if subgoal ID is empty.
   *
   * {@link BPOPLANTEMPLATESUBGOAL#ERR_PT_SUBGOAL_ADD_TO_CANCELED_TEMPLATE
   * ERR_PT_SUBGOAL_ADD_TO_CANCELED_TEMPLATE} - if plan template is
   * canceled.
   *
   * {@link BPOPLANTEMPLATESUBGOAL#ERR_XFV_PLANTEMPLATE_SUBGOAL_EXISTS
   * ERR_XFV_PLANTEMPLATE_SUBGOAL_EXISTS} - if the sub goal is already
   * assigned to the plan sub goal.
   *
   * {@link BPOPLANTEMPLATESUBGOAL#ERR_CANNOT_MODIFY_AS_PLAN_ITEM_EXISTS
   * ERR_CANNOT_MODIFY_AS_PLAN_ITEM_EXISTS} - if plan items have been
   * added.
   */
  public void validateModify(PlanTemplateSubGoalKey key,
    PlanTemplateAndSubGoalModifyDetails details) throws AppException,
      InformationalException {

    PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    PlanTemplatePlanItem planTemplatePlanItemObj = PlanTemplatePlanItemFactory.newInstance();

    SubGoalAndPlanTemplateKey subGoalAndPlanTemplateKey = new SubGoalAndPlanTemplateKey();

    // Sub goal ID must not be blank.
    if (0 == details.subGoalID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATESUBGOAL.ERR_FV_SUBGOAL_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    subGoalAndPlanTemplateKey.subGoalID = details.subGoalID;
    subGoalAndPlanTemplateKey.planTemplateID = details.planTemplateID;
    planTemplateKey.planTemplateID = details.planTemplateID;

    // Check if plan template is canceled.
    PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatus(
      planTemplateKey);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATESUBGOAL.ERR_PT_SUBGOAL_ADD_TO_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    // BEGIN, CR00233815, GP
    PlanTemplateAndSubGoalReadDetails planTemplateSubGoalReadDetails = readTemplateSubGoalDetails(
      key);

    // END, CR00233815

    // If sub-goal is modified, the new sub-goal must not already be assigned to
    // template.
    if (planTemplateSubGoalReadDetails.subGoalID != details.subGoalID) {

      // Check if the sub goal is already assigned to the plan.
      PlanTemplateSubGoalCount planTemplateSubGoalCount = countForSubGoalIDAndTemplateID(
        subGoalAndPlanTemplateKey);

      if (0 != planTemplateSubGoalCount.count) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANTEMPLATESUBGOAL.ERR_XFV_PLANTEMPLATE_SUBGOAL_EXISTS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }

      // Sub goal cannot be modified if plan items have been added.
      if (0 != planTemplatePlanItemObj.countForPlanTemplateSubGoalID(key).count) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANTEMPLATESUBGOAL.ERR_CANNOT_MODIFY_AS_PLAN_ITEM_EXISTS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
  }

  // END, CR00228796

  // ___________________________________________________________________________

  // BEGIN, CR00233815, GP
  /**
   * Performs operations before modifying the plan template sub goal
   *
   * @param key the plan template sub goal key
   * @param details the plan template sub goal details
   *
   * @deprecated Since Curam 6.0, replaced with {@link PlanTemplateSubGoal#
   * premodifyPlanTemplateSubGoalDetails(PlanTemplateSubGoalKey,PlanTemplateAndSubGoalModifyDetails)}.
   * as part of implementing localization for PlanTemplateSubGoal description.
   * See release note CR00233815.
   */
  @Deprecated
  // END, CR00233815
  protected void premodifyDetails(PlanTemplateSubGoalKey key, curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalModifyDetails details)
    throws AppException, InformationalException {

    // validate modification details
    validateModify(details, key);

  }

  // END, CR00000038

  // BEGIN, CR00228796, GP
  /**
   * Performs validations before modifying the plan template sub goal.
   *
   * @param key contains the plan template sub goal key.
   * @param details contains the plan template sub goal details.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */

  protected void premodifyPlanTemplateSubGoalDetails(PlanTemplateSubGoalKey key,
    PlanTemplateAndSubGoalModifyDetails details) throws AppException,
      InformationalException {

    validateModify(key, details);

  }
  // END, CR00228796
}
