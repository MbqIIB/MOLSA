/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.OUTCOMEACHIEVEDEntry;
import curam.util.persistence.StandardEntity;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateRange;


/**
 * Wrapper interface for the
 * {@link curam.serviceplans.sl.entity.intf.PlannedGoal} entity.
 */
// BEGIN, CR00309529, POH
@ImplementedBy(PlannedGoalImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface PlannedGoal extends StandardEntity {
  // END, CR00309529, POH

  /**
   * Retrieves the User entered remarks about the planned goal.
   *
   * @return The planned goal comments.
   */
  String getComments();

  /**
   * Retrieves the date range for when the goal is expected to start and finish.
   *
   * @return The expected date range values.
   */
  DateRange getExpectedDateRange();

  /**
   * Retrieves the date range for when the goal actually started and finished.
   *
   * @return The actual date range values.
   */
  DateRange getActualDateRange();

  /**
   * Retrieves the outcome result for the goal. This is determined by the user
   * based on whether the sub-goals added to the goal were enough to satisfy the
   * goal.
   *
   * @return The outcome achieved code table entry value.
   */
  OUTCOMEACHIEVEDEntry getOutcomeAchieved();

  /**
   * Retrieves the {@link ServicePlanDelivery} details that the planned goal
   * record relates to.
   *
   * @return The linked service plan delivery details.
   */
  ServicePlanDelivery getPlanDelivery();

  /**
   * Retrieves the {@link Goal} details for the planned goal record.
   *
   * @return The goal details.
   */
  Goal getGoal();

  /**
   * Retrieves an immutable list of active planned sub goals for the planned
   * goal.
   *
   * @return An immutable list of active planned sub goals that
   */
  List<PlannedSubGoal> listActivePlannedSubGoals();
}
