/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.codetable.PLANITEMAPPROVALCHECK;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SERVICEPLANGROUPAPPROVALCHECK;
import curam.core.impl.CuramConst;
import curam.message.BPOSERVICEPLANGROUPAPPROVALCHECK;
import curam.serviceplans.sl.entity.fact.ServicePlanGroupFactory;
import curam.serviceplans.sl.entity.intf.ServicePlanGroup;
import curam.serviceplans.sl.entity.struct.CancelServicePlanGroupApprovalCheckDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupApprovalCheckCount;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupApprovalCheckDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupApprovalCheckKey;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupApprovalCheckStatusDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupApprovalCheckUNKey;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupApprovalCheckUNModifyKey;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Implements the methods from the Service PlanGroup ApprovalCheck entity.
 */
public class ServicePlanGroupApprovalCheck extends curam.serviceplans.sl.entity.base.ServicePlanGroupApprovalCheck {

  /**
   * Ensures validations are done before data modification for Service Plan
   * Group Approval Check.
   *
   * @param key approval check key
   * @param details approval check details
   *
   * @throws AppException, InformationalException
   */
  protected void precancel(final ServicePlanGroupApprovalCheckKey key,
    final CancelServicePlanGroupApprovalCheckDetails details)
    throws AppException, InformationalException {

    validateCancel(key);
  }

  /**
   * Ensures validations are done before data insertion for Service Plan
   * Group Approval Check
   *
   * @param details approval check details
   *
   * @throws AppException, InformationalException
   */
  protected void preinsert(ServicePlanGroupApprovalCheckDtls details)
    throws AppException, InformationalException {

    // setting type code if all service plan types is selected
    if (details.appliesToAllInd) {
      if (details.userName.length() > 0) {
        details.typeCode = SERVICEPLANGROUPAPPROVALCHECK.USER;
      }
      if (details.organisationUnitID != 0) {
        details.typeCode = SERVICEPLANGROUPAPPROVALCHECK.ORG_UNIT;
      }
    } else {
      // setting the typceCode  when a specific service plan is selected
      if (details.userName.length() > 0) {
        details.typeCode = SERVICEPLANGROUPAPPROVALCHECK.USER;
      }
      if (details.organisationUnitID != 0) {
        details.typeCode = SERVICEPLANGROUPAPPROVALCHECK.ORG_UNIT;
      }
      if ((details.userName.length() == 0) && (details.organisationUnitID == 0)) {
        details.typeCode = SERVICEPLANGROUPAPPROVALCHECK.SERVICE_PLAN_GROUP;
      }
    }

    // set record status to normal
    details.statusCode = RECORDSTATUS.NORMAL;

    // Check the details
    validateDetails(details);

    // Check the insert
    validateInsert(details);
  }

  /**
   * Ensures validations are done before data modification for Service Plan
   * Group Approval Check
   *
   * @param key approval check key data
   *
   * @param details approval check details
   * @throws AppException, InformationalException
   */
  protected void premodify(ServicePlanGroupApprovalCheckKey key,
    ServicePlanGroupApprovalCheckDtls details) throws AppException,
      InformationalException {

    validateDetails(details);

    validateModify(key, details);
  }

  /**
   * Ensures validations are done before canceling the entry for Service Plan
   * Group Approval Check
   *
   * @param details approval check details
   * @param key approval check key data
   *
   * @throws AppException, InformationalException
   */
  protected void validateCancel(ServicePlanGroupApprovalCheckKey key)
    throws AppException, InformationalException {
    // Read record status

    ServicePlanGroupApprovalCheckStatusDetails approvalCheckStatusDetails = new ServicePlanGroupApprovalCheckStatusDetails();

    approvalCheckStatusDetails = this.readStatus(key);

    if (approvalCheckStatusDetails.statusCode.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANGROUPAPPROVALCHECK.ERR_APPROVALCHECK_FV_CANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  /**
   * Ensures common validations are done before inserting and modifying data
   * for Service Plan Group Approval Check
   *
   * @param details approval check details
   *
   * @throws AppException, InformationalException
   */

  protected void validateDetails(ServicePlanGroupApprovalCheckDtls details)
    throws AppException, InformationalException {
    
    // BEGIN, CR00238338, PF
    // Percentage must be greater than zero & must not be
    // greater than one hundred.
    if ((details.percentage < 0)
      || (details.percentage > CuramConst.gkOneHundredPercent)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANGROUPAPPROVALCHECK.ERR_APPROVALCHECK_FV_PERCENTAGE_NOT_IN_RANGE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00238338
    
    // Estimated cost cannot be negative.
    if (details.estimatedCost.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANGROUPAPPROVALCHECK.ERR_APPROVALCHECK_FV_ESTIMATED_COST_NEGATIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (!details.appliesToAllInd && details.servicePlanGroupID != 0) {
      ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();
      ServicePlanGroupKey spgKey = new ServicePlanGroupKey();

      spgKey.servicePlanGroupId = details.servicePlanGroupID;
      ServicePlanGroupDtls spgDtls = servicePlanGroupObj.read(spgKey);

      if (spgDtls.servicePlanGroupStatus.equals(RECORDSTATUS.CANCELLED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANGROUPAPPROVALCHECK.ERR_APPROVALCHECK_XRV_SERVICEPLANGROUP_CANCELED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

  }

  /**
   * Ensures common validations are done before inserting  data
   * for Service Plan Group Approval Check
   *
   * @param details approval check details
   *
   * @throws AppException, InformationalException
   */

  protected void validateInsert(ServicePlanGroupApprovalCheckDtls details)
    throws AppException, InformationalException {

    // struct for duplicate approval checks
    ServicePlanGroupApprovalCheckCount approvalCheckCount = new ServicePlanGroupApprovalCheckCount();

    // validate user type plan item approval checks
    if (details.typeCode.equals(PLANITEMAPPROVALCHECK.USER)) {
      // set key details
      ServicePlanGroupApprovalCheckUNKey unameKey = new
        ServicePlanGroupApprovalCheckUNKey();

      unameKey.estimatedCost = details.estimatedCost;
      unameKey.servicePlanGroupID = details.servicePlanGroupID;
      unameKey.userName = details.userName;
      unameKey.statusCode = details.statusCode;

      // if all types selected
      if (details.servicePlanGroupID == 0) {
        approvalCheckCount = this.countByUsernameAllTypes(unameKey);
      } else { // if a particular service plan is selected
        approvalCheckCount = this.countByUsername(unameKey);
      }
      // must select either service plan or applies to all
      if ((details.appliesToAllInd == false)
        && (details.servicePlanGroupID == 0)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANGROUPAPPROVALCHECK.ERR_APPROVALCHECK_XFV_SELECT_SERVICEPLAN),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      // if service plan is selected, selecting all types is not permitted
      if ((details.appliesToAllInd) && (details.servicePlanGroupID != 0)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANGROUPAPPROVALCHECK.ERR_APPROVALCHECK_XFV_SELECT_APPLIESTOALLIND),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
    // checking for duplicate approval checks
    if (approvalCheckCount.recordCount != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANGROUPAPPROVALCHECK.ERR_APPROVALCHECK_FV_TYPE_ACTIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  /**
   * Ensures common validations are done before modifying  data
   * for Service Plan Group Approval Check
   *
   * @param ServicePlanGroupApprovalCheckKey  Service Plan Approval Check key
   * value passed to get the status of the approval check details.
   *
   * @param details approval check details
   *
   * @throws AppException, InformationalException
   */
  protected void validateModify(ServicePlanGroupApprovalCheckKey key,
    ServicePlanGroupApprovalCheckDtls details)
    throws AppException, InformationalException {

    ServicePlanGroupApprovalCheckStatusDetails approvalCheckStatusDetails = new ServicePlanGroupApprovalCheckStatusDetails();

    approvalCheckStatusDetails = this.readStatus(key);

    if (approvalCheckStatusDetails.statusCode.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANGROUPAPPROVALCHECK.ERR_APPROVALCHECK_RV_CANCELED_NO_MODIFY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // struct to check for duplicate approval checks
    ServicePlanGroupApprovalCheckCount approvalCheckCount = new ServicePlanGroupApprovalCheckCount();

    // validate user type service plan approval checks
    if (details.typeCode.equals(PLANITEMAPPROVALCHECK.USER)) {
      // set key details
      ServicePlanGroupApprovalCheckUNModifyKey unameModifyKey = new
        ServicePlanGroupApprovalCheckUNModifyKey();

      unameModifyKey.estimatedCost = details.estimatedCost;
      unameModifyKey.servicePlanGroupID = details.servicePlanGroupID;
      unameModifyKey.userName = details.userName;
      unameModifyKey.statusCode = details.statusCode;
      unameModifyKey.servicePlanGroupApprovalChkID = details.servicePlanGroupApprovalChkID;

      if (details.servicePlanGroupID == 0) {
        approvalCheckCount = this.countByUsernameAllTypesForModify(
          unameModifyKey);
      } else {
        approvalCheckCount = this.countByUsernameForModify(unameModifyKey);
      }
      // select service plan or applies to all
      if ((details.appliesToAllInd == false)
        && (details.servicePlanGroupID == 0)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOSERVICEPLANGROUPAPPROVALCHECK.ERR_APPROVALCHECK_XFV_SELECT_SERVICEPLAN),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }
    }
    // checking for duplicate approval checks
    if (approvalCheckCount.recordCount != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANGROUPAPPROVALCHECK.ERR_APPROVALCHECK_FV_TYPE_ACTIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

  }

}
