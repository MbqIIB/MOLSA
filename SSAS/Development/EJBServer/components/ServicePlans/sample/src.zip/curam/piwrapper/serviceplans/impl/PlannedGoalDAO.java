/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import com.google.inject.ImplementedBy;

import curam.util.persistence.ReaderDAO;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * Read only data access wrapper for the
 * {@link curam.serviceplans.sl.entity.intf.PlannedGoal} entity.
 */
// BEGIN, CR00351232, VT
// BEGIN, CR00309529, POH
@ImplementedBy(PlannedGoalDAOImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface PlannedGoalDAO extends ReaderDAO<Long, PlannedGoal> {
  // END, CR00309529
  /**
   * Retrieves the planned goal details linked to a service plan delivery.
   *
   * @param servicePlanDelivery
   * The service plan delivery to find the planned goal for.
   * @return The planned goal linked to the service plan delivery, or null if
   * one is not linked.
   */
  public PlannedGoal readByServicePlanDelivery(ServicePlanDelivery servicePlanDelivery);
  // END, CR00351232
}
