/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.goodcause.impl;

import java.util.Set;

import com.google.inject.Singleton;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.serviceplans.sl.entity.impl.GoodCauseLinkAdapter;
import curam.serviceplans.sl.entity.struct.GoodCauseDtlsList;
import curam.serviceplans.sl.entity.struct.GoodCauseKey;
import curam.serviceplans.sl.entity.struct.GoodCauseLinkDtls;
import curam.serviceplans.sl.entity.struct.RelatedReferenceKey;
import curam.serviceplans.sl.entity.struct.SearchGoodCauseKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;

/**
 * Standard implementation of {@linkplain curam.goodcause.impl.GoodCauseLinkDAO}.
 */
@Singleton
// BEGIN, CR00183334, PS
public class GoodCauseLinkDAOImpl extends
    StandardDAOImpl<GoodCauseLink, GoodCauseLinkDtls> implements
    GoodCauseLinkDAO {
  // END, CR00183334
  /**
   * Instance of Good Cause Link adapter.
   */
  private static final GoodCauseLinkAdapter goodCauseLinkAdapter = new GoodCauseLinkAdapter();

  /**
   * Constructor for the class.
   */
  // BEGIN, CR00183334, PS
  protected GoodCauseLinkDAOImpl() {
    // END, CR00183334
    super(goodCauseLinkAdapter, GoodCauseLink.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<GoodCauseLink> searchByGoodCause(GoodCauseKey goodCauseKey) {

    return newSet(goodCauseLinkAdapter
        .searchByGoodCause(goodCauseKey.goodCauseID));
  }

  /**
   * {@inheritDoc}
   */
  public Set<GoodCauseLink> searchByRelatedReference(
      RelatedReferenceKey relatedReferenceKey) {

    return newSet(goodCauseLinkAdapter
        .searchByRelatedReference(relatedReferenceKey.relatedID));
  }

  /**
   * {@inheritDoc}
   */
  public GoodCauseDtlsList searchUnassociatedGoodCausesForRelatedReference(
      Long relatedReferenceID, RECORDSTATUSEntry recordStatus)
      throws AppException, InformationalException {

    curam.serviceplans.sl.entity.intf.GoodCauseLink goodCauseLinkObj = curam.serviceplans.sl.entity.fact.GoodCauseLinkFactory
        .newInstance();

    SearchGoodCauseKey searchGoodCauseKey = new SearchGoodCauseKey();
    searchGoodCauseKey.relatedID = relatedReferenceID;
    searchGoodCauseKey.goodCauseStatus = recordStatus.getCode();

    return goodCauseLinkObj.searchUnassociatedGoodCauses(searchGoodCauseKey);
  }
}
