/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.facade.impl;


import curam.serviceplans.facade.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.facade.intf.ServicePlanDelivery;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetails;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetailsList;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetailsList1;
import curam.serviceplans.facade.struct.SPGDeliveryNoteKey;
import curam.serviceplans.facade.struct.ServicePlanGroupDeliveryKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryNoteLinkKey;
import curam.serviceplans.sl.fact.MaintainSPGDeliveryNoteFactory;
import curam.serviceplans.sl.intf.MaintainSPGDeliveryNote;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This API is used to maintain the notes for service plan group delivery.
 */
public class SPGDeliveryNote extends
  curam.serviceplans.facade.base.SPGDeliveryNote {

  /**
   * This method is used to create note for service plan group delivery.
   *
   * @param noteDetails
   *           has the details of the note which need to be recorded
   * @return SPGDeliveryAttachmentLinkKey
   *           has the id of the attachment link key which gets created
   * @throws AppException, InformationalException
   */
  public SPGDeliveryNoteLinkKey createNote(
      final SPGDeliveryNoteDetails noteDetails)
    throws AppException, InformationalException {

    MaintainSPGDeliveryNote maintainSPGDeliveryNoteObj =
      MaintainSPGDeliveryNoteFactory.newInstance();

    SPGDeliveryNoteLinkKey SPGDeliveryNoteLinkKey =
      maintainSPGDeliveryNoteObj.createNote(noteDetails);

    return SPGDeliveryNoteLinkKey;
  }

  // BEGIN, CR00240923 PDN
  /**
   * This method is used to list all the notes for service plan group delivery.
   * @deprecated - replaced by {@link #listNotesByGroupDeliveryID()}
   * @deprecated-since Version 6.0
   *
   * @param key
   *          id of the service plan group delivery key
   * @return SPGDeliveryNoteDetailsList
   *          list of service plan group delivery key details.
   * @throws AppException, InformationalException
   */
  public SPGDeliveryNoteDetailsList listNotesByGroupDeliveryID(
      SPGDeliveryKey key)
    throws AppException, InformationalException {
    
    SPGDeliveryNoteDetailsList spgDeliveryNoteDetailsList = 
      new SPGDeliveryNoteDetailsList();

    SPGDeliveryNoteDetailsList1 spgDeliveryNoteDetailsList1 = 
      listNotesByGroupDeliveryID1(key);
    
    spgDeliveryNoteDetailsList.assign(spgDeliveryNoteDetailsList1);

    return spgDeliveryNoteDetailsList;
  }
  
  /**
   * This method is used to list all the notes for service plan group delivery.
   *
   * @param key
   *          id of the service plan group delivery key
   * @return SPGDeliveryNoteDetailsList
   *          list of service plan group delivery key details.
   * @throws AppException, InformationalException
   */
  public SPGDeliveryNoteDetailsList1 listNotesByGroupDeliveryID1(
      SPGDeliveryKey key)
    throws AppException, InformationalException {

    MaintainSPGDeliveryNote maintainSPGDeliveryNoteObj =
      MaintainSPGDeliveryNoteFactory.newInstance();

    SPGDeliveryNoteDetailsList1 spgDeliveryNoteDetailsList =
      maintainSPGDeliveryNoteObj.listNotesByGroupDeliveryID1(key);

    // Create the objects for menu and context description
    ServicePlanDelivery servicePlanDeliveryObj
      = ServicePlanDeliveryFactory.newInstance();

    ServicePlanGroupDeliveryKey servicePlanGroupDeliveryKey
      = new ServicePlanGroupDeliveryKey();

    servicePlanGroupDeliveryKey.servicePlanGroupDeliveryID
      = key.servicePlanGroupDeliveryId;

    // Get the menu data
    spgDeliveryNoteDetailsList.menuData =
    servicePlanDeliveryObj.getICServicePlanGroupMenuData(
      servicePlanGroupDeliveryKey);

    // Get the context description
    spgDeliveryNoteDetailsList.contextDescription =
    servicePlanDeliveryObj.getServicePlanGroupContextDescription(
      servicePlanGroupDeliveryKey);

    return spgDeliveryNoteDetailsList;
  }  
  // END, CR00240923

  /**
   * This method is used to modify the notes for service plan group delivery.
   *
   * @param noteDetails
   *           modified note details
   * @throws AppException, InformationalException
   */
  public void modifyNote(SPGDeliveryNoteDetails noteDetails)
    throws AppException, InformationalException {

    MaintainSPGDeliveryNote maintainSPGDeliveryNoteObj =
      MaintainSPGDeliveryNoteFactory.newInstance();

    maintainSPGDeliveryNoteObj.modifyNote(noteDetails);
  }

  /**
   * This method is used to remove the notes for service plan group delivery.
   *
   * @param noteDetails
   *           details of the note to be removed
   * @throws AppException, InformationalException
   */
  public void removeNote(SPGDeliveryNoteDetails noteDetails)
    throws AppException, InformationalException {

    MaintainSPGDeliveryNote maintainSPGDeliveryNoteObj =
      MaintainSPGDeliveryNoteFactory.newInstance();

    maintainSPGDeliveryNoteObj.removeNote(noteDetails);
  }

  /**
   * This method is used to view the notes for service plan group delivery.
   *
   * @param key
   *          has the note link id of the record which needs to be returned.
   * @return SPGDeliveryNoteDetails
   *          details of the service plan group delivery note
   * @throws AppException, InformationalException
   */
  public SPGDeliveryNoteDetails viewNote(SPGDeliveryNoteKey key)
    throws AppException, InformationalException {

    MaintainSPGDeliveryNote maintainSPGDeliveryNoteObj =
      MaintainSPGDeliveryNoteFactory.newInstance();

    SPGDeliveryNoteLinkKey spgdDeliveryNoteLinkKey
      = new SPGDeliveryNoteLinkKey();

    spgdDeliveryNoteLinkKey.spgDeliveryNoteLinkId
      = key.spgDeliveryNoteLinkId;

    SPGDeliveryNoteDetails spgDeliveryNoteDetails =
      maintainSPGDeliveryNoteObj.viewNote(spgdDeliveryNoteLinkKey);

    // Create the objects for menu and context description
    ServicePlanDelivery servicePlanDeliveryObj
      = ServicePlanDeliveryFactory.newInstance();

    ServicePlanGroupDeliveryKey servicePlanGroupDeliveryKey
      = new ServicePlanGroupDeliveryKey();

    servicePlanGroupDeliveryKey.servicePlanGroupDeliveryID
      = key.servicePlanGroupDeliveryId;

    // Get the menu data
    spgDeliveryNoteDetails.menuData =
    servicePlanDeliveryObj.getICServicePlanGroupMenuData(
      servicePlanGroupDeliveryKey);

    return spgDeliveryNoteDetails;
  }
}