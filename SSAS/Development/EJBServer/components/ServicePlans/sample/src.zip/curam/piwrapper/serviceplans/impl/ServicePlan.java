/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.piwrapper.serviceplans.impl;


import com.google.inject.ImplementedBy;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SERVICEPLANTYPEEntry;
import curam.piwrapper.caseconfiguration.impl.CaseConfiguration;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * A read only wrapper object for the
 * {@linkplain curam.serviceplans.sl.entity.intf.ServicePlan} entity.
 */
// BEGIN, CR00309529, POH
@ImplementedBy(ServicePlanImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ServicePlan extends CaseConfiguration,
    Lifecycle<RECORDSTATUSEntry> {
  // END, CR00309529

  /**
   * Retrieves the service plan type for the service plan.
   *
   * @return the type for the service plan
   */
  public SERVICEPLANTYPEEntry getServicePlanType();

  /**
   * Checks Service Plan security.
   *
   * @param securityCheckType
   * the type of security check to perform
   */
  public void checkSecurity(final byte securityCheckType) throws AppException,
      InformationalException;
}
