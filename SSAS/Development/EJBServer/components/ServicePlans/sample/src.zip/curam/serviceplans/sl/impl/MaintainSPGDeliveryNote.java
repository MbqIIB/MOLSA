/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.fact.NoteFactory;
import curam.core.sl.entity.intf.Note;
import curam.core.sl.entity.struct.LastNoteDetails;
import curam.core.sl.entity.struct.ModifyNoteDetails1;
import curam.core.sl.entity.struct.NoteDtls;
import curam.core.sl.entity.struct.NoteDtlsList;
import curam.core.sl.entity.struct.NoteKey;
import curam.core.sl.entity.struct.NoteText;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.SecurityResult;
import curam.core.struct.UsersKey;
import curam.message.BPOSPGNOTES;
import curam.message.CASENOTE;
import curam.message.GENERAL;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetails;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetails1;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetailsList;
import curam.serviceplans.facade.struct.SPGDeliveryNoteDetailsList1;
import curam.serviceplans.sl.entity.fact.SPGDeliveryNoteLinkFactory;
import curam.serviceplans.sl.entity.intf.SPGDeliveryNoteLink;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryNoteLinkDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryNoteLinkKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryNoteLinkStatusDtls;
import curam.serviceplans.sl.struct.NoteIdKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.DateTime;


/**
 * This API is used to maintain the notes for service plan group delivery.
 */
public abstract class MaintainSPGDeliveryNote extends curam.serviceplans.sl.base.MaintainSPGDeliveryNote {

  // ____________________________________________________________________________
  /**
   * This method is used to create note for service plan group delivery.
   *
   * @param details SPGDeliveryNoteDetails
   * - Details populated from the UIM which needs to be added
   * @return SPGDeliveryNoteLinkKey
   * - contains the ID of the link which was created
   * @throws AppException, InformationalException
   */
  public SPGDeliveryNoteLinkKey createNote(final SPGDeliveryNoteDetails details)
    throws AppException, InformationalException {

    // Create an entry in CEF note
    Note noteObj = NoteFactory.newInstance();

    details.noteDtls.noteID = UniqueIDFactory.newInstance().getNextID();

    if (details.noteDtls.notesText.toString().trim().length() > 0) {

      // insert information line, created as a result of
      StringBuffer noteText = new StringBuffer();

      int position = details.noteDtls.notesText.indexOf(
        CASENOTE.INF_NOTE_CREATED_AS_A_RESULT_OF.getMessageText());

      if (position == -1) {

        noteText.append(
          CASENOTE.INF_NOTE_CREATED_AS_A_RESULT_OF.getMessageText());
        noteText.append(CuramConst.gkSpace);
        noteText.append(CASENOTE.INF_NOTE_TYPE_USER_NOTE);
        noteText.append(CuramConst.gkNewLine);
      }

      noteText.append(details.noteDtls.notesText);
      details.noteDtls.notesText = noteText.toString();
    }

    noteObj.insert(details.noteDtls);

    // Create an entry in service plan group
    SPGDeliveryNoteLink spgDeliveryNoteLinkObj = SPGDeliveryNoteLinkFactory.newInstance();

    details.spgDeliveryNoteLink.noteId = details.noteDtls.noteID;
    details.spgDeliveryNoteLink.status = RECORDSTATUS.NORMAL;

    spgDeliveryNoteLinkObj.insert(details.spgDeliveryNoteLink);

    SPGDeliveryNoteLinkKey returnKey = new SPGDeliveryNoteLinkKey();

    returnKey.spgDeliveryNoteLinkId = details.spgDeliveryNoteLink.spgDeliveryNoteLinkId;

    return returnKey;
  }

  // BEGIN, CR00240923 PDN  
  // ____________________________________________________________________________
  /**
   * This method is used to list all the notes for service plan group delivery.
   * @param key SPGDeliveryKey
   * - contains the ID of the service plan group delivery.
   * @return SPGDeliveryNoteDetailsList
   * - List of the service plan group delivery note details.
   * @throws AppException, InformationalException
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #listNotesByGroupDeliveryID()}
   */
  public SPGDeliveryNoteDetailsList listNotesByGroupDeliveryID(
    SPGDeliveryKey key) throws AppException, InformationalException {

    // Return struct
    SPGDeliveryNoteDetailsList spgDeliveryNoteDetailsList = new SPGDeliveryNoteDetailsList();

    SPGDeliveryNoteDetailsList1 spgDeliveryNoteDetailsList1 = listNotesByGroupDeliveryID1(
      key);
    
    spgDeliveryNoteDetailsList.assign(spgDeliveryNoteDetailsList1);

    return spgDeliveryNoteDetailsList;
  }
  
  // ____________________________________________________________________________
  /**
   * This method is used to list all the notes for service plan group delivery.
   *
   * @param key SPGDeliveryKey
   * - contains the ID of the service plan group delivery.
   * @return SPGDeliveryNoteDetailsList
   * - List of the service plan group delivery note details.
   * @throws AppException, InformationalException
   */
  public SPGDeliveryNoteDetailsList1 listNotesByGroupDeliveryID1(
    SPGDeliveryKey key) throws AppException, InformationalException {

    // Entity instance
    SPGDeliveryNoteLink spgDeliveryNoteLinkObj = SPGDeliveryNoteLinkFactory.newInstance();

    // Return struct
    SPGDeliveryNoteDetailsList1 spgDeliveryNoteDetailsList = new SPGDeliveryNoteDetailsList1();

    SPGDeliveryNoteDetails1 spgDeliveryNoteDetails;

    // Fetch the list of notes from service plan group delivery id
    NoteDtlsList noteDtlsList = spgDeliveryNoteLinkObj.searchNotesBySPGDeliveryID1(
      key);

    NoteDtls noteDtls;

    NoteIdKey noteIdKey = new NoteIdKey();

    SPGDeliveryNoteLinkDtls spgDeliveryNoteLinkDtls;

    final int sizeOfNoteList = noteDtlsList.dtls.size();

    // Iterate through each note fetch the link details
    // and add to the return struct
    for (int noteListIter = 0; noteListIter < sizeOfNoteList; noteListIter++) {

      noteDtls = noteDtlsList.dtls.item(noteListIter);
      spgDeliveryNoteDetails = new SPGDeliveryNoteDetails1();
      spgDeliveryNoteDetails.noteDtls.assign(noteDtls);
      noteIdKey.noteId = noteDtls.noteID;
      spgDeliveryNoteLinkDtls = spgDeliveryNoteLinkObj.readByNoteId(noteIdKey);
      spgDeliveryNoteDetails.spgDeliveryNoteLink.assign(spgDeliveryNoteLinkDtls);
      spgDeliveryNoteDetails.noteDtls.assign(noteDtls);

      // Users variables
      UserAccess userAccessObj = UserAccessFactory.newInstance();
      UsersKey usersKey = new UsersKey();

      // set the user name from the spgDeliveryNoteDetails details.
      usersKey.userName = spgDeliveryNoteDetails.noteDtls.userName;

      // invoke the method getFullName to get the user full name
      // and set that to spgDeliveryNoteDetails details.
      spgDeliveryNoteDetails.fullname = userAccessObj.getFullName(usersKey).fullname;

      spgDeliveryNoteDetailsList.dtls.addRef(spgDeliveryNoteDetails);
    }

    NoteKey noteKey = new NoteKey();
    NoteText noteText = new NoteText();

    // Note Object
    Note noteObj = NoteFactory.newInstance();

    // Security Variables
    SecurityResult securityResult;

    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();

    final int sizeOfList = spgDeliveryNoteDetailsList.dtls.size();

    for (int i = 0; i < sizeOfList; i++) {

      spgDeliveryNoteDetails = spgDeliveryNoteDetailsList.dtls.item(i);

      // Check the note sensitivity
      noteKey.noteID = spgDeliveryNoteDetails.noteDtls.noteID;

      securityResult = dataBasedSecurity.checkNoteSecurity(noteKey);

      if (securityResult.result) {

        // Assign the details.
        noteText.notesText = spgDeliveryNoteDetails.noteDtls.notesText;

        // BEGIN, CR00142625
        LastNoteDetails lastNoteDetails = noteObj.getLastNoteText1(noteText);

        // END, CR00142625
        
        noteText.notesText = lastNoteDetails.content;
        
        spgDeliveryNoteDetails.modifiedDateTime = lastNoteDetails.dateTime;
        
        // Truncate the note
        noteText = noteObj.truncate(noteText);
      
        spgDeliveryNoteDetails.truncatedNoteText = noteText.notesText;

        spgDeliveryNoteDetails.noteDtls.notesText = noteText.notesText;

      } else {

        // Return no details to client if User does not have access
        spgDeliveryNoteDetails.noteDtls.priorityCode = CuramConst.gkEmpty;
        spgDeliveryNoteDetails.noteDtls.sensitivityCode = CuramConst.gkEmpty;
        spgDeliveryNoteDetails.noteDtls.creationDateTime = DateTime.kZeroDateTime;
        spgDeliveryNoteDetails.noteDtls.notesText = CuramConst.gkRestricted;
      }
    }

    return spgDeliveryNoteDetailsList;
  }  

  // END, CR00240923

  // ____________________________________________________________________________
  /**
   * This method is used to modify the notes for service plan group delivery.
   *
   * @param noteDetails SPGDeliveryNoteDetails
   * - Service plan group delivery note which needs to be modified
   * @throws AppException, InformationalException
   */
  public void modifyNote(SPGDeliveryNoteDetails noteDetails)
    throws AppException, InformationalException {

    // validation to check if the record is already canceled and in this case,
    // the record cannot be modified and so error is thrown
    if (noteDetails.spgDeliveryNoteLink.status.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_GENERAL_FV_NO_MODIFY_RECORD_CANCELLED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 81);
    }

    // CEF note Object
    Note noteObj = NoteFactory.newInstance();

    NoteKey noteKey = new NoteKey();

    noteKey.noteID = noteDetails.noteDtls.noteID;

    ModifyNoteDetails1 modifyNoteDetails = new ModifyNoteDetails1();

    modifyNoteDetails.assign(noteDetails.noteDtls);

    if (modifyNoteDetails.notesText.toString().trim().length() > 0) {

      // insert information line, modified as a result of
      StringBuffer noteText = new StringBuffer();

      noteText.append(
        CASENOTE.INF_NOTE_MODIFIED_AS_A_RESULT_OF.getMessageText());
      noteText.append(CuramConst.gkSpace);
      noteText.append(CASENOTE.INF_NOTE_TYPE_USER_NOTE);
      noteText.append(CuramConst.gkNewLine);

      noteText.append(modifyNoteDetails.notesText);

      modifyNoteDetails.notesText = noteText.toString();
    }

    // Pass the modified Dtls with the version number
    noteObj.modifyNote1(noteKey, modifyNoteDetails);
  }

  // ____________________________________________________________________________
  /**
   * This method is used to remove the notes for service plan group delivery.
   *
   * @param noteDetails SPGDeliveryNoteDetails
   * - The record which is to be removed.
   * @throws AppException, InformationalException
   */
  public void removeNote(SPGDeliveryNoteDetails noteDetails)
    throws AppException, InformationalException {

    // Entity layer link object
    SPGDeliveryNoteLink spgDeliveryNoteLinkObj = SPGDeliveryNoteLinkFactory.newInstance();

    SPGDeliveryNoteLinkKey spgDeliveryNoteLinkKey = new SPGDeliveryNoteLinkKey();

    spgDeliveryNoteLinkKey.spgDeliveryNoteLinkId = noteDetails.spgDeliveryNoteLink.spgDeliveryNoteLinkId;

    SPGDeliveryNoteLinkDtls deliveryNoteLinkDtls = new SPGDeliveryNoteLinkDtls();

    NoteIdKey noteIdKey = new NoteIdKey();

    noteIdKey.noteId = noteDetails.noteDtls.noteID;

    deliveryNoteLinkDtls.assign(
      spgDeliveryNoteLinkObj.read(spgDeliveryNoteLinkKey));

    if (deliveryNoteLinkDtls.status.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_GENERAL_FV_RECORD_ALREADY_CANCELLED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 74);
    }

    SPGDeliveryNoteLinkStatusDtls spgDeliveryNoteLinkStatusDtls = new SPGDeliveryNoteLinkStatusDtls();

    spgDeliveryNoteLinkStatusDtls.status = RECORDSTATUS.CANCELLED;

    // Cancel the record.
    spgDeliveryNoteLinkObj.cancelLink(spgDeliveryNoteLinkKey,
      spgDeliveryNoteLinkStatusDtls);
  }

  // ____________________________________________________________________________
  /**
   * This method is used to view the notes for service plan group delivery.
   *
   * @param key SPGDeliveryNoteLinkKey
   * - The key for the record which is to be read.
   * @return SPGDeliveryNoteDetails
   * - The returned record details for viewing.
   * @throws AppException, InformationalException
   */
  public SPGDeliveryNoteDetails viewNote(SPGDeliveryNoteLinkKey linkKey)
    throws AppException, InformationalException {

    // Return struct
    SPGDeliveryNoteDetails spgDeliveryNoteDetails = new SPGDeliveryNoteDetails();

    SPGDeliveryNoteLink spgDeliveryNoteLinkObj = SPGDeliveryNoteLinkFactory.newInstance();

    SPGDeliveryNoteLinkDtls spgDeliveryNoteLinkDtls = spgDeliveryNoteLinkObj.read(
      linkKey);

    NoteIdKey nodeIDKey = new NoteIdKey();

    nodeIDKey.noteId = spgDeliveryNoteLinkDtls.noteId;

    NoteDtls noteDtls = spgDeliveryNoteLinkObj.readNoteDetailsByLinkID1(
      nodeIDKey);

    // Set the return struct
    spgDeliveryNoteDetails.noteDtls.assign(noteDtls);
    spgDeliveryNoteDetails.spgDeliveryNoteLink.assign(spgDeliveryNoteLinkDtls);

    // Check security on retrieved details.
    checkSecurityForRead(spgDeliveryNoteDetails);

    // Users variables
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    // set the user name from the opinion details.
    usersKey.userName = spgDeliveryNoteDetails.noteDtls.userName;

    // invoke the method getFullName to get the user full name
    // and set that to spgDeliveryNoteDetails
    spgDeliveryNoteDetails.fullname = userAccessObj.getFullName(usersKey).fullname;

    return spgDeliveryNoteDetails;
  }

  // ____________________________________________________________________________
  /**
   * This method is used to check the read security on notes
   * for a service plan group delivery.
   *
   * @param key SPGDeliveryNoteDetails
   * - The record which is to be checked.
   * @throws AppException, InformationalException
   */
  protected void checkSecurityForRead(SPGDeliveryNoteDetails details)
    throws AppException, InformationalException {

    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();

    NoteKey noteKey = new NoteKey();

    noteKey.noteID = details.noteDtls.noteID;

    // Check the note sensitivity
    SecurityResult securityResult = dataBasedSecurity.checkNoteSecurity(noteKey);

    if (securityResult.result == false) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSPGNOTES.ERR_SPGNOTE_SL_FV_SENSITIVITY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }
}
