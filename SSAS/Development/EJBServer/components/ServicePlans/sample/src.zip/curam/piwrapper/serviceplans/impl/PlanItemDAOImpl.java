/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;

import java.util.ArrayList;
import java.util.List;

import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.serviceplans.sl.entity.fact.SubGoalFactory;
import curam.serviceplans.sl.entity.impl.PlanItemAdapter;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemSummaryDetails;
import curam.serviceplans.sl.entity.struct.PlanItemSummaryDetailsList;
import curam.serviceplans.sl.entity.struct.SubGoalKey;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;

/**
 * Data access for {@linkplain curam.sl.entity.intf.PlanItem}.
 */
@Singleton
// BEGIN, CR00183334, PS
public class PlanItemDAOImpl extends StandardDAOImpl<PlanItem, PlanItemDtls>
    implements PlanItemDAO {
  // END, CR00183334
  private static final PlanItemAdapter adapter = new PlanItemAdapter();

  private static final curam.serviceplans.sl.entity.intf.SubGoal subGoalEntity = SubGoalFactory
      .newInstance();

  @Inject
  private PlanItemDAO planItemDAO;

  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected PlanItemDAOImpl() {
    // no-arg constructor for use only by Guice
    // END, CR00183334
    super(adapter, PlanItem.class);
  }

  /**
   * {@inheritDoc}
   */
  public List<PlanItem> listActiveBySubGoal(final SubGoal subGoal) {

    // Create the return list
    List<PlanItem> planItemList = new ArrayList<PlanItem>();

    // Search for plan items linked to the sub goal
    SubGoalKey subGoalKey = new SubGoalKey();
    subGoalKey.subGoalID = subGoal.getID();

    try {
      PlanItemSummaryDetailsList planItemSummaryDetailsList = subGoalEntity
          .searchPlanItems(subGoalKey);

      // Filter out the cancelled records from the list
      for (PlanItemSummaryDetails planItemSummaryDetails : planItemSummaryDetailsList.dtls
          .items()) {
        PlanItem planItem = planItemDAO.get(planItemSummaryDetails.planItemID);
        if (planItem.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)) {
          planItemList.add(planItem);
        }
      }

      return planItemList;

      /*
       * Catch an exceptions and thrown them as runtime exceptions as there is
       * nothing the application can do to cater for exceptions thrown here.
       */
    } catch (AppException e) {
      throw new AppRuntimeException(e);
    } catch (InformationalException e) {
      throw new AppRuntimeException(e);
    }
  }
}
