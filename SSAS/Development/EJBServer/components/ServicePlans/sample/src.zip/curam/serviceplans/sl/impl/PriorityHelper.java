/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import curam.core.sl.struct.Priority;
import curam.core.sl.struct.PriorityDetails;
import curam.core.sl.struct.PriorityPosition;
import curam.serviceplans.sl.struct.OrderPriorityDetails;
import curam.serviceplans.sl.struct.PriorityDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;


/**
 * Priority helper class implementation.  Used for ordering and sorting
 * priority values when there is a potential clash or a new number is needed.
 */
public abstract class PriorityHelper extends curam.serviceplans.sl.base.PriorityHelper {

  /**
   * Returns the next priority by adding one to the
   * current lowest priority. The lowest priority is the highest
   * numerical value.
   *
   * @param list The list of existing priorities and associated record IDs. 
   * This list does not have to ordered.
   * @param currentDetails The current record that is having 
   * it's priority created/changed.
   * @return Priority of Record
   * @throws InformationalException e2
   * @throws AppException e1
   */
  public Priority getNextPriority(final PriorityDetailsList list, 
    final OrderPriorityDetails currentDetails)
    throws AppException, InformationalException {

    // Create return struct
    final Priority priority = new Priority();

    int latestPriority = 0;

    // Note that priority is unique but not necessarily in sequential order
    OrderPriorityDetails item;
    final int size = list.dtls.size();
    
    for (int i = 0; i < size; i++) {
      item = list.dtls.item(i);
      
      // If this entry is the same as the record that is being modified then
      // skip it so that it doesn't end up skewing the maximum priority
      if (item.recordKeyID == currentDetails.recordKeyID) {
        continue;
      }

      if (item.priority > latestPriority) {
        latestPriority = item.priority;
      }
    }

    // Set return value to latest value
    priority.dtls.priority = latestPriority;

    // Add one to the priority to get the next priority
    priority.dtls.priority = priority.dtls.priority + 1;

    // Return back the value
    return priority;
  }

  /**
   * Generates a list of priority details for records that need to be modified 
   * to resolve conflicts created by new or updated priorities. 
   * The list returned contains the appropriate id's and the new modified 
   * priorities.
   *
   * @param details The details of the record and priority that may class with 
   * existing entries
   * @param list The list of all active associated records.  
   * This list is not expected to be ordered.
   * @return The list of the records with new priorities
   * @throws InformationalException e2
   * @throws AppException e1
   */
  public PriorityDetailsList reorderPriority(
    final OrderPriorityDetails details, final PriorityDetailsList list)
    throws AppException, InformationalException {

    // Create return struct
    final PriorityDetailsList reorderedList = new PriorityDetailsList();

    OrderPriorityDetails record = null;
    boolean foundClash = false;

    // Sorted Map that may be used for processing if a clash is detected
    final Map<Integer, OrderPriorityDetails> sortedMap = new TreeMap<Integer, OrderPriorityDetails>();

    OrderPriorityDetails item;    
    final int size = list.dtls.size();
    
    for (int i = 0; i < size; i++) {
      item = list.dtls.item(i);
      
      // Don't do anything if this is the record that is being modified
      if (item.recordKeyID == details.recordKeyID) {
        continue;
      }

      // Check to see if we hit an existing entry.
      if (item.priority == details.priority) {
        foundClash = true;
      }

      // Need to re-order anything that clashes - actually might NOT
      // need to if there was no actual clash but speculatively build the list 
      // anyway.
      if (item.priority >= details.priority) {
        record = item;

        // Add this record into the sorted list in case it needs to be 
        // renumbered
        sortedMap.put(record.priority, record);
      }

    }

    // If there was a clash then need to go through the list that was built up
    // and potentially renumber things.  Can stop doing this as soon as no more
    // clashes
    if (foundClash) {
      int currentClash = details.priority;

      final Iterator<OrderPriorityDetails> it = sortedMap.values().iterator();

      while (it.hasNext()) {
        record = it.next();

        // If this clashes then add one, and assign this new value to the
        // current clash we are looking for.  Then put this record in the result
        // list
        if (record.priority == currentClash) {
          currentClash = ++record.priority;
          reorderedList.dtls.addRef(record);
        } else {
          // Run out of entries that clash, can finish now
          break;
        }
      }

    }

    // Return the reordered list to be modified.
    return reorderedList;
  }

  /**
   * Validates the priority details.  This is simply a convenience method to 
   * centralize the error messages and checks for all priority functionality.
   *
   * @param details The details of the priority entered
   * @throws InformationalException e2
   * @throws AppException e1
   */
  public void validatePriority(final PriorityDetails details) 
    throws AppException, InformationalException {

    // If 'Apply Next Priority' has not been set, priority must be set
    if (details.applyNextPriorityInd == false && details.priority == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOAPPROVALCRITERIA.ERR_XFV_PRIORITY_BLANK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // If 'Apply Next Priority' indicator has been set, 
    // priority cannot be entered
    if (details.applyNextPriorityInd == true && details.priority != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOAPPROVALCRITERIA.ERR_XFV_ASSIGN_NEXT_PRIORITY_CANNOT_SELECT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Priority cannot be a negative number
    if (details.priority < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOAPPROVALCRITERIA.ERR_FV_PRIORITY_POSITIVE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  /**
   * Generate the priority order text string.
   *
   * @param dtlsList priority details list
   * @param currentPriority current priority details
   * @return Priority Position
   * @throws InformationalException e2
   * @throws AppException e1
   * @see curam.serviceplans.sl.intf.PriorityHelper#getPriorityPosition(
   * curam.serviceplans.sl.struct.PriorityDetailsList, 
   * curam.serviceplans.sl.struct.OrderPriorityDetails)
   */
  public PriorityPosition getPriorityPosition(
    final PriorityDetailsList dtlsList, 
    final OrderPriorityDetails currentPriority) 
    throws AppException, InformationalException {

    final PriorityPosition result = new PriorityPosition();

    final int priorityCount = dtlsList.dtls.size();
    int priorityPosition = 1;

    for (int i = 0; i < priorityCount; i++) {
      // If this entry has a priority less that the current one then it's
      // in front of it, so add one to the position
      if (dtlsList.dtls.item(i).priority < currentPriority.priority) {
        priorityPosition++;
      }
    }

    final LocalisableString priorityText = new LocalisableString(
      curam.message.BPOPRIORITYHELPER.INF_XRV_PRIORITY_POSITION);

    priorityText.arg(currentPriority.priority);
    priorityText.arg(priorityPosition);
    priorityText.arg(priorityCount);

    result.priorityPosition = priorityText.getMessage();

    return result;
  }

}
