/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;

import com.google.inject.Inject;

import curam.codetable.impl.OUTCOMEACHIEVEDEntry;
import curam.codetable.impl.PLANNEDSUBGOALSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SENSITIVITYEntry;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDtls;
import curam.util.persistence.helper.ReadOnlyEntityImpl;
import curam.util.type.DateRange;

/**
 * Standard implementation of the {@link PlannedSubGoal} interface.
 */
// BEGIN, CR00183334, PS
public class PlannedSubGoalImpl extends
    ReadOnlyEntityImpl<Long, PlannedSubGoalDtls> implements PlannedSubGoal {
  // END, CR00183334
  @Inject
  private UserDAO userDAO;

  @Inject
  private PlannedGoalDAO plannedGoalDAO;

  @Inject
  private SubGoalDAO subGoalDAO;
  
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected PlannedSubGoalImpl() {
    // no-arg constructor for use only by Guice.
  }

  // END, CR00183334

  /**
   * {@inheritDoc}
   */
  public DateRange getActualDateRange() {
    return new DateRange(getDtls().actualStartDate, getDtls().actualEndDate);
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  public DateRange getExpectedDateRange() {
    return new DateRange(getDtls().expectedStartDate, getDtls().expectedEndDate);
  }

  /**
   * {@inheritDoc}
   */
  public OUTCOMEACHIEVEDEntry getOutcomeAchieved() {
    return OUTCOMEACHIEVEDEntry.get(getDtls().outcomeAchieved);
  }

  /**
   * {@inheritDoc}
   */
  public User getOwner() {
    return userDAO.get(getDtls().ownerID);
  }

  /**
   * {@inheritDoc}
   */
  public PlannedGoal getPlannedGoal() {
    return plannedGoalDAO.get(getDtls().plannedGoalID);
  }

  /**
   * {@inheritDoc}
   */
  public RECORDSTATUSEntry getRecordStatus() {
    return RECORDSTATUSEntry.get(getDtls().recordStatus);
  }

  /**
   * {@inheritDoc}
   */
  public SENSITIVITYEntry getSensitivity() {
    return SENSITIVITYEntry.get(getDtls().sensitivityCode);
  }

  /**
   * {@inheritDoc}
   */
  public PLANNEDSUBGOALSTATUSEntry getStatus() {
    return PLANNEDSUBGOALSTATUSEntry.get(getDtls().status);
  }

  /**
   * {@inheritDoc}
   */
  public SubGoal getSubGoal() {
    return subGoalDAO.get(getDtls().subGoalID);
  }

  /**
   * {@inheritDoc}
   */
  public ServicePlanDelivery getPlanDelivery() {
    return getPlannedGoal().getPlanDelivery();
  }

}
