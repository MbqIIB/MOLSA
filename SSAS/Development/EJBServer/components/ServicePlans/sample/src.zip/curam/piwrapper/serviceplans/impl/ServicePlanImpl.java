/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;

import com.google.inject.Inject;

import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SERVICEPLANTYPEEntry;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.serviceplans.sl.entity.struct.ServicePlanDtls;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.ReadOnlyEntityImpl;

/**
 * Standard implementation of
 * {@linkplain curam.piwrapper.serviceplans.impl.ServicePlan}.
 */
// BEGIN, CR00183334, PS
public class ServicePlanImpl extends ReadOnlyEntityImpl<Long, ServicePlanDtls>
    implements ServicePlan {
  // END, CR00183334
  @Inject
  private CaseHeaderDAO caseHeaderDAO;

  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected ServicePlanImpl() {
    // no-arg constructor for use only by Guice.
  }

  // END, CR00183334

  /**
   * {@inheritDoc}
   */
  public String getCaseConfigurationName() {
    return getServicePlanType().toUserLocaleString();
  }

  /**
   * {@inheritDoc}
   */
  public RECORDSTATUSEntry getLifecycleState() {
    return RECORDSTATUSEntry.get(getDtls().recordStatus);
  }

  /**
   * {@inheritDoc}
   */
  public void checkSecurity(final byte securityCheckType) throws AppException,
      InformationalException {

    ServicePlanOperationSecurityKey spOperationSecurityKey = 
      new ServicePlanOperationSecurityKey();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = 
      ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    // populate operation type
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = 
      securityCheckType;

    // populate concern role ID
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = 
      caseHeaderDAO.get(getID()).getConcernRole().getID();

    // set service plan delivery key
    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = 
      getDtls().servicePlanID;

    // check service plan security
    servicePlanSecurity
        .servicePlanOperationSecurityCheck(spOperationSecurityKey);
  }

  /**
   * {@inheritDoc}
   */
  public CASETYPECODEEntry getCaseType() {
    return CASETYPECODEEntry.SERVICEPLAN;
  }

  /**
   * {@inheritDoc}
   */
  public String getLinkText() {
    return getCaseConfigurationName();
  }

  /**
   * {@inheritDoc}
   */
  public String getPageLink() {
    return "ServicePlanAdmin_servicePlanHomePage.do?servicePlanID=";
  }

  /**
   * {@inheritDoc}
   */
  public SERVICEPLANTYPEEntry getServicePlanType() {
    return SERVICEPLANTYPEEntry.get(getDtls().servicePlanType);
  }
}
