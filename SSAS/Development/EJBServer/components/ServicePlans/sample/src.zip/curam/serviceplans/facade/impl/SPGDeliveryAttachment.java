/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.facade.impl;


import curam.core.struct.AttachmentKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.fact.MaintainSPGDeliveryAttachmentFactory;
import curam.serviceplans.sl.intf.MaintainSPGDeliveryAttachment;
import curam.serviceplans.sl.struct.SPGDAttachmenDetails;
import curam.serviceplans.sl.struct.SPGDAttachmentList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class is used to maintain the functionality related
 * to Attachment for the service plan group delivery.
 *
 */
public class SPGDeliveryAttachment extends
    curam.serviceplans.facade.base.SPGDeliveryAttachment {

  /**
   * Facade layer method to add the attachment to the service plan group
   * delivery.
   *
   * @param spgAttachmentDetails SPGDAttachmenDetails
   *
   * @return AttachmentKey - The id of the attachment created.
   * @throws AppException, InformationalException
   */
  public AttachmentKey addAttachment(
      final SPGDAttachmenDetails spgAttachmentDetails)
    throws AppException, InformationalException {

    final MaintainSPGDeliveryAttachment spgDeliveryObj
      = MaintainSPGDeliveryAttachmentFactory.newInstance();
    final AttachmentKey attachmentKey =
    spgDeliveryObj.addAttachment(spgAttachmentDetails);

    return attachmentKey;
  }

  /**
   * Facade layer method to list all the attachments to the service plan group
   * delivery.
   *
   * @param spgDeliveryKey SPGDeliveryKey
   *           The id of service plan group delivery.
   * @return SPGDAttachmentList
   *           This list has all the attachment details needed
   *           for the attachment.
   * @throws AppException, InformationalException
   */
  public SPGDAttachmentList listAttachment(final SPGDeliveryKey spgDeliveryKey)
      throws AppException, InformationalException {
    MaintainSPGDeliveryAttachment spgDeliveryObj
      = MaintainSPGDeliveryAttachmentFactory.newInstance();
    SPGDAttachmentList spgdAttachmentList
      = spgDeliveryObj.listAttachment(spgDeliveryKey);
    return spgdAttachmentList;
  }

  /**
   * Facade layer method to modify the attachment in the service plan group
   * delivery.
   *
   * @param spgAttachmentDetails
   *           Details of the attachment for modification.
   * @throws AppException, InformationalException
   */
  public void modifyAttachment(SPGDAttachmenDetails spgAttachmentDetails)
    throws AppException, InformationalException {
    MaintainSPGDeliveryAttachment spgDeliveryObj
      = MaintainSPGDeliveryAttachmentFactory.newInstance();
    spgDeliveryObj.modifyAttachment(spgAttachmentDetails);
  }

  /**
   * Facade layer method to remove the attachment from the service plan group
   * delivery.
   *
   * @param spgAttachmentKey
   *          The details of the attachment which needs to be removed.
   * @throws AppException, InformationalException
   */
  public void removeAttachment(SPGDAttachmenDetails spgAttachmentKey)
    throws AppException, InformationalException {
    MaintainSPGDeliveryAttachment spgDeliveryObj =
      MaintainSPGDeliveryAttachmentFactory.newInstance();
    spgDeliveryObj.removeAttachment(spgAttachmentKey);
  }

  /**
   * Facade layer method to view the attachment details in the
   * service plan group delivery.
   *
   * @param attachmentKey
   *           AttachmentKey
   * @return SPGDAttachmenDetails
   *           Details of the attachment.
   * @throws AppException, InformationalException
   */
  public SPGDAttachmenDetails viewAttachment(AttachmentKey attachmentKey)
      throws AppException, InformationalException {
    MaintainSPGDeliveryAttachment spgDeliveryObj
      = MaintainSPGDeliveryAttachmentFactory.newInstance();

    SPGDAttachmenDetails spdgAttachmenDetails
      = spgDeliveryObj.viewAttachment(attachmentKey);

    return spdgAttachmenDetails;
  }

}
