/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import java.util.Calendar;

import curam.codetable.ATTENDANCE;
import curam.codetable.ATTENDANCETRACKINGHOURS;
import curam.codetable.ATTENDANCETRACKINGMINUTES;
import curam.codetable.CASESTATUS;
import curam.codetable.PLANITEMNAME;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.RESPONSIBILITYTYPE;
import curam.core.fact.CaseHeaderFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.SystemUser;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.DailyAttendanceFactory;
import curam.core.sl.entity.intf.DailyAttendance;
import curam.core.sl.entity.struct.AttendanceServiceDateAndTime;
import curam.core.sl.entity.struct.DailyAttendanceDtls;
import curam.core.sl.entity.struct.DailyAttendanceKey;
import curam.core.sl.infrastructure.entity.struct.RecordStatusAndVersionNo;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseIDRecordStatus;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.Count;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOCLIENTPARTICIPATION;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.GENERALCASE;
import curam.serviceplans.sl.entity.fact.PIDailyAttendanceLinkFactory;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.intf.PIDailyAttendanceLink;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.struct.AttendanceCountForDateAndPlanItemKey;
import curam.serviceplans.sl.entity.struct.CaseDailyAttendanceSummaryDtls;
import curam.serviceplans.sl.entity.struct.NameNotEditableIndDetails;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkDtls;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkDtlsList;
import curam.serviceplans.sl.entity.struct.PIDailyAttendanceLinkKey;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlanItemsForDailyAttendanceSearchKey;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemParticipantIDDetails;
import curam.serviceplans.sl.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.intf.ServicePlanDelivery;
import curam.serviceplans.sl.struct.CaseActiveClientParticipationsKey;
import curam.serviceplans.sl.struct.CaseAndDateRangeKey;
import curam.serviceplans.sl.struct.CaseClientParticipationSearchKey;
import curam.serviceplans.sl.struct.CaseClientParticipationSecurityCheckKey;
import curam.serviceplans.sl.struct.CaseDailyAttendanceDetailsAsStrings;
import curam.serviceplans.sl.struct.CaseDailyAttendanceDetailsAsStringsList;
import curam.serviceplans.sl.struct.CaseDailyAttendanceSummaryDetailsList;
import curam.serviceplans.sl.struct.ClientParticipationXMLString;
import curam.serviceplans.sl.struct.PIDailyAttendanceDetailsList;
import curam.serviceplans.sl.struct.PIDailyAttendanceSummaryDetailsList;
import curam.serviceplans.sl.struct.ParticipationCaseAndDateKey;
import curam.serviceplans.sl.struct.PlanItemActiveClientParticipationSearchKey;
import curam.serviceplans.sl.struct.PlanItemAndDateRangeKey;
import curam.serviceplans.sl.struct.PlanItemChartDetails;
import curam.serviceplans.sl.struct.PlanItemClientParticipationSearchKey;
import curam.serviceplans.sl.struct.PlanItemClientParticipationSecurityCheckKey;
import curam.serviceplans.sl.struct.PlanItemsForClientParticipationSearchKey;
import curam.serviceplans.sl.struct.PlannedItemDailyAttendanceDetails;
import curam.serviceplans.sl.struct.PlannedItemNameAndIDDetailsList;
import curam.serviceplans.sl.struct.ServicePlanDailyAttendanceList;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanKey;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.struct.WeeklyParticipationDetailsList;
import curam.serviceplans.sl.struct.WeeklyParticipationSummaryDetails;
import curam.serviceplans.sl.struct.WeeklyParticipationSummaryDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.MultipleRecordException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;


/**
 * Business layer functionality for managing client participation for planItem
 * and for service plan.
 */
public abstract class ClientParticipation extends curam.serviceplans.sl.base.ClientParticipation {

  protected static final long MINUTESPERHOUR = 60l;

  // BEGIN, CR00052924, GM
  protected static String kZeroValueString = CuramConst.gkStringZero;
  // END, CR00052924
  protected static short kDaysInWeek = 7;
  protected static short minTwoDigitNumber = 10;

  // BEGIN, CR00114509, PMD
  // _________________________________________________________________________
  /**
   * Adds a Daily Attendance record.
   *
   * @param plannedItemDailyAttendanceDetails Daily attendance information
   * provided by user.
   * @return Identifier of newly created daily attendance record.
   */
  public DailyAttendanceKey addParticipation(
    PlannedItemDailyAttendanceDetails plannedItemDailyAttendanceDetails)
    throws AppException, InformationalException {

    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = plannedItemDailyAttendanceDetails.plannedItemID;

    // Read back the caseID
    plannedItemDailyAttendanceDetails.dtls.dtls.caseID = plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey).caseID;

    PlanItemClientParticipationSecurityCheckKey planItemClientParticipationSecurityCheckKey = new PlanItemClientParticipationSecurityCheckKey();

    planItemClientParticipationSecurityCheckKey.caseID = plannedItemDailyAttendanceDetails.dtls.dtls.caseID;

    planItemClientParticipationSecurityCheckKey.plannedItemID = plannedItemDailyAttendanceDetails.plannedItemID;

    planItemClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kMaintainSecurityCheck;

    try {
      checkPlanItemClientParticipationSecurityRights(
        planItemClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_MAINTAIN_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        // user-plan item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_ADD_PLAN_ITEM_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // DailyAttendance manipulation object
    DailyAttendance dailyAttendanceObj = DailyAttendanceFactory.newInstance();

    DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();

    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = plannedItemDailyAttendanceDetails.plannedItemID;

    // Get the concern role id
    PlannedItemParticipantIDDetails plannedItemParticipantIDDetails = plannedItemObj.readParticipantID(
      plannedItemKey);

    plannedItemDailyAttendanceDetails.dtls.dtls.creationDate = Date.getCurrentDate();
    plannedItemDailyAttendanceDetails.dtls.dtls.createdBySystem = false;
    plannedItemDailyAttendanceDetails.dtls.dtls.concernRoleID = plannedItemParticipantIDDetails.concernRoleID;

    // service plan specific validations
    validateDetails(plannedItemDailyAttendanceDetails);
    validateParticipation(plannedItemDailyAttendanceDetails);

    // Insert the daily attendance record
    dailyAttendanceObj.insert(plannedItemDailyAttendanceDetails.dtls.dtls);

    // assign generated key to return structure
    dailyAttendanceKey.dailyAttendanceID = plannedItemDailyAttendanceDetails.dtls.dtls.dailyAttendanceID;

    // PIDailyAttendanceLink manipulation object
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    PIDailyAttendanceLinkDtls piDailyAttendanceLinkDtls = new PIDailyAttendanceLinkDtls();

    // Set the link details
    piDailyAttendanceLinkDtls.plannedItemID = plannedItemDailyAttendanceDetails.plannedItemID;
    piDailyAttendanceLinkDtls.dailyAttendanceID = plannedItemDailyAttendanceDetails.dtls.dtls.dailyAttendanceID;
    piDailyAttendanceLinkDtls.recordStatus = RECORDSTATUS.NORMAL;

    // Insert the planned item daily attendance link
    piDailyAttendanceLinkObj.insert(piDailyAttendanceLinkDtls);

    // Service plans workflow raise event integration
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.CREATEPARTICIPATION;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = plannedItemDailyAttendanceDetails.plannedItemID;
    curam.util.events.impl.EventService.raiseEvent(event);

    return dailyAttendanceKey;
  }

  // _________________________________________________________________________
  /**
   * Sets Daily Attendance record to status "Canceled".
   *
   * @param key The key identifying the record to be cancelled.
   */
  public void cancelParticipation(DailyAttendanceKey key)
    throws AppException, InformationalException {

    PlanItemClientParticipationSecurityCheckKey planItemClientParticipationSecurityCheckKey = new PlanItemClientParticipationSecurityCheckKey();

    // DailyAttendance manipulation variables
    DailyAttendance dailyAttendanceObj = DailyAttendanceFactory.newInstance();
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    // get daily attendance details for service plan security check
    DailyAttendanceDtls dailyAttendanceDtls = dailyAttendanceObj.read(key);

    try {

      // Read the associated planned item from the link entity
      planItemClientParticipationSecurityCheckKey.plannedItemID = piDailyAttendanceLinkObj.readPlannedItemIDByDailyAttendanceID(key).plannedItemID;

    } catch (MultipleRecordException e) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();
      AppException ae = new AppException(
        curam.message.GENERAL.ERR_GENERAL_MULTIPLE_RECORDS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        ae, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kFatalError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    }

    planItemClientParticipationSecurityCheckKey.caseID = dailyAttendanceDtls.caseID;

    planItemClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kMaintainSecurityCheck;

    try {
      checkPlanItemClientParticipationSecurityRights(
        planItemClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_MAINTAIN_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        // user-plan item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_DELETE_PLAN_ITEM_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Validate the cancel operation
    validateCancel(dailyAttendanceDtls);

    RecordStatusAndVersionNo recordStatusAndVersionNo = new RecordStatusAndVersionNo();

    // Modify record status to 'Canceled'
    recordStatusAndVersionNo.recordStatus = RECORDSTATUS.CANCELLED;

    // Get link records for the daily attendance (there should only be one)
    PIDailyAttendanceLinkDtlsList piDailyAttendanceLinkDtlsList = piDailyAttendanceLinkObj.searchByDailyAttendanceID(
      key);

    for (int i = 0; i < piDailyAttendanceLinkDtlsList.dtls.size(); i++) {

      PIDailyAttendanceLinkDtls piDailyAttendanceLinkDtls = new PIDailyAttendanceLinkDtls();
      PIDailyAttendanceLinkKey piDailyAttendanceLinkKey = new PIDailyAttendanceLinkKey();

      piDailyAttendanceLinkDtls = piDailyAttendanceLinkDtlsList.dtls.item(i);

      piDailyAttendanceLinkKey.piDailyAttendanceLinkID = piDailyAttendanceLinkDtls.piDailyAttendanceLinkID;

      // Cancel the link record
      piDailyAttendanceLinkObj.modifyStatus(piDailyAttendanceLinkKey,
        recordStatusAndVersionNo);
    }

    // Cancel the daily attendance
    dailyAttendanceObj.modifyStatus(key, recordStatusAndVersionNo);

    // Service plans workflow raise event integration
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.DELETEPARTICIPATION;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = planItemClientParticipationSecurityCheckKey.plannedItemID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // _________________________________________________________________________
  /**
   * Modifies details of the daily attendance.
   *
   * @param details Modified Daily Attendance details
   */
  public void modifyDetails(
    PlannedItemDailyAttendanceDetails details)
    throws AppException, InformationalException {

    // planned item ID is not modified
    // case ID is also not modified
    // so read from database to get details for security is not needed
    PlanItemClientParticipationSecurityCheckKey planItemClientParticipationSecurityCheckKey = new PlanItemClientParticipationSecurityCheckKey();

    planItemClientParticipationSecurityCheckKey.caseID = details.dtls.dtls.caseID;
    planItemClientParticipationSecurityCheckKey.plannedItemID = details.plannedItemID;
    planItemClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kMaintainSecurityCheck;

    try {
      checkPlanItemClientParticipationSecurityRights(
        planItemClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_MAINTAIN_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        // user-plan item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_MODIFY_PLAN_ITEM_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Validate the modify details
    validateModify(details);

    DailyAttendanceKey dailyAttendanceKey = new DailyAttendanceKey();

    dailyAttendanceKey.dailyAttendanceID = details.dtls.dtls.dailyAttendanceID;

    // Modify the details
    DailyAttendanceFactory.newInstance().modify(dailyAttendanceKey,
      details.dtls.dtls);
  }

  // _________________________________________________________________________
  /**
   * Reads daily attendance details.
   *
   * @param key Identifier of the daily attendance record
   *
   * @return Daily Attendance details
   */
  public PlannedItemDailyAttendanceDetails viewDetails(
    DailyAttendanceKey key)
    throws AppException, InformationalException {

    // DailyAttendance manipulation variable
    DailyAttendance dailyAttendanceObj = DailyAttendanceFactory.newInstance();

    // PIDailyAttendanceLink manipulation variable
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    // Planned Item manipulation variable
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // Return struct
    PlannedItemDailyAttendanceDetails plannedItemDailyAttendanceDetails = new PlannedItemDailyAttendanceDetails();

    PlannedItemKey plannedItemKey = new PlannedItemKey();

    // Read the daily attendance details
    plannedItemDailyAttendanceDetails.dtls.dtls = dailyAttendanceObj.read(key);

    try {

      // Read the associated planned item from the link entity
      plannedItemKey.plannedItemID = piDailyAttendanceLinkObj.readPlannedItemIDByDailyAttendanceID(key).plannedItemID;

    } catch (MultipleRecordException e) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();
      AppException ae = new AppException(
        curam.message.GENERAL.ERR_GENERAL_MULTIPLE_RECORDS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        ae, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kFatalError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 4);
    }

    // Read back the plan item name
    plannedItemDailyAttendanceDetails.name = plannedItemObj.read(plannedItemKey).name;
    plannedItemDailyAttendanceDetails.plannedItemID = plannedItemKey.plannedItemID;

    // Check Service Plan security before returning details to user
    // get service plan ID
    PlanItemClientParticipationSecurityCheckKey planItemClientParticipationSecurityCheckKey = new PlanItemClientParticipationSecurityCheckKey();

    planItemClientParticipationSecurityCheckKey.caseID = plannedItemDailyAttendanceDetails.dtls.dtls.caseID;

    planItemClientParticipationSecurityCheckKey.plannedItemID = plannedItemKey.plannedItemID;

    planItemClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkPlanItemClientParticipationSecurityRights(
        planItemClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        // user-plan item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_PLAN_ITEM_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // BEGIN, CR00120342, CSH
    // The values for hours and minutes are stored separately in the database,
    // but to display them on the modify they must have a date time format
    curam.util.type.DateTime timeParticipatedDate = curam.util.type.DateTime.kZeroDateTime;

    // BEGIN CR00135076, GBA
    int iHours = 0;
    int iMinutes = 0;
    boolean totalTimeEntered = false;

    if (plannedItemDailyAttendanceDetails.dtls.dtls.totalHours != null
      && !(plannedItemDailyAttendanceDetails.dtls.dtls.totalHours.equals(""))) {
      iHours = Integer.parseInt(
        plannedItemDailyAttendanceDetails.dtls.dtls.totalHours);
      totalTimeEntered = true;
    }

    if (plannedItemDailyAttendanceDetails.dtls.dtls.totalMinutes != null
      && !(plannedItemDailyAttendanceDetails.dtls.dtls.totalMinutes.equals(""))) {
      iMinutes = Integer.parseInt(
        plannedItemDailyAttendanceDetails.dtls.dtls.totalMinutes);
      totalTimeEntered = true;
    }

    if (totalTimeEntered) {
      // Add the values for hours and minutes to the time participated variable
      timeParticipatedDate = timeParticipatedDate.addTime(iHours, iMinutes, 0);

      // Assign the date time value to the return struct
      plannedItemDailyAttendanceDetails.timeParticipated = timeParticipatedDate;
    }
    // END CR00135076
    // END, CR00120342

    return plannedItemDailyAttendanceDetails;
  }

  // END, CR00114509

  // _________________________________________________________________________
  /**
   * Checks service plan security for case participation operations
   *
   * @param caseClientParticipationSecurityCheckKey Details of client
   * participation
   */
  @Override
  protected void checkCaseClientParticipationSecurityRights(
    CaseClientParticipationSecurityCheckKey
    caseClientParticipationSecurityCheckKey)
    throws AppException, InformationalException {

    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    // read case id
    servicePlanDeliveryKey.key.caseID = caseClientParticipationSecurityCheckKey.caseID;

    curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    ServicePlanSecurity servicePlanSecurityObj = new ServicePlanSecurity();

    ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // get service plan ID
    curam.serviceplans.sl.struct.ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      servicePlanDeliveryKey);

    CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    caseHeaderKey.caseID = servicePlanDeliveryKey.key.caseID;

    // get plan participant ID
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = caseClientParticipationSecurityCheckKey.operationType;

    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.key.servicePlanID;

    servicePlanSecurityObj.servicePlanOperationSecurityCheck(
      servicePlanOperationSecurityKey);

  }

  // _________________________________________________________________________
  /**
   * Checks service plan security for case participation operations
   *
   * @param planItemClientParticipationSecurityCheckKey Details of client participation
   */
  public void checkPlanItemClientParticipationSecurityRights(
    PlanItemClientParticipationSecurityCheckKey
    planItemClientParticipationSecurityCheckKey)
    throws AppException, InformationalException {

    // Service plan security check
    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    ServicePlanSecurity servicePlanSecurityObj = new ServicePlanSecurity();

    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

    if (planItemClientParticipationSecurityCheckKey.caseID == 0) {

      // read case ID using planned item ID
      PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

      PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

      plannedItemIDKey.plannedItemID = planItemClientParticipationSecurityCheckKey.plannedItemID;

      planItemClientParticipationSecurityCheckKey.caseID = plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey).caseID;
    }

    servicePlanDeliveryKey.key.caseID = planItemClientParticipationSecurityCheckKey.caseID;

    // get service plan ID
    ServicePlanKey servicePlanKey = servicePlanDeliveryObj.readServicePlanID(
      servicePlanDeliveryKey);

    // assign operation type
    servicePlanSecurityKey.securityCheckType = planItemClientParticipationSecurityCheckKey.operationType;

    // assign service plan ID
    servicePlanSecurityKey.servicePlanID = servicePlanKey.key.servicePlanID;

    // check security rights against operation SID and participant sensitivity
    // ServicePlanSecurityResult servicePlanSecurityResult;

    servicePlanSecurityObj.servicePlanSecurityCheck(servicePlanSecurityKey);

    // get exceptions
    curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

    plannedItemKey.plannedItemIDKey.plannedItemID = planItemClientParticipationSecurityCheckKey.plannedItemID;

    servicePlanSecurityObj.planItemSensitivityCheck(plannedItemKey);

  }

  // BEGIN, CR00114509, PMD
  // _________________________________________________________________________
  /**
   * @param caseDailyAttendanceSummaryDetailsList
   * List of Client Participations for service plan
   *
   * @return List of daily attendances for a service plan with
   * restricted information
   *
   * @deprecated This method is replaced by {@link #filterByPlannedItemSensitivity()} 
   * Filters list by planItem/user sensitivity level
   */
  @Deprecated
  public CaseDailyAttendanceDetailsAsStringsList filterByPlanItemSensitivity(
    CaseDailyAttendanceSummaryDetailsList caseDailyAttendanceSummaryDetailsList)
    throws AppException, InformationalException {

    CaseDailyAttendanceDetailsAsStringsList caseDailyAttendanceDetailsAsStringsList = new CaseDailyAttendanceDetailsAsStringsList();

    // read sensitivity of current user
    Users userObj = curam.core.fact.UsersFactory.newInstance();

    SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    UsersKey usersKey = new UsersKey();

    // get the current user's details
    SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    usersKey.userName = systemUserDtls.userName;

    java.lang.String userSensitivityCode = new String(
      userObj.readSensitivityCode(usersKey).sensitivity);

    int numberOfRecords = caseDailyAttendanceSummaryDetailsList.dtlsList.dtls.size();

    PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    curam.serviceplans.sl.entity.struct.PlannedItemKey plannedItemKey = new
      curam.serviceplans.sl.entity.struct.PlannedItemKey();

    // ensure capacity of return list
    caseDailyAttendanceDetailsAsStringsList.detailsAsStrings.ensureCapacity(
      numberOfRecords);

    for (int i = 0; i < numberOfRecords; i++) {

      CaseDailyAttendanceSummaryDtls currentDetails = new CaseDailyAttendanceSummaryDtls();

      CaseDailyAttendanceDetailsAsStrings caseDailyAttendanceDetailsAsStrings = new CaseDailyAttendanceDetailsAsStrings();

      currentDetails = caseDailyAttendanceSummaryDetailsList.dtlsList.dtls.item(
        i);

      plannedItemKey.plannedItemID = currentDetails.plannedItemID;

      caseDailyAttendanceDetailsAsStrings.dailyAttendanceID = currentDetails.dailyAttendanceID;
      caseDailyAttendanceDetailsAsStrings.plannedItemID = currentDetails.plannedItemID;

      // if user sensitivity < plan item sensitivity
      if (Integer.parseInt(userSensitivityCode)
        < Integer.parseInt(
          plannedItemObj.readSensitivityCode(plannedItemKey).sensitivityCode)) {

        // BEGIN, CR00116151, CSH
        // BEGIN, CR00002667, PMD
        caseDailyAttendanceDetailsAsStrings.name = caseDailyAttendanceDetailsAsStrings.attendance = caseDailyAttendanceDetailsAsStrings.recordStatus = caseDailyAttendanceDetailsAsStrings.totalHours = caseDailyAttendanceDetailsAsStrings.totalMinutes = CuramConst.gkRestricted;

        caseDailyAttendanceDetailsAsStrings.serviceDate = curam.util.type.Date.kZeroDate;
        // END, CR00002667
        // END, CR00116151

      } else {

        // BEGIN, CR00002667, PMD
        caseDailyAttendanceDetailsAsStrings.serviceDate = currentDetails.serviceDate;
        // END, CR00002667

        // BEGIN, CR00116151, CSH
        caseDailyAttendanceDetailsAsStrings.name = currentDetails.name;
        caseDailyAttendanceDetailsAsStrings.totalHours = currentDetails.totalHours;
        caseDailyAttendanceDetailsAsStrings.totalMinutes = currentDetails.totalMinutes;
        // END, CR00116151

        // BEGIN CR00126106, GBA
        caseDailyAttendanceDetailsAsStrings.createdBySystem = currentDetails.createdBySystem;
        // END CR00126106

        caseDailyAttendanceDetailsAsStrings.attendance = curam.util.type.CodeTable.getOneItemForUserLocale(
          ATTENDANCE.TABLENAME, currentDetails.attendance);

        caseDailyAttendanceDetailsAsStrings.recordStatus = curam.util.type.CodeTable.getOneItemForUserLocale(
          RECORDSTATUS.TABLENAME, currentDetails.recordStatus);

      }

      caseDailyAttendanceDetailsAsStringsList.detailsAsStrings.addRef(
        caseDailyAttendanceDetailsAsStrings);

    }

    return caseDailyAttendanceDetailsAsStringsList;
  }

  // _________________________________________________________________________
  /**
   * Filters list by planItem/user sensitivity level
   *
   * @param caseAttendanceForDateList List of attendances for service plan for date
   *
   * @return List of attendances for service plan for date
   * with restricted information
   */
  public CaseDailyAttendanceDetailsAsStringsList filterListForDateByPlanItemSensitivity(
    CaseDailyAttendanceSummaryDetailsList caseAttendanceForDateList)
    throws AppException, InformationalException {

    // read sensitivity of current user
    Users userObj = curam.core.fact.UsersFactory.newInstance();

    SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    UsersKey usersKey = new UsersKey();

    // get the current user's details
    SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    usersKey.userName = systemUserDtls.userName;

    java.lang.String userSensitivityCode = new String(
      userObj.readSensitivityCode(usersKey).sensitivity);

    int numberOfRecords = caseAttendanceForDateList.dtlsList.dtls.size();

    PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    curam.serviceplans.sl.entity.struct.PlannedItemKey plannedItemKey = new
      curam.serviceplans.sl.entity.struct.PlannedItemKey();

    CaseDailyAttendanceDetailsAsStringsList caseDailyAttendanceDetailsAsStringsList = new CaseDailyAttendanceDetailsAsStringsList();

    for (int i = 0; i < numberOfRecords; i++) {

      CaseDailyAttendanceSummaryDtls currentListDetails = new CaseDailyAttendanceSummaryDtls();

      CaseDailyAttendanceDetailsAsStrings caseDailyAttendanceDetailsAsStrings = new CaseDailyAttendanceDetailsAsStrings();

      currentListDetails = caseAttendanceForDateList.dtlsList.dtls.item(i);

      plannedItemKey.plannedItemID = currentListDetails.plannedItemID;

      // if user sensitivity < plan item sensitivity
      if (Integer.parseInt(userSensitivityCode)
        < Integer.parseInt(
          plannedItemObj.readSensitivityCode(plannedItemKey).sensitivityCode)) {

        // BEGIN, CR00116151, CSH
        caseDailyAttendanceDetailsAsStrings.name = caseDailyAttendanceDetailsAsStrings.attendance = caseDailyAttendanceDetailsAsStrings.recordStatus = caseDailyAttendanceDetailsAsStrings.totalHours = caseDailyAttendanceDetailsAsStrings.totalMinutes = CuramConst.gkRestricted;

      } else {

        caseDailyAttendanceDetailsAsStrings.name = currentListDetails.name;
        caseDailyAttendanceDetailsAsStrings.totalHours = currentListDetails.totalHours;
        caseDailyAttendanceDetailsAsStrings.totalMinutes = currentListDetails.totalMinutes;
        // END, CR00116151

        caseDailyAttendanceDetailsAsStrings.attendance = curam.util.type.CodeTable.getOneItemForUserLocale(
          ATTENDANCE.TABLENAME, currentListDetails.attendance);

        caseDailyAttendanceDetailsAsStrings.recordStatus = curam.util.type.CodeTable.getOneItemForUserLocale(
          RECORDSTATUS.TABLENAME, currentListDetails.recordStatus);

      }

      caseDailyAttendanceDetailsAsStringsList.detailsAsStrings.addRef(
        caseDailyAttendanceDetailsAsStrings);
    }

    return caseDailyAttendanceDetailsAsStringsList;

  }

  // _________________________________________________________________________
  /**
   * @param planItemClientParticipationSearchKey Planned Item identifier
   *
   * @return List of Daily Attendance details for planItem
   * @deprecated This method is replaced by {@link #listForPlannedItem()} 
   * Lists all daily attendance records for particular planItem.
   */
  @Deprecated
  public PIDailyAttendanceSummaryDetailsList listForPlanItem(
    PlanItemClientParticipationSearchKey planItemClientParticipationSearchKey)
    throws AppException, InformationalException {

    // Service plan security check
    PlanItemClientParticipationSecurityCheckKey planItemClientParticipationSecurityCheckKey = new PlanItemClientParticipationSecurityCheckKey();

    planItemClientParticipationSecurityCheckKey.plannedItemID = planItemClientParticipationSearchKey.plannedItemIDKey.plannedItemID;

    planItemClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkPlanItemClientParticipationSecurityRights(
        planItemClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        // user-plan item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_PLAN_ITEM_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // PIDailyAttendanceLink manipulation variables
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    // Return struct
    PIDailyAttendanceSummaryDetailsList piDailyAttendanceSummaryDetailsList = new PIDailyAttendanceSummaryDetailsList();

    // Get the list of daily attendances
    piDailyAttendanceSummaryDetailsList.piDtlsList = piDailyAttendanceLinkObj.searchDailyAttendanceByPlannedItemID(
      planItemClientParticipationSearchKey.plannedItemIDKey);

    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = planItemClientParticipationSearchKey.plannedItemIDKey.plannedItemID;

    // Get the planned item name
    piDailyAttendanceSummaryDetailsList.name = plannedItemObj.read(plannedItemKey).name;

    return piDailyAttendanceSummaryDetailsList;

  }
  
  // BEGIN, CR00168425, GBA
  /**
   * This method replaces the deprecated method {@link #listForPlanItem()} Lists
   * all daily attendance records for particular planItem.
   *
   * @param planItemClientParticipationSearchKey
   * Contains Plan Item identifier
   *
   * @return List of Daily Attendance details for planItem
   *
   * @throws AppException
   * {@link BPOCLIENTPARTICIPATION#ERR_CLIENTPARTICIPATION_VIEW_PLAN_ITEM_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * these client participation details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOCLIENTPARTICIPATION#ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this service plan.
   */
  public PIDailyAttendanceDetailsList listForPlannedItem(
    PlanItemClientParticipationSearchKey planItemClientParticipationSearchKey)
    throws AppException, InformationalException {

    // Service plan security check
    PlanItemClientParticipationSecurityCheckKey planItemClientParticipationSecurityCheckKey = new PlanItemClientParticipationSecurityCheckKey();

    planItemClientParticipationSecurityCheckKey.plannedItemID = planItemClientParticipationSearchKey.plannedItemIDKey.plannedItemID;

    planItemClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkPlanItemClientParticipationSecurityRights(
        planItemClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        // user-plan item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_PLAN_ITEM_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // PIDailyAttendanceLink manipulation variables
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    // Return struct
    PIDailyAttendanceDetailsList piDailyAttendanceDetailsList = new PIDailyAttendanceDetailsList();

    // Get the list of daily attendances
    piDailyAttendanceDetailsList.piDtlsList = piDailyAttendanceLinkObj.searchDailyAttendanceByPlannedItem(
      planItemClientParticipationSearchKey.plannedItemIDKey);

    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = planItemClientParticipationSearchKey.plannedItemIDKey.plannedItemID;

    // BEGIN, CR00236077, NS
    final PlannedItemDtls planItemDtls = plannedItemObj.read(plannedItemKey);
    final PlanItem planItemObj = PlanItemFactory.newInstance();
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = planItemDtls.planItemID;
    final NameNotEditableIndDetails nameNotEditableIndDetails = planItemObj.readNameNotEditableIndDetails(
      planItemKey);

    if (nameNotEditableIndDetails.nameNotEditableInd) {
      piDailyAttendanceDetailsList.name = CodeTable.getOneItem(
        PLANITEMNAME.TABLENAME, nameNotEditableIndDetails.name,
        TransactionInfo.getProgramLocale());
    } else {
      piDailyAttendanceDetailsList.name = planItemDtls.name;
    }
    // END, CR00236077

    return piDailyAttendanceDetailsList;

  }
  
  // _________________________________________________________________________
  /**
   * This method replaces the deprecated method {@link #listForPlanItemForWeek()}
   * Lists all attendance records with time absent information for particular 
   * plan item for week specified.
   *
   * @param planItemAndDateRangeKey Contains Plan Item identifier and date range
   *
   * @return List of daily attendance details for planItem
   * for week specified
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PIDailyAttendanceDetailsList listForPlannedItemForWeek(
    PlanItemAndDateRangeKey planItemAndDateRangeKey)
    throws AppException, InformationalException {

    // validation about for range
    Calendar dateUnderCheck = planItemAndDateRangeKey.participationsPlanItemAndDateRangeKey.fromDate.getCalendar();

    // get date for Monday of the week
    if (dateUnderCheck.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_FROM_DATE_IS_NOT_MONDAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    dateUnderCheck = planItemAndDateRangeKey.participationsPlanItemAndDateRangeKey.toDate.getCalendar();

    // get date for Monday of the week
    if (dateUnderCheck.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_TO_DATE_IS_NOT_SUNDAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    PlanItemClientParticipationSecurityCheckKey planItemClientParticipationSecurityCheckKey = new PlanItemClientParticipationSecurityCheckKey();

    // Check Service Plan security before returning details to user
    planItemClientParticipationSecurityCheckKey.plannedItemID = planItemAndDateRangeKey.participationsPlanItemAndDateRangeKey.plannedItemID;

    planItemClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkPlanItemClientParticipationSecurityRights(
        planItemClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        // user-plan item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_PLAN_ITEM_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // PIDailyAttendanceLink manipulation variables
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    PIDailyAttendanceDetailsList piDailyAttendanceDetailsList = new PIDailyAttendanceDetailsList();

    // Get the list of attendance for the planned item
    piDailyAttendanceDetailsList.piDtlsList = piDailyAttendanceLinkObj.searchByPlannedItemIDForDateRange(
      planItemAndDateRangeKey.participationsPlanItemAndDateRangeKey);

    return piDailyAttendanceDetailsList;

  }

  // END, CR00168425

  // _________________________________________________________________________
  /**
   * @param planItemAndDateRangeKey Planned Item identifier and date range
   *
   * @return List of daily attendance details for planItem
   * for week specified
   * @deprecated This method is replaced by {@link #listForPlannedItemForWeek()} 
   * Lists all attendance records for particular plan item for week specified.
   */
  @Deprecated
  public PIDailyAttendanceSummaryDetailsList listForPlanItemForWeek(
    PlanItemAndDateRangeKey planItemAndDateRangeKey)
    throws AppException, InformationalException {

    // validation about for range
    Calendar dateUnderCheck = planItemAndDateRangeKey.participationsPlanItemAndDateRangeKey.fromDate.getCalendar();

    // get date for Monday of the week
    if (dateUnderCheck.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_FROM_DATE_IS_NOT_MONDAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    dateUnderCheck = planItemAndDateRangeKey.participationsPlanItemAndDateRangeKey.toDate.getCalendar();

    // get date for Monday of the week
    if (dateUnderCheck.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_TO_DATE_IS_NOT_SUNDAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);
    }

    PlanItemClientParticipationSecurityCheckKey planItemClientParticipationSecurityCheckKey = new PlanItemClientParticipationSecurityCheckKey();

    // Check Service Plan security before returning details to user
    planItemClientParticipationSecurityCheckKey.plannedItemID = planItemAndDateRangeKey.participationsPlanItemAndDateRangeKey.plannedItemID;

    planItemClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkPlanItemClientParticipationSecurityRights(
        planItemClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        // user-plan item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_PLAN_ITEM_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // PIDailyAttendanceLink manipulation variables
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    PIDailyAttendanceSummaryDetailsList piDailyAttendanceSummaryDetailsList = new PIDailyAttendanceSummaryDetailsList();

    // Get the list of attendance for the planned item
    piDailyAttendanceSummaryDetailsList.piDtlsList = piDailyAttendanceLinkObj.searchByPlannedItemIDForDatesRange(
      planItemAndDateRangeKey.participationsPlanItemAndDateRangeKey);

    return piDailyAttendanceSummaryDetailsList;

  }

  // _________________________________________________________________________
  /**
   * @param caseClientParticipationSearchKey Service Plan identifier
   *
   * @return List of daily attendance details for service plan
   *
   * @deprecated This method is replaced by {@link #listForServicePlan()} 
   * Lists all daily attendance records for a service plan.
   */
  @Deprecated
  public CaseDailyAttendanceDetailsAsStringsList listForCase(
    CaseClientParticipationSearchKey caseClientParticipationSearchKey)
    throws AppException, InformationalException {

    // security check key
    CaseClientParticipationSecurityCheckKey caseClientParticipationSecurityCheckKey = new CaseClientParticipationSecurityCheckKey();

    caseClientParticipationSecurityCheckKey.caseID = caseClientParticipationSearchKey.servicePlanDeliveyKey.caseID;
    caseClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkCaseClientParticipationSecurityRights(
        caseClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // user-participant item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_READ_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // PIDailyAttendanceLink manipulation variable
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    CaseDailyAttendanceSummaryDetailsList caseDailyAttendanceSummaryDetailsList = new CaseDailyAttendanceSummaryDetailsList();

    // Search for daily attendances
    caseDailyAttendanceSummaryDetailsList.dtlsList = piDailyAttendanceLinkObj.searchDailyAttendanceByCaseID(
      caseClientParticipationSearchKey.servicePlanDeliveyKey);

    CaseDailyAttendanceDetailsAsStringsList CaseDailyAttendanceDetailsAsStringsList = filterByPlanItemSensitivity(
      caseDailyAttendanceSummaryDetailsList);

    return CaseDailyAttendanceDetailsAsStringsList;
  }
  
  // BEGIN, CR00168425, GBA
  // _________________________________________________________________________
  /**
   * This method replaces the deprecated method {@link #listForCase()} 
   * Lists all daily attendance records for a service plan.
   *
   * @param caseClientParticipationSearchKey Contains Service Plan identifier
   *
   * @return List of daily attendance details for service plan
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ServicePlanDailyAttendanceList listForServicePlan(
    CaseClientParticipationSearchKey caseClientParticipationSearchKey)
    throws AppException, InformationalException {

    // security check key
    CaseClientParticipationSecurityCheckKey caseClientParticipationSecurityCheckKey = new CaseClientParticipationSecurityCheckKey();

    caseClientParticipationSecurityCheckKey.caseID = caseClientParticipationSearchKey.servicePlanDeliveyKey.caseID;
    caseClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkCaseClientParticipationSecurityRights(
        caseClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // user-participant item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_READ_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // PIDailyAttendanceLink manipulation variable
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    ServicePlanDailyAttendanceList servicePlanDailyAttendanceList = new ServicePlanDailyAttendanceList();

    // Search for daily attendances
    servicePlanDailyAttendanceList.dtlsList = piDailyAttendanceLinkObj.searchDailyAttendancesByCaseID(
      caseClientParticipationSearchKey.servicePlanDeliveyKey);

    filterByPlannedItemSensitivity(servicePlanDailyAttendanceList);

    return servicePlanDailyAttendanceList;
  }

  // _________________________________________________________________________
  /**
   * This method replaces the deprecated method {@link #filterByPlanItemSensitivity()}
   * Filters list by planItem/user sensitivity level
   *
   * @param ServicePlanDailyAttendanceList
   * List of Client Participations for service plan
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void filterByPlannedItemSensitivity(
    ServicePlanDailyAttendanceList details) throws AppException,
      InformationalException {

    // read sensitivity of current user
    Users userObj = curam.core.fact.UsersFactory.newInstance();

    SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    UsersKey usersKey = new UsersKey();

    // get the current user's details
    SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    usersKey.userName = systemUserDtls.userName;

    String userSensitivityCode = new String(
      userObj.readSensitivityCode(usersKey).sensitivity);

    int numberOfRecords = details.dtlsList.dtls.size();

    PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    curam.serviceplans.sl.entity.struct.PlannedItemKey plannedItemKey = new
      curam.serviceplans.sl.entity.struct.PlannedItemKey();

    for (int i = 0; i < numberOfRecords; i++) {

      plannedItemKey.plannedItemID = details.dtlsList.dtls.item(i).plannedItemID;

      // if user sensitivity < plan item sensitivity
      if (Integer.parseInt(userSensitivityCode)
        < Integer.parseInt(
          plannedItemObj.readSensitivityCode(plannedItemKey).sensitivityCode)) {

        details.dtlsList.dtls.item(i).name = details.dtlsList.dtls.item(i).attendance = details.dtlsList.dtls.item(i).recordStatus = details.dtlsList.dtls.item(i).totalHours = details.dtlsList.dtls.item(i).totalMinutes = details.dtlsList.dtls.item(i).hoursAbsent = details.dtlsList.dtls.item(i).minutesAbsent = CuramConst.gkRestricted;

        details.dtlsList.dtls.item(i).serviceDate = curam.util.type.Date.kZeroDate;
      } 
    }
  }
  
  // _________________________________________________________________________
  /**
   * This method replaces the deprecated method {@link #listForCaseForWeek()}
   * Lists daily attendance records with time absent information for 
   * the service plan specified.
   *
   * @param caseAndDateRangeKey Contains Service Plan identifier and date range
   *
   * @return List of daily attendance details for service plan
   * for week specified
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ServicePlanDailyAttendanceList listForServicePlanForWeek(
    CaseAndDateRangeKey caseAndDateRangeKey)
    throws AppException, InformationalException {

    // validation about for range
    Calendar dateUnderCheck = caseAndDateRangeKey.participationsForCaseAndDateRangeKey.fromDate.getCalendar();

    // get date for Monday of the week
    if (dateUnderCheck.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_FROM_DATE_IS_NOT_MONDAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);
    }

    dateUnderCheck = caseAndDateRangeKey.participationsForCaseAndDateRangeKey.toDate.getCalendar();

    // get date for Monday of the week
    if (dateUnderCheck.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_TO_DATE_IS_NOT_SUNDAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // security check
    CaseClientParticipationSecurityCheckKey caseClientParticipationSecurityCheckKey = new CaseClientParticipationSecurityCheckKey();

    caseClientParticipationSecurityCheckKey.caseID = caseAndDateRangeKey.participationsForCaseAndDateRangeKey.caseID;

    caseClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkCaseClientParticipationSecurityRights(
        caseClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // user-participant item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_READ_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // PIDailyAttendanceLink manipulation variables
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    ServicePlanDailyAttendanceList servicePlanDailyAttendanceList = new ServicePlanDailyAttendanceList();

    // Search for daily attendances
    servicePlanDailyAttendanceList.dtlsList = piDailyAttendanceLinkObj.searchDailyAttendancesByCaseIDAndDateRange(
      caseAndDateRangeKey.participationsForCaseAndDateRangeKey);

    filterByPlannedItemSensitivity(servicePlanDailyAttendanceList);

    return servicePlanDailyAttendanceList;

  }

  // END, CR00168425

  // _________________________________________________________________________
  /**
   * @param caseAndDateRangeKey Service Plan identifier and date range
   *
   * @return List of daily attendance details for service plan
   * for week specified
   *
   * @deprecated This method is replaced by {@link #listForServicePlanForWeek()}
   * Lists daily attendance records for service plan specified.
   */
  @Deprecated
  public CaseDailyAttendanceDetailsAsStringsList listForCaseForWeek(
    CaseAndDateRangeKey caseAndDateRangeKey)
    throws AppException, InformationalException {

    // validation about for range
    Calendar dateUnderCheck = caseAndDateRangeKey.participationsForCaseAndDateRangeKey.fromDate.getCalendar();

    // get date for Monday of the week
    if (dateUnderCheck.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_FROM_DATE_IS_NOT_MONDAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    dateUnderCheck = caseAndDateRangeKey.participationsForCaseAndDateRangeKey.toDate.getCalendar();

    // get date for Monday of the week
    if (dateUnderCheck.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_TO_DATE_IS_NOT_SUNDAY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // security check
    CaseClientParticipationSecurityCheckKey caseClientParticipationSecurityCheckKey = new CaseClientParticipationSecurityCheckKey();

    caseClientParticipationSecurityCheckKey.caseID = caseAndDateRangeKey.participationsForCaseAndDateRangeKey.caseID;

    caseClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkCaseClientParticipationSecurityRights(
        caseClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // user-participant item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_READ_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // PIDailyAttendanceLink manipulation variables
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    CaseDailyAttendanceSummaryDetailsList caseDailyAttendanceSummaryDetailsList = new CaseDailyAttendanceSummaryDetailsList();

    caseDailyAttendanceSummaryDetailsList.dtlsList = piDailyAttendanceLinkObj.searchDailyAttendanceByCaseIDAndDateRange(
      caseAndDateRangeKey.participationsForCaseAndDateRangeKey);

    CaseDailyAttendanceDetailsAsStringsList caseDailyAttendanceDetailsAsStringsList = filterByPlanItemSensitivity(
      caseDailyAttendanceSummaryDetailsList);

    return caseDailyAttendanceDetailsAsStringsList;

  }

  // _________________________________________________________________________
  /**
   * Gets list of attendance records for service plan for date
   *
   * @param participationCaseAndDateKey Contains planned service plan ID and date
   *
   * @return List of attendance records for service plan for date
   */
  public CaseDailyAttendanceDetailsAsStringsList listForCaseForDate(
    ParticipationCaseAndDateKey participationCaseAndDateKey)
    throws AppException, InformationalException {

    // security check
    CaseClientParticipationSecurityCheckKey caseClientParticipationSecurityCheckKey = new
      CaseClientParticipationSecurityCheckKey();

    caseClientParticipationSecurityCheckKey.caseID = participationCaseAndDateKey.participationsForCaseAndDateKey.caseID;

    caseClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkCaseClientParticipationSecurityRights(
        caseClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // user-participant item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_READ_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    CaseDailyAttendanceSummaryDetailsList caseDailyAttendanceSummaryDetailsList = new CaseDailyAttendanceSummaryDetailsList();

    // Get the list of attendances for case and date
    caseDailyAttendanceSummaryDetailsList.dtlsList = piDailyAttendanceLinkObj.searchDailyAttendanceByCaseIDAndDate(
      participationCaseAndDateKey.participationsForCaseAndDateKey);

    CaseDailyAttendanceDetailsAsStringsList caseDailyAttendanceDetailsAsStringsList = filterListForDateByPlanItemSensitivity(
      caseDailyAttendanceSummaryDetailsList);

    return caseDailyAttendanceDetailsAsStringsList;

  }

  // END, CR00114509

  // _________________________________________________________________________
  /**
   * Makes summary of total time and participation type for every week.
   *
   * @param weeklyParticipationDetailsList List of details required for
   * weekly attendance summary
   *
   * @return List of weekly Daily Attendance details
   */
  public WeeklyParticipationSummaryDetailsList summarizeWeeklyParticipationForList(
    WeeklyParticipationDetailsList weeklyParticipationDetailsList)
    throws AppException, InformationalException {

    WeeklyParticipationSummaryDetailsList weeklyParticipationSummaryDetailsList = new WeeklyParticipationSummaryDetailsList();

    // BEGIN, CR00114509, PMD
    AttendanceServiceDateAndTime attendanceServiceDateAndTime = new AttendanceServiceDateAndTime();

    int numberOfRecords = weeklyParticipationDetailsList.attendanceSummaryDetailsList.dtls.size();

    if (numberOfRecords > 0) {

      Date dateUpper = weeklyParticipationDetailsList.attendanceSummaryDetailsList.dtls.item(0).serviceDate;

      Calendar calendarDateUpper = dateUpper.getCalendar();

      while (calendarDateUpper.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
        calendarDateUpper.add(Calendar.DATE, 1);
      }

      Date dateLower = weeklyParticipationDetailsList.attendanceSummaryDetailsList.dtls.item(numberOfRecords - 1).serviceDate;

      Calendar calendarDateLower = dateLower.getCalendar();

      while (calendarDateLower.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY) {
        calendarDateLower.add(Calendar.DATE, -1);
      }

      dateUpper = new Date(calendarDateUpper);
      dateLower = new Date(calendarDateLower);

      int currentItem = 0;

      long numberOfHoursForWeek = 0;
      long numberOfMinutesForWeek = 0;

      // list is sorted by date descending
      for (Date date = dateUpper; !date.before(dateLower)
        && (currentItem < numberOfRecords); date = date.addDays(-kDaysInWeek)) {

        attendanceServiceDateAndTime = weeklyParticipationDetailsList.attendanceSummaryDetailsList.dtls.item(
          currentItem);

        WeeklyParticipationSummaryDetails weeklyParticipationSummaryDetails = new WeeklyParticipationSummaryDetails();

        // this is Monday
        weeklyParticipationSummaryDetails.fromDate = date.addDays(
          -kDaysInWeek + 1);

        // this is Sunday
        weeklyParticipationSummaryDetails.toDate = date;

        weeklyParticipationSummaryDetails.participationTypeInd = false;

        curam.util.exception.LocalisableString totalTimeString = new curam.util.exception.LocalisableString(
          BPOCLIENTPARTICIPATION.TOTAL_TIME_STRING);

        while (!attendanceServiceDateAndTime.serviceDate.before(
          weeklyParticipationSummaryDetails.fromDate)) {

          if (!attendanceServiceDateAndTime.attendance.equals(ATTENDANCE.ABSENT)) {

            // BEGIN, CR00116151, CSH
            // BEGIN HARP 53333 HMB
            // BEGIN CR00135076, GBA
            // Accumulate hours and minutes
            if (attendanceServiceDateAndTime.totalHours != null
              && !(attendanceServiceDateAndTime.totalHours.equals(""))) {
              numberOfHoursForWeek += Integer.parseInt(
                attendanceServiceDateAndTime.totalHours);
            }
            if (attendanceServiceDateAndTime.totalMinutes != null
              && !(attendanceServiceDateAndTime.totalMinutes.equals(""))) {
              numberOfMinutesForWeek += Integer.parseInt(
                attendanceServiceDateAndTime.totalMinutes);
            }
            // END CR00135076
            // END HARP 53333
            // END, CR00116151
          }

          // move to the next item in the list
          if (++currentItem < numberOfRecords) {
            attendanceServiceDateAndTime = weeklyParticipationDetailsList.attendanceSummaryDetailsList.dtls.item(
              currentItem);
          } else {
            break;
          }
        }
        // BEGIN HARP 53333 HMB
        if (numberOfMinutesForWeek >= MINUTESPERHOUR) {
          long hourCount = numberOfMinutesForWeek / MINUTESPERHOUR;
          long minuteRemainder = numberOfMinutesForWeek % MINUTESPERHOUR;

          numberOfHoursForWeek += hourCount;
          numberOfMinutesForWeek = minuteRemainder;
        }
        // END HARP 53333

        // if item total time was calculated and (next record belongs to another week OR if there are no next records)
        // if item total time was not calculated as it belongs to another week
        if ((currentItem >= numberOfRecords)
          || ((currentItem < numberOfRecords)
            && attendanceServiceDateAndTime.serviceDate.before(
              weeklyParticipationSummaryDetails.fromDate))) {

          String hours = new String();

          if (numberOfHoursForWeek < minTwoDigitNumber) {
            hours = hours + kZeroValueString
              + String.valueOf(numberOfHoursForWeek);
          } else {
            hours = hours + String.valueOf(numberOfHoursForWeek);
          }

          String minutes = new String();

          if (numberOfMinutesForWeek < minTwoDigitNumber) {
            minutes = minutes + kZeroValueString
              + String.valueOf(numberOfMinutesForWeek);
          } else {
            minutes = minutes + String.valueOf(numberOfMinutesForWeek);
          }

          totalTimeString.arg(hours);
          totalTimeString.arg(minutes);

          // BEGIN, CR00163659, CL
          weeklyParticipationSummaryDetails.totalTimeForWeek = totalTimeString.getMessage(
            TransactionInfo.getProgramLocale());
          // END, CR00163659

          // add details to the list
          weeklyParticipationSummaryDetailsList.weeklyParticipatonSummaryDetails.add(
            weeklyParticipationSummaryDetails);

          // reset number of hours and minutes as calculation for next week will start
          numberOfHoursForWeek = 0l;
          numberOfMinutesForWeek = 0l;

        }
      }
    }// end if

    // END, CR00114509
    return weeklyParticipationSummaryDetailsList;
  }

  // _________________________________________________________________________
  /**
   * Gets chart of client participation weekly summary for planItem
   *
   * @param planItemActiveClientParticipationSearchKey Contains case
   * ID and dates range
   *
   * @return XML string containing client participation weekly summary for planItem
   */
  public PlanItemChartDetails weeklyChartForPlanItem(
    PlanItemActiveClientParticipationSearchKey
    planItemActiveClientParticipationSearchKey)
    throws AppException, InformationalException {

    return null;

  }

  // _________________________________________________________________________
  /**
   * Gets chart of client participation weekly summary for case
   *
   * @param caseActiveClientParticipationsKey Contains case ID and
   * dates range
   *
   * @return XML client participation weekly summary for case
   */
  public ClientParticipationXMLString weeklyChartForCase(
    CaseActiveClientParticipationsKey
    caseActiveClientParticipationsKey)
    throws AppException, InformationalException {
    return null;

  }

  // _________________________________________________________________________
  /**
   * Gets list of weekly client participation for planItem.
   *
   * @param planItemActiveClientParticipationSearchKey Contains planned
   * plan item ID, dates and record status
   *
   * @return List of details required for weekly participation summary
   */
  public WeeklyParticipationSummaryDetailsList weeklyListForPlanItem(
    PlanItemActiveClientParticipationSearchKey
    planItemActiveClientParticipationSearchKey)
    throws AppException, InformationalException {

    PlanItemClientParticipationSecurityCheckKey planItemClientParticipationSecurityCheckKey = new PlanItemClientParticipationSecurityCheckKey();

    // Check Service Plan security before returning details to user
    planItemClientParticipationSecurityCheckKey.plannedItemID = planItemActiveClientParticipationSearchKey.activeClientParticipationsForPlanItemKey.plannedItemID;

    planItemClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkPlanItemClientParticipationSecurityRights(
        planItemClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        // user-plan item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_PLAN_ITEM_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // BEGIN, CR00114509, PMD
    // PIDailyAttendanceLink manipulation variables
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    WeeklyParticipationDetailsList weeklyParticipationDetailsList = new WeeklyParticipationDetailsList();

    planItemActiveClientParticipationSearchKey.activeClientParticipationsForPlanItemKey.recordStatus = RECORDSTATUS.CANCELLED;

    // Get the list of weekly attendances
    weeklyParticipationDetailsList.attendanceSummaryDetailsList = piDailyAttendanceLinkObj.searchWeeklyAttendanceForPlannedItem(
      planItemActiveClientParticipationSearchKey.activeClientParticipationsForPlanItemKey);
    // END, CR00114509

    WeeklyParticipationSummaryDetailsList weeklyParticipationSummaryDetailsList = summarizeWeeklyParticipationForList(
      weeklyParticipationDetailsList);

    curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    curam.serviceplans.sl.struct.PlannedItemIDKey plannedItemIDKey = new curam.serviceplans.sl.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemID = planItemActiveClientParticipationSearchKey.activeClientParticipationsForPlanItemKey.plannedItemID;

    // Get the planned item name
    weeklyParticipationSummaryDetailsList.name = (plannedItemObj.readPlannedItemDetails(plannedItemIDKey)).plannedItemDtls.name;

    return weeklyParticipationSummaryDetailsList;

  }

  // _________________________________________________________________________
  /**
   * Gets weekly list of daily attendance for service plan.
   *
   * @param caseActiveClientParticipationsKey Contains planned service
   * plan ID, dates and record status
   *
   * @return List of details required for weekly attendance summary
   */
  public WeeklyParticipationSummaryDetailsList weeklyListForCase(
    CaseActiveClientParticipationsKey caseActiveClientParticipationsKey)
    throws AppException, InformationalException {

    // security check
    CaseClientParticipationSecurityCheckKey caseClientParticipationSecurityCheckKey = new CaseClientParticipationSecurityCheckKey();

    caseClientParticipationSecurityCheckKey.caseID = caseActiveClientParticipationsKey.activeClientParticipationForCaseKey.caseID;
    caseClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kReadSecurityCheck;

    try {
      checkCaseClientParticipationSecurityRights(
        caseClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // user-participant item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_READ_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // BEGIN, CR00114509, PMD
    // DailyAttendance manipulation variables
    curam.core.sl.entity.intf.DailyAttendance dailyAttendanceObj = curam.core.sl.entity.fact.DailyAttendanceFactory.newInstance();

    CaseIDRecordStatus caseIDRecordStatus = new CaseIDRecordStatus();

    WeeklyParticipationDetailsList weeklyParticipationDetailsList = new WeeklyParticipationDetailsList();

    // Set the search key
    caseIDRecordStatus.statusCode = RECORDSTATUS.CANCELLED;
    caseIDRecordStatus.caseID = caseActiveClientParticipationsKey.activeClientParticipationForCaseKey.caseID;

    weeklyParticipationDetailsList.attendanceSummaryDetailsList = dailyAttendanceObj.searchSummaryDetailsByCaseIDAndStatus(
      caseIDRecordStatus);
    // END, CR00114509

    WeeklyParticipationSummaryDetailsList weeklyParticipationSummaryDetailsList = summarizeWeeklyParticipationForList(
      weeklyParticipationDetailsList);

    return weeklyParticipationSummaryDetailsList;

  }

  // _________________________________________________________________________
  /**
   * Gets list of In Progress or Completed planItems for Plan Participant
   *
   * @param planItemsForClientParticipationSearchKey Contains plan item statuses
   * valid for creation of Client Participation
   *
   * @return List of details required for weekly participation summary
   */
  public PlannedItemNameAndIDDetailsList listPlanItemsForClientParticipation(
    PlanItemsForClientParticipationSearchKey planItemsForClientParticipationSearchKey)
    throws AppException, InformationalException {

    CaseClientParticipationSecurityCheckKey caseClientParticipationSecurityCheckKey = new CaseClientParticipationSecurityCheckKey();

    caseClientParticipationSecurityCheckKey.caseID = planItemsForClientParticipationSearchKey.planItemsForClientParticipationSearchKey.caseID;

    caseClientParticipationSecurityCheckKey.operationType = ServicePlanSecurity.kMaintainSecurityCheck;

    try {
      checkCaseClientParticipationSecurityRights(
        caseClientParticipationSecurityCheckKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_MAINTAIN_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // user-participant item sensitivity check failed
        throw new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_READ_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    PlannedItemNameAndIDDetailsList plannedItemNameAndIDDetailsList = new PlannedItemNameAndIDDetailsList();

    // BEGIN, CR00114509, PMD
    PlanItemsForDailyAttendanceSearchKey planItemsForDailyAttendanceSearchKey = new PlanItemsForDailyAttendanceSearchKey();

    planItemsForDailyAttendanceSearchKey.caseID = planItemsForClientParticipationSearchKey.planItemsForClientParticipationSearchKey.caseID;

    planItemsForDailyAttendanceSearchKey.responsibilityType1 = RESPONSIBILITYTYPE.CLIENT;

    planItemsForDailyAttendanceSearchKey.responsibilityType2 = RESPONSIBILITYTYPE.PARTICIPANT;

    planItemsForDailyAttendanceSearchKey.status1 = PLANNEDITEMSTATUS.INPROGRESS;

    planItemsForDailyAttendanceSearchKey.status2 = curam.codetable.PLANNEDITEMSTATUS.COMPLETED;

    // Get the list of plan items
    plannedItemNameAndIDDetailsList.plannedItemIDAndNameDetailsList = plannedItemObj.searchPlanItemsForDailyAttendance(
      planItemsForDailyAttendanceSearchKey);
    // END, CR00114509

    if (plannedItemNameAndIDDetailsList.plannedItemIDAndNameDetailsList.dtls.isEmpty()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_XRV_PLANNEDITEM_LIST_IS_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    return plannedItemNameAndIDDetailsList;

  }

  // BEGIN, CR00114509, PMD
  // _________________________________________________________________________
  /**
   * Validates participation details entered by user.
   *
   * @param details Details of the daily attendance to be
   * inserted or modified.
   */
  public void validateDetails(PlannedItemDailyAttendanceDetails details)
    throws AppException, InformationalException {

    // planned item should be provided
    if (details.plannedItemID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_PLAN_ITEM_NOT_PROVIDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // attendance should be selected
    if (details.dtls.dtls.attendance.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_TYPE_NOT_PROVIDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00116151, CSH
    // check if time provided is correct
    // BEGIN, CR00168425, GBA
    if (CuramConst.gkEmpty.equals(details.dtls.dtls.totalHours)) {
      details.dtls.dtls.totalHours = ATTENDANCETRACKINGHOURS.ATH2001;
    }
    if (CuramConst.gkEmpty.equals(details.dtls.dtls.totalMinutes)) {
      details.dtls.dtls.totalMinutes = ATTENDANCETRACKINGMINUTES.ATM2001;
    }
    if (CuramConst.gkEmpty.equals(details.dtls.dtls.hoursAbsent)) {
      details.dtls.dtls.hoursAbsent = ATTENDANCETRACKINGHOURS.ATH2001;
    }
    if (CuramConst.gkEmpty.equals(details.dtls.dtls.minutesAbsent)) {
      details.dtls.dtls.minutesAbsent = ATTENDANCETRACKINGMINUTES.ATM2001;
    }
    validateTotalTime(Integer.parseInt(details.dtls.dtls.totalHours), 
      Integer.parseInt(details.dtls.dtls.totalMinutes));
    validateTotalTime(Integer.parseInt(details.dtls.dtls.hoursAbsent),
      Integer.parseInt(details.dtls.dtls.minutesAbsent));
    // END, CR00168425
    // END, CR00116151
  }

  // BEGIN, CR00168425, GBA
  // _________________________________________________________________________
  /**
   * Validates values of Total Hours and Total Minutes.
   *
   * @param Total Hour value, Total Minute value.
   *
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void validateTotalTime(int totalHours, int totalMinutes)
    throws AppException {
    // BEGIN, CR00238338, PF
    // max value for hours is 24
    if (totalHours > CuramConst.gkNumberOfHoursInADay) {
    
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_HOURS_INVALID_VALUE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // if value for hours is 24 then amount for minutes must
    // not be greater than zero
    if (totalHours == CuramConst.gkNumberOfHoursInADay && totalMinutes > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_MAX_NUM_HOURS_IN_A_DAY_EXCEEDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // max value of minutes should be 59
    if (totalMinutes > (CuramConst.gkNumberOfSecondsInMinute - 1)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_MINUTES_INVALID_VALUE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // END, CR00168425
  
  // _________________________________________________________________________
  /**
   * Validates participation details.
   *
   * @param details Details of the daily attendance to be
   * inserted or modified.
   */
  public void validateParticipation(PlannedItemDailyAttendanceDetails details)
    throws AppException, InformationalException {

    // PIDailyAttendanceLink manipulation variable
    PIDailyAttendanceLink piDailyAttendanceLinkObj = PIDailyAttendanceLinkFactory.newInstance();

    AttendanceCountForDateAndPlanItemKey attendanceCountForDateAndPlanItemKey = new AttendanceCountForDateAndPlanItemKey();

    // manipulation objects
    CaseDailyAttendanceSummaryDetailsList caseDailyAttendanceSummaryDetailsList = new CaseDailyAttendanceSummaryDetailsList();

    curam.serviceplans.sl.entity.struct.ActiveParticipationsForPlanItemAndDateRangeKey activeParticipationsForPlanItemAndDateRangeKeyObj = new curam.serviceplans.sl.entity.struct.ActiveParticipationsForPlanItemAndDateRangeKey();

    // populate key to search for active attendances of type,
    // date and plan item specified
    attendanceCountForDateAndPlanItemKey.dailyAttendanceID = details.dtls.dtls.dailyAttendanceID;
    attendanceCountForDateAndPlanItemKey.serviceDate = details.dtls.dtls.serviceDate;
    attendanceCountForDateAndPlanItemKey.attendance = details.dtls.dtls.attendance;
    attendanceCountForDateAndPlanItemKey.plannedItemID = details.plannedItemID;
    attendanceCountForDateAndPlanItemKey.dailyAttendanceIDIsNull = (details.dtls.dtls.dailyAttendanceID
      == 0);
    attendanceCountForDateAndPlanItemKey.recordStatus = RECORDSTATUS.CANCELLED;

    // get the number of attendances already recorded for this attendance type,
    // date and planned item
    Count count = piDailyAttendanceLinkObj.countDailyAttendanceForDateAndPlanItem(
      attendanceCountForDateAndPlanItemKey);

    // Check that an attendance record has not already been recorded for this
    // planned item, attendance type and date
    if (count.numberOfRecords >= 1) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_PARTICIPATIONS_FOR_TYPE_PLAN_ITEM_DATE_EXIST),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    PlannedItemDtls plannedItemDtls;
    PlannedItemKey plannedItemKey = new PlannedItemKey();

    plannedItemKey.plannedItemID = details.plannedItemID;
    plannedItemDtls = plannedItemObj.read(plannedItemKey);

    // Plan item responsibility must be with client
    if ((!plannedItemDtls.responsibilityType.equals(RESPONSIBILITYTYPE.CLIENT)
      && !plannedItemDtls.responsibilityType.equals(
        RESPONSIBILITYTYPE.PARTICIPANT))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_XRV_PLANNED_ITEM_RESPONSIBILITYTYPE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Plan Item must be started
    if ((plannedItemDtls.actualStartDate.equals(Date.kZeroDate))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_PLAN_ITEM_NOT_STARTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Service date must be after plan item start date
    if (details.dtls.dtls.serviceDate.before(plannedItemDtls.actualStartDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_PARTICIPATION_DATE_PLAN_ITEM_STARTDATE).arg(
          plannedItemDtls.actualStartDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Service date must be before plan item end date
    if ((!plannedItemDtls.actualEndDate.equals(curam.util.type.Date.kZeroDate))
      && details.dtls.dtls.serviceDate.after(plannedItemDtls.actualEndDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_PARTICIPATION_DATE_PLAN_ITEM_ENDDATE).arg(
          plannedItemDtls.actualEndDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // Plan item must be 'In Progress' or 'Completed'
    if ((!plannedItemDtls.status.equals(PLANNEDITEMSTATUS.INPROGRESS))
      && (!plannedItemDtls.status.equals(PLANNEDITEMSTATUS.COMPLETED))) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_FV_PARTICIPATION_PLAN_ITEM_STATUS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseStatusCode caseStatusCode;

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = details.dtls.dtls.caseID;

    // BEGIN, CR00227859, PM
    // Security variables
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = details.dtls.dtls.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859
    
    // Read the case status
    caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // Case status must not be closed
    if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_XRV_ADD_MODIFY_PARTICIPATION_CASE_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // ensure that total client participation for a day does
    // not exceed 24 hours

    // assign values to objects
    activeParticipationsForPlanItemAndDateRangeKeyObj.fromDate = details.dtls.dtls.serviceDate;
    activeParticipationsForPlanItemAndDateRangeKeyObj.toDate = details.dtls.dtls.serviceDate;
    activeParticipationsForPlanItemAndDateRangeKeyObj.plannedItemID = details.plannedItemID;
    activeParticipationsForPlanItemAndDateRangeKeyObj.recordStatus = RECORDSTATUS.CANCELLED;

    // read all active participations for date we are currently inserting
    // participation
    caseDailyAttendanceSummaryDetailsList.dtlsList = piDailyAttendanceLinkObj.searchActiveByPlannedItemIDAndDateRange(
      activeParticipationsForPlanItemAndDateRangeKeyObj);

    // BEGIN, CR00116151, CSH
    // counting primitives
    int runningHour = 0;
    int runningMin = 0;

    // for each participation record found for the date, sum the time allotted
    for (int i = 0; i
      < caseDailyAttendanceSummaryDetailsList.dtlsList.dtls.size(); i++) {

      // BEGIN, CR00120145 ,CSH
      // if participation type is same as participation type we are trying to
      // enter, ignore it as we are editing this type
      if (!caseDailyAttendanceSummaryDetailsList.dtlsList.dtls.item(i).attendance.equals(
        details.dtls.dtls.attendance)) {
        // BEGIN CR00135077, GBA
        String totalHoursStr = caseDailyAttendanceSummaryDetailsList.dtlsList.dtls.item(i).totalHours;

        if (totalHoursStr != null && !(totalHoursStr.equals(""))) {
          runningHour += Integer.parseInt(totalHoursStr);
        }
        String totalMinsStr = caseDailyAttendanceSummaryDetailsList.dtlsList.dtls.item(i).totalMinutes;

        if (totalMinsStr != null && !(totalMinsStr.equals(""))) {
          runningMin += Integer.parseInt(totalMinsStr);
        }
        // END CR00135077
      }
      // END, CR00120145
    }

    // now add the current participation
    // BEGIN CR00135077, GBA
    String totalHourStr = details.dtls.dtls.totalHours;

    if (totalHourStr != null && !(totalHourStr.equals(""))) {
      runningHour += Integer.parseInt(totalHourStr);
    }
    String totalMinStr = details.dtls.dtls.totalMinutes;

    if (totalMinStr != null && !(totalMinStr.equals(""))) {
      runningMin += Integer.parseInt(totalMinStr);
    }
    // END CR00135077

    // add minutes to hour
    runningHour += runningMin / CuramConst.gkNumberOfSecondsInMinute;
    runningMin %= CuramConst.gkNumberOfSecondsInMinute;
    // BEGIN, CR00238338, PF
    // ensure that total is not greater than 24 hours
    if (runningHour > CuramConst.gkNumberOfHoursInADay
      || runningHour == CuramConst.gkNumberOfHoursInADay && runningMin > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_MAX_NUM_HOURS_IN_A_DAY_EXCEEDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // _________________________________________________________________________
  /**
   * Validates the cancel operation
   *
   * @param details Details of the daily attendance to be
   * cancelled
   */
  public void validateCancel(DailyAttendanceDtls details)
    throws AppException, InformationalException {

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = details.caseID;
    
    // BEGIN, CR00227859, PM
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = details.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859


    // check that the case is not closed
    CaseStatusCode caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    if (caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_XRV_CANCEL_PARTICIPATION_CASE_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check that the record is not already cancelled
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_XRV_ALREADY_CANCELED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00120128, PMD
    // Check that the record wasn't created automatically by the system
    if (details.createdBySystem) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_RV_CANNOT_DELETE_SYSTEM_CREATED_RECORDS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00120128
  }

  // _________________________________________________________________________
  /**
   * Validates the modify operation
   *
   * @param details Details of the daily attendance to be
   * modified
   */
  public void validateModify(PlannedItemDailyAttendanceDetails details)
    throws AppException, InformationalException {

    // Check that the record is not cancelled
    if (details.dtls.dtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTPARTICIPATION.ERR_CLIENTPARTICIPATION_XRV_MODIFY_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    validateDetails(details);
    validateParticipation(details);

  }
  // END, CR00114509

}
