/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2004, 2014
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office 
 */

/*
 * Copyright 2004 - 2006, 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import java.io.ByteArrayOutputStream;

import curam.codetable.ORGOBJECTTYPE;
import curam.core.impl.EnvVars;
import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.GetResourcesDetails;
import curam.core.struct.UserKeyStruct;
import curam.serviceplans.sl.struct.ServicePlanContractKey;
import curam.serviceplans.sl.struct.ServicePlanData;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanDocumentData;
import curam.serviceplans.sl.struct.ServicePlanDocumentDetails;
import curam.serviceplans.sl.struct.ServicePlanDocumentKey;
import curam.serviceplans.sl.struct.ServicePlanDocumentTemplateCodeKey;
import curam.serviceplans.sl.struct.ServicePlanReturnDocDetails;
import curam.serviceplans.sl.struct.ServicePlanUserData;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.Locale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Blob;
import curam.util.xml.impl.XMLDocument;
import curam.util.xml.impl.XMLEncodingConstants;
import curam.util.xml.impl.XMLPrintStream;


/**
 * This process class provides the functionality for the ServicePlanDocGeneration
 * service layer.
 */
public abstract class ServicePlanDocGeneration extends curam.serviceplans.sl.base.ServicePlanDocGeneration {

  // BEGIN, CR00053248, GM
  protected static final String kServicePlanContract = ExtensionConst.gkPDFFileNameExtenmsion;
  // END, CR00053248

  // ___________________________________________________________________________
  /**
   * Generates an XML document from the specified XSL template and previews that
   * document.
   *
   * @param servicePlanDocumentDetails Contains service plan document details.
   * @param servicePlanDocumentData Contains service plan document data to be printed.
   */
  public ServicePlanReturnDocDetails generateAndPreviewDocument(
    ServicePlanDocumentDetails servicePlanDocumentDetails,
    ServicePlanDocumentData servicePlanDocumentData)
    throws AppException, InformationalException {

    ServicePlanReturnDocDetails servicePlanReturnDocDetails = new ServicePlanReturnDocDetails();

    // Create Preview Stream
    ByteArrayOutputStream previewStream = new java.io.ByteArrayOutputStream();

    // Create XMLPrintStream object
    // BEGIN, CR00103465, ZV
    XMLPrintStream printStreamObj = new XMLPrintStream();
    // END, CR00103465

    curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey = new curam.util.administration.struct.XSLTemplateInstanceKey();

    // Set up XSL template instance
    xslTemplateInstanceKey.templateID = servicePlanDocumentDetails.templateID;
    xslTemplateInstanceKey.templateVersion = servicePlanDocumentDetails.versionNo;

    // BEGIN, CR00408760, KRK
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS_DEFAULT))) {
      // set printer name (if already defined)
      if (servicePlanDocumentDetails.printerName.length() > 0) {
        printStreamObj.setPrinterName(servicePlanDocumentDetails.printerName);
      }

      printStreamObj.setPreviewStream(previewStream);

      xslTemplateInstanceKey.locale = TransactionInfo.getProgramLocale();

      // Open print stream
      // BEGIN, CR00103465, ZV
      printStreamObj.open(xslTemplateInstanceKey);
      // END, CR00103465

      XMLDocument documentObj = new XMLDocument(printStreamObj.getStream(),
        XMLEncodingConstants.kEncodeUTF8);
      
      // BEGIN, CR00086709, POB
      // open document
      documentObj.open(curam.util.transaction.TransactionInfo.getProgramUser(),
        Locale.getFormattedTime(curam.util.type.DateTime.getCurrentDateTime()),
        String.valueOf(servicePlanDocumentDetails.versionNo),
        servicePlanDocumentDetails.comments);
      // END, CR00086709

      // add data to document
      documentObj.add(servicePlanDocumentData);

      // close document and print stream objects
      documentObj.close();

      printStreamObj.close();
    }
    // END, CR00408760

    // previewBuffer
    servicePlanReturnDocDetails.fileName = kServicePlanContract;
    servicePlanReturnDocDetails.fileData = new Blob(previewStream.toByteArray());

    return servicePlanReturnDocDetails;
  }

  // ___________________________________________________________________________
  /**
   * Generates an XML document from the specified XSL template and prints that
   * document.
   *
   * @param servicePlanDocumentDetails Contains service plan document details.
   * @param servicePlanDocumentData Contains service plan document data to be printed.
   */
  public void generateAndPrintDocument(
    ServicePlanDocumentDetails servicePlanDocumentDetails,
    ServicePlanDocumentData servicePlanDocumentData)
    throws AppException, InformationalException {

    // Create XMLPrintStream object
    // BEGIN, CR00103465, ZV
    XMLPrintStream printStreamObj = new XMLPrintStream();
    // END, CR00103465

    curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey = new curam.util.administration.struct.XSLTemplateInstanceKey();

    // Set up XSL template instance
    xslTemplateInstanceKey.templateID = servicePlanDocumentDetails.templateID;
    xslTemplateInstanceKey.templateVersion = servicePlanDocumentDetails.versionNo;
    xslTemplateInstanceKey.locale = TransactionInfo.getProgramLocale();
    // set printer name (if already defined)
    if (servicePlanDocumentDetails.printerName.length() > 0) {
      printStreamObj.setPrinterName(servicePlanDocumentDetails.printerName);
    }

    // Open print stream
    // BEGIN, CR00103465, ZV
    printStreamObj.open(xslTemplateInstanceKey);
    // END, CR00103465

    XMLDocument documentObj = new XMLDocument(printStreamObj.getStream(),
      XMLEncodingConstants.kEncodeUTF8);
    
    // BEGIN, CR00086709, POB
    // open document
    documentObj.open(curam.util.transaction.TransactionInfo.getProgramUser(),
      Locale.getFormattedTime(curam.util.type.DateTime.getCurrentDateTime()),
      String.valueOf(servicePlanDocumentDetails.versionNo),
      servicePlanDocumentDetails.comments);
    // END, CR00086709

    // add data to document
    documentObj.add(servicePlanDocumentData);

    // close document and print stream objects
    documentObj.close();

    printStreamObj.close();
    // previewBuffer.


  }

  // ___________________________________________________________________________
  /**
   * Returns data of currently working user (if online) or case owner (if in
   * deferred processing or in batch mode).
   *
   * @param servicePlanDeliveryKey contains case ID.
   *
   * @return service plan user data (full name and default printer).
   */
  public ServicePlanUserData getUserData(ServicePlanDeliveryKey servicePlanDeliveryKey)
    throws AppException, InformationalException {

    // return structure
    ServicePlanUserData servicePlanUserData = new ServicePlanUserData();

    // AdminUser object and access structures
    curam.core.intf.AdminUserAssistant adminUserAssistantObj = curam.core.fact.AdminUserAssistantFactory.newInstance();
    UserKeyStruct userKeyStruct = new UserKeyStruct();
    GetResourcesDetails getResourcesDetails;
    
    // BEGIN, CR00060051, PMD
    // CaseUserRole manipulation variables
    curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // Set the case header key to be the service plan delivery key
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = servicePlanDeliveryKey.key.caseID;
        
    // Read case owner
    CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(caseHeaderKey);
    
    // If the case owner is a user, set the user details
    if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.USER)) {
      
      servicePlanUserData.userName = caseOwnerDetails.userName;
      servicePlanUserData.userFullName = caseOwnerDetails.userFullName;

      // ensure that the user's default printer is available
      userKeyStruct.userName = caseOwnerDetails.userName;

      // get the default printer information
      getResourcesDetails = adminUserAssistantObj.getUserDefaultPrinter(
        userKeyStruct);

      if (getResourcesDetails.resourceID != 0) {
        servicePlanUserData.defaultPrinter = getResourcesDetails.name;
      }      
    }    
    // END, CR00060051, PMD

    return servicePlanUserData;

  }

  // ___________________________________________________________________________
  /**
   * Previews document by template id code and service plan contract and
   * case specified .
   *
   * @param servicePlanDocumentTemplateCodeKey Contains caseID, service plan ContractID and document template ID code.
   *
   * @return Service Plan return details - file Name and File Contents
   */

  public ServicePlanReturnDocDetails previewDocumentByTemplateIDCode(ServicePlanDocumentTemplateCodeKey servicePlanDocumentTemplateCodeKey)
    throws AppException, InformationalException {

    // create return struct
    ServicePlanReturnDocDetails servicePlanReturnDocDetails = new ServicePlanReturnDocDetails();

    ServicePlanDocumentKey servicePlanDocumentKey = new ServicePlanDocumentKey();

    curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey = new curam.util.xml.struct.XSLTemplateIDCodeKey();

    // read document template by template id
    xslTemplateIDCodeKey.templateIDCode = servicePlanDocumentTemplateCodeKey.templateTypeCode;
    curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj = curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

    xslTemplateIDCodeKey.localeIdentifier = TransactionInfo.getProgramLocale();

    curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
      xslTemplateIDCodeKey);

    // preview document
    servicePlanDocumentKey.servicePlanContractID = servicePlanDocumentTemplateCodeKey.servicePlanContractID;
    servicePlanDocumentKey.caseID = servicePlanDocumentTemplateCodeKey.caseID;
    servicePlanDocumentKey.templateID = xslTemplateInstanceKey.templateID;
    servicePlanDocumentKey.versionNo = xslTemplateInstanceKey.templateVersion;

    ServicePlanData servicePlanData = getRequiredInformationForDocument(
      servicePlanDocumentKey);

    // populate return struct
    servicePlanReturnDocDetails = generateAndPreviewDocument(
      servicePlanData.documentDetails, servicePlanData.documentData);

    return servicePlanReturnDocDetails;

  }

  // ___________________________________________________________________________
  /**
   * Prints document by template id code and case specified .
   *
   * @param servicePlanDocumentTemplateCodeKey Contains caseID, service plan ContractID and document template ID code.
   */
  public void printDocumentByTemplateIDCode(ServicePlanDocumentTemplateCodeKey servicePlanDocumentTemplateCodeKey)
    throws AppException, InformationalException { // return structure

    curam.util.xml.struct.XSLTemplateIDCodeKey xslTemplateIDCodeKey = new curam.util.xml.struct.XSLTemplateIDCodeKey();

    // read document template by template id
    xslTemplateIDCodeKey.templateIDCode = servicePlanDocumentTemplateCodeKey.templateTypeCode;
    curam.util.xml.intf.XSLTemplateUtility xslTemplateUtilityObj = curam.util.xml.fact.XSLTemplateUtilityFactory.newInstance();

    xslTemplateIDCodeKey.localeIdentifier = TransactionInfo.getProgramLocale();

    curam.util.administration.struct.XSLTemplateInstanceKey xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
      xslTemplateIDCodeKey);
    ServicePlanDocumentKey servicePlanDocumentKey = new ServicePlanDocumentKey();

    // print document
    servicePlanDocumentKey.servicePlanContractID = servicePlanDocumentTemplateCodeKey.servicePlanContractID;
    servicePlanDocumentKey.caseID = servicePlanDocumentTemplateCodeKey.caseID;
    servicePlanDocumentKey.templateID = xslTemplateInstanceKey.templateID;
    servicePlanDocumentKey.versionNo = xslTemplateInstanceKey.templateVersion;

    ServicePlanData servicePlanData = getRequiredInformationForDocument(
      servicePlanDocumentKey);

    // BEGIN, CR00409231, KRK
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS_DEFAULT))) {
      // populate return struct
      generateAndPrintDocument(servicePlanData.documentDetails,
        servicePlanData.documentData);
    }
    // END, CR00409231
  }

  // ___________________________________________________________________________
  /**
   * Returns the required service plan date to either print or preview a service
   * plan document
   *
   * @param servicePlanDocumentKey Contains case ID, service Plan Contract ID, document ID and
   * document template version No of document to be printed/Previewed
   *
   * @return service plan document data.
   */
  public ServicePlanData getRequiredInformationForDocument(ServicePlanDocumentKey servicePlanDocumentKey)
    throws AppException, InformationalException { // income support document data

    // Return Struct
    ServicePlanDocumentData servicePlanDocumentData = new ServicePlanDocumentData();
    ServicePlanData servicePlanData = new ServicePlanData();
    ServicePlanDocumentDetails servicePlanDocumentDetails = new ServicePlanDocumentDetails();
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
    ServicePlanContractKey servicePlanContractKey = new ServicePlanContractKey();
    ServicePlanUserData servicePlanUserData;

    // XSLTemplate Obj, XSLTemplateKey and XSLTemplateInstDtls structs
    curam.util.internal.xml.intf.XSLTemplate xslTemplateObj = curam.util.internal.xml.fact.XSLTemplateFactory.newInstance();
    curam.util.internal.xml.struct.XSLTemplateKey xslTemplateKey = new curam.util.internal.xml.struct.XSLTemplateKey();
    curam.util.internal.xml.struct.XSLTemplateDtls xslTemplateDtls;

    xslTemplateKey.templateID = servicePlanDocumentKey.templateID;
    xslTemplateKey.localeIdentifier = TransactionInfo.getProgramLocale();
    try {
      xslTemplateDtls = xslTemplateObj.read(xslTemplateKey);
    } catch (curam.util.exception.RecordNotFoundException e) {
      AppException ae = new AppException(
        curam.message.BPOSPINCOMESUPPORTDOCUMENTS.ERR_INCOMESUPPORTDOCUMENTTEMPLATE_RNFE);

      ae.arg(xslTemplateKey.templateID);
      throw ae;
    }
    // ServicePlanContract business object
    curam.serviceplans.sl.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.fact.ServicePlanContractFactory.newInstance();

    servicePlanDeliveryKey.key.caseID = servicePlanDocumentKey.caseID;
    servicePlanUserData = getUserData(servicePlanDeliveryKey);

    servicePlanDocumentDetails.printerName = servicePlanUserData.defaultPrinter;
    servicePlanDocumentDetails.templateID = servicePlanDocumentKey.templateID;
    servicePlanDocumentDetails.versionNo = servicePlanDocumentKey.versionNo;
    servicePlanDocumentDetails.caseID = servicePlanDocumentKey.caseID;
    servicePlanDocumentDetails.servicePlanContractID = servicePlanDocumentKey.servicePlanContractID;

    servicePlanData.documentDetails = servicePlanDocumentDetails;

    if (xslTemplateDtls.templateIDCode.equals(
      curam.codetable.TEMPLATEIDCODE.SERVICEPLANCONTRACT)) {

      servicePlanContractKey.servicePlanContractID = servicePlanDocumentKey.servicePlanContractID;

      // get full income support details
      servicePlanDocumentData.contractDetails = servicePlanContractObj.readCompleteContract(
        servicePlanContractKey);
      servicePlanData.documentData = servicePlanDocumentData;
    }

    return servicePlanData;
  }

}
