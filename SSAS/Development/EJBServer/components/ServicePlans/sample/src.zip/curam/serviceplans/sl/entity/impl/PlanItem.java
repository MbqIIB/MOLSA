/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOPLANITEM;
import curam.serviceplans.sl.entity.struct.PlanItemCancelKey;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemIDAndStatusKey;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlanItemStatusDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public abstract class PlanItem extends curam.serviceplans.sl.entity.base.PlanItem {

  // ___________________________________________________________________________
  /**
   * Ensure that it is valid to cancel the plan item identified by the key.
   *
   * @param key the plan item key
   * @param details the plan item details
   */
  protected void precancel(PlanItemCancelKey key, PlanItemStatusDetails details)
    throws AppException, InformationalException {

    PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = key.planItemID;
    validateCancel(planItemKey);

  }

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for an insert operation.
   *
   * @param dtls the details
   */
  protected void preinsert(PlanItemDtls dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00110475, MC
    // validates the data entered and includes a check that a plan item with
    // the same name does not already exist
    validateInsert(dtls);
    // END, CR00110475
  }

  // ___________________________________________________________________________
  /**
   * Performs validation of the details for a modify operation.  This includes
   * ensuring that plan item has not already been canceled.
   *
   * @param key the plan item key
   * @param dtls the plan item details
   */
  protected void premodify(PlanItemKey key, PlanItemDtls dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00110475, MC
    // validates the data entered and ensures that the record is not already 
    // canceled
    validateModify(key, dtls);
    // END, CR00110475
  }

  // ___________________________________________________________________________
  /**
   * @see curam.serviceplans.sl.entity.intf.PlanItem#validateCancel(curam.serviceplans.sl.entity.struct.PlanItemKey)
   */
  public void validateCancel(PlanItemKey key)
    throws AppException, InformationalException {

    //
    // check that the record isn't canceled already
    //

    // read in the record status
    PlanItemStatusDetails planItemStatusDetails = readRecordStatus(key);

    // is the plan item already canceled?
    if (planItemStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_ALREADY_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    PlanItemIDAndStatusKey planItemIDAndStatusKey = new PlanItemIDAndStatusKey();

    // set the key for counting all active sub goals that the planItem
    // is linked to
    planItemIDAndStatusKey.planItemID = key.planItemID;
    planItemIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // plan item must not be assigned to any sub goal
    if (countSubGoalsByPlanItemAndStatus(planItemIDAndStatusKey).numPlanItems
      > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_XRV_ASSIGNED_TO_SUBGOAL),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // there must not be any active template based on the planItem
    if (countPlanTemplatePlanItemsByPlanItemAndStatus(planItemIDAndStatusKey).numPlanItems
      > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_XRV_TEMPLATES_EXIST),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Determines that the details provided for the plan item are valid.
   *
   * @param details the plan item details
   */
  public void validateDetails(PlanItemDtls details)
    throws AppException, InformationalException {

    if (details.name.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_FV_NAME_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (details.createPageName.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_FV_CREATEPAGE_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (details.createPagePlanItemIDParamName.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_PLAN_ITEM_FV_CREATEPAGEPLANITEMIDPARAM_BLANK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (details.createPageSubGoalIDParamName.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_PLAN_ITEM_FV_CREATEPAGESUBGOALIDPARAM_BLANK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (details.viewPageName.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_FV_VIEWPAGE_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (details.viewPagePlanItemParamName.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_PLAN_ITEM_FV_VIEWPAGEPLANITEMPARAM_BLANK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (details.modifyPageName.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_FV_MODIFYPAGE_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (details.modifyPagePlanItemParamName.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_PLAN_ITEM_FV_MODIFYPAGEPLANITEMPARAM_BLANK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (details.typeCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_FV_TYPECODE_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    
    // BEGIN, CR00000016, CSH
    // ensures that authorized units are not entered for plan items with no unit type selected
    if ((details.authorizedUnits != 0) && (details.unitType.length() == 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_PLAN_ITEM_XFV_AUTHORIZED_UNITS_NO_UNIT_TYPE_SELECTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // ensures that maximum units are not entered for plan items with no unit type selected 
    if ((details.maximumUnits != 0) && (details.unitType.length() == 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_PLAN_ITEM_XFV_MAXIMUM_UNITS_NO_UNIT_TYPE_SELECTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
 
    // BEGIN, CR00000022, PMD
    // Authorized Units must be greater than zero
    if (details.authorizedUnits < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_FV_AUTHORIZED_UNITS_LE_ZERO),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    
    // Maximum Units must be greater than zero
    if (details.maximumUnits < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_FV_MAXIMUM_UNITS_LE_ZERO),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00000022

    // ensures that authorized units entered do not exceed maximum units
    if (details.authorizedUnits > details.maximumUnits) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANITEM.ERR_PLAN_ITEM_XFV_AUTHORIZED_UNITS_GREATER_THAN_MAXIMUM_UNITS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00000016    
    // BEGIN, CR00161962, LJ
    // Ensure the estimated cost isn't negative
    if (details.cost.isNegative()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_COST_NEGATIVE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00161962
  }

  // ___________________________________________________________________________
  /**
   * @see curam.serviceplans.sl.entity.intf.PlanItem#validateInsert(curam.serviceplans.sl.entity.struct.PlanItemDtls)
   */
  public void validateInsert(PlanItemDtls dtls)
    throws AppException, InformationalException {

    validateDetails(dtls);
    // BEGIN, CR00138465, MC
    // BEGIN, CR00110475, MC
    // Validate the details
    String code = curam.codetable.impl.PLANITEMTYPEEntry.get(dtls.typeCode).getCode();

    // validates the data entered and includes a check that a plan item with
    // the same name does not already exist
    ServicePlanHookManager.getPlanItemHook(code).validateInsert(dtls);
    // END, CR00110475
    // END, CR00138465
    

  }

  // ___________________________________________________________________________
  /**
   * Validates that an plan item can be modified. This included checking that the
   * required details have been specified and the plan item is not already canceled
   * and that unique fields are unique.
   *
   * @param key Identifies the plan item being modified.
   * @param dtls The new details.
   */
  public void validateModify(PlanItemKey key, PlanItemDtls dtls)
    throws AppException, InformationalException {

    // check mandatory fields have been entered
    validateDetails(dtls);
    
    // BEGIN, CR00138465, MC
    String code = curam.codetable.impl.PLANITEMTYPEEntry.get(dtls.typeCode).getCode();

    // validates the data entered and ensures that the record is not already 
    // canceled
    ServicePlanHookManager.getPlanItemHook(code).validateModify(key, dtls);
    // END, CR00138465

   

  }

}
