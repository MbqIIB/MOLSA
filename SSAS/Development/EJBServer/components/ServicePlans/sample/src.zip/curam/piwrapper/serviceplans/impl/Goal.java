/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.GOALNAMEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.util.persistence.StandardEntity;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Date;


/**
 * Read only wrapper interface for the
 * {@link curam.serviceplans.sl.entity.intf.Goal} entity.
 */
// BEGIN, CR00309529, POH
@ImplementedBy(GoalImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface Goal extends StandardEntity, Lifecycle<RECORDSTATUSEntry> {
  // END, CR00309529, POH

  /**
   * Retrieves the code table entry value for the name field.
   *
   * @return The name code table entry value.
   */
  GOALNAMEEntry getName();

  /**
   * Retrieves the user entered reference number to represent this type of goal.
   *
   * @return The reference field value.
   */
  String getReference();

  /**
   * Retrieves the date on which the goal definition was created.
   *
   * @return The value of the date created field.
   */
  Date getDateCreated();

  /**
   * Retrieves the value of the description field.
   *
   * @return The value of the description field.
   */
  String getDescription();

  /**
   * Returns an immutable list of all active sub goals that are linked to this
   * goal.
   *
   * @return An immutable list of active sub goals linked to the gaol, or an
   * empty list if none are found.
   */
  List<SubGoal> listActiveSubGoals();

}
