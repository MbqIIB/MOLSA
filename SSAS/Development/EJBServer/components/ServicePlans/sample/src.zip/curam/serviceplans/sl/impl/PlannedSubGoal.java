/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2005, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;

import curam.codetable.MILESTONESTATUSCODE;
import curam.codetable.OUTCOMEACHIEVED;
import curam.codetable.PLANCONTENTTYPE;
import curam.codetable.PLANITEMNAME;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SENSITIVITY;
import curam.codetable.SUBGOALNAME;
import curam.codetable.impl.LOCALEEntry;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.UsersFactory;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.MilestoneConfigurationFactory;
import curam.core.sl.entity.fact.MilestoneDeliveryFactory;
import curam.core.sl.entity.intf.MilestoneConfiguration;
import curam.core.sl.entity.struct.MilestoneConfigurationDtls;
import curam.core.sl.entity.struct.MilestoneConfigurationKey;
import curam.core.sl.entity.struct.MilestoneDeliveryAndConfigDetails;
import curam.core.sl.entity.struct.MilestoneDeliveryAndConfigDetailsList;
import curam.core.sl.entity.struct.MilestoneDeliveryDetails;
import curam.core.sl.entity.struct.MilestoneDeliveryKey;
import curam.core.sl.entity.struct.ReadMilestoneDeliveryDetails;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.SensitivityCode;
import curam.core.struct.UserFullname;
import curam.core.struct.UserSecurityDetails;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOPLANNEDSUBGOAL;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.GENERALCASE;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedGoalFactory;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.fact.SPMilestoneDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.intf.SPMilestoneDeliveryLink;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.struct.NameNotEditableIndDetails;
import curam.serviceplans.sl.entity.struct.PlanItemIDDetailsStruct;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalCaseIDKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalCountDetails;
import curam.serviceplans.sl.entity.struct.PlannedGoalDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemForSubgoalList;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedItemKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForServicePlanList;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDtls;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalIDAndCaseID;
import curam.serviceplans.sl.entity.struct.SPMilestoneAndLinkDtls;
import curam.serviceplans.sl.entity.struct.SPMilestoneAndLinkDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.fact.MilestoneFactory;
import curam.serviceplans.sl.struct.CreatePlannedSubGoalDetails;
import curam.serviceplans.sl.struct.ListPlannedItemSummDetailsForSubGoal;
import curam.serviceplans.sl.struct.ListPlannedSubGoalDetails;
import curam.serviceplans.sl.struct.ListPlannedSubGoalDetailsList;
import curam.serviceplans.sl.struct.ModifyPlannedSubGoalDetails;
import curam.serviceplans.sl.struct.PlanContentMilestoneDetails;
import curam.serviceplans.sl.struct.PlanContentMilestoneDetailsList;
import curam.serviceplans.sl.struct.PlanParticipantSensitivityAndUserName;
import curam.serviceplans.sl.struct.PlannedGoalKey;
import curam.serviceplans.sl.struct.PlannedGroupKey;
import curam.serviceplans.sl.struct.PlannedItemIndicator;
import curam.serviceplans.sl.struct.PlannedItemSummDetailsForSubGoal;
import curam.serviceplans.sl.struct.PlannedItemsForPlannedSubgoal;
import curam.serviceplans.sl.struct.PlannedSubGoalCaseIDKey;
import curam.serviceplans.sl.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.struct.PlannedSubGoalListByTypeDetailsList;
import curam.serviceplans.sl.struct.PlannedSubGoalTypeCodeDetails;
import curam.serviceplans.sl.struct.PlannedSubGoalTypeCodeKey;
import curam.serviceplans.sl.struct.ReadCaseIDByPlannedSubGoalIDDetails;
import curam.serviceplans.sl.struct.ReadPlannedSubGoalDetails;
import curam.serviceplans.sl.struct.ReadPlannedSubGoalDetailsForModification;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanSubGoalSecurityKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.NotFoundIndicator;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;


/**
 * Business layer functionality for managing service plan planned sub goals.
 */
public abstract class PlannedSubGoal extends curam.serviceplans.sl.base.PlannedSubGoal {

  // BEGIN, CR00236426, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public PlannedSubGoal() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00236426

  /**
   * Creates the planned sub-goal.
   *
   * @param details
   * Contains the planned sub-goal details.
   *
   * @return Key of the created planned sub-goal.
   *
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_CREATE_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to maintain
   * this service plan.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_SENSITIVITY_CAN_NOT_BE_HIGHER_THAN_CURRENT_USER}
   * - if the user specifies a sensitivity greater than his own.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have maintenance rights for this case. Please contact
   * your security administrator.
   */
  public PlannedSubGoalKey create(CreatePlannedSubGoalDetails details)
    throws AppException, InformationalException {

    // Planned Sub-Goal entity manipulation variables
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedsubgoalObj = PlannedSubGoalFactory.newInstance();
    PlannedSubGoalDtls plannedsubgoalDtls = new PlannedSubGoalDtls();

    PlanParticipantSensitivityAndUserName securityDetails = new PlanParticipantSensitivityAndUserName();
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    // BEGIN, CR00080774, CSH
    CaseSearchKey caseSearchKey = new CaseSearchKey();
    // END, CR00080774
    // BEGIN, CR00213430, AK
    Users userObj = UsersFactory.newInstance();
    UsersKey userKey = new UsersKey();
    UsersDtls usersDtls = new UsersDtls();
    NotFoundIndicator nfIndicator = new NotFoundIndicator();
    String userLocale = TransactionInfo.getProgramLocale();
    // END, CR00213430


    // BEGIN, CR00227859, PM
    // Security variables
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = details.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKeyStruct = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();

    // To be returned
    PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();

    // validate the owner details are correct
    validateOwnerDetails(details);

    // if owner is to be current user than let us set it
    if (details.me == true) {
      details.dtls.ownerID = curam.util.transaction.TransactionInfo.getProgramUser();
    }

    // get planned goal id
    PlannedGoalCaseIDKey plannedGoalCaseIDKey = new PlannedGoalCaseIDKey();

    plannedGoalCaseIDKey.caseID = details.caseID;
    curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = PlannedGoalFactory.newInstance();

    details.dtls.plannedGoalID = plannedGoalObj.readPlannedGoalIDByCaseID(plannedGoalCaseIDKey).plannedGoalID;

    // assign creation details
    plannedsubgoalDtls.assign(details.dtls);

    // create planned sub-goal
    plannedsubgoalObj.insert(plannedsubgoalDtls);

    // set goal identifier to be returned
    plannedSubGoalKey.key.plannedSubGoalID = plannedsubgoalDtls.plannedSubGoalID;

    plannedSubGoalKeyStruct.plannedSubGoalID = plannedsubgoalDtls.plannedSubGoalID;

    // Send notification if owner is not current user
    // BEGIN, CR00091205, CM
    if (!details.dtls.ownerID.equals(
      curam.util.transaction.TransactionInfo.getProgramUser())) {
      // END, CR00091205
      // notification manipulation variables
      curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();
      StandardManualTaskDtls standardManualTaskDtls = new StandardManualTaskDtls();

      // assign owner
      standardManualTaskDtls.dtls.assignDtls.assignmentID = details.dtls.ownerID;

      // set subject and comments
      // BEGIN, CR00213430, AK
      userKey.userName = details.dtls.ownerID;
      usersDtls = userObj.read(nfIndicator, userKey);
      if (!nfIndicator.isNotFound()) {
        userLocale = usersDtls.defaultLocale;
      }
      // END, CR00213430
      // Read the caseID BY plannedSubGoalID
      // BEGIN, CR00080774, CSH
      caseSearchKey.caseID = plannedsubgoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKeyStruct).caseID;
      // END, CR00080774

      AppException subjectText = new AppException(
        curam.message.BPOPLANNEDSUBGOAL.INF_SUBGOAL_ASSIGNMENT_SUBJECT);

      // BEGIN, CR00080774, CSH
      subjectText.arg(
        caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);
      // END, CR00080774

      AppException commentsText = new AppException(
        curam.message.BPOPLANNEDSUBGOAL.INF_SUBGOAL_ASSIGNMENT_COMMENTS);

      commentsText.arg(
        // BEGIN, CR00163098, JC
        CodeTable.getOneItem(SUBGOALNAME.TABLENAME,
        plannedsubgoalObj.readPlannedSubGoalDetailsAndSubgoalName(plannedSubGoalKeyStruct).subGoalName,
        userLocale));
      // END, CR00163098, JC
      // BEGIN, CR00080774, CSH
      commentsText.arg(
        caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);
      // END, CR00080774

      // BEGIN, CR00163659, CL
      standardManualTaskDtls.dtls.taskDtls.subject = subjectText.getMessage(
        userLocale);
      standardManualTaskDtls.dtls.taskDtls.comments = commentsText.getMessage(
        userLocale);
      // END, CR00163659
      // BEGIN, CR00023618, SK
      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.standardCaseTaskDefinitionID;
      // END, CR00023618
      // send notification
      // BEGIN, CR00333044, GYH
      standardManualTaskDtls.dtls.concerningDtls.caseID = details.caseID;
      // END, CR00333044
      notificationObj.createWorkAllocationNotification(standardManualTaskDtls);

    }

    // Ensure that the sensitivity entered is not greater than the current user

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();

    // END, CR00179387

    // check service plan sensitivity of the sub goal
    try {
      servicePlanSecurity.subGoalSensitivityCheck(plannedSubGoalKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_CREATE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_SUBGOAL_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_SENSITIVITY_CAN_NOT_BE_HIGHER_THAN_CURRENT_USER);
      } else {
        throw e;
      }
    }

    // Check Sensitivity against proposed owner and service plan participant

    // read Plan participant and check security level
    caseHeaderKey.caseID = details.caseID;
    securityDetails.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;
    securityDetails.ownerID = details.dtls.ownerID;
    securityDetails.subGoalSensitivity = details.dtls.sensitivityCode;
    checkSensitivityForProposedOwnerAndPlanParticipant(securityDetails);

    return plannedSubGoalKey;

  }

  /**
   * Returns a list of all planned sub-goals for a particular service plan.
   *
   * @param key
   * Contains the caseID key for the specific service plan.
   *
   * @return List of planned sub-goals for the service plan.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_LIST_SECURITY_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to view this
   * service plan.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_LIST_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to list
   * sub goals for this service plan.
   */
  public ListPlannedSubGoalDetailsList list(PlannedSubGoalCaseIDKey key)
    throws AppException, InformationalException {

    // read the list of planned sub-goals based on a Case identifier
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedsubgoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    ServicePlanDelivery servicePlanDelivery = ServicePlanDeliveryFactory.newInstance();

    ListPlannedSubGoalDetailsList listPlannedSubGoalDetailsList = new ListPlannedSubGoalDetailsList();

    PlannedSubGoalDetailsForServicePlanList plannedSubGoalDetailsForServicePlanList = plannedsubgoalObj.searchByCaseID(
      key.key);

    for (int i = 0; i < plannedSubGoalDetailsForServicePlanList.dtls.size(); i++) {

      ListPlannedSubGoalDetails listPlannedSubGoalDetails = new ListPlannedSubGoalDetails();

      // assign details
      listPlannedSubGoalDetails.id = plannedSubGoalDetailsForServicePlanList.dtls.item(i).id;
      listPlannedSubGoalDetails.outcomeAchieved = plannedSubGoalDetailsForServicePlanList.dtls.item(i).outcomeAchieved;
      listPlannedSubGoalDetails.status = plannedSubGoalDetailsForServicePlanList.dtls.item(i).status;
      listPlannedSubGoalDetails.name = plannedSubGoalDetailsForServicePlanList.dtls.item(i).name;

      // Set the type code to planned sub goal for each record found
      listPlannedSubGoalDetails.planContentType = PLANCONTENTTYPE.PLANNEDSUBGOAL;

      // The following scenarios can occur and have to be checked when setting
      // both from and end date:
      // 1. Where both set of dates are not set
      // 2. Where both sets of dates are set
      // 3. Where expected date is set and actual is not set
      // 4. Where actual date is set and expected date is not set.

      // Is both the actual and expected start dates are not set?
      if (plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualStartDate.isZero()
        && plannedSubGoalDetailsForServicePlanList.dtls.item(i).expectedStartDate.isZero()) {
        // Set to no date
        listPlannedSubGoalDetails.startDate = curam.util.type.Date.kZeroDate;
      } // Are both start dates set?
      else if (!plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualStartDate.isZero()
        && !plannedSubGoalDetailsForServicePlanList.dtls.item(i).expectedStartDate.isZero()) {
        // set to the earliest actual start date
        listPlannedSubGoalDetails.startDate = plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualStartDate;

      } // if actual start date set and expected date not set?
      else if ((!plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualStartDate.isZero()
        && plannedSubGoalDetailsForServicePlanList.dtls.item(i).expectedStartDate.isZero())) {
        listPlannedSubGoalDetails.startDate = plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualStartDate;
      } // if expected start date set and actual date not set?
      else if ((!plannedSubGoalDetailsForServicePlanList.dtls.item(i).expectedStartDate.isZero()
        && plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualStartDate.isZero())) {
        listPlannedSubGoalDetails.startDate = plannedSubGoalDetailsForServicePlanList.dtls.item(i).expectedStartDate;
      }

      // Do the same Checks for the actual and expected end dates
      // Is both the actual and expected end dates not set?
      if (plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualEndDate.isZero()
        && plannedSubGoalDetailsForServicePlanList.dtls.item(i).expectedEndDate.isZero()) {
        // Set to no date
        listPlannedSubGoalDetails.startDate = curam.util.type.Date.kZeroDate;
      } // Is the both end dates set?
      else if (!plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualEndDate.isZero()
        && !plannedSubGoalDetailsForServicePlanList.dtls.item(i).expectedEndDate.isZero()) {
        // BEGIN, CR00106906,GM
        // if so and less then expected end date then set to expected end date
        if (plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualEndDate.before(
          plannedSubGoalDetailsForServicePlanList.dtls.item(i).expectedEndDate)) {
          listPlannedSubGoalDetails.endDate = plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualEndDate;
        } // // END, CR00106906
        // else set to actual end date
        else {
          listPlannedSubGoalDetails.endDate = plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualEndDate;
        }
      } // Is actual end date set and expected date not set?
      else if ((!plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualEndDate.isZero()
        && plannedSubGoalDetailsForServicePlanList.dtls.item(i).expectedEndDate.isZero())) {
        listPlannedSubGoalDetails.endDate = plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualEndDate;
      } // if expected end date set and actual date not set?
      else if ((!plannedSubGoalDetailsForServicePlanList.dtls.item(i).expectedEndDate.isZero()
        && plannedSubGoalDetailsForServicePlanList.dtls.item(i).actualEndDate.isZero())) {
        listPlannedSubGoalDetails.endDate = plannedSubGoalDetailsForServicePlanList.dtls.item(i).expectedEndDate;
      }
      // assign each structure to struct list to be returned
      listPlannedSubGoalDetailsList.plannedSubGoalList.addRef(
        listPlannedSubGoalDetails);
    }

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Read service plan id.
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = key.key.caseID;

    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDelivery.read(servicePlanDeliveryKey).servicePlanID;

    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.key.caseID;

    // set security check key
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(BPOPLANNEDSUBGOAL.ERR_LIST_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_LIST_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
    return listPlannedSubGoalDetailsList;
  }

  /**
   * Modifies a planned sub-goal.
   *
   * @param modifyPlannedSubGoalDetails Contains the new values for a planned sub-goal.
   *
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_CREATE_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to maintain
   * this service plan.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_SENSITIVITY_CAN_NOT_BE_HIGHER_THAN_CURRENT_USER}
   * - if the user specifies a sensitivity greater than his own.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have maintenance rights for this case. Please contact
   * your security administrator.
   */
  public void modify(ModifyPlannedSubGoalDetails modifyPlannedSubGoalDetails)
    throws AppException, InformationalException {
    // Planned Sub-Goal entity manipulation variables
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();

    // Set planned sub-goal key
    plannedSubGoalKey.plannedSubGoalID = modifyPlannedSubGoalDetails.plannedSubGoalModifyDetails.plannedSubGoalID;

    PlanParticipantSensitivityAndUserName planParticipantSensitivityAndUserName = new PlanParticipantSensitivityAndUserName();

    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    // BEGIN, CR00080774, CSH
    CaseSearchKey caseSearchKey = new CaseSearchKey();
    // END, CR00080774
    // BEGIN, CR00234114, AK
    Users userObj = UsersFactory.newInstance();
    UsersKey userKey = new UsersKey();
    UsersDtls usersDtls = new UsersDtls();
    NotFoundIndicator nfIndicator = new NotFoundIndicator();
    String userLocale = TransactionInfo.getProgramLocale();

    // END, CR00234114
    // Modify planned sub-goal
    plannedSubGoalObj.modify(plannedSubGoalKey,
      modifyPlannedSubGoalDetails.plannedSubGoalModifyDetails);

    // Give notification to user if the user is not the current user
    if (modifyPlannedSubGoalDetails.plannedSubGoalModifyDetails.ownerID.compareTo(
      TransactionInfo.getProgramUser())
        != 0) {
      // notification manipulation variables
      curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();
      StandardManualTaskDtls standardManualTaskDtls = new StandardManualTaskDtls();

      // assign owner
      standardManualTaskDtls.dtls.assignDtls.assignmentID = modifyPlannedSubGoalDetails.plannedSubGoalModifyDetails.ownerID;
      // BEGIN, CR00023618, SK
      standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.standardCaseTaskDefinitionID;
      // END, CR00023618

      // set subject and comments

      // Read the caseID BY plannedSubGoalID
      // BEGIN, CR00080774, CSH
      caseSearchKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;
      // END, CR00080774

      AppException subjectText = new AppException(
        curam.message.BPOPLANNEDSUBGOAL.INF_SUBGOAL_ASSIGNMENT_SUBJECT);

      // BEGIN, CR00080774, CSH
      subjectText.arg(
        caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);
      // END, CR00080774

      AppException commentsText = new AppException(
        curam.message.BPOPLANNEDSUBGOAL.INF_SUBGOAL_ASSIGNMENT_COMMENTS);

      // BEGIN, CR00234114, AK
      userKey.userName = modifyPlannedSubGoalDetails.plannedSubGoalModifyDetails.ownerID;
      usersDtls = userObj.read(nfIndicator, userKey);
      if (!nfIndicator.isNotFound()) {
        userLocale = usersDtls.defaultLocale;
      }

      commentsText.arg(
        // BEGIN, CR00163098, JC
        CodeTable.getOneItem(SUBGOALNAME.TABLENAME,
        plannedSubGoalObj.readPlannedSubGoalDetailsAndSubgoalName(plannedSubGoalKey).subGoalName,
        userLocale));
      // END, CR00163098, JC
      // BEGIN, CR00080774, CSH
      commentsText.arg(
        caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference);
      // END, CR00080774

      // BEGIN, CR00163659, CL
      standardManualTaskDtls.dtls.taskDtls.subject = subjectText.getMessage(
        userLocale);
      standardManualTaskDtls.dtls.taskDtls.comments = commentsText.getMessage(
        userLocale);
      // END, CR00163659
      // END, CR00234114

      // send notification
      // BEGIN, CR00333044, GYH
      standardManualTaskDtls.dtls.concerningDtls.caseID = caseSearchKey.caseID;
      // END, CR00333044
      notificationObj.createWorkAllocationNotification(standardManualTaskDtls);
    }

    // Ensure that the sensitivity entered is not great than the current user.
    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    PlannedSubGoalKey plannedSubGoalSLKey = new PlannedSubGoalKey();

    plannedSubGoalSLKey.key.plannedSubGoalID = modifyPlannedSubGoalDetails.plannedSubGoalModifyDetails.plannedSubGoalID;

    // check service plan sensitivity of the sub goal
    try {
      servicePlanSecurity.subGoalSensitivityCheck(plannedSubGoalSLKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_CREATE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_SUBGOAL_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_SENSITIVITY_CAN_NOT_BE_HIGHER_THAN_CURRENT_USER);
      } else {
        throw e;
      }
    }

    // Check Sensitivity against plan participant and proposed owner
    // read Plan participant and check security level

    caseHeaderKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;

    // BEGIN, CR00227859, PM
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = caseHeaderKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(
          curam.message.GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    // Set the security details been checked
    planParticipantSensitivityAndUserName.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    planParticipantSensitivityAndUserName.ownerID = modifyPlannedSubGoalDetails.plannedSubGoalModifyDetails.ownerID;

    planParticipantSensitivityAndUserName.subGoalSensitivity = modifyPlannedSubGoalDetails.plannedSubGoalModifyDetails.sensitivityCode;
    checkSensitivityForProposedOwnerAndPlanParticipant(
      planParticipantSensitivityAndUserName);

  }

  /**
   * Returns the details for a specific planned sub-goal for view screen.
   *
   * @param key
   * Contains the planned sub-goal key.
   *
   * @return Details of the requested planned sub-goal.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_VIEW_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to view
   * this sub goal.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_VIEW_SUBGOAL_DELETED} - if this
   * sub-goal has been deleted and is no longer present on the service
   * plan.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_VIEW_SECURITY_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to view this
   * service plan.
   */
  public ReadPlannedSubGoalDetails read(PlannedSubGoalKey key)
    throws AppException, InformationalException {
    // Planned Sub-Goal entity manipulation variable
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // return item
    ReadPlannedSubGoalDetails readPlannedSubGoalDetails = new ReadPlannedSubGoalDetails();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanSubGoalSecurityKey servicePlanSubGoalSecurityKey = new ServicePlanSubGoalSecurityKey();

    try {
      // read in detail values
      readPlannedSubGoalDetails.plannedSubGoalDetailsAndSubGoalNameAndType = plannedSubGoalObj.readPlannedSubGoalDetailsAndSubgoalNameAndType(
        key.key);
    } catch (curam.util.exception.RecordNotFoundException e) {
      // throw message
      throw new AppException(BPOPLANNEDSUBGOAL.ERR_VIEW_SUBGOAL_DELETED);
    }

    // if(readPlannedSubGoalDetails.plannedSubGoalDetailsAndSubGoalNameAndType.plannedSubGoalID)
    // user full name manipulation variables
    curam.core.intf.Users UserObj = UsersFactory.newInstance();
    UsersKey usersKey = new UsersKey();
    UserFullname userFullname = null;

    usersKey.userName = readPlannedSubGoalDetails.plannedSubGoalDetailsAndSubGoalNameAndType.ownerID;

    // get full name and add to return struct
    userFullname = UserObj.getFullName(usersKey);
    readPlannedSubGoalDetails.plannedSubGoalFullUserName.fullName = userFullname.fullname;

    // need to read the service plan case id and plan participant role id.
    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Read Case ID
    curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();

    plannedSubGoalKey.plannedSubGoalID = key.key.plannedSubGoalID;

    // Read service plan id.
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;

    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = servicePlanDeliveryKey.caseID;

    servicePlanSubGoalSecurityKey.plannedSubGoalKey.key.plannedSubGoalID = key.key.plannedSubGoalID;
    readPlannedSubGoalDetails.servicePlanDeliveryID = servicePlanDeliveryKey.caseID;

    // check service plan security
    try {
      servicePlanSecurity.subGoalOperationSecurityCheck(
        servicePlanSubGoalSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(BPOPLANNEDSUBGOAL.ERR_VIEW_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_SUBGOAL_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_VIEW_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    return readPlannedSubGoalDetails;
  }

  /**
   * Returns the details for a specific planned sub-goal for modification
   * screen.
   *
   * @param key
   * Contains the planned sub-goal key
   *
   * @return Details of the requested planned sub-goal
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_CREATE_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to maintain
   * this service plan.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_MODIFY_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to modify
   * this sub goal.
   */
  public ReadPlannedSubGoalDetailsForModification readForModification(
    PlannedSubGoalKey key) throws AppException, InformationalException {
    // Planned Sub-Goal entity manipulation variable
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // Return value
    ReadPlannedSubGoalDetailsForModification readPlannedSubGoalDetailsForModification = new ReadPlannedSubGoalDetailsForModification();

    // Read planned sub-goal details
    readPlannedSubGoalDetailsForModification.plannedSubGoalDetailsAndSubGoalName = plannedSubGoalObj.readPlannedSubGoalDetailsAndSubgoalName(
      key.key);

    // user full name manipulation variables
    curam.core.intf.Users UserObj = UsersFactory.newInstance();
    UsersKey usersKey = new UsersKey();
    UserFullname userFullname = null;

    usersKey.userName = readPlannedSubGoalDetailsForModification.plannedSubGoalDetailsAndSubGoalName.ownerID;

    // get full name and add to return struct
    userFullname = UserObj.getFullName(usersKey);
    readPlannedSubGoalDetailsForModification.plannedSubGoalFullUserName.fullName = userFullname.fullname;

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanSubGoalSecurityKey servicePlanSubGoalSecurityKey = new ServicePlanSubGoalSecurityKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // Read Case ID
    curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();

    plannedSubGoalKey.plannedSubGoalID = key.key.plannedSubGoalID;

    // Read service plan id.
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;

    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    servicePlanSubGoalSecurityKey.plannedSubGoalKey.key.plannedSubGoalID = key.key.plannedSubGoalID;

    // check service plan security
    try {
      servicePlanSecurity.subGoalOperationSecurityCheck(
        servicePlanSubGoalSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_CREATE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_SUBGOAL_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_MODIFY_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
    // Return planned sub-goal details
    return readPlannedSubGoalDetailsForModification;

  }

  /**
   * Returns all planned items of a specific planned sub-goal.
   *
   * @param key Contains the planned sub-goal key.
   *
   * @return List of all planned items of the requested planned sub-goal.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PlannedItemsForPlannedSubgoal readPlannedItemsForPlannedSubgoal(
    PlannedSubGoalKey key) throws AppException, InformationalException {

    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    PlannedItemsForPlannedSubgoal plannedItemsForPlannedSubgoal = new PlannedItemsForPlannedSubgoal();

    // retrieve planned item list for specified planned subgoal key
    PlannedItemForSubgoalList plannedItemForSubgoalList = plannedSubGoalObj.searchPlannedItems(
      key.key);

    ListPlannedItemSummDetailsForSubGoal listPlannedItemSummDetailsForSubGoal = new ListPlannedItemSummDetailsForSubGoal();

    for (int i = 0; i < plannedItemForSubgoalList.dtls.size(); i++) {

      PlannedItemSummDetailsForSubGoal plannedItemSummDetailsForSubGoal = new PlannedItemSummDetailsForSubGoal();

      // BEGIN, CR00236077, NS
      final PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

      plannedItemIDKey.plannedItemID = plannedItemForSubgoalList.dtls.item(i).plannedItemID;
      final curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();
      final PlanItemIDDetailsStruct planItemIDDetailsStruct = plannedItemObj.readPlanItemID(
        plannedItemIDKey);

      final PlanItem planItemObj = PlanItemFactory.newInstance();
      final PlanItemKey planItemKey = new PlanItemKey();

      planItemKey.planItemID = planItemIDDetailsStruct.planItemID;
      final NameNotEditableIndDetails nameNotEditableIndDetails = planItemObj.readNameNotEditableIndDetails(
        planItemKey);

      if (nameNotEditableIndDetails.nameNotEditableInd) {
        plannedItemSummDetailsForSubGoal.planItemName = CodeTable.getOneItem(
          PLANITEMNAME.TABLENAME, nameNotEditableIndDetails.name,
          TransactionInfo.getProgramLocale());
      } else {
        plannedItemSummDetailsForSubGoal.planItemName = plannedItemForSubgoalList.dtls.item(i).planItemName;
      }
      // END, CR00236077

      plannedItemSummDetailsForSubGoal.outcomeName = plannedItemForSubgoalList.dtls.item(i).outcomeName;
      plannedItemSummDetailsForSubGoal.plannedItemID = plannedItemForSubgoalList.dtls.item(i).plannedItemID;
      plannedItemSummDetailsForSubGoal.status = plannedItemForSubgoalList.dtls.item(i).status;
      plannedItemSummDetailsForSubGoal.datePeriodMaxInd = plannedItemForSubgoalList.dtls.item(i).datePeriodMaxInd;

      // If completed, set end date to actual end date and start date to actual start date
      if (plannedItemForSubgoalList.dtls.item(i).status.equals(
        PLANNEDITEMSTATUS.COMPLETED)) {
        plannedItemSummDetailsForSubGoal.endDate = plannedItemForSubgoalList.dtls.item(i).actualEndDate;
        plannedItemSummDetailsForSubGoal.startDate = plannedItemForSubgoalList.dtls.item(i).actualStartDate;
      } // if progress set start date to actual and end date to expected
      else if (plannedItemForSubgoalList.dtls.item(i).status.equals(
        PLANNEDITEMSTATUS.INPROGRESS)) {
        plannedItemSummDetailsForSubGoal.endDate = plannedItemForSubgoalList.dtls.item(i).expectedEndDate;
        plannedItemSummDetailsForSubGoal.startDate = plannedItemForSubgoalList.dtls.item(i).actualStartDate;
      } else // set both to expected.
      {
        plannedItemSummDetailsForSubGoal.endDate = plannedItemForSubgoalList.dtls.item(i).expectedEndDate;
        plannedItemSummDetailsForSubGoal.startDate = plannedItemForSubgoalList.dtls.item(i).expectedStartDate;
      }

      // add each plan item record to list struct below
      listPlannedItemSummDetailsForSubGoal.planItemDetailsForSubGroup.addRef(
        plannedItemSummDetailsForSubGoal);

    }

    // assign list struct and return
    plannedItemsForPlannedSubgoal.list = listPlannedItemSummDetailsForSubGoal;

    return plannedItemsForPlannedSubgoal;
  }

  /**
   * Physically removes a planned sub-goal from the database.
   *
   * @param key
   * Contains the planned sub-goal key.
   *
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_SUBGOAL_XFV_DELETE_PLAN_ITEM_CHECK_FAILED}
   * - if this sub-goal cannot be deleted as there are plan items
   * dependent on it.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_SUBGOAL_XFV_DELETE_PLAN_ITEM_MANDATORY_CHECK_FAILED}
   * - if this sub-goal cannot be deleted as there are plan items
   * which are marked as mandatory in the template.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_SENSITIVITY_CAN_NOT_BE_HIGHER_THAN_CURRENT_USER}
   * - if the user specifies a sensitivity greater than his own.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_SUBGOAL_XFV_DELETE_MILESTONE_CHECK_FAILED}
   * - if this sub-goal cannot be deleted as there are milestones
   * dependent on it.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have maintenance rights for this case. Please contact
   * your security administrator.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_DELETE_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to maintain
   * this service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   */
  public void remove(PlannedSubGoalKey key) throws AppException,
      InformationalException {
    // Planned Sub-Goal entity manipulation variable
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanSubGoalSecurityKey servicePlanSubGoalSecurityKey = new ServicePlanSubGoalSecurityKey();

    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // need to read the service plan case id and plan participant role id.
    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // Read Case ID
    curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();

    // BEGIN, CR00091347, CM
    // SpMilestoneDeliveryLink entity object
    SPMilestoneDeliveryLink spMilestoneDeliveryLinkObj = SPMilestoneDeliveryLinkFactory.newInstance();

    // Planned Item Service Layer object
    curam.serviceplans.sl.intf.PlannedItem plannedItemSLObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // Planned Item entity object
    curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    PlannedItemKey plannedItemKey = new PlannedItemKey();
    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();
    PlannedSubGoalIDAndCaseID plannedSubGoalIDAndCaseID = new PlannedSubGoalIDAndCaseID();

    MilestoneDeliveryKey milestoneDeliveryKey = new MilestoneDeliveryKey();

    PlannedItemIndicator plannedItemIndicator = new PlannedItemIndicator();
    PlannedItemIndicator plannedItemIndicator2 = new PlannedItemIndicator();
    PlannedItemIndicator plannedItemIndicator3 = new PlannedItemIndicator();
    // BEGIN, CR00161962, LJ
    final PlannedItemIndicator plannedItemMandIndicator = new PlannedItemIndicator();

    // END, CR00161962
    // END, CR00091347

    plannedSubGoalKey.plannedSubGoalID = key.key.plannedSubGoalID;

    // Read service plan id.
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;

    // BEGIN, CR00227859, PM
    // Security variables
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = servicePlanDeliveryKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(
          curam.message.GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    servicePlanSubGoalSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    servicePlanSubGoalSecurityKey.plannedSubGoalKey.key.plannedSubGoalID = key.key.plannedSubGoalID;

    // check service plan security
    try {
      servicePlanSecurity.subGoalOperationSecurityCheck(
        servicePlanSubGoalSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_DELETE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_SUBGOAL_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_SENSITIVITY_CAN_NOT_BE_HIGHER_THAN_CURRENT_USER);
      } else {
        throw e;
      }
    }
    // BEGIN, CR00161962, LJ
    final curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDEntKey = new PlannedItemIDKey();
    // END, CR00161962
    // BEGIN, CR00091347, CM
    // retrieve planned item list for specified planned subgoal key
    PlannedItemForSubgoalList plannedItemForSubgoalList = plannedSubGoalObj.searchPlannedItems(
      key.key);

    // loop through the subgoal and remove all the planned items attached
    for (int i = 0; i < plannedItemForSubgoalList.dtls.size(); i++) {

      // set plannedItemKey
      plannedItemKey.plannedItemID = plannedItemForSubgoalList.dtls.item(i).plannedItemID;

      // set plannedItemIDKey
      plannedItemIDKey.plannedItemID = plannedItemKey.plannedItemID;

      // Check if Planned Item is associated with a case
      plannedItemIndicator = plannedItemSLObj.isPlannedItemAssociatedWithCase(
        plannedItemIDKey);

      // BEGIN, CR00093557, CM
      // Check if Planned Item is linked with an associated item
      plannedItemIndicator2 = plannedItemSLObj.isPlannedItemAssociated(
        plannedItemIDKey);

      // Check if the Planned Items status is 'In Progress' or 'Completed'
      plannedItemIndicator3 = plannedItemSLObj.isStatusInProgressOrCompleted(
        plannedItemIDKey);
      // END, CR00093557

      // BEGIN, CR00161962, LJ
      plannedItemIDEntKey.plannedItemID = plannedItemForSubgoalList.dtls.item(i).plannedItemID;

      // Check if the planned item mandatory indicator is true/false.
      plannedItemMandIndicator.plannedItemIndicator = plannedItemSLObj.isMandatoryIndSet(plannedItemIDEntKey).isMandatoryInd;
      // END, CR00161962
      // Check to see if any of the validations for a Planned Item fail
      if (plannedItemIndicator.plannedItemIndicator
        || plannedItemIndicator2.plannedItemIndicator
        || plannedItemIndicator3.plannedItemIndicator) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDSUBGOAL.ERR_SUBGOAL_XFV_DELETE_PLAN_ITEM_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);

      }
      // BEGIN, CR00161962, LJ
      // if planned item mandatory indicator is set then the sub goal should
      // not be allowed to be deleted.
      if (plannedItemMandIndicator.plannedItemIndicator) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDSUBGOAL.ERR_SUBGOAL_XFV_DELETE_PLAN_ITEM_MANDATORY_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
      // END, CR00161962
      // Remove the planned item(s)
      plannedItemObj.remove(plannedItemKey);

    }// End of for

    // set the key
    plannedSubGoalIDAndCaseID.caseID = servicePlanDeliveryKey.caseID;
    plannedSubGoalIDAndCaseID.plannedSubGoalID = key.key.plannedSubGoalID;

    // BEGIN, CR00236426, GP
    MilestoneDeliveryAndConfigDetailsList milestoneDeliveryAndConfigDetailsList = spMilestoneDeliveryLinkObj.searchMilestonesByPlannedSubGoalID1(
      plannedSubGoalIDAndCaseID);

    for (MilestoneDeliveryAndConfigDetails milestoneDeliveryAndConfigDetails :
      milestoneDeliveryAndConfigDetailsList.dtls.items()) {

      // Loop through the subgoal and remove all the milestone deliveries
      // attached.
      milestoneDeliveryKey.milestoneDeliveryID = milestoneDeliveryAndConfigDetails.milestoneDeliveryID;
      // END, CR00236426

      // Read the milestone delivery details.
      ReadMilestoneDeliveryDetails readMilestoneDeliveryDtls = MilestoneDeliveryFactory.newInstance().readDetails(
        milestoneDeliveryKey);

      // The milestone cannot be deleted if the status is In Progress or
      // Completed.
      if (!readMilestoneDeliveryDtls.status.equals(
        MILESTONESTATUSCODE.NOTSTARTED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDSUBGOAL.ERR_SUBGOAL_XFV_DELETE_MILESTONE_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);

      }

      // Remove the milestone delivery
      MilestoneFactory.newInstance().remove(milestoneDeliveryKey);

    }// end of for

    // Call for a physical removed based
    plannedSubGoalObj.remove(key.key);

  }// END, CR00091347

  /**
   * Validates that a planned sub goal exists for a specific service plan.
   * Returns a list of sub goal types.
   *
   * @param key
   * Contains the caseID key for the specific service plan.
   *
   * @return List of all sub-goal types.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_CREATE_SECURITY_CHECK_FAILED} - if
   * the user does not have the appropriate privileges to maintain
   * this service plan.
   * @throws AppException
   * {@link BPOPLANNEDSUBGOAL#ERR_CREATE_PARTICIPANT_SENSITIVITY_CHECK_FAILED}
   * - if the user does not have the appropriate privileges to add sub
   * goals to this service plan.
   */
  public PlannedSubGoalTypeCodeDetails validateGoalExistsAndReturnSubGoalTypes(
    PlannedSubGoalCaseIDKey key) throws AppException, InformationalException {

    // validate planned goal exists for service plan
    validateGoalExistsForServicePlan(key);

    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanOperationSecurityKey spOperationSecurityKey = new ServicePlanOperationSecurityKey();

    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.key.caseID;

    // set security check key
    spOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;
    spOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // Read service plan id.
    ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = key.key.caseID;

    spOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanOperationSecurityCheck(
        spOperationSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_CREATE_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDSUBGOAL.ERR_CREATE_PARTICIPANT_SENSITIVITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
    // used just to give the UIM page a way to get a sub-goal type code table
    // lookup
    PlannedSubGoalTypeCodeDetails plannedSubGoalTypeCodeDetails = new PlannedSubGoalTypeCodeDetails();

    return plannedSubGoalTypeCodeDetails;

  }

  /**
   * Returns all sub goals that can be selected for a planned sub goal of a
   * particular type.
   *
   * @param key Contains the planned sub-goal type key
   * @param caseIDKey unique identifier of the service plan delivery.
   *
   * @return List of all sub-goals available for a particular type.
   */
  public PlannedSubGoalListByTypeDetailsList select(
    PlannedSubGoalTypeCodeKey key, PlannedSubGoalCaseIDKey caseIDKey)
    throws AppException, InformationalException {
    // Sub-Goal entity manipulation variable
    curam.serviceplans.sl.entity.intf.GoalSubGoalLink goalSubGoalLinkObj = curam.serviceplans.sl.entity.fact.GoalSubGoalLinkFactory.newInstance();
    // input key
    curam.serviceplans.sl.entity.struct.GoalIDAndSubGoalTypeKey goalIDAndSubGoalTypeKey = new curam.serviceplans.sl.entity.struct.GoalIDAndSubGoalTypeKey();

    // PlannedGoal entity manipulation variable
    curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    curam.core.struct.CaseID caseID = new curam.core.struct.CaseID();

    // return value
    PlannedSubGoalListByTypeDetailsList plannedSubGoalListByTypeDetailsList = new PlannedSubGoalListByTypeDetailsList();

    validateTypeCodeSelected(key);

    // set caseID key
    caseID.caseID = caseIDKey.key.caseID;

    goalIDAndSubGoalTypeKey.typeCode = key.typeCode;
    goalIDAndSubGoalTypeKey.goalID = plannedGoalObj.readGoalIDByCaseID(caseID).goalID;

    // retrieve all sub goals of a certain type and status
    plannedSubGoalListByTypeDetailsList.list = goalSubGoalLinkObj.searchSubGoalsByGoalAndType(
      goalIDAndSubGoalTypeKey);

    return plannedSubGoalListByTypeDetailsList;

  }

  /**
   * Checks the sensitivity level against the service plan participant and proposed
   * owner. Only called when inserting and modifying a sub goal
   *
   * @param key Contains the sensitivity check details
   */
  public void checkSensitivityForProposedOwnerAndPlanParticipant(
    PlanParticipantSensitivityAndUserName key)
    throws AppException, InformationalException {

    Users usersObj = curam.core.fact.UsersFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    // Check proposed owner sensitivity against sub goal sensitivity
    usersKey.userName = key.ownerID;
    UserSecurityDetails userSecurityDetails = usersObj.readUserSecurityDetails(
      usersKey);

    if (Integer.parseInt(key.subGoalSensitivity)
      > Integer.parseInt(userSecurityDetails.sensitivity)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDSUBGOAL.ERR_SENSITIVITY_CAN_NOT_BE_HIGHER_THAN_PROPOSED_OWNER),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // Check the plan participant sensitivity against the sub goal sensitivity
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    SensitivityCode sensitivityCode = new SensitivityCode();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;

    sensitivityCode = concernRoleObj.readSensitivityCode(concernRoleKey);

    if (Integer.parseInt(key.subGoalSensitivity)
      < Integer.parseInt(sensitivityCode.sensitivity)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDSUBGOAL.ERR_SENSITIVITY_CAN_NOT_BE_LOWER_THAN_THE_PLAN_PARTICIPANT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
  }

  /**
   * Validates the a goal exists for service plan delivery
   *
   * @param plannedSubGoalCaseIDKey Contains the sensitivity check details
   */
  public void validateGoalExistsForServicePlan(PlannedSubGoalCaseIDKey plannedSubGoalCaseIDKey)
    throws AppException, InformationalException {

    // Make sure there exists a Planned Goal for the particular
    // case before allowing an addition of a Sub-Goal
    PlannedGoalCaseIDKey plannedGoalCaseIDKey = new PlannedGoalCaseIDKey();

    plannedGoalCaseIDKey.caseID = plannedSubGoalCaseIDKey.key.caseID;
    PlannedGoalCountDetails plannedGoalCountDetails = null;
    curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = PlannedGoalFactory.newInstance();

    plannedGoalCountDetails = plannedGoalObj.countPlannedGoalByCaseID(
      plannedGoalCaseIDKey);

    // make sure record count does not equal to zero
    if (plannedGoalCountDetails.recordCount == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_SELECTTYPE_NO_GOAL_DEFINED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  /**
   * Validates owner details for a service plan sub goal
   *
   * @param createPlannedSubGoalDetails Contains the sub goal details to be created
   */
  public void validateOwnerDetails(CreatePlannedSubGoalDetails createPlannedSubGoalDetails)
    throws AppException, InformationalException {

    // Check to see if owner has been selected
    if ((createPlannedSubGoalDetails.me == false)
      && (createPlannedSubGoalDetails.dtls.ownerID.length() == 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_CREATE_NO_OWNER_SELECTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Check to see if only one of the owner details is set
    if ((createPlannedSubGoalDetails.me == true)
      && (createPlannedSubGoalDetails.dtls.ownerID.length() > 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_CREATE_MULTI_OWNERS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates the a sub goal type was selected
   *
   * @param plannedSubGoalTypeCodeKey Contains the sub goal type code
   */
  public void validateTypeCodeSelected(PlannedSubGoalTypeCodeKey plannedSubGoalTypeCodeKey)
    throws AppException, InformationalException {

    // make sure a type has been selected
    if (plannedSubGoalTypeCodeKey.typeCode == null) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_SELECTSUBGOAL_NO_TYPE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  /**
   * Clones planned sub goals.
   *
   */

  public void clone(
    curam.serviceplans.sl.struct.PlannedSubGoalDtls oldPlannedSubGoalDtls,
    PlannedGoalKey newPlannedGoalID,
    PlannedGroupKey newPlannedGroupID)
    throws AppException, InformationalException {

    // PlannedSubGoal entity manipulation variables
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.PlannedSubGoalDtls plannedSubGoalDtls;
    curam.serviceplans.sl.entity.struct.PlannedSubGoalKey plannedSubGoalKey = new curam.serviceplans.sl.entity.struct.PlannedSubGoalKey();
    curam.serviceplans.sl.entity.struct.ModifyOutcomeAchievedDetails modifyOutcomeAchievedDetails = new curam.serviceplans.sl.entity.struct.ModifyOutcomeAchievedDetails();

    // Planned Item business object
    curam.serviceplans.sl.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.fact.PlannedItemFactory.newInstance();

    // set outcome achieved to not attained for the old sub goal
    plannedSubGoalKey.plannedSubGoalID = oldPlannedSubGoalDtls.dtls.plannedSubGoalID;

    // read details
    plannedSubGoalDtls = plannedSubGoalObj.read(plannedSubGoalKey);

    // BEGIN, CR00108566, MC
    boolean closePreviousPlan_default = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE_DEFAULT);

    boolean closePreviousPlan = curam.util.resources.Configuration.getBooleanProperty(
      curam.core.impl.EnvVars.ENV_SERVICEPLANS_CLOSE_PREVIOUS_PLAN_ON_CLONE,
      closePreviousPlan_default);

    if (closePreviousPlan) {
      modifyOutcomeAchievedDetails.outcomeAchieved = OUTCOMEACHIEVED.NOTATTAINED;
      modifyOutcomeAchievedDetails.versionNo = plannedSubGoalDtls.versionNo;

      // modify outcome achieved for the old sub goal
      plannedSubGoalObj.modifyOutcomeAchieved(plannedSubGoalKey,
        modifyOutcomeAchievedDetails);
    }
    // END, CR00108566


    // BEGIN, CR00117949, MC
    // CaseStatus manipulation variables
    // read current status

    curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();

    CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();

    plannedSubGoalKey.plannedSubGoalID = oldPlannedSubGoalDtls.dtls.plannedSubGoalID;

    currentCaseStatusKey.caseID = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(plannedSubGoalKey).caseID;

    // BEGIN, CR00224271, ZV
    curam.core.struct.CaseStatusDtls caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
      currentCaseStatusKey);

    // END, CR00224271

    if (closePreviousPlan
      && !curam.codetable.CASESTATUS.CLOSED.equals(caseStatusDtls.statusCode)) {

      // create new planned sub goal record
      plannedSubGoalDtls.ownerID = oldPlannedSubGoalDtls.dtls.ownerID;
      plannedSubGoalDtls.subGoalID = oldPlannedSubGoalDtls.dtls.subGoalID;
      plannedSubGoalDtls.plannedGoalID = newPlannedGoalID.key.plannedGoalID;
      plannedSubGoalDtls.outcomeAchieved = oldPlannedSubGoalDtls.dtls.outcomeAchieved;

      plannedSubGoalDtls.plannedGroupID = newPlannedGroupID.key.plannedGroupID;
      plannedSubGoalDtls.sensitivityCode = oldPlannedSubGoalDtls.dtls.sensitivityCode;

    } else {

      plannedSubGoalDtls = new PlannedSubGoalDtls();

      plannedSubGoalDtls.plannedGoalID = newPlannedGoalID.key.plannedGoalID;
      plannedSubGoalDtls.recordStatus = RECORDSTATUS.NORMAL;
      plannedSubGoalDtls.ownerID = curam.util.transaction.TransactionInfo.getProgramUser();

      plannedSubGoalDtls.plannedGroupID = newPlannedGroupID.key.plannedGroupID;

      plannedSubGoalDtls.sensitivityCode = SENSITIVITY.DEFAULTCODE;
      plannedSubGoalDtls.subGoalID = oldPlannedSubGoalDtls.dtls.subGoalID;

    }

    // END, CR00117949

    // insert planned sub goal
    plannedSubGoalObj.insert(plannedSubGoalDtls);

    PlannedSubGoalKey originalPlannedSubGoalKey = new PlannedSubGoalKey();
    PlannedSubGoalKey newCreatedPlannedSubGoalKey = new PlannedSubGoalKey();

    originalPlannedSubGoalKey.key.plannedSubGoalID = oldPlannedSubGoalDtls.dtls.plannedSubGoalID;

    newCreatedPlannedSubGoalKey.key.plannedSubGoalID = plannedSubGoalDtls.plannedSubGoalID;

    // clone planned items
    plannedItemObj.clonePlanItemsForServicePlan(originalPlannedSubGoalKey,
      newCreatedPlannedSubGoalKey);

    // BEGIN, CR00057087, PMD
    // Search for all milestones at planned subgoal level and clone them
    curam.serviceplans.sl.entity.struct.PlannedGoalKey oldPlannedGoalkey = new curam.serviceplans.sl.entity.struct.PlannedGoalKey();

    oldPlannedGoalkey.plannedGoalID = oldPlannedSubGoalDtls.dtls.plannedGoalID;

    // Read the old planned goal details to get the case id.
    PlannedGoalDtls oldPlannedGoalDtls = PlannedGoalFactory.newInstance().read(
      oldPlannedGoalkey);

    PlannedSubGoalIDAndCaseID plannedSubGoalIDAndCaseID = new PlannedSubGoalIDAndCaseID();

    plannedSubGoalIDAndCaseID.plannedSubGoalID = oldPlannedSubGoalDtls.dtls.plannedSubGoalID;
    plannedSubGoalIDAndCaseID.caseID = oldPlannedGoalDtls.caseID;

    // Search for planned subgoal milestones
    SPMilestoneAndLinkDtlsList spMilestoneAndLinkDtlsList = SPMilestoneDeliveryLinkFactory.newInstance().searchMilestonesAndLinksByCaseIDAndPlannedSubGoalID(
      plannedSubGoalIDAndCaseID);

    MilestoneConfiguration milestoneConfig = MilestoneConfigurationFactory.newInstance();
    MilestoneConfigurationKey milestoneConfigKey = new MilestoneConfigurationKey();

    for (int i = 0; i < spMilestoneAndLinkDtlsList.dtls.size(); i++) {

      curam.serviceplans.sl.entity.struct.PlannedGoalKey newPlannedGoalkey = new curam.serviceplans.sl.entity.struct.PlannedGoalKey();

      newPlannedGoalkey.plannedGoalID = newPlannedGoalID.key.plannedGoalID;

      // Read the new planned goal details to get the case id.
      PlannedGoalDtls newPlannedGoalDtls = PlannedGoalFactory.newInstance().read(
        newPlannedGoalkey);

      SPMilestoneAndLinkDtls spMilestoneAndLinkDtls = new SPMilestoneAndLinkDtls();

      // BEGIN, CR00117949, MC
      if (closePreviousPlan
        && !curam.codetable.CASESTATUS.CLOSED.equals(caseStatusDtls.statusCode)) {
        spMilestoneAndLinkDtls.assign(spMilestoneAndLinkDtlsList.dtls.item(i));
      } else {

        milestoneConfigKey.milestoneConfigurationID = spMilestoneAndLinkDtlsList.dtls.item(i).milestoneConfigurationID;
        MilestoneConfigurationDtls milestoneConfigurationDtls = milestoneConfig.read(
          milestoneConfigKey);

        // BEGIN, CR00279939, PS
        spMilestoneAndLinkDtls.expectedStartDate = spMilestoneAndLinkDtlsList.dtls.item(i).expectedStartDate;
        spMilestoneAndLinkDtls.expectedEndDate = spMilestoneAndLinkDtlsList.dtls.item(i).expectedEndDate;
        spMilestoneAndLinkDtls.actualEndDate = spMilestoneAndLinkDtlsList.dtls.item(i).actualEndDate;
        spMilestoneAndLinkDtls.actualStartDate = spMilestoneAndLinkDtlsList.dtls.item(i).actualStartDate;
        spMilestoneAndLinkDtls.comments = spMilestoneAndLinkDtlsList.dtls.item(i).comments;
        // END, CR00279939

        spMilestoneAndLinkDtls.milestoneConfigurationID = milestoneConfigurationDtls.milestoneConfigurationID;
        spMilestoneAndLinkDtls.status = MILESTONESTATUSCODE.NOTSTARTED;
        spMilestoneAndLinkDtls.milestoneDeliveryID = spMilestoneAndLinkDtlsList.dtls.item(i).milestoneDeliveryID;
        spMilestoneAndLinkDtls.ownerUserName = TransactionInfo.getProgramUser();

      }
      spMilestoneAndLinkDtls.caseID = newPlannedGoalDtls.caseID;
      // END, CR00117949

      // Clone the milestone
      MilestoneFactory.newInstance().clone(spMilestoneAndLinkDtls,
        new PlannedGroupKey(), newCreatedPlannedSubGoalKey);
    }
    // END, CR00057087
  }

  /**
   * Reads case ID of the service plan delivery for which the planned sub goal
   * has been created.
   *
   * @param key planned item details
   *
   * @return caseID
   */
  public ReadCaseIDByPlannedSubGoalIDDetails readCaseID(PlannedSubGoalKey key)
    throws AppException, InformationalException {

    // return value
    ReadCaseIDByPlannedSubGoalIDDetails readCaseIDByPlannedSubGoalIDDetails = new ReadCaseIDByPlannedSubGoalIDDetails();

    // PlannedSubGoal entity manipulation variables
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();

    // read case ID
    readCaseIDByPlannedSubGoalIDDetails.dtls = plannedSubGoalObj.readCaseIDByPlannedSubGoalID(
      key.key);

    // return case id
    return readCaseIDByPlannedSubGoalIDDetails;
  }

  // BEGIN, CR00053508, PMD
  /**
   * Returns all milestones for a specified planned sub-goal.
   *
   * @param key the planned sub-goal key
   *
   * @return List of all milestones of the requested planned sub-goal
   */
  public PlanContentMilestoneDetailsList readMilestonesForPlannedSubGoal(
    PlannedSubGoalKey key)
    throws AppException, InformationalException {

    // Return struct
    PlanContentMilestoneDetailsList planContentMilestoneDetailsList = new PlanContentMilestoneDetailsList();

    ReadCaseIDByPlannedSubGoalIDDetails readCaseIDByPlannedSubGoalIDDetails = new ReadCaseIDByPlannedSubGoalIDDetails();

    // Read the case id for the planned sub goal
    readCaseIDByPlannedSubGoalIDDetails.dtls = PlannedSubGoalFactory.newInstance().readCaseIDByPlannedSubGoalID(
      key.key);

    PlannedSubGoalIDAndCaseID plannedSubGoalIDAndCaseID = new PlannedSubGoalIDAndCaseID();

    plannedSubGoalIDAndCaseID.plannedSubGoalID = key.key.plannedSubGoalID;
    plannedSubGoalIDAndCaseID.caseID = readCaseIDByPlannedSubGoalIDDetails.dtls.caseID;

    // Get the list of milestones for the planned sub goal

    // BEGIN, CR00236426, GP
    MilestoneDeliveryDetails milestoneDeliveryDetails = new
      MilestoneDeliveryDetails();
    PlanContentMilestoneDetails planContentMilestoneDetails = new PlanContentMilestoneDetails();
    MilestoneDeliveryAndConfigDetailsList milestoneDeliveryAndConfigDetailsList = SPMilestoneDeliveryLinkFactory.newInstance().searchMilestonesByPlannedSubGoalID1(
      plannedSubGoalIDAndCaseID);

    for (MilestoneDeliveryAndConfigDetails milestoneDeliveryAndConfigDetails :
      milestoneDeliveryAndConfigDetailsList.dtls.items()) {

      milestoneDeliveryDetails = new MilestoneDeliveryDetails();

      milestoneDeliveryDetails.assign(milestoneDeliveryAndConfigDetails);

      // Read the localized name.
      if (0 != milestoneDeliveryAndConfigDetails.nameTextID) {

        LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          milestoneDeliveryAndConfigDetails.nameTextID);

        milestoneDeliveryDetails.name = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
      // Read the localized type.
      if (0 != milestoneDeliveryAndConfigDetails.typeTextID) {

        LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          milestoneDeliveryAndConfigDetails.typeTextID);

        milestoneDeliveryDetails.type = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
      // END, CR00236426

      planContentMilestoneDetails = new PlanContentMilestoneDetails();

      // Set the sub-goal milestone details.
      planContentMilestoneDetails.milestoneDeliveryID = milestoneDeliveryDetails.milestoneDeliveryID;
      planContentMilestoneDetails.name = milestoneDeliveryDetails.name;
      planContentMilestoneDetails.type = milestoneDeliveryDetails.type;
      planContentMilestoneDetails.status = milestoneDeliveryDetails.status;

      // Set the start date.
      if (planContentMilestoneDetails.status.equals(
        MILESTONESTATUSCODE.NOTSTARTED)) {

        planContentMilestoneDetails.startDate = milestoneDeliveryDetails.expectedStartDate;
      } else {
        planContentMilestoneDetails.startDate = milestoneDeliveryDetails.actualStartDate;
      }

      // Set the end date.
      if (planContentMilestoneDetails.status.equals(
        MILESTONESTATUSCODE.COMPLETED)) {

        planContentMilestoneDetails.endDate = milestoneDeliveryDetails.actualEndDate;
      } else {

        planContentMilestoneDetails.endDate = milestoneDeliveryDetails.expectedEndDate;
      }

      // Set the indicator.
      if (planContentMilestoneDetails.status.equals(
        MILESTONESTATUSCODE.NOTSTARTED)
          && (milestoneDeliveryDetails.expectedStartDate.before(
            curam.util.type.Date.getCurrentDate()))) {

        planContentMilestoneDetails.indicator = true;
      }

      planContentMilestoneDetailsList.dtlsList.addRef(
        planContentMilestoneDetails);
    }

    return planContentMilestoneDetailsList;
  }

}
