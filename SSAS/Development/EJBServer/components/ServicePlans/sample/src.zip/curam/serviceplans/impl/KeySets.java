/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.impl;


/**
 * Constants for Key Set for service plan component.
 *
 */
public abstract class KeySets extends curam.util.resources.KeySet {

  /**
   * Key set constant for service plan business object.
   */
  public static final String KEY_SET_SERCPLANBO = "SERCPLANBO";
}
