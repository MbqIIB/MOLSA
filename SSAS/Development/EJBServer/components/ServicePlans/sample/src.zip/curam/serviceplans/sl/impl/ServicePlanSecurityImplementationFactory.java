/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.core.impl.SecurityImplementationFactory;
import curam.message.BPOSERVICEPLANSECURITYIMPLEMENTATIONFACTORY;
import curam.serviceplans.sl.fact.ServicePlanSecurityFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * Provides a factory interface to set and retrieve the Service Plan Security
 * Object for the current transaction.
 */
public abstract class ServicePlanSecurityImplementationFactory {

  /**
   * The value used to attach the Security object to the Transaction.
   */
  protected static final Integer kSecurityIdentifier = new Integer(2);

  /**
   * Registers a Security Implementation Object for the current transaction.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public static void register() throws AppException, InformationalException {

    // register core security implementation
    SecurityImplementationFactory.register();
    // BEGIN, CR00178697, PB

    TransactionInfo.setFacadeScopeObject(kSecurityIdentifier,
      ServicePlanSecurityFactory.newInstance());
    // END, CR00178697

  }

  /**
   * Retrieves the Security Implementation Object for the current transaction.
   *
   * @return The Security Implementation Object for the current transaction.
   *
   * @throws AppException
   * {@link BPOSERVICEPLANSECURITYIMPLEMENTATIONFACTORY#ERR_
   * NO_SECURITY_IMPLEMENTATION_REGISTERED} - if no service plan
   * security implementation has been registered.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam V6.0, replaced with
   * {@link ServicePlanSecurityImplementationFactory#get1()}. This
   * method is returning the ServicePlanSecurity implementation
   * class object reference instead of ServicePlanSecurity interface
   * class reference, hence it is deprecated and no longer used. See
   * release note: CR00179387.
   */
  @Deprecated
  public static ServicePlanSecurity get() throws AppException,
      InformationalException {

    ServicePlanSecurity securityImpl = (ServicePlanSecurity) (TransactionInfo.getFacadeScopeObject(
      kSecurityIdentifier));

    // BEGIN, CR00178697, PB
    if (null == securityImpl) {
      // END, CR00178697

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANSECURITYIMPLEMENTATIONFACTORY.ERR_NO_SECURITY_IMPLEMENTATION_REGISTERED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    return securityImpl;
  }
  
  // BEGIN, CR00179387, NS
  /**
   * Retrieves the Security Interface Reference for the current transaction.
   *
   * @return The Security Interface Reference for the current transaction.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link  BPOSERVICEPLANSECURITYIMPLEMENTATIONFACTORY#ERR_
   * NO_SECURITY_IMPLEMENTATION_REGISTERED} - if no service plan
   * security implementation has been registered.
   */
  public static curam.serviceplans.sl.intf.ServicePlanSecurity get1()
    throws AppException, InformationalException {

    curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = (curam.serviceplans.sl.intf.ServicePlanSecurity) (TransactionInfo.getFacadeScopeObject(
      kSecurityIdentifier));
    
    // BEGIN, CR00273882, KRK
    // Register the service plan security implementation if it is not registered
    // already and then return the instance.
    if (null == servicePlanSecurity) { 
      register();
      servicePlanSecurity = (curam.serviceplans.sl.intf.ServicePlanSecurity) (
        TransactionInfo.getFacadeScopeObject(kSecurityIdentifier));
    }
    // END, CR00273882
    
    if (null == servicePlanSecurity) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSERVICEPLANSECURITYIMPLEMENTATIONFACTORY.ERR_NO_SECURITY_IMPLEMENTATION_REGISTERED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    return servicePlanSecurity;
  }
  // END, CR00179387
}
