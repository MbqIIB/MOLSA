/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2005,2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2005, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kActualCost;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kCaseID;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kClosed;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kEstimatedCost;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kGantt;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kGroup;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kGroupType;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kID;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kIntegrated;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kIntegratedName;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kIntegratedType;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kName;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kOpen;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kPlanItem;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kPlannedGoal;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kPlannedGroup;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kPlannedSubGoal;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kStatus;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kType;
import static curam.core.sl.infrastructure.impl.ServicePlanGanttConst.kView;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import curam.codetable.CASESTATUS;
import curam.codetable.PLANITEMNAME;
import curam.codetable.PLANNEDSUBGOALSTATUS;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.intf.SystemUser;
import curam.core.intf.Users;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.BPOSERVICEPLANSTATEMENT;
import curam.message.BPOTRACKINGGANTT;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryFactory;
import curam.serviceplans.sl.entity.fact.SPGDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanGroupFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.SPGDelivery;
import curam.serviceplans.sl.entity.intf.SPGDeliveryLink;
import curam.serviceplans.sl.entity.intf.ServicePlanGroup;
import curam.serviceplans.sl.entity.struct.IntegratedCaseIDKey;
import curam.serviceplans.sl.entity.struct.NameNotEditableIndDetails;
import curam.serviceplans.sl.entity.struct.PlanItemIDDetailsStruct;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlannedItemIDKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedGroupIDDetails;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedSubGoalIDDetails;
import curam.serviceplans.sl.entity.struct.SPGDeliveryDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryDtlsList;
import curam.serviceplans.sl.entity.struct.SPGDeliveryKey;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkDtls;
import curam.serviceplans.sl.entity.struct.SPGDeliveryLinkDtlsList;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.ServicePlanGroupKey;
import curam.serviceplans.sl.entity.struct.ServicePlanStatementDetails;
import curam.serviceplans.sl.entity.struct.ServicePlanStatementDetails1;
import curam.serviceplans.sl.struct.HideInformationIndicatorStruct;
import curam.serviceplans.sl.struct.PlannedGroupKey;
import curam.serviceplans.sl.struct.ProcessingDetailsStruct;
import curam.serviceplans.sl.struct.SPStatementXMLString;
import curam.serviceplans.sl.struct.ServicePlanDeliveryAndParticipantSummaryDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanForICList;
import curam.serviceplans.sl.struct.ServicePlanIntegratedCaseKey;
import curam.serviceplans.sl.struct.ServicePlanOperationSecurityKey;
import curam.serviceplans.sl.struct.ServicePlanStatementDeliveryDetails;
import curam.serviceplans.sl.struct.ServicePlanStatementDeliveryDetails1;
import curam.serviceplans.sl.struct.ServicePlanStatementDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanStatementDetailsList;
import curam.serviceplans.sl.struct.ServicePlanStatementDetailsList1;
import curam.serviceplans.sl.struct.ServicePlanStatementGoalDetails;
import curam.serviceplans.sl.struct.ServicePlanStatementGoalDetails1;
import curam.serviceplans.sl.struct.ServicePlanStatementGroupDetails;
import curam.serviceplans.sl.struct.ServicePlanStatementGroupDetails1;
import curam.serviceplans.sl.struct.ServicePlanStatementGroupKey;
import curam.serviceplans.sl.struct.ServicePlanStatementIntegratedDetails;
import curam.serviceplans.sl.struct.ServicePlanStatementIntegratedDetails1;
import curam.serviceplans.sl.struct.ServicePlanStatementIntegratedKey;
import curam.serviceplans.sl.struct.ServicePlanStatementXMLDetails;
import curam.serviceplans.sl.struct.ServicePlanStatementXMLString;
import curam.serviceplans.sl.struct.UserSensitivityCodeStruct;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Money;


/**
 * Business layer functionality formatting service plan statement.
 */
public abstract class ServicePlanStatement extends curam.serviceplans.sl.base.ServicePlanStatement {

  // BEGIN, CR00222522, ELG
  // __________________________________________________________________________
  /**
   * Gets service plan statement information from database tables and formats
   * XML string for a service plan delivery.
   *
   * @param servicePlanDeliveryKey
   * Contains caseID
   *
   * @return XML String containing Service Plan Statement information
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   * @deprecated Since Curam V6.0, replaced by
   * {@link #showStatement(ServicePlanDeliveryKey)}. See release
   * note: CR00222522.
   */
  @Deprecated
  // END, CR00222522
  public ServicePlanStatementXMLString showStatement(final
    ServicePlanDeliveryKey servicePlanDeliveryKey) throws AppException,
      InformationalException {
    // BEGIN, CR00161962, LJ
    ServicePlanStatementDeliveryKey servicePlanStatementDeliveryKey = new ServicePlanStatementDeliveryKey();

    servicePlanStatementDeliveryKey.caseID = servicePlanDeliveryKey.key.caseID;

    // BEGIN, CR00246182, TV
    // BEGIN, CR00208728, LP
    final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = readServicePlanStatementDetails(
      servicePlanStatementDeliveryKey);
    // END, CR00246182

    final ServicePlanStatementXMLString servicePlanStatementXMLString = createServicePlanStatementXmlDetails1(
      servicePlanStatementDeliveryDetails);

    // END, CR00208728

    return servicePlanStatementXMLString;
    // END, CR00161962
  }

  // BEGIN, CR00222522, ELG
  // __________________________________________________________________________
  /**
   * Gets service plan statement information from database tables and formats
   * XML string for a service plan delivery.
   *
   * @param servicePlanDeliveryKey
   * Contains caseID
   *
   * @return XML String containing Service Plan Statement information,
   * and boolean indicator indicating is XML details set or not
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  public ServicePlanStatementXMLDetails showStatement1(
    final ServicePlanDeliveryKey servicePlanDeliveryKey) throws AppException,
      InformationalException {

    // return structure
    ServicePlanStatementXMLDetails servicePlanStatementXMLDetails = new ServicePlanStatementXMLDetails();

    ServicePlanStatementDeliveryKey servicePlanStatementDeliveryKey = new ServicePlanStatementDeliveryKey();

    servicePlanStatementDeliveryKey.caseID = servicePlanDeliveryKey.key.caseID;

    // BEGIN, CR00246182, TV
    final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = readServicePlanStatementDetails(
      servicePlanStatementDeliveryKey, false);
    // END, CR00246182
    
    // BEGIN, CR00234055, MR
    final int numberOfStatements = servicePlanStatementDeliveryDetails.statementDetailsList.servicePlanStatementDetailsList.dtls.size();

    servicePlanStatementXMLDetails.dtls = createServicePlanStatementXmlDetails1(
      servicePlanStatementDeliveryDetails);

    if ((numberOfStatements > 0)
      && (servicePlanStatementXMLDetails.dtls.statementDetails.length() > 0)) {
      // END, CR00234055
      servicePlanStatementXMLDetails.statementDetailsXMLEmptyInd = false;

    } else {

      servicePlanStatementXMLDetails.statementDetailsXMLEmptyInd = true;

    }

    return servicePlanStatementXMLDetails;

  }

  // END, CR00222522

  // BEGIN, CR00246182, TV
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Reads the details required to create the XML string for the Costing Gantt.
   *
   * @param servicePlanStatementDeliveryKey
   * Contains case ID of the service plan delivery.
   *
   * @return Details required to create the tracking Gantt XML string.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  public ServicePlanStatementDeliveryDetails1 readServicePlanStatementDetails(
    ServicePlanStatementDeliveryKey servicePlanStatementDeliveryKey)
    throws AppException, InformationalException {

    // Call the read method and allow exceptions to be thrown
    final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = readServicePlanStatementDetails(
      servicePlanStatementDeliveryKey, true);

    // Return details object
    return servicePlanStatementDeliveryDetails;
  }

  // END, CR00161962
  // END, CR00246182

  // BEGIN, CR00246182, TV
  // BEGIN, CR00161962, LJ

  // __________________________________________________________________________

  /**
   * Reads the Service Plan Statement Delivery Details.
   *
   * @param key
   * ServicePlanStatementDeliveryKey
   * @param throwException
   * throwException
   *
   * @return ServicePlanStatementDeliveryDetails
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  public ServicePlanStatementDeliveryDetails1 readStatementDeliveryDetailsWithExceptionOptional(
    ServicePlanStatementDeliveryKey key, boolean throwException)
    throws AppException, InformationalException {

    // Call the read method and allow exceptions to be thrown
    final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = readServicePlanStatementDetails(
      key, throwException);

    // Return details object
    return servicePlanStatementDeliveryDetails;

  }

  // END, CR00161962
  // END, CR00246182

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Creates the XML string for the Service Plan Delivery costing Gantt.
   *
   * @param details
   * Details required to create the costing Gantt XML String.
   *
   * @return The created XML String to be displayed on the costing Gantt
   * diagram.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#
   * createServicePlanStatementXmlDetails1()}
   */
  @Deprecated
  public ServicePlanStatementXMLString createServicePlanStatementXmlDetails(
    ServicePlanStatementDeliveryDetails servicePlanStatementDeliveryDetails)
    throws AppException, InformationalException {

    ServicePlanStatementXMLString servicePlanStatementXMLString = formatServicePlanStatementXML(
      servicePlanStatementDeliveryDetails.statementDetailsList,
      servicePlanStatementDeliveryDetails.statementGoalDetails);

    return servicePlanStatementXMLString;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________
  /**
   * Gets service plan statement information from database tables and formats
   * XML string for a service plan group delivery.
   *
   * @param servicePlanStatementGroupKey
   * Contains service plan group delivery ID
   *
   * @return XML String containing Service Plan Group Statement information
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00229255 MN
  public SPStatementXMLString showGroupStatement(
    ServicePlanStatementGroupKey servicePlanStatementGroupKey)
    throws AppException, InformationalException {
    // END, CR00229225

    // BEGIN, CR00246182, TV
    // BEGIN, CR00208728, LP
    final ServicePlanStatementGroupDetails1 servicePlanStatementGroupDetails = readServicePlanStatementGroupDetails(
      servicePlanStatementGroupKey);
    // END, CR00246182

    // BEGIN, CR00229255 MN
    final SPStatementXMLString servicePlanStatementXMLString = createServicePlanStatementGroupXmlDetails1(
      servicePlanStatementGroupDetails);

    // END, CR00229225
    // END, CR00208728

    return servicePlanStatementXMLString;
  }

  // END, CR00161962

  // BEGIN, CR00246182, TV 
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Reads the details required to create the XML string for the Costing Gantt.
   *
   * @param servicePlanStatementGroupKey
   * Contains the Service Plan Delivery Group ID.
   *
   * @return Details required to create the tracking Gantt XML string.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  public ServicePlanStatementGroupDetails1 readServicePlanStatementGroupDetails(
    ServicePlanStatementGroupKey servicePlanStatementGroupKey)
    throws AppException, InformationalException {

    // Read the Service Plan Group Delivery details based on the passed ID
    final SPGDelivery spgDeliveryObj = SPGDeliveryFactory.newInstance();

    SPGDeliveryKey spgDeliveryKey = new SPGDeliveryKey();

    spgDeliveryKey.servicePlanGroupDeliveryId = servicePlanStatementGroupKey.groupDeliveryID;

    final SPGDeliveryDtls spgDeliveryDtls = spgDeliveryObj.read(spgDeliveryKey);

    // Read the Service Plan Group Details
    final ServicePlanGroup servicePlanGroupObj = ServicePlanGroupFactory.newInstance();

    final ServicePlanGroupKey servicePlanGroupKey = new ServicePlanGroupKey();

    servicePlanGroupKey.servicePlanGroupId = spgDeliveryDtls.servicePlanGroupId;

    final ServicePlanGroupDtls servicePlanGroupDtls = servicePlanGroupObj.read(
      servicePlanGroupKey);

    // Create the statement group details object
    final ServicePlanStatementGroupDetails1 servicePlanStatementGroupDetails = new ServicePlanStatementGroupDetails1();

    servicePlanStatementGroupDetails.groupDeliveryID = servicePlanStatementGroupKey.groupDeliveryID;
    servicePlanStatementGroupDetails.groupName = servicePlanGroupDtls.servicePlanGroupName;

    // Read the details of the associated service plans
    final SPGDeliveryLink spgDeliveryLinkObj = SPGDeliveryLinkFactory.newInstance();

    spgDeliveryKey = new SPGDeliveryKey();

    spgDeliveryKey.servicePlanGroupDeliveryId = servicePlanStatementGroupKey.groupDeliveryID;

    final SPGDeliveryLinkDtlsList spgDeliveryLinkDtlsList = spgDeliveryLinkObj.searchServicePlanDeliveriesByServicePlanGroupDeliveryId(
      spgDeliveryKey);

    // Setup variables for estimated / actual costs
    double estimatedCost = 0;
    double actualCost = 0;

    // Loop around each of the associated service plans
    final int numberOfSPGDeliveries = spgDeliveryLinkDtlsList.dtls.size();

    final ServicePlanStatementDeliveryKey servicePlanStatementDeliveryKey = new ServicePlanStatementDeliveryKey();

    for (int spgDeliveryCount = 0; spgDeliveryCount < numberOfSPGDeliveries; spgDeliveryCount++) {

      final SPGDeliveryLinkDtls spgDeliveryLinkDtls = spgDeliveryLinkDtlsList.dtls.item(
        spgDeliveryCount);

      servicePlanStatementDeliveryKey.caseID = spgDeliveryLinkDtls.caseID;

      final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = readServicePlanStatementDetails(
        servicePlanStatementDeliveryKey, false);

      // Check if data has been populated
      if (servicePlanStatementDeliveryDetails.statementGoalDetails.servicePlanStatementGoalDetails.plannedGoalID
        != 0) {
        // Add costings from service plan goal
        estimatedCost += servicePlanStatementDeliveryDetails.statementGoalDetails.servicePlanStatementGoalDetails.estimatedCost.getValue();

        actualCost += servicePlanStatementDeliveryDetails.statementGoalDetails.servicePlanStatementGoalDetails.actualCost.getValue();

        servicePlanStatementGroupDetails.statementDeliveryDetailsList.addRef(
          servicePlanStatementDeliveryDetails);
      }
    }

    servicePlanStatementGroupDetails.estimatedCost = new Money(estimatedCost);
    servicePlanStatementGroupDetails.actualCost = new Money(actualCost);

    return servicePlanStatementGroupDetails;
  }

  // END, CR00161962
  // END, CR00246182 

  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Creates the XML string for the Service Plan Group Delivery costing Gantt.
   *
   * @param details
   * Details required to create the costing Gantt XML String.
   *
   * @return The created XML String to be displayed on the costing Gantt
   * diagram.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#
   * createServicePlanStatementGroupXmlDetails1()}
   */
  @Deprecated
  // BEGIN, CR00229255 MN
  public SPStatementXMLString createServicePlanStatementGroupXmlDetails(
    ServicePlanStatementGroupDetails servicePlanStatementGroupDetails)
    throws AppException, InformationalException {
    // END, CR00229225
    // Create root node
    Element ganttElement = new Element(kGantt);

    ganttElement.setAttribute(kView, kOpen);

    // Create service plan group element
    Element groupElement = createGroupXML(servicePlanStatementGroupDetails);

    ganttElement.addContent(groupElement);

    // Output the XML as a string and assign it to the return object
    XMLOutputter outputter = new XMLOutputter();

    // BEGIN, CR00229255 MN
    SPStatementXMLString servicePlanStatementXMLString = new SPStatementXMLString();

    // END, CR00229225

    servicePlanStatementXMLString.newStatementDetails = outputter.outputString(
      ganttElement);

    return servicePlanStatementXMLString;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________
  /**
   * Gets service plan statement information from database tables and formats
   * XML string for an integrated service plan.
   *
   * @param servicePlanStatementIntegratedKey
   * Contains integrated service plan ID
   *
   * @return XML String containing Integrated Service Plan Statement information
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00229255 MN
  public SPStatementXMLString showIntegratedStatement(
    ServicePlanStatementIntegratedKey servicePlanStatementIntegratedKey)
    throws AppException, InformationalException {
    // END, CR00229225

    // BEGIN, CR00246182, TV
    // BEGIN, CR00208728, LP
    final ServicePlanStatementIntegratedDetails1 servicePlanStatementIntegratedDetails = readServicePlanStatementIntegratedDetails(
      servicePlanStatementIntegratedKey);
    // END, CR00246182
    
    // BEGIN, CR00229255 MN
    final SPStatementXMLString servicePlanStatementXMLString = createServicePlanStatementIntegratedXmlDetails1(
      servicePlanStatementIntegratedDetails);

    // END, CR00229225
    // END, CR00208728

    return servicePlanStatementXMLString;
  }

  // END, CR00161962

  
  // BEGIN, CR00246182, TV
  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________

  /**
   * Reads the details required to create the XML string for the Costing Gantt.
   *
   * @param servicePlanStatementGroupKey
   * Contains the Integrated Service Plan ID.
   *
   * @return Details required to create the tracking Gantt XML string.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  public ServicePlanStatementIntegratedDetails1 readServicePlanStatementIntegratedDetails(
    ServicePlanStatementIntegratedKey servicePlanStatementIntegratedKey)
    throws AppException, InformationalException {

    // Find all associated service plans with 'Integrated Service Plan' a.k.a.
    // 'Integrated Case'
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

    servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = servicePlanStatementIntegratedKey.integratedCaseID;

    final ServicePlanForICList servicePlanForICList = servicePlanDeliveryObj.listByIntegratedCase(
      servicePlanIntegratedCaseKey);

    // Put all found values into map
    final Map<Long, ServicePlanDeliveryAndParticipantSummaryDetails> servicePlanMap = new HashMap<Long, ServicePlanDeliveryAndParticipantSummaryDetails>();

    int numberOfServicePlans = servicePlanForICList.servicePlanDeliveryAndParticipantSummaryDetailsList.size();

    for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {
      final ServicePlanDeliveryAndParticipantSummaryDetails servicePlanDetails = servicePlanForICList.servicePlanDeliveryAndParticipantSummaryDetailsList.item(
        servicePlanCount);

      servicePlanMap.put(servicePlanDetails.caseID, servicePlanDetails);
    }

    // Create return object
    final ServicePlanStatementIntegratedDetails1 servicePlanStatementIntegratedDetails = new ServicePlanStatementIntegratedDetails1();

    servicePlanStatementIntegratedDetails.integratedCaseID = servicePlanStatementIntegratedKey.integratedCaseID;

    // Setup variables for estimated / actual costs
    double estimatedCost = 0;
    double actualCost = 0;

    // Find all associated service plan groups
    final SPGDelivery spgDeliveryObj = SPGDeliveryFactory.newInstance();

    final IntegratedCaseIDKey caseHeaderKey = new IntegratedCaseIDKey();

    caseHeaderKey.integratedCaseID = servicePlanStatementIntegratedKey.integratedCaseID;

    final SPGDeliveryDtlsList spgDeliveryDtlsList = spgDeliveryObj.searchByIntegratedCaseId(
      caseHeaderKey);

    final int numberOfSPGDeliveries = spgDeliveryDtlsList.dtls.size();

    final ServicePlanStatementGroupKey servicePlanStatementGroupKey = new ServicePlanStatementGroupKey();

    for (int spgDeliveryCount = 0; spgDeliveryCount < numberOfSPGDeliveries; spgDeliveryCount++) {
      // Read the group details and add to return object.
      final SPGDeliveryDtls spgDeliveryDtls = spgDeliveryDtlsList.dtls.item(
        spgDeliveryCount);

      servicePlanStatementGroupKey.groupDeliveryID = spgDeliveryDtls.servicePlanGroupDeliveryId;

      // BEGIN, CR00246182, TV
      final ServicePlanStatementGroupDetails1 servicePlanStatementGroupDetails = readServicePlanStatementGroupDetails(
        servicePlanStatementGroupKey);

      // END, CR00246182

      // Assign values from each underlying service plan group
      estimatedCost += servicePlanStatementGroupDetails.estimatedCost.getValue();
      actualCost += servicePlanStatementGroupDetails.actualCost.getValue();

      servicePlanStatementIntegratedDetails.statementGroupDetailsList.addRef(
        servicePlanStatementGroupDetails);

      // Remove any service plans within group from main list.
      numberOfServicePlans = servicePlanStatementGroupDetails.statementDeliveryDetailsList.size();

      for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {
        final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = servicePlanStatementGroupDetails.statementDeliveryDetailsList.item(
          servicePlanCount);

        final long servicePlanDeliveryCaseID = servicePlanStatementDeliveryDetails.statementGoalDetails.servicePlanStatementGoalDetails.caseID;

        if (servicePlanMap.containsKey(servicePlanDeliveryCaseID)) {
          servicePlanMap.remove(servicePlanDeliveryCaseID);
        }
      }
    }

    // Add remaining service plans in list to return object.
    final Iterator<ServicePlanDeliveryAndParticipantSummaryDetails> servicePlanIterator = servicePlanMap.values().iterator();

    final ServicePlanStatementDeliveryKey servicePlanStatementDeliveryKey = new ServicePlanStatementDeliveryKey();

    while (servicePlanIterator.hasNext()) {
      final ServicePlanDeliveryAndParticipantSummaryDetails servicePlanDetails = servicePlanIterator.next();

      servicePlanStatementDeliveryKey.caseID = servicePlanDetails.caseID;

      final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = readServicePlanStatementDetails(
        servicePlanStatementDeliveryKey, false);

      // Check if data has been populated
      if (servicePlanStatementDeliveryDetails.statementGoalDetails.servicePlanStatementGoalDetails.plannedGoalID
        != 0) {
        // Assign values from each underlying service plan group
        estimatedCost += servicePlanStatementDeliveryDetails.statementGoalDetails.servicePlanStatementGoalDetails.estimatedCost.getValue();

        actualCost += servicePlanStatementDeliveryDetails.statementGoalDetails.servicePlanStatementGoalDetails.actualCost.getValue();

        servicePlanStatementIntegratedDetails.statementDeliveryDetailsList.addRef(
          servicePlanStatementDeliveryDetails);
      }
    }

    servicePlanStatementIntegratedDetails.estimatedCost = new Money(
      estimatedCost);
    servicePlanStatementIntegratedDetails.actualCost = new Money(actualCost);

    return servicePlanStatementIntegratedDetails;

  }

  // END, CR00161962
  // END, CR00246182  
  
  
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Creates the XML string for the Integrated Service Plan costing Gantt.
   *
   * @param details
   * Details required to create the costing Gantt XML String.
   *
   * @return The created XML String to be displayed on the costing Gantt
   * diagram.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#
   * createServicePlanStatementIntegratedXmlDetails1()}
   */
  @Deprecated
  // BEGIN, CR00229255 MN
  public SPStatementXMLString createServicePlanStatementIntegratedXmlDetails(
    ServicePlanStatementIntegratedDetails
    servicePlanStatementIntegratedDetails)
    throws AppException, InformationalException {
    // END, CR00229225

    // Create the integrated service plan element
    Element integratedElement = new Element(kIntegrated);

    integratedElement.setAttribute(kType, kIntegratedType);

    integratedElement.setAttribute(kID,
      String.valueOf(servicePlanStatementIntegratedDetails.integratedCaseID));
    // BEGIN CR00381184 CC
    integratedElement.setAttribute(kName,
      BPOTRACKINGGANTT.INF_TRACKING_GANTT_STATEMENT_INTEGRATED_SERVICE_PLAN.getMessageText(
      TransactionInfo.getProgramLocale()));
    // END  CR00381184
    integratedElement.setAttribute(kEstimatedCost,
      servicePlanStatementIntegratedDetails.estimatedCost.toString());
    integratedElement.setAttribute(kActualCost,
      servicePlanStatementIntegratedDetails.actualCost.toString());

    // Add the service plan group deliveries
    int numberOfGroups = servicePlanStatementIntegratedDetails.statementGroupDetailsList.size();

    for (int groupCount = 0; groupCount < numberOfGroups; groupCount++) {
      ServicePlanStatementGroupDetails servicePlanStatementGroupDetails = servicePlanStatementIntegratedDetails.statementGroupDetailsList.item(
        groupCount);

      // Create group element
      Element groupElement = createGroupXML(servicePlanStatementGroupDetails);

      integratedElement.addContent(groupElement);
    }

    // Add the service plan deliveries
    int numberOfServicePlans = servicePlanStatementIntegratedDetails.statementDeliveryDetailsList.size();

    for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {

      ServicePlanStatementDeliveryDetails servicePlanStatementDeliveryDetails = servicePlanStatementIntegratedDetails.statementDeliveryDetailsList.item(
        servicePlanCount);

      // Create goal element
      Element goalElement = createGoalXML(servicePlanStatementDeliveryDetails);

      // Add goal element to the ISP element
      integratedElement.addContent(goalElement);
    }

    // Create root node
    Element ganttElement = new Element(kGantt);

    ganttElement.setAttribute(kView, kOpen);

    ganttElement.addContent(integratedElement);

    // Output the XML as a string and assign it to the return object
    XMLOutputter outputter = new XMLOutputter();

    // BEGIN, CR00229255 MN
    SPStatementXMLString servicePlanStatementXMLString = new SPStatementXMLString();

    // END, CR00229225

    servicePlanStatementXMLString.newStatementDetails = outputter.outputString(
      ganttElement);

    return servicePlanStatementXMLString;
  }

  // END, CR00161962
  // __________________________________________________________________________
  /**
   * Formats XML string from list retrieved from database
   *
   * @param servicePlanStatementDetailsList
   * List of service plan statement data retrieved from database
   * @param servicePlanStatementGoalDetails
   * Details of Planned Goal
   *
   * @return Service Plan Statement Data as XML String
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#formatServicePlanStatementXML1()}
   */
  @Deprecated
  public ServicePlanStatementXMLString formatServicePlanStatementXML(
    ServicePlanStatementDetailsList servicePlanStatementDetailsList,
    ServicePlanStatementGoalDetails servicePlanStatementGoalDetails)
    throws AppException, InformationalException {
    // BEGIN, CR00161962, LJ
    // Create goal element from passed objects
    ServicePlanStatementDeliveryDetails servicePlanStatementDeliveryDetails = new ServicePlanStatementDeliveryDetails();

    servicePlanStatementDeliveryDetails.statementGoalDetails = servicePlanStatementGoalDetails;
    servicePlanStatementDeliveryDetails.statementDetailsList = servicePlanStatementDetailsList;

    // Code for this refactored to private helper method for reuse elsewhere
    Element goalElement = createGoalXML(servicePlanStatementDeliveryDetails);

    // Create gantt element
    Element ganttElement = new Element(kGantt);

    String caseStatus = servicePlanStatementGoalDetails.servicePlanStatementGoalDetails.plannedGoalStatus;

    if (caseStatus.equals(CASESTATUS.CLOSED)
      || caseStatus.equals(CASESTATUS.COMPLETED)
      || caseStatus.equals(CASESTATUS.CANCELED)) {
      ganttElement.setAttribute(kView, kClosed);
    } else {
      ganttElement.setAttribute(kView, kOpen);
    }

    ganttElement.addContent(goalElement);

    // Output the return string
    XMLOutputter xmlOutputter = new XMLOutputter();

    ServicePlanStatementXMLString servicePlanStatementXMLString = new ServicePlanStatementXMLString();

    servicePlanStatementXMLString.statementDetails = xmlOutputter.outputString(
      ganttElement);

    return servicePlanStatementXMLString;
    // END, CR00161962
  }

  // _________________________________________________________________________

  /**
   * Processes planned groups for planned subgoal(formats XML string and
   * calculates cost).
   *
   * @param processingDetailsStruct Structure containing data needed to control
   * recursion and return its results
   * @param parentElement Element which contents will be formatted
   * in current iteration
   * @param servicePlanStatementDetailsList Details needed to format service
   * plan statement(list from database)
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#processPlannedGroups1()}
   */
  @Deprecated
  // BEGIN, CR00198672, VK
  protected void processPlannedGroups(
    ProcessingDetailsStruct processingDetailsStruct,
    Element parentElement,
    ServicePlanStatementDetailsList servicePlanStatementDetailsList)
    throws AppException, InformationalException {
    // END, CR00198672
    // do not start processing if the index for some reasons goes out of range
    // of current list
    if (processingDetailsStruct.indexOfElement
      < servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.size()) {
      boolean parentGroupFound = false;

      ServicePlanStatementDetails servicePlanStatementDetails = new ServicePlanStatementDetails();

      // search for parent group of planned group
      // if this is root planned group, its parent group ID will be equal to 0
      while (!parentGroupFound
        && (processingDetailsStruct.indexOfElement
          < servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.size())) {
        servicePlanStatementDetails = servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.item(
          processingDetailsStruct.indexOfElement);

        parentGroupFound = (servicePlanStatementDetails.parentGroupID
          == processingDetailsStruct.parentGroupID);

        if (!parentGroupFound) {
          processingDetailsStruct.indexOfElement++;
        }
      }

      // if parent group was found, process planned subgoals and planned items
      // what belong to it.
      if (parentGroupFound) {
        long planGroupID = servicePlanStatementDetails.plannedGroupID;

        Element planGroupElement = formatPlannedGroupXMLElement(
          servicePlanStatementDetails);

        Money planGroupEstimatedCost = new Money(0);
        Money planGroupActualCost = new Money(0);

        ProcessingDetailsStruct internalProcessingDetailsStruct = new ProcessingDetailsStruct();

        internalProcessingDetailsStruct.assign(processingDetailsStruct);
        internalProcessingDetailsStruct.estimatedCost = planGroupEstimatedCost;
        internalProcessingDetailsStruct.actualCost = planGroupActualCost;

        processSubGoalsAndActions(internalProcessingDetailsStruct,
          planGroupElement, servicePlanStatementDetailsList);

        // set cost of current planned group(it is derived from cost of
        // subgoals)
        planGroupElement.setAttribute(kEstimatedCost,
          internalProcessingDetailsStruct.estimatedCost.toString());

        planGroupElement.setAttribute(kActualCost,
          internalProcessingDetailsStruct.actualCost.toString());

        // increase total cost of planned groups - this will be added to
        // planned goal cost
        processingDetailsStruct.estimatedCost = new Money(
          processingDetailsStruct.estimatedCost.getValue()
            + internalProcessingDetailsStruct.estimatedCost.getValue());

        processingDetailsStruct.actualCost = new Money(
          processingDetailsStruct.actualCost.getValue()
            + internalProcessingDetailsStruct.actualCost.getValue());

        // if this is root group and parent Id = 0, the parent is goal itself
        parentElement.addContent(planGroupElement);

        // maybe this plan group is a child of another plan group
        processingDetailsStruct.parentGroupID = planGroupID;

        // go to the beginning of the remaining list
        processingDetailsStruct.indexOfElement = 0;

        // start searching for parent group again and process its planned
        // subgoal and planned items
        processPlannedGroups(processingDetailsStruct, planGroupElement,
          servicePlanStatementDetailsList);

        // it is possible the parent element has more than one child - check
        // for more branches
        processingDetailsStruct.parentGroupID = Long.parseLong(
          parentElement.getAttributeValue(kID));

        // start from beginning of the remaining list
        processingDetailsStruct.indexOfElement = 0;

        processPlannedGroups(processingDetailsStruct, parentElement,
          servicePlanStatementDetailsList);

        if (planGroupElement != null) {
          // add to the cost of parent plan group the cost of the current
          // child plan group
          Money parentEstimatedCost = new Money(
            parentElement.getAttributeValue(kEstimatedCost));
          Money parentActualCost = new Money(
            parentElement.getAttributeValue(kActualCost));

          Money currentChildEstimatedCost = new Money(
            planGroupElement.getAttributeValue(kEstimatedCost));
          Money childActualCost = new Money(
            planGroupElement.getAttributeValue(kActualCost));

          parentElement.setAttribute(kEstimatedCost,
            (new Money(parentEstimatedCost.getValue() + currentChildEstimatedCost.getValue())).toString());

          parentElement.setAttribute(kActualCost,
            (new Money(parentActualCost.getValue() + childActualCost.getValue())).toString());
        }
      }
    }
  }

  // _________________________________________________________________________

  /**
   * Processed planned sub goals and planned items, what belongs to
   * planned group or directly to goal
   *
   * @param processingDetailsStruct Structure containing data needed to control
   * processing and return its results
   * @param parentElement Element which contents will be formatted(planned goal
   * or planned group)
   * @param servicePlanStatementDetailsList Details needed to format service
   * plan statement(list from database)
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#processSubGoalsAndActions1()}
   */
  @Deprecated
  public void processSubGoalsAndActions(
    ProcessingDetailsStruct processingDetailsStruct,
    Element parentElement,
    ServicePlanStatementDetailsList servicePlanStatementDetailsList)
    throws AppException, InformationalException {

    ServicePlanStatementDetails servicePlanStatementDetails = new ServicePlanStatementDetails();

    servicePlanStatementDetails = servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.item(
      processingDetailsStruct.indexOfElement);

    ServicePlanStatementDetails newServicePlanStatementDetails = new ServicePlanStatementDetails();

    newServicePlanStatementDetails.assign(servicePlanStatementDetails);

    int numberOfRecords = servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.size();

    int initialIndex = processingDetailsStruct.indexOfElement;

    long planGroupID = servicePlanStatementDetails.plannedGroupID;
    long planSubGoalID = servicePlanStatementDetails.plannedSubGoalID;

    // if goal has plan group, check if the record in the list has subgoal and
    // if this subgoal belongs exactly to the group which currently is processed
    // (but not to its parent or child)
    boolean cycleEntered = false;

    if (servicePlanStatementDetails.plannedSubGoalID != 0) {
      HideInformationIndicatorStruct hideInformationIndicatorStruct = new HideInformationIndicatorStruct();

      hideInformationIndicatorStruct.hideInformation = false;

      UserSensitivityCodeStruct sensitivityCode = new UserSensitivityCodeStruct();

      sensitivityCode.userSensitivityCode = processingDetailsStruct.userSensitivityCode;

      // format planned subgoal element
      Element subGoalElement = formatPlannedSubGoalXMLElement(
        servicePlanStatementDetails, sensitivityCode,
        hideInformationIndicatorStruct);

      Money plannedSubGoalEstimatedCost = new Money(0);
      Money plannedSubGoalActualCost = new Money(0);

      // process subgoals and planned items just for the group which was
      // passed as parameter
      while ((processingDetailsStruct.indexOfElement < numberOfRecords)
        && (servicePlanStatementDetails.plannedGroupID == planGroupID)) {
        cycleEntered = true;

        // subGoal has planned items ?
        if (servicePlanStatementDetails.plannedItemID != 0) {
          // format planned item element
          Element planItemElement = formatPlannedActionXMLElement(
            servicePlanStatementDetails, sensitivityCode);

          // calculate planned subgoal cost(it is derived from planned
          // items costs)
          plannedSubGoalEstimatedCost = new Money(
            servicePlanStatementDetails.plannedItemEstimatedCost.getValue()
              + plannedSubGoalEstimatedCost.getValue());

          plannedSubGoalActualCost = new Money(
            servicePlanStatementDetails.plannedItemActualCost.getValue()
              + plannedSubGoalActualCost.getValue());

          subGoalElement.setAttribute(kEstimatedCost,
            plannedSubGoalEstimatedCost.toString());
          subGoalElement.setAttribute(kActualCost,
            plannedSubGoalActualCost.toString());

          // add planned item element to planned subgoal
          subGoalElement.addContent(planItemElement);
        }

        // try to go to the next element
        if (++processingDetailsStruct.indexOfElement < numberOfRecords) {
          // change value of details
          newServicePlanStatementDetails = servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.item(
            processingDetailsStruct.indexOfElement);

          planSubGoalID = newServicePlanStatementDetails.plannedSubGoalID;
        }

        // if we will start process new subgoal information,
        // plan group still should be the same as was passed in parameter
        if ((planSubGoalID != servicePlanStatementDetails.plannedSubGoalID)
          && (newServicePlanStatementDetails.plannedGroupID == planGroupID)) {
          // add previous subgoal element to planned goal or planned group
          parentElement.addContent(subGoalElement);

          // format new planned subgoal element
          subGoalElement = formatPlannedSubGoalXMLElement(
            newServicePlanStatementDetails, sensitivityCode,
            hideInformationIndicatorStruct);

          // add planned subGoal cost to goal cost or plan group cost
          // depending what is passed here
          processingDetailsStruct.estimatedCost = new Money(
            processingDetailsStruct.estimatedCost.getValue()
              + plannedSubGoalEstimatedCost.getValue());
          processingDetailsStruct.actualCost = new Money(
            processingDetailsStruct.actualCost.getValue()
              + plannedSubGoalActualCost.getValue());

          // we will start calculation of another planned sub goal costs from 0
          plannedSubGoalEstimatedCost = new Money(0);
          plannedSubGoalActualCost = new Money(0);
        }

        // we will process next record
        servicePlanStatementDetails.assign(newServicePlanStatementDetails);
      }

      // add the last processed subgoal to parent: goal or plan group
      parentElement.addContent(subGoalElement);

      // recalculate final cost of this group of planned subgoals
      processingDetailsStruct.estimatedCost = new Money(
        processingDetailsStruct.estimatedCost.getValue()
          + plannedSubGoalEstimatedCost.getValue());
      processingDetailsStruct.actualCost = new Money(
        processingDetailsStruct.actualCost.getValue()
          + plannedSubGoalActualCost.getValue());
    }

    // we need to decide how many elements should be deleted from list
    int upperIndex = processingDetailsStruct.indexOfElement;

    if (cycleEntered
      && (servicePlanStatementDetails.plannedGroupID != planGroupID)
        || (upperIndex >= numberOfRecords)) {
      upperIndex--;
    }

    // remove processed items from list
    for (int i = initialIndex; i <= upperIndex; i++) {
      servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.remove(
        initialIndex);
    }
  }

  // _________________________________________________________________________

  // _________________________________________________________________________
  /**
   * Reads sensitivity code of the current user
   *
   * @return Sensitivity code of the current user
   */
  @Override
  protected UserSensitivityCodeStruct readCurrentUserSensitivity()
    throws AppException, InformationalException {

    UserSensitivityCodeStruct userSensitivityCodeStruct = new UserSensitivityCodeStruct();

    Users userObj = curam.core.fact.UsersFactory.newInstance();

    SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    UsersKey usersKey = new UsersKey();

    // get the current user's details
    SystemUserDtls systemUserDtls = systemUserObj.getUserDetails();

    usersKey.userName = systemUserDtls.userName;

    userSensitivityCodeStruct.userSensitivityCode = userObj.readSensitivityCode(usersKey).sensitivity;

    return userSensitivityCodeStruct;
  }

  // BEGIN, CR00246182, TV
  // _________________________________________________________________________
  /**
   * Formats XML element of the planned goal
   *
   * @param Service
   * Plan Statement Details
   *
   * @return XML element containing goal details
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#formatPlannedGoalXMLElement1()}
   */
  @Deprecated
  // BEGIN, CR00198672, VK
  protected Element formatPlannedGoalXMLElement(
    ServicePlanStatementGoalDetails servicePlanStatementGoalDetails)
    throws AppException, InformationalException {
    // END, CR00198672
    Element goalElement = new Element(kPlannedGoal);

    Money initialGoalCost = new Money(0.0);

    // plannedSubGoal structs
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.PlannedGoalKey plannedGoalKey = new curam.serviceplans.sl.entity.struct.PlannedGoalKey();
    curam.serviceplans.sl.entity.struct.PlannedSubGoalStatusList plannedSubGoalStatusList = new curam.serviceplans.sl.entity.struct.PlannedSubGoalStatusList();

    curam.serviceplans.sl.entity.struct.PlannedSubGoalStatus plannedSubGoalStatus = new curam.serviceplans.sl.entity.struct.PlannedSubGoalStatus();

    // populate key
    plannedGoalKey.plannedGoalID = servicePlanStatementGoalDetails.servicePlanStatementGoalDetails.plannedGoalID;

    // read back all plannedSubGoal statuses
    plannedSubGoalStatusList = plannedSubGoalObj.searchPlannedSubGoalStatusByPlannedGoalID(
      plannedGoalKey);

    // we do not use the status from the method key as this is of type 
    // CASESTATUS
    // we need a status of type PLANNEDSUBGOALSTATUS
    // default status to be 'not started'.
    plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.NOTSTARTED;

    // check all statuses for 'completed'.
    for (int i = 0; i < plannedSubGoalStatusList.dtls.size(); i++) {

      if ((!plannedSubGoalStatusList.dtls.item(i).status.equals(
        PLANNEDSUBGOALSTATUS.INPROGRESS))
          && (plannedSubGoalStatusList.dtls.item(i).status.equals(
            PLANNEDSUBGOALSTATUS.COMPLETED))) {

        plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.COMPLETED;

      }
    }

    // if statuses are not 'completed', check for 'in progress'.
    for (int i = 0; i < plannedSubGoalStatusList.dtls.size(); i++) {

      if (plannedSubGoalStatusList.dtls.item(i).status.equals(
        PLANNEDSUBGOALSTATUS.INPROGRESS)) {

        plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.INPROGRESS;

      }
    }
    goalElement.setAttribute(kType, kPlannedGoal).setAttribute(kID, String.valueOf(servicePlanStatementGoalDetails.servicePlanStatementGoalDetails.plannedGoalID)).setAttribute(kName, servicePlanStatementGoalDetails.servicePlanStatementGoalDetails.goalName).setAttribute(kEstimatedCost, String.valueOf(initialGoalCost)).setAttribute(kActualCost, String.valueOf(initialGoalCost)).setAttribute(
      kStatus, plannedSubGoalStatus.status);

    return goalElement;
  }

  // END, CR00246182

  // _________________________________________________________________________

  /**
   * Formats XML element of the planned group
   *
   * @param Service
   * Plan Statement Details
   * @return XML element containing goal details
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#formatPlannedGroupXMLElement1()}
   */
  @Deprecated
  // BEGIN, CR00198672, VK
  protected Element formatPlannedGroupXMLElement(
    ServicePlanStatementDetails servicePlanStatementDetails)
    throws AppException, InformationalException {
    // END, CR00198672
    // BEGIN, CR00161962, LJ
    Element planGroupElement = new Element(kPlannedGroup);

    Money initialPlanGroupCost = new Money(0.0);

    // Manipulation variables
    curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();

    PlannedGroupKey plannedGroupKey = new PlannedGroupKey();

    ReadCaseIDByPlannedGroupIDDetails readCaseIDByPlannedGroupIDDetails;

    // assign value
    plannedGroupKey.key.plannedGroupID = servicePlanStatementDetails.plannedGroupID;

    // read caseID
    readCaseIDByPlannedGroupIDDetails = plannedGroupObj.readCaseIDByPlannedGroupID(
      plannedGroupKey.key);

    planGroupElement.setAttribute(kType, kPlannedGroup);
    planGroupElement.setAttribute(kID,
      String.valueOf(servicePlanStatementDetails.plannedGroupID));
    planGroupElement.setAttribute(kCaseID,
      String.valueOf(readCaseIDByPlannedGroupIDDetails.caseID));
    planGroupElement.setAttribute(kName,
      servicePlanStatementDetails.plannedGroupName);
    planGroupElement.setAttribute(kEstimatedCost,
      String.valueOf(initialPlanGroupCost));
    planGroupElement.setAttribute(kActualCost,
      String.valueOf(initialPlanGroupCost));
    // END, CR00161962
    return planGroupElement;
  }

  // _________________________________________________________________________

  /**
   * Formats XML element of the planned subGoal
   *
   * @param servicePlanStatementDetails
   * Service Plan Statement Details
   * @param userSensitivityCodeStruct
   * User sensitivity code
   * @param hideInformationIndicatorStruct
   * Indicator to show if we need to hide information of this planned
   * subgoal(probably needs to be removed)
   *
   * @return XML element containing subGoal details
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#formatPlannedSubGoalXMLElement1()}
   */
  @Deprecated
  // BEGIN, CR00198672, VK
  protected Element formatPlannedSubGoalXMLElement(
    ServicePlanStatementDetails servicePlanStatementDetails,
    UserSensitivityCodeStruct userSensitivityCodeStruct,
    HideInformationIndicatorStruct hideInformationIndicatorStruct)
    throws AppException, InformationalException {
    // END, CR00198672
    Element subGoalElement = new Element(kPlannedSubGoal);
    // BEGIN, CR00161962, LJ
    // need the Service Plan Delivery Case Id, use the subgoal id to retrieve
    curam.serviceplans.sl.entity.intf.PlannedSubGoal psgObj = PlannedSubGoalFactory.newInstance();
    PlannedSubGoalKey psgKey = new PlannedSubGoalKey();

    psgKey.plannedSubGoalID = servicePlanStatementDetails.plannedSubGoalID;
    ReadCaseIDByPlannedSubGoalIDDetails caseIdDtls = psgObj.readCaseIDByPlannedSubGoalID(
      psgKey);

    Money initialSubCost = new Money(0.0);

    subGoalElement.setAttribute(kType, kPlannedSubGoal);
    subGoalElement.setAttribute(kID,
      String.valueOf(servicePlanStatementDetails.plannedSubGoalID));
    subGoalElement.setAttribute(kCaseID, String.valueOf(caseIdDtls.caseID));
    subGoalElement.setAttribute(kName, servicePlanStatementDetails.subGoalName);
    subGoalElement.setAttribute(kEstimatedCost, String.valueOf(initialSubCost));
    subGoalElement.setAttribute(kActualCost, String.valueOf(initialSubCost));
    subGoalElement.setAttribute(kStatus,
      servicePlanStatementDetails.plannedSubGoalStatus);
    // END, CR00161962
    return subGoalElement;
  }

  // _________________________________________________________________________

  /**
   * Formats Plan Item XML Element
   *
   * @param hideInformationIndicatorStruct
   * Indicator to show if we need to hide information of this planned
   * item(probably needs to be removed)
   *
   * @param servicePlanStatementDetails
   * Service Plan Statement Details
   * @param userSensitivityCodeStruct
   * User sensitivity code
   * @return Identifier of newly created participation record.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#formatPlannedActionXMLElement1()}
   */
  @Deprecated
  // BEGIN, CR00198672, VK
  protected Element formatPlannedActionXMLElement(
    ServicePlanStatementDetails servicePlanStatementDetails,
    UserSensitivityCodeStruct userSensitivityCodeStruct) throws AppException,
      InformationalException {
    // END, CR00198672
    // BEGIN, CR00161962, LJ
    Element planItemElement = new Element(kPlanItem);

    planItemElement.setAttribute(kType, kPlanItem);
    planItemElement.setAttribute(kID,
      String.valueOf(servicePlanStatementDetails.plannedItemID));
    planItemElement.setAttribute(kName,
      servicePlanStatementDetails.plannedItemName);
    planItemElement.setAttribute(kEstimatedCost,
      String.valueOf(servicePlanStatementDetails.plannedItemEstimatedCost));
    planItemElement.setAttribute(kActualCost,
      String.valueOf(servicePlanStatementDetails.plannedItemActualCost));
    planItemElement.setAttribute(kStatus,
      servicePlanStatementDetails.plannedItemStatus);
    // END, CR00161962
    return planItemElement;

  }

  // BEGIN, CR00161962, LJ
  // _________________________________________________________________________

  /**
   * Creates a group element to add to the xml string
   *
   * @param servicePlanStatementGroupDetails
   * the group record.
   *
   * @return Element Group element to be displayed on the Costing Gantt chart.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#createGroupXML1()}
   */
  @Deprecated
  // BEGIN, CR00198672, VK
  protected Element createGroupXML(
    ServicePlanStatementGroupDetails servicePlanStatementGroupDetails)
    throws AppException, InformationalException {
    // END, CR00198672
    Element groupElement = new Element(kGroup);

    groupElement.setAttribute(kType, kGroupType);

    groupElement.setAttribute(kID,
      String.valueOf(servicePlanStatementGroupDetails.groupDeliveryID));
    groupElement.setAttribute(kName, servicePlanStatementGroupDetails.groupName);

    groupElement.setAttribute(kEstimatedCost,
      servicePlanStatementGroupDetails.estimatedCost.toString());
    groupElement.setAttribute(kActualCost,
      servicePlanStatementGroupDetails.actualCost.toString());

    // Create service plan elements
    int numberOfServicePlans = servicePlanStatementGroupDetails.statementDeliveryDetailsList.size();

    for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {
      ServicePlanStatementDeliveryDetails servicePlanStatementDeliveryDetails = servicePlanStatementGroupDetails.statementDeliveryDetailsList.item(
        servicePlanCount);

      Element goalElement = createGoalXML(servicePlanStatementDeliveryDetails);

      // Add goal element to group element
      groupElement.addContent(goalElement);
    }

    return groupElement;
  }

  // END, CR00161962
  // BEGIN, CR00161962, LJ
  // _________________________________________________________________________

  /**
   * Creates a goal element to add to the xml string
   *
   * @param servicePlanStatementDeliveryDetails
   * the service plan record.
   *
   * @return Element Goal element to be displayed on the Costing Gantt chart.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   * @deprecated Since Curam6.0, replaced with
   * {@link ServicePlanStatement#createGoalXML1()}
   */
  @Deprecated
  // BEGIN, CR00198672, VK
  protected Element createGoalXML(
    ServicePlanStatementDeliveryDetails servicePlanStatementDeliveryDetails)
    throws AppException, InformationalException {
    // END, CR00198672

    Element goalElement = formatPlannedGoalXMLElement(
      servicePlanStatementDeliveryDetails.statementGoalDetails);

    Money goalActualCost = new Money(0.0);
    Money goalEstimatedCost = new Money(0.0);

    // set initial cost of the goal
    goalElement.setAttribute(kEstimatedCost, goalActualCost.toString());
    goalElement.setAttribute(kActualCost, goalActualCost.toString());

    ProcessingDetailsStruct processingDetailsStruct = new ProcessingDetailsStruct();

    if (servicePlanStatementDeliveryDetails.statementDetailsList.servicePlanStatementDetailsList.dtls.size()
      > 0) {
      // if at least there exist a goal
      // read sensitivity of current user
      UserSensitivityCodeStruct userSensitivityCodeStruct = readCurrentUserSensitivity();

      ServicePlanStatementDetails servicePlanStatementDetails = new ServicePlanStatementDetails();

      servicePlanStatementDetails = servicePlanStatementDeliveryDetails.statementDetailsList.servicePlanStatementDetailsList.dtls.item(
        0);

      while (servicePlanStatementDeliveryDetails.statementDetailsList.servicePlanStatementDetailsList.dtls.size()
        > 0) {
        // as we remove all processed items of list, we always will start from
        // the beginning of the list
        servicePlanStatementDetails = servicePlanStatementDeliveryDetails.statementDetailsList.servicePlanStatementDetailsList.dtls.item(
          0);

        if ((servicePlanStatementDetails.plannedGroupID == 0)
          && (servicePlanStatementDetails.plannedSubGoalID != 0)) {
          // this item does not have planGroup, but has subgoals
          // we reached a group, where planGroup is empty
          processingDetailsStruct.estimatedCost = goalEstimatedCost;
          processingDetailsStruct.actualCost = goalActualCost;
          processingDetailsStruct.indexOfElement = 0;
          processingDetailsStruct.parentGroupID = 0;
          processingDetailsStruct.userSensitivityCode = userSensitivityCodeStruct.userSensitivityCode;

          processSubGoalsAndActions(processingDetailsStruct, goalElement,
            servicePlanStatementDeliveryDetails.statementDetailsList);
        } else {
          // part of list with planned groups
          processingDetailsStruct.estimatedCost = goalEstimatedCost;
          processingDetailsStruct.actualCost = goalActualCost;
          processingDetailsStruct.indexOfElement = 0;
          processingDetailsStruct.parentGroupID = 0;
          processingDetailsStruct.userSensitivityCode = userSensitivityCodeStruct.userSensitivityCode;

          processPlannedGroups(processingDetailsStruct, goalElement,
            servicePlanStatementDeliveryDetails.statementDetailsList);
        }

        goalElement.setAttribute(kEstimatedCost,
          processingDetailsStruct.estimatedCost.toString());
        goalElement.setAttribute(kActualCost,
          processingDetailsStruct.actualCost.toString());

        goalEstimatedCost = processingDetailsStruct.estimatedCost;
        goalActualCost = processingDetailsStruct.actualCost;
      }
    }

    return goalElement;
  }

  // END, CR00161962
  
  // BEGIN, CR00246182, TV  
  // BEGIN, CR00161962, LJ
  // __________________________________________________________________________

  /**
   * Overloaded method which reads the details required to create the XML string
   * for the Costing Gantt.
   *
   * @param servicePlanStatementDeliveryKey
   * ServicePlanStatementDeliveryKey
   *
   * @return ServicePlanStatementDeliveryDetails
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00198672, VK
  protected ServicePlanStatementDeliveryDetails1 readServicePlanStatementDetails
    (ServicePlanStatementDeliveryKey servicePlanStatementDeliveryKey,
    boolean throwException) throws AppException, InformationalException {
    // END, CR00198672

    /*
     * This method has been added to allow a boolean flag to be passed to
     * determine if an exception should be raised as within the context of a
     * service plan group delivery the exception should not be thrown to prevent
     * the chart being displayed.
     *
     * The method has been written in this manner as the original exception
     * thrown from the read method cannot be moved from it's location as
     * dependencies may exist on that code.
     */
    final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();

    servicePlanDeliveryKey.key.caseID = servicePlanStatementDeliveryKey.caseID;

    // security check
    final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliverySLObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

    final ServicePlanSecurity servicePlanSecurityObj = new ServicePlanSecurity();

    final ServicePlanOperationSecurityKey servicePlanOperationSecurityKey = new ServicePlanOperationSecurityKey();

    // get service plan ID
    final curam.serviceplans.sl.struct.ServicePlanKey servicePlanKey = servicePlanDeliverySLObj.readServicePlanID(
      servicePlanDeliveryKey);

    final CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    final curam.core.struct.CaseHeaderKey caseHeaderKey = new curam.core.struct.CaseHeaderKey();

    caseHeaderKey.caseID = servicePlanDeliveryKey.key.caseID;

    // get plan participant ID
    servicePlanOperationSecurityKey.servicePlanParticipantSecurityKey.concernRoleID = caseHeaderObj.readParticipantRoleID(caseHeaderKey).concernRoleID;

    servicePlanOperationSecurityKey.servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    servicePlanOperationSecurityKey.servicePlanSecurityKey.servicePlanID = servicePlanKey.key.servicePlanID;

    try {
      servicePlanSecurityObj.servicePlanOperationSecurityCheck(
        servicePlanOperationSecurityKey);
    } catch (final AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        // operation SID security check failed
        throw new AppException(
          BPOSERVICEPLANSTATEMENT.ERR_SERVICE_PLAN_STATEMENT_VIEW_OPERATION_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PARTICIPANT_SENSITIVITY_CHECK_FAILED)) {
        // user-participant item sensitivity check failed
        throw new AppException(
          BPOSERVICEPLANSTATEMENT.ERR_CLIENTPARTICIPATION_XRV_PLANPARTICIPANT_USER_SENSITIVITY_LEVEL);
      } else {
        throw e;
      }
    }

    final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();

    final curam.serviceplans.sl.struct.ServicePlanStatementDetailsList1 servicePlanStatementDetailsListWithPlannedGroups = new curam.serviceplans.sl.struct.ServicePlanStatementDetailsList1();

    final ServicePlanStatementDetailsList1 servicePlanStatementDetailsListWithoutPlannedGroups = new ServicePlanStatementDetailsList1();

    final ServicePlanStatementDetailsList1 servicePlanStatementDetailsList = new ServicePlanStatementDetailsList1();

    final ServicePlanStatementGoalDetails1 servicePlanStatementGoalDetails = new ServicePlanStatementGoalDetails1();

    // boolean flag to show if exception could have occurred
    boolean exceptionOccurred = false;

    // read planned goal details
    try {
      servicePlanStatementGoalDetails.servicePlanStatementGoalDetails = servicePlanDeliveryObj.readServicePlanStatementGoalDetails1(
        servicePlanDeliveryKey.key);
    } catch (final curam.util.exception.RecordNotFoundException rnfe) {
      if (throwException == true) {
        throw new AppException(
          BPOSERVICEPLANSTATEMENT.ERR_SERVICE_PLAN_STATEMENT_XRV_GOAL_NOT_DEFINED);

      } else {
        exceptionOccurred = true;
      }
    }

    // Create return object
    final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = new ServicePlanStatementDeliveryDetails1();

    // Populate details if exception has not occurred
    if (exceptionOccurred == false) {

      servicePlanStatementDetailsListWithPlannedGroups.servicePlanStatementDetailsList = servicePlanDeliveryObj.searchServicePlanStatementDetailsByCaseID1(
        servicePlanDeliveryKey.key);

      servicePlanStatementDetailsListWithoutPlannedGroups.servicePlanStatementDetailsList = servicePlanDeliveryObj.searchPlannedSubGoalsForServicePlanStatement1(
        servicePlanDeliveryKey.key);

      // ensure capacity of final list
      servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.ensureCapacity(
        servicePlanStatementDetailsListWithPlannedGroups.servicePlanStatementDetailsList.dtls.size()
          + servicePlanStatementDetailsListWithoutPlannedGroups.servicePlanStatementDetailsList.dtls.size());

      // assign the list with planned groups
      servicePlanStatementDetailsList.assign(
        servicePlanStatementDetailsListWithPlannedGroups);

      final int servicePlanStatementDetailsListSize = servicePlanStatementDetailsListWithoutPlannedGroups.servicePlanStatementDetailsList.dtls.size();

      // add the list without planned groups
      for (int i = 0; i < servicePlanStatementDetailsListSize; i++) {
        servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.addRef(
          servicePlanStatementDetailsListWithoutPlannedGroups.servicePlanStatementDetailsList.dtls.item(
            i));
      }

      // Loop around each service plan and populate actual and estimated costs
      double estimatedCost = 0;
      double actualCost = 0;

      final int numberOfPlanItems = servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.size();

      for (int planItemCount = 0; planItemCount < numberOfPlanItems; planItemCount++) {

        final curam.serviceplans.sl.entity.struct.ServicePlanStatementDetails1 servicePlanStatementDetails = servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.item(
          planItemCount);

        estimatedCost += servicePlanStatementDetails.plannedItemEstimatedCost.getValue();
        actualCost += servicePlanStatementDetails.plannedItemActualCost.getValue();
      }

      // Assign totals to goal details
      servicePlanStatementGoalDetails.servicePlanStatementGoalDetails.estimatedCost = new Money(
        estimatedCost);
      servicePlanStatementGoalDetails.servicePlanStatementGoalDetails.actualCost = new Money(
        actualCost);

      servicePlanStatementDeliveryDetails.statementDetailsList = servicePlanStatementDetailsList;
      servicePlanStatementDeliveryDetails.statementGoalDetails = servicePlanStatementGoalDetails;

      // BEGIN, CR00182804, ELG
    } else {

      // servicePlanStatementDeliveryDetails remains empty
      // Add informational message
      curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

      LocalisableString infoMessage = new LocalisableString(
        curam.message.BPOSERVICEPLANSTATEMENT.ERR_SERVICE_PLAN_STATEMENT_XRV_GOAL_NOT_DEFINED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }
    // END, CR00182804

    return servicePlanStatementDeliveryDetails;
  }

  // END, CR00161962
  // END, CR00246182

  /**
   * Creates the XML string for the Integrated Service Plan costing Gantt.
   *
   * @param servicePlanStatementIntegratedDetails
   * Details required to create the costing Gantt XML String.
   *
   * @return The created XML String to be displayed on the costing Gantt
   * diagram.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00208728, LP
  // BEGIN, CR00229255 MN
  public SPStatementXMLString createServicePlanStatementIntegratedXmlDetails1(
    final ServicePlanStatementIntegratedDetails1
    servicePlanStatementIntegratedDetails)
    throws AppException, InformationalException {
    // END, CR00229225
    // Create the integrated service plan element
    final Element integratedElement = new Element(kIntegrated);

    integratedElement.setAttribute(kType, kIntegratedType);

    integratedElement.setAttribute(kID,
      String.valueOf(servicePlanStatementIntegratedDetails.integratedCaseID));
    // BEGIN,CR00381184, CC
    integratedElement.setAttribute(kName,
      BPOTRACKINGGANTT.INF_TRACKING_GANTT_STATEMENT_INTEGRATED_SERVICE_PLAN.getMessageText(
      TransactionInfo.getProgramLocale()));
    // END, CR00381184
    integratedElement.setAttribute(kEstimatedCost,
      servicePlanStatementIntegratedDetails.estimatedCost.toString());
    integratedElement.setAttribute(kActualCost,
      servicePlanStatementIntegratedDetails.actualCost.toString());

    // Add the service plan group deliveries
    final int numberOfGroups = servicePlanStatementIntegratedDetails.statementGroupDetailsList.size();

    for (int groupCount = 0; groupCount < numberOfGroups; groupCount++) {
      final ServicePlanStatementGroupDetails1 servicePlanStatementGroupDetails = servicePlanStatementIntegratedDetails.statementGroupDetailsList.item(
        groupCount);

      // Create group element
      final Element groupElement = createGroupXML1(
        servicePlanStatementGroupDetails);

      integratedElement.addContent(groupElement);
    }

    // Add the service plan deliveries
    final int numberOfServicePlans = servicePlanStatementIntegratedDetails.statementDeliveryDetailsList.size();

    for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {

      final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = servicePlanStatementIntegratedDetails.statementDeliveryDetailsList.item(
        servicePlanCount);

      // Create goal element
      final Element goalElement = createGoalXML1(
        servicePlanStatementDeliveryDetails);

      // Add goal element to the ISP element
      integratedElement.addContent(goalElement);
    }

    // Create root node
    final Element ganttElement = new Element(kGantt);

    ganttElement.setAttribute(kView, kOpen);

    ganttElement.addContent(integratedElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    // BEGIN, CR00229255 MN
    final SPStatementXMLString servicePlanStatementXMLString = new SPStatementXMLString();

    // END, CR00229225

    servicePlanStatementXMLString.newStatementDetails = outputter.outputString(
      ganttElement);

    return servicePlanStatementXMLString;
  }

  // END, CR00208728

  /**
   * Creates a goal element to add to the xml string.
   *
   * @param servicePlanStatementDeliveryDetails
   * the service plan record.
   *
   * @return Element Goal element to be displayed on the Costing Gantt chart.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00208728, LP
  protected Element createGoalXML1(
    final ServicePlanStatementDeliveryDetails1
    servicePlanStatementDeliveryDetails)
    throws AppException, InformationalException {

    final Element goalElement = formatPlannedGoalXMLElement1(
      servicePlanStatementDeliveryDetails.statementGoalDetails);

    Money goalActualCost = new Money(0.0);
    Money goalEstimatedCost = new Money(0.0);

    // set initial cost of the goal
    goalElement.setAttribute(kEstimatedCost, goalActualCost.toString());
    goalElement.setAttribute(kActualCost, goalActualCost.toString());

    final ProcessingDetailsStruct processingDetailsStruct = new ProcessingDetailsStruct();

    if (servicePlanStatementDeliveryDetails.statementDetailsList.servicePlanStatementDetailsList.dtls.size()
      > 0) {
      // if at least there exist a goal
      // read sensitivity of current user
      final UserSensitivityCodeStruct userSensitivityCodeStruct = readCurrentUserSensitivity();

      ServicePlanStatementDetails1 servicePlanStatementDetails = new ServicePlanStatementDetails1();

      servicePlanStatementDetails = servicePlanStatementDeliveryDetails.statementDetailsList.servicePlanStatementDetailsList.dtls.item(
        0);

      while (servicePlanStatementDeliveryDetails.statementDetailsList.servicePlanStatementDetailsList.dtls.size()
        > 0) {
        // as we remove all processed items of list, we always will start from
        // the beginning of the list
        servicePlanStatementDetails = servicePlanStatementDeliveryDetails.statementDetailsList.servicePlanStatementDetailsList.dtls.item(
          0);

        if ((servicePlanStatementDetails.plannedGroupID == 0)
          && (servicePlanStatementDetails.plannedSubGoalID != 0)) {
          // this item does not have planGroup, but has subgoals
          // we reached a group, where planGroup is empty
          processingDetailsStruct.estimatedCost = goalEstimatedCost;
          processingDetailsStruct.actualCost = goalActualCost;
          processingDetailsStruct.indexOfElement = 0;
          processingDetailsStruct.parentGroupID = 0;
          processingDetailsStruct.userSensitivityCode = userSensitivityCodeStruct.userSensitivityCode;

          processSubGoalsAndActions1(processingDetailsStruct, goalElement,
            servicePlanStatementDeliveryDetails.statementDetailsList);
        } else {
          // part of list with planned groups
          processingDetailsStruct.estimatedCost = goalEstimatedCost;
          processingDetailsStruct.actualCost = goalActualCost;
          processingDetailsStruct.indexOfElement = 0;
          processingDetailsStruct.parentGroupID = 0;
          processingDetailsStruct.userSensitivityCode = userSensitivityCodeStruct.userSensitivityCode;

          processPlannedGroups1(processingDetailsStruct, goalElement,
            servicePlanStatementDeliveryDetails.statementDetailsList);
        }

        goalElement.setAttribute(kEstimatedCost,
          processingDetailsStruct.estimatedCost.toString());
        goalElement.setAttribute(kActualCost,
          processingDetailsStruct.actualCost.toString());

        goalEstimatedCost = processingDetailsStruct.estimatedCost;
        goalActualCost = processingDetailsStruct.actualCost;
      }
    }

    return goalElement;
  }

  // END, CR00208728

  /**
   * Processes planned groups for planned subgoal(formats XML string and
   * calculates cost).
   *
   * @param processingDetailsStruct
   * Structure containing data needed to control recursion and return
   * its results
   * @param parentElement
   * Element which contents will be formatted in current iteration
   * @param servicePlanStatementDetailsList
   * Details needed to format service plan statement(list from
   * database)
   */
  // BEGIN, CR00208728, LP
  protected void processPlannedGroups1(
    final ProcessingDetailsStruct processingDetailsStruct,
    final Element parentElement,
    final ServicePlanStatementDetailsList1 servicePlanStatementDetailsList)
    throws AppException, InformationalException {

    // do not start processing if the index for some reasons goes out of range
    // of current list
    if (processingDetailsStruct.indexOfElement
      < servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.size()) {
      boolean parentGroupFound = false;

      ServicePlanStatementDetails1 servicePlanStatementDetails = new ServicePlanStatementDetails1();

      // search for parent group of planned group
      // if this is root planned group, its parent group ID will be equal to 0
      while (!parentGroupFound
        && (processingDetailsStruct.indexOfElement
          < servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.size())) {
        servicePlanStatementDetails = servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.item(
          processingDetailsStruct.indexOfElement);

        parentGroupFound = servicePlanStatementDetails.parentGroupID
          == processingDetailsStruct.parentGroupID;

        if (!parentGroupFound) {
          processingDetailsStruct.indexOfElement++;
        }
      }

      // if parent group was found, process planned subgoals and planned items
      // what belong to it.
      if (parentGroupFound) {
        final long planGroupID = servicePlanStatementDetails.plannedGroupID;

        final Element planGroupElement = formatPlannedGroupXMLElement1(
          servicePlanStatementDetails);

        final Money planGroupEstimatedCost = new Money(0);
        final Money planGroupActualCost = new Money(0);

        final ProcessingDetailsStruct internalProcessingDetailsStruct = new ProcessingDetailsStruct();

        internalProcessingDetailsStruct.assign(processingDetailsStruct);
        internalProcessingDetailsStruct.estimatedCost = planGroupEstimatedCost;
        internalProcessingDetailsStruct.actualCost = planGroupActualCost;

        processSubGoalsAndActions1(internalProcessingDetailsStruct,
          planGroupElement, servicePlanStatementDetailsList);

        // set cost of current planned group(it is derived from cost of
        // subgoals)
        planGroupElement.setAttribute(kEstimatedCost,
          internalProcessingDetailsStruct.estimatedCost.toString());

        planGroupElement.setAttribute(kActualCost,
          internalProcessingDetailsStruct.actualCost.toString());

        // increase total cost of planned groups - this will be added to planned
        // goal cost
        processingDetailsStruct.estimatedCost = new Money(
          processingDetailsStruct.estimatedCost.getValue()
            + internalProcessingDetailsStruct.estimatedCost.getValue());

        processingDetailsStruct.actualCost = new Money(
          processingDetailsStruct.actualCost.getValue()
            + internalProcessingDetailsStruct.actualCost.getValue());

        // if this is root group and parent Id = 0, the parent is goal itself
        parentElement.addContent(planGroupElement);

        // maybe this plan group is a child of another plan group
        processingDetailsStruct.parentGroupID = planGroupID;

        // go to the beginning of the remaining list
        processingDetailsStruct.indexOfElement = 0;

        // start searching for parent group again and process its planned
        // subgoal and planned items
        processPlannedGroups1(processingDetailsStruct, planGroupElement,
          servicePlanStatementDetailsList);

        // it is possible the parent element has more than one child - check for
        // more branches
        processingDetailsStruct.parentGroupID = Long.parseLong(
          parentElement.getAttributeValue(kID));

        // start from beginning of the remaining list
        processingDetailsStruct.indexOfElement = 0;

        processPlannedGroups1(processingDetailsStruct, parentElement,
          servicePlanStatementDetailsList);

        if (planGroupElement != null) {
          // add to the cost of parent plan group the cost of the current child
          // plan group
          final Money parentEstimatedCost = new Money(
            parentElement.getAttributeValue(kEstimatedCost));
          final Money parentActualCost = new Money(
            parentElement.getAttributeValue(kActualCost));

          final Money currentChildEstimatedCost = new Money(
            planGroupElement.getAttributeValue(kEstimatedCost));
          final Money childActualCost = new Money(
            planGroupElement.getAttributeValue(kActualCost));

          parentElement.setAttribute(kEstimatedCost,
            (new Money(parentEstimatedCost.getValue() + currentChildEstimatedCost.getValue())).toString());

          parentElement.setAttribute(kActualCost,
            (new Money(parentActualCost.getValue() + childActualCost.getValue())).toString());
        }
      }
    }
  }

  // END, CR00208728
  /**
   * Formats XML element of the planned group.
   *
   * @param Service
   * Plan Statement Details
   * @return XML element containing goal details
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00208728, LP
  protected Element formatPlannedGroupXMLElement1(
    final ServicePlanStatementDetails1 servicePlanStatementDetails)
    throws AppException, InformationalException {

    final Element planGroupElement = new Element(kPlannedGroup);

    final Money initialPlanGroupCost = new Money(0.0);

    // Manipulation variables
    final curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();

    final PlannedGroupKey plannedGroupKey = new PlannedGroupKey();

    ReadCaseIDByPlannedGroupIDDetails readCaseIDByPlannedGroupIDDetails;

    // assign value
    plannedGroupKey.key.plannedGroupID = servicePlanStatementDetails.plannedGroupID;

    // read caseID
    readCaseIDByPlannedGroupIDDetails = plannedGroupObj.readCaseIDByPlannedGroupID(
      plannedGroupKey.key);

    planGroupElement.setAttribute(kType, kPlannedGroup);
    planGroupElement.setAttribute(kID,
      String.valueOf(servicePlanStatementDetails.plannedGroupID));
    planGroupElement.setAttribute(kCaseID,
      String.valueOf(readCaseIDByPlannedGroupIDDetails.caseID));
    planGroupElement.setAttribute(kName,
      servicePlanStatementDetails.plannedGroupName);
    planGroupElement.setAttribute(kEstimatedCost,
      String.valueOf(initialPlanGroupCost));
    planGroupElement.setAttribute(kActualCost,
      String.valueOf(initialPlanGroupCost));

    return planGroupElement;
  }

  // END, CR00208728

  /**
   * Formats XML element of the planned goal.
   *
   * @param Service
   * Plan Statement Details
   *
   * @return XML element containing goal details
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00208728, LP
  protected Element formatPlannedGoalXMLElement1(
    final ServicePlanStatementGoalDetails1 servicePlanStatementGoalDetails)
    throws AppException, InformationalException {

    final Element goalElement = new Element(kPlannedGoal);

    final Money initialGoalCost = new Money(0.0);

    // plannedSubGoal structs
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    final curam.serviceplans.sl.entity.struct.PlannedGoalKey plannedGoalKey = new curam.serviceplans.sl.entity.struct.PlannedGoalKey();
    curam.serviceplans.sl.entity.struct.PlannedSubGoalStatusList plannedSubGoalStatusList = new curam.serviceplans.sl.entity.struct.PlannedSubGoalStatusList();

    final curam.serviceplans.sl.entity.struct.PlannedSubGoalStatus plannedSubGoalStatus = new curam.serviceplans.sl.entity.struct.PlannedSubGoalStatus();

    // populate key
    plannedGoalKey.plannedGoalID = servicePlanStatementGoalDetails.servicePlanStatementGoalDetails.plannedGoalID;

    // read back all plannedSubGoal statuses
    plannedSubGoalStatusList = plannedSubGoalObj.searchPlannedSubGoalStatusByPlannedGoalID(
      plannedGoalKey);

    // we do not use the status from the method key as this is of type
    // CASESTATUS
    // we need a status of type PLANNEDSUBGOALSTATUS
    // default status to be 'not started'.
    plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.NOTSTARTED;

    // check all statuses for 'completed'.
    for (int i = 0; i < plannedSubGoalStatusList.dtls.size(); i++) {
      if ((!plannedSubGoalStatusList.dtls.item(i).status.equals(
        PLANNEDSUBGOALSTATUS.INPROGRESS))
          && (plannedSubGoalStatusList.dtls.item(i).status.equals(
            PLANNEDSUBGOALSTATUS.COMPLETED))) {

        plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.COMPLETED;

      }
    }

    // if statuses are not 'completed', check for 'in progress'.
    for (int i = 0; i < plannedSubGoalStatusList.dtls.size(); i++) {
      if (plannedSubGoalStatusList.dtls.item(i).status.equals(
        PLANNEDSUBGOALSTATUS.INPROGRESS)) {
        plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.INPROGRESS;

      }
    }
    goalElement.setAttribute(kType, kPlannedGoal);
    goalElement.setAttribute(kID,
      String.valueOf(
      servicePlanStatementGoalDetails.servicePlanStatementGoalDetails.caseID));
    goalElement.setAttribute(kName,
      servicePlanStatementGoalDetails.servicePlanStatementGoalDetails.goalName);
    goalElement.setAttribute(kEstimatedCost, String.valueOf(initialGoalCost));
    goalElement.setAttribute(kActualCost, String.valueOf(initialGoalCost));
    goalElement.setAttribute(kStatus, plannedSubGoalStatus.status);

    return goalElement;
  }

  // END, CR00208728

  /**
   * Processed planned sub goals and planned items, what belongs to planned
   * group or directly to goal.
   *
   * @param processingDetailsStruct
   * Structure containing data needed to control processing and return
   * its results
   * @param parentElement
   * Element which contents will be formatted(planned goal or planned
   * group)
   * @param servicePlanStatementDetailsList
   * Details needed to format service plan statement(list from
   * database)
   */
  // BEGIN, CR00208728, LP
  public void processSubGoalsAndActions1(
    final ProcessingDetailsStruct processingDetailsStruct,
    final Element parentElement,
    final ServicePlanStatementDetailsList1 servicePlanStatementDetailsList)
    throws AppException, InformationalException {

    ServicePlanStatementDetails1 servicePlanStatementDetails = new ServicePlanStatementDetails1();

    servicePlanStatementDetails = servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.item(
      processingDetailsStruct.indexOfElement);

    ServicePlanStatementDetails1 newServicePlanStatementDetails = new ServicePlanStatementDetails1();

    newServicePlanStatementDetails.assign(servicePlanStatementDetails);

    final int numberOfRecords = servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.size();

    final int initialIndex = processingDetailsStruct.indexOfElement;

    final long planGroupID = servicePlanStatementDetails.plannedGroupID;
    long planSubGoalID = servicePlanStatementDetails.plannedSubGoalID;

    // if goal has plan group, check if the record in the list has subgoal and
    // if this subgoal belongs exactly to the group which currently is processed
    // (but not to its parent or child)
    boolean cycleEntered = false;

    if (servicePlanStatementDetails.plannedSubGoalID != 0) {
      final HideInformationIndicatorStruct hideInformationIndicatorStruct = new HideInformationIndicatorStruct();

      hideInformationIndicatorStruct.hideInformation = false;

      final UserSensitivityCodeStruct sensitivityCode = new UserSensitivityCodeStruct();

      sensitivityCode.userSensitivityCode = processingDetailsStruct.userSensitivityCode;

      // format planned subgoal element
      Element subGoalElement = formatPlannedSubGoalXMLElement1(
        servicePlanStatementDetails, sensitivityCode,
        hideInformationIndicatorStruct);

      Money plannedSubGoalEstimatedCost = new Money(0);
      Money plannedSubGoalActualCost = new Money(0);

      // process subgoals and planned items just for the group which was passed
      // as parameter
      while ((processingDetailsStruct.indexOfElement < numberOfRecords)
        && (servicePlanStatementDetails.plannedGroupID == planGroupID)) {
        cycleEntered = true;

        // subGoal has planned items ?
        if (servicePlanStatementDetails.plannedItemID != 0) {
          // format planned item element
          final Element planItemElement = formatPlannedActionXMLElement1(
            servicePlanStatementDetails, sensitivityCode);

          // calculate planned subgoal cost(it is derived from planned items
          // costs)
          plannedSubGoalEstimatedCost = new Money(
            servicePlanStatementDetails.plannedItemEstimatedCost.getValue()
              + plannedSubGoalEstimatedCost.getValue());

          plannedSubGoalActualCost = new Money(
            servicePlanStatementDetails.plannedItemActualCost.getValue()
              + plannedSubGoalActualCost.getValue());

          subGoalElement.setAttribute(kEstimatedCost,
            plannedSubGoalEstimatedCost.toString());
          subGoalElement.setAttribute(kActualCost,
            plannedSubGoalActualCost.toString());

          // add planned item element to planned subgoal
          subGoalElement.addContent(planItemElement);
        }

        // try to go to the next element
        if (++processingDetailsStruct.indexOfElement < numberOfRecords) {
          // change value of details
          newServicePlanStatementDetails = servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.item(
            processingDetailsStruct.indexOfElement);

          planSubGoalID = newServicePlanStatementDetails.plannedSubGoalID;
        }

        // if we will start process new subgoal information,
        // plan group still should be the same as was passed in parameter
        if ((planSubGoalID != servicePlanStatementDetails.plannedSubGoalID)
          && (newServicePlanStatementDetails.plannedGroupID == planGroupID)) {
          // add previous subgoal element to planned goal or planned group
          parentElement.addContent(subGoalElement);

          // format new planned subgoal element
          subGoalElement = formatPlannedSubGoalXMLElement1(
            newServicePlanStatementDetails, sensitivityCode,
            hideInformationIndicatorStruct);

          // add planned subGoal cost to goal cost or plan group cost depending
          // what is
          // passed here
          processingDetailsStruct.estimatedCost = new Money(
            processingDetailsStruct.estimatedCost.getValue()
              + plannedSubGoalEstimatedCost.getValue());
          processingDetailsStruct.actualCost = new Money(
            processingDetailsStruct.actualCost.getValue()
              + plannedSubGoalActualCost.getValue());

          // we will start calculation of another planned sub goal costs from 0
          plannedSubGoalEstimatedCost = new Money(0);
          plannedSubGoalActualCost = new Money(0);
        }

        // we will process next record
        servicePlanStatementDetails.assign(newServicePlanStatementDetails);
      }

      // add the last processed subgoal to parent: goal or plan group
      parentElement.addContent(subGoalElement);

      // recalculate final cost of this group of planned subgoals
      processingDetailsStruct.estimatedCost = new Money(
        processingDetailsStruct.estimatedCost.getValue()
          + plannedSubGoalEstimatedCost.getValue());
      processingDetailsStruct.actualCost = new Money(
        processingDetailsStruct.actualCost.getValue()
          + plannedSubGoalActualCost.getValue());
    }

    // we need to decide how many elements should be deleted from list
    int upperIndex = processingDetailsStruct.indexOfElement;

    if (cycleEntered
      && (servicePlanStatementDetails.plannedGroupID != planGroupID)
        || (upperIndex >= numberOfRecords)) {
      upperIndex--;
    }

    // remove processed items from list
    for (int i = initialIndex; i <= upperIndex; i++) {
      servicePlanStatementDetailsList.servicePlanStatementDetailsList.dtls.remove(
        initialIndex);
    }
  }

  // END, CR00208728

  /**
   * Creates a group element to add to the xml string.
   *
   * @param servicePlanStatementGroupDetails
   * the group record.
   *
   * @return Element Group element to be displayed on the Costing Gantt chart.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00208728, LP
  protected Element createGroupXML1(
    final ServicePlanStatementGroupDetails1 servicePlanStatementGroupDetails)
    throws AppException, InformationalException {

    final Element groupElement = new Element(kGroup);

    groupElement.setAttribute(kType, kGroupType);

    groupElement.setAttribute(kID,
      String.valueOf(servicePlanStatementGroupDetails.groupDeliveryID));
    groupElement.setAttribute(kName, servicePlanStatementGroupDetails.groupName);

    groupElement.setAttribute(kEstimatedCost,
      servicePlanStatementGroupDetails.estimatedCost.toString());
    groupElement.setAttribute(kActualCost,
      servicePlanStatementGroupDetails.actualCost.toString());

    // Create service plan elements
    final int numberOfServicePlans = servicePlanStatementGroupDetails.statementDeliveryDetailsList.size();

    for (int servicePlanCount = 0; servicePlanCount < numberOfServicePlans; servicePlanCount++) {
      final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = servicePlanStatementGroupDetails.statementDeliveryDetailsList.item(
        servicePlanCount);

      final Element goalElement = createGoalXML1(
        servicePlanStatementDeliveryDetails);

      // Add goal element to group element
      groupElement.addContent(goalElement);
    }

    return groupElement;
  }

  // END, CR00208728

  /**
   * Formats Plan Item XML Element.
   *
   * @param hideInformationIndicatorStruct
   * Indicator to show if we need to hide information of this planned
   * item(probably needs to be removed)
   *
   * @param servicePlanStatementDetails
   * Service Plan Statement Details
   * @param userSensitivityCodeStruct
   * User sensitivity code
   * @return Identifier of newly created participation record.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // BEGIN, CR00208728, LP
  protected Element formatPlannedActionXMLElement1(
    final ServicePlanStatementDetails1 servicePlanStatementDetails,
    final UserSensitivityCodeStruct userSensitivityCodeStruct)
    throws AppException, InformationalException {

    // BEGIN, CR00236077, NS
    final PlannedItem plannedItemObj = PlannedItemFactory.newInstance();
    final PlannedItemIDKey plannedItemIdKey = new PlannedItemIDKey();

    plannedItemIdKey.plannedItemID = servicePlanStatementDetails.plannedItemID;
    final PlanItemIDDetailsStruct planItemIDDetailsStruct = plannedItemObj.readPlanItemID(
      plannedItemIdKey);

    final PlanItem planItemObj = PlanItemFactory.newInstance();
    final PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.planItemID = planItemIDDetailsStruct.planItemID;
    final NameNotEditableIndDetails nameNotEditableIndDetails = planItemObj.readNameNotEditableIndDetails(
      planItemKey);

    if (nameNotEditableIndDetails.nameNotEditableInd) {
      servicePlanStatementDetails.plannedItemName = CodeTable.getOneItem(
        PLANITEMNAME.TABLENAME, nameNotEditableIndDetails.name,
        TransactionInfo.getProgramLocale());
    }
    // END, CR00236077
    
    final Element planItemElement = new Element(kPlanItem);

    planItemElement.setAttribute(kType, kPlanItem);
    planItemElement.setAttribute(kID,
      String.valueOf(servicePlanStatementDetails.plannedItemID));
    planItemElement.setAttribute(kName,
      servicePlanStatementDetails.plannedItemName);
    planItemElement.setAttribute(kEstimatedCost,
      String.valueOf(servicePlanStatementDetails.plannedItemEstimatedCost));
    planItemElement.setAttribute(kActualCost,
      String.valueOf(servicePlanStatementDetails.plannedItemActualCost));
    planItemElement.setAttribute(kStatus,
      servicePlanStatementDetails.plannedItemStatus);
    return planItemElement;

  }

  // END, CR00208728

  /**
   * Formats XML element of the planned subGoal.
   *
   * @param servicePlanStatementDetails
   * Service Plan Statement Details
   * @param userSensitivityCodeStruct
   * User sensitivity code
   * @param hideInformationIndicatorStruct
   * Indicator to show if we need to hide information of this planned
   * subgoal(probably needs to be removed)
   *
   * @return XML element containing subGoal details
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00208728, LP
  protected Element formatPlannedSubGoalXMLElement1(
    final ServicePlanStatementDetails1 servicePlanStatementDetails,
    final UserSensitivityCodeStruct userSensitivityCodeStruct,
    final HideInformationIndicatorStruct hideInformationIndicatorStruct)
    throws AppException, InformationalException {

    final Element subGoalElement = new Element(kPlannedSubGoal);

    // need the Service Plan Delivery Case Id, use the subgoal id to retrieve
    final curam.serviceplans.sl.entity.intf.PlannedSubGoal psgObj = PlannedSubGoalFactory.newInstance();
    final PlannedSubGoalKey psgKey = new PlannedSubGoalKey();

    psgKey.plannedSubGoalID = servicePlanStatementDetails.plannedSubGoalID;
    final ReadCaseIDByPlannedSubGoalIDDetails caseIdDtls = psgObj.readCaseIDByPlannedSubGoalID(
      psgKey);

    final Money initialSubCost = new Money(0.0);

    subGoalElement.setAttribute(kType, kPlannedSubGoal);
    subGoalElement.setAttribute(kID,
      String.valueOf(servicePlanStatementDetails.plannedSubGoalID));
    subGoalElement.setAttribute(kCaseID, String.valueOf(caseIdDtls.caseID));
    subGoalElement.setAttribute(kName, servicePlanStatementDetails.subGoalName);
    subGoalElement.setAttribute(kEstimatedCost, String.valueOf(initialSubCost));
    subGoalElement.setAttribute(kActualCost, String.valueOf(initialSubCost));
    subGoalElement.setAttribute(kStatus,
      servicePlanStatementDetails.plannedSubGoalStatus);

    return subGoalElement;
  }

  // END, CR00208728

  // __________________________________________________________________________
  /**
   * Formats XML string from list retrieved from database.
   *
   * @param servicePlanStatementDetailsList
   * List of service plan statement data retrieved from database
   * @param servicePlanStatementGoalDetails
   * Details of Planned Goal
   *
   * @return Service Plan Statement Data as XML String
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00208728, LP
  public ServicePlanStatementXMLString formatServicePlanStatementXML1(
    final ServicePlanStatementDetailsList1 servicePlanStatementDetailsList,
    final ServicePlanStatementGoalDetails1 servicePlanStatementGoalDetails)
    throws AppException, InformationalException {
    // BEGIN, CR00161962, LJ
    // Create goal element from passed objects
    final ServicePlanStatementDeliveryDetails1 servicePlanStatementDeliveryDetails = new ServicePlanStatementDeliveryDetails1();

    servicePlanStatementDeliveryDetails.statementGoalDetails = servicePlanStatementGoalDetails;
    servicePlanStatementDeliveryDetails.statementDetailsList = servicePlanStatementDetailsList;

    // Code for this refactored to private helper method for reuse elsewhere
    final Element goalElement = createGoalXML1(
      servicePlanStatementDeliveryDetails);

    // Create gantt element
    final Element ganttElement = new Element(kGantt);

    final String caseStatus = servicePlanStatementGoalDetails.servicePlanStatementGoalDetails.plannedGoalStatus;

    if (caseStatus.equals(CASESTATUS.CLOSED)
      || caseStatus.equals(CASESTATUS.COMPLETED)
      || caseStatus.equals(CASESTATUS.CANCELED)) {
      ganttElement.setAttribute(kView, kClosed);
    } else {
      ganttElement.setAttribute(kView, kOpen);
    }

    ganttElement.addContent(goalElement);

    // Output the return string
    final XMLOutputter xmlOutputter = new XMLOutputter();

    final ServicePlanStatementXMLString servicePlanStatementXMLString = new ServicePlanStatementXMLString();

    servicePlanStatementXMLString.statementDetails = xmlOutputter.outputString(
      ganttElement);

    return servicePlanStatementXMLString;
    // END, CR00161962
  }

  // END, CR00208728
  /**
   * Creates the XML string for the Service Plan Delivery costing Gantt.
   *
   * @param servicePlanStatementDeliveryDetails
   * Details required to create the costing Gantt XML String.
   *
   * @return The created XML String to be displayed on the costing Gantt
   * diagram.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00208728, LP
  public ServicePlanStatementXMLString createServicePlanStatementXmlDetails1(
    final ServicePlanStatementDeliveryDetails1
    servicePlanStatementDeliveryDetails)
    throws AppException, InformationalException {

    final ServicePlanStatementXMLString servicePlanStatementXMLString = formatServicePlanStatementXML1(
      servicePlanStatementDeliveryDetails.statementDetailsList,
      servicePlanStatementDeliveryDetails.statementGoalDetails);

    return servicePlanStatementXMLString;
  }

  // END, CR00208728

  /**
   * Creates the XML string for the Service Plan Group Delivery costing Gantt.
   *
   * @param servicePlanStatementGroupDetails
   * Details required to create the costing Gantt XML String.
   *
   * @return The created XML String to be displayed on the costing Gantt
   * diagram.
   *
   * @throws InformationalException
   * e2
   * @throws AppException
   * e1
   */
  // BEGIN, CR00208728, LP
  // BEGIN, CR00229255 MN
  public SPStatementXMLString createServicePlanStatementGroupXmlDetails1(
    final ServicePlanStatementGroupDetails1 servicePlanStatementGroupDetails)
    throws AppException, InformationalException {
    // END, CR00229225
    // Create root node
    final Element ganttElement = new Element(kGantt);

    ganttElement.setAttribute(kView, kOpen);

    // Create service plan group element
    final Element groupElement = createGroupXML1(
      servicePlanStatementGroupDetails);

    ganttElement.addContent(groupElement);

    // Output the XML as a string and assign it to the return object
    final XMLOutputter outputter = new XMLOutputter();

    // BEGIN, CR00229255 MN
    final SPStatementXMLString servicePlanStatementXMLString = new SPStatementXMLString();

    // END, CR00229225

    servicePlanStatementXMLString.newStatementDetails = outputter.outputString(
      ganttElement);

    return servicePlanStatementXMLString;
  }
  // END, CR00208728

}
