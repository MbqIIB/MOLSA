/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.piwrapper.serviceplans.impl;

import java.util.List;

import com.google.inject.Inject;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.SUBGOALNAMEEntry;
import curam.codetable.impl.SUBGOALTYPEEntry;
import curam.serviceplans.sl.entity.struct.SubGoalDtls;
import curam.util.persistence.helper.ReadOnlyEntityImpl;
import curam.util.type.Date;

/**
 * A wrapper object for {@linkplain curam.serviceplans.sl.entity.intf.SubGoal}.
 */
// BEGIN, CR00183334, PS
public class SubGoalImpl extends ReadOnlyEntityImpl<Long, SubGoalDtls>
    implements SubGoal {
  // END, CR00183334
  @Inject
  private PlanItemDAO planItemDAO;

  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected SubGoalImpl() {
    // no-arg constructor for use only by Guice.
  }

  // END, CR00183334

  /**
   * {@inheritDoc}
   */
  public SUBGOALNAMEEntry getName() {
    return SUBGOALNAMEEntry.get(getDtls().name);
  }

  /**
   * {@inheritDoc}
   */
  public Date getDateCreated() {
    return getDtls().dateCreated;
  }

  /**
   * {@inheritDoc}
   */
  public String getDescription() {
    return getDtls().description;
  }

  /**
   * {@inheritDoc}
   */
  public String getSubGoalReference() {
    return getDtls().subGoalReference;
  }

  /**
   * {@inheritDoc}
   */
  public RECORDSTATUSEntry getLifecycleState() {
    return RECORDSTATUSEntry.get(getDtls().recordStatus);
  }

  /**
   * {@inheritDoc}
   */
  public int getVersionNo() {
    return getDtls().versionNo;
  }

  /**
   * {@inheritDoc}
   */
  public SUBGOALTYPEEntry getTypeCode() {
    return SUBGOALTYPEEntry.get(getDtls().typeCode);
  }

  /**
   * {@inheritDoc}
   */
  public List<PlanItem> listActivePlanItems() {
    return planItemDAO.listActiveBySubGoal(this);
  }

}
