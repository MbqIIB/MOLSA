/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.facade.impl;

import curam.serviceplans.sl.entity.struct.PlanItemTaskConfigSearchKey;
import curam.serviceplans.sl.entity.struct.TaskConfigurationDtls;
import curam.serviceplans.sl.entity.struct.TaskConfigurationDtlsList;
import curam.serviceplans.sl.entity.struct.TaskConfigurationKey;
import curam.serviceplans.sl.fact.TaskConfigurationFactory;
import curam.serviceplans.sl.struct.TaskConfigurationDetails;
import curam.serviceplans.sl.struct.TaskConfigurationDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This process class provides the functionality for the  Task
 * Configurations in facade layer.
 */
public abstract class TaskConfiguration extends
  curam.serviceplans.facade.base.TaskConfiguration {

//_____________________________________________________________________________
  /**
   * This method is used to cancel the task configuration record.
   *
   * @param taskConfigKey
   *            TaskConfigurationKey
   * @throws AppException, InformationalException
   */
  public void cancelTaskConfiguration(final TaskConfigurationKey taskConfigKey)
    throws AppException, InformationalException {
    final curam.serviceplans.sl.intf.TaskConfiguration taskConfigurationObj
      = TaskConfigurationFactory.newInstance();
    taskConfigurationObj.cancel(taskConfigKey);
  }
//_____________________________________________________________________________
  /**
   * This method is used to search the task configuration record
   * based on the search criteria entered by the user.
   *
   * @param searchKey
   *            Contains search criteria
   *
   * @return TaskConfigurationDtlsList
   * @throws AppException, InformationalException
   */
  public TaskConfigurationDetailsList searchByTaskNamePriorityAssignee(
    final PlanItemTaskConfigSearchKey searchKey)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.TaskConfiguration taskConfigurationObj
      = TaskConfigurationFactory.newInstance();

    final TaskConfigurationDetailsList piTaskConfigurationDtlsList
      = taskConfigurationObj.searchByTaskNamePriorityAssignee(searchKey);
    return piTaskConfigurationDtlsList;
  }

//_____________________________________________________________________________
  /**
   * This method is used to create a new task configuration.
   *
   * @param taskConfigDtls
   *            TaskConfigurationDtls
   *
   * @return TaskConfigurationKey
   * @throws AppException, InformationalException
   */
  public TaskConfigurationKey createTaskConfiguration(
    final TaskConfigurationDtls taskConfigDtls)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.TaskConfiguration taskConfigurationObj
      = TaskConfigurationFactory.newInstance();

    final TaskConfigurationKey taskConfigurationKey
      = taskConfigurationObj.insert(taskConfigDtls);

    return taskConfigurationKey;
  }
//_____________________________________________________________________________
  /**
   * This method is used to fetch all the active records from the
   * task configuration.
   *
   * @return TaskConfigurationDtlsList
   * @throws AppException, InformationalException
   */
  public TaskConfigurationDtlsList listTaskConfiguration()
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.TaskConfiguration taskConfigurationObj
      = TaskConfigurationFactory.newInstance();
    final TaskConfigurationDtlsList taskConfigurationDtlsList
      = taskConfigurationObj.list();

    return taskConfigurationDtlsList;
  }
//_____________________________________________________________________________
  /**
   * This method is used to modify the task configuration.
   *
   * @param taskConfigDtls
   *            TaskConfigurationDtls
   * @throws AppException, InformationalException
   */
  public void modifyTaskConfiguration(
    final TaskConfigurationDtls taskConfigDtls)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.TaskConfiguration taskConfigurationObj
      = TaskConfigurationFactory.newInstance();
    taskConfigurationObj.modify(taskConfigDtls);
  }
//_____________________________________________________________________________
  /**
   * This method is used to read the record from the task configuration.
   *
   * @param taskConfigKey
   *            TaskConfigurationKey
   *
   * @return TaskConfigurationDtls
   * @throws AppException, InformationalException
   */
  public TaskConfigurationDetails readTaskConfiguration(
    final TaskConfigurationKey taskConfigKey)
    throws AppException, InformationalException {

    final curam.serviceplans.sl.intf.TaskConfiguration taskConfigurationObj
      = TaskConfigurationFactory.newInstance();
    final TaskConfigurationDetails taskConfigurationDtls =
      taskConfigurationObj.read(taskConfigKey);
    return taskConfigurationDtls;
  }
}
