/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2007, 2009-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;

import curam.codetable.LOCALIZABLETEXTGROUPCODE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.fact.MilestoneConfigurationFactory;
import curam.core.sl.entity.struct.MilestoneConfigIDAndName;
import curam.core.sl.entity.struct.MilestoneConfigIDAndNameDetails;
import curam.core.sl.entity.struct.MilestoneConfigIDAndNameDetailsList;
import curam.core.sl.entity.struct.RecordStatusKey;
import curam.core.sl.struct.Priority;
import curam.core.sl.struct.PriorityDetails;
import curam.core.sl.struct.PriorityPosition;
import curam.message.BPOAPPROVALCRITERIA;
import curam.message.BPOPLANTEMPLATE;
import curam.message.BPOPLANTEMPLATEPLANGROUP;
import curam.message.GENERAL;
import curam.serviceplans.sl.entity.fact.PlanItemApprovalCriteriaLinkFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplateMilestoneFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanGroupFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemApprCritFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory;
import curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory;
import curam.serviceplans.sl.entity.intf.PlanItemApprovalCriteriaLink;
import curam.serviceplans.sl.entity.intf.PlanTemplateMilestone;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanGroup;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanItemApprCrit;
import curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal;
import curam.serviceplans.sl.entity.struct.ListTemplateSubGoalsForModifyKey;
import curam.serviceplans.sl.entity.struct.PlanItemAndTemplatePlanItemDetails;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkDtls;
import curam.serviceplans.sl.entity.struct.PlanItemApprovalCriteriaLinkKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateCount;
import curam.serviceplans.sl.entity.struct.PlanTemplateDescriptionTextID;
import curam.serviceplans.sl.entity.struct.PlanTemplateDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplateIDAndParentGroupID;
import curam.serviceplans.sl.entity.struct.PlanTemplateIDPlanGroupIDAndSubGoalID;
import curam.serviceplans.sl.entity.struct.PlanTemplateLocalizedNameAndID;
import curam.serviceplans.sl.entity.struct.PlanTemplateLocalizedNameAndIDList;
import curam.serviceplans.sl.entity.struct.PlanTemplateMilestoneCommentsTextID;
import curam.serviceplans.sl.entity.struct.PlanTemplateMilestoneDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplateMilestoneKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateNameAndIDDetails;
import curam.serviceplans.sl.entity.struct.PlanTemplateNameAndNameTextID;
import curam.serviceplans.sl.entity.struct.PlanTemplateNameAndStatus;
import curam.serviceplans.sl.entity.struct.PlanTemplateNameTextID;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupCommentsTextID;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupCount;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupNameAndTemplateIDKey;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupNameDetails;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupNameTextID;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemApprCritDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemDescriptionTextID;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalDescriptionTextID;
import curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalDtls;
import curam.serviceplans.sl.entity.struct.SearchUnassociatedTemplateApprovalCriteriaKey;
import curam.serviceplans.sl.entity.struct.TemplateApprovalCriteriaDetailsList;
import curam.serviceplans.sl.entity.struct.TemplateApprovalCriteriaPriorityDetails;
import curam.serviceplans.sl.entity.struct.TemplateApprovalCriteriaPriorityDetailsList;
import curam.serviceplans.sl.entity.struct.TemplateApprovalCriteriaPrioritySearchDetails;
import curam.serviceplans.sl.entity.struct.TemplateIDAndPlanGroupID;
import curam.serviceplans.sl.entity.struct.TemplatePlanGroupNameDetails;
import curam.serviceplans.sl.fact.PlanTemplateFactory;
import curam.serviceplans.sl.intf.PriorityHelper;
import curam.serviceplans.sl.fact.PriorityHelperFactory;
import curam.serviceplans.sl.struct.AddTemplatePlanItemApprovalCriteriaDetails;
import curam.serviceplans.sl.struct.CancelPlanTemplateDetails;
import curam.serviceplans.sl.struct.GoalNameAndIDDetails;
import curam.serviceplans.sl.struct.GoalNameAndIDDetailsList;
import curam.serviceplans.sl.struct.MilestoneConfigIDAndNameList;
import curam.serviceplans.sl.struct.OrderPriorityDetails;
import curam.serviceplans.sl.struct.PlanGroupNameDetails;
import curam.serviceplans.sl.struct.PlanItemAndOutcomeKey;
import curam.serviceplans.sl.struct.PlanItemAndOutcomeNameDetails;
import curam.serviceplans.sl.struct.PlanItemNameDetails;
import curam.serviceplans.sl.struct.PlanItemNameDetailsList;
import curam.serviceplans.sl.struct.PlanTemplateAndPlanItemDetails;
import curam.serviceplans.sl.struct.PlanTemplateAndPlanItemModifyDetails;
import curam.serviceplans.sl.struct.PlanTemplateAndSubGoalModifyDetails;
import curam.serviceplans.sl.struct.PlanTemplateAndSubGoalReadDetails;
import curam.serviceplans.sl.struct.PlanTemplateChart;
import curam.serviceplans.sl.struct.PlanTemplateDetails;
import curam.serviceplans.sl.struct.PlanTemplateDetailsList;
import curam.serviceplans.sl.struct.PlanTemplateKey;
import curam.serviceplans.sl.struct.PlanTemplateMilestoneDetails;
import curam.serviceplans.sl.struct.PlanTemplateNameAndIDDetailsList;
import curam.serviceplans.sl.struct.PlanTemplateNameDetails;
import curam.serviceplans.sl.struct.PlanTemplatePlanGroupDetails;
import curam.serviceplans.sl.struct.PlanTemplatePlanGroupKey;
import curam.serviceplans.sl.struct.PlanTemplatePlanGroupModifyDetails;
import curam.serviceplans.sl.struct.PlanTemplatePlanItemApprCritDetails;
import curam.serviceplans.sl.struct.PlanTemplatePlanItemApprCritKey;
import curam.serviceplans.sl.struct.PlanTemplatePlanItemKey;
import curam.serviceplans.sl.struct.PlanTemplateReorderInstruction;
import curam.serviceplans.sl.struct.PlanTemplateSubGoalDetails;
import curam.serviceplans.sl.struct.PlanTemplateSubGoalKey;
import curam.serviceplans.sl.struct.PriorityDetailsList;
import curam.serviceplans.sl.struct.ReadPlanTemplateDetails;
import curam.serviceplans.sl.struct.ReadPlanTemplatePlanItemForModifyDetails;
import curam.serviceplans.sl.struct.ReadTemplateAndSubGoalForModifyDetails;
import curam.serviceplans.sl.struct.ReadTemplateMilestoneDetails;
import curam.serviceplans.sl.struct.ReadTemplatePlanItemApprovalCriteriaDetails;
import curam.serviceplans.sl.struct.ReadTemplatePlanItemForModifyKey;
import curam.serviceplans.sl.struct.ReadTemplateSubGoalForModifyKey;
import curam.serviceplans.sl.struct.ServicePlanGoalSubGoalsAndPlanItemsDetails;
import curam.serviceplans.sl.struct.ServicePlanKey;
import curam.serviceplans.sl.struct.SubGoalAndPlanTemplatePlanItemsDetails;
import curam.serviceplans.sl.struct.SubGoalNameDetails;
import curam.serviceplans.sl.struct.SubGoalNameDetailsList;
import curam.serviceplans.sl.struct.TemplateItemDetails;
import curam.serviceplans.sl.struct.TemplatePlanItemDetailsList;
import curam.serviceplans.sl.struct.TemplateSubGoalDetailsList;
import curam.serviceplans.sl.struct.UnassociatedTemplateApprovalCriteriaDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.intf.TextTranslation;
import curam.workspaceservices.localization.struct.GroupCodeAndLocaleKey;
import curam.workspaceservices.localization.struct.LocalizableTextTranslationDetails;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextCount;
import curam.workspaceservices.localization.struct.TextTranslationDtls;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;


/**
 * The plan template describes a template for a service plan. This is used
 * when creating a service plan of a specific type. A plan template consists
 * of a goal, sub goals and planItems. The service layer of the plan template
 * provides access to all these items.
 */
public abstract class PlanTemplate extends curam.serviceplans.sl.base.PlanTemplate {

  // BEGIN, CR00226647, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public PlanTemplate() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00226647

  // _________________________________________________________________________
  // BEGIN, CR00226779 MN
  /**
   * Associates a plan item with the plan template. A plan template plan item is
   * used to associate the plan item with a plan template sub goal
   *
   * @param details the details of the association
   *
   * @deprecated since Curam v6, replaced with {@link addTemplatePlanItem(PlanTemplateAndPlanItemDetails details)}.
   * The new method addTemplatePlanItem adds a plan item to a plan template
   * along with approval and mandatory indicators.See release note <CR00226779>.
   */
  @Deprecated
  public void addPlanItem(
    curam.serviceplans.sl.struct.PlanTemplatePlanItemDetails details)
    throws AppException, InformationalException {
    PlanTemplateAndPlanItemDetails planTemplateAndPlanItemDetails = new PlanTemplateAndPlanItemDetails();

    planTemplateAndPlanItemDetails.dtls.authorizedUnits = details.dtls.authorizedUnits;
    planTemplateAndPlanItemDetails.dtls.description = details.dtls.description;
    planTemplateAndPlanItemDetails.dtls.duration = details.dtls.duration;
    planTemplateAndPlanItemDetails.dtls.expectedOutcomeID = details.dtls.expectedOutcomeID;
    planTemplateAndPlanItemDetails.dtls.expectedOutcomeName = details.dtls.expectedOutcomeName;
    planTemplateAndPlanItemDetails.dtls.maximumUnits = details.dtls.maximumUnits;
    planTemplateAndPlanItemDetails.dtls.name = details.dtls.name;
    planTemplateAndPlanItemDetails.dtls.outcomeRequiredInd = details.dtls.outcomeRequiredInd;
    planTemplateAndPlanItemDetails.dtls.planItemID = details.dtls.planItemID;
    planTemplateAndPlanItemDetails.dtls.planTemplatePlanItemID = details.dtls.planTemplatePlanItemID;
    planTemplateAndPlanItemDetails.dtls.planTemplateSubGoalID = details.dtls.planTemplateSubGoalID;
    planTemplateAndPlanItemDetails.dtls.startDay = details.dtls.startDay;
    planTemplateAndPlanItemDetails.dtls.versionNo = details.dtls.versionNo;

    this.addTemplatePlanItem(planTemplateAndPlanItemDetails);

  }

  // END, CR00226779

  // _________________________________________________________________________
  /**
   * Associates a sub goal with the plan template.  A plan template
   * sub goal association is used to associate the sub goal with a plan
   * template
   *
   * @param details the details of the association
   */
  public PlanTemplateSubGoalKey addSubGoal(PlanTemplateSubGoalDetails details)
    throws AppException, InformationalException {

    // Plan Template Sub Goal entity and manipulation variables
    PlanTemplateSubGoal planTemplateSubGoalObj = PlanTemplateSubGoalFactory.newInstance();

    // return value
    PlanTemplateSubGoalKey planTemplateSubGoalKey = new PlanTemplateSubGoalKey();

    PlanTemplateSubGoalDtls planTemplateSubGoalDtls = new PlanTemplateSubGoalDtls();

    planTemplateSubGoalDtls.assign(details.dtls);

    // BEGIN, CR00228796, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!planTemplateSubGoalDtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(planTemplateSubGoalDtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      planTemplateSubGoalDtls.descriptionTextID = localizableTextHandler.store(
        );
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      planTemplateSubGoalDtls.descriptionTextID = localizableTextHandler.store(
        );
    }

    // BEGIN, CR00229083, GP
    planTemplateSubGoalDtls.description = null;
    // END, CR00229083

    // END, CR00228796

    // add the plan item to plan template
    planTemplateSubGoalObj.insert(planTemplateSubGoalDtls);

    planTemplateSubGoalKey.key.planTemplateSubGoalID = planTemplateSubGoalDtls.planTemplateSubGoalID;

    // BEGIN, CR00020193, PMD
    // Set the id and type of the template item added
    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    templateItemDetails.templateItemObjID = String.valueOf(
      planTemplateSubGoalKey.key.planTemplateSubGoalID);
    templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplateSubGoal;
    postUpdateTemplateItem(templateItemDetails);
    // END, CR00020193

    return planTemplateSubGoalKey;
  }

  // _________________________________________________________________________
  /**
   * Removes the association between a plan template and a plan item.
   *
   * @param key the key of the association
   */
  public void cancelPlanItem(PlanTemplatePlanItemKey key)
    throws AppException, InformationalException {

    // Plan Template PlanItem entity
    PlanTemplatePlanItem planTemplatePlanItemObj = PlanTemplatePlanItemFactory.newInstance();

    // BEGIN, CR00020193, PMD
    // Read the planTemplateSubGoalID, so that we know which node
    // to return to in the tree control
    PlanTemplateSubGoalKey planTemplateSubGoalKey = new PlanTemplateSubGoalKey();

    planTemplateSubGoalKey.key = planTemplatePlanItemObj.readPlanTemplateSubGoalID(
      key.key);
    // END, CR00020193

    // cancel plan template planItem
    planTemplatePlanItemObj.remove(key.key);

    // BEGIN, CR00020193, PMD
    // Set the id and type of the template item to return to
    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    templateItemDetails.templateItemObjID = String.valueOf(
      planTemplateSubGoalKey.key.planTemplateSubGoalID);
    templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplateSubGoal;
    postUpdateTemplateItem(templateItemDetails);
    // END, CR00020193

  }

  // _________________________________________________________________________
  /**
   * Removes the association between a plan template and an sub goal
   *
   * @param key the key of the association
   */
  public void cancelSubGoal(PlanTemplateSubGoalKey key)
    throws AppException, InformationalException {

    // Plan Template Sub Goal entity
    PlanTemplateSubGoal planTemplateSubGoalObj = PlanTemplateSubGoalFactory.newInstance();

    // BEGIN, CR00020193, PMD
    // Read the planTemplateID and the planTemplatePlanGroupID,
    // so that we know which node to return to in the tree control
    TemplateIDAndPlanGroupID templateIDAndPlanGroupID = new TemplateIDAndPlanGroupID();

    templateIDAndPlanGroupID = planTemplateSubGoalObj.readTemplateIDAndPlanGroupID(
      key.key);
    // END, CR00020193

    // cancel plan template sub goal
    planTemplateSubGoalObj.remove(key.key);

    // BEGIN, CR00020193, PMD
    // Set the id and type of the template item to return to
    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    if (templateIDAndPlanGroupID.planTemplatePlanGroupID != 0) {

      // The removed sub-goal was part of a plan group,
      // return the user to this plan group
      templateItemDetails.templateItemObjID = String.valueOf(
        templateIDAndPlanGroupID.planTemplatePlanGroupID);
      templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplatePlanGroup;

    } else {

      // The removed sub-goal was not part of a plan group,
      // return the user to template home
      templateItemDetails.templateItemObjID = String.valueOf(
        templateIDAndPlanGroupID.planTemplateID);
      templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplate;

    }
    postUpdateTemplateItem(templateItemDetails);
    // END, CR00020193

  }

  // _________________________________________________________________________
  /**
   * Creates a plan template
   *
   * @param details the details of the new plan template
   * @return the key of the new plan template
   */
  public PlanTemplateKey create(PlanTemplateDetails details)
    throws AppException, InformationalException {

    // return value
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    // Plan Template entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    // set creation date
    details.dtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // set record status
    details.dtls.recordStatus = RECORDSTATUS.NORMAL;

    // BEGIN, CR00226647, GP

    // BEGIN, CR00233815, GP
    PlanTemplateNameAndStatus planTemplateNameKey = new
      PlanTemplateNameAndStatus();
    // END, CR00233815
    PlanTemplateCount planTemplateCount = new PlanTemplateCount();

    // Service plan template name must not be blank.
    if (details.dtls.name.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_NAME_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Trim empty spaces from both sides of the string.
    details.dtls.name = details.dtls.name.trim();

    StringBuffer name = new StringBuffer(details.dtls.name);

    // If there is a space between the words longer than one reduce it to
    // exactly one space.
    char prevChar = name.charAt(0);
    int index = 0;

    for (char c : name.toString().toCharArray()) {
      if ((c == CuramConst.gkSpaceChar) && prevChar == CuramConst.gkSpaceChar) {
        name.deleteCharAt(index);
      }
      prevChar = c;
      index++;
    }

    details.dtls.name = name.toString();

    // Set name key details.
    planTemplateNameKey.name = details.dtls.name;
    planTemplateNameKey.recordStatus = RECORDSTATUS.NORMAL;

    // BEGIN, CR00233815, GP
    // Count templates by name.
    planTemplateCount = planTemplateObj.countByNameAndStatus(
      planTemplateNameKey);
    // END, CR00233815

    if (planTemplateCount.count > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_NAME_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // BEGIN, CR00236426, GP
    // Check the localized records for duplicates.
    TextTranslation TextTranslationObj = TextTranslationFactory.newInstance();
    TextCount textCount = new TextCount();
    GroupCodeAndLocaleKey groupCodeAndLocaleKey = new GroupCodeAndLocaleKey();

    groupCodeAndLocaleKey.groupCode = LOCALIZABLETEXTGROUPCODE.PLANTEMPLATENAME;
    groupCodeAndLocaleKey.localeCode = LOCALEEntry.get((ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())).toString();
    groupCodeAndLocaleKey.name = details.dtls.name;
    textCount = TextTranslationObj.countByGroupCodeAndLocale(
      groupCodeAndLocaleKey);

    if (0 < textCount.count) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_NAME_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00236426


    // Store the name and description as localized values.
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.setGroupCode(
      LOCALIZABLETEXTGROUPCODE.PLANTEMPLATENAME);
    localizableTextHandler.addValue(details.dtls.name,
      LOCALEEntry.get(
      (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
    details.dtls.nameTextID = localizableTextHandler.store();

    if (!details.dtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(details.dtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      details.dtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      details.dtls.descriptionTextID = localizableTextHandler.store();
    }

    // BEGIN, CR00228023, GP
    details.dtls.name = null;
    // END, CR00228023

    details.dtls.description = null;
    // END, CR00226647

    // create plan template
    planTemplateObj.insert(details.dtls);

    // set plan template ID
    planTemplateKey.planTemplateKey.planTemplateID = details.dtls.planTemplateID;

    // return plan template list
    return planTemplateKey;
  }

  // _________________________________________________________________________
  /**
   * Lists all plan templates on the system
   *
   * @return A list of all the plan templates that are available
   */
  public PlanTemplateDetailsList list() throws AppException, InformationalException {

    // return value
    PlanTemplateDetailsList planTemplateDetailsList = new PlanTemplateDetailsList();

    // Plan Template entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    // list plan templates
    planTemplateDetailsList.list = planTemplateObj.readAll();

    // BEGIN, CR00226647, GP

    for (int i = 0; i < planTemplateDetailsList.list.dtls.size(); i++) {

      if (0 != planTemplateDetailsList.list.dtls.item(i).nameTextID) {

        LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          planTemplateDetailsList.list.dtls.item(i).nameTextID);

        planTemplateDetailsList.list.dtls.item(i).name = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
    }
    // END, CR00226647

    // return plan template list
    return planTemplateDetailsList;
  }

  // _________________________________________________________________________
  /**
   * Gets the XML data for producing a GANTT chart of the plan template.
   *
   * @param key the key of the plan template
   * @return the XML data
   */
  public PlanTemplateChart listDetails(PlanTemplateKey key)
    throws AppException, InformationalException {
    return null;
  }

  // _________________________________________________________________________
  /**
   * Lists all planItems not currently associated with a plan template
   * sub goal.  These will likely be for addition to the plan template
   * sub goal.
   *
   * @param key the key of the plan template sub goal
   * @return the list of unassociated planItems
   */
  public PlanItemNameDetailsList listUnassociatedPlanItems(PlanTemplateSubGoalKey key)
    throws AppException, InformationalException {

    // Plan Template Sub Goal entity and manipulation variables
    curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal planTemplateSubGoalObj = curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory.newInstance();

    curam.serviceplans.sl.entity.struct.ListUnassociatedPlanItemsKey listUnassociatedPlanItemsKey = new curam.serviceplans.sl.entity.struct.ListUnassociatedPlanItemsKey();

    // return value
    PlanItemNameDetailsList planItemNameDetailsList = new PlanItemNameDetailsList();

    // set the key
    listUnassociatedPlanItemsKey.planTemplateSubGoalID = key.key.planTemplateSubGoalID;
    listUnassociatedPlanItemsKey.recordStatus = RECORDSTATUS.NORMAL;

    // read unassociated planItems list
    planItemNameDetailsList.list = planTemplateSubGoalObj.searchUnassociatedPlanItems(
      listUnassociatedPlanItemsKey);

    // return the list
    return planItemNameDetailsList;

  }

  // _________________________________________________________________________
  /**
   * Lists all sub goal not currently associated with a plan template.  These
   * will likely be for addition to the plan template,
   *
   * @param key The key of the plan template for which the unassociated
   * sub goals are required
   * @return the list of unassociated plan template sub goals
   */
  public SubGoalNameDetailsList listUnassociatedSubGoals(PlanTemplateKey key)
    throws AppException, InformationalException {

    // Plan Template entity and manipulation variables
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    curam.serviceplans.sl.entity.struct.ListUnassociatedSubGoalsKey listUnassociatedSubGoalsKey = new curam.serviceplans.sl.entity.struct.ListUnassociatedSubGoalsKey();

    // return value
    SubGoalNameDetailsList subGoalNameDetailsList = new SubGoalNameDetailsList();

    // set the key
    listUnassociatedSubGoalsKey.planTemplateID = key.planTemplateKey.planTemplateID;
    listUnassociatedSubGoalsKey.recordStatus = RECORDSTATUS.NORMAL;

    // read unassociated planItems list
    subGoalNameDetailsList.list = planTemplateObj.searchUnassociatedSubGoals(
      listUnassociatedSubGoalsKey);

    // return the list
    return subGoalNameDetailsList;

  }

  // _________________________________________________________________________
  /**
   * Modifies a plan template.
   *
   * @param key The key of the plan template
   * @param details The new details for the plan template
   */
  public void modify(PlanTemplateKey key, PlanTemplateDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00226647, GP
    long nameTextID, descriptionTextID;

    ReadPlanTemplateDetails readPlanTemplateDetails = new
      ReadPlanTemplateDetails();
    // BEGIN, CR00233815, GP
    PlanTemplateNameAndStatus planTemplateNameKey = new
      PlanTemplateNameAndStatus();
    // END, CR00233815
    PlanTemplateCount planTemplateCount = new PlanTemplateCount();
    // END, CR00226647

    // Plan Template entity object.
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    // BEGIN, CR00226647, GP

    // Read the plan template details.
    readPlanTemplateDetails = read(key);

    // Service plan template name must not be blank.
    if (details.dtls.name.equals(CuramConst.gkEmpty)) {

      throw new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_NAME_BLANK);
    }

    // Trim empty spaces from both sides of the string.
    details.dtls.name = details.dtls.name.trim();

    StringBuffer name = new StringBuffer(details.dtls.name);

    // If there is a space between the words longer than one reduce it to
    // exactly one space.
    for (int i = 0; i < name.length(); i++) {
      if ((name.charAt(i) == CuramConst.gkSpaceChar)
        && (name.charAt(i + 1) == CuramConst.gkSpaceChar)) {
        name.deleteCharAt(i + 1);
        i--;
      }
    }

    details.dtls.name = name.toString();

    // If name is modified, the new name must be unique.
    if (!readPlanTemplateDetails.dtls.name.equals(details.dtls.name)) {

      // set name key details
      planTemplateNameKey.name = details.dtls.name;
      planTemplateNameKey.recordStatus = RECORDSTATUS.NORMAL;

      // BEGIN, CR00233815, GP
      // Count templates by name.
      planTemplateCount = planTemplateObj.countByNameAndStatus(
        planTemplateNameKey);
      // END, CR00233815

      if (planTemplateCount.count > 0) {
        // plan template name must be unique
        throw new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_NAME_EXISTS);
      }
      // BEGIN, CR00236426, GP
      // Check the localized records for duplicates.
      TextTranslation TextTranslationObj = TextTranslationFactory.newInstance();
      TextCount textCount = new TextCount();
      GroupCodeAndLocaleKey groupCodeAndLocaleKey = new GroupCodeAndLocaleKey();

      groupCodeAndLocaleKey.groupCode = LOCALIZABLETEXTGROUPCODE.PLANTEMPLATENAME;
      groupCodeAndLocaleKey.localeCode = LOCALEEntry.get((ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())).toString();
      groupCodeAndLocaleKey.name = details.dtls.name;
      textCount = TextTranslationObj.countByGroupCodeAndLocale(
        groupCodeAndLocaleKey);

      if (0 < textCount.count) {
        // Plan template name must be unique.
        throw new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_NAME_EXISTS);
      }

      // END, CR00236426

    }

    // Modify Localized name.
    if (0 == details.dtls.nameTextID) {

      // Handling Legacy data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(details.dtls.name,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      nameTextID = localizableTextHandler.store();

      // BEGIN, CR00229083, GP
      // Update the struct passed to modify().
      details.dtls.nameTextID = nameTextID;
      // END, CR00229083

    } else {

      // Handling New data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        details.dtls.nameTextID);

      localizableTextHandler.addValue(details.dtls.name,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      localizableTextHandler.store();
    }

    // Modify Localized description.
    if (0 == details.dtls.descriptionTextID) {

      if (!details.dtls.description.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(details.dtls.description,
          LOCALEEntry.get(
          (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }

      // BEGIN, CR00229083, GP
      // Update the struct passed to modify().
      details.dtls.descriptionTextID = descriptionTextID;
      // END, CR00229083

    } else {

      // Handling New data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        details.dtls.descriptionTextID);

      localizableTextHandler.addValue(details.dtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      localizableTextHandler.store();

    }

    // BEGIN, CR00228023, GP
    details.dtls.name = null;
    // END, CR00228023

    details.dtls.description = null;
    // END, CR00226647

    // Modify plan template.
    planTemplateObj.modify(key.planTemplateKey, details.dtls);
  }

  // _________________________________________________________________________
  // BEGIN, CR00226905 MN
  /**
   * Modifies the association between the plan template and a plan item.
   *
   * @param key the key of the plan item association
   * @param details the new details for the association
   *
   * @deprecated since Curam v6, replaced with {@link modifyPlanTemplatePlanItem(PlanTemplatePlanItemKey key, PlanTemplateAndPlanItemModifyDetails details)}.
   * The new method modifyPlanTemplatePlanItem modifies a plan item in
   * a plan template along with approval and mandatory indicators.
   * See release note <CR00226905>.
   */
  @Deprecated
  public void modifyPlanItem(PlanTemplatePlanItemKey key,
    curam.serviceplans.sl.struct.PlanTemplatePlanItemModifyDetails details)
    throws AppException, InformationalException {

    PlanTemplateAndPlanItemModifyDetails modifyDetails = new PlanTemplateAndPlanItemModifyDetails();

    modifyDetails.details.authorizedUnits = details.details.authorizedUnits;
    modifyDetails.details.description = details.details.description;
    modifyDetails.details.duration = details.details.duration;
    modifyDetails.details.expectedOutcomeID = details.details.expectedOutcomeID;
    modifyDetails.details.maximumUnits = details.details.maximumUnits;
    modifyDetails.details.planItemID = details.details.planItemID;
    modifyDetails.details.startDay = details.details.startDay;
    modifyDetails.details.versionNo = details.details.versionNo;

    this.modifyPlanTemplatePlanItem(key, modifyDetails);
  }

  // END, CR00226905

  // _________________________________________________________________________

  // BEGIN, CR00229083, GP
  /**
   * Modifies the association between the plan template and an sub goal.
   *
   * @param key the key of the sub goal association
   * @param details the new details for the association
   *
   * @deprecated Since Curam 6.0, replaced with {@link PlanTemplate#
   * modifyPlanTemplateSubGoal()} as part of implementing localization of plan
   * template sub goal description. See release note: CR00229083.
   */
  @Deprecated
  // END, CR00229083
  // BEGIN, CR00233815, GP
  public void modifySubGoal(PlanTemplateSubGoalKey key, curam.serviceplans.sl.struct.PlanTemplateSubGoalModifyDetails details)
    throws AppException, InformationalException {
    // END, CR00233815

    // Plan Template Sub Goal entity
    curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal planTemplateSubGoalObj = curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory.newInstance();

    // modify plan template sub goal
    // BEGIN, CR00000038
    planTemplateSubGoalObj.modifyDetails(key.key, details.details);
    // END, CR00000038
  }

  // BEGIN, CR00228796, GP
  /**
   * Modifies the association between the plan template and a sub goal.
   *
   * @param key contains the key of the sub goal association.
   * @param details contains the new details for the association.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void modifyPlanTemplateSubGoal(PlanTemplateSubGoalKey key,
    PlanTemplateAndSubGoalModifyDetails details) throws AppException,
      InformationalException {

    PlanTemplateSubGoal planTemplateSubGoalObj = PlanTemplateSubGoalFactory.newInstance();

    long descriptionTextID;

    // Modify Localized description.
    if (0 == details.dtls.descriptionTextID) {

      if (!details.dtls.description.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(details.dtls.description,
          LOCALEEntry.get(
          (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }
      // Update the struct passed to modify().
      details.dtls.descriptionTextID = descriptionTextID;

    } else {

      // Handling New data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        details.dtls.descriptionTextID);

      localizableTextHandler.addValue(details.dtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      localizableTextHandler.store();

    }
    details.dtls.description = null;

    planTemplateSubGoalObj.modifyPlanTemplateSubGoalDetails(key.key,
      details.dtls);

  }

  // END, CR00228796

  // _________________________________________________________________________
  /**
   * Reads the details of the plan template.
   *
   * @param key the key of the plan template
   * @return the details of the plan template.
   */
  public ReadPlanTemplateDetails read(PlanTemplateKey key)
    throws AppException, InformationalException {

    // return value
    ReadPlanTemplateDetails readPlanTemplateDetails = new ReadPlanTemplateDetails();

    // Plan Template entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    // Goal entity and manipulation variables
    curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.GoalKey goalKey = new curam.serviceplans.sl.entity.struct.GoalKey();

    // read plan template details
    readPlanTemplateDetails.dtls = planTemplateObj.read(key.planTemplateKey);

    // BEGIN, CR00226647, GP
    // Read the localized name and description.
    if (readPlanTemplateDetails.dtls.nameTextID != 0) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        readPlanTemplateDetails.dtls.nameTextID);

      readPlanTemplateDetails.dtls.name = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    if (readPlanTemplateDetails.dtls.descriptionTextID != 0) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        readPlanTemplateDetails.dtls.descriptionTextID);

      readPlanTemplateDetails.dtls.description = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00226647

    // set goal key
    goalKey.goalID = readPlanTemplateDetails.dtls.goalID;

    // read goal name
    readPlanTemplateDetails.goalName = goalObj.readName(goalKey).name;

    // return plan template details
    return readPlanTemplateDetails;
  }

  // _________________________________________________________________________
  // BEGIN, CR00226779 MN
  /**
   * Reads the details of the association between an plan item and the plan
   * template.
   *
   * @param key the key of association
   * @return the details of the association
   *
   * @deprecated since Curam v6, replaced with {@link readTemplatePlanItem}.
   * The new method readTemplatePlanItem along with the existing functionality
   * reads approval and mandatory indicators. See release note <CR00226779>
   */
  @Deprecated
  public curam.serviceplans.sl.struct.PlanTemplatePlanItemDetails readPlanItem(
    PlanTemplatePlanItemKey key)
    throws AppException, InformationalException {

    curam.serviceplans.sl.struct.PlanTemplatePlanItemDetails readDetails = new curam.serviceplans.sl.struct.PlanTemplatePlanItemDetails();

    PlanTemplateAndPlanItemDetails details = this.readTemplatePlanItem(key);

    readDetails.dtls.authorizedUnits = details.dtls.authorizedUnits;
    readDetails.dtls.description = details.dtls.description;
    readDetails.dtls.duration = details.dtls.duration;
    readDetails.dtls.expectedOutcomeID = details.dtls.expectedOutcomeID;
    readDetails.dtls.expectedOutcomeName = details.dtls.expectedOutcomeName;
    readDetails.dtls.maximumUnits = details.dtls.maximumUnits;
    readDetails.dtls.name = details.dtls.name;
    readDetails.dtls.outcomeRequiredInd = details.dtls.outcomeRequiredInd;
    readDetails.dtls.planItemID = details.dtls.planItemID;
    readDetails.dtls.planTemplatePlanItemID = details.dtls.planTemplatePlanItemID;
    readDetails.dtls.planTemplateSubGoalID = details.dtls.planTemplateSubGoalID;
    readDetails.dtls.startDay = details.dtls.startDay;
    readDetails.dtls.versionNo = details.dtls.versionNo;

    return readDetails;
  }

  // END, CR00226779
  // _________________________________________________________________________

  // BEGIN, CR00229083, GP
  /**
   * Reads the details of the association between an sub goal and the plan
   * template.
   *
   * @param key the key of the association
   * @return the details of the association
   *
   * @deprecated Since Curam 6.0, replaced with {@link PlanTemplate#
   * readTemplateSubGoal()} as part of implementing localization of plan
   * template sub goal description. See release note: CR00229083.
   */
  @Deprecated
  // END, CR00229083
  public PlanTemplateSubGoalDetails readSubGoal(PlanTemplateSubGoalKey key)
    throws AppException, InformationalException {

    // Plan Template Sub Goal entity
    curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal planTemplateSubGoalObj = curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory.newInstance();

    // return value
    PlanTemplateSubGoalDetails planTemplateSubGoalDetails = new PlanTemplateSubGoalDetails();

    // read plan template plan item details
    planTemplateSubGoalDetails.dtls = planTemplateSubGoalObj.readDetails(
      key.key);

    // return plan template plan item details
    return planTemplateSubGoalDetails;
  }

  // BEGIN, CR00229083, GP
  /**
   * Reads the details of the association between a sub goal and the plan
   * template.
   *
   * @param key contains the key of the association.
   *
   * @return the details of the association.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public PlanTemplateAndSubGoalReadDetails readTemplateSubGoal(
    PlanTemplateSubGoalKey key) throws AppException, InformationalException {

    PlanTemplateSubGoal planTemplateSubGoalObj = PlanTemplateSubGoalFactory.newInstance();
    PlanTemplateAndSubGoalReadDetails planTemplateAndSubGoalReadDetails = new
      PlanTemplateAndSubGoalReadDetails();

    planTemplateAndSubGoalReadDetails.dtls = planTemplateSubGoalObj.readTemplateSubGoalDetails(
      key.key);

    // Read the localized description.
    if (0 != planTemplateAndSubGoalReadDetails.dtls.descriptionTextID) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        planTemplateAndSubGoalReadDetails.dtls.descriptionTextID);

      planTemplateAndSubGoalReadDetails.dtls.description = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }

    return planTemplateAndSubGoalReadDetails;
  }

  // END, CR00229083

  // _________________________________________________________________________
  /**
   * Reorders an item within the plan template.  The exact item to change and
   * whether it is to be moved up or down is contained in the instruction.
   * Once the reorder operation is complete the resulting plan template GANTT
   * chart is returned in XML form
   *
   * @param key the key of the plan template
   * @param instruction provides the details of the reorder operation
   * @return the new XML data for the chart
   */
  public PlanTemplateChart reorderDetails(PlanTemplateKey key, PlanTemplateReorderInstruction instruction)
    throws AppException, InformationalException {
    return null;
  }

  // ___________________________________________________________________________
  /**
   * Cancels a plan template.
   *
   * @param details the key of the plan template
   */
  public void cancel(CancelPlanTemplateDetails details)
    throws AppException, InformationalException {

    // Plan Template entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    curam.serviceplans.sl.entity.struct.PlanTemplateCancelDetails planTemplateCancelDetails = new curam.serviceplans.sl.entity.struct.PlanTemplateCancelDetails();
    curam.serviceplans.sl.entity.struct.PlanTemplateKey planTemplateKey = new curam.serviceplans.sl.entity.struct.PlanTemplateKey();

    // Set version number
    planTemplateCancelDetails.versionNo = details.versionNo;

    // Set record status to CANCELLED
    planTemplateCancelDetails.recordStatus = RECORDSTATUS.CANCELLED;

    // set plan template key
    planTemplateKey.planTemplateID = details.planTemplateID;

    // cancel plan template
    planTemplateObj.cancel(planTemplateKey, planTemplateCancelDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads plan template plan item name.
   *
   * @param key the key of the plan template planItem
   * @return PlanItem name
   */
  public PlanItemNameDetails readPlanItemName(PlanTemplatePlanItemKey key)
    throws AppException, InformationalException {

    // Plan Template PlanItem entity
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem planTemplatePlanItemObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory.newInstance();

    // return value
    PlanItemNameDetails planItemNameDetails = new PlanItemNameDetails();

    // read plan item name
    planItemNameDetails.templatePlanItemNameDetails = planTemplatePlanItemObj.readPlanItemName(
      key.key);

    // return plan item name details
    return planItemNameDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads plan template sub goal name.
   *
   * @param key the key of the plan template sub goal
   * @return Sub Goal name
   */
  public SubGoalNameDetails readSubGoalName(PlanTemplateSubGoalKey key)
    throws AppException, InformationalException {

    // Plan Template Sub Goal entity
    curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal planTemplateSubGoalObj = curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory.newInstance();

    // return value
    SubGoalNameDetails subGoalNameDetails = new SubGoalNameDetails();

    // read sub goal name
    subGoalNameDetails.subGoalNameDetails = planTemplateSubGoalObj.readSubGoalName(
      key.key);

    // return plan item name details
    return subGoalNameDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads plan template name.
   *
   * @param key the key of the plan template
   * @return Template name
   */
  public PlanTemplateNameDetails readTemplateName(PlanTemplateKey key)
    throws AppException, InformationalException {

    // Plan Template entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    // return value
    PlanTemplateNameDetails planTemplateNameDetails = new PlanTemplateNameDetails();

    // Read the template name.

    // BEGIN, CR00226647, GP
    PlanTemplateNameAndNameTextID planTemplateNameAndNameTextID = new
      PlanTemplateNameAndNameTextID();

    planTemplateNameAndNameTextID = planTemplateObj.readPlanTemplateName(
      key.planTemplateKey);

    // Read the localized name and description.
    if (planTemplateNameAndNameTextID.nameTextID != 0) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        planTemplateNameAndNameTextID.nameTextID);

      planTemplateNameDetails.details.name = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    } else {
      planTemplateNameDetails.details.name = planTemplateNameAndNameTextID.name;
    }

    // END, CR00226647

    // return plan item name details
    return planTemplateNameDetails;
  }

  // ___________________________________________________________________________
  /**
   * Lists all sub goals associated with the plan template.
   *
   * @param key Plan Template unique identifier
   *
   * @return The list sub goals associated with plan template
   */
  public TemplateSubGoalDetailsList listSubGoals(PlanTemplateKey key)
    throws AppException, InformationalException {

    // Plan Template Sub Goal entity
    curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal planTemplateSubGoalObj = curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory.newInstance();

    // return value
    curam.serviceplans.sl.struct.TemplateSubGoalDetailsList templateSubGoalDetailsList = new TemplateSubGoalDetailsList();

    // list sub goals
    templateSubGoalDetailsList.templateSubGoalDetailsList = planTemplateSubGoalObj.searchByPlanTemplateID(
      key.planTemplateKey);

    return templateSubGoalDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all plan template planItems associated with the plan template.
   *
   * @param key Plan Template unique identifier
   *
   * @return The list of plan template planItems associated with plan template
   */
  public TemplatePlanItemDetailsList listPlanItemsForTemplate(PlanTemplateKey key)
    throws AppException, InformationalException {

    // Plan Template PlanItem entity
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem planTemplatePlanItemObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory.newInstance();

    // return value
    curam.serviceplans.sl.struct.TemplatePlanItemDetailsList templatePlanItemDetailsList = new TemplatePlanItemDetailsList();

    // list planItems
    templatePlanItemDetailsList.templatePlanItemDetailsList = planTemplatePlanItemObj.searchByPlanTemplateID(
      key.planTemplateKey);

    return templatePlanItemDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Lists all plan template planItems associated with the plan template sub goal.
   *
   * @param key Plan Template Sub Goal unique identifier
   *
   * @return The list of plan template planItems associated with plan template
   * sub goal
   */
  public TemplatePlanItemDetailsList listPlanItemsForTemplateSubGoal(PlanTemplateSubGoalKey key)
    throws AppException, InformationalException {

    // Plan Template PlanItem entity
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem planTemplatePlanItemObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory.newInstance();

    // return value
    curam.serviceplans.sl.struct.TemplatePlanItemDetailsList templatePlanItemDetailsList = new TemplatePlanItemDetailsList();

    // list planItems
    templatePlanItemDetailsList.templatePlanItemDetailsList = planTemplatePlanItemObj.searchByPlanTemplateSubGoalID(
      key.key);

    return templatePlanItemDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Returns list of planTemplateIDs and planTemplateNames for all plan
   * templates assigned to a service plan.
   *
   * @param key Service Plan unique identifier
   *
   * @return The list of plan template IDs and plan template names associated
   * with service plan
   */
  public PlanTemplateNameAndIDDetailsList listByServicePlan(ServicePlanKey key)
    throws AppException, InformationalException {

    // return value
    PlanTemplateNameAndIDDetailsList planTemplateNameAndIDDetailsList = new PlanTemplateNameAndIDDetailsList();

    // PlanTemplateServicePlanLink entity
    curam.serviceplans.sl.entity.intf.PlanTemplateServicePlanLink planTemplateServicePlanLinkObj = curam.serviceplans.sl.entity.fact.PlanTemplateServicePlanLinkFactory.newInstance();

    // BEGIN, CR00226647, GP
    PlanTemplateLocalizedNameAndIDList planTemplateLocalizedNameAndIDList = new
      PlanTemplateLocalizedNameAndIDList();
    curam.serviceplans.sl.entity.struct.ServicePlanKey servicePlanKey = new
      curam.serviceplans.sl.entity.struct.ServicePlanKey();
    PlanTemplateNameAndIDDetails planTemplateNameAndIDDetails;

    servicePlanKey.servicePlanID = key.key.servicePlanID;

    planTemplateLocalizedNameAndIDList = planTemplateServicePlanLinkObj.searchLocalizedNameByServicePlanID(
      servicePlanKey);
    planTemplateNameAndIDDetailsList.list.dtls.ensureCapacity(
      planTemplateLocalizedNameAndIDList.dtls.size());

    for (PlanTemplateLocalizedNameAndID planTemplateLocalizedNameAndID :
      planTemplateLocalizedNameAndIDList.dtls.items()) {

      planTemplateNameAndIDDetails = new PlanTemplateNameAndIDDetails();

      planTemplateNameAndIDDetails.planTemplateID = planTemplateLocalizedNameAndID.planTemplateID;

      // Check if localized name is found.
      if (0 != planTemplateLocalizedNameAndID.nameTextID) {

        LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          planTemplateLocalizedNameAndID.nameTextID);

        planTemplateNameAndIDDetails.name = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      } else {

        planTemplateNameAndIDDetails.name = planTemplateLocalizedNameAndID.name;
      }

      planTemplateNameAndIDDetailsList.list.dtls.addRef(
        planTemplateNameAndIDDetails);
    }
    // END, CR00226647


    // return the list
    return planTemplateNameAndIDDetailsList;
  }

  // ___________________________________________________________________________
  // BEGIN, CR00226899 MN
  /**
   * Reads goalID, list of sub goal details for the goal and list of planItem
   * details for each sub goal.
   *
   * @param key Plan Template unique identifier
   *
   * @return The goal ID, list of plan template sub goals associated with the goal
   * and list of planItems associated with each plan template sub goal
   *
   * @deprecated since Curam v6 replaced with {@link(listServicePlanGoalSubGoalAndPlanItems)}
   * This new method listServicePlanGoalSubGoalAndPlanItems along with the
   * existing functionality reads approval and mandatory indicators.
   * See release note <CR00226899>.
   */
  @Deprecated
  public curam.serviceplans.sl.struct.GoalSubGoalsAndPlanItemsDetails listGoalSubGoalAndPlanItems(PlanTemplateKey key)
    throws AppException, InformationalException {

    ServicePlanGoalSubGoalsAndPlanItemsDetails details = this.listServicePlanGoalSubGoalAndPlanItems(
      key);

    curam.serviceplans.sl.struct.GoalSubGoalsAndPlanItemsDetails goalsAndPlanItemsDetails = new curam.serviceplans.sl.struct.GoalSubGoalsAndPlanItemsDetails();

    curam.serviceplans.sl.entity.struct.PlanItemAndPlanTemplatePlanItemDetails planItemDetails = new curam.serviceplans.sl.entity.struct.PlanItemAndPlanTemplatePlanItemDetails();

    PlanItemAndTemplatePlanItemDetails templatePlanItemDetails = null;

    SubGoalAndPlanTemplatePlanItemsDetails templateSubGoalDetails = new SubGoalAndPlanTemplatePlanItemsDetails();

    curam.serviceplans.sl.struct.SubGoalAndPlanItemsDetails subGoalDetails = new curam.serviceplans.sl.struct.SubGoalAndPlanItemsDetails();

    if (details.subGoalAndPlanTemplatePlanItemsDetails != null) {
      for (int i = 0; i < details.subGoalAndPlanTemplatePlanItemsDetails.size(); i++) {
        templateSubGoalDetails = details.subGoalAndPlanTemplatePlanItemsDetails.get(
          i);
        for (int j = 0; j
          < templateSubGoalDetails.planItemAndTemplatePlanItemDetailsList.dtls.size(); j++) {

          templatePlanItemDetails = templateSubGoalDetails.planItemAndTemplatePlanItemDetailsList.dtls.get(
            j);

          planItemDetails.authorizedUnits = templatePlanItemDetails.authorizedUnits;
          planItemDetails.cost = templatePlanItemDetails.cost;
          planItemDetails.duration = templatePlanItemDetails.duration;
          planItemDetails.expectedOutcomeID = templatePlanItemDetails.expectedOutcomeID;
          planItemDetails.maximumUnits = templatePlanItemDetails.maximumUnits;
          planItemDetails.planItemID = templatePlanItemDetails.planItemID;
          planItemDetails.sensitivityCode = templatePlanItemDetails.sensitivityCode;
          planItemDetails.startDay = templatePlanItemDetails.startDay;
          subGoalDetails.planItemAndPlanTemplatePlanItemDetailsList.dtls.add(
            planItemDetails);
          subGoalDetails.subGoalID = templateSubGoalDetails.subGoalID;
          subGoalDetails.planTemplateSubGoalID = templateSubGoalDetails.planTemplateSubGoalID;
        }
        goalsAndPlanItemsDetails.subGoalAndPlanItemsDetails.add(subGoalDetails);
        goalsAndPlanItemsDetails.goalID = details.goalID;

      }
    }
    return goalsAndPlanItemsDetails;
  }

  // END, CR00226899
  // ___________________________________________________________________________
  /**
   * Reads plan item name and expected outcome name for plan template planItem.
   *
   * @param key planItemID and expectedOutcomeID
   *
   * @return PlanItem name and outcome name
   */
  public PlanItemAndOutcomeNameDetails readPlanItemAndOutcomeName(
    PlanItemAndOutcomeKey key)
    throws AppException, InformationalException {

    // return value
    PlanItemAndOutcomeNameDetails planItemAndOutcomeNameDetails = new PlanItemAndOutcomeNameDetails();

    // PlanItem entity
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // Outcome entity
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();

    // read plan item name
    planItemAndOutcomeNameDetails.planItemNameDetails = planItemObj.readName(
      key.planItemKey);

    // read outcome name
    planItemAndOutcomeNameDetails.outcomeNameDetails = outcomeObj.readName(
      key.outcomeKey);

    return planItemAndOutcomeNameDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads details about all goals available to be added to a plan template
   *
   * @param currentGoal current plan template goal
   * @return Goal name and ID details list
   */
  public GoalNameAndIDDetailsList listAvailableGoals(GoalNameAndIDDetails currentGoal)
    throws AppException, InformationalException {

    // to be returned
    GoalNameAndIDDetailsList retList = new GoalNameAndIDDetailsList();

    // Goal entity and manipulation variables
    curam.serviceplans.sl.entity.intf.Goal goalObj = curam.serviceplans.sl.entity.fact.GoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.GoalStatusDetails goalStatusDetails = new curam.serviceplans.sl.entity.struct.GoalStatusDetails();
    curam.serviceplans.sl.entity.struct.GoalNameAndIDDetails goalNameAndIDDetails = new curam.serviceplans.sl.entity.struct.GoalNameAndIDDetails();

    // set goal status
    goalStatusDetails.recordStatus = RECORDSTATUS.NORMAL;

    // list all existing active goals
    curam.serviceplans.sl.entity.struct.GoalNameAndIDDetailsList goalNameAndIDDetailsList = goalObj.listGoalDetailsByStatus(
      goalStatusDetails);

    // index of the current goal in the list
    int index = -1;

    // find current goal in the list
    for (int i = 0; i < goalNameAndIDDetailsList.dtls.size(); i++) {
      if (currentGoal.details.goalID
        == goalNameAndIDDetailsList.dtls.item(i).goalID) {
        index = i;
        break;
      }
    }

    if (index >= 0) {
      goalNameAndIDDetails.assign(goalNameAndIDDetailsList.dtls.item(index));
      goalNameAndIDDetailsList.dtls.remove(index);
      goalNameAndIDDetailsList.dtls.add(0, goalNameAndIDDetails);
    }

    retList.goalNameAndIDDetailsList = goalNameAndIDDetailsList;

    return retList;
  }

  // BEGIN, CR00000028, PMD
  // _________________________________________________________________________
  /**
   * Creates a plan group for a service plan template
   *
   * @param details the details of the new plan group
   * @return the key of the new plan group
   */
  public PlanTemplatePlanGroupKey createPlanGroup(PlanTemplatePlanGroupDetails details)
    throws AppException, InformationalException {

    // Return Object
    PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new PlanTemplatePlanGroupKey();

    // Plan Template Plan Group Entity
    PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();

    // BEGIN, CR00235328, GP
    PlanTemplatePlanGroupCount planTemplatePlanGroupCount = new
      PlanTemplatePlanGroupCount();

    PlanTemplatePlanGroupNameAndTemplateIDKey planTemplatePlanGroupNameAndTemplateIDKey = new
      PlanTemplatePlanGroupNameAndTemplateIDKey();

    // Trim empty spaces from both sides of the string.
    details.dtls.name = details.dtls.name.trim();

    if (0 == details.dtls.name.length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATEPLANGROUP.ERR_PLAN_GROUP_FV_NAME_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    StringBuffer name = new StringBuffer(details.dtls.name);

    // If there is a space between the words longer than one reduce it to
    // exactly one space.

    char prevChar = name.charAt(0);
    int index = 0;

    for (char c : name.toString().toCharArray()) {
      if ((c == CuramConst.gkSpaceChar) && prevChar == CuramConst.gkSpaceChar) {
        name.deleteCharAt(index);
      }
      prevChar = c;
      index++;
    }

    details.dtls.name = name.toString();

    planTemplatePlanGroupNameAndTemplateIDKey.name = details.dtls.name;
    planTemplatePlanGroupNameAndTemplateIDKey.planTemplateID = details.dtls.planTemplateID;

    // Check the legacy records for duplicates.
    // Count plan groups by name and template id.
    planTemplatePlanGroupCount = planTemplatePlanGroupObj.countByNameAndTemplateID(
      planTemplatePlanGroupNameAndTemplateIDKey);

    if (0 != planTemplatePlanGroupCount.count) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANGROUP.ERR_PLAN_GROUP_XFV_NAME_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check the localized records for duplicates.
    TextTranslation TextTranslationObj = TextTranslationFactory.newInstance();
    TextCount textCount = new TextCount();
    GroupCodeAndLocaleKey groupCodeAndLocaleKey = new GroupCodeAndLocaleKey();

    groupCodeAndLocaleKey.groupCode = LOCALIZABLETEXTGROUPCODE.PLANTEMPLATEPLANGROUPNAME;
    groupCodeAndLocaleKey.localeCode = LOCALEEntry.get((ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())).toString();
    groupCodeAndLocaleKey.name = details.dtls.name;
    textCount = TextTranslationObj.countByGroupCodeAndLocale(
      groupCodeAndLocaleKey);

    if (0 != textCount.count) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANGROUP.ERR_PLAN_GROUP_XFV_NAME_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    // Localize name and comments.
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.setGroupCode(
      LOCALIZABLETEXTGROUPCODE.PLANTEMPLATEPLANGROUPNAME);
    localizableTextHandler.addValue(details.dtls.name,
      LOCALEEntry.get(
      (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
    details.dtls.nameTextID = localizableTextHandler.store();

    localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!details.dtls.comments.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(details.dtls.comments,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      details.dtls.commentsTextID = localizableTextHandler.store(
        );
    } else {
      // If comments is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      details.dtls.commentsTextID = localizableTextHandler.store(
        );
    }
    details.dtls.comments = null;
    details.dtls.name = null;
    // END, CR00235328

    // Create the plan group
    planTemplatePlanGroupObj.insert(details.dtls);

    // Set the plan template plan group key
    planTemplatePlanGroupKey.key.planTemplatePlanGroupID = details.dtls.planTemplatePlanGroupID;

    // BEGIN, CR00020193, PMD
    // Set the id and type of the template item added
    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    templateItemDetails.templateItemObjID = String.valueOf(
      planTemplatePlanGroupKey.key.planTemplatePlanGroupID);
    templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplatePlanGroup;
    postUpdateTemplateItem(templateItemDetails);
    // END, CR00020193

    return planTemplatePlanGroupKey;
  }

  // BEGIN, CR00235328, GP
  /**
   * Modifies a plan group for a service plan template
   *
   * @param key the plan group key
   * @param details the updated plan group details
   * @deprecated Since Curam 6.0, replaced with {@link PlanTemplate#
   * modifyPlanTemplatePlanGroup()} as part of implementing localization of
   * plan template plan group attributes. See release note: CR00235328.
   */
  @Deprecated
  // END, CR00235328
  public void modifyPlanGroup(PlanTemplatePlanGroupKey key, PlanTemplatePlanGroupModifyDetails details)
    throws AppException, InformationalException {

    // Plan Template Plan Group Entity
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanGroup planTemplatePlanGroupObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanGroupFactory.newInstance();

    // Modify the plan group
    planTemplatePlanGroupObj.modifyDetails(key.key, details.details);

  }

  // BEGIN, CR00235328, GP
  /**
   * Modifies a plan group for a service plan template.
   *
   * @param key contains the plan group key.
   * @param details the updated plan group details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyTemplatePlanGroup(PlanTemplatePlanGroupDtls
    planTemplatePlanGroupDtls) throws AppException, InformationalException {

    long commentsTextID, nameTextID;
    PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();
    PlanTemplatePlanGroupKey key = new PlanTemplatePlanGroupKey();
    PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new
      PlanTemplatePlanGroupKey();
    PlanTemplatePlanGroupCount planTemplatePlanGroupCount = new
      PlanTemplatePlanGroupCount();
    TemplatePlanGroupNameDetails templatePlanGroupNameDetails = new
      TemplatePlanGroupNameDetails();
    PlanTemplatePlanGroupNameDetails planTemplatePlanGroupNameDetails = new
      PlanTemplatePlanGroupNameDetails();
    PlanTemplatePlanGroupNameAndTemplateIDKey planTemplatePlanGroupNameAndTemplateIDKey = new
      PlanTemplatePlanGroupNameAndTemplateIDKey();
    curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupModifyDetails details = new curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupModifyDetails();
    PlanTemplatePlanGroupCommentsTextID planTemplatePlanGroupCommentsTextID = new PlanTemplatePlanGroupCommentsTextID();
    PlanTemplatePlanGroupNameTextID planTemplatePlanGroupNameTextID = new
      PlanTemplatePlanGroupNameTextID();

    key.key.planTemplatePlanGroupID = planTemplatePlanGroupDtls.planTemplatePlanGroupID;
    details.assign(planTemplatePlanGroupDtls);

    // Trim empty spaces from both sides of the string.
    details.name = planTemplatePlanGroupDtls.name.trim();

    if (details.name.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATEPLANGROUP.ERR_PLAN_GROUP_FV_NAME_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    StringBuffer name = new StringBuffer(details.name);

    // If there is a space between the words longer than one reduce it to
    // exactly one space.
    for (int i = 0; i < name.length(); i++) {
      if ((name.charAt(i) == CuramConst.gkSpaceChar)
        && (name.charAt(i + 1) == CuramConst.gkSpaceChar)) {
        name.deleteCharAt(i + 1);
        i--;
      }
    }

    details.name = name.toString();
    planTemplatePlanGroupKey.key.planTemplatePlanGroupID = planTemplatePlanGroupDtls.planTemplatePlanGroupID;

    planTemplatePlanGroupNameDetails = planTemplatePlanGroupObj.readNameDetails(
      planTemplatePlanGroupKey.key);

    // Read the localized name.
    if (0 != planTemplatePlanGroupNameDetails.nameTextID) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        planTemplatePlanGroupNameDetails.nameTextID);

      templatePlanGroupNameDetails.name = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }

    // If name is modified, the new name must be unique.
    if (!templatePlanGroupNameDetails.name.equals(details.name)) {

      planTemplatePlanGroupNameAndTemplateIDKey.name = details.name;
      planTemplatePlanGroupNameAndTemplateIDKey.planTemplateID = planTemplatePlanGroupDtls.planTemplateID;

      // Count plan groups by name and template id.
      planTemplatePlanGroupCount = planTemplatePlanGroupObj.countByNameAndTemplateID(
        planTemplatePlanGroupNameAndTemplateIDKey);

      if (planTemplatePlanGroupCount.count > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANTEMPLATEPLANGROUP.ERR_PLAN_GROUP_XFV_NAME_EXISTS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            1);
      }
    }

    // Check the localized records for duplicates.
    TextTranslation TextTranslationObj = TextTranslationFactory.newInstance();
    TextCount textCount = new TextCount();
    GroupCodeAndLocaleKey groupCodeAndLocaleKey = new GroupCodeAndLocaleKey();

    groupCodeAndLocaleKey.groupCode = LOCALIZABLETEXTGROUPCODE.PLANTEMPLATEPLANGROUPNAME;
    groupCodeAndLocaleKey.localeCode = LOCALEEntry.get((ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())).toString();
    groupCodeAndLocaleKey.name = details.name;
    textCount = TextTranslationObj.countByGroupCodeAndLocale(
      groupCodeAndLocaleKey);

    if (textCount.count > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANGROUP.ERR_PLAN_GROUP_XFV_NAME_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);
    }

    // Modify Localized name.
    if (0 == planTemplatePlanGroupDtls.nameTextID) {

      // Handling Legacy data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.setGroupCode(
        LOCALIZABLETEXTGROUPCODE.PLANTEMPLATEPLANGROUPNAME);
      localizableTextHandler.setShortTextInd(true);
      localizableTextHandler.addValue(details.name,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      nameTextID = localizableTextHandler.store();

      // Update in entity.
      planTemplatePlanGroupNameTextID.nameTextID = nameTextID;
      planTemplatePlanGroupNameTextID.versionNo = planTemplatePlanGroupDtls.versionNo;
      planTemplatePlanGroupObj.modifyNameTextID(planTemplatePlanGroupKey.key,
        planTemplatePlanGroupNameTextID);
    } else {

      // Handling New data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplatePlanGroupDtls.nameTextID);

      localizableTextHandler.addValue(details.name,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      localizableTextHandler.store();
    }

    // Modify Localized comments.
    if (0 == planTemplatePlanGroupDtls.commentsTextID) {

      if (!planTemplatePlanGroupDtls.comments.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(planTemplatePlanGroupDtls.comments,
          LOCALEEntry.get(
          (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
        commentsTextID = localizableTextHandler.store();
      } else {
        // If comments is empty, just create localizableTextID.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        commentsTextID = localizableTextHandler.store();
      }

      // Update the entity.
      planTemplatePlanGroupCommentsTextID.commentsTextID = commentsTextID;
      planTemplatePlanGroupCommentsTextID.versionNo = planTemplatePlanGroupDtls.versionNo;
      planTemplatePlanGroupObj.modifyCommentsTextID(
        planTemplatePlanGroupKey.key, planTemplatePlanGroupCommentsTextID);

    } else {

      // Handling New data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplatePlanGroupDtls.commentsTextID);

      localizableTextHandler.addValue(planTemplatePlanGroupDtls.comments,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      localizableTextHandler.store();

    }
    details.name = null;
    details.comments = null;

    planTemplatePlanGroupObj.modifyDetails(key.key, details);
  }

  // END, CR00235328

  // _________________________________________________________________________
  /**
   * Reads plan group details for a service plan template
   *
   * @param key the plan group key
   * @return the plan group details
   */
  public PlanTemplatePlanGroupDetails readPlanGroup(PlanTemplatePlanGroupKey key)
    throws AppException, InformationalException {

    // Return Object
    PlanTemplatePlanGroupDetails planTemplatePlanGroupDetails = new PlanTemplatePlanGroupDetails();

    // Plan Template Plan Group Entity
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanGroup planTemplatePlanGroupObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanGroupFactory.newInstance();

    // Read Plan Template Plan Group Details
    planTemplatePlanGroupDetails.dtls = planTemplatePlanGroupObj.read(key.key);

    // BEGIN, CR00235328, GP
    // Read the localized name.
    if (planTemplatePlanGroupDetails.dtls.nameTextID != 0) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        planTemplatePlanGroupDetails.dtls.nameTextID);

      planTemplatePlanGroupDetails.dtls.name = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // Read the localized comments.
    if (0 != planTemplatePlanGroupDetails.dtls.commentsTextID) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        planTemplatePlanGroupDetails.dtls.commentsTextID);

      planTemplatePlanGroupDetails.dtls.comments = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00235328

    return planTemplatePlanGroupDetails;
  }

  // _________________________________________________________________________
  /**
   * Removes plan group details for a service plan template(physical delete)
   *
   * @param key the plan group key
   */
  public void removePlanGroup(PlanTemplatePlanGroupKey key)
    throws AppException, InformationalException {

    // Plan Template Plan Group Entity
    PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();

    // BEGIN, CR00020193, PMD
    // Read the planTemplateID and parentGroupID, so that we know which node
    // to return to in the tree control
    PlanTemplateIDAndParentGroupID planTemplateIDAndParentGroupID = new PlanTemplateIDAndParentGroupID();

    planTemplateIDAndParentGroupID = planTemplatePlanGroupObj.readPlanTemplateIDAndParentGroupID(
      key.key);
    // END, CR00020193

    // Remove the Plan Template Plan Group
    planTemplatePlanGroupObj.remove(key.key);

    // BEGIN, CR00020193, PMD
    // Set the id and type of the template item to return to
    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    if (planTemplateIDAndParentGroupID.parentGroupID != 0) {

      // The removed plan group was part of a parent plan group,
      // return the user to this plan group
      templateItemDetails.templateItemObjID = String.valueOf(
        planTemplateIDAndParentGroupID.parentGroupID);
      templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplatePlanGroup;

    } else {

      // The removed plan group was not part of a parent plan group,
      // return the user to template home
      templateItemDetails.templateItemObjID = String.valueOf(
        planTemplateIDAndParentGroupID.planTemplateID);
      templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplate;

    }

    postUpdateTemplateItem(templateItemDetails);
    // END, CR00020193

  }

  // _________________________________________________________________________
  /**
   * Reads a plan group name
   *
   * @param key the plan group key
   * @return the plan group name details
   */
  public PlanGroupNameDetails readPlanGroupName(PlanTemplatePlanGroupKey key)
    throws AppException, InformationalException {

    // Return Object
    PlanGroupNameDetails planGroupNameDetails = new PlanGroupNameDetails();

    // Plan Template Plan Group Entity
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanGroup planTemplatePlanGroupObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanGroupFactory.newInstance();

    // BEGIN, CR00235328, GP
    PlanTemplatePlanGroupNameDetails planTemplatePlanGroupNameDetails = new
      PlanTemplatePlanGroupNameDetails();

    planTemplatePlanGroupNameDetails = planTemplatePlanGroupObj.readNameDetails(
      key.key);

    // Read the localized name.
    if (0 != planTemplatePlanGroupNameDetails.nameTextID) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        planTemplatePlanGroupNameDetails.nameTextID);

      planGroupNameDetails.planGroupNameDetails.name = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00235328

    return planGroupNameDetails;
  }

  // END, CR00000028

  // BEGIN, CR00000034, PMD
  // ___________________________________________________________________________
  // BEGIN, CR00226779 MN
  /**
   * Reads plan item details and a list of plan item names
   *
   * @param key contains the plan item key and the plan template sub goal key
   *
   * @return list of plan items available for modification and the template plan item details
   *
   * @deprecated since Curam v6, replaced with {@link readPlanTemplatePlanItemForModify}.
   * The new method readPlanTemplatePlanItemForModify has been introduced
   * which along with the existing functionality reads approval and
   * mandatory indicators. See release note <CR00226779>
   */
  @Deprecated
  public curam.serviceplans.sl.struct.ReadTemplatePlanItemForModifyDetails readTemplatePlanItemForModify(ReadTemplatePlanItemForModifyKey key)
    throws AppException, InformationalException {

    ReadPlanTemplatePlanItemForModifyDetails details = this.readPlanTemplatePlanItemForModify(
      key);

    curam.serviceplans.sl.struct.ReadTemplatePlanItemForModifyDetails modifyDetails = new curam.serviceplans.sl.struct.ReadTemplatePlanItemForModifyDetails();

    modifyDetails.planItemDetails.authorizedUnits = details.details.authorizedUnits;
    modifyDetails.planItemDetails.description = details.details.description;
    modifyDetails.planItemDetails.duration = details.details.duration;
    modifyDetails.planItemDetails.expectedOutcomeID = details.details.expectedOutcomeID;
    modifyDetails.planItemDetails.expectedOutcomeName = details.details.expectedOutcomeName;
    modifyDetails.planItemDetails.maximumUnits = details.details.maximumUnits;
    modifyDetails.planItemDetails.name = details.details.name;
    modifyDetails.planItemDetails.outcomeRequiredInd = details.details.outcomeRequiredInd;
    modifyDetails.planItemDetails.planItemID = details.details.planItemID;
    modifyDetails.planItemDetails.planTemplatePlanItemID = details.details.planTemplatePlanItemID;
    modifyDetails.planItemDetails.planTemplateSubGoalID = details.details.planTemplateSubGoalID;
    modifyDetails.planItemDetails.startDay = details.details.startDay;
    modifyDetails.planItemDetails.versionNo = details.details.versionNo;

    return modifyDetails;
  }

  // END, CR00226779
  // END, CR00000034


  // BEGIN, CR00000038, CSH
  // _________________________________________________________________________

  // BEGIN, CR00229083, GP
  /**
   * Lists all sub goals not currently associated with a plan template,
   * along with the sub-goal selected for modification.
   *
   * @param key The key of the plan template which contains the sub-goal
   * to be modified and the subgoal key
   * @return list of sub-goals available for modification and the template sub-goal details
   *
   * @deprecated Since Curam 6.0, replaced with {@link PlanTemplate#
   * readPlanTemplateSubGoalForModify()} as part of implementing localization of plan
   * template sub goal description. See release note : CR00229083.
   */
  @Deprecated
  // END, CR00229083
  // BEGIN, CR00233815, GP
  public curam.serviceplans.sl.struct.ReadTemplateSubGoalForModifyDetails readTemplateSubGoalForModify(
    ReadTemplateSubGoalForModifyKey key) throws AppException, InformationalException {
    // END, CR00233815

    // Plan Template Sub Goal Entity
    curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal planTemplateSubGoalObj = curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory.newInstance();

    curam.serviceplans.sl.entity.struct.ListTemplateSubGoalsForModifyKey listTemplateSubGoalsForModifyKey = new curam.serviceplans.sl.entity.struct.ListTemplateSubGoalsForModifyKey();

    // Return Object
    // BEGIN, CR00233815, GP
    curam.serviceplans.sl.struct.ReadTemplateSubGoalForModifyDetails readTemplateSubGoalForModifyDetails = new curam.serviceplans.sl.struct.ReadTemplateSubGoalForModifyDetails();

    // END, CR00233815

    // Get the sub-goal details
    readTemplateSubGoalForModifyDetails.subGoalDetails = planTemplateSubGoalObj.readDetails(
      key.planTemplateSubGoalKey);

    // set the plan template key, sub-goal key
    listTemplateSubGoalsForModifyKey.planTemplateID = key.planTemplateKey.planTemplateID;
    listTemplateSubGoalsForModifyKey.subGoalID = key.subGoalKey.subGoalID;
    listTemplateSubGoalsForModifyKey.recordStatus = RECORDSTATUS.NORMAL;

    // read sub-goals list
    readTemplateSubGoalForModifyDetails.subGoalNameList = planTemplateSubGoalObj.searchTemplateSubGoalsForModify(
      listTemplateSubGoalsForModifyKey);

    return readTemplateSubGoalForModifyDetails;
  }

  // END, CR00000038

  // BEGIN, CR00229083, GP
  /**
   * Lists all sub goals not currently associated with a plan template,
   * along with the sub-goal selected for modification.
   *
   * @param key contains the key of the plan template which contains the
   * sub-goal to be modified and the subgoal key.
   *
   * @return list of sub-goals available for modification and the template
   * sub-goal details.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public ReadTemplateAndSubGoalForModifyDetails readPlanTemplateSubGoalForModify(
    ReadTemplateSubGoalForModifyKey key) throws AppException,
      InformationalException {

    PlanTemplateSubGoal planTemplateSubGoalObj = PlanTemplateSubGoalFactory.newInstance();
    ListTemplateSubGoalsForModifyKey listTemplateSubGoalsForModifyKey = new ListTemplateSubGoalsForModifyKey();
    ReadTemplateAndSubGoalForModifyDetails readTemplateAndSubGoalForModifyDetails = new
      ReadTemplateAndSubGoalForModifyDetails();

    // Get the sub-goal details.
    readTemplateAndSubGoalForModifyDetails.dtls.dtls = planTemplateSubGoalObj.readTemplateSubGoalDetails(
      key.planTemplateSubGoalKey);

    listTemplateSubGoalsForModifyKey.planTemplateID = key.planTemplateKey.planTemplateID;
    listTemplateSubGoalsForModifyKey.subGoalID = key.subGoalKey.subGoalID;
    listTemplateSubGoalsForModifyKey.recordStatus = RECORDSTATUS.NORMAL;

    // Read the list of sub goals.
    readTemplateAndSubGoalForModifyDetails.subGoalNameList = planTemplateSubGoalObj.searchTemplateSubGoalsForModify(
      listTemplateSubGoalsForModifyKey);

    return readTemplateAndSubGoalForModifyDetails;

  }

  // END, CR00229083

  // BEGIN, CR00000022, PMD
  // _________________________________________________________________________
  // BEGIN, CR00226779 MN
  /**
   * Associates a plan item with the plan template. A plan template plan item is
   * used to associate the plan item with a plan template sub goal
   *
   * @param details The details of the association
   * @return The key of the new template plan item
   *
   * @deprecated since Curam v6, replaced with {@link createTemplatePlanItem}.
   * The new adds a plan item to a template sub-goal along with approval and
   * mandatory indicators. See release note <CR00226779>
   */
  @Deprecated
  public PlanTemplatePlanItemKey createPlanItem(
    curam.serviceplans.sl.struct.PlanTemplatePlanItemDetails details)
    throws AppException, InformationalException {
    PlanTemplateAndPlanItemDetails planTemplateAndPlanItemDetails = new PlanTemplateAndPlanItemDetails();

    planTemplateAndPlanItemDetails.dtls.authorizedUnits = details.dtls.authorizedUnits;
    planTemplateAndPlanItemDetails.dtls.description = details.dtls.description;
    planTemplateAndPlanItemDetails.dtls.duration = details.dtls.duration;
    planTemplateAndPlanItemDetails.dtls.expectedOutcomeID = details.dtls.expectedOutcomeID;
    planTemplateAndPlanItemDetails.dtls.expectedOutcomeName = details.dtls.expectedOutcomeName;
    planTemplateAndPlanItemDetails.dtls.maximumUnits = details.dtls.maximumUnits;
    planTemplateAndPlanItemDetails.dtls.name = details.dtls.name;
    planTemplateAndPlanItemDetails.dtls.outcomeRequiredInd = details.dtls.outcomeRequiredInd;
    planTemplateAndPlanItemDetails.dtls.planItemID = details.dtls.planItemID;
    planTemplateAndPlanItemDetails.dtls.planTemplatePlanItemID = details.dtls.planTemplatePlanItemID;
    planTemplateAndPlanItemDetails.dtls.planTemplateSubGoalID = details.dtls.planTemplateSubGoalID;
    planTemplateAndPlanItemDetails.dtls.startDay = details.dtls.startDay;
    planTemplateAndPlanItemDetails.dtls.versionNo = details.dtls.versionNo;

    return this.createTemplatePlanItem(planTemplateAndPlanItemDetails);

  }

  // END, CR00226779
  // END, CR00000022

  // BEGIN, CR00020193, PMD
  // _________________________________________________________________________
  /**
   * This method is used to record the id of the template item to be displayed
   * after an item has been added/removed from the service plan template.
   *
   * @param details The id and type of the item to be displayed.
   */
  public void postUpdateTemplateItem(TemplateItemDetails details)
    throws AppException, InformationalException {

    TreeXMLNodeUtil treeUtil = new TreeXMLNodeUtil();

    treeUtil.setLastAccessedNode(details.templateItemObjID,
      details.templateItemObjType);

  }

  // END, CR00020193, PMD

  // BEGIN, CR00047794, PMD
  // _________________________________________________________________________
  /**
   * Adds a milestone to a service plan template
   *
   * @param details the milestone template details
   * @return The newly created key for the PlanTemplateMilestone
   */
  public PlanTemplateMilestoneKey addMilestone(
    PlanTemplateMilestoneDetails details)
    throws AppException, InformationalException {

    // Return Struct
    PlanTemplateMilestoneKey planTemplateMilestoneKey = new PlanTemplateMilestoneKey();

    // BEGIN, CR00228796, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!details.dtls.comments.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(details.dtls.comments,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      details.dtls.commentsTextID = localizableTextHandler.store();
    } else {
      // If comments is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      details.dtls.commentsTextID = localizableTextHandler.store();
    }

    // BEGIN, CR00229083, GP
    details.dtls.comments = null;
    // END, CR00229083
    // END, CR00228796

    // Add the milestone to the template
    PlanTemplateMilestoneFactory.newInstance().insert(details.dtls);

    planTemplateMilestoneKey.planTemplateMilestoneID = details.dtls.planTemplateMilestoneID;

    // Set the id and type of the template item added
    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    templateItemDetails.templateItemObjID = String.valueOf(
      planTemplateMilestoneKey.planTemplateMilestoneID);
    templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplateMilestone;
    postUpdateTemplateItem(templateItemDetails);

    return planTemplateMilestoneKey;
  }

  // _________________________________________________________________________
  /**
   * Modifies a milestone for a service plan template
   *
   * @param details the updated milestone details
   */
  public void modifyMilestone(PlanTemplateMilestoneDetails details)
    throws AppException, InformationalException {

    PlanTemplateMilestoneKey planTemplateMilestoneKey = new PlanTemplateMilestoneKey();

    planTemplateMilestoneKey.planTemplateMilestoneID = details.dtls.planTemplateMilestoneID;

    // BEGIN, CR00228796, GP

    // Modify localized comments.
    long commentsTextID;

    // Modify Localized description.
    if (0 == details.dtls.commentsTextID) {

      if (!details.dtls.comments.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(details.dtls.comments,
          LOCALEEntry.get(
          (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
        commentsTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        commentsTextID = localizableTextHandler.store();
      }
      // Update the struct passed to modify().
      details.dtls.commentsTextID = commentsTextID;

    } else {

      // Handling New data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        details.dtls.commentsTextID);

      localizableTextHandler.addValue(details.dtls.comments,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      localizableTextHandler.store();

    }

    // BEGIN, CR00229083, GP
    details.dtls.comments = null;
    // END, CR00229083

    // END, CR00228796


    // Modify the template milestone details
    PlanTemplateMilestoneFactory.newInstance().modify(planTemplateMilestoneKey,
      details.dtls);
  }

  // _________________________________________________________________________

  // BEGIN, CR00229083, GP
  /**
   * Reads milestone details for a service plan template
   *
   * @param key the template milestone key
   * @return the template milestone details
   *
   * @deprecated Since Curam 6.0, replaced with {@link PlanTemplate#
   * readTemplateMilestone()} as part of implementing localization of plan
   * template Milestone comments. See release note: CR00229083.
   */
  @Deprecated
  // END, CR00229083
  // BEGIN, CR00233815, GP
  public curam.serviceplans.sl.struct.ReadMilestoneDetails readMilestone(PlanTemplateMilestoneKey key)
    throws AppException, InformationalException {

    // Return Struct
    curam.serviceplans.sl.struct.ReadMilestoneDetails readMilestoneDetails = new
      curam.serviceplans.sl.struct.ReadMilestoneDetails();

    // END, CR00233815

    // Read the template milestone details
    readMilestoneDetails.details = PlanTemplateMilestoneFactory.newInstance().readDetails(
      key);
    return readMilestoneDetails;
  }

  // BEGIN, CR00228796, GP
  /**
   * Reads milestone details for a service plan template.
   *
   * @param key contains the template milestone key.
   *
   * @return the template milestone details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ReadTemplateMilestoneDetails readTemplateMilestone(
    PlanTemplateMilestoneKey key) throws AppException, InformationalException {

    ReadTemplateMilestoneDetails readTemplateMilestoneDetails = new
      ReadTemplateMilestoneDetails();

    readTemplateMilestoneDetails.dtls = PlanTemplateMilestoneFactory.newInstance().readMilestoneDetails(
      key);

    // Read the localized comments.
    if (0 != readTemplateMilestoneDetails.dtls.commentsTextID) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        readTemplateMilestoneDetails.dtls.commentsTextID);

      readTemplateMilestoneDetails.dtls.comments = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }

    return readTemplateMilestoneDetails;
  }

  // END, CR00228796

  // _________________________________________________________________________
  /**
   * Removes the milestone details from a service plan template(physical delete)
   *
   * @param key the template milestone key
   */
  public void removeMilestone(PlanTemplateMilestoneKey key)
    throws AppException, InformationalException {

    // Plan Template Milestone Entity
    curam.serviceplans.sl.entity.intf.PlanTemplateMilestone planTemplateMilestoneObj = curam.serviceplans.sl.entity.fact.PlanTemplateMilestoneFactory.newInstance();

    // Read the planTemplateID, planTemplatePlanGroupID and
    // planTemplateSubGoalID, so that we know which node to return
    // to in the tree control
    PlanTemplateIDPlanGroupIDAndSubGoalID planTemplateIDPlanGroupIDAndSubGoalID = new PlanTemplateIDPlanGroupIDAndSubGoalID();

    planTemplateIDPlanGroupIDAndSubGoalID = planTemplateMilestoneObj.readPlanTemplateIDPlanGroupIDAndSubGoalID(
      key);

    // Remove the milestone from the template
    planTemplateMilestoneObj.remove(key);

    // Set the id and type of the template item to return to
    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    if (planTemplateIDPlanGroupIDAndSubGoalID.planTemplateSubGoalID != 0) {

      // The removed milestone was at sub goal level
      // return the user to this sub goal
      templateItemDetails.templateItemObjID = String.valueOf(
        planTemplateIDPlanGroupIDAndSubGoalID.planTemplateSubGoalID);
      templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplateSubGoal;

    } else if (planTemplateIDPlanGroupIDAndSubGoalID.planTemplatePlanGroupID
      != 0) {

      // The removed milestone was at plan group level
      // return the user to this plan group
      templateItemDetails.templateItemObjID = String.valueOf(
        planTemplateIDPlanGroupIDAndSubGoalID.planTemplatePlanGroupID);
      templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplatePlanGroup;

    } else {

      // The removed milestone was at template level
      // return the user to the template home page
      templateItemDetails.templateItemObjID = String.valueOf(
        planTemplateIDPlanGroupIDAndSubGoalID.planTemplateID);
      templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplate;

    }

    postUpdateTemplateItem(templateItemDetails);

  }

  // _________________________________________________________________________
  /**
   * Method to return a list of active milestone configurations.
   *
   * @return a list of active milestone configurations
   */
  public MilestoneConfigIDAndNameList listActiveMilestoneConfigs()
    throws AppException, InformationalException {

    // Return Struct
    MilestoneConfigIDAndNameList milestoneConfigIDAndNameList = new MilestoneConfigIDAndNameList();

    RecordStatusKey recordStatusKey = new RecordStatusKey();

    recordStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // Get the list of milestone configurations.

    // BEGIN, CR00247170, GP
    MilestoneConfigIDAndName milestoneConfigIDAndName;
    MilestoneConfigIDAndNameDetailsList milestoneConfigIDAndNameDetailsList = MilestoneConfigurationFactory.newInstance().searchNameDetailsAndIDByRecordStatus(
      recordStatusKey);
    
    for (MilestoneConfigIDAndNameDetails milestoneConfigIDAndNameDetails : 
      milestoneConfigIDAndNameDetailsList.dtls.items()) {
      
      milestoneConfigIDAndName = new MilestoneConfigIDAndName();
      milestoneConfigIDAndName.milestoneConfigurationID = milestoneConfigIDAndNameDetails.milestoneConfigurationID;
      milestoneConfigIDAndName.name = milestoneConfigIDAndName.name;
      
      // Read the localized name.
      if (0 != milestoneConfigIDAndNameDetails.nameTextID) {

        LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          milestoneConfigIDAndNameDetails.nameTextID);

        milestoneConfigIDAndName.name = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
      milestoneConfigIDAndNameList.dtlsList.dtls.addRef(
        milestoneConfigIDAndName);
    }      
    
    // END, CR00247170

    return milestoneConfigIDAndNameList;
  }

  // END, CR00047794

  // BEGIN, CR00161962, LJ
  // _________________________________________________________________________
  /**
   * This method is used to list all the Approval Criteria that are not
   * associated with Plan Template Plan Item.
   *
   * @param key
   * plan template plan item key.
   * @return UnassociatedTemplateApprovalCriteriaDetailsList - list of all the
   * unassociated approval criteria.
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  public curam.serviceplans.sl.struct.UnassociatedTemplateApprovalCriteriaDetailsList listUnassociatedTemplateApprovalCriteria(
    final curam.serviceplans.sl.struct.PlanTemplatePlanItemKey key)
    throws AppException, InformationalException {
    // Create Plan Template Plan Item
    PlanTemplatePlanItem planTemplatePlanItemObj = PlanTemplatePlanItemFactory.newInstance();

    // Create Criteria Key to search
    SearchUnassociatedTemplateApprovalCriteriaKey searchunassociatedtemplateapprovalcriteriakey = new SearchUnassociatedTemplateApprovalCriteriaKey();

    UnassociatedTemplateApprovalCriteriaDetailsList list = new UnassociatedTemplateApprovalCriteriaDetailsList();

    // assign Plan Template Plan Item ID
    searchunassociatedtemplateapprovalcriteriakey.planTemplatePlanItemID = key.key.planTemplatePlanItemID;

    // Search for the unassociated Plan Template Plan Item Approval Criteria.
    list.list = planTemplatePlanItemObj.searchUnassociatedTemplateApprovalCriteria(
      searchunassociatedtemplateapprovalcriteriakey);

    PlanTemplatePlanItemApprCrit planTemplatePlanItemApprCritObj = PlanTemplatePlanItemApprCritFactory.newInstance();
    // search for associated approval criteria
    TemplateApprovalCriteriaDetailsList detailsList = planTemplatePlanItemApprCritObj.searchByPlanTemplatePlanItemID(
      key.key);

    // check for the associated approval criteria
    if (!detailsList.dtls.isEmpty()) {
      list.ApprCritAssociatedInd = true;
    }

    return list;

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // _________________________________________________________________________
  /**
   * Helper method to carry out the validation and reordering of the priority
   * values if need be.
   *
   * @param details
   * - plan template plan item approval criteria details.
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  protected void callPriorityHelper(PlanTemplatePlanItemApprCritDetails details)
    throws AppException, InformationalException {

    PriorityHelper priorityHelper = PriorityHelperFactory.newInstance();

    // Create Object
    PlanTemplatePlanItemApprCrit templatePlanItemApprCritObj = PlanTemplatePlanItemApprCritFactory.newInstance();

    PriorityDetails priorityDetails = new PriorityDetails();

    priorityDetails.applyNextPriorityInd = details.assignNextPriority;
    priorityDetails.priority = details.dtls.priority;

    // Validate the options provided
    priorityHelper.validatePriority(priorityDetails);

    TemplateApprovalCriteriaPrioritySearchDetails key = new TemplateApprovalCriteriaPrioritySearchDetails();

    TemplateApprovalCriteriaPriorityDetailsList appCritPriDtlsList = null;
    TemplateApprovalCriteriaPriorityDetails appCritPriDtls = new TemplateApprovalCriteriaPriorityDetails();
    curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemApprCritKey planTemplatePlanItemApprCritKey = new curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemApprCritKey();

    PriorityDetailsList existingPriorities = new PriorityDetailsList();
    PriorityDetailsList reorderedPriorities = null;

    // Get the list of existing priorities
    key.occursWhen = details.dtls.occursWhen;

    key.planTemplatePlanItemID = details.dtls.planTemplatePlanItemID;
    appCritPriDtlsList = templatePlanItemApprCritObj.searchPriorityDetailsByOccursWhenAndPlanTemplatePlanItem(
      key);

    existingPriorities.assign(appCritPriDtlsList);

    // If we need to assign the next priority then update the details struct
    if (details.assignNextPriority) {
      // Create details for the existing entry
      OrderPriorityDetails currentDetails = new OrderPriorityDetails();

      currentDetails.priority = details.dtls.priority;
      currentDetails.recordKeyID = details.dtls.planTemplatePlanItemApprCritID;
      currentDetails.versionNo = details.dtls.versionNo;

      // Given the current list of priority details, get the next one
      Priority priority = priorityHelper.getNextPriority(existingPriorities,
        currentDetails);

      // Update the details struct so that when we return the new value will be
      // written to the database
      details.dtls.priority = priority.dtls.priority;

    } else {
      OrderPriorityDetails orderDetails = new OrderPriorityDetails();

      orderDetails.priority = details.dtls.priority;
      orderDetails.recordKeyID = details.dtls.planTemplatePlanItemApprCritID;
      orderDetails.versionNo = details.dtls.versionNo;

      reorderedPriorities = priorityHelper.reorderPriority(orderDetails,
        existingPriorities);
      int size = reorderedPriorities.dtls.size();

      for (int i = 0; i < size; i++) {
        appCritPriDtls.assign(reorderedPriorities.dtls.item(i));
        planTemplatePlanItemApprCritKey.planTemplatePlanItemApprCritID = appCritPriDtls.planTemplatePlanItemApprCritID;

        // Update this entry to modify the priority
        templatePlanItemApprCritObj.modifyPriority(
          planTemplatePlanItemApprCritKey, appCritPriDtls);
      }
    }
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // _________________________________________________________________________
  /**
   * Reads the service plan template plan item approval criteria key.
   *
   * @param planTemplatePlanItemApprCritKey
   * - template plan item approval criteria key.
   * @return details - template plan item approval criteria details.
   *
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  public ReadTemplatePlanItemApprovalCriteriaDetails readApprovalCriteria(
    PlanTemplatePlanItemApprCritKey planTemplatePlanItemApprCritKey)
    throws AppException, InformationalException {

    // Create Object
    PlanTemplatePlanItemApprCrit templatePlanItemApprCritObj = PlanTemplatePlanItemApprCritFactory.newInstance();

    ReadTemplatePlanItemApprovalCriteriaDetails details = new ReadTemplatePlanItemApprovalCriteriaDetails();

    // read details
    details.dtls = templatePlanItemApprCritObj.read(
      planTemplatePlanItemApprCritKey.key);

    // read criteria name
    details.criteriaName = templatePlanItemApprCritObj.readApprovalCriteriaName(
      planTemplatePlanItemApprCritKey.key);

    // Assign description. It's needed as title for remove approval criteria
    // page
    details.criteriaNameDescription = CodeTable.getOneItem(
      curam.codetable.APPROVALCRITERIANAME.TABLENAME, details.criteriaName.name);

    // Read the details
    details.priorityPosition = getPriorityPosition(details.dtls);

    return details;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ___________________________________________________________________________
  /**
   * Modify existing service plan template plan item approval criteria entry.
   *
   * @param PlanTemplatePlanItemApprCritDetails
   * - template plan item approval criteria details.
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  public void modifyApprovalCriteria(
    PlanTemplatePlanItemApprCritDetails details)
    throws AppException, InformationalException {

    // Carry out validation and re-ordering of existing entries
    callPriorityHelper(details);

    // Create Object
    PlanTemplatePlanItemApprCrit templatePlanItemApprCritObj = PlanTemplatePlanItemApprCritFactory.newInstance();

    // Create return Object
    curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemApprCritKey key = new curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemApprCritKey();

    // Assign key
    key.planTemplatePlanItemApprCritID = details.dtls.planTemplatePlanItemApprCritID;

    // modify Plan Template Plan Item Approval Criteria
    templatePlanItemApprCritObj.modify(key, details.dtls);

    // Set the id and type of the template item added
    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    templateItemDetails.templateItemObjID = String.valueOf(
      key.planTemplatePlanItemApprCritID);

    templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplatePlanItemApprovalCriteria;
    postUpdateTemplateItem(templateItemDetails);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Remove the service plan template plan item approval criteria entry.
   *
   * @param PlanTemplatePlanItemApprCritKey
   * - Plan template plan item approval criteria key
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  public void removeApprovalCriteria(
    PlanTemplatePlanItemApprCritKey planTemplatePlanItemApprCritKey)
    throws AppException, InformationalException {
    // Create Object
    PlanTemplatePlanItemApprCrit templatePlanItemApprCritObj = PlanTemplatePlanItemApprCritFactory.newInstance();

    PlanTemplatePlanItemKey planTemplatePlanItemKey = new PlanTemplatePlanItemKey();

    // read plan template plan item associated with this approval criteria
    planTemplatePlanItemKey.key = templatePlanItemApprCritObj.readPlanTemplatePlanItemID(
      planTemplatePlanItemApprCritKey.key);

    // Removes Plan Template Plan Item Approval Criteria
    templatePlanItemApprCritObj.remove(planTemplatePlanItemApprCritKey.key);

    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    templateItemDetails.templateItemObjID = String.valueOf(
      planTemplatePlanItemKey.key.planTemplatePlanItemID);
    templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplatePlanItem;
    postUpdateTemplateItem(templateItemDetails);

  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Creates approval criteria for service plan template plan item approval
   * criteria.
   *
   * @param details
   * - template plan item approval criteria details.
   * @return key - plan template plan item approval criteria key.
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  public PlanTemplatePlanItemApprCritKey createApprovalCriteria(
    AddTemplatePlanItemApprovalCriteriaDetails details)
    throws AppException, InformationalException {

    // validate details
    validateCreate(details);

    // create PlanItemApprovalCriteriaLink object
    PlanItemApprovalCriteriaLink planItemApprovalCriteriaLinkObj = PlanItemApprovalCriteriaLinkFactory.newInstance();

    // create plan template plan item approval criteria record.
    PlanTemplatePlanItemApprCritKey key = new PlanTemplatePlanItemApprCritKey();

    // Create Object
    PlanTemplatePlanItemApprCrit templatePlanItemApprCritObj = PlanTemplatePlanItemApprCritFactory.newInstance();

    PlanItemApprovalCriteriaLinkKey planItemApprovalCriteriaLinkKey = new PlanItemApprovalCriteriaLinkKey();

    // Assign key to search record.
    planItemApprovalCriteriaLinkKey.planItemApprovalCriteriaLinkID = details.planItemApprovalCriteriaLinkID;

    // Search for the details that needs to be copied
    PlanItemApprovalCriteriaLinkDtls planItemApprovalCriteriaLinkDtls = planItemApprovalCriteriaLinkObj.read(
      planItemApprovalCriteriaLinkKey);

    PlanTemplatePlanItemApprCritDetails dtls = new PlanTemplatePlanItemApprCritDetails();

    // Assign the Priority and occurs when details
    dtls.dtls.assign(planItemApprovalCriteriaLinkDtls);

    // Assign plan template plan item id
    dtls.dtls.planTemplatePlanItemID = details.planTemplatePlanItemID;

    // Insert Plan Template Plan Item Approval Criteria
    templatePlanItemApprCritObj.insert(dtls.dtls);

    // Assign key
    key.key.planTemplatePlanItemApprCritID = dtls.dtls.planTemplatePlanItemApprCritID;

    // Set the id and type of the template item added
    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    templateItemDetails.templateItemObjID = String.valueOf(
      key.key.planTemplatePlanItemApprCritID);

    templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplatePlanItemApprovalCriteria;
    postUpdateTemplateItem(templateItemDetails);

    return key;
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Helper method. Perform validation before reading a plan item approval
   * criteria link.
   *
   * @param details
   * - template plan item approval criteria details.
   *
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  protected void validateCreate(
    AddTemplatePlanItemApprovalCriteriaDetails details)
    throws AppException, InformationalException {

    InformationalManager infoManager = TransactionInfo.getInformationalManager();

    // validate planItemApprovalCriteriaLinkID before reading the record
    if (details.planItemApprovalCriteriaLinkID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(
          BPOAPPROVALCRITERIA.ERR_DETAILS_APPROVAL_CRITERIA_NAME_INVALID),
          GeneralConstants.kEmpty,
          InformationalElement.InformationalType.kError,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }
    infoManager.failOperation();
  }

  // END, CR00161962

  // BEGIN, CR00161962, LJ
  // ____________________________________________________________________________
  /**
   * Helper method to generate the priority position details.
   *
   * @param dtls
   * ApprovalCriteria details
   * @return result - Priority position.
   * @throws AppException
   * - Standard application exception
   * @throws InformationalException
   * - Standard information exception
   */
  protected PriorityPosition getPriorityPosition(
    PlanTemplatePlanItemApprCritDtls dtls)
    throws AppException, InformationalException {

    PriorityPosition result = new PriorityPosition();

    PriorityHelper priorityHelper = PriorityHelperFactory.newInstance();

    // Create Object
    PlanTemplatePlanItemApprCrit templatePlanItemApprCritObj = PlanTemplatePlanItemApprCritFactory.newInstance();

    TemplateApprovalCriteriaPrioritySearchDetails key = new TemplateApprovalCriteriaPrioritySearchDetails();

    TemplateApprovalCriteriaPriorityDetailsList appCritPriDtlsList = null;

    PriorityDetailsList existingPriorities = new PriorityDetailsList();

    // Get the list of existing priorities
    key.occursWhen = dtls.occursWhen;
    key.planTemplatePlanItemID = dtls.planTemplatePlanItemID;
    appCritPriDtlsList = templatePlanItemApprCritObj.searchPriorityDetailsByOccursWhenAndPlanTemplatePlanItem(
      key);

    existingPriorities.assign(appCritPriDtlsList);

    OrderPriorityDetails currentDetails = new OrderPriorityDetails();

    currentDetails.priority = dtls.priority;
    currentDetails.recordKeyID = dtls.planTemplatePlanItemApprCritID;
    currentDetails.versionNo = dtls.versionNo;

    result = priorityHelper.getPriorityPosition(existingPriorities,
      currentDetails);

    return result;
  }

  // END, CR00161962

  // BEGIN, CR00226779 MN
  /**
   * Associates a plan item with the plan template including mandatory and
   * approval information. A plan template plan item is used to associate the
   * plan item with a plan template sub goal.
   *
   * @param details the details of the association
   */
  public void addTemplatePlanItem(PlanTemplateAndPlanItemDetails details)
    throws AppException, InformationalException {

    curam.serviceplans.sl.intf.PlanTemplate planTemplateObj = PlanTemplateFactory.newInstance();

    planTemplateObj.createTemplatePlanItem(details);
  }

  /**
   * Associates a plan item with the plan template. A plan template plan item is
   * used to associate the plan item with a plan template sub goal
   *
   * @param details The details of the association
   * @return The key of the new template plan item
   */
  public PlanTemplatePlanItemKey createTemplatePlanItem(
    PlanTemplateAndPlanItemDetails details) throws AppException,
      InformationalException {
    // Return Object
    PlanTemplatePlanItemKey planTemplatePlanItemKey = new PlanTemplatePlanItemKey();

    // Plan Template PlanItem entity
    PlanTemplatePlanItem planTemplatePlanItemObj = PlanTemplatePlanItemFactory.newInstance();

    PlanTemplatePlanItemDtls planTemplatePlanItemDtls = new PlanTemplatePlanItemDtls();

    // assign the details
    planTemplatePlanItemDtls.assign(details.dtls);

    // BEGIN, CR00228796, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!planTemplatePlanItemDtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(planTemplatePlanItemDtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      planTemplatePlanItemDtls.descriptionTextID = localizableTextHandler.store(
        );
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      planTemplatePlanItemDtls.descriptionTextID = localizableTextHandler.store(
        );
    }
    planTemplatePlanItemDtls.description = null;
    // END, CR00228796

    // add the plan item to plan template
    planTemplatePlanItemObj.insert(planTemplatePlanItemDtls);

    planTemplatePlanItemKey.key.planTemplatePlanItemID = planTemplatePlanItemDtls.planTemplatePlanItemID;

    // Set the id and type of the template item added
    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    templateItemDetails.templateItemObjID = String.valueOf(
      planTemplatePlanItemKey.key.planTemplatePlanItemID);
    templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplatePlanItem;
    postUpdateTemplateItem(templateItemDetails);

    return planTemplatePlanItemKey;
  }

  public ReadPlanTemplatePlanItemForModifyDetails readPlanTemplatePlanItemForModify(ReadTemplatePlanItemForModifyKey key)
    throws AppException, InformationalException {
    // Return Struct
    ReadPlanTemplatePlanItemForModifyDetails readTemplatePlanItemForModifyDetails = new ReadPlanTemplatePlanItemForModifyDetails();

    curam.serviceplans.sl.entity.struct.ListPlanItemsForModifyKey listPlanItemsForModifyKey = new curam.serviceplans.sl.entity.struct.ListPlanItemsForModifyKey();

    // Plan Template Plan Item Entity
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem planTemplatePlanItemObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory.newInstance();

    // Read the template plan item details
    readTemplatePlanItemForModifyDetails.details = planTemplatePlanItemObj.readPlanTemplateAndPlanItemDetails(
      key.planTemplatePlanItemKey);

    // Set the key for the plan item search
    listPlanItemsForModifyKey.planItemID = key.planItemKey.planItemID;
    listPlanItemsForModifyKey.planTemplateSubGoalID = key.planTemplateSubGoalKey.planTemplateSubGoalID;
    listPlanItemsForModifyKey.recordStatus = RECORDSTATUS.NORMAL;

    // Get a list of plan item names
    readTemplatePlanItemForModifyDetails.planItemNameList = planTemplatePlanItemObj.searchTemplatePlanItemsForModify(
      listPlanItemsForModifyKey);

    return readTemplatePlanItemForModifyDetails;
  }

  /**
   * Reads the details of the association between an plan item and the plan
   * template.
   *
   * @param key the key of association
   * @return the details of the association
   */
  public PlanTemplateAndPlanItemDetails readTemplatePlanItem(
    PlanTemplatePlanItemKey key) throws AppException, InformationalException {
    // Plan Template PlanItem entity
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem planTemplatePlanItemObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory.newInstance();

    // return value
    PlanTemplateAndPlanItemDetails planTemplatePlanItemDetails = new PlanTemplateAndPlanItemDetails();

    // read plan template plan item details
    planTemplatePlanItemDetails.dtls = planTemplatePlanItemObj.readPlanTemplateAndPlanItemDetails(
      key.key);

    // BEGIN, CR00228796 , GP
    // Read the localized description.
    if (0 != planTemplatePlanItemDetails.dtls.descriptionTextID) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        planTemplatePlanItemDetails.dtls.descriptionTextID);

      planTemplatePlanItemDetails.dtls.description = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00228796

    // return plan template plan item details
    return planTemplatePlanItemDetails;
  }

  // END, CR00226779

  // BEGIN, CR00226899 MN
  /**
   * Reads goalID, list of sub goal details for the goal and list of planItem
   * details for each sub goal.
   *
   * @param key Plan Template unique identifier
   *
   * @return The goal ID, list of plan template sub goals associated
   * with the goal and list of planItems associated with each plan
   * template sub goal
   */
  public ServicePlanGoalSubGoalsAndPlanItemsDetails listServicePlanGoalSubGoalAndPlanItems(PlanTemplateKey key)
    throws AppException, InformationalException {
    // return value
    ServicePlanGoalSubGoalsAndPlanItemsDetails goalSubGoalsAndPlanItemsDetails = new ServicePlanGoalSubGoalsAndPlanItemsDetails();
    SubGoalAndPlanTemplatePlanItemsDetails subGoalAndPlanItemsDetails;

    // PlanTemplate entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    // PlanTemplateSubGoal entity
    curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal planTemplateSubGoalObj = curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory.newInstance();

    curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalIDAndSubGoalIDDetailsList planTemplateSubGoalIDAndSubGoalIDDetailsList;

    curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalKey planTemplateSubGoalKey = new  curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalKey();

    // PlanTemplatePlanItem entity
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem planTemplatePlanItemObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory.newInstance();

    curam.serviceplans.sl.entity.struct.PlanItemAndTemplatePlanItemDetailsList planItemAndPlanTemplatePlanItemDetailsList = new curam.serviceplans.sl.entity.struct.PlanItemAndTemplatePlanItemDetailsList();

    // read goal ID by plan template key
    curam.serviceplans.sl.entity.struct.GoalIDDetails goalIDDetails = planTemplateObj.readGoalID(
      key.planTemplateKey);

    // assign goal ID to returned struct
    goalSubGoalsAndPlanItemsDetails.goalID = goalIDDetails.goalID;

    // read plan template sub goal details for the plan template
    try {
      planTemplateSubGoalIDAndSubGoalIDDetailsList = planTemplateSubGoalObj.searchPlanTemplateSubGoalIDAndSubGoalIDByPlanTemplateID(
        key.planTemplateKey);
    } catch (curam.util.exception.RecordNotFoundException e) {
      // do nothing, plan template sub goal might not be defined for
      // the plan template
      planTemplateSubGoalIDAndSubGoalIDDetailsList = null;
    }

    // if there are plan template sub goals, iterate the list
    if (planTemplateSubGoalIDAndSubGoalIDDetailsList != null) {
      for (int i = 0; i
        < planTemplateSubGoalIDAndSubGoalIDDetailsList.dtls.size(); i++) {

        // create a new instance of the sub goal and plan item details
        subGoalAndPlanItemsDetails = new SubGoalAndPlanTemplatePlanItemsDetails();

        // assign plan template sub goal ID
        subGoalAndPlanItemsDetails.planTemplateSubGoalID = planTemplateSubGoalIDAndSubGoalIDDetailsList.dtls.item(i).planTemplateSubGoalID;
        // assign sub goal ID
        subGoalAndPlanItemsDetails.subGoalID = planTemplateSubGoalIDAndSubGoalIDDetailsList.dtls.item(i).subGoalID;

        // set the key for plan item search
        planTemplateSubGoalKey.planTemplateSubGoalID = planTemplateSubGoalIDAndSubGoalIDDetailsList.dtls.item(i).planTemplateSubGoalID;

        // search for plan template planItems assigned to the plan template
        // sub goal
        try {
          planItemAndPlanTemplatePlanItemDetailsList = planTemplatePlanItemObj.searchPlanItemByPlanTemplateSubGoalID(
            planTemplateSubGoalKey);
        } catch (curam.util.exception.RecordNotFoundException e) {
          // do nothing, plan template plan item might not be defined for
          // the plan template sub goal
          planItemAndPlanTemplatePlanItemDetailsList = null;
        }

        if (planItemAndPlanTemplatePlanItemDetailsList != null) {
          // assign plan item details to the returned struct
          subGoalAndPlanItemsDetails.planItemAndTemplatePlanItemDetailsList.assign(
            planItemAndPlanTemplatePlanItemDetailsList);
        }

        // assign sub goals and plan item details to the returned struct
        goalSubGoalsAndPlanItemsDetails.subGoalAndPlanTemplatePlanItemsDetails.addRef(
          subGoalAndPlanItemsDetails);

      }
    }
    return goalSubGoalsAndPlanItemsDetails;
  }

  // END, CR00226899
  // BEGIN, CR00226905 MN
  /**
   * Modifies the association between the plan template and a plan item
   * including Mandatory and approval indicators.
   *
   * @param key the key of the plan item association
   * @param details the new details for the association
   */
  public void modifyPlanTemplatePlanItem(PlanTemplatePlanItemKey key,
    PlanTemplateAndPlanItemModifyDetails details) throws AppException,
      InformationalException {
    // Plan Template PlanItem entity
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem planTemplatePlanItemObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory.newInstance();

    // BEGIN, CR00228796, GP
    // Modify Localized description.

    long descriptionTextID;

    if (0 == details.details.descriptionTextID) {

      if (!details.details.description.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(details.details.description,
          LOCALEEntry.get(
          (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }
      // Update the struct passed to modify().
      details.details.descriptionTextID = descriptionTextID;

    } else {

      // Handling New data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        details.details.descriptionTextID);

      localizableTextHandler.addValue(details.details.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      localizableTextHandler.store();
    }

    // BEGIN, CR00229083, GP
    details.details.description = null;
    // END, CR00229083

    // END, CR00228796

    // modify plan template planItem
    planTemplatePlanItemObj.modifyPlanTemplateAndPlanItemDetails(key.key,
      details.details);

    // Set the id and type of the template item added
    TemplateItemDetails templateItemDetails = new TemplateItemDetails();

    templateItemDetails.templateItemObjID = String.valueOf(
      key.key.planTemplatePlanItemID);
    templateItemDetails.templateItemObjType = TreeXMLNodeUtil.kPlanTemplatePlanItem;
    postUpdateTemplateItem(templateItemDetails);
  }

  // END, CR00226905

  // BEGIN, CR00226647, GP
  /**
   * Checks to ensure multiple text translations are not present for a single
   * locale. If it is, an error message is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE} - If
   * multiple text translation is present for the same locale.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    TextTranslationDtlsList textTranslationDtlsList = new
      TextTranslationDtlsList();
    TextTranslation textTranslation = TextTranslationFactory.newInstance();
    SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();

    key.localizableTextID = localizableTextHandler.getID();
    textTranslationDtlsList = textTranslation.searchByLocalizableTextID(key);

    for (TextTranslationDtls textTranslationDtls : textTranslationDtlsList.dtls.items()) {

      if (textTranslationDtls.localeCode.equals(locale)) {
        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(textTranslationDtls.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          15);
      }
    }
  }

  /**
   * Creates a text translation for the Plan Template attribute, name.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Plan Template
   * attribute, name.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY} - if text to be translated is
   * empty.
   * {@link GENERAL#ERR_LOCALE_EMPTY} - if locale is empty.
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   * {@link BPOPLANTEMPLATE#ERR_TEMPLATE_FV_CANCELED_NO_MODIFY - if the
   * plan template to be modified is already deleted.}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addNameTextTranslation(final
    LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    PlanTemplateNameTextID planTemplateNameTextID = new
      PlanTemplateNameTextID();
    PlanTemplateDtls planTemplateDtls = new PlanTemplateDtls();

    planTemplateKey.planTemplateKey.planTemplateID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_TEXT_EMPTY);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_LOCALE_EMPTY);
    }

    planTemplateDtls = planTemplateObj.read(planTemplateKey.planTemplateKey);

    // Record must not be already canceled.
    if (planTemplateDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      throw new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_CANCELED_NO_MODIFY);
    }

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplateDtls.nameTextID) {      
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())) {

        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        throw e;

      }

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      String value = planTemplateDtls.name;
      
      // BEGIN, CR00246419, GP
      localizableTextHandler.setShortTextInd(true);
      localizableTextHandler.setGroupCode(
        LOCALIZABLETEXTGROUPCODE.PLANTEMPLATENAME);
      // END, CR00246419

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      planTemplateNameTextID.nameTextID = textID;
      planTemplateNameTextID.versionNo = planTemplateDtls.versionNo;
      planTemplateObj.modifyNameTextID(planTemplateKey.planTemplateKey,
        planTemplateNameTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplateDtls.nameTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplateDtls.nameTextID);
      
      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the Plan Template attribute,
   * name.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Plan Template
   * attribute, name.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * {@link BPOPLANTEMPLATE#ERR_TEMPLATE_FV_CANCELED_NO_MODIFY - if the
   * plan template to be modified is already deleted.}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyNameTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    PlanTemplateNameTextID planTemplateNameTextID = new
      PlanTemplateNameTextID();
    PlanTemplateDtls planTemplateDtls = new PlanTemplateDtls();

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 15);
    }

    planTemplateKey.planTemplateKey.planTemplateID = localizableTextTranslationDetails.localizableTextParentID;

    planTemplateDtls = planTemplateObj.read(planTemplateKey.planTemplateKey);

    // Record must not be already cancelled.
    if (planTemplateDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_CANCELED_NO_MODIFY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplateDtls.nameTextID) {      
      // END, CR00246419

      // Handling legacy Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      // BEGIN, CR00246419, GP
      localizableTextHandler.setShortTextInd(true);
      localizableTextHandler.setGroupCode(
        LOCALIZABLETEXTGROUPCODE.PLANTEMPLATENAME);
      // END, CR00246419

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      textID = localizableTextHandler.store();
      planTemplateNameTextID.nameTextID = textID;
      planTemplateNameTextID.versionNo = planTemplateDtls.versionNo;
      planTemplateObj.modifyNameTextID(planTemplateKey.planTemplateKey,
        planTemplateNameTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplateDtls.nameTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplateDtls.nameTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      localizableTextHandler.store();
    }
  }

  /**
   * Creates a text translation for the Plan Template attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for Plan Template
   * attribute, name.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY} - if text to be translated is
   * empty.
   * {@link GENERAL#ERR_LOCALE_EMPTY} - if locale is empty.
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   * {@link BPOPLANTEMPLATE#ERR_TEMPLATE_FV_CANCELED_NO_MODIFY - if the
   * plan template to be modified is already deleted.}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addDescriptionTextTranslation(final
    LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    PlanTemplateDescriptionTextID planTemplateDescriptionTextID = new
      PlanTemplateDescriptionTextID();
    PlanTemplateDtls planTemplateDtls = new PlanTemplateDtls();

    planTemplateKey.planTemplateKey.planTemplateID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 24);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_LOCALE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 8);
    }

    planTemplateDtls = planTemplateObj.read(planTemplateKey.planTemplateKey);

    // Record must not be already cancelled.
    if (planTemplateDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_CANCELED_NO_MODIFY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplateDtls.descriptionTextID) {      
      // END, CR00246419
      
      // BEGIN, CR00227878, GP
      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !planTemplateDtls.description.equals(CuramConst.gkEmpty)) {
        // END, CR00227878
        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          13);

      }

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      String value = planTemplateDtls.description;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      planTemplateDescriptionTextID.descriptionTextID = textID;
      planTemplateDescriptionTextID.versionNo = planTemplateDtls.versionNo;
      planTemplateObj.modifyDescriptionTextID(planTemplateKey.planTemplateKey,
        planTemplateDescriptionTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplateDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplateDtls.descriptionTextID);
      
      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the Plan Template attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of Plan Template
   * attribute, name.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * {@link BPOPLANTEMPLATE#ERR_TEMPLATE_FV_CANCELED_NO_MODIFY - if the
   * plan template to be modified is already deleted.}
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    PlanTemplateDescriptionTextID planTemplateDescriptionTextID = new
      PlanTemplateDescriptionTextID();
    PlanTemplateDtls planTemplateDtls = new PlanTemplateDtls();

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 19);
    }

    planTemplateKey.planTemplateKey.planTemplateID = localizableTextTranslationDetails.localizableTextParentID;

    planTemplateDtls = planTemplateObj.read(planTemplateKey.planTemplateKey);

    // Record must not be already canceled.
    if (planTemplateDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_CANCELED_NO_MODIFY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplateDtls.descriptionTextID) {      
      // END, CR00246419

      // Handling legacy Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      textID = localizableTextHandler.store();
      planTemplateDescriptionTextID.descriptionTextID = textID;
      planTemplateDescriptionTextID.versionNo = planTemplateDtls.versionNo;
      planTemplateObj.modifyDescriptionTextID(planTemplateKey.planTemplateKey,
        planTemplateDescriptionTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplateDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplateDtls.descriptionTextID);      

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      localizableTextHandler.store();
    }
  }

  // END, CR00226647

  // BEGIN, CR00228796, GP
  /**
   * Creates a text translation for the PlanTemplateMilestone attribute,
   * comments.
   *
   * @param localizableTextTranslationDetails contains the
   * localizable text translation details used for
   * PlanTemplateMilestone attribute, comments.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text
   * to be translated is empty.
   * {@link GENERAL#ERR_LOCALE_EMPTY ERR_LOCALE_EMPTY} - if locale is
   * empty.
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addTemplateMilestoneCommentsTextTranslation(final
    LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    PlanTemplateMilestone planTemplateMilestoneObj = PlanTemplateMilestoneFactory.newInstance();
    PlanTemplateMilestoneKey planTemplateMilestoneKey = new
      PlanTemplateMilestoneKey();
    PlanTemplateMilestoneCommentsTextID planTemplateMilestoneCommentsTextID = new PlanTemplateMilestoneCommentsTextID();
    PlanTemplateMilestoneDtls planTemplateMilestoneDtls = new
      PlanTemplateMilestoneDtls();

    planTemplateMilestoneKey.planTemplateMilestoneID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 16);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_LOCALE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 7);
    }

    planTemplateMilestoneDtls = planTemplateMilestoneObj.read(
      planTemplateMilestoneKey);

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplateMilestoneDtls.commentsTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !planTemplateMilestoneDtls.comments.equals(CuramConst.gkEmpty)) {

        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          14);

      }

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      String value = planTemplateMilestoneDtls.comments;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      planTemplateMilestoneCommentsTextID.commentsTextID = textID;
      planTemplateMilestoneCommentsTextID.versionNo = planTemplateMilestoneDtls.versionNo;
      planTemplateMilestoneObj.modifyCommentsTextID(planTemplateMilestoneKey,
        planTemplateMilestoneCommentsTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplateMilestoneDtls.commentsTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplateMilestoneDtls.commentsTextID);
      
      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the PlanTemplateMilestone
   * attribute,comments.
   * @param localizableNameTextTranslationDetails contains the
   * localizable  text translation details like locale code,
   * localizable text used for the localization of
   * PlanTemplateMilestone attribute,comments.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyTemplateMilestoneCommentsTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    PlanTemplateMilestone planTemplateMilestoneObj = PlanTemplateMilestoneFactory.newInstance();
    PlanTemplateMilestoneKey planTemplateMilestoneKey = new
      PlanTemplateMilestoneKey();
    PlanTemplateMilestoneCommentsTextID planTemplateMilestoneCommentsTextID = new PlanTemplateMilestoneCommentsTextID();
    PlanTemplateMilestoneDtls planTemplateMilestoneDtls = new
      PlanTemplateMilestoneDtls();

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 21);
    }

    planTemplateMilestoneKey.planTemplateMilestoneID = localizableTextTranslationDetails.localizableTextParentID;

    planTemplateMilestoneDtls = planTemplateMilestoneObj.read(
      planTemplateMilestoneKey);

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplateMilestoneDtls.commentsTextID) {
      // END, CR00246419

      // Handling legacy Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      textID = localizableTextHandler.store();
      planTemplateMilestoneCommentsTextID.commentsTextID = textID;
      planTemplateMilestoneCommentsTextID.versionNo = planTemplateMilestoneDtls.versionNo;
      planTemplateMilestoneObj.modifyCommentsTextID(planTemplateMilestoneKey,
        planTemplateMilestoneCommentsTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplateMilestoneDtls.commentsTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplateMilestoneDtls.commentsTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      localizableTextHandler.store();
    }
  }

  /**
   * Creates a text translation for the PlanTemplatePlanItem attribute,
   * description.
   *
   * @param localizableTextTranslationDetails contains the
   * localizable text translation details used for
   * PlanTemplatePlanItem attribute, description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text
   * to be translated is empty.
   * {@link GENERAL#ERR_LOCALE_EMPTY ERR_LOCALE_EMPTY} - if locale is
   * empty.
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addTemplatePlanItemDescriptionTextTranslation(final
    LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    PlanTemplatePlanItem planTemplatePlanItemObj = PlanTemplatePlanItemFactory.newInstance();
    PlanTemplatePlanItemKey planTemplatePlanItemKey = new
      PlanTemplatePlanItemKey();
    PlanTemplatePlanItemDescriptionTextID planTemplatePlanItemDescriptionTextID = new PlanTemplatePlanItemDescriptionTextID();
    PlanTemplatePlanItemDtls planTemplatePlanItemDtls = new
      PlanTemplatePlanItemDtls();

    planTemplatePlanItemKey.key.planTemplatePlanItemID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_TEXT_EMPTY);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_LOCALE_EMPTY);
    }

    planTemplatePlanItemDtls = planTemplatePlanItemObj.read(
      planTemplatePlanItemKey.key);

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplatePlanItemDtls.descriptionTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !planTemplatePlanItemDtls.description.equals(CuramConst.gkEmpty)) {

        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        throw e;

      }

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      String value = planTemplatePlanItemDtls.description;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      planTemplatePlanItemDescriptionTextID.descriptionTextID = textID;
      planTemplatePlanItemDescriptionTextID.versionNo = planTemplatePlanItemDtls.versionNo;
      planTemplatePlanItemObj.modifyDescriptionTextID(
        planTemplatePlanItemKey.key, planTemplatePlanItemDescriptionTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplatePlanItemDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplatePlanItemDtls.descriptionTextID);
      
      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the PlanTemplatePlanItem
   * attribute,Description.
   * @param localizableNameTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text used for the localization of
   * PlanTemplatePlanItem attribute,Description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyTemplatePlanItemDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    PlanTemplatePlanItem planTemplatePlanItemObj = PlanTemplatePlanItemFactory.newInstance();
    PlanTemplatePlanItemKey planTemplatePlanItemKey = new
      PlanTemplatePlanItemKey();
    PlanTemplatePlanItemDescriptionTextID planTemplatePlanItemDescriptionTextID = new PlanTemplatePlanItemDescriptionTextID();
    PlanTemplatePlanItemDtls planTemplatePlanItemDtls = new
      PlanTemplatePlanItemDtls();

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 23);
    }

    planTemplatePlanItemKey.key.planTemplatePlanItemID = localizableTextTranslationDetails.localizableTextParentID;

    planTemplatePlanItemDtls = planTemplatePlanItemObj.read(
      planTemplatePlanItemKey.key);

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplatePlanItemDtls.descriptionTextID) {
      // END, CR00246419

      // Handling legacy Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      textID = localizableTextHandler.store();
      planTemplatePlanItemDescriptionTextID.descriptionTextID = textID;
      planTemplatePlanItemDescriptionTextID.versionNo = planTemplatePlanItemDtls.versionNo;
      planTemplatePlanItemObj.modifyDescriptionTextID(
        planTemplatePlanItemKey.key, planTemplatePlanItemDescriptionTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplatePlanItemDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplatePlanItemDtls.descriptionTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      localizableTextHandler.store();
    }
  }

  // END, CR00228796

  // BEGIN, CR00235328, GP

  /**
   * Creates a text translation for the PlanTemplatePlanGroup attribute, name.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for
   * PlanTemplatePlanGroup attribute, name.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY} - if text to be translated is
   * empty.
   *
   * {@link GENERAL#ERR_LOCALE_EMPTY} - if locale is empty.
   *
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addTemplatePlanGroupNameTextTranslation(final
    LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    PlanTemplatePlanGroup planTemplateObj = PlanTemplatePlanGroupFactory.newInstance();
    PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new
      PlanTemplatePlanGroupKey();

    PlanTemplatePlanGroupNameTextID planTemplatePlanGroupNameTextID = new
      PlanTemplatePlanGroupNameTextID();

    PlanTemplatePlanGroupDtls planTemplatePlanGroupDtls = new
      PlanTemplatePlanGroupDtls();

    planTemplatePlanGroupKey.key.planTemplatePlanGroupID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 18);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_LOCALE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 9);
    }

    planTemplatePlanGroupDtls = planTemplateObj.read(
      planTemplatePlanGroupKey.key);

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplatePlanGroupDtls.nameTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())) {

        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          12);

      }

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      String value = planTemplatePlanGroupDtls.name;

      localizableTextHandler.setShortTextInd(true);

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      planTemplatePlanGroupNameTextID.nameTextID = textID;
      planTemplatePlanGroupNameTextID.versionNo = planTemplatePlanGroupDtls.versionNo;
      planTemplateObj.modifyNameTextID(planTemplatePlanGroupKey.key,
        planTemplatePlanGroupNameTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplatePlanGroupDtls.nameTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplatePlanGroupDtls.nameTextID);
      
      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the PlanTemplatePlanGroup
   * attribute,name.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of
   * PlanTemplatePlanGroup attribute, name.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyTemplatePlanGroupNameTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    PlanTemplatePlanGroup planTemplateObj = PlanTemplatePlanGroupFactory.newInstance();
    PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new
      PlanTemplatePlanGroupKey();

    PlanTemplatePlanGroupNameTextID planTemplatePlanGroupNameTextID = new
      PlanTemplatePlanGroupNameTextID();

    PlanTemplatePlanGroupDtls planTemplatePlanGroupDtls = new
      PlanTemplatePlanGroupDtls();

    planTemplatePlanGroupKey.key.planTemplatePlanGroupID = localizableTextTranslationDetails.localizableTextParentID;

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 14);
    }

    planTemplatePlanGroupDtls = planTemplateObj.read(
      planTemplatePlanGroupKey.key);
    
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplatePlanGroupDtls.nameTextID) {
      // END, CR00246419

      // Handling legacy Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      textID = localizableTextHandler.store();
      planTemplatePlanGroupNameTextID.nameTextID = textID;
      planTemplatePlanGroupNameTextID.versionNo = planTemplatePlanGroupDtls.versionNo;
      planTemplateObj.modifyNameTextID(planTemplatePlanGroupKey.key,
        planTemplatePlanGroupNameTextID);
      
      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplatePlanGroupDtls.nameTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplatePlanGroupDtls.nameTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      localizableTextHandler.store();
    }
  }

  /**
   * Creates a text translation for the PlanTemplatePlanGroup attribute,
   * description.
   *
   * @param localizableTextTranslationDetails contains the
   * localizable text translation details used for
   * PlanTemplatePlanGroup attribute, comments.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text
   * to be translated is empty.
   * {@link GENERAL#ERR_LOCALE_EMPTY ERR_LOCALE_EMPTY} - if locale is
   * empty.
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addTemplatePlanGroupCommentsTextTranslation(final
    LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();
    PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new
      PlanTemplatePlanGroupKey();
    PlanTemplatePlanGroupCommentsTextID planTemplatePlanGroupCommentsTextID = new PlanTemplatePlanGroupCommentsTextID();
    PlanTemplatePlanGroupDtls planTemplatePlanGroupDtls = new
      PlanTemplatePlanGroupDtls();

    planTemplatePlanGroupKey.key.planTemplatePlanGroupID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 20);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_LOCALE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 11);
    }

    planTemplatePlanGroupDtls = planTemplatePlanGroupObj.read(
      planTemplatePlanGroupKey.key);

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplatePlanGroupDtls.commentsTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !planTemplatePlanGroupDtls.comments.equals(CuramConst.gkEmpty)) {

        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          16);

      }

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      String value = planTemplatePlanGroupDtls.comments;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      planTemplatePlanGroupCommentsTextID.commentsTextID = textID;
      planTemplatePlanGroupCommentsTextID.versionNo = planTemplatePlanGroupDtls.versionNo;
      planTemplatePlanGroupObj.modifyCommentsTextID(
        planTemplatePlanGroupKey.key, planTemplatePlanGroupCommentsTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplatePlanGroupDtls.commentsTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplatePlanGroupDtls.commentsTextID);
      
      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the PlanTemplatePlanGroup
   * attribute,comments.
   * @param localizableNameTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text used for the localization of
   * PlanTemplatePlanGroup attribute,comments.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyTemplatePlanGroupCommentsTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    PlanTemplatePlanGroup planTemplatePlanGroupObj = PlanTemplatePlanGroupFactory.newInstance();
    PlanTemplatePlanGroupKey planTemplatePlanGroupKey = new
      PlanTemplatePlanGroupKey();
    PlanTemplatePlanGroupCommentsTextID planTemplatePlanGroupCommentsTextID = new PlanTemplatePlanGroupCommentsTextID();
    PlanTemplatePlanGroupDtls planTemplatePlanGroupDtls = new
      PlanTemplatePlanGroupDtls();

    planTemplatePlanGroupKey.key.planTemplatePlanGroupID = localizableTextTranslationDetails.localizableTextParentID;

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      throw new AppException(GENERAL.ERR_TEXT_EMPTY);
    }

    planTemplatePlanGroupKey.key.planTemplatePlanGroupID = localizableTextTranslationDetails.localizableTextParentID;

    planTemplatePlanGroupDtls = planTemplatePlanGroupObj.read(
      planTemplatePlanGroupKey.key);

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplatePlanGroupDtls.commentsTextID) {
      // END, CR00246419

      // Handling legacy Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      textID = localizableTextHandler.store();
      planTemplatePlanGroupCommentsTextID.commentsTextID = textID;
      planTemplatePlanGroupCommentsTextID.versionNo = planTemplatePlanGroupDtls.versionNo;
      planTemplatePlanGroupObj.modifyCommentsTextID(
        planTemplatePlanGroupKey.key, planTemplatePlanGroupCommentsTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != planTemplatePlanGroupDtls.commentsTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplatePlanGroupDtls.commentsTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      localizableTextHandler.store();
    }
  }

  // END, CR00235328
  
  // BEGIN, CR00247170, GP
  /**
   * Creates a text translation for the PlanTemplateSubGoal attribute,
   * description.
   *
   * @param localizableTextTranslationDetails contains the
   * localizable text translation details used for
   * PlanTemplateSubGoal attribute, description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text
   * to be translated is empty.
   * {@link GENERAL#ERR_LOCALE_EMPTY ERR_LOCALE_EMPTY} - if locale is
   * empty.
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if
   * translation for that locale exists already.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void addTemplateSubGoalDescriptionTextTranslation(final
    LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    PlanTemplateSubGoal planTemplateSubGoalObj = PlanTemplateSubGoalFactory.newInstance();
    PlanTemplateSubGoalKey planTemplateSubGoalKey = new
      PlanTemplateSubGoalKey();
    PlanTemplateSubGoalDescriptionTextID planTemplateSubGoalDescriptionTextID = new PlanTemplateSubGoalDescriptionTextID();
    PlanTemplateSubGoalDtls planTemplateSubGoalDtls = new
      PlanTemplateSubGoalDtls();

    planTemplateSubGoalKey.key.planTemplateSubGoalID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 17);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_LOCALE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 10);
    }

    planTemplateSubGoalDtls = planTemplateSubGoalObj.read(
      planTemplateSubGoalKey.key);

    // Handling legacy Data.
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplateSubGoalDtls.descriptionTextID) {

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !planTemplateSubGoalDtls.description.equals(CuramConst.gkEmpty)) {

        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          11);

      }

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      String value = planTemplateSubGoalDtls.description;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      planTemplateSubGoalDescriptionTextID.descriptionTextID = textID;
      planTemplateSubGoalDescriptionTextID.versionNo = planTemplateSubGoalDtls.versionNo;
      planTemplateSubGoalObj.modifyDescriptionTextID(planTemplateSubGoalKey.key,
        planTemplateSubGoalDescriptionTextID);
   
    } else if (0 != planTemplateSubGoalDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplateSubGoalDtls.descriptionTextID);
      
      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the PlanTemplateSubGoal
   * attribute,Description.
   * @param localizableNameTextTranslationDetails contains the
   * localizable text translation details like locale code,
   * localizable text used for the localization of
   * PlanTemplateSubGoal attribute,Description.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyTemplateSubGoalDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    PlanTemplateSubGoal planTemplateSubGoalObj = PlanTemplateSubGoalFactory.newInstance();
    PlanTemplateSubGoalKey planTemplateSubGoalKey = new
      PlanTemplateSubGoalKey();
    PlanTemplateSubGoalDescriptionTextID planTemplateSubGoalDescriptionTextID = new PlanTemplateSubGoalDescriptionTextID();
    PlanTemplateSubGoalDtls planTemplateSubGoalDtls = new
      PlanTemplateSubGoalDtls();

    planTemplateSubGoalKey.key.planTemplateSubGoalID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text is empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 22);
    }

    planTemplateSubGoalDtls = planTemplateSubGoalObj.read(
      planTemplateSubGoalKey.key);

    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == planTemplateSubGoalDtls.descriptionTextID) {

      // Handling legacy Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      textID = localizableTextHandler.store();
      planTemplateSubGoalDescriptionTextID.descriptionTextID = textID;
      planTemplateSubGoalDescriptionTextID.versionNo = planTemplateSubGoalDtls.versionNo;
      planTemplateSubGoalObj.modifyDescriptionTextID(planTemplateSubGoalKey.key,
        planTemplateSubGoalDescriptionTextID);

    } else if (0 != planTemplateSubGoalDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        planTemplateSubGoalDtls.descriptionTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      localizableTextHandler.store();
    }
  }
  // END, CR00247170
  
}
