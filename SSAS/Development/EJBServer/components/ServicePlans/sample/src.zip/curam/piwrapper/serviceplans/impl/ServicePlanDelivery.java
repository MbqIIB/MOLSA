/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.piwrapper.serviceplans.impl;


import com.google.inject.ImplementedBy;

import curam.codetable.impl.SERVICEPLANTYPEEntry;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * A wrapper read only interface for the
 * {@link curam.serviceplans.sl.entity.intf.ServicePlanDelivery} entity.
 */
// BEGIN, CR00309529, POH
@ImplementedBy(ServicePlanDeliveryImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ServicePlanDelivery extends CaseHeader {
  // END, CR00309529

  /**
   * Retrieves the {@link ServicePlan} admin configuration details.
   *
   * @return The service plan instance related to the this delivery.
   */
  ServicePlan getServicePlan();

  /**
   * Retrieves the type of service plan.
   *
   * @return The code table entry value for the service plan type.
   */
  SERVICEPLANTYPEEntry getServicePlanType();

  /**
   * Retrieves the {@link PlannedGoal} details linked to this service plan
   * delivery.
   *
   * @return An instance of {@link PlannedGoal}, or null if a goal has not been
   * assigned to the plan delivery.
   */
  PlannedGoal getPlannedGoal();
}
