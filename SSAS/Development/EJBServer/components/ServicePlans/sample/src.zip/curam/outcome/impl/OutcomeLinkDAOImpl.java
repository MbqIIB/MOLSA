/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.outcome.impl;

import java.util.Set;

import com.google.inject.Singleton;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.serviceplans.sl.entity.impl.OutcomeLinkAdapter;
import curam.serviceplans.sl.entity.struct.OutcomeDtlsList;
import curam.serviceplans.sl.entity.struct.OutcomeKey;
import curam.serviceplans.sl.entity.struct.OutcomeLinkDtls;
import curam.serviceplans.sl.entity.struct.RelatedReferenceKey;
import curam.serviceplans.sl.entity.struct.SearchOutcomeKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;

/**
 * Standard implementation of {@linkplain curam.outcome.impl.OutcomeLinkDAO}.
 */
@Singleton
// BEGIN, CR00183334, PS
public class OutcomeLinkDAOImpl extends
    StandardDAOImpl<OutcomeLink, OutcomeLinkDtls> implements OutcomeLinkDAO {
  // END, CR00183334
  /**
   * Instance of Outcome Link adapter.
   */
  private static final OutcomeLinkAdapter outcomeLinkAdapter = new OutcomeLinkAdapter();

  /**
   * Constructor for the class.
   */
  // BEGIN, CR00183334, PS
  protected OutcomeLinkDAOImpl() {
    // END, CR00183334
    super(outcomeLinkAdapter, OutcomeLink.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<OutcomeLink> searchByRelatedReference(
      RelatedReferenceKey relatedReferenceKey) {

    return newSet(outcomeLinkAdapter
        .searchByRelatedReference(relatedReferenceKey.relatedID));
  }

  /**
   * {@inheritDoc}
   */
  public Set<OutcomeLink> searchByOutcome(OutcomeKey outcomeKey) {

    return newSet(outcomeLinkAdapter.searchByOutcome(outcomeKey.outcomeID));
  }

  /**
   * {@inheritDoc}
   */
  public OutcomeDtlsList searchUnassociatedOutcomesForRelatedReference(
      Long relatedReferenceID, RECORDSTATUSEntry recordStatus)
      throws AppException, InformationalException {

    curam.serviceplans.sl.entity.intf.OutcomeLink outcomeLinkObj = curam.serviceplans.sl.entity.fact.OutcomeLinkFactory
        .newInstance();

    SearchOutcomeKey searchOutcomeKey = new SearchOutcomeKey();
    searchOutcomeKey.relatedID = relatedReferenceID;
    searchOutcomeKey.outcomeStatus = recordStatus.getCode();

    return outcomeLinkObj.searchUnassociatedOutcomes(searchOutcomeKey);
  }
}
