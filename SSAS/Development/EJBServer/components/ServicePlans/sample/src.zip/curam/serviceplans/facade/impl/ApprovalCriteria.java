/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.facade.impl;

import com.google.inject.Inject;

import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.serviceplans.facade.struct.ApprovalCriteriaDetails;
import curam.serviceplans.facade.struct.ApprovalCriteriaDetailsList;
import curam.serviceplans.facade.struct.ApprovalCriteriaID;
import curam.serviceplans.facade.struct.CancelApprovalCriteriaDetails;
import curam.serviceplans.sl.fact.ApprovalCriteriaFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTableItemIdentifier;
import curam.workspaceservices.facade.struct.LocalizableTextDetails;
import curam.workspaceservices.facade.struct.TextTranslationDetails;
import curam.workspaceservices.facade.struct.ViewLocalizableTextDetails;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.impl.TextTranslation;
import curam.workspaceservices.localization.impl.TextTranslationDAO;


/** 
 * Process class implementing the Approval Criteria facade layer.
 */
public class ApprovalCriteria extends
    curam.serviceplans.facade.base.ApprovalCriteria {
  
  // BEGIN, CR00227878, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;
  @Inject
  private TextTranslationDAO textTranslationDAO;
  
  /**
   * Default constructor.
   */
  public ApprovalCriteria() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  
 // END, CR00227878
  /**
   * Create a new ApprovalCriteria entry
   * 
   * @param details Details for creation of the approval criteria
   * @throws AppException, InformationalException  
   */
  public void createApprovalCriteria(final ApprovalCriteriaDetails details)
      throws AppException, InformationalException {
    
    curam.serviceplans.sl.intf.ApprovalCriteria approvalObj = 
      ApprovalCriteriaFactory.newInstance();
    
    approvalObj.createApprovalCriteria(details.details);    
  }


  // __________________________________________________________________________ 
  /**
   * List all approval criteria in the system
   * 
   * @return Approval criteria details list
   * @throws AppException, InformationalException  
   */
  public ApprovalCriteriaDetailsList listApprovalCriteria()
      throws AppException, InformationalException {
    
    ApprovalCriteriaDetailsList appCritDtlsList 
      = new ApprovalCriteriaDetailsList();
    
    curam.serviceplans.sl.intf.ApprovalCriteria approvalObj = 
      ApprovalCriteriaFactory.newInstance();
    
    appCritDtlsList.list.assign(approvalObj.listApprovalCriteria());
   
    return appCritDtlsList;
  }

  
  //___________________________________________________________________________
  /**
   * Modify Approval Criteria
   * 
   * @param details 
   *           The details for the approval criteria to modify
   * @throws AppException, InformationalException  
   */
  public void modifyApprovalCriteria(ApprovalCriteriaDetails details)
      throws AppException, InformationalException {

    curam.serviceplans.sl.intf.ApprovalCriteria approvalObj = 
      ApprovalCriteriaFactory.newInstance();   

    approvalObj.modifyApprovalCriteria(details.details);  
  }


  //___________________________________________________________________________
  /**
   * Read Approval Criteria entry
   * 
   * @param key 
   *           Contains the ID of the approval criteria record to read
   * @returns ApprovalCriteriaDetails 
   *           Details for the specified approval criteria record
   * @throws AppException, InformationalException 
   */
  public ApprovalCriteriaDetails readApprovalCriteria(ApprovalCriteriaID key)
      throws AppException, InformationalException {
    
    ApprovalCriteriaDetails readDetails = new ApprovalCriteriaDetails();

    curam.serviceplans.sl.intf.ApprovalCriteria approvalObj = 
      ApprovalCriteriaFactory.newInstance();

    readDetails.details.assign(approvalObj.readApprovalCriteria(key.key));
    
    // BEGIN, CR00227878, GP 
    // Read the localized description.
   if ( readDetails.details.dtls.descriptionTextID != 0 ) {
      
      LocalizableTextHandler localizableText = localizableTextHandlerDAO
          .get(readDetails.details.dtls.descriptionTextID); 
      readDetails.details.dtls.description = localizableText.getValue(
          LOCALEEntry.get(ProgramLocale.getLocale(TransactionInfo.getProgramUser
            ()).toString())); 
    } 
    // END, CR00227878
   
   readDetails.contextDescription 
      = getApprovalCriteriaContextDescription(readDetails);
   
    return readDetails;
  }


  //___________________________________________________________________________
  /** 
   * Cancel an existing approval criteria entry
   * 
   * @param details 
   *           Details used to specify an approval criteria record to cancel 
   * @throws AppException, InformationalException  
   */
  public void cancelApprovalCriteria(CancelApprovalCriteriaDetails details)
      throws AppException, InformationalException {

    curam.serviceplans.sl.intf.ApprovalCriteria approvalObj = 
      ApprovalCriteriaFactory.newInstance();
    
    approvalObj.cancelApprovalCriteria(details.details);
  }


  // __________________________________________________________________________
  /**
   * Helper method that reads approval criteria context description.  This
   * method is not modeled.
   *
   * @param details 
   *           Details read from database
   * @return String 
   *           containing the context description
   * @throws AppException, InformationalException  
   */
  protected String getApprovalCriteriaContextDescription(
    ApprovalCriteriaDetails details) 
    throws AppException, InformationalException {

    String contextDescription = null;
    
    // create the context description
    LocalisableString description =
      new LocalisableString(
        curam.message.BPOSERVICEPLAN.INF_MENU_CTI_DESCRIPTION);

    description.arg(
      new CodeTableItemIdentifier(
          curam.codetable.APPROVALCRITERIANAME.TABLENAME,
          details.details.dtls.criteriaName));

    // assign it to the return object
    contextDescription =  description.toClientFormattedText();

    // return context description
    return contextDescription;
  }  
  // BEGIN, CR00227878, GP
  /**
   * Assigns the text translation details.
   *  
   * @param textTranslation
   *        The text translation information.
   * 
   * @return The text translation details.
   */
  protected TextTranslationDetails assignTextTranslationDtls(final 
      TextTranslation textTranslation) {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails()
        ;
    textTranslationDetails.dtls.localeCode = textTranslation.getLocale()
        .getCode();
    textTranslationDetails.dtls.localizableTextID = textTranslation
        .getLocalizableTextID();
    textTranslationDetails.dtls.text = textTranslation.getText();
    textTranslationDetails.dtls.textTranslationID = textTranslation.getID();
    return textTranslationDetails;
  }

  /**
   * Provides text translation for the  attribute.
   * 
   * @param LocalizableNameTextTranslationDetails
   *        The localizable name text translation details.
   * 
   * @return The view localizable text details.
   *  
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  protected ViewLocalizableTextDetails getTextTranslation(
      final LocalizableTextDetails localizableTextTranslationDetails)
        throws AppException, InformationalException {

    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO
        .get(localizableTextTranslationDetails.dtls.localizableTextID);
    ViewLocalizableTextDetails viewLocalizableTextDetails = new 
        ViewLocalizableTextDetails();
    viewLocalizableTextDetails.dtls.localizableTextID = localizableTextHandler
        .getID();

    for (TextTranslation textTranslation : localizableTextHandler
        .listTranslations()) {

      TextTranslationDetails textTranslationDetails = assignTextTranslationDtls(
         textTranslation);
      viewLocalizableTextDetails.translations.dtls.addRef(
          textTranslationDetails);

    }
    return viewLocalizableTextDetails;
  }
  
  /**
   * Creates a text translation for the Approval Criteria attribute, description.
   * 
   * @param localizableTextTranslationDetails
   *          The localizable text translation details used for Approval Criteria  
   *          description.
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  public void addDescriptionTextTranslation(
      final LocalizableTextDetails localizableTextDetails)
      throws AppException, InformationalException {
        
    curam.serviceplans.sl.intf.ApprovalCriteria approvalCriteriaObj = 
        ApprovalCriteriaFactory.newInstance();
    
    approvalCriteriaObj.addDescriptionTextTranslation(localizableTextDetails
        .dtls);
  }
  
  /**
   * Modifies the text translation details for the Approval Criteria attribute, 
   * description.
   * 
   * @param localizableNameTextTranslationDetails
   *          The localizable name text translation details like locale code,
   *          localizable text used for the localization of Approval Criteria 
   *          description.
   * 
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  public void modifyDescriptionTextTranslation(
      final LocalizableTextDetails localizableTextDetails)
      throws AppException, InformationalException {
    
    curam.serviceplans.sl.intf.ApprovalCriteria approvalCriteriaObj = 
      ApprovalCriteriaFactory.newInstance();

    approvalCriteriaObj.modifyDescriptionTextTranslation(localizableTextDetails
        .dtls);
  }
  
  /**
   * Reads the text translation for the Approval Criteria attribute, description.
   * 
   * @param localizableNameTextTranslationDetails
   *          The localizable text translation details like locale code,
   *          localizable text, etc. for the Approval Criteria description.
   * 
   * @return The Text translation details.
   * 
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  public TextTranslationDetails readDescriptionTextTranslation(
      final LocalizableTextDetails localizableTextDetails)
        throws AppException, InformationalException {
    
    TextTranslationDetails textTranslationDetails = new 
        TextTranslationDetails();

     // Handle legacy data.
     if (0 == localizableTextDetails.dtls.localizableTextID
         && 0 == localizableTextDetails.dtls.textTranslationID) {

       textTranslationDetails.dtls.localeCode = ProgramLocale
           .getDefaultServerLocale();      

       curam.serviceplans.sl.intf.ApprovalCriteria approvalCriteriaObj = 
           ApprovalCriteriaFactory.newInstance();
  
       curam.serviceplans.sl.struct.ApprovalCriteriaDetails 
           approvalCriteriaDetails = new curam.serviceplans.sl.struct
             .ApprovalCriteriaDetails(); 
      curam.serviceplans.sl.struct.ApprovalCriteriaID approvalCriteriaKey = new 
          curam.serviceplans.sl.struct.ApprovalCriteriaID();

      // As there is no localization yet, read it from Approval Criteria entity. 
      approvalCriteriaKey.approvalCriteriaID = localizableTextDetails.dtls
          .localizableTextParentID;
  
      approvalCriteriaDetails = approvalCriteriaObj.readApprovalCriteria(
          approvalCriteriaKey);
   
      textTranslationDetails.dtls.text = approvalCriteriaDetails.dtls
          .description;
          
      textTranslationDetails.dtls.localeCode = ProgramLocale
          .getDefaultServerLocale(); 

    } else {

      TextTranslation textTranslation = textTranslationDAO.get(
          localizableTextDetails.dtls.textTranslationID);
      textTranslationDetails = assignTextTranslationDtls(textTranslation);  
    }

    return textTranslationDetails;
    
  }
  
  /**
   * Lists the text translations for the Approval Criteria attribute, 
   * description.
   * 
   * @param localizableTextTranslationDetails
   *          The localizable text translation details like locale code,
   *          localizable text, etc. for the description.
   * 
   * @return The view text translation details.
   * 
   * @throws AppException
   *           Generic Exception Signature.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  public ViewLocalizableTextDetails listLocalizableDescriptionText(
      final LocalizableTextDetails localizableTextDetails) throws 
        AppException, InformationalException {
    
    ViewLocalizableTextDetails viewLocalizableTextDetails = new 
    ViewLocalizableTextDetails();
    TextTranslationDetails textTranslationDetails = new TextTranslationDetails()
        ;
    curam.serviceplans.sl.intf.ApprovalCriteria approvalCriteriaObj = 
        ApprovalCriteriaFactory.newInstance();
    curam.serviceplans.sl.struct.ApprovalCriteriaDetails 
        approvalCriteriaDetails = new curam.serviceplans.sl.struct
          .ApprovalCriteriaDetails();
    curam.serviceplans.sl.struct.ApprovalCriteriaID approvalCriteriaKey = new 
        curam.serviceplans.sl.struct.ApprovalCriteriaID();

    approvalCriteriaKey.approvalCriteriaID = 
        localizableTextDetails.dtls.localizableTextParentID;      
    approvalCriteriaDetails = approvalCriteriaObj.readApprovalCriteria(
        approvalCriteriaKey); 

     // Handle new data.
    if (0 != localizableTextDetails.dtls.localizableTextID) {
      viewLocalizableTextDetails = getTextTranslation(localizableTextDetails);
    }
    // BEGIN, CR00229083, GP
    else if (0 != approvalCriteriaDetails.dtls.descriptionTextID) { 
        
      LocalizableTextDetails localizableTextDtls = new LocalizableTextDetails();
      localizableTextDtls.dtls.localizableTextID = approvalCriteriaDetails.dtls
          .descriptionTextID;        
      viewLocalizableTextDetails = getTextTranslation(localizableTextDtls);        
    }
    // END, CR00229083
    else {

      // Handle legacy data.  
      // As there is no localization yet, read it from Approval Criteria entity.  
        
      textTranslationDetails.dtls.localeCode = ProgramLocale
          .getDefaultServerLocale(); 
      textTranslationDetails.dtls.text = approvalCriteriaDetails.dtls
          .description;
      if (! textTranslationDetails.dtls.text.equals(CuramConst
          .gkEmpty)) { 
        viewLocalizableTextDetails.translations.dtls.addRef(
            textTranslationDetails);
      }
     }
   return viewLocalizableTextDetails;
  }
  // END, CR00227878
}
