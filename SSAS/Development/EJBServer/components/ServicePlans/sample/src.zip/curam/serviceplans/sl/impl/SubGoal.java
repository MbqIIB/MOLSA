/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2005, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.ContractTextDtls;
import curam.message.BPOCONTRACTTEXT;
import curam.message.BPOSUBGOAL;
import curam.message.GENERAL;
import curam.serviceplans.sl.entity.fact.SubGoalOutcomeLinkFactory;
import curam.serviceplans.sl.entity.fact.SubGoalPlanItemLinkFactory;
import curam.serviceplans.sl.entity.intf.SubGoalOutcomeLink;
import curam.serviceplans.sl.entity.intf.SubGoalPlanItemLink;
import curam.serviceplans.sl.entity.struct.OutcomeCountDetails;
import curam.serviceplans.sl.entity.struct.OutcomeDtls;
import curam.serviceplans.sl.entity.struct.PlanItemCountDetails;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.SearchUnassociatedOutcomesForSubGoalKey;
import curam.serviceplans.sl.entity.struct.SearchUnassociatedPlanItemsForSubGoalKey;
import curam.serviceplans.sl.entity.struct.SubGoalContractTextCountKey;
import curam.serviceplans.sl.entity.struct.SubGoalContractTextDtls;
import curam.serviceplans.sl.entity.struct.SubGoalContractTextRemoveKey;
import curam.serviceplans.sl.entity.struct.SubGoalDescriptionTextID;
import curam.serviceplans.sl.entity.struct.SubGoalDtls;
import curam.serviceplans.sl.entity.struct.SubGoalOutcomeKey;
import curam.serviceplans.sl.entity.struct.SubGoalOutcomeLinkDtls;
import curam.serviceplans.sl.entity.struct.SubGoalPlanItemCountKey;
import curam.serviceplans.sl.entity.struct.SubGoalPlanItemLinkDtls;
import curam.serviceplans.sl.entity.struct.SubGoalPlanItemRemoveKey;
import curam.serviceplans.sl.entity.struct.SubGoalStatusDetails;
import curam.serviceplans.sl.struct.ContractTextDetails;
import curam.serviceplans.sl.struct.ContractTextKey;
import curam.serviceplans.sl.struct.CreateContractTextDetails;
import curam.serviceplans.sl.struct.CreateOutcomeDetails;
import curam.serviceplans.sl.struct.CreatePlanItemDetails;
import curam.serviceplans.sl.struct.CreateSubGoalDetails;
import curam.serviceplans.sl.struct.ModifyContractTextDetails;
import curam.serviceplans.sl.struct.ModifySubGoalDetails;
import curam.serviceplans.sl.struct.OutcomeKey;
import curam.serviceplans.sl.struct.OutcomeKeyList;
import curam.serviceplans.sl.struct.PlanItemKey;
import curam.serviceplans.sl.struct.PlanItemKeyList;
import curam.serviceplans.sl.struct.ReadSubGoalDetails;
import curam.serviceplans.sl.struct.RemoveSubGoalContractTextKey;
import curam.serviceplans.sl.struct.SubGoalCancelKey;
import curam.serviceplans.sl.struct.SubGoalContractTextDetailsList;
import curam.serviceplans.sl.struct.SubGoalDetailsList;
import curam.serviceplans.sl.struct.SubGoalKey;
import curam.serviceplans.sl.struct.SubGoalNameDetails;
import curam.serviceplans.sl.struct.SubGoalOutcomeDetailsList;
import curam.serviceplans.sl.struct.SubGoalPlanItemDetailsList;
import curam.serviceplans.sl.struct.SubGoalUnassociatedOutcomeDetailsList;
import curam.serviceplans.sl.struct.SubGoalUnassociatedPlanItemDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.intf.TextTranslation;
import curam.workspaceservices.localization.struct.LocalizableTextTranslationDetails;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextTranslationDtls;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;


/**
 * Business layer functionality for managing service plan sub goals.
 */
public abstract class SubGoal extends curam.serviceplans.sl.base.SubGoal {

  // BEGIN, CR00228110, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public SubGoal() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00228110
  // ___________________________________________________________________________
  /**
   * Adds existing planItems to a sub goal.
   *
   * @param subGoalKey  Identifies the sub goal.
   * @param planItemKeyList The list of planItems to be added to the sub goal.
   */
  public void addExistingPlanItems(
    SubGoalKey subGoalKey,
    PlanItemKeyList planItemKeyList)
    throws AppException, InformationalException {

    // loop variables
    SubGoalPlanItemLink subGoalPlanItemLinkObj = SubGoalPlanItemLinkFactory.newInstance();
    PlanItemKey planItemKey = new PlanItemKey();
    int numOutcomes = planItemKeyList.planItemKey.size();

    // loop through all the planItems
    for (int i = 0; i < numOutcomes; i++) {

      // validate that the plan item can be added to the sub goal
      planItemKey.key.planItemID = planItemKeyList.planItemKey.item(i).key.planItemID;
      validateAddPlanItem(subGoalKey, planItemKey);

      // add the plan item to the sub goal
      SubGoalPlanItemLinkDtls subGoalPlanItemLinkDtls = new SubGoalPlanItemLinkDtls();

      subGoalPlanItemLinkDtls.subGoalID = subGoalKey.subGoalKey.subGoalID;
      subGoalPlanItemLinkDtls.planItemID = planItemKey.key.planItemID;
      subGoalPlanItemLinkObj.insert(subGoalPlanItemLinkDtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Adds existing outcomes to a sub goal.
   *
   * @param subGoalKey   Identifies the sub goal.
   * @param outcomeKeyList The list of outcomes to be added to the sub goal.
   */
  public void addExistingOutcomes(
    SubGoalKey subGoalKey,
    OutcomeKeyList outcomeKeyList)
    throws AppException, InformationalException {

    // loop variables
    SubGoalOutcomeLink subGoalOutcomeLinkObj = SubGoalOutcomeLinkFactory.newInstance();
    OutcomeKey outcomeKey = new OutcomeKey();
    int numOutcomes = outcomeKeyList.outcomeKey.size();

    // loop through all the outcomes
    for (int i = 0; i < numOutcomes; i++) {

      // validate that the outcome can be added to the sub goal
      outcomeKey.key.outcomeID = outcomeKeyList.outcomeKey.item(i).key.outcomeID;
      validateAddOutcome(subGoalKey, outcomeKey);

      // add the outcome to the sub goal
      SubGoalOutcomeLinkDtls subGoalOutcomeLinkDtls = new SubGoalOutcomeLinkDtls();

      subGoalOutcomeLinkDtls.subGoalID = subGoalKey.subGoalKey.subGoalID;
      subGoalOutcomeLinkDtls.outcomeID = outcomeKey.key.outcomeID;
      subGoalOutcomeLinkObj.insert(subGoalOutcomeLinkDtls);

    }

  }

  // ___________________________________________________________________________
  /**
   * Cancels a sub goal.
   *
   * @param key Identifies the sub goal.
   */
  public void cancel(SubGoalCancelKey key)
    throws AppException, InformationalException {

    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.SubGoalStatusDetails subGoalStatusDetails = new curam.serviceplans.sl.entity.struct.SubGoalStatusDetails();

    subGoalStatusDetails.recordStatus = curam.codetable.RECORDSTATUS.CANCELLED;
    // BEGIN, CR00228110, GP
    SubGoalKey subGoalKey = new SubGoalKey();

    subGoalKey.subGoalKey.subGoalID = key.key.subGoalID;
    key.key.versionNo = read(subGoalKey).dtls.versionNo;
    // END, CR00228110
    subGoalObj.cancel(key.key, subGoalStatusDetails);

    // Service plans workflow raise event integration
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.DELETESUBGOAL;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = key.key.subGoalID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // ___________________________________________________________________________
  /**
   * Creates a sub goal.
   *
   * @param details The details for the new sub goal.
   *
   * @return The ID of the new sub goal.
   */
  public SubGoalKey create(CreateSubGoalDetails details)
    throws AppException, InformationalException {

    // populate the sub goal details
    curam.serviceplans.sl.entity.struct.SubGoalDtls subGoalDtls = new curam.serviceplans.sl.entity.struct.SubGoalDtls();

    // assign the creation details
    subGoalDtls.assign(details.createSubGoalDetails);

    // default the record status and creation date
    subGoalDtls.recordStatus = RECORDSTATUS.NORMAL;
    subGoalDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // insert the sub goal details
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    // BEGIN, CR00228110, GP
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

    if (!subGoalDtls.description.equals(CuramConst.gkEmpty)) {

      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      localizableTextHandler.addValue(subGoalDtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      subGoalDtls.descriptionTextID = localizableTextHandler.store();
    } else {
      // If description is empty, create only localizableID. No translation is
      // required.
      localizableTextHandler = localizableTextHandlerDAO.newInstance();
      subGoalDtls.descriptionTextID = localizableTextHandler.store();
    }

    subGoalDtls.description = null;
    // END, CR00228110

    subGoalObj.insert(subGoalDtls);

    // return sub goal identifier
    SubGoalKey subGoalKey = new SubGoalKey();

    subGoalKey.subGoalKey.subGoalID = subGoalDtls.subGoalID;

    // Service plans workflow raise event integration
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.CREATESUBGOAL;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = subGoalDtls.subGoalID;
    curam.util.events.impl.EventService.raiseEvent(event);

    return subGoalKey;

  }

  // ___________________________________________________________________________
  /**
   * Creates an plan item associated with a sub goal.
   *
   * @param subGoalKey        Identifies the sub goal.
   * @param createPlanItemDetails The details for the new planItem.
   *
   * @return The ID of the new planItem.
   */
  public PlanItemKey createPlanItem(
    SubGoalKey subGoalKey,
    CreatePlanItemDetails createPlanItemDetails)
    throws AppException, InformationalException {

    //
    // validate sub goal
    //

    // SubGoal entity manipulation variables
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    // read sub goal record status
    curam.serviceplans.sl.entity.struct.SubGoalStatusDetails subGoalStatusDetails = subGoalObj.readRecordStatus(
      subGoalKey.subGoalKey);

    // sub goal cannot be created for a cancelled goal
    if (!subGoalStatusDetails.recordStatus.equals(RECORDSTATUS.NORMAL)) {
      throw new AppException(BPOSUBGOAL.ERR_SUBGOAL_CANCELED);
    }

    //
    // create the planItem
    //

    // populate the details
    PlanItemDtls planItemDtls = new PlanItemDtls();

    planItemDtls.assign(createPlanItemDetails);

    // default the record status and creation date
    planItemDtls.recordStatus = RECORDSTATUS.NORMAL;
    planItemDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // create the plan item record
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    planItemObj.insert(planItemDtls);

    //
    // link the plan item to the sub goal
    //

    // populate the link details
    SubGoalPlanItemLinkDtls subGoalPlanItemLinkDtls = new SubGoalPlanItemLinkDtls();

    subGoalPlanItemLinkDtls.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalPlanItemLinkDtls.planItemID = planItemDtls.planItemID;

    // insert the link
    curam.serviceplans.sl.entity.intf.SubGoalPlanItemLink subGoalPlanItemLinkObj = curam.serviceplans.sl.entity.fact.SubGoalPlanItemLinkFactory.newInstance();

    subGoalPlanItemLinkObj.insert(subGoalPlanItemLinkDtls);

    //
    // return the new plan item id
    //

    PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.key.planItemID = planItemDtls.planItemID;
    return planItemKey;

  }

  // ___________________________________________________________________________
  /**
   * Creates a contract text associated with a sub goal.
   *
   * @param subGoalKey              Identifies the sub goal
   * @param createContractTextDetails The details of the new contract text.
   *
   * @return The ID of the new contract text.
   */
  public ContractTextKey createContractText(
    SubGoalKey subGoalKey,
    CreateContractTextDetails createContractTextDetails)
    throws AppException, InformationalException {

    //
    // add the contract text and link it to the sub goal
    //

    // contract text variables
    curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();
    ContractTextDtls contractTextDtls = new ContractTextDtls();

    validateAddContractText(subGoalKey, createContractTextDetails);

    // ensure that contract text does not exist already for the chosen language
    validateAddContractText(subGoalKey, createContractTextDetails);

    // insert the contract text record
    contractTextDtls.contractText = createContractTextDetails.contractText;
    contractTextDtls.languageCode = createContractTextDetails.languageCode;
    contractTextDtls.recordStatus = RECORDSTATUS.NORMAL;
    // set the contract text type to Service plans
    contractTextDtls.typeCode = curam.codetable.CONTRACTTEXTTYPE.SERVICEPLANS;

    // create contract text
    contractTextObj.insert(contractTextDtls);

    // add the sub goal contract text link
    SubGoalContractTextDtls subGoalContractTextDtls = new SubGoalContractTextDtls();

    subGoalContractTextDtls.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalContractTextDtls.contractTextID = contractTextDtls.contractTextID;
    curam.serviceplans.sl.entity.intf.SubGoalContractText subGoalContractTextObj = curam.serviceplans.sl.entity.fact.SubGoalContractTextFactory.newInstance();

    subGoalContractTextObj.insert(subGoalContractTextDtls);

    // return the contract text id
    ContractTextKey contractTextKey = new ContractTextKey();

    contractTextKey.contractTextKey.contractTextID = contractTextDtls.contractTextID;
    return contractTextKey;

  }

  // ___________________________________________________________________________
  /**
   * Creates an outcome associated with a sub goal.
   *
   * @param subGoalKey         Identifies the sub goal.
   * @param createOutcomeDetails The details of the new outcome.
   *
   * @return The ID of the new outcome.
   */
  public OutcomeKey createOutcome(
    SubGoalKey subGoalKey,
    CreateOutcomeDetails createOutcomeDetails)
    throws AppException, InformationalException {

    //
    // create the outcome
    //

    // populate the details
    OutcomeDtls outcomeDtls = new OutcomeDtls();

    outcomeDtls.assign(createOutcomeDetails.createOutcomeDetails);

    // default the record status and creation date
    outcomeDtls.recordStatus = RECORDSTATUS.NORMAL;
    outcomeDtls.dateCreated = curam.util.type.Date.getCurrentDate();

    // create the outcome record
    curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();

    outcomeObj.insert(outcomeDtls);

    //
    // link the outcome to the planItem
    //

    // populate the link details
    SubGoalOutcomeLinkDtls subGoalOutcomeLinkDtls = new SubGoalOutcomeLinkDtls();

    subGoalOutcomeLinkDtls.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalOutcomeLinkDtls.outcomeID = outcomeDtls.outcomeID;

    // insert the link
    curam.serviceplans.sl.entity.intf.SubGoalOutcomeLink subGoalOutcomeLinkObj = curam.serviceplans.sl.entity.fact.SubGoalOutcomeLinkFactory.newInstance();

    subGoalOutcomeLinkObj.insert(subGoalOutcomeLinkDtls);

    //
    // return the new outcome id
    //

    OutcomeKey outcomeKey = new OutcomeKey();

    outcomeKey.key.outcomeID = outcomeDtls.outcomeID;
    return outcomeKey;

  }

  // ___________________________________________________________________________
  /**
   * Lists all sub goals.
   *
   * @return A list of all sub goals.
   */
  public SubGoalDetailsList list()
    throws AppException, InformationalException {

    // return object
    SubGoalDetailsList subGoalDetailsList = new SubGoalDetailsList();

    // call the entity list method to populate the return object
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    subGoalDetailsList.dtls = subGoalObj.readAll();

    return subGoalDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all planItems associated with a specific sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return A list of all planItems associated with the sub goal.
   */
  public SubGoalPlanItemDetailsList listPlanItems(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    SubGoalPlanItemDetailsList planItemList = new SubGoalPlanItemDetailsList();

    // read the plan item list and populate the return object
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    planItemList.dtls = subGoalObj.searchPlanItems(key.subGoalKey);

    return planItemList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all contract texts associated with a specific sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return A list of contract texts associated with the sub goal.
   */
  public SubGoalContractTextDetailsList listContractTexts(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    SubGoalContractTextDetailsList contractTextList = new SubGoalContractTextDetailsList();

    // read the list of contracts and populate the return object
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    contractTextList.dtls = subGoalObj.searchContractTexts(key.subGoalKey);

    return contractTextList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all outcomes associated with a specific sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return A list of outcomes associated with the sub goal.
   */
  public SubGoalOutcomeDetailsList listOutcomes(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    SubGoalOutcomeDetailsList outcomeList = new SubGoalOutcomeDetailsList();

    // read the outcome list and populate the return object
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    outcomeList.dtls = subGoalObj.searchOutcomes(key.subGoalKey);

    return outcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all planItems not associated with a specific sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return A list of planItems not associated with the sub goal.
   */
  public SubGoalUnassociatedPlanItemDetailsList listUnassociatedPlanItems(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    SubGoalUnassociatedPlanItemDetailsList unassociatedPlanItemList = new SubGoalUnassociatedPlanItemDetailsList();

    // populate the search key
    SearchUnassociatedPlanItemsForSubGoalKey searchKey = new SearchUnassociatedPlanItemsForSubGoalKey();

    searchKey.subGoalID = key.subGoalKey.subGoalID;
    searchKey.planItemRecordStatus = RECORDSTATUS.NORMAL;

    // read the list of unassociated planItems
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    unassociatedPlanItemList.dtls = subGoalObj.searchUnassociatedPlanItemsByStatus(
      searchKey);

    return unassociatedPlanItemList;

  }

  // ___________________________________________________________________________
  /**
   * Lists all outcomes not associated with a specific sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return A list of outcomes not associated with the sub goal.
   */
  public SubGoalUnassociatedOutcomeDetailsList listUnassociatedOutcomes(SubGoalKey key)
    throws AppException, InformationalException {

    // return object
    SubGoalUnassociatedOutcomeDetailsList unassociatedOutcomeList = new SubGoalUnassociatedOutcomeDetailsList();

    // populate the search key
    SearchUnassociatedOutcomesForSubGoalKey searchKey = new SearchUnassociatedOutcomesForSubGoalKey();

    searchKey.subGoalID = key.subGoalKey.subGoalID;
    searchKey.outcomeRecordStatus = RECORDSTATUS.NORMAL;

    // read the list of unassociated outcomes
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    unassociatedOutcomeList.dtls = subGoalObj.searchUnassociatedOutcomesByStatus(
      searchKey);

    return unassociatedOutcomeList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies a sub goal.
   *
   * @param details The modified sub goal details.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOSUBGOAL#ERR_SUBGOAL_CANCELED ERR_SUBGOAL_CANCELED} - if
   * the subgoal to be modified is already canceled.
   */
  public void modify(ModifySubGoalDetails details)
    throws AppException, InformationalException {

    // populate the modify key
    curam.serviceplans.sl.entity.struct.SubGoalKey subGoalKey = new curam.serviceplans.sl.entity.struct.SubGoalKey();

    subGoalKey.subGoalID = details.dtls.subGoalID;

    // populate the modify details
    curam.serviceplans.sl.entity.struct.SubGoalDtls subGoalDtls = new curam.serviceplans.sl.entity.struct.SubGoalDtls();

    subGoalDtls.assign(details.dtls);

    // modify the sub goal
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    // BEGIN, CR00228110, GP

    SubGoalStatusDetails subGoalStatusDetails = subGoalObj.readRecordStatus(
      subGoalKey);

    // check if the sub goal already canceled.
    if (subGoalStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);

    }
    // Modify localized description.
    long descriptionTextID;

    // Modify Localized description.
    if (0 == subGoalDtls.descriptionTextID) {

      if (!subGoalDtls.description.equals(CuramConst.gkEmpty)) {
        // Handling Legacy data.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        localizableTextHandler.addValue(subGoalDtls.description,
          LOCALEEntry.get(
          (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
        descriptionTextID = localizableTextHandler.store();
      } else {
        // If description is empty, just create localizableTextID.
        LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

        descriptionTextID = localizableTextHandler.store();
      }

      // Update the entity struct.
      subGoalDtls.descriptionTextID = descriptionTextID;

    } else {

      // Handling New data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        subGoalDtls.descriptionTextID);

      localizableTextHandler.addValue(subGoalDtls.description,
        LOCALEEntry.get(
        (ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString())));
      localizableTextHandler.store();

    }

    subGoalDtls.description = null;
    // END, CR00228110


    subGoalObj.modify(subGoalKey, subGoalDtls);

    // Service plans workflow raise event integration
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.MODIFYSUBGOAL;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = details.dtls.subGoalID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // ___________________________________________________________________________
  /**
   * Modifies a contract text associated with a sub goal.
   *
   * @param modifyDetails The modifies contract text details.
   */
  public void modifyContractText(ModifyContractTextDetails modifyDetails)
    throws AppException, InformationalException {

    // populate the key
    curam.core.sl.entity.struct.ContractTextKey key = new curam.core.sl.entity.struct.ContractTextKey();

    key.contractTextID = modifyDetails.dtls.contractTextID;

    // populate the details
    curam.core.sl.entity.struct.ModifyContractTextDetails details = new curam.core.sl.entity.struct.ModifyContractTextDetails();

    details.contractText = modifyDetails.dtls.contractText;
    details.versionNo = modifyDetails.dtls.versionNo;

    // modify the details
    curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();

    contractTextObj.modify(key, details);

  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a sub goal.
   *
   * @param key Identifies the sub goal.
   *
   * @return The sub goal details.
   */
  public ReadSubGoalDetails read(SubGoalKey key)
    throws AppException, InformationalException {

    // set up the read key
    curam.serviceplans.sl.entity.struct.SubGoalKey subGoalKey = new curam.serviceplans.sl.entity.struct.SubGoalKey();

    subGoalKey.subGoalID = key.subGoalKey.subGoalID;

    // read the details into the output struct
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();
    ReadSubGoalDetails readSubGoalDetails = new ReadSubGoalDetails();

    readSubGoalDetails.dtls = subGoalObj.read(subGoalKey, false);

    // BEGIN, CR00228110, GP
    // Read the localized description.
    if (0 != readSubGoalDetails.dtls.descriptionTextID) {

      LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
        readSubGoalDetails.dtls.descriptionTextID);

      readSubGoalDetails.dtls.description = localizableText.getValue(
        LOCALEEntry.get(
          ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
    }
    // END, CR00228110

    return readSubGoalDetails;

  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a contract text associated with a sub goal.
   *
   * @param contractTextKey Identifies the contract text.
   *
   * @return The contract text details.
   */
  public ContractTextDetails readContractText(ContractTextKey contractTextKey)
    throws AppException, InformationalException {

    // return object
    ContractTextDetails contractTextDetails = new ContractTextDetails();

    // read the contract text entity(now moved to core)
    curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();

    // populate the output details
    contractTextDetails.assign(
      contractTextObj.read(contractTextKey.contractTextKey, false));

    return contractTextDetails;

  }

  // ___________________________________________________________________________
  /**
   * Removes the association between an plan item and a sub goal.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param planItemKey    Identifies the planItem.
   */
  public void removePlanItem(SubGoalKey subGoalKey, PlanItemKey planItemKey)
    throws AppException, InformationalException {

    // populate the remove key
    SubGoalPlanItemRemoveKey subGoalPlanItemRemoveKey = new SubGoalPlanItemRemoveKey();

    subGoalPlanItemRemoveKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalPlanItemRemoveKey.planItemID = planItemKey.key.planItemID;

    // Plan Template entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    curam.serviceplans.sl.entity.struct.SubGoalPlanItemAndStatusKey subGoalPlanItemAndStatusKey = new curam.serviceplans.sl.entity.struct.SubGoalPlanItemAndStatusKey();

    subGoalPlanItemAndStatusKey.planItemID = planItemKey.key.planItemID;
    subGoalPlanItemAndStatusKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalPlanItemAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // there must not be a plan template plan item based on this plan item that
    // is assigned to the plan template sub goal created for this sub goal
    if (planTemplateObj.countBySubGoalAndPlanItem(subGoalPlanItemAndStatusKey).count
      > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUBGOAL.ERR_SUBGOAL_XRV_PLANTEMPLATEPLAN_ITEM_ASSIGNED_TO_PLANTEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // remove the link between the sub goal and planItem
    SubGoalPlanItemLink subGoalPlanItemLink = SubGoalPlanItemLinkFactory.newInstance();

    subGoalPlanItemLink.removeBySubGoalIDAndPlanItemID(subGoalPlanItemRemoveKey);

  }

  // ___________________________________________________________________________
  /**
   * Removes the association between a contract text and a sub goal. The
   * contract text is also deleted.
   *
   * @param key Identifies the sub goal and contract text details.
   */
  public void removeContractText(RemoveSubGoalContractTextKey key)
    throws AppException, InformationalException {

    //
    // remove the sub goal-contract text link
    //

    // populate the sub goal contract text key
    SubGoalContractTextRemoveKey linkKey = new SubGoalContractTextRemoveKey();

    linkKey.subGoalID = key.subGoalID;
    linkKey.contractTextID = key.contractTextID;

    // remove the link between the sub goal and the contract text
    curam.serviceplans.sl.entity.intf.SubGoalContractText subGoalContractTextObj = curam.serviceplans.sl.entity.fact.SubGoalContractTextFactory.newInstance();

    subGoalContractTextObj.removeBySubGoalIDAndContractTextID(linkKey);

    //
    // cancel the contract text record
    //

    // cancel struct
    curam.core.sl.entity.struct.ContractTextKey contractTextKey = new curam.core.sl.entity.struct.ContractTextKey();
    curam.core.sl.entity.struct.CancelContractTextDetails cancelContractTextDetails = new curam.core.sl.entity.struct.CancelContractTextDetails();

    // populate the cancel details
    contractTextKey.contractTextID = key.contractTextID;
    cancelContractTextDetails.recordStatus = RECORDSTATUS.CANCELLED;
    cancelContractTextDetails.versionNo = key.contractTextVersionNo;

    // cancel the contract text
    curam.core.sl.entity.intf.ContractText contractTextObj = curam.core.sl.entity.fact.ContractTextFactory.newInstance();

    contractTextObj.cancel(contractTextKey, cancelContractTextDetails);

  }

  // ___________________________________________________________________________
  /**
   * Removes the association between an outcome and a sub goal.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param outcomeKey   Identifies the outcome.
   */
  public void removeOutcome(SubGoalKey subGoalKey, OutcomeKey outcomeKey)
    throws AppException, InformationalException {

    // populate the remove key
    SubGoalOutcomeKey subGoalOutcomeKey = new SubGoalOutcomeKey();

    subGoalOutcomeKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalOutcomeKey.outcomeID = outcomeKey.key.outcomeID;

    // remove the link between the plan item and outcome
    SubGoalOutcomeLink subGoalOutcomeLink = SubGoalOutcomeLinkFactory.newInstance();

    subGoalOutcomeLink.removeBySubGoalIDAndOutcomeID(subGoalOutcomeKey);

  }

  // ___________________________________________________________________________
  /**
   * Validates that a contract text can be associated with a sub goal.
   * SubGoals can only have one contract text per language.
   *
   * @param subGoalKey              Identifies the sub goal.
   * @param createContractTextDetails The new contract text details.
   */
  public void validateAddContractText(
    SubGoalKey subGoalKey,
    CreateContractTextDetails createContractTextDetails)
    throws AppException, InformationalException {

    //
    // check that the sub goal doesn't already have a contract in the same
    // language as the new contract
    //

    // check that the language code has been specified
    if (createContractTextDetails.languageCode.length() < 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOCONTRACTTEXT.ERR_LANGUAGECODE_FV_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

    }

    // set up the count key
    SubGoalContractTextCountKey subGoalContractTextCountKey = new SubGoalContractTextCountKey();

    subGoalContractTextCountKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    subGoalContractTextCountKey.languageCode = createContractTextDetails.languageCode;
    subGoalContractTextCountKey.recordStatus = RECORDSTATUS.NORMAL;

    // count the number of active contracts for this sub goal in the same language
    curam.serviceplans.sl.entity.intf.SubGoalContractText subGoalContractTextObj = curam.serviceplans.sl.entity.fact.SubGoalContractTextFactory.newInstance();
    curam.serviceplans.sl.entity.struct.ContractTextCountDetails contractTextCountDetails = subGoalContractTextObj.countBySubGoalIDContractLanguageAndStatus(
      subGoalContractTextCountKey);

    // is there already a contract in the same language as the new contract?
    if (contractTextCountDetails.numContractTexts > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUBGOAL.ERR_SUBGOAL_XFV_CONTRACTTEXT_EXISTS_FOR_LANGUAGE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates that an plan item can be added to a sub goal. An plan item cannot be
   * associated with the same sub goal more than once.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param planItemKey    Identifies the planItem.
   */
  public void validateAddPlanItem(SubGoalKey subGoalKey, PlanItemKey planItemKey)
    throws AppException, InformationalException {

    // SubGoal entity manipulation variables
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    // read sub goal record status
    curam.serviceplans.sl.entity.struct.SubGoalStatusDetails subGoalStatusDetails = subGoalObj.readRecordStatus(
      subGoalKey.subGoalKey);

    // sub goal cannot be created for a cancelled goal
    if (!subGoalStatusDetails.recordStatus.equals(RECORDSTATUS.NORMAL)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // populate the count key
    SubGoalPlanItemCountKey countKey = new SubGoalPlanItemCountKey();

    countKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    countKey.planItemID = planItemKey.key.planItemID;

    // count the number of existing links between the sub goal and planItem
    SubGoalPlanItemLink subGoalPlanItemLinkObj = SubGoalPlanItemLinkFactory.newInstance();
    PlanItemCountDetails countDetails = subGoalPlanItemLinkObj.countBySubGoalIDAndPlanItemID(
      countKey);

    // is the plan item already linked to the sub goal?
    if (countDetails.numPlanItems > 0) {

      // get the plan item name
      curam.serviceplans.sl.entity.intf.PlanItem planItemObj = curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();
      curam.serviceplans.sl.entity.struct.PlanItemNameDetails planItemNameDetails = planItemObj.readName(
        planItemKey.key);

      // throw an exception indicating the name of the plan item which
      // caused the problem
      AppException e = new AppException(
        BPOSUBGOAL.ERR_SUBGOAL_XFV_PLAN_ITEM_EXISTS);

      e.arg(planItemNameDetails.name);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

  }

  // ___________________________________________________________________________
  /**
   * Validates than an outcome can be added to a sub goal. An outcome cannot
   * be associated with the same sub goal more than once.
   *
   * @param subGoalKey Identifies the sub goal.
   * @param outcomeKey   Identifies the outcome.
   */
  public void validateAddOutcome(
    SubGoalKey subGoalKey,
    OutcomeKey outcomeKey)
    throws AppException, InformationalException {

    // populate the count key
    SubGoalOutcomeKey countKey = new SubGoalOutcomeKey();

    countKey.subGoalID = subGoalKey.subGoalKey.subGoalID;
    countKey.outcomeID = outcomeKey.key.outcomeID;

    // count the number of existing associations between the sub goal and outcome
    SubGoalOutcomeLink subGoalOutcomeLinkObj = SubGoalOutcomeLinkFactory.newInstance();
    OutcomeCountDetails countDetails = subGoalOutcomeLinkObj.countBySubGoalIDAndOutcomeID(
      countKey);

    // is the outcome already linked to the sub goal?
    if (countDetails.recordCount > 0) {

      // get the outcome name
      curam.serviceplans.sl.entity.intf.Outcome outcomeObj = curam.serviceplans.sl.entity.fact.OutcomeFactory.newInstance();
      curam.serviceplans.sl.entity.struct.OutcomeNameDetails outcomeNameDetails = outcomeObj.readName(
        outcomeKey.key);

      // throw an exception indicating the name of the outcome which
      // caused the problem
      AppException e = new AppException(
        BPOSUBGOAL.ERR_SUBGOAL_XFV_OUTCOME_EXISTS);

      e.arg(outcomeNameDetails.name);
      throw e;

    }

  }

  // ___________________________________________________________________________
  /**
   * Reads sub goal name.
   *
   * @param key SubGoal unique identifier
   * @return SubGoal name
   */
  public SubGoalNameDetails readName(SubGoalKey key)
    throws AppException, InformationalException {

    // sub goal entity object
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();

    // return value
    SubGoalNameDetails subGoalNameDetails = new SubGoalNameDetails();

    // read sub goal name
    subGoalNameDetails.subGoalNameDetails = subGoalObj.readName(key.subGoalKey);

    // return sub goal name
    return subGoalNameDetails;
  }

  // BEGIN, CR00228110, GP
  /**
   * Checks to ensure multiple text translations are not present for a single
   * locale. If it is, an error message is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE } - If multiple text
   * translation is present for the same locale.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    TextTranslationDtlsList textTranslationDtlsList = new
      TextTranslationDtlsList();
    TextTranslation textTranslation = TextTranslationFactory.newInstance();
    SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();

    key.localizableTextID = localizableTextHandler.getID();
    textTranslationDtlsList = textTranslation.searchByLocalizableTextID(key);

    for (TextTranslationDtls textTranslationDtls : textTranslationDtlsList.dtls.items()) {

      if (textTranslationDtls.localeCode.equals(locale)) {
        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(textTranslationDtls.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          17);
      }
    }
  }

  /**
   * Creates a text translation for the SubGoal attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details used for SubGoal
   * attribute, description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * {@link GENERAL#ERR_LOCALE_EMPTY ERR_LOCALE_EMPTY} - if locale is
   * empty.
   * {@link GENERAL#ERR_TRANSLATION_EXISTS_FOR_LOCALE
   * ERR_TRANSLATION_EXISTS_FOR_LOCALE} - if translation for that
   * locale exists already.
   * {@link BPOSUBGOAL#ERR_SUBGOAL_CANCELED ERR_SUBGOAL_CANCELED - if the
   * SubGoal to be modified is already canceled.}
   */
  public void addDescriptionTextTranslation(final
    LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();
    SubGoalKey subGoalKey = new SubGoalKey();

    SubGoalDescriptionTextID subGoalDescriptionTextID = new
      SubGoalDescriptionTextID();
    SubGoalDtls subGoalDtls = new SubGoalDtls();

    subGoalKey.subGoalKey.subGoalID = localizableTextTranslationDetails.localizableTextParentID;

    // Check if input localized text and locale are empty.
    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 26);
    }
    if (localizableTextTranslationDetails.localeCode.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_LOCALE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 12);
    }

    subGoalDtls = subGoalObj.read(subGoalKey.subGoalKey);

    // Record must not be already canceled.
    if (subGoalDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // Handling legacy Data.
    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == subGoalDtls.descriptionTextID) {
      // END, CR00246419

      if (localizableTextTranslationDetails.localeCode.equals(
        ProgramLocale.getDefaultServerLocale())
          && !subGoalDtls.description.equals(CuramConst.gkEmpty)) {

        AppException e = new AppException(
          GENERAL.ERR_TRANSLATION_EXISTS_FOR_LOCALE);

        e.arg(localizableTextTranslationDetails.localeCode);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          18);

      }

      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      String value = subGoalDtls.description;

      // Create one translation record for legacy data.
      localizableTextHandler.addValue(value,
        LOCALEEntry.get(ProgramLocale.getDefaultServerLocale()));

      // Create one translation record for new data.
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      textID = localizableTextHandler.store();

      // Update in entity.
      subGoalDescriptionTextID.descriptionTextID = textID;
      subGoalDescriptionTextID.versionNo = subGoalDtls.versionNo;
      subGoalObj.modifyDescriptionTextID(subGoalKey.subGoalKey,
        subGoalDescriptionTextID);
      
      // BEGIN, CR00246419, GP      
    } else if (0 != subGoalDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        subGoalDtls.descriptionTextID);
      
      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      validateNoTranslationsForLocale(localizableTextHandler,
        localizableTextTranslationDetails.localeCode);
      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));
      localizableTextHandler.store();
    }
  }

  /**
   * Modifies the text translation details for the SubGoal attribute,
   * description.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable name text translation details like locale code,
   * localizable text used for the localization of SubGoal attribute,
   * description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERAL#ERR_TEXT_EMPTY ERR_TEXT_EMPTY} - if text to be
   * translated is empty.
   * {@link BPOSUBGOAL#ERR_SUBGOAL_CANCELED ERR_SUBGOAL_CANCELED }- if the
   * plan template to be modified is already deleted.
   */
  public void modifyDescriptionTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    long textID;
    curam.serviceplans.sl.entity.intf.SubGoal subGoalObj = curam.serviceplans.sl.entity.fact.SubGoalFactory.newInstance();
    SubGoalKey subGoalKey = new SubGoalKey();

    SubGoalDescriptionTextID subGoalDescriptionTextID = new
      SubGoalDescriptionTextID();
    SubGoalDtls subGoalDtls = new SubGoalDtls();

    if (localizableTextTranslationDetails.text.equals(CuramConst.gkEmpty)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERAL.ERR_TEXT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 27);
    }

    subGoalKey.subGoalKey.subGoalID = localizableTextTranslationDetails.localizableTextParentID;

    subGoalDtls = subGoalObj.read(subGoalKey.subGoalKey);

    // Record must not be already canceled.
    if (subGoalDtls.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUBGOAL.ERR_SUBGOAL_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // BEGIN, CR00246419, GP
    if (0 == localizableTextTranslationDetails.localizableTextID
      && 0 == localizableTextTranslationDetails.textTranslationID
      && 0 == subGoalDtls.descriptionTextID) {
      // END, CR00246419

      // Handling legacy Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.newInstance();

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      textID = localizableTextHandler.store();
      subGoalDescriptionTextID.descriptionTextID = textID;
      subGoalDescriptionTextID.versionNo = subGoalDtls.versionNo;
      subGoalObj.modifyDescriptionTextID(subGoalKey.subGoalKey,
        subGoalDescriptionTextID);

      // BEGIN, CR00246419, GP      
    } else if (0 != subGoalDtls.descriptionTextID) {
      
      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        subGoalDtls.descriptionTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode));     
      localizableTextHandler.store();     
    } else {      
      // END, CR00246419

      // Handling new Data.
      LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
        localizableTextTranslationDetails.localizableTextID);

      localizableTextHandler.addValue(localizableTextTranslationDetails.text,
        LOCALEEntry.get(localizableTextTranslationDetails.localeCode.toString(
        )));
      localizableTextHandler.store();
    }
  }
  // END, CR00228110

}
