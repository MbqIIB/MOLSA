/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.serviceplans.sl.entity.intf.BaselinePlanItem;
import curam.serviceplans.sl.entity.struct.BaselinePlanItemByBaselineSubGoalIDDetailsList;
import curam.serviceplans.sl.entity.struct.BaselinePlanItemKey;
import curam.serviceplans.sl.entity.struct.BaselineSubGoalKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class provides methods used to validate the insertion, modification
 * and canceling of baselines sub-goals
 */
public abstract class BaselineSubGoal extends curam.serviceplans.sl.entity.base.BaselineSubGoal {

  // ___________________________________________________________________________
  /**
   * Ensures validations and deletion of Baseline PlanItems before the data modification
   *
   * @param key Baseline Sub-Goal identifier
   *
   */
  protected void preremove(BaselineSubGoalKey key)
    throws AppException, InformationalException {

    // Delete any baseline planItems before a baseline subGoal
    // can be deleted
    BaselinePlanItem baselinePlanItemObj =
      curam.serviceplans.sl.entity.fact.BaselinePlanItemFactory.newInstance();
    BaselinePlanItemByBaselineSubGoalIDDetailsList baselinePlanItemByBaselineSubGoalIDDetailsList =
      baselinePlanItemObj.searchByBaselineSubGoalID(key);

    // Delete each record
    for (int i = 0; i
      < baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.size(); i++) {
      BaselinePlanItemKey baselinePlanItemKey = new BaselinePlanItemKey();

      baselinePlanItemKey.baselinePlanItemID =
        baselinePlanItemByBaselineSubGoalIDDetailsList.dtls.item(i)
          .baselinePlanItemID;
      baselinePlanItemObj.remove(baselinePlanItemKey);
    }
  }
}
