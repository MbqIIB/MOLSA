/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.CASESTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.sl.struct.RecordCount;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.Count;
import curam.message.BPOPLANNEDGROUP;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.fact.SPMilestoneDeliveryLinkFactory;
import curam.serviceplans.sl.entity.intf.PlannedGoal;
import curam.serviceplans.sl.entity.intf.PlannedSubGoal;
import curam.serviceplans.sl.entity.intf.SPMilestoneDeliveryLink;
import curam.serviceplans.sl.entity.struct.ActualAndExpectedDates;
import curam.serviceplans.sl.entity.struct.MultipleContractsAllowedIndStruct;
import curam.serviceplans.sl.entity.struct.PlannedGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedGroupActualAndExpectedDates;
import curam.serviceplans.sl.entity.struct.PlannedGroupDtls;
import curam.serviceplans.sl.entity.struct.PlannedGroupKey;
import curam.serviceplans.sl.entity.struct.PlannedGroupModifyDetails;
import curam.serviceplans.sl.entity.struct.PlannedGroupNameAndPlannedGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForPlannedGroupList;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalPlannedGroupIDKey;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedGroupIDDetails;
import curam.serviceplans.sl.entity.struct.ReadMultipleContractsAllowedByCaseIDKey;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryIssuedAndAcceptStatus;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.DateTime;


/**
 * This entity class provides the functionality for planned groups.
 */

public abstract class PlannedGroup extends curam.serviceplans.sl.entity.base.PlannedGroup {

  // ___________________________________________________________________________
  /**
   * Performs operations before inserting the planned group details
   *
   * @param details Planned group details
   */
  protected void preinsert(PlannedGroupDtls details)
    throws AppException, InformationalException {

    // Validate the details
    validateInsert(details);
    
    // BEGIN, CR00292366, AKr
    if (details.createdOn.isZero()) {
      details.createdOn = DateTime.getCurrentDateTime();
    }
    // END, CR00292366
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification.
   *
   * @param key Planned group identifier
   * @param dtls Planned group details
   */
  protected void premodify(PlannedGroupKey key, PlannedGroupModifyDetails dtls)
    throws AppException, InformationalException {

    // Validate the details
    validateModify(key, dtls);
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data deletion.
   *
   * @param key Planned Group identifier
   */
  protected void preremove(PlannedGroupKey key)
    throws AppException, InformationalException {

    // Validate if remove is allowed based on the key
    validateRemove(key);
  }

  // ___________________________________________________________________________
  /**
   * Validates the planned group details.
   *
   * @param details The details of the planned group
   */
  public void validateInsert(PlannedGroupDtls details)
    throws AppException, InformationalException {

    // Validation to check if contracts have already been issued

    // ServicePlan Object
    curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();
    // ServicePlanContract Object
    curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();
    PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();

    PlannedGoalKey plannedGoalKey = new PlannedGoalKey();

    // set the key
    plannedGoalKey.plannedGoalID = details.plannedGoalID;
    // BEGIN CR00106813, GSP
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = null;
    curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    caseHeaderKey.caseID = plannedGoalObj.read(plannedGoalKey).caseID;
    caseStatusCode = caseHeaderObj.readStatus(caseHeaderKey);
    if (caseStatusCode.statusCode.compareTo(CASESTATUS.CLOSED) == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDGROUP.ERR_PLANGROUP_FV_INSERT_SERVICEPLAN_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00106813
    
    MultipleContractsAllowedIndStruct multipleContractsAllowedIndStruct = new MultipleContractsAllowedIndStruct();

    ReadMultipleContractsAllowedByCaseIDKey readMultipleContractsAllowedByCaseIDKey = new ReadMultipleContractsAllowedByCaseIDKey();

    // Set the input struct
    readMultipleContractsAllowedByCaseIDKey.caseID = plannedGoalObj.read(plannedGoalKey).caseID;

    // read the multipleContractsAllowed indicator value
    multipleContractsAllowedIndStruct = servicePlanObj.readMultipleContractsAllowedInd(
      readMultipleContractsAllowedByCaseIDKey);

    RecordCount recordCount = new RecordCount();

    ServicePlanDeliveryIssuedAndAcceptStatus servicePlanDeliveryIssuedAndAcceptStatus = new ServicePlanDeliveryIssuedAndAcceptStatus();

    // Set the input struct
    servicePlanDeliveryIssuedAndAcceptStatus.caseID = readMultipleContractsAllowedByCaseIDKey.caseID;

    // Check to see if multiple contracts are allowed
    if (multipleContractsAllowedIndStruct.multipleContractsAllowedInd == false) {

      try {

        // check to ensure no contract that are issued OR Accepted
        recordCount = servicePlanContractObj.countIssuAndAccContractsByCaseID(
          servicePlanDeliveryIssuedAndAcceptStatus);

      } catch (curam.util.exception.RecordNotFoundException e) {// No contract has been issued
      }

      // Check to see if a contract has been issued OR accepted.
      // If it has then throw an error
      if (recordCount.count > 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDGROUP.ERR_PLANGROUP_FV_CREATE_CONTRACT_ALREADY_EXISTS),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // Validation to check plan group name is unique
    // set key - name and planned goal
    PlannedGroupNameAndPlannedGoalKey plannedGroupNameAndPlannedGoalKey = new PlannedGroupNameAndPlannedGoalKey();
    Count count = null;

    plannedGroupNameAndPlannedGoalKey.name = details.name;
    plannedGroupNameAndPlannedGoalKey.plannedGoalID = details.plannedGoalID;

    // Check that for each planned group, the name is unique.
    count = countByNameAndPlannedGoalID(plannedGroupNameAndPlannedGoalKey);

    // if records exist, this name exists already for one of the planned groups
    // with this planned goal ID

    if (count.numberOfRecords > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOPLANNEDGROUP.ERR_PLANGROUP_FV_CREATE_NAME_NOT_UNIQUE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates planned group modify details.
   *
   * @param key Planned group identifier
   * @param dtls Planned group details
   */
  public void validateModify(PlannedGroupKey key, 
    PlannedGroupModifyDetails dtls)
    throws AppException, InformationalException {
    
    // Validation to check plan group name is unique
    // set key - name and planned goal
    PlannedGroupNameAndPlannedGoalKey plannedGroupNameAndPlannedGoalKey = new PlannedGroupNameAndPlannedGoalKey();
    Count count = null;

    plannedGroupNameAndPlannedGoalKey.name = dtls.name;
    plannedGroupNameAndPlannedGoalKey.plannedGoalID = dtls.plannedGoalID;

    // if only comments modified, should be fine to modify
    if (!dtls.name.equals(read(key).name)) {

      // Check that for each planned group, the name is unique.
      count = countByNameAndPlannedGoalID(plannedGroupNameAndPlannedGoalKey);

      // if records exist, this name exists already for one of the planned 
      // groups with this planned goal ID
      if (count.numberOfRecords > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOPLANNEDGROUP.ERR_PLANGROUP_FV_CREATE_NAME_NOT_UNIQUE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }

    // BEGIN, CR00106813, GSP 
    PlannedGroupKey plannedGroupKey = new PlannedGroupKey();
    ReadCaseIDByPlannedGroupIDDetails readCaseIDByPlannedGroupIDDetails = null;
    curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = null;

    plannedGroupKey.plannedGroupID = dtls.plannedGroupID;
    readCaseIDByPlannedGroupIDDetails = readCaseIDByPlannedGroupID(
      plannedGroupKey);
    caseHeaderKey.caseID = readCaseIDByPlannedGroupIDDetails.caseID;
    caseStatusCode = caseHeaderObj.readStatus(caseHeaderKey);
    if (caseStatusCode.statusCode.compareTo(CASESTATUS.CLOSED) == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDGROUP.ERR_PLANGROUP_FV_MODIFY_SERVICEPLAN_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00106813
  }

  // ___________________________________________________________________________
  /**
   * Validates planned sub-goal deletion
   *
   * @param key Planned group identifier
   */
  public void validateRemove(PlannedGroupKey key)
    throws AppException, InformationalException {

    // Planned SubGoal entity manipulation variables
    PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();
    PlannedSubGoalDetailsForPlannedGroupList plannedSubGoalDetailsForPlannedGroupList = null;
    PlannedSubGoalPlannedGroupIDKey plannedSubGoalPlannedGroupIDKey = new PlannedSubGoalPlannedGroupIDKey();

    // Planned Group entity manipulation variables
    ReadCaseIDByPlannedGroupIDDetails readCaseIDByPlannedGroupIDDetails = new ReadCaseIDByPlannedGroupIDDetails();

    // Case Header manipulation variable
    curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = null;
    
    // BEGIN, CR00057944, CM
    // SPMilestoneDeliveryLink manipulation variable
    SPMilestoneDeliveryLink sPMilestoneDeliveryLinkObj = SPMilestoneDeliveryLinkFactory.newInstance();
    // END, CR00057944
    
    // check if child plan groups exist for planned group
    curam.core.struct.Count count = countChildGroups(key);

    if (count.numberOfRecords > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDGROUP.ERR_PLANGROUP_FV_DELETE_PLANGROUPS_EXIST),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // set up key
    plannedSubGoalPlannedGroupIDKey.plannedGroupID = key.plannedGroupID;
    // check if any sub goals exist for the planned group
    plannedSubGoalDetailsForPlannedGroupList = plannedSubGoalObj.searchByPlannedGroupID(
      plannedSubGoalPlannedGroupIDKey);
    if (plannedSubGoalDetailsForPlannedGroupList.dtls.size() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANNEDGROUP.ERR_PLANGROUP_FV_DELETE_SUBGOALS_EXIST),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    
    // BEGIN, CR00057944, CM
    // Check if any milestones exist for the planned group
    count = sPMilestoneDeliveryLinkObj.countMilestonesForPlannedGroup(key);
    
    if (count.numberOfRecords > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDGROUP.ERR_PLANGROUP_FV_DELETE_MILESTONES_EXIST),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }  
    // END, CR00057944

    // make sure service plan is not closed
    // Read the CaseID
    readCaseIDByPlannedGroupIDDetails = readCaseIDByPlannedGroupID(key);
    caseHeaderKey.caseID = readCaseIDByPlannedGroupIDDetails.caseID;
    caseStatusCode = caseHeaderObj.readStatus(caseHeaderKey);
    if (caseStatusCode.statusCode.compareTo(CASESTATUS.CLOSED) == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDGROUP.ERR_PLANGROUP_FV_DELETE_SERVICEPLAN_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Reads earliest start and latest end dates.
   *
   * @param key Planned Group identifier
   *
   * @return Earliest Start date and latest End date
   */
  public ActualAndExpectedDates readMinStartAndMaxEndDates(PlannedGroupKey key)
    throws AppException, InformationalException {

    // create return struct
    ActualAndExpectedDates actualAndExpectedDates = new ActualAndExpectedDates();

    return actualAndExpectedDates;
  }

  // ___________________________________________________________________________
  /**
   * Modifies the dates on the planned group.
   *
   * @param key Planned Group identifier
   */
  public void postmodifyDateRange(PlannedGroupKey key,
    PlannedGroupActualAndExpectedDates details) throws AppException,
      InformationalException {

    curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();

    // if dates have changed - notify goal of change.
    PlannedGoalKey plannedGoalKey = new PlannedGoalKey();
    PlannedGroupKey parentPlannedGroupKey = new PlannedGroupKey();

    PlannedGroupDtls plannedGroupDtls = read(key);

    if (plannedGroupDtls.parentGroupID != 0) {
      parentPlannedGroupKey.plannedGroupID = plannedGroupDtls.parentGroupID;

      // Notify planned parent group of date change
      reCalculateDates(parentPlannedGroupKey);
    } else {
      plannedGoalKey.plannedGoalID = plannedGroupDtls.plannedGoalID;

      // Notify planned goal of sub goal change
      plannedGoalObj.reCalculateDates(plannedGoalKey);
    }

  }

  // ___________________________________________________________________________
  /**
   * Checks to see if plan groups dates have to be changed and if so,
   * sets them to new dates.
   *
   * @param key Planned Group identifier
   */
  public void reCalculateDates(PlannedGroupKey key) throws AppException,
      InformationalException {

    PlannedGroupActualAndExpectedDates plannedGroupActualAndExpectedDates = new PlannedGroupActualAndExpectedDates();

    PlannedGroupDtls plannedGroupDtls = read(key);

    // Read the Min and Max Child Planned Groups dates for this Planned Group
    PlannedGroupActualAndExpectedDates plannedChildGroupActualAndExpectedDates = readPlanGroupMaxAndMinDatesForSpecificPlannedGroup(
      key);
    // Read the Min and Max dates of all Child Sub Goals  for this Planned Group
    PlannedGroupActualAndExpectedDates plannedSubGoalActualAndExpectedDates = readPlanSGMinAndMaxDatesForPlanGroup(
      key);

    // When Checking the earliest dates you have to 
    // check first - are the dates set.
    // The reason a date not set still take the date of 
    // 0001-01-01 so fail incorrectly.

    // Check which dates are the earliest and set to new planned group date
    if (plannedChildGroupActualAndExpectedDates.actualStartDate.isZero()) {
      plannedGroupActualAndExpectedDates.actualStartDate = plannedSubGoalActualAndExpectedDates.actualStartDate;
    } else if (plannedSubGoalActualAndExpectedDates.actualStartDate.isZero()) {
      plannedGroupActualAndExpectedDates.actualStartDate = plannedChildGroupActualAndExpectedDates.actualStartDate;
    } else {
      if (plannedChildGroupActualAndExpectedDates.actualStartDate.before(
        plannedSubGoalActualAndExpectedDates.actualStartDate)) {
        plannedGroupActualAndExpectedDates.actualStartDate = plannedChildGroupActualAndExpectedDates.actualStartDate;
      } else {
        plannedGroupActualAndExpectedDates.actualStartDate = plannedSubGoalActualAndExpectedDates.actualStartDate;
      }
    }
    // Check which dates are the earliest and set to new planned group date
    if (plannedChildGroupActualAndExpectedDates.expectedStartDate.isZero()) {
      plannedGroupActualAndExpectedDates.expectedStartDate = plannedSubGoalActualAndExpectedDates.expectedStartDate;
    } else if (plannedSubGoalActualAndExpectedDates.expectedStartDate.isZero()) {
      plannedGroupActualAndExpectedDates.expectedStartDate = plannedChildGroupActualAndExpectedDates.expectedStartDate;
    } else {
      if (plannedChildGroupActualAndExpectedDates.expectedStartDate.before(
        plannedSubGoalActualAndExpectedDates.expectedStartDate)) {
        plannedGroupActualAndExpectedDates.expectedStartDate = plannedChildGroupActualAndExpectedDates.expectedStartDate;
      } else {
        plannedGroupActualAndExpectedDates.expectedStartDate = plannedSubGoalActualAndExpectedDates.expectedStartDate;
      }
    }
    // Check which dates are the latest and set to new planned group date
    if (plannedChildGroupActualAndExpectedDates.actualEndDate.isZero()) {
      plannedGroupActualAndExpectedDates.actualEndDate = plannedSubGoalActualAndExpectedDates.actualEndDate;
    } else if (plannedSubGoalActualAndExpectedDates.actualEndDate.isZero()) {
      plannedGroupActualAndExpectedDates.actualEndDate = plannedChildGroupActualAndExpectedDates.actualEndDate;
    } else {
      if (plannedChildGroupActualAndExpectedDates.actualEndDate.after(
        plannedSubGoalActualAndExpectedDates.actualEndDate)) {
        plannedGroupActualAndExpectedDates.actualEndDate = plannedChildGroupActualAndExpectedDates.actualEndDate;
      } else {
        plannedGroupActualAndExpectedDates.actualEndDate = plannedSubGoalActualAndExpectedDates.actualEndDate;
      }
    }

    // Check to see which dates are the latest and set to new planned group date
    if (plannedChildGroupActualAndExpectedDates.expectedEndDate.isZero()) {
      plannedGroupActualAndExpectedDates.expectedEndDate = plannedSubGoalActualAndExpectedDates.expectedEndDate;
    } else if (plannedSubGoalActualAndExpectedDates.expectedEndDate.isZero()) {
      plannedGroupActualAndExpectedDates.expectedEndDate = plannedChildGroupActualAndExpectedDates.expectedEndDate;
    } else {
      if (plannedChildGroupActualAndExpectedDates.expectedEndDate.after(
        plannedSubGoalActualAndExpectedDates.expectedEndDate)) {
        plannedGroupActualAndExpectedDates.expectedEndDate = plannedChildGroupActualAndExpectedDates.expectedEndDate;
      } else {
        plannedGroupActualAndExpectedDates.expectedEndDate = plannedSubGoalActualAndExpectedDates.expectedEndDate;
      }
    }

    plannedGroupDtls = read(key);

    if (!(plannedGroupActualAndExpectedDates.actualEndDate).equals(
      plannedGroupDtls.actualEndDate)
        || !(plannedGroupActualAndExpectedDates.actualStartDate).equals(
          plannedGroupDtls.actualStartDate)
          || !(plannedGroupActualAndExpectedDates.expectedStartDate).equals(
            plannedGroupDtls.expectedStartDate)
            || !(plannedGroupActualAndExpectedDates.expectedEndDate).equals(
              plannedGroupDtls.expectedEndDate)) {

      // modify the dates to the changed dates
      modifyDateRange(key, plannedGroupActualAndExpectedDates);

    }

  }
}
