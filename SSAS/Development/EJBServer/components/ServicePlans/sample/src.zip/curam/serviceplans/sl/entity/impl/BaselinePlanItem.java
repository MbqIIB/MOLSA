/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 - 2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;

import curam.serviceplans.sl.entity.struct.BaselinePlanItemKey;
import curam.serviceplans.sl.entity.struct.BaselineServiceUnitDeliveryDtlsList;
import curam.serviceplans.sl.entity.struct.BaselineServiceUnitDeliveryKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * This class provides methods used to validate the insertion, modification
 * and canceling of baseline planItems
 */
public abstract class BaselinePlanItem extends curam.serviceplans.sl.entity.base.BaselinePlanItem {

  // BEGIN, CR00000224, PMD
  protected void preremove(BaselinePlanItemKey key)
    throws AppException, InformationalException {

    // Delete any baseline service unit deliveries
    // before a baseline plan item can be deleted
    curam.serviceplans.sl.entity.intf.BaselineServiceUnitDelivery baselineServiceUnitDeliveryObj =
      curam.serviceplans.sl.entity.fact.BaselineServiceUnitDeliveryFactory.newInstance();

    BaselineServiceUnitDeliveryDtlsList baselineServiceUnitDeliveryDtlsList =
      baselineServiceUnitDeliveryObj.searchByBaselinePlanItemID(key);

    // Delete each record
    for (int i = 0; i < baselineServiceUnitDeliveryDtlsList.dtls.size(); i++) {

      BaselineServiceUnitDeliveryKey baselineServiceUnitDeliveryKey =
        new BaselineServiceUnitDeliveryKey();

      baselineServiceUnitDeliveryKey.baselineServiceUnitDeliveryID =
        baselineServiceUnitDeliveryDtlsList.dtls.item(i).baselineServiceUnitDeliveryID;

      baselineServiceUnitDeliveryObj.remove(baselineServiceUnitDeliveryKey);

    }
  }
  // END, CR00000224

 
}
