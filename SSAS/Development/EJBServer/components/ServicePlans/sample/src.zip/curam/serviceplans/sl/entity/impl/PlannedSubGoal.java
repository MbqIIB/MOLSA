/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005, 2007-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.CASESTATUS;
import curam.codetable.PLANNEDITEMSTATUS;
import curam.codetable.PLANNEDSUBGOALSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SERVICEPLANCONTRACTSTATUS;
import curam.core.fact.CaseHeaderFactory;
import curam.core.sl.struct.RecordCount;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.message.BPOPLANNEDSUBGOAL;
import curam.serviceplans.sl.entity.struct.PlannedGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedGroupKey;
import curam.serviceplans.sl.entity.struct.PlannedItemDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemDtlsList;
import curam.serviceplans.sl.entity.struct.PlannedItemForSubgoalList;
import curam.serviceplans.sl.entity.struct.PlannedItemStatusAndSubGoalIDKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalActualAndExpectedDates;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDtls;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalModifyDetails;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalStatus;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedSubGoalIDDetails;
import curam.serviceplans.sl.entity.struct.ReadMultipleContractsAllowedByCaseIDKey;
import curam.serviceplans.sl.entity.struct.recordCountPlanItems;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;
import curam.util.type.DateTime;


/**
 * This class provides methods used to validate the insertion, modification
 * and canceling of planned sub goals.
 */
public abstract class PlannedSubGoal extends curam.serviceplans.sl.entity.base.PlannedSubGoal {

  // ___________________________________________________________________________
  /**
   * Performs operations before inserting the planned sub goal details
   *
   * @param details Planned Sub-Goal details
   */
  protected void preinsert(PlannedSubGoalDtls details)
    throws AppException, InformationalException {

    // Validate the details
    validateInsert(details);
    
    // BEGIN, CR00292366, AKr
    if (details.createdOn.isZero()) {
      details.createdOn = DateTime.getCurrentDateTime();
    }
    // END, CR00292366
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key Planned Sub-Goal identifier
   * @param details Planned Sub-Goal details
   */
  protected void premodify(PlannedSubGoalKey key,
    PlannedSubGoalModifyDetails details) throws AppException,
      InformationalException {

    // Validate the details
    validateModify(details);

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data deletion
   *
   * @param key Planned Sub-Goal identifier
   */
  protected void preremove(PlannedSubGoalKey key)
    throws AppException, InformationalException {

    // Validate if remove is allowed based on the key
    validateRemove(key);
  }

  // ___________________________________________________________________________
  /**
   * Validates the planned sub-goal details
   *
   * @param details The details of the planned sub-goal
   */
  public void validateInsert(PlannedSubGoalDtls details)
    throws AppException, InformationalException {

    // set name key detail
    details.recordStatus = RECORDSTATUS.NORMAL;
    details.status = PLANNEDSUBGOALSTATUS.NOTSTARTED;

    // make sure sensitivity;
    if (details.sensitivityCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_REQUIRES_SENSITIVITY_CODE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();

    // Case Header manipulation variable
    curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = null;

    // make sure service plan is not closed
    PlannedGoalKey plannedGoalKey = new PlannedGoalKey();

    plannedGoalKey.plannedGoalID = details.plannedGoalID;
    caseHeaderKey.caseID = plannedGoalObj.read(plannedGoalKey).caseID;
    caseStatusCode = caseHeaderObj.readStatus(caseHeaderKey);
    if (caseStatusCode.statusCode.compareTo(CASESTATUS.CLOSED) == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_CREATE_SERVICEPLAN_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryIssuedAndAcceptStatus servicePlanDeliveryIssuedAndAcceptStatus = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryIssuedAndAcceptStatus();

    servicePlanDeliveryIssuedAndAcceptStatus.caseID = caseHeaderKey.caseID;
    servicePlanDeliveryIssuedAndAcceptStatus.contractStatusAccepted = SERVICEPLANCONTRACTSTATUS.ACCEPTED;
    servicePlanDeliveryIssuedAndAcceptStatus.contractStatusIssued = SERVICEPLANCONTRACTSTATUS.ISSUED;

    // ServicePlanContract Object
    curam.serviceplans.sl.entity.intf.ServicePlanContract servicePlanContractObj = curam.serviceplans.sl.entity.fact.ServicePlanContractFactory.newInstance();
    RecordCount countIssuedAndAccepted = servicePlanContractObj.countIssuAndAccContractsByCaseID(
      servicePlanDeliveryIssuedAndAcceptStatus);

    // read the multiplecontracInd on the service plan
    ReadMultipleContractsAllowedByCaseIDKey readMultipleContractsAllowedByCaseIDKey = new ReadMultipleContractsAllowedByCaseIDKey();

    readMultipleContractsAllowedByCaseIDKey.caseID = servicePlanDeliveryIssuedAndAcceptStatus.caseID;

    curam.serviceplans.sl.entity.intf.ServicePlan servicePlanObj = curam.serviceplans.sl.entity.fact.ServicePlanFactory.newInstance();
    boolean multipleContractsInd = servicePlanObj.readMultipleContractsAllowedInd(readMultipleContractsAllowedByCaseIDKey).multipleContractsAllowedInd;

    // check if contract is accepted, multiple contracts are allowed on that
    // service plan
    if (countIssuedAndAccepted.count > 0) {
      if (!multipleContractsInd) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_CREATE_WHEN_CONTRACT_ALREADY_ACCEPTED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates planned sub-goal modify details
   *
   * @param dtls The details of the planned sub-goal
   */
  public void validateModify(PlannedSubGoalModifyDetails dtls)
    throws AppException, InformationalException {

    // Planned Sub-Goal entity manipulation variables
    PlannedItemForSubgoalList plannedItemForSubGoalList = null;
    PlannedSubGoalKey plannedSubGoalKey = new PlannedSubGoalKey();
    ReadCaseIDByPlannedSubGoalIDDetails readCaseIDByPlannedSubGoalIDDetails = null;

    // Case Header manipulation variable
    curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = null;

    // set up key
    plannedSubGoalKey.plannedSubGoalID = dtls.plannedSubGoalID;

    // if an outcome for the planned sub-goal is defined, make sure all
    // corresponding planned items have outcomes defined
    if (dtls.outcomeAchieved.length() > 0) {
      // get all planItems
      plannedItemForSubGoalList = searchPlannedItems(plannedSubGoalKey);
      for (int i = 0; i < plannedItemForSubGoalList.dtls.size(); i++) {
        if ((plannedItemForSubGoalList.dtls.get(i)).outcomeName.length() == 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_MODIFY_PLAN_ITEM_OUTCOME_NOT_SET),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }
    }

    // make sure sensitivity set
    if (dtls.sensitivityCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_REQUIRES_SENSITIVITY_CODE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // make sure owner set
    if (dtls.ownerID.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_CREATE_NO_OWNER_SELECTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // make sure service plan is not closed
    readCaseIDByPlannedSubGoalIDDetails = readCaseIDByPlannedSubGoalID(
      plannedSubGoalKey);
    caseHeaderKey.caseID = readCaseIDByPlannedSubGoalIDDetails.caseID;
    caseStatusCode = caseHeaderObj.readStatus(caseHeaderKey);
    if (caseStatusCode.statusCode.compareTo(CASESTATUS.CLOSED) == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_MODIFY_SERVICEPLAN_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates planned sub-goal deletion
   *
   * @param key Planned Sub-Goal identifier
   */
  public void validateRemove(PlannedSubGoalKey key)
    throws AppException, InformationalException {

    // Planned Sub-Goal entity manipulation variables
    ReadCaseIDByPlannedSubGoalIDDetails readCaseIDByPlannedSubGoalIDDetails = null;

    // Case Header manipulation variable
    curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseStatusCode caseStatusCode = null;

    // make sure service plan is not closed
    readCaseIDByPlannedSubGoalIDDetails = readCaseIDByPlannedSubGoalID(key);
    caseHeaderKey.caseID = readCaseIDByPlannedSubGoalIDDetails.caseID;
    caseStatusCode = caseHeaderObj.readStatus(caseHeaderKey);
    if (caseStatusCode.statusCode.compareTo(CASESTATUS.CLOSED) == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDSUBGOAL.ERR_SUBGOAL_FV_DELETE_SERVICEPLAN_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Notifies the goal entity to say dates have changed
   *
   * @param details Planned Sub-Goal identifier
   */
  public void postmodifyDateRange(PlannedSubGoalKey key,
    PlannedSubGoalActualAndExpectedDates details) throws AppException,
      InformationalException {

    curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();

    // if dates have changed - notify goal of change.
    PlannedGoalKey plannedGoalKey = new PlannedGoalKey();
    PlannedSubGoalDtls plannedSubGoalDtls = read(key);

    plannedGoalKey.plannedGoalID = readPlannedGoalIDByPlannedSubGoal(key).plannedGoalID;

    // Check to see if the sub goal is directly linked to Planned GOal or
    // Planned Group and whichever is their parent, a re calculation will have
    // to be done on parent group if dates have changed - notify goal of change.
    PlannedGroupKey plannedGroupKey = new PlannedGroupKey();

    // if subgoal within a planned group then update that planned group,
    // else update the planned goal
    if (plannedSubGoalDtls.plannedGroupID == 0) {
      plannedGoalObj.reCalculateDates(plannedGoalKey);
    } else {
      plannedGroupKey.plannedGroupID = plannedSubGoalDtls.plannedGroupID;
      plannedGroupObj.reCalculateDates(plannedGroupKey);
    }
  }

  // ___________________________________________________________________________
  // BEGIN, CR00236850, MR
  /**
   * Checks to see if sub goal dates have to be changed and if so,
   * sets them to new dates and status as required.
   *
   * @param key Planned Sub-Goal identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void reCalculateDatesAndStatus(final PlannedSubGoalKey key)
    throws AppException, InformationalException {
    // END, CR00236850
    curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj = curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    PlannedSubGoalStatus plannedSubGoalStatus = new PlannedSubGoalStatus();

    // If no plan items exist for sub goal then refresh the dates back to
    // blank and STATUS to NOTSTARTED like it was when no planned items
    // were added
    if (plannedItemObj.searchByPlannedSubGoalID(key).dtls.size() == 0) {
      // set the sub goal status blank.
      plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.NOTSTARTED;
      modifySubGoalStatus(key, plannedSubGoalStatus);
      PlannedSubGoalActualAndExpectedDates plannedSubGoalActualAndExpectedDates = new PlannedSubGoalActualAndExpectedDates();

      // modify the dates to the changed dates
      modifyDateRange(key, plannedSubGoalActualAndExpectedDates);

    } // Other wise set dates to the correct max and min of all plan items
    else {
      // read min and max dates for all actual and expected dates of all
      // planItems for this sub goal
      PlannedSubGoalActualAndExpectedDates plannedSubGoalActualAndExpectedDates = readMaxAndMinActualAndExpDates(
        key);
      
      // BEGIN, CR00236850, MR
      final PlannedItemDtlsList plannedItemDtlsList = plannedItemObj.searchByPlannedSubGoalID(
        key);

      if (plannedItemDtlsList.dtls.size() > 1) {
        for (final PlannedItemDtls plannedItemDtls : 
          plannedItemDtlsList.dtls.items()) {
          if (!plannedItemDtls.actualStartDate.isZero()
            && plannedItemDtls.actualEndDate.isZero()) {
            plannedSubGoalActualAndExpectedDates.actualEndDate = Date.getCurrentDate();
            break;
          }
        }
      }
      // END, CR00236850
      PlannedSubGoalDtls plannedSubGoalDtls = read(key);

      if (!(plannedSubGoalActualAndExpectedDates.actualEndDate.equals(
        plannedSubGoalDtls.actualEndDate))
          || !(plannedSubGoalActualAndExpectedDates.actualStartDate.equals(
            plannedSubGoalDtls.actualStartDate))
            || !(plannedSubGoalActualAndExpectedDates.expectedStartDate.equals(
              plannedSubGoalDtls.expectedStartDate))
              || !(plannedSubGoalActualAndExpectedDates.expectedEndDate.equals(
                plannedSubGoalDtls.expectedEndDate))) {

        // modify the dates to the changed dates
        modifyDateRange(key, plannedSubGoalActualAndExpectedDates);

      }

      // Check the status of all planned items for this sub goal
      PlannedItemStatusAndSubGoalIDKey plannedItemStatusAndSubGoalIDKey = new PlannedItemStatusAndSubGoalIDKey();
      int numberOfPlanItems = searchPlannedItems(key).dtls.size();

      // read all 'not started' planItems.
      recordCountPlanItems recordCountPlanItemsNotStarted = new recordCountPlanItems();

      plannedItemStatusAndSubGoalIDKey.plannedItemStatus = PLANNEDITEMSTATUS.NOTSTARTED;
      plannedItemStatusAndSubGoalIDKey.plannedSubGoalID = key.plannedSubGoalID;

      recordCountPlanItemsNotStarted = plannedItemObj.countPlanItemsOfSpecificStatus(
        plannedItemStatusAndSubGoalIDKey);
      // If all plan planItems are set to 'not started',
      // then set the sub goal status to 'not started'.
      if (recordCountPlanItemsNotStarted.recordCount == numberOfPlanItems) {

        // set the sub goal status to not started
        plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.NOTSTARTED;

      }

      // BEGIN CR00021410, SG
      // BEGIN, HARP 64087, GYH
      // read all 'unapproved' planItems.
      recordCountPlanItems recordCountPlanItemsUnApproved = new recordCountPlanItems();

      plannedItemStatusAndSubGoalIDKey.plannedItemStatus = PLANNEDITEMSTATUS.UNAPPROVED;
      recordCountPlanItemsUnApproved = plannedItemObj.countPlanItemsOfSpecificStatus(
        plannedItemStatusAndSubGoalIDKey);

      // If all plan planItems are set to 'unapproved',
      // then set the sub goal status to 'unapproved'.
      if ((recordCountPlanItemsUnApproved.recordCount == numberOfPlanItems)
        || (recordCountPlanItemsUnApproved.recordCount > 0)) {
        // set the sub goal status to unapproved
        plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.UNAPPROVED;
      } else {
        plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.NOTSTARTED;
      }

      // END, HARP 64087
      // END CR00021410

      // read all 'completed' planItems.
      recordCountPlanItems recordCountPlanItemsCompleted = new recordCountPlanItems();

      plannedItemStatusAndSubGoalIDKey.plannedItemStatus = PLANNEDITEMSTATUS.COMPLETED;
      recordCountPlanItemsCompleted = plannedItemObj.countPlanItemsOfSpecificStatus(
        plannedItemStatusAndSubGoalIDKey);

      // If all plan planItems are set to 'completed',
      // then set the sub goal status to 'completed'.
      if (recordCountPlanItemsCompleted.recordCount == numberOfPlanItems) {

        // set the sub goal status to not started
        plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.COMPLETED;

      }

      if (recordCountPlanItemsCompleted.recordCount < numberOfPlanItems
        && recordCountPlanItemsCompleted.recordCount > 0) {

        // set the sub goal status to in progress
        plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.INPROGRESS;

      }

      // read all 'In Progress' planItems.
      recordCountPlanItems recordCountPlanItemsInProgress = new recordCountPlanItems();

      plannedItemStatusAndSubGoalIDKey.plannedItemStatus = PLANNEDITEMSTATUS.INPROGRESS;
      recordCountPlanItemsInProgress = plannedItemObj.countPlanItemsOfSpecificStatus(
        plannedItemStatusAndSubGoalIDKey);

      // If any planned items are set to 'in progress',
      // then set the sub goal status to 'in progress'.
      if (recordCountPlanItemsInProgress.recordCount > 0) {

        // set the sub goal status to not started
        plannedSubGoalStatus.status = PLANNEDSUBGOALSTATUS.INPROGRESS;

      }
      // modify the status of sub goal
      modifySubGoalStatus(key, plannedSubGoalStatus);

    }
  }

}
