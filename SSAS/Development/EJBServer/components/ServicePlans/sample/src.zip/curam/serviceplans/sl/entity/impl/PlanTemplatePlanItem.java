/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2006, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOPLANTEMPLATEPLANITEM;
import curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemApprCritFactory;
import curam.serviceplans.sl.entity.intf.PlanTemplatePlanItemApprCrit;
import curam.serviceplans.sl.entity.struct.PlanItemAndPlanTemplateSubGoalKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateAndPlanItemModifyDetails;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateStatus;
import curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalKey;
import curam.serviceplans.sl.struct.ReadPlanItemDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;


/**
 * The plan template plan item links an plan item to the plan template.
 */
public abstract class PlanTemplatePlanItem extends curam.serviceplans.sl.entity.base.PlanTemplatePlanItem {
  // ___________________________________________________________________________
  /**
   * Performs operations before inserting the plan template plan item details
   *
   * @param details the plan template plan item details
   */
  protected void preinsert(PlanTemplatePlanItemDtls details)
    throws AppException, InformationalException {

    // validate details
    validateInsert(details);
  }

  // ___________________________________________________________________________
  // BEGIN, CR00228422 MN
  /**
   * Perform operations before modifying the plan template plan item details
   *
   * @param key the key of the plan template planItem
   * @param details the new details
   *
   * @deprecated since Curam v6, replaced with {@link premodifyPlanTemplateAndPlanItemDetails}. 
   * The new method along with existing functionality performs operations on 
   * plan template plan item details along with mandatory and approval 
   * indicators.See release note <CR00228422>
   */
  @Deprecated
  protected void premodifyDetails(
    PlanTemplatePlanItemKey key, 
    curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemModifyDetails 
    details) throws AppException, InformationalException {

    PlanTemplateAndPlanItemModifyDetails modifyDetails = new PlanTemplateAndPlanItemModifyDetails();
    
    modifyDetails.authorizedUnits = details.authorizedUnits;
    modifyDetails.description = details.description;
    modifyDetails.duration = details.duration;
    modifyDetails.expectedOutcomeID = details.expectedOutcomeID;
    modifyDetails.maximumUnits = details.maximumUnits;
    modifyDetails.planItemID = details.planItemID;
    modifyDetails.startDay = details.startDay;
    modifyDetails.versionNo = details.versionNo;
    
    premodifyPlanTemplateAndPlanItemDetails(key, modifyDetails);
  }

  // END, CR00228422

  // ___________________________________________________________________________
  /**
   * Performs operations before canceling the plan template planItem
   *
   * @param key the plan template plan item key
   * @throws AppException, InformationalException
   */
  protected void preremove(PlanTemplatePlanItemKey key)
    throws AppException, InformationalException {

    // validate
    validateCancel(key);
    // BEGIN, CR00161962, LJ
    // part to remove the associated approval criteria for the
    // plan item if any
    PlanTemplatePlanItemApprCrit templatePlanItemApprCritObj = PlanTemplatePlanItemApprCritFactory.newInstance();

    try {
      templatePlanItemApprCritObj.removeByPlanTemplatePlanItem(key);
    } catch (RecordNotFoundException e) {// No approval criteria exists for this plan item
      // which we are trying to delete from the
      // sub goal template
    }
    // END, CR00161962
  }

  // ___________________________________________________________________________
  /**
   * Validate the details for cancel
   *
   * @param key the plan template plan item key
   */
  public void validateCancel(PlanTemplatePlanItemKey key)
    throws AppException, InformationalException {

    // Plan Template entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    // check if plan template is canceled
    PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatusByPlanTemplatePlanItemID(
      key);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_PT_PLAN_ITEM_DELETE_FROM_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validate the details for insert
   *
   * @param details the plan template plan item details
   */
  public void validateInsert(PlanTemplatePlanItemDtls details)
    throws AppException, InformationalException {

    // PlanItem and Plan Template Sub Goal key
    PlanItemAndPlanTemplateSubGoalKey planItemAndPlanTemplateSubGoalKey = new PlanItemAndPlanTemplateSubGoalKey();

    // Plan Item Entity
    curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    // set the key
    planItemAndPlanTemplateSubGoalKey.planItemID = details.planItemID;
    planItemAndPlanTemplateSubGoalKey.planTemplateSubGoalID = details.planTemplateSubGoalID;

    // Read the Plan Item details for validation
    curam.serviceplans.sl.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.struct.PlanItemKey();

    planItemKey.key.planItemID = details.planItemID;

    ReadPlanItemDetails readPlanItemDetails = planItemObj.read(planItemKey);

    // plan item ID must not be blank
    if (details.planItemID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATEPLANITEM.ERR_FV_PLAN_ITEM_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // duration must be specified
    if (details.duration <= 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATEPLANITEM.ERR_FV_DURATION_LE_ZERO),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // number of days after the commenced start date of plan that the planned
    // plan item created on template starts must be specified
    if (details.startDay < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATEPLANITEM.ERR_FV_START_DATE_LT_ZERO),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00000034, PMD

    // Authorized Units must not be entered for Plan Items with no Unit Type.
    if (details.authorizedUnits > 0
      && readPlanItemDetails.dtls.unitType.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_TEMPLATE_PLAN_ITEM_XFV_AUTHORIZED_UNITS_ENTERED_NO_UNIT_TYPE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Maximum Units must not be entered for Plan Items with no Unit Type.
    if (details.maximumUnits > 0
      && readPlanItemDetails.dtls.unitType.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_TEMPLATE_PLAN_ITEM_XFV_MAXIMUM_UNITS_ENTERED_NO_UNIT_TYPE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00000022, PMD
    // Authorized Units must be greater than zero
    if (details.authorizedUnits < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_FV_AUTHORIZED_UNITS_LE_ZERO),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Maximum Units must be greater than zero
    if (details.maximumUnits < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATEPLANITEM.ERR_FV_MAXIMUM_UNITS_LE_ZERO),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    // END, CR00000022

    // Authorized Units must not exceed Maximum Units.
    if (details.authorizedUnits > details.maximumUnits) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_TEMPLATE_PLAN_ITEM_XFV_AUTHORIZED_UNITS_GREATER_THAN_MAXIMUM_UNITS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Maximum Units must not exceed the Plan Item Maximum Units.
    if (details.maximumUnits > readPlanItemDetails.dtls.maximumUnits) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_TEMPLATE_PLAN_ITEM_XFV_MAXIMUM_UNITS_GREATER_THAN_PLAN_ITEM_MAXIMUM_UNITS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    
    // Authorized Units must not exceed the Plan Item Authorized Units.
    if (details.authorizedUnits > readPlanItemDetails.dtls.authorizedUnits) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_TEMPLATE_PLAN_ITEM_XFV_AUTHORIZED_UNITS_GREATER_THAN_PLAN_ITEM_AUTHORIZED_UNITS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00000034

    // Plan Template entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    PlanTemplateSubGoalKey planTemplateSubGoalKey = new PlanTemplateSubGoalKey();

    planTemplateSubGoalKey.planTemplateSubGoalID = details.planTemplateSubGoalID;

    // check if plan template is canceled
    PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatusByPlanTemplateSubGoalID(
      planTemplateSubGoalKey);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_PT_PLAN_ITEM_ADD_TO_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  // BEGIN, CR00228422 MN
  /**
   * Validates details for modify
   *
   * @param details the plan template plan item details
   *
   * @deprecated
   * @deprecated since Curam v6, replaced with {@link validatePlanTemplateAndPlanItemModify}. 
   * The new method along with existing functionality validates 
   * plan template plan item details along with mandatory and approval 
   * indicators.See release note <CR00228422>
   */
  @Deprecated
  public void validateModify(
    curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemModifyDetails 
    details) throws AppException, InformationalException {

    PlanTemplateAndPlanItemModifyDetails modifyDetails = new PlanTemplateAndPlanItemModifyDetails();
    
    modifyDetails.authorizedUnits = details.authorizedUnits;
    modifyDetails.description = details.description;
    modifyDetails.duration = details.duration;
    modifyDetails.expectedOutcomeID = details.expectedOutcomeID;
    modifyDetails.maximumUnits = details.maximumUnits;
    modifyDetails.planItemID = details.planItemID;
    modifyDetails.startDay = details.startDay;
    modifyDetails.versionNo = details.versionNo;
    
    validatePlanTemplateAndPlanItemModify(modifyDetails);

  }

  // END, CR00228422

  // BEGIN, CR00226905 MN
  /**
   * Perform operations before modifying the plan template plan item details
   *
   * @param key the key of the plan template planItem
   * @param details the new details
   */
  protected void premodifyPlanTemplateAndPlanItemDetails(
    PlanTemplatePlanItemKey key, PlanTemplateAndPlanItemModifyDetails details)
    throws AppException, InformationalException {
    // validate details
    validatePlanTemplateAndPlanItemModify(details);
  }

  /**
   * Validates details for modify along with approval and mandatory indicators.
   *
   * @param details the plan template plan item details
   */
  public void validatePlanTemplateAndPlanItemModify(
    PlanTemplateAndPlanItemModifyDetails dtls) throws AppException,
      InformationalException {
    // Plan Item Entity
    curam.serviceplans.sl.intf.PlanItem planItemObj = curam.serviceplans.sl.fact.PlanItemFactory.newInstance();

    // Read the Plan Item details for validation
    curam.serviceplans.sl.struct.PlanItemKey planItemKey = new curam.serviceplans.sl.struct.PlanItemKey();

    planItemKey.key.planItemID = dtls.planItemID;

    ReadPlanItemDetails readPlanItemDetails = planItemObj.read(planItemKey);

    // duration must be specified
    if (dtls.duration <= 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATEPLANITEM.ERR_FV_DURATION_LE_ZERO),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // number of days after the commenced start date of plan that the planned
    // plan item created on template starts must be specified
    if (dtls.startDay < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATEPLANITEM.ERR_FV_START_DATE_LT_ZERO),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // Authorized Units must not be entered for Plan Items with no Unit Type.
    if (dtls.authorizedUnits > 0
      && readPlanItemDetails.dtls.unitType.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_TEMPLATE_PLAN_ITEM_XFV_AUTHORIZED_UNITS_ENTERED_NO_UNIT_TYPE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Maximum Units must not be entered for Plan Items with no Unit Type.
    if (dtls.maximumUnits > 0
      && readPlanItemDetails.dtls.unitType.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_TEMPLATE_PLAN_ITEM_XFV_MAXIMUM_UNITS_ENTERED_NO_UNIT_TYPE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Authorized Units must be greater than zero
    if (dtls.authorizedUnits < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_FV_AUTHORIZED_UNITS_LE_ZERO),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Maximum Units must be greater than zero
    if (dtls.maximumUnits < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATEPLANITEM.ERR_FV_MAXIMUM_UNITS_LE_ZERO),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Authorized Units must not exceed Maximum Units.
    if (dtls.authorizedUnits > dtls.maximumUnits) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_TEMPLATE_PLAN_ITEM_XFV_AUTHORIZED_UNITS_GREATER_THAN_MAXIMUM_UNITS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
        
    // Maximum Units must not exceed the Plan Item Maximum Units.
    if (dtls.maximumUnits > readPlanItemDetails.dtls.maximumUnits) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_TEMPLATE_PLAN_ITEM_XFV_MAXIMUM_UNITS_GREATER_THAN_PLAN_ITEM_MAXIMUM_UNITS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // Authorized Units must not exceed the Plan Item Authorized Units.
    if (dtls.authorizedUnits > readPlanItemDetails.dtls.authorizedUnits) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANITEM.ERR_TEMPLATE_PLAN_ITEM_XFV_AUTHORIZED_UNITS_GREATER_THAN_PLAN_ITEM_AUTHORIZED_UNITS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
  }
  // END, CR00226905
}
