/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.serviceplans.sl.entity.struct.ContractPrintHistoryDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * A contract represents a formal agreement between the organization and the
 * plan participant, or a nominated representative, to undertake the planItems listed
 * on the service plan. A Service Plan is used to describe a plan by which a client
 * will change his. The plan will contain goals which the client will strive to
 * achieve, each goal consists of a number of sub goals and the sub goal
 * contain planItems that the client must perform in order to complete their
 * sub goal.
 */
public abstract class ContractPrintHistory extends curam.serviceplans.sl.entity.base.ContractPrintHistory {

  // _________________________________________________________________________
  /**
   * Set details before the data insertion
   *
   * @param details Details to be inserted.
   *
   */
  protected void preinsert(ContractPrintHistoryDtls details)
    throws AppException, InformationalException {

    // Set the print date and current user name
    details.printDate = curam.util.type.Date.getCurrentDate();
    details.requestedBy =
      curam.util.transaction.TransactionInfo.getProgramUser();

  }
}
