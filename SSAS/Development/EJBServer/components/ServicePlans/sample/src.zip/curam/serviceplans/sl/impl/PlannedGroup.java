/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005, 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import com.google.inject.Inject;

import curam.codetable.MILESTONESTATUSCODE;
import curam.codetable.PLANCONTENTTYPE;
import curam.codetable.SUBGOALNAME;
import curam.codetable.impl.LOCALEEntry;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.entity.struct.MilestoneDeliveryAndConfigDetails;
import curam.core.sl.entity.struct.MilestoneDeliveryAndConfigDetailsList;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.events.SERVICEPLANS;
import curam.message.BPOPLANNEDGROUP;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.GENERALCASE;
import curam.serviceplans.sl.entity.fact.PlannedGoalFactory;
import curam.serviceplans.sl.entity.fact.PlannedGroupFactory;
import curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory;
import curam.serviceplans.sl.entity.fact.SPMilestoneDeliveryLinkFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.intf.PlannedGoal;
import curam.serviceplans.sl.entity.intf.PlannedSubGoal;
import curam.serviceplans.sl.entity.intf.SPMilestoneDeliveryLink;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.struct.ParentGroupIDKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalCaseIDKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalCountDetails;
import curam.serviceplans.sl.entity.struct.PlannedGoalDtls;
import curam.serviceplans.sl.entity.struct.PlannedGroupDetailsList;
import curam.serviceplans.sl.entity.struct.PlannedGroupDtls;
import curam.serviceplans.sl.entity.struct.PlannedGroupIDAndCaseID;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalDetailsForPlannedGroupList;
import curam.serviceplans.sl.entity.struct.PlannedSubGoalPlannedGroupIDKey;
import curam.serviceplans.sl.entity.struct.SPMilestoneAndLinkDtls;
import curam.serviceplans.sl.entity.struct.SPMilestoneAndLinkDtlsList;
import curam.serviceplans.sl.fact.MilestoneFactory;
import curam.serviceplans.sl.struct.CreatePlannedGroupDetails;
import curam.serviceplans.sl.struct.ListPlannedGroupDetails;
import curam.serviceplans.sl.struct.ListPlannedGroupDetailsList;
import curam.serviceplans.sl.struct.ListPlannedSubGoalDetails;
import curam.serviceplans.sl.struct.ListPlannedSubGoalDetailsList;
import curam.serviceplans.sl.struct.ModifyPlannedGroupDetails;
import curam.serviceplans.sl.struct.PlanContentActualAndExpectedDates;
import curam.serviceplans.sl.struct.PlanContentDetails;
import curam.serviceplans.sl.struct.PlanContentDetailsList;
import curam.serviceplans.sl.struct.PlanContentMilestoneDetails;
import curam.serviceplans.sl.struct.PlanContentStartAndEndDate;
import curam.serviceplans.sl.struct.PlannedGoalKey;
import curam.serviceplans.sl.struct.PlannedGroupKey;
import curam.serviceplans.sl.struct.PlannedSubGoalCaseIDKey;
import curam.serviceplans.sl.struct.PlannedSubGoalKey;
import curam.serviceplans.sl.struct.ReadPlannedGroupDetails;
import curam.serviceplans.sl.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanSecurityKey;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;


/**
 * This process class provides the functionality for the Planned Group
 * service layer.
 */
public abstract class PlannedGroup extends curam.serviceplans.sl.base.PlannedGroup {

  // BEGIN, CR00236426, GP
  @Inject
  private LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Default constructor.
   */
  public PlannedGroup() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00236426
  /**
   * Creates the new planned group.
   *
   * @param details
   * Contains the planned group details.
   *
   * @return Key of the created planned group.
   *
   * @throws AppException
   * {@link BPOPLANNEDGROUP#ERR_PLANGROUP_FV_CREATE_NO_GOAL_DEFINED} -
   * if a plan group may be added to the service plan until a service
   * plan goal has been defined.
   * @throws AppException
   * {@link BPOPLANNEDGROUP#ERR_DELETE_SECURITY_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to maintain this
   * service plan.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have the maintenance rights for this case. Please
   * contact your security administrator.
   */
  public PlannedGroupKey create(CreatePlannedGroupDetails details)
    throws AppException, InformationalException {

    // Planned Group entity manipulation variables
    curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = PlannedGroupFactory.newInstance();
    PlannedGroupDtls plannedGroupDtls = new PlannedGroupDtls();

    // Planned Goal entity manipulation variables
    PlannedGoal plannedGoalObj = PlannedGoalFactory.newInstance();
    PlannedGoalCaseIDKey plannedGoalCaseIDKey = new PlannedGoalCaseIDKey();
    PlannedGoalCountDetails plannedGoalCountDetails = null;

    // Service Plan Delivery manipulation object
    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // BEGIN, CR00227859, PM
    // Security variables
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = details.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    // return struct
    PlannedGroupKey plannedGroupKey = new PlannedGroupKey();

    // set the plannedGoalCaseIDKey
    plannedGoalCaseIDKey.caseID = details.caseID;

    // check a planned Goal exists
    plannedGoalCountDetails = plannedGoalObj.countPlannedGoalByCaseID(
      plannedGoalCaseIDKey);

    if (plannedGoalCountDetails.recordCount == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANNEDGROUP.ERR_PLANGROUP_FV_CREATE_NO_GOAL_DEFINED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // read plannedGoalID by caseID
    plannedGroupDtls.plannedGoalID = plannedGoalObj.readPlannedGoalIDByCaseID(plannedGoalCaseIDKey).plannedGoalID;
    // assign the creation details
    plannedGroupDtls.assign(details);

    // create Planned Group
    plannedGroupObj.insert(plannedGroupDtls);

    // set group identifier to be returned
    plannedGroupKey.key.plannedGroupID = plannedGroupDtls.plannedGroupID;

    // Service plans workflow raise event integration
    Event event = new Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = SERVICEPLANS.CREATEPLANGROUP;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = plannedGroupKey.key.plannedGroupID;
    EventService.raiseEvent(event);

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // Read service plan id.
    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedGroupObj.readCaseIDByPlannedGroupID(plannedGroupKey.key).caseID;

    servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(BPOPLANNEDGROUP.ERR_DELETE_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    return plannedGroupKey;
  }
  
  // BEGIN, CR00278597, AC
  /**
   * Returns a list of all planned groups and subgoals for a particular service
   * plan goal.
   *
   * @param servicePlanDeliveryKey
   * Contains the caseID key for the specific service plan.
   *
   * @return List of planned groups and/or sub-goals for the service plan goal.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public PlanContentDetailsList listPlanContent(
    final ServicePlanDeliveryKey servicePlanDeliveryKey) throws AppException,
      InformationalException {

    final PlanContentDetailsList planContentDetailsList = new PlanContentDetailsList();

    // Plan content list consists of both planned subgoals and planned groups
    // Need to list both and add to the plan content list to be returned.

    final ListPlannedGroupDetailsList listPlannedGroupDetailsList = listPlannedGroups(
      servicePlanDeliveryKey);
    
    for (final ListPlannedGroupDetails listPlannedGroupDetails : 
      listPlannedGroupDetailsList.plannedGroupList.items()) {
      
      PlanContentDetails planContentDetails = new PlanContentDetails();

      planContentDetails.name = listPlannedGroupDetails.name;
      planContentDetails.startDate = listPlannedGroupDetails.startDate;
      planContentDetails.endDate = listPlannedGroupDetails.endDate;
      planContentDetails.planContentType = listPlannedGroupDetails.planContentType;
      planContentDetails.planContentID = listPlannedGroupDetails.id;
      planContentDetails.planContentTypeInd = true;
      planContentDetailsList.list.addRef(planContentDetails);
    }

    PlannedSubGoalCaseIDKey plannedSubGoalCaseIDKey = new PlannedSubGoalCaseIDKey();
    curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    plannedSubGoalCaseIDKey.key.caseID = servicePlanDeliveryKey.key.caseID;

    ListPlannedSubGoalDetailsList listPlannedSubGoalDetailsList = plannedSubGoalObj.list(
      plannedSubGoalCaseIDKey);
   
    for (ListPlannedSubGoalDetails listPlannedSubGoalDetails : 
      listPlannedSubGoalDetailsList.plannedSubGoalList.items()) {
      
      PlanContentDetails planContentDetails = new PlanContentDetails();
      
      planContentDetails.name = CodeTable.getOneItem(SUBGOALNAME.TABLENAME,
        listPlannedSubGoalDetails.name, TransactionInfo.getProgramLocale());
      
      planContentDetails.startDate = listPlannedSubGoalDetails.startDate;
      planContentDetails.endDate = listPlannedSubGoalDetails.endDate;
      planContentDetails.outcome = listPlannedSubGoalDetails.outcomeAchieved;
      planContentDetails.status = listPlannedSubGoalDetails.status;
      planContentDetails.planContentType = listPlannedSubGoalDetails.planContentType;
      
      planContentDetails.planContentID = listPlannedSubGoalDetails.id;
      planContentDetails.planContentTypeInd = false;

      planContentDetailsList.list.addRef(planContentDetails);
    }

    return planContentDetailsList;
  }

  // END, CR00278597

  // ___________________________________________________________________________
  /**
   * Returns a list of all planned groups and subgoals for a particular service plan goal.
   *
   * @param servicePlanDeliveryKey Contains the caseID key for the specific service plan
   *
   * @return List of planned groups and/or sub-goals for the service plan goal
   */
  public PlanContentDetailsList listPlanGroupContent(ServicePlanDeliveryKey servicePlanDeliveryKey)
    throws AppException, InformationalException {

    // return struct
    PlanContentDetailsList planContentDetailsList = new PlanContentDetailsList();

    // Plan content list consists of both planned subgoals and planned groups
    // Need to list both and add to the plan content list to be returned

    // list planned sub goals
    PlannedSubGoalCaseIDKey plannedSubGoalCaseIDKey = new PlannedSubGoalCaseIDKey();
    curam.serviceplans.sl.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();

    // set the key
    plannedSubGoalCaseIDKey.key.caseID = servicePlanDeliveryKey.key.caseID;

    ListPlannedSubGoalDetailsList listPlannedSubGoalDetailsList = plannedSubGoalObj.list(
      plannedSubGoalCaseIDKey);

    // assign values of both lists to plan content return struct - Planned SubGoal
    for (int i = 0; i < listPlannedSubGoalDetailsList.plannedSubGoalList.size(); i++) {

      PlanContentDetails planContentDetails = new PlanContentDetails();

      // assign details
      planContentDetails.name = // BEGIN, CR00163098, JC
        CodeTable.getOneItem(SUBGOALNAME.TABLENAME,
        listPlannedSubGoalDetailsList.plannedSubGoalList.item(i).name,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
      planContentDetails.startDate = listPlannedSubGoalDetailsList.plannedSubGoalList.item(i).startDate;
      planContentDetails.endDate = listPlannedSubGoalDetailsList.plannedSubGoalList.item(i).endDate;
      planContentDetails.outcome = listPlannedSubGoalDetailsList.plannedSubGoalList.item(i).outcomeAchieved;
      planContentDetails.status = listPlannedSubGoalDetailsList.plannedSubGoalList.item(i).status;
      planContentDetails.planContentType = listPlannedSubGoalDetailsList.plannedSubGoalList.item(i).planContentType;
      // set the planContentID to the plannedSubGoalID
      planContentDetails.planContentID = listPlannedSubGoalDetailsList.plannedSubGoalList.item(i).id;

      // assign each structure to struct list to be returned
      planContentDetailsList.list.addRef(planContentDetails);

    }

    servicePlanDeliveryKey.key.caseID = servicePlanDeliveryKey.key.caseID;

    // list planned groups
    ListPlannedGroupDetailsList listPlannedGroupDetailsList = listPlannedGroups(
      servicePlanDeliveryKey);

    // assign values of both lists to plan content return struct - Planned group
    for (int i = 0; i < listPlannedGroupDetailsList.plannedGroupList.size(); i++) {
      PlanContentDetails planContentDetails = new PlanContentDetails();

      // assign details
      planContentDetails.name = listPlannedGroupDetailsList.plannedGroupList.item(i).name;
      planContentDetails.startDate = listPlannedGroupDetailsList.plannedGroupList.item(i).startDate;
      planContentDetails.endDate = listPlannedGroupDetailsList.plannedGroupList.item(i).endDate;
      planContentDetails.planContentType = listPlannedGroupDetailsList.plannedGroupList.item(i).planContentType;
      // set the planContentID to the plannedGroupID
      planContentDetails.planContentID = listPlannedGroupDetailsList.plannedGroupList.item(i).id;
      // no outcome or status for planned group


      // assign each structure to struct list to be returned
      planContentDetailsList.list.addRef(planContentDetails);
    }
    return planContentDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of all planned groups for a particular service plan goal.
   *
   * @param key Contains the caseID key for the specific service plan
   *
   * @return List of planned groups for the service plan goal
   */
  public ListPlannedGroupDetailsList listPlannedGroups(ServicePlanDeliveryKey key)
    throws AppException, InformationalException {

    // planned group entity manipulation variables
    curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();

    // return struct
    ListPlannedGroupDetailsList listPlannedGroupDetailsList = new ListPlannedGroupDetailsList();

    PlannedGroupDetailsList plannedGroupDetailsList = plannedGroupObj.searchByCaseID(
      key.key);

    // for loop similar to list plan sub goals
    for (int i = 0; i < plannedGroupDetailsList.dtls.size(); i++) {

      ListPlannedGroupDetails listPlannedGroupDetails = new ListPlannedGroupDetails();

      // assign details
      listPlannedGroupDetails.id = plannedGroupDetailsList.dtls.item(i).plannedGroupID;
      listPlannedGroupDetails.name = plannedGroupDetailsList.dtls.item(i).name;

      // Set the type code to planned sub goal for each record found
      listPlannedGroupDetails.planContentType = PLANCONTENTTYPE.PLANNEDGROUP;

      // Set the dates
      PlanContentActualAndExpectedDates planContentActualAndExpectedDates = new PlanContentActualAndExpectedDates();

      planContentActualAndExpectedDates.actualEndDate = plannedGroupDetailsList.dtls.item(i).actualEndDate;
      planContentActualAndExpectedDates.actualStartDate = plannedGroupDetailsList.dtls.item(i).actualStartDate;
      planContentActualAndExpectedDates.expectedStartDate = plannedGroupDetailsList.dtls.item(i).expectedStartDate;
      planContentActualAndExpectedDates.expectedEndDate = plannedGroupDetailsList.dtls.item(i).expectedEndDate;

      PlanContentStartAndEndDate planContentStartAndEndDate;

      planContentStartAndEndDate = readPlanContentStartAndEndDate(
        planContentActualAndExpectedDates);

      // Set the start and end date to be displayed on list
      listPlannedGroupDetails.endDate = planContentStartAndEndDate.endDate;
      listPlannedGroupDetails.startDate = planContentStartAndEndDate.startDate;

      // assign each structure to struct list to be returned
      listPlannedGroupDetailsList.plannedGroupList.addRef(
        listPlannedGroupDetails);
    }
    return listPlannedGroupDetailsList;
  }

  /**
   * Modifies a planned group.
   *
   * @param modifyPlannedGroupDetails
   * Contains the new values for a planned group.
   *
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have the maintenance rights for this case. Please
   * contact your security administrator.
   * @throws AppException
   * {@link BPOPLANNEDGROUP#ERR_DELETE_SECURITY_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to maintain this
   * service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   */
  public void modify(ModifyPlannedGroupDetails modifyPlannedGroupDetails)
    throws AppException, InformationalException {

    // Planned Group entity manipulation variables
    curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = PlannedGroupFactory.newInstance();
    curam.serviceplans.sl.entity.struct.PlannedGroupKey plannedGroupKey = new curam.serviceplans.sl.entity.struct.PlannedGroupKey();

    // Service Plan Delivery manipulation object
    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // Set planned group key
    plannedGroupKey.plannedGroupID = modifyPlannedGroupDetails.plannedGroupModifyDetails.plannedGroupID;

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // Read service plan id.
    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedGroupObj.readCaseIDByPlannedGroupID(plannedGroupKey).caseID;

    // BEGIN, CR00227859, PM
    // Security variables
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = servicePlanDeliveryKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(BPOPLANNEDGROUP.ERR_DELETE_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // read plannedgoalID
    modifyPlannedGroupDetails.plannedGroupModifyDetails.plannedGoalID = plannedGroupObj.readPlannedGoalIDByPlannedGroup(plannedGroupKey).plannedGoalID;

    // Modify planned group
    plannedGroupObj.modify(plannedGroupKey,
      modifyPlannedGroupDetails.plannedGroupModifyDetails);

    // Service plans workflow raise event integration
    Event event = new Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = SERVICEPLANS.MODIFYPLANGROUP;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = plannedGroupKey.plannedGroupID;
    EventService.raiseEvent(event);

  }

  /**
   * Physically removes a planned group from the database.
   *
   * @param plannedGroupKey
   * Contains the planned group key.
   *
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_RIGHTS} - if the user
   * does not have the maintenance rights for this case. Please
   * contact your security administrator.
   * @throws AppException
   * {@link BPOPLANNEDGROUP#ERR_DELETE_SECURITY_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to maintain this
   * service plan.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_ACCESS_RIGHTS} - if the
   * user does not have the required privileges to access this data.
   * @throws AppException
   * {@link GENERALCASE#ERR_CASESECURITY_CHECK_READONLY_RIGHTS} - if
   * the user does not have the required privileges to maintain this
   * data.
   */
  public void remove(PlannedGroupKey plannedGroupKey) throws AppException,
      InformationalException {

    // Planned group entity manipulation variable
    curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = PlannedGroupFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // need to read the service plan case id
    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

    // Read service plan id.
    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    servicePlanDeliveryKey.caseID = plannedGroupObj.readCaseIDByPlannedGroupID(plannedGroupKey.key).caseID;

    // BEGIN, CR00227859, PM
    // Security variables
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    DataBasedSecurityResult dataBasedSecurityResult;

    // perform case security check
    caseSecurityCheckKey.caseID = servicePlanDeliveryKey.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00227859

    servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(BPOPLANNEDGROUP.ERR_DELETE_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Call for a physical removal from database
    plannedGroupObj.remove(plannedGroupKey.key);

    // Service plans workflow raise event integration
    Event event = new Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = SERVICEPLANS.DELETEPLANGROUP;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = plannedGroupKey.key.plannedGroupID;
    EventService.raiseEvent(event);
  }

  /**
   * View the details for a specific planned group.
   *
   * @param plannedGroupKey
   * Contains the planned sub-goal key.
   *
   * @return Details of the requested planned group.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOPLANNEDGROUP#ERR_VIEW_PLANNED_GROUP_DELETED} - if this
   * plan group is being deleted and is no longer present on the
   * service plan.
   * @throws AppException
   * {@link BPOPLANNEDGROUP#ERR_VIEW_SECURITY_CHECK_FAILED} - if the
   * user does not have the appropriate privileges to view this
   * service plan.
   */
  public ReadPlannedGroupDetails viewDetails(PlannedGroupKey plannedGroupKey)
    throws AppException, InformationalException {

    // Planned Group entity manipulation variable
    curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = PlannedGroupFactory.newInstance();

    // Planned SubGoal entity manipulation variable
    PlannedSubGoal plannedSubGoalObj = PlannedSubGoalFactory.newInstance();

    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();

    // Return value
    ReadPlannedGroupDetails readPlannedGroupDetails = new ReadPlannedGroupDetails();

    PlannedSubGoalDetailsForPlannedGroupList plannedSubGoalDetailsForPlannedGroupList = null;
    PlannedGroupDetailsList plannedGroupDetailsList = null;
    PlanContentDetails planContentDetails = new PlanContentDetails();

    // If the Plan Group is deleted, return an error message

    try {
      // read the name and version number details
      readPlannedGroupDetails.plannedGroupName = plannedGroupObj.readName(
        plannedGroupKey.key);
    } catch (RecordNotFoundException e) {
      // throw exception
      throw new AppException(BPOPLANNEDGROUP.ERR_VIEW_PLANNED_GROUP_DELETED);
    }

    readPlannedGroupDetails.plannedGroupVersionNoAndComments = plannedGroupObj.readVersionNoAndComments(
      plannedGroupKey.key);

    ParentGroupIDKey parentGroupIDKey = new ParentGroupIDKey();

    parentGroupIDKey.parentGroupID = plannedGroupKey.key.plannedGroupID;

    // List all the planned groups for the current plan group.
    plannedGroupDetailsList = plannedGroupObj.searchChildGroupsByParentGroupID(
      parentGroupIDKey);

    PlannedSubGoalPlannedGroupIDKey plannedSubGoalPlannedGroupIDKey = new PlannedSubGoalPlannedGroupIDKey();

    // set the key
    plannedSubGoalPlannedGroupIDKey.plannedGroupID = plannedGroupKey.key.plannedGroupID;
    // List all the sub goals for the current plan group.
    plannedSubGoalDetailsForPlannedGroupList = plannedSubGoalObj.searchByPlannedGroupID(
      plannedSubGoalPlannedGroupIDKey);

    readPlannedGroupDetails.planContentDetails.list.ensureCapacity(
      plannedGroupDetailsList.dtls.size() + plannedGroupDetailsList.dtls.size());

    // Add planned groups to the group content list.
    for (int i = 0; i < plannedGroupDetailsList.dtls.size(); i++) {
      planContentDetails.planContentID = plannedGroupDetailsList.dtls.item(i).plannedGroupID;

      planContentDetails.name = plannedGroupDetailsList.dtls.item(i).name;

      // Set the dates
      PlanContentActualAndExpectedDates planContentActualAndExpectedDates = new PlanContentActualAndExpectedDates();

      planContentActualAndExpectedDates.actualEndDate = plannedGroupDetailsList.dtls.item(i).actualEndDate;
      planContentActualAndExpectedDates.actualStartDate = plannedGroupDetailsList.dtls.item(i).actualStartDate;
      planContentActualAndExpectedDates.expectedStartDate = plannedGroupDetailsList.dtls.item(i).expectedStartDate;
      planContentActualAndExpectedDates.expectedEndDate = plannedGroupDetailsList.dtls.item(i).expectedEndDate;

      PlanContentStartAndEndDate planContentStartAndEndDate;

      planContentStartAndEndDate = readPlanContentStartAndEndDate(
        planContentActualAndExpectedDates);

      // Set the start and end date to be displayed on list
      planContentDetails.endDate = planContentStartAndEndDate.endDate;
      planContentDetails.startDate = planContentStartAndEndDate.startDate;

      planContentDetails.planContentType = PLANCONTENTTYPE.PLANNEDGROUP;
      planContentDetails.planContentTypeInd = true;

      readPlannedGroupDetails.planContentDetails.list.addRef(planContentDetails);
      planContentDetails = new PlanContentDetails();
    }

    // Add planned sub goals to the group content list.
    for (int i = 0; i < plannedSubGoalDetailsForPlannedGroupList.dtls.size(); i++) {

      planContentDetails.planContentID = plannedSubGoalDetailsForPlannedGroupList.dtls.item(i).plannedSubGoalID;
      // to get planned subgoal name from subgoal codetable name
      planContentDetails.name = // BEGIN, CR00163098, JC
        CodeTable.getOneItem(SUBGOALNAME.TABLENAME,
        plannedSubGoalDetailsForPlannedGroupList.dtls.item(i).name,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      planContentDetails.outcome = plannedSubGoalDetailsForPlannedGroupList.dtls.item(i).outcome;
      planContentDetails.status = plannedSubGoalDetailsForPlannedGroupList.dtls.item(i).status;
      PlanContentActualAndExpectedDates planContentActualAndExpectedDates = new PlanContentActualAndExpectedDates();

      // Set the dates
      planContentActualAndExpectedDates.actualEndDate = plannedSubGoalDetailsForPlannedGroupList.dtls.item(i).actualEndDate;
      planContentActualAndExpectedDates.actualStartDate = plannedSubGoalDetailsForPlannedGroupList.dtls.item(i).actualStartDate;
      planContentActualAndExpectedDates.expectedStartDate = plannedSubGoalDetailsForPlannedGroupList.dtls.item(i).expectedStartDate;
      planContentActualAndExpectedDates.expectedEndDate = plannedSubGoalDetailsForPlannedGroupList.dtls.item(i).expectedEndDate;

      PlanContentStartAndEndDate planContentStartAndEndDate;

      planContentStartAndEndDate = readPlanContentStartAndEndDate(
        planContentActualAndExpectedDates);

      // Set the start and end date to be displayed on list
      planContentDetails.endDate = planContentStartAndEndDate.endDate;
      planContentDetails.startDate = planContentStartAndEndDate.startDate;

      planContentDetails.planContentType = PLANCONTENTTYPE.PLANNEDSUBGOAL;
      planContentDetails.planContentTypeInd = false;

      readPlannedGroupDetails.planContentDetails.list.addRef(planContentDetails);
      planContentDetails = new PlanContentDetails();
    }

    // BEGIN, CR00053508, PMD

    // SPMilestoneDeliveryLink entity manipulation variable
    SPMilestoneDeliveryLink spMilestoneDeliveryLinkObj = SPMilestoneDeliveryLinkFactory.newInstance();

    PlannedGroupIDAndCaseID plannedGroupIDAndCaseID = new PlannedGroupIDAndCaseID();

    plannedGroupIDAndCaseID.plannedGroupID = plannedGroupKey.key.plannedGroupID;

    curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey();

    // Read the case id
    servicePlanDeliveryKey.caseID = plannedGroupObj.readCaseIDByPlannedGroupID(plannedGroupKey.key).caseID;

    plannedGroupIDAndCaseID.caseID = servicePlanDeliveryKey.caseID;

    // Get the list of milestones for this planned group.
    // BEGIN, CR00236426, GP
    MilestoneDeliveryAndConfigDetailsList milestoneDeliveryAndConfigDetailsList = spMilestoneDeliveryLinkObj.searchMilestonesByPlannedGroupID1(
      plannedGroupIDAndCaseID);

    for (MilestoneDeliveryAndConfigDetails milestoneDeliveryAndConfigDetails :
      milestoneDeliveryAndConfigDetailsList.dtls.items()) {

      PlanContentMilestoneDetails planContentMilestoneDetails = new PlanContentMilestoneDetails();

      // Set the plan group milestone details
      planContentMilestoneDetails.milestoneDeliveryID = milestoneDeliveryAndConfigDetails.milestoneDeliveryID;
      // Read the localized name.
      if (0 != milestoneDeliveryAndConfigDetails.nameTextID) {

        LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          milestoneDeliveryAndConfigDetails.nameTextID);

        planContentMilestoneDetails.name = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
      // Read the localized type.
      if (0 != milestoneDeliveryAndConfigDetails.typeTextID) {

        LocalizableTextHandler localizableText = localizableTextHandlerDAO.get(
          milestoneDeliveryAndConfigDetails.typeTextID);

        planContentMilestoneDetails.type = localizableText.getValue(
          LOCALEEntry.get(
            ProgramLocale.getLocale(TransactionInfo.getProgramUser()).toString()));
      }
      planContentMilestoneDetails.status = milestoneDeliveryAndConfigDetails.status;

      // Set the start date
      if (planContentMilestoneDetails.status.equals(
        MILESTONESTATUSCODE.NOTSTARTED)) {

        planContentMilestoneDetails.startDate = milestoneDeliveryAndConfigDetails.expectedStartDate;
      } else {
        planContentMilestoneDetails.startDate = milestoneDeliveryAndConfigDetails.actualStartDate;
      }

      // Set the end date
      if (planContentMilestoneDetails.status.equals(
        MILESTONESTATUSCODE.COMPLETED)) {

        planContentMilestoneDetails.endDate = milestoneDeliveryAndConfigDetails.actualEndDate;
      } else {

        planContentMilestoneDetails.endDate = milestoneDeliveryAndConfigDetails.expectedEndDate;
      }

      // Set the indicator
      if (planContentMilestoneDetails.status.equals(
        MILESTONESTATUSCODE.NOTSTARTED)
          && (milestoneDeliveryAndConfigDetails.expectedStartDate.before(
            Date.getCurrentDate()))) {

        planContentMilestoneDetails.indicator = true;
      }
      // END, CR00236426
      readPlannedGroupDetails.milestoneList.dtlsList.addRef(
        planContentMilestoneDetails);
    }
    // END, CR00053508

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity = ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387

    ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

    // need to read the service plan case id and plan participant role id.
    servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

    // Read service plan id.
    servicePlanSecurityKey.servicePlanID = servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.servicePlanSecurityCheck(servicePlanSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(BPOPLANNEDGROUP.ERR_VIEW_SECURITY_CHECK_FAILED);
      } else {
        throw e;
      }
    }
    // Return planned group details
    return readPlannedGroupDetails;
  }

  // ___________________________________________________________________________
  /**
   * Clones planned group details
   *
   * @param oldPlannedGroupDtls planned group that is to be cloned
   * @param newPlannedGoalID newly created planned goal identifier
   * @param newParentGroupID newly created parent group identifier
   */
  public void clone(
    curam.serviceplans.sl.struct.PlannedGroupDtls oldPlannedGroupDtls,
    PlannedGoalKey newPlannedGoalID,
    PlannedGroupKey newParentGroupID)
    throws AppException, InformationalException {

    // Planned Group entity manipulation variable
    curam.serviceplans.sl.entity.intf.PlannedGroup plannedGroupObj = curam.serviceplans.sl.entity.fact.PlannedGroupFactory.newInstance();
    curam.serviceplans.sl.entity.struct.PlannedGroupDtls plannedGroupDtls = new curam.serviceplans.sl.entity.struct.PlannedGroupDtls();
    curam.serviceplans.sl.entity.struct.PlannedGoalIDAndParentGroupIDKey plannedGoalIDAndParentGroupIDKey = new curam.serviceplans.sl.entity.struct.PlannedGoalIDAndParentGroupIDKey();
    curam.serviceplans.sl.entity.struct.PlannedGroupDtlsList plannedGroupDtlsList;

    // Planned Sub Goal entity manipulation variable
    curam.serviceplans.sl.entity.intf.PlannedSubGoal plannedSubGoalObj = curam.serviceplans.sl.entity.fact.PlannedSubGoalFactory.newInstance();
    curam.serviceplans.sl.entity.struct.PlannedGoalIDAndPlannedGroupIDKey plannedGoalIDAndPlannedGroupIDKey = new curam.serviceplans.sl.entity.struct.PlannedGoalIDAndPlannedGroupIDKey();
    curam.serviceplans.sl.entity.struct.PlannedSubGoalDtlsList plannedSubGoalDtlsList;

    // Planned Sub Goal business object manipulation variable
    curam.serviceplans.sl.intf.PlannedSubGoal boPlannedSubGoalObj = curam.serviceplans.sl.fact.PlannedSubGoalFactory.newInstance();
    curam.serviceplans.sl.struct.PlannedSubGoalDtls boPlannedSubGoalDtls;
    curam.serviceplans.sl.struct.PlannedGoalKey boPlannedGoalKey = new curam.serviceplans.sl.struct.PlannedGoalKey();
    curam.serviceplans.sl.struct.PlannedGroupKey boPlannedGroupKey = new curam.serviceplans.sl.struct.PlannedGroupKey();

    // create new planned group details
    plannedGroupDtls.assign(oldPlannedGroupDtls.dtls);
    plannedGroupDtls.parentGroupID = newParentGroupID.key.plannedGroupID;
    plannedGroupDtls.plannedGoalID = newPlannedGoalID.key.plannedGoalID;
    plannedGroupDtls.plannedGroupID = 0;

    // insert new planned group
    plannedGroupObj.insert(plannedGroupDtls);

    // set new planned goal ID
    boPlannedGoalKey.key.plannedGoalID = newPlannedGoalID.key.plannedGoalID;

    // set new planned group ID
    boPlannedGroupKey.key.plannedGroupID = plannedGroupDtls.plannedGroupID;

    // BEGIN, CR00057087, PMD
    // Search for all milestones at planned group level and clone them
    curam.serviceplans.sl.entity.struct.PlannedGoalKey oldPlannedGoalkey = new curam.serviceplans.sl.entity.struct.PlannedGoalKey();

    oldPlannedGoalkey.plannedGoalID = oldPlannedGroupDtls.dtls.plannedGoalID;

    // Read the old planned goal details to get the case id.
    PlannedGoalDtls oldPlannedGoalDtls = PlannedGoalFactory.newInstance().read(
      oldPlannedGoalkey);

    PlannedGroupIDAndCaseID plannedGroupIDAndCaseID = new PlannedGroupIDAndCaseID();

    plannedGroupIDAndCaseID.plannedGroupID = oldPlannedGroupDtls.dtls.plannedGroupID;
    plannedGroupIDAndCaseID.caseID = oldPlannedGoalDtls.caseID;

    // Search for planned group milestones
    SPMilestoneAndLinkDtlsList spMilestoneAndLinkDtlsList = SPMilestoneDeliveryLinkFactory.newInstance().searchMilestonesAndLinksByCaseIDAndPlannedGroupID(
      plannedGroupIDAndCaseID);

    for (int k = 0; k < spMilestoneAndLinkDtlsList.dtls.size(); k++) {

      curam.serviceplans.sl.entity.struct.PlannedGoalKey newPlannedGoalkey = new curam.serviceplans.sl.entity.struct.PlannedGoalKey();

      newPlannedGoalkey.plannedGoalID = boPlannedGoalKey.key.plannedGoalID;

      // Read the new planned goal details to get the case id.
      PlannedGoalDtls newPlannedGoalDtls = PlannedGoalFactory.newInstance().read(
        newPlannedGoalkey);

      SPMilestoneAndLinkDtls spMilestoneAndLinkDtls = new SPMilestoneAndLinkDtls();

      spMilestoneAndLinkDtls.assign(spMilestoneAndLinkDtlsList.dtls.item(k));
      spMilestoneAndLinkDtls.caseID = newPlannedGoalDtls.caseID;

      // Clone the milestone
      MilestoneFactory.newInstance().clone(spMilestoneAndLinkDtls,
        boPlannedGroupKey, new PlannedSubGoalKey());
    }
    // END, CR00057087

    // set the key
    plannedGoalIDAndPlannedGroupIDKey.plannedGoalID = oldPlannedGroupDtls.dtls.plannedGoalID;
    plannedGoalIDAndPlannedGroupIDKey.plannedGroupID = oldPlannedGroupDtls.dtls.plannedGroupID;

    // search for sub goals
    plannedSubGoalDtlsList = plannedSubGoalObj.searchByPlannedGoalIDAndPlannedGroupID(
      plannedGoalIDAndPlannedGroupIDKey);

    // clone found sub goals
    for (int i = 0; i < plannedSubGoalDtlsList.dtls.size(); i++) {

      // assign details for cloning planned sub goal
      boPlannedSubGoalDtls = new curam.serviceplans.sl.struct.PlannedSubGoalDtls();
      boPlannedSubGoalDtls.dtls.assign(plannedSubGoalDtlsList.dtls.item(i));

      // clone sub goal
      boPlannedSubGoalObj.clone(boPlannedSubGoalDtls, boPlannedGoalKey,
        boPlannedGroupKey);
    }

    // set the key
    plannedGoalIDAndParentGroupIDKey.parentGroupID = oldPlannedGroupDtls.dtls.plannedGroupID;
    plannedGoalIDAndParentGroupIDKey.plannedGoalID = oldPlannedGroupDtls.dtls.plannedGoalID;

    // search for the next level planned groups
    plannedGroupDtlsList = plannedGroupObj.searchByPlannedGoalIDAndParentGroupID(
      plannedGoalIDAndParentGroupIDKey);

    // clone planned groups found
    for (int j = 0; j < plannedGroupDtlsList.dtls.size(); j++) {

      // assign the old details
      oldPlannedGroupDtls.dtls.assign(plannedGroupDtlsList.dtls.item(j));

      // clone
      clone(oldPlannedGroupDtls, boPlannedGoalKey, boPlannedGroupKey);
    }
  }

  // ___________________________________________________________________________
  /**
   * Reads the actual and expected dates for a planned group or subgoal
   * It decides which of the dates(expected/actual StartDate and
   * actual/expected EndDate) are the earliest and returns them.
   *
   * @param expectedAndActualDates Both expected and actual dates
   *
   * @return The plan content start and end date
   */
  public PlanContentStartAndEndDate readPlanContentStartAndEndDate(PlanContentActualAndExpectedDates expectedAndActualDates)
    throws AppException, InformationalException {

    // Create return struct
    PlanContentStartAndEndDate planContentStartAndEndDate = new
      PlanContentStartAndEndDate();

    // The following scenarios can occur and have to be checked when setting
    // both start and end date:
    // 1. Where both set of dates are not set
    // 2. Where both sets of dates are set
    // 3. Where expected date is set and actual is not set
    // 4. Where actual date is set and expected date is not set.

    // Is both the actual and expected start dates are not set?
    if (expectedAndActualDates.actualStartDate.isZero()
      && expectedAndActualDates.expectedStartDate.isZero()) {
      // Set to no date
      planContentStartAndEndDate.startDate = curam.util.type.Date.kZeroDate;
    } // Are both start dates set?
    else if (!expectedAndActualDates.actualStartDate.isZero()
      && !expectedAndActualDates.expectedStartDate.isZero()) {

      // Set to the actual start date
      planContentStartAndEndDate.startDate = expectedAndActualDates.actualStartDate;

    } // if actual start date set and expected date not set?
    else if ((!expectedAndActualDates.actualStartDate.isZero()
      && expectedAndActualDates.expectedStartDate.isZero())) {
      planContentStartAndEndDate.startDate = expectedAndActualDates.actualStartDate;
    } // if expected start date set and actual date not set?
    else if ((!expectedAndActualDates.expectedStartDate.isZero()
      && expectedAndActualDates.actualStartDate.isZero())) {
      planContentStartAndEndDate.startDate = expectedAndActualDates.expectedStartDate;
    }

    // Do the same Checks for the actual and expected end dates
    // Is both the actual and expected end dates not set?
    if (expectedAndActualDates.actualEndDate.isZero()
      && expectedAndActualDates.expectedEndDate.isZero()) {
      // Set to no date
      planContentStartAndEndDate.startDate = curam.util.type.Date.kZeroDate;
    } // Is the both end dates set?
    else if (!expectedAndActualDates.actualEndDate.isZero()
      && !expectedAndActualDates.expectedEndDate.isZero()) {

      // BEGIN, CR00156275, SK
      planContentStartAndEndDate.endDate = expectedAndActualDates.actualEndDate;
      // END, CR00156275

    } // Is actual end date set and expected date not set?
    else if ((!expectedAndActualDates.actualEndDate.isZero()
      && expectedAndActualDates.expectedEndDate.isZero())) {
      planContentStartAndEndDate.endDate = expectedAndActualDates.actualEndDate;
    } // if expected end date set and actual date not set?
    else if ((!expectedAndActualDates.expectedEndDate.isZero()
      && expectedAndActualDates.actualEndDate.isZero())) {
      planContentStartAndEndDate.endDate = expectedAndActualDates.expectedEndDate;
    }

    return planContentStartAndEndDate;
  }

}
