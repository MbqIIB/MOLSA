/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;

import curam.core.fact.AttachmentFactory;
import curam.core.intf.Attachment;
import curam.core.struct.AttachmentKey;
import curam.serviceplans.sl.entity.struct.PlannedItemAttachmentLinkDtls;
import curam.serviceplans.sl.entity.struct.PlannedItemAttachmentLinkKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

public abstract class PlannedItemAttachmentLink
      extends curam.serviceplans.sl.entity.base.PlannedItemAttachmentLink {

  // ___________________________________________________________________________
  /**
   * Performs removal of planned item attachments before removing the
   * planned item
   *
   * @param plannedItemAttachmentLinkKey - The planned item attachment link
   *   key to remove the attachments
   */
  protected void preremove(PlannedItemAttachmentLinkKey
     plannedItemAttachmentLinkKey) throws AppException, InformationalException {

    //  Creating Planned Item Attachment Link details
    PlannedItemAttachmentLinkDtls
      plannedItemAttachmentLinkDtls = new PlannedItemAttachmentLinkDtls();

    // Creating Attachment key
    AttachmentKey attachmentKey =  new AttachmentKey();

    // Read the planned item attachment link table
    // and get the corresponding attachment id
    plannedItemAttachmentLinkDtls = read(plannedItemAttachmentLinkKey);

    //  Getting the Entity Attachment object
    Attachment attachmentObj = AttachmentFactory.newInstance();

    attachmentKey.attachmentID = plannedItemAttachmentLinkDtls.attachmentID;

    //  Deleting Attachment details
    attachmentObj.remove(attachmentKey);
  }
}
