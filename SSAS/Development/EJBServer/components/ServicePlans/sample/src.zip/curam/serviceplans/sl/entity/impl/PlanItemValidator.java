/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOPLANITEM;
import curam.serviceplans.sl.entity.fact.PlanItemFactory;
import curam.serviceplans.sl.entity.intf.PlanItem;
import curam.serviceplans.sl.entity.struct.PlanItemCountDetails;
import curam.serviceplans.sl.entity.struct.PlanItemDtls;
import curam.serviceplans.sl.entity.struct.PlanItemKey;
import curam.serviceplans.sl.entity.struct.PlanItemNameAndReferenceDetails;
import curam.serviceplans.sl.entity.struct.PlanItemNameAndStatusDetails;
import curam.serviceplans.sl.entity.struct.PlanItemReferenceDetails;
import curam.serviceplans.sl.entity.struct.PlanItemStatusDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class contains validation method for plan item creation and 
 * modification. The methods contained in this class are invoked using hook
 * mechanism.
 *
 *
 */

public class PlanItemValidator extends curam.serviceplans.sl.entity.base.PlanItemValidator {

  // ___________________________________________________________________________
  /**
   * Validates the details of a planned item before insertion
   *
   * @param dtls details of the plan item to be validated.
   */


  public void validateInsert(PlanItemDtls dtls) throws AppException,
      InformationalException {

    PlanItem planItemObj = PlanItemFactory.newInstance();

    //
    // check unique fields
    //

    // search if any active records already have the specified name
    PlanItemNameAndStatusDetails planItemNameAndStatusDetails = new PlanItemNameAndStatusDetails();

    planItemNameAndStatusDetails.name = dtls.name;
    planItemNameAndStatusDetails.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    PlanItemCountDetails planItemCount = planItemObj.countByNameAndStatus(
      planItemNameAndStatusDetails);

    // do any active records already have that name?
    if (planItemCount.numPlanItems > 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_FV_NAME_EXISTS),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    // has a reference been specified?
    if (dtls.planItemReference.length() > 0) {

      // yes, reference has been specified so check that it's unique
      PlanItemReferenceDetails planItemReferenceDetails = new PlanItemReferenceDetails();

      planItemReferenceDetails.planItemReference = dtls.planItemReference;
      planItemCount = planItemObj.countByReference(planItemReferenceDetails);

      // does reference already exist?
      if (planItemCount.numPlanItems > 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOPLANITEM.ERR_PLAN_ITEM_FV_REFERENCE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates the details of a planned item before modification
   *
   * @param key id of the plan item whose details are to be modified
   * @param dtls details of the plan item to be validated.
   */

  public void validateModify(PlanItemKey key, PlanItemDtls dtls)
    throws AppException, InformationalException {

    //
    // check that the record isn't canceled
    //

    PlanItem planItemObj = PlanItemFactory.newInstance();

    // read in the record status
    PlanItemStatusDetails planItemStatusDetails = planItemObj.readRecordStatus(
      key);

    // is the plan item already canceled?
    if (planItemStatusDetails.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANITEM.ERR_PLAN_ITEM_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    //
    // check that unique fields are still unique
    //

    // read the old name and reference
    PlanItemNameAndReferenceDetails nameAndReferenceDetails = planItemObj.readNameAndReference(
      key);

    // has the name been changed?
    if (!dtls.name.equals(nameAndReferenceDetails.name)) {

      // count the number of active records with the new name
      PlanItemNameAndStatusDetails nameAndStatusDetails = new PlanItemNameAndStatusDetails();

      nameAndStatusDetails.name = dtls.name;
      nameAndStatusDetails.recordStatus = RECORDSTATUS.NORMAL;
      PlanItemCountDetails planItemCount = planItemObj.countByNameAndStatus(
        nameAndStatusDetails);

      // is the name already in active use?
      if (planItemCount.numPlanItems > 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOPLANITEM.ERR_PLAN_ITEM_FV_NAME_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);

      }

    }

    // has the reference been changed?
    if (!dtls.planItemReference.equals(
      nameAndReferenceDetails.planItemReference)) {

      // count the number of records with the new reference
      PlanItemReferenceDetails planItemReferenceDetails = new PlanItemReferenceDetails();

      planItemReferenceDetails.planItemReference = dtls.planItemReference;
      PlanItemCountDetails planItemCount = planItemObj.countByReference(
        planItemReferenceDetails);

      // is the reference already in use?
      if (planItemCount.numPlanItems > 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOPLANITEM.ERR_PLAN_ITEM_FV_REFERENCE_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      }

    }

  }

}
