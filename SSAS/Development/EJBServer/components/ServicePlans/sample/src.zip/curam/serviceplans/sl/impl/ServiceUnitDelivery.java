/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006-2007, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.message.BPOPLANNEDITEM;
import curam.message.BPOSERVICEPLANSECURITY;
import curam.message.BPOSERVICEUNITDELIVERY;
import curam.serviceplans.sl.entity.fact.PlannedItemFactory;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory;
import curam.serviceplans.sl.entity.intf.PlannedItem;
import curam.serviceplans.sl.entity.intf.ServicePlanDelivery;
import curam.serviceplans.sl.entity.struct.PlanItemIDDetailsStruct;
import curam.serviceplans.sl.entity.struct.PlanItemServiceUnitDeliveryDetails;
import curam.serviceplans.sl.entity.struct.PlannedItemIDStatus;
import curam.serviceplans.sl.entity.struct.ReadCaseIDByPlannedItemDetailsStruct;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryCancelKey;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryCount;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryDtls;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryDtlsList;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryKey;
import curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryStatusDetails;
import curam.serviceplans.sl.struct.PlanItemKey;
import curam.serviceplans.sl.struct.PlannedItemIDKey;
import curam.serviceplans.sl.struct.ReadServiceUnitDeliveryKey;
import curam.serviceplans.sl.struct.ServicePlanPlanItemSecurityKey;
import curam.serviceplans.sl.struct.ServiceUnitDeliveryDetails;
import curam.serviceplans.sl.struct.ServiceUnitDeliveryDetailsList;
import curam.serviceplans.sl.struct.ServiceUnitDeliveryListKey;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Date;


public abstract class ServiceUnitDelivery extends
  curam.serviceplans.sl.base.ServiceUnitDelivery {

  // BEGIN, CR00000080, CM
  /**
   * Cancels a Service Unit Delivery.
   * 
   * @param key
   *          Contains the key of the Service Unit Delivery.
   * 
   * @throws AppException
   *           {@link BPOPLANNEDITEM#ERR_MODIFY_SERVICEPLAN_SECURITY_CHECK_FAILED}
   *           - if the user does not have the appropriate privileges to
   *           maintain this service plan.
   * @throws AppException
   *           {@link BPOSERVICEUNITDELIVERY#ERR_MODIFY_PARTICIPANT_CHECK_FAILED}
   *           - if the user does not have the appropriate privileges to
   *           maintain this plan item.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  public void cancelServiceUnitDelivery(
    curam.serviceplans.sl.struct.ServiceUnitDeliveryCancelKey key)
    throws AppException, InformationalException {

    // Service Unit Delivery Business Object
    curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj =
      ServiceUnitDeliveryFactory.newInstance();
    ServiceUnitDeliveryCancelKey serviceUnitDeliveryCancelKey =
      new ServiceUnitDeliveryCancelKey();
    ServiceUnitDeliveryStatusDetails serviceUnitDeliveryStatusDetails =
      new ServiceUnitDeliveryStatusDetails();

    // Service Plan Delivery Entity Object
    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory
        .newInstance();

    // Planned Item Entity Object
    PlannedItem plannedItemObj =
      curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity =
      ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387
    
    ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey =
      new ServicePlanPlanItemSecurityKey();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType =
      ServicePlanSecurity.kMaintainSecurityCheck;

    ServiceUnitDeliveryDtls serviceUnitDeliveryDtls = 
      new ServiceUnitDeliveryDtls();

    // Read the plannedItemID
    ServiceUnitDeliveryKey serviceUnitDeliveryKey = 
      new ServiceUnitDeliveryKey();

    // Read servicePlanID.
    ServicePlanDeliveryKey servicePlanDeliveryKey =
      new ServicePlanDeliveryKey();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct =
      new ReadCaseIDByPlannedItemDetailsStruct();

    curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey =
      new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    // Set Service Unit Delivery key
    serviceUnitDeliveryKey.serviceUnitDeliveryID =
      key.key.serviceUnitDeliveryID;

    // Read Service Unit Deliveries
    serviceUnitDeliveryDtls =
      serviceUnitDeliveryObj.read(serviceUnitDeliveryKey);

    // Set the plannedItemId
    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey
      .plannedItemID = serviceUnitDeliveryDtls.plannedItemID;

    plannedItemIDKey.plannedItemID = serviceUnitDeliveryDtls.plannedItemID;

    // Read the Case ID
    readCaseIDByPlannedItemDetailsStruct =
      plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey);

    // Set the caseID
    servicePlanDeliveryKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID =
      servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);

    } catch (AppException e) {

      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
            BPOPLANNEDITEM.ERR_MODIFY_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
          BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
            BPOSERVICEUNITDELIVERY.ERR_MODIFY_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Set version number
    serviceUnitDeliveryCancelKey.versionNo = key.key.versionNo;

    // Set record status to CANCELLED
    serviceUnitDeliveryStatusDetails.recordStatus = RECORDSTATUS.CANCELLED;

    // set Service Unit Delivery key
    serviceUnitDeliveryCancelKey.serviceUnitDeliveryID =
      key.key.serviceUnitDeliveryID;

    // cancel Service Unit Delivery
    serviceUnitDeliveryObj.cancel(serviceUnitDeliveryCancelKey,
      serviceUnitDeliveryStatusDetails);

    // Service plans workflow raise event integration
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.DELETESERVICEUNITDELIVERY;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = key.key.serviceUnitDeliveryID;
    curam.util.events.impl.EventService.raiseEvent(event);
  }

  /**
   * Lists active service unit deliveries for a planned item on a given day.
   * 
   * @param serviceUnitDeliveryListKey
   *          Contains the planned item id, delivery date and record status.
   * 
   * @return A list of all the Service Unit Deliveries that are available.
   * 
   * @throws AppException
   *           {@link BPOPLANNEDITEM#ERR_VIEW_SERVICEPLAN_SECURITY_CHECK_FAILED}
   *           - if the user does not have the appropriate privileges to view
   *           this service plan.
   * @throws AppException
   *           {@link BPOSERVICEUNITDELIVERY#ERR_VIEW_PARTICIPANT_CHECK_FAILED}
   *           - if the user does not have the appropriate privileges to view
   *           this plan item.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  public ServiceUnitDeliveryDetailsList listServiceUnitDelivery(
    ServiceUnitDeliveryListKey serviceUnitDeliveryListKey)
    throws AppException, InformationalException {

    // Return Object
    ServiceUnitDeliveryDetailsList serviceUnitDeliveryDetailsList =
      new ServiceUnitDeliveryDetailsList();

    // Service Unit Delivery Entity
    curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj =
      curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory.newInstance();

    // ServicePlanDelivery Object
    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory
        .newInstance();

    // PlannedItem entity
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity =
      ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387
    
    ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey =
      new ServicePlanPlanItemSecurityKey();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType =
      ServicePlanSecurity.kReadSecurityCheck;

    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey
      .plannedItemID = serviceUnitDeliveryListKey.key.plannedItemID;

    ServicePlanDeliveryKey servicePlanDeliveryKey =
      new ServicePlanDeliveryKey();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct =
      new ReadCaseIDByPlannedItemDetailsStruct();

    curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey =
      new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemID =
      serviceUnitDeliveryListKey.key.plannedItemID;

    readCaseIDByPlannedItemDetailsStruct =
      plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey);

    servicePlanDeliveryKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    // Read service plan id.
    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID =
      servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);
    } catch (AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_VIEW_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEUNITDELIVERY.ERR_VIEW_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    serviceUnitDeliveryListKey.key.recordStatus = RECORDSTATUS.NORMAL;

    ServiceUnitDeliveryDtlsList serviceUnitDeliveryDtlsList =
      new ServiceUnitDeliveryDtlsList();

    serviceUnitDeliveryDtlsList =
      serviceUnitDeliveryObj.searchByPlannedItemIDAndDeliveryDate(
        serviceUnitDeliveryListKey.key);

    for (int i = 0; i < serviceUnitDeliveryDtlsList.dtls.size(); i++) {

      ServiceUnitDeliveryDetails serviceUnitDeliveryDetails =
        new ServiceUnitDeliveryDetails();

      serviceUnitDeliveryDetails.dtls =
        serviceUnitDeliveryDtlsList.dtls.item(i);
      serviceUnitDeliveryDetailsList.dtlsList.addRef(
          serviceUnitDeliveryDetails);

      // BEGIN, CR00057872, CM
      // Check if the list is empty
      if (!serviceUnitDeliveryDetailsList.dtlsList.isEmpty()) {

        // Users manipulation variables
        curam.core.intf.Users usersObj =
          curam.core.fact.UsersFactory.newInstance();
        UsersKey usersKey = new UsersKey();

        // Need to recordedBy's full name
        usersKey.userName =
          serviceUnitDeliveryDetailsList.dtlsList.item(i).dtls.recordedBy;

        // Read full name
        UserFullname userFullname = usersObj.getFullName(usersKey);

        serviceUnitDeliveryDetails.dtls.recordedBy = userFullname.fullname;

      }
      // END, CR00057872
    }

    return serviceUnitDeliveryDetailsList;
  }

  /**
   * Records a Service Unit Delivery.
   * 
   * @param dtls
   *          Contains the details of the new Service Unit Delivery.
   * 
   * @return The unique id of the newly created delivery.
   * 
   * @throws AppException
   *           {@link BPOPLANNEDITEM#ERR_MODIFY_SERVICEPLAN_SECURITY_CHECK_FAILED}
   *           - if the user does not have the appropriate privileges to
   *           maintain this service plan.
   * @throws AppException
   *           {@link BPOSERVICEUNITDELIVERY#ERR_MODIFY_PARTICIPANT_CHECK_FAILED}
   *           - if the user does not have the appropriate privileges to
   *           maintain this plan item.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  public curam.serviceplans.sl.struct.ServiceUnitDeliveryKey recordServiceUnitDelivery(
      ServiceUnitDeliveryDetails dtls) throws AppException,
      InformationalException {

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity =
      ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387
    
    ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey =
      new ServicePlanPlanItemSecurityKey();

    // Return Object
    curam.serviceplans.sl.struct.ServiceUnitDeliveryKey serviceUnitDeliveryKey =
      new curam.serviceplans.sl.struct.ServiceUnitDeliveryKey();

    // Service Unit Delivery Entity Object
    curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj =
      ServiceUnitDeliveryFactory.newInstance();

    // PlannedItem Entity Object
    PlannedItem plannedItemObj =
      curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // ServicePlanDelivery Entity Object
    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory
        .newInstance();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType =
      ServicePlanSecurity.kMaintainSecurityCheck;

    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey
      .plannedItemID = dtls.dtls.plannedItemID;

    // Read service plan id.
    ServicePlanDeliveryKey servicePlanDeliveryKey =
      new ServicePlanDeliveryKey();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct =
      new ReadCaseIDByPlannedItemDetailsStruct();

    // Read case id
    curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey =
      new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = dtls.dtls.plannedItemID;

    readCaseIDByPlannedItemDetailsStruct =
      plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey);

    servicePlanDeliveryKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID =
      servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);
    } catch (AppException e) {
      if (e.equals(BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
            BPOPLANNEDITEM.ERR_MODIFY_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
          BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
            BPOSERVICEUNITDELIVERY.ERR_MODIFY_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    dtls.dtls.recordedDate = Date.getCurrentDate();
    dtls.dtls.recordedBy =
      curam.util.transaction.TransactionInfo.getProgramUser();
    dtls.dtls.recordStatus = RECORDSTATUS.NORMAL;

    // Add the service unit delivery
    serviceUnitDeliveryObj.insert(dtls.dtls);

    serviceUnitDeliveryKey.key.serviceUnitDeliveryID =
      dtls.dtls.serviceUnitDeliveryID;

    // Service plans workflow raise event integration
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.RECORDSERVICEUNITDELIVERY;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = dtls.dtls.serviceUnitDeliveryID;
    curam.util.events.impl.EventService.raiseEvent(event);

    return serviceUnitDeliveryKey;
  }

  /**
   * Modifies a Service Unit Delivery.
   * 
   * @param dtls
   *          Contains the updated Service Unit Delivery details.
   * 
   * @throws AppException
   *           {@link BPOPLANNEDITEM#ERR_MODIFY_SERVICEPLAN_SECURITY_CHECK_FAILED}
   *           - if the user does not have the appropriate privileges to
   *           maintain this service plan.
   * @throws AppException
   *           {@link BPOSERVICEUNITDELIVERY#ERR_MODIFY_PARTICIPANT_CHECK_FAILED}
   *           - if the user does not have the appropriate privileges to
   *           maintain this plan item.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  public void modifyServiceUnitDelivery(ServiceUnitDeliveryDetails dtls)
    throws AppException, InformationalException {

    // Service Unit Delivery Entity
    curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj =
      ServiceUnitDeliveryFactory.newInstance();

    // populate the modify details
    curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryKey key =
      new curam.serviceplans.sl.entity.struct.ServiceUnitDeliveryKey();

    // ServicePlanDelivery Object
    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory
        .newInstance();

    // PlannedItem entity
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity =
      ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387
    
    ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey =
      new ServicePlanPlanItemSecurityKey();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType =
      ServicePlanSecurity.kMaintainSecurityCheck;

    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey
      .plannedItemID = dtls.dtls.plannedItemID;

    // Read service plan id.
    ServicePlanDeliveryKey servicePlanDeliveryKey =
      new ServicePlanDeliveryKey();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct =
      new ReadCaseIDByPlannedItemDetailsStruct();

    // Read case id
    curam.serviceplans.sl.entity.struct.PlannedItemIDKey plannedItemIDKey =
      new curam.serviceplans.sl.entity.struct.PlannedItemIDKey();

    plannedItemIDKey.plannedItemID = dtls.dtls.plannedItemID;

    readCaseIDByPlannedItemDetailsStruct =
      plannedItemObj.readCaseIDByPlannedItemID(plannedItemIDKey);

    servicePlanDeliveryKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID =
      servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);
    } catch (AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_MODIFY_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEUNITDELIVERY.ERR_MODIFY_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    key.serviceUnitDeliveryID = dtls.dtls.serviceUnitDeliveryID;

    dtls.dtls.recordedBy =
      curam.util.transaction.TransactionInfo.getProgramUser();
    dtls.dtls.recordedDate = curam.util.type.Date.getCurrentDate();
    dtls.dtls.recordStatus = RECORDSTATUS.NORMAL;

    // Modify the Service Unit Delivery
    serviceUnitDeliveryObj.modify(key, dtls.dtls);

    // Service plans workflow raise event integration
    Event event = new Event();

    // BEGIN, CR00021588, TV
    // BEGIN,HARP 65061,SRK
    event.eventKey = curam.events.SERVICEPLANS.MODIFYSERVICEUNITDELIVERY;
    // END, HARP 65061
    // END, CR00021588

    event.primaryEventData = dtls.dtls.serviceUnitDeliveryID;
    curam.util.events.impl.EventService.raiseEvent(event);
  }

  /**
   * Reads Service Unit Delivery details. Retrieves the unitType from Plan Item.
   * Gets the units received to date.
   * 
   * @param readServiceUnitDeliveryKey
   *          a key containing the planned item id and the service unit delivery
   *          id
   * 
   * @return the Service Unit Delivery details
   * 
   * @throws AppException
   *           {@link BPOPLANNEDITEM#ERR_VIEW_SERVICEPLAN_SECURITY_CHECK_FAILED}
   *           - if the user does not have the appropriate privileges to view
   *           this service plan.
   * @throws AppException
   *           {@link BPOSERVICEUNITDELIVERY#ERR_VIEW_PARTICIPANT_CHECK_FAILED}
   *           - if the user does not have the appropriate privileges to view
   *           this plan item.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  public ServiceUnitDeliveryDetails viewServiceUnitDelivery(
    ReadServiceUnitDeliveryKey readServiceUnitDeliveryKey)
    throws AppException, InformationalException {

    // Return Object
    ServiceUnitDeliveryDetails serviceUnitDeliveryDetails =
      new ServiceUnitDeliveryDetails();

    // Service Unit Delivery Entity
    curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj =
      ServiceUnitDeliveryFactory.newInstance();

    // Plan Item Entity
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj =
      curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    PlanItemServiceUnitDeliveryDetails planItemServiceUnitDeliveryDetails =
      new PlanItemServiceUnitDeliveryDetails();

    // Service Unit Delivery Count
    ServiceUnitDeliveryCount serviceUnitDeliveryCount =
      new ServiceUnitDeliveryCount();

    // ServicePlanDelivery Entity Object
    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory
        .newInstance();

    // PlannedItem entity Object
    PlannedItem plannedItemObj = PlannedItemFactory.newInstance();

    // BEGIN, CR00179387, NS
    final curam.serviceplans.sl.intf.ServicePlanSecurity servicePlanSecurity =
      ServicePlanSecurityImplementationFactory.get1();
    // END, CR00179387
    
    ServicePlanPlanItemSecurityKey servicePlanPlanItemSecurityKey =
      new ServicePlanPlanItemSecurityKey();

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.securityCheckType =
      ServicePlanSecurity.kReadSecurityCheck;

    servicePlanPlanItemSecurityKey.plannedItemIDKey.plannedItemIDKey
      .plannedItemID = readServiceUnitDeliveryKey.plannedItemKey
      .plannedItemIDKey.plannedItemID;

    // Read service plan id.
    ServicePlanDeliveryKey servicePlanDeliveryKey =
      new ServicePlanDeliveryKey();

    ReadCaseIDByPlannedItemDetailsStruct readCaseIDByPlannedItemDetailsStruct =
      new ReadCaseIDByPlannedItemDetailsStruct();

    PlannedItemIDKey plannedItemIDKey = new PlannedItemIDKey();

    plannedItemIDKey.plannedItemIDKey.plannedItemID =
      readServiceUnitDeliveryKey.plannedItemKey.plannedItemIDKey.plannedItemID;

    readCaseIDByPlannedItemDetailsStruct =
      plannedItemObj.readCaseIDByPlannedItemID(
        plannedItemIDKey.plannedItemIDKey);

    servicePlanDeliveryKey.caseID = readCaseIDByPlannedItemDetailsStruct.caseID;

    servicePlanPlanItemSecurityKey.servicePlanSecurityKey.servicePlanID =
      servicePlanDeliveryObj.read(servicePlanDeliveryKey).servicePlanID;

    // check service plan security
    try {
      servicePlanSecurity.planItemOperationSecurityCheck(
        servicePlanPlanItemSecurityKey);
    } catch (AppException e) {
      if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_SECURITY_CHECK_FAILED)) {
        throw new AppException(
          BPOPLANNEDITEM.ERR_VIEW_SERVICEPLAN_SECURITY_CHECK_FAILED);
      } else if (e.equals(
        BPOSERVICEPLANSECURITY.ERR_PLAN_ITEM_SENSITIVITY_CHECK_FAILED)) {
        throw new AppException(
          BPOSERVICEUNITDELIVERY.ERR_VIEW_PARTICIPANT_CHECK_FAILED);
      } else {
        throw e;
      }
    }

    // Read ServiceUnitDelivery Details
    serviceUnitDeliveryDetails.dtls =
      serviceUnitDeliveryObj.read(
        readServiceUnitDeliveryKey.serviceUnitDeliveryKey);

    // Get the Plan Item ID
    PlanItemIDDetailsStruct planItemIDDetailsStruct =
      new PlanItemIDDetailsStruct();

    planItemIDDetailsStruct =
      plannedItemObj.readPlanItemID(plannedItemIDKey.plannedItemIDKey);

    PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.key.planItemID = planItemIDDetailsStruct.planItemID;

    // Get the unit type from the plan item
    planItemServiceUnitDeliveryDetails =
      planItemObj.readPlanItemServiceUnitDeliveryDetails(planItemKey.key);

    serviceUnitDeliveryDetails.unitType =
      planItemServiceUnitDeliveryDetails.unitType;

    // Get units received to date
    PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

    plannedItemIDStatus.plannedItemID =
      plannedItemIDKey.plannedItemIDKey.plannedItemID;

    serviceUnitDeliveryCount =
      serviceUnitDeliveryObj.countActiveServiceUnitDeliveryByPlannedItemID(
        plannedItemIDStatus);

    serviceUnitDeliveryDetails.unitsReceivedToDate =
      serviceUnitDeliveryCount.count;

    // Get the current user's full name
    curam.core.intf.Users usersObj = curam.core.fact.UsersFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    usersKey.userName = serviceUnitDeliveryDetails.dtls.recordedBy;

    serviceUnitDeliveryDetails.recordedByFullName =
      usersObj.getFullName(usersKey).fullname;

    return serviceUnitDeliveryDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the details required to display the add
   * service unit delivery to the plan item screen
   *
   * @param plannedItemIDKey the key of the planned item
   *
   * @return the service unit delivery details
   */
  public ServiceUnitDeliveryDetails readDetailsForAddServiceUnitDelivery(
    PlannedItemIDKey plannedItemIDKey)
    throws AppException, InformationalException {

    // Plan Item Entity Object
    curam.serviceplans.sl.entity.intf.PlanItem planItemObj =
      curam.serviceplans.sl.entity.fact.PlanItemFactory.newInstance();

    // Planned Item Entity Object
    curam.serviceplans.sl.entity.intf.PlannedItem plannedItemObj =
      curam.serviceplans.sl.entity.fact.PlannedItemFactory.newInstance();

    // Service Unit Entity Object
    curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj =
      curam.serviceplans.sl.entity.fact.ServiceUnitDeliveryFactory.newInstance();

    PlanItemServiceUnitDeliveryDetails planItemServiceUnitDeliveryDetails =
      new PlanItemServiceUnitDeliveryDetails();

    // Return object
    ServiceUnitDeliveryDetails serviceUnitDeliveryDetails =
      new ServiceUnitDeliveryDetails();

    // Get the Plan Item ID
    PlanItemIDDetailsStruct planItemIDDetailsStruct =
      new PlanItemIDDetailsStruct();

    planItemIDDetailsStruct =
      plannedItemObj.readPlanItemID(plannedItemIDKey.plannedItemIDKey);

    PlanItemKey planItemKey = new PlanItemKey();

    planItemKey.key.planItemID = planItemIDDetailsStruct.planItemID;

    // Get the unitType from Plan Item details
    planItemServiceUnitDeliveryDetails =
      planItemObj.readPlanItemServiceUnitDeliveryDetails(planItemKey.key);

    // Use count method to get the units received to date
    PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

    plannedItemIDStatus.plannedItemID =
      plannedItemIDKey.plannedItemIDKey.plannedItemID;

    ServiceUnitDeliveryCount serviceUnitDeliveryCount =
      new ServiceUnitDeliveryCount();

    serviceUnitDeliveryCount =
      serviceUnitDeliveryObj.countActiveServiceUnitDeliveryByPlannedItemID(
        plannedItemIDStatus);

    serviceUnitDeliveryDetails.unitType =
      planItemServiceUnitDeliveryDetails.unitType;
    serviceUnitDeliveryDetails.unitsReceivedToDate =
      serviceUnitDeliveryCount.count;

    // Setting the number of units to be equal to 1.

    // BEGIN, CR00021588, TV
    serviceUnitDeliveryDetails.dtls.numberofUnits =
      curam.serviceplans.sl.impl.ServicePlanUtility.gkOne;
    // END, CR00021588

    return serviceUnitDeliveryDetails;
  }

  // END, CR00000080

  // BEGIN, CR00000048, PMD
  // ___________________________________________________________________________
  /**
   * Clones Service Unit Deliveries
   *
   * @param clonedPlannedItemKey Contains the unique ID of the planned item being cloned
   * @param newPlannedItemKey
   *   Contains the unique ID of the planned item created as a result of cloning
   *
   */
  public void clone(PlannedItemIDKey clonedPlannedItemKey, PlannedItemIDKey newPlannedItemKey)
    throws AppException, InformationalException {

    // Service Unit Delivery Entity
    curam.serviceplans.sl.entity.intf.ServiceUnitDelivery serviceUnitDeliveryObj =
      ServiceUnitDeliveryFactory.newInstance();

    // Authorized Unit History Business Object
    curam.serviceplans.sl.intf.AuthorizedUnitHistory authorizedUnitHistoryObj =
      curam.serviceplans.sl.fact.AuthorizedUnitHistoryFactory.newInstance();

    ServiceUnitDeliveryDtlsList serviceUnitDeliveryDtlsList =
      new ServiceUnitDeliveryDtlsList();
    PlannedItemIDStatus plannedItemIDStatus = new PlannedItemIDStatus();

    plannedItemIDStatus.plannedItemID =
      clonedPlannedItemKey.plannedItemIDKey.plannedItemID;
    plannedItemIDStatus.recordStatus = RECORDSTATUS.NORMAL;

    // Get the list of Service Unit Deliveries for this planned item
    serviceUnitDeliveryDtlsList =
      serviceUnitDeliveryObj.searchByPlannedItemIDAndStatus(plannedItemIDStatus);

    // Clone the service unit deliveries.
    for (int i = 0; i < serviceUnitDeliveryDtlsList.dtls.size(); i++) {

      ServiceUnitDeliveryDtls serviceUnitDeliveryDtls =
        new ServiceUnitDeliveryDtls();

      serviceUnitDeliveryDtls.assign(serviceUnitDeliveryDtlsList.dtls.item(i));
      serviceUnitDeliveryDtls.plannedItemID =
        newPlannedItemKey.plannedItemIDKey.plannedItemID;

      serviceUnitDeliveryObj.insert(serviceUnitDeliveryDtls);
    }

    // Clone the Authorized Unit History
    authorizedUnitHistoryObj.clone(clonedPlannedItemKey, newPlannedItemKey);

  }
  // END, CR00000048

}
