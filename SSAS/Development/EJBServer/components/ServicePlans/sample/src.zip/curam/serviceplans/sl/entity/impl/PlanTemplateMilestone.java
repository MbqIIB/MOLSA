/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.sl.entity.fact.MilestoneConfigurationFactory;
import curam.core.sl.entity.struct.EarliestStartDay;
import curam.core.sl.entity.struct.MilestoneConfigurationKey;
import curam.message.BPOPLANTEMPLATEMILESTONE;
import curam.serviceplans.sl.entity.fact.PlanTemplateFactory;
import curam.serviceplans.sl.entity.struct.PlanTemplateKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateMilestoneDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplateMilestoneKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateStatus;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This entity class provides the functionality for plan template milestones.
 */
public abstract class PlanTemplateMilestone extends curam.serviceplans.sl.entity.base.PlanTemplateMilestone {

  // ___________________________________________________________________________
  /**
   * Performs operations before inserting the plan template milestone details
   *
   * @param details The plan template milestone details
   */
  protected void preinsert(PlanTemplateMilestoneDtls details) 
    throws AppException, InformationalException {

    // Validate the details
    validateInsert(details);
    
  }

  // ___________________________________________________________________________
  /**
   * Performs operations before modifying the plan template milestone details
   *
   * @param key The key of the plan template milestone
   * @param details The plan template milestone details
   */
  protected void premodify(PlanTemplateMilestoneKey key, 
    PlanTemplateMilestoneDtls details) 
    throws AppException, InformationalException {

    // Validate the details
    validateModify(details);
    
  }

  // ___________________________________________________________________________
  /**
   * Performs operations before removing the plan template milestone details
   *
   * @param key The key of the plan template milestone
   */
  protected void preremove(PlanTemplateMilestoneKey key) 
    throws AppException, InformationalException {

    // Validate the details
    validateRemove(key);
    
  }

  // ___________________________________________________________________________
  /**
   * Validate the common details
   *
   * @param details The plan template milestone details
   */
  public void validateDetails(PlanTemplateMilestoneDtls details) 
    throws AppException, InformationalException {

    MilestoneConfigurationKey milestoneConfigurationKey = new MilestoneConfigurationKey();  
    EarliestStartDay earliestStartDay = new EarliestStartDay();
    
    milestoneConfigurationKey.milestoneConfigurationID = details.milestoneConfigurationID;

    // Start After Plan Start must not be negative
    if (details.startAfter < 0) {
     
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEMILESTONE.ERR_MILESTONE_FV_START_AFTER_PLAN_START_LT_ZERO),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);      
    }

    // Duration must be entered
    if (details.duration == 0) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEMILESTONE.ERR_MILESTONE_FV_DURATION_BLANK),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);      
    }

    // Duration must be greater than zero
    if (details.duration < 0) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATEMILESTONE.ERR_FV_DURATION_LT_ZERO),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);      
    }
    
    // Start After Plan Start must be greater than or equal to
    // the earliest start day specified for this milestone
    
    // Read the earliest start day
    earliestStartDay = MilestoneConfigurationFactory.newInstance().readEarliestStartDay(
      milestoneConfigurationKey);
    
    if (details.startAfter < earliestStartDay.earliestStartDay) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATEMILESTONE.ERR_XRV_START_AFTER_PLAN_START_LT_EARLIEST_START_DAY).arg(
          earliestStartDay.earliestStartDay),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    
  }

  // ___________________________________________________________________________
  /**
   * Validate the details for insert
   *
   * @param details The plan template milestone details
   */
  public void validateInsert(PlanTemplateMilestoneDtls details) 
    throws AppException, InformationalException {
      
    // Validate the common details
    validateDetails(details);
        
    // Plan template must not be cancelled
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    planTemplateKey.planTemplateID = details.planTemplateID;
    PlanTemplateStatus planTemplateStatus = PlanTemplateFactory.newInstance().readStatus(
      planTemplateKey);
    
    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEMILESTONE.ERR_RV_ADD_MILESTONE_PLAN_TEMPLATE_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validate the details for modify
   *
   * @param details The plan template milestone details
   */
  public void validateModify(PlanTemplateMilestoneDtls details) 
    throws AppException, InformationalException {
    
    // Validate the common details
    validateDetails(details);

    // Plan template must not be cancelled
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    planTemplateKey.planTemplateID = details.planTemplateID;
    PlanTemplateStatus planTemplateStatus = PlanTemplateFactory.newInstance().readStatus(
      planTemplateKey);
    
    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEMILESTONE.ERR_RV_MODIFY_MILESTONE_PLAN_TEMPLATE_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }    
  }

  // ___________________________________________________________________________
  /**
   * Validate the details for remove
   *
   * @param key The plan template milestone key
   */
  public void validateRemove(PlanTemplateMilestoneKey key) 
    throws AppException, InformationalException {

    // Plan template must not be cancelled
    PlanTemplateStatus planTemplateStatus = PlanTemplateFactory.newInstance().readStatusByPlanTemplateMilestoneID(
      key);
    
    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEMILESTONE.ERR_RV_REMOVE_MILESTONE_PLAN_TEMPLATE_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }
   
}
