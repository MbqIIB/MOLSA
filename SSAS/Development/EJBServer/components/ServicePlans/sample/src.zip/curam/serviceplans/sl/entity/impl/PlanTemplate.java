/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2006, 2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOPLANTEMPLATE;
import curam.serviceplans.sl.entity.struct.PlanTemplateCancelDetails;
import curam.serviceplans.sl.entity.struct.PlanTemplateDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplateIDAndStatusKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateStatus;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * The plan template describes a template for a service plan.  This is used
 * when creating a service plan of a specific type.
 */
public abstract class PlanTemplate extends curam.serviceplans.sl.entity.base.PlanTemplate {

  // ___________________________________________________________________________
  /**
   * Performs operations before inserting the plan template details
   *
   * @param details the plan template details
   */
  protected void preinsert(PlanTemplateDtls details)
    throws AppException, InformationalException {

    // Validate the details
    validateInsert(details);
  }

  // ___________________________________________________________________________
  /**
   * Perform operations before modifying the plan template details
   *
   * @param key the key of the plan template
   * @param details the new details
   */
  protected void premodify(PlanTemplateKey key, PlanTemplateDtls details)
    throws AppException, InformationalException {

    // Validate the details
    validateModify(details);

  }

  // ___________________________________________________________________________
  /**
   * Performs operations before canceling the plan template
   *
   * @param key     the plan template unique identifier
   * @param details the plan template details
   */
  protected void precancel(PlanTemplateKey key, PlanTemplateCancelDetails details)
    throws AppException, InformationalException {

    // Validate cancel
    validateCancel(key);

  }

  // ___________________________________________________________________________
  /**
   * Validate the details for insert
   *
   * @param dtls the plan template details
   */
  public void validateInsert(PlanTemplateDtls dtls)
    throws AppException, InformationalException {

    if (dtls.goalID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_GOAL_BLANK),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validate the details for modify
   *
   * @param dtls the plan template details
   */
  public void validateModify(PlanTemplateDtls dtls)
    throws AppException, InformationalException {

    // Plan Template Sub Goal entity object
    curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal planTemplateSubGoalObj = curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory.newInstance();

    // Plan Template key
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();
    
    // set the key
    planTemplateKey.planTemplateID = dtls.planTemplateID;

    // Read record status
    PlanTemplateStatus planTemplateStatus = readStatus(planTemplateKey);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_CANCELED_NO_MODIFY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }  

    if (readGoalID(planTemplateKey).goalID != dtls.goalID) {
      if (planTemplateSubGoalObj.countByPlanTemplateID(planTemplateKey).count
        > 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_XRV_SUB_GOALS_EXIST),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }

  }

  // ___________________________________________________________________________
  /**
   * Validate the plan template to be canceled
   *
   * @param key Plan template unique identifier
   */
  public void validateCancel(PlanTemplateKey key)
    throws AppException, InformationalException {

    // Read record status
    PlanTemplateStatus planTemplateStatus = readStatus(key);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOPLANTEMPLATE.ERR_TEMPLATE_FV_CANCELED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    PlanTemplateIDAndStatusKey planTemplateIDAndStatusKey = new PlanTemplateIDAndStatusKey();

    // set the key
    planTemplateIDAndStatusKey.planTemplateID = key.planTemplateID;
    planTemplateIDAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;

    // Plan Template Service Plan Link entity
    curam.serviceplans.sl.entity.intf.PlanTemplateServicePlanLink planTemplateServicePlanLinkObj = curam.serviceplans.sl.entity.fact.PlanTemplateServicePlanLinkFactory.newInstance();

    // there must not be any service plan based on the template
    if (planTemplateServicePlanLinkObj.countByServicePlanPlanTemplateAndStatus(planTemplateIDAndStatusKey).count
      > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATE.ERR_TEMPLATE_XRV_ASSIGNED_TO_SERVICEPLAN),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }
}
