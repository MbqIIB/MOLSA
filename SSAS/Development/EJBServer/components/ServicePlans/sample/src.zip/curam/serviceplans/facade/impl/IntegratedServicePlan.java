/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.facade.impl;

import curam.core.sl.struct.CaseIDKey;
import curam.core.struct.CaseHeaderKey;
import curam.serviceplans.facade.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.facade.intf.ServicePlanDelivery;
import curam.serviceplans.facade.struct.ICServicePlanDeliveryMenuDataDetails;
import curam.serviceplans.facade.struct.ISPCaseKeyAndViewActiveKey;
import curam.serviceplans.facade.struct.IntegratedServicePlanContextDescription;
import curam.serviceplans.facade.struct.IntegratedServicePlanHomePageDetails;
import curam.serviceplans.facade.struct.IntegratedServicePlanHomePageKey;
import curam.serviceplans.facade.struct.IntegratedServicePlanKey;
import curam.serviceplans.facade.struct.IntegratedServicePlanMenuDataDetails;
import curam.serviceplans.facade.struct.IntegratedServicePlanTabDetails;
import curam.serviceplans.facade.struct.MilestoneDeliveryDetailsList;
import curam.serviceplans.facade.struct.SPDeliveryContextDescription;
import curam.serviceplans.sl.fact.MaintainIntegratedServicePlanFactory;
import curam.serviceplans.sl.intf.MaintainIntegratedServicePlan;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

/**
 * Facade layer class used to maintain the integrated service plan
 * functionality.
 *
 */
public abstract class IntegratedServicePlan extends
    curam.serviceplans.facade.base.IntegratedServicePlan {

//   _________________________________________________________________________
  /**
   * This method is used to get all the milestones.
   *
   * @param ispCaseKey
   *          ISPCaseKeyAndViewActiveKey
   * @return MilestoneDeliveryDetailsList
   *
   * @throws AppException e1
   * @throws InformationalException e2
   */
  public MilestoneDeliveryDetailsList listInProgressAndFutureMilestones(
      final ISPCaseKeyAndViewActiveKey ispCaseKey) throws AppException,
      InformationalException {

    curam.serviceplans.sl.struct.MilestoneDeliveryDetailsList
      milestoneDeliveryDetailsList = null;
    MaintainIntegratedServicePlan maintainISPDeliveryObj
      = MaintainIntegratedServicePlanFactory.newInstance();
    CaseIDKey caseIDKey = new CaseIDKey();
    caseIDKey.caseID = ispCaseKey.caseID;
    curam.serviceplans.facade.struct.MilestoneDeliveryDetailsList returnStruct
      = new curam.serviceplans.facade.struct.MilestoneDeliveryDetailsList();
    // If the indicator is set to true fetch all the milestones else just fetch
    // the milestones in progress and incomplete.
    if (ispCaseKey.allMileStones) {
      milestoneDeliveryDetailsList = maintainISPDeliveryObj
          .getAllMilestones(caseIDKey);
    } else {
      milestoneDeliveryDetailsList = maintainISPDeliveryObj
          .getIncompleteMilestones(caseIDKey);
    }
    returnStruct.dtlsList.assign(milestoneDeliveryDetailsList);

    // getting integrated case menu
    ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory
        .newInstance();

    IntegratedServicePlanKey integratedServicePlanKey
      = new IntegratedServicePlanKey();

    integratedServicePlanKey.integratedCaseID = ispCaseKey.caseID;

    //get menu data
    returnStruct.menuData.menuData = servicePlanDeliveryObj
        .getICIntegratedServicePlanMenuData(integratedServicePlanKey).menuData;

    return returnStruct;
  }


//_________________________________________________________________________
  /**
   * Constructs the Integrated Service Plan Home Page details.
   *
   * @param integratedServicePlanHomePageKey
   *          IntegratedServicePlanHomePageKey
   * @return IntegratedServicePlanHomePageDetails
   *
   * @throws AppException e1
   * @throws InformationalException e2
   */
  public IntegratedServicePlanHomePageDetails
    readHomePageDetails(
          IntegratedServicePlanHomePageKey integratedServicePlanHomePageKey)
              throws AppException, InformationalException {

    // Service layer Integrated Service Plan Home Page details
    MaintainIntegratedServicePlan maintainIntegratedServicePlan =
      MaintainIntegratedServicePlanFactory.newInstance();

    curam.serviceplans.sl.struct.IntegratedServicePlanKey serviceLayerKey =
      new curam.serviceplans.sl.struct.IntegratedServicePlanKey();

    serviceLayerKey.integratedCaseID =
      integratedServicePlanHomePageKey.integratedCaseID;

    curam.serviceplans.sl.struct.IntegratedServicePlanHomePageDetails
      serviceHomePageDetails =
       new curam.serviceplans.sl.struct.IntegratedServicePlanHomePageDetails();
    if(integratedServicePlanHomePageKey.activeOnly){
      serviceHomePageDetails =
          maintainIntegratedServicePlan.readIntegratedServicePlanHomePage(
               serviceLayerKey, true);
    }
    else {
      serviceHomePageDetails =
        maintainIntegratedServicePlan.readIntegratedServicePlanHomePage(
      serviceLayerKey, false);
    }

    IntegratedServicePlanKey facadeIntegratedServicePlanKey
      = new IntegratedServicePlanKey();

    facadeIntegratedServicePlanKey.integratedCaseID
      = integratedServicePlanHomePageKey.integratedCaseID;

    // Context description
    IntegratedServicePlanContextDescription
      integratedServicePlanContextDescription =
        getContextDescription(facadeIntegratedServicePlanKey);

    // Menu data
    IntegratedServicePlanMenuDataDetails integratedServicePlanMenuDataDetails =
      getMenuData(facadeIntegratedServicePlanKey);

    // Create return object
    IntegratedServicePlanHomePageDetails integratedServicePlanHomePageDetails =
      new IntegratedServicePlanHomePageDetails();

    integratedServicePlanHomePageDetails.activeOnly
      = integratedServicePlanHomePageKey.activeOnly;

    integratedServicePlanHomePageDetails.homePageDetails
      = serviceHomePageDetails;
    integratedServicePlanHomePageDetails.description
      = integratedServicePlanContextDescription;
    integratedServicePlanHomePageDetails.menuData
      = integratedServicePlanMenuDataDetails;

    return integratedServicePlanHomePageDetails;
  }


//_________________________________________________________________________
  /**
   * Gets the context description for the Integrated Service Plan.
   *
   *
   * @param integratedServicePlanKey
   *          IntegratedServicePlanKey
   * @return IntegratedServicePlanContextDescription
   *
   * @throws AppException e1
   * @throws InformationalException e2
   */
  public IntegratedServicePlanContextDescription
    getContextDescription(IntegratedServicePlanKey integratedServicePlanKey)
      throws AppException, InformationalException {

    ServicePlanDelivery servicePlanDeliveryObj
      = ServicePlanDeliveryFactory.newInstance();

    SPDeliveryContextDescription spDeliveryContextDescription =
      servicePlanDeliveryObj.
        getIntegratedServicePlanContextDescription(integratedServicePlanKey);

    IntegratedServicePlanContextDescription
      integratedServicePlanContextDescription =
        new IntegratedServicePlanContextDescription();

    integratedServicePlanContextDescription.description
      = spDeliveryContextDescription.description;

    return integratedServicePlanContextDescription;
  }


//_________________________________________________________________________
  /**
   * Builds the Integrated Service Plan Menu data.
   *
   * @param integratedServicePlanKey
   *          IntegratedServicePlanKey
   * @return IntegratedServicePlanMenuDataDetails
   *
   * @throws AppException e1
   * @throws InformationalException e2
   */
  public IntegratedServicePlanMenuDataDetails
    getMenuData(IntegratedServicePlanKey integratedServicePlanKey)
      throws AppException, InformationalException {

    ServicePlanDelivery servicePlanDeliveryObj
      = ServicePlanDeliveryFactory.newInstance();

    ICServicePlanDeliveryMenuDataDetails icServicePlanDeliveryMenuDataDetails =
      servicePlanDeliveryObj.
        getICIntegratedServicePlanMenuData(integratedServicePlanKey);

    IntegratedServicePlanMenuDataDetails integratedServicePlanMenuDataDetails =
      new IntegratedServicePlanMenuDataDetails();

    integratedServicePlanMenuDataDetails.menuData
      = icServicePlanDeliveryMenuDataDetails.menuData;

    return integratedServicePlanMenuDataDetails;
  }

// BEGIN, CR00211672, CSH 
//_________________________________________________________________________
  /**
   * Reads the details for display on the Integrated Service Plan tab.
   *
   * @param key
   *          The unique identifier of the assistance case.
   * @return IntegratedServicePlanTabDetails
   *
   * @throws AppException Standard application exception
   * @throws InformationalException Standard information exception
   */
  public IntegratedServicePlanTabDetails readIntegratedServicePlanTabDetails(
      CaseHeaderKey key) throws AppException, InformationalException {
        
    IntegratedServicePlanTabDetails tabDetails = 
      new IntegratedServicePlanTabDetails();
    
    // Service layer Integrated Service Plan Home Page details
    MaintainIntegratedServicePlan maintainIntegratedServicePlan =
      MaintainIntegratedServicePlanFactory.newInstance();
    
    tabDetails.tabDtls = 
      maintainIntegratedServicePlan.readIntegratedServicePlanTabDetails(key);
      
    return tabDetails;
  }
  // END CR00211672
}