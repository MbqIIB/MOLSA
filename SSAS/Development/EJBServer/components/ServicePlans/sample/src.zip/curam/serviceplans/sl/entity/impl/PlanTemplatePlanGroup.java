/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.message.BPOPLANTEMPLATEPLANGROUP;
import curam.serviceplans.sl.entity.struct.PlanTemplateKey;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupDtls;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupKey;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanGroupModifyDetails;
import curam.serviceplans.sl.entity.struct.PlanTemplatePlanItemKey;
import curam.serviceplans.sl.entity.struct.PlanTemplateStatus;
import curam.serviceplans.sl.entity.struct.PlanTemplateSubGoalKey;
import curam.serviceplans.sl.entity.struct.TemplatePlanGroupDetailsList;
import curam.serviceplans.sl.entity.struct.TemplatePlanItemDetailsList;
import curam.serviceplans.sl.entity.struct.TemplateSubGoalDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This entity class provides the functionality for plan template plan groups.
 */
public abstract class PlanTemplatePlanGroup extends curam.serviceplans.sl.entity.base.PlanTemplatePlanGroup {

  // ___________________________________________________________________________
  /**
   * Performs operations before inserting the plan template plan group details
   *
   * @param details the plan template plan group details
   */
  @Override
  protected void preinsert(PlanTemplatePlanGroupDtls details)
    throws AppException, InformationalException {

    // Validate the details
    validateInsert(details);
  }

  /**
   * Performs operations before modifying the plan template plan group details
   *
   * @param key the key of the plan template plan group
   * @param details the plan template plan group details
   */
  @Override
  protected void premodifyDetails(PlanTemplatePlanGroupKey key, PlanTemplatePlanGroupModifyDetails details)
    throws AppException, InformationalException {

    // Validate the details
    validateModify(key, details);

  }

  // ___________________________________________________________________________
  /**
   * Performs operations before removing the plan template plan group details
   *
   * @param key the key of the plan template plan group
   */
  @Override
  protected void preremove(PlanTemplatePlanGroupKey key)
    throws AppException, InformationalException {

    // Validate
    validateRemove(key);
  }

  // ___________________________________________________________________________
  /**
   * Validate the details for insert
   *
   * @param details the plan template plan group details
   */
  public void validateInsert(PlanTemplatePlanGroupDtls details)
    throws AppException, InformationalException {

    // Plan template key and entity object
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    planTemplateKey.planTemplateID = details.planTemplateID;

    // Check if plan template is canceled
    PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatus(
      planTemplateKey);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANGROUP.ERR_PT_CREATE_PLAN_GROUP_FOR_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validate the details for modify
   *
   * @param key the template plan group key
   * @param details the plan template plan group details
   */
  public void validateModify(PlanTemplatePlanGroupKey key, PlanTemplatePlanGroupModifyDetails details)
    throws AppException, InformationalException {

    // Plan template key and entity object
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();
    PlanTemplateKey planTemplateKey = new PlanTemplateKey();

    planTemplateKey.planTemplateID = details.planTemplateID;

    // Check if plan template is canceled
    PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatus(
      planTemplateKey);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANGROUP.ERR_PT_MODIFY_PLAN_GROUP_FOR_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validate the details for cancel
   *
   * @param key the plan template plan group key
   */
  public void validateRemove(PlanTemplatePlanGroupKey key)
    throws AppException, InformationalException {

    // Plan Template entity
    curam.serviceplans.sl.entity.intf.PlanTemplate planTemplateObj = curam.serviceplans.sl.entity.fact.PlanTemplateFactory.newInstance();

    // check if plan template is canceled
    PlanTemplateStatus planTemplateStatus = planTemplateObj.readStatusByPlanTemplatePlanGroupID(
      key);

    if (planTemplateStatus.recordStatus.equals(RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOPLANTEMPLATEPLANGROUP.ERR_PT_PLANGROUP_DELETE_FROM_CANCELED_TEMPLATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Before physically deleting a template plan group,
    // all child records need to be physically deleted first

    removeChildRecords(key);

    // Search for child plan groups
    TemplatePlanGroupDetailsList templateChildPlanGroupDetailsList = searchChildPlanGroupsForTemplate(
      key);

    // For every child plan group...
    for (int i = 0; i < templateChildPlanGroupDetailsList.dtls.size(); i++) {

      PlanTemplatePlanGroupKey planTemplateChildPlanGroupKey = new PlanTemplatePlanGroupKey();

      planTemplateChildPlanGroupKey.planTemplatePlanGroupID = templateChildPlanGroupDetailsList.dtls.item(i).planTemplatePlanGroupID;

      removeChildRecords(planTemplateChildPlanGroupKey);

      // Remove the child plan group
      remove(planTemplateChildPlanGroupKey);

    }
  }

  // ___________________________________________________________________________
  /**
   * Removes all child records for a plan group
   *
   * @param key the plan template plan group key
   */
  public void removeChildRecords(PlanTemplatePlanGroupKey key)
    throws AppException, InformationalException {

    // Plan Template SubGoal entity
    curam.serviceplans.sl.entity.intf.PlanTemplateSubGoal planTemplateSubGoalObj = curam.serviceplans.sl.entity.fact.PlanTemplateSubGoalFactory.newInstance();

    // Plan Template PlanItem entity object
    curam.serviceplans.sl.entity.intf.PlanTemplatePlanItem planTemplatePlanItemObj = curam.serviceplans.sl.entity.fact.PlanTemplatePlanItemFactory.newInstance();

    // Search for associated sub-goals
    TemplateSubGoalDetailsList templateSubGoalDetailsList = planTemplateSubGoalObj.searchByPlanTemplatePlanGroupID(
      key);

    // For each associated sub-goal...
    for (int i = 0; i < templateSubGoalDetailsList.dtls.size(); i++) {

      PlanTemplateSubGoalKey planTemplateSubGoalKey = new PlanTemplateSubGoalKey();

      planTemplateSubGoalKey.planTemplateSubGoalID = templateSubGoalDetailsList.dtls.item(i).planTemplateSubGoalID;

      // Search for associated plan items
      TemplatePlanItemDetailsList templatePlanItemDetailsList = planTemplatePlanItemObj.searchByPlanTemplateSubGoalID(
        planTemplateSubGoalKey);

      // For each associated plan item...
      for (int j = 0; j < templatePlanItemDetailsList.dtls.size(); j++) {

        PlanTemplatePlanItemKey planTemplatePlanItemKey = new PlanTemplatePlanItemKey();

        planTemplatePlanItemKey.planTemplatePlanItemID = templatePlanItemDetailsList.dtls.item(j).planTemplatePlanItemID;

        // Remove the plan item
        planTemplatePlanItemObj.remove(planTemplatePlanItemKey);

      }
      // Remove the sub-goal
      planTemplateSubGoalObj.remove(planTemplateSubGoalKey);
    }

  }

}
