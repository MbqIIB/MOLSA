/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.serviceplans.sl.entity.impl;


import curam.codetable.BASELINETYPE;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseStatusCode;
import curam.message.BPOBASELINE;
import curam.serviceplans.sl.entity.intf.BaselineSubGoal;
import curam.serviceplans.sl.entity.struct.BaseLineNameAndPlannedGoalKey;
import curam.serviceplans.sl.entity.struct.BaselineDtls;
import curam.serviceplans.sl.entity.struct.BaselineKey;
import curam.serviceplans.sl.entity.struct.BaselinePlanGroupKey;
import curam.serviceplans.sl.entity.struct.BaselinePlannedGroupPlanContentDtlsList;
import curam.serviceplans.sl.entity.struct.BaselineSubGoalByBaselineIDDetailsList;
import curam.serviceplans.sl.entity.struct.BaselineSubGoalKey;
import curam.serviceplans.sl.entity.struct.PlannedGoalKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;


/**
 * This class provides methods used to validate the insertion, modification
 * and canceling of baselines
 */
public abstract class Baseline extends curam.serviceplans.sl.entity.base.Baseline {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details Baseline details
   */
  protected void preinsert(BaselineDtls details)
    throws AppException, InformationalException {

    curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    PlannedGoalKey plannedGoalKey = new PlannedGoalKey();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // read case header and ensure not set to closed
    // Ensure service plan is not closed
    plannedGoalKey.plannedGoalID = details.plannedGoalID;
    caseHeaderKey.caseID = plannedGoalObj.read(plannedGoalKey).caseID;

    validateDetails(details);

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key Baseline identifier
   * @param details Baseline details
   */
  protected void premodify(BaselineKey key, BaselineDtls details)
    throws AppException, InformationalException {

    validateDetails(details);

    // Ensure that the baseline type is Manual
    if (!details.typeCode.equals(BASELINETYPE.MANUAL)) {

      // baseline type must be manual - only check if name is entered
      // if comments was entered - should be able to modify fine.
      if (details.name.length() != 0) {

        if (!details.name.equals(read(key).name)) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOBASELINE.ERR_SERPLAN_BASELINE_MODIFY_RV_TYPECODE_MUST_BE_MANUAL),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }
    }

    curam.serviceplans.sl.entity.intf.PlannedGoal plannedGoalObj = curam.serviceplans.sl.entity.fact.PlannedGoalFactory.newInstance();
    // The service plan must not be closed.
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    PlannedGoalKey plannedGoalKey = new PlannedGoalKey();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // set plannedGoalKey
    plannedGoalKey.plannedGoalID = details.plannedGoalID;

    // read case header and ensure not set to closed
    // Ensure service plan is not closed
    caseHeaderKey.caseID = plannedGoalObj.read(plannedGoalKey).caseID;
    CaseStatusCode caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // If closed than return error.
    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOBASELINE.ERR_SERPLAN_MODIFY_BASELINE_RV_SERPLAN_MUST_NOT_BE_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Validates Baseline details before insertion or modification
   *
   * @param details The details of the baseline
   */
  public void validateDetails(BaselineDtls details)
    throws AppException, InformationalException {

    // Ensure that the baseline name is unique
    BaselineDtls baselineDtls = new BaselineDtls();

    // trim empty spaces from both sides of the string
    details.name = details.name.trim();

    // Make sure that user has entered a name
    if (details.name.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOBASELINE.BASELINE_FV_NAME_MUST_BE_ENTERED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }    
     
    // set key - name and planned goal
    BaseLineNameAndPlannedGoalKey baseLineNameAndPlannedGoalKey = new BaseLineNameAndPlannedGoalKey();

    baseLineNameAndPlannedGoalKey.name = details.name;
    baseLineNameAndPlannedGoalKey.plannedGoalID = details.plannedGoalID;

    // read baselines by name for a specific planned goal
    try {
      baselineDtls = readByNameAndPlannedGoal(baseLineNameAndPlannedGoalKey);
      if (baselineDtls.baseLineID != details.baseLineID) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOBASELINE.ERR_BASELINE_FV_NAME_EXISTS),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    } catch (RecordNotFoundException e) {// ignore if exception found.
    }

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations and deletion of Baseline Sub-Goals before the data modification
   *
   * @param key Baseline identifier
   */
  protected void preremove(BaselineKey key)
    throws AppException, InformationalException {

    // Delete any baseline sub goal for this baseline
    BaselineSubGoal baselineSubGoal = curam.serviceplans.sl.entity.fact.BaselineSubGoalFactory.newInstance();

    // Delete any baseline plan group for this baseline
    curam.serviceplans.sl.entity.intf.BaselinePlanGroup baselinePlanGroup = curam.serviceplans.sl.entity.fact.BaselinePlanGroupFactory.newInstance();

    validateRemove(key);

    BaselineSubGoalByBaselineIDDetailsList baselineSubGoalByBaselineIDDetailsList = baselineSubGoal.searchSubGoalsByBaselineID(
      key);

    for (int i = 0; i < baselineSubGoalByBaselineIDDetailsList.dtls.size(); i++) {
      BaselineSubGoalKey baselineSubGoalKey = new BaselineSubGoalKey();

      baselineSubGoalKey.baselineSubGoalID = baselineSubGoalByBaselineIDDetailsList.dtls.item(i).baselineSubGoalID;
      baselineSubGoal.remove(baselineSubGoalKey);
    }
    
    // Delete any baseline plan groups for this baseline
    
    BaselinePlannedGroupPlanContentDtlsList baselinePlannedGroupPlanContentDtlsList = baselinePlanGroup.searchContentListDetailsByBaselineID(
      key);
    
    for (int i = 0; i < baselinePlannedGroupPlanContentDtlsList.dtls.size(); i++) {
      BaselinePlanGroupKey baselinePlanGroupKey = new BaselinePlanGroupKey();
      
      baselinePlanGroupKey.baselinePGID = baselinePlannedGroupPlanContentDtlsList.dtls.item(i).baselinePlannedGroupID;
      baselinePlanGroup.remove(baselinePlanGroupKey);      
    }
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations and deletion of Baseline Sub-Goals before the data modification
   *
   * @param key Baseline identifier
   */
  public void validateRemove(BaselineKey key)
    throws AppException, InformationalException {

    // The service plan must not be closed.
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // read case header and ensure not set to closed
    // Ensure service plan is not closed
    caseHeaderKey.caseID = readCaseIDByBaselineID(key).caseID;
    CaseStatusCode caseStatusCode = caseHeaderObj.readCaseStatus(caseHeaderKey);

    // If closed than return error.
    if (caseStatusCode.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOBASELINE.ERR_SERPLAN_DELETE_BASELINE_RV_SERPLAN_MUST_NOT_BE_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // check that type code is manual
    // Ensure that the baseline type is Manual
    if (!read(key).typeCode.equals(BASELINETYPE.MANUAL)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOBASELINE.ERR_SERPLAN_BASELINE_DELETE_RV_TYPECODE_MUST_BE_MANUAL),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }
}
