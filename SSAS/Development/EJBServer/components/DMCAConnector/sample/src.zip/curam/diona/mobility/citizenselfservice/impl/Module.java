/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package curam.diona.mobility.citizenselfservice.impl;

import com.google.inject.AbstractModule;
import com.google.inject.multibindings.Multibinder;
import curam.creoleprogramrecommendation.impl.AuthorizationEvent;
import curam.meetings.sl.impl.Meeting.MeetingEvents;

@SuppressWarnings("all")
public class Module extends AbstractModule {
		
	protected void configure() {
		
		/*
		* Listener for Application Case Authorization 
		*/
        /* commented out.
		Multibinder<AuthorizationEvent> authorizationEventListeners = Multibinder.newSetBinder(binder(), AuthorizationEvent.class);
		authorizationEventListeners.addBinding().to(AuthorizationEventListener.class);
        */
        /* commented out.
		Multibinder<MeetingEvents> meetingEventsListeners = Multibinder.newSetBinder(binder(), MeetingEvents.class);
		meetingEventsListeners.addBinding().to(MeetingEventsListener.class);
		*/
		
        /* commented out. 
		Multibinder<curam.core.sl.event.impl.PaymentInstrumentEvent> paymentEvent
	    = Multibinder.newSetBinder(binder(), 
	    		curam.core.sl.event.impl.PaymentInstrumentEvent.class);
		paymentEvent.addBinding().to(PaymentInstrumentEventListener.class);
        */
 		
	}

}
