/*
 * Copyright 2013-2014 Diona.
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you
 * entered into with Diona.
 */
package curam.diona.mobility.sembatchsync.codetableservice.impl;

import javax.xml.bind.JAXB;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;

import org.w3c.dom.Document;

import curam.diona.mobility.sembatchsync.codetableservice.struct.CodeTableDetails;
import curam.diona.mobility.sembatchsync.codetableservice.struct.CodeTableDetailsList;
import curam.diona.mobility.sembatchsync.codetableservice.struct.CodeTableServiceRequest;
import curam.diona.mobility.sembatchsync.codetableservice.struct.CodeTableServiceResponse;
import curam.diona.mobility.sembatchsync.codetableservice.struct.ObjectFactory;
import curam.diona.mobility.util.impl.DIMASConstants;
import curam.util.administration.fact.CodeTableAdminFactory;
import curam.util.administration.intf.CodeTableAdmin;
import curam.util.administration.struct.CodeTableAdminListAllItemsAndDefaultOut;
import curam.util.administration.struct.CodeTableHeaderDetails;
import curam.util.administration.struct.CodeTableItemDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public class CodeTableWS extends curam.diona.mobility.sembatchsync.codetableservice.base.CodeTableWS {

	/**
	 * This method retrieves all the codetable data.
	 * @param xmlMessage - Service Request
	 * @return Document
	 * @throws AppException
	 * @throws InformationalException
	 */
	public Document getAllCodeTables(Document xmlMessage)
	throws AppException, InformationalException {

		ObjectFactory objectFactory = new ObjectFactory();
		CodeTableAdmin codeTableAdminObj = CodeTableAdminFactory.newInstance();
		CodeTableServiceResponse codeTableServiceResponse = objectFactory.createCodeTableServiceResponse();
		for(CodeTableHeaderDetails codeTableHeaderDetails : codeTableAdminObj.listAllTables().dtls){
			if (!codeTableHeaderDetails.tableName.isEmpty()){
				CodeTableDetailsList codeTableDetailsList = getCodeTableDetails(codeTableHeaderDetails.tableName);
				codeTableServiceResponse.getCodeTableDetailsList().add(codeTableDetailsList);
			}
		}
		DOMResult result = new DOMResult();
		JAXB.marshal(codeTableServiceResponse, result);
		return (Document) result.getNode();	
	}

	@Override

	/**
	 * This method retrieves codetable data for a specific table
	 *  @param xmlMessage - Service request
	 *  @return Document
	 *  @throws AppException
	 *  @throws InformationalException
	 */
	public Document getCodeTableDataByTableName(Document xmlMessage)
	throws AppException, InformationalException {

		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
		ObjectFactory objectFactory = new ObjectFactory();
		CodeTableServiceRequest codeTableServiceRequest = JAXB.unmarshal(source, CodeTableServiceRequest.class);
		CodeTableServiceResponse codeTableServiceResponse = objectFactory.createCodeTableServiceResponse();
		if ((DIMASConstants.gSingle.equals(codeTableServiceRequest.getCodeTableRequest())) && (!codeTableServiceRequest.getCodeTableName().isEmpty())){
			CodeTableDetailsList codeTableDetailsList = getCodeTableDetails(codeTableServiceRequest.getCodeTableName());
			codeTableServiceResponse.getCodeTableDetailsList().add(codeTableDetailsList);
		}		
		DOMResult result = new DOMResult();
		JAXB.marshal(codeTableServiceResponse, result);

		return (Document) result.getNode();	
	}

	/**
	 * This method retrieves the codetable details for a given table name.
	 * 
	 * @param codeTableName
	 * @return  CodeTableDetailsList
	 * @throws AppException
	 * @throws InformationalException
	 */
	private CodeTableDetailsList getCodeTableDetails(String codeTableName) throws AppException, InformationalException{

		CodeTableAdmin codeTableAdminObj = CodeTableAdminFactory.newInstance();
		ObjectFactory objectFactory = new ObjectFactory();
		CodeTableDetailsList codeTableDetailsList = objectFactory.createCodeTableDetailsList();
		CodeTableDetails codeTableDetails = null;
		CodeTableAdminListAllItemsAndDefaultOut adminListAllItemsAndDefaultOut = codeTableAdminObj.listAllItems(codeTableName);
		for(CodeTableItemDetails codeTableItemDetails : adminListAllItemsAndDefaultOut.dtls.items()){
			if (!codeTableItemDetails.isEnabled)
				continue;
			codeTableDetails = objectFactory.createCodeTableDetails();
			codeTableDetails.setCode(codeTableItemDetails.code);
			codeTableDetails.setDescription(codeTableItemDetails.description);
			codeTableDetails.setLocaleIdentifier(codeTableItemDetails.locale);
			codeTableDetailsList.setTableName(codeTableName);
			codeTableDetailsList.getDetails().add(codeTableDetails);
		}
		return codeTableDetailsList;
	}

}
