/*
 * Copyright 2013-2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */

package curam.diona.mobility.citizenselfservice.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map.Entry;
import curam.util.events.impl.EventService;
import javax.xml.bind.JAXB;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import curam.codetable.DOCUMENTTYPE;
import curam.core.facade.fact.ConcernRoleAttachmentFactory;
import curam.core.facade.struct.ConcernRoleAttachmentDetails;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.type.Blob;
import curam.diona.mobility.citizenselfservice.struct.CitizenProofOfDocument;
import org.w3c.dom.Document;
import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.diona.mobility.citizenselfservice.sample.struct.CitizenAddressDetails;
import curam.citizenworkspace.security.impl.CitizenWorkspaceAccountInfo;
import curam.citizenworkspace.security.impl.CitizenWorkspaceAccountManager;
import curam.citizenworkspace.security.impl.CreateAccountDetails;
import curam.clientdiary.message.SCHEDULEDAPPOINTMENT;
import curam.codetable.ADDRESSELEMENTTYPE;
import curam.codetable.ADDRESSSTATE;
import curam.codetable.ADDRESSUSCOUNTY;
import curam.codetable.CONCERNROLEADDRESSTYPE;
import curam.codetable.EMAILTYPE;
import curam.codetable.FININSTRUCTIONSTATUS;
import curam.codetable.GENDER;
import curam.codetable.MONTH;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.PHONETYPE;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CASEGROUPTYPEEntry;
import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.FINCOMPONENTSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.REFERRALRELATEDROLETYPEEntry;
import curam.codetable.impl.SERVICEDELIVERYSTATUSEntry;
import curam.codetable.impl.SERVICEDELRELATEDTYPEEntry;
import curam.core.facade.fact.FinancialFactory;
import curam.core.facade.fact.IntegratedCaseFactory;
import curam.core.facade.fact.OrganizationFactory;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.intf.IntegratedCase;
import curam.core.facade.intf.Organization;
import curam.core.facade.intf.Participant;
import curam.core.facade.struct.ListICProductDeliveryClientRoleKey;
import curam.core.facade.struct.ListParticipantFinancials1;
import curam.core.facade.struct.ListParticipantFinancialsKey;
import curam.core.facade.struct.MaintainParticipantEmailAddressDetails;
import curam.core.facade.struct.MaintainParticipantPhoneDetails;
import curam.core.facade.struct.ParticipantFinancials1;
import curam.core.facade.struct.ReadOrganizationUserHomePageDetails;
import curam.core.facade.struct.ReadParticipantActiveAddressList;
import curam.core.facade.struct.ReadParticipantAddressListKey;
import curam.core.facade.struct.ReadParticipantEmailAddressDetails;
import curam.core.facade.struct.ReadParticipantEmailAddressKey;
import curam.core.facade.struct.ReadParticipantEmailAddressList;
import curam.core.facade.struct.ReadParticipantEmailAddressListKey;
import curam.core.facade.struct.ReadParticipantPhoneNumberDetails;
import curam.core.facade.struct.ReadParticipantPhoneNumberKey;
import curam.core.facade.struct.ReadParticipantPhoneNumberList;
import curam.core.facade.struct.ReadParticipantPhoneNumberListKey;
import curam.core.facade.struct.ReadPaymentInstructionDetails1;
import curam.core.facade.struct.ReadPaymentInstructionKey;
import curam.core.facade.struct.ReadPersonHomeDetails;
import curam.core.facade.struct.ReadPersonHomeKey;
import curam.core.facade.struct.ReadUserHomePageKey;
import curam.core.fact.AddressElementFactory;
import curam.core.fact.AddressFactory;
import curam.core.fact.AlternateNameFactory;
import curam.core.fact.CaseGroupsFactory;
import curam.core.fact.ConcernRoleAddressFactory;
import curam.core.fact.ConcernRoleEmailAddressFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.ConcernRolePhoneNumberFactory;
import curam.core.fact.EmailAddressFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.AlternateName;
import curam.core.intf.CaseGroups;
import curam.core.intf.ConcernRole;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.struct.CaseIDAndParticipantRoleIDKey;
import curam.core.sl.struct.CaseParticipantRoleIDStruct;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressElementDtlsList;
import curam.core.struct.AddressFieldDetails;
import curam.core.struct.AddressKey;
import curam.core.struct.AddressRMDtls;
import curam.core.struct.AlternateNameKey;
import curam.core.struct.CaseAndConcernRoleKey;
import curam.core.struct.CaseGroupsDtls;
import curam.core.struct.CaseGroupsDtlsList;
import curam.core.struct.CaseGroupsReadmultiKey;
import curam.core.struct.ConcernNameAddressDetails;
import curam.core.struct.ConcernRoleAddressDtls;
import curam.core.struct.ConcernRoleAddressKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleEmailAddressDtls;
import curam.core.struct.ConcernRoleEmailAddressKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.ConcernRolePhoneNumberKey;
import curam.core.struct.EmailAddressDtls;
import curam.core.struct.EmailAddressKey;
import curam.core.struct.EmailRMDtls;
import curam.core.struct.FinancialComponentDtls;
import curam.core.struct.FinancialComponentDtlsList;
import curam.core.struct.MaintainEmailKey;
import curam.core.struct.MaintainPhoneNumberKey;
import curam.core.struct.NameAddressReadKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PhoneRMDtls;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ReadMultiByConcernRoleIDPhoneResult;
import curam.cpm.facade.fact.ReferralFactory;
import curam.cpm.facade.intf.Referral;
import curam.cpm.facade.struct.ListReferralsKey;
import curam.cpm.facade.struct.ReadReferralDetails;
import curam.cpm.facade.struct.ReferralList;
import curam.cpm.facade.struct.ReferralListDetails;
import curam.cpm.sl.entity.struct.ProviderAndServiceKey;
import curam.cpm.sl.entity.struct.ProviderOfferingDtls;
import curam.cpm.sl.fact.ReferralRoleFactory;
import curam.cpm.sl.fact.ServiceDeliveryLinkFactory;
import curam.cpm.sl.intf.ServiceDeliveryLink;
import curam.cpm.sl.struct.ReferralRoleDtls;
import curam.cpm.sl.struct.ReferralRoleDtlsList;
import curam.cpm.sl.struct.SearchByServiceDeliveryRelatedTypeAndStatusKey;
import curam.cpm.sl.struct.ServiceDeliveryLinkDtls;
import curam.cpm.sl.struct.ServiceDeliveryLinkDtlsList;
import curam.cpm.util.impl.FrequencyPatternUtil;
import curam.cpm.util.impl.FrequencyPatternUtilImpl;
import curam.cpm.util.impl.ServiceDeliveryFacadeHelper;
import curam.diona.mobility.citizenselfservice.sample.struct.CitizenAddressKey;
import curam.diona.mobility.citizenselfservice.sample.struct.CitizenBasicInfo;
import curam.diona.mobility.citizenselfservice.sample.struct.CitizenDemographics;
import curam.diona.mobility.citizenselfservice.sample.struct.CitizenEmailData;
import curam.diona.mobility.citizenselfservice.sample.struct.CitizenPhoneData;
import curam.diona.mobility.citizenselfservice.sample.struct.CitizenPhoneNumberKey;
import curam.diona.mobility.citizenselfservice.sample.struct.CitizenProfileDetails;
import curam.diona.mobility.citizenselfservice.sample.struct.ConcernRoleDetails;
import curam.diona.mobility.citizenselfservice.sample.struct.ConcernRoleDetailsList;
import curam.diona.mobility.citizenselfservice.sample.struct.ConcernRoleEmailKey;
import curam.diona.mobility.citizenselfservice.sample.struct.ModifyCitizenAddressDetails;
import curam.diona.mobility.citizenselfservice.sample.struct.ModifyCitizenEmailDetails;
import curam.diona.mobility.citizenselfservice.sample.struct.ModifyContactInfo;
import curam.diona.mobility.citizenselfservice.sample.struct.ResponseCode;
import curam.diona.mobility.citizenselfservice.struct.CaseDetails;
import curam.diona.mobility.citizenselfservice.struct.CaseList;
import curam.diona.mobility.citizenselfservice.struct.CaseMember;
import curam.diona.mobility.citizenselfservice.struct.CitizenAddressInformation;
import curam.diona.mobility.citizenselfservice.struct.CitizenEmailAddress;
import curam.diona.mobility.citizenselfservice.struct.CitizenPhoneDetails;
import curam.diona.mobility.citizenselfservice.struct.ClientDetails;
import curam.diona.mobility.citizenselfservice.struct.ClientDetailsList;
import curam.diona.mobility.citizenselfservice.struct.ClientsCaseDetails;
import curam.diona.mobility.citizenselfservice.struct.ConcernRoleIDAndDateKey;
import curam.diona.mobility.citizenselfservice.struct.DashBoardCaseDetails;
import curam.diona.mobility.citizenselfservice.struct.DashBoardDetails;
import curam.diona.mobility.citizenselfservice.struct.DashBoardDetailsKey;
import curam.diona.mobility.citizenselfservice.struct.DashBoardPaymentDetails;
import curam.diona.mobility.citizenselfservice.struct.DashBoardServicesDetails;
import curam.diona.mobility.citizenselfservice.struct.ObjectFactory;
import curam.diona.mobility.citizenselfservice.struct.PaymentDetails;
import curam.diona.mobility.citizenselfservice.struct.PaymentList;
import curam.diona.mobility.citizenselfservice.struct.PersonBirthDayDetails;
import curam.diona.mobility.citizenselfservice.struct.ProviderDetails;
import curam.diona.mobility.citizenselfservice.struct.ProviderKey;
import curam.diona.mobility.citizenselfservice.struct.RecertificationDetails;
import curam.diona.mobility.citizenselfservice.struct.RecertificationDetailsKey;
import curam.diona.mobility.citizenselfservice.struct.ServiceDetails;
import curam.diona.mobility.citizenselfservice.struct.ServiceList;
import curam.diona.mobility.util.impl.DIMASConstants;
import curam.diona.mobility.util.impl.EnrichCodeTable;
import curam.intake.codetable.impl.LITEREFERRALSTATUSEntry;
import curam.intake.codetable.impl.LITEREFERRALTYPEEntry;
import curam.litereferral.entity.struct.LiteReferralConcernRoleID;
import curam.litereferral.facade.fact.LiteAgencyReferralFactory;
import curam.litereferral.facade.fact.LiteReferralFactory;
import curam.litereferral.facade.intf.LiteAgencyReferral;
import curam.litereferral.facade.intf.LiteReferral;
import curam.litereferral.facade.struct.LiteReferralDetails;
import curam.litereferral.facade.struct.LiteReferralDetailsList;
import curam.litereferral.impl.LiteAgencyReferralDAO;
import curam.litereferral.impl.LiteProviderReferralDAO;
import curam.message.GENERAL;
import curam.message.dmmessage.DMMESSAGE;
import curam.participant.impl.PhoneNumberDAO;
import curam.participantmessages.persistence.impl.ParticipantMessageDAO;
import curam.pdc.fact.PDCAddressFactory;
import curam.pdc.intf.PDCAddress;
import curam.pdc.struct.ParticipantAddressDetails;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.impl.AddressDAO;
import curam.piwrapper.impl.EmailAddress;
import curam.piwrapper.impl.EmailAddressDAO;
import curam.provider.impl.ProviderDAO;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.referral.impl.ReferralRoleDAO;
import curam.servicedelivery.impl.ServiceDelivery;
import curam.servicedelivery.impl.ServiceDeliveryDAO;
import curam.util.dataaccess.CuramValueList;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.DatabaseException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.FrequencyPattern;
import curam.util.type.FrequencyPattern.DayOfMonth;
import curam.util.type.FrequencyPattern.DayOfWeekMask;
import curam.util.type.FrequencyPattern.PatternType;
import curam.piwrapper.financialmanager.impl.InstructionLineItem;
import curam.piwrapper.financialmanager.impl.InstructionLineItemDAO;
import curam.piwrapper.financialmanager.impl.FinancialInstruction;
import curam.core.struct.FinInstructionID;
import curam.piwrapper.financialmanager.impl.FinancialInstruction;
import curam.piwrapper.financialmanager.impl.FinancialInstructionDAO;


/**
 * This class provides the operations to cater to Citizen Specific
 * functionalities.
 */
@SuppressWarnings("all")
public class CitizenSelfServiceWS implements
    curam.diona.mobility.citizenselfservice.intf.CitizenSelfServiceWS {

  @Inject
  private CitizenWorkspaceAccountManager citizenWorkspaceAccountManager;
    @Inject
    private InstructionLineItemDAO instructionLineItemDAO;

    @Inject
    private FinancialInstructionDAO financialInstructionDAO;

  @Inject
  private CaseHeaderDAO caseHeaderDAO;

  @Inject
  private ServiceDeliveryDAO serviceDeliveryDAO;

  @Inject
  ParticipantMessageDAO participantMessageDAO;

  @Inject
  private Provider<CreateAccountDetails> createAccountDetails;

  @Inject
  private LiteAgencyReferralDAO liteAgencyReferralDAO;

  @Inject
  private AddressDAO addressDAO;

  @Inject
  private EmailAddressDAO emailAddressDAO;

  @Inject
  private PhoneNumberDAO phoneNumberDAO;

  @Inject
  private LiteProviderReferralDAO liteProviderReferralDAO;

  @Inject
  private ProviderDAO providerDAO;

  @Inject
  protected Provider<ServiceDeliveryFacadeHelper> serviceDeliveryFacadeHelperProvider;

  @Inject
  protected ReferralRoleDAO referralRoleDAO;

  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  /**
   * Default Constructor
   */
  public CitizenSelfServiceWS() {
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Method returns citizen demographics information.
   * 
   * @param xmlMessage
   *          - no input parameter
   * @return domResult - includes citizen basic information,address,phone number
   *         and email details.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document viewCitizenPersonalDetails(Document xmlMessage)
      throws AppException, InformationalException {

    CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());
    Participant participant = ParticipantFactory.newInstance();
    ReadPersonHomeKey key = new ReadPersonHomeKey();
    key.concernRoleHomePageKey.concernRoleID = citizenWorkspaceAccountInfo
        .getConcernRole().getID();

    curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory sampleObjectFactory =
      new curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory();

    curam.core.intf.Address addressObj = curam.core.fact.AddressFactory
        .newInstance();
    ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();
    CitizenProfileDetails citizenProfileDetails = sampleObjectFactory
        .createCitizenProfileDetails();
    CitizenDemographics citizenDemographics = sampleObjectFactory
        .createCitizenDemographics();
    // Basic Information
    ReadPersonHomeDetails personDtls = curam.core.facade.fact.PersonFactory
        .newInstance().readHomePageDetails(key);
    CitizenBasicInfo citizenBasicInfo = sampleObjectFactory
        .createCitizenBasicInfo();
    citizenBasicInfo.setFirstName(personDtls.personHomeDetails.firstForename);
    citizenBasicInfo.setLastName(personDtls.personHomeDetails.surname);
    String personGender = EnrichCodeTable.enrichCodeTableValue(
        GENDER.TABLENAME, personDtls.personHomeDetails.sex);
    citizenBasicInfo.setGender(personGender);
    citizenBasicInfo.setGenderCode(personDtls.personHomeDetails.sex);
    XMLGregorianCalendar dateofBirth = getXMLGregCalDate(personDtls.personHomeDetails.dateOfBirth
        .getCalendar().getTime());
    citizenBasicInfo.setDateOfBirth(dateofBirth);
    citizenBasicInfo.setFullName(personDtls.personHomeDetails.fullName);
    citizenBasicInfo.setConcernRoleID(key.concernRoleHomePageKey.concernRoleID);
    citizenDemographics.setBasicInfo(citizenBasicInfo);

    // Person Address
    ReadParticipantAddressListKey listKey = new ReadParticipantAddressListKey();
    listKey.maintainAddressKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;
    ReadParticipantActiveAddressList activeAddressList = participant
        .listActiveAddresses(listKey);
    Date currDt = Date.getCurrentDate();
    for (AddressRMDtls addressRMDtls : activeAddressList.readActiveAddressesByConcernRoleResult.details.dtls) {
      if (addressRMDtls.endDate.isZero()
          || addressRMDtls.endDate.compareTo(currDt) >= 0) {
        curam.diona.mobility.citizenselfservice.sample.struct.CitizenAddressDetails citizenAddressDetails = 
          sampleObjectFactory.createCitizenAddressDetails();

        concernRoleAddressKey.concernRoleAddressID = addressRMDtls.concernRoleAddressID;
        readCitizenAddress(concernRoleAddressKey, citizenAddressDetails);
        citizenDemographics.getAddress().add(citizenAddressDetails);
      }

    }
    // Person Contact Number
    ReadParticipantPhoneNumberListKey numberListKey = new ReadParticipantPhoneNumberListKey();
    numberListKey.maintainPhoneNumberKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;
    ReadParticipantPhoneNumberList participantPhoneNumberList = participant
        .listPhoneNumber(numberListKey);
    for (PhoneRMDtls phoneRMDtls : participantPhoneNumberList.readMultiByConcernRoleIDPhoneResult.details.dtls) {
      if (!phoneRMDtls.statusCode.equals(RECORDSTATUSEntry.CANCELLED.getCode())
          && (phoneRMDtls.endDate.isZero() || phoneRMDtls.endDate
              .compareTo(currDt) >= 0)) {
        CitizenPhoneData citizenPhoneData = sampleObjectFactory
            .createCitizenPhoneData();
        populeCitizenPhoneData(phoneRMDtls, citizenPhoneData);
        citizenDemographics.getPhoneNumber().add(citizenPhoneData);
      }

    }
    // Person Email
    ReadParticipantEmailAddressListKey mailAddressKey = new ReadParticipantEmailAddressListKey();
    mailAddressKey.maintainEmailKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;
    ReadParticipantEmailAddressList emailAddressList = participant
        .listEmailAddress(mailAddressKey);
    for (EmailRMDtls emailRMDtls : emailAddressList.readMultiByConcernRoleEmailResult.details.dtls) {
      if (!emailRMDtls.statusCode.equals(RECORDSTATUSEntry.CANCELLED.getCode())
          && (emailRMDtls.endDate.isZero() || emailRMDtls.endDate
              .compareTo(currDt) >= 0)) {
        CitizenEmailData citizenEmailData = sampleObjectFactory
            .createCitizenEmailData();
        populateCitizenEmailData(emailRMDtls, citizenEmailData);
        citizenDemographics.getEmail().add(citizenEmailData);
      }

    }
    citizenProfileDetails.setDtls(citizenDemographics);
    return toDocument(citizenProfileDetails);
  }

  /**
   * Method populates citizen email details.
   * 
   * @param emailRMDtls
   *          - contains citizen email details.
   * @param citizenEmailData
   *          - instance of CitizenEmailData that will be populated from
   *          emailRMDtls.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   * @throws DatabaseException
   *           - Generic DatabaseException Signature.
   * @throws AppRuntimeException
   *           - Generic AppRuntimeException Signature.
   */
  private void populateCitizenEmailData(EmailRMDtls emailRMDtls,
      CitizenEmailData citizenEmailData) throws DatabaseException,
      AppRuntimeException, AppException, InformationalException {

    citizenEmailData
        .setConcernRoleEmailAddressId(emailRMDtls.concernRoleEmailAddressID);
    citizenEmailData.setEmailAddressID(emailRMDtls.emailAddressID);
    citizenEmailData.setPrimaryEmailInd(emailRMDtls.primaryInd);
    citizenEmailData.setEmailAddress(emailRMDtls.emailAddress);
    citizenEmailData.setEmailStartDate(getXMLGregCalDate(emailRMDtls.startDate
        .getCalendar().getTime()));
    if (!emailRMDtls.endDate.isZero()) {
      citizenEmailData.setEmailEndDate(getXMLGregCalDate(emailRMDtls.endDate
          .getCalendar().getTime()));
    }
    citizenEmailData.setEmailType(curam.util.type.CodeTable.getOneItem(
        EMAILTYPE.TABLENAME, emailRMDtls.typeCode));
    citizenEmailData.setEmailStatusCode(emailRMDtls.statusCode);
    citizenEmailData.setEmailTypeCode(emailRMDtls.typeCode);
    citizenEmailData
        .setConcernRoleEmailVersionNo(emailRMDtls.concernRoleEmailAddressVersionNo);
    citizenEmailData.setEmailVersion(emailRMDtls.emailAddressVersionNo);
  }

  /**
   * Method populates citizen phone details.
   * 
   * @param phoneRMDtls
   *          - contains citizen phone details.
   * @param citizenPhoneData
   *          - instance of populeCitizenPhoneData that will be populated from
   *          phoneRMDtls.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  private void populeCitizenPhoneData(PhoneRMDtls phoneRMDtls,
      CitizenPhoneData citizenPhoneData) throws AppException,
      InformationalException {
    citizenPhoneData
        .setConcernRolePhoneNumberID(phoneRMDtls.concernRolePhoneNumberID);
    citizenPhoneData.setPhoneNumberID(phoneRMDtls.phoneNumberID);
    citizenPhoneData.setPrimaryPhoneInd(phoneRMDtls.primaryInd);
    citizenPhoneData.setPhoneNumber(phoneRMDtls.phoneNumber);
    citizenPhoneData.setPhoneAreaCode(phoneRMDtls.phoneAreaCode);
    citizenPhoneData.setPhoneCountryCode(phoneRMDtls.phoneCountryCode);
    citizenPhoneData.setPhoneExtension(phoneRMDtls.phoneExtension);
    XMLGregorianCalendar phoneStartDate = getXMLGregCalDate(phoneRMDtls.startDate
        .getCalendar().getTime());
    citizenPhoneData.setPhoneStartDate(phoneStartDate);
    if (!phoneRMDtls.endDate.isZero()) {
      XMLGregorianCalendar phoneEndDate = getXMLGregCalDate(phoneRMDtls.endDate
          .getCalendar().getTime());
      citizenPhoneData.setPhoneEndDate(phoneEndDate);

    }
    citizenPhoneData.setPhoneStatusCode(phoneRMDtls.statusCode);
    citizenPhoneData.setPhoneTypeCode(phoneRMDtls.typeCode);
    String phoneType = EnrichCodeTable.enrichCodeTableValue(
        PHONETYPE.TABLENAME, phoneRMDtls.typeCode);
    citizenPhoneData.setPhoneType(phoneType);
    citizenPhoneData
        .setConcernRolePhoneVersionNo(phoneRMDtls.phoneNumberVersionNo);
    citizenPhoneData.setPhoneVersionNo(phoneRMDtls.phoneNumberVersionNo);

  }

  /**
   * Method updates phone details concerned to a citizen.
   * 
   * @param xmlMessage
   *          - contains an instance of ModifyContactInfo.
   * @return result - contains response code.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document updateCitizenContactInfoDetails(Document xmlMessage)
      throws AppException, InformationalException {

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    // input struct
    ModifyContactInfo modifyContactInfo = JAXB.unmarshal(source,
        ModifyContactInfo.class);
    // enactment struct
    CitizenPhoneDetails citizenPhoneDetails = new CitizenPhoneDetails();
    CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());

    MaintainPhoneNumberKey maintainPhoneNumberKey = new MaintainPhoneNumberKey();
    maintainPhoneNumberKey.concernRoleID = citizenWorkspaceAccountInfo
        .getConcernRole().getID();

    // assign phone details
    MaintainParticipantPhoneDetails maintainParticipantPhoneDetails = 
      new MaintainParticipantPhoneDetails();
    maintainParticipantPhoneDetails.concernRolePhoneDetails.concernRoleID = 
      maintainPhoneNumberKey.concernRoleID;
    citizenPhoneDetails.concernRoleID = maintainPhoneNumberKey.concernRoleID;

    ConcernRolePhoneNumberKey concernRolePhoneNumberKey = new ConcernRolePhoneNumberKey();
    concernRolePhoneNumberKey.concernRolePhoneNumberID = modifyContactInfo
        .getConcernRolePhoneId();
    ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls = ConcernRolePhoneNumberFactory
        .newInstance().read(concernRolePhoneNumberKey);

    maintainParticipantPhoneDetails.concernRolePhoneDetails.concernRolePhoneNumberID = 
      modifyContactInfo.getConcernRolePhoneId();
    citizenPhoneDetails.concernRolePhoneNumberID = modifyContactInfo
        .getConcernRolePhoneId();

    if (!modifyContactInfo.getPhoneAreaCode().equals(CuramConst.gkEmpty)) {
      maintainParticipantPhoneDetails.concernRolePhoneDetails.phoneAreaCode = modifyContactInfo
          .getPhoneAreaCode();
      citizenPhoneDetails.phoneAreaCode = modifyContactInfo.getPhoneAreaCode();
    }

    if (!modifyContactInfo.getPhoneCountryCode().equals(CuramConst.gkEmpty)) {
      maintainParticipantPhoneDetails.concernRolePhoneDetails.phoneCountryCode = modifyContactInfo
          .getPhoneCountryCode();
      citizenPhoneDetails.phoneCountryCode = modifyContactInfo
          .getPhoneCountryCode();
    }
    if (modifyContactInfo.getPhoneExtension() != null) {
      maintainParticipantPhoneDetails.concernRolePhoneDetails.phoneExtension = modifyContactInfo
          .getPhoneExtension();
      citizenPhoneDetails.phoneExtension = modifyContactInfo
          .getPhoneExtension();
    }
    if (!modifyContactInfo.getPhoneNumber().equals(CuramConst.gkEmpty)) {
      maintainParticipantPhoneDetails.concernRolePhoneDetails.phoneNumber = modifyContactInfo
          .getPhoneNumber();
      citizenPhoneDetails.phoneNumber = modifyContactInfo.getPhoneNumber();
    }

    maintainParticipantPhoneDetails.concernRolePhoneDetails.phoneNumberID = concernRolePhoneNumberDtls.phoneNumberID;
    citizenPhoneDetails.phoneNumberID = concernRolePhoneNumberDtls.phoneNumberID;

    maintainParticipantPhoneDetails.concernRolePhoneDetails.primaryPhoneInd = modifyContactInfo
        .isPrimaryPhoneInd();
    citizenPhoneDetails.primaryPhoneInd = modifyContactInfo.isPrimaryPhoneInd();

    maintainParticipantPhoneDetails.concernRolePhoneDetails.statusCode = RECORDSTATUS.NORMAL;
    citizenPhoneDetails.statusCode = RECORDSTATUS.NORMAL;

    maintainParticipantPhoneDetails.concernRolePhoneDetails.typeCode = modifyContactInfo
        .getTypeCode();
    citizenPhoneDetails.typeCode = modifyContactInfo.getTypeCode();

    if (modifyContactInfo.getStartDate() != null) {
      maintainParticipantPhoneDetails.concernRolePhoneDetails.startDate = new Date(
          modifyContactInfo.getStartDate().toGregorianCalendar());
      citizenPhoneDetails.startDate = maintainParticipantPhoneDetails.concernRolePhoneDetails.startDate;
    }
    if (modifyContactInfo.getEndDate() != null) {
      maintainParticipantPhoneDetails.concernRolePhoneDetails.endDate = new Date(
          modifyContactInfo.getEndDate().toGregorianCalendar());
      citizenPhoneDetails.endDate = maintainParticipantPhoneDetails.concernRolePhoneDetails.endDate;
    }

    if (!modifyContactInfo.getComments().equals(CuramConst.gkEmpty)) {
      maintainParticipantPhoneDetails.concernRolePhoneDetails.comments = modifyContactInfo
          .getComments();
      citizenPhoneDetails.comments = modifyContactInfo.getComments();
    }

    maintainParticipantPhoneDetails.concernRolePhoneDetails.versionNo = concernRolePhoneNumberDtls.versionNo;
    citizenPhoneDetails.concernRoleEmailVersionNo = concernRolePhoneNumberDtls.versionNo;

    curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory
        .newInstance();
    curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory sampleObjectFactory = 
      new curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory();
    ResponseCode responseCode = sampleObjectFactory.createResponseCode();
    if (!modifyContactInfo.isDeferredProcessingInd()) {
      try {
        // modify phone details
        maintainConcernRolePhoneObj.modifyPhoneNumber(maintainPhoneNumberKey,
            maintainParticipantPhoneDetails.concernRolePhoneDetails);
        responseCode.setResponseCode(123456789L);
      } catch (Exception e) {
        e.printStackTrace();
        responseCode.setResponseCode(987654321L);
      }
    } else {
      // enact workflow
      citizenPhoneDetails.typeDesc = curam.util.type.CodeTable.getOneItem(
          PHONETYPE.TABLENAME, citizenPhoneDetails.typeCode);
      citizenPhoneDetails.completePhoneNo = citizenPhoneDetails.phoneCountryCode
          + DIMASConstants.kSpace
          + citizenPhoneDetails.phoneAreaCode
          + DIMASConstants.kSpace
          + citizenPhoneDetails.phoneNumber
          + DIMASConstants.kSpace + citizenPhoneDetails.phoneExtension;
      final List<CitizenPhoneDetails> enactmentStruct = new ArrayList<CitizenPhoneDetails>();
      enactmentStruct.add(citizenPhoneDetails);
      curam.util.workflow.impl.EnactmentService.startProcess(
          DMConstant.kDMCitizenPhoneDetailsUpdates, enactmentStruct);
    }

    return toDocument(responseCode);
  }

  /**
   * Method returns citizen address details.
   * 
   * @param xmlMessage
   *          - holds concernRoleAddressID.
   * @return domResult - holds address information.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document viewCitizenAddressInfoDetails(Document xmlMessage)
      throws AppException, InformationalException {
    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    CitizenAddressKey citizenAddressKey = JAXB.unmarshal(source,
        CitizenAddressKey.class);
    DOMResult domResult = new DOMResult();
    curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory sampleObjectFactory = 
      new curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory();
    CitizenAddressDetails citizenAddressDetails = sampleObjectFactory
        .createCitizenAddressDetails();
    ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();
    concernRoleAddressKey.concernRoleAddressID = citizenAddressKey
        .getConcernRoleAddressID();
    readCitizenAddress(concernRoleAddressKey, citizenAddressDetails);
    return toDocument(citizenAddressDetails);
  }

  /**
   * Method reads citizen address details.
   * 
   * @param concernRoleAddressKey
   *          - holds concernRoleAddressID.
   * @param citizenAddressDetails
   *          - holds address details.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */

  private void readCitizenAddress(ConcernRoleAddressKey concernRoleAddressKey,
      CitizenAddressDetails citizenAddressDetails) throws AppException,
      InformationalException {

    ParticipantEvidenceInterface concernRoleAddressObj = (ParticipantEvidenceInterface) ConcernRoleAddressFactory
        .newInstance();
    EIEvidenceKey evidenceKey = new EIEvidenceKey();
    evidenceKey.evidenceID = concernRoleAddressKey.concernRoleAddressID;
    // read participant evidence
    ConcernRoleAddressDtls concernRoleAddressDtls = (ConcernRoleAddressDtls) concernRoleAddressObj
        .readEvidence(evidenceKey);

    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory
        .newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    concernRoleKey.concernRoleID = concernRoleAddressDtls.concernRoleID;
    // Read ConcernRole details
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey);
    if (concernRoleAddressDtls.addressID == concernRoleDtls.primaryAddressID) {
      citizenAddressDetails.setIsPrimary(true);
    } else {
      citizenAddressDetails.setIsPrimary(false);
    }
    citizenAddressDetails.setAddressID(concernRoleAddressDtls.addressID);
    citizenAddressDetails
        .setConcernRoleAddressID(concernRoleAddressDtls.concernRoleAddressID);
    citizenAddressDetails
        .setFromDate(getXMLGregCalDate(concernRoleAddressDtls.startDate
            .getCalendar().getTime()));
    if (!concernRoleAddressDtls.endDate.isZero()) {
      citizenAddressDetails
          .setToDate(getXMLGregCalDate(concernRoleAddressDtls.endDate
              .getCalendar().getTime()));
    }
    citizenAddressDetails.setTypeCode(concernRoleAddressDtls.typeCode);
    citizenAddressDetails.setType(curam.util.type.CodeTable.getOneItem(
        CONCERNROLEADDRESSTYPE.TABLENAME, concernRoleAddressDtls.typeCode));
    /*
    // Read Address Elements
    AddressKey addressKey = new AddressKey();
    addressKey.addressID = concernRoleAddressDtls.addressID;
    AddressElementDtlsList addressElementDtlsList = AddressElementFactory
        .newInstance().readAddressElementDetails(addressKey);

    for (int i = 0; i < addressElementDtlsList.dtls.size(); i++) {
      if (addressElementDtlsList.dtls.item(i).elementType
          .equals(ADDRESSELEMENTTYPE.LINE1)) {
        citizenAddressDetails
            .setApartment(addressElementDtlsList.dtls.item(i).elementValue);
      } else if (addressElementDtlsList.dtls.item(i).elementType
          .equals(ADDRESSELEMENTTYPE.LINE2)) {
        citizenAddressDetails
            .setStreet1(addressElementDtlsList.dtls.item(i).elementValue);
      } else if (addressElementDtlsList.dtls.item(i).elementType
          .equals(ADDRESSELEMENTTYPE.LINE3)) {
        citizenAddressDetails
            .setStreet2(addressElementDtlsList.dtls.item(i).elementValue);
      } else if (addressElementDtlsList.dtls.item(i).elementType
          .equals(ADDRESSELEMENTTYPE.CITY)) {
        citizenAddressDetails
            .setCity(addressElementDtlsList.dtls.item(i).elementValue);
      } else if (addressElementDtlsList.dtls.item(i).elementType
          .equals(ADDRESSELEMENTTYPE.STATE)) {
        citizenAddressDetails
            .setStateCode(addressElementDtlsList.dtls.item(i).elementValue);
        citizenAddressDetails.setState(curam.util.type.CodeTable.getOneItem(
            ADDRESSSTATE.TABLENAME,
            addressElementDtlsList.dtls.item(i).elementValue));
      } else if (addressElementDtlsList.dtls.item(i).elementType
          .equals(ADDRESSELEMENTTYPE.USCOUNTY)) {
        citizenAddressDetails
            .setCountyCode(addressElementDtlsList.dtls.item(i).elementValue);
        citizenAddressDetails.setCounty(curam.util.type.CodeTable.getOneItem(
            ADDRESSUSCOUNTY.TABLENAME,
            addressElementDtlsList.dtls.item(i).elementValue));
      } else if (addressElementDtlsList.dtls.item(i).elementType
          .equals(ADDRESSELEMENTTYPE.ZIP)) {
        citizenAddressDetails
            .setZip(addressElementDtlsList.dtls.item(i).elementValue);
      }
    }
    citizenAddressDetails.setStatusCode(concernRoleAddressDtls.statusCode);
    citizenAddressDetails.setComments(concernRoleAddressDtls.comments);
    citizenAddressDetails
        .setConcernRoleAddressVersion(concernRoleAddressDtls.versionNo);*/
	curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls displayDtls = concernRoleAddressObj.getDetailsForListDisplay(evidenceKey);
	citizenAddressDetails
        .setFromDate(getXMLGregCalDate(displayDtls.startDate
            .getCalendar().getTime()));
    if (!displayDtls.endDate.isZero()) {
      citizenAddressDetails
          .setToDate(getXMLGregCalDate(displayDtls.endDate
              .getCalendar().getTime()));
    }
	citizenAddressDetails.setApartment(displayDtls.summary);
  }

  /**
   * This method returns a list of Payments Received by a Citizen.
   * 
   * @param Document
   * @return Document
   * @throws AppException
   * @throws InformationalException
   */
  public Document listCitizenPayments(Document xmlMessage) throws AppException,
      InformationalException {

    CitizenWorkspaceAccountInfo cwAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());

    ObjectFactory fact = new ObjectFactory();
    PaymentList paymentDetailsList = fact.createPaymentList();

    // Issued Payments
    ListParticipantFinancialsKey key = new ListParticipantFinancialsKey();
    key.concernRoleID = cwAccountInfo.getConcernRole().getID();

    ListParticipantFinancials1 listParticipantFinancials1 = ParticipantFactory
        .newInstance().listParticipantFinancial1(key);

    for (ParticipantFinancials1 participantFin : listParticipantFinancials1.participantFinancialsList.dtls) {
      if (participantFin.statusCode.equals(FININSTRUCTIONSTATUS.ISSUED)) {

        PaymentDetails paymentDetails = fact.createPaymentDetails();
        paymentDetails.setAmount(roundToDecimals(participantFin.amount
            .getValue()));
        XMLGregorianCalendar paymentDate = getXMLGregCalDate(participantFin.effectiveDate
            .getCalendar().getTime());
        paymentDetails.setPaymentDate(paymentDate);
        String currencyType = EnrichCodeTable.enrichCodeTableValue("Currency",
            participantFin.currencyType);

        // Read PaymentInstruction Details
        ReadPaymentInstructionKey paymentInstructionKey = new ReadPaymentInstructionKey();
        paymentInstructionKey.finInstructionID = participantFin.finInstructionID;

        StringBuilder programName = new StringBuilder();
        try {
            FinInstructionID finInstructionID = new FinInstructionID();
            finInstructionID.finInstructionID = participantFin.finInstructionID;
            List<InstructionLineItem> instructionLineItemList = 
                    instructionLineItemDAO.searchByFinancialInstruction(
                    (FinancialInstruction)financialInstructionDAO.get(
                    Long.valueOf(finInstructionID.finInstructionID)));
            for (InstructionLineItem lineItem : instructionLineItemList ) {
                
                long caseID = lineItem.getCaseId();
                ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
                productDeliveryKey.caseID = caseID;
                ProductDeliveryDtls productDelDtls = curam.core.fact.ProductDeliveryFactory
                    .newInstance().read(productDeliveryKey);
                String caseDesc = curam.util.type.CodeTable.getOneItem(
                        PRODUCTTYPE.TABLENAME, (productDelDtls.productType));
                programName.append(caseDesc + ", ");
                
    
            }
            if (programName.length() > 0) {
                programName.setLength(programName.length() - 2);
            }
            paymentDetails.setProgramName(programName.toString());
        } catch (Throwable e) {
            e.printStackTrace();
            throw new RuntimeException(e);
            
        }
        
        paymentDetails.setCurrencySymbol(Configuration
            .getProperty(EnvVars.ENV_CURRENCY_SYMBOL));
        paymentDetails.setPrimaryKey(paymentInstructionKey.finInstructionID);

        paymentDetailsList.getDtls().add(paymentDetails);
      }
    }
    return toDocument(paymentDetailsList);

  }

  /**
   * Method returns citizen contacts details.
   * 
   * @param xmlMessage
   *          - holds concernRolePhoneNumberID.
   * @return domResult - holds contact information.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document viewCitizenContactDetails(Document xmlMessage)
      throws AppException, InformationalException {

    CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());
    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    CitizenPhoneNumberKey citizenPhoneNumberKey = JAXB.unmarshal(source,
        CitizenPhoneNumberKey.class);

    curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory sampleObjectFactory = 
      new curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory();

    CitizenPhoneData citizenPhoneData = sampleObjectFactory
        .createCitizenPhoneData();
    ReadParticipantPhoneNumberKey numberKey = new ReadParticipantPhoneNumberKey();
    numberKey.readConcernRolePhoneKey.concernRolePhoneNumberID = citizenPhoneNumberKey
        .getConcernRolePhoneNumberID();

    // Read Phone Number
    ReadParticipantPhoneNumberDetails numberDetails = ParticipantFactory
        .newInstance().readPhoneNumber(numberKey);
    citizenPhoneData
        .setConcernRolePhoneNumberID(numberDetails.concernRolePhoneDetails.concernRolePhoneNumberID);
    citizenPhoneData
        .setPhoneNumberID(numberDetails.concernRolePhoneDetails.phoneNumberID);
    citizenPhoneData
        .setPrimaryPhoneInd(numberDetails.concernRolePhoneDetails.primaryPhoneInd);
    citizenPhoneData
        .setPhoneNumber(numberDetails.concernRolePhoneDetails.phoneNumber);
    citizenPhoneData
        .setPhoneAreaCode(numberDetails.concernRolePhoneDetails.phoneAreaCode);
    citizenPhoneData
        .setPhoneCountryCode(numberDetails.concernRolePhoneDetails.phoneCountryCode);
    citizenPhoneData
        .setPhoneExtension(numberDetails.concernRolePhoneDetails.phoneExtension);
    XMLGregorianCalendar phoneStartDate = getXMLGregCalDate(numberDetails.concernRolePhoneDetails.startDate
        .getCalendar().getTime());
    citizenPhoneData.setPhoneStartDate(phoneStartDate);
    if (!numberDetails.concernRolePhoneDetails.endDate.isZero()) {
      XMLGregorianCalendar phoneEndDate = getXMLGregCalDate(numberDetails.concernRolePhoneDetails.endDate
          .getCalendar().getTime());
      citizenPhoneData.setPhoneEndDate(phoneEndDate);

    }
    citizenPhoneData
        .setPhoneTypeCode(numberDetails.concernRolePhoneDetails.typeCode);
    String phoneType = EnrichCodeTable.enrichCodeTableValue(
        PHONETYPE.TABLENAME, numberDetails.concernRolePhoneDetails.typeCode);
    citizenPhoneData.setPhoneType(phoneType);
    citizenPhoneData
        .setComments(numberDetails.concernRolePhoneDetails.comments);
    citizenPhoneData
        .setConcernRolePhoneVersionNo(numberDetails.concernRolePhoneDetails.versionNo);
    citizenPhoneData
        .setPhoneStatusCode(numberDetails.concernRolePhoneDetails.statusCode);

    return toDocument(citizenPhoneData);
  }

  /**
   * Method returns citizen email details.
   * 
   * @param xmlMessage
   *          - holds concernRoleEmailAddressID.
   * @return domResult - holds email details.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document viewCitizenEmailAddress(Document xmlMessage)
      throws AppException, InformationalException {

    CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());
    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    ConcernRoleEmailKey concernRoleEmailKey = JAXB.unmarshal(source,
        ConcernRoleEmailKey.class);

    curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory sampleObjectFactory = 
      new curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory();

    CitizenEmailData citizenEmailData = sampleObjectFactory
        .createCitizenEmailData();
    ReadParticipantEmailAddressKey emailAddressKey = new ReadParticipantEmailAddressKey();
    emailAddressKey.readConcernRoleEmailKey.concernRoleEmailAddressID = concernRoleEmailKey
        .getConcernRoleEmailID();
    ReadParticipantEmailAddressDetails emailAddressDetails = ParticipantFactory
        .newInstance().readEmailAddress(emailAddressKey);
    citizenEmailData
        .setConcernRoleEmailAddressId(emailAddressDetails.concernRoleEmailDetails.concernRoleEmailAddressID);
    citizenEmailData
        .setEmailAddressID(emailAddressDetails.concernRoleEmailDetails.emailAddressID);
    citizenEmailData
        .setEmailAddress(emailAddressDetails.concernRoleEmailDetails.emailAddress);
    citizenEmailData
        .setEmailStartDate(getXMLGregCalDate(emailAddressDetails.concernRoleEmailDetails.startDate
            .getCalendar().getTime()));
    if (!emailAddressDetails.concernRoleEmailDetails.endDate.isZero()) {
      citizenEmailData
          .setEmailEndDate(getXMLGregCalDate(emailAddressDetails.concernRoleEmailDetails.endDate
              .getCalendar().getTime()));
    }
    citizenEmailData
        .setPrimaryEmailInd(emailAddressDetails.concernRoleEmailDetails.primaryEmailInd);
    citizenEmailData.setEmailType(curam.util.type.CodeTable.getOneItem(
        EMAILTYPE.TABLENAME,
        emailAddressDetails.concernRoleEmailDetails.typeCode));
    citizenEmailData
        .setEmailTypeCode(emailAddressDetails.concernRoleEmailDetails.typeCode);
    citizenEmailData
        .setConcernRoleEmailVersionNo(emailAddressDetails.concernRoleEmailDetails.versionNo);
    citizenEmailData
        .setComments(emailAddressDetails.concernRoleEmailDetails.comments);
    citizenEmailData
        .setEmailStatusCode(emailAddressDetails.concernRoleEmailDetails.statusCode);
    return toDocument(citizenEmailData);
  }

  /**
   * Method updates address details concerned to a citizen.
   * 
   * @param xmlMessage
   *          - contains an instance of ModifyCitizenAddressDetails.
   * @return result - contains response code.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document updateCitizenAddress(Document xmlMessage)
      throws AppException, InformationalException {

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    // input struct
    ModifyCitizenAddressDetails modifyAddressDetails = JAXB.unmarshal(source,
        ModifyCitizenAddressDetails.class);
    CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());
    // enactment struct
    CitizenAddressInformation citizenAddressInformation = new CitizenAddressInformation();

    curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory sampleObjectFactory = 
      new curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory();

    PDCAddress pdcAddress = PDCAddressFactory.newInstance();
    ParticipantAddressDetails participantaddressdetails = new ParticipantAddressDetails();
    participantaddressdetails.concernRoleID = citizenWorkspaceAccountInfo
        .getConcernRole().getID();

    curam.core.intf.AddressData addressDataObj = curam.core.fact.AddressDataFactory
        .newInstance();

    ConcernRoleAddressKey concernRoleAddressKey = new ConcernRoleAddressKey();
    concernRoleAddressKey.concernRoleAddressID = modifyAddressDetails
        .getConcernRoleAddressID();
    ConcernRoleAddressDtls concernRoleAddressDtls = ConcernRoleAddressFactory
        .newInstance().read(concernRoleAddressKey);

    AddressFieldDetails addressfielddetails = new AddressFieldDetails();
    addressfielddetails.addressID = concernRoleAddressDtls.addressID;
    citizenAddressInformation.addressID = concernRoleAddressDtls.addressID;
    citizenAddressInformation.concernRoleID = participantaddressdetails.concernRoleID;

    AddressKey addressKey = new AddressKey();
    addressKey.addressID = addressfielddetails.addressID;
    AddressDtls addressDtls = AddressFactory.newInstance().read(addressKey);
    addressfielddetails.addressLayoutType = addressDtls.addressLayoutType;

    if (null != addressDtls.countryCode) {
      // TODO ideally struct assign should be used based on
      // MaintainConcernRoleAddress.modify
      addressfielddetails.countryCode = addressDtls.countryCode;

    }

    if (null != modifyAddressDetails.getApartment()) {
      addressfielddetails.addressLine1 = modifyAddressDetails.getApartment();
      citizenAddressInformation.apartment = modifyAddressDetails.getApartment();

    }
    if (null != modifyAddressDetails.getStreet1()) {
      addressfielddetails.addressLine2 = modifyAddressDetails.getStreet1();
      citizenAddressInformation.street1 = modifyAddressDetails.getStreet1();
    }
    if (null != modifyAddressDetails.getStreet2()) {
      addressfielddetails.addressLine3 = modifyAddressDetails.getStreet2();
      citizenAddressInformation.street2 = modifyAddressDetails.getStreet2();
    }
    if (null != modifyAddressDetails.getCity()) {
      addressfielddetails.city = modifyAddressDetails.getCity();
      citizenAddressInformation.city = modifyAddressDetails.getCity();
    }
    if (null != modifyAddressDetails.getState()) {
      addressfielddetails.stateCode = modifyAddressDetails.getState();
      citizenAddressInformation.state = modifyAddressDetails.getState();
    }
    if (null != modifyAddressDetails.getZip()) {
      addressfielddetails.zipCode = modifyAddressDetails.getZip();
      citizenAddressInformation.zip = modifyAddressDetails.getZip();
    }
    if (null != modifyAddressDetails.getCounty()) {
      addressfielddetails.usCountyCode = modifyAddressDetails.getCounty();
      citizenAddressInformation.county = modifyAddressDetails.getCounty();
    }
    OtherAddressData otherAddressData = addressDataObj
        .parseFieldsToData(addressfielddetails);

    participantaddressdetails.addressData = otherAddressData.addressData;
    if (null != modifyAddressDetails.getTypeCode()) {
      participantaddressdetails.typeCode = modifyAddressDetails.getTypeCode();
      citizenAddressInformation.typeCode = modifyAddressDetails.getTypeCode();
    }
    participantaddressdetails.statusCode = RECORDSTATUS.NORMAL;
    citizenAddressInformation.statusCode = RECORDSTATUS.NORMAL;

    participantaddressdetails.primaryAddressInd = modifyAddressDetails
        .isPrimaryAddressInd();
    citizenAddressInformation.primaryAddressInd = modifyAddressDetails
        .isPrimaryAddressInd();

    participantaddressdetails.concernRoleAddressID = modifyAddressDetails
        .getConcernRoleAddressID();
    citizenAddressInformation.concernRoleAddressID = modifyAddressDetails
        .getConcernRoleAddressID();

    participantaddressdetails.concernRoleAddressVersionNo = concernRoleAddressDtls.versionNo;
    citizenAddressInformation.concernRoleAddressVersionNo = concernRoleAddressDtls.versionNo;
    if (modifyAddressDetails.getAddressStartDate() != null) {
      participantaddressdetails.startDate = new Date(modifyAddressDetails
          .getAddressStartDate().toGregorianCalendar());
      citizenAddressInformation.startDate = participantaddressdetails.startDate;

    }
    if (modifyAddressDetails.getAddressEndDate() != null) {
      participantaddressdetails.endDate = new Date(modifyAddressDetails
          .getAddressEndDate().toGregorianCalendar());
      citizenAddressInformation.endDate = participantaddressdetails.endDate;
    }
    if (!modifyAddressDetails.getComments().equals(CuramConst.gkEmpty)) {
      participantaddressdetails.comments = modifyAddressDetails.getComments();
      citizenAddressInformation.comments = modifyAddressDetails.getComments();
    }

    ResponseCode responseCode = sampleObjectFactory.createResponseCode();

    if (!modifyAddressDetails.isDeferredProcessingInd()) {
      try {
        // modify address
        pdcAddress.modify(participantaddressdetails);
        responseCode.setResponseCode(123456789L);
      } catch (Exception e) {
        e.printStackTrace();
        responseCode.setResponseCode(987654321L);
      }
    } else {
      // enact workflow
      AddressFactory.newInstance().getOneLineAddressString(otherAddressData);
      citizenAddressInformation.addressData = otherAddressData.addressData;
      citizenAddressInformation.typeDesc = curam.util.type.CodeTable
          .getOneItem(CONCERNROLEADDRESSTYPE.TABLENAME,
              citizenAddressInformation.typeCode);
      final List<CitizenAddressInformation> enactmentStruct = new ArrayList<CitizenAddressInformation>();
      enactmentStruct.add(citizenAddressInformation);
      curam.util.workflow.impl.EnactmentService.startProcess(
          DMConstant.kDMCitizenAddressDetailsUpdates, enactmentStruct);
    }

    return toDocument(responseCode);

  }

  /**
   * Method reads services availed by the Citizen.
   * 
   * @param xmlMessage
   *          - contains providerID,serviceOfeeringID.
   * @return result - provider details.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document viewProviderDetails(Document xmlMessage) throws AppException,
      InformationalException {

    ObjectFactory fact = new ObjectFactory();
    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    ProviderKey providerKey = JAXB.unmarshal(source, ProviderKey.class);
    ProviderDetails providerDetails = fact.createProviderDetails();
    ProviderAndServiceKey providerAndServiceKey = new ProviderAndServiceKey();

    // Read Provider Details
    providerAndServiceKey.providerID = providerKey.getProviderID();
    providerDetails.setGeneralInformation(providerDAO.get(
        providerKey.getProviderID()).getClientInfo().getValue());
    if (providerKey.getServiceOfferingID() != 0) {
      StringBuilder sqlBuilder = new StringBuilder();
      sqlBuilder.append(" SELECT PROVIDEROFFERINGID FROM PROVIDEROFFERING ");
      sqlBuilder.append(" INTO :providerOfferingID");
      sqlBuilder
          .append(" WHERE PROVIDERCONCERNROLEID=:providerID AND SERVICEOFFERINGID=:serviceID ");
      // Read Provider Offering Details
      providerAndServiceKey.serviceID = providerKey.getServiceOfferingID();
      try {
        ProviderOfferingDtls offeringDtls = (ProviderOfferingDtls) curam.util.dataaccess.DynamicDataAccess
            .executeNs(ProviderOfferingDtls.class, providerAndServiceKey,
                false, sqlBuilder.toString());
        Long providerOfferingID = offeringDtls.providerOfferingID;
        curam.providerservice.impl.ProviderOffering providerOfferingObj = providerOfferingDAO
            .get(providerOfferingID);
        if (providerOfferingObj.getDocumentsRequiredInfo() != null) {
          providerDetails.setRequiredDocuments(providerOfferingObj
              .getDocumentsRequiredInfo().getValue());
        } else {
          providerDetails.setRequiredDocuments(CuramConst.gkEmpty);

        }
        if (providerOfferingObj.getClientFeeInfo() != null) {
          providerDetails.setFeesInformation(providerOfferingObj
              .getClientFeeInfo().getValue());
        } else {
          providerDetails.setFeesInformation(CuramConst.gkEmpty);
        }

        try {
          curam.provider.impl.Provider providerObj = providerOfferingObj
              .getProvider();
          EmailAddress emailAddr = providerObj.getEmailAddress();
          if (emailAddr != null) {
            providerDetails.setProviderEmailAddress(emailAddr.getEmail());
          } else {
            providerDetails.setProviderEmailAddress(CuramConst.gkEmpty);
          }
        } catch (RecordNotFoundException re) {
          providerDetails.setProviderEmailAddress(CuramConst.gkEmpty);
        }

        try {
          curam.provider.impl.Provider providerObj = providerOfferingObj
              .getProvider();
          curam.participant.impl.PhoneNumber phoneObj = providerObj
              .getPrimaryPhoneNumber();
          if (phoneObj != null) {
            providerDetails.setProviderPhoneNumber(phoneObj.getCountryCode()
                + phoneObj.getAreaCode() + phoneObj.getNumber()
                + phoneObj.getExtension());
          } else {
            providerDetails.setProviderPhoneNumber(CuramConst.gkEmpty);
          }

        } catch (RecordNotFoundException re) {
          providerDetails.setProviderPhoneNumber(CuramConst.gkEmpty);
        } catch (NullPointerException re) {
          providerDetails.setProviderPhoneNumber(CuramConst.gkEmpty);
        }

        try {
          curam.provider.impl.Provider providerObj = providerOfferingObj
              .getProvider();
          curam.piwrapper.impl.Address addrObj = providerObj
              .getPrimaryAddress();
          if (addrObj.getOneLineAddressString() != null) {
            providerDetails.setProviderAddress(addrObj
                .getOneLineAddressString());
          } else {
            providerDetails.setProviderAddress(CuramConst.gkEmpty);
          }
          providerDetails.setProviderLatitude(addrObj.getLatitude());
          providerDetails.setProviderLongitude(addrObj.getLongitude());
        } catch (RecordNotFoundException re) {
          providerDetails.setProviderAddress(CuramConst.gkEmpty);
          providerDetails.setProviderLongitude(0.0);
          providerDetails.setProviderLatitude(0.0);
        } catch (NullPointerException re) {
          providerDetails.setProviderAddress(CuramConst.gkEmpty);
          providerDetails.setProviderLongitude(0.0);
          providerDetails.setProviderLatitude(0.0);
        }

        try {

          MaintainPhoneNumberKey arg0 = new MaintainPhoneNumberKey();
          arg0.concernRoleID = providerKey.getProviderID();

          curam.core.intf.MaintainConcernRolePhone maintainConcernRolePhoneObj = curam.core.fact.MaintainConcernRolePhoneFactory
              .newInstance();

          ReadMultiByConcernRoleIDPhoneResult res = maintainConcernRolePhoneObj
              .readmultiByConcernRole(arg0);
          String mobileType = curam.codetable.PHONETYPE.MOBILE;
          Date currDt = Date.getCurrentDate();
          for (PhoneRMDtls phoneRMDtls : res.details.dtls) {
            if (!phoneRMDtls.statusCode.equals(RECORDSTATUSEntry.CANCELLED
                .getCode())
                && (phoneRMDtls.endDate.isZero() || phoneRMDtls.endDate
                    .compareTo(currDt) >= 0)) {

              if (mobileType.equals(phoneRMDtls.typeCode)) {
                providerDetails
                    .setProviderMobileNumber(phoneRMDtls.phoneCountryCode
                        + phoneRMDtls.phoneAreaCode + phoneRMDtls.phoneNumber

                    );
                if (phoneRMDtls.primaryInd) {
                  break;
                }
              }
            }
          }
        } catch (RecordNotFoundException ee) {
          providerDetails.setProviderMobileNumber(CuramConst.gkEmpty);
        }

      } catch (RecordNotFoundException re) {
        providerDetails.setRequiredDocuments(CuramConst.gkEmpty);
        providerDetails.setFeesInformation(CuramConst.gkEmpty);
      }

    } else {
      providerDetails.setRequiredDocuments(CuramConst.gkEmpty);
      providerDetails.setFeesInformation(CuramConst.gkEmpty);
    }

    return toDocument(providerDetails);
  }

  /**
   * Method list services availed by a citizen.
   * 
   * @param xmlMessage
   *          - input parameter does not hold anything required to list cases.
   * @return domResult - list of services.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document listCitizenServicesAvailed(Document xmlMessage)
      throws AppException, InformationalException {

    ObjectFactory fact = new ObjectFactory();

    ServiceList citizenServicesAvailedList = fact.createServiceList();

    // Outcome plan Services
    listCitizenOutcomePlanServices(citizenServicesAvailedList);
    // OutcomePlan Referrals
    listCitizenOutcomePlanReferrals(citizenServicesAvailedList);
    // Stand alone Referrals
    listCitizenLiteReferrals(citizenServicesAvailedList);

    return toDocument(citizenServicesAvailedList);

  }

  /**
   * Method list names of referrals with in a OutcomePlan for a participant.
   * 
   * @param citizenServicesAvailedList
   *          - list of services records.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  private void listCitizenOutcomePlanReferralNames(
      List<CitizenServiceAvailed> citizenServicesAvailedList)
      throws AppException, InformationalException {

    CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());
    ObjectFactory fact = new ObjectFactory();
    curam.core.sl.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.fact.CaseParticipantRoleFactory
        .newInstance();
    curam.outcomeplanning.outcomeplan.facade.intf.OutcomePlan outcomePlan = curam.outcomeplanning.outcomeplan.facade.fact.OutcomePlanFactory
        .newInstance();

    Referral referral = ReferralFactory.newInstance();
    ListReferralsKey referralsKey = new ListReferralsKey();
    curam.cpm.sl.struct.ReferralKey referralKey = new curam.cpm.sl.struct.ReferralKey();
    ReferralList referralList;
    ReadReferralDetails readReferralDetails;
    CaseIDAndParticipantRoleIDKey caseIDAndParticipantRoleIDKey = new CaseIDAndParticipantRoleIDKey();
    curam.cpm.sl.struct.SearchByReferralRelatedObjectTypeAndStatusKey byReferralRelatedObjectTypeAndStatusKey = new curam.cpm.sl.struct.SearchByReferralRelatedObjectTypeAndStatusKey();
    curam.cpm.sl.intf.ReferralRole referralRole = ReferralRoleFactory
        .newInstance();

    // OutcomePlan List
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    concernRoleKey.concernRoleID = citizenWorkspaceAccountInfo.getConcernRole()
        .getID();

    curam.outcomeplanning.outcomeplan.facade.struct.ListOutcomePlansResult outcomePlansResult = outcomePlan
        .listOutcomePlansByParticipant(concernRoleKey);
    for (curam.outcomeplanning.outcomeplan.facade.struct.OutcomePlanSummaryDetails summaryDetails : outcomePlansResult.dtls) {

      // Read CaseID
      CaseHeader caseHeader = caseHeaderDAO.get(summaryDetails.outcomePlanID);
      // Read CasePariticipantRoleID of the participant
      caseIDAndParticipantRoleIDKey.caseID = caseHeader.getID();
      caseIDAndParticipantRoleIDKey.participantRoleID = concernRoleKey.concernRoleID;
      CaseParticipantRoleIDStruct caseParticipantRoleIDStruct = caseParticipantRole
          .readCaseParticipantRoleIDByParticipantRoleIDAndCaseID(caseIDAndParticipantRoleIDKey);
      // List referrals for a case
      referralsKey.relatedObjectID = caseHeader.getID();
      referralList = referral.listReferralsForCase(referralsKey);
      for (ReferralListDetails listDetails : referralList.referralDtls) {

        byReferralRelatedObjectTypeAndStatusKey.recordStatus = RECORDSTATUSEntry.NORMAL
            .getCode();
        byReferralRelatedObjectTypeAndStatusKey.referralID = listDetails.referralID;
        byReferralRelatedObjectTypeAndStatusKey.relatedObjectType = REFERRALRELATEDROLETYPEEntry.CLIENT
            .getCode();

        // List referral roles to filter referrals for the participant
        ReferralRoleDtlsList referralRoleDtlsList = referralRole
            .searchByReferralRelatedObjectTypeAndStatus(byReferralRelatedObjectTypeAndStatusKey);
        for (ReferralRoleDtls referralRoleDtls : referralRoleDtlsList.dtls) {
          if (referralRoleDtls.relatedObjectID == caseParticipantRoleIDStruct.caseParticipantRoleID) {

            // Read Referral Details
            referralKey.referralID = listDetails.referralID;
            readReferralDetails = referral.readReferralDetails(referralKey);
            if (!readReferralDetails.referralDtls
                .equals(RECORDSTATUSEntry.CANCELLED.getCode())) {
              CitizenServiceAvailed citizenServicesAvailedDetails = new CitizenServiceAvailed();

              citizenServicesAvailedDetails
                  .setServiceName(listDetails.serviceName);

              citizenServicesAvailedList.add(citizenServicesAvailedDetails);

            }
          }

        }
      }
    }
  }

  /**
   * Method list services within a OutcomePlan for a participant.
   * 
   * @param citizenServicesAvailedList
   *          - list of services records.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  private void listCitizenOutcomePlanServices(
      ServiceList citizenServicesAvailedList) throws AppException,
      InformationalException {

     CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());
    ObjectFactory fact = new ObjectFactory();
    curam.outcomeplanning.outcomeplan.facade.intf.OutcomePlan outcomePlan = curam.outcomeplanning.outcomeplan.facade.fact.OutcomePlanFactory
        .newInstance();
    ServiceDeliveryLink serviceDeliveryLink = ServiceDeliveryLinkFactory
        .newInstance();

    HashMap<Integer, String> monthMap = getMonthsFromCodeTable(MONTH.TABLENAME);

    SearchByServiceDeliveryRelatedTypeAndStatusKey deliveryRelatedTypeAndStatusKey = 
      new SearchByServiceDeliveryRelatedTypeAndStatusKey();
    CaseIDAndParticipantRoleIDKey caseIDAndParticipantRoleIDKey = new CaseIDAndParticipantRoleIDKey();
    curam.core.sl.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.fact.CaseParticipantRoleFactory
        .newInstance();

    // List OutcomePlans for a ConcernRole
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    concernRoleKey.concernRoleID = citizenWorkspaceAccountInfo.getConcernRole()
        .getID();

    curam.outcomeplanning.outcomeplan.facade.struct.ListOutcomePlansResult outcomePlansResult = outcomePlan
        .listOutcomePlansByParticipant(concernRoleKey);
    for (curam.outcomeplanning.outcomeplan.facade.struct.OutcomePlanSummaryDetails summaryDetails : outcomePlansResult.dtls) {
      CaseHeader caseHeader = caseHeaderDAO.get(summaryDetails.outcomePlanID);

      // Read CasePariticipantRoleID of the Participant
      caseIDAndParticipantRoleIDKey.caseID = caseHeader.getID();
      caseIDAndParticipantRoleIDKey.participantRoleID = concernRoleKey.concernRoleID;
      CaseParticipantRoleIDStruct caseParticipantRoleIDStruct = caseParticipantRole
          .readCaseParticipantRoleIDByParticipantRoleIDAndCaseID(caseIDAndParticipantRoleIDKey);

      List<curam.servicedelivery.impl.ServiceDelivery> serviceDeliveries =
        new ArrayList<curam.servicedelivery.impl.ServiceDelivery>();
      Date currDt = Date.getCurrentDate();
      if (null != caseHeader) {
        // List ServiceDeliveries for a Case
        serviceDeliveries = serviceDeliveryDAO.searchByCase(caseHeader);
        for (ServiceDelivery serviceDelivery : serviceDeliveries) {
          Date coveringEndDate = serviceDelivery.getCoverPeriodEndDate();
          if (coveringEndDate == null || coveringEndDate.isZero()
              || coveringEndDate.equals(CuramConst.gkEmpty)
              || coveringEndDate.compareTo(currDt) >= 0) {
            if (serviceDelivery.getLifecycleState().getCode().equals(
                SERVICEDELIVERYSTATUSEntry.INPROGRESS.getCode())
                || serviceDelivery.getLifecycleState().getCode().equals(
                    SERVICEDELIVERYSTATUSEntry.NOTSTARTED.getCode())
                || serviceDelivery.getLifecycleState().getCode().equals(
                    SERVICEDELIVERYSTATUSEntry.OPEN.getCode())) {

              // List active service delivery link records to filter
              // services for the participant
              deliveryRelatedTypeAndStatusKey.serviceDeliveryID = serviceDelivery
                  .getID();
              deliveryRelatedTypeAndStatusKey.recordStatus = RECORDSTATUSEntry.NORMAL
                  .getCode();
              deliveryRelatedTypeAndStatusKey.relatedType = SERVICEDELRELATEDTYPEEntry.CASEPARTICIPANTROLE
                  .getCode();
              ServiceDeliveryLinkDtlsList dtlsList = serviceDeliveryLink
                  .searchByServiceDeliveryRelatedTypeAndStatus(deliveryRelatedTypeAndStatusKey);

              for (ServiceDeliveryLinkDtls linkDtls : dtlsList.dtls) {
                if (linkDtls.relatedID == caseParticipantRoleIDStruct.caseParticipantRoleID) {
                  ServiceDetails citizenServicesAvailedDetails = fact
                      .createServiceDetails();

                  citizenServicesAvailedDetails.setPrimaryKey(serviceDelivery
                      .getID());
                  citizenServicesAvailedDetails.setName(serviceDelivery
                      .getName());
                
                  int numOccurances = 1;

                  if (serviceDelivery.getServiceFrequencyPattern() != null
                      && !serviceDelivery.getServiceFrequencyPattern()
                          .isZeroPattern()) {
                    FrequencyPatternUtil frequencyPatternUtil = new FrequencyPatternUtilImpl();
                    Date anchorDate = frequencyPatternUtil
                        .getAnchorDateAfterReferenceDate(serviceDelivery
                            .getCoverPeriodStartDate(), serviceDelivery
                            .getServiceFrequencyPattern());

                    DateRange coverPeriod = new DateRange(serviceDelivery
                        .getCoverPeriodStartDate(), serviceDelivery
                        .getCoverPeriodEndDate());
                    List<Date> frequencyOccurrences = frequencyPatternUtil
                        .getFrequencyOccurrencesWithinPeriod(serviceDelivery
                            .getServiceFrequencyPattern(), coverPeriod,
                            anchorDate);
                    numOccurances = frequencyOccurrences.size();

                  }
                  citizenServicesAvailedDetails.setTotalUnits(new Long(
                      serviceDelivery.getUnitsAuthorized() * numOccurances));
                  citizenServicesAvailedDetails.setAvailedUnits(new Long(
                      serviceDelivery.getUnitsConsumed()));

                  try {
                    LocalisableString localisableString = new LocalisableString(
                        SCHEDULEDAPPOINTMENT.INFO_FREQUENCY_DURATION_STRING);
                    localisableString.arg(serviceDelivery.getDurationHours());
                    localisableString.arg(serviceDelivery.getDurationMinutes());

                    citizenServicesAvailedDetails
                        .setFrequencyAndDuration(getFrequencyPatternAsHumanReadableString(
                            serviceDelivery, monthMap)
                            + CuramConst.gkSpace
                            + localisableString.getMessage());

                    Date nextSessiondate = Date.getCurrentDate();
                    if (nextSessiondate.before(serviceDelivery
                        .getCoverPeriodStartDate())) {
                      citizenServicesAvailedDetails
                          .setNextSession(getXMLGregCalDate(serviceDelivery
                              .getFrequencyPattern().getNextOccurrence(
                                  serviceDelivery.getCoverPeriodStartDate())
                              .getCalendar().getTime()));
                    } else {
                      citizenServicesAvailedDetails
                          .setNextSession(getXMLGregCalDate(serviceDelivery
                              .getFrequencyPattern().getNextOccurrence(
                                  nextSessiondate).getCalendar().getTime()));
                    }

                  } catch (NullPointerException ne) {
                    citizenServicesAvailedDetails
                        .setFrequencyAndDuration(CuramConst.gkEmpty);
                    citizenServicesAvailedDetails.setNextSession(null);

                  }

                  // Provider Information
                  boolean isProviderNotFound = false;
                  try {
                    citizenServicesAvailedDetails.setProviderID(serviceDelivery
                        .getProvider().getID());
                  } catch (NullPointerException e) {
                    isProviderNotFound = true;
                     citizenServicesAvailedDetails
                           .setProviderAddress(CuramConst.gkEmpty);                    
                  }

                  if (!isProviderNotFound) {
                   
                    citizenServicesAvailedDetails
                        .setProviderName(serviceDelivery.getProvider()
                            .getName());
                    // todo refactor.
                    citizenServicesAvailedDetails
                                       .setProviderAddress(((curam.piwrapper.impl.Address) this.addressDAO
                                               .get(serviceDelivery
                                                       .getProvider()
                                                       .getPrimaryAddressID()))
                                                       .getOneLineAddressString());                   
                    citizenServicesAvailedDetails
                        .setProviderLongitude(((curam.piwrapper.impl.Address) this.addressDAO
                            .get(serviceDelivery.getProvider()
                                .getPrimaryAddressID())).getLongitude());
                    citizenServicesAvailedDetails
                        .setProviderLatitude(((curam.piwrapper.impl.Address) this.addressDAO
                            .get(serviceDelivery.getProvider()
                                .getPrimaryAddressID())).getLatitude());
                  
                  }
                  citizenServicesAvailedList.getDtls().add(
                      citizenServicesAvailedDetails);

                }
              }
            }
          }
        }
      }
    }
  }

  /**
   * Method list referrals with in a OutcomePlan for a participant.
   * 
   * @param citizenServicesAvailedList
   *          - list of services records.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  private void listCitizenOutcomePlanReferrals(
      ServiceList citizenServicesAvailedList) throws AppException,
      InformationalException {

    CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());
    ObjectFactory fact = new ObjectFactory();
    curam.core.sl.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.fact.CaseParticipantRoleFactory
        .newInstance();
    curam.outcomeplanning.outcomeplan.facade.intf.OutcomePlan outcomePlan = curam.outcomeplanning.outcomeplan.facade.fact.OutcomePlanFactory
        .newInstance();
   
    Referral referral = ReferralFactory.newInstance();
    ListReferralsKey referralsKey = new ListReferralsKey();
    curam.cpm.sl.struct.ReferralKey referralKey = new curam.cpm.sl.struct.ReferralKey();
    ReferralList referralList;
    ReadReferralDetails readReferralDetails;
    CaseIDAndParticipantRoleIDKey caseIDAndParticipantRoleIDKey = new CaseIDAndParticipantRoleIDKey();
    curam.cpm.sl.struct.SearchByReferralRelatedObjectTypeAndStatusKey byReferralRelatedObjectTypeAndStatusKey = 
      new curam.cpm.sl.struct.SearchByReferralRelatedObjectTypeAndStatusKey();
    curam.cpm.sl.intf.ReferralRole referralRole = ReferralRoleFactory
        .newInstance();

    // OutcomePlan List
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    concernRoleKey.concernRoleID = citizenWorkspaceAccountInfo.getConcernRole()
        .getID();

    curam.outcomeplanning.outcomeplan.facade.struct.ListOutcomePlansResult outcomePlansResult = outcomePlan
        .listOutcomePlansByParticipant(concernRoleKey);
    for (curam.outcomeplanning.outcomeplan.facade.struct.OutcomePlanSummaryDetails summaryDetails : outcomePlansResult.dtls) {

      // Read CaseID
      CaseHeader caseHeader = caseHeaderDAO.get(summaryDetails.outcomePlanID);
      // Read CasePariticipantRoleID of the participant
      caseIDAndParticipantRoleIDKey.caseID = caseHeader.getID();
      caseIDAndParticipantRoleIDKey.participantRoleID = concernRoleKey.concernRoleID;
      CaseParticipantRoleIDStruct caseParticipantRoleIDStruct = caseParticipantRole
          .readCaseParticipantRoleIDByParticipantRoleIDAndCaseID(caseIDAndParticipantRoleIDKey);
      // List referrals for a case
      referralsKey.relatedObjectID = caseHeader.getID();
      referralList = referral.listReferralsForCase(referralsKey);
      for (ReferralListDetails listDetails : referralList.referralDtls) {

        byReferralRelatedObjectTypeAndStatusKey.recordStatus = RECORDSTATUSEntry.NORMAL
            .getCode();
        byReferralRelatedObjectTypeAndStatusKey.referralID = listDetails.referralID;
        byReferralRelatedObjectTypeAndStatusKey.relatedObjectType = REFERRALRELATEDROLETYPEEntry.CLIENT
            .getCode();

        // List referral roles to filter referrals for the participant
        ReferralRoleDtlsList referralRoleDtlsList = referralRole
            .searchByReferralRelatedObjectTypeAndStatus(byReferralRelatedObjectTypeAndStatusKey);
        for (ReferralRoleDtls referralRoleDtls : referralRoleDtlsList.dtls) {
          if (referralRoleDtls.relatedObjectID == caseParticipantRoleIDStruct.caseParticipantRoleID) {

            // Read Referral Details
            referralKey.referralID = listDetails.referralID;
            readReferralDetails = referral.readReferralDetails(referralKey);
            if (!readReferralDetails.referralDtls
                .equals(RECORDSTATUSEntry.CANCELLED.getCode())) {
              ServiceDetails citizenServicesAvailedDetails = fact
                  .createServiceDetails();
             
              citizenServicesAvailedDetails.setName(listDetails.serviceName);
                                       
              citizenServicesAvailedDetails
                  .setProviderID(readReferralDetails.providerID);
              citizenServicesAvailedDetails
                  .setProviderName(readReferralDetails.providerName);

              citizenServicesAvailedDetails
                           .setProviderAddress(readReferralDetails.providerAddress);              
              citizenServicesAvailedDetails
                  .setProviderLatitude(((curam.piwrapper.impl.Address) this.addressDAO
                      .get(providerDAO.get(readReferralDetails.providerID)
                          .getPrimaryAddressID())).getLatitude());
              citizenServicesAvailedDetails
                  .setProviderLongitude(((curam.piwrapper.impl.Address) this.addressDAO
                      .get(providerDAO.get(readReferralDetails.providerID)
                          .getPrimaryAddressID())).getLongitude());
              citizenServicesAvailedDetails.setNextSession(null);
              citizenServicesAvailedDetails.setTotalUnits(0L);
              citizenServicesAvailedDetails.setAvailedUnits(0L);
              citizenServicesAvailedDetails
                  .setFrequencyAndDuration(CuramConst.gkEmpty);
              citizenServicesAvailedDetails
                  .setPrimaryKey(listDetails.serviceOfferingID);
              citizenServicesAvailedList.getDtls().add(
                  citizenServicesAvailedDetails);
            }
          }

        }
      }
    }
  }

  /**
   * Method list stand alone lite referrals referred to a participant.
   * 
   * @param citizenServicesAvailedList
   *          - list of services records.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */

  private void listCitizenLiteReferrals(ServiceList citizenServicesAvailedList)
      throws AppException, InformationalException {

    CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());
    ObjectFactory fact = new ObjectFactory();
    LiteReferral liteReferral = LiteReferralFactory.newInstance();
    LiteAgencyReferral liteAgencyReferral = LiteAgencyReferralFactory
        .newInstance();

    // Stand Alone Referral
    LiteReferralConcernRoleID liteReferralConcernRoleID = new LiteReferralConcernRoleID();
    liteReferralConcernRoleID.concernRoleID = citizenWorkspaceAccountInfo
        .getConcernRole().getID();

    LiteReferralDetailsList liteReferralDetailsList = liteReferral
        .listLiteReferrals(liteReferralConcernRoleID);

    for (LiteReferralDetails liteReferralDetails : liteReferralDetailsList.dtls) {
      if (!liteReferralDetails.status.equals(LITEREFERRALSTATUSEntry.CLOSED
          .getCode())
          && !liteReferralDetails.status
              .equals(LITEREFERRALSTATUSEntry.CANCELED.getCode())
          && !liteReferralDetails.status.equals(LITEREFERRALSTATUSEntry.EXPIRED
              .getCode())) {

        ServiceDetails citizenServicesAvailedDetails = fact
            .createServiceDetails();
        String phoneNumber = CuramConst.gkEmpty;
       
        citizenServicesAvailedDetails
            .setPrimaryKey(liteReferralDetails.liteReferralID);
        citizenServicesAvailedDetails.setName(liteReferralDetails.referral);

        citizenServicesAvailedDetails
            .setFrequencyAndDuration(CuramConst.gkEmpty);
        citizenServicesAvailedDetails.setNextSession(null);
        citizenServicesAvailedDetails.setTotalUnits(0L);
        citizenServicesAvailedDetails.setAvailedUnits(0L);
        
        // Provider Details
        if (liteReferralDetails.type.equals(LITEREFERRALTYPEEntry.PROVIDER
            .getCode())) {
          curam.litereferral.impl.LiteProviderReferral providerReferral = 
            (curam.litereferral.impl.LiteProviderReferral) this.liteProviderReferralDAO
              .get(liteReferralDetails.liteReferralID);

          citizenServicesAvailedDetails.setProviderID(providerReferral
              .getProvider().getID());
          
          citizenServicesAvailedDetails.setProviderName(providerReferral
              .getProvider().getName());

           citizenServicesAvailedDetails
                   .setProviderAddress(((curam.piwrapper.impl.Address) this.addressDAO
                           .get(providerReferral.getProvider()
                                   .getPrimaryAddressID()))
                                   .getOneLineAddressString());
          
          citizenServicesAvailedDetails
              .setProviderLatitude(((curam.piwrapper.impl.Address) this.addressDAO
                  .get(providerReferral.getProvider().getPrimaryAddressID()))
                  .getLatitude().doubleValue());
          citizenServicesAvailedDetails
              .setProviderLongitude(((curam.piwrapper.impl.Address) this.addressDAO
                  .get(providerReferral.getProvider().getPrimaryAddressID()))
                  .getLongitude().doubleValue());
        }
        citizenServicesAvailedList.getDtls().add(citizenServicesAvailedDetails);
      }

    }

  }

  /**
   * Method list names of services within a OutcomePlan for a participant.
   * 
   * @param citizenServicesAvailedList
   *          - list of services records.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  private void listCitizenOutcomePlanServiceNames(
      List<CitizenServiceAvailed> citizenServicesAvailedList)
      throws AppException, InformationalException {

    CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());
    ObjectFactory fact = new ObjectFactory();
    curam.outcomeplanning.outcomeplan.facade.intf.OutcomePlan outcomePlan = curam.outcomeplanning.outcomeplan.facade.fact.OutcomePlanFactory
        .newInstance();
    ServiceDeliveryLink serviceDeliveryLink = ServiceDeliveryLinkFactory
        .newInstance();

    SearchByServiceDeliveryRelatedTypeAndStatusKey deliveryRelatedTypeAndStatusKey = 
      new SearchByServiceDeliveryRelatedTypeAndStatusKey();
    CaseIDAndParticipantRoleIDKey caseIDAndParticipantRoleIDKey = new CaseIDAndParticipantRoleIDKey();
    curam.core.sl.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.fact.CaseParticipantRoleFactory
        .newInstance();

    // List OutcomePlans for a ConcernRole
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    concernRoleKey.concernRoleID = citizenWorkspaceAccountInfo.getConcernRole()
        .getID();

    curam.outcomeplanning.outcomeplan.facade.struct.ListOutcomePlansResult outcomePlansResult = outcomePlan
        .listOutcomePlansByParticipant(concernRoleKey);

    for (curam.outcomeplanning.outcomeplan.facade.struct.OutcomePlanSummaryDetails summaryDetails : outcomePlansResult.dtls) {
      CaseHeader caseHeader = caseHeaderDAO.get(summaryDetails.outcomePlanID);

      // Read CasePariticipantRoleID of the Participant
      caseIDAndParticipantRoleIDKey.caseID = caseHeader.getID();
      caseIDAndParticipantRoleIDKey.participantRoleID = concernRoleKey.concernRoleID;
      CaseParticipantRoleIDStruct caseParticipantRoleIDStruct = caseParticipantRole
          .readCaseParticipantRoleIDByParticipantRoleIDAndCaseID(caseIDAndParticipantRoleIDKey);

      List<curam.servicedelivery.impl.ServiceDelivery> serviceDeliveries =
        new ArrayList<curam.servicedelivery.impl.ServiceDelivery>();
      Date currDt = Date.getCurrentDate();
      if (null != caseHeader) {
        // List ServiceDeliveries for a Case
        serviceDeliveries = serviceDeliveryDAO.searchByCase(caseHeader);
        for (ServiceDelivery serviceDelivery : serviceDeliveries) {
          Date coveringEndDate = serviceDelivery.getCoverPeriodEndDate();
          if (coveringEndDate == null || coveringEndDate.isZero()
              || coveringEndDate.equals(CuramConst.gkEmpty)
              || coveringEndDate.compareTo(currDt) >= 0) {
            if (serviceDelivery.getLifecycleState().getCode().equals(
                SERVICEDELIVERYSTATUSEntry.INPROGRESS.getCode())
                || serviceDelivery.getLifecycleState().getCode().equals(
                    SERVICEDELIVERYSTATUSEntry.NOTSTARTED.getCode())
                || serviceDelivery.getLifecycleState().getCode().equals(
                    SERVICEDELIVERYSTATUSEntry.OPEN.getCode())) {

              // List active service delivery link records to filter
              // services for the participant
              deliveryRelatedTypeAndStatusKey.serviceDeliveryID = serviceDelivery
                  .getID();
              deliveryRelatedTypeAndStatusKey.recordStatus = RECORDSTATUSEntry.NORMAL
                  .getCode();
              deliveryRelatedTypeAndStatusKey.relatedType = SERVICEDELRELATEDTYPEEntry.CASEPARTICIPANTROLE
                  .getCode();
              ServiceDeliveryLinkDtlsList dtlsList = serviceDeliveryLink
                  .searchByServiceDeliveryRelatedTypeAndStatus(deliveryRelatedTypeAndStatusKey);

              for (ServiceDeliveryLinkDtls linkDtls : dtlsList.dtls) {
                if (linkDtls.relatedID == caseParticipantRoleIDStruct.caseParticipantRoleID) {

                  CitizenServiceAvailed citizenServicesAvailedDetails = new CitizenServiceAvailed();
                  citizenServicesAvailedDetails.setServiceName(serviceDelivery
                      .getName());

                  citizenServicesAvailedList.add(citizenServicesAvailedDetails);

                }
              }
            }
          }
        }
      }
    }
  }

  /**
   * Method list names of stand alone lite referrals referred to a participant.
   * 
   * @param citizenServicesAvailedList
   *          - list of services records.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */

  private void listCitizenLiteReferralNames(
      List<CitizenServiceAvailed> citizenServicesAvailedList)
      throws AppException, InformationalException {

    CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());
    ObjectFactory fact = new ObjectFactory();
    LiteReferral liteReferral = LiteReferralFactory.newInstance();
    LiteAgencyReferral liteAgencyReferral = LiteAgencyReferralFactory
        .newInstance();

    // Stand Alone Referral
    LiteReferralConcernRoleID liteReferralConcernRoleID = new LiteReferralConcernRoleID();
    liteReferralConcernRoleID.concernRoleID = citizenWorkspaceAccountInfo
        .getConcernRole().getID();

    LiteReferralDetailsList liteReferralDetailsList = liteReferral
        .listLiteReferrals(liteReferralConcernRoleID);

    for (LiteReferralDetails liteReferralDetails : liteReferralDetailsList.dtls) {
      if (!liteReferralDetails.status.equals(LITEREFERRALSTATUSEntry.CLOSED
          .getCode())
          && !liteReferralDetails.status
              .equals(LITEREFERRALSTATUSEntry.CANCELED.getCode())
          && !liteReferralDetails.status.equals(LITEREFERRALSTATUSEntry.EXPIRED
              .getCode())) {

        CitizenServiceAvailed citizenServicesAvailedDetails = new CitizenServiceAvailed();
        citizenServicesAvailedDetails
            .setServiceName(liteReferralDetails.referral);

        citizenServicesAvailedList.add(citizenServicesAvailedDetails);
      }

    }

  }

  /**
   * This method returns a list of Next Payments due for a Citizen.
   * 
   * @param xmlMessage
   * @return domResult
   * @throws AppException
   * @throws InformationalException
   */
  public Document listCitizenNextPayments(Document xmlMessage)
      throws AppException, InformationalException {

    CitizenWorkspaceAccountInfo cwAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());

    ObjectFactory fact = new ObjectFactory();
    PaymentList paymentDetailsList = fact.createPaymentList();

    // Next Payments
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    concernRoleKey.concernRoleID = cwAccountInfo.getConcernRole().getID();

    FinancialComponentDtlsList componentDtlsList = searchActiveFCByConcernRole(concernRoleKey);
    for (FinancialComponentDtls componentDtls : componentDtlsList.dtls.items()) {

      PaymentDetails paymentDetails = fact.createPaymentDetails();
      paymentDetails
          .setAmount(roundToDecimals(componentDtls.amount.getValue()));
      paymentDetails.setPaymentDate(getXMLGregCalDate(componentDtls.dueDate
          .getCalendar().getTime()));

      ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      productDeliveryKey.caseID = componentDtls.caseID;
      ProductDeliveryDtls productDelDtls = curam.core.fact.ProductDeliveryFactory
          .newInstance().read(productDeliveryKey);
     
      paymentDetails.setProgramName(curam.util.type.CodeTable.getOneItem(
          PRODUCTTYPE.TABLENAME, (productDelDtls.productType)));

      paymentDetails.setCurrencySymbol(Configuration
          .getProperty(EnvVars.ENV_CURRENCY_SYMBOL));

      paymentDetails.setPrimaryKey(componentDtls.financialCompID);

      paymentDetailsList.getDtls().add(paymentDetails);
    }

    return toDocument(paymentDetailsList);
  }

  /**
   * This method returns a list of active Financial Component records for a
   * participant.
   * 
   * @param key
   *          holds concernroleID
   * @return financialComponentDtlsList holds instances of financial records
   * @throws AppException
   * @throws InformationalException
   */
  private FinancialComponentDtlsList searchActiveFCByConcernRole(
      final ConcernRoleKey key) throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();

    StringBuilder sqlBuilder = new StringBuilder();

    sqlBuilder
        .append("SELECT FinancialComponent.dueDate, FinancialComponent.amount, FinancialComponent.caseID, ");
    sqlBuilder
        .append("FinancialComponent.caseTypeCode, FinancialComponent.categoryCode,FinancialComponent.typeCode,"
            + "FinancialComponent.currencyTypeCode ");
    sqlBuilder.append("INTO :dueDate, :amount, :caseID, ");
    sqlBuilder
        .append(":caseTypeCode, :categoryCode , :typeCode, :currencyTypeCode ");
    sqlBuilder.append("FROM FinancialComponent ");

    sqlBuilder
        .append("WHERE FinancialComponent.concernRoleID = :concernRoleID ");
    sqlBuilder.append("AND FinancialComponent.statusCode = :statusCode");
    sqlBuilder.append(" AND FinancialComponent.dueDate >= :date");
    sqlBuilder.append("  order by FinancialComponent.dueDate asc");

    ConcernRoleIDAndDateKey concernRoleIDAndDateKey = new ConcernRoleIDAndDateKey();
    concernRoleIDAndDateKey.concernRoleID = key.concernRoleID;
    concernRoleIDAndDateKey.date = Date.getCurrentDate();
    concernRoleIDAndDateKey.statusCode = FINCOMPONENTSTATUSEntry.LIVE.getCode();

    CuramValueList<FinancialComponentDtls> valueList = null;
    try {
      valueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
          curam.core.struct.FinancialComponentDtls.class,
          concernRoleIDAndDateKey, false, true, sqlBuilder.toString());
    } catch (curam.util.exception.ReadmultiMaxException e) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
          .addInfoMgrExceptionWithLookup(
              new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
              CuramConst.gkEmpty,
              InformationalElement.InformationalType.kError,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              8);
      informationalManager.failOperation();
    }

    FinancialComponentDtlsList financialComponentDtlsList = new FinancialComponentDtlsList();
    for (FinancialComponentDtls componentDtls : valueList.items()) {
      financialComponentDtlsList.dtls.addRef(componentDtls);
    }

    return financialComponentDtlsList;
  }

  /**
   * Method returns a list of Cases concerned to a citizen.
   * 
   * @param xmlMessage
   *          - input parameter does not hold anything required to list cases.
   * @return domResult - list of cases.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document listCitizenCases(Document xmlMessage) throws AppException,
      InformationalException {

    CitizenWorkspaceAccountInfo cwAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getInfo().getProgramUser());
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    concernRoleKey.concernRoleID = cwAccountInfo.getConcernRole().getID();
    CaseList citizenCaseDetailsList = listCaseByConcernRoleID(concernRoleKey);
    return toDocument(citizenCaseDetailsList);
  }

  /**
   * Method returns a list of cases for a given concernrole.
   * 
   * @param concernRoleKey
   *          - holds concernroleID.
   * @return citizenCaseDetailsList - list of cases.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  private CaseList listCaseByConcernRoleID(ConcernRoleKey concernRoleKey)
      throws AppException, InformationalException {

    Organization organization = OrganizationFactory.newInstance();
    IntegratedCase integratedCase = IntegratedCaseFactory.newInstance();
    ObjectFactory fact = new ObjectFactory();

    ConcernRole concernRole = ConcernRoleFactory.newInstance();
    CaseGroups caseGroups = CaseGroupsFactory.newInstance();

    ReadUserHomePageKey homePageKey = new ReadUserHomePageKey();
    ReadOrganizationUserHomePageDetails organizationUserHomePageDetails;
    CaseList citizenCaseDetailsList = fact.createCaseList();
    ListICProductDeliveryClientRoleKey clientRoleKey = new ListICProductDeliveryClientRoleKey();
    NameAddressReadKey nameAddressReadKey = new NameAddressReadKey();
    CaseGroupsReadmultiKey caseGroupReadMultiKey = new CaseGroupsReadmultiKey();

    // Product Delivery Cases
    int ongoingCount = 0;
    int pendingCount = 0;
    int suspendedCount = 0;

    CuramValueList<ClientsCaseDetails> valueList = searchPDCByConcernRoleID(concernRoleKey);
    for (ClientsCaseDetails caseDetails : valueList.items()) {

      CaseDetails citizenCaseDetails = fact.createCaseDetails();
      citizenCaseDetails.setProgramName(curam.util.type.CodeTable.getOneItem(
          PRODUCTTYPE.TABLENAME, (caseDetails.productType)));
      citizenCaseDetails.setPrimaryKey(caseDetails.caseID);
      citizenCaseDetails.setCaseID(caseDetails.caseReference);

      if (caseDetails.orgobjectType.equals(ORGOBJECTTYPE.USER)) {
        // Case Worker Details
        homePageKey.userKeyStruct.userName = caseDetails.username;
        organizationUserHomePageDetails = organization
            .readOrganizationUserHomePage(homePageKey);
        citizenCaseDetails
            .setContactAgencyPhoneNumber(organizationUserHomePageDetails.organizationUserDetails.businessCountryCode
                + organizationUserHomePageDetails.organizationUserDetails.businessAreaCode
                + organizationUserHomePageDetails.organizationUserDetails.businessNumber
                + organizationUserHomePageDetails.organizationUserDetails.businessPhoneExtn);
        citizenCaseDetails
            .setContactAgencyMobileNumber(organizationUserHomePageDetails.organizationUserDetails.mobileCountryCode
                + organizationUserHomePageDetails.organizationUserDetails.mobileAreaCode
                + organizationUserHomePageDetails.organizationUserDetails.mobileNumber);

        citizenCaseDetails
            .setContactAgencyEmailAddress(organizationUserHomePageDetails.organizationUserDetails.businessEMail);
        citizenCaseDetails
            .setContactCaseWorkerName(organizationUserHomePageDetails.organizationUserDetails.fullName);
      }

      if (CASESTATUSEntry.OPEN.getCode().equals(caseDetails.caseStatus)
      /*
       * JM Commenting out as codetable entry does not exist ||
       * CASESTATUSEntry.SUBMITTED.getCode().equals( caseDetails.caseStatus)
       */
      || CASESTATUSEntry.APPROVED.getCode().equals(caseDetails.caseStatus)) {
        citizenCaseDetails.setCaseStatusCode(DMConstant.kPendingCase);
        pendingCount++;
      } else if (CASESTATUSEntry.ACTIVE.getCode()
          .equals(caseDetails.caseStatus)
          || CASESTATUSEntry.PENDINGCLOSURE.getCode().equals(
              caseDetails.caseStatus)) {

        citizenCaseDetails.setCaseStatusCode(DMConstant.kOngoingCase);
        ongoingCount++;
      } else if (CASESTATUSEntry.SUSPENDED.getCode().equals(
          caseDetails.caseStatus)) {
        citizenCaseDetails.setCaseStatusCode(DMConstant.kSuspended);
        suspendedCount++;
      }
      // Case Members of a Product Delivery Case.
      caseGroupReadMultiKey.caseID = caseDetails.caseID;
      CaseGroupsDtlsList caseGroupDtlsList = caseGroups
          .searchByCase(caseGroupReadMultiKey);
      for (CaseGroupsDtls caseGroupsDtls : caseGroupDtlsList.dtls) {
        if (CASEGROUPTYPEEntry.MEMBER.getCode()
            .equals(caseGroupsDtls.groupCode)) {
          CaseMember caseMember = new CaseMember();
          nameAddressReadKey.concernRoleID = caseGroupsDtls.concernRoleID;
          ConcernNameAddressDetails nameAddressDetails = concernRole
              .readNameAndAddress(nameAddressReadKey);
          caseMember.setName(nameAddressDetails.fullName);
          citizenCaseDetails.getCaseMembers().add(caseMember);
        }
      }
      citizenCaseDetailsList.getDtls().add(citizenCaseDetails);

    }
    return citizenCaseDetailsList;
  }

  /**
   * Method searches Product Delivery Cases by a ConcernroleID.
   * 
   * @param key
   *          - contains concernroleID.
   * @return valueList - contains caseheader records.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  private CuramValueList searchPDCByConcernRoleID(final ConcernRoleKey key)
      throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();
    CaseAndConcernRoleKey caseAndConcernRoleKey = new CaseAndConcernRoleKey();
    StringBuilder sqlBuilder = new StringBuilder();

    sqlBuilder
        .append("SELECT DISTINCT CASEHEADER.CASEID, CASEHEADER.CASEREFERENCE, CASEHEADER.CONCERNROLEID, CASEHEADER.STATUSCODE,"
            + "CASEHEADER.STARTDATE, ");
    sqlBuilder
        .append("CASEHEADER.ENDDATE, PRODUCTDELIVERY.PRODUCTTYPE, ORGOBJECTLINK.ORGOBJECTTYPE, ORGOBJECTLINK.USERNAME,");
    sqlBuilder
        .append(" ORGOBJECTLINK.ORGOBJECTLINKID, CONCERNROLE.CONCERNROLENAME ,CASEHEADER.LASTWRITTEN ");
    sqlBuilder
        .append(" INTO :caseID,:caseReference,:concernRoleID,:caseStatus,:caseStartDate, ");
    sqlBuilder
        .append(":caseEndDate,:productType,:orgobjectType,:username, :ownerorgobjectLinkID ,:concernRoleName ,:lastwritten ");
    sqlBuilder
        .append(" FROM CASEHEADER,PRODUCTDELIVERY,ORGOBJECTLINK,CASEGROUPS,CONCERNROLE ");
    sqlBuilder.append(" WHERE CASEHEADER.CASEID = PRODUCTDELIVERY.CASEID ");
    sqlBuilder
        .append(" AND CASEHEADER.OWNERORGOBJECTLINKID = ORGOBJECTLINK.ORGOBJECTLINKID");
    sqlBuilder.append(" AND CASEHEADER.CASEID = CASEGROUPS.CASEID ");
    sqlBuilder
        .append(" AND CASEHEADER.CONCERNROLEID=CONCERNROLE.CONCERNROLEID");
    sqlBuilder.append(" AND CASEGROUPS.GROUPCODE='"
        + CASEGROUPTYPEEntry.MEMBER.getCode() + "'");
    sqlBuilder.append(" AND CASEHEADER.STATUSCODE !='"
        + CASESTATUSEntry.CANCELED.getCode() + "'");
    sqlBuilder.append(" AND CASEHEADER.STATUSCODE !='"
        + CASESTATUSEntry.CLOSED.getCode() + "'");
    sqlBuilder.append(" AND CASEGROUPS.CONCERNROLEID = :concernRoleID");
    sqlBuilder.append(" ORDER BY CASEHEADER.LASTWRITTEN DESC");

    caseAndConcernRoleKey.concernRoleID = key.concernRoleID;
    CuramValueList<ClientsCaseDetails> valueList = null;
    try {
      valueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
          ClientsCaseDetails.class, caseAndConcernRoleKey, false, true,
          sqlBuilder.toString());
    } catch (curam.util.exception.ReadmultiMaxException e) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addInfoMgrExceptionWithLookup(
              new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      informationalManager.failOperation();
    }
    return valueList;
  }
  
  /**
   * Method returns a map containing months.
   * 
   * @param tableName
   *          - name of the code table.
   * @return monthMap - HashMap instance.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */

  private HashMap<Integer, String> getMonthsFromCodeTable(String tableName)
      throws AppException, InformationalException {

    LinkedHashMap<String, String> codeTableItemsMap = new LinkedHashMap<String, String>();
    HashMap<Integer, String> monthMap = new HashMap<Integer, String>();
    codeTableItemsMap = curam.util.type.CodeTable.getAllEnabledItems(tableName,
        TransactionInfo.getProgramLocale());
    Iterator entries = codeTableItemsMap.entrySet().iterator();
    int i = 0;
    while (entries.hasNext()) {
      Entry thisEntry = (Entry) entries.next();
      String value = (String) thisEntry.getValue();
      monthMap.put(i, value);
      i++;
    }
    return monthMap;
  }

  /**
   * Method lists person records whose birthday falls on the current date.
   * 
   * @param xmlMessage
   *          - input parameter does not hold anything required to list person
   *          records.
   * @return domResult - list of person records.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document listBirthdayNotifications(Document xmlMessage)
      throws AppException, InformationalException {

    ObjectFactory objectFactory = new ObjectFactory();
    ClientDetailsList concernRoleDetailsList = objectFactory
        .createClientDetailsList();

    InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();
    StringBuilder sqlBuilder = new StringBuilder();
        
    sqlBuilder
        .append("SELECT PERSON.CONCERNROLEID,CONCERNROLE.CONCERNROLENAME,EXTERNALUSER.USERNAME,PERSON.DATEOFBIRTH ");
    sqlBuilder
        .append(" INTO :concernRoleID,:concernRoleName,:userName,:dateOfBirth");
    sqlBuilder.append(" FROM PERSON,CONCERNROLE,EXTERNALUSER");
    sqlBuilder.append(" WHERE PERSON.CONCERNROLEID=CONCERNROLE.CONCERNROLEID");
    sqlBuilder
        .append(" AND  EXTERNALUSER.FULLNAME=CONCERNROLE.CONCERNROLENAME");

    CuramValueList<PersonBirthDayDetails> valueList = null;
    try {
      valueList = curam.util.dataaccess.DynamicDataAccess
          .executeNsMulti(PersonBirthDayDetails.class, null, false, true,
              sqlBuilder.toString());
    } catch (curam.util.exception.ReadmultiMaxException e) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addInfoMgrExceptionWithLookup(
              new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      informationalManager.failOperation();
    }

    Date currentDate = Date.getCurrentDate();
    int month = currentDate.getCalendar().getInstance().get(Calendar.MONTH);
    int day = currentDate.getCalendar().getInstance()
        .get(Calendar.DAY_OF_MONTH);

    for (PersonBirthDayDetails dtls : valueList.items()) {
      int dobMonth = dtls.dateOfBirth.getCalendar().get(Calendar.MONTH);
      int dobDay = dtls.dateOfBirth.getCalendar().get(Calendar.DAY_OF_MONTH);
      if (dobMonth == month && day == dobDay) {
        ClientDetails concernRoleDetails = objectFactory.createClientDetails();

        concernRoleDetails.setPrimaryKey(dtls.concernRoleID);
        concernRoleDetails.setFirstName(dtls.concernRoleName);
        // TODO Need to obtain first name and second name separately
        // concernRoleDetails.setLastName(value);
        concernRoleDetails.setUserName(dtls.userName);
        concernRoleDetailsList.getDtls().add(concernRoleDetails);
      }
    }
    return toDocument(concernRoleDetailsList);
  }

  /**
   * Method lists Recertification Records linked to product delivery cases along
   * with member details of the product delivery case.
   * 
   * @param xmlMessage
   *          - input parameter holds the no of days that will be used to
   *          subtract the
   * @return domResult - list of recertification records.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document listRecertificationNotifications(Document xmlMessage)
      throws AppException, InformationalException {

    curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory sampleObjectFactory = new curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory();
    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    RecertificationDetailsKey recertificationDetailsKey = JAXB.unmarshal(
        source, RecertificationDetailsKey.class);
    ConcernRoleDetailsList concernRoleDetailsList = sampleObjectFactory
        .createConcernRoleDetailsList();
    InformationalManager informationalManager = TransactionInfo
        .getInformationalManager();
    // SQL Execution
    StringBuilder sqlBuilder = new StringBuilder();
    sqlBuilder
        .append("SELECT DISTINCT PERIODTODATE,PRODUCTDELIVERY.PRODUCTTYPE,");
    sqlBuilder
        .append("CASEGROUPS.CONCERNROLEID,CONCERNROLE.CONCERNROLENAME,EXTERNALUSER.USERNAME,CASEHEADER.CASEREFERENCE ");
    sqlBuilder
        .append(" INTO :periodToDate,:productType,:concernRoleID,:concernRoleName,:userName,:caseReference ");
    sqlBuilder
        .append(" FROM  PRODUCTDELIVERYCERTDIARY,CASEGROUPS,PRODUCTDELIVERY,CONCERNROLE,CASEHEADER,EXTERNALUSER");
    sqlBuilder
        .append(" WHERE PRODUCTDELIVERYCERTDIARY.CASEID=CASEGROUPS.CASEID");
    sqlBuilder
        .append(" AND PRODUCTDELIVERY.CASEID=PRODUCTDELIVERYCERTDIARY.CASEID");
    sqlBuilder.append(" AND PRODUCTDELIVERY.CASEID=CASEHEADER.CASEID ");
    sqlBuilder
        .append(" AND CASEGROUPS.CONCERNROLEID=CONCERNROLE.CONCERNROLEID");
    sqlBuilder.append(" AND EXTERNALUSER.FULLNAME=CONCERNROLE.CONCERNROLENAME");
    sqlBuilder.append(" AND CASEHEADER.STATUSCODE !='"
        + CASESTATUSEntry.CANCELED.getCode() + "'");
    sqlBuilder.append(" AND CASEGROUPS.GROUPCODE='"
        + CASEGROUPTYPEEntry.MEMBER.getCode() + "'");

    CuramValueList<RecertificationDetails> valueList = null;
    try {
      valueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
          RecertificationDetails.class, null, false, true, sqlBuilder
              .toString());
    } catch (curam.util.exception.ReadmultiMaxException e) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory
          .getManager()
          .addInfoMgrExceptionWithLookup(
              new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
              CuramConst.gkEmpty, InformationalElement.InformationalType.kError);
      informationalManager.failOperation();
    }

    Date currentDate = Date.getCurrentDate();
    for (RecertificationDetails dtls : valueList.items()) {

      Date periodToDate = dtls.periodToDate.addDays(-recertificationDetailsKey
          .getNoOfDayskey().intValue());

      if (periodToDate.equals(currentDate)) {
        ConcernRoleDetails concernRoleDetails = sampleObjectFactory
            .createConcernRoleDetails();
        concernRoleDetails.setConcernRoleID(dtls.concernRoleID);
        concernRoleDetails.setConcernRoleName(dtls.concernRoleName);
        concernRoleDetails.setUserName(dtls.userName);
        concernRoleDetails.setProgramName(curam.util.type.CodeTable.getOneItem(
            PRODUCTTYPE.TABLENAME, (dtls.productType)));
        concernRoleDetails
            .setProgramExpiryDate(getXMLGregCalDate(dtls.periodToDate
                .getCalendar().getTime()));
        concernRoleDetailsList.getDtls().add(concernRoleDetails);
        concernRoleDetails.setCaseReference(dtls.caseReference);
      }
    }
    return toDocument(concernRoleDetailsList);
  }

  /**
   * Method lists citizen messages that are to be displayed on the dash board.
   * 
   * @param xmlMessage
   *          - no input parameter
   * @return domResult - list of messages.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document listCitizenDashBoardMessages(Document xmlMessage)
      throws AppException, InformationalException {
    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
      
    DashBoardDetailsKey dashboardDetailsKey = JAXB.unmarshal(source,
        DashBoardDetailsKey.class);
    boolean getPayments = dashboardDetailsKey.isEnablePayments() != null ? dashboardDetailsKey.isEnablePayments() : true;
    boolean getCases = dashboardDetailsKey.isEnableCases()  != null ? dashboardDetailsKey.isEnableCases() : true;
    boolean getServices = dashboardDetailsKey.isEnableServices()  != null ? dashboardDetailsKey.isEnableServices() : false;

    CitizenWorkspaceAccountInfo cwAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getInfo().getProgramUser());
    ObjectFactory objectFactory = new ObjectFactory();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    concernRoleKey.concernRoleID = cwAccountInfo.getConcernRole().getID();

    DashBoardDetails dashBoardSummary = objectFactory.createDashBoardDetails();

    // Cases Details
    if (getCases) {
        CaseList citizenCaseDetailsList = listCaseByConcernRoleID(concernRoleKey);
        DashBoardCaseDetails dashBoardCaseDetails = objectFactory
            .createDashBoardCaseDetails();

        for (CaseDetails caseDetails : citizenCaseDetailsList.getDtls()) {
          dashBoardCaseDetails.getProgramName().add(caseDetails.getProgramName());
        }
        dashBoardCaseDetails.setTotalCount(citizenCaseDetailsList.getDtls().size());
        dashBoardSummary.setCasedtls(dashBoardCaseDetails);
    }
    
    // Payment Details
    if (getPayments) {
        DashBoardPaymentDetails boardPaymentDetails = objectFactory
            .createDashBoardPaymentDetails();
        // Previous Payment Total Count
        ListParticipantFinancialsKey key = new ListParticipantFinancialsKey();
        key.concernRoleID = cwAccountInfo.getConcernRole().getID();

        ListParticipantFinancials1 listParticipantFinancials1 = ParticipantFactory
            .newInstance().listParticipantFinancial1(key);
        boardPaymentDetails
            .setTotalCount(listParticipantFinancials1.participantFinancialsList.dtls
                .size());
        dashBoardSummary.setPmntdtls(boardPaymentDetails);

        // Next Payment
        InformationalManager informationalManager = TransactionInfo
            .getInformationalManager();
        StringBuilder sqlBuilder = new StringBuilder();
        sqlBuilder
            .append("SELECT FinancialComponent.dueDate, FinancialComponent.amount ");
        sqlBuilder.append(" INTO :dueDate,:amount");
        sqlBuilder.append(" FROM FinancialComponent ");
        sqlBuilder
            .append(" WHERE FinancialComponent.concernRoleID = :concernRoleID ");
        sqlBuilder.append(" AND FinancialComponent.statusCode = '"
            + FINCOMPONENTSTATUSEntry.LIVE.getCode() + "'");
        sqlBuilder.append(" AND FinancialComponent.dueDate >= :date");
        sqlBuilder.append(" ORDER BY FinancialComponent.dueDate asc");

        ConcernRoleIDAndDateKey concernRoleIDAndDateKey = new ConcernRoleIDAndDateKey();
        concernRoleIDAndDateKey.concernRoleID = key.concernRoleID;
        concernRoleIDAndDateKey.date = Date.getCurrentDate();

        CuramValueList<FinancialComponentDtls> valueList = null;
        try {
          valueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
              curam.core.struct.FinancialComponentDtls.class,
              concernRoleIDAndDateKey, false, true, sqlBuilder.toString());
        } catch (curam.util.exception.ReadmultiMaxException e) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager()
              .addInfoMgrExceptionWithLookup(
                  new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
                  CuramConst.gkEmpty,
                  InformationalElement.InformationalType.kError,
                  curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
                  8);
          informationalManager.failOperation();
        }
        boardPaymentDetails.setCurrencySymbol(Configuration
            .getProperty(EnvVars.ENV_CURRENCY_SYMBOL));
        if (valueList == null || valueList.items().length == 0) {
          boardPaymentDetails.setAmount("0");
          boardPaymentDetails.setPaymentDate(null);
        }
        for (FinancialComponentDtls componentDtls : valueList.items()) {
          boardPaymentDetails.setAmount(roundToDecimals(componentDtls.amount
              .getValue()));
          boardPaymentDetails
              .setPaymentDate(getXMLGregCalDate(componentDtls.dueDate.getCalendar()
                  .getTime()));
          break;
        }
    }
    // Services
    if (getServices) {
        DashBoardServicesDetails dashBoardServicesDetails = objectFactory
            .createDashBoardServicesDetails();

        List<CitizenServiceAvailed> citizenServicesAvailedList = new ArrayList<CitizenServiceAvailed>();
        listCitizenOutcomePlanServiceNames(citizenServicesAvailedList);
        listCitizenOutcomePlanReferralNames(citizenServicesAvailedList);
        listCitizenLiteReferralNames(citizenServicesAvailedList);

        dashBoardServicesDetails.setTotalCount(citizenServicesAvailedList.size());

        for (CitizenServiceAvailed citizenServicesAvailedDetails : citizenServicesAvailedList) {
          dashBoardServicesDetails.getServiceName().add(
              citizenServicesAvailedDetails.getServiceName());
        }

        dashBoardSummary.setServicedtls(dashBoardServicesDetails);
    }
    return toDocument(dashBoardSummary);
  }

  /**
   * Method updates email details concerned to a citizen.
   * 
   * @param xmlMessage
   *          - contains an instance of ModifyCitizenEmailDetails.
   * @return result - contains response code.
   * @throws AppException
   *           - Generic InformationalException Signature.
   * @throws InformationalException
   *           - Generic InformationalException Signature.
   */
  public Document updateCitizenEmailDetails(Document xmlMessage)
      throws AppException, InformationalException {

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    // input struct
    ModifyCitizenEmailDetails emailDetails = JAXB.unmarshal(source,
        ModifyCitizenEmailDetails.class);
    CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
        .readAccountBy(TransactionInfo.getProgramUser());
    curam.core.intf.MaintainConcernRoleEmail maintainConcernRoleEmailObj = 
      curam.core.fact.MaintainConcernRoleEmailFactory
        .newInstance();
    // enactment struct
    CitizenEmailAddress citizenEmailAddress = new CitizenEmailAddress();
    MaintainPhoneNumberKey maintainPhoneNumberKey = new MaintainPhoneNumberKey();
    maintainPhoneNumberKey.concernRoleID = citizenWorkspaceAccountInfo
        .getConcernRole().getID();

    MaintainEmailKey maintainEmailKey = new MaintainEmailKey();
    maintainEmailKey.concernRoleID = maintainPhoneNumberKey.concernRoleID;

    // assign email details
    MaintainParticipantEmailAddressDetails maintainParticipantEmailAddressDetails = 
      new MaintainParticipantEmailAddressDetails();

    ConcernRoleEmailAddressKey concernRoleEmailAddressKey = new ConcernRoleEmailAddressKey();
    concernRoleEmailAddressKey.concernRoleEmailAddressID = emailDetails
        .getConcernRoleEmailAddressID();
    ConcernRoleEmailAddressDtls concernRoleEmailAddressDtls = ConcernRoleEmailAddressFactory
        .newInstance().read(concernRoleEmailAddressKey);

    maintainParticipantEmailAddressDetails.concernRoleEmailDetails.emailAddressID = 
      concernRoleEmailAddressDtls.emailAddressID;
    citizenEmailAddress.emailAddressID = concernRoleEmailAddressDtls.emailAddressID;

    maintainParticipantEmailAddressDetails.concernRoleEmailDetails.concernRoleEmailAddressID = emailDetails
        .getConcernRoleEmailAddressID();
    citizenEmailAddress.concernRoleEmailAddressID = emailDetails
        .getConcernRoleEmailAddressID();

    if (!emailDetails.getEmailAddress().equals(CuramConst.gkEmpty)) {
      maintainParticipantEmailAddressDetails.concernRoleEmailDetails.emailAddress = emailDetails
          .getEmailAddress();
      citizenEmailAddress.emailAddress = emailDetails.getEmailAddress();
    }
    maintainParticipantEmailAddressDetails.concernRoleEmailDetails.typeCode = emailDetails
        .getTypeCode();
    citizenEmailAddress.typeCode = emailDetails.getTypeCode();

    maintainParticipantEmailAddressDetails.concernRoleEmailDetails.concernRoleID = 
      maintainPhoneNumberKey.concernRoleID;
    citizenEmailAddress.concernRoleID = maintainPhoneNumberKey.concernRoleID;

    maintainParticipantEmailAddressDetails.concernRoleEmailDetails.primaryEmailInd = emailDetails
        .isPrimaryEmailInd();
    citizenEmailAddress.primaryEmailInd = emailDetails.isPrimaryEmailInd();

    maintainParticipantEmailAddressDetails.concernRoleEmailDetails.statusCode = RECORDSTATUS.NORMAL;
    citizenEmailAddress.statusCode = RECORDSTATUS.NORMAL;

    if (emailDetails.getStartDate() != null) {
      maintainParticipantEmailAddressDetails.concernRoleEmailDetails.startDate = new Date(
          emailDetails.getStartDate().toGregorianCalendar());
      citizenEmailAddress.startDate = maintainParticipantEmailAddressDetails.concernRoleEmailDetails.startDate;
    }
    if (emailDetails.getEndDate() != null) {
      maintainParticipantEmailAddressDetails.concernRoleEmailDetails.endDate = new Date(
          emailDetails.getEndDate().toGregorianCalendar());
      citizenEmailAddress.endDate = maintainParticipantEmailAddressDetails.concernRoleEmailDetails.endDate;
    }
    if (!emailDetails.getComments().equals(CuramConst.gkEmpty)) {
      maintainParticipantEmailAddressDetails.concernRoleEmailDetails.comments = emailDetails
          .getComments();
      citizenEmailAddress.comments = emailDetails.getComments();
    }

    EmailAddressKey paramEmailAddressKey = new EmailAddressKey();
    paramEmailAddressKey.emailAddressID = concernRoleEmailAddressDtls.emailAddressID;
    EmailAddressDtls emailAddressDtls = EmailAddressFactory.newInstance().read(
        paramEmailAddressKey);
    maintainParticipantEmailAddressDetails.concernRoleEmailDetails.versionNo = emailAddressDtls.versionNo;
    citizenEmailAddress.concernRoleEmailVersionNo = emailAddressDtls.versionNo;

    curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory sampleObjectFactory = 
      new curam.diona.mobility.citizenselfservice.sample.struct.ObjectFactory();

    ResponseCode responseCode = sampleObjectFactory.createResponseCode();
    if (!emailDetails.isDeferredProcessingInd()) {
      try {
        // modify email details
        maintainConcernRoleEmailObj.modifyEmailAddress(maintainEmailKey,
            maintainParticipantEmailAddressDetails.concernRoleEmailDetails);
        responseCode.setResponseCode(123456789L);
      } catch (Exception e) {
        e.printStackTrace();
        responseCode.setResponseCode(987654321L);
      }
    } else {
      // enact workflow
      citizenEmailAddress.typeDesc = curam.util.type.CodeTable.getOneItem(
          EMAILTYPE.TABLENAME, citizenEmailAddress.typeCode);
      final List<CitizenEmailAddress> enactmentStruct = new ArrayList<CitizenEmailAddress>();
      enactmentStruct.add(citizenEmailAddress);
      curam.util.workflow.impl.EnactmentService.startProcess(
          DMConstant.kDMCitizenEmailDetailsUpdates, enactmentStruct);
    }

    return toDocument(responseCode);
  }

  /**
   * This method is to used to update documents for Verification
   * 
   * @param Document
   * @return Document
   * @throws AppException
   * @throws InformationalException
   */
  public Document uploadDocument(Document xmlMessage)
  throws AppException, InformationalException {

      try {
          CitizenWorkspaceAccountInfo citizenWorkspaceAccountInfo = citizenWorkspaceAccountManager
          .readAccountBy(TransactionInfo.getProgramUser());

          DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
          CitizenProofOfDocument citizenProofOfDocument = JAXB.unmarshal(
                  source, CitizenProofOfDocument.class);
          curam.core.facade.intf.ConcernRoleAttachment concernRoleAttachment = ConcernRoleAttachmentFactory
          .newInstance();

          // persist details
          ConcernRoleAttachmentDetails attachmentDetails = new ConcernRoleAttachmentDetails();
          attachmentDetails.attachmentDtls.attachmentName = citizenProofOfDocument
          .getAttachmentName();
          attachmentDetails.linkDtls.concernRoleID = citizenWorkspaceAccountInfo
          .getConcernRole().getID();
          attachmentDetails.attachmentDtls.documentType = DOCUMENTTYPE.EVIDENCEFORM;
          attachmentDetails.linkDtls.description = DMMESSAGE.INF_MOBILE_UPLOAD
          .getMessageText();
          byte[] byteArray = null;
          // jaxb converts base64 into binary
          // so its not required to convert it again.
          byteArray = citizenProofOfDocument.getAttachmentContents();
          attachmentDetails.attachmentDtls.attachmentContents = new Blob(
                  byteArray);
          attachmentDetails.attachmentDtls.receiptDate = Date
          .getCurrentDate();
          concernRoleAttachment
          .createConcernRoleAttachment(attachmentDetails);

          // raise event to enact work flow to initiate a task to case worker
          // to verify the uploaded document

          ConcernRoleKey concernRoleKey = new ConcernRoleKey();
          concernRoleKey.concernRoleID = citizenWorkspaceAccountInfo
          .getConcernRole().getID();

          Event event = new Event();
          event.eventKey = curam.events.DMMESSAGE.CASEWORKERTASKNOTIFICATION;
          event.primaryEventData = concernRoleKey.concernRoleID;
          EventService.raiseEvent(event);
      } catch (Throwable ee) {
          ee.printStackTrace();
          throw new RuntimeException(ee);

      }
      ObjectFactory fact = new ObjectFactory();
      curam.diona.mobility.citizenselfservice.struct.ResponseCode responseCode = fact.createResponseCode();
      responseCode.setResponseCode(123456789L);
      return toDocument(responseCode);

  }  
  
  /**
   * Method appends two decimals to double value.
   * 
   * @param d
   *          - double value
   * @return - formatted string
   */
  private static String roundToDecimals(double d) {
    return String.format("%.2f", d);
  }

  /**
   * Method to fetch Date
   * 
   * @param Document
   * @return
   * @throws AppException
   * @throws InformationalException
   */
  private XMLGregorianCalendar getXMLGregCalDate(java.util.Date date) {
    XMLGregorianCalendar formatteddate = null;
    if (date != null) {
      try {
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(date);
        formatteddate = DatatypeFactory.newInstance()
            .newXMLGregorianCalendarDate(cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH),
                DatatypeConstants.FIELD_UNDEFINED);
        return formatteddate;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return formatteddate;

  }

  /**
   * Method returns human readable representation of a frequency pattern.
   * 
   * @param serviceDelivery
   *          - service delivery details.
   * @param monthMap
   *          - HashMap instance.
   * @return decodedPattern
   */

  private String getFrequencyPatternAsHumanReadableString(
      ServiceDelivery serviceDelivery, HashMap<Integer, String> monthMap) {

    Calendar calendar = new GregorianCalendar();
    StringBuffer decodedPattern = new StringBuffer("");
    FrequencyPattern ff = serviceDelivery.getFrequencyPattern();
    if (ff == null) {
      ff = serviceDelivery.getServiceFrequencyPattern();
    }
    if (serviceDelivery.getFrequencyPattern().getPatternType().equals(
        PatternType.kBiMonthly)) {
      if (serviceDelivery.getFrequencyPattern().getDayOfMonth().isNumberedDay()) {
        decodedPattern.append(DMMESSAGE.INF_DAY);
        decodedPattern.append(serviceDelivery.getFrequencyPattern()
            .getDayOfMonth().toString());
        decodedPattern.append(DMMESSAGE.INF_AND);
        String pattern = serviceDelivery.getFrequencyPattern().toString();
        decodedPattern.append(new DayOfMonth(Byte.parseByte(pattern.substring(
            1, 3))).toString());
      } else {
        decodedPattern.append(DMMESSAGE.INF_THE);
        decodedPattern.append(serviceDelivery.getFrequencyPattern()
            .getDayOfMonth().toString());
        decodedPattern.append(DMMESSAGE.INF_AND);
        decodedPattern.append(DayOfMonth.kNullDayOfMonth.toString());
        decodedPattern.append(" ");
        decodedPattern.append(serviceDelivery.getFrequencyPattern()
            .getDayOfWeekMask().toString());
      }
      decodedPattern.append(" ");
      decodedPattern.append(DMMESSAGE.INF_EVERY_MONTH);
    } else if (serviceDelivery.getFrequencyPattern().getPatternType().equals(
        PatternType.kDaily)) {
      if (serviceDelivery.getFrequencyPattern().getDayOfWeekMask().equals(
          DayOfWeekMask.kWeekday)) {
        decodedPattern.append(DMMESSAGE.INF_EVERY_WEEK_DAYS);
      } else {
        decodedPattern.append("Every ");
        Integer b = Integer.valueOf(serviceDelivery.getFrequencyPattern()
            .getInterval());
        decodedPattern.append(b.toString());
        decodedPattern.append(" ");
        decodedPattern.append(DMMESSAGE.INF_DAYS);
      }
    } else if (serviceDelivery.getFrequencyPattern().getPatternType().equals(
        PatternType.kWeekly)) {
      decodedPattern.append(DMMESSAGE.INF_RECUR_EVERY);
      Integer b = Integer.valueOf(serviceDelivery.getFrequencyPattern()
          .getInterval());
      decodedPattern.append(b.toString());
      decodedPattern.append(DMMESSAGE.INF_WEEKS_ON);

      if (serviceDelivery.getFrequencyPattern().getDayOfWeekMask().equals(
          DayOfWeekMask.kNullDayOfWeek))
        decodedPattern.append(DMMESSAGE.INF_THE_START_DAY);
      else {
        decodedPattern.append(serviceDelivery.getFrequencyPattern()
            .getDayOfWeekMask().toString());
      }

    } else if (serviceDelivery.getFrequencyPattern().getPatternType().equals(
        PatternType.kMonthly)) {
      if (serviceDelivery.getFrequencyPattern().getDayOfMonth().isNumberedDay()) {
        decodedPattern.append(DMMESSAGE.INF_DAY);
        decodedPattern.append(serviceDelivery.getFrequencyPattern()
            .getDayOfMonth().toString());
        decodedPattern.append(DMMESSAGE.INF_OFEVERY);
        Integer c = Integer.valueOf(serviceDelivery.getFrequencyPattern()
            .getInterval());
        decodedPattern.append(c.toString());
        decodedPattern.append(DMMESSAGE.INF_MONTHS);
      } else {
        decodedPattern.append(DMMESSAGE.INF_THE);
        decodedPattern.append(serviceDelivery.getFrequencyPattern()
            .getDayOfMonth().toString());
        decodedPattern.append(" ");
        decodedPattern.append(serviceDelivery.getFrequencyPattern()
            .getDayOfWeekMask().toString());
        decodedPattern.append(DMMESSAGE.INF_OFEVERY);
        Integer b = Integer.valueOf(serviceDelivery.getFrequencyPattern()
            .getInterval());
        decodedPattern.append(b.toString());
        decodedPattern.append(DMMESSAGE.INF_MONTHS);
      }
    } else if (serviceDelivery.getFrequencyPattern().getDayOfMonth()
        .isNumberedDay()) {
      decodedPattern.append(DMMESSAGE.INF_EVERY);
      decodedPattern.append(serviceDelivery.getFrequencyPattern()
          .getDayOfMonth());
      decodedPattern.append(" ");
      decodedPattern.append(monthMap.get(serviceDelivery.getFrequencyPattern()
          .getInterval() - 1));

    } else {
      decodedPattern.append(DMMESSAGE.INF_THE);
      decodedPattern.append(serviceDelivery.getFrequencyPattern()
          .getDayOfMonth());
      decodedPattern.append(" ");
      decodedPattern.append(serviceDelivery.getFrequencyPattern()
          .getDayOfWeekMask());
      decodedPattern.append(DMMESSAGE.INF_OF);
      decodedPattern.append(monthMap.get(serviceDelivery.getFrequencyPattern()
          .getInterval() - 1));
    }

    return decodedPattern.toString();
  }

  /**
   * Helper class to keep service name, to be used for populating Service Dash
   * Board details.
   */
  private class CitizenServiceAvailed {

    public void CitizenServiceAvailed() {
    };

    protected String serviceName;

    public void setServiceName(String name) {
      serviceName = name;
    }

    public String getServiceName() {
      return serviceName;
    }
  }



/**
 * Method Converts a JAXB object to DOM Document.
 * @param object - JAXB Object.
 * @return document - org.w3c.dom.Document object is returned.
 * 
 */
private org.w3c.dom.Document toDocument(Object doc) {
	// temp fix to apply namespace prefix on a existing jaxb object
	// cannot use namespace mappers has some isues in different jdk vendors
	// other option is to update every class jaxb generated class.
	// one other option is to do a recursive loop and form the dom again.
	// as mostly this works. if not can be customized. 
	
	java.io.StringWriter tempStringHandler = new java.io.StringWriter();
    JAXB.marshal(doc, tempStringHandler);
    String s = tempStringHandler.toString();
    if (s.indexOf("ns2:") == -1) {
	    s = tempStringHandler.toString().replaceAll("</", "@/ns2:");
	    s = s.replace("<?xml", "@?xml");
	    s = s.replaceAll("<", "<ns2:");
	    s = s.replaceAll("@/ns2:", "</ns2:");
	    s = s.replace("@?xml", "<?xml");
	    s = s.replace("xmlns=", "xmlns:ns2=");
    }
    return convertStringToDOM(s);
}


/**
 * Method Converts a String xml object to DOM Document.
 * @param in - String xml Object.
 * @return document - org.w3c.dom.Document object is returned.
 * 
 */
private org.w3c.dom.Document convertStringToDOM(String in) {
    try {
    
    javax.xml.parsers.DocumentBuilderFactory factory = javax.xml.parsers.DocumentBuilderFactory.newInstance();
    javax.xml.parsers.DocumentBuilder builder = factory.newDocumentBuilder();
    org.w3c.dom.Document document = builder.parse(new org.xml.sax.InputSource(new java.io.StringReader(in)));    
    return document;
    
    } catch (Exception e) {
         e.printStackTrace(System.out);
        throw new RuntimeException(e);
    }
}

}