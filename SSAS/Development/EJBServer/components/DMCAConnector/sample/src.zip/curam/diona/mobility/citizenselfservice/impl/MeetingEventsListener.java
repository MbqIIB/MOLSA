/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package curam.diona.mobility.citizenselfservice.impl;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.io.UnsupportedEncodingException;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.codetable.DMMessageType;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.meetings.sl.impl.Meeting.MeetingEvents;
import curam.meetings.sl.impl.MeetingAttendee;
import curam.meetings.sl.impl.MeetingDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.DateTime;
import dm.events.EventException;
import dm.events.curam.DMNotificationHandler;
import dm.events.curam.NotificationHandler;
import dm.events.type.SOREvent;
import dm.events.type.SOREventWrapper;

@SuppressWarnings("all")
public class MeetingEventsListener implements MeetingEvents {

	
	@Inject
	protected Provider<curam.meetings.sl.impl.Meeting> meetingProvider;

	protected MeetingEventsListener() {

	}

	public void inviteAttendee(final long meetingID,
			final MeetingAttendee meetingAttendee) throws AppException,
			InformationalException {

		boolean isSucess = true;
		MeetingDetails meetingDetails = meetingProvider.get().readMeetingDetails(
				meetingID);

		SOREventWrapper  wrapper = new SOREventWrapper ();
		SOREvent event = wrapper.getEvent();
		event.setRelatedId(meetingID);
		if (meetingDetails.isAllDayEvent()) {
			resetTimeForAllDayEvent(meetingDetails);
		}

		event.setCreatedOn(getXMLGregCalDate(DateTime.getCurrentDateTime().getCalendar().getTime()));
		event.setType(DMMessageType.APPOINTMENT);
		event.setSentDateTime(DateTime.getCurrentDateTime().toString());
		event.setLastUpdatedBy(TransactionInfo.getProgramUser());
		event.setEventStartTime(meetingDetails.getStartDateTime().toString());
		event.setEventEndTime(meetingDetails.getEndDateTime().toString());
		// TODO encode for location.
		event.setLocation(meetingDetails.getLocation());
		event.setContactEmailAddress(meetingDetails.getOrganizer().getEmailAddress());
		event.setContactPerson(meetingDetails.getOrganizer().getFullName());
		try {
			String subj =  meetingDetails.getSubject() != null 
				? new org.apache.commons.codec.binary.Base64()
				.encodeBase64String(meetingDetails.getSubject().getBytes("UTF-8"))
				: meetingDetails.getSubject();
			event.setSubject(subj);
			System.out.println("sub=" + subj);
			String desc = meetingDetails.getDescription() != null ? 
			  new org.apache.commons.codec.binary.Base64().encodeBase64String(
			meetingDetails.getDescription().getBytes("UTF-8")) : meetingDetails.getDescription();
			event.setContent(desc); 
			event.setNotes(desc);
		} catch(UnsupportedEncodingException e1) {
		   e1.printStackTrace();
		}
		StringBuilder sqlBuilder = new StringBuilder();
		
		sqlBuilder.append(" SELECT EXTERNALUSER.USERNAME");
		sqlBuilder.append(" INTO :userName");
		sqlBuilder.append(" FROM EXTERNALUSER ");
		sqlBuilder.append(" WHERE UPPER(EXTERNALUSER.FULLNAME) ='"+meetingAttendee.getName().toUpperCase()+"'");
		try{
		ExternalUserDtls externalUserDtls = (ExternalUserDtls)
		curam.util.dataaccess.DynamicDataAccess.executeNs( ExternalUserDtls.class, null, 
				false, sqlBuilder.toString());
		event.setUserId(externalUserDtls.userName); 
		
		}catch(RecordNotFoundException re){
			isSucess = false;
		}
		if(isSucess){
			try {
				NotificationHandler notify = DMNotificationHandler.getInstance();
				notify.handleNotification( 
						event);
			} catch (EventException e) {
				e.printStackTrace();
			}
		}
	
	}

	@Override
	public void invalidAttendeeEmailAddress(MeetingDetails meetingDetails,
			MeetingAttendee meetingAttendee) throws AppException,
			InformationalException {
		// TODO Auto-generated method stub

	}

	@Override
	public void postCancelMeeting(MeetingDetails meetingDetails)
	throws AppException, InformationalException {
		// TODO Auto-generated method stub


	}

	@Override
	public void postCreateMeeting(MeetingDetails meetingDetails)
	throws AppException, InformationalException {
		// TODO Auto-generated method stub

	}

	@Override
	public void postModifyMeeting(MeetingDetails meetingDetails)
	throws AppException, InformationalException {
		// TODO Auto-generated method stub

	}

	@Override
	public void preCancelMeeting(long meetingID) throws AppException,
	InformationalException {
		// TODO Auto-generated method stub

	}

	@Override
	public void preCreateMeeting(MeetingDetails meetingDetails)
	throws AppException, InformationalException {
		// TODO Auto-generated method stub

	}

	@Override
	public void preModifyMeeting(MeetingDetails meetingDetails)
	throws AppException, InformationalException {
		// TODO Auto-generated method stub

	}


	/**
	 * Method to fetch Date
	 * 
	 * @param Document
	 * @return
	 * @throws AppException
	 * @throws InformationalException
	 */
	private XMLGregorianCalendar getXMLGregCalDate(java.util.Date date) {
		XMLGregorianCalendar formatteddate = null;
		if (date != null) {
			try {
				GregorianCalendar cal = new GregorianCalendar();
				cal.setTime(date);
				formatteddate = DatatypeFactory.newInstance()
				.newXMLGregorianCalendarDate(cal.get(Calendar.YEAR),
						cal.get(Calendar.MONTH) + 1,
						cal.get(Calendar.DAY_OF_MONTH),
						DatatypeConstants.FIELD_UNDEFINED);
				return formatteddate;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return formatteddate;

	}

	private void resetTimeForAllDayEvent(MeetingDetails meetingDetails) {

     	DateTime startDateTime = meetingDetails.getStartDateTime();
	    DateTime endDateTime = meetingDetails.getEndDateTime();
		Calendar refCal = startDateTime.getCalendar();
		refCal.set(
				refCal.get(Calendar.YEAR),
				refCal.get(Calendar.MONTH), 
				refCal.get(Calendar.DAY_OF_MONTH), 
				0, 
				0, 
				0);
		
		Calendar endCal = endDateTime.getCalendar();
		endCal.set(
				endCal.get(Calendar.YEAR),
				endCal.get(Calendar.MONTH), 
				endCal.get(Calendar.DAY_OF_MONTH), 
				23, 
				59, 
				0);
		
     	meetingDetails.setStartDateTime(new DateTime(refCal));
	    meetingDetails.setEndDateTime(new DateTime(endCal));

	}
	

}
