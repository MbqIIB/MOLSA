/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package curam.diona.mobility.citizenselfservice.impl;

import java.io.UnsupportedEncodingException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import curam.core.impl.CuramConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.DateTime;
import curam.workspaceservices.facade.fact.LocalizableTextFactory;
import curam.workspaceservices.facade.intf.LocalizableText;
import curam.workspaceservices.facade.struct.SystemMessageKey;
import curam.workspaceservices.facade.struct.TextTranslationDetails;
import curam.workspaceservices.localization.fact.TextTranslationFactory;
import curam.workspaceservices.localization.struct.SearchByLocalizableTextIDKey;
import curam.workspaceservices.localization.struct.TextTranslationDtlsList;
import curam.workspaceservices.localization.struct.TextTranslationKey;
import curam.workspaceservices.systemmessage.fact.SystemMessageFactory;
import curam.workspaceservices.systemmessage.intf.SystemMessage;
import curam.workspaceservices.systemmessage.struct.SystemMessageDtls;
import dm.events.EventException;
import dm.events.curam.DMNotificationHandler;
import dm.events.curam.NotificationHandler;
import dm.events.type.SOREvent;
import dm.events.type.SOREventWrapper;


@SuppressWarnings("all")
public  class DMSystemMessage 
extends curam.diona.mobility.citizenselfservice.base.DMSystemMessage
implements curam.diona.mobility.citizenselfservice.intf.DMSystemMessage{


	public void publishSystemMessage(SystemMessageKey systemMessageKey)
	throws AppException, InformationalException
	{

		super.publishSystemMessage(systemMessageKey);
		SystemMessage systemMessage = SystemMessageFactory.newInstance();
		LocalizableText localizableText = LocalizableTextFactory.newInstance();
		TextTranslationKey textTranslationKey =  new TextTranslationKey();
		curam.workspaceservices.systemmessage.struct.SystemMessageKey messageKey
		= new curam.workspaceservices.systemmessage.struct.SystemMessageKey();

		//read system message
		messageKey.systemMessageID = systemMessageKey.systemMessageID;
		SystemMessageDtls systemMessageDtls = systemMessage.read(messageKey);

		SOREventWrapper  wrapper = new SOREventWrapper ();
		SOREvent event = wrapper.getEvent();
		event.setRelatedId(messageKey.systemMessageID);
		event.setCreatedBy(systemMessageDtls.createdBy);
		event.setCreatedOn(getXMLGregCalDate(systemMessageDtls.creationDate.getCalendar().getTime()));
		event.setType ( 
				curam.codetable.DMMessageType.ANNOUNCEMENT);
		event.setStatus( 
				curam.codetable.DMMessageStatus.UNREAD);
		event.setEventStartTime(systemMessageDtls.effectiveDateTime.toString());
		event.setEventEndTime(systemMessageDtls.expiryDateTime.toString());
		event.setSentDateTime(DateTime.getCurrentDateTime().toString());
		 
		//Title 
		String title = "";
		SearchByLocalizableTextIDKey idKey = new SearchByLocalizableTextIDKey();
		idKey.localizableTextID = systemMessageDtls.titleTextID;
		TextTranslationDtlsList dtlsList = 
				 TextTranslationFactory.newInstance().searchByLocalizableTextID(idKey);
		if (!dtlsList.dtls.isEmpty()) {
			title = dtlsList.dtls.get(0).text;
		}
		//Message 
		String textContent = "";
		SearchByLocalizableTextIDKey key = new SearchByLocalizableTextIDKey();
		key.localizableTextID = systemMessageDtls.messageTextID;
		TextTranslationDtlsList txtDetails = 
				 TextTranslationFactory.newInstance().searchByLocalizableTextID(key);
		if (!txtDetails.dtls.isEmpty()) {
			textContent = txtDetails.dtls.get(0).text;
		}
		
		
		try {
			String message = title + CuramConst.gkNewLine + textContent;
			if (message.indexOf("<") != -1) {
			    // simple check to strip tags, or else have to use 3rd party libraries
			    // as this is not required.
			    // assumption is well formed html,
			    // this may not handle all types of html strings,
			    // so best is to modify the uim page to support plain text.
				String noHTMLString = message.replaceAll("\\<.*?\\>", "");
				message = noHTMLString.replaceAll("&nbsp;", " ");
			}			
			String encodedContent = new org.apache.commons.codec.binary.Base64()
			.encodeAsString(message.getBytes("UTF-8"));
			event.setContent(encodedContent);
			
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		
		
		
		NotificationHandler notify = DMNotificationHandler.getInstance();
		try {
			notify.handleNotification(
					event);
		} catch (EventException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Method to fetch Date
	 * 
	 * @param Document
	 * @return
	 * @throws AppException
	 * @throws InformationalException
	 */
	private XMLGregorianCalendar getXMLGregCalDate(java.util.Date date) {
		XMLGregorianCalendar formatteddate = null;
		if (date != null) {
			try {
				GregorianCalendar cal = new GregorianCalendar();
				cal.setTime(date);
				formatteddate = DatatypeFactory.newInstance()
				.newXMLGregorianCalendarDate(cal.get(Calendar.YEAR),
						cal.get(Calendar.MONTH) + 1,
						cal.get(Calendar.DAY_OF_MONTH),
						DatatypeConstants.FIELD_UNDEFINED);
				return formatteddate;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return formatteddate;

	}

}
