/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package curam.diona.mobility.citizenselfservice.impl;

import java.util.Calendar;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.GregorianCalendar;
import java.util.Map;

import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import curam.codetable.VERIFICATIONITEMNAME;
import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.events.Verification;
import curam.util.events.impl.EventFilter;
import curam.util.events.impl.EventHandler;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.DateTime;
import curam.verification.sl.entity.fact.VerifiableDataItemFactory;
import curam.verification.sl.entity.struct.VerifiableDataItemDtls;
import curam.verification.sl.entity.struct.VerifiableDataItemKey;
import curam.verification.sl.infrastructure.entity.fact.VDIEDLinkFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationFactory;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkDtls;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationKey;
import dm.events.EventException;
import dm.events.curam.DMNotificationHandler;
import dm.events.curam.NotificationHandler;
import dm.events.type.SOREvent;
import dm.events.type.SOREventWrapper;

@SuppressWarnings("all")
public class DMVerificationEventHandler implements EventHandler, EventFilter  

{
	
	private static final int MAX_ENTRIES = 100;

	private static Map<String,String> 
	      eventDescriptionCache = Collections.synchronizedMap(new LinkedHashMap<String, String>() {
		@Override
		protected boolean removeEldestEntry(
				java.util.Map.Entry<String, String> eldest) {
			return size() > MAX_ENTRIES;
		}
		
	});

	@Override
	public boolean accept(Event event) throws AppException,
	InformationalException {

		return true;
	}


	@Override
	public void eventRaised(Event event) throws AppException,
	InformationalException {
		if(event.eventKey.eventType.equals(Verification.VerificationInserted.eventType)){

			VerificationKey verificationKey =  new VerificationKey();
			verificationKey.verificationID =  event.primaryEventData;
			VerificationDtls verificationDtls = VerificationFactory.newInstance().read(verificationKey);

			VDIEDLinkKey vdiedLinkKey =  new VDIEDLinkKey();
			vdiedLinkKey.VDIEDLinkID = verificationDtls.VDIEDLinkID;
			VDIEDLinkDtls vdiedLinkDtls = VDIEDLinkFactory.newInstance().read(vdiedLinkKey);

			VerifiableDataItemKey verifiableDataItemKey =  new VerifiableDataItemKey();
			verifiableDataItemKey.verifiableDataItemID = vdiedLinkDtls.verifiableDataItemID;
			VerifiableDataItemDtls verifiableDataItemDtls = VerifiableDataItemFactory.newInstance().read(verifiableDataItemKey);

			EvidenceDescriptorKey evidenceDescriptorKey =  new EvidenceDescriptorKey();
			evidenceDescriptorKey.evidenceDescriptorID = vdiedLinkDtls.evidenceDescriptorID;
			EvidenceDescriptorDtls  evidenceDescriptorDtls = EvidenceDescriptorFactory.newInstance().read(evidenceDescriptorKey);

			
			String key = "" +
			evidenceDescriptorDtls.caseID + ""
			+ evidenceDescriptorDtls.evidenceDescriptorID;
			
			if (!eventDescriptionCache.containsKey(key)) {
				eventDescriptionCache.put(key, key);
			
			SOREventWrapper  wrapper = new SOREventWrapper ();
			SOREvent sorEvent = wrapper.getEvent();

			sorEvent.setSentDateTime(DateTime.getCurrentDateTime().toString());
			sorEvent.setCreatedOn(getXMLGregCalDate(DateTime.getCurrentDateTime().getCalendar().getTime()));
			sorEvent.setType(curam.codetable.DMMessageType.PROOF);
			sorEvent.setStatus(curam.codetable.DMMessageStatus.UNREAD);
			sorEvent.setCreatedBy(TransactionInfo.getProgramUser());
			sorEvent.setEventStartTime(DateTime.getCurrentDateTime().toString());
			sorEvent.setRelatedId(verificationKey.verificationID);
			sorEvent.setRequiredDocument( 
					curam.util.type.CodeTable
					.getOneItem(VERIFICATIONITEMNAME.TABLENAME,
							verifiableDataItemDtls.name));

			StringBuilder sqlBuilder = new StringBuilder();
			sqlBuilder.append(" SELECT EXTERNALUSER.USERNAME");
			sqlBuilder.append(" INTO :userName");
			sqlBuilder.append(" FROM EXTERNALUSER,CONCERNROLE ");
			sqlBuilder.append(" WHERE EXTERNALUSER.FULLNAME=CONCERNROLE.CONCERNROLENAME");
			sqlBuilder.append(" AND CONCERNROLE.CONCERNROLEID="+evidenceDescriptorDtls.participantID);

			boolean recordExist=true;
			try{
				ExternalUserDtls externalUserDtls = (ExternalUserDtls)
				curam.util.dataaccess.DynamicDataAccess.executeNs( ExternalUserDtls.class, null, 
						false, sqlBuilder.toString());
				sorEvent.setUserId(externalUserDtls.userName); 
			}catch(RecordNotFoundException re){
				recordExist=false;
			}
			if(recordExist){
				NotificationHandler notify = DMNotificationHandler.getInstance();
				try {
					notify.handleNotification(
							sorEvent);
				} catch (EventException e) {
					e.printStackTrace();
				}
			}
		  }
		}
	}
	/**
	 * Method to fetch Date
	 * 
	 * @param Document
	 * @return
	 * @throws AppException
	 * @throws InformationalException
	 */
	private XMLGregorianCalendar getXMLGregCalDate(java.util.Date date) {
		XMLGregorianCalendar formatteddate = null;
		if (date != null) {
			try {
				GregorianCalendar cal = new GregorianCalendar();
				cal.setTime(date);
				formatteddate = DatatypeFactory.newInstance()
				.newXMLGregorianCalendarDate(cal.get(Calendar.YEAR),
						cal.get(Calendar.MONTH) + 1,
						cal.get(Calendar.DAY_OF_MONTH),
						DatatypeConstants.FIELD_UNDEFINED);
				return formatteddate;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return formatteddate;

	}
}
