/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */

package curam.diona.mobility.citizenselfservice.impl;

import curam.codetable.DMMessageType;
import curam.codetable.PROGRAMTYPE;
import curam.codetable.CASETYPECODE;
import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.creoleprogramrecommendation.impl.AuthorizationEvent;
import curam.creoleprogramrecommendation.impl.SimulatedDeterminationAuthorization;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.type.DateTime;
import dm.events.EventException;
import dm.events.curam.DMNotificationHandler;
import dm.events.curam.NotificationHandler;
import dm.events.type.SOREvent;
import dm.events.type.SOREventWrapper;

public class AuthorizationEventListener extends AuthorizationEvent {

	protected AuthorizationEventListener(){
		// Protected constructor for use only by Guice
	}

	@Override 
	public void postAuthorization(SimulatedDeterminationAuthorization simulatedDeterminationAuthorization)
	throws InformationalException, AppException
	{

		boolean isSucess = true;
		String programName = curam.util.type.CodeTable
		.getOneItem(PROGRAMTYPE.TABLENAME,
				simulatedDeterminationAuthorization.getCREOLEProgramRecommendation().
				getSimulatedDetermination(simulatedDeterminationAuthorization.
						getSimulatedDetermination().getID()).
						getCREOLEProgramRecommendationProduct().getProgramType().getCode()
		) ;

		SOREventWrapper  wrapper = new SOREventWrapper ();
		SOREvent event = wrapper.getEvent();
		event.setRelatedId( simulatedDeterminationAuthorization.getDelivery().getConcernRole().getID().longValue());
		
		event.setContent(programName);
		event.setType(DMMessageType.APPSTATUS);
		event.setSentDateTime(DateTime.getCurrentDateTime().toString());
		event.setCaseReference(simulatedDeterminationAuthorization.getDelivery().getCaseReference());
		event.setProgramName(programName);
		if (simulatedDeterminationAuthorization.getDelivery().getCaseType() != null) {
			event.setCaseType(curam.util.type.CodeTable.getOneItem(
					CASETYPECODE.TABLENAME,
		simulatedDeterminationAuthorization.getDelivery().getCaseType().getCode()));
		}
		StringBuilder sqlBuilder = new StringBuilder();
		sqlBuilder.append(" SELECT EXTERNALUSER.USERNAME");
		sqlBuilder.append(" INTO :userName");
		sqlBuilder.append(" FROM EXTERNALUSER ");
		sqlBuilder.append(" WHERE UPPER(EXTERNALUSER.FULLNAME)= '"+
				simulatedDeterminationAuthorization.getDelivery().getConcernRole().getName().toUpperCase()+"'");
		
		try{
			ExternalUserDtls externalUserDtls = (ExternalUserDtls)
			curam.util.dataaccess.DynamicDataAccess.executeNs( ExternalUserDtls.class, null, 
					false, sqlBuilder.toString());
			event.setUserId(externalUserDtls.userName);
		}catch(RecordNotFoundException re){
			isSucess = false;
		}
		
		if(isSucess){
			NotificationHandler notify = DMNotificationHandler.getInstance();
			try {
				notify.handleNotification( 
						event);
			} catch (EventException e) {
				e.printStackTrace();
			}
		}
	
	}
}
