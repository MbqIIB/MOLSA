/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package dm.util.transport;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import dm.util.transport.HttpEndPoint;
import dm.util.transport.Transport;

/**
 * Http Transport Sender Utility.
 *
 */
public class HttpSender implements Transport<HttpEndPoint> {


@Override
public void invoke(HttpEndPoint endpointInfo, Object payloadObject) throws Exception {
		HttpURLConnection con = null;
        try {
			//TODO use HttpClient / HttpConnectionManager.
	        URL obj = new URL(endpointInfo.getUrlString());
	        con = (HttpURLConnection) obj.openConnection();		
	        con.setRequestMethod(endpointInfo.getRequestMethod());
	        // loading the http header properties.
	        for(Map.Entry<String,String> entry 
	        		: endpointInfo.getHttpRequestHeader().entrySet()) {
	         con.setRequestProperty(entry.getKey(), entry.getValue());
	        }
	
	        
	      
	       // Send post request
	       con.setDoOutput(true);
	       DataOutputStream wr = new DataOutputStream(con.getOutputStream());
	       wr.writeBytes((String) payloadObject);
	       wr.flush();
	       wr.close();
	
	       int responseCode = con.getResponseCode();
	       System.out.println("\nSending 'POST' request to URL : " + endpointInfo.getUrlString());
	//	           System.out.println("Post parameters :" );
	       System.out.println("Response Code : " + responseCode);
	
	       BufferedReader in = new BufferedReader(
	               new InputStreamReader(con.getInputStream()));
	       String inputLine;
	       StringBuffer response = new StringBuffer();
	
	       while ((inputLine = in.readLine()) != null) {
	           response.append(inputLine);
	       }
	       in.close();
	
	       //print result
	       // TODO fault handling and logging error.
	       System.out.println(response.toString());
        } catch (Throwable ee) {
        	// log error.
        	// 
        	ee.printStackTrace();
        	throw new Exception(ee);
        	
        }
		
	}



}
