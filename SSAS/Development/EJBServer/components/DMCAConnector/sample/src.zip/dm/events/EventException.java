/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package dm.events;

/**
 * 
 * Event Exception.
 */
public class EventException extends Exception {
	
	// TODO 
	// handle nested exception.
	
	public EventException(Throwable e) {
	   super(e);
	  
	}

	public EventException(String message) {
		   super(message);
		  
		}
	
	public EventException(String message, Throwable e) {
		   super(message, e);
		  
		}

}
