/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */


package dm.events.datatype;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the dm.events.datatype package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Fault_QNAME = new QName("http://diona.com/notification", "fault");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: dm.events.datatype
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SEMException }
     * 
     */
    public SEMException createSEMException() {
        return new SEMException();
    }

    /**
     * Create an instance of {@link NotificationMessageRequest }
     * 
     */
    public NotificationMessageRequest createNotificationMessageRequest() {
        return new NotificationMessageRequest();
    }

    /**
     * Create an instance of {@link CaseStatusMessageType }
     * 
     */
    public CaseStatusMessageType createCaseStatusMessageType() {
        return new CaseStatusMessageType();
    }

    /**
     * Create an instance of {@link DocumentMessageType }
     * 
     */
    public DocumentMessageType createDocumentMessageType() {
        return new DocumentMessageType();
    }

    /**
     * Create an instance of {@link PaymentMessageType }
     * 
     */
    public PaymentMessageType createPaymentMessageType() {
        return new PaymentMessageType();
    }

    /**
     * Create an instance of {@link ApplicationStatusMessageType }
     * 
     */
    public ApplicationStatusMessageType createApplicationStatusMessageType() {
        return new ApplicationStatusMessageType();
    }

    /**
     * Create an instance of {@link AppointmentMessageType }
     * 
     */
    public AppointmentMessageType createAppointmentMessageType() {
        return new AppointmentMessageType();
    }

    /**
     * Create an instance of {@link AnnouncementMessageType }
     * 
     */
    public AnnouncementMessageType createAnnouncementMessageType() {
        return new AnnouncementMessageType();
    }

    /**
     * Create an instance of {@link NotificationMessageResponse }
     * 
     */
    public NotificationMessageResponse createNotificationMessageResponse() {
        return new NotificationMessageResponse();
    }

    /**
     * Create an instance of {@link AbstractNotificationMessage }
     * 
     */
    public AbstractNotificationMessage createAbstractNotificationMessage() {
        return new AbstractNotificationMessage();
    }

    /**
     * Create an instance of {@link ContactInformationType }
     * 
     */
    public ContactInformationType createContactInformationType() {
        return new ContactInformationType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SEMException }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://diona.com/notification", name = "fault")
    public JAXBElement<SEMException> createFault(SEMException value) {
        return new JAXBElement<SEMException>(_Fault_QNAME, SEMException.class, null, value);
    }

}
