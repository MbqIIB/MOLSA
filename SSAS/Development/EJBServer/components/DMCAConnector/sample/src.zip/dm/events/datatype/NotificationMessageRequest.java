/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */


package dm.events.datatype;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;choice>
 *         &lt;element name="CaseStatusChange" type="{http://diona.com/notification}CaseStatusMessageType"/>
 *         &lt;element name="DocumentUpload" type="{http://diona.com/notification}DocumentMessageType"/>
 *         &lt;element name="PaymentInfo" type="{http://diona.com/notification}PaymentMessageType"/>
 *         &lt;element name="ApplicationStatus" type="{http://diona.com/notification}ApplicationStatusMessageType"/>
 *         &lt;element name="Appointment" type="{http://diona.com/notification}AppointmentMessageType"/>
 *         &lt;element name="Announcement" type="{http://diona.com/notification}AnnouncementMessageType"/>
 *       &lt;/choice>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "caseStatusChange",
    "documentUpload",
    "paymentInfo",
    "applicationStatus",
    "appointment",
    "announcement"
})
@XmlRootElement(name = "NotificationMessageRequest")
public class NotificationMessageRequest {

    @XmlElement(name = "CaseStatusChange")
    protected CaseStatusMessageType caseStatusChange;
    @XmlElement(name = "DocumentUpload")
    protected DocumentMessageType documentUpload;
    @XmlElement(name = "PaymentInfo")
    protected PaymentMessageType paymentInfo;
    @XmlElement(name = "ApplicationStatus")
    protected ApplicationStatusMessageType applicationStatus;
    @XmlElement(name = "Appointment")
    protected AppointmentMessageType appointment;
    @XmlElement(name = "Announcement")
    protected AnnouncementMessageType announcement;

    /**
     * Gets the value of the caseStatusChange property.
     * 
     * @return
     *     possible object is
     *     {@link CaseStatusMessageType }
     *     
     */
    public CaseStatusMessageType getCaseStatusChange() {
        return caseStatusChange;
    }

    /**
     * Sets the value of the caseStatusChange property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaseStatusMessageType }
     *     
     */
    public void setCaseStatusChange(CaseStatusMessageType value) {
        this.caseStatusChange = value;
    }

    /**
     * Gets the value of the documentUpload property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentMessageType }
     *     
     */
    public DocumentMessageType getDocumentUpload() {
        return documentUpload;
    }

    /**
     * Sets the value of the documentUpload property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentMessageType }
     *     
     */
    public void setDocumentUpload(DocumentMessageType value) {
        this.documentUpload = value;
    }

    /**
     * Gets the value of the paymentInfo property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentMessageType }
     *     
     */
    public PaymentMessageType getPaymentInfo() {
        return paymentInfo;
    }

    /**
     * Sets the value of the paymentInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentMessageType }
     *     
     */
    public void setPaymentInfo(PaymentMessageType value) {
        this.paymentInfo = value;
    }

    /**
     * Gets the value of the applicationStatus property.
     * 
     * @return
     *     possible object is
     *     {@link ApplicationStatusMessageType }
     *     
     */
    public ApplicationStatusMessageType getApplicationStatus() {
        return applicationStatus;
    }

    /**
     * Sets the value of the applicationStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApplicationStatusMessageType }
     *     
     */
    public void setApplicationStatus(ApplicationStatusMessageType value) {
        this.applicationStatus = value;
    }

    /**
     * Gets the value of the appointment property.
     * 
     * @return
     *     possible object is
     *     {@link AppointmentMessageType }
     *     
     */
    public AppointmentMessageType getAppointment() {
        return appointment;
    }

    /**
     * Sets the value of the appointment property.
     * 
     * @param value
     *     allowed object is
     *     {@link AppointmentMessageType }
     *     
     */
    public void setAppointment(AppointmentMessageType value) {
        this.appointment = value;
    }

    /**
     * Gets the value of the announcement property.
     * 
     * @return
     *     possible object is
     *     {@link AnnouncementMessageType }
     *     
     */
    public AnnouncementMessageType getAnnouncement() {
        return announcement;
    }

    /**
     * Sets the value of the announcement property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnnouncementMessageType }
     *     
     */
    public void setAnnouncement(AnnouncementMessageType value) {
        this.announcement = value;
    }

}
