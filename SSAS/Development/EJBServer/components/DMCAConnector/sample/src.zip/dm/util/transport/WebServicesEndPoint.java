/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package dm.util.transport;

import dm.util.transport.HttpEndPoint;


/**
 * 
 * WebServices EndPoint Class.
 * Represents EndPoint for SOAP Protocol.
 *
 */
public class WebServicesEndPoint extends HttpEndPoint {

	private String soapActionUri;
	
	public WebServicesEndPoint(String host, int port) {
		super(host, port);
	}

	public String getSoapActionUri() {
		return soapActionUri;
	}

	public void setSoapActionUri(String soapActionUri) {
		this.soapActionUri = soapActionUri;
	}
	
	
	
	
	

}
