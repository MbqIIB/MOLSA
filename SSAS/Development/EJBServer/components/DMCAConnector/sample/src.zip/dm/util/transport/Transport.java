/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package dm.util.transport;

/**
 * Interface for Transport.
 *
 */
public interface Transport<L extends EndPoint> {
	
	/**
	 * Invokes a endpoint and pass the payload.
	 * @param endpoint EndPoint Object to invoke.
	 * @param payload  Payload Object to send via transport.
	 * @throws Exception
	 */
	void invoke(L endpoint, Object payload) throws Exception;

}
