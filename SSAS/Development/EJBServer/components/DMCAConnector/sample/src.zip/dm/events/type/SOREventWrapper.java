/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package dm.events.type;

import java.util.Calendar;
import java.util.Random;
import java.util.TimeZone;

import dm.events.Event;


/**
 * 
 * Wrapper for SOREvent object.
 *
 */
public class SOREventWrapper extends Event {

	private SOREvent event = new SOREvent();
	
	public SOREventWrapper() {
		// set unique message id.
		event.setMessageId( new Random().nextLong());
		Calendar c = Calendar.getInstance();
		TimeZone tz = c.getTimeZone();
		long offset = tz.getRawOffset();
		if (tz.inDaylightTime(c.getTime())) {
			offset = offset + tz.getDSTSavings();
		}
		event.setTimeZoneOffset(offset);
	}

	public SOREvent getEvent() {
		return event;
	}

	public void setEvent(SOREvent event) {
		this.event = event;
	}
	
	
	
	
	
	
}
