/*
 * Copyright 2014 Diona Technologies Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Diona
 * ("Confidential Information"). You shall not disclose such Confidential Information
 *  and shall use it only in accordance with the terms of the license agreement you
 *  entered into with Diona.
 */
package dm.events.curam;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import curam.util.resources.Configuration;
import dm.events.EventException;
import dm.util.transport.HttpEndPoint;
import dm.util.transport.HttpSender;
import dm.util.transport.Transport;

/*
 * Utility class to send event notification.
 */
public class DMNotificationHandler implements NotificationHandler {
	
			 
	/**
	 * constant for soap action.
	 */
	public static final String SOAP_ACTION_STRING =
			 "SOAPAction";
	/*
	 * constants for user agent.
	 */
	public static final String USER_AGENT =
			 "User-Agent";
	
	public static final String USER_AGENT_NAME =
			"Java Http Client";
	
	public static final String SOAP_OPERATION =
			"urn:createDMMessageAndNotify";
	
	public static final String ACCEPT_ENCODING =
			"Accept-Encoding";
	
	/*
	 * constants for soap binding start part.
	 */
    private static final String soapBindStart =
	            "<soapenv:Envelope"
	         + " xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" "
	         + "xmlns:ns2=\"http://dm.diona.com\">  "
	         + " <soapenv:Header/>   <soapenv:Body>  "
	         + "<ns2:DMMessageCreateRequest>";
	
    /*
     * constants for soap binding end part.
     */
    private static final String soapBindEnd 
           = "</ns2:DMMessageCreateRequest>"
    		+ "</soapenv:Body></soapenv:Envelope>";
	
	/**
	 * Handles all notification to remote SOR
	 * invoking notification webservice.
	 * @param event
	 * @throws EventException 
	 */
	public void handleNotification(
			dm.events.type.SOREvent event) throws EventException {
			String docXMLFragment = convertSOREventToDMXML(event);
			// use sender to send...
			// get url from local properties file.
			String url = "http://localhost:6001/NotificationService";
			String configUrl =   Configuration.getProperty(
				   "dm.notification.service.url");
			if(configUrl != null && configUrl.length() > 0)
			{
				url = configUrl;
			}
			   
			
			HttpEndPoint endpoint = new HttpEndPoint(url,0);
			endpoint.setUrlString(url);
			endpoint.addRequestHeader(ACCEPT_ENCODING, "gzip,deflate");
			endpoint.addRequestHeader(SOAP_ACTION_STRING, SOAP_OPERATION);
			endpoint.addRequestHeader(USER_AGENT,  USER_AGENT_NAME);	
			endpoint.setRequestMethod(HttpEndPoint.HTTP_POST_METHOD);
			Transport<HttpEndPoint> sender = new HttpSender();
			
			try {
				sender.invoke(endpoint, soapBindStart 
						+ docXMLFragment +soapBindEnd );
			} catch (Exception e) {
				throw new EventException(e);
			}
			
		
			
			// TODO 
			// process this offline.
			// for scenarios where a batch process triggers lots of notifications.
			// to use HTTPConnectionManager of httpclient.
			
	}

	
	private String convertSOREventToDMXML( dm.events.type.SOREvent event) {
		StringWriter swr = new StringWriter();
		try {
			Marshaller marshal = 
					 JAXBContext.newInstance(
							 "dm.events.type").createMarshaller();
	        // to neglect the xml prolog.
			marshal.setProperty(Marshaller.JAXB_FRAGMENT, true);
			marshal.marshal(event, swr);
		} catch (Throwable e) {
			throw new RuntimeException(e);
		}
		
		String retValue = swr.toString().replace("SOREvent", "message");
		System.out.println("sorevent = " + retValue);
		return retValue;
	}
	
	public static <T> T getInstance()  {
		T handler = null;
		
		String handlderClass =   Configuration.getProperty(
				   "dm.notification.service.NotificationHandlerClass");
		if (handlderClass == null) {
			handler = (T) new DMNotificationHandler();
		} else {
			
			try {
				Class<?> eventClass = Class.forName(handlderClass);
				final T resultObjecct = (T) eventClass.newInstance();
				handler = resultObjecct;
			} catch (ClassNotFoundException e) {
				throw new RuntimeException(
						"Error creating NotificationHandler instance ", e);
			} catch (InstantiationException e) {
				throw new RuntimeException(
						"Error creating NotificationHandler instance ", e);
			} catch (IllegalAccessException e) {
				throw new RuntimeException(
						"Error creating NotificationHandler instance ", e);
			}
			
		}
		
		return handler;
		
		
	}
	
}
