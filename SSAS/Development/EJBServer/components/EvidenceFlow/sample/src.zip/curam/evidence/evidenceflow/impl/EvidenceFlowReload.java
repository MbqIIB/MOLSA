/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidence.evidenceflow.impl;


import com.google.inject.ImplementedBy;

import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.StandardEntity;


/**
 * The EvidenceFlowReload is a means of determining if data of interest to the
 * <code>EvidenceFlow</code> has changed. A time stamp of the latest change is
 * maintained by the <code>EvidenceFlowReload</code>. Contributors of 'data' of
 * interest to the <code>EvidenceFlow</code> inform the
 * <code>EvidenceFlowReload</code> that data has changed thus causing the time
 * stamp to be updated. The <code>EvidenceFlowReload</code> can be queried to
 * see if a reload is required by passing in the time stamp that was last used
 * to retrieve the data.
 *
 * Note: In any long running transactions, or those involving CER attribute
 * calculations, it is recommended to inform the EvidenceFlowReload of the 
 * changed data via the <code>EvidenceFlowUtility.updateEvidenceFlow()</code>
 * method, which will automatically defer the updates until the end of the 
 * transaction. This helps to reduce contention for this table among
 * multiple threads.
 */
@ImplementedBy(EvidenceFlowReloadImpl.class)
public interface EvidenceFlowReload extends StandardEntity, Insertable {

  /**
   * Retrieves the Case Header for the associated case.
   *
   * @return the associated case's Case Header.
   */
  CaseHeader getCase();

  /**
   * Sets the case.
   *
   * @param caseHeader
   * The associated case's Case Header.
   */
  void setCase(CaseHeader caseHeader);

  /**
   * The EvidenceFlow data has changed therefore the lastUpdated field should be
   * modified to the current date time.
   *
   * Note: In any long running transactions, or those involving CER attribute
   * calculations, it is recommended to inform the EvidenceFlowReload of the 
   * changed data via the <code>EvidenceFlowUtility.updateEvidenceFlow()</code>
   * method, which will automatically defer the updates until the end of the 
   * transaction. This helps to reduce contention for this table among
   * multiple threads.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  void dataChanged() throws InformationalException;

  /**
   * Compares the time stamp passed in with the time stamp of this object and
   * determines if a reload is required.
   *
   * @param timeStamp
   * The time stamp used to compare with the currently held time stamp
   * to determine if a reload is required.
   *
   * @return true is returned if the currently held time stamp is greater than
   * the time stamp passed in, otherwise false is returned.
   */
  boolean shouldReload(final long timeStamp);

  /**
   * Retrieves the time stamp.
   *
   * @return the time stamp of the latest update.
   */
  long getTimeStamp();

}
