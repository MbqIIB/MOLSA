/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidence.evidenceflow.facade.impl;


import com.google.inject.Inject;

import curam.evidence.evidenceflow.impl.EvidenceFlowReload;
import curam.evidence.evidenceflow.impl.EvidenceFlowReloadDAO;
import curam.evidence.evidenceflow.stack.impl.CaseEvidenceStack;
import curam.evidence.evidenceflow.stack.impl.CaseEvidenceStackDAO;
import curam.evidence.evidenceflow.stack.impl.JDOMCaseEvidenceStack;
import curam.evidence.evidenceflow.facade.struct.PingKey;
import curam.evidence.evidenceflow.facade.struct.PingResult;
import curam.evidence.evidenceflow.facade.struct.StackID;
import curam.evidence.evidenceflow.facade.struct.StackKey;
import curam.evidence.evidenceflow.facade.struct.StackVersionNo;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This class is used to communicate with the EvidenceFlow widget.
 */
public class EvidenceFlow extends curam.evidence.evidenceflow.facade.base.EvidenceFlow {

  /**
   * Instance of the CaseEvidenceStackData DAO. 
   */
  @Inject
  protected CaseEvidenceStackDAO caseEvidenceStackDAO;

  /**
   * Instance of the EvidenceFlowReload DAO. 
   */
  @Inject
  protected EvidenceFlowReloadDAO evidenceFlowReloadDAO;

  /**
   * Instance of the CaseHeader DAO. 
   */
  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  /**
   * Constructor. Guice Set-up.
   */
  public EvidenceFlow() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a {@linkplain CaseEvidenceStack} record.
   *
   * @param key
   * The string representation of the modified
   * {@linkplain CaseEvidenceStack}.
   *
   * @return the id of the newly created {@linkplain CaseEvidenceStack}
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public StackID addStack(final StackKey key) throws AppException,
      InformationalException {

    // Create a new instance of the Case Evidence Stack object and assign it's
    // XML.
    final CaseEvidenceStack caseEvidenceStack = caseEvidenceStackDAO.newInstance();

    caseEvidenceStack.setXML(key.stackXML);

    caseEvidenceStack.insert();

    final StackID stackID = new StackID();

    stackID.stackID = caseEvidenceStack.getID();

    // Return the newly created stack's id.
    return stackID;

  }

  /**
   * Modifies the specified {@linkplain CaseEvidenceStack} with the updated
   * information detailed in the {@linkplain StackKey}.
   *
   * @param key
   * The string representation of the modified
   * {@linkplain CaseEvidenceStack}.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public StackVersionNo modifyStack(final StackKey key) throws AppException,
      InformationalException {

    // Create an instance of JDOMCaseEvidenceStack objects to query the
    // Case Evidence Stack's XML.
    final JDOMCaseEvidenceStack jdomCaseEvidenceStack = new JDOMCaseEvidenceStack(
      key.stackXML);

    final CaseEvidenceStack caseEvidenceStack = caseEvidenceStackDAO.get(
      jdomCaseEvidenceStack.getStackID());

    caseEvidenceStack.setXML(key.stackXML);

    caseEvidenceStack.modify(jdomCaseEvidenceStack.getVersionNo());

    // Assign the newly modified Case Evidence Stack's version number to the
    // return struct.
    final StackVersionNo stackVersionNo = new StackVersionNo();

    stackVersionNo.versionNo = caseEvidenceStack.getVersionNo();

    return stackVersionNo;

  }

  /**
   * Removes the specified {@linkplain CaseEvidenceStack}.
   *
   * @param key
   * The string representation of {@linkplain CaseEvidenceStack} to be
   * removed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void removeStack(final StackKey key) throws AppException,
      InformationalException {

    // Create an instance of JDOMCaseEvidenceStack objects to query the
    // Case Evidence Stack's XML.
    final JDOMCaseEvidenceStack jdomCaseEvidenceStack = new JDOMCaseEvidenceStack(
      key.stackXML);

    final CaseEvidenceStack caseEvidenceStack = caseEvidenceStackDAO.get(
      jdomCaseEvidenceStack.getStackID());

    caseEvidenceStack.remove(jdomCaseEvidenceStack.getVersionNo());

  }

  /**
   * Assesses whether any of the data displayed in the EvidenceFlow widget for a
   * case has changed since time specified in the input parameter.
   *
   * @param pingKey
   * The case id and the time stamp used to determine if the data has
   * been updated.
   *
   * @return A result of 'true' if the data to be displayed in the EvidenceFlow 
   * has changed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PingResult ping(final PingKey pingKey) throws AppException,
      InformationalException {

    final CaseHeader caseHeader = caseHeaderDAO.get(pingKey.caseID);

    final EvidenceFlowReload evidenceFlowReload = evidenceFlowReloadDAO.read(
      caseHeader);

    final PingResult pingResult = new PingResult();

    // Query the EvidenceFlowReload object to see if a reload is required.
    pingResult.hasDataChanged = evidenceFlowReload.shouldReload(
      pingKey.timeStamp);

    return pingResult;
  }

}
