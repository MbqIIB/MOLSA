/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidence.evidenceflow.impl;


import com.google.inject.AbstractModule;
import com.google.inject.TypeLiteral;
import com.google.inject.multibindings.Multibinder;

import curam.advisor.impl.AdviceConfigurationCacheImpl.PublicationHandler;
import curam.advisor.impl.AdvisorEvents;
import curam.core.sl.infrastructure.impl.TransactionPreCommitHandler;
import curam.creole.storage.database.RuleSetEditingManager;
import curam.evidence.impl.EvidenceFlowXMLBuilder;
import curam.util.persistence.PersistenceEvent;


/**
 * Guice module for EvidenceFlow.
 *
 * @deprecated since 6.0_SP2_EP10
 */
@Deprecated
public class Module extends AbstractModule {

  /**
   * {@inheritDoc}
   */
  @Override
  public void configure() {

    // Add bindings for event listeners required for the evidence flow reload
    // functionality.....

    // Add a binding to the listener for the AdviceItemCaseLink events.
    addAdviceItemCaseLinkBindings();

    // Add a binding to the listener for the AdviceItem events.
    addAdviceItemBindings();

    // Add the EvidenceFlowXML builder implementation binding.
    bind(EvidenceFlowXMLBuilder.class).to(JDOMEvidenceFlowXMLBuilder.class);

    // BEGIN, CR00295817, POB
    /*
     * register the transaction handler for pre commit processing
     */
    final Multibinder<TransactionPreCommitHandler> callbackHandlers = Multibinder.newSetBinder(
      binder(), new TypeLiteral<TransactionPreCommitHandler>() {// type
      // literal
      // -
      // intentionally
      // blank
    });

    callbackHandlers.addBinding().to(
      EvidenceFlowTransactionCallbackHandler.class);
    // END, CR00295817

    final Multibinder<AdvisorEvents> events = Multibinder.newSetBinder(binder(),
      new TypeLiteral<AdvisorEvents>() {// type
      // literal
      // -
      // intentionally
      // blank
    });

    events.addBinding().to(AdvisorRecalculationRequiredHandler.class);

  }

  /**
   * Adds the bindings to the {@link AdviceItemCaseLink}.
   *
   * @deprecated since 6.0_SP2_EP10
   */
  @Deprecated
  protected void addAdviceItemCaseLinkBindings() {

    final Multibinder<PersistenceEvent<curam.advisor.impl.AdviceItemCaseLink>> adviceItemCaseLinkEventListeners = Multibinder.newSetBinder(
      binder(),
      new TypeLiteral<PersistenceEvent<curam.advisor.impl.AdviceItemCaseLink>>() {/*
       * */});

    adviceItemCaseLinkEventListeners.addBinding().to(
      EvidenceFlowAdviceItemCaseLinkEventListener.class);
  }

  /**
   * Adds the bindings to the {@link AdviceItem}.
   *
   * @deprecated since 6.0_SP2_EP10
   */
  @Deprecated
  protected void addAdviceItemBindings() {

    final Multibinder<PersistenceEvent<curam.advisor.impl.AdviceItem>> adviceItemEventListeners = Multibinder.newSetBinder(
      binder(),
      new TypeLiteral<PersistenceEvent<curam.advisor.impl.AdviceItem>>() {/*
       * */});

    adviceItemEventListeners.addBinding().to(
      EvidenceFlowAdviceItemEventListener.class);
  }

}
