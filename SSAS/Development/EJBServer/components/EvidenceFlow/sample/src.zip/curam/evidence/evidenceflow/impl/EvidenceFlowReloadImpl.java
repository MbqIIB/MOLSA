/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidence.evidenceflow.impl;


import com.google.inject.Inject;

import curam.evidence.evidenceflow.entity.struct.EvidenceFlowReloadDtls;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Implementation of the {@link EvidenceFlowReload} interface.
 */
public class EvidenceFlowReloadImpl extends SingleTableEntityImpl<EvidenceFlowReloadDtls> implements EvidenceFlowReload {

  /**
   * Instance of the CaseHeader DAO. 
   */
  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  /**
   * {@inheritDoc}
   */
  public CaseHeader getCase() {

    return caseHeaderDAO.get(getDtls().caseID);
  }

  /**
   * {@inheritDoc}
   */
  public long getTimeStamp() {

    return getDtls().lastUpdated;
  }

  /**
   * {@inheritDoc}
   */
  public void setCase(final CaseHeader caseHeader) {
    getDtls().caseID = caseHeader.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {

    // Set the latestUpated field to the current date time.
    getDtls().lastUpdated = System.currentTimeMillis();

  }

  /**
   * {@inheritDoc}
   *
   */
  public void dataChanged() throws InformationalException {

    // Set the latestUpated field to the current date time.
    getDtls().lastUpdated = System.currentTimeMillis();

    super.modify();

  }

  /**
   * {@inheritDoc}
   */
  public boolean shouldReload(final long timeStamp) {

    boolean shouldReload = false;

    // If the current time stamp is later than the time stamp being passed in
    // then a reload is required.
    if (getDtls().lastUpdated > timeStamp) {
      shouldReload = true;
    }

    return shouldReload;
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No cross entity validations defined.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No cross field validations defined.
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No mandatory field validations defined.
  }

}
