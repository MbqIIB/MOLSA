/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidence.evidenceflow.impl;


import com.google.inject.Singleton;

import curam.codetable.impl.ADVICECATEGORYEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.PersistenceEvent;


/**
 * On post insert of an {@link AdviceItemCaseLink} if the {@link AdviceItem}
 * being linked is of type
 * <ul>
 * <li><code>ADVICECATEGORYEntry.ISSUES</code></li>, or
 * <li><code>ADVICECATEGORYEntry.REMINDERS</code></li>
 * </ul>
 *
 * the {@link EvidenceFlowReload}'s time stamp associated with the
 * {@link AdviceItemCaseLink}'s case is updated.
 *
 * @deprecated since 6.0_SP2_EP10 due to a new storage mechanism being
 * introduced for advice.
 */
@Singleton
@Deprecated
final class EvidenceFlowAdviceItemCaseLinkEventListener extends PersistenceEvent<curam.advisor.impl.AdviceItemCaseLink> {

  /**
   * Updates the {@link EvidenceFlowReload}'s time stamp associated with the
   * {@link AdviceItemCaseLink}'s case if the {@link AdviceItem} being linked is
   * of either type
   * <ul>
   * <li><code>ADVICECATEGORYEntry.ISSUES</code></li>
   * <li><code>ADVICECATEGORYEntry.REMINDERS</code></li>
   * </ul>
   *
   * @param adviceItemCaseLink
   * The {@link AdviceItemCaseLink} that has just been inserted.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated since 6.0_SP2_EP10.
   */
  @Override
  @Deprecated
  public void postInsert(final curam.advisor.impl.AdviceItemCaseLink adviceItemCaseLink)
    throws AppException, InformationalException {

    final curam.advisor.impl.AdviceItem adviceItem = adviceItemCaseLink.getAdviceItem();

    // Inform the EvidenceFlowReload object related to this case that the data
    // has changed, if an insert of an issue or reminder has just taken place,
    // thus updating the time stamp.
    if (adviceItem.getCategoryType().equals(ADVICECATEGORYEntry.ISSUES)
      || adviceItem.getCategoryType().equals(ADVICECATEGORYEntry.REMINDERS)) {

      // Only process if the case id has been set.
      if (adviceItemCaseLink.getCaseID() != 0) {
        // BEGIN, CR00295817, POB
        EvidenceFlowUtility.updateEvidenceFlow(
          adviceItemCaseLink.getCaseID().longValue());
        // END, CR00295817
      }
    }

  }

  /**
   * Updates the {@link EviednceFlowReload}'s time stamp associated with the
   * {@link AdviceItemCaseLink}'s case if the linked {@link AdviceItem} is
   * of either type
   * <ul>
   * <li><code>ADVICECATEGORYEntry.ISSUES</code></li>
   * <li><code>ADVICECATEGORYEntry.REMINDERS</code></li>
   * </ul>
   *
   * @param adviceItemCaseLink
   * The {@link AdviceItemCaseLink} that has just been modified.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated since 6.0_SP2_EP10.
   */
  @Override
  @Deprecated
  public void postModify(final curam.advisor.impl.AdviceItemCaseLink adviceItemCaseLink)
    throws AppException, InformationalException {

    final curam.advisor.impl.AdviceItem adviceItem = adviceItemCaseLink.getAdviceItem();

    // Inform the EvidenceFlowReload object related to this case that the data
    // has changed, if an insert of an issue or reminder has just taken place,
    // thus updating the time stamp.
    if (adviceItem.getCategoryType().equals(ADVICECATEGORYEntry.ISSUES)
      || adviceItem.getCategoryType().equals(ADVICECATEGORYEntry.REMINDERS)) {

      // Only process if the case id has been set.
      if (adviceItemCaseLink.getCaseID() != 0) {
        // BEGIN, CR00295817, POB
        EvidenceFlowUtility.updateEvidenceFlow(
          adviceItemCaseLink.getCaseID().longValue());
        // END, CR00295817

      }
    }
  }
}
