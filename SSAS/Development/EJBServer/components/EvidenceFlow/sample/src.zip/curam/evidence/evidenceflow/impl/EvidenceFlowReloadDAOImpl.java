/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidence.evidenceflow.impl;


import com.google.inject.Singleton;

import curam.evidence.evidenceflow.entity.impl.EvidenceFlowReloadAdapter;
import curam.evidence.evidenceflow.entity.struct.EvidenceFlowReloadDtls;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;


/**
 * Implementation of {@linkplain EvidenceFlowReloadDAO} interface.
 *
 */
@Singleton
final class EvidenceFlowReloadDAOImpl extends StandardDAOImpl<EvidenceFlowReload, EvidenceFlowReloadDtls> implements
  EvidenceFlowReloadDAO {

  /**
   * Single instance of the entity adapter shared across all DAO
   * implementations.
   */
  protected static final EvidenceFlowReloadAdapter kAdapter = new EvidenceFlowReloadAdapter();

  /**
   * @see StandardDAOImpl.
   */
  protected EvidenceFlowReloadDAOImpl() {
    super(kAdapter, EvidenceFlowReload.class);
  }

  /**
   * {@inheritDoc}
   *
   */
  public EvidenceFlowReload read(final CaseHeader caseHeader)
    throws InformationalException {

    final EvidenceFlowReloadDtls evidenceFlowReloadDtls = kAdapter.readByCaseID(
      caseHeader.getID());

    // If no reload object exists, create one and return it.
    if (null == evidenceFlowReloadDtls) {

      final EvidenceFlowReload evidenceFlowReload = this.newInstance();

      evidenceFlowReload.setCase(caseHeader);

      evidenceFlowReload.insert();

      return evidenceFlowReload;

    } else {

      // BEGIN, CR00263893, JS
      // Return the existing EvidenceFlowReload object.
      return getEntity(evidenceFlowReloadDtls);
      // END, CR00263893
    }

  }

}
