/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidence.evidenceflow.stack.impl;

import com.google.inject.ImplementedBy;

import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.OptimisticLockRemovable;
import curam.util.persistence.StandardEntity;

/**
 * A representation of an Evidence stack that has been created by the user.
 */
@ImplementedBy(CaseEvidenceStackImpl.class)
public interface CaseEvidenceStack extends StandardEntity, Insertable,
    OptimisticLockModifiable, OptimisticLockRemovable {

  /**
   * Sets XML representation of the Case Evidence Stack.
   * 
   * TODO: Put a link to the schema or document the schema in here.
   * 
   * @param xml
   *          The XML representation of the Case Evidence Stack.
   * 
   */
  void setXML(String xml);

  /**
   * Retrieves the Case Header for the associated case.
   * 
   * @return the associated case's Case Header.
   * 
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  CaseHeader getCase();

  /**
   * Retrieves the Case Evidence Stack's name.
   * 
   * @return the Case Evidence Stack's name.
   */
  String getName();

  /**
   * Retrieves the name of the user who owns (or created) the Case Evidence
   * Stack.
   * 
   * @return the Case Evidence Stack owner's name.
   */
  String getUsername();

  /**
   * Retrieves XML representation of the Case Evidence Stack.
   * 
   * @return the XML representation of the Case Evidence Stack.
   * 
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  String getXML() throws InformationalException;

}
