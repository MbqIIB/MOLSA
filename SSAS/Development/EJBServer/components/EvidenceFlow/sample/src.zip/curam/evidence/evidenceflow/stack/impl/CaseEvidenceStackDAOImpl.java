/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidence.evidenceflow.stack.impl;


import java.util.Set;

import com.google.inject.Singleton;

import curam.evidence.evidenceflow.stack.entity.impl.CaseEvidenceStackAdapter;
import curam.evidence.evidenceflow.stack.entity.struct.CaseEvidenceStackDtls;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.user.impl.User;
import curam.util.persistence.StandardDAOImpl;


/**
 * Implementation of {@linkplain CaseEvidenceStackDAO} interface
 *
 */
@Singleton
final class CaseEvidenceStackDAOImpl extends StandardDAOImpl<CaseEvidenceStack, CaseEvidenceStackDtls> implements
  CaseEvidenceStackDAO {

  /**
   * Single instance of the entity adapter shared across all DAO
   * implementations.
   */
  protected static final CaseEvidenceStackAdapter kAdapter = new CaseEvidenceStackAdapter();

  /**
   * @see StandardDAOImpl
   */
  protected CaseEvidenceStackDAOImpl() {
    super(kAdapter, CaseEvidenceStack.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<CaseEvidenceStack> search(final User user,
    final CaseHeader caseHeader) {

    return newUnmodifiableSet(
      kAdapter.searchByUsernameAndCaseID(user.getUsername(), caseHeader.getID()));
  }
}
