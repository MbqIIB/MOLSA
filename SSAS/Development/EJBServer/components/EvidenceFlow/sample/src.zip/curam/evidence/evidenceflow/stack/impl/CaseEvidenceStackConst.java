/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidence.evidenceflow.stack.impl;


/**
 * Constants used by the Case Evidence Stack implementation.
 *
 */
public class CaseEvidenceStackConst {

  /**
   * The string used as the name attribute in the Case Evidence Stack XML.
   */
  public static final String kName = "name";

  /**
   * The string used as the primary id attribute in the Case Evidence Stack XML.
   */
  public static final String kPrimaryID = "primaryid";

  /**
   * The string used as the type attribute in the Case Evidence Stack XML.
   */
  public static final String kType = "type";

  /**
   * The string used as the version attribute in the Case Evidence Stack XML.
   */
  public static final String kVersion = "version";

  /**
   * The string used as the case id attribute in the Case Evidence Stack XML.
   */
  public static final String kCaseID = "caseid";

  /**
   * The string used as the value for the type attribute in the Case Evidence
   * Stack XML.
   */
  public static final String kUser = "user";

  /**
   * The path to the {@linkplain CaseEvidenceStack} schema used for validating
   * XML representations of the same.
   */
  public static final String kCaseEvidenceStackSchema = "curam/evidence/evidenceflow/stack/impl/CaseEvidenceStack.xsd";

  /**
   * protected constructor to prevent instantiation.
   */
  protected CaseEvidenceStackConst() {// Can't instantiate constant class.
  }

}
