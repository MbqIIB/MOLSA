/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidence.evidenceflow.stack.impl;


import java.util.Arrays;

import com.google.inject.Inject;

import curam.evidence.evidenceflow.stack.entity.impl.CaseEvidenceStackDataAdapter;
import curam.evidence.evidenceflow.stack.entity.struct.CaseEvidenceStackDataDtls;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Implementation of the {@link CaseEvidenceStackData} interface.
 */
final class CaseEvidenceStackDataImpl extends SingleTableEntityImpl<CaseEvidenceStackDataDtls> implements
  CaseEvidenceStackData {

  /**
   * Instance of the CaseEvidenceStackData DAO. 
   */
  @Inject
  protected CaseEvidenceStackDataDAO caseEvidenceStackDataDAO;

  /**
   * Variable containing the data XML 
   */
  protected transient String xml;

  /**
   * {@inheritDoc}
   */
  public String getData() {

    if (xml == null) {

      final CaseEvidenceStackData overflow = this.getOverflow();

      if (overflow == null) {
        xml = getDtls().data;
      } else {

        // recurse through the overflow records
        xml = pad(getDtls().data) + overflow.getData();
      }
    }

    return xml;
  }

  /**
   * Retrieve the overflow {@linkplain CaseEvidenceStackData}
   *
   * @return the {@linkplain CaseEvidenceStackData} record if an overflow exists
   * otherwise null is returned.
   */
  protected CaseEvidenceStackData getOverflow() {
    final long overflowID = getDtls().overflowID;

    return (overflowID == 0 ? null : caseEvidenceStackDataDAO.get(overflowID));
  }

  /**
   * {@inheritDoc}
   */
  public void setData(final String data) {
    xml = data;
  }

  /**
   * Set the overflow {@linkplain CaseEvidenceStackData}
   *
   * @param value
   * the overflow {@linkplain CaseEvidenceStackData} record.
   */
  protected void setOverflow(final CaseEvidenceStackData value) {
    getDtls().overflowID = (value == null ? 0L : value.getID());

  }

  @Override
  public void insert() throws InformationalException {

    // Store the XML over multiple rows if necessary
    if (xml.length() > CaseEvidenceStackDataAdapter.kMaxLength_data) {

      final String firstSegment = xml.substring(0,
        CaseEvidenceStackDataAdapter.kMaxLength_data);

      final String remainingSegments = xml.substring(
        CaseEvidenceStackDataAdapter.kMaxLength_data);

      // This record stores only the first segment
      getDtls().data = firstSegment;

      // store the remaining segments
      final CaseEvidenceStackData overflowCaseEvidenceStackData = caseEvidenceStackDataDAO.newInstance();

      overflowCaseEvidenceStackData.setData(remainingSegments);
      overflowCaseEvidenceStackData.insert();

      setOverflow(overflowCaseEvidenceStackData);

    } else {

      // This record can store the entire data
      setOverflow(null);
      getDtls().data = xml;
    }

    super.insert();
  }

  @Override
  public void modify() throws InformationalException {

    // get the existing overflow, if any
    final CaseEvidenceStackData overflow = getOverflow();

    // detect if the XML is longer than the maximum allowed
    if (xml.length() > CaseEvidenceStackDataAdapter.kMaxLength_data) {
      // split the XML between this record and one or more
      // overflow rows

      final String firstSegment = xml.substring(0,
        CaseEvidenceStackDataAdapter.kMaxLength_data);

      final String remainingSegments = xml.substring(
        CaseEvidenceStackDataAdapter.kMaxLength_data);

      if (overflow == null) {

        // create the overflow record(s)
        final CaseEvidenceStackData newOverflow = caseEvidenceStackDataDAO.newInstance();

        newOverflow.setData(remainingSegments);
        newOverflow.insert();

        // set the overflow id
        setOverflow(newOverflow);
      } else {
        // modify the existing overflow
        overflow.setData(remainingSegments);
        overflow.modify();
      }

      // this record stores only the first segment
      getDtls().data = firstSegment;
      super.modify();

    } else {
      // this record can store the whole XML
      getDtls().data = xml;
      // clear the pointer to the overflow
      setOverflow(null);

      super.modify();

      // remove any existing overflow
      if (overflow != null) {
        overflow.remove();

      }

    }

  }

  @Override
  public void remove() throws InformationalException {

    /*
     * remove any overflow record (which will cascade to other overflows as
     * necessary)
     */
    final CaseEvidenceStackData overflow = getOverflow();

    if (overflow != null) {
      overflow.remove();
    }

    super.remove();

  }

  /**
   * Increases the supplied String's length to the maximum field length, by
   * right-padding with spaces.
   *
   * @param value
   * the String to pad.
   *
   * @return the padded String.
   */
  protected String pad(final String value) {
    final char[] pad = new char[CaseEvidenceStackDataAdapter.kMaxLength_data - value.length()];

    Arrays.fill(pad, ' ');

    return value + new String(pad);

  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No validations of this type have been identified.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No validations of this type have been identified.
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No validations of this type have been identified.
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// No validations of this type have been identified.
  }

}
