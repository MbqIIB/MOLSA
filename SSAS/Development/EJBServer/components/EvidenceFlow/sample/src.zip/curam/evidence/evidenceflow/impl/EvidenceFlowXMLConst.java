/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidence.evidenceflow.impl;


/**
 * Constants for use by <code>EvidenceFlowXMLBuilder</code>.
 *
 */
public final class EvidenceFlowXMLConst {

  /**
   * The name of the scroll bar property used in the evidence flow widget.
   */
  public static final String kOfProperty = "scrollbar.of.label";
  
  /**
   * The name of the scroll bar property used in the evidence flow widget.
   */
  public static final String kLocale = "locale";  
  
  /**
   * The name of the first error property used in the evidence flow widget.
   */
  public static final String kErrorCode101Property = "ERROR_CODE_101"; 
  
  /**
   * The name of the second error property used in the evidence flow widget.
   */
  public static final String kErrorCode102Property = "ERROR_CODE_102";
  
  /**
   * The name of the third error property used in the evidence flow widget.
   */
  public static final String kErrorCode103Property = "ERROR_CODE_103";    
  
  /**
   * The name of the fourth error property used in the evidence flow widget.
   */
  public static final String kErrorCode104Property = "ERROR_CODE_104";  
  
  /**
   * The name of the fifth error property used in the evidence flow widget.
   */
  public static final String kErrorCode105Property = "ERROR_CODE_105"; 
  
  /**
   * The name of the new stack property used in the evidence flow widget.
   */
  public static final String kNewStackProperty = "new.stack.label";  
  
  /**
   * The name of the property used in the evidence flow widget to inform the
   * user the stack name used is not unique.
   */
  public static final String kStackNameNotUniqueProperty = "stack.name.in.use.msg";   
  
  /**
   * The name of the property used in the evidence flow widget to inform the
   * user the stack name was not entered.
   */
  public static final String kStackNameNotEntered = "stack.name.min.length.msg";   
  
  /**
   * The property <code>String</code>.
   */
  public static final String kProperty = "property";
   
  /**
   * The properties <code>String</code>.
   */
  public static final String kProperties = "properties";  
  
  /**
   * The stack <code>String</code>.
   */
  public static final String kStack = "stack";

  /**
   * The stacks <code>String</code>.
   */
  public static final String kStacks = "stacks";

  /**
   * The evidence flow <code>String</code>.
   */
  public static final String kEvidenceFlow = "evidenceflow";

  /**
   * The banner item left <code>String</code>.
   */
  public static final String kBannerItemLeft = "banneritemleft";

  /**
   * The flag <code>String</code>.
   */
  public static final String kFlag = "flag";

  /**
   * The time stamp <code>String</code>.
   */
  public static final String kTimeStamp = "timestamp";

  /**
   * The case id <code>String</code>.
   */
  public static final String kCaseID = "caseid";

  /**
   * The type <code>String</code>.
   */
  public static final String kType = "type";

  /**
   * The name <code>String</code>.
   */
  public static final String kName = "name";

  /**
   * The system <code>String</code>.
   */
  public static final String kSystem = "system";

  /**
   * The target <code>String</code>.
   */
  public static final String kTarget = "target";

  /**
   * The verifications <code>String</code>.
   */
  public static final String kVerifications = "verifications";

  /**
   * The reminders <code>String</code>.
   */
  public static final String kReminders = "reminders";

  /**
   * The value <code>String</code>.
   */
  public static final String kValue = "value";

  /**
   * The display item <code>String</code>.
   */
  public static final String kDisplayItem = "displayitem";

  /**
   * The issues item <code>String</code>.
   */
  public static final String kIusses = "issues";

  /**
   * The id <code>String</code>.
   */
  public static final String kId = "id";

  /**
   * The cover <code>String</code>.
   */
  public static final String kCover = "cover";

  /**
   * The cover ref <code>String</code>.
   */
  public static final String kCoverRef = "coverref";

  /**
   * The reference <code>String</code>.
   */
  public static final String kReference = "reference";

  /**
   * The cover delay <code>String</code>.
   */
  public static final String kCoverDelay = "coverdelay";

  /**
   * The polling interval <code>String</code>.
   */
  public static final String kPollingInteval = "pollinginterval";

  /**
   * The number of milliseconds in an hour.
   */
  public static final int kHourInMilliseconds = 3600000;

  /**
   * The number of milliseconds in a minute.
   */
  public static final int kMinuteInMilliseconds = 60000;

  /**
   * The default cover <code>String</code>.
   */
  public static final String kDefaultCover = "defaultcover";

  /**
   * The accordion entry <code>String</code>.
   */
  public static final String kAccordionEntry = "accordionentry";

  /**
   * The Evidence resolve workspace uim. 
   */
  public static final String kEvidenceResolvePage = "Evidence_resolveWorkspace";

  /**
   * The Evidence workspace URL format, used to generate the workspace URL for
   * evidence types.
   */
  public static final String kEvidenceWorkspaceURLFormat = "{0}Page.do?caseID={1}&evidenceType={2}&o3ctx=135168";
  
  /**
   * The no cover <code>String</code> used as the evidence flow default when
   * no evidence types have been configured for the given case.
   */
  public static final String kNoCover = "NOCOVER";  

  /**
   * protected constructor to prevent instantiation.
   */
  protected EvidenceFlowXMLConst() {// Can't instantiate constant class.
  }

}
