/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidence.evidenceflow.impl;


import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.util.events.impl.EventFilter;
import curam.util.events.impl.EventHandler;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.verification.sl.infrastructure.entity.fact.VDIEDLinkFactory;
import curam.verification.sl.infrastructure.entity.fact.VerificationFactory;
import curam.verification.sl.infrastructure.entity.intf.VDIEDLink;
import curam.verification.sl.infrastructure.entity.intf.Verification;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkDtls;
import curam.verification.sl.infrastructure.entity.struct.VDIEDLinkKey;
import curam.verification.sl.infrastructure.entity.struct.VerificationDtls;
import curam.verification.sl.infrastructure.entity.struct.VerificationKey;


/**
 * This event handler listens for the
 * {@link curam.events.Verification#VerificationSatisified} event and updates
 * the {@link EvidenceFlowReload} for the case linked to the 
 * {@link Verification}.
 *
 */
public class EvidenceFlowVerificationHandler implements EventHandler,
  EventFilter {

  /**
   * Constructor 
   */
  public EvidenceFlowVerificationHandler() {
    super();

  }

  /**
   * Updates the {@link EvidenceFlowReload} for the case linked to the
   * {@link Verification} the event was raised for.
   *
   * @param event
   * The event that has been raised.
   */
  public void eventRaised(final Event event) throws AppException,
      InformationalException {

    // The case id is required so that the EvidenceFlowReload for the case
    // linked to the verification can be updated. So retrieve the case id.....
    final Verification verificationObj = VerificationFactory.newInstance();
    final VerificationKey verificationKey = new VerificationKey();

    verificationKey.verificationID = event.primaryEventData;

    final VerificationDtls verificationDtls = verificationObj.read(
      verificationKey);

    final VDIEDLink vdiedLinkObj = VDIEDLinkFactory.newInstance();
    final VDIEDLinkKey vdiedLinkKey = new VDIEDLinkKey();

    vdiedLinkKey.VDIEDLinkID = verificationDtls.VDIEDLinkID;

    final VDIEDLinkDtls vdiedLinkDtls = vdiedLinkObj.read(vdiedLinkKey);

    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();
    
    evidenceDescriptorKey.evidenceDescriptorID = vdiedLinkDtls.evidenceDescriptorID;

    final EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj.read(
      evidenceDescriptorKey);
    
    // Only attempt to retrieve/update the EvidenceFlowReload if the case id is
    // populated on the evidence descriptor. This means the verification details
    // has been configured for case level data.
    if (evidenceDescriptorDtls.caseID != 0) {
      
      // BEGIN, CR00295817, POB
      EvidenceFlowUtility.updateEvidenceFlow(evidenceDescriptorDtls.caseID);
      // END, CR00295817
    }
  }

  /**
   * Accepts the {@link curam.events.Verification#VerificationSatisified} event.
   *
   * @param event
   * The event that has been raised.
   *
   * @return True is returned if the event is of type
   * {@link curam.events.Verification#VerificationSatisified}, otherwise
   * false is returned.
   */
  public boolean accept(final Event event) throws AppException,
      InformationalException {

    if ((event.eventKey.eventClass.equals(
      curam.events.Verification.VerificationSatisified.eventClass))
        && (event.eventKey.eventType.equals(
          curam.events.Verification.VerificationSatisified.eventType))
            || (event.eventKey.eventClass.equals(
              curam.events.Verification.VerificationInserted.eventClass))
                && (event.eventKey.eventType.equals(
                  curam.events.Verification.VerificationInserted.eventType))) {
      return true;
    }

    return false;
  }

}
