/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidence.evidenceflow.stack.impl;

import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.user.impl.User;
import curam.util.persistence.StandardDAO;

/**
 * Data access object for the {@link CaseEvidenceStack} entity.
 */
@ImplementedBy(CaseEvidenceStackDAOImpl.class)
public interface CaseEvidenceStackDAO extends StandardDAO<CaseEvidenceStack> {

  /**
   * Retrieves all the {@linkplain CaseEvidenceStack}'s for a particular user on
   * a specified case.
   * 
   * @param user
   *          The user for whom the {@linkplain CaseEvidenceStack}'s are sought.
   * 
   * @param caseHeader
   *          The case header for the case which the
   *          {@linkplain CaseEvidenceStack}'s are sought.
   * 
   * @return An unmodifiable set of {@linkplain CaseEvidenceStack}'s for the
   *         specified user name and case id.
   */
  Set<CaseEvidenceStack> search(User user, CaseHeader caseHeader);

}
