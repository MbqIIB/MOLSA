/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidence.evidenceflow.stack.impl;


import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;

import javax.xml.XMLConstants;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import javax.xml.validation.Validator;

import org.xml.sax.SAXException;

import com.google.inject.Inject;

import curam.evidence.evidenceflow.stack.message.GENCASEEVIDENCESTACK;
import curam.evidence.evidenceflow.stack.message.impl.GENCASEEVIDENCESTACKExceptionCreator;
import curam.evidence.evidenceflow.stack.entity.struct.CaseEvidenceStackDtls;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.transaction.TransactionInfo;


/**
 * Implementation of the {@link CaseEvidenceStack} interface.
 */
public class CaseEvidenceStackImpl extends SingleTableEntityImpl<CaseEvidenceStackDtls> implements CaseEvidenceStack {

  /**
   * Instance of the CaseHeader DAO.
   */
  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  /**
   * Instance of the CaseEvidenceStackData DAO.
   */
  @Inject
  protected CaseEvidenceStackDataDAO caseEvidenceStackDataDAO;

  /**
   * The XML representation of the Case Evidence Stack minus the stack element
   * attributes.
   */
  protected String strippedXML = "";

  /**
   * A JDOM classed used to manipulate the XML representation of
   * {@link CaseEvidenceStack}.
   */
  protected JDOMCaseEvidenceStack jdomCaseEvidenceStack;

  /**
   * {@inheritDoc}
   *
   */
  public void setXML(final String xml) {

    // The XML must not be null.
    if (xml == null) {

      final AppRuntimeException exception = new AppRuntimeException(
        GENCASEEVIDENCESTACKExceptionCreator.ERR_CASE_EVIDENCE_STACK_XML_NULL());

      throw exception;

    } else {

      // Validate the XML against its schema if this setting is enabled.
      if (isValidateAgainstSchemaOnSetDataEnabled()) {
        validateXMLAgainstSchema(xml);
      }

      jdomCaseEvidenceStack = new JDOMCaseEvidenceStack(xml);

      // Set the name and case attributes based on the XML.
      setDatabaseAttributes(jdomCaseEvidenceStack);

      // Strip the attributes out from the stack element in the XML.
      jdomCaseEvidenceStack.removeCaseID();
      jdomCaseEvidenceStack.removeName();
      jdomCaseEvidenceStack.removeStackID();
      jdomCaseEvidenceStack.removeType();
      jdomCaseEvidenceStack.removeVersionNo();
      strippedXML = jdomCaseEvidenceStack.getXML();
    }

  }

  /**
   * Reads the environment variable
   * <code>ENV_VALIDATE_STACK_DATA_AGAINST_SCHEMA_ON_SET</code> to see if
   * validation of the {@link CaseEvidenceStack} XML against it's schema is
   * enabled when the XML is being set.
   *
   * @return true if the XML should be validated against it's schema, or false
   * if it should not be.
   */
  protected boolean isValidateAgainstSchemaOnSetDataEnabled() {

    Boolean validateEnabled = new Boolean(
      curam.util.resources.Configuration.getBooleanProperty(
        curam.core.impl.EnvVars.ENV_VALIDATE_STACK_DATA_AGAINST_SCHEMA_ON_SET));

    if (validateEnabled == false) {

      validateEnabled = new Boolean(
        curam.util.resources.Configuration.getBooleanProperty(
          curam.core.impl.EnvVars.ENV_VALIDATE_STACK_DATA_AGAINST_SCHEMA_ON_SET_DEFAULT));
    }

    return validateEnabled.booleanValue();
  }

  /**
   * Reads the environment variable
   * <code>ENV_VALIDATE_STACK_DATA_AGAINST_SCHEMA_ON_RETRIEVAL</code> to see if
   * validation of the {@link CaseEvidenceStack} XML against it's schema is
   * enabled when the XML is being retrieved.
   *
   * @return true if the XML should be validated against it's schema, or false
   * if it should not be.
   */
  protected boolean isValidateAgainstSchemaOnRetrieveDataEnabled() {

    Boolean validateEnabled = new Boolean(
      curam.util.resources.Configuration.getBooleanProperty(
        curam.core.impl.EnvVars.ENV_VALIDATE_STACK_DATA_AGAINST_SCHEMA_ON_RETRIEVAL));

    if (validateEnabled == false) {

      validateEnabled = new Boolean(
        curam.util.resources.Configuration.getBooleanProperty(
          curam.core.impl.EnvVars.ENV_VALIDATE_STACK_DATA_AGAINST_SCHEMA_ON_RETRIEVAL_DEFAULT));
    }

    return validateEnabled.booleanValue();
  }

  /**
   * Sets the name of the Case Evidence Stack.
   *
   * @param name
   * The name of the Case Evidence Stack.
   */
  void setName(final String name) {
    getDtls().name = name;
  }

  /**
   * Sets case associated to the Case Evidence Stack.
   *
   * @param caseHeader
   * The Case Header for the associated case.
   */
  void setCase(final CaseHeader caseHeader) {
    getDtls().caseID = caseHeader.getID();
  }

  /**
   * Sets the {@link CaseEvidenceStackData} id
   *
   * @param caseEvidenceStackData
   * The Case Evidence Stack Data, which is an XML representation of
   * the contents of the stack.
   */
  protected void setCaseEvidenceStackData(
    final CaseEvidenceStackData caseEvidenceStackData) {

    getDtls().caseEvidenceStackDataID = caseEvidenceStackData.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {

    // Set the current user to be the user associated with the stack.
    getDtls().username = TransactionInfo.getInfo().getInfoProgramUser();

  }

  /**
   * Sets the other required attributes of {@link CaseEvidenceStack} based on
   * the values in the XML. Attributes such as username and case id.
   *
   * @param jdomCaseEvidenceStack
   * The XML representation of the Case Evidence Stack.
   *
   * @throws AppRuntimeException
   * Generic Exception Signature.
   */
  protected void setDatabaseAttributes(
    final JDOMCaseEvidenceStack jdomCaseEvidenceStack)
    throws AppRuntimeException {

    // Get the name attribute value and use it to set the name on this
    // {@link CaseEvidenceStack}.
    final String name = jdomCaseEvidenceStack.getName();

    validateName(name);
    setName(name);

    // Get the case id attribute value and use it to set the case id on this
    // {@link CaseEvidenceStack}.
    final Long caseID = jdomCaseEvidenceStack.getCaseID();

    validateCaseID(caseID);

    final CaseHeader caseHeader = caseHeaderDAO.get(caseID);

    setCase(caseHeader);

  }

  /**
   * {@inheritDoc}
   */
  public CaseHeader getCase() {
    return caseHeaderDAO.get(getDtls().caseID);
  }

  /**
   * {@inheritDoc}
   */
  public String getName() {
    return getDtls().name;
  }

  /**
   * {@inheritDoc}
   */
  public String getUsername() {
    return getDtls().username;
  }

  /**
   * {@inheritDoc}
   *
   */
  public String getXML() throws InformationalException {

    final String xml = caseEvidenceStackDataDAO.get(getDtls().caseEvidenceStackDataID).getData();

    jdomCaseEvidenceStack = new JDOMCaseEvidenceStack(xml);

    // Add the stack attributes back into the XML, this attributes are required
    // by the Evidence Flow widget.
    jdomCaseEvidenceStack.setCaseID(getDtls().caseID);
    jdomCaseEvidenceStack.setName(getDtls().name);
    jdomCaseEvidenceStack.setStackID(getDtls().caseEvidenceStackID);
    jdomCaseEvidenceStack.setType(CaseEvidenceStackConst.kUser);
    jdomCaseEvidenceStack.setVersionNo(getDtls().versionNo);

    // Validate the XML against its schema if this setting is enabled.
    if (isValidateAgainstSchemaOnRetrieveDataEnabled()) {
      validateXMLAgainstSchema(jdomCaseEvidenceStack.getXML());
    }

    return jdomCaseEvidenceStack.getXML();
  }

  @Override
  public void insert() throws InformationalException {

    try {
      storeXML();
    } catch (final Exception e) {

      final AppException appExecption = new AppException(
        GENCASEEVIDENCESTACK.ERR_ON_INSERT, e);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        appExecption,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      ValidationHelper.failIfErrorsExist();

    }
    super.insert();
  }

  @Override
  public void modify(final Integer versionNo) throws InformationalException {

    try {
      modifyXML();
    } catch (final Exception e) {

      final AppException appExecption = new AppException(
        GENCASEEVIDENCESTACK.ERR_ON_MODIFY, e);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        appExecption,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      ValidationHelper.failIfErrorsExist();
    }
    super.modify(versionNo);

  }

  @Override
  public void remove(final Integer versionNo) throws InformationalException {

    final CaseEvidenceStackData caseEvidenceStackData = caseEvidenceStackDataDAO.get(
      getDtls().caseEvidenceStackDataID);

    super.remove(versionNo);

    try {
      removeXML(caseEvidenceStackData);
    } catch (final Exception e) {

      final AppException appExecption = new AppException(
        GENCASEEVIDENCESTACK.ERR_ON_REMOVE, e);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        appExecption,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      ValidationHelper.failIfErrorsExist();

    }

  }

  /**
   * Inserts the XML into {@link CaseEvidenceStackData}
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void storeXML() throws InformationalException {

    // insert blob
    final CaseEvidenceStackData caseEvidenceStackData = caseEvidenceStackDataDAO.newInstance();

    caseEvidenceStackData.setData(strippedXML);

    caseEvidenceStackData.insert();

    setCaseEvidenceStackData(caseEvidenceStackData);

  }

  /**
   * Modifies the XML in {@link CaseEvidenceStackData}
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void modifyXML() throws InformationalException {

    // Modify blob
    final CaseEvidenceStackData caseEvidenceStackData = caseEvidenceStackDataDAO.get(
      getDtls().caseEvidenceStackDataID);

    caseEvidenceStackData.setData(strippedXML);

    caseEvidenceStackData.modify();

  }

  /**
   * Removes the XML from {@link CaseEvidenceStackData}
   *
   * @param caseEvidenceStackData
   * The {@link CaseEvidenceStackData} record including it's overflows
   * to be removed.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void removeXML(final CaseEvidenceStackData caseEvidenceStackData)
    throws InformationalException {

    // Remove XML data
    caseEvidenceStackData.remove();

  }

  /**
   * Validates the name property is not null or an empty string.
   *
   * @param nameToValidate
   * The {@link CaseEvidenceStack} name to be validated.
   *
   * @throws AppRuntimeException
   * Generic Exception Signature.
   */
  protected void validateName(final String nameToValidate)
    throws AppRuntimeException {

    if (null == nameToValidate) {

      final AppRuntimeException appRuntimeException = new AppRuntimeException(
        GENCASEEVIDENCESTACKExceptionCreator.ERR_CASE_EVIDENCE_STACK_NAME_NULL());

      throw appRuntimeException;

    } else if (nameToValidate.length() == 0) {

      final AppRuntimeException appRuntimeException = new AppRuntimeException(
        GENCASEEVIDENCESTACKExceptionCreator.ERR_CASE_EVIDENCE_STACK_NAME_EMPTY());

      throw appRuntimeException;
    }

  }

  /**
   * Validates the case id property is not null or an empty string.
   *
   * @param caseID
   * The {@link CaseEvidenceStack} case id to be validated.
   *
   * @throws AppRuntimeException
   * Generic Exception Signature.
   */
  protected void validateCaseID(final Long caseID) throws AppRuntimeException {

    if (null == caseID) {

      final AppRuntimeException appRuntimeException = new AppRuntimeException(
        GENCASEEVIDENCESTACKExceptionCreator.ERR_CASE_EVIDENCE_STACK_CASEID_NOT_VALID());

      throw appRuntimeException;

    } else if (caseID == 0) {

      final AppRuntimeException appRuntimeException = new AppRuntimeException(
        GENCASEEVIDENCESTACKExceptionCreator.ERR_CASE_EVIDENCE_STACK_CASEID_NOT_VALID());

      throw appRuntimeException;

    }

  }

  /**
   * Validates the XML representing a {@link CaseEvidenceStack} against the
   * schema for {@link CaseEvidenceStackData}.
   *
   * @param xml
   * The XML representation of a {@link CaseEvidenceStack}
   *
   * @throws AppRuntimeException
   * Generic Exception Signature.
   */
  protected void validateXMLAgainstSchema(final String xml)
    throws AppRuntimeException {

    final InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(
      CaseEvidenceStackConst.kCaseEvidenceStackSchema);

    final SchemaFactory factory = SchemaFactory.newInstance(
      XMLConstants.W3C_XML_SCHEMA_NS_URI);

    try {

      final Schema schema = factory.newSchema(new StreamSource(is));
      final Validator validator = schema.newValidator();

      validator.validate(new StreamSource(new StringReader(xml)));

    } catch (final SAXException e) {

      final AppRuntimeException appRuntimeExecption = new AppRuntimeException(
        GENCASEEVIDENCESTACK.ERR_CASE_EVIDENCE_STACK_XML_NOT_VALID, e);

      throw appRuntimeExecption;

    } catch (final IOException e) {

      final AppRuntimeException appRuntimeExecption = new AppRuntimeException(
        GENCASEEVIDENCESTACK.ERR_CASE_EVIDENCE_STACK_XML_NOT_VALID, e);

      throw appRuntimeExecption;
    }

  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No validations of this type have been identified.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No validations of this type have been identified.
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No validations of this type have been identified.
  }
}
