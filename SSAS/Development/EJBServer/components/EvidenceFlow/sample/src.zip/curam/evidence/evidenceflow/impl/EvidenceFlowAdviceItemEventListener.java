/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidence.evidenceflow.impl;


import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.codetable.impl.ADVICECATEGORYEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.PersistenceEvent;


/**
 * On post insert of an {@link AdviceItem} of type
 * <ul>
 * <li><code>ADVICECATEGORYEntry.ISSUES</code></li>, or
 * <li><code>ADVICECATEGORYEntry.REMINDERS</code></li>
 * </ul>
 *
 * the {@link EvidenceFlowReload}'s time stamp associated with the
 * {@link AdviceItem}'s case is updated.
 *
 * @deprecated since 6.0_SP2_EP10 due to a new storage mechanism being
 * introduced for advice.
 */
@Singleton
@Deprecated
final class EvidenceFlowAdviceItemEventListener extends PersistenceEvent<curam.advisor.impl.AdviceItem> {

  /**
   * Instance of AdviceItemCaseLink DAO
   */
  @Inject
  protected curam.advisor.impl.AdviceItemCaseLinkDAO adviceItemCaseLinkDAO;

  /**
   * Updates the {@link EvidenceFlowReload}'s time stamp if the
   * {@link AdviceItem} being modified is of either type:
   *
   * <ul>
   * <li><code>ADVICECATEGORYEntry.ISSUES</code></li>
   * <li><code>ADVICECATEGORYEntry.REMINDERS</code></li>
   * </ul>
   *
   * And if the {@link AdviceItem} has been linked to a case via
   * {@link AdviceItemCaseLink}.
   *
   * @param adviceItem
   * The {@link AdviceItem} that has just been inserted.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated since 6.0_SP2_EP10
   */
  @Override
  @Deprecated
  public void postModify(final curam.advisor.impl.AdviceItem adviceItem) throws AppException,
      InformationalException {

    // If the modification has occurred on an advice item of type issues or
    // reminders and the advice item is linked to a case, then update the
    // EvidenceFlowReload's time stamp because something of interest to the
    // evidence flow has changed.
    if (adviceItem.getCategoryType().equals(ADVICECATEGORYEntry.ISSUES)
      || adviceItem.getCategoryType().equals(ADVICECATEGORYEntry.REMINDERS)) {

      // Note: Assumption is made here that more often than not the only thing
      // that is modified on an AdviceItem is the showAdvice field, ideally a
      // check would be done on this field to see if it has changed and only
      // update the EvidenceFlowReload if it has.

      // Attempt to read the AdviceItemCaseLink by the AdviceItem
      final curam.advisor.impl.AdviceItemCaseLink adviceItemCaseLink = adviceItemCaseLinkDAO.get(
        adviceItem);

      // If an AdviceItemCaseLink exists update the EvidenceFlowReload.
      if (null != adviceItemCaseLink) {

        // Only process if the case id has been set.
        if (adviceItemCaseLink.getCaseID() != 0) {

          // BEGIN, CR00295817, POB
          EvidenceFlowUtility.updateEvidenceFlow(
            adviceItemCaseLink.getCaseID().longValue());
          // END, CR00295817

        }
      }
    }

  }
}
