/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidence.evidenceflow.impl;


import com.google.inject.ImplementedBy;

import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;


/**
 * Data access object for the {@link EvidenceFlowReload} entity.
 */
@ImplementedBy(EvidenceFlowReloadDAOImpl.class)
public interface EvidenceFlowReloadDAO extends StandardDAO<EvidenceFlowReload> {

  /**
   * Retrieves an {@link EvidenceFlowReload} for the specified case. If no
   * {@link EvidenceFlowReload} exists for this case one is created and then
   * returned.
   *
   * @param caseHeader
   * The Case Header for the {@link EvidenceFlowReload} being sought.
   *
   * @return the {@link EvidenceFlowReload} being sought.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  EvidenceFlowReload read(final CaseHeader caseHeader)
    throws InformationalException;
}
