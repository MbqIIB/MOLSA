/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidence.evidenceflow.stack.impl;


import com.google.inject.Singleton;

import curam.evidence.evidenceflow.stack.entity.impl.CaseEvidenceStackDataAdapter;
import curam.evidence.evidenceflow.stack.entity.struct.CaseEvidenceStackDataDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Implementation of {@linkplain CaseEvidenceStackDataDAO} interface
 *
 */
@Singleton
final class CaseEvidenceStackDataDAOImpl extends StandardDAOImpl<CaseEvidenceStackData, CaseEvidenceStackDataDtls> implements
  CaseEvidenceStackDataDAO {

  /**
   * Single instance of the entity adapter shared across all DAO
   * implementations.
   */
  protected static final CaseEvidenceStackDataAdapter kAdapter = new CaseEvidenceStackDataAdapter();

  /**
   * @see StandardDAOImpl
   */
  protected CaseEvidenceStackDataDAOImpl() {
    super(kAdapter, CaseEvidenceStackData.class);
  }
}
