/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.evidence.evidenceflow.impl;


import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Level;
import org.jdom.Content;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

import com.google.inject.Inject;

import curam.advisor.entity.fact.AdviceXMLResultFactory;
import curam.advisor.entity.struct.AdviceContextKey;
import curam.advisor.impl.AdviceContext;
import curam.advisor.impl.AdviceContextDAO;
import curam.codetable.EVIDENCECATEGORY;
import curam.codetable.VERIFICATIONSTATUS;
import curam.codetable.impl.CASEEVIDENCEEntry;
import curam.codetable.impl.EVIDENCECATEGORYEntry;
import curam.core.impl.EnvVars;
import curam.core.sl.impl.VerificationInterface;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EvidenceIssues;
import curam.core.sl.infrastructure.impl.EvidenceVerification;
import curam.core.sl.infrastructure.intf.EvidenceController;
import curam.core.sl.infrastructure.logging.impl.LogMessage;
import curam.core.sl.infrastructure.struct.CaseEvidenceVerificationDetails;
import curam.core.sl.infrastructure.struct.CaseEvidenceVerificationDetailsList;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EvidenceTypeAdminDetails;
import curam.core.sl.infrastructure.struct.EvidenceTypeAdminDetailsList;
import curam.core.sl.infrastructure.struct.IssueDetails;
import curam.core.sl.infrastructure.struct.IssueDetailsList;
import curam.core.sl.struct.CaseIDKey;
import curam.core.struct.CaseKey;
import curam.evidence.evidenceflow.message.GENEVIDENCEFLOWCONFIG;
import curam.evidence.evidenceflow.message.GENEVIDENCEFLOWDISPLAY;
import curam.evidence.evidenceflow.stack.codetable.impl.STACKTYPEEntry;
import curam.evidence.evidenceflow.stack.impl.CaseEvidenceStack;
import curam.evidence.evidenceflow.stack.impl.CaseEvidenceStackDAO;
import curam.evidence.evidenceflow.stack.impl.JDOMCaseEvidenceStack;
import curam.evidence.impl.EvidenceFlowXMLBuilder;
import curam.evidence.impl.EvidenceType;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.user.impl.User;
import curam.piwrapper.user.impl.UserDAO;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.DatabaseException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.resources.Configuration;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * Builds the <code>EvidenceFlow</code> XML. This XML is built on
 * <code>JDOM Document</code>.
 */
public class JDOMEvidenceFlowXMLBuilder implements EvidenceFlowXMLBuilder {

  /**
   * Access to the Advice Context
   */
  @Inject
  private AdviceContextDAO adviceContextDAO;

  /**
   * The Evidence Issues interface. *
   */
  @Inject
  protected EvidenceIssues evidenceIssues;

  /**
   * The Evidence Verification interface. *
   */
  @Inject
  protected EvidenceVerification evidenceVerification;

  /**
   * Instance of the User DAO.
   */
  @Inject
  protected UserDAO userDAO;

  /**
   * Instance of the CaseEvidenceStack DAO.
   */
  @Inject
  protected CaseEvidenceStackDAO caseEvidenceStackDAO;

  /**
   * Instance of the CoverController.
   */
  protected CoverController coverController;

  /**
   * Instance of the EvidenceFlowReloadDAO.
   */
  @Inject
  protected EvidenceFlowReloadDAO evidenceFlowReloadDAO;

  /**
   * {@inheritDoc}
   */
  public String build(final CaseHeader caseHeader) throws AppException,
      InformationalException {

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseHeader.getID();

    coverController = new CoverController(caseKey);

    return documentToString(buildInternal(caseHeader));
  }

  /**
   * This method builds the <code>Document</code> for the data to be displayed
   * in the <code>EvidenceFlow</code> widget.
   *
   * @return The XML <code>Document</code> describing the state of the evidence
   * associated to the case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Document buildInternal(final CaseHeader caseHeader)
    throws AppException, InformationalException {

    final Element rootElement = createRootElement(caseHeader);

    // Build and add the stacks.
    rootElement.addContent(buildStacks(caseHeader));

    // Build and add accordions.
    rootElement.addContent(buildCategoryAccordions(caseHeader));

    // Build and add the covers.
    rootElement.addContent(coverController.getCoverElements());
    
    rootElement.addContent(buildProperties());

    return new Document(rootElement);
  }

  /**
   * Creates the root <code>Element</code> and sets it's attributes for the
   * <code>EvidenceFlow</code> XML.
   *
   * @param caseHeader
   * The case for which the XML is being built.
   *
   * @return The root <code>Element</code> for the <code>EvidenceFlow</code>
   * XML.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Element createRootElement(final CaseHeader caseHeader)
    throws InformationalException {

    final Element rootElement = new Element(EvidenceFlowXMLConst.kEvidenceFlow);

    rootElement.setAttribute(EvidenceFlowXMLConst.kCaseID,
      String.valueOf(caseHeader.getID()));

    // Get and set the evidence flow time stamp for this case. The time stamp is
    // set by the system any time something of interest to the evidence flow
    // occurs. This is used to gauge whether or not anything has changed since
    // the last time the evidence flow received data.
    final EvidenceFlowReload evidenceFlowReload = evidenceFlowReloadDAO.read(
      caseHeader);

    final String timestamp = String.valueOf(evidenceFlowReload.getTimeStamp());

    rootElement.setAttribute(EvidenceFlowXMLConst.kTimeStamp, timestamp);

    rootElement.setAttribute(EvidenceFlowXMLConst.kCoverDelay, getCoverDelay());

    rootElement.setAttribute(EvidenceFlowXMLConst.kPollingInteval,
      getPollingInterval());

    rootElement.setAttribute(EvidenceFlowXMLConst.kDefaultCover,
      getDefaultCover());
    
    rootElement.setAttribute(EvidenceFlowXMLConst.kLocale, 
      TransactionInfo.getProgramLocale());

    return rootElement;
  }

  /**
   * Reads the configured default cover type and checks to see if this cover
   * type exists for this case, if it does not a randomly selected cover is set
   * to the default.
   *
   * @return The evidence type code to be set as the default cover.
   */
  protected String getDefaultCover() {

    String defaultCover = "";

    final String configuredDefaultCover = getConfiguredDefaultCover();

    if (coverController.doesCoverExist(configuredDefaultCover)) {

      defaultCover = configuredDefaultCover;
    } else {
      defaultCover = coverController.getRandomCover();
      logDefaultCoverMsg(configuredDefaultCover);
    }

    return defaultCover;
  }

  /**
   * Reads the environment variable
   * <code>ENV_EVIDENCEFLOW_DEFAULT_EVIDENCE</code> to retrieve the default
   * evidence cover figure. If this read returns an empty <code>String</code>
   * the default value for this variable is then read..
   *
   * @return The <code>String</code>. value of the environment variable
   * <code>ENV_EVIDENCEFLOW_COVER_DELAY</code>.
   */
  protected String getConfiguredDefaultCover() {

    String defaultCover = Configuration.getProperty(
      EnvVars.ENV_EVIDENCEFLOW_DEFAULT_EVIDENCE_TYPE);

    if (defaultCover.length() == 0) {
      defaultCover = Configuration.getProperty(
        EnvVars.ENV_EVIDENCEFLOW_DEFAULT_EVIDENCE_TYPE_DEFAULT);
    }
    return defaultCover;
  }

  /**
   * Reads the environment variable
   * <code>ENV_EVIDENCEFLOW_POLLING_INTERVAL</code> to retrieve the polling
   * interval figure. If this read returns a <code>Null</code> the default value
   * for this variable is then read. A <code>String</code> representation of
   * this <code>Integer</code> value is then returned.
   *
   * @return The value of the environment variable
   * <code>ENV_EVIDENCEFLOW_POLLING_INTERVAL</code>.
   */
  protected String getPollingInterval() {

    Integer pollingInterval = Configuration.getIntProperty(
      EnvVars.ENV_EVIDENCEFLOW_POLLING_INTERVAL);

    if (null == pollingInterval) {
      pollingInterval = EnvVars.ENV_EVIDENCEFLOW_POLLING_INTERVAL_DEFAULT;
    }

    // If the configured polling interval is longer than an hour log a warning
    // because this really would not be a very usable configuration.
    if (pollingInterval.intValue() > EvidenceFlowXMLConst.kHourInMilliseconds) {

      logPollingIntervalMsg(pollingInterval.intValue(),
        EvidenceFlowXMLConst.kHourInMilliseconds);

    }
    return pollingInterval.toString();
  }

  /**
   * Reads the environment variable <code>ENV_EVIDENCEFLOW_COVER_DELAY</code> to
   * retrieve the cover delay figure. If this read returns a <code>Null</code>
   * the default value for this variable is then read. A <code>String</code>
   * representation of this <code>Integer</code> value is then returned.
   *
   * @return The <code>String</code>. value of the environment variable
   * <code>ENV_EVIDENCEFLOW_COVER_DELAY</code>.
   */
  protected String getCoverDelay() {

    Integer coverDelay = Configuration.getIntProperty(
      EnvVars.ENV_EVIDENCEFLOW_COVER_DELAY);

    if (null == coverDelay) {

      coverDelay = EnvVars.ENV_EVIDENCEFLOW_COVER_DELAY_DEFAULT;

    }

    // If the configured cover delay is longer than a minute log a warning
    // because this really would not be a very usable configuration.
    if (coverDelay.intValue() > EvidenceFlowXMLConst.kMinuteInMilliseconds) {
      logCoverDelayMsg(coverDelay.intValue(),
        EvidenceFlowXMLConst.kMinuteInMilliseconds);
    }
    return coverDelay.toString();
  }

  /**
   * Checks to see if <code>ENV_EVIDENCEFLOW_COVER_DELAY_LOG_ON</code> is set to
   * true and the level of logging is at least <code>Trace Ultra Verbose</code>,
   * if so the
   * <code>GENEVIDENCEFLOWCONFIG.WARN_EVIDENCE_COVER_DELAY_TOO_HIGH</code>
   * warning message is logged.
   *
   * @param configuredDelay
   * The configured cover delay value.
   *
   * @param recommendedMaxDelay
   * The recommended maximum cover delay value.
   */
  protected void logCoverDelayMsg(final int configuredDelay,
    final int recommendedMaxDelay) {

    Boolean loggingEnabled = new Boolean(
      Configuration.getBooleanProperty(
        EnvVars.ENV_EVIDENCEFLOW_COVER_DELAY_LOG_ON));

    if (loggingEnabled == false) {

      loggingEnabled = new Boolean(
        curam.util.resources.Configuration.getBooleanProperty(
          EnvVars.ENV_EVIDENCEFLOW_COVER_DELAY_LOG_ON_DEFAULT));
    }

    // Only log the message if logging is enabled and the correct level of
    // logging is set.
    if (loggingEnabled) {

      if (Trace.atLeast(Trace.kTraceUltraVerbose)) {

        // BEGIN, CR00288633, RB
        final LogMessage coverDelayMsg = new LogMessage(
          new LocalisableString(GENEVIDENCEFLOWCONFIG.WARN_EVIDENCE_COVER_DELAY_TOO_HIGH).arg(configuredDelay).arg(
            recommendedMaxDelay));

        // END, CR00288633

        coverDelayMsg.log(Level.WARN);
      }

    }

  }

  /**
   * Checks to see if <code>ENV_EVIDENCEFLOW_DEFAULT_EVIDENCE_TYPE_LOG_ON</code>
   * is set to true and the level of logging is at least
   * <code>Trace Ultra Verbose</code>, if so the
   * <code>GENEVIDENCEFLOWCONFIG.WARN_DEFAULT_EVIDENCE_TYPE_IS_NOT_AVAILABLE</code>
   * warning message is logged.
   *
   * @param defaultCoverEvidenceType
   * The configured default cover evidence type.
   */
  protected void logDefaultCoverMsg(final String defaultCoverEvidenceType) {

    Boolean loggingEnabled = new Boolean(
      Configuration.getBooleanProperty(
        EnvVars.ENV_EVIDENCEFLOW_DEFAULT_EVIDENCE_TYPE_LOG_ON));

    if (loggingEnabled == false) {

      loggingEnabled = new Boolean(
        curam.util.resources.Configuration.getBooleanProperty(
          EnvVars.ENV_EVIDENCEFLOW_DEFAULT_EVIDENCE_TYPE_LOG_ON_DEFAULT));
    }

    // Only log the message if logging is enabled and the correct level of
    // logging is set.
    if (loggingEnabled) {

      if (Trace.atLeast(Trace.kTraceUltraVerbose)) {

        // BEGIN, CR00288633, RB
        final LogMessage defaultCoverMsg = new LogMessage(
          new LocalisableString(GENEVIDENCEFLOWCONFIG.WARN_DEFAULT_EVIDENCE_TYPE_IS_NOT_AVAILABLE).arg(
            defaultCoverEvidenceType));

        // END, CR00288633

        defaultCoverMsg.log(Level.WARN);
      }

    }

  }

  /**
   * Checks to see if <code>ENV_EVIDENCEFLOW_POLLING_INTERVAL_LOG_ON</code> is
   * set to true and the level of logging is at least
   * <code>Trace Ultra Verbose</code>, if so the
   * <code>GENEVIDENCEFLOWCONFIG.WARN_EVIDENCE_POLLING_INTERVAL_TOO_HIGH</code>
   * warning message is logged.
   *
   * @param recommendedMaxDelay
   * The recommended maximum polling interval value.
   * @param configuredPollingInterval
   * The configured polling interval value.
   */
  protected void logPollingIntervalMsg(final int configuredPollingInterval,
    final int recommendedMaxpollingInterval) {

    Boolean loggingEnabled = new Boolean(
      Configuration.getBooleanProperty(
        EnvVars.ENV_EVIDENCEFLOW_POLLING_INTERVAL_LOG_ON));

    if (loggingEnabled == false) {

      loggingEnabled = new Boolean(
        curam.util.resources.Configuration.getBooleanProperty(
          curam.core.impl.EnvVars.ENV_EVIDENCEFLOW_POLLING_INTERVAL_LOG_ON_DEFAULT));
    }

    // Only log the message if logging is enabled and the correct level of
    // logging is set.
    if (loggingEnabled) {

      if (Trace.atLeast(Trace.kTraceUltraVerbose)) {

        // BEGIN, CR00288633, RB
        final LogMessage pollingIntervalMsg = new LogMessage(
          new LocalisableString(curam.evidence.evidenceflow.message.GENEVIDENCEFLOWCONFIG.WARN_EVIDENCE_POLLING_INTERVAL_TOO_HIGH).arg(configuredPollingInterval).arg(
            recommendedMaxpollingInterval));

        // END, CR00288633

        pollingIntervalMsg.log(Level.WARN);
      }

    }

  }

  /**
   * Builds the stack <code>Element</code> and it's child <code>Elements</code>
   * which consists of both system defined and user defined stacks.
   *
   * @param caseHeader
   * The case that stacks are being created for.
   *
   * @return The stack <code>Element</code> and all its children.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Element buildStacks(final CaseHeader caseHeader)
    throws AppException, InformationalException {

    final Element stacks = new Element(EvidenceFlowXMLConst.kStacks);

    // Add system defined stacks.
    stacks.addContent(buildIssuesStack(caseHeader));
    stacks.addContent(buildVerificationsStack(caseHeader));

    // Add user defined stacks.
    stacks.addContent(buildUserDefinedStacks(caseHeader));
    return stacks;
  }
  
  /**
   * Builds the properties <code>Element</code> and it's child <code>Elements</code>
   * which consists of localised strings to be displayed by the widget.
   *
   * @return The properties <code>Element</code> and all its children.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  private Element buildProperties() throws AppException,
      InformationalException {

    final Element properties = new Element(EvidenceFlowXMLConst.kProperties);

    final String userLocale = TransactionInfo.getProgramLocale();
    
    // Add system defined stacks.
    Element property = new Element(EvidenceFlowXMLConst.kProperty);

    property.setAttribute(EvidenceFlowXMLConst.kId, 
      EvidenceFlowXMLConst.kOfProperty);
    
    property.setAttribute(EvidenceFlowXMLConst.kValue, 
      GENEVIDENCEFLOWDISPLAY.MSG_OF.getMessageText(userLocale));
    
    properties.addContent(property);
    
    property = new Element(EvidenceFlowXMLConst.kProperty);
    property.setAttribute(EvidenceFlowXMLConst.kId, 
      EvidenceFlowXMLConst.kErrorCode101Property);
    
    property.setAttribute(EvidenceFlowXMLConst.kValue, 
      GENEVIDENCEFLOWDISPLAY.ERR_CODE_101.getMessageText(userLocale));
    
    properties.addContent(property);
    
    property = new Element(EvidenceFlowXMLConst.kProperty);
    property.setAttribute(EvidenceFlowXMLConst.kId, 
      EvidenceFlowXMLConst.kErrorCode102Property);
    
    property.setAttribute(EvidenceFlowXMLConst.kValue, 
      GENEVIDENCEFLOWDISPLAY.ERR_CODE_102.getMessageText(userLocale));
    
    properties.addContent(property);  
    
    property = new Element(EvidenceFlowXMLConst.kProperty);
    property.setAttribute(EvidenceFlowXMLConst.kId, 
      EvidenceFlowXMLConst.kErrorCode103Property);
    
    property.setAttribute(EvidenceFlowXMLConst.kValue, 
      GENEVIDENCEFLOWDISPLAY.ERR_CODE_103.getMessageText(userLocale));
    
    properties.addContent(property);    
    
    property = new Element(EvidenceFlowXMLConst.kProperty);
    property.setAttribute(EvidenceFlowXMLConst.kId, 
      EvidenceFlowXMLConst.kErrorCode104Property);
    
    property.setAttribute(EvidenceFlowXMLConst.kValue, 
      GENEVIDENCEFLOWDISPLAY.ERR_CODE_104.getMessageText(userLocale));
    
    properties.addContent(property);    
    
    property = new Element(EvidenceFlowXMLConst.kProperty);
    property.setAttribute(EvidenceFlowXMLConst.kId, 
      EvidenceFlowXMLConst.kErrorCode105Property);
    
    property.setAttribute(EvidenceFlowXMLConst.kValue, 
      GENEVIDENCEFLOWDISPLAY.ERR_CODE_105.getMessageText(userLocale));
    
    properties.addContent(property); 
    
    property = new Element(EvidenceFlowXMLConst.kProperty);
    property.setAttribute(EvidenceFlowXMLConst.kId, 
      EvidenceFlowXMLConst.kNewStackProperty);
    
    property.setAttribute(EvidenceFlowXMLConst.kValue, 
      GENEVIDENCEFLOWDISPLAY.MSG_NEW_STACK.getMessageText(userLocale));
    
    properties.addContent(property); 
    
    property = new Element(EvidenceFlowXMLConst.kProperty);
    property.setAttribute(EvidenceFlowXMLConst.kId, 
      EvidenceFlowXMLConst.kStackNameNotUniqueProperty);
    
    property.setAttribute(EvidenceFlowXMLConst.kValue, 
      GENEVIDENCEFLOWDISPLAY.ERR_STACK_NAME_NOT_UNIQUE.getMessageText(
      userLocale));
    
    properties.addContent(property);
    
    property = new Element(EvidenceFlowXMLConst.kProperty);
    property.setAttribute(EvidenceFlowXMLConst.kId, 
      EvidenceFlowXMLConst.kStackNameNotEntered);
    
    property.setAttribute(EvidenceFlowXMLConst.kValue, 
      GENEVIDENCEFLOWDISPLAY.ERR_STACK_NAME_NOT_ENTERED.getMessageText(
      userLocale));
    
    properties.addContent(property); 
    
    return properties;
  }  

  /**
   * This method converts the XML <code>Document</code> in to a
   * <code>String</code>.
   *
   * @param document
   * The XML <code>Document</code> to be converted into a
   * <code>String</code>.
   *
   * @return A <code>String</code> representation of the XML described by the
   * <code>Document</code>
   */
  protected String documentToString(final Document document) {

    final Format format = Format.getRawFormat();

    format.setIndent("");
    format.setLineSeparator("");

    // TODO: Need to see if this is an appropriate way of making sure the
    // attribute value is not escaped. Escaping the target attribute on the
    // Cover Element causes a problem because the ampersand between parameters
    // gets escaped.
    final EvidenceXMLOutputter xmlOutputter = new EvidenceXMLOutputter(format);

    return xmlOutputter.outputString(document);

  }

  /**
   * This method builds the <code>JDOM Element</code> that represents the Issues
   * stack for the specified case.
   *
   * @param caseHeader
   * The case for which the issues stack is being built.
   *
   * @return A <code>JDOM Element</code> representing an issues stack.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Element buildIssuesStack(final CaseHeader caseHeader)
    throws AppException, InformationalException {

    final Element issueStack = new Element(EvidenceFlowXMLConst.kStack);

    // Set the stack attributes.
    issueStack.setAttribute(EvidenceFlowXMLConst.kName,
      STACKTYPEEntry.ISSUES.toUserLocaleString());
    issueStack.setAttribute(EvidenceFlowXMLConst.kType,
      EvidenceFlowXMLConst.kSystem);

    issueStack.addContent(buildIssuesStackContents(caseHeader));

    return issueStack;

  }

  /**
   * This method builds the <code>JDOM Element</code> that represents the
   * verifications stack for the specified case.
   *
   * @param caseHeader
   * The case for which the verifications stack is being built.
   *
   * @return A <code>JDOM Element</code> representing an verifications stack.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected Element buildVerificationsStack(final CaseHeader caseHeader)
    throws AppException, InformationalException {

    final Element verificationStack = new Element(EvidenceFlowXMLConst.kStack);

    // Set the stack attributes.
    verificationStack.setAttribute(EvidenceFlowXMLConst.kName,
      STACKTYPEEntry.ITEMSTOVERIFY.toUserLocaleString());
    verificationStack.setAttribute(EvidenceFlowXMLConst.kType,
      EvidenceFlowXMLConst.kSystem);

    verificationStack.addContent(buildVerificationsStackContents(caseHeader));

    return verificationStack;

  }

  /**
   * Retrieves all outstanding verifications for the evidence on the specified
   * case. For each evidence type found to have outstanding verifications an
   * <code>Element</code> of the following structure is created: <br/>
   * <br/>
   *
   * <b><i>{@code <coverref reference="evidence type"/>}</i></b>
   *
   * @param caseHeader
   * The case for which the issues stack is being built.
   *
   * @return A <code>List</code> of <code>Elements</code> that describes the
   * contents of the verifications stack.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected List<Element> buildVerificationsStackContents(
    final CaseHeader caseHeader) throws AppException, InformationalException {

    final VerificationInterface verificationObj = evidenceVerification.getVerificationImpl();

    final CaseIDKey caseKey = new CaseIDKey();

    caseKey.caseID = caseHeader.getID();

    // BEGIN, CR00222660, PF
    final CaseEvidenceVerificationDetailsList caseEvidenceVerificationDetailsList = verificationObj.listVerificationsForCase(
      caseKey);

    final List<Element> verifications = new ArrayList<Element>();
    final Set<String> evidenceTypes = new HashSet<String>();

    final EvidenceDescriptor evidenceDescriptor = EvidenceDescriptorFactory.newInstance();

    // Iterate through each issue and create an coverref element for the
    // evidence type if one has not already being created.
    for (final CaseEvidenceVerificationDetails caseEvidenceVerificationDetails : caseEvidenceVerificationDetailsList.dtls) {

      // Only process non verified items.
      if (caseEvidenceVerificationDetails.verificationStatus.equals(
        VERIFICATIONSTATUS.NOTVERIFIED)) {

        final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

        evidenceDescriptorKey.evidenceDescriptorID = caseEvidenceVerificationDetails.evidenceDescriptorID;

        final EvidenceDescriptorDtls evidenceDescriptDtls = evidenceDescriptor.read(
          evidenceDescriptorKey);

        // Only process the verification details if it's related evidence is
        // configured as case evidence for the current case.
        if (coverController.doesCoverExist(evidenceDescriptDtls.evidenceType)) {

          // Increment the number of verifications for this evidence type.
          coverController.addVerification(evidenceDescriptDtls.evidenceType);

          // Only want unique entries in the verifications collection, no
          // duplicates should be present.
          if (!evidenceTypes.contains(evidenceDescriptDtls.evidenceType)) {

            final Element coverRef = createCoverrefElement(
              evidenceDescriptDtls.evidenceType);

            verifications.add(coverRef);

            evidenceTypes.add(evidenceDescriptDtls.evidenceType);
          }

        }
      }
    }
    // END, CR00222660

    // This sorts the entries of the stack alphabetically. The sorting is
    // actually sorted based on the localized description of the evidence type.
    Collections.sort(verifications, new CoverRefComparator());
    return verifications;
  }

  /**
   * Retrieves all issues for the evidence on the specified case. For each
   * evidence type found to have issues an <code>Element</code> of the following
   * structure is created: <br/>
   * <br/>
   *
   * <b><i>{@code <coverref reference="evidence type"/>}</i></b>
   *
   * @param caseHeader
   * The case for which the issues stack is being built.
   *
   * @return A <code>List</code> of <code>Elements</code> that describes the
   * contents of the issues stack.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected List<Element> buildIssuesStackContents(final CaseHeader caseHeader)
    throws AppException, InformationalException {

    // Get all issues for this case.
    final IssueDetailsList issueDetailsList = evidenceIssues.listIssuesForCase(
      caseHeader.getID());

    final List<Element> issues = new ArrayList<Element>();
    final Set<String> evidenceTypes = new HashSet<String>();

    // Iterate through each issue and create an coverref element for the
    // evidence type if one has not already being created.
    for (final IssueDetails issueDetails : issueDetailsList.dtls) {

      // Increment the number of issues for this evidence type.
      coverController.addIssue(issueDetails.evidenceType);

      // Only want unique entries in the issues collection, no duplicates should
      // be present.
      if (!evidenceTypes.contains(issueDetails.evidenceType)) {

        final Element coverRef = createCoverrefElement(
          issueDetails.evidenceType);

        issues.add(coverRef);

        evidenceTypes.add(issueDetails.evidenceType);
      }

    }

    // This sorts the entries of the stack alphabetically. The sorting is
    // actually sorted based on the localized description of the evidence type.
    Collections.sort(issues, new CoverRefComparator());
    return issues;
  }

  /**
   * Creates a <code>Element</code> of the structure below for the specified
   * evidence type. <br/>
   * <br/>
   *
   * <b><i>{@code <coverref reference="evidence type"/>}</i></b>
   *
   * @param evidType
   * The evidence type for which the element should be created.
   *
   * @return A cover reference <code>Element</code>.
   */
  protected Element createCoverrefElement(final String evidType) {

    final Element coverRef = new Element(EvidenceFlowXMLConst.kCoverRef);

    coverRef.setAttribute(EvidenceFlowXMLConst.kReference, evidType);

    return coverRef;
  }

  /**
   * Builds a <code>Collection</code> of accordion <code>Elements</code>, each
   * accordion <code>Element</code> represents an evidence category. Each
   * accordion <code>Element</code> contains a list of cover reference
   * <code>Elements</code> representing the evidence types for the category. An
   * accordion <code>Element</code> takes the form of: <br/>
   * <br/>
   *
   * <b><i> {@code <accordionentry name="evidence category name">}<br/>
   * {@code <coverref reference="evidence type 1"/>}<br/> {@code <coverref
   * reference="evidence type 2"/>}<br/> {@code ........}<br/> {@code </accordionentry> }<br/>
   * </i></b>
   *
   * @param caseHeader
   * The case for which the categories are being built.
   *
   * @return A <code>Collection</code> of accordion <code>Elements</code>.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Collection<Element> buildCategoryAccordions(
    final CaseHeader caseHeader) throws AppException, InformationalException {

    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseHeader.getID();

    final EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

    // Retrieve all evidence types for this case.
    final EvidenceTypeAdminDetailsList list = evidenceControllerObj.listEvidenceTypes(
      caseKey);

    final Map<String, EvidenceCategory> categoryAccordions = new HashMap<String, EvidenceCategory>();

    // Iterate through all evidence types and create a corresponding XML element
    // in the correct category for each.
    for (final EvidenceTypeAdminDetails evidenceTypeAdminDetails : list.dtls) {

      // If the category already exists then simply add the new evidence type
      // to it. Otherwise create a new category and then add the evidence
      // type.
      if (categoryAccordions.containsKey(evidenceTypeAdminDetails.category)) {

        // Update the category.
        final EvidenceCategory category = categoryAccordions.get(
          evidenceTypeAdminDetails.category);

        category.addEvidenceType(evidenceTypeAdminDetails);

      } else {

        final EvidenceCategory category = new EvidenceCategory(
          evidenceTypeAdminDetails.category);

        category.addEvidenceType(evidenceTypeAdminDetails);

        categoryAccordions.put(evidenceTypeAdminDetails.category, category);
      }

    }

    return getEvidenceCategoryElements(categoryAccordions);
  }

  /**
   * Generates a <code>List</code> of <code>JDOM Elements</code> that represents
   * the {@linkplain EvidenceCategory}s on the case. The <code>List</code> of
   * elements is sorted based on the {@linkplain EvidenceCategory#sortOrder}.
   *
   * @param categoryAccordions
   * A <code>Map</code> of the {@linkplain EvidenceCategory}s on the
   * case.
   *
   * @return A <code>List</code> of <code>JDOM Elements</code> that represents
   * the {@linkplain EvidenceCategory}s on the case
   */
  protected List<Element> getEvidenceCategoryElements(
    final Map<String, EvidenceCategory> categoryAccordions) {

    final List<Element> categoryElements = new ArrayList<Element>();

    final List<EvidenceCategory> categoryList = new ArrayList<EvidenceCategory>(
      categoryAccordions.values());

    Collections.sort(categoryList, new EvidenceCategoryComparator());

    final Iterator<EvidenceCategory> iterator = categoryList.iterator();

    // Iterate over all Evidence Categories and compile a list of their Element
    // representations.
    while (iterator.hasNext()) {

      final EvidenceCategory evidenceCategory = iterator.next();
      final Element categoryElement = evidenceCategory.getXML();

      categoryElements.add(categoryElement);
    }
    return categoryElements;
  }

  /**
   * Builds the user defined stack <code>Elements</code>.
   *
   * @param caseHeader
   * The case for which the stacks are being built.
   *
   * @return A <code>Collection</code> of user defined stack
   * <code>Elements</code>.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected Collection<Content> buildUserDefinedStacks(
    final CaseHeader caseHeader) throws InformationalException {

    // Get the current user, and retrieve their stacks for this case.
    final User user = userDAO.get(
      TransactionInfo.getInfo().getInfoProgramUser());

    final Set<CaseEvidenceStack> caseEvidenceStacks = caseEvidenceStackDAO.search(
      user, caseHeader);

    final Collection<Content> userDefinedList = new ArrayList<Content>();

    for (final CaseEvidenceStack caseEvidenceStack : caseEvidenceStacks) {

      final JDOMCaseEvidenceStack jdomCaseEvidenceStack = new JDOMCaseEvidenceStack(
        caseEvidenceStack.getXML());

      final Document doc = jdomCaseEvidenceStack.getStackDocument();

      userDefinedList.add(doc.getRootElement().detach());

    }

    return userDefinedList;
  }

  /**
   * The Cover Controller is responsible for managing the creation and
   * maintenance of {@linkplain Cover}s. A {@linkplain Cover} is an in memory
   * representation of the state of an evidence type that contains the
   * information that will be displayed in the <code>EvidenceFlow</code> widget.
   */
  protected class CoverController {

    /**
     * Variable used to maintain a <code>Map</code> of <code>Covers</code> for
     * the case.
     */
    protected final Map<String, Cover> covers;

    /**
     * Constructor that creates a {@linkplain Cover} for each evidence type
     * associated with the case.
     *
     * @param key
     * The case id for which to create the {@linkplain Cover}s.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public CoverController(final CaseKey key) throws AppException,
        InformationalException {

      covers = new HashMap<String, Cover>();
      createCovers(key);

    }

    /**
     * Creates a {@linkplain Cover} for each evidence type associated with the
     * case. Each {@linkplain Cover} created is then place in a <code>Map</code>
     * to be accessed later.
     *
     * @param key
     * The case id for which to create the {@linkplain Cover}.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    protected void createCovers(final CaseKey key) throws AppException,
        InformationalException {

      final EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

      // Get the evidence types configured for the case.
      final EvidenceTypeAdminDetailsList list = evidenceControllerObj.listEvidenceTypes(
        key);

      // Create a Cover for each evidence type.
      for (final EvidenceTypeAdminDetails details : list.dtls) {

        final Cover cover = new Cover(details.evidenceType, key.caseID);

        covers.put(details.evidenceType, cover);
      }

    }

    /**
     * Adds an issue to the {@linkplain Cover} that represents the evidence type
     * being passed in. Adding an issue results in an issues counter being
     * incremented on the {@linkplain Cover}.
     *
     * @param evType
     * The evidence type for which an issue needs to added.
     */
    public void addIssue(final String evType) {

      if (covers.containsKey(evType)) {

        covers.get(evType).addIssue();
      }
    }

    /**
     * Adds a verification to the {@linkplain Cover} that represents the
     * evidence type being passed in. Adding a verification results in a
     * verification counter being incremented on the {@linkplain Cover}.
     *
     * @param evType
     * The evidence type for which a verification needs to added.
     */
    public void addVerification(final String evType) {

      if (covers.containsKey(evType)) {

        covers.get(evType).addVerification();
      }
    }

    /**
     * Adds a reminder to the {@linkplain Cover} that represents the evidence
     * type being passed in. Adding a reminder results in a reminder counter
     * being incremented on the {@linkplain Cover}.
     *
     * @param evType
     * The evidence type for which a reminder needs to added.
     */
    public void addReminder(final String evType) {

      if (covers.containsKey(evType)) {

        covers.get(evType).addReminder();
      }
    }

    /**
     * Checks to see a {@linkplain Cover} for the specified evidence type
     * exists.
     *
     * @param evidenceType
     *
     * @return True if a {@linkplain Cover} for the specified evidence type
     * exists, otherwise false.
     */
    public boolean doesCoverExist(final String evidenceType) {

      return covers.containsKey(evidenceType);
    }

    /**
     * Returns the evidence type of a {@linkplain Cover} that was retrieved
     * randomly from the controllers {@linkplain Cover} map.
     *
     * @return The evidence type code for a {@linkplain Cover} retrieved at
     * random form the controllers {@linkplain Cover} map. If the map is
     * empty due to no evidence been configured for the case
     * {@linkplain EvidenceFlowXMLConst#kNoCover} is returned.
     */
    public String getRandomCover() {

      if (covers.isEmpty()) {
        return EvidenceFlowXMLConst.kNoCover;
      }

      return covers.entrySet().iterator().next().getValue().getEvidenceType();

    }

    /**
     * Generates a <code>Collection</code> of {@linkplain Cover}
     * <code>Elements</code> by iterating through the <code>Map</code> of covers
     * for the case. Each <Code>Cover</code> <code>Element</code> is an XML
     * representation of the state of the evidence type it is representing. For
     * example it will indicate if there are any issues, reminders, or
     * verifications associated with the evidence type.
     *
     * @return A <code>Collection</code> of {@linkplain Cover}
     * <code>Elements</code>
     */
    public Collection<Element> getCoverElements() {

      final Collection<Element> coverElements = new ArrayList<Element>();
      final Collection<Cover> coverList = covers.values();

      for (final Cover cover : coverList) {

        coverElements.add(cover.getXML());
      }

      return coverElements;
    }
  }


  /**
   * A Cover is an in memory representation of an evidence type with regards the
   * number of issues, verifications and reminders associated with it.
   *
   */
  protected class Cover {

    /**
     * The evidence type this cover represents.
     */
    protected final String evidenceType;

    /**
     * An issues counter.
     */
    protected int issues;

    /**
     * A verifications counter.
     */
    protected int verifications;

    /**
     * A reminders counter.
     */
    protected int reminders;

    /**
     * The URL that links to this evidence type's workspace page.
     */
    protected final String url;

    /**
     * Constructor which initializes all counter to zero, assigns the evidence
     * type to the cover and retrieves the workspace page for this evidence
     * type.
     *
     * @param evType
     * The evidence type for which this cover is to be a representation
     * of.
     *
     * @param caseID
     * The case the cover is related to.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public Cover(final String evType, final long caseID) throws AppException,
        InformationalException {

      evidenceType = evType;
      verifications = 0;
      reminders = 0;
      issues = 0;
      url = getURL(evType, caseID);

    }

    /**
     * Retrieves the {@linkplain EvidenceType}'s workspace page and builds up
     * it's <code>URL</code> including parameters.
     *
     * @param evType
     * The {@linkplain EvidenceType} for which the <code>URL</code> is
     * being retrieved.
     * @param caseID
     * The case for which the XML is being generated.
     *
     * @return The {@linkplain EvidenceType}'s workspace page <code>URL</code>
     * including page parameters.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    protected String getURL(final String evType, final long caseID)
      throws AppException, InformationalException {

      final EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

      final EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceType = evType;

      String evidenceWorkspacePage = evidenceControllerObj.readWorkspacePage(eiEvidenceKey).pageName.pageName;

      if (null == evidenceWorkspacePage || evidenceWorkspacePage.length() == 0) {
        // TODO this needs to be more eloquently done.
        evidenceWorkspacePage = EvidenceFlowXMLConst.kEvidenceResolvePage;

      }

      final MessageFormat urlFormat = new MessageFormat(
        EvidenceFlowXMLConst.kEvidenceWorkspaceURLFormat);
      final Object[] params = {
        evidenceWorkspacePage, Long.toString(caseID),
        evType };

      return urlFormat.format(params);

    }

    /**
     * Creates a <code>JDOM Element</code> that details the state of the
     * <code>Cover</code>. It will indicate if there are any:
     *
     * <ul>
     * <li>Issues.</li>
     * <li>Reminders.</li>
     * <li>Verifications.</li>
     * </ul>
     *
     * It will also contain:
     *
     * <ul>
     * <li>The localized {@linkplain CASEEVIDENCEEntry} as the
     * <code>Cover</code> name.</li>
     * <li>A URL attribute containing the <code>Cover's</code> workspace page.</li>
     * </ul>
     *
     *
     * @return A <code>JDOM Element</code> that details the state of the
     * <code>Cover</code>.
     */
    public Element getXML() {

      final Element cover = new Element(EvidenceFlowXMLConst.kCover);

      cover.setAttribute(EvidenceFlowXMLConst.kId, evidenceType);
      cover.setAttribute(EvidenceFlowXMLConst.kName,
        CASEEVIDENCEEntry.get(evidenceType).toUserLocaleString());
      cover.setAttribute(EvidenceFlowXMLConst.kTarget, url);

      cover.addContent(buildDisplayItems());

      // If any issues or verifications exist add a banner flag item to help
      // indicate this.
      if (issues > 0 || verifications > 0) {
        cover.addContent(createFlagBannerItem());
      }

      return cover;
    }

    /**
     * Generates a <code>Collection</code> of <code>JDOM Elements</code> that
     * represent display items on the <code>Cover</code>. Display items are used
     * to indicate if there are any:
     *
     * <ul>
     * <li>Issues.</li>
     * <li>Reminders.</li>
     * <li>Verifications.</li>
     * </ul>
     *
     * A display item takes the form of: <br/>
     * <br/>
     * <b><i>{@code <displayitem name="display item name"
     * value="display item value"/> }</i></b> <br/>
     * <br/>
     *
     * @return A <code>Collection</code> of <code>JDOM Elements</code> that
     * represent display items on the <code>Cover</code>.
     */
    protected Collection<Element> buildDisplayItems() {

      final Collection<Element> displayItems = new ArrayList<Element>();

      // If issues exist add a display item.
      if (issues > 0) {

        final Element issuesElement = new Element(
          EvidenceFlowXMLConst.kDisplayItem);

        issuesElement.setAttribute(EvidenceFlowXMLConst.kName,
          EvidenceFlowXMLConst.kIusses);
        issuesElement.setAttribute(EvidenceFlowXMLConst.kValue, issuesTxt());

        displayItems.add(issuesElement);
      }

      // If verifications exist add a display item.
      if (verifications > 0) {

        final Element verificationsElement = new Element(
          EvidenceFlowXMLConst.kDisplayItem);

        verificationsElement.setAttribute(EvidenceFlowXMLConst.kName,
          EvidenceFlowXMLConst.kVerifications);
        verificationsElement.setAttribute(EvidenceFlowXMLConst.kValue,
          verificationsTxt());

        displayItems.add(verificationsElement);
      }

      // If reminders exist add a display item.
      if (reminders > 0) {

        final Element remindersElement = new Element(
          EvidenceFlowXMLConst.kDisplayItem);

        remindersElement.setAttribute(EvidenceFlowXMLConst.kName,
          EvidenceFlowXMLConst.kReminders);
        remindersElement.setAttribute(EvidenceFlowXMLConst.kValue,
          remindersTxt());

        displayItems.add(remindersElement);
      }

      return displayItems;
    }

    /**
     * Creates a <code>JDOM Element</code> of the following structure: * <br/>
     * <br/>
     * <b><i>{@code <banneritemleft name="flag"/>}</i></b> <br/>
     * <br/>
     *
     * The <code>EvidenceFlow</code> widget interprets this and puts a flag icon
     * on the cover banner on the left.
     *
     * @return A <code>JDOM Element</code> indicating that a flag banner left
     * item should be displayed.
     */
    protected Element createFlagBannerItem() {

      final Element flagElement = new Element(
        EvidenceFlowXMLConst.kBannerItemLeft);

      flagElement.setAttribute(EvidenceFlowXMLConst.kName,
        EvidenceFlowXMLConst.kFlag);
      return flagElement;
    }

    /**
     * Determines which verifications text should be displayed for the cover
     * based on the number of verifications.
     *
     * @return An empty <code>String</code> if no verifications are present, the
     * plural verifications <code>String</code> if more than one
     * verification exist, and the single verification
     * <code>String</code> when only one verification exists.
     */
    protected String verificationsTxt() {

      String verificationsStr = "";

      final String locale = TransactionInfo.getProgramLocale();

      if (verifications > 1) {

        final LocalisableString verificationsLocStr = new LocalisableString(GENEVIDENCEFLOWDISPLAY.MSG_ITEMS_TO_VERIFY).arg(
          verifications);

        verificationsStr = verificationsLocStr.getMessage(locale);
      } else if (verifications == 1) {

        final LocalisableString verificationsLocStr = new LocalisableString(GENEVIDENCEFLOWDISPLAY.MSG_ITEM_TO_VERIFY).arg(
          verifications);

        verificationsStr = verificationsLocStr.getMessage(locale);
      }

      return verificationsStr;
    }

    /**
     * Determines which reminders text should be displayed for the cover based
     * on the number of reminders.
     *
     * @return An empty <code>String</code> if no reminders are present, the
     * plural reminders <code>String</code> if more than one reminder
     * exist, and the single reminder <code>String</code> when only one
     * reminder exists.
     */
    protected String remindersTxt() {

      String remindersStr = "";

      final String locale = TransactionInfo.getProgramLocale();

      if (reminders > 1) {

        final LocalisableString remindersLocStr = new LocalisableString(GENEVIDENCEFLOWDISPLAY.MSG_REMINDERS).arg(
          reminders);

        remindersStr = remindersLocStr.getMessage(locale);

      } else if (reminders == 1) {

        final LocalisableString remindersLocStr = new LocalisableString(GENEVIDENCEFLOWDISPLAY.MSG_REMINDER).arg(
          reminders);

        remindersStr = remindersLocStr.getMessage(locale);
      }

      return remindersStr;
    }

    /**
     * Determines which issues text should be displayed for the cover based on
     * the number of issues.
     *
     * @return An empty <code>String</code> if no issues are present, the plural
     * issues <code>String</code> if more than one issue exist, and the
     * single issue <code>String</code> when only one issue exists.
     */
    protected String issuesTxt() {

      String issuesStr = "";

      final String locale = TransactionInfo.getProgramLocale();

      if (issues > 1) {

        final LocalisableString issuesLocStr = new LocalisableString(GENEVIDENCEFLOWDISPLAY.MSG_ISSUES).arg(
          issues);

        issuesStr = issuesLocStr.getMessage(locale);

      } else if (issues == 1) {

        final LocalisableString issuesLocStr = new LocalisableString(GENEVIDENCEFLOWDISPLAY.MSG_ISSUE).arg(
          issues);

        issuesStr = issuesLocStr.getMessage(locale);
      }

      return issuesStr;
    }

    /**
     * Retrieves the evidence type.
     *
     * @return The {@linkplain CASEEVEINDCEEnty} code for the cover.
     */
    public String getEvidenceType() {

      return evidenceType;
    }

    /**
     * Increments the issues counter by 1.
     */
    public void addIssue() {
      issues++;
    }

    /**
     * Increments the verifications counter by 1.
     */
    public void addVerification() {
      verifications++;
    }

    /**
     * Increments the reminders counter by 1.
     */
    public void addReminder() {
      reminders++;
    }

  }


  /**
   * Overrides {@linkplain XMLOutputter#escapeAttributeEntities(String)} to
   * insure no escaping takes place on the attributes of the XML elements.
   *
   */
  protected class EvidenceXMLOutputter extends XMLOutputter {

    /**
     * Constructor
     */
    EvidenceXMLOutputter(final Format format) {
      super(format);
    }

    /**
     * Simply returns the attribute value as is, thus performing no escaping.
     *
     * @param value
     * The attribute value being processed.
     *
     * @return The unmodified parameter value.
     */
    @Override
    public String escapeAttributeEntities(final String value) {
      // Return value "as is".
      return value;
    }

  }


  /**
   * An Evidence Category is a grouping of {@linkplain CASEEVIDENCEEntry}s, this
   * class is used to maintain an in memory Evidence Category used during the
   * creation of the <code>EvidenceFlow</code> XML.
   *
   */
  protected class EvidenceCategory {

    /**
     * The localised name of the Evidence Category
     */
    protected String name = "";

    /**
     * A <code>Map</code> of {@linkplain EvidenceTypeAdminDetails}, each one
     * represents and evidence type in this category.
     */
    protected final Map<String, EvidenceTypeAdminDetails> evidenceTypes;

    protected final int sortOrder;

    /**
     * Constructor that initialises the <code>Map</code> of Evidence Types and
     * set the name of this Evidence Category.
     *
     * @param categoryNameCode
     * The Evidence Category name code of type
     * {@linkplain EVIDENCECATEGORYEntry}.
     *
     * @throws DatabaseException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppRuntimeException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    EvidenceCategory(final String categoryNameCode) throws DatabaseException,
        AppRuntimeException, AppException, InformationalException {

      final String locale = TransactionInfo.getProgramLocale();

      name = EVIDENCECATEGORYEntry.get(categoryNameCode).toUserLocaleString();
      evidenceTypes = new HashMap<String, EvidenceTypeAdminDetails>();
      sortOrder = CodeTable.sortOrder(EVIDENCECATEGORY.TABLENAME,
        categoryNameCode, locale);

    }

    /**
     * Generates an <code>JDOM Element</code> of the Evidence Category that
     * includes all it's child elements. The structure of the element is as
     * follows: <br/>
     * <br/>
     * <b><i> {@code <accordionentry name="evidence category name">}<br/>
     * {@code <coverref reference="evidence type 1"/>}<br/> {@code <coverref
     * reference="evidence type 2"/>}<br/> {@code ........}<br/> {@code </accordionentry>
     * * }<br/>
     * </i></b>
     *
     * @return An <code>Element</code> representation of the Evidence Category.
     */
    public Element getXML() {

      final List<EvidenceTypeAdminDetails> evidenceTypeList = new ArrayList<EvidenceTypeAdminDetails>(
        evidenceTypes.values());

      // Sort the Evidence Types before creating the XML references to them.
      Collections.sort(evidenceTypeList, new EvidenceTypeComparator());

      // Create the accordion element.
      final Element category = new Element(EvidenceFlowXMLConst.kAccordionEntry);

      category.setAttribute(EvidenceFlowXMLConst.kName, name);

      // Create a cover reference for each evidence type and add it to the
      // accordion element.
      for (final EvidenceTypeAdminDetails evidenceTypeAdminDetails : evidenceTypeList) {

        final Element coverRef = new Element(EvidenceFlowXMLConst.kCoverRef);

        coverRef.setAttribute(EvidenceFlowXMLConst.kReference,
          evidenceTypeAdminDetails.evidenceType);

        category.addContent(coverRef);
      }

      return category;
    }

    /**
     * Adds a Evidence Type to this Category. Only unique evidence types will be
     * added to an Evidence Category, there should be no duplicates.
     *
     * @param evidenceTypeAdminDetails
     * The {@linkplain EvidenceTypeAdminDetails} describing the
     * Evidence Type to be added to this Evidence Category.
     */
    public void addEvidenceType(
      final EvidenceTypeAdminDetails evidenceTypeAdminDetails) {

      if (!evidenceTypes.containsKey(evidenceTypeAdminDetails.evidenceType)) {

        evidenceTypes.put(evidenceTypeAdminDetails.evidenceType,
          evidenceTypeAdminDetails);
      }

    }

    /**
     * Retrieves the sort order for the {@linkplain EvidenceCategory}.
     */
    public int getSortOrder() {
      return this.sortOrder;
    }

    /**
     * Retrieves the name of the {@linkplain EvidenceCategory}.
     */
    public String getName() {
      return this.name;
    }
  }


  /**
   * Comparator class for {@linkplain EvidenceCategory}. The comparison is
   * evaluated from the {@linkplain EvidenceCategory#sortOrder} if these are
   * equal then they {@linkplain EvidenceCategory}s are evaluated based on
   * {@linkplain EvidenceCategory#name}.
   */
  protected class EvidenceCategoryComparator implements
    Comparator<EvidenceCategory> {

    public EvidenceCategoryComparator() {// None required
    }

    /**
     * Sort based on evidence category code sort order and name.
     */
    public int compare(final EvidenceCategory o1, final EvidenceCategory o2) {

      final int result = Long.valueOf(o1.getSortOrder()).compareTo(
        Long.valueOf(o2.getSortOrder()));

      if (result == 0) {
        return o1.getName().compareTo(o2.getName());
      }

      return result;
    }
  }


  /**
   * Comparator class for {@linkplain EvidenceTypeAdminDetails}. The comparison
   * is evaluated from the {@linkplain EvidenceTypeAdminDetails#sortOrder}.
   */
  protected class EvidenceTypeComparator implements
    Comparator<EvidenceTypeAdminDetails> {

    EvidenceTypeComparator() {// Constructor required because without one (that
      // is not protected) and the
      // class being protected a performance warning is present.
    }

    /**
     * {@inheritDoc}
     */
    public int compare(
      final EvidenceTypeAdminDetails evidenceTypeAdminDetails1,
      final EvidenceTypeAdminDetails evidenceTypeAdminDetails2) {

      final Long long1 = new Long(evidenceTypeAdminDetails1.sortOrder);
      final Long long2 = new Long(evidenceTypeAdminDetails2.sortOrder);

      return long1.compareTo(long2);

    }
  }


  /**
   * Comparator class for <code>Elements</code> of the following structure <br/>
   * <br/>
   * <b><i>{@code <coverref reference="evidence type"/> }</i></b> <br/>
   * <br/>
   * where the <b>reference</b> attribute value should be a
   * {@linkplain CASEEVEINDCEEnty} code.
   *
   * <br/>
   * <br/>
   * The comparator compares the localized <code>String</code> description of
   * the evidence type from {@linkplain CASEEVEINDCEEnty}.
   *
   */
  protected class CoverRefComparator implements Comparator<Element> {

    CoverRefComparator() {// Constructor required because without one (that is
      // not protected) and the
      // class being protected a performance warning is present.
    }

    /**
     * {@inheritDoc}
     */
    public int compare(final Element element1, final Element element2) {

      // Extract both code-table codes from the elements.
      final String code1 = element1.getAttributeValue(
        EvidenceFlowXMLConst.kReference);
      final String code2 = element2.getAttributeValue(
        EvidenceFlowXMLConst.kReference);

      // Get the localized descriptions for both codes.
      final String localizedDescription1 = CASEEVIDENCEEntry.get(code1).toUserLocaleString();

      final String localizedDescription2 = CASEEVIDENCEEntry.get(code2).toUserLocaleString();

      // Return the comparison of both localized strings.
      return localizedDescription1.compareTo(localizedDescription2);

    }
  }
}
