/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidence.evidenceflow.impl;


import java.util.SortedSet;

import com.google.inject.Inject;
import com.google.inject.Injector;

import curam.core.sl.infrastructure.impl.TransactionPreCommitHandler;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * Class to provide pre commit phase processing required for the Evidence Flow.
 */
public class EvidenceFlowTransactionCallbackHandler implements TransactionPreCommitHandler {

  @Inject
  private CaseHeaderDAO caseHeaderDAO;
  
  @Inject
  private EvidenceFlowReloadDAO evidenceFlowReloadDAO;
  
  /**
   * Method to perform pre commit point processing for the evidence flow.
   * This method checks for requests to update the evidence flow reload table
   * from within the current transaction and updates the appropriate rows.
   */
  public void preCommit() throws AppRuntimeException {
    
    SortedSet<Long> reloadCaseSet = EvidenceFlowUtility.getEvidenceFlowReloadRequests();
    
    if (caseHeaderDAO == null || evidenceFlowReloadDAO == null) {
      final Injector injector = GuiceWrapper.getInjector();

      if (injector != null) {

        /*
         * if we're being called from the commit inside the
         * GuiceWrapper set up itself, then no injector will be
         * available yet
         */
        injector.injectMembers(this);
      }
    }
    
    if (caseHeaderDAO == null || evidenceFlowReloadDAO == null) {
      return;
    }
    
    for (Long caseIDLong : reloadCaseSet) {
    
      try {
        final CaseHeader caseHeader = caseHeaderDAO.get(caseIDLong.longValue());
      
        final EvidenceFlowReload evidenceFlowReload = evidenceFlowReloadDAO.read(
          caseHeader);

        evidenceFlowReload.dataChanged();
      } catch (InformationalException e) {// log error and continue to process other reload requests.
      }

    }
          
  }

}
