/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.evidence.evidenceflow.impl;


import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import curam.util.transaction.TransactionInfo;


/**
 * Utility class for evidence flow processing.
 */
public final class EvidenceFlowUtility {
  
  protected EvidenceFlowUtility() {// blank constructor - should never be called
  }
  
  /**
   * name of the thread local transaction object for evidence flow reload requests.
   */
  private static final String kReloadRequestObject = "EFReload";

  /**
   * When changes happen that need to be reflected on the EvidenceFlow screen, this method should
   * be called to ensure that the EvidenceFlow screen for the case is updated accordingly.
   *
   * @param caseID ID of the case whose EvidenceFlow needs to be updated.
   */
  @SuppressWarnings("unchecked")
  public static final void updateEvidenceFlow(long caseID) {
    
    Object setObject = TransactionInfo.getFacadeScopeObject(
      kReloadRequestObject);
    
    SortedSet<Long> caseIDSet = null;
    
    if (setObject == null) {
      caseIDSet = new TreeSet<Long>();
    } else if (setObject instanceof List<?>) {
      caseIDSet = (TreeSet<Long>) setObject;
    } else {
      caseIDSet = new TreeSet<Long>();
    }
    
    Long caseIDLong = new Long(caseID);
    
    if (!caseIDSet.contains(caseIDLong)) {
      caseIDSet.add(caseIDLong);
    }
    
    TransactionInfo.setFacadeScopeObject(kReloadRequestObject, caseIDSet);
  }
  
  /**
   * Method to retrieve the list of requests to update the evidence flow table.
   *
   * @return SortedSet of caseIDs whose evidence flow reload entry should be updated.
   */
  @SuppressWarnings("unchecked")
  static SortedSet<Long> getEvidenceFlowReloadRequests() {
    
    Object setObject = TransactionInfo.getFacadeScopeObject(
      kReloadRequestObject);
      
    SortedSet<Long> caseIDSet = null;
      
    if (setObject == null) {
      caseIDSet = new TreeSet<Long>();
    } else if (setObject instanceof TreeSet<?>) {
      caseIDSet = (TreeSet<Long>) setObject;
    } else {
      caseIDSet = new TreeSet<Long>();
    }
    
    return caseIDSet;
  }
}
