package curam.diona.mobility.socialworker.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;
import com.google.code.geocoder.Geocoder;
import com.google.code.geocoder.GeocoderRequestBuilder;
import com.google.code.geocoder.model.GeocodeResponse;
import com.google.code.geocoder.model.GeocoderGeometry;
import com.google.code.geocoder.model.GeocoderRequest;
import com.google.code.geocoder.model.GeocoderResult;
import com.google.code.geocoder.model.GeocoderResultType;
import com.google.code.geocoder.model.GeocoderStatus;
import com.google.code.geocoder.model.LatLng;
import curam.core.sl.struct.GeoCodeDetails;
import curam.core.struct.OtherAddressData;
import curam.core.sl.fact.GeoCodeFactory;
import curam.util.resources.Configuration;
import curam.codetable.ACTIVITYATTENDEETYPE;
import curam.core.facade.struct.ActivityAttendeeDetails;
import curam.core.facade.struct.ActivityAttendeeList;
import curam.core.struct.MaintainAttendeeActivityKey;
import curam.core.sl.entity.struct.OrgStructureAndOrgUnitKey;
import curam.core.facade.intf.Organization;
import curam.core.facade.fact.OrganizationFactory;
import curam.core.sl.struct.OrganisationUnitDetailsAndUserList;
import curam.core.facade.struct.OrgStructureAndPositionKey;
import curam.core.facade.struct.ListUserForPositionDetails;
import curam.core.facade.intf.WorkAllocation;
import curam.core.facade.fact.WorkAllocationFactory;
import curam.core.sl.struct.ListWorkQueueSubscriptionsKey;
import curam.core.sl.struct.ListWorkQueueSubscriptions;
import curam.core.sl.entity.struct.WorkQueueSubscriptionFullDetails;
		
import javax.xml.bind.JAXB;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;

import org.apache.commons.codec.binary.Base64;
import org.w3c.dom.Document;

import com.google.inject.Inject;

import curam.codetable.ACTIVITYPRIORITY;
import curam.codetable.ACTIVITYTIMESTATUS;
import curam.codetable.ACTIVITYTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.facade.fact.ActivityFactory;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.fact.PersonFactory;
import curam.core.facade.intf.Activity;
import curam.core.facade.intf.Case;
import curam.core.facade.intf.Person;
import curam.core.facade.struct.ActivityDetails;
import curam.core.facade.struct.ActivityIdKey;
import curam.core.facade.struct.ActivityListViewDetails;
import curam.core.facade.struct.ListCaseAttachmentDetails;
import curam.core.facade.struct.ListCaseAttachmentKey;
import curam.core.facade.struct.ListCaseByCurrentUserKey;
import curam.core.facade.struct.ListCasesForUserDetails;
import curam.core.facade.struct.ReadCaseAttachmentDetails;
import curam.core.facade.struct.ReadCaseAttachmentKey;
import curam.core.facade.struct.ReadParticipantPhoneNumberList;
import curam.core.facade.struct.ReadParticipantPhoneNumberListKey;
import curam.core.facade.struct.ReadPersonDetails;
import curam.core.facade.struct.ReadPersonKey;
import curam.core.facade.struct.ViewRecurringUserActivityDetails;
import curam.core.sl.struct.CaseKey;
import curam.core.sl.struct.CaseParticipantDetails;
import curam.core.sl.struct.SearchCaseParticipantDetails;
import curam.core.sl.struct.SearchCaseParticipantDetailsKey;
import curam.core.sl.struct.SearchCaseParticipantDetailsList;
import curam.core.struct.ActivityDtls;
import curam.core.struct.ActivityKey;
import curam.core.struct.ActivityListDetails;
import curam.core.struct.AttachmentDetails;
import curam.core.struct.CaseAndConcernSummaryDetails;
import curam.core.struct.PhoneRMDtls;
import curam.core.struct.UserActivityDetails;
import curam.core.struct.UserActivityDetailsList;
import curam.diona.mobility.socialworker.struct.CaseListByUsernameKey;
import curam.diona.mobility.socialworker.struct.CaseListByUsernameResult;
import curam.diona.mobility.socialworker.struct.CaseMembersDetails;
import curam.diona.mobility.socialworker.struct.CaseNote;
import curam.diona.mobility.socialworker.struct.CaseNoteInsertKey;
import curam.diona.mobility.socialworker.struct.CaseNoteInsertResult;
import curam.diona.mobility.socialworker.struct.CaseNoteListByCaseIDKey;
import curam.diona.mobility.socialworker.struct.CaseNoteListByCaseIDResult;
import curam.diona.mobility.socialworker.struct.CaseNoteModifyKey;
import curam.diona.mobility.socialworker.struct.CaseReadByCaseIDKey;
import curam.diona.mobility.socialworker.struct.CaseReadByCaseIDResult;
import curam.diona.mobility.socialworker.struct.CaseVisit;
import curam.diona.mobility.socialworker.struct.CaseVisitInsertKey;
import curam.diona.mobility.socialworker.struct.CaseVisitInsertResult;
import curam.diona.mobility.socialworker.struct.CaseVisitListByCaseIDKey;
import curam.diona.mobility.socialworker.struct.CaseVisitListByCaseIDResult;
import curam.diona.mobility.socialworker.struct.CaseVisitListByUsernameDateTimeRangeKey;
import curam.diona.mobility.socialworker.struct.CaseVisitListByUsernameDateTimeRangeResult;
import curam.diona.mobility.socialworker.struct.CaseVisitModifyKey;
import curam.diona.mobility.socialworker.struct.Cases;
import curam.diona.mobility.socialworker.struct.CoordinatesDetails;
import curam.diona.mobility.socialworker.struct.DocumentHeaderList;
import curam.diona.mobility.socialworker.struct.DocumentHeaderListByCaseIDKey;
import curam.diona.mobility.socialworker.struct.DocumentHeaderListByCaseIDResult;
import curam.diona.mobility.socialworker.struct.DocumentHeaderReadByDocumentHeaderIDKey;
import curam.diona.mobility.socialworker.struct.DocumentHeaderReadByDocumentHeaderIDResult;
import curam.diona.mobility.socialworker.struct.EmptyResponse;
import curam.diona.mobility.socialworker.struct.LocationDetails;
import curam.diona.mobility.socialworker.struct.PhoneNumbersDetails;
import curam.diona.mobility.socialworker.struct.VisitNoteLinkInsertKey;
import curam.diona.mobility.socialworker.struct.VisitNoteLinkInsertResult;
import curam.diona.mobility.socialworker.struct.VisitNoteLinkListByCaseVisitIDKey;
import curam.diona.mobility.socialworker.struct.VisitNoteLinkListByCaseVisitIDResult;
import curam.diona.mobility.socialworker.struct.VisitNoteLinks;
import curam.meetings.facade.fact.MeetingManagementFactory;
import curam.meetings.facade.intf.MeetingManagement;
import curam.meetings.facade.struct.CreateMeetingDetails;
import curam.meetings.meetingminutes.facade.fact.MeetingMinutesManagementFactory;
import curam.meetings.meetingminutes.facade.struct.CaseMeetingDetails;
import curam.meetings.meetingminutes.facade.struct.MeetingCaseKey;
import curam.meetings.meetingminutes.facade.struct.MeetingDetailsSummaryList;
import curam.meetings.meetingminutes.facade.struct.RichTextMeetingMinutesDetails;
import curam.meetings.meetingminutes.facade.struct.RichTextMeetingNotesDetails;
import curam.meetings.meetingminutes.sl.impl.MeetingMinutes;
import curam.meetings.meetingminutes.sl.impl.MeetingMinutesDAO;
import curam.meetings.meetingminutes.sl.impl.MeetingNotes;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.piwrapper.casemanager.impl.CaseUserRoleDAO;
import curam.piwrapper.impl.EmailAddress;
import curam.piwrapper.impl.EmailAddressDAO;
import curam.piwrapper.organization.impl.OrgObjectLink;
import curam.piwrapper.user.impl.UserDAO;
import curam.sec.meetingminutes.entity.fact.MeetingLinkFactory;
import curam.sec.meetingminutes.entity.intf.MeetingLink;
import curam.sec.meetingminutes.entity.struct.MeetingMinutesKey;
import curam.sec.meetingminutes.facade.struct.CreateMeetingMinutesResult;
import curam.sec.meetingminutes.facade.struct.MeetingDetailsSummary;
import curam.sec.meetingminutes.facade.struct.MeetingNotesDetails;
import curam.sec.meetings.facade.struct.MeetingResult;
import curam.sec.meetings.facade.struct.ViewMeetingDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.exception.AppRuntimeException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;

public class SocialWorkerWS implements
			curam.diona.mobility.socialworker.intf.SocialWorkerWS {

	@Inject
	UserDAO userDAO;

	@Inject
	ConcernRoleDAO concernRoleDAO;

	@Inject
	CaseParticipantRoleDAO caseParticipantRoleDAO;

	@Inject
	CaseUserRoleDAO caseUserRoleDAO;

	@Inject
	CaseHeaderDAO caseHeaderDAO;

  @Inject
  EmailAddressDAO emailAddressDAO;
  
  @Inject
  MeetingMinutesDAO meetingMinutesDAO;

	/**
	 * Case Note subject is automatically set on creation to first n number of
	 * characters taken from the note text. This constant specifies how many
	 * characters to use.
	 */
	private static final int kMaxNoteSubjectLength = 40;

	private static final String kMeetingSubject ="Amerni Home Visit";
	
	/**
	 * Default Constructor
	 */
	public SocialWorkerWS() {
		GuiceWrapper.getInjector().injectMembers(this);

	}

	/**
	 * Returns list of all cases assigned to current user along with all the
	 * details about case members.
	 * 
	 * The argument passed in is: Case_listByUsernameKey.username
	 * 
	 * @param xmlMessage
	 *            containing case owner user name.
	 * @return details about the cases assigned to the user.
	 */
	public Document case_listByUsername(Document xmlMessage)
			throws AppException, InformationalException {

		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());

		String caseOwner = JAXB.unmarshal(source, CaseListByUsernameKey.class)
				.getUsername();

		Case caseObj = CaseFactory.newInstance();
		ListCaseByCurrentUserKey listCaseByCurrentUserKey = new ListCaseByCurrentUserKey();
		listCaseByCurrentUserKey.casesByOwnerKey.ownerID = caseOwner;

		ListCasesForUserDetails listCasesForUserDetails = caseObj
				.listAllCasesForUser(listCaseByCurrentUserKey);

		CaseListByUsernameResult case_listByUsernameResult = new CaseListByUsernameResult();
		for (CaseAndConcernSummaryDetails summaryDetails : listCasesForUserDetails.dtls.list.dtls) {

			Cases casesDtls = new Cases();

			if (summaryDetails.caseTypeCode.equalsIgnoreCase(CASETYPECODE.INTEGRATEDCASE)
				|| summaryDetails.caseTypeCode.equalsIgnoreCase(CASETYPECODE.PRODUCTDELIVERY)) {
				if (summaryDetails.statusCode != CASESTATUS.CANCELED
						&& summaryDetails.statusCode != CASESTATUS.CLOSED) {
						
					casesDtls.setCaseID(Long.toString(summaryDetails.caseID));
					casesDtls.setReference(caseHeaderDAO.get(summaryDetails.caseID)
						.getCaseReference());
					casesDtls.setLocation(getCaseLocation(summaryDetails.caseID));
					casesDtls
						.setDateAssigned(getXMLGregCalCuramDate(getCaseAssignedDate(summaryDetails.caseID)));
					casesDtls.setUsername(caseOwner);
					List<CaseMembersDetails> listOfMembers = getCaseMemberList(summaryDetails.caseID);
					casesDtls.getMembers().addAll(listOfMembers);

					case_listByUsernameResult.getCases().add(casesDtls);
				}
			}
		}
		DOMResult result = new DOMResult();
		JAXB.marshal(case_listByUsernameResult, result);
		return (Document) result.getNode();

	}

	/**
	 * A method used to add meeting minute for a case.
	 * 
	 * @param Document
	 * @return Document
	 * 
	 * @throws AppException
	 * @throws InformationalException
	 */
	public Document caseNote_insert(Document xmlMessage) throws AppException,
			InformationalException {

		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
		CaseNoteInsertKey createCaseNoteKey = JAXB.unmarshal(source,
				CaseNoteInsertKey.class);
		String notesText = createCaseNoteKey.getContents();
		DateTime createdDateTime = new DateTime(
				(createCaseNoteKey.getCreatedDateTime()).toGregorianCalendar());

		curam.meetings.meetingminutes.facade.intf.MeetingMinutesManagement meetingMinutesObj = MeetingMinutesManagementFactory
				.newInstance();
		MeetingCaseKey paramMeetingCaseKey = new MeetingCaseKey();
		ActivityKey paramActivityKey = new ActivityKey();
		RichTextMeetingMinutesDetails paramRichTextMeetingMinutesDetails = new RichTextMeetingMinutesDetails();

		// Set the caseID for meeting creation
		paramMeetingCaseKey.caseID = Long.parseLong(createCaseNoteKey
				.getCaseID());

		// Link meeting minutes to meeting
		// TODO Activity code to be set to meeting activity ID
		paramActivityKey.activityID = 0l;

		// Populate details required for meeting minute
		paramRichTextMeetingMinutesDetails.organizedByOptions.byMeInd = true;
		paramRichTextMeetingMinutesDetails.richTextMeetingAgenda = "";

		paramRichTextMeetingMinutesDetails.dtls.subject = kMeetingSubject;
		paramRichTextMeetingMinutesDetails.dtls.sensitivityCode = userDAO
				.get(TransactionInfo.getProgramUser()).getSensitivity()
				.getCode();
		paramRichTextMeetingMinutesDetails.dtls.meetingAgenda = null;

		// TODO Date to be changed to meeting start date if we get meeting
		// activity ID param
		paramRichTextMeetingMinutesDetails.dtls.startTime = DateTime
				.getCurrentDateTime().addTime(1, 0, 0);
		paramRichTextMeetingMinutesDetails.dtls.endTime = DateTime
				.getCurrentDateTime().addTime(2, 0, 0);
		paramRichTextMeetingMinutesDetails.dtls.allDayEvent = false;

		CreateMeetingMinutesResult meetingResult = meetingMinutesObj
				.createOrUpdateMeetingDetails(paramMeetingCaseKey,
						paramActivityKey, paramRichTextMeetingMinutesDetails);
						
		MeetingMinutesKey paramMeetingMinutesKey = new MeetingMinutesKey();
    	paramMeetingMinutesKey.meetingID = meetingResult.meetingID;
    
    	MeetingNotesDetails existingNotesDtls = meetingMinutesObj
        .readMeetingNotes(paramMeetingMinutesKey);
		
		 // Populate updated details and modify the record
    	RichTextMeetingNotesDetails paramRichTextMeetingNotesDetails = new RichTextMeetingNotesDetails();
    	paramRichTextMeetingNotesDetails.dtls.meetingID = meetingResult.meetingID;
    	paramRichTextMeetingNotesDetails.dtls.meetingNotesID = existingNotesDtls.notesDtls.meetingNotesID;
    	paramRichTextMeetingNotesDetails.richTextMeetingNotes = notesText;
    	paramRichTextMeetingNotesDetails.dtls.recordStatus = existingNotesDtls.notesDtls.recordStatus;
    	paramRichTextMeetingNotesDetails.dtls.versionNo = existingNotesDtls.notesDtls.versionNo;
    	meetingMinutesObj.updateMeetingNotes(paramRichTextMeetingNotesDetails);

		CaseNoteInsertResult response = new CaseNoteInsertResult();
		response.setCaseNoteID((Long.toString(meetingResult.meetingID)));
		DOMResult domResult = new DOMResult();
		JAXB.marshal(response, domResult);

		return (Document) domResult.getNode();

	}

	/**
	 * A method to schedule an appointment (create visit).
	 * 
	 * @param xmlMessage
	 *            contains creation details: caseID, startDateTime, endDateTime
	 * @return id of the newly created appointment
	 */
	public Document caseVisit_insert(Document xmlMessage) throws AppException,
			InformationalException {

		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
		CaseVisitInsertKey caseVisitInsertKey = JAXB.unmarshal(source,
				CaseVisitInsertKey.class);
		// Call meeting creation
		CaseVisitInsertResult createAppointmentDetails = createCuramActivity(caseVisitInsertKey);
		DOMResult domResult = new DOMResult();
		JAXB.marshal(createAppointmentDetails, domResult);
		return (Document) domResult.getNode();

	}

	/**
	 * Returns details about the case and its members.
	 * 
	 * @param xmlMessage
	 *            contains case unique identifier
	 * 
	 * @return Structure containing case details and list of case members with
	 *         appropriate details.
	 */
	public Document case_readByCaseID(Document xmlMessage) throws AppException,
			InformationalException {
		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
		CaseReadByCaseIDKey readCaseDetailsKey = JAXB.unmarshal(source,
				CaseReadByCaseIDKey.class);

		CaseReadByCaseIDResult Case_readByCaseIDResult = new CaseReadByCaseIDResult();
		Cases caseDtls = new Cases();

		Long caseID = Long.parseLong(readCaseDetailsKey.getCaseID());

		caseDtls.setCaseID(readCaseDetailsKey.getCaseID());
		caseDtls.setReference(caseHeaderDAO.get(caseID).getCaseReference());
		caseDtls.setLocation(getCaseLocation(caseID));

		Date assignedDate = getCaseAssignedDate(caseID);
		caseDtls.setDateAssigned(getXMLGregCalCuramDate(assignedDate));
		
        String caseOwner = getCaseOwner(caseID);
        if (caseOwner.equals("")) {
          if (isCurrentUserCaseOwner(caseID)) {
            caseOwner = TransactionInfo.getProgramUser();
          }
        }
        caseDtls.setUsername(caseOwner);

		List<CaseMembersDetails> caseMemberDetailsList = getCaseMemberList(caseID);
		caseDtls.getMembers().addAll(caseMemberDetailsList);

		Case_readByCaseIDResult.setCase(caseDtls);

		DOMResult domResult = new DOMResult();
		JAXB.marshal(Case_readByCaseIDResult, domResult);
		return (Document) domResult.getNode();
	}

	/**
	 * Cancels the appointment and schedules a new one.
	 * 
	 * @param xmlMessage
	 *            containing unique ID of the activity that needs to be
	 *            rescheduled and new activity start and end date and time.
	 * @return activity unique ID.
	 * 
	 */
	public Document caseVisit_modify(Document xmlMessage) throws AppException,
			InformationalException {

		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
		CaseVisitModifyKey rescheduleAppointmentKey = JAXB.unmarshal(source,
				CaseVisitModifyKey.class);

		// Note: I intended to use cancelStandardUserActivity() operation, but
		// it is
		// throwing an exception: java.lang.NoClassDefFoundError:
		// curam/events/ACTIVITY

		// Read activity details in order to obtain caseID and versionNo
		Activity activityObj = ActivityFactory.newInstance();
		ActivityIdKey activityIdKey = new ActivityIdKey();
		activityIdKey.activityID = Long.parseLong(rescheduleAppointmentKey
				.getCaseVisitID());
		ViewRecurringUserActivityDetails activityDetails = activityObj
				.readActivityDetailsAndInviteesList(activityIdKey);
		// Modify old activity
		ActivityDetails newActivityDetails = new ActivityDetails();
		// Assign operation is not working!!!
		// newActivityDetails.assign(activityDetails);

		newActivityDetails.activityID = Long.parseLong(rescheduleAppointmentKey
				.getCaseVisitID());
		newActivityDetails.activityTypeCode = ACTIVITYTYPE.MEETING;
		newActivityDetails.allDayInd = false;
		newActivityDetails.caseID = activityDetails.maintainRecurringUserActivityDetails.caseID;
		newActivityDetails.concernRoleID = activityDetails.maintainRecurringUserActivityDetails.concernRoleID;

		newActivityDetails.locationID = activityDetails.maintainRecurringUserActivityDetails.locationID;
		newActivityDetails.locationName = activityDetails.maintainRecurringUserActivityDetails.locationName;
		newActivityDetails.notes = activityDetails.maintainRecurringUserActivityDetails.notes;
		// newActivityDetails.organisationID =
		newActivityDetails.priorityCode = ACTIVITYPRIORITY.MEDIUM;
		newActivityDetails.recordStatusCode = RECORDSTATUS.NORMAL;
		newActivityDetails.recurrenceID = activityDetails.maintainRecurringUserActivityDetails.recurrenceID;
		// newActivityDetails.slotAllocationID =
		newActivityDetails.startDateTime = new DateTime(
				(rescheduleAppointmentKey.getStartDateTime())
						.toGregorianCalendar());
		newActivityDetails.endDateTime = new DateTime(
				(rescheduleAppointmentKey.getEndDateTime())
						.toGregorianCalendar());
		newActivityDetails.subject = activityDetails.maintainRecurringUserActivityDetails.subject;
		newActivityDetails.timeStatusCode = activityDetails.maintainRecurringUserActivityDetails.timeStatusCode;

		// newActivityDetails.userName = TransactionInfo.getProgramUser();
		curam.core.intf.Activity activitySLObj = curam.core.fact.ActivityFactory.newInstance();
		ActivityKey activityKey = new ActivityKey();
		activityKey.activityID = Long.parseLong(rescheduleAppointmentKey
			.getCaseVisitID());
		newActivityDetails.userName = activitySLObj.read(activityKey).userName;
       

		newActivityDetails.versionNo = activityDetails.maintainRecurringUserActivityDetails.versionNo;

		activityObj.modifyActivity(activityIdKey, newActivityDetails);

		EmptyResponse emptyResponse = new EmptyResponse();
		emptyResponse.setEmpty("");
		DOMResult domResult = new DOMResult();
		JAXB.marshal(emptyResponse, domResult);
		return (Document) domResult.getNode();

	}

	/**
	 * A method used to modify meeting minutes for a case.
	 * 
	 * @param Document
	 * @return Document
	 * 
	 * @throws AppException
	 * @throws InformationalException
	 */
	public Document caseNote_modify(Document xmlMessage) throws AppException,
			InformationalException {

		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
		CaseNoteModifyKey modifyCaseNoteKey = JAXB.unmarshal(source,
				CaseNoteModifyKey.class);

		curam.meetings.meetingminutes.facade.intf.MeetingMinutesManagement meetingMinutesObj = MeetingMinutesManagementFactory
				.newInstance();
		MeetingMinutesKey paramMeetingMinutesKey = new MeetingMinutesKey();
		paramMeetingMinutesKey.meetingID = Long.valueOf(modifyCaseNoteKey
				.getCaseNoteID().toString());
		// Read existing notes based on the meeting minute
		MeetingNotesDetails existingNotesDtls = meetingMinutesObj
				.readMeetingNotes(paramMeetingMinutesKey);

		// Populate updated details and modify the record
		RichTextMeetingNotesDetails paramRichTextMeetingNotesDetails = new RichTextMeetingNotesDetails();
		paramRichTextMeetingNotesDetails.dtls.meetingID = Long
				.valueOf(modifyCaseNoteKey.getCaseNoteID().toString());
		paramRichTextMeetingNotesDetails.dtls.meetingNotesID = existingNotesDtls.notesDtls.meetingNotesID;
		paramRichTextMeetingNotesDetails.richTextMeetingNotes = modifyCaseNoteKey
				.getContents();
		paramRichTextMeetingNotesDetails.dtls.recordStatus = existingNotesDtls.notesDtls.recordStatus;
		paramRichTextMeetingNotesDetails.dtls.versionNo = existingNotesDtls.notesDtls.versionNo;
		meetingMinutesObj.updateMeetingNotes(paramRichTextMeetingNotesDetails);

		DOMResult domResult = new DOMResult();
		EmptyResponse emptyResponce = new EmptyResponse();
		emptyResponce.setEmpty("");
		JAXB.marshal(emptyResponce, domResult);
		return (Document) domResult.getNode();

	}

	/**
	 * Returns visit details list.
	 * 
	 * @param xmlMessage
	 *            containing: username, startDateTime, endDateTime
	 * @return AppointmentsList
	 */
	public Document caseVisit_listByUsernameDateTimeRange(Document xmlMessage)
			throws AppException, InformationalException {

		CaseVisitListByUsernameDateTimeRangeResult cvList = new CaseVisitListByUsernameDateTimeRangeResult();
		CaseVisit caseVisit;

		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
		CaseVisitListByUsernameDateTimeRangeKey caseVisitListByUsernameDateTimeRangeKey = JAXB
				.unmarshal(source,
						CaseVisitListByUsernameDateTimeRangeKey.class);

		XMLGregorianCalendar startDateTimeXML = caseVisitListByUsernameDateTimeRangeKey
				.getStartDateTime();
		XMLGregorianCalendar endDateTimeXML = caseVisitListByUsernameDateTimeRangeKey
				.getEndDateTime();
		String username = caseVisitListByUsernameDateTimeRangeKey.getUsername();

		DateTime startDateTime = new DateTime(
				startDateTimeXML.toGregorianCalendar());
		DateTime endDateTime = new DateTime(
				endDateTimeXML.toGregorianCalendar());

		Activity activityObj = ActivityFactory.newInstance();
		ActivityIdKey activityIDKey = new ActivityIdKey();
		ViewRecurringUserActivityDetails viewActivityDetails;

    UserActivityDetailsList userActivityDetailsList = activityObj.listActivityAndAttendanceForCurrentUser();
    // iterate the list to filter out all activities that do not have start
    // date in the next 24 hours
    for (UserActivityDetails userActivityDetails : userActivityDetailsList.dtls) {
      if (userActivityDetails.activityTypeCode.equals(ACTIVITYTYPE.MEETING)) {

        // The list method only returns date, so a separate read is
        // required to obtain datetime.
        activityIDKey.activityID = userActivityDetails.activityID;
        viewActivityDetails = activityObj
            .readActivityDetailsAndInviteesList(activityIDKey);
        DateTime activityStartDateTime = viewActivityDetails.maintainRecurringUserActivityDetails.startDateTime;

        if (!activityStartDateTime.before(startDateTime)
            && !activityStartDateTime.after(endDateTime)) {

          caseVisit = new CaseVisit();

          caseVisit.setCaseVisitID(Long
              .toString(userActivityDetails.activityID));
          caseVisit.setCaseID(Long.toString(userActivityDetails.caseID));
          caseVisit.setUsername(username);

          caseVisit
              .setStartDateTime(getXMLGregCalDateTime(activityStartDateTime));
          caseVisit
              .setEndDateTime(getXMLGregCalDateTime(viewActivityDetails.maintainRecurringUserActivityDetails.endDateTime));

          cvList.getCaseVisit().add(caseVisit);
        }
      }

    }

    DOMResult result = new DOMResult();
    JAXB.marshal(cvList, result);
    return (Document) result.getNode();

  }

	/**
	 * Returns details about notes associated with a case.
	 * 
	 * @param xmlMessage
	 *            containing CaseID.
	 * @return Notes details list.
	 */
	public Document caseNote_listByCaseID(Document xmlMessage)
			throws AppException, InformationalException {

		// TODO Review (caseID parmeter is meeting ID)

		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
		CaseNoteListByCaseIDKey readCaseNotesKey = JAXB.unmarshal(source,
				CaseNoteListByCaseIDKey.class);

		List<CaseNote> caseNoteDetailsList = getCaseNoteList(Long
				.parseLong(readCaseNotesKey.getCaseID()));

		CaseNoteListByCaseIDResult caseNoteListByCaseIDResult = new CaseNoteListByCaseIDResult();

		caseNoteListByCaseIDResult.getCaseNote().addAll(caseNoteDetailsList);

		DOMResult domResult = new DOMResult();
		JAXB.marshal(caseNoteListByCaseIDResult, domResult);
		return (Document) domResult.getNode();
	}

	/**
	 * Returns details about documents associated with a case.
	 * 
	 * @param xmlMessage
	 *            containing CaseID.
	 * @return Documents details list.
	 */
	public Document documentHeader_listByCaseID(Document xmlMessage)
			throws AppException, InformationalException {

		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
		DocumentHeaderListByCaseIDKey listKey = JAXB.unmarshal(source,
				DocumentHeaderListByCaseIDKey.class);

		Case caseObj = CaseFactory.newInstance();

		ListCaseAttachmentKey listCaseAttachmentKey = new ListCaseAttachmentKey();
		listCaseAttachmentKey.attachmentCaseID.caseID = Long.parseLong(listKey
				.getCaseID());
		ListCaseAttachmentDetails listCaseAttachmentDetails = caseObj
				.listCaseAttachment(listCaseAttachmentKey);

		DocumentHeaderListByCaseIDResult listResult = new DocumentHeaderListByCaseIDResult();

		DocumentHeaderList documentHeader;
		ReadCaseAttachmentKey readCaseAttachmentKey;
		ReadCaseAttachmentDetails caseAttachmentDetails;

		for (AttachmentDetails attachmentDetails : listCaseAttachmentDetails.attachmentDetailsList.dtls) {
			documentHeader = new DocumentHeaderList();
			documentHeader.setDocumentHeaderID(Long
					.toString(attachmentDetails.caseAttachmentLinkID));
			documentHeader.setCaseID(Long.toString(attachmentDetails.caseID));

			documentHeader
					.setCreatedDateTime(getXMLGregCalDateTime(attachmentDetails.attachmentDate
							.getDateTime()));

			// mandatory field in schema, but has no meaning in Curam
			documentHeader.setDocumentDataBinaryID("");

			readCaseAttachmentKey = new ReadCaseAttachmentKey();
			readCaseAttachmentKey.readCaseAttachmentIn.attachmentID = attachmentDetails.attachmentID;
			readCaseAttachmentKey.readCaseAttachmentIn.caseAttachmentLinkID = attachmentDetails.caseAttachmentLinkID;

			caseAttachmentDetails = caseObj
					.readCaseAttachment(readCaseAttachmentKey);
			setDocumentFileAttributes(caseAttachmentDetails, documentHeader);

			listResult.getDocumentHeaderList().add(documentHeader);
		}

		DOMResult domResult = new DOMResult();
		JAXB.marshal(listResult, domResult);
		return (Document) domResult.getNode();

	}

	/**
	 * Reads a document.
	 * 
	 * @param xmlMessage
	 *            containing DocumentID.
	 * @return Documents
	 */
	public Document documentHeader_readByDocumentHeaderID(Document xmlMessage)
			throws AppException, InformationalException {

		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
		DocumentHeaderReadByDocumentHeaderIDKey readKey = JAXB.unmarshal(
				source, DocumentHeaderReadByDocumentHeaderIDKey.class);

		DocumentHeaderReadByDocumentHeaderIDResult readResult = new DocumentHeaderReadByDocumentHeaderIDResult();

		Case caseObj = CaseFactory.newInstance();
		ReadCaseAttachmentKey readCaseAttachmentKey = new ReadCaseAttachmentKey();

		readCaseAttachmentKey.readCaseAttachmentIn.caseAttachmentLinkID = Long
				.parseLong(readKey.getDocumentHeaderID());

		ReadCaseAttachmentDetails caseAttachmentDetails = caseObj
				.readCaseAttachment(readCaseAttachmentKey);
		curam.diona.mobility.socialworker.struct.DocumentHeader document = new curam.diona.mobility.socialworker.struct.DocumentHeader();

		byte[] byteData = caseAttachmentDetails.readCaseAttachmentOut.attachmentContents
				.copyBytes();

		String encodedStringData = Base64.encodeBase64String(byteData);
		document.setBinaryData(encodedStringData);

		document.setDocumentHeaderID(readKey.getDocumentHeaderID());

		// Set all other attributes to empty string. This is because they were
		// made
		// mandatory in the schema, but are actually unused from this operation
		// (same
		// struct is used from listDocuments, and that's where they are used
		// from.
		document.setCaseID("");
		DateTime dt = DateTime.kZeroDateTime;
		document.setCreatedDateTime(getXMLGregCalDateTime(dt));
		document.setDocumentDataBinaryID("");
		document.setExtension("");
		document.setSize("");
		document.setTitle("");

		readResult.setDocumentHeader(document);

		DOMResult domResult = new DOMResult();
		JAXB.marshal(readResult, domResult);
		return (Document) domResult.getNode();
	}

	/**
	 * Returns a list of past and future visits for a case.
	 * 
	 * @param xmlMessage
	 *            containing caseID.
	 * @return AppointmentsList
	 */
	public Document caseVisit_listByCaseID(Document xmlMessage)
			throws AppException, InformationalException {

		DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
		CaseVisitListByCaseIDKey listKey = JAXB.unmarshal(source,
				CaseVisitListByCaseIDKey.class);
		CaseVisitListByCaseIDResult listResult = new CaseVisitListByCaseIDResult();

		curam.core.facade.intf.Activity activityObj = curam.core.facade.fact.ActivityFactory
				.newInstance();

		ActivityIdKey activityIDKey = new ActivityIdKey();
		ViewRecurringUserActivityDetails viewActivityDetails;
		CaseVisit caseVisit;

		ActivityListViewDetails activityList = activityObj
				.listActivityForCurrentUser();
		// iterate the list to filter out all activities that do not relate to
		// the case
		for (ActivityListDetails activityDetails : activityList.activityList.dtls) {
			if (activityDetails.activityTypeCode.equals(ACTIVITYTYPE.MEETING)
					&& activityDetails.caseID == Long.parseLong(listKey
							.getCaseID())
                    && (isCurentUserAttendee(activityDetails.activityID))) {

				caseVisit = new CaseVisit();
				caseVisit.setCaseID(listKey.getCaseID());
				caseVisit.setCaseVisitID(Long
						.toString(activityDetails.activityID));
				caseVisit.setUsername(TransactionInfo.getProgramUser());

				activityIDKey.activityID = activityDetails.activityID;
				viewActivityDetails = activityObj
						.readActivityDetailsAndInviteesList(activityIDKey);

				DateTime activityStart = viewActivityDetails.maintainRecurringUserActivityDetails.startDateTime;
				DateTime activityEnd = viewActivityDetails.maintainRecurringUserActivityDetails.endDateTime;

				caseVisit
						.setStartDateTime(getXMLGregCalDateTime(activityStart));
				caseVisit.setEndDateTime(getXMLGregCalDateTime(activityEnd));

				listResult.getCaseVisit().add(caseVisit);

			}
		}

		DOMResult domResult = new DOMResult();
		JAXB.marshal(listResult, domResult);
		return (Document) domResult.getNode();
	}

	/**
	 * Method that returns date on which the case was assigned to its current
	 * owner.
	 * 
	 * @param caseID
	 * @return Date on which the case was assigned to the current owner.
	 */
	private Date getCaseAssignedDate(Long caseID) {
		CaseHeader caseHeader = caseHeaderDAO.get(caseID);
		List<curam.piwrapper.casemanager.impl.CaseUserRole> caseUserRoleList = caseUserRoleDAO
				.listActiveByCase(caseHeader);

		DateRange dateRange = null;
		for (int i = 0; i < caseUserRoleList.size(); i++) {
			if ((caseUserRoleList.get(i).getType().toString())
					.equals(CASEUSERROLETYPE.OWNER)) {
				if ((caseUserRoleList.get(i).getRecordStatus().toString())
						.equals(RECORDSTATUS.NORMAL)) {
					dateRange = caseUserRoleList.get(i).getDateRange();
					break;
				}
			}
		}

		if (dateRange != null) {
			return dateRange.start();
		} else {
			return null;
		}

	}

	/**
	 * Returns location of the case's primary client primary address.
	 * 
	 * @throws InformationalException
	 * @throws AppException
	 */
	private LocationDetails getCaseLocation(Long caseID) throws AppException,
			InformationalException {

		Case caseObj = CaseFactory.newInstance();
		CaseKey caseKey = new CaseKey();
		caseKey.key.caseID = caseID;
		CaseParticipantDetails caseParticipantDetails = caseObj
				.getPrimaryCaseParticipantDetails(caseKey);

		ConcernRole concernRoleObj = concernRoleDAO
				.get(caseParticipantDetails.participantRoleID);

		curam.piwrapper.impl.Address addrObj = concernRoleObj
				.getPrimaryAddress();
        boolean retriveLatLng = false;
        if ((addrObj.getLongitude() == null 
            || addrObj.getLongitude().doubleValue() == 0D)
            && (addrObj.getLatitude() == null 
            || addrObj.getLatitude().doubleValue() == 0D)) {
            retriveLatLng = true;
        }

		LocationDetails locationDetails = new LocationDetails();
		locationDetails.setAddress(addrObj.getOneLineAddressString());
		CoordinatesDetails coordinatesDetails = new CoordinatesDetails();
        if (retriveLatLng) {
            String address = addrObj.getOneLineAddressString();
            if (address != null && !address.isEmpty()) {
                StringBuilder addrTemp = new StringBuilder();
                String[] addressLinesArray = address.split(",");

                for (int i=0;i<addressLinesArray.length;i++) {
                    if (addressLinesArray.length > 2 &&    (i > 1)) {
                        addrTemp.append(addressLinesArray[i]);
                        if (i != (addressLinesArray.length - 1)) {
                            addrTemp.append(",");
                        }
                    }
                }
                if (addrTemp.toString().trim().isEmpty()) {
                    addrTemp.append(address);
                }

                GeoCodeDetails gd = getGeoCode(addrTemp.toString().trim());
                coordinatesDetails.setLatitude(gd.latitude);
                coordinatesDetails.setLongitude(gd.longitude);

            }
        } else {
            if (addrObj.getLatitude() != null) {
                coordinatesDetails.setLatitude(addrObj.getLatitude().doubleValue());
            }
            if (addrObj.getLongitude() != null) {
                coordinatesDetails.setLongitude(addrObj.getLongitude().doubleValue());
            }
        }
		locationDetails.setCoordinates(coordinatesDetails);
		return locationDetails;

	}

	/**
	 * Returns list of case members with appropriate details.
	 * 
	 * @param caseID
	 * @return details set for each member: name age date of birth email phone
	 *         number details list
	 * @throws InformationalException
	 * @throws AppException
	 */
	private List<CaseMembersDetails> getCaseMemberList(Long caseID)
			throws AppException, InformationalException {

		Case caseObj = CaseFactory.newInstance();

		SearchCaseParticipantDetailsKey searchCaseParticipantDetailsKey = new SearchCaseParticipantDetailsKey();
		searchCaseParticipantDetailsKey.caseID = caseID;
		searchCaseParticipantDetailsKey.caseParticipantTypeList = CASEPARTICIPANTROLETYPE.MEMBER;
		SearchCaseParticipantDetailsList searchCaseParticipantMembersList = caseObj
				.listCaseParticipant(searchCaseParticipantDetailsKey);
		// Primary client does not get returned among other members
		searchCaseParticipantDetailsKey.caseParticipantTypeList = CASEPARTICIPANTROLETYPE.PRIMARY;
		// Only one record is expected in the list
		SearchCaseParticipantDetailsList searchCaseParticipantPrimaryList = caseObj
				.listCaseParticipant(searchCaseParticipantDetailsKey);
		List<CaseMembersDetails> caseMembersDetailsList = new ArrayList<CaseMembersDetails>();
		populateCaseMemberDetailsList(caseMembersDetailsList,
				searchCaseParticipantMembersList);
		populateCaseMemberDetailsList(caseMembersDetailsList,
				searchCaseParticipantPrimaryList);

		return caseMembersDetailsList;
	}

	/**
	 * Method iterates participant list, collects participant information such
	 * as name, age, email address, and populates caseMembersDetailsList with
	 * this information.
	 * 
	 * @param caseMembersDetailsList
	 * @param participantList
	 * @throws InformationalException
	 * @throws AppException
	 */
	private void populateCaseMemberDetailsList(
			List<CaseMembersDetails> caseMembersDetailsList,
			SearchCaseParticipantDetailsList participantList)
			throws AppException, InformationalException {

		Person personObj = PersonFactory.newInstance();

		ReadPersonKey readPersonKey = new ReadPersonKey();
		ReadPersonDetails readPersonDetails;
		CaseMembersDetails caseMemberDetails;
		for (SearchCaseParticipantDetails caseParticipantDtls : participantList.searchCaseParticipantDetails) {
			caseMemberDetails = new CaseMembersDetails();
			caseMemberDetails.setName(caseParticipantDtls.name);

			CaseParticipantRole caseParticipantRoleObj = caseParticipantRoleDAO
					.get(caseParticipantDtls.caseParticipantRoleID);
			ConcernRole concernRoleObj = concernRoleDAO
					.get(caseParticipantRoleObj.getConcernRole().getID());
			readPersonKey.maintainConcernRoleKey.concernRoleID = concernRoleObj
					.getID();
			readPersonDetails = personObj.readPerson(readPersonKey);
			caseMemberDetails.setMemberID(Long
					.toString(caseParticipantDtls.caseParticipantRoleID));

			Date dob = readPersonDetails.personFurtherDetails.dateOfBirth;
			caseMemberDetails.setDateOfBirth(getXMLGregCalCuramDate(dob));

			EmailAddress emailAddressObj = emailAddressDAO.get(concernRoleObj
					.getPrimaryEmailAddressID());

			String email = null;
			try {
				email = emailAddressObj.getEmail();
			} catch (RecordNotFoundException e) {
				// do nothing - leave email empty
			}

			if (email != null) {
				caseMemberDetails.setEmail(email);
			}

			List<PhoneNumbersDetails> phoneNumberDetailsList = getPhoneNumberList(readPersonDetails.personFurtherDetails.concernRoleID);
			if (phoneNumberDetailsList.size() > 0) {
				caseMemberDetails.getPhoneNumbers().addAll(
						phoneNumberDetailsList);
			}
			caseMembersDetailsList.add(caseMemberDetails);
		}

	}

	/**
	 * Returns list of phone numbers for a given concern role.
	 * 
	 * @param concernRoleID
	 * @return List containing a list of strings formed by concatenating country
	 *         code, area code and phone number.
	 * @throws AppException
	 * @throws InformationalException
	 */
	private List<PhoneNumbersDetails> getPhoneNumberList(Long concernRoleID)
			throws AppException, InformationalException {

		List<PhoneNumbersDetails> phoneNumberDetailsList = new ArrayList<PhoneNumbersDetails>();
		;
		PhoneNumbersDetails phoneNumbersDetails;

		ReadParticipantPhoneNumberListKey phoneNoKey = new ReadParticipantPhoneNumberListKey();
		phoneNoKey.maintainPhoneNumberKey.concernRoleID = concernRoleID;
		Person personObj = PersonFactory.newInstance();
		ReadParticipantPhoneNumberList phoneNoList = personObj
				.listPhoneNumber(phoneNoKey);

		for (PhoneRMDtls phoneRMDtls : phoneNoList.readMultiByConcernRoleIDPhoneResult.details.dtls) {
			phoneNumbersDetails = new PhoneNumbersDetails();
			phoneNumbersDetails.setNumber(phoneRMDtls.phoneNumberString);
			phoneNumbersDetails.setPhoneID(Long
					.toString(phoneRMDtls.concernRolePhoneNumberID));
			phoneNumberDetailsList.add(phoneNumbersDetails);
		}

		return phoneNumberDetailsList;
	}

	/**
	 * Populates list of meetings related to the case.
	 * 
	 * @param caseID
	 * @return
	 * @throws AppException
	 * @throws InformationalException
	 */
	private List<CaseNote> getCaseNoteList(Long caseID) throws AppException,
			InformationalException {
		curam.meetings.meetingminutes.facade.intf.MeetingMinutesManagement meetingMinutesObj = MeetingMinutesManagementFactory
				.newInstance();
		MeetingCaseKey paramMeetingCaseKey = new MeetingCaseKey();
		paramMeetingCaseKey.caseID = caseID;
		MeetingDetailsSummaryList meetingDetailsList = meetingMinutesObj
				.listMeetingsForCase(paramMeetingCaseKey);
		CaseNote caseNotesDetails;
		curam.diona.mobility.socialworker.struct.ObjectFactory swObjectFactory = new curam.diona.mobility.socialworker.struct.ObjectFactory();
		List<CaseNote> caseNotesDetailsList = new ArrayList<CaseNote>();
		MeetingCaseKey meetingCaseKey = new MeetingCaseKey();
		MeetingMinutesKey meetingMinutesKey = new MeetingMinutesKey();
		
		for (MeetingDetailsSummary meetingDetails : meetingDetailsList.dtls
				.items()) {
			caseNotesDetails = swObjectFactory.createCaseNote();
			caseNotesDetails.setCaseID(Long.toString(caseID));
			meetingMinutesKey.meetingID = meetingDetails.meetingDetailsID;
			      meetingCaseKey.caseID = caseID;
				  CaseMeetingDetails meetingDtls = meetingMinutesObj
				  .readMeetingDetailsForCase(meetingMinutesKey,
              meetingCaseKey);
			caseNotesDetails.setCaseNoteID(String
					.valueOf(meetingDetails.meetingDetailsID));
			MeetingNotesDetails notesDetails = meetingMinutesObj
					.readMeetingNotes(meetingMinutesKey);
			String content = new String(notesDetails.notesDtls.notes);
        	content = content.replaceAll("\\<.*?>", "");
        	content = content.replaceAll("\\t", "");
        	content = content.replaceAll("\\&nbsp;", "");
      		caseNotesDetails.setContents(content);
	  		caseNotesDetails
					.setCreatedDateTime(getXMLGregCalDateTime(meetingDetails.startTime));
			caseNotesDetails.setAuthor(meetingDtls.organizerFullName);
			caseNotesDetailsList.add(caseNotesDetails);
		}
		return caseNotesDetailsList;
	}

	/**
	 * Creates an Activity of type Meeting.
	 * 
	 * @param createAppointmentKey
	 *            Contains unique identifier of the case to which the activity
	 *            is related, activity start and end date and time.
	 * 
	 * @return Unique identifier of the newly created activity.
	 * 
	 * @throws AppException
	 * @throws InformationalException
	 */
	private CaseVisitInsertResult createCuramActivity(
			CaseVisitInsertKey caseVisitInsertKey) throws AppException,
			InformationalException {

		CaseHeader caseHeader = caseHeaderDAO.get(Long
				.parseLong(caseVisitInsertKey.getCaseID()));
		// Populate meeting details
		CreateMeetingDetails meetingDetails = new CreateMeetingDetails();
		meetingDetails.meetingDtls.activityTypeCode = ACTIVITYTYPE.MEETING;
		meetingDetails.meetingDtls.allDayInd = false;
		meetingDetails.meetingDtls.caseID = Long.parseLong(caseVisitInsertKey
				.getCaseID());
		meetingDetails.meetingDtls.caseReference = caseHeader
				.getCaseReference();
		ConcernRole concernRole = caseHeader.getConcernRole();
		meetingDetails.meetingDtls.concernRoleID = concernRole.getID();
		meetingDetails.meetingDtls.endDateTime = new DateTime(
				(caseVisitInsertKey.getEndDateTime()).toGregorianCalendar());
		meetingDetails.meetingDtls.locationName = "";
		meetingDetails.meetingDtls.meetingMinutesID = 0L;
		meetingDetails.meetingDtls.notes = "";
		meetingDetails.meetingDtls.startDateTime = new DateTime(
				(caseVisitInsertKey.getStartDateTime()).toGregorianCalendar());
		meetingDetails.meetingDtls.priorityCode = ACTIVITYPRIORITY.MEDIUM;
		meetingDetails.meetingDtls.recordStatusCode = RECORDSTATUS.NORMAL;
		meetingDetails.meetingDtls.timeStatusCode = ACTIVITYTIMESTATUS.BUSY;
		meetingDetails.meetingDtls.recurrenceID = 0L;
		meetingDetails.meetingDtls.subject = kMeetingSubject;

		curam.meetings.facade.intf.MeetingManagement meetingManagementObj = MeetingManagementFactory
				.newInstance();
		// Create meeting activity
		MeetingResult meetigResult = meetingManagementObj
				.create(meetingDetails);

		CaseVisitInsertResult createAppointmentDetails = new CaseVisitInsertResult();
		createAppointmentDetails.setCaseVisitID(Long
				.toString(meetigResult.activityID));
		return createAppointmentDetails;
	}
    
    private XMLGregorianCalendar getXMLGregCalDateTime(DateTime dateTime)  {
        XMLGregorianCalendar formatteddate = null;
    try {
        if (dateTime != null) {
            // convert to iso date time string in UTC
                final java.text.SimpleDateFormat dateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.ENGLISH);
                dateFormat.setTimeZone(new java.util.SimpleTimeZone(java.util.SimpleTimeZone.UTC_TIME, "UTC"));
                String convertedDateTimeString = dateFormat.format(dateTime.getCalendar().getTime());
                
                final java.text.SimpleDateFormat converteddateFormat = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.ENGLISH);
                
    
            Calendar cal = Calendar.getInstance();
            cal.setTime(converteddateFormat.parse(convertedDateTimeString));
    
        
    
            formatteddate = DatatypeFactory.newInstance().newXMLGregorianCalendar(
                 cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH), cal.getTime().getHours(),
                cal.getTime().getMinutes(), cal.get(Calendar.SECOND),
                DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
    // set this so the isodate time format is set properly with the ending Z, dont have to worry about date or time.
    formatteddate.setTimezone(0);
    
        return formatteddate;
    
        }
          } catch (Throwable e) {
            e.printStackTrace();
            throw new AppRuntimeException(e);
          }
        return formatteddate;
      }
    
    


	/**
	 * Method to transform curam.util.Date to XMLGregorianCalendar.
	 * 
	 */
	private XMLGregorianCalendar getXMLGregCalCuramDate(Date date) {
		XMLGregorianCalendar formatteddate = null;
		if (date != null) {
			try {
				Calendar cal = date.getCalendar();
				formatteddate = DatatypeFactory.newInstance()
						.newXMLGregorianCalendarDate(cal.get(Calendar.YEAR),
								cal.get(Calendar.MONTH) + 1,
								cal.get(Calendar.DAY_OF_MONTH),
								DatatypeConstants.FIELD_UNDEFINED);
				return formatteddate;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return formatteddate;
	}

	/**
	 * Sets title, extension and size attributes in the DocumentHeader object
	 * passed in.
	 */
	private void setDocumentFileAttributes(
			ReadCaseAttachmentDetails caseAttachmentDetails,
			DocumentHeaderList documentHeader) {

		String title = "";
		String extension = "";

		if (caseAttachmentDetails.readCaseAttachmentOut.attachmentName.length() > 0) {
			String attachmentName = caseAttachmentDetails.readCaseAttachmentOut.attachmentName;
			int extensionStart = attachmentName.lastIndexOf('.');
			if (extensionStart > 0) {
				title = attachmentName.substring(0, extensionStart);
				extension = attachmentName.substring(extensionStart + 1);
			} else {
				title = attachmentName;
			}

			documentHeader
					.setSize(Long
							.toString(caseAttachmentDetails.readCaseAttachmentOut.attachmentContents
									.length()));

		} else if (caseAttachmentDetails.readCaseAttachmentOut.fileLocation
				.length() > 0) {

			String fileLocation = caseAttachmentDetails.readCaseAttachmentOut.fileLocation;

			int fileNameStart = fileLocation.lastIndexOf('\\');
			int extensionStart = fileLocation.lastIndexOf('.');

			if (fileNameStart <= -1) {
				fileNameStart = 0;
			}

			if (extensionStart > 0) {
				title = fileLocation.substring(fileNameStart + 1,
						extensionStart);
				extension = fileLocation.substring(extensionStart + 1);
			} else {
				// no extension
				title = fileLocation.substring(fileNameStart + 1);
			}

			File attachmentFile = new File(fileLocation);
			documentHeader.setSize(Long.toString(attachmentFile.length()));

		}
		documentHeader.setExtension(extension);
		documentHeader.setTitle(title);
	}

	/**
	 * Method that returns username of the case owner.
	 * 
	 * @param caseID
	 * @return Username of the current owner. An empty string if the case owner
	 *         is an organisation object other than 'user', such as 'workgroup'.
	 */
	private String getCaseOwner(Long caseID) {
		CaseHeader caseHeader = caseHeaderDAO.get(caseID);
		List<curam.piwrapper.casemanager.impl.CaseUserRole> caseUserRoleList = caseUserRoleDAO
				.listActiveByCase(caseHeader);

		OrgObjectLink orgObjectLinkObj = null;
		for (int i = 0; i < caseUserRoleList.size(); i++) {
			if ((caseUserRoleList.get(i).getType().toString())
					.equals(CASEUSERROLETYPE.OWNER)) {
				if ((caseUserRoleList.get(i).getRecordStatus().toString())
						.equals(RECORDSTATUS.NORMAL)) {
					orgObjectLinkObj = caseUserRoleList.get(i)
							.getOrgObjectLink();
					break;
				}
			}
		}

		if (orgObjectLinkObj != null
				&& orgObjectLinkObj.getOrgObjectType().equals(
						ORGOBJECTTYPE.USER)) {
			return (String) orgObjectLinkObj.getOrgObjectIdentifier();
		} else {
			return new String("");
		}

	}

    /**
   * Helper method to figure out whether the user is the case owner, or if
   * belongs to a structure that owns the case (org unit, position, work queue).
   * 
   * @param caseID
   * @param username
   * @return True if the user is case owner or belongs to a structure that owns
   *         the case, false otherwise.
   * @throws AppException
   * @throws InformationalException
   */
  private boolean isCurrentUserCaseOwner(Long caseID) 
  throws AppException, InformationalException {
    
    CaseHeader caseHeader = caseHeaderDAO.get(caseID);
    List<curam.piwrapper.casemanager.impl.CaseUserRole> caseUserRoleList = caseUserRoleDAO
        .listActiveByCase(caseHeader);

    OrgObjectLink orgObjectLinkObj = null;
    for (int i = 0; i < caseUserRoleList.size(); i++) {
      if ((caseUserRoleList.get(i).getType().toString())
          .equals(CASEUSERROLETYPE.OWNER)) {
        if ((caseUserRoleList.get(i).getRecordStatus().toString())
            .equals(RECORDSTATUS.NORMAL)) {
          orgObjectLinkObj = caseUserRoleList.get(i).getOrgObjectLink();
          break;
        }
      }
    }
    String username = TransactionInfo.getProgramUser();
    if (orgObjectLinkObj != null && orgObjectLinkObj.getOrgObjectType().getCode().equals(ORGOBJECTTYPE.USER) ) {
      return true;
    } else if(orgObjectLinkObj != null && orgObjectLinkObj.getOrgObjectType().getCode().equals(ORGOBJECTTYPE.ORGUNIT) ) {
      return isUserInOrgunit(username, (Long) orgObjectLinkObj.getOrgObjectIdentifier());
    } else if(orgObjectLinkObj != null && orgObjectLinkObj.getOrgObjectType().getCode().equals(ORGOBJECTTYPE.POSITION) ) {
      return isUserInPosition(username, (Long) orgObjectLinkObj.getOrgObjectIdentifier());
    } else if(orgObjectLinkObj != null && orgObjectLinkObj.getOrgObjectType().getCode().equals(ORGOBJECTTYPE.WORKQUEUE) ) {
      return isUserInWorkQueue(username, (Long) orgObjectLinkObj.getOrgObjectIdentifier());
    } else {
      return false;
    }

  }
 
  /**
   * Helper method that checks whether the user belongs to the org unit.
   * @param username
   * @param orgUnitID
   * @return true if the user is the member of the org unit, false otherwise.
   * @throws AppException
   * @throws InformationalException
   */
  private boolean isUserInOrgunit(String username, Long orgUnitID) 
  throws AppException, InformationalException {
    
    Organization organizationObj = OrganizationFactory.newInstance();
    OrgStructureAndOrgUnitKey orgStructureAndOrgUnitKey = new OrgStructureAndOrgUnitKey();
    orgStructureAndOrgUnitKey.organisationUnitID = orgUnitID;
    OrganisationUnitDetailsAndUserList list = organizationObj.readOrganisationUnitDetailsAndUserList(orgStructureAndOrgUnitKey);
    for (int i = 0; i < list.userDetailsList.size(); i++) {
      if (list.userDetailsList.item(i).userName.equals(username)) {
        return true;
      }
    }
    
    return false;
  }
  
  /**
   * Helper method that checks whether the user belongs to the position.
   * @param username
   * @param positionID
   * @return true if the user is in the position, false otherwise.
   * @throws AppException
   * @throws InformationalException
   */
  private boolean isUserInPosition(String username, Long positionID) 
  throws AppException, InformationalException {
    
    Organization organizationObj = OrganizationFactory.newInstance();
    OrgStructureAndPositionKey orgStructureAndPositionKey = new OrgStructureAndPositionKey();
    orgStructureAndPositionKey.orgStructureAndPositionKey.orgStructureAndPositionKey.positionID = positionID;
    ListUserForPositionDetails listUserForPosition = organizationObj.listAllUsersForPosition(orgStructureAndPositionKey);
    for (int i = 0; i < listUserForPosition.userForPositionDetailsList.userForPositionDetailsOrgUnitList.dtls.size(); i++) {
      String userNameOnThePosition = listUserForPosition.userForPositionDetailsList.userForPositionDetailsOrgUnitList.dtls.item(i).userName;
      if (userNameOnThePosition.equals(username)) {
        return true;
      }
    }
    
    return false;
    
  }
  
  /**
   * Helper method that checks whether the user is a member of the work queue.
   * @param username
   * @param workQueueID
   * @return true if the user is in the work queue, false otherwise.
   * @throws AppException
   * @throws InformationalException
   */
  private boolean isUserInWorkQueue(String username, Long workQueueID) 
  throws AppException, InformationalException {
    
    WorkAllocation workAllocation = WorkAllocationFactory.newInstance();
    ListWorkQueueSubscriptionsKey listWorkQueueSubscriptionsKey = new ListWorkQueueSubscriptionsKey();
    listWorkQueueSubscriptionsKey.key.workQueueID = workQueueID;
    ListWorkQueueSubscriptions listWorkQueueSubscriptions = workAllocation.listAllWorkQueueSubscriptions(listWorkQueueSubscriptionsKey);
    
    for (int i = 0; i < listWorkQueueSubscriptions.userSubscriptionList.dtls.size(); i++ ) {
      WorkQueueSubscriptionFullDetails subscription = listWorkQueueSubscriptions.userSubscriptionList.dtls.item(i);
      if (subscription.userName.equals(username)) {
        return true;
      }
    }
    
    return false;
    
  }


	/**
	 * Constructs note subject text
	 * 
	 * @param notesText
	 * @param createdDateTime
	 * @return string to be passed in as a note subject
	 */
	private String getNoteSubjectText(String notesText, DateTime createdDateTime) {

		Date createdDate = new Date(createdDateTime);
		String subjectText = null;
		if (notesText.length() <= kMaxNoteSubjectLength) {
			subjectText = notesText;
		} else {
			subjectText = notesText.substring(0, kMaxNoteSubjectLength);
		}
		return createdDate.toString() + " - " + subjectText + "...";
	}

  /**
   * A method used to link meeting minute to activity.
   * 
   * @param Document
   * @return Document
   * 
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public Document visitNoteLink_insert(Document xmlMessage) throws AppException, InformationalException {

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    VisitNoteLinkInsertKey visitNoteLinkInsertKey = JAXB.unmarshal(source,
        VisitNoteLinkInsertKey.class);
    
    curam.meetings.meetingminutes.facade.intf.MeetingMinutesManagement meetingMinutesObj = MeetingMinutesManagementFactory
        .newInstance();
 
    MeetingCaseKey paramMeetingCaseKey = new MeetingCaseKey();
    ActivityKey paramActivityKey = new ActivityKey();
    RichTextMeetingMinutesDetails paramRichTextMeetingMinutesDetails = new RichTextMeetingMinutesDetails();

    //get the activity details based on activity id
    Activity activityObj = ActivityFactory.newInstance();
    ActivityIdKey activityIdKey = new ActivityIdKey();
    long activityID = Long.parseLong(visitNoteLinkInsertKey
        .getCaseVisitID());
    activityIdKey.activityID = activityID;
    ViewRecurringUserActivityDetails activityDetails = activityObj
        .readActivityDetailsAndInviteesList(activityIdKey);

    // Link meeting minutes to meeting
    
    long meetingMinuteID = Long.valueOf(visitNoteLinkInsertKey.getCaseNoteID());
    MeetingMinutes aMeeting = (MeetingMinutes)this.meetingMinutesDAO.get(meetingMinuteID);
   
    paramActivityKey.activityID = activityID;
    paramRichTextMeetingMinutesDetails.dtls.meetingID =  meetingMinuteID;
  
  curam.core.intf.Activity activity = curam.core.fact.ActivityFactory.newInstance();

    ActivityKey key = new ActivityKey();

    key.activityID = activityID;

    ActivityDtls activityDtls = activity.read(key);    

    // activity ID param
    paramRichTextMeetingMinutesDetails.dtls.activityID = activityID;
    paramRichTextMeetingMinutesDetails.dtls.startTime = activityDetails.maintainRecurringUserActivityDetails.startDateTime;
    paramRichTextMeetingMinutesDetails.dtls.endTime = activityDetails.maintainRecurringUserActivityDetails.endDateTime;
    paramRichTextMeetingMinutesDetails.dtls.sensitivityCode =  aMeeting.getSensitivity().getCode();

    // Populate details required for meeting minute
    paramRichTextMeetingMinutesDetails.richTextMeetingAgenda = "";
    paramRichTextMeetingMinutesDetails.dtls.subject = aMeeting.getSubject();
    paramRichTextMeetingMinutesDetails.dtls.allDayEvent = false;
    paramRichTextMeetingMinutesDetails.dtls.versionNo=aMeeting.getVersionNo();
    paramRichTextMeetingMinutesDetails.dtls.organizer = activityDtls.userName;
    CreateMeetingMinutesResult meetingResult = meetingMinutesObj
        .createOrUpdateMeetingDetails(paramMeetingCaseKey,
            paramActivityKey, paramRichTextMeetingMinutesDetails);
    
    VisitNoteLinkInsertResult visitNoteLinkInsertResult = new VisitNoteLinkInsertResult();   
    visitNoteLinkInsertResult.setVisitNoteLinkID(String.valueOf(meetingResult.meetingID));
    DOMResult domResult = new DOMResult();
    JAXB.marshal(visitNoteLinkInsertResult, domResult);
    return (Document) domResult.getNode();
  }

  /**
   * A method used to remove meeting link.
   * 
   * @param Document
   * @return Document
   * 
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public Document visitNoteLink_remove(Document xmlMessage) throws AppException, InformationalException {
    // TODO Auto-generated method stub
    EmptyResponse emptyResponse = new EmptyResponse();
    emptyResponse.setEmpty("");
    DOMResult domResult = new DOMResult();
    JAXB.marshal(emptyResponse, domResult);
    return (Document) domResult.getNode();
  }

  /**
   * A method used to list visit note.
   * 
   * @param Document
   * @return Document
   * 
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public Document visitNoteLink_listByCaseVisitID(Document xmlMessage) throws AppException, InformationalException {
    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    VisitNoteLinkListByCaseVisitIDKey vsitNoteLinkListByCaseVisitIDKey = JAXB.unmarshal(source,
        VisitNoteLinkListByCaseVisitIDKey.class);
    
    //get activity details based on activity id
    MeetingManagement meetingManagement = MeetingManagementFactory.newInstance();
    ActivityKey paramActivityKey= new ActivityKey();
    paramActivityKey.activityID = Long.parseLong(vsitNoteLinkListByCaseVisitIDKey.getCaseVisitID());
    ViewMeetingDetails viewMeetingDetails = meetingManagement.view(paramActivityKey);
    
    VisitNoteLinkListByCaseVisitIDResult visitNoteLinkListByCaseVisitIDResult = new VisitNoteLinkListByCaseVisitIDResult();

    if (viewMeetingDetails.meetingDtls.meetingMinutesID != 0) {
	   VisitNoteLinks visitNoteLinks = new VisitNoteLinks();
	   visitNoteLinks.setCaseNoteID(String.valueOf(viewMeetingDetails.meetingDtls.meetingMinutesID));
	   visitNoteLinks.setCaseVisitID(vsitNoteLinkListByCaseVisitIDKey.getCaseVisitID());
	   visitNoteLinks.setVisitNoteLinkID(String.valueOf(viewMeetingDetails.meetingDtls.meetingMinutesID));
	   visitNoteLinkListByCaseVisitIDResult.getVisitNoteLinks().add(visitNoteLinks);
    }

    DOMResult domResult = new DOMResult();
    JAXB.marshal(visitNoteLinkListByCaseVisitIDResult, domResult);
    return (Document) domResult.getNode();

  }

    public GeoCodeDetails getGeoCode(String addressData) {
        GeoCodeDetails geoCodeDetails = new GeoCodeDetails();
        Geocoder geocoder = null;
            try {

                try {
                        String googleKey = Configuration.getProperty("curam.miscapp.googlemapsapi.client.key");
                        String googleIdentifier = Configuration.getProperty(
                          "curam.miscapp.googlemapsapi.client.id");
                        if (googleKey != null 
                                && googleIdentifier != null 
                                && !googleIdentifier.isEmpty() 
                                && !googleKey.isEmpty()) {
                            geocoder = new Geocoder(googleIdentifier, googleKey);
                        }
                  } catch (Throwable e) {
                    geocoder = new Geocoder();
                  }

                if (geocoder == null) {
                    geocoder = new Geocoder();
                }
                GeocoderRequest geocoderRequest = (new GeocoderRequestBuilder()).setAddress(addressData).getGeocoderRequest();
                GeocodeResponse geocoderResponse = geocoder.geocode(geocoderRequest);
                if(geocoderResponse != null 
                   && geocoderResponse.getResults() != null && geocoderResponse.getResults().size() > 0)
                {
                    GeocoderResult geocoderResult = (GeocoderResult)geocoderResponse.getResults().iterator().next();
                    geoCodeDetails.latitude = geocoderResult.getGeometry().getLocation().getLat().doubleValue();
                    geoCodeDetails.longitude = geocoderResult.getGeometry().getLocation().getLng().doubleValue();
                        
                    
                }

        } catch(Throwable e) {
            e.printStackTrace();
            throw new AppRuntimeException(e);
        }

        return geoCodeDetails;
    }

  /**
   * Helper method to check whether current user is among attendees of the activity.
   * @param activityID
   * @return true if the current user is attendee, false otherwise
   * @throws AppException
   * @throws InformationalException
   */
  private boolean isCurentUserAttendee(Long activityID) 
  throws AppException, InformationalException {

    Activity activityFacadeObj = ActivityFactory.newInstance();
    MaintainAttendeeActivityKey maintainAttendeeActivityKey = new MaintainAttendeeActivityKey();
    maintainAttendeeActivityKey.activityID = activityID;
   
    ActivityAttendeeList activityAttendeeList = activityFacadeObj.readActivityAttendeeList(maintainAttendeeActivityKey);
    
    for (ActivityAttendeeDetails activityAttendeeDetails : activityAttendeeList.activityAttendeeDetails) {
      if (activityAttendeeDetails.activityAttendeeType.equals(ACTIVITYATTENDEETYPE.USER)
          && activityAttendeeDetails.activityAttendeeID.equals(TransactionInfo.getProgramUser()) ){
          return true;
      }
    }
    return false;
  }
}
