package curam.diona.mobility.socialworker.impl;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.xml.bind.JAXB;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;

import org.apache.commons.codec.binary.Base64;
import org.w3c.dom.Document;

import com.google.inject.Inject;

import curam.codetable.ACTIVITYPRIORITY;
import curam.codetable.ACTIVITYTIMESTATUS;
import curam.codetable.ACTIVITYTYPE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.NOTEPRIORITY;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.facade.fact.ActivityFactory;
import curam.core.facade.fact.CaseFactory;
import curam.core.facade.fact.PersonFactory;
import curam.core.facade.intf.Activity;
import curam.core.facade.intf.Case;
import curam.core.facade.intf.Person;
import curam.core.facade.struct.ActivityDetails;
import curam.core.facade.struct.ActivityIdKey;
import curam.core.facade.struct.ActivityListViewDetails;
import curam.core.facade.struct.CaseAccessibleNotesList1;
import curam.core.facade.struct.CaseKey_fo;
import curam.core.facade.struct.CaseNoteKey;
import curam.core.facade.struct.InsertCaseNoteDetails;
import curam.core.facade.struct.ListCaseAttachmentDetails;
import curam.core.facade.struct.ListCaseAttachmentKey;
import curam.core.facade.struct.ListCaseByCurrentUserKey;
import curam.core.facade.struct.ListCasesForUserDetails;
import curam.core.facade.struct.MaintainStandardActivityUserDetails;
import curam.core.facade.struct.ModifyCaseNoteDetails1;
import curam.core.facade.struct.NewActivityDetails;
import curam.core.facade.struct.ReadCaseAttachmentDetails;
import curam.core.facade.struct.ReadCaseAttachmentKey;
import curam.core.facade.struct.ReadCaseNoteDetails1;
import curam.core.facade.struct.ReadParticipantPhoneNumberList;
import curam.core.facade.struct.ReadParticipantPhoneNumberListKey;
import curam.core.facade.struct.ReadPersonDetails;
import curam.core.facade.struct.ReadPersonKey;
import curam.core.facade.struct.ViewRecurringUserActivityDetails;
import curam.core.sl.entity.struct.AccessibleCaseNoteDetails1;
import curam.core.sl.struct.CaseKey;
import curam.core.sl.struct.CaseParticipantDetails;
import curam.core.sl.struct.SearchCaseParticipantDetails;
import curam.core.sl.struct.SearchCaseParticipantDetailsKey;
import curam.core.sl.struct.SearchCaseParticipantDetailsList;
import curam.core.struct.ActivityListDetails;
import curam.core.struct.AttachmentDetails;
import curam.core.struct.CaseAndConcernSummaryDetails;
import curam.core.struct.PhoneRMDtls;
import curam.diona.mobility.socialworker.struct.CaseListByUsernameKey;
import curam.diona.mobility.socialworker.struct.CaseListByUsernameResult;
import curam.diona.mobility.socialworker.struct.CaseMembersDetails;
import curam.diona.mobility.socialworker.struct.CaseNote;
import curam.diona.mobility.socialworker.struct.CaseNoteInsertKey;
import curam.diona.mobility.socialworker.struct.CaseNoteInsertResult;
import curam.diona.mobility.socialworker.struct.CaseNoteListByCaseIDKey;
import curam.diona.mobility.socialworker.struct.CaseNoteListByCaseIDResult;
import curam.diona.mobility.socialworker.struct.CaseNoteModifyKey;
import curam.diona.mobility.socialworker.struct.CaseReadByCaseIDKey;
import curam.diona.mobility.socialworker.struct.CaseReadByCaseIDResult;
import curam.diona.mobility.socialworker.struct.CaseVisit;
import curam.diona.mobility.socialworker.struct.CaseVisitInsertKey;
import curam.diona.mobility.socialworker.struct.CaseVisitInsertResult;
import curam.diona.mobility.socialworker.struct.CaseVisitListByCaseIDKey;
import curam.diona.mobility.socialworker.struct.CaseVisitListByCaseIDResult;
import curam.diona.mobility.socialworker.struct.CaseVisitListByUsernameDateTimeRangeKey;
import curam.diona.mobility.socialworker.struct.CaseVisitListByUsernameDateTimeRangeResult;
import curam.diona.mobility.socialworker.struct.CaseVisitModifyKey;
import curam.diona.mobility.socialworker.struct.Cases;
import curam.diona.mobility.socialworker.struct.CoordinatesDetails;
import curam.diona.mobility.socialworker.struct.DocumentHeaderList;
import curam.diona.mobility.socialworker.struct.DocumentHeaderListByCaseIDKey;
import curam.diona.mobility.socialworker.struct.DocumentHeaderListByCaseIDResult;
import curam.diona.mobility.socialworker.struct.DocumentHeaderReadByDocumentHeaderIDKey;
import curam.diona.mobility.socialworker.struct.DocumentHeaderReadByDocumentHeaderIDResult;
import curam.diona.mobility.socialworker.struct.EmptyResponse;
import curam.diona.mobility.socialworker.struct.LocationDetails;
import curam.diona.mobility.socialworker.struct.PhoneNumbersDetails;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.piwrapper.casemanager.impl.CaseUserRoleDAO;
import curam.piwrapper.impl.EmailAddress;
import curam.piwrapper.impl.EmailAddressDAO;
import curam.piwrapper.organization.impl.OrgObjectLink;
import curam.piwrapper.user.impl.UserDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateTime;

public class SocialWorkerWS implements
    curam.diona.mobility.socialworker.intf.SocialWorkerWS {

  @Inject
  UserDAO userDAO;

  @Inject
  ConcernRoleDAO concernRoleDAO;

  @Inject
  CaseParticipantRoleDAO caseParticipantRoleDAO;

  @Inject
  CaseUserRoleDAO caseUserRoleDAO;

  @Inject
  CaseHeaderDAO caseHeaderDAO;

  @Inject
  EmailAddressDAO emailAddressDAO;
  
  /**
   * Case Note subject is automatically set on creation to first n number of 
   * characters taken from the note text. This constant specifies how many 
   * characters to use. 
   */
  private static final int kMaxNoteSubjectLength = 40;

  /**
   * Default Constructor
   */
  public SocialWorkerWS() {
    GuiceWrapper.getInjector().injectMembers(this);

  }

  /**
   * Returns list of all cases assigned to current user along with all the
   * details about case members.
   * 
   * The argument passed in is: Case_listByUsernameKey.username
   * 
   * @param xmlMessage
   *          containing case owner user name.
   * @return details about the cases assigned to the user.
   */
  public Document case_listByUsername(Document xmlMessage) throws AppException,
      InformationalException {

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());

    String caseOwner = JAXB.unmarshal(source, CaseListByUsernameKey.class)
        .getUsername();

    Case caseObj = CaseFactory.newInstance();
    ListCaseByCurrentUserKey listCaseByCurrentUserKey = new ListCaseByCurrentUserKey();
    listCaseByCurrentUserKey.casesByOwnerKey.ownerID = caseOwner;

    ListCasesForUserDetails listCasesForUserDetails = caseObj
        .listAllCasesForUser(listCaseByCurrentUserKey);

    CaseListByUsernameResult case_listByUsernameResult = new CaseListByUsernameResult();
    for (CaseAndConcernSummaryDetails summaryDetails : listCasesForUserDetails.dtls.list.dtls) {

      Cases casesDtls = new Cases();

      if (summaryDetails.statusCode != CASESTATUS.CANCELED
          && summaryDetails.statusCode != CASESTATUS.CLOSED) {

        casesDtls.setCaseID(Long.toString(summaryDetails.caseID));
        casesDtls.setReference(caseHeaderDAO.get(summaryDetails.caseID)
            .getCaseReference());
        casesDtls.setLocation(getCaseLocation(summaryDetails.caseID));
        casesDtls
            .setDateAssigned(getXMLGregCalCuramDate(getCaseAssignedDate(summaryDetails.caseID)));
        casesDtls.setUsername(caseOwner);
        List<CaseMembersDetails> listOfMembers = getCaseMemberList(summaryDetails.caseID);
        casesDtls.getMembers().addAll(listOfMembers);
        
        case_listByUsernameResult.getCases().add(casesDtls);
      }
    }
    DOMResult result = new DOMResult();
    JAXB.marshal(case_listByUsernameResult, result);
    return (Document) result.getNode();

  }

  /**
   * A method used to add note for a case.
   * 
   * @param Document
   * @return Document
   * 
   * @throws AppException
   * @throws InformationalException
   */
  public Document caseNote_insert(Document xmlMessage) throws AppException,
      InformationalException {

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    CaseNoteInsertKey createCaseNoteKey = JAXB.unmarshal(source,
        CaseNoteInsertKey.class);

    Case caseObj = CaseFactory.newInstance();
    InsertCaseNoteDetails caseNoteDetails = new InsertCaseNoteDetails();

    caseNoteDetails.details.caseNoteDetails.caseNoteDetails.caseID = Long
        .parseLong(createCaseNoteKey.getCaseID());
  
    DateTime createdDateTime = new DateTime((createCaseNoteKey.getCreatedDateTime()).toGregorianCalendar());
    String notesText = createCaseNoteKey.getContents();
    caseNoteDetails.details.caseNoteDetails.noteDetails.notesText = notesText;  
    caseNoteDetails.details.caseNoteDetails.noteDetails.subjectText = 
      getNoteSubjectText(notesText, createdDateTime);
    caseNoteDetails.details.caseNoteDetails.noteDetails.priorityCode = NOTEPRIORITY.DEFAULTCODE;
    caseNoteDetails.details.caseNoteDetails.noteDetails.sensitivityCode = userDAO
        .get(TransactionInfo.getProgramUser()).getSensitivity().getCode();

    caseObj.createNote(caseNoteDetails);

    CaseNoteInsertResult response = new CaseNoteInsertResult();
    response
        .setCaseNoteID((Long
            .toString(caseNoteDetails.details.caseNoteDetails.caseNoteDetails.caseNoteID)));

    DOMResult domResult = new DOMResult();
    JAXB.marshal(response, domResult);

    return (Document) domResult.getNode();

  }

  /**
   * A method to schedule an appointment (create visit).
   * 
   * @param xmlMessage
   *          contains creation details: caseID, startDateTime, endDateTime
   * @return id of the newly created appointment
   */
  public Document caseVisit_insert(Document xmlMessage) throws AppException,
      InformationalException {

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    CaseVisitInsertKey caseVisitInsertKey = JAXB.unmarshal(source,
        CaseVisitInsertKey.class);

    CaseVisitInsertResult createAppointmentDetails = createCuramActivity(caseVisitInsertKey);
    DOMResult domResult = new DOMResult();
    JAXB.marshal(createAppointmentDetails, domResult);
    return (Document) domResult.getNode();

  }

  /**
   * Returns details about the case and its members.
   * 
   * @param xmlMessage
   *          contains case unique identifier
   * 
   * @return Structure containing case details and list of case members with
   *         appropriate details.
   */
  public Document case_readByCaseID(Document xmlMessage) throws AppException,
      InformationalException {
    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    CaseReadByCaseIDKey readCaseDetailsKey = JAXB.unmarshal(source,
        CaseReadByCaseIDKey.class);

    CaseReadByCaseIDResult Case_readByCaseIDResult = new CaseReadByCaseIDResult();
    Cases caseDtls = new Cases();

    Long caseID = Long.parseLong(readCaseDetailsKey.getCaseID());

    caseDtls.setCaseID(readCaseDetailsKey.getCaseID());
    caseDtls.setReference(caseHeaderDAO.get(caseID).getCaseReference());
    caseDtls.setLocation(getCaseLocation(caseID));
    
    Date assignedDate = getCaseAssignedDate(caseID);
    caseDtls.setDateAssigned(getXMLGregCalCuramDate(assignedDate));
    caseDtls.setUsername(getCaseOwner(caseID));
    
    List<CaseMembersDetails> caseMemberDetailsList = getCaseMemberList(caseID);
    caseDtls.getMembers().addAll(caseMemberDetailsList);
         
    Case_readByCaseIDResult.setCase(caseDtls);

    DOMResult domResult = new DOMResult();
    JAXB.marshal(Case_readByCaseIDResult, domResult);
    return (Document) domResult.getNode();
  }

  /**
   * Cancels the appointment and schedules a new one.
   * 
   * @param xmlMessage
   *          containing unique ID of the activity that needs to be rescheduled
   *          and new activity start and end date and time.
   * @return activity unique ID.
   * 
   */
  public Document caseVisit_modify(Document xmlMessage) throws AppException,
      InformationalException {

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    CaseVisitModifyKey rescheduleAppointmentKey = JAXB.unmarshal(source,
        CaseVisitModifyKey.class);

    // Note: I intended to use cancelStandardUserActivity() operation, but it is
    // throwing an exception: java.lang.NoClassDefFoundError:
    // curam/events/ACTIVITY

    // Read activity details in order to obtain caseID and versionNo
    Activity activityObj = ActivityFactory.newInstance();
    ActivityIdKey activityIdKey = new ActivityIdKey();
    activityIdKey.activityID = Long.parseLong(rescheduleAppointmentKey
        .getCaseVisitID());
    ViewRecurringUserActivityDetails activityDetails = activityObj
        .readActivityDetailsAndInviteesList(activityIdKey);
    // Modify old activity
    ActivityDetails newActivityDetails = new ActivityDetails();
    // Assign operation is not working!!!
    // newActivityDetails.assign(activityDetails);

    newActivityDetails.activityID = Long.parseLong(rescheduleAppointmentKey
        .getCaseVisitID());
    newActivityDetails.activityTypeCode = ACTIVITYTYPE.APPOINTMENT;
    newActivityDetails.allDayInd = false;
    newActivityDetails.caseID = activityDetails.maintainRecurringUserActivityDetails.caseID;
    newActivityDetails.concernRoleID = activityDetails.maintainRecurringUserActivityDetails.concernRoleID;

    newActivityDetails.locationID = activityDetails.maintainRecurringUserActivityDetails.locationID;
    newActivityDetails.locationName = activityDetails.maintainRecurringUserActivityDetails.locationName;
    newActivityDetails.notes = activityDetails.maintainRecurringUserActivityDetails.notes;
    // newActivityDetails.organisationID =
    newActivityDetails.priorityCode = ACTIVITYPRIORITY.MEDIUM;
    newActivityDetails.recordStatusCode = RECORDSTATUS.NORMAL;
    newActivityDetails.recurrenceID = activityDetails.maintainRecurringUserActivityDetails.recurrenceID;
    // newActivityDetails.slotAllocationID =
    newActivityDetails.startDateTime = new DateTime((rescheduleAppointmentKey
        .getStartDateTime()).toGregorianCalendar());
    newActivityDetails.endDateTime = new DateTime((rescheduleAppointmentKey
        .getEndDateTime()).toGregorianCalendar());
    newActivityDetails.subject = activityDetails.maintainRecurringUserActivityDetails.subject;
    newActivityDetails.timeStatusCode = activityDetails.maintainRecurringUserActivityDetails.timeStatusCode;
    newActivityDetails.userName = TransactionInfo.getProgramUser();
    newActivityDetails.versionNo = activityDetails.maintainRecurringUserActivityDetails.versionNo;

    activityObj.modifyActivity(activityIdKey, newActivityDetails);
       
    EmptyResponse emptyResponse = new EmptyResponse();
    emptyResponse.setEmpty("");
    DOMResult domResult = new DOMResult();
    JAXB.marshal(emptyResponse, domResult);
    return (Document) domResult.getNode();

  }

  /**
   * A method used to modify note for a case.
   * 
   * @param Document
   * @return Document
   * 
   * @throws AppException
   * @throws InformationalException
   */
  public Document caseNote_modify(Document xmlMessage) throws AppException,
      InformationalException {

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    CaseNoteModifyKey modifyCaseNoteKey = JAXB.unmarshal(source,
        CaseNoteModifyKey.class);

    Case caseObj = CaseFactory.newInstance();

    ModifyCaseNoteDetails1 caseNoteDetails = new ModifyCaseNoteDetails1();
    caseNoteDetails.details.caseNoteDetails.caseNoteDetails.noteID = Long
        .parseLong(modifyCaseNoteKey.getCaseNoteID());

    CaseNoteKey caseNoteKeyStruct = new CaseNoteKey();
    caseNoteKeyStruct.key.key.caseNoteID = caseNoteDetails.details.caseNoteDetails.caseNoteDetails.noteID;
    ReadCaseNoteDetails1 caseNoteDtls = CaseFactory.newInstance().readNote1(
        caseNoteKeyStruct);

    caseNoteDetails.details.caseNoteDetails.caseNoteDetails.caseID = caseNoteDtls.details.noteDetails.caseID;
    caseNoteDetails.details.caseNoteDetails.caseNoteDetails.noteID = caseNoteDtls.details.noteDetails.noteID;
    caseNoteDetails.details.caseNoteDetails.caseNoteDetails.versionNo = caseNoteDtls.details.noteDetails.versionNo;
    caseNoteDetails.details.caseNoteDetails.modifyNoteDetails.priorityCode = caseNoteDtls.details.noteDetails.priorityCode;
    caseNoteDetails.details.caseNoteDetails.modifyNoteDetails.sensitivityCode = caseNoteDtls.details.noteDetails.sensitivityCode;
    caseNoteDetails.details.caseNoteDetails.modifyNoteDetails.subjectText = caseNoteDtls.details.noteDetails.subjectText;
    caseNoteDetails.details.key.caseNoteID = caseNoteDtls.details.noteDetails.caseNoteID;
    caseNoteDetails.details.caseNoteDetails.modifyNoteDetails.notesText = modifyCaseNoteKey
        .getContents();
    
    caseObj.modifyNote1(caseNoteDetails);

    DOMResult domResult = new DOMResult();
    EmptyResponse emptyResponce = new EmptyResponse();
    emptyResponce.setEmpty("");
    JAXB.marshal(emptyResponce, domResult);
    return (Document) domResult.getNode();
  }

  /**
   * Returns visit details list.
   * 
   * @param xmlMessage
   *          containing: username, startDateTime, endDateTime
   * @return AppointmentsList
   */
  public Document caseVisit_listByUsernameDateTimeRange(Document xmlMessage)
      throws AppException, InformationalException {

    CaseVisitListByUsernameDateTimeRangeResult cvList = new CaseVisitListByUsernameDateTimeRangeResult();
    CaseVisit caseVisit;

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    CaseVisitListByUsernameDateTimeRangeKey caseVisitListByUsernameDateTimeRangeKey =
      JAXB.unmarshal(source, CaseVisitListByUsernameDateTimeRangeKey.class);
        
    XMLGregorianCalendar startDateTimeXML = caseVisitListByUsernameDateTimeRangeKey.getStartDateTime();
    XMLGregorianCalendar endDateTimeXML = caseVisitListByUsernameDateTimeRangeKey.getEndDateTime();
    String username = caseVisitListByUsernameDateTimeRangeKey.getUsername();

    DateTime startDateTime = new DateTime(startDateTimeXML
        .toGregorianCalendar());
    DateTime endDateTime = new DateTime(endDateTimeXML.toGregorianCalendar());

    Activity activityObj = ActivityFactory.newInstance();
    ActivityIdKey activityIDKey = new ActivityIdKey();
    ViewRecurringUserActivityDetails viewActivityDetails;

    ActivityListViewDetails activityList = activityObj
        .listActivityForCurrentUser();
    // iterate the list to filter out all activities that do not have start
    // date in the next 24 hours
    for (ActivityListDetails activityDetails : activityList.activityList.dtls) {
      if (activityDetails.activityTypeCode.equals(ACTIVITYTYPE.APPOINTMENT)) {

        // The list method only returns date, so a separate read is
        // required to obtain datetime.
        activityIDKey.activityID = activityDetails.activityID;
        viewActivityDetails = activityObj
            .readActivityDetailsAndInviteesList(activityIDKey);
        DateTime activityStartDateTime = viewActivityDetails.maintainRecurringUserActivityDetails.startDateTime;

        if (!activityStartDateTime.before(startDateTime)
            && !activityStartDateTime.after(endDateTime)) {

          caseVisit = new CaseVisit();

          caseVisit.setCaseVisitID(Long.toString(activityDetails.activityID));
          caseVisit.setCaseID(Long.toString(activityDetails.caseID));
          caseVisit.setUsername(username);

          caseVisit
              .setStartDateTime(getXMLGregCalDateTime(activityStartDateTime));
          caseVisit
              .setEndDateTime(getXMLGregCalDateTime(viewActivityDetails.maintainRecurringUserActivityDetails.endDateTime));
          /*
          caseVisit.setSubject(activityDetails.subject);
          caseVisit.setLocation(getCaseLocation(activityDetails.caseID));
          */
          
          cvList.getCaseVisit().add(caseVisit);
        }
      }

    }

    DOMResult result = new DOMResult();
    JAXB.marshal(cvList, result);
    return (Document) result.getNode();

  }

  /**
   * Returns details about notes associated with a case.
   * 
   * @param xmlMessage
   *          containing CaseID.
   * @return Notes details list.
   */
  public Document caseNote_listByCaseID(Document xmlMessage)
      throws AppException, InformationalException {
    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    CaseNoteListByCaseIDKey readCaseNotesKey = JAXB.unmarshal(source,
        CaseNoteListByCaseIDKey.class);

    List<CaseNote> caseNoteDetailsList = getCaseNoteList(Long
        .parseLong(readCaseNotesKey.getCaseID()));

    CaseNoteListByCaseIDResult caseNoteListByCaseIDResult = new CaseNoteListByCaseIDResult();

    caseNoteListByCaseIDResult.getCaseNote().addAll(caseNoteDetailsList);

    DOMResult domResult = new DOMResult();
    JAXB.marshal(caseNoteListByCaseIDResult, domResult);
    return (Document) domResult.getNode();
  }

  /**
   * Returns details about documents associated with a case.
   * 
   * @param xmlMessage
   *          containing CaseID.
   * @return Documents details list.
   */
  public Document documentHeader_listByCaseID(Document xmlMessage)
      throws AppException, InformationalException {

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    DocumentHeaderListByCaseIDKey listKey = JAXB.unmarshal(source,
        DocumentHeaderListByCaseIDKey.class);

    Case caseObj = CaseFactory.newInstance();

    ListCaseAttachmentKey listCaseAttachmentKey = new ListCaseAttachmentKey();
    listCaseAttachmentKey.attachmentCaseID.caseID = Long.parseLong(listKey
        .getCaseID());
    ListCaseAttachmentDetails listCaseAttachmentDetails = caseObj
        .listCaseAttachment(listCaseAttachmentKey);

    DocumentHeaderListByCaseIDResult listResult = new DocumentHeaderListByCaseIDResult();

    DocumentHeaderList documentHeader;
    ReadCaseAttachmentKey readCaseAttachmentKey;
    ReadCaseAttachmentDetails caseAttachmentDetails;

    for (AttachmentDetails attachmentDetails : listCaseAttachmentDetails.attachmentDetailsList.dtls) {
      documentHeader = new DocumentHeaderList();
      documentHeader.setDocumentHeaderID(Long
          .toString(attachmentDetails.caseAttachmentLinkID));
      documentHeader.setCaseID(Long.toString(attachmentDetails.caseID));

      documentHeader
          .setCreatedDateTime(getXMLGregCalDateTime(attachmentDetails.attachmentDate.getDateTime()));
      
      // mandatory field in schema, but has no meaning in Curam
      documentHeader.setDocumentDataBinaryID("");

      readCaseAttachmentKey = new ReadCaseAttachmentKey();
      readCaseAttachmentKey.readCaseAttachmentIn.attachmentID = attachmentDetails.attachmentID;
      readCaseAttachmentKey.readCaseAttachmentIn.caseAttachmentLinkID = attachmentDetails.caseAttachmentLinkID;

      caseAttachmentDetails = caseObj.readCaseAttachment(readCaseAttachmentKey);
      setDocumentFileAttributes(caseAttachmentDetails, documentHeader);
     
      listResult.getDocumentHeaderList().add(documentHeader);
    }

    DOMResult domResult = new DOMResult();
    JAXB.marshal(listResult, domResult);
    return (Document) domResult.getNode();

  }

  /**
   * Reads a document.
   * 
   * @param xmlMessage
   *          containing DocumentID.
   * @return Documents
   */
  public Document documentHeader_readByDocumentHeaderID(Document xmlMessage)
      throws AppException, InformationalException {

    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    DocumentHeaderReadByDocumentHeaderIDKey readKey = JAXB.unmarshal(source,
        DocumentHeaderReadByDocumentHeaderIDKey.class);

    DocumentHeaderReadByDocumentHeaderIDResult readResult = new DocumentHeaderReadByDocumentHeaderIDResult();

    Case caseObj = CaseFactory.newInstance();
    ReadCaseAttachmentKey readCaseAttachmentKey = new ReadCaseAttachmentKey();

    readCaseAttachmentKey.readCaseAttachmentIn.caseAttachmentLinkID = Long
        .parseLong(readKey.getDocumentHeaderID());

    ReadCaseAttachmentDetails caseAttachmentDetails = caseObj
        .readCaseAttachment(readCaseAttachmentKey);
    curam.diona.mobility.socialworker.struct.DocumentHeader document = new curam.diona.mobility.socialworker.struct.DocumentHeader();
  
    byte[] byteData = caseAttachmentDetails.readCaseAttachmentOut.attachmentContents.copyBytes();
     
    String encodedStringData = Base64.encodeBase64String(byteData);
    document.setBinaryData(encodedStringData);
        
    document.setDocumentHeaderID(readKey.getDocumentHeaderID());
    
    // Set all other attributes to empty string. This is because they were made
    // mandatory in the schema, but are actually unused from this operation (same
    // struct is used from listDocuments, and that's where they are used from.
    document.setCaseID("");
    DateTime dt = DateTime.kZeroDateTime;
    document.setCreatedDateTime(getXMLGregCalDateTime(dt));
    document.setDocumentDataBinaryID("");
    document.setExtension("");
    document.setSize("");
    document.setTitle("");    
    
    readResult.setDocumentHeader(document);

    DOMResult domResult = new DOMResult();
    JAXB.marshal(readResult, domResult);
    return (Document) domResult.getNode();
  }

  /**
   * Returns a list of past and future visits for a case.
   * 
   * @param xmlMessage
   *          containing caseID.
   * @return AppointmentsList
   */
  public Document caseVisit_listByCaseID(Document xmlMessage)
      throws AppException, InformationalException {
   
    DOMSource source = new DOMSource(xmlMessage.getDocumentElement());
    CaseVisitListByCaseIDKey listKey = JAXB.unmarshal(source,
        CaseVisitListByCaseIDKey.class);
    CaseVisitListByCaseIDResult listResult = new CaseVisitListByCaseIDResult();
    
    curam.core.facade.intf.Activity activityObj = 
      curam.core.facade.fact.ActivityFactory.newInstance();
    
    ActivityIdKey activityIDKey = new ActivityIdKey();
    ViewRecurringUserActivityDetails viewActivityDetails;
    CaseVisit caseVisit; 
   
    ActivityListViewDetails activityList = activityObj .listActivityForCurrentUser();
    // iterate the list to filter out all activities that do not relate to the case
    for (ActivityListDetails activityDetails : activityList.activityList.dtls) {
      if (activityDetails.activityTypeCode.equals(ACTIVITYTYPE.APPOINTMENT)
          && activityDetails.caseID == Long.parseLong(listKey.getCaseID())) {

        caseVisit = new CaseVisit();
        caseVisit.setCaseID(listKey.getCaseID());
        caseVisit.setCaseVisitID(Long.toString(activityDetails.activityID));
        caseVisit.setUsername(TransactionInfo.getProgramUser());
        
        activityIDKey.activityID = activityDetails.activityID;
        viewActivityDetails = activityObj
            .readActivityDetailsAndInviteesList(activityIDKey);

        DateTime activityStart = viewActivityDetails.maintainRecurringUserActivityDetails.startDateTime;
        DateTime activityEnd = viewActivityDetails.maintainRecurringUserActivityDetails.endDateTime;

        caseVisit.setStartDateTime(getXMLGregCalDateTime(activityStart));
        caseVisit.setEndDateTime(getXMLGregCalDateTime(activityEnd));
        
        listResult.getCaseVisit().add(caseVisit);

      }
    }
    
    DOMResult domResult = new DOMResult();
    JAXB.marshal(listResult, domResult);
    return (Document) domResult.getNode();
  }
  
  /**
   * Method that returns date on which the case was assigned to its current
   * owner.
   * 
   * @param caseID
   * @return Date on which the case was assigned to the current owner.
   */
  private Date getCaseAssignedDate(Long caseID) {
    CaseHeader caseHeader = caseHeaderDAO.get(caseID);
    List<curam.piwrapper.casemanager.impl.CaseUserRole> caseUserRoleList = caseUserRoleDAO
        .listActiveByCase(caseHeader);

    DateRange dateRange = null;
    for (int i = 0; i < caseUserRoleList.size(); i++) {
      if ((caseUserRoleList.get(i).getType().toString())
          .equals(CASEUSERROLETYPE.OWNER)) {
        if ((caseUserRoleList.get(i).getRecordStatus().toString())
            .equals(RECORDSTATUS.NORMAL)) {
          dateRange = caseUserRoleList.get(i).getDateRange();
          break;
        }
      }
    }

    if (dateRange != null) {
      return dateRange.start();
    } else {
      return null;
    }

  }

  /**
   * Returns location of the case's primary client primary address.
   * 
   * @throws InformationalException
   * @throws AppException
   */
  private LocationDetails getCaseLocation(Long caseID) throws AppException,
      InformationalException {

    Case caseObj = CaseFactory.newInstance();
    CaseKey caseKey = new CaseKey();
    caseKey.key.caseID = caseID;
    CaseParticipantDetails caseParticipantDetails = caseObj
        .getPrimaryCaseParticipantDetails(caseKey);

    ConcernRole concernRoleObj = concernRoleDAO
        .get(caseParticipantDetails.participantRoleID);

    curam.piwrapper.impl.Address addrObj = concernRoleObj.getPrimaryAddress();

    LocationDetails locationDetails = new LocationDetails();
    locationDetails.setAddress(addrObj.getOneLineAddressString());
    CoordinatesDetails coordinatesDetails = new CoordinatesDetails();

    coordinatesDetails.setLatitude(addrObj.getLatitude());
    coordinatesDetails.setLongitude(addrObj.getLongitude());
    locationDetails.setCoordinates(coordinatesDetails);

    return locationDetails;

  }

  /**
   * Returns list of case members with appropriate details.
   * 
   * @param caseID
   * @return details set for each member: name age date of birth email phone
   *         number details list
   * @throws InformationalException
   * @throws AppException
   */
  private List<CaseMembersDetails> getCaseMemberList(Long caseID)
      throws AppException, InformationalException {

    Case caseObj = CaseFactory.newInstance();

    SearchCaseParticipantDetailsKey searchCaseParticipantDetailsKey = new SearchCaseParticipantDetailsKey();
    searchCaseParticipantDetailsKey.caseID = caseID;
    searchCaseParticipantDetailsKey.caseParticipantTypeList = CASEPARTICIPANTROLETYPE.MEMBER;
    SearchCaseParticipantDetailsList searchCaseParticipantMembersList = caseObj
        .listCaseParticipant(searchCaseParticipantDetailsKey);
    // Primary client does not get returned among other members
    searchCaseParticipantDetailsKey.caseParticipantTypeList = CASEPARTICIPANTROLETYPE.PRIMARY;
    // Only one record is expected in the list
    SearchCaseParticipantDetailsList searchCaseParticipantPrimaryList = caseObj
        .listCaseParticipant(searchCaseParticipantDetailsKey);
    List<CaseMembersDetails> caseMembersDetailsList = new ArrayList<CaseMembersDetails>();
    populateCaseMemberDetailsList(caseMembersDetailsList,
        searchCaseParticipantMembersList);
    populateCaseMemberDetailsList(caseMembersDetailsList,
        searchCaseParticipantPrimaryList);

    return caseMembersDetailsList;
  }

  /**
   * Method iterates participant list, collects participant information such as
   * name, age, email address, and populates caseMembersDetailsList with this
   * information.
   * 
   * @param caseMembersDetailsList
   * @param participantList
   * @throws InformationalException
   * @throws AppException
   */
  private void populateCaseMemberDetailsList(
      List<CaseMembersDetails> caseMembersDetailsList,
      SearchCaseParticipantDetailsList participantList) throws AppException,
      InformationalException {

    Person personObj = PersonFactory.newInstance();

    ReadPersonKey readPersonKey = new ReadPersonKey();
    ReadPersonDetails readPersonDetails;
    CaseMembersDetails caseMemberDetails;
    for (SearchCaseParticipantDetails caseParticipantDtls : participantList.searchCaseParticipantDetails) {
      caseMemberDetails = new CaseMembersDetails();
      caseMemberDetails.setName(caseParticipantDtls.name);

      CaseParticipantRole caseParticipantRoleObj = caseParticipantRoleDAO
          .get(caseParticipantDtls.caseParticipantRoleID);
      ConcernRole concernRoleObj = concernRoleDAO.get(caseParticipantRoleObj
          .getConcernRole().getID());
      readPersonKey.maintainConcernRoleKey.concernRoleID = concernRoleObj
          .getID();
      readPersonDetails = personObj.readPerson(readPersonKey);
      caseMemberDetails.setMemberID(Long
          .toString(caseParticipantDtls.caseParticipantRoleID));

      Date dob = readPersonDetails.personFurtherDetails.dateOfBirth;
      caseMemberDetails.setDateOfBirth(getXMLGregCalCuramDate(dob));
      
      EmailAddress emailAddressObj = emailAddressDAO.get(concernRoleObj
          .getPrimaryEmailAddressID());
      
      String email = null;
      try {
        email = emailAddressObj.getEmail();
      } catch(RecordNotFoundException e){
        // do nothing - leave email empty
      }
      
      if (email != null) {
        caseMemberDetails.setEmail(email);
      }
        
      List<PhoneNumbersDetails> phoneNumberDetailsList = 
        getPhoneNumberList(readPersonDetails.personFurtherDetails.concernRoleID);
      if (phoneNumberDetailsList.size() > 0) {
        caseMemberDetails.getPhoneNumbers().addAll(phoneNumberDetailsList);
      }
      caseMembersDetailsList.add(caseMemberDetails);
    }

  }

  /**
   * Returns list of phone numbers for a given concern role.
   * 
   * @param concernRoleID
   * @return List containing a list of strings formed by concatenating country
   *         code, area code and phone number.
   * @throws AppException
   * @throws InformationalException
   */
  private List<PhoneNumbersDetails> getPhoneNumberList(Long concernRoleID)
      throws AppException, InformationalException {

    List<PhoneNumbersDetails> phoneNumberDetailsList = new ArrayList<PhoneNumbersDetails>();;
    PhoneNumbersDetails phoneNumbersDetails;

    ReadParticipantPhoneNumberListKey phoneNoKey = new ReadParticipantPhoneNumberListKey();
    phoneNoKey.maintainPhoneNumberKey.concernRoleID = concernRoleID;
    Person personObj = PersonFactory.newInstance();
    ReadParticipantPhoneNumberList phoneNoList = personObj
        .listPhoneNumber(phoneNoKey);

    for (PhoneRMDtls phoneRMDtls : phoneNoList.readMultiByConcernRoleIDPhoneResult.details.dtls) {
      phoneNumbersDetails = new PhoneNumbersDetails();
      phoneNumbersDetails.setNumber(phoneRMDtls.phoneNumberString);
      phoneNumbersDetails.setPhoneID(Long
          .toString(phoneRMDtls.concernRolePhoneNumberID));
      phoneNumberDetailsList.add(phoneNumbersDetails);
    }

    return phoneNumberDetailsList;
  }

  /**
   * Populates list of notes related to the case.
   * 
   * @param caseID
   * @return
   * @throws AppException
   * @throws InformationalException
   */
  private List<CaseNote> getCaseNoteList(Long caseID) throws AppException,
      InformationalException {
    
    CaseNote caseNotesDetails;
    List<CaseNote> caseNotesDetailsList = new ArrayList<CaseNote>();
    Case caseObj = CaseFactory.newInstance();
    CaseKey_fo caseKey = new CaseKey_fo();
    caseKey.key.key.caseID = caseID;
    CaseAccessibleNotesList1 notesList = caseObj.listAccessibleNotes1(caseKey);

    for (AccessibleCaseNoteDetails1 noteDetails : notesList.details.details) {
      
      caseNotesDetails = new CaseNote();
      caseNotesDetails.setCaseID(Long.toString(caseID));
      caseNotesDetails.setCaseNoteID(Long.toString(noteDetails.caseNoteID));
      caseNotesDetails.setAuthor(noteDetails.userName);
      caseNotesDetails
          .setCreatedDateTime(getXMLGregCalDateTime(noteDetails.creationDateTime));
      caseNotesDetails.setContents(noteDetails.notesText);     
      caseNotesDetailsList.add(caseNotesDetails);
    }

    return caseNotesDetailsList;
  }
 
  /**
   * Creates an Activity of type Appointment.
   * 
   * @param createAppointmentKey
   *          Contains unique identifier of the case to which the activity is
   *          related, activity start and end date and time.
   * 
   * @return Unique identifier of the newly created activity.
   * 
   * @throws AppException
   * @throws InformationalException
   */
  private CaseVisitInsertResult createCuramActivity(
      CaseVisitInsertKey caseVisitInsertKey) throws AppException,
      InformationalException {

    Activity activityObj = ActivityFactory.newInstance();
    MaintainStandardActivityUserDetails maintainStandardActivityUserDetails = new MaintainStandardActivityUserDetails();

    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.activityTypeCode = ACTIVITYTYPE.APPOINTMENT;
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.allDayInd = false;

    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.caseID = Long
        .parseLong(caseVisitInsertKey.getCaseID());

    CaseHeader caseHeader = caseHeaderDAO.get(Long.parseLong(caseVisitInsertKey
        .getCaseID()));
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.caseReference = caseHeader
        .getCaseReference();
    ConcernRole concernRole = caseHeader.getConcernRole();
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.concernRoleID = concernRole
        .getID();
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.caseTypeCode = caseHeader
        .getCaseType().getCode();
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.concernRoleName = concernRole
        .getName();
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.concernRoleType = concernRole
        .getConcernRoleType().getCode();
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.startDateTime = new DateTime(
        (caseVisitInsertKey.getStartDateTime()).toGregorianCalendar());
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.endDateTime = new DateTime(
        (caseVisitInsertKey.getEndDateTime()).toGregorianCalendar());
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.subject = caseVisitInsertKey
        .getUsername();

    // No subject gets sent from the client
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.subject = caseHeader
        .getCaseReference();
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.priorityCode = ACTIVITYPRIORITY.MEDIUM;
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.timeStatusCode = ACTIVITYTIMESTATUS.BUSY;
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.recordStatusCode = RECORDSTATUS.NORMAL;
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.locationID = 0L;
    maintainStandardActivityUserDetails.viewStandardActivityUserDetails.locationName = "";

    NewActivityDetails newActivityDetails = activityObj
        .createStandardUserActivity(maintainStandardActivityUserDetails);

    CaseVisitInsertResult createAppointmentDetails = new CaseVisitInsertResult();
    createAppointmentDetails.setCaseVisitID(Long
        .toString(newActivityDetails.activityID));

    return createAppointmentDetails;

  }

  /**
   * Method to transform curam.util.DateTime to XMLGregorianCalendar.
   * 
   */
  private XMLGregorianCalendar getXMLGregCalDateTime(DateTime dateTime) {
    XMLGregorianCalendar formatteddate = null;
    if (dateTime != null) {
      Calendar cal = dateTime.getCalendar();
      try {

        formatteddate = DatatypeFactory.newInstance().newXMLGregorianCalendar(
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH), cal.get(Calendar.HOUR),
            cal.get(Calendar.MINUTE), cal.get(Calendar.SECOND),
            // cal.get(Calendar.MILLISECOND),
            DatatypeConstants.FIELD_UNDEFINED, cal.get(Calendar.ZONE_OFFSET));

        return formatteddate;

      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return formatteddate;
  }

  /**
   * Method to transform curam.util.Date to XMLGregorianCalendar.
   * 
   */
  private XMLGregorianCalendar getXMLGregCalCuramDate(Date date) {
    XMLGregorianCalendar formatteddate = null;
    if (date != null) {
      try {
        Calendar cal = date.getCalendar();
        formatteddate = DatatypeFactory.newInstance()
            .newXMLGregorianCalendarDate(cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH),
                DatatypeConstants.FIELD_UNDEFINED);
        return formatteddate;
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return formatteddate;
  }


  /**
   * Sets title, extension and size attributes in the DocumentHeader object passed in.
   */
  private void setDocumentFileAttributes(
    ReadCaseAttachmentDetails caseAttachmentDetails, DocumentHeaderList documentHeader) {
    
    String title = "";
    String extension = "";
   
    if (caseAttachmentDetails.readCaseAttachmentOut.attachmentName.length() > 0) {
      String attachmentName = caseAttachmentDetails.readCaseAttachmentOut.attachmentName;
      int extensionStart = attachmentName.lastIndexOf('.');
      if (extensionStart > 0) {
        title = attachmentName.substring(0, extensionStart);
        extension = attachmentName.substring(extensionStart + 1);
      } else {
        title = attachmentName;
      }
      
      documentHeader.setSize(Long.toString(caseAttachmentDetails.readCaseAttachmentOut.attachmentContents.length()));
      
    } else if (caseAttachmentDetails.readCaseAttachmentOut.fileLocation
        .length() > 0) {
   
      String fileLocation = caseAttachmentDetails.readCaseAttachmentOut.fileLocation;
      
      int fileNameStart = fileLocation.lastIndexOf('\\');
      int extensionStart = fileLocation.lastIndexOf('.');

      if (fileNameStart <= -1) {
        fileNameStart = 0;
      }

      if (extensionStart > 0) {
        title = fileLocation.substring(fileNameStart + 1, extensionStart);
        extension = fileLocation.substring(extensionStart + 1);
      } else {
        // no extension
        title = fileLocation.substring(fileNameStart + 1);
      }
      
      File attachmentFile = new File(fileLocation);
      documentHeader.setSize(Long.toString(attachmentFile.length()));
     
    }
    documentHeader.setExtension(extension);
    documentHeader.setTitle(title);
  }
  
  /**
   * Method that returns username of the case owner.
   * 
   * @param caseID
   * @return Username of the current owner. An empty string if the case owner
   *         is an organisation object other than 'user', such as 'workgroup'.
   */
  private String getCaseOwner(Long caseID) {
    CaseHeader caseHeader = caseHeaderDAO.get(caseID);
    List<curam.piwrapper.casemanager.impl.CaseUserRole> caseUserRoleList = caseUserRoleDAO
        .listActiveByCase(caseHeader);

    OrgObjectLink orgObjectLinkObj = null;
    for (int i = 0; i < caseUserRoleList.size(); i++) {
      if ((caseUserRoleList.get(i).getType().toString())
          .equals(CASEUSERROLETYPE.OWNER)) {
        if ((caseUserRoleList.get(i).getRecordStatus().toString())
            .equals(RECORDSTATUS.NORMAL)) {
          orgObjectLinkObj = caseUserRoleList.get(i).getOrgObjectLink();
          break;
        }
      }
    }

    if (orgObjectLinkObj != null && orgObjectLinkObj.getOrgObjectType().equals(ORGOBJECTTYPE.USER) ) {
      return (String) orgObjectLinkObj.getOrgObjectIdentifier();
    } else {
      return new String("");
    }

  }
  
  /**
   * Constructs note subject text
   *
   * @param notesText
   * @param createdDateTime
   * @return string to be passed in as a note subject
   */
  private String getNoteSubjectText(String notesText, DateTime createdDateTime) {
  
    Date createdDate = new Date(createdDateTime);
    String subjectText = null;
    if (notesText.length() <= kMaxNoteSubjectLength) {
      subjectText = notesText;
    } else {
      subjectText = notesText.substring(0, kMaxNoteSubjectLength);
    }
    return createdDate.toString() + " - "+ subjectText + "...";
  }

}
