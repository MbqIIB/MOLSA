//>>built
define("dijit/nls/it/common",({buttonOk:"OK",buttonCancel:"Annulla",buttonSave:"Salva",itemClose:"Chiudi"}));
