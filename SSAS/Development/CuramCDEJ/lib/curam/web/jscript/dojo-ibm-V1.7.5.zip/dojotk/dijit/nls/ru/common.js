//>>built
define("dijit/nls/ru/common",({buttonOk:"ОК",buttonCancel:"Отмена",buttonSave:"Сохранить",itemClose:"Закрыть"}));
