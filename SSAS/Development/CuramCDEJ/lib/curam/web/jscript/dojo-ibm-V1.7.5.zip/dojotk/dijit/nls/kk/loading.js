//>>built
define("dijit/nls/kk/loading",({loadingState:"Жүктелуде...",errorState:"Кешіріңіз, қате орын алды"}));
