//>>built
define("dijit/layout/utils",["dojo/_base/array","dojo/dom-class","dojo/dom-geometry","dojo/dom-style","dojo/_base/lang",".."],function(_1,_2,_3,_4,_5,_6){
var _7=_5.getObject("layout",true,_6);
_7.marginBox2contentBox=function(_8,mb){
var cs=_4.getComputedStyle(_8);
var me=_3.getMarginExtents(_8,cs);
var pb=_3.getPadBorderExtents(_8,cs);
return {l:_4.toPixelValue(_8,cs.paddingLeft),t:_4.toPixelValue(_8,cs.paddingTop),w:mb.w-(me.w+pb.w),h:mb.h-(me.h+pb.h)};
};
function _9(_a){
return _a.substring(0,1).toUpperCase()+_a.substring(1);
};
function _b(_c,_d){
var _e=_c.resize?_c.resize(_d):_3.setMarginBox(_c.domNode,_d);
if(_c.fakeWidget){
return;
}
if(_e){
_5.mixin(_c,_e);
}else{
_5.mixin(_c,_3.getMarginBoxSimple(_c.domNode));
_5.mixin(_c,_d);
}
};
_7.layoutChildren=function(_f,dim,_10,_11,_12){
dim=_5.mixin({},dim);
_2.add(_f,"dijitLayoutContainer");
_10=_1.filter(_10,function(_13){
return _13.region!="center"&&_13.layoutAlign!="client";
}).concat(_1.filter(_10,function(_14){
return _14.region=="center"||_14.layoutAlign=="client";
}));
var _15={};
_1.forEach(_10,function(_16){
var elm=_16.domNode,pos=(_16.region||_16.layoutAlign);
if(!pos){
throw new Error("No region setting for "+_16.id);
}
var _17=elm.style;
_17.left=dim.l+"px";
_17.top=dim.t+"px";
_17.position="absolute";
_2.add(elm,"dijitAlign"+_9(pos));
var _18={};
if(_11&&_11==_16.id){
_18[_16.region=="top"||_16.region=="bottom"?"h":"w"]=_12;
}
if(pos=="top"||pos=="bottom"){
_18.w=dim.w;
_b(_16,_18);
dim.h-=_16.h;
if(pos=="top"){
dim.t+=_16.h;
}else{
_17.top=dim.t+dim.h+"px";
}
}else{
if(pos=="left"||pos=="right"){
_18.h=dim.h;
_b(_16,_18);
dim.w-=_16.w;
if(pos=="left"){
dim.l+=_16.w;
}else{
_17.left=dim.l+dim.w+"px";
}
}else{
if(pos=="client"||pos=="center"){
_b(_16,dim);
}
}
}
_15[pos]={w:dim.w,h:dim.h};
});
return _15;
};
return {marginBox2contentBox:_7.marginBox2contentBox,layoutChildren:_7.layoutChildren};
});
