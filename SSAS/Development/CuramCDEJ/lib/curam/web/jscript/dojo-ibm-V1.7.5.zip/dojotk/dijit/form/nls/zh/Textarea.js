//>>built
define("dijit/form/nls/zh/Textarea",({iframeEditTitle:"编辑区",iframeFocusTitle:"编辑区框架"}));
