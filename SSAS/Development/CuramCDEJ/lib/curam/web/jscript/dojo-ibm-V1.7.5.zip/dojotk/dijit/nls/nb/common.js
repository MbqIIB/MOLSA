//>>built
define("dijit/nls/nb/common",({buttonOk:"OK",buttonCancel:"Avbryt",buttonSave:"Lagre",itemClose:"Lukk"}));
