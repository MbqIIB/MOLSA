if(!dojo._hasResource["dijit.tests._Templated"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dijit.tests._Templated"] = true;
dojo.provide("dijit.tests._Templated");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests._Templated", dojo.moduleUrl("dijit", "tests/_Templated.html"));
}

}
