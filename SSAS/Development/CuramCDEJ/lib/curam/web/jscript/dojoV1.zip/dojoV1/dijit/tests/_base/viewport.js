if(!dojo._hasResource["dijit.tests._base.viewport"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dijit.tests._base.viewport"] = true;
dojo.provide("dijit.tests._base.viewport");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests._base.viewport", dojo.moduleUrl("dijit", "tests/_base/viewport.html"));
	doh.registerUrl("dijit.tests._base.viewportStrict", dojo.moduleUrl("dijit", "tests/_base/viewportStrict.html"));
}

}
