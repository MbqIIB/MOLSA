/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006,2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.codetable.VERIFICATIONTYPE;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.sl.impl.VerificationRelatedTypeUtil;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeKey;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.message.ENTVERIFICATIONREQUIREMENTUSAGE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.verification.sl.entity.fact.VerifiableDataItemFactory;
import curam.verification.sl.entity.fact.VerificationRequirementFactory;
import curam.verification.sl.entity.fact.VerificationRequirementUsageFactory;
import curam.verification.sl.entity.intf.VerificationRequirement;
import curam.verification.sl.entity.struct.CountTypeByRequirementIDAndStatusDetails;
import curam.verification.sl.entity.struct.DataItemRelatedItemAndStatusDetails;
import curam.verification.sl.entity.struct.ReadReqUsageRelatedItemType;
import curam.verification.sl.entity.struct.RequirementIDTypeAndStatusKey;
import curam.verification.sl.entity.struct.SearchAllActiveVerificationRequirementUsageNamesList;
import curam.verification.sl.entity.struct.SearchAllActiveVerificationRequirementUsageTypesList;
import curam.verification.sl.entity.struct.VerifiableDataItemDetails;
import curam.verification.sl.entity.struct.VerificationRequirementIDAndStatusKey;
import curam.verification.sl.entity.struct.VerificationRequirementKey;
import curam.verification.sl.entity.struct.VerificationRequirementRecordCount;
import curam.verification.sl.entity.struct.VerificationRequirementStatusDetails;
import curam.verification.sl.entity.struct.VerificationRequirementUsageCancelDetails;
import curam.verification.sl.entity.struct.VerificationRequirementUsageDtls;
import curam.verification.sl.entity.struct.VerificationRequirementUsageDtlsList;
import curam.verification.sl.entity.struct.VerificationRequirementUsageKey;
import curam.verification.sl.entity.struct.VerificationRequirementUsageNameAndStatusKey;
import curam.verification.sl.entity.struct.VerificationRequirementUsageRecordCount;
import curam.verification.sl.infrastructure.entity.fact.VerificationFactory;
import curam.verification.sl.infrastructure.entity.intf.Verification;
import curam.verification.sl.infrastructure.entity.struct.VerificationRequirementIDDetailsList;
import curam.verification.sl.infrastructure.fact.VerificationControllerFactory;
import curam.verification.sl.infrastructure.intf.VerificationController;


/**
 * Contains details about a specific operations that can be executed on a
 * Verification Requirement Usage record. A Verification Requirement Usage record contains
 * details of which type of case are satisfied by a specific verification requirement.
 */
public abstract class VerificationRequirementUsage extends curam.verification.sl.entity.base.VerificationRequirementUsage {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details Verification Requirement Usage details
   */
  protected void preinsert(VerificationRequirementUsageDtls details)
    throws AppException, InformationalException {

    validateInsert(details);
    validateDetails(details);

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key  Verification Requirement Usage identifier
   * @param details Verification Requirement Usage details
   */
  protected void premodify(VerificationRequirementUsageKey key, VerificationRequirementUsageDtls details)
    throws AppException, InformationalException {

    validateModify(details);
    validateDetails(details);

  }

  // ___________________________________________________________________________
  /**
   * Performs the validations common to all operations
   *
   * @param details Verification Requirement Usage details
   */
  public void validateDetails(VerificationRequirementUsageDtls details)
    throws AppException, InformationalException {
   
    ReadReqUsageRelatedItemType readReqUsageRelatedItemType = new ReadReqUsageRelatedItemType();

    readReqUsageRelatedItemType.relatedItemType = details.relatedItemType;
    boolean recordCount = false;  
  
    // BEGIN, CR00369537, RPB
    final VerificationRelatedTypeUtil relatedTypeUtil = new VerificationRelatedTypeUtil();

    recordCount = relatedTypeUtil.isCaseTypeValid(details.relatedItemID,
      details.relatedItemType);
    // END, CR00369537
   
    if (!recordCount) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_INVALID_TYPE_FOR_CASE_SELECTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // The name must be entered
    if (details.name.trim().length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_FV_NAME_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the logical delete
   *
   * @param key Verification Requirement Usage identifier
   * @param dtls Verification Requirement Usage details
   */
  protected void precancel(VerificationRequirementUsageKey key, VerificationRequirementUsageCancelDetails dtls)
    throws AppException, InformationalException {

    curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage = curam.verification.sl.entity.fact.VerificationRequirementUsageFactory.newInstance();

    verificationRequirementUsage.validateCancel(dtls);

    // Set the record status to cancelled
    dtls.recordStatus = RECORDSTATUS.CANCELLED;

  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Requirement Usage details before the logical delete
   *
   *
   * @param details Verification Requirement Usage details
   */
  public void validateCancel(VerificationRequirementUsageCancelDetails details) throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Record must not be already canceled
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      AppException appException = new AppException(
        ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_FV_VERIFICATION_REQUIREMENT_USAGE_CANCELLED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsageObj = VerificationRequirementUsageFactory.newInstance();

    VerificationRequirementKey verificationRequirementKey = new VerificationRequirementKey();
    VerificationRequirementUsageKey verificationRequirementUsageKey = new VerificationRequirementUsageKey();
    VerificationRequirementUsageDtls VerificationRequirementUsageDtls = new VerificationRequirementUsageDtls();

    VerificationRequirementIDDetailsList verificationRequirementIDDetailsList = new VerificationRequirementIDDetailsList();

    verificationRequirementUsageKey.verificationRequirementUsageID = details.verificationRequirementUsageID;

    VerificationRequirementUsageDtls = verificationRequirementUsageObj.read(
      verificationRequirementUsageKey);

    verificationRequirementKey.verificationRequirementID = VerificationRequirementUsageDtls.verificationRequirementID;

    Verification verification = VerificationFactory.newInstance();

    verificationRequirementIDDetailsList = verification.searchVerificationRequirementsByRequirementID(
      verificationRequirementKey);

    if (!verificationRequirementIDDetailsList.dtls.isEmpty()) {

      AppException appException = new AppException(
        ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_XRV_HAS_ASSOCIATED_USAGE_VERIFICATION_APPLICATION);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Requirement Usage details before the data insertion
   *
   * @param details Verification Requirement Usage details
   */
  public void validateInsert(VerificationRequirementUsageDtls details) throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // The name must be entered
    if (details.name.trim().length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_FV_NAME_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    VerificationRequirement verificationRequirement = VerificationRequirementFactory.newInstance();
    VerificationRequirementStatusDetails verificationRequirementStatusDetails = new VerificationRequirementStatusDetails();

    VerificationRequirementKey verificationRequirementKey = new VerificationRequirementKey();

    verificationRequirementKey.verificationRequirementID = details.verificationRequirementID;

    verificationRequirementStatusDetails = verificationRequirement.readStatusByID(
      verificationRequirementKey);

    if (verificationRequirementStatusDetails.recordStatus.equals(
      RECORDSTATUS.CANCELLED)) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_FV_VERIFICATION_REQUIREMENT_CANCELLED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // The name must not already be in use
    VerificationRequirementUsageNameAndStatusKey verificationRequirementUsageNameAndStatusKey = new VerificationRequirementUsageNameAndStatusKey();

    verificationRequirementUsageNameAndStatusKey.recordStatus = curam.codetable.RECORDSTATUS.CANCELLED;

    verificationRequirementUsageNameAndStatusKey.name = details.name;
    verificationRequirementUsageNameAndStatusKey.verificationRequirementID = details.verificationRequirementID;

    VerificationRequirementUsageRecordCount verificationRequirementUsageRecordCount;

    verificationRequirementUsageRecordCount = countByNameAndStatus(
      verificationRequirementUsageNameAndStatusKey);

    if (verificationRequirementUsageRecordCount.recordCount > 0) {
      AppException appException = new AppException(
        ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_XRV_NAME_ALREADY_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // BEGIN, CR00080439, AL
    // There cannot be more than one instance of the verification requirement for the data item type and related item type

    // read verification requirement id for verifiableDataItemID
    VerifiableDataItemDetails verifiableDataItemDetails = verificationRequirement.readVerifiableDataItemDetails(
      verificationRequirementKey);

    DataItemRelatedItemAndStatusDetails dataItemRelatedItemAndStatusDetails = new DataItemRelatedItemAndStatusDetails();

    dataItemRelatedItemAndStatusDetails.recordStatus = curam.codetable.RECORDSTATUS.CANCELLED;
    dataItemRelatedItemAndStatusDetails.verifiableDataItemID = verifiableDataItemDetails.verifiableDataItemID;
    dataItemRelatedItemAndStatusDetails.relatedItemType = details.relatedItemType;
    VerificationRequirementRecordCount verificationRequirementRecordCount = verificationRequirement.countTypeByDateItemIDAndStatus(
      dataItemRelatedItemAndStatusDetails);

    if (verificationRequirementRecordCount.recordCount > 0) {
      AppException appException = new AppException(
        ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENT_XRV_ASSOCIATED_FOR_VERIFIABLEDATAITEM_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    // END, CR00080439
    // There cannot be more than one instance of the type of usage for the same verification requirement.

    curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage = curam.verification.sl.entity.fact.VerificationRequirementUsageFactory.newInstance();

    RequirementIDTypeAndStatusKey requirementIDTypeAndStatusKey = new RequirementIDTypeAndStatusKey();

    requirementIDTypeAndStatusKey.recordStatus = curam.codetable.RECORDSTATUS.CANCELLED;

    requirementIDTypeAndStatusKey.relatedItemType = details.relatedItemType;
    requirementIDTypeAndStatusKey.verificationRequirementID = details.verificationRequirementID;
    CountTypeByRequirementIDAndStatusDetails countTypeByRequirementIDAndStatusDetails = verificationRequirementUsage.countTypeByRequirementIDAndStatus(
      requirementIDTypeAndStatusKey);

    if (countTypeByRequirementIDAndStatusDetails.recordCount > 0) {
      AppException appException = new AppException(
        ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_XRV_ASSOCIATED_FOR_VERIFICATION_REQUIREMENT_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00075395, GM
    // Need to ensure that we do not attempt to apply NON Participant evidence to
    // participant level
    EvidenceTypeKey evidenceTypeKey;
    curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItemObj = VerifiableDataItemFactory.newInstance();

    verificationRequirementKey.verificationRequirementID = details.verificationRequirementID;
    evidenceTypeKey = verifiableDataItemObj.readDataItemEvidenceTypeByVerificationReqID(
      verificationRequirementKey);

    // BEGIN CR00191839
    boolean isParticipantData = false;

    if (Configuration.getBooleanProperty(EnvVars.ENV_PDC_ENABLED)) {
      isParticipantData = EvidenceControllerFactory.newInstance().isPDCEvidence(
        evidenceTypeKey);
    } else {
      isParticipantData = EvidenceControllerFactory.newInstance().isEvidenceParticipantData(
        evidenceTypeKey);
    }
    // END CR00191839

    // If we attempt to apply  non participant level data to non case data level then
    // an error should be thrown to advise the user.
    if ((!isParticipantData)
      && (details.relatedItemID.equals(VERIFICATIONTYPE.NONCASEDATA))) {
      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_INVALID_TYPE_FOR_NON_CASE_DATA_LEVEL);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }
    // END, CR00075395

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Requirement Usage details before the data modification
   *
   *
   * @param details Verification Requirement Usage details
   */
  public void validateModify(VerificationRequirementUsageDtls details) throws AppException, InformationalException {
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Record must not be already canceled
    if (details.recordStatus.equals(RECORDSTATUS.CANCELLED)) {

      AppException appException = new AppException(
        ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_FV_VERIFICATION_REQUIREMENT_USAGE_CANCELLED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // The name must be entered
    if (details.name.trim().length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_FV_NAME_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    // The name must not already be in use
    // Retrieve a list of all Verification Requirement Usage names.
    VerificationRequirementIDAndStatusKey verificationRequirementIDAndStatusKey = new VerificationRequirementIDAndStatusKey();

    verificationRequirementIDAndStatusKey.recordStatus = RECORDSTATUS.CANCELLED;
    verificationRequirementIDAndStatusKey.verificationRequirementID = details.verificationRequirementID;
    SearchAllActiveVerificationRequirementUsageNamesList searchAllActiveVerificationRequirementUsageNamesList = searchAllActiveNames(
      verificationRequirementIDAndStatusKey);

    // Iterate through the list of Verification Requirement Usage.
    for (int i = 0; i
      < searchAllActiveVerificationRequirementUsageNamesList.dtls.size(); i++) {

      // Do not check against its own record in the list.
      if (details.verificationRequirementUsageID
        != searchAllActiveVerificationRequirementUsageNamesList.dtls.item(i).verificationRequirementUsageID) {

        // Check that the name does not already exist.
        if (details.name.equals(
          searchAllActiveVerificationRequirementUsageNamesList.dtls.item(i).name)) {

          AppException appException = new AppException(
            ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_XRV_NAME_ALREADY_EXISTS);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            appException, CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
        }

      }
    }

    // The type must not already be in use
    // Retrieve a list of all Verification Requirement Usage types.

    SearchAllActiveVerificationRequirementUsageTypesList searchAllActiveVerificationRequirementUsageTypesList = searchAllActiveTypes(
      verificationRequirementIDAndStatusKey);

    // Iterate through the list of Verification Requirement Usage.
    for (int j = 0; j
      < searchAllActiveVerificationRequirementUsageTypesList.dtls.size(); j++) {

      // Do not check against its own record in the list.
      if (details.verificationRequirementUsageID
        != searchAllActiveVerificationRequirementUsageTypesList.dtls.item(j).verificationRequirementUsageID) {

        // Check that the type does not already exist.
        if (details.relatedItemType.equals(
          searchAllActiveVerificationRequirementUsageTypesList.dtls.item(j).relatedItemType)) {

          AppException appException = new AppException(
            ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_XRV_TYPE_ALREADY_EXISTS);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            appException, CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
        }

      }
    }

    // BEGIN, CR00021427, NK
    curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsageObj = VerificationRequirementUsageFactory.newInstance();

    VerificationRequirementKey verificationRequirementKey = new VerificationRequirementKey();
    VerificationRequirementUsageKey verificationRequirementUsageKey = new VerificationRequirementUsageKey();
    VerificationRequirementUsageDtls VerificationRequirementUsageDtls = new VerificationRequirementUsageDtls();

    VerificationRequirementIDDetailsList verificationRequirementIDDetailsList = new VerificationRequirementIDDetailsList();

    verificationRequirementUsageKey.verificationRequirementUsageID = details.verificationRequirementUsageID;

    VerificationRequirementUsageDtls = verificationRequirementUsageObj.read(
      verificationRequirementUsageKey);

    verificationRequirementKey.verificationRequirementID = VerificationRequirementUsageDtls.verificationRequirementID;

    Verification verification = VerificationFactory.newInstance();

    verificationRequirementIDDetailsList = verification.searchVerificationRequirementsByRequirementID(
      verificationRequirementKey);

    if (!verificationRequirementIDDetailsList.dtls.isEmpty()) {

      AppException appException = new AppException(
        ENTVERIFICATIONREQUIREMENTUSAGE.ERR_VERIFICATIONREQUIREMENTUSAGE_XRV_HAS_ASSOCIATED_USAGE_VERIFICATION_APPLICATION_MODIFICATION);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00021427


    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();

    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }
  
  @Override
  public VerificationRequirementUsageDtlsList searchByRelatedItemType(
    ReadReqUsageRelatedItemType key) throws AppException,
      InformationalException {
    return super.searchByRelatedItemType(key);
  }

}
