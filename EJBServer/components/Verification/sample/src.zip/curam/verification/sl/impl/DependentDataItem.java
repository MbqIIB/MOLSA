/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.verification.sl.entity.fact.DependentDataItemFactory;
import curam.verification.sl.entity.struct.DependentDataItemKey;
import curam.verification.sl.entity.struct.VerifiableDataItemKey;
import curam.verification.sl.struct.CancelDependantDataItemDetails;
import curam.verification.sl.struct.CreateDependantDataItemDetails;
import curam.verification.sl.struct.DependantDataItemList;
import curam.verification.sl.struct.ModifyDependantDataItemDetails;
import curam.verification.sl.struct.ReadDependantDataItemDetails;


/**
 * This process class provides the functionality for the Dependent Data Item
 * service layer.
 */
public abstract class DependentDataItem extends curam.verification.sl.base.DependentDataItem {

  // ___________________________________________________________________________
  /**
   * Cancels a Dependent Data Item record
   * 
   * @param details Dependent Data Item details
   */ 
  public void cancelDependantDataItem(CancelDependantDataItemDetails details) throws AppException, InformationalException {
    curam.verification.sl.entity.intf.DependentDataItem dependentDataItem =
      DependentDataItemFactory.newInstance();
    
    // Create and populate the Dependent Data Item key
    DependentDataItemKey dependentDataItemKey = new DependentDataItemKey();

    dependentDataItemKey.dependentDataItemID =
      details.cancelDtls.dependentDataItemID;

    // Cancel a Dependent Data Item record
    dependentDataItem.cancel(dependentDataItemKey, details.cancelDtls); 
    
  }

  // ___________________________________________________________________________
  /**
   * Creates a Dependent Data Item record
   * 
   * @param details Dependent Data Item details
   * 
   * @return The unique identifier of the record created
   */  
  public DependentDataItemKey createDependantDataItem(CreateDependantDataItemDetails details) throws AppException, InformationalException {
    
    curam.verification.sl.entity.intf.DependentDataItem dependentDataItem =
      DependentDataItemFactory.newInstance();
    
    details.createDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    
    // Create a Dependent Data Item record 
    dependentDataItem.insert(details.createDtls);

    // Create and populate the return struct
    DependentDataItemKey dependentDataItemKey = new DependentDataItemKey();

    dependentDataItemKey.dependentDataItemID =
      details.createDtls.dependentDataItemID;
    
    return dependentDataItemKey;
  
  }

  // ___________________________________________________________________________
  /**
   * Lists a Dependent Data Item Details
   *
   * @return List Dependent Data Item List details
   */
  public DependantDataItemList listDependantDataItem(VerifiableDataItemKey key) throws AppException, InformationalException {
    
    curam.verification.sl.entity.intf.DependentDataItem dependentDataItem =
      DependentDataItemFactory.newInstance();
    
    // create return structure
    DependantDataItemList dependantDataItemList = new DependantDataItemList();

    // get list Dependent Data Item Details
    dependantDataItemList.listDtls =
      dependentDataItem.searchAllDependentDataItemByVerifiableItemID(key);
    
    return  dependantDataItemList;
    
  }

  // ___________________________________________________________________________
  /**
   * Modifies a Dependent Data Item record
   *
   * @param details Dependent Data Item details
   */
  public void modifyDependantDataItem(ModifyDependantDataItemDetails details) throws AppException, InformationalException {
    
    curam.verification.sl.entity.intf.DependentDataItem dependentDataItem =
      DependentDataItemFactory.newInstance();
    
    // Create and populate the Dependent Data Item key
    DependentDataItemKey dependentDataItemKey = new DependentDataItemKey();

    dependentDataItemKey.dependentDataItemID =
      details.modifyDtls.dependentDataItemID;
    
    // Modify a Dependent Data Item record 
    dependentDataItem.modify(dependentDataItemKey, details.modifyDtls);
    
  }

  // ___________________________________________________________________________
  /**
   * Reads a Dependent Data Item record
   *
   * @param key Dependent Data Item Details
   * @return details Dependent Data Item Details
   */
  public ReadDependantDataItemDetails readDependantDataItem(DependentDataItemKey key) throws AppException, InformationalException {
   
    curam.verification.sl.entity.intf.DependentDataItem dependentDataItem =
      DependentDataItemFactory.newInstance();

    // create return structure
    ReadDependantDataItemDetails readDependantDataItemDetails =
      new ReadDependantDataItemDetails();

    // Read the Dependent Data Item Record
    readDependantDataItemDetails.readDtls = dependentDataItem.read(key);

    return readDependantDataItemDetails;
  }
  
}
