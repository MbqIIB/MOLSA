/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2006,2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.impl;


import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.infrastructure.creole.rulesetadmin.struct.CREOLERuleClassDetails;
import curam.core.impl.CuramConst;
import curam.core.sl.infrastructure.creole.impl.CREOLEUtils;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.struct.CreoleRuleInformation;
import curam.message.CREOLEPRODUCTSANDBOX;
import curam.message.ENTVERIFICATIONREQUIREMENT;
import curam.message.impl.ENTVERIFICATIONREQUIREMENTExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.transaction.TransactionInfo;
import curam.util.type.NotFoundIndicator;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.fact.VerificationRequirementFactory;
import curam.verification.sl.entity.intf.VerificationItemUtilization;
import curam.verification.sl.entity.struct.CountActiveItemUtilizationForRequirement;
import curam.verification.sl.entity.struct.RequirementLevelDateStatusAndVerifiableIDDetails;
import curam.verification.sl.entity.struct.VerifiableDataItemKey;
import curam.verification.sl.entity.struct.VerificationRequirementKey;
import curam.verification.sl.fact.VRRuleClassLinkFactory;
import curam.verification.sl.infrastructure.impl.VerificationConst;
import curam.verification.sl.intf.VRRuleClassLink;
import curam.verification.sl.struct.CancelVerificationRequirementDetails;
import curam.verification.sl.struct.CreateVerificationRequirementDetails;
import curam.verification.sl.struct.GetVerificationRequirementDetails;
import curam.verification.sl.struct.ListVerificationRequirementDetailsList;
import curam.verification.sl.struct.ModifyVerificationRequirementDetails;
import curam.verification.sl.struct.NewVerificationRequirementDetails;
import curam.verification.sl.struct.ReadVerificationRequirementDetails;
import curam.verification.sl.struct.UpdateVerificationRequirementDetails;
import curam.verification.sl.struct.VRRuleClassLinkDtls;
import curam.verification.sl.struct.VRRuleClassLinkKey;
import curam.verification.sl.struct.VRCreoleRuleClassLinkResultDtls;
import curam.verification.sl.struct.VerificationMessage;
import curam.verification.sl.struct.VerificationMessageList;
import curam.verification.sl.struct.VerificationRequirementIDKey;


/**
 * This process class provides the functionality for the Verification Requirement
 * service layer.
 */
public abstract class VerificationRequirement extends curam.verification.sl.base.VerificationRequirement {

  // ___________________________________________________________________________
  /**
   * Cancels a Verification requirement record
   *
   * @param details Verification requirement details
   */
  @Override
  public void cancelVerificationRequirement(final CancelVerificationRequirementDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();

    // Create and populate the Verification requirement key
    final VerificationRequirementKey verificationRequirementKey = new VerificationRequirementKey();

    verificationRequirementKey.verificationRequirementID = details.cancelDtls.verificationRequirementID;

    // Cancel a Verification requirement record
    verificationRequirementObj.cancel(verificationRequirementKey,
      details.cancelDtls);
    
    // Delete the associate link record
    final VerificationRequirementIDKey verificationRequirementIDKey = new VerificationRequirementIDKey();

    verificationRequirementIDKey.verificationRequirementID = details.cancelDtls.verificationRequirementID;
    updateVRCreoleRuleClassLink(verificationRequirementIDKey,
      new CreoleRuleInformation());
  }

  // ___________________________________________________________________________
  /**
   * Creates a Verification requirement record
   *
   * @param details Verification requirement details
   *
   * @return The unique identifier of the record created
   */
  @Deprecated
  @Override
  public VerificationMessageList createVerificationRequirement(final CreateVerificationRequirementDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Create a Verification requirement record
    details.createDtls.recordStatus = RECORDSTATUS.DEFAULTCODE;
    verificationRequirementObj.insert(details.createDtls);

    // Create and populate the return struct
    final VerificationMessageList result = new VerificationMessageList();

    final VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();
    final RequirementLevelDateStatusAndVerifiableIDDetails requirementLevelDateStatusAndVerifiableIDDetails = new   RequirementLevelDateStatusAndVerifiableIDDetails();

    requirementLevelDateStatusAndVerifiableIDDetails.fromDate = details.createDtls.fromDate;
    requirementLevelDateStatusAndVerifiableIDDetails.level = details.createDtls.verificationLevel;
    requirementLevelDateStatusAndVerifiableIDDetails.recordStatus = RECORDSTATUS.CANCELLED;
   
    requirementLevelDateStatusAndVerifiableIDDetails.verifiableDataItemID = details.createDtls.verifiableDataItemID;
    
    if (requirementLevelDateStatusAndVerifiableIDDetails.toDate.isZero()) {
      requirementLevelDateStatusAndVerifiableIDDetails.toDate = details.createDtls.fromDate;
    } else {
      requirementLevelDateStatusAndVerifiableIDDetails.toDate = details.createDtls.toDate;
    }
    
    final CountActiveItemUtilizationForRequirement countActiveItemUtilizationForRequirement = verificationItemUtilization.countActiveItemUtilization(
      requirementLevelDateStatusAndVerifiableIDDetails);

    if (countActiveItemUtilizationForRequirement.recordCount == 0) {
      final LocalisableString infoMessage1 = new LocalisableString(
        curam.message.ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_NO_ACTIVE_VERIFICATION_UTILIZATION);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage1, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      // The informational must now be converted to a format
      // suitable for return to the client.
      final String[] informationalArray = informationalManager.obtainInformationalAsString();

      // The array of informational strings must be
      // transferred to an array of structs because we
      // cannot return an array of strings directly. Each
      // string goes into one struct

      for (int i = 0; i != informationalArray.length; i++) {
        final VerificationMessage warning = new VerificationMessage();

        warning.message = informationalArray[i];
        result.dtls.addRef(warning);

      }
    }

    return result;

  }

  // ___________________________________________________________________________
  /**
   * Reads a list of Verification requirement for verifiable data item
   *
   * @param key Verifiable data item key
   *
   * @return Verification requirement list
   */
  @Override
  public ListVerificationRequirementDetailsList listVerificationRequirement(final VerifiableDataItemKey key)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();

    // Create the return struct
    final ListVerificationRequirementDetailsList verificationRequirementListDetailsList = new ListVerificationRequirementDetailsList();

    // Read a Verification requirement
    verificationRequirementListDetailsList.listDtls = verificationRequirementObj.searchAllVerificationRequirementByVerifiableItemID(
      key);

    return verificationRequirementListDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Modifies a Verification requirement record
   *
   * @param details Verification requirement details
   */
  @Deprecated
  @Override
  public void modifyVerificationRequirement(final ModifyVerificationRequirementDetails details)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();

    // Create and populate the verification requirement key
    final VerificationRequirementKey verificationRequirementKey = new VerificationRequirementKey();

    verificationRequirementKey.verificationRequirementID = details.modifyDtls.verificationRequirementID;

    // Modify a Verification requirement record
    verificationRequirementObj.modify(verificationRequirementKey,
      details.modifyDtls);

  }

  // ___________________________________________________________________________
  /**
   * Reads a Verification requirement record
   *
   * @param key Verification requirement key
   *
   * @return Details of the Verification requirement record
   */
  @Deprecated
  @Override
  public ReadVerificationRequirementDetails readVerificationRequirement(final VerificationRequirementKey key)
    throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();

    // Create the return struct
    final ReadVerificationRequirementDetails readVerificationRequirementDetails = new ReadVerificationRequirementDetails();

    // Read a Verification requirement record
    readVerificationRequirementDetails.readDtls = verificationRequirementObj.read(
      key);

    return readVerificationRequirementDetails;

  }
  
  // BEGIN, CR00333788, AKr
  /**
   * Creates a new verification requirement record and also defines the rules 
   * governing the requirement for verification for a piece of data.
   *
   * @param details The details of the new verification requirement to be created.
   *
   * @return The unique identifier of the record created
   *
   * @throws AppException Generic Exception Signature
   * @throws InformationalException Generic Exception Signature
   * @throws InformationalException  
   * {@link ENTVERIFICATIONREQUIREMENT#ERR_VERIFICATIONREQUIREMENT_FV_NO_ACTIVE_VERIFICATION_UTILIZATION}
   * - when there is no active verification item utilization existing to satisfy this verification requirement.
   */

  @Override
  public VerificationMessageList newVerificationRequirement(
    final NewVerificationRequirementDetails details) throws AppException, InformationalException {
    
    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();

    details.createVerificationRequirementDtls.recordStatus = RECORDSTATUSEntry.DEFAULT().getCode();
    verificationRequirementObj.insert(details.createVerificationRequirementDtls);

    final VerificationMessageList result = new VerificationMessageList();
    final VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();
    final RequirementLevelDateStatusAndVerifiableIDDetails requirementLevelDateStatusAndVerifiableIDDetails = new   RequirementLevelDateStatusAndVerifiableIDDetails();

    requirementLevelDateStatusAndVerifiableIDDetails.fromDate = details.createVerificationRequirementDtls.fromDate;
    requirementLevelDateStatusAndVerifiableIDDetails.level = details.createVerificationRequirementDtls.verificationLevel;
    requirementLevelDateStatusAndVerifiableIDDetails.recordStatus = RECORDSTATUSEntry.CANCELLED.getCode(); 
    requirementLevelDateStatusAndVerifiableIDDetails.verifiableDataItemID = details.createVerificationRequirementDtls.verifiableDataItemID;
    
    if (requirementLevelDateStatusAndVerifiableIDDetails.toDate.isZero()) {
      requirementLevelDateStatusAndVerifiableIDDetails.toDate = details.createVerificationRequirementDtls.fromDate;
    } else {
      requirementLevelDateStatusAndVerifiableIDDetails.toDate = details.createVerificationRequirementDtls.toDate;
    }
    
    final CountActiveItemUtilizationForRequirement countActiveItemUtilizationForRequirement = verificationItemUtilization.countActiveItemUtilization(
      requirementLevelDateStatusAndVerifiableIDDetails);

    if (countActiveItemUtilizationForRequirement.recordCount == 0) {
      final LocalisableString infoMessage1 = new LocalisableString(
        ENTVERIFICATIONREQUIREMENT.ERR_VERIFICATIONREQUIREMENT_FV_NO_ACTIVE_VERIFICATION_UTILIZATION);

      ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        infoMessage1, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
      final String[] informationalArray = informationalManager.obtainInformationalAsString();

      for (int i = 0; i != informationalArray.length; i++) {
        final VerificationMessage warning = new VerificationMessage();

        warning.message = informationalArray[i];
        result.dtls.addRef(warning);

      }
    }
    
    if (!details.newCreoleRuleInformation.ruleSetWithRuleClassName.isEmpty()
      || !details.newCreoleRuleInformation.displayRuleSetWithRuleClassName.isEmpty()
      || !details.newCreoleRuleInformation.displayUIM.isEmpty()) {
      final VRRuleClassLink vRCreoleRuleClassLink = VRRuleClassLinkFactory.newInstance();
      final VRRuleClassLinkDtls vRCreoleRuleClassLinkDtls = new VRRuleClassLinkDtls();

      vRCreoleRuleClassLinkDtls.verificationRequirementID = details.createVerificationRequirementDtls.verificationRequirementID;
      if (!details.newCreoleRuleInformation.ruleSetWithRuleClassName.isEmpty()) {
        vRCreoleRuleClassLinkDtls.ruleSetWithRuleClassName = details.newCreoleRuleInformation.ruleSetWithRuleClassName;
      }

      if (!details.newCreoleRuleInformation.displayRuleSetWithRuleClassName.isEmpty()) {
        vRCreoleRuleClassLinkDtls.displayRuleClassName = details.newCreoleRuleInformation.displayRuleSetWithRuleClassName;
      }
      if (!details.newCreoleRuleInformation.displayUIM.isEmpty()) {
        vRCreoleRuleClassLinkDtls.displayUIM = details.newCreoleRuleInformation.displayUIM;
      }

      vRCreoleRuleClassLink.insert(vRCreoleRuleClassLinkDtls);
    }

    return result;
  }
  
  /**
   * Reads the details of a verification requirement record
   *
   * @param key Identifier for the verification requirement
   *
   * @return The verification Requirement Details
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  
  @Override
  public GetVerificationRequirementDetails getVerificationRequirement(
    final VerificationRequirementKey key) throws AppException, InformationalException {

    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();
    final ReadVerificationRequirementDetails readVerificationRequirementDetails = new ReadVerificationRequirementDetails();

    readVerificationRequirementDetails.readDtls = verificationRequirementObj.read(
      key);
        
    final GetVerificationRequirementDetails getVerificationRequirementDetails = new GetVerificationRequirementDetails();
    
    getVerificationRequirementDetails.readVerificationRequirementDtls = readVerificationRequirementDetails.readDtls;
    
    final VerificationRequirementIDKey verificationRequirementIDKey = new VerificationRequirementIDKey();

    verificationRequirementIDKey.verificationRequirementID = key.verificationRequirementID;
      
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();  
    final VRCreoleRuleClassLinkResultDtls vRCreoleRuleClassLinkResultDtls = VRRuleClassLinkFactory.newInstance().readByVerificationRequirement(
      nfIndicator, verificationRequirementIDKey);
    
    if (!nfIndicator.isNotFound()) {
      final CreoleRuleInformation creoleRuleInformation = new CreoleRuleInformation();

      creoleRuleInformation.ruleSetWithRuleClassName = vRCreoleRuleClassLinkResultDtls.ruleSetWithRuleClassName;
      creoleRuleInformation.displayRuleSetWithRuleClassName = vRCreoleRuleClassLinkResultDtls.displayRuleClassName;
      final CREOLEUtils.RuleSetAndRuleClassName ruleSetAndRuleClassNameObject = CREOLEUtils.RuleSetAndRuleClassName.getRuleSetAndRuleClassName(
        vRCreoleRuleClassLinkResultDtls.ruleSetWithRuleClassName);
      final String ruleSetName = ruleSetAndRuleClassNameObject.getRuleSetName();

      // BEGIN, CR00358053, VKR
      CREOLERuleClassDetails creoleRuleClassDetails = new CREOLERuleClassDetails();

      creoleRuleClassDetails.ruleSetWithRuleClassName = ruleSetAndRuleClassNameObject.toString();
      
      creoleRuleInformation.creoleRuleClassDisplayName = new CREOLEUtils().getDisplayRuleName(
        ruleSetName, creoleRuleClassDetails);
       
      // END, CR00358053
      getVerificationRequirementDetails.readCreoleRuleInformation = creoleRuleInformation;
    }        
    return getVerificationRequirementDetails;
  }
  
  /**
   * Updates a verification requirement record with the new details.
   *
   * @param details The details of the new verification requirement to be updated.
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  @Override
  public void updateVerificationRequirement(
    final UpdateVerificationRequirementDetails details) throws AppException,
      InformationalException {
        
    final curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();
    final VerificationRequirementKey verificationRequirementKey = new VerificationRequirementKey();

    verificationRequirementKey.verificationRequirementID = details.modifyVerificationRequirementDtls.verificationRequirementID;
    verificationRequirementObj.modify(verificationRequirementKey,
      details.modifyVerificationRequirementDtls);
      
    final VerificationRequirementIDKey verificationRequirementIDKey = new VerificationRequirementIDKey();
    
    verificationRequirementIDKey.verificationRequirementID = details.modifyVerificationRequirementDtls.verificationRequirementID;    
    updateVRCreoleRuleClassLink(verificationRequirementIDKey,
      details.updateCreoleRuleInformation);  
  }

  /**
   * Updates the verification requirement creole rule class link record whenever 
   * the verification requirement is updated or canceled.
   *
   * @param verificationRequirementIDKey The unique identifier of the verification requirement record.
   * @param creoleRuleInformation The details of the linked rule class.
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  
  private void updateVRCreoleRuleClassLink(final VerificationRequirementIDKey verificationRequirementIDKey, final CreoleRuleInformation creoleRuleInformation)
    throws AppException, InformationalException {
    
    final VRRuleClassLink vRCreoleRuleClassLinkObj = VRRuleClassLinkFactory.newInstance();

    verificationRequirementIDKey.verificationRequirementID = verificationRequirementIDKey.verificationRequirementID;
    
    final NotFoundIndicator nfIndicator = new NotFoundIndicator();
    final VRCreoleRuleClassLinkResultDtls vRCreoleRuleClassLinkResultDtls = vRCreoleRuleClassLinkObj.readByVerificationRequirement(
      nfIndicator, verificationRequirementIDKey);
    
    if (!nfIndicator.isNotFound()) {
      final VRRuleClassLinkKey vRCreoleRuleClassLinkKey = new VRRuleClassLinkKey();
  
      vRCreoleRuleClassLinkKey.vrCreoleRuleClassLinkID = vRCreoleRuleClassLinkResultDtls.vrCreoleRuleClassLinkID;
      
      vRCreoleRuleClassLinkObj.remove(vRCreoleRuleClassLinkKey);
    }
    
    if (!creoleRuleInformation.ruleSetWithRuleClassName.isEmpty()
      || !creoleRuleInformation.displayRuleSetWithRuleClassName.isEmpty()
      || !creoleRuleInformation.displayUIM.isEmpty()) {
      final VRRuleClassLinkDtls newVRCreoleRuleClassLinkDtls = new VRRuleClassLinkDtls();

      newVRCreoleRuleClassLinkDtls.verificationRequirementID = verificationRequirementIDKey.verificationRequirementID;
      if (!creoleRuleInformation.ruleSetWithRuleClassName.isEmpty()) {
        newVRCreoleRuleClassLinkDtls.ruleSetWithRuleClassName = creoleRuleInformation.ruleSetWithRuleClassName;
      }
      if (!creoleRuleInformation.displayRuleSetWithRuleClassName.isEmpty()) {
        newVRCreoleRuleClassLinkDtls.displayRuleClassName = creoleRuleInformation.displayRuleSetWithRuleClassName;
      }
      if (!creoleRuleInformation.displayUIM.isEmpty()) {
        newVRCreoleRuleClassLinkDtls.displayUIM = creoleRuleInformation.displayUIM;
      }
      vRCreoleRuleClassLinkObj.insert(newVRCreoleRuleClassLinkDtls);
    }
  }
  
  // END, CR00333788
}
