/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006,2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.entity.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.impl.CuramConst;
import curam.message.ENTVERIFICATIONCATEGORY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.verification.sl.entity.fact.VerifiableDataItemFactory;
import curam.verification.sl.entity.struct.CancelVerificationCategoryDtls;
import curam.verification.sl.entity.struct.SearchAllActiveVerifiableDataItemNamesList;
import curam.verification.sl.entity.struct.SearchAllActiveVerificationCategoryNamesList;
import curam.verification.sl.entity.struct.VerificationCategoryDtls;
import curam.verification.sl.entity.struct.VerificationCategoryIDAndStatusKey;
import curam.verification.sl.entity.struct.VerificationCategoryKey;
import curam.verification.sl.entity.struct.VerificationCategoryNameAndStatusKey;
import curam.verification.sl.entity.struct.VerificationCategoryNameCountDetails;
import curam.verification.sl.entity.struct.VerificationCategoryStatusDetails;
import curam.verification.sl.entity.struct.VerificationCategoryStatusKey;
import curam.verification.sl.infrastructure.fact.VerificationControllerFactory;
import curam.verification.sl.infrastructure.intf.VerificationController;


/**
 * Contains details about a specific operations that can be executed on a
 * Verification Category record. A Verification Category record group logical
 * verifiable data item together.
 */
public abstract class VerificationCategory extends curam.verification.sl.entity.base.VerificationCategory {

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data insertion
   *
   * @param details Verification Category details
   */

  protected void preinsert(VerificationCategoryDtls details)
    throws AppException, InformationalException {

    validateInsert(details);
    validateDetails(details);

  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the logical delete
   *
   * @param key Verification Category identifier
   * @param dtls Verification Category details
   */
  protected void precancel(VerificationCategoryKey key,
    CancelVerificationCategoryDtls dtls) throws AppException,
      InformationalException {

    curam.verification.sl.entity.intf.VerificationCategory verificationCategoryObj = curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();

    verificationCategoryObj.validateCancel(dtls);

    // Set the record status to cancelled
    dtls.recordStatus = RECORDSTATUS.CANCELLED;

  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Category details before the logical delete
   *
   *
   * @param details Verification Category details
   */
  public void validateCancel(CancelVerificationCategoryDtls details)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // BEGIN, CR00105264 ,BD
    // Record must not be already canceled
    // Read the database record
    VerificationCategoryKey key = new VerificationCategoryKey();

    key.verificationCategoryID = details.verificationCategoryID;
    VerificationCategoryStatusDetails verificationCategoryStatusDetails = readStatusByID(
      key);      
    
    if (verificationCategoryStatusDetails.recordStatus.equals(
      RECORDSTATUS.CANCELLED)) {
      // END, CR00105264
      
      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONCATEGORY.ERR_VERIFICATIONCATEGORY_FV_VERIFICATION_CATEGORY_CANCELLED);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    
    // If any associated Verifiable Data Item records exist the record
    // may not be cancelled
    
    curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItemObj = VerifiableDataItemFactory.newInstance();

    VerificationCategoryIDAndStatusKey verificationCategoryIDAndStatusKey = new VerificationCategoryIDAndStatusKey();

    verificationCategoryIDAndStatusKey.verificationCategoryID = details.verificationCategoryID;
    verificationCategoryIDAndStatusKey.recordStatus = RECORDSTATUS.CANCELLED;
    SearchAllActiveVerifiableDataItemNamesList searchAllActiveVerifiableDataItemNamesList = verifiableDataItemObj.searchAllActiveNames(
      verificationCategoryIDAndStatusKey);

    if (searchAllActiveVerifiableDataItemNamesList.dtls.size() > 0) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONCATEGORY.ERR_VERIFICATIONCATEGORY_XRV_ASSOCIATED_VERIFIABLE_DATA_ITEM_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Category details before the data insertion
   *
   * @param details Verification Category details
   */
  public void validateInsert(VerificationCategoryDtls details) throws
      AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // The name must not already be in use
    VerificationCategoryNameAndStatusKey verificationCategoryNameAndStatusKey = new VerificationCategoryNameAndStatusKey();

    verificationCategoryNameAndStatusKey.recordStatus = curam.codetable.RECORDSTATUS.CANCELLED;

    verificationCategoryNameAndStatusKey.name = details.name;

    VerificationCategoryNameCountDetails verificationCategoryNameCountDetails;

    verificationCategoryNameCountDetails = countByNameAndStatus(
      verificationCategoryNameAndStatusKey);

    if (verificationCategoryNameCountDetails.recordCount > 0) {
      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONCATEGORY.ERR_VERIFICATIONCATEGORY_XRV_NAME_ALREADY_EXISTS);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  // ___________________________________________________________________________
  /**
   * Validates the Verification Category details before the data modification
   *
   *
   * @param details Verifiable Data Item details
   */
  public void validateModify(VerificationCategoryDtls details)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
  
    // BEGIN, CR00102936 ,BD
    // Record must not be already canceled
    // Read the database record
    VerificationCategoryKey key = new VerificationCategoryKey();

    key.verificationCategoryID = details.verificationCategoryID;
    VerificationCategoryStatusDetails verificationCategoryStatusDetails = readStatusByID(
      key);      
    
    if (verificationCategoryStatusDetails.recordStatus.equals(
      RECORDSTATUS.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.ENTVERIFICATIONCATEGORY.ERR_VERIFICATIONCATEGORY_FV_VERIFICATION_CATEGORY_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    // END, CR00102936 

    // The name must not already be in use
    // Retrieve a list of all Verification Category names.
    VerificationCategoryStatusKey verificationCategoryStatusKey = new VerificationCategoryStatusKey();

    verificationCategoryStatusKey.recordStatus = RECORDSTATUS.CANCELLED;
    SearchAllActiveVerificationCategoryNamesList verificationCategoryIDAndNameDetailsList = searchAllActiveNames(
      verificationCategoryStatusKey);

    // Iterate through the list of Verification categories.
    for (int i = 0; i < verificationCategoryIDAndNameDetailsList.dtls.size(); i++) {

      // Do not check against its own record in the list.
      if (details.verificationCategoryID
        != verificationCategoryIDAndNameDetailsList.dtls.item(i).verificationCategoryID) {

        // Check that the name does not already exist.
        if (details.name.equals(
          verificationCategoryIDAndNameDetailsList.dtls.item(i).name)) {

          AppException appException = new AppException(
            ENTVERIFICATIONCATEGORY.ERR_VERIFICATIONCATEGORY_XRV_NAME_ALREADY_EXISTS);
         
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
            appException, CuramConst.gkEmpty,
            InformationalElement.InformationalType.kError,
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
        }
      }
    }
    
    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175
  }

  // ___________________________________________________________________________
  /**
   * Ensures validations are performed before the data modification
   *
   * @param key Verification Category identifier
   * @param details Verification Category details
   */
  protected void premodify(VerificationCategoryKey key, VerificationCategoryDtls
    details) throws AppException, InformationalException {

    validateModify(details);
    validateDetails(details);
  }

  /**
   * Sets status to cancelled
   *
   * @param key identifies category
   */
  protected void presearchAllActiveNames(VerificationCategoryStatusKey key) throws AppException, InformationalException {

    VerificationCategoryStatusKey verificationCategoryStatusKey = new VerificationCategoryStatusKey();

    verificationCategoryStatusKey.recordStatus = RECORDSTATUS.CANCELLED;

  }

  // ___________________________________________________________________________
  /**
   * Performs the validations common to all operations
   *
   * @param details Verification Category details
   */

  public void validateDetails(VerificationCategoryDtls details)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    // Name must be entered
    if (details.name.trim().length() == 0) {

      AppException appException = new AppException(
        curam.message.ENTVERIFICATIONCATEGORY.ERR_VERIFICATIONCATEGORY_FV_NAME_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        appException, CuramConst.gkEmpty,
        InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00081175, JPG
    VerificationController verificationControllerObj = VerificationControllerFactory.newInstance();
    
    verificationControllerObj.checkForInformationals();
    // END, CR00081175

  }

}
