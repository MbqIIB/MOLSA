/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.verification.sl.impl;


import org.jdom.Document;
import org.jdom.Element;

import curam.codetable.RECORDSTATUS;
import curam.codetable.VERIFIABLEITEMNAME;
import curam.codetable.VERIFICATIONCATEGORYNAME;
import curam.codetable.VERIFICATIONDEPENDENTITEMNAME;
import curam.codetable.VERIFICATIONGROUPNAME;
import curam.codetable.VERIFICATIONITEMNAME;
import curam.codetable.VERIFICATIONREQUIREMENTNAME;
import curam.codetable.VERIFICATIONREQUUSAGENAME;
import curam.core.sl.infrastructure.impl.XmlTreeConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.resources.XMLUtil;
import curam.util.transaction.TransactionInfo;
import curam.verification.sl.entity.fact.DependentDataItemFactory;
import curam.verification.sl.entity.fact.VerificationItemUtilizationFactory;
import curam.verification.sl.entity.fact.VerificationRequirementFactory;
import curam.verification.sl.entity.intf.DependentDataItem;
import curam.verification.sl.entity.struct.SearchAllActiveVerifiableDataItemNamesList;
import curam.verification.sl.entity.struct.SearchAllActiveVerificationCategoryNames;
import curam.verification.sl.entity.struct.SearchAllActiveVerificationCategoryNamesList;
import curam.verification.sl.entity.struct.SearchAllActiveVerificationRequirementNamesList;
import curam.verification.sl.entity.struct.VerifiableDataItemIDAndStatusKey;
import curam.verification.sl.entity.struct.VerifiableDataItemKey;
import curam.verification.sl.entity.struct.VerificationCategoryIDAndStatusKey;
import curam.verification.sl.entity.struct.VerificationCategoryKey;
import curam.verification.sl.entity.struct.VerificationCategoryStatusKey;
import curam.verification.sl.entity.struct.VerificationGroupDtls;
import curam.verification.sl.entity.struct.VerificationRequirementIDAndStatusKey;
import curam.verification.sl.fact.VerificationGroupFactory;
import curam.verification.sl.struct.DependantDataItemList;
import curam.verification.sl.struct.ListVerificationRequirementDetailsList;
import curam.verification.sl.struct.ReadXMLDetails;
import curam.verification.sl.struct.VerifiableDataItemTreeDetails;
import curam.verification.sl.struct.VerificationCategoryTreeDetails;
import curam.verification.sl.struct.VerificationGroupDtlsList;
import curam.verification.sl.struct.VerificationItemUtilizationList;
import curam.verification.sl.struct.VerificationRequirementTreeDetails;
import curam.verification.sl.struct.VerificationTreeDetails;


/**
 * The VerificationTree class provides a number of methods to  read all
 * category and its child nodes data from the database to construct verification
 * tree.
 */


public abstract class VerificationTree extends curam.verification.sl.base.VerificationTree {

  // BEGIN, CR00069996, SK
  protected static final String kNamespace = XmlTreeConst.kNamespace;
  protected static final String kdependentDataItem = XmlTreeConst.kdependentDataItem;
  protected static final String kdependentDataItemID = XmlTreeConst.kdependentDataItemID;
  protected static final String kdependencies = XmlTreeConst.kdependencies;
  protected static final String kverificationRequirementUsage = XmlTreeConst.kverificationRequirementUsage;
  protected static final String kverifiableDataItem = XmlTreeConst.kverifiableDataItem;
  protected static final String kverificationRequirement = XmlTreeConst.kverificationRequirement;
  // BEGIN, CR00350224, SSK
  protected static final String krequirements = XmlTreeConst.kRequirements;
  protected static final String kverificationItemUtilization = XmlTreeConst.kverificationItemUtilization;
  protected static final String kitems = XmlTreeConst.kItems;
  // END, CR00350224
  protected static final String kverificationCategory = XmlTreeConst.kverificationCategory;
  protected static final String kverificationRequirementUsageID = XmlTreeConst.kverificationRequirementUsageID;
  protected static final String kverificationRequirementID = XmlTreeConst.kverificationRequirementID;
  protected static final String kverifiableDataItemID = XmlTreeConst.kverifiableDataItemID;
  protected static final String kverificationItemUtilizationID = XmlTreeConst.kverificationItemUtilizationID;
  protected static final String kverificationCategoryID = XmlTreeConst.kverificationCategoryID;
  protected static final String kTreeName = XmlTreeConst.kverificationTreeName;
  protected static final String kNodeSet = XmlTreeConst.kNodeSet;
  protected static final String kStartNode = XmlTreeConst.kStartNode;
  protected static final String kNode = XmlTreeConst.kNode;
  protected static final String kID = XmlTreeConst.kID;
  protected static final String kType = XmlTreeConst.kType;
  protected static final String kView = XmlTreeConst.kView;
  protected static final String kTitle = XmlTreeConst.kTitle;
  protected static final String kParamValue = XmlTreeConst.kParamValue;
  protected static final String kNodeInfo = XmlTreeConst.kNodeInfo;
  protected static final String kNodeTypes = XmlTreeConst.kNodeTypes;
  protected static final String kNodeType = XmlTreeConst.kNodeType;
  protected static final String kActions = XmlTreeConst.kActions;
  protected static final String kAction = XmlTreeConst.kAction;
  protected static final String kKey = XmlTreeConst.kKey;
  protected static final String kDefault = XmlTreeConst.kDefault;
  protected static final String kIDPrefix = XmlTreeConst.kVerificationIDPrefix;
  protected static final String kName = XmlTreeConst.kName;

  // BEGIN, CR00341469, RPB
  protected static final String kGroups = XmlTreeConst.kGroups;
  protected static final String kverificationGroupID = XmlTreeConst.kverificationGroupID;
  protected static final String kverificationGroup = XmlTreeConst.kverificationGroup;
  // END, CR00341469
  
  
  // END, CR00069996

  // ___________________________________________________________________________
  /**
   * Gets XML tree for the given category.
   *
   * @param key identifies verification category.
   *
   * @return Category tree in XML format.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  public ReadXMLDetails getXMLStringForCategoryTree(VerificationCategoryKey key)
    throws AppException, InformationalException {

    // Verification Tree variables
    VerificationTreeDetails verficationTreeDetails = new VerificationTreeDetails();

    // XML data
    ReadXMLDetails readXMLDetails = new ReadXMLDetails();

    verficationTreeDetails = readCategoryTreeData(key);
    readXMLDetails = buildXMLTree(verficationTreeDetails);

    return readXMLDetails;
  }

  // ___________________________________________________________________________
  /**
   * Gets XML tree for all the categories.
   *
   * @return Category tree in XML format.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  public ReadXMLDetails getXMLStringForTree() throws AppException,
      InformationalException {

    // Verification Tree variables
    VerificationTreeDetails verficationTreeDetails = new VerificationTreeDetails();

    // XML data
    ReadXMLDetails readXMLDetails = new ReadXMLDetails();

    // retrieve data and build XML tree
    verficationTreeDetails = readTreeData();
    readXMLDetails = buildXMLTree(verficationTreeDetails);

    return readXMLDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads all category and its child nodes data from the database.
   *
   * @return All categories and their child entities details.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  public VerificationTreeDetails readTreeData() throws AppException,
      InformationalException {

    // Verification Tree variables
    VerificationTreeDetails verificationTreeDetails = new VerificationTreeDetails();

    // VerificationCategory variables
    VerificationCategoryKey verificationCategoryKey = new VerificationCategoryKey();

    curam.verification.sl.entity.intf.VerificationCategory verificationCategory = curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();

    VerificationCategoryStatusKey verificationCategoryStatusKey = new VerificationCategoryStatusKey();

    verificationCategoryStatusKey.recordStatus = RECORDSTATUS.CANCELLED;

    SearchAllActiveVerificationCategoryNamesList searchAllActiveVerificationCategoryNamesList = verificationCategory.searchAllActiveNames(
      verificationCategoryStatusKey);

    for (int i = 0; i
      < searchAllActiveVerificationCategoryNamesList.dtls.size(); i++) {

      verificationCategoryKey.verificationCategoryID = searchAllActiveVerificationCategoryNamesList.dtls.item(i).verificationCategoryID;

      VerificationCategoryTreeDetails verificationCategoryTreeDetails = new VerificationCategoryTreeDetails();

      verificationCategoryTreeDetails = readCategoryDetails(
        verificationCategoryKey);
      verificationCategoryTreeDetails.nameDtls = searchAllActiveVerificationCategoryNamesList.dtls.item(
        i);

      verificationTreeDetails.categoryDtlsList.addRef(
        verificationCategoryTreeDetails);
    }

    return verificationTreeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Gets category and its child nodes data from the database.
   *
   * @param key identifies verification category.
   * @return Category and its child entities details.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  public VerificationTreeDetails readCategoryTreeData(
    VerificationCategoryKey key) throws AppException, InformationalException {

    // Verification Tree variables
    VerificationTreeDetails verificationTreeDetails = new VerificationTreeDetails();

    curam.verification.sl.entity.intf.VerificationCategory verificationCategory = curam.verification.sl.entity.fact.VerificationCategoryFactory.newInstance();

    SearchAllActiveVerificationCategoryNames searchAllActiveVerificationCategoryNames = new SearchAllActiveVerificationCategoryNames();

    VerificationCategoryTreeDetails verificationCategoryTreeDetails = new VerificationCategoryTreeDetails();

    // read category name
    searchAllActiveVerificationCategoryNames.name = verificationCategory.readNameByID(key).name;
    searchAllActiveVerificationCategoryNames.verificationCategoryID = key.verificationCategoryID;

    verificationCategoryTreeDetails = readCategoryDetails(key);

    verificationCategoryTreeDetails.nameDtls = searchAllActiveVerificationCategoryNames;

    verificationTreeDetails.categoryDtlsList.addRef(
      verificationCategoryTreeDetails);

    return verificationTreeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads Category Details
   * @param key  VerificationCategoryKey
   * @return Tree Information For VerificationCategory
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  public VerificationCategoryTreeDetails readCategoryDetails(
    VerificationCategoryKey key) throws AppException, InformationalException {

    VerificationCategoryTreeDetails verificationCategoryTreeDetails = new VerificationCategoryTreeDetails();

    VerifiableDataItemTreeDetails verifiableDataItemTreeDetails = new VerifiableDataItemTreeDetails();

    curam.verification.sl.entity.intf.VerifiableDataItem verifiableDataItem = curam.verification.sl.entity.fact.VerifiableDataItemFactory.newInstance();

    SearchAllActiveVerifiableDataItemNamesList searchAllActiveVerifiableDataItemNamesList;

    // VerificationItemUtilization variables
    VerifiableDataItemIDAndStatusKey verifiableDataItemIDAndStatusKey = new VerifiableDataItemIDAndStatusKey();

    curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = curam.verification.sl.entity.fact.VerificationItemUtilizationFactory.newInstance();

    // Verification Requirement variables
    curam.verification.sl.entity.intf.VerificationRequirement verificationRequirement = curam.verification.sl.entity.fact.VerificationRequirementFactory.newInstance();
    DependentDataItem dependentDataItem = DependentDataItemFactory.newInstance();

    VerificationRequirementTreeDetails verificationRequirementTreeDetails = new VerificationRequirementTreeDetails();
    SearchAllActiveVerificationRequirementNamesList searchAllActiveVerificationRequirementNamesList;
    curam.verification.sl.entity.intf.VerificationRequirementUsage verificationRequirementUsage = curam.verification.sl.entity.fact.VerificationRequirementUsageFactory.newInstance();

    VerificationCategoryIDAndStatusKey verificationCategoryIDAndStatusKey = new VerificationCategoryIDAndStatusKey();

    verificationCategoryIDAndStatusKey.verificationCategoryID = key.verificationCategoryID;

    VerificationRequirementIDAndStatusKey verificationRequirementIDAndStatusKey = new VerificationRequirementIDAndStatusKey();

    searchAllActiveVerifiableDataItemNamesList = verifiableDataItem.searchAllActiveNames(
      verificationCategoryIDAndStatusKey);

    for (int i = 0; i < searchAllActiveVerifiableDataItemNamesList.dtls.size(); i++) {
      verifiableDataItemTreeDetails = new VerifiableDataItemTreeDetails();

      // construct key
      verifiableDataItemIDAndStatusKey.verifiableDataItemID = searchAllActiveVerifiableDataItemNamesList.dtls.item(i).verifiableDataItemID;

      // read item utilization record
      verifiableDataItemTreeDetails.itemUtilizationList = verificationItemUtilization.searchAllActiveNames(
        verifiableDataItemIDAndStatusKey);

      // read dependent data item record
      verifiableDataItemTreeDetails.dependentItemList = dependentDataItem.searchAllActiveNames(
        verifiableDataItemIDAndStatusKey);

      searchAllActiveVerificationRequirementNamesList = verificationRequirement.searchAllActiveNames(
        verifiableDataItemIDAndStatusKey);

      for (int j = 0; j
        < searchAllActiveVerificationRequirementNamesList.dtls.size(); j++) {
        verificationRequirementTreeDetails = new VerificationRequirementTreeDetails();
        verificationRequirementIDAndStatusKey.verificationRequirementID = searchAllActiveVerificationRequirementNamesList.dtls.item(j).verificationRequirementID;
        verificationRequirementIDAndStatusKey.recordStatus = RECORDSTATUS.CANCELLED;
        // get usages
        verificationRequirementTreeDetails.reqtUsageList = verificationRequirementUsage.searchAllActiveNames(
          verificationRequirementIDAndStatusKey);

        verificationRequirementTreeDetails.nameDtls = searchAllActiveVerificationRequirementNamesList.dtls.item(
          j);

        verifiableDataItemTreeDetails.requirementList.addRef(
          verificationRequirementTreeDetails);
      }

      verifiableDataItemTreeDetails.nameDtls = searchAllActiveVerifiableDataItemNamesList.dtls.item(
        i);

      verificationCategoryTreeDetails.dataItemList.addRef(
        verifiableDataItemTreeDetails);
    }

    return verificationCategoryTreeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Display Verification in Tree Structure.
   *
   * @param details Contains VerificationCategory Information.
   * @return XML Data.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  public ReadXMLDetails buildXMLTree(VerificationTreeDetails details)
    throws AppException, InformationalException {
    ReadXMLDetails readXMLDetails = new ReadXMLDetails();

    // Create Node Types that will be added to the tree.
    Element mainElement = new Element(kNodeInfo, kNamespace);

    mainElement.setAttribute(kName, kTreeName);

    // Attach the Node Types
    mainElement.addContent(createNodeTypesXML());

    // Add NodeSet Element
    mainElement.addContent(createVerificationTree(details));

    Document document = new Document(mainElement);

    readXMLDetails.XMLData = XMLUtil.getAsString(document);
    
    return readXMLDetails;
  }

  // ___________________________________________________________________________
  /**
   * Constructs Verification Tree
   *
   * @param details identifies VerificationTree Details.
   *
   * @return NodeSetElement with all nodes.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createVerificationTree(VerificationTreeDetails details)
    throws AppException, InformationalException {
    // END, CR00198672
    curam.verification.sl.entity.intf.VerificationItemUtilization verificationItemUtilization = VerificationItemUtilizationFactory.newInstance();

    VerificationItemUtilizationList verificationItemUtilizationList = new VerificationItemUtilizationList();

    VerifiableDataItemKey verifiableDataItemKey = new VerifiableDataItemKey();

    curam.verification.sl.entity.intf.VerificationRequirement verificationRequirementObj = VerificationRequirementFactory.newInstance();

    ListVerificationRequirementDetailsList verificationRequirementListDetailsList = new ListVerificationRequirementDetailsList();
    curam.verification.sl.entity.intf.DependentDataItem dependentDataItem = DependentDataItemFactory.newInstance();

    DependantDataItemList dependantDataItemList = new DependantDataItemList();
    Element nodeSetElement = new  Element(kNodeSet, kNamespace);

    for (int i = 0; i < details.categoryDtlsList.size(); i++) {

      String verificationCategoryName = details.categoryDtlsList.item(i).nameDtls.name;

      long verificationCategoryID = details.categoryDtlsList.item(i).nameDtls.verificationCategoryID;

      // BEGIN,CR00087502,SRK
      TreeXMLNodeDetail treeXMLNodeDetails = TreeXMLCacheNode.getInstance().getTreeXMLNodeDetails(
        verificationCategoryID);
      // END,CR00087502

      String verificationCategoryIDString = Long.toString(
        verificationCategoryID);
      String verificationCategoryNameDescription = readCodeTableItemDescription(
        verificationCategoryName, VERIFICATIONCATEGORYNAME.TABLENAME);
    
      Element nodeElementForVerificationCategory = new  Element(kNode,
        kNamespace);

      nodeElementForVerificationCategory.setAttribute(kID,
        kIDPrefix + verificationCategoryIDString);

      // BEGIN,CR00087502,SRK
      // BEGIN, CR00145676, GSP
      if (treeXMLNodeDetails.getStLastAccessedNodeId() != 0) {

        String stStartNodeId = kIDPrefix
          + treeXMLNodeDetails.getStLastAccessedNodeId();

        nodeSetElement.setAttribute(kStartNode, stStartNodeId);
      }
      // END, CR00145676
      // END,CR00087502

      nodeElementForVerificationCategory.setAttribute(kType,
        kverificationCategory);
      Element titleElementForVerificationCategory = new  Element(kTitle,
        kNamespace);

      nodeElementForVerificationCategory.addContent(
        titleElementForVerificationCategory);
      titleElementForVerificationCategory.setText(
        verificationCategoryNameDescription);
      Element paramValueElementForVerificationCategory = new  Element(
        kParamValue, kNamespace);

      nodeElementForVerificationCategory.addContent(
        paramValueElementForVerificationCategory);
      paramValueElementForVerificationCategory.setAttribute(kName, kverificationCategoryID).addContent(
        verificationCategoryIDString);

      nodeSetElement.addContent(nodeElementForVerificationCategory);
     
      for (int j = 0; j < details.categoryDtlsList.item(i).dataItemList.size(); j++) {
        String verifiableDataItemName = details.categoryDtlsList.item(i).dataItemList.item(j).nameDtls.name;

        String verifiableDataItemNameDescription = readCodeTableItemDescription(
          verifiableDataItemName, VERIFIABLEITEMNAME.TABLENAME);
        long verifiableDataItemID = details.categoryDtlsList.item(i).dataItemList.item(j).nameDtls.verifiableDataItemID;
        String verifiableDataItemIDString = Long.toString(verifiableDataItemID);
        Element nodeElementForVerifiableDataItem = new  Element(kNode,
          kNamespace);

        nodeElementForVerificationCategory.addContent(
          nodeElementForVerifiableDataItem);

        nodeElementForVerifiableDataItem.setAttribute(kID,
          kIDPrefix + verifiableDataItemIDString);
        nodeElementForVerifiableDataItem.setAttribute(kType,
          kverifiableDataItem);
        Element titleElementForVerifiableDataItem = new  Element(kTitle,
          kNamespace);

        nodeElementForVerifiableDataItem.addContent(
          titleElementForVerifiableDataItem);
        titleElementForVerifiableDataItem.setText(
          verifiableDataItemNameDescription);
        Element paramValueElementForVerifiableDataItem = new  Element(
          kParamValue, kNamespace);

        nodeElementForVerifiableDataItem.addContent(
          paramValueElementForVerifiableDataItem);

        paramValueElementForVerifiableDataItem.setAttribute(kName, kverifiableDataItemID).addContent(
          verifiableDataItemIDString);

        verifiableDataItemKey.verifiableDataItemID = details.categoryDtlsList.item(i).dataItemList.item(j).nameDtls.verifiableDataItemID;

        verificationItemUtilizationList.listDtls = verificationItemUtilization.searchVerificationItemUtilizationListDetails(
          verifiableDataItemKey);
      
        Element nodeElementForItems = new  Element(kNode, kNamespace);

        if (verificationItemUtilizationList.listDtls.dtls.size() > 0) {

          nodeElementForVerifiableDataItem.addContent(nodeElementForItems);
          // BEGIN, CR00069996, SK
          nodeElementForItems.setAttribute(kID,
            XmlTreeConst.kPrefixVerificationITem + verifiableDataItemIDString);
          // END, CR00069996
          nodeElementForItems.setAttribute(kType, kitems);
          Element titleElementForItems = new  Element(kTitle, kNamespace);

          nodeElementForItems.addContent(titleElementForItems);
          // BEGIN, CR00109753, SK
          LocalisableString messageAll = new LocalisableString(
            curam.message.BPOVERIFICATIONCONST.INF_NODE_ITEMS);

          titleElementForItems.setText(
            messageAll.getMessage(TransactionInfo.getProgramLocale()));
          // END, CR00109753

          Element paramValueElementForItems = new  Element(kParamValue,
            kNamespace);

          nodeElementForItems.addContent(paramValueElementForItems);
          paramValueElementForItems.setAttribute(kName, kverifiableDataItemID).addContent(
            verifiableDataItemIDString);
        }

        for (int k = 0; k
          < details.categoryDtlsList.item(i).dataItemList.item(j).itemUtilizationList.dtls.size(); k++) {
          String vericationItemUtilizationName = details.categoryDtlsList.item(i).dataItemList.item(j).itemUtilizationList.dtls.item(k).name;

          String vericationItemUtilizationNameDescription = readCodeTableItemDescription(
            vericationItemUtilizationName, VERIFICATIONITEMNAME.TABLENAME);

          long verificationItemUtilizationID = details.categoryDtlsList.item(i).dataItemList.item(j).itemUtilizationList.dtls.item(k).verificationItemUtilizationID;

          String verificationItemUtilizationIDString = Long.toString(
            verificationItemUtilizationID);

          nodeElementForItems.addContent(
            createVerificationItemUtilizationXML(
              vericationItemUtilizationNameDescription,
              verificationItemUtilizationIDString));

          verificationRequirementListDetailsList.listDtls = verificationRequirementObj.searchAllVerificationRequirementByVerifiableItemID(
            verifiableDataItemKey);
        }

        verificationRequirementListDetailsList.listDtls = verificationRequirementObj.searchAllVerificationRequirementByVerifiableItemID(
          verifiableDataItemKey);
            
        Element nodeElementForRequirements = new  Element(kNode, kNamespace);

        if (verificationRequirementListDetailsList.listDtls.dtls.size() > 0) {

          nodeElementForVerifiableDataItem.addContent(
            nodeElementForRequirements);
          // BEGIN, CR00069996, SK
          nodeElementForRequirements.setAttribute(kID,
            XmlTreeConst.kPrefixVerificationRequirements
            + verifiableDataItemIDString);
          // END, CR00069996
          nodeElementForRequirements.setAttribute(kType, krequirements);
          Element titleElementForRequirements = new  Element(kTitle, kNamespace);

          nodeElementForRequirements.addContent(titleElementForRequirements);
          // BEGIN, CR00109753, SK
          LocalisableString messageAll = new LocalisableString(
            curam.message.BPOVERIFICATIONCONST.INF_NODE_REQUIREMENTS);

          titleElementForRequirements.setText(
            messageAll.getMessage(TransactionInfo.getProgramLocale()));
          // END, CR00109753

          Element paramValueElementForRequirements = new  Element(kParamValue,
            kNamespace);

          nodeElementForRequirements.addContent(
            paramValueElementForRequirements);
          paramValueElementForRequirements.setAttribute(kName, kverifiableDataItemID).addContent(
            verifiableDataItemIDString);
        }

        for (int m = 0; m
          < details.categoryDtlsList.item(i).dataItemList.item(j).requirementList.size(); m++) {

          String verificationRequirementName = details.categoryDtlsList.item(i).dataItemList.item(j).requirementList.item(m).nameDtls.name;

          String vericationRequirementNameDescription = readCodeTableItemDescription(
            verificationRequirementName, VERIFICATIONREQUIREMENTNAME.TABLENAME);

          long verificationRequirementID = details.categoryDtlsList.item(i).dataItemList.item(j).requirementList.item(m).nameDtls.verificationRequirementID;

          String verificationRequirementIDString = Long.toString(
            verificationRequirementID);
          Element nodeElementForVerificationRequirement = new  Element(kNode,
            kNamespace);

          nodeElementForRequirements.addContent(
            nodeElementForVerificationRequirement);
          nodeElementForVerificationRequirement.setAttribute(kID,
            kIDPrefix + verificationRequirementIDString);

          nodeElementForVerificationRequirement.setAttribute(kType,
            kverificationRequirement);
          Element titleElementForVerificationRequirement = new  Element(kTitle,
            kNamespace);

          nodeElementForVerificationRequirement.addContent(
            titleElementForVerificationRequirement);
          titleElementForVerificationRequirement.setText(
            vericationRequirementNameDescription);
          Element paramValueElementForVerificationRequirement = new  Element(
            kParamValue, kNamespace);

          nodeElementForVerificationRequirement.addContent(
            paramValueElementForVerificationRequirement);

          paramValueElementForVerificationRequirement.setAttribute(kName, kverificationRequirementID).addContent(
            verificationRequirementIDString);

          for (int n = 0; n
            < details.categoryDtlsList.item(i).dataItemList.item(j).requirementList.item(m).reqtUsageList.dtls.size(); n++) {
            String verificationRequirementUsageName = details.categoryDtlsList.item(i).dataItemList.item(j).requirementList.item(m).reqtUsageList.dtls.item(n).name;

            String verificationRequirementUsageNameDescription = readCodeTableItemDescription(
              verificationRequirementUsageName,
              VERIFICATIONREQUUSAGENAME.TABLENAME);

            long verificationRequirementUsageID = details.categoryDtlsList.item(i).dataItemList.item(j).requirementList.item(m).reqtUsageList.dtls.item(n).verificationRequirementUsageID;

            String verificationRequirementUsageIDString = Long.toString(
              verificationRequirementUsageID);

            nodeElementForVerificationRequirement.addContent(
              createVerificationRequirementUsageXML(
                verificationRequirementUsageNameDescription,
                verificationRequirementUsageIDString));
          }
        }

        dependantDataItemList.listDtls = dependentDataItem.searchAllDependentDataItemByVerifiableItemID(
          verifiableDataItemKey);

        // BEGIN, CR00341469, RPB
        Element nodeElementForVerificationGroup = new Element(kNode, kNamespace);
        curam.verification.sl.intf.VerificationGroup vgObject = VerificationGroupFactory.newInstance();
        VerificationGroupDtlsList vgDtlsList = vgObject.listVerificationGroups(
          verifiableDataItemKey);
        
        if (vgDtlsList.dtls.size() > 0) {
          // if (true) {

          nodeElementForVerifiableDataItem.addContent(
            nodeElementForVerificationGroup);

          nodeElementForVerificationGroup.setAttribute(kID,
            XmlTreeConst.kPrefixVerificationGroups + verifiableDataItemIDString);

          nodeElementForVerificationGroup.setAttribute(kType, kGroups);
          Element titleElementForVerficationGroup = new Element(kTitle,
            kNamespace);

          nodeElementForVerificationGroup.addContent(
            titleElementForVerficationGroup);

          LocalisableString messageAll = new LocalisableString(
            curam.message.BPOVERIFICATIONCONST.INF_NODE_GROUPS);

          titleElementForVerficationGroup.setText(
            messageAll.getMessage(TransactionInfo.getProgramLocale()));

          Element paramValueElementForVerificationGroup = new Element(
            kParamValue, kNamespace);

          nodeElementForVerificationGroup.addContent(
            paramValueElementForVerificationGroup);
          paramValueElementForVerificationGroup.setAttribute(kName, kverifiableDataItemID).addContent(
            verifiableDataItemIDString);
        }

        for (final VerificationGroupDtls verificationGroupDtls : vgDtlsList.dtls) {
          String verificationGroupName = verificationGroupDtls.name;
          String vericationGroupNameDescription = readCodeTableItemDescription(
            verificationGroupName, VERIFICATIONGROUPNAME.TABLENAME);
          long verificationGroupID = verificationGroupDtls.verificationGroupID;
          String verificationGroupIDString = Long.toString(verificationGroupID);

          nodeElementForVerificationGroup.addContent(
            createVerificationGroupXML(vericationGroupNameDescription,
            verificationGroupIDString));
        }        
        // END, CR00341469
        
        Element nodeElementForDependentDataItems = new  Element(kNode,
          kNamespace);

        if (dependantDataItemList.listDtls.dtls.size() > 0) {

          nodeElementForVerifiableDataItem.addContent(
            nodeElementForDependentDataItems);
          // BEGIN, CR00069996, SK
          nodeElementForDependentDataItems.setAttribute(kID,
            XmlTreeConst.kPrefixVerificationDependentDataItems
            + verifiableDataItemIDString);
          // END, CR00069996
          nodeElementForDependentDataItems.setAttribute(kType, kdependencies);
          Element titleElementForDependentDataItems = new  Element(kTitle,
            kNamespace);

          nodeElementForDependentDataItems.addContent(
            titleElementForDependentDataItems);
          // BEGIN, CR00190258, CL
          titleElementForDependentDataItems.setText(
            new curam.util.exception.LocalisableString(curam.message.BPOVERIFICATIONCONST.TEXT_DEPENDENCIES).getMessage(
              TransactionInfo.getProgramLocale()));
          // END, CR00190258
          Element paramValueElementForDependentDataItems = new  Element(
            kParamValue, kNamespace);

          nodeElementForDependentDataItems.addContent(
            paramValueElementForDependentDataItems);
          paramValueElementForDependentDataItems.setAttribute(kName, kverifiableDataItemID).addContent(
            verifiableDataItemIDString);
        }

        for (int k = 0; k
          < details.categoryDtlsList.item(i).dataItemList.item(j).dependentItemList.dtls.size(); k++) {
          String dependentDataItemName = details.categoryDtlsList.item(i).dataItemList.item(j).dependentItemList.dtls.item(k).name;

          String dependentDataItemNameDescription = readCodeTableItemDescription(
            dependentDataItemName, VERIFICATIONDEPENDENTITEMNAME.TABLENAME);

          long dependentDataItemID = details.categoryDtlsList.item(i).dataItemList.item(j).dependentItemList.dtls.item(k).dependentDataItemID;

          String dependentDataItemIDString = Long.toString(dependentDataItemID);

          nodeElementForDependentDataItems.addContent(
            createDependentDataItemXML(dependentDataItemNameDescription,
            dependentDataItemIDString));
        }
      }
    }   
    return nodeSetElement;

  }

  // ___________________________________________________________________________
  /**
   * Constructs VerificationItemUtilization Node
   *
   * @param itemName identifies VerificationItemName.
   * @param verificationItemUtilizationID identifies VerificationItemUtilization.
   * @return VerificationItemUtilization Element.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createVerificationItemUtilizationXML(String itemName,
    String verificationItemUtilizationID)
    throws AppException, InformationalException {
    // END, CR00198672
    Element nodeElementForItemUtilization = new  Element(kNode, kNamespace);

    nodeElementForItemUtilization.setAttribute(kID,
      kIDPrefix + verificationItemUtilizationID);
    nodeElementForItemUtilization.setAttribute(kType,
      kverificationItemUtilization);
    Element titleElementForItemUtilization = new  Element(kTitle, kNamespace);

    nodeElementForItemUtilization.addContent(titleElementForItemUtilization);
    titleElementForItemUtilization.setText(itemName);
    Element paramValueElementForItemUtilization = new  Element(kParamValue,
      kNamespace);

    nodeElementForItemUtilization.addContent(
      paramValueElementForItemUtilization);

    paramValueElementForItemUtilization.setAttribute(kName, kverificationItemUtilizationID).addContent(
      verificationItemUtilizationID);

    return nodeElementForItemUtilization;
  }
  
  // BEGIN, CR00341469, RPB
  /**
   * Constructs VerificationItemUtilization Node
   *
   * @param verificationItemUtilizationID
   * identifies VerificationItemUtilization.
   * @param itemName
   * identifies VerificationItemName.
   * @return VerificationItemUtilization Element.
   * @throws AppException
   * If error occurs.
   * @throws InformationalException
   * If error occurs.
   */

  protected Element createVerificationGroupXML(String itemName,
    String verificationGroupID) throws AppException, InformationalException {

    Element nodeElementForVerificationGroup = new Element(kNode, kNamespace);

    nodeElementForVerificationGroup.setAttribute(kID,
      kIDPrefix + verificationGroupID);
    nodeElementForVerificationGroup.setAttribute(kType, kverificationGroup);
    Element titleElementForVerificationGroup = new Element(kTitle, kNamespace);

    nodeElementForVerificationGroup.addContent(titleElementForVerificationGroup);
    titleElementForVerificationGroup.setText(itemName);
    Element paramValueElementVerficationGroup = new Element(kParamValue,
      kNamespace);

    nodeElementForVerificationGroup.addContent(
      paramValueElementVerficationGroup);

    paramValueElementVerficationGroup.setAttribute(kName, kverificationGroupID).addContent(
      verificationGroupID);

    return nodeElementForVerificationGroup;
  }

  // END, CR00341469
  
  // ___________________________________________________________________________
  /**
   * Constructs DependentDataItem Node
   *
   * @param dependentItemName identifies DependentDataItemName.
   * @param dependentDataItemID identifies DependentDataItemID.
   * @return DependentDataItem Element.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createDependentDataItemXML(String dependentItemName,
    String dependentDataItemID)
    throws AppException, InformationalException {
    // END, CR00198672
    Element nodeElementForDependentDataItem = new  Element(kNode, kNamespace);

    nodeElementForDependentDataItem.setAttribute(kID,
      kIDPrefix + dependentDataItemID);
    nodeElementForDependentDataItem.setAttribute(kType, kdependentDataItem);
    Element titleElementForDependentDataItem = new  Element(kTitle, kNamespace);

    nodeElementForDependentDataItem.addContent(titleElementForDependentDataItem);
    titleElementForDependentDataItem.setText(dependentItemName);
    Element paramValueElementForDependentDataItem = new  Element(kParamValue,
      kNamespace);

    nodeElementForDependentDataItem.addContent(
      paramValueElementForDependentDataItem);

    paramValueElementForDependentDataItem.setAttribute(kName, kdependentDataItemID).addContent(
      dependentDataItemID);

    return nodeElementForDependentDataItem;
  }

  // ___________________________________________________________________________
  /**
   * Constructs VerificationRequirementUsage Node
   *
   * @param requirementUsageName identifies VerificationRequirementUsage Name.
   * @param verificationRequirementUsageID identifies verificationRequirementUsageID.
   * @return VerificationRequirementUsage Element.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  // BEGIN, CR00198672, VK
  protected Element createVerificationRequirementUsageXML(String
    requirementUsageName, String verificationRequirementUsageID)
    throws AppException, InformationalException {
    // END, CR00198672
    Element nodeElementForRequirementUsage = new  Element(kNode, kNamespace);

    nodeElementForRequirementUsage.setAttribute(kID,
      kIDPrefix + verificationRequirementUsageID);
    nodeElementForRequirementUsage.setAttribute(kType,
      kverificationRequirementUsage);
    Element titleElementForRequirementUsage = new  Element(kTitle, kNamespace);

    nodeElementForRequirementUsage.addContent(titleElementForRequirementUsage);
    titleElementForRequirementUsage.setText(requirementUsageName);
    Element paramValueElementForRequirementUsage = new  Element(kParamValue,
      kNamespace);

    nodeElementForRequirementUsage.addContent(
      paramValueElementForRequirementUsage);

    paramValueElementForRequirementUsage.setAttribute(kName, kverificationRequirementUsageID).addContent(
      verificationRequirementUsageID);

    return nodeElementForRequirementUsage;
  }

  // ___________________________________________________________________________
  /**
   * Constructs Verification NodeTypes.
   *
   * @return All NodeTypes Information.
   */
  protected static Element createNodeTypesXML() {
    Element nodeTypesElement = new  Element(kNodeTypes, kNamespace);
    Element nodeTypeElement = new  Element(kNodeType, kNamespace);

    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(kName, kverificationCategory);
    Element actionsElement = new  Element(kActions, kNamespace);

    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);
    Element actionElement = new  Element(kAction, kNamespace);

    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);
    Element paramElement = new  Element(kKey, kNamespace);

    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, kverificationCategoryID);

    nodeTypeElement = new  Element(kNodeType, kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(kName, kitems);
    actionsElement = new  Element(kActions, kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);
    actionElement = new  Element(kAction, kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);
    paramElement = new  Element(kKey, kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, kverifiableDataItemID);

    nodeTypeElement = new  Element(kNodeType, kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(kName, kverificationItemUtilization);
    actionsElement = new  Element(kActions, kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);
    actionElement = new  Element(kAction, kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);
    paramElement = new  Element(kKey, kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, kverificationItemUtilizationID);

    nodeTypeElement = new  Element(kNodeType, kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(kName, krequirements);
    actionsElement = new  Element(kActions, kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);
    actionElement = new  Element(kAction, kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);
    paramElement = new  Element(kKey, kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, kverifiableDataItemID);

    nodeTypeElement = new  Element(kNodeType, kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(kName, kverificationRequirement);
    actionsElement = new  Element(kActions, kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);
    actionElement = new  Element(kAction, kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);
    paramElement = new  Element(kKey, kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, kverificationRequirementID);

    // BEGIN, CR00341469, RPB
    nodeTypeElement = new Element(kNodeType, kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(kName, kGroups);
    actionsElement = new Element(kActions, kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);
    actionElement = new Element(kAction, kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);
    paramElement = new Element(kKey, kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, kverifiableDataItemID);

    nodeTypeElement = new Element(kNodeType, kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(kName, kverificationGroup);
    actionsElement = new Element(kActions, kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);
    actionElement = new Element(kAction, kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);
    paramElement = new Element(kKey, kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, kverificationGroupID);
    // END, CR00341469    

    nodeTypeElement = new  Element(kNodeType, kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(kName, kverifiableDataItem);
    actionsElement = new  Element(kActions, kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);
    actionElement = new  Element(kAction, kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);
    paramElement = new  Element(kKey, kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, kverifiableDataItemID);

    nodeTypeElement = new  Element(kNodeType, kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(kName, kverificationRequirementUsage);
    actionsElement = new  Element(kActions, kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);
    actionElement = new  Element(kAction, kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);
    paramElement = new  Element(kKey, kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, kverificationRequirementUsageID);

    nodeTypeElement = new  Element(kNodeType, kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(kName, kdependencies);
    actionsElement = new  Element(kActions, kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);
    actionElement = new  Element(kAction, kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);
    paramElement = new  Element(kKey, kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, kverifiableDataItemID);

    nodeTypeElement = new  Element(kNodeType, kNamespace);
    nodeTypesElement.addContent(nodeTypeElement);
    nodeTypeElement.setAttribute(kName, kdependentDataItem);
    actionsElement = new  Element(kActions, kNamespace);
    nodeTypeElement.addContent(actionsElement);
    actionsElement.setAttribute(kDefault, kView);
    actionElement = new  Element(kAction, kNamespace);
    actionsElement.addContent(actionElement);
    actionElement.setAttribute(kName, kView);
    paramElement = new  Element(kKey, kNamespace);
    actionElement.addContent(paramElement);
    paramElement.setAttribute(kName, kdependentDataItemID);

    return nodeTypesElement;
  }

  // ___________________________________________________________________________
  /**
   * This readCodeTableItemDescription method reads the description of code table code.
   *
   * @param codeName code table code.
   * @param codeTablelName code table name.
   * @return CodeItem Description.
   * @throws AppException If error occurs.
   * @throws InformationalException If error occurs.
   */
  public String readCodeTableItemDescription(String codeName,
    String codeTablelName)
    throws AppException, InformationalException {

    CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    // code table variables
    curam.util.internal.codetable.intf.CodeTable codeTableInterface = CodeTableFactory.newInstance();

    ctitemKey.code = codeName;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = codeTablelName;

    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC

    return ctitem.description;
  }

}
