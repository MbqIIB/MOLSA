/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalcheck.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeSet;

import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.approvalcheck.entity.impl.ApprovalCheckAdapter;
import curam.approvalcheck.entity.struct.ApprovalCheckDtls;
import curam.codetable.impl.APPROVALCHECKOVERRIDEEntry;
import curam.codetable.impl.APPROVALCHECKTYPEEntry;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.ORGSTRUCTURESTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.fact.OrganisationStructureFactory;
import curam.core.sl.entity.intf.OrganisationStructure;
import curam.core.sl.entity.struct.OrganisationStructureID;
import curam.core.sl.entity.struct.OrganisationStructureStatus;
import curam.core.struct.SearchByOrgUnitStatusKey;
import curam.core.struct.UserForOrgUnitDetails;
import curam.core.struct.UserForOrgUnitDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.persistence.helper.EventDispatcherFactory;


/**
 * Approval Check Data Access Object. Performs approval check on user,
 * organization unit or the related identifier and related type. An event is
 * sent before default approval check processing is performed to allow the
 * approval check to be overridden. This DAO also provides status search methods
 * for user, organization unit, related id and related type.
 */

@Singleton
// BEGIN, CR00183334, PS
public class ApprovalCheckDAOImpl extends StandardDAOImpl<ApprovalCheck, ApprovalCheckDtls> implements
  ApprovalCheckDAO {
  // END, CR00183334
  protected static final ApprovalCheckAdapter adapter = new ApprovalCheckAdapter();

  // BEGIN, CR00231006, GD
  @Inject
  protected EventDispatcherFactory<ApprovalCheckOverrideEvent> approvalCheckOverrideEventDispatcherFactory;
  // END, CR00231006

  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected ApprovalCheckDAOImpl() {
    // no-arg constructor for use only by Guice
    // END, CR00183334
    super(adapter, ApprovalCheck.class);
  }

  /**
   * {@inheritDoc}
   */
  public List<ApprovalCheck> searchByTypeOrganisationUnitAndStatus(
    final APPROVALCHECKTYPEEntry type,
    final APPROVALRELATEDTYPEEntry relatedType,
    final long organisationUnitID, final RECORDSTATUSEntry status) {
    return Collections.unmodifiableList(
      newList(
        adapter.searchByOrganisationUnitIDTypeRelatedTypeAndStatus(
          type.getCode(), organisationUnitID, status.getCode(),
          relatedType.getCode())));
  }

  /**
   * {@inheritDoc}
   */
  public List<ApprovalCheck> searchByTypeRelatedIDRelatedTypeAndStatus(
    final APPROVALCHECKTYPEEntry type,
    final APPROVALRELATEDTYPEEntry relatedType, final long relatedID,
    final RECORDSTATUSEntry status) {
    return Collections.unmodifiableList(
      newList(
        adapter.searchByTypeRelatedIDRelatedTypeAndStatus(relatedID,
        relatedType.getCode(), status.getCode(), type.getCode())));
  }

  /**
   * {@inheritDoc}
   */
  public List<ApprovalCheck> searchByTypeUsernameAndStatus(
    final APPROVALCHECKTYPEEntry type,
    final APPROVALRELATEDTYPEEntry relatedType, final String username,
    final RECORDSTATUSEntry status) {
    return Collections.unmodifiableList(
      newList(
        adapter.searchByUsernameTypeRelatedTypeAndStatus(status.getCode(),
        username, type.getCode(), relatedType.getCode())));
  }

  /**
   * {@inheritDoc}
   */
  public Boolean checkApprovalRequired(final long relatedID,
    final APPROVALRELATEDTYPEEntry relatedType, final String userName)
    throws InformationalException, AppException {

    /**
     * Allow for approval check override
     */
    // this codetable will be set by listeners if an overridden approval check
    // was
    // performed.
    APPROVALCHECKOVERRIDEEntry approvalCheckRequired = APPROVALCHECKOVERRIDEEntry.NOT_SPECIFIED;

    // BEGIN, CR00231006, GD
    approvalCheckOverrideEventDispatcherFactory.get(ApprovalCheckOverrideEvent.class).overrideApprovalCheck(
      relatedID, relatedType, userName, approvalCheckRequired);
    // END, CR00231006

    if (!approvalCheckRequired.equals(APPROVALCHECKOVERRIDEEntry.NOT_SPECIFIED)) {
      // return true if approval check is required
      // return false if approval check is not required
      return approvalCheckRequired.equals(
        APPROVALCHECKOVERRIDEEntry.APPROVALCHECKREQUIRED);
    }
    // first check for approval checks recorded against the user
    List<ApprovalCheck> approvalCheckList = searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.USER, relatedType, relatedID,
      RECORDSTATUSEntry.NORMAL);

    if (approvalCheckList.size() > 0) {
      List<ApprovalCheck> matchedList = checkForApprovalOnUser(
        approvalCheckList, userName);

      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }
    // if no approval checks recorded against the user then
    // search for approval checks against the organization unit that the user
    // belongs to
    approvalCheckList = searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.ORGANISATIONUNIT, relatedType, relatedID,
      RECORDSTATUSEntry.NORMAL);
    if (approvalCheckList.size() > 0) {
      List<ApprovalCheck> matchedList = checkForApprovalOnOrgUnit(
        approvalCheckList, userName);

      if (matchedList.size() > 0) {
        return checkForApproval(matchedList);
      }
    }
    // if no approval checks found for the users organization units then
    // search for approval checks on the related type and related identifier
    approvalCheckList = searchByTypeRelatedIDRelatedTypeAndStatus(
      APPROVALCHECKTYPEEntry.RELATEDTYPE, relatedType, relatedID,
      RECORDSTATUSEntry.NORMAL);
    if (approvalCheckList.size() > 0) {
      return checkForApproval(approvalCheckList);
    }
    // nothing found
    return false;

  }

  /**
   * Returns a list of approval check objects for the user provided.
   *
   * @param approvalCheckList
   * List of user approval check objects.
   * @param userName
   * The user that the returned approval check list relates to.
   * @return list of approval check objects for the user provided.
   */
  protected List<ApprovalCheck> checkForApprovalOnUser(
    final List<ApprovalCheck> approvalCheckList, final String userName) {

    List<ApprovalCheck> userMatchList = new ArrayList<ApprovalCheck>();

    // add objects that match this user
    for (ApprovalCheck matchingApprovalCheck : approvalCheckList) {
      if (matchingApprovalCheck.getUsername().equals(userName)) {
        userMatchList.add(matchingApprovalCheck);
      }
    }

    return userMatchList;

  }

  /**
   * Returns a list of approval check objects for organization units that the
   * user provided belongs to.
   *
   * @param approvalCheckList
   * List of organization unit approval check objects.
   * @param userName
   * The user that must belong to the organization unit recorded on the
   * approval check.
   * @return list of approval check objects for organization units that the user
   * provided belongs to.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected List<ApprovalCheck> checkForApprovalOnOrgUnit(
    final List<ApprovalCheck> approvalCheckList, final String userName)
    throws InformationalException, AppException {

    List<ApprovalCheck> userMatchList = new ArrayList<ApprovalCheck>();
    // only add objects for org units that this user belongs to
    SearchByOrgUnitStatusKey searchByOrgUnitStatusKey = new SearchByOrgUnitStatusKey();

    searchByOrgUnitStatusKey.recordStatus = curam.codetable.RECORDSTATUS.NORMAL;
    searchByOrgUnitStatusKey.effectiveDate = curam.util.type.Date.getCurrentDate();
    searchByOrgUnitStatusKey.organisationStructureID = getActiveOrgStructure();
    for (ApprovalCheck matchingApprovalCheck : approvalCheckList) {
      // check if current user is part of the org unit
      // BEGIN, CR00299433, MC
      searchByOrgUnitStatusKey.organisationUnitID = matchingApprovalCheck.getOrganisationUnitID();
      // END, CR00299433
      UserForOrgUnitDetailsList userList = UsersFactory.newInstance().searchByOrgUnit(
        searchByOrgUnitStatusKey);

      for (UserForOrgUnitDetails user : userList.dtls.items()) {
        if (user.userName.equals(userName)) {
          userMatchList.add(matchingApprovalCheck);
        }
      }
    }

    return userMatchList;

  }

  /**
   * Retrieves the active organization structure.
   * @return The active organization structure identifier.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  Long getActiveOrgStructure() throws InformationalException,
      AppException {

    OrganisationStructure organisationStructure = OrganisationStructureFactory.newInstance();
    OrganisationStructureStatus organisationStructureStatus = new OrganisationStructureStatus();

    organisationStructureStatus.statusCode = ORGSTRUCTURESTATUSEntry.ACTIVE.getCode();

    OrganisationStructureID organisationStructureID = organisationStructure.readActiveOrganisationStructureID(
      organisationStructureStatus);

    return organisationStructureID.organisationStructureID;
  }

  /**
   * Finds approval check with the greatest percentage value from the approval
   * check list provided. Uses the approval check object found to determine
   * whether approval is required.
   *
   * @param approvalCheckList
   * The list of approval check object, where one object will be used
   * to determine whether approval is required.
   * @return True if the percentage is greater than a random number between 0
   * and 100. False if the percentage is less than a random number
   * between 0 and 100.
   */
  protected Boolean checkForApproval(final List<ApprovalCheck> approvalCheckList) {

    if (approvalCheckList.size() == 0) {
      return false;
    }
    TreeSet<Integer> sortedSet = new TreeSet<Integer>();

    // add the approval check records into a set, sorted ascending by approval
    // check percentage
    for (ApprovalCheck sortedApprovalCheckByPercentage : approvalCheckList) {
      sortedSet.add(
        new Integer(sortedApprovalCheckByPercentage.getPercentage()));
    }

    // get the value of the maximum percentage in the approval check list
    int maxPercentageFromList = sortedSet.last().intValue();

    // If the percentage is 0 then return false
    if (maxPercentageFromList == 0) {
      return false;
    }

    // BEGIN, CR00238338, PF
    // get a random number
    int randNum = new Double(Math.random() * CuramConst.gkOneHundredPercent).intValue();

    // END, CR00238338, PF
    
    // if the percentage recorded against the approval check is greater than or
    // equal to the random number then
    // return true. If the percentage is less than the random number then return
    // false.
    return maxPercentageFromList >= randNum;

  }

}
