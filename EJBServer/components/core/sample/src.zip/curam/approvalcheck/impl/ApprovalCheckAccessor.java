/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalcheck.impl;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.APPROVALCHECKTYPEEntry;
import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.util.persistence.OptimisticLockable;
import curam.util.persistence.StandardEntity;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.Money;

/**
 * 
 * Accessor interface for Approval Check.
 */
@ImplementedBy(ApprovalCheckImpl.class)
public interface ApprovalCheckAccessor extends StandardEntity,
    OptimisticLockable, Lifecycle<RECORDSTATUSEntry> {

  /**
   * Returns the value of the relatedID field.
   * 
   * @return the relatedID.
   */
  public long getRelatedID();

  /**
   * Returns the value of the percentage field.
   * 
   * @return the percentage.
   */
  public short getPercentage();

  /**
   * Returns the value of the cost field.
   * 
   * @return the cost.
   */
  public Money getCost();

  /**
   * Returns the value of the comments field.
   * 
   * @return the comments.
   */
  public String getComments();

  /**
   * Returns the value of the username field.
   * 
   * @return the username.
   */
  public String getUsername();

  /**
   * Returns the value of the organisationUnitID field.
   * 
   * @return the organisationUnitID.
   */
  public long getOrganisationUnitID();

  /**
   * Returns the value of the relatedType field.
   * 
   * @return the related type.
   */
  public APPROVALRELATEDTYPEEntry getRelatedType();

  /**
   * Returns the value of the type field.
   * 
   * @return the type, i.e. 'User', 'OrganisationUnit', or 'RelatedType'.
   */
  public APPROVALCHECKTYPEEntry getType();
}
