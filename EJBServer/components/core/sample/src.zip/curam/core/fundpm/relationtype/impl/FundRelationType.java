/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.fundpm.relationtype.impl;


import curam.util.ctm.bom.BusinessObjectModule;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * A Fund PM Rule Set can have association with any Fund Relation Type Item.
 * This interface is modeled to capture the characteristics of 
 * a Fund Relation type Item.
 *
 * <p>
 * A fund relation type item ultimately will be represented as an entity in the
 * system. Hence the methods contained in the interface will also 
 * correspond to operations specific to that entity. 
 * </p>
 *
 * <p>
 * A fund PM rule set {@link BusinessObjectModule} can have dependencies with 
 * any Fund relation type item. Hence the methods within this interface 
 * will also provide information that suitably assists in considering a 
 * particular fund relation type item as  a dependent {@link BusinessObjectModule}.  
 * </p>
 */
public interface FundRelationType {

  /**
   * Returns the unique key for this fund relation type. The unique key  
   * is used to distinguish this fund relation type from other 
   * {@link FundRelationType}
   *
   * @return The unique key for this fund relation type.
   */
  String getKey();
  
  /**
   * Returns a suitable display name of the incoming fund relation type item. 
   *
   * @param relationTypeObjectId Because a fund relation type item is represented 
   * as an entity, the incoming parameter contains value to identify the entity. 
   * @return The suitable display name of the incoming fund relation type item.
   *
   * @throws InformationalException Generic exception signature
   * @throws AppException Generic exception signature.
   */
  String getDisplayName(Long relationTypeObjectId) 
    throws AppException, InformationalException;
   
  /**
   * Returns the unique business object type identifier for this fund relation
   * type identifier.
   *
   * @return The unique business object type identifier for this fund relation
   * type identifier.
   */
  String getType(Long relatedObjectId) throws AppException, InformationalException;
  
}
