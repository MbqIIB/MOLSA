/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright (c) 2005-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import java.util.Iterator; 
import curam.core.facade.struct.InboxContextDescription;
import curam.core.facade.struct.LimitedListDeferredTaskDetails;
import curam.core.facade.struct.LimitedListReservedTaskDetails;
import curam.core.facade.struct.LimitedListWorkQueueUnreservedTasksDetails;
import curam.core.facade.struct.ListAssignedTaskDetails;
import curam.core.facade.struct.ListReservedByPriorityDetails;
import curam.core.facade.struct.ListReservedByPriorityKey;
import curam.core.facade.struct.ListReservedByStatusKey;
import curam.core.facade.struct.ListReservedDueOnDateDetails;
import curam.core.facade.struct.ListReservedDueOnOrBeforeDateDetails;
import curam.core.facade.struct.ListReservedKey;
import curam.core.facade.struct.ListSearchTaskDetails;
import curam.core.facade.struct.ListTaskKey;
import curam.core.facade.struct.ListUserOrgObjectWorkQueueDetails;
import curam.core.facade.struct.ListWorkQueueNameDtls;
import curam.core.facade.struct.ListWorkQueueUnreservedTasksKey;
import curam.core.facade.struct.ReserveNextTaskDetails;
import curam.core.facade.struct.ReserveNextTaskKey;
import curam.core.facade.struct.ReserveNextWorkQueueTaskKey;
import curam.core.facade.struct.SubscribeUserWorkQueueKey;
import curam.core.facade.struct.UnsubscribeUserWorkQueueKey;
import curam.core.facade.struct.ViewUserInboxDetails;
import curam.core.facade.struct.ViewUserInboxKey;
import curam.core.hook.task.impl.SearchTaskUtilities;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.CurrentUserWorkQueueAndSubscriberDetails;
import curam.core.sl.entity.struct.CurrentUserWorkQueueAndSubscriberDetailsList;
import curam.core.sl.fact.InboxFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.InboxOptionsPreferencesDetails;
import curam.core.sl.struct.InboxOptionsSummaryDetails;
import curam.core.sl.struct.InboxUserPreferenceDetails;
import curam.core.sl.struct.TaskQueryKey;
import curam.core.sl.struct.TaskQueryResultDetailsList;
import curam.core.sl.struct.TaskRedirectionSecurity;
import curam.core.struct.AvailableTaskSearchCriteria;
import curam.core.struct.AvailableTaskSearchResult;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * Standard implementation of {@link curam.core.facade.intf.Inbox}.
 */
public abstract class Inbox extends curam.core.facade.base.Inbox {

  /**
   * {@inheritDoc}
   */
  @Override
  public ReserveNextTaskDetails reserveNextTask(
    ReserveNextTaskKey reserveNextTaskKey) throws AppException,
      InformationalException {

    // Inbox service layer object
    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    // create return object
    ReserveNextTaskDetails reserveNextTaskDetails = new ReserveNextTaskDetails();

    reserveNextTaskKey.reserveTaskKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // reserve next task
    reserveNextTaskDetails.reserveTaskDetails = inboxObj.reserveNextTask(
      reserveNextTaskKey.reserveTaskKey);

    // return reserved task details
    return reserveNextTaskDetails;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReserveNextTaskDetails reserveNextWorkQueueTask(
    ReserveNextWorkQueueTaskKey reserveNextWorkQueueTaskKey)
    throws AppException, InformationalException {

    // Inbox service layer object
    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    // create return object
    ReserveNextTaskDetails reserveNextTaskDetails = new ReserveNextTaskDetails();

    reserveNextWorkQueueTaskKey.reserveTaskKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // reserve next work queue task
    reserveNextTaskDetails.reserveTaskDetails = inboxObj.reserveNextWorkQueueTask(
      reserveNextWorkQueueTaskKey.reserveTaskKey);

    // return reserved task details
    return reserveNextTaskDetails;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void subscribeUserWorkQueue(
    SubscribeUserWorkQueueKey subscribeUserWorkQueueKey) throws AppException,
      InformationalException {
    // Call the Inbox service layer object
    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    // Work Queue Subscription service layer objects
    UserAccess userAccessObj = UserAccessFactory.newInstance();

    // Service layer method key
    curam.core.sl.struct.SubscribeUserWorkQueueKey slSubscribeUserWorkQueueKey = new curam.core.sl.struct.SubscribeUserWorkQueueKey();

    // set up the current user name
    slSubscribeUserWorkQueueKey.userName = userAccessObj.getUserDetails().userName;

    // set up the work queue id
    slSubscribeUserWorkQueueKey.key.workQueueID = subscribeUserWorkQueueKey.subscribeUserWorkQueue.key.workQueueID;

    // subscribe the user;
    inboxObj.subscribeUserWorkQueue(slSubscribeUserWorkQueueKey);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void unsubscribeUserWorkQueue(UnsubscribeUserWorkQueueKey key)
    throws AppException, InformationalException {
    // Inbox service layer object
    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    // Work Queue Subscription service layer objects
    UserAccess userAccessObj = UserAccessFactory.newInstance();

    // Service layer method key
    curam.core.sl.struct.UnsubscribeUserWorkQueueKey unsubscribeUserWorkQueueKey = new curam.core.sl.struct.UnsubscribeUserWorkQueueKey();

    // set up the work queue id and the user un-subscribe
    unsubscribeUserWorkQueueKey.key.workQueueID = key.unsubscribeUserWorkQueueKey.key.workQueueID;

    unsubscribeUserWorkQueueKey.userName = userAccessObj.getUserDetails().userName;

    inboxObj.unsubscribeUserWorkQueue(unsubscribeUserWorkQueueKey);

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReserveNextTaskDetails reserveNextTaskFromPreferredWorkQueue(
    ReserveNextWorkQueueTaskKey reserveNextWorkQueueTaskKey)
    throws AppException, InformationalException {

    // Inbox service layer object
    curam.core.sl.intf.Inbox inboxObj = InboxFactory.newInstance();

    // create return object
    ReserveNextTaskDetails reserveNextTaskDetails = new ReserveNextTaskDetails();

    reserveNextWorkQueueTaskKey.reserveTaskKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // reserve next work queue task
    reserveNextTaskDetails.reserveTaskDetails = inboxObj.reserveNextTaskFromPreferredWorkQueue(
      reserveNextWorkQueueTaskKey.reserveTaskKey);

    // return reserved task details
    return reserveNextTaskDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ReserveNextTaskDetails reserveNextTaskFromPreferredOrgUnit(
    ReserveNextWorkQueueTaskKey reserveNextWorkQueueTaskKey)
    throws AppException, InformationalException {

    // Inbox service layer object
    curam.core.sl.intf.Inbox inboxObj = InboxFactory.newInstance();

    // create return object
    ReserveNextTaskDetails reserveNextTaskDetails = new ReserveNextTaskDetails();

    reserveNextWorkQueueTaskKey.reserveTaskKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // reserve next work queue task
    reserveNextTaskDetails.reserveTaskDetails = inboxObj.reserveNextTaskFromPreferredOrgUnit(
      reserveNextWorkQueueTaskKey.reserveTaskKey);

    // return reserved task details
    return reserveNextTaskDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void manageAvailableTaskResults(AvailableTaskSearchCriteria criteria)
    throws AppException, InformationalException {
    // Only store the query criteria information if the search button has been
    // pressed
    if (criteria.actionIDProperty.equals(ClientActionConst.kSave_Query)) {
      SearchTaskUtilities.storeAvailableTaskSearch(criteria);
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setInboxOptionsUserPreferences(
    InboxUserPreferenceDetails preferences)
    throws AppException, InformationalException {
    InboxFactory.newInstance().setInboxOptionsUserPreferences(preferences);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListAssignedTaskDetails listAssigned(ListTaskKey listTaskKey)
    throws AppException, InformationalException {

    // Create a Inbox object
    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    // List Assigned Details- details to be returned
    curam.core.facade.struct.ListAssignedTaskDetails listAssignedTaskDetails = new curam.core.facade.struct.ListAssignedTaskDetails();

    listTaskKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // call the service Layer method
    listAssignedTaskDetails.taskDetailsList = inboxObj.listAssigned(
      listTaskKey.taskListKey);

    // get the context Description
    listAssignedTaskDetails.inboxContextDescription = readContextDescription(
      listTaskKey);

    // Return the details
    return listAssignedTaskDetails;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LimitedListDeferredTaskDetails listLimitedDeferredTasks()
    throws AppException, InformationalException {

    // Inbox business process object
    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    // Create return object
    LimitedListDeferredTaskDetails listDeferredTaskDetails = new LimitedListDeferredTaskDetails();

    ListTaskKey listTaskKey = new ListTaskKey();

    listTaskKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // Get the list of deferred tasks
    listDeferredTaskDetails.taskDetailsList = inboxObj.listLimitedDeferredTasks(
      listTaskKey.taskListKey, inboxObj.getInboxTaskReadMultiDetails());

    listDeferredTaskDetails.inboxContextDescription = readContextDescription(
      listTaskKey);

    // Obtain the informational(s) to be returned to the client
    String[] warnings = TransactionInfo.getInformationalManager().obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMsgDtls infoMsgDtls = new InformationalMsgDtls();

      infoMsgDtls.informationMsgTxt = warnings[i];
      listDeferredTaskDetails.informationalMsgDetailsList.dtls.addRef(
        infoMsgDtls);
    }

    // Return the details
    return listDeferredTaskDetails;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LimitedListReservedTaskDetails listLimitedReservedTasks()
    throws AppException, InformationalException {

    ListReservedByStatusKey key = new ListReservedByStatusKey();

    key.taskListKey.userName = TransactionInfo.getProgramUser();
    key.taskListKey.statusCode = curam.codetable.TASKSTATUS.NOTSTARTED;

    return listLimitedReservedTasksByStatus(key);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListReservedByPriorityDetails listReservedByPriority(
    ListReservedByPriorityKey listReservedByPriorityKey) throws AppException,
      InformationalException {

    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    ListReservedByPriorityDetails listReservedByPriorityDetails = new ListReservedByPriorityDetails();

    ListTaskKey listTaskKey = new ListTaskKey();

    listReservedByPriorityKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    listReservedByPriorityDetails.taskDetailsList = inboxObj.listReservedByPriority(
      listReservedByPriorityKey.taskListKey);

    listTaskKey.taskListKey.userName = listReservedByPriorityKey.taskListKey.userName;

    listReservedByPriorityDetails.inboxContextDescription = readContextDescription(
      listTaskKey);

    return listReservedByPriorityDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LimitedListReservedTaskDetails listLimitedReservedTasksByStatus(
    ListReservedByStatusKey listReservedByStatusKey) throws AppException,
      InformationalException {

    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();
    LimitedListReservedTaskDetails listReservedTaskDetails = new LimitedListReservedTaskDetails();

    curam.core.sl.struct.UserNameAndStatusKey userNameAndStatusKey = new curam.core.sl.struct.UserNameAndStatusKey();

    ListTaskKey listTaskKey = new ListTaskKey();

    listReservedByStatusKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    userNameAndStatusKey.userName = listReservedByStatusKey.taskListKey.userName;
    userNameAndStatusKey.statusCode = listReservedByStatusKey.taskListKey.statusCode;

    listReservedTaskDetails.taskDetailsList = inboxObj.listLimitedReservedTasksByStatus(
      userNameAndStatusKey, inboxObj.getInboxTaskReadMultiDetails());

    listTaskKey.taskListKey.userName = listReservedByStatusKey.taskListKey.userName;

    listReservedTaskDetails.inboxContextDescription = readContextDescription(
      listTaskKey);

    // Obtain the informational(s) to be returned to the client
    String[] warnings = TransactionInfo.getInformationalManager().obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMsgDtls infoMsgDtls = new InformationalMsgDtls();

      infoMsgDtls.informationMsgTxt = warnings[i];
      listReservedTaskDetails.informationalMsgDetailsList.dtls.addRef(
        infoMsgDtls);
    }
    return listReservedTaskDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListReservedDueOnDateDetails listReservedDueOnDate(
    ListReservedKey listReservedKey) throws AppException,
      InformationalException {

    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    ListReservedDueOnDateDetails listReservedDueOnDateDetails = new ListReservedDueOnDateDetails();

    ListTaskKey listTaskKey = new ListTaskKey();

    listReservedKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    listReservedDueOnDateDetails.taskDetailsList = inboxObj.listReservedDueOnDate(
      listReservedKey.taskListKey);

    listTaskKey.taskListKey.userName = listReservedKey.taskListKey.userName;

    listReservedDueOnDateDetails.inboxContextDescription = readContextDescription(
      listTaskKey);

    return listReservedDueOnDateDetails;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListReservedDueOnOrBeforeDateDetails listReservedDueOnOrBeforeDate(
    ListReservedKey listReservedKey) throws AppException,
      InformationalException {

    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    ListReservedDueOnOrBeforeDateDetails listReservedDueOnOrBeforeDateDetails = new ListReservedDueOnOrBeforeDateDetails();

    ListTaskKey listTaskKey = new ListTaskKey();

    listReservedKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    listReservedDueOnOrBeforeDateDetails.taskDetailsList = inboxObj.listReservedDueOnOrBeforeDate(
      listReservedKey.taskListKey);

    listTaskKey.taskListKey.userName = listReservedKey.taskListKey.userName;

    listReservedDueOnOrBeforeDateDetails.inboxContextDescription = readContextDescription(
      listTaskKey);

    return listReservedDueOnOrBeforeDateDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public LimitedListWorkQueueUnreservedTasksDetails listLimitedUnreservedWorkQueueTasks(ListWorkQueueUnreservedTasksKey key)
    throws AppException, InformationalException {

    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    LimitedListWorkQueueUnreservedTasksDetails returnList = new LimitedListWorkQueueUnreservedTasksDetails();

    returnList.dtls = inboxObj.listLimitedUnreservedWorkQueueTasks(key.key,
      inboxObj.getInboxTaskReadMultiDetails());

    // Obtain the informational(s) to be returned to the client
    String[] warnings = TransactionInfo.getInformationalManager().obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMsgDtls infoMsgDtls = new InformationalMsgDtls();

      infoMsgDtls.informationMsgTxt = warnings[i];
      returnList.informationalMsgDetailsList.dtls.addRef(infoMsgDtls);
    }

    return returnList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public TaskQueryResultDetailsList listAvailableTasks()
    throws AppException, InformationalException {
    // Inbox service layer object
    curam.core.sl.intf.Inbox inboxObj = InboxFactory.newInstance();

    TaskQueryResultDetailsList tasks = inboxObj.listAvailableTasks(
      inboxObj.getInboxTaskReadMultiDetails());

    // Obtain the informational(s) to be returned to the client
    String[] warnings = TransactionInfo.getInformationalManager().obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMsgDtls infoMsgDtls = new InformationalMsgDtls();

      infoMsgDtls.informationMsgTxt = warnings[i];
      tasks.informationalMsgDetailsList.dtls.addRef(infoMsgDtls);
    }

    return tasks;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public TaskQueryResultDetailsList searchForTasks(TaskQueryKey key)
    throws AppException, InformationalException {

    TaskQueryResultDetailsList resultList = new TaskQueryResultDetailsList();

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    resultList = inboxObj.searchTask(key,
      inboxObj.getInboxTaskReadMultiDetails());

    informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      resultList.informationalMsgDetailsList.dtls.addRef(informationalMsgDtls);

    }
    return resultList;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public AvailableTaskSearchResult searchAvailableTasks()
    throws AppException, InformationalException {

    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    return inboxObj.searchAvailableTasks(
      inboxObj.getInboxTaskReadMultiDetails());
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListUserOrgObjectWorkQueueDetails searchWorkQueues(
    ListTaskKey listTaskKey)
    throws AppException, InformationalException {

    // Call the Inbox service layer object
    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    // Create return object
    ListUserOrgObjectWorkQueueDetails listUserWorkQueueDetails = new ListUserOrgObjectWorkQueueDetails();

    listTaskKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    listUserWorkQueueDetails.workQueueDetailsList = inboxObj.searchWorkQueues(
      listTaskKey.taskListKey);

    return listUserWorkQueueDetails;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public ListWorkQueueNameDtls searchWorkQueueName(ListTaskKey listTaskKey)
    throws AppException, InformationalException {

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    String[] warnings = informationalManager.obtainInformationalAsString();

    // Inbox service layer object
    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    // create return object
    ListWorkQueueNameDtls listWorkQueueNameDetails = new ListWorkQueueNameDtls();

    listTaskKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // read subscribed work queue details list
    listWorkQueueNameDetails.workQueueDetailsList = inboxObj.searchWorkQueueName(
      listTaskKey.taskListKey);

    informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      listWorkQueueNameDetails.informationalMsgDetailsList.dtls.addRef(
        informationalMsgDtls);

    }

    // return subscribed work queue details list
    return listWorkQueueNameDetails;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public InboxContextDescription readContextDescription(ListTaskKey listTaskKey)
    throws AppException, InformationalException {

    InboxContextDescription inboxContextDescription = new InboxContextDescription();

    UserAccess userAccessObj = UserAccessFactory.newInstance();
    UserFullname userFullname;
    UsersKey usersKey = new UsersKey();

    // BEGIN, CR00161962, KY
    // Populating username with Transaction user if it is not passed through key
    if (listTaskKey.taskListKey.userName != null
      && !(listTaskKey.taskListKey.userName).equals(CuramConst.gkEmpty)) {
      usersKey.userName = listTaskKey.taskListKey.userName;
    } else {
      usersKey.userName = TransactionInfo.getProgramUser();
    }
    // END, CR00161962

    userFullname = userAccessObj.getFullName(usersKey);

    inboxContextDescription.userFullName = userFullname.fullname;

    // return the details
    return inboxContextDescription;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public InboxOptionsSummaryDetails viewInboxOptionsSummaryForUser()
    throws AppException, InformationalException {
    return InboxFactory.newInstance().viewInboxOptionsSummaryForUser();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public InboxOptionsPreferencesDetails getInboxOptionsUserPreferences()
    throws AppException, InformationalException {
    return InboxFactory.newInstance().getInboxOptionsUserPreferences();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public TaskRedirectionSecurity getTaskRedirectionAndBlockingSecurity()
    throws AppException, InformationalException {
    return InboxFactory.newInstance().getTaskRedirectionAndBlockingSecurity();
  }
  
  /**
   * Returns a list of the task details that have been deferred by the current 
   * user.
   *
   * @param listTaskKey The details of this struct are not used as the current 
   * user is used in the method call.
   *
   * @return A list of task details that have been deferred by the current user.
   *
   * @deprecated Since 6.0, this method has been replaced by 
   * {@link #listLimitedDeferredTasks(ListTaskKey)}. The new method limits the 
   * number of tasks returned. See Release Note CR00233124.
   */
  @Override
  @Deprecated
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  public curam.core.facade.struct.ListDeferredTaskDetails listDeferred(
    ListTaskKey listTaskKey) throws AppException, InformationalException {

    // Inbox business process object
    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    // Create return object
    curam.core.facade.struct.ListDeferredTaskDetails listDeferredTaskDetails = new curam.core.facade.struct.ListDeferredTaskDetails();

    listTaskKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // Get the list of deferred tasks
    listDeferredTaskDetails.taskDetailsList = inboxObj.listDeferred(
      listTaskKey.taskListKey);

    listDeferredTaskDetails.inboxContextDescription = readContextDescription(
      listTaskKey);

    // Return the details
    return listDeferredTaskDetails;

  }

  /**
   * Returns a list of the open tasks that are reserved by the current user.
   *
   * @param listTaskKey The name of the current user.
   *
   * @return A list of the open tasks that are reserved by the current user.
   * @deprecated Since 6.0, this method has been replaced by 
   * {@link #listLimitedReservedTasks(ListTaskKey)}. The new method limits 
   * the number of tasks returned. See Release Note CR00233124.
   */
  @Override
  @Deprecated
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  public curam.core.facade.struct.ListReservedTaskDetails listReserved(
    ListTaskKey listTaskKey) throws AppException, InformationalException {

    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    curam.core.sl.struct.UserNameAndStatusKey userNameAndStatusKey = new curam.core.sl.struct.UserNameAndStatusKey();

    curam.core.facade.struct.ListReservedTaskDetails listReservedTaskDetails = new curam.core.facade.struct.ListReservedTaskDetails();

    listTaskKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    userNameAndStatusKey.userName = listTaskKey.taskListKey.userName;
    userNameAndStatusKey.statusCode = curam.codetable.TASKSTATUS.NOTSTARTED;

    listReservedTaskDetails.taskDetailsList = inboxObj.listReservedByStatus(
      userNameAndStatusKey);

    listReservedTaskDetails.inboxContextDescription = readContextDescription(
      listTaskKey);

    return listReservedTaskDetails;
  }

  /**
   * Returns a list of all the tasks that are reserved by the current user and 
   * filtered by task status (e.g. Open or Deferred).
   * <P>
   * The number of tasks that returned may be limited. This may be changed by 
   * altering the 
   * {@link curam.core.impl.EnvVars#ENV_INBOX_MAX_TASK_LIST_SIZE ENV_INBOX_MAX_TASK_LIST_SIZE} 
   * application property. The default is 100. If the number of records exceeds
   * the specified maximum value then an informational message is returned
   * ({@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED INF_READMULTI_MAX_EXCEEDED}) 
   * informing the user that more records exist.
   * <P>
   * By default the returned tasks are ordered deadline time in ascending 
   * order using the sort class 
   * {@link curam.core.sl.impl.TaskSortByDeadlineAscending TaskSortByDeadlineAscending}. 
   * The sort order can be changed by using Guice to bind 
   * {@link curam.core.sl.impl.TaskSort TaskSort} to another sort class.
   *
   * @param listReservedByStatusKey The task status used to filter the 
   * search results.
   *
   * @return A list of all the tasks that are reserved by the current user and 
   * filtered by task status.
   *
   * @deprecated Since 6.0, this method has been replaced by 
   * {@link #listLimitedReservedTasksByStatus(ListTaskKey)}. The new method 
   * limits the number of tasks returned. See Release Note CR00233124.
   */
  @Override
  @Deprecated
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  public curam.core.facade.struct.ListReservedTaskDetails listReservedByStatus(
    ListReservedByStatusKey listReservedByStatusKey) throws AppException,
      InformationalException {

    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();
    curam.core.facade.struct.ListReservedTaskDetails listReservedTaskDetails = new curam.core.facade.struct.ListReservedTaskDetails();

    curam.core.sl.struct.UserNameAndStatusKey userNameAndStatusKey = new curam.core.sl.struct.UserNameAndStatusKey();

    ListTaskKey listTaskKey = new ListTaskKey();

    listReservedByStatusKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    userNameAndStatusKey.userName = listReservedByStatusKey.taskListKey.userName;
    userNameAndStatusKey.statusCode = listReservedByStatusKey.taskListKey.statusCode;

    listReservedTaskDetails.taskDetailsList = inboxObj.listReservedByStatus(
      userNameAndStatusKey);

    listTaskKey.taskListKey.userName = listReservedByStatusKey.taskListKey.userName;

    listReservedTaskDetails.inboxContextDescription = readContextDescription(
      listTaskKey);

    return listReservedTaskDetails;
  }

  /**
   * Returns a list of all the work queues that the current user is 
   * subscribed to.
   * @param listTaskKey The name of the user.
   *
   * @return A list of all the work queues that the current user is 
   * subscribed to.
   *
   * @deprecated Since Curam 6.0 , replaced with 
   * {@link Inbox#searchWorkQueues(ListTaskKey)}. In addition to the current 
   * functionality, the new method return 
   * struct core.facade.struct.ListUserWorkQueueDtls aggregates 
   * core.sl.struct.ListUserWorkQueueDtls which further aggregates struct
   * core.entity.struct.ListUserWorkQueueDtls, and this struct contains 
   * all the fields of ListUserWorkQueueDetails along with  workQueueName, 
   * subscriberID, subscriberName  and subscriberType. Also, the return struct 
   * core.sl.struct.ListUserWorkQueueDtls  contains WorkQueues subscribed by 
   * the user as well as that are subscribed by the user's organization objects.
   * See release note : CR00226437.
   */
  @Override
  @Deprecated
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  public curam.core.facade.struct.ListUserWorkQueueDetails listWorkQueue(
    ListTaskKey listTaskKey)
    throws AppException, InformationalException {

    // Call the Inbox service layer object
    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    // Create return object
    curam.core.facade.struct.ListUserWorkQueueDetails listUserWorkQueueDetails = new curam.core.facade.struct.ListUserWorkQueueDetails();

    listTaskKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    listUserWorkQueueDetails.workQueueDetailsList = inboxObj.listWorkQueue(
      listTaskKey.taskListKey);

    return listUserWorkQueueDetails;

  }

  /**
   * Returns a list of work queue names and identifiers currently subscribed 
   * by the current user.
   *
   * @param listTaskKey The user name.
   *
   * @return A list of work queue names and identifiers currently subscribed 
   * by the current user.
   *
   * @deprecated Since Curam 6.0 , replaced with 
   * {@link WorkQueue#searchWorkQueueName(ListTaskKey)}. In addition to the 
   * current functionality, the new method return struct 
   * curam.core.facade.struct.ListWorkQueueNameDtls aggregates 
   * curam.core.sl.struct.WorkQueueNameDtlsList, which aggregates struct 
   * curam.core.sl.entity.struct.CurrentUserWorkQueueAndSubscriberDetails, and 
   * this struct contains all the fields of CurrentUserWorkQueueDetails along 
   * with subscriberID, subscriberName, subscriberType, pageTitle and 
   * unsubscribePageText. See release note CR00226714.
   */
  @Override
  @Deprecated
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  public curam.core.facade.struct.ListWorkQueueNameDetails listWorkQueueName(
    ListTaskKey listTaskKey)
    throws AppException, InformationalException {

    // create return object
    curam.core.facade.struct.ListWorkQueueNameDetails listWorkQueueNameDetails = new curam.core.facade.struct.ListWorkQueueNameDetails();

    ListWorkQueueNameDtls listWQNameDtls = searchWorkQueueName(listTaskKey);

    curam.core.sl.struct.WorkQueueNameDtlsList workQueueDtlsList = listWQNameDtls.workQueueDetailsList;

    CurrentUserWorkQueueAndSubscriberDetailsList currentUserWQDetailsList = workQueueDtlsList.workQueueDetailsList;

    curam.core.sl.entity.struct.CurrentUserWorkQueueDetailsList currentUserWQDtlsList = new curam.core.sl.entity.struct.CurrentUserWorkQueueDetailsList();

    final Iterator<CurrentUserWorkQueueAndSubscriberDetails> itr = currentUserWQDetailsList.dtls.iterator();

    while (itr.hasNext()) {
      curam.core.sl.entity.struct.CurrentUserWorkQueueAndSubscriberDetails wqsubsDetails = itr.next();

      curam.core.sl.entity.struct.CurrentUserWorkQueueDetails currentWQDetails = new curam.core.sl.entity.struct.CurrentUserWorkQueueDetails();

      currentWQDetails.subscriptionDateTime = wqsubsDetails.subscriptionDateTime;
      currentWQDetails.workQueueName = wqsubsDetails.workQueueName;
      currentWQDetails.workQueueID = wqsubsDetails.workQueueID;
      currentUserWQDtlsList.dtls.add(currentWQDetails);
    }
    curam.core.sl.struct.WorkQueueNameDetailsList workQueueDetailsList = new curam.core.sl.struct.WorkQueueNameDetailsList();

    workQueueDetailsList.workQueueDetailsList = currentUserWQDtlsList;
    listWorkQueueNameDetails.workQueueDetailsList = workQueueDetailsList;

    // return subscribed work queue details list
    return listWorkQueueNameDetails;

  }

  /**
   * Returns a list of all the task details that are unreserved and assigned 
   * to a specified work queue.
   * <P>
   * The number of tasks that returned may be limited. This may be changed by 
   * altering the 
   * {@link curam.core.impl.EnvVars#ENV_INBOX_MAX_TASK_LIST_SIZE ENV_INBOX_MAX_TASK_LIST_SIZE} 
   * application property. The default is 100. If the number of records exceeds
   * the specified maximum value then an informational message is returned 
   * ({@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED INF_READMULTI_MAX_EXCEEDED}) 
   * informing the user that more records exist.
   * <P>
   * By default the returned tasks are ordered deadline time in ascending order
   * using the sort class 
   * {@link curam.core.sl.impl.TaskSortByDeadlineAscending TaskSortByDeadlineAscending}. 
   * The sort order can be changed by using Guice to bind 
   * {@link curam.core.sl.impl.TaskSort TaskSort} to another sort class.
   *
   * @param key The unique identifier of the work queues whose unreserved 
   * task details will be returned.
   *
   * @return A list of all the task details that are unreserved and assigned 
   * to a specified work queue.
   *
   * @deprecated Since Curam 6.0, this method has been replaced by 
   * {@link #listlimitedUnreservedWorkQueueTasks(ListWorkQueueUnreservedTasksKey)}. 
   * The new method limits the number of tasks returned. 
   * See Release Note CR00233124.
   */
  @Override
  @Deprecated
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  public curam.core.facade.struct.ListWorkQueueUnreservedTasksDetails listUnreservedWorkQueueTasks(ListWorkQueueUnreservedTasksKey key)
    throws AppException, InformationalException {

    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    curam.core.facade.struct.ListWorkQueueUnreservedTasksDetails listWorkQueueUnreservedTaskDetails = new curam.core.facade.struct.ListWorkQueueUnreservedTasksDetails();

    listWorkQueueUnreservedTaskDetails.dtls = inboxObj.listUnreservedWorkQueueTasks(
      key.key);

    return listWorkQueueUnreservedTaskDetails;
  }
  
  /**
   * Returns the details displayed on the 5.2 version of the Inbox home page. 
   * This includes the details regarding the users current workload 
   * (e.g. graph of tasks by status, priority and due date).
   *
   * @return The workload details of the user.
   *
   * @deprecated Since Curam 6.0, this method is no longer referenced in the 
   * Inbox. See release note CR00233124.
   */
  @Override
  @Deprecated
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  public ViewUserInboxDetails viewUserInbox(ViewUserInboxKey viewUserInboxKey)
    throws AppException, InformationalException {

    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();
    ViewUserInboxDetails viewUserInboxDetails = new ViewUserInboxDetails();
    ListTaskKey listTaskKey = new ListTaskKey();

    viewUserInboxKey.viewInboxKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    viewUserInboxDetails.viewInboxDetails = inboxObj.viewUserInbox(
      viewUserInboxKey.viewInboxKey);

    listTaskKey.taskListKey.userName = viewUserInboxKey.viewInboxKey.userName;

    viewUserInboxDetails.inboxContextDescription = readContextDescription(
      listTaskKey);

    return viewUserInboxDetails;
  }

  /**
   * Returns a list of task details based on a task identifier, case identifier
   * or participant identifier.
   *
   * @param key The search criteria.
   *
   * @return A list of task details based on the search criteria.
   *
   * @deprecated Since Curam 6.0. This method is replaced by 
   * {@link #searchForTasks(TaskQueryKey) which allows the user to search for 
   * tasks using many more search parameters. However it does not provide 
   * functionality to search using case ID or participant ID.
   */
  @Override
  @Deprecated
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  public ListSearchTaskDetails searchTask(
    curam.core.facade.struct.SearchTaskKey key)
    throws AppException, InformationalException {

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    curam.core.facade.struct.ListTaskKey listTaskKey = new curam.core.facade.struct.ListTaskKey();

    // Obtain the informational(s) to be returned to the client
    String[] matchedResults = informationalManager.obtainInformationalAsString();

    // Inbox service layer object
    curam.core.sl.intf.Inbox inboxObj = curam.core.sl.fact.InboxFactory.newInstance();

    // List Task Details- details to be returned
    curam.core.sl.struct.SearchTaskDetailsList searchTaskDetailsList = new curam.core.sl.struct.SearchTaskDetailsList();

    // Create return object
    curam.core.facade.struct.ListSearchTaskDetails listSearchTaskDetails = new curam.core.facade.struct.ListSearchTaskDetails();

    // Service layer method key
    curam.core.sl.struct.SearchTaskKey searchTaskKey = new curam.core.sl.struct.SearchTaskKey();

    searchTaskKey.taskID = key.taskFindKey.taskID;
    searchTaskKey.caseID = key.taskFindKey.caseID;
    searchTaskKey.participantRoleID = key.taskFindKey.participantRoleID;

    searchTaskDetailsList = inboxObj.searchTask(searchTaskKey);

    listSearchTaskDetails.taskDetailsList.assign(searchTaskDetailsList);

    informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // Obtain the informational(s) to be returned to the client
    matchedResults = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < matchedResults.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = matchedResults[i];
      listSearchTaskDetails.informationalMsgDetailsList.dtls.addRef(
        informationalMsgDtls);

    }
    listTaskKey.taskListKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    // get the context Description
    listSearchTaskDetails.inboxContextDescription = readContextDescription(
      listTaskKey);

    return listSearchTaskDetails;
  }
}
