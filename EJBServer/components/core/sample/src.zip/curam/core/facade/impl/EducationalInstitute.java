/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.codetable.INFORMATIONPROVIDERTYPE;
import curam.core.facade.fact.InformationProviderFactory;
import curam.core.facade.intf.InformationProvider;
import curam.core.facade.struct.EducationalInstituteModifyDetails;
import curam.core.facade.struct.EducationalInstituteRegistrationDetails;
import curam.core.facade.struct.EducationalInstituteViewDetails;
import curam.core.facade.struct.InformationProviderRegistrationResult;
import curam.core.facade.struct.ModifyInformationProviderReturnDetails;
import curam.core.facade.struct.ParticipantSearchDetails;
import curam.core.facade.struct.ParticipantSearchResult;
import curam.core.facade.struct.ReadInformationProviderDetails;
import curam.core.facade.struct.ReadInformationProviderDetailsKey;
import curam.core.facade.struct.ReadInformationProviderHomeKey;
import curam.core.fact.ConcernFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.intf.Concern;
import curam.core.intf.ConcernRole;
import curam.core.sl.fact.EducationalInstituteFactory;
import curam.core.sl.fact.ParticipantSearchRouterFactory;
import curam.core.sl.intf.ParticipantSearchRouter;
import curam.core.sl.struct.EducationalInstituteHomeDetails;
import curam.core.sl.struct.EducationalInstituteSearchKey;
import curam.core.sl.struct.EducationalInstituteSearchResult;
import curam.core.struct.ConcernDtls;
import curam.core.struct.ConcernKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.InformationalMsgDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;
import curam.core.fact.ConcernFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.intf.Concern;
import curam.core.intf.ConcernRole;
import curam.core.struct.ConcernDtls;
import curam.core.struct.ConcernKey;
import curam.core.struct.ConcernRoleDtls;


public class EducationalInstitute extends curam.core.facade.base.EducationalInstitute {

  /**
   * @param key
   * of type EducationalInstituteSearchKey
   * @return InformationProviderSearchDetails
   *
   * @throws AppException
   * Application Exception
   * @throws InformationalException
   * Informational Exception
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}
   *
   * This method searches the Educational Institution with respect to the
   * criteria entered by the user.
   */
  @Deprecated
  public EducationalInstituteSearchResult search(
    EducationalInstituteSearchKey key) throws AppException,
      InformationalException {

    EducationalInstituteSearchResult educationalInstituteSearchResultObj = new EducationalInstituteSearchResult();
    curam.core.sl.struct.EducationalInstituteSearchKey keySL = new curam.core.sl.struct.EducationalInstituteSearchKey();

    keySL.assign(key);
    curam.core.sl.intf.EducationalInstitute educationalInstituteObj = EducationalInstituteFactory.newInstance();

    educationalInstituteSearchResultObj = educationalInstituteObj.search(keySL);
    return educationalInstituteSearchResultObj;
  }

  /**
   * Reads information required to display on the Educational Institute Home
   * page. The details are captured from 2 places 1. Information Provider
   * details through InformationProvider API & 2. Educational Institute details
   *
   * @param concernRoleKey - concernRoleID of the Educational Institute.
   * @return Educational Institute Home Details
   *
   * @throws AppException Application Exception
   * @throws InformationalException Informational Exception
   */
  public curam.core.facade.struct.EducationalInstituteHomeDetails readEducationalInstituteHomePageDetails(
    ConcernRoleKey concernRoleKey) throws AppException, InformationalException {

    curam.core.facade.struct.EducationalInstituteHomeDetails educationalInstituteHomeDetailsFL = new curam.core.facade.struct.EducationalInstituteHomeDetails();
    InformationProvider informationProvider = InformationProviderFactory.newInstance();
    ReadInformationProviderHomeKey readInformationProviderHomeKey = new ReadInformationProviderHomeKey();
    curam.core.sl.intf.EducationalInstitute educationalInstitute = EducationalInstituteFactory.newInstance();

    // Educational Institute details
    EducationalInstituteHomeDetails educationalInstituteHomeDetails = educationalInstitute.readEducationalInstituteHomePageDetails(
      concernRoleKey);

    educationalInstituteHomeDetailsFL.assign(educationalInstituteHomeDetails);

    // Information Provider details
    readInformationProviderHomeKey.concernRoleHomePageKey.concernRoleID = concernRoleKey.concernRoleID;
    educationalInstituteHomeDetailsFL.completeDetails.assign(
      informationProvider.readHomePageDetails(readInformationProviderHomeKey));

    return educationalInstituteHomeDetailsFL;
  }

  /**
   * This method is used to register an EducationalInstitute.
   *
   * @param details
   * of type EducationalInstituteRegistrationDetails
   *
   * @return Educational Institute Registration ID Details
   *
   * @throws AppException
   * Application Exception
   * @throws InformationalException
   * Informational Exception
   */
  public InformationProviderRegistrationResult registerEducationalInstitute(
    EducationalInstituteRegistrationDetails details) throws AppException,
      InformationalException {

    InformationProviderRegistrationResult informationProviderRegistrationResult = new InformationProviderRegistrationResult();
    InformationProvider informationProviderObj = InformationProviderFactory.newInstance();

    details.infoProviderRegDetails.infoProvRegistrationDetails.type = INFORMATIONPROVIDERTYPE.EDUINSTITUTE;
    informationProviderRegistrationResult = informationProviderObj.register(
      details.infoProviderRegDetails);

    curam.core.sl.struct.EducationalInstituteRegistrationDetails educationalInstituteRegistrationDetailsSL = new curam.core.sl.struct.EducationalInstituteRegistrationDetails();

    educationalInstituteRegistrationDetailsSL.assign(details);
    educationalInstituteRegistrationDetailsSL.concernRoleID = informationProviderRegistrationResult.registrationIDDetails.concernRoleID;
    curam.core.sl.intf.EducationalInstitute maintainEducationalInstituteObj = EducationalInstituteFactory.newInstance();

    maintainEducationalInstituteObj.registerEducationalInstitute(
      educationalInstituteRegistrationDetailsSL);

    return informationProviderRegistrationResult;
  }

  /**
   * This method modifies an EducationalInstitute.
   *
   * @param details
   * of type EducationalInstituteModifyDetails
   * @return ModifyInformationProviderReturnDetails
   * @throws AppException
   * Application Exception
   * @throws InformationalException
   * Informational Exception
   */
  public ModifyInformationProviderReturnDetails modifyEducationalInstitute(
    EducationalInstituteModifyDetails details) throws AppException,
      InformationalException {

    InformationProvider informationProviderObj = InformationProviderFactory.newInstance();

    details.infoProvDetails.infoProviderDetails.typeCode = INFORMATIONPROVIDERTYPE.EDUINSTITUTE;
    ModifyInformationProviderReturnDetails modifyInformationProviderReturnDetails = informationProviderObj.modifyInformationProviderDetails(
      details.infoProvDetails);

    curam.core.sl.struct.EducationalInstituteModifyDetails educationalInstituteModifyDetailsSL = new curam.core.sl.struct.EducationalInstituteModifyDetails();

    educationalInstituteModifyDetailsSL.assign(details);
    educationalInstituteModifyDetailsSL.concernRoleID = details.infoProvDetails.infoProviderDetails.concernRoleID;
    educationalInstituteModifyDetailsSL.endDate = details.infoProvDetails.infoProviderDetails.endDate;
    educationalInstituteModifyDetailsSL.statusCode = details.infoProvDetails.infoProviderDetails.statusCode;
    curam.core.sl.intf.EducationalInstitute maintainEducationalInstituteObj = EducationalInstituteFactory.newInstance();
    // BEGIN, CR00321187, AC
    final ConcernKey concernKey = new ConcernKey();
    final Concern concernObj = ConcernFactory.newInstance();
    
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.infoProvDetails.infoProviderDetails.concernRoleID;
    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
  
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(concernRoleKey, true);

    concernKey.concernID = concernRoleDtls.concernID;

    final ConcernDtls concernDtls = concernObj.read(concernKey);

    concernDtls.name = details.infoProvDetails.infoProviderDetails.name;
    concernObj.modify(concernKey, concernDtls);
    // END, CR00321187
    maintainEducationalInstituteObj.modifyEducationalInstitute(
      educationalInstituteModifyDetailsSL);

    return modifyInformationProviderReturnDetails;
  }

  /**
   * This method reads details of an EducationalInstitute to modify
   *
   * @param key
   * of type ConcernRoleKey
   * @return EducationalInstituteViewDetails
   * @throws AppException
   * Application Exception
   * @throws InformationalException
   * Informational Exception
   */
  public EducationalInstituteViewDetails readEducationalInstituteToModify(
    ConcernRoleKey key) throws AppException, InformationalException {
    InformationProvider informationProviderObj = InformationProviderFactory.newInstance();
    ReadInformationProviderDetailsKey readInformationProviderDetailsKey = new ReadInformationProviderDetailsKey();

    readInformationProviderDetailsKey.maintainConcernRoleKey.concernRoleID = key.concernRoleID;
    ReadInformationProviderDetails readInformationProviderDetails = informationProviderObj.readInformationProviderDetails(
      readInformationProviderDetailsKey);

    EducationalInstituteViewDetails educationalInstituteViewDetails = new EducationalInstituteViewDetails();
    curam.core.sl.intf.EducationalInstitute maintainEducationalInstituteObj = EducationalInstituteFactory.newInstance();
    curam.core.sl.struct.EducationalInstituteViewDetails educationalInstituteViewDetailsSL = maintainEducationalInstituteObj.readEducationalInstituteToModify(
      key);

    educationalInstituteViewDetails.assign(educationalInstituteViewDetailsSL);
    educationalInstituteViewDetails.infoPrivDetails.assign(
      readInformationProviderDetails);
    return educationalInstituteViewDetails;
  }

  // BEGIN, CR00218851, ZV
  // BEGIN, CR00290965, IBM
  /**
   * Searches for an Educational Institute by specified search criteria.
   *
   * @param key Education institute search criteria
   *
   * @return Educational institute details found
   *
   * @throws AppException Application Exception
   * @throws InformationalException Informational Exception
   *
   * @deprecated Since Curam 6.0 SP2, replaced with 
   * {@link EducationalInstitute#searchEducationalInstitute(EducationalInstituteSearchKey)}
   *
   * This method is deprecated as informational messages are not returned. 
   * This method is replaced by searchEducationalInstitute(EducationalInstituteSearchKey) 
   * which returns the informational message along with educational institute details as well. 
   * See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantSearchResult search1(
    curam.core.facade.struct.EducationalInstituteSearchKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    ParticipantSearchRouter participantSearchRouterObj = ParticipantSearchRouterFactory.newInstance();

    ParticipantSearchResult participantSearchResult = new ParticipantSearchResult();

    key.key.key.educationalInstituteInd = true;
    key.key.key.subtype = key.type;

    participantSearchResult.dtls = participantSearchRouterObj.search(
      key.key.key);

    return participantSearchResult;
  }

  // END, CR00218851

  // BEGIN, CR00290965, IBM
  /**
   * Searches for an educational institute details by specified search criteria.
   *
   * @param educationalInstituteSearchKey contains education institute search criteria
   *
   * @return educational institute details
   *
   * @throws AppException Application Exception
   * @throws InformationalException Informational Exception
   */
  public ParticipantSearchDetails searchEducationalInstitute(
    final curam.core.facade.struct.EducationalInstituteSearchKey 
    educationalInstituteSearchKey) throws AppException, InformationalException {
    
    ParticipantSearchRouter participantSearchRouter = ParticipantSearchRouterFactory.newInstance();

    ParticipantSearchDetails participantSearchDetails = new ParticipantSearchDetails();

    educationalInstituteSearchKey.key.key.educationalInstituteInd = true;
    educationalInstituteSearchKey.key.key.subtype = educationalInstituteSearchKey.type;

    participantSearchDetails.dtls = participantSearchRouter.search(
      educationalInstituteSearchKey.key.key);
    
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    String[] infos = informationalManager.obtainInformationalAsString();

    for (String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      participantSearchDetails.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }
    
    return participantSearchDetails;
  }
  // END, CR00290965
}
