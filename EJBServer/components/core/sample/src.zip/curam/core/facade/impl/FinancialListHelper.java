/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2009, 2013
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office 
 */

/*
 * Copyright 2009-2013 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import java.util.Comparator;
import java.util.Iterator;

import curam.codetable.FINANCIALINSTRUCTION;
import curam.codetable.FININSTRUCTIONSTATUS;
import curam.codetable.ILISTATUS;
import curam.codetable.ILITYPE;
import curam.codetable.METHODOFDELIVERY;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.PaymentInstructionFactory;
import curam.core.fact.PaymentInstrumentFactory;
import curam.core.fact.PaymentRegenerationRequestFactory;
import curam.core.fact.ViewConcernAccountFactory;
import curam.core.fact.WMInstanceDataFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DP_const;
import curam.core.intf.InstructionLineItem;
import curam.core.sl.struct.BooleanResult;
import curam.core.struct.AccountInstructionIdentifier;
import curam.core.struct.ConcernAccAdjustedItemsDetail;
import curam.core.struct.FinInstructionID;
import curam.core.struct.FinancialInstructionDetails;
import curam.core.struct.FinancialInstructionRegeneratedCount;
import curam.core.struct.ILIFinInstructID;
import curam.core.struct.InstructionLineItemDtls;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.PaymentInstructionDtls;
import curam.core.struct.PaymentInstructionKey;
import curam.core.struct.PaymentInstrumentDtls;
import curam.core.struct.PaymentInstrumentKey;
import curam.core.struct.RegeneratedFinancialInstructionIDKey;
import curam.core.struct.WMInstanceDataDtls;
import curam.core.struct.WMInstanceDataDtlsList;
import curam.core.struct.WMInstanceDataSearchByCaseIDIn;
import curam.message.GENERAL;
import curam.message.GENERALFINANCE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.fact.DeferredProcessingFactory;
import curam.util.struct.ProcessInfoDetails;
import curam.util.struct.ProcessNameKey;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * Helper class that provides operations to help construct the xml for the
 * financial list widget.
 *
 */
public class FinancialListHelper extends curam.core.facade.base.FinancialListHelper {

  // BEGIN, CR00184135, MC
  // ___________________________________________________________________________
  /**
   * Comparator used to order the instructions by due date
   */
  public class DueDateComparator implements Comparator<Object> {

    public DueDateComparator() {
      super();
    }

    public int compare(final Object o1, final Object o2) {

      FinancialInstructionDetails struct1 = (FinancialInstructionDetails) o1;
      FinancialInstructionDetails struct2 = (FinancialInstructionDetails) o2;

      return struct1.dueDate.compareTo(struct2.dueDate);
    }
  }
  // END, CR00184135

  // BEGIN, CR00219579, MC
  // ___________________________________________________________________________
  /**
   * Sets indicators required to display only the actions that are appropriate
   * to the current state of the instruction.
   *
   * @param details The financial instruction details.
   *
   * @return The list of instruction to be displayed with the display
   * indicators set.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public FinancialInstructionDetails setListRowActionDisplayIndicators(
    final FinancialInstructionDetails details)
    throws AppException, InformationalException {

    boolean alreadyRegenerated = true;

    String instructionStatusCode = details.statusCode;

    // BEGIN, CR00327227, KH
    // This applies to all payments except refunds
    if (details.typeCode.equals(FINANCIALINSTRUCTION.PAYMENT)
      && !details.instructionLineItemType.equals(ILITYPE.REFUND)) {
      // END, CR00327227
      
      /*
       * If the payment has already been reissued do not display the
       * reissue button.
       */
      alreadyRegenerated = paymentReissued(details).booleanResult;

      // Has the cancelled payment been invalidated?
      FinInstructionID finInstructionID = new FinInstructionID();

      finInstructionID.finInstructionID = details.finInstructionID;

      PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();

      paymentInstrumentKey.pmtInstrumentID = PaymentInstructionFactory.newInstance().readByFinInstructionID(finInstructionID).pmtInstrumentID;

      if (instructionStatusCode.equals(FININSTRUCTIONSTATUS.CANCELLED)) {

        details.displayIndicators.cancelInd = false;
        details.displayIndicators.invalidateInd = false;
        details.displayIndicators.approveInd = false;

        boolean invalidatedInd = PaymentInstrumentFactory.newInstance().readInvalidatedInd(paymentInstrumentKey).invalidatedInd;

        if (!invalidatedInd) {
          // Allow the user to invalidate the payment
          details.displayIndicators.invalidateInd = true;
        }

        if (alreadyRegenerated || invalidatedInd) {
          details.displayIndicators.reissueInd = false;          
          // BEGIN, CR00369134, KRK
          details.displayIndicators.reissueDeductionIndOpt = false;
          // END, CR00369134
          details.displayIndicators.cancelInd = false;
        } else {
          details.displayIndicators.reissueInd = true;
          // BEGIN, CR00369134, KRK
          details.displayIndicators.reissueDeductionIndOpt = true;
          // END, CR00369134
        }
        
        // BEGIN, CR00358036, GA
        // Third party payments cannot be invalidated. Disable the indicator for third party payments.       
        PaymentInstructionDtls paymentInstructionDtls = PaymentInstructionFactory.newInstance().readByFinInstructionID(
          finInstructionID);

        paymentInstrumentKey = new PaymentInstrumentKey();

        paymentInstrumentKey.pmtInstrumentID = paymentInstructionDtls.pmtInstrumentID;

        PaymentInstrumentDtls paymentInstrumentDtls = PaymentInstrumentFactory.newInstance().read(
          paymentInstrumentKey);

        if (0 == paymentInstrumentDtls.caseNomineeID) {
          details.displayIndicators.invalidateInd = false;
          // BEGIN, CR00369134, KRK
          details.displayIndicators.reissueDeductionIndOpt = false;
          // END, CR00369134
        }
        // END, CR00358036

      } else if (instructionStatusCode.equals(FININSTRUCTIONSTATUS.SUSPENDED)) {        
        // BEGIN, CR00369134, KRK
        details.displayIndicators.reissueDeductionIndOpt = false;
        // END, CR00369134
        details.displayIndicators.reissueInd = false;
        details.displayIndicators.approveInd = true;
        details.displayIndicators.cancelInd = true;

      } else if (instructionStatusCode.equals(FININSTRUCTIONSTATUS.CREATED)
        || instructionStatusCode.equals(FININSTRUCTIONSTATUS.ISSUED)
        || instructionStatusCode.equals(FININSTRUCTIONSTATUS.PROCESSED)) {
        details.displayIndicators.reissueInd = false;
        // BEGIN, CR00369134, KRK
        details.displayIndicators.reissueDeductionIndOpt = false;
        // END, CR00369134
        details.displayIndicators.approveInd = false;
        details.displayIndicators.cancelInd = true;

      } // BEGIN, CR00317416, CSH
      else if (instructionStatusCode.equals(FININSTRUCTIONSTATUS.REVERSED)
        || instructionStatusCode.equals(FININSTRUCTIONSTATUS.EXPIRED)) {
        details.displayIndicators.reissueInd = false;
        // BEGIN, CR00369134, KRK
        details.displayIndicators.reissueDeductionIndOpt = false;
        // END, CR00369134
        details.displayIndicators.approveInd = false;
        details.displayIndicators.cancelInd = false;
        details.displayIndicators.reverseInd = false;
      }
      
    } else if ((details.typeCode.equals(FINANCIALINSTRUCTION.WRITEOFF)
      || details.typeCode.equals(FINANCIALINSTRUCTION.PAYMENTRECEIVED)
      || details.typeCode.equals(FINANCIALINSTRUCTION.LIABILITY))
        && !details.statusCode.equals(FININSTRUCTIONSTATUS.REVERSED)) {
        
      details.displayIndicators.reverseInd = true;
    }
    // END, CR00317416
    
    // BEGIN, CR00327227, KH
    /*
     * If the refund has not been reversed enable this action. This is the
     * only list action that applies to a refund payment.
     */
    if (details.instructionLineItemType.equals(ILITYPE.REFUND)
      && !details.statusCode.equals(FININSTRUCTIONSTATUS.REVERSED)) {
      details.displayIndicators.reverseInd = true;
    }
    // END, CR00327227
      
    if (details.deliveryMethodType.equals(METHODOFDELIVERY.CASH)) {
      // A cash payment/ payment received cannot be cancelled.
      details.displayIndicators.cancelInd = false;
      details.displayIndicators.reverseInd = false;
    }

    // BEGIN, CR00328565, CSH 
    // If the instruction is for a payment received then check if there are
    // any related instruction line items that have an unprocessed amount.
    if (details.typeCode.equals(FINANCIALINSTRUCTION.PAYMENTRECEIVED)) {
      
      // Read the instructionLineItem entity
      ILIFinInstructID pmtRecvILIFinInstructID = new ILIFinInstructID();
      InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();

      // Instruction line items details list
      InstructionLineItemDtlsList relatedIliDtlsList;

      // Set the key to read Instruction Line Item
      pmtRecvILIFinInstructID.finInstructionID = details.finInstructionID;
      relatedIliDtlsList = instructionLineItemObj.searchByFinInstructID(
        pmtRecvILIFinInstructID); 
      for (int k = 0; k < relatedIliDtlsList.dtls.size(); k++) {

        // We only want to populate the instructionLineItemID if there is 
        // an unprocessed amount that can be allocated or refunded.
        // There should only be one such item.
        if (relatedIliDtlsList.dtls.item(k).unprocessedAmount.isPositive()) {

          details.instructionLineItemID = relatedIliDtlsList.dtls.item(k).instructLineItemID;
          details.unprocessedAmount = relatedIliDtlsList.dtls.item(k).unprocessedAmount;
          
          // If there is an unprocessed amount then set indicators allowing 
          // the allocate or refund actions to be enabled
          details.displayIndicators.allocateInd = true;
          details.displayIndicators.refundInd = true;
          break;
        }
      }
    }
    // END, CR00328565

    return details;
  }

  // ___________________________________________________________________________
  /**
   * Set the field that will display the type and status of the instructions.
   * For example the type of a reissued payment will display as
   * Payment (Reissued).
   *
   * @param details The financial instruction details.
   *
   * @return The list row item with the type field set.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public FinancialInstructionDetails setTypeStatus(
    final FinancialInstructionDetails details)
    throws AppException, InformationalException {

    LocalisableString typeStatus = new LocalisableString(
      GENERAL.INF_GENERAL_CODETABLE_BRACKETS);

    String instructionType = CodeTable.getOneItem(
      FINANCIALINSTRUCTION.TABLENAME, details.typeCode,
      TransactionInfo.getProgramLocale());

    String statusCode = CuramConst.gkEmpty;

    if (!details.statusCode.equals(FININSTRUCTIONSTATUS.CREATED)
      && !details.statusCode.equals(FININSTRUCTIONSTATUS.ISSUED)) {

      statusCode = CodeTable.getOneItem(FININSTRUCTIONSTATUS.TABLENAME,
        details.statusCode, TransactionInfo.getProgramLocale());
    }

    if (details.typeCode.equals(FINANCIALINSTRUCTION.LIABILITY)
      && details.statusCode.equals(FININSTRUCTIONSTATUS.ISSUED)) {

      // Check if the ILI(s) associated with the liability are reversed.
      ILIFinInstructID liabilityILIFinInstructID = new ILIFinInstructID();

      liabilityILIFinInstructID.finInstructionID = details.finInstructionID;

      // read instructionLineItem
      InstructionLineItemDtlsList iliDtlsList = InstructionLineItemFactory.newInstance().searchByFinInstructID(
        liabilityILIFinInstructID);

      for (int i = 0; i < iliDtlsList.dtls.size(); i++) {
        if (iliDtlsList.dtls.item(i).statusCode.equals(ILISTATUS.REVERSED)) {

          // Display Liability (Reversed)
          statusCode = CodeTable.getOneItem(ILISTATUS.TABLENAME,
            ILISTATUS.REVERSED, TransactionInfo.getProgramLocale());
          break;
        }
      }

    } else if (details.typeCode.equals(FINANCIALINSTRUCTION.PAYMENT)) {

      // Check if this is a reissued payment
      if (details.statusCode.equals(FININSTRUCTIONSTATUS.ISSUED)) {

        if (paymentReissued(details).booleanResult) {

          // Display Payment (Reissued)
          statusCode = GENERALFINANCE.INF_REISSUED.getMessageText();
        }
      }

      if (details.instructionLineItemType.equals(
        ILITYPE.MANUALPAYMENTOVERPAYMENT)) {

        // Display Manual Payment (status)
        instructionType = GENERALFINANCE.INF_MANUAL_PAYMENT.getMessageText();
      }
      // BEGIN, CR00385373, MR
      final ILIFinInstructID liabilityILIFinInstructID = new ILIFinInstructID();

      liabilityILIFinInstructID.finInstructionID = details.finInstructionID;

      final InstructionLineItemDtlsList iliDtlsList = InstructionLineItemFactory.newInstance().searchByFinInstructID(
        liabilityILIFinInstructID);
      final WMInstanceDataSearchByCaseIDIn wmInstanceDataSearchByCaseIDIn = new WMInstanceDataSearchByCaseIDIn();
      long wmID = 0;

      for (InstructionLineItemDtls iliDtls : iliDtlsList.dtls) {
        wmInstanceDataSearchByCaseIDIn.caseID = iliDtls.caseID;
        WMInstanceDataDtlsList wmInstanceDataDtlsList = WMInstanceDataFactory.newInstance().searchByCaseID(
          wmInstanceDataSearchByCaseIDIn);
        Iterator iter = wmInstanceDataDtlsList.dtls.iterator();

        while (iter.hasNext()) {
          WMInstanceDataDtls element = (WMInstanceDataDtls) iter.next();

          if (element.paymentDate.equals(iliDtls.effectiveDate)
            && element.financialInstructionID == iliDtls.finInstructionID) {
            wmID = element.wm_instDataID;

            final ProcessNameKey dpProcessByApiKey = new ProcessNameKey();

            dpProcessByApiKey.instDataID = wmID;
            dpProcessByApiKey.processName = DP_const.DP_MANUAL_PAYMENT_ALLOCATION;

            final ProcessInfoDetails dpProcessInfoDetails = DeferredProcessingFactory.newInstance().getDeferredProcessInfo(
              dpProcessByApiKey);

            if (dpProcessInfoDetails.processName.equals(
              dpProcessByApiKey.processName)) {
              instructionType = GENERALFINANCE.INF_MANUAL_PAYMENT.getMessageText();
            }
          }
        }
      }
      // END, CR00385373


      if (details.statusCode.equals(FININSTRUCTIONSTATUS.CANCELLED)) {

        PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();
        FinInstructionID finInstructionID = new FinInstructionID();

        // Get the related payment instruction key
        finInstructionID.finInstructionID = details.finInstructionID;
        paymentInstrumentKey.pmtInstrumentID = PaymentInstructionFactory.newInstance().readByFinInstructionID(finInstructionID).pmtInstrumentID;

        if (PaymentInstrumentFactory.newInstance().readInvalidatedInd(paymentInstrumentKey).invalidatedInd) {

          // Display Payment (Cancelled and invalidated)
          String canceledInvalidated = CodeTable.getOneItem(
            FININSTRUCTIONSTATUS.TABLENAME, details.statusCode,
            TransactionInfo.getProgramLocale())
              + CuramConst.gkSpace
              + GENERAL.INF_INVALIDATED.getMessageText(
                TransactionInfo.getProgramLocale());

          statusCode = canceledInvalidated;
        }
      }
    } // BEGIN, CR00289420, PMD
    else if (details.typeCode.equals(FINANCIALINSTRUCTION.PAYMENTRECEIVED)) {

      if (details.instructionLineItemType.equals(ILITYPE.DEDUCTIONPAYMENT)) {
        instructionType = GENERALFINANCE.INF_DEDUCTION.getMessageText();
      }

      if (details.statusCode.equals(FININSTRUCTIONSTATUS.REVERSED)) {
        statusCode = CodeTable.getOneItem(ILISTATUS.TABLENAME,
          ILISTATUS.REVERSED, TransactionInfo.getProgramLocale());
      }
      // END, CR00289420
    } else if (details.typeCode.equals(FINANCIALINSTRUCTION.ADJUSTMENT)) {

      // Display Credit or Debit as the status of the adjustment
      AccountInstructionIdentifier accountInstructionIdentifier = new AccountInstructionIdentifier();

      accountInstructionIdentifier.finInstructionID = details.finInstructionID;

      // Only one ILI is created for each adjustment
      ConcernAccAdjustedItemsDetail concernAccAdjustedItemsDetail = ViewConcernAccountFactory.newInstance().viewAdjustmentInstructionDetail(accountInstructionIdentifier).adjustedItemsList.dtls.item(
        0);

      if (concernAccAdjustedItemsDetail.creditAmount.isZero()) {
        statusCode = GENERALFINANCE.INF_DEBIT.getMessageText(
          TransactionInfo.getProgramLocale());
      } else {
        statusCode = GENERALFINANCE.INF_CREDIT.getMessageText(
          TransactionInfo.getProgramLocale());
      }
    } // Display "Liability Write Off" for Write Offs
    else if (details.typeCode.equals(FINANCIALINSTRUCTION.WRITEOFF)) {
      instructionType = GENERALFINANCE.INF_LIABILITY_WRITE_OFF.getMessageText(
        TransactionInfo.getProgramLocale());

      if (details.statusCode.equals(FININSTRUCTIONSTATUS.REVERSED)) {

        statusCode = CodeTable.getOneItem(ILISTATUS.TABLENAME,
          ILISTATUS.REVERSED, TransactionInfo.getProgramLocale());
      }
    }
    
    if (statusCode.length() > 0) {

      typeStatus.arg(instructionType);
      typeStatus.arg(statusCode);

      details.typeStatus = typeStatus.getMessage();
    } else {
      details.typeStatus = instructionType;
    }

    return details;
  }

  // END, CR00219579

  // ___________________________________________________________________________
  /**
   * Search to see if this instruction has been previously regenerated.
   *
   * @param details The financial instruction details.
   *
   * @return a boolean to state that the payment has been reissued.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature. 
   */
  public BooleanResult paymentReissued(
    final FinancialInstructionDetails details)
    throws AppException, InformationalException {

    BooleanResult booleanResult = new BooleanResult();

    if (details.statusCode.equals(FININSTRUCTIONSTATUS.CANCELLED)) {

      // PaymentRegenerationRequest manipulation variables
      PaymentInstructionKey pmtInstructionKey = new PaymentInstructionKey();
      FinInstructionID finInstructionID = new FinInstructionID();

      finInstructionID.finInstructionID = details.finInstructionID;

      // Set key to search for existing payment regeneration requests
      pmtInstructionKey.pmtInstructionID = PaymentInstructionFactory.newInstance().readByFinInstructionID(finInstructionID).pmtInstructionID;

      try {
        PaymentRegenerationRequestFactory.newInstance().readByPmtInstructionID(
          pmtInstructionKey);
        booleanResult.booleanResult = true;
        return booleanResult;
      } catch (RecordNotFoundException e) {
        // No payment regeneration request found
        booleanResult.booleanResult = false;
        return booleanResult;
      }
    } else {

      RegeneratedFinancialInstructionIDKey regeneratedKey = new RegeneratedFinancialInstructionIDKey();

      regeneratedKey.finInstructionID = details.finInstructionID;
      FinancialInstructionRegeneratedCount regeneratedCount = PaymentRegenerationRequestFactory.newInstance().countRegeneratedByFinInstructID(
        regeneratedKey);

      if (regeneratedCount.regeneratedCount > 0) {
        booleanResult.booleanResult = true;
        return booleanResult;
      }
    }
    booleanResult.booleanResult = false;
    return booleanResult;
  }
}
