/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.core.facade.struct.CreateModifyOrRunCaseQueryDtls;
import curam.core.sl.entity.struct.QueryDetails;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.struct.CancelQueryDetails;
import curam.core.sl.struct.CaseQueryKey;
import curam.core.sl.struct.ListCaseQueriesForUserResult;
import curam.core.sl.struct.RunCaseQueryResult;
import curam.core.sl.struct.createModifyCaseQueryResult;
import curam.message.BPOQUERY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This process class provides the functionality for the Prospect Person
 * presentation layer.
 */
public abstract class Query extends curam.core.facade.base.Query {

  // _________________________________________________________________________
  /**
   * @param details The case search criteria for a query.
   *
   * @return List of cases that match the query and the query id.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.facade.impl.CaseQuery#createOrRun()} and
   * {@link curam.core.facade.impl.CaseQuery#modify()} 
   *
   * This method creates, modifies or runs a case search query.
   *
   * If the client action was save and a non zero queryID was supplied,
   * then that query record will be modified, otherwise it will be created.
   * If the client action was run, the query will be executed and the results
   * returned.
   */
  @Deprecated
  public createModifyCaseQueryResult createModifyOrRunCaseQuery(CreateModifyOrRunCaseQueryDtls details)
    throws AppException, InformationalException {

    // Query sl object
    curam.core.sl.intf.Query queryObj = curam.core.sl.fact.QueryFactory.newInstance();

    createModifyCaseQueryResult result = new createModifyCaseQueryResult();

    if ((details.actionIDProperty.equals(ClientActionConst.kSave_Query)) || (
      details.actionIDProperty.equals(ClientActionConst.kSave_Query_From_List))) {

      if (details.searchCriteria.queryName.length() == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOQUERY.ERR_QUERY_FV_NAME_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
      result = queryObj.createModifyCaseQuery(details.searchCriteria);
    } else if (details.actionIDProperty.equals(ClientActionConst.kRun_Query)) {
      result.list = queryObj.runCaseQuery(details.searchCriteria).list;
    } else {
      AppException e = new AppException(BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 9);
    }

    return result;
  }

  // _________________________________________________________________________
  /**
   * @param details The case search criteria for a query.
   *
   * @return List of cases that match the query and the query id.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by 
   * {@link curam.core.facade.impl.CaseQuery#createOrRun()} and
   * {@link curam.core.facade.impl.CaseQuery#modify()} 
   *
   * This method creates or modifies a search query for a case worker. If the
   * details contain a non zero queryID then that query record will be modified,
   * otherwise it will be created.
   */
  @Deprecated
  public createModifyCaseQueryResult createModifyCaseQuery(QueryDetails details)
    throws AppException, InformationalException {

    // Query sl object
    curam.core.sl.intf.Query queryObj = curam.core.sl.fact.QueryFactory.newInstance();

    createModifyCaseQueryResult createModifyCaseQueryResult = queryObj.createModifyCaseQuery(
      details);

    return createModifyCaseQueryResult;
  }

  // _________________________________________________________________________
  /**
   * @return List of web addresses for both original and duplicate
   * participants
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.facade.impl.CaseQuery#listForUser()}.
   *
   * This method searches case queries for the logged on user.
   */
  @Deprecated
  public ListCaseQueriesForUserResult listCaseQueriesForUser()
    throws AppException, InformationalException {

    // Query sl object
    curam.core.sl.intf.Query queryObj = curam.core.sl.fact.QueryFactory.newInstance();

    ListCaseQueriesForUserResult listCaseQueriesForUserResult = queryObj.listCaseQueriesForUser();

    return listCaseQueriesForUserResult;
  }

  // _________________________________________________________________________
  /**
   * @param key - The case search criteria for a query.
   *
   * @return List of web addresses for both original and duplicate
   * participants
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.facade.impl.CaseQuery#listAndRun()}. 
   *
   * This method runs a query and return a list of cases.
   */
  @Deprecated
  public RunCaseQueryResult runCaseQuery(CaseQueryKey key)
    throws AppException, InformationalException {

    // Query sl object
    curam.core.sl.intf.Query queryObj = curam.core.sl.fact.QueryFactory.newInstance();

    RunCaseQueryResult runCaseQueryResult = queryObj.runSavedCaseQuery(key);

    runCaseQueryResult.numberOfRecords = runCaseQueryResult.list.searchDtls.size();

    return runCaseQueryResult;
  }

  // _________________________________________________________________________
  /**
   * @param key The modified case search criteria for a query.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #deleteQuery1()}.
   *
   * Used when a user wants to delete a stored case query.
   */
  @Deprecated
  public void deleteQuery(CaseQueryKey key) throws AppException, InformationalException {
    // Query sl object
    curam.core.sl.intf.Query queryObj = curam.core.sl.fact.QueryFactory.newInstance();

    queryObj.delete(key);

  }
  
  // BEGIN, CR00202673, ZV
  // _________________________________________________________________________
  /**
   * Deletes stored case query.
   *
   * @param details contains query id and version no.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void deleteQuery1(CancelQueryDetails details)
    throws AppException, InformationalException {

    curam.core.sl.intf.Query queryObj = curam.core.sl.fact.QueryFactory.newInstance();

    queryObj.delete1(details);
  }
  // END, CR00202673

}
