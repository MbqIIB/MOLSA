/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2002, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.CONCERNROLETYPE;
import curam.core.facade.struct.ModifyUtilityDetails;
import curam.core.facade.struct.ModifyUtilityReturnDetails;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ParticipantContextDetails;
import curam.core.facade.struct.ParticipantSearchDetails;
import curam.core.facade.struct.ParticipantSearchResult;
import curam.core.facade.struct.ReadUtilityDetails;
import curam.core.facade.struct.ReadUtilityDetailsKey;
import curam.core.facade.struct.ReadUtilityHomeKey;
import curam.core.facade.struct.UtilityRegistrationWithTextBankAccountSortCodeDetails;
import curam.core.facade.struct.ReadUtilityHomePageDetails;
import curam.core.facade.struct.SearchDetails;
import curam.core.facade.struct.SearchKey;
import curam.core.facade.struct.UtilityRegistrationResult;
import curam.core.facade.struct.UtilitySearchKey;
import curam.core.sl.fact.ParticipantSearchRouterFactory;
import curam.core.sl.intf.ParticipantSearchRouter;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.UtilityDetails;
import curam.core.struct.UtilityHomePageReadResult;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for the Utility presentation
 * layer.
 *
 */
public abstract class Utility extends curam.core.facade.base.Utility {

  // ___________________________________________________________________________
  /**
   * Read a Utilities home page details
   *
   * @param key utility identifier
   *
   * @return utility homepage details
   */
  public ReadUtilityHomePageDetails readHomePageDetails(ReadUtilityHomeKey key)
    throws AppException, InformationalException {

    // Utility homepage maintenance object
    curam.core.intf.UtilityHomePage utilityHomePageObj = curam.core.fact.UtilityHomePageFactory.newInstance();

    // Concern role details maintenance object
    curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();

    // Details to be returned
    ReadUtilityHomePageDetails readUtilityHomePageDetails = new ReadUtilityHomePageDetails();

    // Read the utility homepage details
    UtilityHomePageReadResult utilityHomePageReadResult = utilityHomePageObj.read(
      key.concernRoleHomePageKey);

    // Read the concern role details
    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    maintainConcernRoleKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;
    UtilityDetails utilityDetails = maintainConcernRoleDetailsObj.readUtility(
      maintainConcernRoleKey);

    // Assign details to the return object
    readUtilityHomePageDetails.utilityHomeDetails.assign(
      utilityHomePageReadResult.utilityHomePageDetails);
    readUtilityHomePageDetails.utilityHomeDetails.assign(utilityDetails);
    readUtilityHomePageDetails.informationalMsgDtlsList.assign(
      utilityHomePageReadResult.informationalMsgDtlsList);

    // Context object and key
    curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    // Populate context description key
    participantContextDescriptionKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    // Read the context description
    readUtilityHomePageDetails.participantContextDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Return details
    return readUtilityHomePageDetails;
  }

  // BEGIN, CR00231961, ZV
  // ___________________________________________________________________________
  /**
   * Register a utility
   *
   * @param details details of the utility to be registered
   *
   * @return details from the operation
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link #registerWithTextBankAccountSortCode()}. 
   * See release note: CR00231961
   */
  @Deprecated
  public UtilityRegistrationResult register(
    curam.core.facade.struct.UtilityRegistrationDetails details)
    throws AppException, InformationalException {
    
    UtilityRegistrationWithTextBankAccountSortCodeDetails utilityRegistrationDetails = new UtilityRegistrationWithTextBankAccountSortCodeDetails();
    
    utilityRegistrationDetails.utilityRegistrationDetails.assign(
      details.utilityRegistrationDetails);
    utilityRegistrationDetails.bankSortCode = details.utilityRegistrationDetails.bankSortCode;

    return registerWithTextBankAccountSortCode(utilityRegistrationDetails);
  }

  // END, CR00231961

  // ___________________________________________________________________________
  /**
   * @param key utility search key
   *
   * @return Utility/Utilities found
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}
   *
   * Searches for a utility record using specified search criteria
   */
  @Deprecated
  public SearchDetails search(SearchKey key) throws AppException, InformationalException {

    // Utility search object
    curam.core.intf.UtilitySearchRouter utilitySearchRouterObj = curam.core.fact.UtilitySearchRouterFactory.newInstance();

    // Details to be returned
    SearchDetails searchDetails = new SearchDetails();

    // Search for Utility
    searchDetails.utilitySearchResult = utilitySearchRouterObj.search(
      key.utilitySearchKey);

    // Return details
    return searchDetails;
  }

  // ___________________________________________________________________________
  /**
   * Updates a utility with modified details.
   *
   * @param details Utility details
   *
   * @return return details
   */
  public ModifyUtilityReturnDetails modifyUtilityDetails(ModifyUtilityDetails details)
    throws AppException, InformationalException {

    // Get instance of maintenance object
    curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();

    // The details to be returned
    ModifyUtilityReturnDetails modifyUtilityReturnDetails = new ModifyUtilityReturnDetails();

    // Create a key for modification
    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    maintainConcernRoleKey.concernRoleID = details.utilityDetails.concernRoleID;

    // Modify the utility details
    maintainConcernRoleDetailsObj.modifyUtility(maintainConcernRoleKey,
      details.utilityDetails);

    // BEGIN, CR00016578, SPD
    // Create an informational manager
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];

      modifyUtilityReturnDetails.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00016578

    // Return the details
    return modifyUtilityReturnDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves details of the specified utility.
   *
   * @param key Utility key
   *
   * @return Utility Details
   */
  public ReadUtilityDetails readUtilityDetails(ReadUtilityDetailsKey key)
    throws AppException, InformationalException {

    // Get instance of maintenance object
    curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();

    // Get instance of context maintenance object
    curam.core.facade.intf.ParticipantContext participantContextObj = curam.core.facade.fact.ParticipantContextFactory.newInstance();

    // The details to be returned
    ReadUtilityDetails readUtilityDetails = new ReadUtilityDetails();

    // Read the utility details
    readUtilityDetails.utilityDetails = maintainConcernRoleDetailsObj.readUtility(
      key.maintainConcernRoleKey);

    // Read the context details
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.maintainConcernRoleKey.concernRoleID;
    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    participantContextDetails.participantContextDescriptionDetails = participantContextObj.readContextDescription(
      participantContextDescriptionKey);

    // Assign the context details to the returning object
    readUtilityDetails.participantContextDetails = participantContextDetails;

    // Return the object
    return readUtilityDetails;

  }

  // BEGIN, CR00218851, ZV
  // BEGIN, CR00290965, IBM
  /**
   * Searches for an Utility by specified search criteria.
   *
   * @param key Utility search criteria
   *
   * @return Utility details found
   *
   * @throws InformationalException Informational Exception
   *
   * @throws AppException Application Exception
   * @deprecated Since Curam 6.0 SP2, replaced with {@link 
   * Utility#searchUtility(UtilitySearchKey)}
   *
   * This method is deprecated as informational messages are not returned. This 
   * method is replaced by searchUtility(UtilitySearchKey) which returns the 
   * informational message along with utility details as well. 
   * See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public ParticipantSearchResult search1(UtilitySearchKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    ParticipantSearchRouter participantSearchRouterObj = ParticipantSearchRouterFactory.newInstance();

    ParticipantSearchResult participantSearchResult = new ParticipantSearchResult();

    key.key.key.concernRoleType = CONCERNROLETYPE.UTILITY;
    key.key.key.subtype = key.type;

    participantSearchResult.dtls = participantSearchRouterObj.search(
      key.key.key);

    return participantSearchResult;
  }

  // END, CR00218851

  // BEGIN, CR00231961, ZV
  // ___________________________________________________________________________
  /**
   * Register a utility
   *
   * @param details details of the utility to be registered
   *
   * @return details from the operation
   */
  public UtilityRegistrationResult registerWithTextBankAccountSortCode(
    final UtilityRegistrationWithTextBankAccountSortCodeDetails details)
    throws AppException, InformationalException {

    curam.core.intf.UtilityRegistration utilityRegistrationObj = curam.core.fact.UtilityRegistrationFactory.newInstance();

    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Read concern ID from ConcernRole, if necessary
    if (details.utilityRegistrationDetails.relatedConcernRoleID != 0) {
      concernRoleKey.concernRoleID = details.utilityRegistrationDetails.relatedConcernRoleID;
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      details.utilityRegistrationDetails.concernID = concernRoleDtls.concernID;
    }

    UtilityRegistrationResult utilityRegistrationResult = new UtilityRegistrationResult();
    
    details.utilityRegistrationDetails.bankSortCode = details.bankSortCode;
    // BEGIN, CR00371769, VT
    details.utilityRegistrationDetails.bicOpt = details.bicOpt;
    // END, CR00371769

    utilityRegistrationResult.registrationIDDetails = utilityRegistrationObj.registerUtility(
      details.utilityRegistrationDetails);

    return utilityRegistrationResult;
  }

  // END, CR00231961

  // BEGIN, CR00290965, IBM
  /**
   * Searches for an Utility by specified search criteria.
   *
   * @param utilitySearchKey contains utility search key
   *
   * @return participant search details
   *
   * @throws InformationalException Informational Exception
   * @throws AppException Application Exception
   */
  public ParticipantSearchDetails searchUtility(final UtilitySearchKey utilitySearchKey)
    throws AppException, InformationalException {
    
    ParticipantSearchRouter participantSearchRouter = ParticipantSearchRouterFactory.newInstance();

    ParticipantSearchDetails participantSearchDetails = new ParticipantSearchDetails();

    utilitySearchKey.key.key.concernRoleType = CONCERNROLETYPE.UTILITY;
    utilitySearchKey.key.key.subtype = utilitySearchKey.type;

    participantSearchDetails.dtls = participantSearchRouter.search(
      utilitySearchKey.key.key);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    String[] infos = informationalManager.obtainInformationalAsString();

    for (String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      participantSearchDetails.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }
    
    return participantSearchDetails;
  }
  // END, CR00290965
}
