/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright (c) 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;

import curam.core.sl.fact.IncidentTabFactory;
import curam.core.sl.struct.IncidentTabDetails;
import curam.incident.entity.struct.IncidentKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Facade Class for the Incidents Tab details panel.
 */
public abstract class IncidentTab extends curam.core.facade.base.IncidentTab {
  
  // ___________________________________________________________________________
  /**
   * Reads the Incident tab display details.
   *
   * @param key Key of incident to be read
   *
   * @return Incident tab display details
   */
  public IncidentTabDetails readIncidentTabDetails(IncidentKey key)
    throws AppException, InformationalException {

    return  IncidentTabFactory.newInstance().readIncidentTabDetails(key);
  }

  
  
}

