/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.core.sl.entity.struct.QueryKey;
import curam.core.sl.entity.struct.SearchByUserNameAndTypeDetails1List;
import curam.core.sl.fact.InboxFactory;
import curam.core.sl.fact.TaskQueryFactory;
import curam.core.sl.infrastructure.impl.ClientActionConst;
import curam.core.sl.struct.ReadMultiOperationDetails;
import curam.core.sl.struct.TaskQueryDetails;
import curam.core.sl.struct.TaskQueryResult;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.OrganisationObjectDetailsList;
import curam.message.BPOQUERY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.resources.GeneralConstants;
import curam.util.transaction.TransactionInfo;


/**
 * This class provides the functionality for Task Queries. A user can list,
 * create, save, run and delete their personal task queries.
 * <P>
 * The user can create a task query using the following search criteria:
 * <ul>
 * <li>My Tasks List Only: Returns only those tasks reserved by the user</li>
 * <li>Assigned To: Returns tasks assigned to a particular user, job, position, 
 * organization unit or work queue</li>
 * <li>Business Object Type: Returns tasks related to a particular business 
 * object e.g. Person or Case</li>
 * <li>Status: Returns tasks based on their status e.g. Open, Closed etc.</li>
 * <li>Category: Returns tasks based on their category</li>
 * <li>Deadline From Date: Returns tasks with a deadline greater or equal to 
 * this date</li>
 * <li>Deadline To Date: Returns tasks with a deadline less than or equal to 
 * this date</li>
 * <li>Deadline Due: A code table which returns tasks that have a deadline that
 * is one of the following: Overdue, Due today, Due this week, Due this month, 
 * Due after this month</li>
 * <li>Creation From Date: Returns tasks with a creation time greater or equal 
 * to this date</li>
 * <li>Creation To Date: Returns tasks with a creation time less than or equal 
 * to this date</li>
 * <li>Creation Last Number Of Days: Returns tasks created in the specified last
 * number of days</li>
 * <li>Creation Last Number Of Weeks: Returns tasks created in the specified 
 * last number of weeks</li>
 * <li>Restart From Date: Returns tasks with a restart date greater or equal 
 * to this date</li>
 * <li>Restart To Date: Returns tasks with a restart date less than or equal to 
 * this date</li>
 * </ul>
 * <P>
 * The task query search criteria is subject to a number of validations:
 * <ul>
 * <li>A query name uniquely identifying the query must be supplied</li>
 * <li>A query name must not already exist in the users previously stored task 
 * queries</li> 
 * <li>The deadline due field must be blank if either the deadline from or to 
 * date fields are filled.</li>
 * <li>The creation from and to date fields must be blank if either the last 
 * number of days or last number of weeks fields are filled</li>
 * <li>The creation time last number of days field must be blank if the last 
 * number of weeks field is filled</li>
 * <li>Creation from date must be before creation to date</li>
 * <li>Restart from date must be before restart to date</li>
 * <li>Deadline from date must be before deadline to date</li>
 * </ul>
 */

public abstract class TaskQuery extends curam.core.facade.base.TaskQuery {

  // ____________________________________________________________________________
  /**
   * This method lists the currently logged on user's task queries. The list is 
   * ordered by the number of times the query is run.
   *
   * @return A list of task queries for the logged on user.
   */
  public SearchByUserNameAndTypeDetails1List list() throws AppException,
      InformationalException {
    
    curam.core.sl.intf.TaskQuery taskQueryObj = TaskQueryFactory.newInstance();

    return taskQueryObj.list();

  }

  // ____________________________________________________________________________
  /**
   * This method creates or runs a task query.
   *
   * If the client action was save then the query will be created. If the
   * client action was run, the query will be executed and the results returned.
   *
   * This method limits the number of tasks that are returned to the client. 
   * The limit is governed by the {@link 
   * curam.core.impl.EnvVars#ENV_INBOX_MAX_TASK_LIST_SIZE 
   * ENV_INBOX_MAX_TASK_LIST_SIZE} environment variable. If the number of 
   * records exceed this maximum value then an information message is displayed
   * ({@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED
   * INF_READMULTI_MAX_EXCEEDED}) informing the user that more records exist.
   *
   * @param details The criteria for a task query.
   *
   * @return If validation succeeds and the client action was run then a list 
   * of tasks that satisfy the specified query's criteria is returned. If 
   * validation succeeds and the client action was save then the newly created 
   * query ID is returned. If validation fails then the validation messages
   * are returned in an informational exception.
   */
  public TaskQueryResult createOrRunQuery(TaskQueryDetails details)
    throws AppException, InformationalException {

    // The reason the method has dual functionality is because it is called from 
    // the submit action in a UIM page. Submit actions can only be associated 
    // with a single facade method.
    
    curam.core.sl.intf.TaskQuery taskQuery = TaskQueryFactory.newInstance();

    TaskQueryResult result = new TaskQueryResult();

    if (details.actionIDProperty.equals(ClientActionConst.kSave_Query)) {
      result = taskQuery.create(details);
    } else if (details.actionIDProperty.equals(ClientActionConst.kRun_Query)) {
      ReadMultiOperationDetails readMulti = InboxFactory.newInstance().getInboxTaskReadMultiDetails();

      result = taskQuery.run(details, readMulti);
    } else {
      AppException e = new AppException(BPOQUERY.ERR_QUERY_FV_UNKNOWN_ACTION);

      e.arg(details.actionIDProperty);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    
    InformationalManager infoMgr = TransactionInfo.getInformationalManager();
    // Obtain the informational(s) to be returned to the client
    String[] warnings = infoMgr.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      result.resultList.informationalMsgDetailsList.dtls.addRef(
        informationalMsgDtls);
    }

    return result;
  }

  // ____________________________________________________________________________
  /**
   * This method runs a task query from the database. This method limits the 
   * number of tasks that are returned to the client. The limit is governed by 
   * the {@link curam.core.impl.EnvVars#ENV_INBOX_MAX_TASK_LIST_SIZE 
   * ENV_INBOX_MAX_TASK_LIST_SIZE} environment variable. If the number of 
   * records exceed this maximum value then an information message is displayed
   * ({@link curam.message.BPOINBOX#INF_READMULTI_MAX_EXCEEDED
   * INF_READMULTI_MAX_EXCEEDED}) informing the user that more records exist.
   *
   * @param key The ID of the task query.
   *
   * @return A list of tasks that satisfy the query criteria. If there are any
   * validation errors related to the query criteria then an informational 
   * exception is thrown.
   */
  public TaskQueryResult run(QueryKey key) throws AppException,
      InformationalException {
    ReadMultiOperationDetails readMulti = InboxFactory.newInstance().getInboxTaskReadMultiDetails();
    TaskQueryResult resultList = TaskQueryFactory.newInstance().run(key,
      readMulti);

    InformationalManager infoMgr = TransactionInfo.getInformationalManager();
    // Obtain the informational(s) to be returned to the client
    String[] warnings = infoMgr.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      resultList.resultList.informationalMsgDetailsList.dtls.addRef(
        informationalMsgDtls);
    }
    return resultList;
  }

  // ____________________________________________________________________________
  /**
   * This method modifies a task query's criteria.
   *
   * @param details The task query criteria to replace the existing criteria.
   *
   * @return If validation succeeds, then the query id. If there are any
   * validation errors then an informational exception is thrown.
   */
  public TaskQueryResult modify(TaskQueryDetails details) throws AppException,
      InformationalException {
    return TaskQueryFactory.newInstance().modify(details);
  }

  // ____________________________________________________________________________
  /**
   * This method reads a task query from the database.
   *
   * @param key The query ID.
   *
   * @return The task query corresponding to the specified query ID.
   */
  public TaskQueryDetails read(QueryKey key) 
    throws AppException, InformationalException {
    return TaskQueryFactory.newInstance().read(key);
  }

  /**
   * Gets the current user's organization objects. An organization object can 
   * be a user, an organization unit, a position, a job or a work queue.
   *
   * @return The current user's organization objects.
   */
  public OrganisationObjectDetailsList getUserOrgObjects() 
    throws AppException, InformationalException {
    OrganisationObjectDetailsList returnList = curam.core.hook.task.impl.SearchTaskUtilities.getUserOrgObjects();

    // The selected values for the task query is nothing selected, therefore
    // set them to empty string
    returnList.selectedValues = GeneralConstants.kEmpty;
    return returnList;
  }
}
