/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright (c) 2005-2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.core.facade.struct.EventClassChangeDetails;
import curam.core.facade.struct.EventClassDetails;
import curam.core.facade.struct.EventClassDetailsList;
import curam.core.facade.struct.EventKey;
import curam.core.facade.struct.EventTypeChangeDetails;
import curam.core.facade.struct.EventTypeDetailsList;
import curam.core.facade.struct.ProcessEnactmentEventCreateDetails;
import curam.core.facade.struct.ProcessEnactmentEventData;
import curam.core.facade.struct.ProcessEnactmentEventDataKey;
import curam.core.facade.struct.ProcessEnactmentEventDetails;
import curam.core.facade.struct.ProcessEnactmentEventKey;
import curam.core.facade.struct.ProcessEnactmentEventSummaryDetailsList;
import curam.core.facade.struct.ProcessSearchDetails;
import curam.core.facade.struct.ProcessSummaryDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Facade class for creating and editing Workflow Events and their associated
 * enactment mappings
 */
public abstract class WorkflowEvents extends curam.core.facade.base.WorkflowEvents {

  // ___________________________________________________________________________
  /**
   * Method to create a new Event Class
   *
   * @param dtls Details of the Event Class to create
   */
  public void createEventClass(EventClassDetails dtls)
    throws AppException, InformationalException {

    // create the internal key
    curam.util.administration.struct.EventClassDetails eventClassDetails = new
      curam.util.administration.struct.EventClassDetails();

    eventClassDetails.eventClass = dtls.eventClass;

    // get the Event admin
    curam.util.administration.intf.EventDefinitionAdmin eventDefinitionAdminObj = curam.util.administration.fact.EventDefinitionAdminFactory.newInstance();

    eventDefinitionAdminObj.createEventClass(eventClassDetails);

  }

  // ___________________________________________________________________________
  /**
   * Method to list all Event Classes
   *
   * @return List of Events in the system
   */
  public EventClassDetailsList listEventClasses()
    throws AppException, InformationalException {

    EventClassDetailsList eventClassDetailsList = new EventClassDetailsList();

    // get the event admin
    curam.util.administration.intf.EventDefinitionAdmin eventDefinitionAdminObj = curam.util.administration.fact.EventDefinitionAdminFactory.newInstance();

    // get list in internal format
    curam.util.administration.struct.EventClassDetailsList internalEventClassDetailsList = eventDefinitionAdminObj.readAllEventClasses();

    // resize the list to be returned
    eventClassDetailsList.dtls.ensureCapacity(
      internalEventClassDetailsList.dtls.size());

    for (int i = 0; i < internalEventClassDetailsList.dtls.size(); i++) {

      EventClassDetails eventClassDetails = new EventClassDetails();

      eventClassDetails.eventClass = internalEventClassDetailsList.dtls.item(i).eventClass;

      eventClassDetailsList.dtls.addRef(eventClassDetails);

    }

    return eventClassDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Method to delete a particular event class from the system
   *
   * @param dtls Details of the Event Class to delete
   */
  public void deleteEventClass(EventClassDetails dtls)
    throws AppException, InformationalException {

    // create the internal key
    curam.util.events.struct.EventClass eventClass = new curam.util.events.struct.EventClass();

    eventClass.eventClass = dtls.eventClass;

    // get the event admin object
    curam.util.administration.intf.EventDefinitionAdmin eventDefinitionAdminObj = curam.util.administration.fact.EventDefinitionAdminFactory.newInstance();

    eventDefinitionAdminObj.deleteEventClass(eventClass);

  }

  // ___________________________________________________________________________
  /**
   * Method to change the details of an Event Class (rename it)
   *
   * @param dtls Details of the Event Class to change and what to change it to
   */
  public void modifyEventClass(EventClassChangeDetails dtls)
    throws AppException, InformationalException {

    // create internal details struct
    curam.util.administration.struct.EventClassModifyDetails eventClassModifyDetails = new
      curam.util.administration.struct.EventClassModifyDetails();

    eventClassModifyDetails.originalEventClass = dtls.oldEventClass;
    eventClassModifyDetails.modifiedEventClass = dtls.newEventClass;

    // get event admin object
    curam.util.administration.intf.EventDefinitionAdmin eventDefinitionAdminObj = curam.util.administration.fact.EventDefinitionAdminFactory.newInstance();

    eventDefinitionAdminObj.modifyEventClass(eventClassModifyDetails);

  }

  // ___________________________________________________________________________
  /**
   * Method to find all Event Types for a given Event Class
   *
   * @param key The Event Class to use in the search
   *
   * @return List of all Event Types for the Event Class
   */
  public EventTypeDetailsList listEventTypeByClass(EventClassDetails key)
    throws AppException, InformationalException {

    // create the return list
    EventTypeDetailsList eventTypeDetailsList = new EventTypeDetailsList();

    // create internal search key
    curam.util.administration.struct.EventClassDetails eventClassDetails = new
      curam.util.administration.struct.EventClassDetails();

    eventClassDetails.eventClass = key.eventClass;

    // get event admin object
    curam.util.administration.intf.EventDefinitionAdmin eventDefinitionAdminObj = curam.util.administration.fact.EventDefinitionAdminFactory.newInstance();

    // get internal list of event types
    curam.util.administration.struct.EventTypeDetailsList internalEventTypeDetailsList = eventDefinitionAdminObj.searchEventTypeByEventClass(
      eventClassDetails);

    // resize the return list
    eventTypeDetailsList.dtls.ensureCapacity(
      internalEventTypeDetailsList.dtls.size());

    for (int i = 0; i < internalEventTypeDetailsList.dtls.size(); i++) {

      curam.core.facade.struct.EventTypeDetails eventTypeDetails = new curam.core.facade.struct.EventTypeDetails();

      eventTypeDetails.eventType = internalEventTypeDetailsList.dtls.item(i).eventType;

      eventTypeDetailsList.dtls.addRef(eventTypeDetails);

    }
    return eventTypeDetailsList;
  }
  
  // ___________________________________________________________________________
  /**
   * Returns the name of an event class for display. This method is required for
   * the edit event class page to display the name of the event class that is
   * being edited.
   */
  public EventClassDetails readEventClassNameForDisplay(
    EventClassDetails eventClassDetails)
    throws AppException, InformationalException {

    // Just return the same name as was passed into the function.
    EventClassDetails details = new EventClassDetails();

    details.eventClass = eventClassDetails.eventClass;
    return details;
  }  

  // ___________________________________________________________________________
  /**
   * Method to create an Event Type for a given Event Class
   *
   * @param dtls Details of the Event Type to create
   */
  public void createEventType(EventKey dtls)
    throws AppException, InformationalException {

    // create the internal key
    curam.util.administration.struct.EventTypeDetails eventTypeDetails = new curam.util.administration.struct.EventTypeDetails();

    eventTypeDetails.eventClass = dtls.eventClass;
    eventTypeDetails.eventType = dtls.eventType;

    // get the event admin object
    curam.util.administration.intf.EventDefinitionAdmin eventDefinitionAdminObj = curam.util.administration.fact.EventDefinitionAdminFactory.newInstance();

    eventDefinitionAdminObj.createEventType(eventTypeDetails);

  }

  // ___________________________________________________________________________
  /**
   * Method to delete an Event Type from a given Event Class
   *
   * @param dtls Details of the Event Type to delete
   */
  public void deleteEventType(EventKey dtls)
    throws AppException, InformationalException {

    // create the internal key
    curam.util.events.struct.EventKey eventKey = new curam.util.events.struct.EventKey();

    eventKey.eventClass = dtls.eventClass;
    eventKey.eventType = dtls.eventType;

    // get the event admin object
    curam.util.administration.intf.EventDefinitionAdmin eventDefinitionAdminObj = curam.util.administration.fact.EventDefinitionAdminFactory.newInstance();

    eventDefinitionAdminObj.deleteEventType(eventKey);

  }

  // ___________________________________________________________________________
  /**
   * Method to modify a particular Event Type
   *
   * @param dtls Details of the Event Type to change and what to change it to
   */
  public void modifyEventType(EventTypeChangeDetails dtls)
    throws AppException, InformationalException {

    // create the internal struct
    curam.util.administration.struct.EventTypeModifyDetails eventTypeModifyDetails = new curam.util.administration.struct.EventTypeModifyDetails();

    eventTypeModifyDetails.eventClass = dtls.eventClass;
    eventTypeModifyDetails.originalEventType = dtls.oldEventType;
    eventTypeModifyDetails.modifiedEventType = dtls.newEventType;

    // get the event admin object
    curam.util.administration.intf.EventDefinitionAdmin eventDefinitionAdminObj = curam.util.administration.fact.EventDefinitionAdminFactory.newInstance();

    eventDefinitionAdminObj.modifyEventType(eventTypeModifyDetails);

  }

  // ___________________________________________________________________________
  /**
   * Searches for all Workflow Processes that match the specified criteria
   *
   * @param key Search criteria to use
   *
   * @return Summary list of matching Workflow Processes
   */
  public ProcessSummaryDetailsList searchProcesses(ProcessSearchDetails key)
    throws AppException, InformationalException {

    ProcessSummaryDetailsList processSummaryDetailsList = new ProcessSummaryDetailsList();

    curam.util.workflow.struct.ProcessSummaryDetailsList internalProcessSummaryDetailsList = curam.util.workflow.impl.ProcessDefinitionSearch.searchProcesses(
      key.processName, key.processDisplayName, key.category, key.createdBy,
      key.dateCreated, false);

    // resize the return list
    processSummaryDetailsList.dtls.ensureCapacity(
      internalProcessSummaryDetailsList.dtls.size());

    for (int i = 0; i < internalProcessSummaryDetailsList.dtls.size(); i++) {

      curam.util.workflow.struct.ProcessSummaryDetails internalProcessSummaryDetails = internalProcessSummaryDetailsList.dtls.item(
        i);

      curam.core.facade.struct.ProcessSummaryDetails processSummaryDetails = new curam.core.facade.struct.ProcessSummaryDetails();

      processSummaryDetails.category = internalProcessSummaryDetails.category;
      processSummaryDetails.processID = internalProcessSummaryDetails.processID;
      processSummaryDetails.processName = internalProcessSummaryDetails.processName;
      processSummaryDetails.processDisplayName = internalProcessSummaryDetails.processDisplayName;
      processSummaryDetails.processVersion = internalProcessSummaryDetails.processVersion;

      processSummaryDetailsList.dtls.addRef(processSummaryDetails);

    } // end for i
    // END HARP 56117, IQ

    return processSummaryDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Disables a specified Workflow Event Mapping
   *
   * @param key Details of the Workflow Event Mapping to disable
   */
  public void disableProcessEnactment(ProcessEnactmentEventKey key)
    throws AppException, InformationalException {

    curam.util.workflow.struct.ProcessEnactmentEventKey processEnactmentEventKey = new curam.util.workflow.struct.ProcessEnactmentEventKey();

    processEnactmentEventKey.processStartEventID = key.processStartEventID;

    // get event admin object
    curam.util.workflow.impl.ProcessEnactmentEventAdmin.changeProcessEnactmentStatus(
      processEnactmentEventKey, false);

  }

  // ___________________________________________________________________________
  /**
   * Enables a specified Workflow Event Mapping
   *
   * @param key Details of the Workflow Event Mapping to enable
   */
  public void enableProcessEnactment(ProcessEnactmentEventKey key)
    throws AppException, InformationalException {

    // create the internal key
    curam.util.workflow.struct.ProcessEnactmentEventKey processEnactmentEventKey = new curam.util.workflow.struct.ProcessEnactmentEventKey();

    processEnactmentEventKey.processStartEventID = key.processStartEventID;

    // get event admin object
    curam.util.workflow.impl.ProcessEnactmentEventAdmin.changeProcessEnactmentStatus(
      processEnactmentEventKey, true);

  }

  // ___________________________________________________________________________
  /**
   * Lists all Workflow Event Mappings for a particular Event
   *
   * @param key The Event Class and Type
   *
   * @return List of Workflow Event Mappings
   */
  public ProcessEnactmentEventSummaryDetailsList getAllProcessEnactmentsForEvent(
    EventKey key) throws AppException, InformationalException {

    ProcessEnactmentEventSummaryDetailsList processEnactmentEventSummaryDetailsList = new ProcessEnactmentEventSummaryDetailsList();

    // get the internal key
    curam.util.events.struct.EventDetails internalKey = new curam.util.events.struct.EventDetails();

    internalKey.eventClass = key.eventClass;
    internalKey.eventType = key.eventType;

    // call internal API
    curam.util.workflow.struct.ProcessEnactmentEventSummaryDetailsList internalProcessEnactmentEventSummaryDetailsList = curam.util.workflow.impl.ProcessEnactmentEventAdmin.getAllProcessEnactmentsForEvent(
      internalKey);

    // resize the return list
    processEnactmentEventSummaryDetailsList.dtls.ensureCapacity(
      processEnactmentEventSummaryDetailsList.dtls.size());

    for (int i = 0; i
      < internalProcessEnactmentEventSummaryDetailsList.dtls.size(); i++) {

      curam.core.facade.struct.ProcessEnactmentEventSummaryDetails processEnactmentEventSummaryDetails = new curam.core.facade.struct.ProcessEnactmentEventSummaryDetails();

      curam.util.workflow.struct.ProcessEnactmentEventSummaryDetails internalProcessEnactmentEventSummaryDetails = internalProcessEnactmentEventSummaryDetailsList.dtls.item(
        i);

      processEnactmentEventSummaryDetails.eventClass = internalProcessEnactmentEventSummaryDetails.eventClass;
      processEnactmentEventSummaryDetails.eventType = internalProcessEnactmentEventSummaryDetails.eventType;
      processEnactmentEventSummaryDetails.processName = internalProcessEnactmentEventSummaryDetails.processToStart;
      processEnactmentEventSummaryDetails.processDisplayName = internalProcessEnactmentEventSummaryDetails.processDisplayName;
      processEnactmentEventSummaryDetails.enabled = internalProcessEnactmentEventSummaryDetails.enabled;
      processEnactmentEventSummaryDetails.processStartEventID = internalProcessEnactmentEventSummaryDetails.processStartEventID;
      processEnactmentEventSummaryDetails.processID = internalProcessEnactmentEventSummaryDetails.processID;
      processEnactmentEventSummaryDetails.processVersionNo = internalProcessEnactmentEventSummaryDetails.processVersionNo;
      
      processEnactmentEventSummaryDetailsList.dtls.addRef(
        processEnactmentEventSummaryDetails);

    }

    return processEnactmentEventSummaryDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Returns the details of a given Workflow Event Mapping
   *
   * @param key The Mapping to return
   *
   * @return Details of the Workflow event Mapping including all Mapping Data
   */
  public ProcessEnactmentEventDetails readProcessEnactment(
    ProcessEnactmentEventKey key) throws AppException, InformationalException {

    ProcessEnactmentEventDetails processEnactmentEventDetails = new ProcessEnactmentEventDetails();

    // get internal key
    curam.util.workflow.struct.ProcessEnactmentEventKey processEnactmentEventKey = new curam.util.workflow.struct.ProcessEnactmentEventKey();

    processEnactmentEventKey.processStartEventID = key.processStartEventID;

    // read process event enactment details
    curam.util.workflow.struct.ProcessEnactmentEventDetails internalProcessEnactmentEventDetails = curam.util.workflow.impl.ProcessEnactmentEventAdmin.readProcessEnactment(
      processEnactmentEventKey);

    processEnactmentEventDetails.eventClass = internalProcessEnactmentEventDetails.eventClass;
    processEnactmentEventDetails.eventType = internalProcessEnactmentEventDetails.eventType;
    processEnactmentEventDetails.processName = internalProcessEnactmentEventDetails.processToStart;
    processEnactmentEventDetails.processStartEventID = internalProcessEnactmentEventDetails.processStartEventID;
    processEnactmentEventDetails.enabled = internalProcessEnactmentEventDetails.enabled;

    processEnactmentEventDetails.data.ensureCapacity(
      internalProcessEnactmentEventDetails.dtls.size());

    for (int i = 0; i < internalProcessEnactmentEventDetails.dtls.size(); i++) {

      curam.core.facade.struct.ProcessEnactmentEventData processEnactmentEventData = new curam.core.facade.struct.ProcessEnactmentEventData();

      curam.util.workflow.struct.ProcessEnactmentEventData internalProcessEnactmentEventData = internalProcessEnactmentEventDetails.dtls.item(
        i);

      processEnactmentEventData.eventField = internalProcessEnactmentEventData.eventField;
      processEnactmentEventData.procEvtMappingID = internalProcessEnactmentEventData.procEvtMappingID;
      processEnactmentEventData.procStartEventID = internalProcessEnactmentEventData.procStartEventID;
      processEnactmentEventData.wdoAttribute = internalProcessEnactmentEventData.wdoAttribute;

      processEnactmentEventDetails.data.addRef(processEnactmentEventData);

    }

    return processEnactmentEventDetails;

  }

  // ___________________________________________________________________________
  /**
   * Creates a new Process Enactment for a specified Event and Workflow PRocess
   *
   * @param dtls Details of the Enactment to create
   */
  public void createProcessEnactmentForEvent(
    ProcessEnactmentEventCreateDetails dtls)
    throws AppException, InformationalException {

    // create internal details struct for creating the enactment
    curam.util.workflow.struct.ProcessEnactmentEventDetails processEnactmentEventDetails = new curam.util.workflow.struct.ProcessEnactmentEventDetails();

    processEnactmentEventDetails.eventClass = dtls.eventClass;
    processEnactmentEventDetails.eventType = dtls.eventType;
    processEnactmentEventDetails.enabled = false;
    processEnactmentEventDetails.processToStart = dtls.processName;

    // add the new enactment mapping
    curam.util.workflow.impl.ProcessEnactmentEventAdmin.addProcessEnactmentForEvent(
      processEnactmentEventDetails);

  }

  // ___________________________________________________________________________
  /**
   * Modify Event Mapping Data for a Process Enactment
   *
   * data The Mapping Data to modify
   */
  public void modifyProcessEnactmentEventData(ProcessEnactmentEventData data)
    throws AppException, InformationalException {

    // create internal data struct
    curam.util.workflow.struct.ProcessEnactmentEventData processEnactmentEventData = new curam.util.workflow.struct.ProcessEnactmentEventData();

    processEnactmentEventData.procStartEventID = data.procStartEventID;
    processEnactmentEventData.procEvtMappingID = data.procEvtMappingID;
    processEnactmentEventData.wdoAttribute = data.wdoAttribute;
    processEnactmentEventData.eventField = data.eventField;

    // save event data mapping
    curam.util.workflow.impl.ProcessEnactmentEventAdmin.modifyProcessEnactmentEventData(
      processEnactmentEventData);

  }

  // ___________________________________________________________________________
  /**
   * Read Event Mapping Data for a Process Enactment
   *
   * @param key The specific mapping data to read
   *
   * @return details of the mapping data read
   */
  public ProcessEnactmentEventData readProcessEnactmentEventData(
    ProcessEnactmentEventDataKey key) throws AppException, InformationalException {

    ProcessEnactmentEventData processEnactmentEventData = new ProcessEnactmentEventData();

    // get the event data mapping internal struct
    curam.util.workflow.struct.ProcessEnactmentEventData internalProcessEnactmentEventData = curam.util.workflow.impl.ProcessEnactmentEventAdmin.readProcessEnactmentEventData(
      key.procEvtMappingID);

    processEnactmentEventData.procEvtMappingID = internalProcessEnactmentEventData.procEvtMappingID;
    processEnactmentEventData.procStartEventID = internalProcessEnactmentEventData.procStartEventID;
    processEnactmentEventData.wdoAttribute = internalProcessEnactmentEventData.wdoAttribute;
    processEnactmentEventData.eventField = internalProcessEnactmentEventData.eventField;

    return processEnactmentEventData;

  }

  // ___________________________________________________________________________
  /**
   * Method to delete a particular Workflow Process Event Enactment
   *
   * @param key Key of the enactment to delete
   */
  public void deleteProcessEnactmentForEvent(ProcessEnactmentEventKey key)
    throws AppException, InformationalException {

    // create internal key
    curam.util.workflow.struct.ProcessEnactmentEventKey processEnactmentEventKey = new curam.util.workflow.struct.ProcessEnactmentEventKey();

    processEnactmentEventKey.processStartEventID = key.processStartEventID;

    curam.util.workflow.impl.ProcessEnactmentEventAdmin.deleteProcessEnactment(
      processEnactmentEventKey);

  }

  // ___________________________________________________________________________
  /**
   * Method to publish all changes made to Process Event Enactment Mappings
   */
  public void publishChanges() throws AppException, InformationalException {

    // refresh the cache to publish the changes made to the enactment mappings
    curam.util.workflow.impl.ProcessEnactmentEventAdmin.refreshCache();

  }

}
