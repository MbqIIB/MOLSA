/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2003, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.codetable.ACTIONCONTROLID;
import curam.codetable.ASSESSMENTTYPE;
import curam.codetable.CALENDARTYPE;
import curam.codetable.CASEEVENTTYPE;
import curam.codetable.CASENOMINEESTATUS;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.COMMUNICATIONFORMAT;
import curam.codetable.COMMUNICATIONSTATUS;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.CONTACTLOGLINKTYPE;
import curam.codetable.EVIDENCETREESTATUS;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.NOMINEECONCERNROLETYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.PAGETYPE;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.REPRESENTATIVETYPE;
import curam.codetable.RULESCOMPONENTTYPE;
import curam.codetable.SCREENINGNAMECODE;
import curam.codetable.SERVICEPLANTYPE;
import curam.codetable.impl.BATCHPROCESSNAMEEntry;
import curam.codetable.impl.CONTACTLOGLINKTYPEEntry;
import curam.core.facade.fact.AttachmentFactory;
import curam.core.facade.fact.CommunicationFactory;
import curam.core.facade.fact.IntegratedCaseFactory;
import curam.core.facade.fact.ProductFactory;
import curam.core.facade.intf.IntegratedCase;
import curam.core.facade.intf.Product;
import curam.core.facade.pdt.fact.ProcessAdminFactory;
import curam.core.facade.pdt.intf.ProcessAdmin;
import curam.core.facade.pdt.struct.ProcessSummaryDetails;
import curam.core.facade.pdt.struct.ProcessSummaryDetailsList;
import curam.core.facade.struct.ActiveCaseParticipantRoleList;
import curam.core.facade.struct.AddClientRoleDetails;
import curam.core.facade.struct.AddMultiClientRoles;
import curam.core.facade.struct.AppealsInstalledInd;
import curam.core.facade.struct.ApproveEvidenceKey;
import curam.core.facade.struct.AssignObjectiveKey;
import curam.core.facade.struct.CERDecisionDetails;
import curam.core.facade.struct.CancelCaseNoteDetails;
import curam.core.facade.struct.CancelClientRoleKey;
import curam.core.facade.struct.CancelCommunicationKey;
import curam.core.facade.struct.CancelRelationshipKey;
import curam.core.facade.struct.CaseAccessibleNotesList;
import curam.core.facade.struct.CaseAccessibleNotesList1;
import curam.core.facade.struct.CaseContactLogAttachmentDetails;
import curam.core.facade.struct.CaseContactLogDetails;
import curam.core.facade.struct.CaseContactLogKey;
import curam.core.facade.struct.CaseContactLogList;
import curam.core.facade.struct.CaseContextDescription;
import curam.core.facade.struct.CaseContextDescriptionKey;
import curam.core.facade.struct.CaseContextPanelKey;
import curam.core.facade.struct.CaseEventAndActivityDetails;
import curam.core.facade.struct.CaseEventAndActivityDetails1;
import curam.core.facade.struct.CaseGroupEligibleMembersDtlsList;
import curam.core.facade.struct.CaseHomePageDetails;
import curam.core.facade.struct.CaseIDDetails;
import curam.core.facade.struct.CaseIDKey;
import curam.core.facade.struct.CaseKey_fo;
import curam.core.facade.struct.CaseListObjectiveKey;
import curam.core.facade.struct.CaseMenuData;
import curam.core.facade.struct.CaseNomineeAndCountDetails;
import curam.core.facade.struct.CaseNomineeAndStatusDetails;
import curam.core.facade.struct.CaseNomineeCaseIDAndStatusKey;
import curam.core.facade.struct.CaseNomineeCaseIDKey;
import curam.core.facade.struct.CaseNomineeContextDescriptionKey;
import curam.core.facade.struct.CaseNomineeContextDescription_fo;
import curam.core.facade.struct.CaseNomineeCreationDetails;
import curam.core.facade.struct.CaseNomineeDeliveryPatternDetailsList;
import curam.core.facade.struct.CaseNomineeHistoryKey;
import curam.core.facade.struct.CaseNomineeIDReferenceNameRelationshipList;
import curam.core.facade.struct.CaseNomineeModifyViewDetails;
import curam.core.facade.struct.CaseNomineeObjectiveDetails;
import curam.core.facade.struct.CaseNomineeObjectiveHistory_fo;
import curam.core.facade.struct.CaseNomineeObjectiveList;
import curam.core.facade.struct.CaseNomineeObjectiveNameDetailsList;
import curam.core.facade.struct.CaseNomineeViewDetails;
import curam.core.facade.struct.CaseNomineeViewDetails1;
import curam.core.facade.struct.CaseNomineeViewKey;
import curam.core.facade.struct.CaseNoteKey;
import curam.core.facade.struct.CaseNoteList;
import curam.core.facade.struct.CaseObjectiveContextDescription;
import curam.core.facade.struct.CaseObjectiveContextDescriptionKey;
import curam.core.facade.struct.CaseObjectiveIDCodeList;
import curam.core.facade.struct.CaseObjectiveKey;
import curam.core.facade.struct.CaseParticipantRoleAndIndicatorDetails;
import curam.core.facade.struct.CaseParticipantRoleKey;
import curam.core.facade.struct.CaseParticipantRoleModifyComments;
import curam.core.facade.struct.CaseReferenceSearchKey;
import curam.core.facade.struct.CaseSearchByOwnerDetailsList;
import curam.core.facade.struct.CaseSearchByOwnerResultList;
import curam.core.facade.struct.CaseSearchList;
import curam.core.facade.struct.CaseSearchList1;
import curam.core.facade.struct.CaseSearchResultList;
import curam.core.facade.struct.CaseStatusHistory;
import curam.core.facade.struct.CaseTypeDetails;
import curam.core.facade.struct.CommunicationAndListRowActionDetails;
import curam.core.facade.struct.CommunicationDetailList;
import curam.core.facade.struct.ConcernRoleKeyStruct;
import curam.core.facade.struct.ContactLogAttendeeAndConcernList;
import curam.core.facade.struct.ContactLogSearchDetails;
import curam.core.facade.struct.ContactLogSearchKey;
import curam.core.facade.struct.ContactLogSearchKey1;
import curam.core.facade.struct.ContactLogWizardDetails;
import curam.core.facade.struct.ContextPanelName;
import curam.core.facade.struct.CreateAppealDetails;
import curam.core.facade.struct.CreateCaseOwnerDetails;
import curam.core.facade.struct.CreateCaseSupervisorDetails;
import curam.core.facade.struct.CreateCommunicationDetails;
import curam.core.facade.struct.CreateDetailsForNomineeList;
import curam.core.facade.struct.CreateNomineeDetails;
import curam.core.facade.struct.CreateReferralDetails;
import curam.core.facade.struct.CreateReviewDetails;
import curam.core.facade.struct.CreateReviewDetails1;
import curam.core.facade.struct.DeliveryPatternForCaseDetailsList;
import curam.core.facade.struct.EvidenceDetails;
import curam.core.facade.struct.EvidenceStatusHistoryDetails;
import curam.core.facade.struct.FinancialInstructionAndCaseID;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.InsertCaseNoteDetails;
import curam.core.facade.struct.IsCreoleProduct;
import curam.core.facade.struct.LanguageLocaleMapKey;
import curam.core.facade.struct.ListAdminCaseRoleDetails;
import curam.core.facade.struct.ListAdminCaseRoleKey;
import curam.core.facade.struct.ListAssessmentDetails;
import curam.core.facade.struct.ListAssessmentKey;
import curam.core.facade.struct.ListCaseAttachmentDetails;
import curam.core.facade.struct.ListCaseAttachmentKey;
import curam.core.facade.struct.ListCaseByCurrentUserDetails;
import curam.core.facade.struct.ListCaseByCurrentUserKey;
import curam.core.facade.struct.ListCaseByPersonDetails;
import curam.core.facade.struct.ListCaseByPersonKey;
import curam.core.facade.struct.ListCaseContactLogDetails;
import curam.core.facade.struct.ListCaseContactLogDetails1;
import curam.core.facade.struct.ListCaseEventDetails;
import curam.core.facade.struct.ListCaseEventKey;
import curam.core.facade.struct.ListCaseNomineeBankAccKey;
import curam.core.facade.struct.ListCaseNomineeBankAccResult;
import curam.core.facade.struct.ListCaseRelationshipDetails;
import curam.core.facade.struct.ListCaseRelationshipKey;
import curam.core.facade.struct.ListCaseStatusHistoryDetails;
import curam.core.facade.struct.ListCaseStatusHistoryDetails1;
import curam.core.facade.struct.ListCaseTaskResult;
import curam.core.facade.struct.ListCasesForParticipantDetails;
import curam.core.facade.struct.ListCasesForUserDetails;
import curam.core.facade.struct.ListClientRoleDetails;
import curam.core.facade.struct.ListClientRoleDetails1;
import curam.core.facade.struct.ListClientRoleKey;
import curam.core.facade.struct.ListCommunicationsDtls;
import curam.core.facade.struct.ListCommunicationsKey;
import curam.core.facade.struct.ListEvidenceDetails;
import curam.core.facade.struct.ListEvidenceKey;
import curam.core.facade.struct.ListRelationshipDetails;
import curam.core.facade.struct.ListRelationshipForCaseMemberDetails;
import curam.core.facade.struct.ListRelationshipForCaseMemberDetails1;
import curam.core.facade.struct.ListRelationshipKey;
import curam.core.facade.struct.ListStatusHistoryKey;
import curam.core.facade.struct.ListTransactionsLogDetails;
import curam.core.facade.struct.MaintainRelationshipDetails;
import curam.core.facade.struct.MaintainRelationshipDetails1;
import curam.core.facade.struct.ModifyAppealDetails;
import curam.core.facade.struct.ModifyCaseAttachmentDetails;
import curam.core.facade.struct.ModifyCaseNomineeAddressDetails;
import curam.core.facade.struct.ModifyCaseNomineeBankAccountDetails;
import curam.core.facade.struct.ModifyCaseNomineeDetails;
import curam.core.facade.struct.ModifyCaseNoteDetails;
import curam.core.facade.struct.ModifyCaseNoteDetails1;
import curam.core.facade.struct.ModifyCaseSupervisorDetails;
import curam.core.facade.struct.ModifyClientRoleDetails;
import curam.core.facade.struct.ModifyCommunicationDetails;
import curam.core.facade.struct.ModifyNomineeAddressDetails;
import curam.core.facade.struct.ModifyNomineeBankAcDetails;
import curam.core.facade.struct.ModifyNomineeStatusDetails;
import curam.core.facade.struct.ModifyReferralDetails;
import curam.core.facade.struct.ModifyReviewDetails;
import curam.core.facade.struct.ModifyReviewDetails1;
import curam.core.facade.struct.ModifyTranslatorRequiredDetails;
import curam.core.facade.struct.MyCasesFilterList;
import curam.core.facade.struct.ObjectiveHistoryDetails;
import curam.core.facade.struct.PageIdentifierResult;
import curam.core.facade.struct.PreviewCaseContactLogDetails;
import curam.core.facade.struct.PreviewCaseContactLogIDKey;
import curam.core.facade.struct.PreviewCaseContactLogKey;
import curam.core.facade.struct.PreviewCaseContactLogXMLDetails;
import curam.core.facade.struct.ProductCategoryCode;
import curam.core.facade.struct.ReadAdminCaseRoleDetails;
import curam.core.facade.struct.ReadAdminCaseRoleKey;
import curam.core.facade.struct.ReadAppealDtls;
import curam.core.facade.struct.ReadAppealKey;
import curam.core.facade.struct.ReadApprovalEventDetails;
import curam.core.facade.struct.ReadApprovalEventKey;
import curam.core.facade.struct.ReadAssessmentCaseDecisionDetails;
import curam.core.facade.struct.ReadAssessmentCaseDecisionKey;
import curam.core.facade.struct.ReadAttachmentDetails;
import curam.core.facade.struct.ReadAttachmentKey;
import curam.core.facade.struct.ReadBenefitProductKey;
import curam.core.facade.struct.ReadBenefitProductStruct1;
import curam.core.facade.struct.ReadCaseAttachmentDetails;
import curam.core.facade.struct.ReadCaseAttachmentForModifyDetails;
import curam.core.facade.struct.ReadCaseAttachmentForModifyKey;
import curam.core.facade.struct.ReadCaseHomePageKey;
import curam.core.facade.struct.ReadCaseNoteDetails;
import curam.core.facade.struct.ReadCaseNoteDetails1;
import curam.core.facade.struct.ReadCaseTypeKey;
import curam.core.facade.struct.ReadClientRoleDetails;
import curam.core.facade.struct.ReadClientRoleDetails1;
import curam.core.facade.struct.ReadClientRoleKey;
import curam.core.facade.struct.ReadCommunicationDetails;
import curam.core.facade.struct.ReadCommunicationKey;
import curam.core.facade.struct.ReadIntegCaseAttachmentDetails;
import curam.core.facade.struct.ReadIntegCaseAttachmentKey;
import curam.core.facade.struct.ReadLiabilityProductStruct1;
import curam.core.facade.struct.ReadProFormaCommKey;
import curam.core.facade.struct.ReadReferralDtls;
import curam.core.facade.struct.ReadReferralKey;
import curam.core.facade.struct.ReadRelationshipDetails;
import curam.core.facade.struct.ReadRelationshipDetails1;
import curam.core.facade.struct.ReadRelationshipKey;
import curam.core.facade.struct.ReadRelationshipListForCaseMemberKey;
import curam.core.facade.struct.ReadReviewDetails1;
import curam.core.facade.struct.ReadReviewDtls;
import curam.core.facade.struct.ReadReviewKey;
import curam.core.facade.struct.ReadTransactionLogDetailsList;
import curam.core.facade.struct.ResolveEvidenceGroupPageKey;
import curam.core.facade.struct.ResolveEvidencePageKey;
import curam.core.facade.struct.ResolveModifyPageKey;
import curam.core.facade.struct.ResolveSiteMapKey;
import curam.core.facade.struct.SearchByCaseNomineeAndDateRangeDetailsList_fo;
import curam.core.facade.struct.SearchByCaseNomineeAndDateRangeKey_fo;
import curam.core.facade.struct.SearchCaseEventAndActivityKey;
import curam.core.facade.struct.SearchContactLogDetails;
import curam.core.facade.struct.SearchTasksForConcernAndCaseDetails;
import curam.core.facade.struct.SetAsPrimaryClientKey;
import curam.core.facade.struct.SetDefaultNomineeKey;
import curam.core.facade.struct.StatusHistoryCaseDetails;
import curam.core.facade.struct.UserNameDetailsList;
import curam.core.facade.struct.WizardProperties;
import curam.core.fact.AdminIntegratedCaseFactory;
import curam.core.fact.CaseApprovalFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseSearchFactory;
import curam.core.fact.FinancialComponentFactory;
import curam.core.fact.GenericBatchProcessInputFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.LocationFactory;
import curam.core.fact.MaintainCaseReviewFactory;
import curam.core.fact.MaintainConcernRoleBankAcFactory;
import curam.core.fact.MaintainConcernRoleDetailsFactory;
import curam.core.fact.MaintainConcernRoleRelationshipsFactory;
import curam.core.fact.MaintainRelatedCasesFactory;
import curam.core.fact.PaymentInstructionFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.ProspectPersonFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.DP_const;
import curam.core.impl.DataBasedSecurity;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.AdminIntegratedCase;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseSearch;
import curam.core.intf.GenericBatchProcessInput;
import curam.core.intf.Location;
import curam.core.intf.MaintainCaseReview;
import curam.core.intf.MaintainConcernRoleBankAc;
import curam.core.intf.MaintainConcernRoleDetails;
import curam.core.intf.MaintainConcernRoleRelationships;
import curam.core.intf.MaintainRelatedCases;
import curam.core.intf.ProductDelivery;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.CaseNomineeFactory;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.PositionFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.CaseNominee;
import curam.core.sl.entity.intf.IssueDelivery;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.intf.Position;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.AssessmentDeliveryKey;
import curam.core.sl.entity.struct.AssessmentTypeDetails;
import curam.core.sl.entity.struct.CaseEvidenceTreeKeyStruct;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseIDStruct;
import curam.core.sl.entity.struct.CaseIDStructList;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.CaseNomineeObjectiveHistoryKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleDtlsList;
import curam.core.sl.entity.struct.CaseParticipantRoleNameDetails;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseIDKey;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseParticipantRoleID;
import curam.core.sl.entity.struct.CaseParticipantRole_eoFullDetails;
import curam.core.sl.entity.struct.ContactLogAttendeeKey;
import curam.core.sl.entity.struct.ContactLogKey;
import curam.core.sl.entity.struct.ContactLogListDtlsList;
import curam.core.sl.entity.struct.InvestigationDeliveryKey;
import curam.core.sl.entity.struct.InvestigationTypeCode;
import curam.core.sl.entity.struct.IssueDeliveryKey;
import curam.core.sl.entity.struct.IssueTypeCode;
import curam.core.sl.entity.struct.LinkIDLinkTypeRecordStatusKey;
import curam.core.sl.entity.struct.ObjectiveHistoryDetailsList;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.ReadEffectiveByDateKey;
import curam.core.sl.entity.struct.ScreeningName;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.fact.CaseFactory;
import curam.core.sl.fact.CaseParticipantRoleFactory;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.fact.ContactLogAttendeeFactory;
import curam.core.sl.fact.ContactLogConcernFactory;
import curam.core.sl.fact.ContactLogFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.infrastructure.assessment.fact.CREOLECaseDecisionFactory;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngine;
import curam.core.sl.infrastructure.assessment.struct.CREOLECaseDecisionKey;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.fact.GeneralUtilityFactory;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.EvidenceVerificationImpl;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.core.sl.infrastructure.impl.UimConst;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.infrastructure.intf.EvidenceController;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrection;
import curam.core.sl.infrastructure.product.creole.fact.CREOLEProductFactory;
import curam.core.sl.infrastructure.product.creole.struct.CREOLEProductKey;
import curam.core.sl.intf.CaseParticipantRole;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.ClientMerge;
import curam.core.sl.intf.ContactLog;
import curam.core.sl.intf.ContactLogAttendee;
import curam.core.sl.intf.ContactLogConcern;
import curam.core.sl.struct.ActivityElementDetails;
import curam.core.sl.struct.AssignObjectiveAndDelPattKey;
import curam.core.sl.struct.CalendarElementData;
import curam.core.sl.struct.CancelCaseContactLogAttendeeDetails;
import curam.core.sl.struct.CancelCaseContactLogDetails;
import curam.core.sl.struct.CaseIDContactLogIDKey;
import curam.core.sl.struct.CaseIDNomineeIDKey;
import curam.core.sl.struct.CaseNomObjectiveAndDelPatternDetailsList;
import curam.core.sl.struct.CaseNomineeAndStatusDetailsList;
import curam.core.sl.struct.CaseNomineeDeliveryPatternDetails;
import curam.core.sl.struct.CaseNomineeDeliveryPatternKey;
import curam.core.sl.struct.CaseNomineeDetails;
import curam.core.sl.struct.CaseNomineeDetailsList;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.CaseParticipantDetails;
import curam.core.sl.struct.CaseParticipantRoleFullDetails;
import curam.core.sl.struct.CaseParticipantRoleFullDetails1;
import curam.core.sl.struct.CaseParticipantRoleIDAndNameDtlsList;
import curam.core.sl.struct.CaseParticipantRole_boKey;
import curam.core.sl.struct.CaseParticipantTabList;
import curam.core.sl.struct.CaseReassignReasonAndCommentsDetails;
import curam.core.sl.struct.CaseUserRoleDetails;
import curam.core.sl.struct.CommunicationDetailsList;
import curam.core.sl.struct.ContactLogLinkIDLinkTypeKey;
import curam.core.sl.struct.CreateCaseContactLogAttendeeDetails;
import curam.core.sl.struct.CreateCaseContactLogAttendeeDetails1;
import curam.core.sl.struct.CreateCaseContactLogDetails;
import curam.core.sl.struct.CreateCaseContactLogDetails1;
import curam.core.sl.struct.CreateCaseNomineeProdDelPattDetails;
import curam.core.sl.struct.DateRangeKey;
import curam.core.sl.struct.DateTimeRangeDetails;
import curam.core.sl.struct.DefaultNomineeDelPattDetailsList;
import curam.core.sl.struct.DeliveryPatternForCaseDetails;
import curam.core.sl.struct.EventElementDetails;
import curam.core.sl.struct.GetEvidenceGroupPageKey;
import curam.core.sl.struct.GetEvidenceGroupPageResult;
import curam.core.sl.struct.GetEvidencePageKey;
import curam.core.sl.struct.GetEvidencePageResult;
import curam.core.sl.struct.GetEvidencePageWithEffectiveFromKey;
import curam.core.sl.struct.GetSiteMapKey;
import curam.core.sl.struct.GetSiteMapResult;
import curam.core.sl.struct.ListEvidenceTreeLessCanceledAndSupersededKey;
import curam.core.sl.struct.ListEvidenceTreeLessCanceledAndSupersededResult;
import curam.core.sl.struct.ListGroupOnTreeResult;
import curam.core.sl.struct.ModifyCaseContactLogDetails;
import curam.core.sl.struct.ObjectiveAndDelPatternHistoryDetailsList;
import curam.core.sl.struct.OwnershipStrategyDetails;
import curam.core.sl.struct.OwnershipStrategyDetailsList;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.PreviewContactLogKey1;
import curam.core.sl.struct.ReadContactLogDetails;
import curam.core.sl.struct.ReasonEndDateComments;
import curam.core.sl.struct.RedetermineTranslatorStruct;
import curam.core.sl.struct.SearchByCaseNomineeAndDateRangeKey_bo;
import curam.core.sl.struct.SearchCaseParticipantDetailsKey;
import curam.core.sl.struct.SearchCaseParticipantDetailsList;
import curam.core.sl.struct.SearchTaskForConcernOrCaseKey;
import curam.core.sl.struct.SetAsPrimaryClientDetails;
import curam.core.sl.struct.UserNameAndFullName;
import curam.core.sl.struct.ViewCaseParticipantRoleDetailsList;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.struct.AdminIntegratedCaseDtls;
import curam.core.struct.AdminIntegratedCaseKey;
import curam.core.struct.BatchProcessDetails;
import curam.core.struct.CancelConcernRoleCommKey;
import curam.core.struct.CaseAndConcernSummaryDtlsList;
import curam.core.struct.CaseApprovalCaseID;
import curam.core.struct.CaseApprovalDtls;
import curam.core.struct.CaseApprovalIDStruct;
import curam.core.struct.CaseApprovalKey;
import curam.core.struct.CaseByConcernRoleIDKey;
import curam.core.struct.CaseDecisionCaseID;
import curam.core.struct.CaseDecisionDtls;
import curam.core.struct.CaseDecisionIDStruct;
import curam.core.struct.CaseEventNSReadDetails;
import curam.core.struct.CaseEventNSReadKey;
import curam.core.struct.CaseGroupRMKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHeaderOwnerDetails;
import curam.core.struct.CaseID;
import curam.core.struct.CaseIDAndRecordStatus;
import curam.core.struct.CaseIDAndTypeCodeKey;
import curam.core.struct.CaseIDConcernAndICTypeKey;
import curam.core.struct.CaseIDConcernRoleID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseNomineeID;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseRelationshipDtls;
import curam.core.struct.CaseRelationshipKey;
import curam.core.struct.CaseReviewDtls;
import curam.core.struct.CaseReviewKey;
import curam.core.struct.CaseSearchCriteria1;
import curam.core.struct.CaseSearchDetails;
import curam.core.struct.CaseSearchDetails1;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStartDate;
import curam.core.struct.CaseStatusHistoryDetailsList;
import curam.core.struct.CaseStatusHistoryDetailsList1;
import curam.core.struct.CaseStatusHistoryKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.CasesByConcernRoleIDAndTypeKey;
import curam.core.struct.ConcernRoleCommRMDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.ConcernRoleIDList;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.ConcernRolesDetails;
import curam.core.struct.Count;
import curam.core.struct.CuramInd;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.EvidenceApprovalKey;
import curam.core.struct.FinInstructionID;
import curam.core.struct.FinancialComponentDtls;
import curam.core.struct.FinancialComponentKey;
import curam.core.struct.FinancialInstructionKey;
import curam.core.struct.GetApprovalDetailsKey;
import curam.core.struct.GetCaseApprovalDetailsResult;
import curam.core.struct.GetCasesByOwnerResult;
import curam.core.struct.ICHomePageNameAndType;
import curam.core.struct.ILICaseIDFinInstID;
import curam.core.struct.ILIFinInstructID;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.InitialCaseSearchCriteria;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.IntegratedCaseType;
import curam.core.struct.IntegratedCaseTypeStruct;
import curam.core.struct.LocationKey;
import curam.core.struct.MaintainCaseAppealDetails;
import curam.core.struct.MaintainCaseAppealDetailsKey;
import curam.core.struct.MaintainCaseReferralDetails;
import curam.core.struct.MaintainCaseReferralKey;
import curam.core.struct.MaintainCaseReviewDetails;
import curam.core.struct.MaintainCaseReviewDetails1;
import curam.core.struct.MaintainCaseReviewKey;
import curam.core.struct.MaintainCommunicationKey;
import curam.core.struct.MaintainConcernRoleRelationshipList;
import curam.core.struct.MaintainConcernRoleRelationshipList1;
import curam.core.struct.MaintainConcernRoleRelationshipRMDetails;
import curam.core.struct.MaintainConcernRoleRelationshipRMDetails1;
import curam.core.struct.OwnerAndTypeKey;
import curam.core.struct.PaymentInstructionDtls;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryPatternByCaseIDKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.ProductIDDetails;
import curam.core.struct.ProductKeyStruct;
import curam.core.struct.ProspectPersonKey;
import curam.core.struct.ReadConcernRoleCommKey;
import curam.core.struct.ReassignAllCasesDetails;
import curam.core.struct.RelatedCaseProductType;
import curam.core.struct.RelationshipConcernRoleIDKey;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UsersKey;
import curam.core.struct.ViewCaseAssessmentListKey;
import curam.core.struct.ViewCaseEventDetailsList;
import curam.core.struct.ViewCaseEventsByCaseIDAndTypeKey;
import curam.core.struct.WMInstanceDataDtls;
import curam.message.BPOBULKCASEREASSIGNMENT;
import curam.message.BPOCASENOMINEE;
import curam.message.BPOCASEUSERROLE;
import curam.message.BPOMAINTAINCASEREVIEW;
import curam.message.BPOREFLECTION;
import curam.message.CASENOTE;
import curam.message.ENTCONTACTLOG;
import curam.message.FACADERESOURCE;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.message.PDCEVIDENCEDESCRIPTION;
import curam.message.SEPARATOR;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.serviceplans.facade.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.facade.intf.ServicePlanDelivery;
import curam.serviceplans.facade.struct.ServicePlanIntegratedCaseKey;
import curam.serviceplans.facade.struct.ServicePlanSecurityKey;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.entity.struct.ServicePlanTypeStruct;
import curam.serviceplans.sl.impl.ServicePlanSecurity;
import curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.Locale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.NotFoundIndicator;
import curam.util.type.StringList;


/**
 * @see curam.core.facade.intf.Case
 */
public abstract class Case extends curam.core.facade.base.Case {

  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by {@link
   * SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
   * TransactionInfo.getProgramLocale())}. Replacement reason -
   * static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note
   * CR00219408.
   */
  @Deprecated
  // BEGIN, CR00023323, SK
  protected static final String kSeparator = // BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  // END, CR00222190

  // END, CR00163471, JC
  // BEGIN, CR00098942, SAI
  protected static final String kSpace = CuramConst.gkSpace;

  // END, CR00098942

  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by {@link
   * CASENOTE.INF_CASE_START_DATE.getMessageText(TransactionInfo.
   * getProgramLocale())}. Replacement reason - static
   * variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note
   * CR00219408.
   */
  @Deprecated
  protected static final String kCaseStartDate = // BEGIN, CR00163471, JC
    CASENOTE.INF_CASE_START_DATE.getMessageText();
  // END, CR00222190
  // END, CR00163471
  // END, CR00023323

  // Estimated length of an EVENT element
  protected static final int kBufferSize = 1024;

  // BEGIN, CR00051657, GM
  protected static final String kServicePlanHome = UimConst.kServicePlanHome;
  // END, CR00051657
  // END, CR00021317

  // BEGIN, CR00148820, MC
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;
  // END, CR00148820

  // BEGIN, CR00209689, CSH
  /**
   * Reference to Payment Correction interface.
   */
  @Inject
  protected PaymentCorrection paymentCorrection;
  // END, CR00209689

  // BEGIN, CR00211744, VM
  @Inject
  protected AssessmentEngine assessmentEngine;
  // END, CR00211744

  // BEGIN, CR00365714, ZV
  /**
   * Instance of the CaseHeader DAO. 
   */
  @Inject
  protected CaseHeaderDAO caseHeaderDAO;
  // END, CR00365714
  
  @Inject 
  protected EvidenceVerificationImpl evidenceVerificationImpl;
  
  // Add injection for using the new CaseTransactionLog API
  public Case() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  
  // ___________________________________________________________________________
  /**
   * Cancel an attachment on a case.
   *
   * @param key
   * Case attachment key.
   */
  public void cancelCaseAttachment(
    final curam.core.facade.struct.CancelCaseAttachmentKey key)
    throws AppException, InformationalException {

    // Case maintenance object
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = key.cancelCaseAttachmentKey.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = caseKey.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Cancel the case attachment
    maintainAttachmentObj.cancelCaseAttachment(key.cancelCaseAttachmentKey);
  }

  // ___________________________________________________________________________
  /**
   * Cancels a Case Relationship.
   *
   * @param key
   * Case relationship identifier.
   */
  public void cancelRelationship(final CancelRelationshipKey key)
    throws AppException, InformationalException {

    // Case relationship maintenance object
    final curam.core.intf.MaintainRelatedCases maintainRelatedCasesObj = curam.core.fact.MaintainRelatedCasesFactory.newInstance();

    // Cancel the Case Relationship
    maintainRelatedCasesObj.cancelCaseRelationship(
      key.maintainCaseRelationshipDetailsKey);
  }

  // ___________________________________________________________________________
  /**
   * Create an attachment for a case.
   *
   * @param details
   * Case attachment details.
   */
  public void createCaseAttachment(
    final curam.core.facade.struct.CreateCaseAttachmentDetails details)
    throws AppException, InformationalException {

    // Case maintenance object
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.createCaseAttachmentDetails.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = caseKey.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kCreateSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Create the case attachment
    maintainAttachmentObj.insertCaseAttachmentDetails(
      details.createCaseAttachmentDetails);
  }

  // ___________________________________________________________________________
  /**
   * Creates a Case Owner with the new case owner details passed in.
   *
   * @param details
   * Details of the case owner.
   *
   * @throws AppException
   * {@link BPOCASEUSERROLE#ERR
   * ERR_CASEUSERROLE_XFV_INVALID_TYPE}
   * - if the case owner entered doesn't belong to the type selected.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createCaseOwner(final CreateCaseOwnerDetails details)
    throws AppException, InformationalException {

    final CaseUserRole caseUserRole = CaseUserRoleFactory.newInstance();

    // BEGIN, CR00001117, CM
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // BEGIN, CR00060051, PMD
    caseKey.caseID = details.caseHeaderKey.caseID;
    // END, CR00060051
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      ServicePlanSecurityImplementationFactory.register();
      servicePlanSecurityKey.caseID = details.caseHeaderKey.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // BEGIN, CR00060051, PMD
    final ReasonEndDateComments reasonEndDateComments = new ReasonEndDateComments();

    reasonEndDateComments.assign(details.reasonCodeAndCommentsDetails);
    caseHeaderKey.caseID = details.caseHeaderKey.caseID;
    
    // BEGIN, CR00387089, IBM
    final GenericBatchProcessInput genericBatchProcessInput = GenericBatchProcessInputFactory.newInstance();
    final BatchProcessDetails batchProcessDetails = new BatchProcessDetails();

    batchProcessDetails.batchProcessName = BATCHPROCESSNAMEEntry.BULK_CASE_REASSIGNMENTS.getCode();
    batchProcessDetails.recordID = caseHeaderKey.caseID;
    
    final Count count = genericBatchProcessInput.countQueuedRecordByID(
      batchProcessDetails);
    
    if (0 < count.numberOfRecords) {
      ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOBULKCASEREASSIGNMENT.ERR_CASE_ALREADY_QUEUED_FOR_REASSIGNMENT),
          ValidationManagerConst.kSetOne,
          1);
    }
    // END, CR00387089
    
    // BEIN, CR00081214, JM
    if (details.linkDtls.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

      // BEGIN, CR00280556, AKr
      if (0 != details.caseOwnerName.length()) {
        // BEGIN, CR00280410, AKr
        final UsersKey usersKey = new UsersKey();
        final NotFoundIndicator notFoundIndicator = new NotFoundIndicator();

        usersKey.userName = details.caseOwnerName;
        UsersFactory.newInstance().read(notFoundIndicator, usersKey);
        if (notFoundIndicator.isNotFound()) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
        } else {
          details.linkDtls.userName = details.caseOwnerName;
        }
      }
      // END, CR00280410
      // END, CR00280556
    } else if (details.linkDtls.orgObjectType.equals(ORGOBJECTTYPE.ORGUNIT)) {

      final OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();
      final OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

      try {
        // try parse the caseOwnerName value, if this throws an error it
        // means a
        // user name string value like 'superuser' has been passed down
        organisationUnitKey.organisationUnitID = Long.parseLong(
          details.caseOwnerName);

      } catch (final NumberFormatException e) {
        // BEGIN, CR00091611, JM
        throw new AppException(
          curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        // END, CR00091611
      }

      try {
        organisationUnitObj.read(organisationUnitKey);
        details.linkDtls.orgObjectReference = organisationUnitKey.organisationUnitID;
        // BEGIN, CR00161962, KY
        details.caseOwnerName = CuramConst.gkEmpty;
        details.linkDtls.userName = CuramConst.gkEmpty;
        // END, CR00161962

      } catch (final RecordNotFoundException e) {
        // BEGIN, CR00091611, JM
        throw new AppException(
          curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        // END, CR00091611
      }

    } else if (details.linkDtls.orgObjectType.equals(ORGOBJECTTYPE.POSITION)) {

      final Position positionObj = PositionFactory.newInstance();
      final PositionKey positionKey = new PositionKey();

      try {
        // try parse the caseOwnerName value, if this throws an error it
        // means a
        // user name string value like 'superuser' has been passed down
        positionKey.positionID = Long.parseLong(details.caseOwnerName);
      } catch (final NumberFormatException e) {
        // BEGIN, CR00091611, JM
        throw new AppException(
          curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        // END, CR00091611
      }
      try {
        positionObj.read(positionKey);
        details.linkDtls.orgObjectReference = positionKey.positionID;
      } catch (final RecordNotFoundException e) {
        // BEGIN, CR00091611, JM
        throw new AppException(
          curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        // END, CR00091611
      }
      // BEGIN, CR00161962, KY
      details.caseOwnerName = CuramConst.gkEmpty;
      details.linkDtls.userName = CuramConst.gkEmpty;
      // END, CR00161962
    } else if (details.linkDtls.orgObjectType.equals(ORGOBJECTTYPE.WORKQUEUE)) {

      final WorkQueue workQueueObj = WorkQueueFactory.newInstance();
      final WorkQueueKey workQueueKey = new WorkQueueKey();

      try {
        // try parse the caseOwnerName value, if this throws an error it
        // means a
        // user name string value like 'superuser' has been passed down
        workQueueKey.workQueueID = Long.parseLong(details.caseOwnerName);
      } catch (final NumberFormatException e) {
        // BEGIN, CR00091611, JM
        throw new AppException(
          curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        // END, CR00091611
      }
      try {
        workQueueObj.read(workQueueKey);
        details.linkDtls.orgObjectReference = workQueueKey.workQueueID;

      } catch (final RecordNotFoundException e) {
        // BEGIN, CR00091611, JM
        throw new AppException(
          curam.message.BPOCASEUSERROLE.ERR_CASEUSERROLE_XFV_INVALID_TYPE);
        // END, CR00091611
      }
      // BEGIN, CR00161962, KY
      details.caseOwnerName = CuramConst.gkEmpty;
      details.linkDtls.userName = CuramConst.gkEmpty;
      // END, CR00161962
    }
    // END, CR00081214
    caseUserRole.modifyWithNewOwner(caseHeaderKey, details.linkDtls,
      reasonEndDateComments);
    // END, CR00060051
    // BEGIN, CR00236662, PB
    if (details.linkDtls.orgObjectType.equals(ORGOBJECTTYPE.USER)) {
      RedetermineTranslatorStruct redetermineTranslatorStruct = new RedetermineTranslatorStruct();
      CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();

      redetermineTranslatorStruct.userName = details.caseOwnerName;
      redetermineTranslatorStruct.caseID = details.caseHeaderKey.caseID;
      caseParticipantRoleObj.redetermineTranslator(redetermineTranslatorStruct);
    } else {
      CaseParticipantRoleDtlsList casePaticipantRoleList = new CaseParticipantRoleDtlsList();
      CaseParticipantRole_eoCaseIDKey participantrolekey = new CaseParticipantRole_eoCaseIDKey();
      curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

      participantrolekey.caseID = details.caseHeaderKey.caseID;
      casePaticipantRoleList = caseParticipantRoleObj.searchByCaseID(
        participantrolekey);
      ModifyTranslatorRequiredDetails modifyTranslatorRequiredDetails = new ModifyTranslatorRequiredDetails();
      curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

      for (CaseParticipantRoleDtls dtls : casePaticipantRoleList.dtls) {
        caseParticipantRoleKey.caseParticipantRoleID = dtls.caseParticipantRoleID;
        modifyTranslatorRequiredDetails.caseParticipantRoleID = dtls.caseParticipantRoleID;
        modifyTranslatorRequiredDetails.translationRequiredInd = false;

        if (dtls.typeCode.equals(CASEPARTICIPANTROLETYPE.PRIMARY)
          || dtls.typeCode.equals(CASEPARTICIPANTROLETYPE.NOMINEE)
          || dtls.typeCode.equals(CASEPARTICIPANTROLETYPE.MEMBER)) {
          caseParticipantRoleObj.modifyTranslatorRequired(
            caseParticipantRoleKey, modifyTranslatorRequiredDetails);
        }
      }
    }
    // END, CR00236662
  }

  // ___________________________________________________________________________
  /**
   * Create a Case Supervisor.
   *
   * @param details
   * Details of the case supervisor.
   */
  public void createCaseSupervisor(final CreateCaseSupervisorDetails details)
    throws AppException, InformationalException {

    // CaseUserRole object and details
    final curam.core.sl.intf.CaseUserRole caseUserRole = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // BEGIN, CR00060051, PMD
    // BEGIN, CR00075609, SPD
    // modify supervisor structs
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final curam.core.sl.entity.struct.OrgObjectLinkDtls orgObjectLinkDtls = new curam.core.sl.entity.struct.OrgObjectLinkDtls();
    final ReasonEndDateComments reasonEndDateComments = new ReasonEndDateComments();

    // set caseID for modify
    caseHeaderKey.caseID = details.newAdminCaseRoleDtls.caseID;

    // Set the supervisor details
    orgObjectLinkDtls.orgObjectType = curam.codetable.ORGOBJECTTYPE.USER;
    orgObjectLinkDtls.userName = details.newAdminCaseRoleDtls.userName;

    // set reasonCode & comments details
    reasonEndDateComments.reasonCode = details.newAdminCaseRoleDtls.reasonCode;
    reasonEndDateComments.comments = details.newAdminCaseRoleDtls.comments;

    // Call CaseUserRole to create the new case supervisor
    caseUserRole.modifyWithNewSupervisor(caseHeaderKey, orgObjectLinkDtls,
      reasonEndDateComments);
    // END, CR00075609
    // END, CR00060051
  }

  // ___________________________________________________________________________
  /**
   * @param details
   * Case relationship details.
   * @deprecated Since Curam 6.0, replaced by {@link #createRelationship1()}
   *
   * Creates a Case Relationship.
   */
  @Deprecated
  public void createRelationship(final MaintainRelationshipDetails details)
    throws AppException, InformationalException {

    // MaintainRelatedCases manipulation variable
    final curam.core.intf.MaintainRelatedCases maintainRelatedCasesObj = curam.core.fact.MaintainRelatedCasesFactory.newInstance();

    // Call MaintainRelatedCases BPO to create the case relationship
    maintainRelatedCasesObj.createCaseRelationship(
      details.maintainCaseRelationshipDetails);
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of Admin Case Roles.
   *
   * @param key
   * Key to retrieve Admin Case Roles.
   *
   * @return List of Admin Case Roles.
   */
  public ListAdminCaseRoleDetails listAdminCaseRole(final ListAdminCaseRoleKey key)
    throws AppException, InformationalException {

    // Create instance of ListAdminCaseRoleDetails
    final ListAdminCaseRoleDetails listAdminCaseRoleDetails = new ListAdminCaseRoleDetails();

    // CaseUserRole object, key and list
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();
    final curam.core.sl.struct.CaseUserRoleCaseIDKey caseUserRoleCaseIDKey = new curam.core.sl.struct.CaseUserRoleCaseIDKey();
    curam.core.sl.struct.CaseUserRoleDetailsList caseUserRoleDetailsList;

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = key.maintainAdminCaseRolesKey.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = key.maintainAdminCaseRolesKey.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    caseUserRoleCaseIDKey.dtls.caseID = key.maintainAdminCaseRolesKey.caseID;

    // read CaseUserRole list
    caseUserRoleDetailsList = caseUserRoleObj.listCaseUserRoles(
      caseUserRoleCaseIDKey);

    // BEGIN, CR00187598, SS
    // If there is more than one user role for this case, then the initial
    // assignment to 'Pending Owner Work queue' must not be shown to the user.

    if (!caseUserRoleDetailsList.dtls.isEmpty()) {
      // BEGIN, CR00216640, GSP
      // retrieve environment variable
      final String dispWorkQueueAsOwnerInCaseUserRole = Configuration.getProperty(
        EnvVars.ENV_DISPLAYTEMPWORKQUEUEASOWNERINCASEUSERROLE);

      for (final CaseUserRoleDetails caseUserRoleDetails : caseUserRoleDetailsList.dtls.items()) {

        if (!(CuramConst.kTemporaryOwnerWorkqueueName.equalsIgnoreCase(
          caseUserRoleDetails.dtls.ownerDetails.orgObjectReferenceName)
            && dispWorkQueueAsOwnerInCaseUserRole.equalsIgnoreCase(
              EnvVars.ENV_VALUE_NO))) {

          listAdminCaseRoleDetails.caseUserRoleDetailsList.addRef(
            caseUserRoleDetails.dtls);
        }
      }
      // END, CR00216640, GSP
    }
    // END, CR00187598

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = key.maintainAdminCaseRolesKey.caseID;

    // Read context description and assign to output object
    listAdminCaseRoleDetails.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    // Set the case menu data
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseContextDescriptionKey.caseID;

    final CaseMenuData caseMenuData = getCaseMenuDataDetails(caseHeaderKey);

    // Will be not set for specific cases e.g. stand alone cases
    if (caseMenuData != null) {
      listAdminCaseRoleDetails.menuData.menuData = caseMenuData.menuData;
    }

    // BEGIN, CR00075853, MG
    // retrieve any informational messages
    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      listAdminCaseRoleDetails.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00075853
    return listAdminCaseRoleDetails;
  }

  // ___________________________________________________________________________
  /**
   * List all the attachments for a case.
   *
   * @param key
   * Contains case identifier.
   *
   * @return List of attachments for a case.
   */
  public ListCaseAttachmentDetails listCaseAttachment(final ListCaseAttachmentKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListCaseAttachmentDetails listCaseAttachmentDetails = new ListCaseAttachmentDetails();

    // MaintainAttachment manipulation variable
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = key.attachmentCaseID.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = caseKey.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Read the list of attachments
    listCaseAttachmentDetails.attachmentDetailsList = maintainAttachmentObj.readCaseAttachments(
      key.attachmentCaseID);

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = key.attachmentCaseID.caseID;

    // Read context description and assign to output object
    listCaseAttachmentDetails.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    // Set the case menu data
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseContextDescriptionKey.caseID;
    final CaseMenuData caseMenuData = getCaseMenuDataDetails(caseHeaderKey);

    // Will be not set for specific cases e.g. stand alone cases
    if (caseMenuData != null) {
      listCaseAttachmentDetails.menuData.menuData = caseMenuData.menuData;
    }

    return listCaseAttachmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * List case by person.
   *
   * @param key
   * concern role identifier
   *
   * @return List of cases by person found.
   */
  public ListCaseByPersonDetails listCaseByPerson(final ListCaseByPersonKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListCaseByPersonDetails listCaseByPersonDetails = new ListCaseByPersonDetails();

    // MaintainRelatedCases manipulation variable
    final curam.core.intf.MaintainRelatedCases maintainRelatedCasesObj = curam.core.fact.MaintainRelatedCasesFactory.newInstance();

    // Read list of case by person
    listCaseByPersonDetails.getAllCasesForPersonDtlsList = maintainRelatedCasesObj.getAllCasesForPerson(
      key.getAllCasesForPersonIn);

    return listCaseByPersonDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a list of relationship records for a case.
   *
   * @param key
   * Contains the case identifier.
   *
   * @return List of case relationships
   */
  public ListRelationshipDetails listRelationship(final ListRelationshipKey key)
    throws AppException, InformationalException {

    // Details to be returned
    final ListRelationshipDetails listRelationshipDetails = new ListRelationshipDetails();

    // MaintainRelatedCases manipulation variable
    final MaintainRelatedCases maintainRelatedCasesObj = MaintainRelatedCasesFactory.newInstance();

    // CaseHeader object
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseKey caseKey;
    CaseTypeCode caseTypeCode = new CaseTypeCode();
    final CaseIDAndTypeCodeKey caseIDAndTypeCodeKey = new CaseIDAndTypeCodeKey();
    RelatedCaseProductType relatedCaseProductType;

    // read list of Case Relationships
    listRelationshipDetails.getRelatedCasesList = maintainRelatedCasesObj.getRelatedCases(
      key.getRelatedCasesKey);

    // Check to see if the list is populated
    if (!listRelationshipDetails.getRelatedCasesList.dtls.isEmpty()) {

      // Reserve space in the return object
      listRelationshipDetails.getRelatedCasesList.dtls.ensureCapacity(
        listRelationshipDetails.getRelatedCasesList.dtls.size());

      // get caseTypeCode for each related case
      for (int i = 0; i
        < listRelationshipDetails.getRelatedCasesList.dtls.size(); i++) {

        caseKey = new CaseKey();
        caseKey.caseID = listRelationshipDetails.getRelatedCasesList.dtls.item(i).relatedCaseID;
        caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

        listRelationshipDetails.getRelatedCasesList.dtls.item(i).caseTypeCode = caseTypeCode.caseTypeCode;

        caseIDAndTypeCodeKey.caseID = listRelationshipDetails.getRelatedCasesList.dtls.item(i).relatedCaseID;
        caseIDAndTypeCodeKey.caseTypeCode = caseTypeCode.caseTypeCode;

        relatedCaseProductType = maintainRelatedCasesObj.getRelatedCaseProductType(
          caseIDAndTypeCodeKey);

        listRelationshipDetails.getRelatedCasesList.dtls.item(i).relatedCaseProductType = relatedCaseProductType.relatedCaseProductType;
      }
    } // END, HARP 37974

    // read the case context description
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = key.getRelatedCasesKey.caseID;

    listRelationshipDetails.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    // Return details
    return listRelationshipDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modify case attachment.
   *
   * @param details
   * Case Attachment details.
   */
  public void modifyCaseAttachment(final ModifyCaseAttachmentDetails details)
    throws AppException, InformationalException {

    // Case Attachment maintenance object
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.modifyAttachmentDetails.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = caseKey.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Modify the Case Attachment
    maintainAttachmentObj.modifyCaseAttachment(details.modifyAttachmentDetails);
  }

  // ___________________________________________________________________________
  /**
   * @param details
   * case relationship details.
   * @deprecated Since Curam 6.0, replaced by {@link #modifyRelationship1()}
   *
   * Modifies a Case Relationship.
   */
  @Deprecated
  public void modifyRelationship(final MaintainRelationshipDetails details)
    throws AppException, InformationalException {

    // Maintain Case relationship maintenance object
    final curam.core.intf.MaintainRelatedCases maintainRelatedCasesObj = curam.core.fact.MaintainRelatedCasesFactory.newInstance();

    // Case relationship maintenance object and key
    final curam.core.intf.CaseRelationship caseRelationshipObj = curam.core.fact.CaseRelationshipFactory.newInstance();
    final CaseRelationshipKey caseRelationshipKey = new CaseRelationshipKey();

    // Details returned from CaseRelationship.read
    CaseRelationshipDtls caseRelationshipDtls;

    caseRelationshipKey.caseRelationshipID = details.maintainCaseRelationshipDetails.caseRelationshipID;

    // Read the case relationship
    caseRelationshipDtls = caseRelationshipObj.read(caseRelationshipKey);

    if (caseRelationshipDtls.statusCode.equals(
      curam.codetable.RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERAL.ERR_GENERAL_FV_NO_MODIFY_RECORD_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          16);
    }

    // Modify Case Relationship
    maintainRelatedCasesObj.modifyCaseRelationship(
      details.maintainCaseRelationshipDetails);
  }

  // ___________________________________________________________________________
  /**
   * Read an Admin Case Role Details.
   *
   * @param key
   * Identifies an administration case role.
   *
   * @return Details of an administration case role
   */
  public ReadAdminCaseRoleDetails readAdminCaseRole(final ReadAdminCaseRoleKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadAdminCaseRoleDetails readAdminCaseRoleDetails = new ReadAdminCaseRoleDetails();

    // BEGIN, CR00060051, PMD
    // CaseUserRole object, key and details
    final curam.core.sl.entity.intf.CaseUserRole caseUserRoleObj = curam.core.sl.entity.fact.CaseUserRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseUserRoleKey caseUserRoleKey = new curam.core.sl.entity.struct.CaseUserRoleKey();
    curam.core.sl.entity.struct.CaseUserRoleDtls caseUserRoleDtls = new curam.core.sl.entity.struct.CaseUserRoleDtls();
    // BEGIN, CR00066677, CM
    final curam.core.sl.intf.CaseUserRole caseUserRoleSLObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();
    // END, CR00066677

    // BEGIN, CR00079264, CM
    // CaseOwnerDetails struct
    CaseOwnerDetails caseOwnerDetails = new CaseOwnerDetails();

    // END, CR00079264

    caseUserRoleKey.caseUserRoleID = key.maintainAdminCaseRoleIDKey.administrationCaseRoleID;

    // read case user role details
    caseUserRoleDtls = caseUserRoleObj.read(caseUserRoleKey);

    // BEGIN, CR00076914, SPD
    // if caseUserRole is of type supervisor, set indicator which will allow
    // us to display a conditional 'Edit' button to edit the supervisor
    // If the type is an owner, an 'Edit' button will not be displayed
    if (caseUserRoleDtls.typeCode.equals(CASEUSERROLETYPE.SUPERVISOR)) {

      // it is a supervisor, therefore set indicator
      readAdminCaseRoleDetails.supervisorInd = true;
    }
    // END, CR00076914

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    // BEGIN, CR00066677, CM
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // END, CR00066677

    // set case key
    caseKey.caseID = caseUserRoleDtls.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = caseUserRoleDtls.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // BEGIN, CR00066677, CM
    // Set the caseHeaderKey
    caseHeaderKey.caseID = caseUserRoleDtls.caseID;

    // BEGIN, CR00148805, ZV
    final OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();

    orgObjectLinkKey.orgObjectLinkID = caseUserRoleDtls.orgObjectLinkID;
    // END, CR00148805

    // BEGIN, CR00079264, CM
    // Check if it is a supervisor for the case
    // BEGIN, CR00089356, SPD
    if ((caseUserRoleDtls.typeCode.equals(CASEUSERROLETYPE.SUPERVISOR))
      || (caseUserRoleDtls.typeCode.equals(CASEUSERROLETYPE.REVIEWER))) {
      // END, CR00089356

      // BEGIN, CR00086435, SPD
      final curam.core.sl.intf.OrgObjectLink orgObjectLinkObj = curam.core.sl.fact.OrgObjectLinkFactory.newInstance();
      UserNameAndFullName userNameAndFullName = new UserNameAndFullName();

      // find userName & fullName for supervisor
      userNameAndFullName = orgObjectLinkObj.getUserNameFullName(
        orgObjectLinkKey);
      // END, CR00086435

      // set the case user role details for the supervisor or reviewer
      caseOwnerDetails.orgObjectReferenceName = userNameAndFullName.fullName;
      caseOwnerDetails.userName = userNameAndFullName.userName;
      caseOwnerDetails.userFullName = userNameAndFullName.fullName;

    } // Else it is the owner of the case
    else {
      // Read the case owner
      // BEGIN, CR00148805, ZV
      caseOwnerDetails = caseUserRoleSLObj.readOwnerName(orgObjectLinkKey);
      // END, CR00148805

      // if the type is a user
      if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

        // Set orgObjectReferenceName
        caseOwnerDetails.orgObjectReferenceName = caseOwnerDetails.userFullName;
      }
    }
    // END, CR00079264

    // Add to return object
    readAdminCaseRoleDetails.dtls.dtls.ownerDetails.assign(caseOwnerDetails);
    // END, CR00066677
    readAdminCaseRoleDetails.dtls.dtls.assign(caseUserRoleDtls);
    // END, CR00060051

    return readAdminCaseRoleDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads details of a case attachment.
   *
   * @param key
   * Key to read the case attachment details.
   *
   * @return Details of the case attachment.
   */
  public ReadAttachmentDetails readAttachment(final ReadAttachmentKey key)
    throws AppException, InformationalException {

    // Details to be returned
    final ReadAttachmentDetails readAttachmentDetails = new ReadAttachmentDetails();

    // MaintainAttachment manipulation variable
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory.newInstance();

    // Call MaintainAttachment BPO to read the attachment details
    readAttachmentDetails.readAttachmentOut = maintainAttachmentObj.readAttachment(
      key.readAttachmentIn);

    return readAttachmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * Read the details for a case attachment.
   *
   * @param key
   * case attachment identifier.
   *
   * @return Details of the case attachment.
   */
  public ReadCaseAttachmentDetails readCaseAttachment(
    final curam.core.facade.struct.ReadCaseAttachmentKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadCaseAttachmentDetails readCaseAttachmentDetails = new ReadCaseAttachmentDetails();

    // MaintainAttachment manipulation variable
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory.newInstance();

    // Call MaintainAttachment BPO to read the case attachment details
    readCaseAttachmentDetails.readCaseAttachmentOut = maintainAttachmentObj.readCaseAttachment(
      key.readCaseAttachmentIn);

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = readCaseAttachmentDetails.readCaseAttachmentOut.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = caseKey.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    return readCaseAttachmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReadIntegCaseAttachmentDetails readIntegCaseAttachment(
    final ReadIntegCaseAttachmentKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadIntegCaseAttachmentDetails readIntegCaseAttachmentDetails = new ReadIntegCaseAttachmentDetails();

    // MaintainAttachment manipulation variable
    final curam.core.intf.MaintainAttachment maintainAttachmentObj = curam.core.fact.MaintainAttachmentFactory.newInstance();

    // Call MaintainAttachment BPO to retrieve the case attachment details
    readIntegCaseAttachmentDetails.caseAttachmentDetailsList = maintainAttachmentObj.searchIntegCaseAttachments(
      key.attachmentCaseID);

    return readIntegCaseAttachmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * Case relationship identifier.
   *
   * @return Details of the case relationship.
   * @deprecated Since Curam 6.0, replaced by {@link #readRelationship1()}
   *
   * Reads a Case Relationship
   */
  @Deprecated
  public ReadRelationshipDetails readRelationship(final ReadRelationshipKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadRelationshipDetails readRelationshipDetails = new ReadRelationshipDetails();

    // BEGIN, CR00221300, ZV
    readRelationshipDetails.assign(readRelationship1(key));
    // END, CR00221300

    return readRelationshipDetails;
  }

  // BEGIN, CR00201195, ZV
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains the case search criteria.
   *
   * @return Details for the list of cases found.
   * @deprecated Since Curam 6.0, replaced by {@link #caseSearch1()}. This
   * method has been deprecated to introduce new case search
   * enhancements.
   *
   * Participant layer method to search for a case.
   */
  @Deprecated
  public CaseSearchList caseSearch(
    final curam.core.facade.struct.CaseReferenceSearchKey key) throws AppException,
      InformationalException {

    // Create return object
    final CaseSearchList caseSearchList = new CaseSearchList();

    // Case Search object.
    final curam.core.intf.CaseSearchRouter caseSearchRouterObj = curam.core.fact.CaseSearchRouterFactory.newInstance();

    // BEGIN, CR00077040, PMD
    caseSearchList.listDtls = caseSearchRouterObj.search(key.caseSearchCriteria);
    // END, CR00077040, PMD

    return caseSearchList;
  }

  // END, CR00201195

  // BEGIN, CR00049337, GOPA
  // ___________________________________________________________________________
  /**
   * Returns a CaseID
   *
   * @param key
   * contains Case Reference Number.
   *
   * @return CaseID for the Case Reference Number.
   */

  public CaseIDDetails getCaseID(final CaseReferenceSearchKey key)
    throws AppException, InformationalException {

    // Create return object
    final CaseIDDetails caseIDDtls = new CaseIDDetails();

    // CaseSearch manipulation variables
    final curam.core.intf.CaseSearch caseSearchObj = curam.core.fact.CaseSearchFactory.newInstance();
    final curam.core.struct.CaseReferenceSearchKey caseReferenceSearchKey = new curam.core.struct.CaseReferenceSearchKey();
    CaseSearchDetails caseSearchDetails;

    caseReferenceSearchKey.caseReference = key.caseReference;

    // Perform the search and map details to return object
    caseSearchDetails = caseSearchObj.readByCaseReference(
      caseReferenceSearchKey);

    caseIDDtls.caseID = caseSearchDetails.caseID;

    return caseIDDtls;
  }

  // END, CR00049337

  // BEGIN, CR00222438, MC
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains the case identifier.
   * @return List of communications on the case.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #listCaseCommunication()}.
   * The new method returns the same details but also returns
   * indicators that will be used to conditionally display list row
   * action appropriate to the event type.
   *
   * Case layer method to search for all communications by case ID.
   */
  @Deprecated
  public ListCommunicationsDtls listCaseCommunications(final ListCommunicationsKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListCommunicationsDtls listCommunicationsDtls = new ListCommunicationsDtls();

    // BEGIN, HARP, 35558, CC
    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj = curam.core.sl.fact.CommunicationFactory.newInstance();

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    checkServicePlanSecurity(key);

    final curam.core.sl.struct.CommunicationKey communicationKey = new curam.core.sl.struct.CommunicationKey();

    communicationKey.caseID = key.caseID;

    listCommunicationsDtls.caseCommunicationDetailsList = communicationObj.listCommunication(
      communicationKey);

    // Set key to read the context description
    caseContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to the return object
    listCommunicationsDtls.contextDescription.description = readCaseContextDescription(caseContextDescriptionKey).description;

    // Set the case menu data
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseContextDescriptionKey.caseID;

    final CaseMenuData caseMenuData = getCaseMenuDataDetails(caseHeaderKey);

    // Will be not set for specific cases e.g. stand alone cases
    if (caseMenuData != null) {
      listCommunicationsDtls.menuData.menuData = caseMenuData.menuData;
    }

    return listCommunicationsDtls;
  }

  // ___________________________________________________________________________
  /**
   * Lists all communications by case ID.
   *
   * @param key
   * Contains the case identifier.
   * @return List of communications on the case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public CommunicationDetailList listCaseCommunication(final ListCommunicationsKey key)
    throws AppException, InformationalException {

    final CommunicationDetailList communicationDetailList = new CommunicationDetailList();
    
    // BEGIN, CR00399621, KRK
    final ReadProFormaCommKey readProFormaCommKey = new ReadProFormaCommKey();
    // END, CR00399621

    // Communication service layer object
    final curam.core.sl.intf.Communication communicationObj = curam.core.sl.fact.CommunicationFactory.newInstance();

    checkServicePlanSecurity(key);

    final curam.core.sl.struct.CommunicationKey communicationKey = new curam.core.sl.struct.CommunicationKey();

    communicationKey.caseID = key.caseID;

    final CommunicationDetailsList communicationDtlsList = communicationObj.listCommunication(
      communicationKey);

    // Assign the details returned to a new struct that also contains the
    // display indicators and fields required for the actions
    String communicationFormat = "";
    CommunicationAndListRowActionDetails communicationDtls;

    // BEGIN, CR00294269, IBM
    for (final ConcernRoleCommRMDtls concernRoleCommRMDtls :
      communicationDtlsList.concernRoleCommList.dtls.items()) {
      // END, CR00294269

      communicationDtls = new CommunicationAndListRowActionDetails();

      // BEGIN, CR00294269, IBM
      communicationDtls.assign(concernRoleCommRMDtls);

      if (RECORDSTATUS.CANCELLED.equals(communicationDtls.statusCode)) {
        // END, CR00294269

        communicationDtls.canceledInd = true;

        // BEGIN, CR00303767, IBM
        // BEGIN, CR00399621, KRK
        if (COMMUNICATIONFORMAT.MSWORD.equals(
          communicationDtls.communicationFormat)) {
          communicationDtls.msWordInd = true;        
        } else if (COMMUNICATIONFORMAT.PROFORMA.equals(
          communicationDtls.communicationFormat)) {         
          readProFormaCommKey.proFormaCommKey.communicationID = communicationDtls.communicationID;
          communicationDtls.localeIdentifier = CommunicationFactory.newInstance().readProForma1(readProFormaCommKey).readProFormaCommDetails.localeIdentifier;
        }
        // END, CR00399621
        // END, CR00303767

      } else {
        communicationFormat = communicationDtls.communicationFormat;

        // BEGIN, CR00294269, IBM
        if (COMMUNICATIONFORMAT.EMAIL.equals(communicationFormat)
          && COMMUNICATIONSTATUS.DRAFT.equals(
            communicationDtls.communicationStatus)) {
          // END, CR00294269

          communicationDtls.draftEmailInd = true;

          // BEGIN, CR00294269, IBM
        } else if (COMMUNICATIONFORMAT.MSWORD.equals(communicationFormat)) {
          // END, CR00294269

          communicationDtls.msWordInd = true;

          final AttachmentLinkKey attachmentLinkKey = new AttachmentLinkKey();

          attachmentLinkKey.attachmentLinkID = communicationDtls.communicationID;

          AttachmentLinkDetails attachmentLinkDetails;

          try {
            attachmentLinkDetails = AttachmentFactory.newInstance().readAttachment(
              attachmentLinkKey);

            communicationDtls.attachmentDtls.attachmentName = attachmentLinkDetails.attachmentDtls.attachmentName;
            communicationDtls.attachmentDtls.attachmentContents = attachmentLinkDetails.attachmentDtls.attachmentContents;

          } catch (final RecordNotFoundException rnfe) {// Do nothing there are no attachments associated with this
            // communication
          }

          // BEGIN, CR00294269, IBM
        } else if (COMMUNICATIONFORMAT.PROFORMA.equals(communicationFormat)) {
          // END, CR00294269

          communicationDtls.proFormaInd = true;        
          
          // BEGIN, CR00399621, KRK
          readProFormaCommKey.proFormaCommKey.communicationID = communicationDtls.communicationID;
          communicationDtls.localeIdentifier = CommunicationFactory.newInstance().readProForma1(readProFormaCommKey).readProFormaCommDetails.localeIdentifier;
        }          
      }      
      // Get the delete page link
      communicationDtls.deletePage.deletePageName = curam.core.facade.fact.CommunicationFactory.newInstance().getDeletePageName(communicationDtls).deletePageName;
      // END, CR00399621
      
      // Add this list item to the return struct
      communicationDetailList.communicationDtls.addRef(communicationDtls);
    }

    return communicationDetailList;
  }

  // ___________________________________________________________________________
  /**
   * Check if the case is a service plan and if it is check its security.
   *
   * @param key
   * ListCommunicationsKey
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  protected void checkServicePlanSecurity(final ListCommunicationsKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = key.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = key.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
      // END, CR00001117

    }
  }

  // END, CR00222438

  // BEGIN, CR00139241, GYH
  /**
   * Retrieve list of cases by owner ID.
   *
   * @param key
   * current user identifier.
   *
   * @return List of cases by current user found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00139241
  public ListCaseByCurrentUserDetails listCaseByCurrentUser(
    final ListCaseByCurrentUserKey key) throws AppException, InformationalException {

    // Create return object
    final ListCaseByCurrentUserDetails listCaseByCurrentUserDetails = new ListCaseByCurrentUserDetails();

    // MaintainCase manipulation variable
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();

    // SystemUser manipulation variables
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Read the system user details
    systemUserDtls = systemUserObj.getUserDetails();

    // Populate ownerID value of key
    // Note in this instance the case owner will always be a user
    key.casesByOwnerKey.ownerID = systemUserDtls.userName;

    // Set status code
    key.casesByOwnerKey.statusCode = curam.codetable.CASESTATUSSEARCH.ALL;

    // Read list of case by current user
    final GetCasesByOwnerResult getCasesByOwnerResult = maintainCaseObj.getCasesByOwner(
      key.casesByOwnerKey);

    // Check if the list is populated
    if (!getCasesByOwnerResult.detailsList.dtls.isEmpty()) {

      // Reserve space in the return object
      listCaseByCurrentUserDetails.getCasesByOwnerResult.detailsList.dtls.ensureCapacity(
        getCasesByOwnerResult.detailsList.dtls.size());

      CaseHeaderOwnerDetails caseHeaderOwnerDetails;

      for (int i = 0; i < getCasesByOwnerResult.detailsList.dtls.size(); i++) {

        caseHeaderOwnerDetails = new CaseHeaderOwnerDetails();

        caseHeaderOwnerDetails.assign(
          getCasesByOwnerResult.detailsList.dtls.item(i));
        // BEGIN, CR00049218, GM
        String productTypeDesc = CuramConst.gkEmpty;
        // END, CR00049218

        final String caseTypeCode = getCasesByOwnerResult.detailsList.dtls.item(i).caseTypeCode;

        // BEGIN, CR00139241, GYH
        // Get the description for the type of the product
        if ((caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY))
          || (caseTypeCode.equals(CASETYPECODE.LIABILITY))) {

          // ProductDelivery manipulation variables
          final ProductDelivery productDeliveryObj = ProductDeliveryFactory.newInstance();
          final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
          ProductDeliveryTypeDetails productDeliveryTypeDetails = new ProductDeliveryTypeDetails();

          // populate key for read
          productDeliveryKey.caseID = getCasesByOwnerResult.detailsList.dtls.item(i).caseID;

          // read back productType for the case
          productDeliveryTypeDetails = productDeliveryObj.readProductType(
            productDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
            productDeliveryTypeDetails.productType,
            TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {

          // CaseHeader manipulation variables
          CaseHeaderDtls caseHeaderDtls;

          // Set key to read caseHeader
          final curam.core.intf.CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
          final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

          caseHeaderKey.caseID = getCasesByOwnerResult.detailsList.dtls.item(i).caseID;

          caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

          productTypeDesc = CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
            caseHeaderDtls.integratedCaseType,
            TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.SCREENINGCASE)) {

          // Screening manipulation variables
          final curam.core.sl.entity.intf.Screening screeningObj = curam.core.sl.entity.fact.ScreeningFactory.newInstance();
          final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
          ScreeningName screeningName;

          // Set key to read read Screening entity
          caseKeyStruct.caseID = getCasesByOwnerResult.detailsList.dtls.item(i).caseID;

          // Read Screening
          screeningName = screeningObj.readName(caseKeyStruct);

          productTypeDesc = CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
            screeningName.name, TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

          // assessmentDelivery manipulation variables
          final curam.core.sl.entity.intf.AssessmentDelivery assessmentDeliveryObj = curam.core.sl.entity.fact.AssessmentDeliveryFactory.newInstance();
          final AssessmentDeliveryKey assessmentDeliveryKey = new AssessmentDeliveryKey();
          AssessmentTypeDetails assessmentTypeDetails;

          // Set key to read Assessment type
          assessmentDeliveryKey.caseID = getCasesByOwnerResult.detailsList.dtls.item(i).caseID;

          // Read AssessmentType
          assessmentTypeDetails = assessmentDeliveryObj.readAssessmentType(
            assessmentDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(ASSESSMENTTYPE.TABLENAME,
            assessmentTypeDetails.assessmentType,
            TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

          // ServicePlan manipulation variables
          final curam.serviceplans.sl.entity.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory.newInstance();
          final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
          ServicePlanTypeStruct servicePlanTypeStruct = new ServicePlanTypeStruct();

          // populate key for read
          servicePlanDeliveryKey.caseID = getCasesByOwnerResult.detailsList.dtls.item(i).caseID;

          // read back servicePlanType
          servicePlanTypeStruct = servicePlanDeliveryObj.readServicePlanType(
            servicePlanDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(
            curam.codetable.SERVICEPLANTYPE.TABLENAME,
            servicePlanTypeStruct.servicePlanType,
            TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.ISSUE)) {

          // IssueDelivery manipulation variables
          final IssueDelivery issueDeliveryObj = curam.core.sl.entity.fact.IssueDeliveryFactory.newInstance();
          final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();
          IssueTypeCode issueTypeCode = new IssueTypeCode();

          // populate key for read
          issueDeliveryKey.caseID = getCasesByOwnerResult.detailsList.dtls.item(i).caseID;

          // read back issueTyoe
          issueTypeCode = issueDeliveryObj.readIssueType(issueDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(
            curam.codetable.ISSUECONFIGURATIONTYPE.TABLENAME,
            issueTypeCode.issueType, TransactionInfo.getProgramLocale());

        } else if (caseTypeCode.equals(CASETYPECODE.INVESTIGATIONCASE)) {

          // InvestigationDelivery manipulation variables
          final curam.core.sl.entity.intf.InvestigationDelivery investigationDelivery = curam.core.sl.entity.fact.InvestigationDeliveryFactory.newInstance();
          final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
          InvestigationTypeCode investigationTypeCode = new InvestigationTypeCode();

          // populate key for read
          investigationDeliveryKey.caseID = getCasesByOwnerResult.detailsList.dtls.item(i).caseID;

          // read back issueTyoe
          investigationTypeCode = investigationDelivery.readInvestigationType(
            investigationDeliveryKey);

          productTypeDesc = CodeTable.getOneItem(
            curam.codetable.INVESTIGATECONFIGTYPE.TABLENAME,
            investigationTypeCode.investigationType,
            TransactionInfo.getProgramLocale());
        }
        // END, CR00139241

        if (caseHeaderOwnerDetails.caseTypeCode.equals(
          CASETYPECODE.RESTRICTEDACCESS)) {
          // BEGIN, CR00163098, JC
          productTypeDesc = CodeTable.getOneItem(CASETYPECODE.TABLENAME,
            getCasesByOwnerResult.detailsList.dtls.item(i).productTypeDesc,
            TransactionInfo.getProgramLocale());
          // END, CR00163098, JC

        }

        // Product type description cannot be empty
        if (productTypeDesc == null || productTypeDesc.length() == 0) {
          // BEGIN, CR00163098, JC
          productTypeDesc = CodeTable.getOneItem(CASETYPECODE.TABLENAME,
            caseTypeCode, TransactionInfo.getProgramLocale());
          // END, CR00163098, JC
        }

        caseHeaderOwnerDetails.productTypeDesc = productTypeDesc;

        // Add to return object
        listCaseByCurrentUserDetails.getCasesByOwnerResult.detailsList.dtls.addRef(
          caseHeaderOwnerDetails);
      }

    }

    return listCaseByCurrentUserDetails;
  }

  // ___________________________________________________________________________
  /**
   * Creates a Case Note.
   *
   * @param details
   * case note details.
   */
  public void createNote(final InsertCaseNoteDetails details) throws AppException,
      InformationalException {

    // Case Note object
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.details.caseNoteDetails.caseNoteDetails.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = details.details.caseNoteDetails.caseNoteDetails.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kCreateSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Create the case note
    caseNoteObj.insert(details.details);
  }

  // BEGIN, CR00231506, PDN
  // ___________________________________________________________________________
  /**
   * Modifies a Case Note.
   *
   * @param details
   * Case note details
   * @deprecated - replaced by {@link #modifyNote1()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  public void modifyNote(final ModifyCaseNoteDetails details) throws AppException,
      InformationalException {

    // Case Note Object
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.details.caseNoteDetails.caseNoteDetails.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = details.details.caseNoteDetails.caseNoteDetails.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Modify the case note
    caseNoteObj.modify(details.details);
  }

  // ___________________________________________________________________________
  /**
   * Modifies a Case Note.
   *
   * @param details
   * Case note details
   */
  public void modifyNote1(final ModifyCaseNoteDetails1 details) throws AppException,
      InformationalException {
    // Case Note Object
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.details.caseNoteDetails.caseNoteDetails.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = details.details.caseNoteDetails.caseNoteDetails.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Modify the case note
    caseNoteObj.modify1(details.details);

  }

  // END, CR00231506

  // ___________________________________________________________________________
  /**
   * Cancels a Case Note.
   *
   * @param details
   * Case note details
   */
  public void cancelNote(final CancelCaseNoteDetails details) throws AppException,
      InformationalException {

    // Case Note Object
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // case note key
    final curam.core.sl.struct.CaseNoteKey caseNoteKey = new curam.core.sl.struct.CaseNoteKey();

    caseNoteKey.key.caseNoteID = details.details.key.caseNoteID;

    // set case key
    caseKey.caseID = caseNoteObj.readCaseID(caseNoteKey).key.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = caseKey.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Cancel the case note
    caseNoteObj.cancel(details.details);
  }

  // BEGIN, CR00231506, PDN
  // ___________________________________________________________________________
  /**
   * Retrieves a specific case note
   *
   * @param key
   * Identifies the note to be retrieved
   *
   * @return The details of the note
   * @deprecated - replaced by {@link #readNote1()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  public ReadCaseNoteDetails readNote(final CaseNoteKey key) throws AppException,
      InformationalException {

    // Create an object to return the details
    final ReadCaseNoteDetails readCaseNoteDetails = new ReadCaseNoteDetails();

    // Case Note Object
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();

    // Read case note details and assign to return object
    readCaseNoteDetails.details = caseNoteObj.read(key.key);

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = readCaseNoteDetails.details.noteDetails.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = readCaseNoteDetails.details.noteDetails.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    return readCaseNoteDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a specific case note
   *
   * @param key
   * Identifies the note to be retrieved
   *
   * @return The details of the note
   */
  public ReadCaseNoteDetails1 readNote1(final CaseNoteKey key) throws AppException,
      InformationalException {

    // Create an object to return the details
    final ReadCaseNoteDetails1 readCaseNoteDetails1 = new ReadCaseNoteDetails1();

    // Case Note Object
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();

    // Read case note details and assign to return object
    readCaseNoteDetails1.details = caseNoteObj.read1(key.key);

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = readCaseNoteDetails1.details.noteDetails.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = readCaseNoteDetails1.details.noteDetails.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    return readCaseNoteDetails1;
  }

  // END, CR00231506

  // ___________________________________________________________________________
  // BEGIN, CR00246976, SS
  // BEGIN, CR00170405, SS
  /**
   * Retrieves a list of case notes for a case.
   *
   * @param key
   * Contains the case identifier.
   *
   * @return A list of notes for the case.
   *
   * @deprecated Since 5.2 SP4, replaced with
   * {@link Case#listAccessibleNotes()}.
   * As the current method does not consider a note access
   * indicator, as going forward now it is required to consider a
   * note access indicator which will determine the accessibility of
   * notes. See release note: CR00246976.
   */
  @Deprecated
  // END, CR00246976
  public CaseNoteList listNote(final CaseKey_fo key) throws AppException,
      InformationalException {

    // Create an object to return the details
    final CaseNoteList caseNoteList = new CaseNoteList();

    // Case Note Object
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = key.key.key.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = key.key.key.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }

    // END, CR00001117
    // Read list of case notes and assign to return object
    caseNoteList.details = caseNoteObj.list(key.key);

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = key.key.key.caseID;

    // Read context description and assign to output object
    caseNoteList.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    // Set the case menu data
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseContextDescriptionKey.caseID;

    final CaseMenuData caseMenuData = getCaseMenuDataDetails(caseHeaderKey);

    // Will be not set for specific cases e.g. stand alone cases
    if (caseMenuData != null) {
      caseNoteList.menuData.menuData = caseMenuData.menuData;
    }

    return caseNoteList;
  }

  // END, CR00170405
  // ___________________________________________________________________________
  /**
   * Cancels a concern case role.
   *
   * @param key
   * Key to cancel the concern case role.
   */
  public void cancelClientRole(final CancelClientRoleKey key) throws AppException,
      InformationalException {

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.struct.CancelClientKey cancelClientKey = new curam.core.sl.struct.CancelClientKey();

    // assign details
    cancelClientKey.caseParticipantRoleID = key.concernCaseRoleID;

    // Call CaseParticipantRole BPO to cancel the concern case role
    caseParticipantRole_boObj.cancelCaseParticipantRole(cancelClientKey);

  }

  // ___________________________________________________________________________
  /**
   * Cancels a case member role.
   *
   * @param key
   * Key to cancel the concern case role.
   */
  public void cancelCaseMember(final CancelClientRoleKey key) throws AppException,
      InformationalException {

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.struct.CancelClientKey cancelClientKey = new curam.core.sl.struct.CancelClientKey();

    // assign details
    cancelClientKey.caseParticipantRoleID = key.concernCaseRoleID;

    // Call CaseParticipantRole BPO to cancel the concern case role
    caseParticipantRole_boObj.cancelCaseParticipantRole(cancelClientKey);

  }

  // ___________________________________________________________________________
  /**
   * Create a Case Appeal.
   *
   * @param details
   * Details of the Case Appeal being created.
   */
  public void createAppeal(final CreateAppealDetails details) throws AppException,
      InformationalException {

    // MaintainCaseAppeals manipulation variables
    final curam.core.intf.MaintainCaseAppeals maintainCaseAppealsObj = curam.core.fact.MaintainCaseAppealsFactory.newInstance();
    final MaintainCaseAppealDetails maintainCaseAppealDetails = new MaintainCaseAppealDetails();

    // Assign details to create the case appeal
    maintainCaseAppealDetails.assign(details);

    // Call MaintainCaseAppeals BPO to create the case appeal
    maintainCaseAppealsObj.createCaseAppeal(maintainCaseAppealDetails);
  }

  // ___________________________________________________________________________
  /**
   * Create a case referral.
   *
   * @param details
   * Details to create the case referral.
   */
  public void createReferral(final CreateReferralDetails details)
    throws AppException, InformationalException {

    // MaintainCaseReferral manipulation variables
    final curam.core.intf.MaintainCaseReferral maintainCaseReferralObj = curam.core.fact.MaintainCaseReferralFactory.newInstance();
    final MaintainCaseReferralDetails maintainCaseReferralDetails = new MaintainCaseReferralDetails();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

      // register the service plan security implementation
      curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = details.caseID;
      servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kCreateSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Assign details to create the case referral
    maintainCaseReferralDetails.assign(details);

    // Need to assign the reason text to the comments passed in.
    maintainCaseReferralDetails.reasonText = details.comments;

    // Call MaintainCaseReferral BPO to create the case referral
    maintainCaseReferralObj.createCaseReferral(maintainCaseReferralDetails);
  }

  // BEGIN, CR00224703, ZV
  // ___________________________________________________________________________
  /**
   * Creates a case review.
   *
   * @param details
   * Details of the case review.
   * @deprecated Since Curam 6.0, replaced by {@link #createReview1()}.
   */
  @Deprecated
  // ___________________________________________________________________________
  /**
   * Creates a case review.
   *
   * @param details
   * Details of the case review.
   */
  public void createReview(CreateReviewDetails details) throws AppException,
      InformationalException {

    // MaintainCaseReview manipulation variables
    curam.core.intf.MaintainCaseReview maintainCaseReviewObj = curam.core.fact.MaintainCaseReviewFactory.newInstance();
    MaintainCaseReviewDetails maintainCaseReviewDetails = new MaintainCaseReviewDetails();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.caseID;

    // read case type code
    CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

      // register the service plan security implementation
      curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = details.caseID;
      servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kCreateSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Assign review details
    maintainCaseReviewDetails.assign(details);

    // Call MaintainCaseReview BPO to create the case review.
    maintainCaseReviewObj.insertCaseReviewEvent(maintainCaseReviewDetails);
  }

  // END, CR00224703

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListAssessmentDetails listAssessment(final ListAssessmentKey key)
    throws AppException, InformationalException {

    // Create a business object
    final curam.core.intf.MaintainAssessments maintainAssessmentsObj = curam.core.fact.MaintainAssessmentsFactory.newInstance();

    // Create the return object
    final ListAssessmentDetails listAssessmentDetails = new ListAssessmentDetails();

    // Create a ViewCaseAssessmentListKey object and read in the caseID
    final ViewCaseAssessmentListKey viewCaseAssessmentListKey = new ViewCaseAssessmentListKey();

    viewCaseAssessmentListKey.caseID = key.caseID;

    // Read in the details into the return object
    listAssessmentDetails.assign(
      maintainAssessmentsObj.viewCaseAssessmentList(viewCaseAssessmentListKey));

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to output object
    listAssessmentDetails.caseContextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    // Return the details
    return listAssessmentDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a list of case relationship details for a case.
   *
   * @param key
   * The case ID to retrieve case relationship details
   *
   * @return A list of case relationship details for the case
   */
  public ListCaseRelationshipDetails listCaseRelationship(
    final ListCaseRelationshipKey key) throws AppException, InformationalException {

    return null;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * The case to retrieve client roles for
   *
   * @return A list of client roles for the case
   * @deprecated Since Curam 6.0 SP2, replaced by {@link #listClientRole1()}. This
   * method has been deprecated to introduce language translation requirement indicators.
   *
   * Retrieves a list of client roles for a case.
   */
  @Deprecated
  public ListClientRoleDetails listClientRole(final ListClientRoleKey key)
    throws AppException, InformationalException {

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList;
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // Details to be returned.
    final ListClientRoleDetails listClientRoleDetails = new ListClientRoleDetails();

    // Context description key
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    CaseContextDescription caseContextDescription;

    // Get the CaseID.
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Get the list of case participant role details.
    viewCaseParticipantRoleDetailsList = caseParticipantRole_boObj.viewCaseParticipantRoleList(
      viewCaseParticipantRole_boKey);

    // Assign the details.
    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      final CaseParticipantRole_eoFullDetails caseParticipantRoleFullDetails = new CaseParticipantRole_eoFullDetails();

      caseParticipantRoleFullDetails.assign(
        viewCaseParticipantRoleDetailsList.dtls.item(i));

      listClientRoleDetails.caseParticipantRoleList.addRef(
        caseParticipantRoleFullDetails);
    }

    caseContextDescriptionKey.caseID = key.caseID;

    // Read the context description
    caseContextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    listClientRoleDetails.contextDescription.assign(caseContextDescription);

    // Return the details.
    return listClientRoleDetails;
  }

  // BEGIN, CR00276833, ELG
  // ___________________________________________________________________________
  /**
   * Retrieves a list of client roles for a case.
   *
   * @param key
   * The case to retrieve client roles for
   *
   * @return A list of client roles for the case
   */
  public ListClientRoleDetails1 listClientRole1(final ListClientRoleKey key)
    throws AppException, InformationalException {

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_eoObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    curam.core.sl.entity.struct.CaseParticipantRoleKey caseParticipantRoleKey = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    // Details to be returned.
    final ListClientRoleDetails1 listClientRoleDetails1 = new ListClientRoleDetails1();

    // Context description key
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;

    // Get the list of case participant role details.
    final ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList = caseParticipantRole_boObj.viewCaseParticipantRoleList(
      viewCaseParticipantRole_boKey);

    // Assign the details.
    for (CaseParticipantRole_eoFullDetails listDetails : viewCaseParticipantRoleDetailsList.dtls) {

      final CaseParticipantRoleAndIndicatorDetails caseParticipantRoleAndIndicatorDetails = new CaseParticipantRoleAndIndicatorDetails();

      caseParticipantRoleAndIndicatorDetails.dtls = listDetails;

      caseParticipantRoleKey.caseParticipantRoleID = caseParticipantRoleAndIndicatorDetails.dtls.caseParticipantRoleID;
      caseParticipantRoleAndIndicatorDetails.translationRequiredInd = caseParticipantRole_eoObj.read(caseParticipantRoleKey).translationRequiredInd;

      if (caseParticipantRoleAndIndicatorDetails.dtls.typeCode.equals(
        CASEPARTICIPANTROLETYPE.PRIMARY)) {

        if (caseParticipantRoleAndIndicatorDetails.translationRequiredInd) {
          caseParticipantRoleAndIndicatorDetails.displayTranslatorNotRequiredInd = true;
          caseParticipantRoleAndIndicatorDetails.displayTranslatorRequiredInd = false;
        } else {
          caseParticipantRoleAndIndicatorDetails.displayTranslatorNotRequiredInd = false;
          caseParticipantRoleAndIndicatorDetails.displayTranslatorRequiredInd = true;
        }

      } else {

        caseParticipantRoleAndIndicatorDetails.displayTranslatorNotRequiredInd = false;
        caseParticipantRoleAndIndicatorDetails.displayTranslatorRequiredInd = false;

      }

      listClientRoleDetails1.listDtls.addRef(
        caseParticipantRoleAndIndicatorDetails);

    }

    caseContextDescriptionKey.caseID = key.caseID;

    // Read the context description
    listClientRoleDetails1.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    return listClientRoleDetails1;

  }

  // END, CR00276833

  // ___________________________________________________________________________
  /**
   * Returns a list of case events.
   *
   * @param key
   * Key to read the list of case events.
   *
   * @return List of case events.
   */
  public ListCaseEventDetails listEvent(final ListCaseEventKey key)
    throws AppException, InformationalException {

    // Create the return object
    final ListCaseEventDetails listCaseEventDetails = new ListCaseEventDetails();

    // ViewCaseEvents manipulation variables
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory.newInstance();
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();
    ViewCaseEventDetailsList viewCaseEventDetailsList;

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Assign the caseID and a blank type code to the key
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;
    // BEGIN, CR00049218, GM
    viewCaseEventsByCaseIDAndTypeKey.typeCode = CuramConst.gkEmpty;
    // END, CR00049218

    // Read in the list of events
    viewCaseEventDetailsList = viewCaseEventsObj.readEventsByType(
      viewCaseEventsByCaseIDAndTypeKey);

    // Assign the details to the return object
    listCaseEventDetails.assign(viewCaseEventDetailsList);

    // Set the type of the start and end date depending on the type code
    for (int i = 0; i < listCaseEventDetails.dtls.size(); i++) {
      // BEGIN, CR00163098, JC
      if (!listCaseEventDetails.dtls.item(i).typeCode.equals(
        CodeTable.getOneItem(CASEEVENTTYPE.TABLENAME, CASEEVENTTYPE.ACTIVITY))) {

        listCaseEventDetails.dtls.item(i).startDateStr = Locale.getFormattedDate(
          viewCaseEventDetailsList.dtls.item(i).startDateTime);

        if (!viewCaseEventDetailsList.dtls.item(i).endDateTime.isZero()) {

          listCaseEventDetails.dtls.item(i).endDateStr = Locale.getFormattedDate(
            viewCaseEventDetailsList.dtls.item(i).endDateTime);
        } else {
          // BEGIN, CR00049218, GM
          listCaseEventDetails.dtls.item(i).endDateStr = CuramConst.gkEmpty;
          // END, CR00049218
        }

      } else {

        listCaseEventDetails.dtls.item(i).startDateStr = Locale.getFormattedDateTime(
          viewCaseEventDetailsList.dtls.item(i).startDateTime);

        if (!viewCaseEventDetailsList.dtls.item(i).endDateTime.isZero()) {

          listCaseEventDetails.dtls.item(i).endDateStr = Locale.getFormattedDate(
            viewCaseEventDetailsList.dtls.item(i).endDateTime);
          CodeTable.getOneItem(CASEEVENTTYPE.TABLENAME, CASEEVENTTYPE.ACTIVITY,
            TransactionInfo.getProgramLocale());
          // END, CR00163098, JC
        } else {
          // BEGIN, CR00049218, GM
          listCaseEventDetails.dtls.item(i).endDateStr = CuramConst.gkEmpty;
          // END, CR00049218
        }

      }

    }

    // Set key to read the context description
    caseContextDescriptionKey.caseID = key.caseID;

    // Read the context description and assign to return object
    listCaseEventDetails.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    return listCaseEventDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modify a Case Appeal.
   *
   * @param details
   * Case Appeal details to be modified.
   */
  public void modifyAppeal(final ModifyAppealDetails details) throws AppException,
      InformationalException {

    // MaintainCaseAppeals manipulation variables
    final curam.core.intf.MaintainCaseAppeals maintainCaseAppealsObj = curam.core.fact.MaintainCaseAppealsFactory.newInstance();
    final MaintainCaseAppealDetails maintainCaseAppealDetails = new MaintainCaseAppealDetails();

    // Assign details to modify the case appeal
    maintainCaseAppealDetails.assign(details);

    // Call MaintainCaseAppeals BPO to modify the case appeal
    maintainCaseAppealsObj.modifyCaseAppeal(maintainCaseAppealDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modify the details for a case referral.
   *
   * @param details
   * Details to modify a case referral.
   */
  public void modifyReferral(final ModifyReferralDetails details)
    throws AppException, InformationalException {

    // MaintainCaseReferral manipulation variables
    final curam.core.intf.MaintainCaseReferral maintainCaseReferralObj = curam.core.fact.MaintainCaseReferralFactory.newInstance();
    final MaintainCaseReferralDetails maintainCaseReferralDetails = new MaintainCaseReferralDetails();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

      // register the service plan security implementation
      curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = details.caseID;
      servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kMaintainSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Assign details to modify the case referral
    maintainCaseReferralDetails.assign(details);
    maintainCaseReferralDetails.reasonText = details.comments;

    maintainCaseReferralDetails.eventID = details.caseEventID;

    // Call MaintainCaseReferral BPO to modify the case referral
    maintainCaseReferralObj.modifyCaseReferral(maintainCaseReferralDetails);
  }

  // BEGIN, CR00224703, ZV
  // ___________________________________________________________________________
  /**
   * Modifies the details of a case review.
   *
   * @param details
   * The case review details.
   * @deprecated Since Curam 6.0, replaced by {@link #modifyReview1()}.
   */
  @Deprecated
  public void modifyReview(ModifyReviewDetails details) throws AppException,
      InformationalException {

    // MaintainCaseReview manipulation variable
    curam.core.intf.MaintainCaseReview maintainCaseReviewObj = curam.core.fact.MaintainCaseReviewFactory.newInstance();
    MaintainCaseReviewDetails maintainCaseReviewDetails = new MaintainCaseReviewDetails();

    // Case review entity objects
    curam.core.intf.CaseReview caseReviewObj = curam.core.fact.CaseReviewFactory.newInstance();
    CaseReviewKey caseReviewKey = new CaseReviewKey();
    CaseReviewDtls caseReviewDtls;

    // Assign key details to read the case review
    caseReviewKey.caseReviewID = details.caseReviewID;

    // read case review event details.
    caseReviewDtls = caseReviewObj.read(caseReviewKey);

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = caseReviewDtls.caseID;

    // read case type code
    CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

      // register the service plan security implementation
      curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = caseReviewDtls.caseID;
      servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kMaintainSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Assign review details
    maintainCaseReviewDetails.assign(details);

    maintainCaseReviewDetails.caseID = caseReviewDtls.caseID;
    maintainCaseReviewDetails.typeCode = caseReviewDtls.typeCode;

    // Call the MaintainCaseReview BPO to modify the case review details.
    maintainCaseReviewObj.modifyCaseReviewEvent(maintainCaseReviewDetails);
  }

  // END, CR00224703

  // ___________________________________________________________________________
  /**
   * Reads Case Appeal details.
   *
   * @param key
   * Contains the identifier of the case appeal to be read.
   *
   * @return Case Appeal details.
   */
  public ReadAppealDtls readAppeal(final ReadAppealKey key) throws AppException,
      InformationalException {

    // Create return object
    final ReadAppealDtls readAppealDtls = new ReadAppealDtls();

    // MaintainCaseAppeals manipulation variables
    final curam.core.intf.MaintainCaseAppeals maintainCaseAppealsObj = curam.core.fact.MaintainCaseAppealsFactory.newInstance();
    final MaintainCaseAppealDetailsKey maintainCaseAppealDetailsKey = new MaintainCaseAppealDetailsKey();

    // Assign key details to read the Case Appeal
    maintainCaseAppealDetailsKey.assign(key);

    // Read Case Appeal details and assign to output object
    readAppealDtls.dtls.assign(
      maintainCaseAppealsObj.getAppealDetails(maintainCaseAppealDetailsKey));

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = readAppealDtls.dtls.caseID;

    // Read context description and assign to output object
    readAppealDtls.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    return readAppealDtls;
  }

  // ___________________________________________________________________________
  /**
   * Reads the case approval event details.
   *
   * @param key
   * Identifier to read the case approval event details.
   *
   * @return Case approval event details.
   */
  public ReadApprovalEventDetails readApprovalEvent(final ReadApprovalEventKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadApprovalEventDetails readApprovalEventDetails = new ReadApprovalEventDetails();

    // MaintainCaseApprovals manipulation variables
    final curam.core.intf.MaintainCaseApprovals maintainCaseApprovalsObj = curam.core.fact.MaintainCaseApprovalsFactory.newInstance();
    final GetApprovalDetailsKey getApprovalDetailsKey = new GetApprovalDetailsKey();

    final CaseApprovalIDStruct caseApprovalIDStruct = new CaseApprovalIDStruct();

    // ProductDeliveryContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read case approval event details
    getApprovalDetailsKey.caseApprovalID = key.caseApprovalID;

    final GetCaseApprovalDetailsResult getCaseApprovalDetailsResult = maintainCaseApprovalsObj.getCaseApprovalDetails(
      getApprovalDetailsKey);

    // Read the case approval event details and assign to return object
    readApprovalEventDetails.assign(getCaseApprovalDetailsResult);

    readApprovalEventDetails.approvalEventDetails.assign(
      getCaseApprovalDetailsResult.getApprovalDetails);

    // Set key to read case context description
    caseApprovalIDStruct.caseApprovalID = key.caseApprovalID;

    // Get the caseID
    final CaseApprovalCaseID caseApprovalCaseID = maintainCaseApprovalsObj.getCaseID(
      caseApprovalIDStruct);

    caseContextDescriptionKey.caseID = caseApprovalCaseID.dtls.caseID;

    readApprovalEventDetails.description = readCaseContextDescription(
      caseContextDescriptionKey);

    return readApprovalEventDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a Concern Case Role.
   *
   * @param key
   * Key to read concern case role details.
   *
   * @return Concern Case Role details.
   * @deprecated Since Curam 6.0, replaced by {@link #readClientRole1()} Since
   * the current method does not consider Translation Required
   * indicator, as going forward now it is required to consider
   * Translation Required indicator for case participant.
   */
  @Deprecated
  public ReadClientRoleDetails readClientRole(final ReadClientRoleKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadClientRoleDetails readClientRoleDetails = new ReadClientRoleDetails();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleFullDetails caseParticipantRoleFullDetails;
    final CaseParticipantRole_boKey caseParticipantRole_boKey = new CaseParticipantRole_boKey();

    // Set key to read Case Participant Role details
    caseParticipantRole_boKey.caseParticipantRoleID = key.concernCaseRoleID;

    // Read concern case role details
    caseParticipantRoleFullDetails = caseParticipantRole_boObj.viewCaseParticipantRole(
      caseParticipantRole_boKey);

    // Assign details to return object
    readClientRoleDetails.assign(caseParticipantRoleFullDetails.dtls);

    return readClientRoleDetails;
  }

  // BEGIN, CR00200171, PB
  // ___________________________________________________________________________
  /**
   * Reads the details of a Concern Case Role.
   *
   * @param key
   * Key to read concern case role details.
   *
   * @return Concern Case Role details.
   */
  public ReadClientRoleDetails1 readClientRole1(final ReadClientRoleKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00205110, PB
    final String locale = TransactionInfo.getProgramLocale();
    final curam.core.facade.struct.LanguageLocaleDetails languageLocaleDetails = new curam.core.facade.struct.LanguageLocaleDetails();
    final curam.core.sl.intf.LanguageLocaleMap languageLocaleMapObj = curam.core.sl.fact.LanguageLocaleMapFactory.newInstance();
    final LanguageLocaleMapKey languageLocaleMapKey = new LanguageLocaleMapKey();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;
    // END, CR00205110
    // Create return object
    final ReadClientRoleDetails1 readClientRoleDetails1 = new ReadClientRoleDetails1();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleFullDetails1 caseParticipantRoleFullDetails1;
    final CaseParticipantRole_boKey caseParticipantRole_boKey = new CaseParticipantRole_boKey();

    // Set key to read Case Participant Role details
    caseParticipantRole_boKey.caseParticipantRoleID = key.concernCaseRoleID;

    // Read concern case role details
    caseParticipantRoleFullDetails1 = caseParticipantRole_boObj.viewCaseParticipantRole1(
      caseParticipantRole_boKey);

    // Assign details to return object
    readClientRoleDetails1.assign(caseParticipantRoleFullDetails1.dtls);
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // BEGIN, CR00205110, PB
    concernRoleKey.concernRoleID = caseParticipantRoleFullDetails1.dtls.participantRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    if (concernRoleDtls.concernRoleType.equals(CONCERNROLETYPE.PERSON)
      || concernRoleDtls.concernRoleType.equals(CONCERNROLETYPE.PROSPECTPERSON)) {

      readClientRoleDetails1.translatorDisplayInd = true;

      readClientRoleDetails1.preferredLanguage = concernRoleDtls.preferredLanguage;

      languageLocaleMapKey.key.key.languageCode = concernRoleDtls.preferredLanguage;
      try {
        languageLocaleDetails.dtls = languageLocaleMapObj.readLanguageLocaleMap(
          languageLocaleMapKey.key);
      } catch (final RecordNotFoundException e) {// Ignored
      }
      if (readClientRoleDetails1.translationRequiredInd
        || (!readClientRoleDetails1.translationRequiredInd
          && !locale.equals(languageLocaleDetails.dtls.localeIdentifier))) {
        readClientRoleDetails1.prefLanguageInd = true;
      }
    }
    // END, CR00205110
    // BEGIN, CR00235514, PB
    if (!readClientRoleDetails1.translationRequiredInd) {
      readClientRoleDetails1.translationRequiredInd = false;
    }
    // END, CR00235514

    return readClientRoleDetails1;
  }

  // END, CR00200171

  // ___________________________________________________________________________
  /**
   * Reads the details of a case member.
   *
   * @param key
   * Key to read concern case role details.
   *
   * @return Concern Case Role details.
   *
   * @deprecated Since Curam 6.0, replaced by {@link #readCaseMember1()}. Since
   * the current method does not consider Translation Required
   * indicator, as going forward now it is required to consider
   * Translation Required indicator for case participant.
   */
  @Deprecated
  public ReadClientRoleDetails readCaseMember(final ReadClientRoleKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadClientRoleDetails readClientRoleDetails = new ReadClientRoleDetails();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleFullDetails caseParticipantRoleFullDetails;
    final CaseParticipantRole_boKey caseParticipantRole_boKey = new CaseParticipantRole_boKey();

    // Set key to read Case Participant Role details
    caseParticipantRole_boKey.caseParticipantRoleID = key.concernCaseRoleID;

    // Read concern case role details
    caseParticipantRoleFullDetails = caseParticipantRole_boObj.viewCaseParticipantRole(
      caseParticipantRole_boKey);

    // Assign details to return object
    readClientRoleDetails.caseID = caseParticipantRoleFullDetails.dtls.caseID;
    readClientRoleDetails.caseParticipantRoleID = caseParticipantRoleFullDetails.dtls.caseParticipantRoleID;
    readClientRoleDetails.concernRoleType = caseParticipantRoleFullDetails.dtls.participantRoleType;
    readClientRoleDetails.endDate = caseParticipantRoleFullDetails.dtls.toDate;
    readClientRoleDetails.name = caseParticipantRoleFullDetails.dtls.name;
    readClientRoleDetails.startDate = caseParticipantRoleFullDetails.dtls.fromDate;
    readClientRoleDetails.recordStatus = caseParticipantRoleFullDetails.dtls.recordStatus;
    readClientRoleDetails.participantRoleID = caseParticipantRoleFullDetails.dtls.participantRoleID;
    readClientRoleDetails.type = caseParticipantRoleFullDetails.dtls.typeCode;
    readClientRoleDetails.versionNo = caseParticipantRoleFullDetails.dtls.versionNo;
    readClientRoleDetails.comments = caseParticipantRoleFullDetails.dtls.comments;
    // BEGIN, CR00109196 PA
    readClientRoleDetails.endReason = caseParticipantRoleFullDetails.dtls.endReason;
    // END, CR00109196, PA

    return readClientRoleDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads the details of a case referral.
   *
   * @param key
   * Contains case referral identifier.
   *
   * @return Details of the case referral
   */
  public ReadReferralDtls readReferral(final ReadReferralKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadReferralDtls readReferralDtls = new ReadReferralDtls();
    // MaintainCaseReferral manipulation variables
    final curam.core.intf.MaintainCaseReferral maintainCaseReferralObj = curam.core.fact.MaintainCaseReferralFactory.newInstance();
    final MaintainCaseReferralKey maintainCaseReferralKey = new MaintainCaseReferralKey();

    // Set key to read case referral details
    maintainCaseReferralKey.caseReferralID = key.caseReferralID;

    // Read the referral details and assign to return object
    final MaintainCaseReferralDetails maintainCaseReferralDetails = maintainCaseReferralObj.getCaseReferralDetails(
      maintainCaseReferralKey);

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = maintainCaseReferralDetails.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

      // register the service plan security implementation
      curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = maintainCaseReferralDetails.caseID;
      servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    readReferralDtls.dtls.assign(maintainCaseReferralDetails);
    readReferralDtls.dtls.comments = maintainCaseReferralDetails.reasonText;

    // Manually assign case eventID
    readReferralDtls.dtls.caseEventID = maintainCaseReferralDetails.eventID;

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = readReferralDtls.dtls.caseID;

    // Read context description and assign to output object
    readReferralDtls.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    return readReferralDtls;
  }

  // BEGIN, CR00224703, ZV
  // ___________________________________________________________________________
  /**
   * Reads details of a case review.
   *
   * @param key
   * Key to read the case review details.
   *
   * @return Case review details
   * @deprecated Since Curam 6.0, replaced by {@link #readReview1()}.
   */
  @Deprecated
  public ReadReviewDtls readReview(final ReadReviewKey key)
    throws AppException, InformationalException {

    // Create a return object
    final ReadReviewDtls readReviewDtls = new ReadReviewDtls();
    // MaintainCaseReview manipulation variables
    final curam.core.intf.MaintainCaseReview maintainCaseReviewObj = curam.core.fact.MaintainCaseReviewFactory.newInstance();
    final MaintainCaseReviewKey maintainCaseReviewKey = new MaintainCaseReviewKey();

    // Case event object
    final curam.core.intf.CaseEvent caseEventObj = curam.core.fact.CaseEventFactory.newInstance();

    // CaseEventNSReadKey object
    final CaseEventNSReadKey caseEventNSReadKey = new CaseEventNSReadKey();

    // CaseEventNSReadDetails object
    CaseEventNSReadDetails caseEventNSReadDetails;

    // Populate caseEventNSReadKey
    caseEventNSReadKey.relatedID = key.caseReviewID;

    // Get the case event details for this review
    caseEventNSReadDetails = caseEventObj.readByRelatedID(caseEventNSReadKey);

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = caseEventNSReadDetails.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final curam.serviceplans.facade.struct.ServicePlanSecurityKey servicePlanSecurityKey = new curam.serviceplans.facade.struct.ServicePlanSecurityKey();

      // register the service plan security implementation
      curam.serviceplans.sl.impl.ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = caseEventNSReadDetails.caseID;
      servicePlanSecurityKey.securityCheckType = curam.serviceplans.sl.impl.ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Populate the maintainCaseReviewKey with the case event ID.
    maintainCaseReviewKey.caseEventID = caseEventNSReadDetails.caseEventID;

    // Assign key details to read the case review
    maintainCaseReviewKey.caseReviewID = key.caseReviewID;

    // Call MaintainCaseReview BPO to read the case review details and
    // assign
    // to return object
    readReviewDtls.dtls.assign(
      maintainCaseReviewObj.viewCaseReviewEvent(maintainCaseReviewKey));

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = caseEventNSReadDetails.caseID;

    // Read context description and assign to output object
    readReviewDtls.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    return readReviewDtls;
  }

  // END, CR00224703

  // BEGIN, CR00200171, PB
  // ___________________________________________________________________________
  /**
   * Reads the details of a case member.
   *
   * @param key
   * Key to read concern case role details.
   *
   * @return Concern Case Role details.
   */
  public ReadClientRoleDetails1 readCaseMember1(final ReadClientRoleKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00205110, PB
    final String locale = TransactionInfo.getProgramLocale();
    final curam.core.facade.struct.LanguageLocaleDetails languageLocaleDetails = new curam.core.facade.struct.LanguageLocaleDetails();
    final curam.core.sl.intf.LanguageLocaleMap languageLocaleMapObj = curam.core.sl.fact.LanguageLocaleMapFactory.newInstance();
    final LanguageLocaleMapKey languageLocaleMapKey = new LanguageLocaleMapKey();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;
    // END, CR00205110
    // Create return object
    final ReadClientRoleDetails1 readClientRoleDetails1 = new ReadClientRoleDetails1();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    CaseParticipantRoleFullDetails1 caseParticipantRoleFullDetails1;
    final CaseParticipantRole_boKey caseParticipantRole_boKey = new CaseParticipantRole_boKey();

    // Set key to read Case Participant Role details
    caseParticipantRole_boKey.caseParticipantRoleID = key.concernCaseRoleID;

    // Read concern case role details
    caseParticipantRoleFullDetails1 = caseParticipantRole_boObj.viewCaseParticipantRole1(
      caseParticipantRole_boKey);

    // Assign details to return object
    readClientRoleDetails1.caseID = caseParticipantRoleFullDetails1.dtls.caseID;
    readClientRoleDetails1.caseParticipantRoleID = caseParticipantRoleFullDetails1.dtls.caseParticipantRoleID;
    readClientRoleDetails1.concernRoleType = caseParticipantRoleFullDetails1.dtls.participantRoleType;
    readClientRoleDetails1.endDate = caseParticipantRoleFullDetails1.dtls.toDate;
    readClientRoleDetails1.name = caseParticipantRoleFullDetails1.dtls.name;
    readClientRoleDetails1.startDate = caseParticipantRoleFullDetails1.dtls.fromDate;
    readClientRoleDetails1.recordStatus = caseParticipantRoleFullDetails1.dtls.recordStatus;
    readClientRoleDetails1.participantRoleID = caseParticipantRoleFullDetails1.dtls.participantRoleID;
    readClientRoleDetails1.type = caseParticipantRoleFullDetails1.dtls.typeCode;
    readClientRoleDetails1.versionNo = caseParticipantRoleFullDetails1.dtls.versionNo;
    readClientRoleDetails1.comments = caseParticipantRoleFullDetails1.dtls.comments;
    readClientRoleDetails1.translationRequiredInd = caseParticipantRoleFullDetails1.dtls.translationRequiredInd;
    readClientRoleDetails1.endReason = caseParticipantRoleFullDetails1.dtls.endReason;

    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // BEGIN, CR00213628, PB
    if (!readClientRoleDetails1.translationRequiredInd) {
      final LocalisableString confirmMessage = new LocalisableString(
        FACADERESOURCE.INF_TRANSLATOR_REQUIRED_INDICATOR);

      readClientRoleDetails1.confirmMessage = confirmMessage.getMessage(
        TransactionInfo.getProgramLocale());
    } else {
      final LocalisableString confirmMessage = new LocalisableString(
        FACADERESOURCE.INF_TRANSLATOR_NOT_REQUIRED_INDICATOR);

      readClientRoleDetails1.confirmMessage = confirmMessage.getMessage(
        TransactionInfo.getProgramLocale());
    }

    // END, CR00213628

    // BEGIN, CR00205110, PB
    concernRoleKey.concernRoleID = caseParticipantRoleFullDetails1.dtls.participantRoleID;
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    if (concernRoleDtls.concernRoleType.equals(CONCERNROLETYPE.PERSON)
      || concernRoleDtls.concernRoleType.equals(CONCERNROLETYPE.PROSPECTPERSON)) {
      readClientRoleDetails1.translatorDisplayInd = true;
      readClientRoleDetails1.preferredLanguage = concernRoleDtls.preferredLanguage;

      languageLocaleMapKey.key.key.languageCode = concernRoleDtls.preferredLanguage;
      try {
        languageLocaleDetails.dtls = languageLocaleMapObj.readLanguageLocaleMap(
          languageLocaleMapKey.key);
      } catch (final RecordNotFoundException e) {// Ignored
      }
      if (readClientRoleDetails1.translationRequiredInd
        || (!readClientRoleDetails1.translationRequiredInd
          && !locale.equals(languageLocaleDetails.dtls.localeIdentifier))) {
        readClientRoleDetails1.prefLanguageInd = true;
      }
    }
    // END, CR00205110
    // BEGIN, CR00235514, PB
    if (!readClientRoleDetails1.translationRequiredInd) {
      readClientRoleDetails1.translationRequiredInd = false;
    }
    // END, CR00235514
    return readClientRoleDetails1;
  }

  // END, CR00200171

  // BEGIN, CR00190939, GD
  // ___________________________________________________________________________
  /**
   * @param caseNomineeCaseIDKey
   * contains caseID
   *
   * @return list of all objectives for this case and details of the participant
   * to whom each is assigned
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listObjectiveAndDelPattern()}.
   *
   * Method to list all Objectives available for a case
   */
  @Deprecated
  // END, CR00190939
  public CaseNomineeObjectiveNameDetailsList listObjective(
    final CaseNomineeCaseIDKey caseNomineeCaseIDKey) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // return structure
    final CaseNomineeObjectiveNameDetailsList caseNomineeObjectiveNameDetailsList = new CaseNomineeObjectiveNameDetailsList();

    // read list from service layer into return struct
    caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList = caseNomineeObj.listObjective(
      caseNomineeCaseIDKey.caseNomineeCaseIDKey);

    // read context description
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID;

    caseNomineeObjectiveNameDetailsList.caseContextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    return caseNomineeObjectiveNameDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * Method to list all objectives for a case and their current delivery pattern
   *
   * @param caseNomineeCaseIDKey
   * contains caseID
   *
   * @return List of all objectives for this case, the details of the
   * participant to whom each is assigned and the current delivery
   * pattern for each objective.
   */
  public CaseNomObjectiveAndDelPatternDetailsList listObjectiveAndDelPattern(
    final CaseNomineeCaseIDKey caseNomineeCaseIDKey) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    return caseNomineeObj.listObjectiveAndDelPattern(
      caseNomineeCaseIDKey.caseNomineeCaseIDKey);
  }

  // ___________________________________________________________________________
  /**
   * Method to return CaseNominee context description.
   *
   * @param caseNomineeContextDescriptionKey
   * Contains caseNomineeID
   *
   * @return Case nominee context description
   */
  @Override
  protected CaseNomineeContextDescription_fo readCaseNomineeContextDescription(
    final CaseNomineeContextDescriptionKey caseNomineeContextDescriptionKey)
    throws AppException, InformationalException {

    final CaseNomineeContextDescription_fo caseNomineeContextDescription = new CaseNomineeContextDescription_fo();

    final curam.core.sl.entity.struct.CaseNomineeViewKey caseNomineeViewKey = new curam.core.sl.entity.struct.CaseNomineeViewKey();
    curam.core.sl.entity.struct.CaseNomineeDetails caseNomineeDetails;
    final curam.core.sl.entity.intf.CaseNominee caseNomineeObj = curam.core.sl.entity.fact.CaseNomineeFactory.newInstance();

    curam.core.sl.entity.struct.DefaultCaseNomineeDetails defaultCaseNomineeDetails = new curam.core.sl.entity.struct.DefaultCaseNomineeDetails();
    final curam.core.sl.entity.struct.DefaultCaseNomineeKey defaultCaseNomineeKey = new curam.core.sl.entity.struct.DefaultCaseNomineeKey();

    caseNomineeViewKey.caseNomineeID = caseNomineeContextDescriptionKey.caseNomineeID;

    caseNomineeDetails = caseNomineeObj.readCaseNomineeDetails(
      caseNomineeViewKey);

    caseNomineeContextDescription.nomineeName = caseNomineeDetails.concernRoleName;

    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();
    CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName;

    caseIDKey.caseID = caseNomineeDetails.caseID;

    caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
      caseIDKey);

    if (caseNomineeDetails.defaultNomInd == true) {

      caseNomineeContextDescription.description = caseReferenceProductNameConcernRoleName.productName
        + kSpace + caseReferenceProductNameConcernRoleName.caseReference // BEGIN,
        // CR00098942,
        // SAI
        + kSpace
        // BEGIN, CR00222190, ELG
        + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
          TransactionInfo.getProgramLocale())
          // END, CR00222190
          // END, CR00098942
          + caseNomineeDetails.concernRoleName
          + kSpace
          + caseNomineeDetails.alternateID;

    } else {

      defaultCaseNomineeKey.caseID = caseNomineeDetails.caseID;
      defaultCaseNomineeKey.defaultNomInd = true;

      defaultCaseNomineeDetails = caseNomineeObj.readDefaultCaseNominee(
        defaultCaseNomineeKey);

      caseNomineeContextDescription.description = caseReferenceProductNameConcernRoleName.productName
        + kSpace + caseReferenceProductNameConcernRoleName.caseReference // BEGIN,
        // CR00098942,
        // SAI
        + kSpace
        // BEGIN, CR00222190, ELG
        + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
          TransactionInfo.getProgramLocale())
          // END, CR00222190
          // END, CR00098942
          + defaultCaseNomineeDetails.concernRoleName
          + kSpace
          + defaultCaseNomineeDetails.primaryAlternateID;

    }

    return caseNomineeContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * @param assignObjectiveKey
   * contains caseID, caseNomineeID, objectiveID and from date
   * @deprecated Since Curam 6.0, replaced by {@link #assignObjective1()}. This
   * method as been deprecated to remove setting the start date
   * logic currently found in the original method.
   *
   * Method to assign the receipt of an objective from one
   * CaseNominee to another.
   */
  @Deprecated
  public InformationMsgDtlsList assignObjective(
    final AssignObjectiveKey assignObjectiveKey) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseStartDate caseStartDate = new CaseStartDate();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // variables used to read objective assignments
    final curam.core.sl.entity.intf.CaseNomineeObjective caseNomineeObjectiveObj = curam.core.sl.entity.fact.CaseNomineeObjectiveFactory.newInstance();
    ObjectiveHistoryDetailsList objectiveHistoryDetailsList;
    final curam.core.sl.entity.struct.CaseObjectiveKey caseObjectiveKey = new curam.core.sl.entity.struct.CaseObjectiveKey();

    if (assignObjectiveKey.assignObjectiveKey.fromDate.isZero()) {

      // Going to set the start date to the case start date
      caseHeaderKey.caseID = assignObjectiveKey.assignObjectiveKey.caseID;
      caseStartDate = caseHeaderObj.readStartDate(caseHeaderKey);

      // Need to set up search key
      caseObjectiveKey.rulesObjectiveID = assignObjectiveKey.assignObjectiveKey.rulesObjectiveID;
      caseObjectiveKey.fromDate = caseStartDate.startDate;
      caseObjectiveKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
      caseObjectiveKey.caseID = assignObjectiveKey.assignObjectiveKey.caseID;

      // retrieve list from entity
      objectiveHistoryDetailsList = caseNomineeObjectiveObj.searchObjectiveHistoryForCase(
        caseObjectiveKey);

      if (objectiveHistoryDetailsList.dtls.isEmpty()) {

        // Going to set the start date to the case start date as this is
        // the
        // first explicit assignment
        assignObjectiveKey.assignObjectiveKey.fromDate = caseStartDate.startDate;
        assignObjectiveKey.assignObjectiveKey.fromCaseStartDateInd = true;
      }

    }

    // call service layer method
    caseNomineeObj.assignObjective(assignObjectiveKey.assignObjectiveKey);

    // BEGIN, CR00001839, SD
    // create return object.
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // return all informational messages
    return informationMsgDtlsList;
    // END, CR00001839

  }

  // BEGIN, CR00190939, GD
  // BEGIN, CR00180791, SPD
  // ___________________________________________________________________________
  /**
   * Method to assign the receipt of an objective from one CaseNominee to
   * another.
   *
   * @param assignObjectiveAndDelPattKey
   * contains caseID, caseNomineeID, objectiveID and from date
   */
  public InformationMsgDtlsList assignObjective1(
    final AssignObjectiveAndDelPattKey assignObjectiveAndDelPattKey)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // CaseHeader manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseStartDate caseStartDate = new CaseStartDate();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    final curam.core.sl.struct.AssignObjectiveKey assignObjectiveKey = new curam.core.sl.struct.AssignObjectiveKey();

    assignObjectiveKey.caseID = assignObjectiveAndDelPattKey.caseID;
    assignObjectiveKey.caseNomineeID = assignObjectiveAndDelPattKey.caseNomineeID;
    assignObjectiveKey.fromCaseStartDateInd = assignObjectiveAndDelPattKey.fromCaseStartDateInd;
    assignObjectiveKey.fromDate = assignObjectiveAndDelPattKey.fromDate;
    assignObjectiveKey.rulesObjectiveID = assignObjectiveAndDelPattKey.rulesObjectiveID;

    // Populate correct caseNomineeID based on delivery pattern selected
    if (assignObjectiveAndDelPattKey.productDeliveryPatternID != 0) {
      final CaseNomineeDeliveryPatternKey caseNomineeDeliveryPatternKey = new CaseNomineeDeliveryPatternKey();

      caseNomineeDeliveryPatternKey.caseNomineeID = assignObjectiveAndDelPattKey.caseNomineeID;
      final curam.core.sl.struct.CaseNomineeDeliveryPatternDetailsList deliveryPatternList = caseNomineeObj.listCurrentDeliveryPattern(
        caseNomineeDeliveryPatternKey);

      for (int i = 0; i < deliveryPatternList.dtls.size(); i++) {
        if (deliveryPatternList.dtls.item(i).productDeliveryPatternID
          == assignObjectiveAndDelPattKey.productDeliveryPatternID) {

          assignObjectiveKey.caseNomineeID = deliveryPatternList.dtls.item(i).caseNomineeID;
          break;
        }
      }
    }

    caseNomineeObj.validateComponentAssignmentStartDate(assignObjectiveKey);

    if (assignObjectiveAndDelPattKey.fromCaseStartDateInd == true) {

      // Going to set the start date to the case start date
      caseHeaderKey.caseID = assignObjectiveAndDelPattKey.caseID;
      caseStartDate = caseHeaderObj.readStartDate(caseHeaderKey);

      assignObjectiveKey.fromDate = caseStartDate.startDate;
    }

    // BEGIN, CR00211744, VM
    assessmentEngine.assignObjective(assignObjectiveKey);
    // END, CR00211744

    // Create return object.
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // END, CR00180791
  // END, CR00190939

  // ___________________________________________________________________________
  /**
   * @param caseNomineeCreationDetails
   * details of Case Nominee to be created
   *
   * @return Case Nominee ID
   * @deprecated Since Curam 6.0, replaced by {@link #createCaseNominee1()}.
   *
   * Method to create a CaseNominee on a case.
   */
  @Deprecated
  public CaseNomineeID createCaseNominee(
    final CaseNomineeCreationDetails caseNomineeCreationDetails)
    throws AppException, InformationalException {

    // Return struct
    final CaseNomineeID caseNomineeID = new CaseNomineeID();

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // Check facade level validations
    createNomineeDetails(caseNomineeCreationDetails);

    // Create nominee for the specified case
    caseNomineeObj.createCaseNominee(
      caseNomineeCreationDetails.caseNomineeCreationDetails);

    // Populate return struct
    caseNomineeID.caseNomineeID = caseNomineeCreationDetails.caseNomineeCreationDetails.caseNomineeDtls.caseNomineeID;

    return caseNomineeID;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public curam.core.facade.struct.CaseNomineeDetails listCaseNominee(
    final CaseNomineeCaseIDKey caseNomineeCaseIDKey) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // return structure
    CaseNomineeDetailsList caseNomineeDetailsList = new CaseNomineeDetailsList();

    // BEGIN, CR00190939, GD
    // struct used to store unfiltered list
    CaseNomineeDetailsList unfilteredCaseNomineeDetailsList = new CaseNomineeDetailsList();

    // read list from service layer into unfiltered struct
    unfilteredCaseNomineeDetailsList = caseNomineeObj.listCaseNominee(
      caseNomineeCaseIDKey.caseNomineeCaseIDKey);

    // populate return struct with filtered nominee list
    caseNomineeDetailsList = caseNomineeObj.filterCaseNomineeListByCaseParticipantRole(
      caseNomineeCaseIDKey.caseNomineeCaseIDKey,
      unfilteredCaseNomineeDetailsList);
    // END, CR00190939

    final curam.core.facade.struct.CaseNomineeDetails caseNomineeDetails = new curam.core.facade.struct.CaseNomineeDetails();

    // read for the context description
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID;

    caseNomineeDetails.caseContextDescription = readCaseContextDescription(
      caseContextDescriptionKey);
    caseNomineeDetails.caseNomineeDetailsList = caseNomineeDetailsList;

    return caseNomineeDetails;
  }

  // BEGIN, CR00201781, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public curam.core.facade.struct.CaseNomineeDetails listCaseNomineeAndAge(
    final CaseNomineeCaseIDKey caseNomineeCaseIDKey) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // return structure
    CaseNomineeDetailsList caseNomineeDetailsList = new CaseNomineeDetailsList();

    // struct used to store unfiltered list
    CaseNomineeDetailsList unfilteredCaseNomineeDetailsList = new CaseNomineeDetailsList();

    // read list from service layer into unfiltered struct
    unfilteredCaseNomineeDetailsList = caseNomineeObj.listCaseNominee(
      caseNomineeCaseIDKey.caseNomineeCaseIDKey);

    // populate return struct with filtered nominee list
    caseNomineeDetailsList = caseNomineeObj.filterCaseNomineeListByCaseParticipantRole(
      caseNomineeCaseIDKey.caseNomineeCaseIDKey,
      unfilteredCaseNomineeDetailsList);

    final MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory.newInstance();

    final curam.core.facade.struct.CaseNomineeDetails caseNomineeDetails = new curam.core.facade.struct.CaseNomineeDetails();

    for (int i = 0; i < caseNomineeDetailsList.caseNomineeDetailsList.size(); i++) {

      final ConcernRolesDetails concernRolesDetails = new ConcernRolesDetails();

      // Assign details needed to append age to name
      concernRolesDetails.assign(
        caseNomineeDetailsList.caseNomineeDetailsList.item(i));

      // Append age to concern role name
      caseNomineeDetailsList.caseNomineeDetailsList.item(i).concernRoleName = maintainConcernRoleDetailsObj.appendAgeToName(concernRolesDetails).concernRoleName;
    }

    caseNomineeDetails.caseNomineeDetailsList = caseNomineeDetailsList;

    return caseNomineeDetails;
  }

  // END, CR00201781, GD

  // BEGIN, CR00201781, GD
  // ___________________________________________________________________________
  /**
   * @param caseNomineeCaseIDKey
   * contains caseID
   * @param caseNomineeID
   * The identifier for the case nominee to be excluded from the
   * returned list of case nominees.
   *
   * @return List of CaseNominees for case and their delivery information
   * @deprecated Since Curam 6.0, replaced by {@link #listOtherCaseNominees1()}.
   *
   * Returns all case nominees for a case except for the nominee
   * with the ID provided.
   */
  @Deprecated
  // END, CR00201781
  public CaseNomineeAndCountDetails listOtherCaseNominees(
    final CaseNomineeCaseIDKey caseNomineeCaseIDKey, final CaseNomineeID caseNomineeID)
    throws AppException, InformationalException {

    final CaseNomineeAndCountDetails caseNomineeDetails = new CaseNomineeAndCountDetails();

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // return structure
    CaseNomineeDetailsList caseNomineeDetailsList = new CaseNomineeDetailsList();

    // read list from service layer into return struct
    caseNomineeDetailsList = caseNomineeObj.listOtherCaseNominees(
      caseNomineeCaseIDKey.caseNomineeCaseIDKey, caseNomineeID);

    // read context description
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID;

    caseNomineeDetails.caseContextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    // BEGIN, CR00181451, SPD
    final MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory.newInstance();

    // Append the persons age to their name to differentiate between the
    // nominees with the same name
    for (int i = 0; i < caseNomineeDetailsList.caseNomineeDetailsList.size(); i++) {

      final ConcernRolesDetails concernRolesDetails = new ConcernRolesDetails();

      concernRolesDetails.assign(
        caseNomineeDetailsList.caseNomineeDetailsList.item(i));

      caseNomineeDetailsList.caseNomineeDetailsList.item(i).concernRoleName = maintainConcernRoleDetailsObj.appendAgeToName(concernRolesDetails).concernRoleName;
    }
    // END, CR00181451

    caseNomineeDetails.caseNomineeDetailsList = caseNomineeDetailsList;

    // Set an indicator to tell the UI that there are no other nominees for
    // this case.
    if (caseNomineeDetailsList.caseNomineeDetailsList.size() > 0) {
      caseNomineeDetails.defaultNomineeOnlyInd = false;
    } else {
      caseNomineeDetails.defaultNomineeOnlyInd = true;
    }

    return caseNomineeDetails;
  }

  // BEGIN, CR00222906, KH
  // BEGIN, CR00201781, GD
  // BEGIN, CR00292632, SG
  // ___________________________________________________________________________
  /**
   * Lists all of the case nominees for a case with the exception of the one who
   * received the specified financial instruction. The list does not include any
   * case nominee delivery patterns where the delivery pattern frequency differs
   * from the frequency of the given financial instruction. The number of
   * nominees is also returned.
   *
   * @param key
   * Contains the ID of the financial instruction used to identify the
   * nominee who is currently in receipt of the instruction.
   *
   * @return The list of case nominees and their delivery pattern details,
   * excluding the nominee currently in receipt of the instruction.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Case#listCaseNominees(FinancialInstructionAndCaseID)}. This method
   * selects the Case Nominee ID wrongly when instruction line items are
   * searched by Financial Instruction ID alone. See release note: CR00292632.
   */
  @Deprecated
  public CaseNomineeAndCountDetails listOtherCaseNominees1(
    final FinancialInstructionKey key) throws AppException,
      InformationalException {

    // END, CR00292632
    // Return struct
    final CaseNomineeAndCountDetails caseNomineeDetails = new CaseNomineeAndCountDetails();

    final ILIFinInstructID finInstructionID = new ILIFinInstructID();

    finInstructionID.finInstructionID = key.finInstructionID;
    final InstructionLineItemDtlsList iliList = InstructionLineItemFactory.newInstance().searchByFinInstructID(
      finInstructionID);

    boolean isThirdPartyPaymentInd = false;

    if (iliList.dtls.size() > 0) {

      // BEGIN, CR00242881, VM
      /*
       * If the financial instruction is linked to a third party payment, the
       * caseID will not be specified. We can get this, and the caseNomineeID,
       * from the financial component in this instance.
       */
      long caseID = 0;
      long originalCaseNomineeID = 0;

      // BEGIN, CR00244234, MC
      if (iliList.dtls.item(0).caseID == 0) {
        // END, CR00244234
        FinancialComponentKey finCompKey = new FinancialComponentKey();

        finCompKey.financialCompID = iliList.dtls.item(0).financialCompID;
        FinancialComponentDtls finCompDtls = FinancialComponentFactory.newInstance().read(
          finCompKey);

        caseID = finCompDtls.caseID;
        originalCaseNomineeID = finCompDtls.caseNomineeID;

        isThirdPartyPaymentInd = true;
      } else {
        caseID = iliList.dtls.item(0).caseID;
        originalCaseNomineeID = iliList.dtls.item(0).caseNomineeID;
      }
      // END, CR00242881

      // ServiceLayer CaseNominee objects
      final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();
      final curam.core.sl.struct.CaseNomineeCaseIDKey caseNomineeCaseIDKey = new curam.core.sl.struct.CaseNomineeCaseIDKey();

      caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID = caseID;

      final CaseNomineeDetailsList nomineeList = caseNomineeObj.listCaseNominee(
        caseNomineeCaseIDKey);

      // Read context description
      final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

      caseContextDescriptionKey.caseID = caseID;
      caseNomineeDetails.caseContextDescription = readCaseContextDescription(
        caseContextDescriptionKey);

      final MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory.newInstance();

      final ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();

      // BEGIN, CR00223924, CW
      // Get the delivery frequency of the payment by reading
      // the effective delivery pattern for the nominee on the payment
      readEffectiveByDateKey.caseNomineeID = originalCaseNomineeID;
      readEffectiveByDateKey.effectiveDate = iliList.dtls.item(0).coverPeriodFrom;
      readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;

      CaseNomineeDeliveryPatternDetails caseNomineeDeliveryPatternDetails = caseNomineeObj.readNearestDeliveryPattern(
        readEffectiveByDateKey);

      final String paymentFrequency = caseNomineeDeliveryPatternDetails.deliveryFrequency;

      // Set the effective date to today's date for further reads
      readEffectiveByDateKey.effectiveDate = Date.getCurrentDate();

      for (int i = 0; i < nomineeList.caseNomineeDetailsList.size(); i++) {

        // Find current delivery pattern for caseNomineeID
        readEffectiveByDateKey.caseNomineeID = nomineeList.caseNomineeDetailsList.item(i).caseNomineeID;

        caseNomineeDeliveryPatternDetails = caseNomineeObj.readNearestDeliveryPattern(
          readEffectiveByDateKey);

        // We only want to include nominee delivery patterns with the same
        // frequency as the original payment
        final boolean sameDeliveryFrequency = caseNomineeDeliveryPatternDetails.deliveryFrequency.equalsIgnoreCase(
          paymentFrequency);

        // BEGIN, CR00251946, KH
        /*
         * Do not display the nominee who received the payment OR any nominee
         * who has a delivery pattern with a different delivery frequency to
         * the payment OR any nominee who is inactive.
         */
        if (nomineeList.caseNomineeDetailsList.item(i).nomineeStatus.equals(
          CASENOMINEESTATUS.EXPIRED)
            || nomineeList.caseNomineeDetailsList.item(i).caseNomineeID
              == originalCaseNomineeID
              || !sameDeliveryFrequency) {
          // END, CR00223924

          nomineeList.caseNomineeDetailsList.remove(i);
          i--;
          continue;
        }
        // END, CR00251946

        /*
         * Append the persons age to their name to differentiate between
         * nominees with the same name.
         */
        final ConcernRolesDetails concernRolesDetails = new ConcernRolesDetails();

        concernRolesDetails.assign(nomineeList.caseNomineeDetailsList.item(i));

        nomineeList.caseNomineeDetailsList.item(i).concernRoleName = maintainConcernRoleDetailsObj.appendAgeToName(concernRolesDetails).concernRoleName;

        /*
         * Append the delivery pattern name to differentiate between nominees
         * with multiple delivery patterns.
         */
        nomineeList.caseNomineeDetailsList.item(i).concernRoleName += CuramConst.gkSpace
          + CuramConst.gkDash + CuramConst.gkSpace
          + caseNomineeDeliveryPatternDetails.deliveryPatternName;
      }

      caseNomineeDetails.caseNomineeDetailsList = nomineeList;

      // Set an indicator to tell the UI that there are no other nominees for
      // this case.
      // If the payment is a third party payment set this indicator
      // to tell the UI not to display the option to regenerate the payment to
      // a new nominee.
      if (nomineeList.caseNomineeDetailsList.size() > 0
        || isThirdPartyPaymentInd) {
        caseNomineeDetails.defaultNomineeOnlyInd = false;
      } else {
        caseNomineeDetails.defaultNomineeOnlyInd = true;
      }

    }

    return caseNomineeDetails;
  }

  // END, CR00201781, CR00222906

  // BEGIN, CR00201781, GD
  // ___________________________________________________________________________
  /**
   * @param caseNomineeHistoryKey
   * contains caseNomineeID
   *
   * @return List of objective assignments for Nominee
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listCaseNomineeAssignmentHistory()}.
   *
   * Method to list the history of all Objectives ever assigned to a
   * CaseNominee
   */
  @Deprecated
  // END, CR00190939
  public CaseNomineeObjectiveHistory_fo listCaseNomineeHistory(
    final CaseNomineeHistoryKey caseNomineeHistoryKey) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // return structure
    final CaseNomineeObjectiveHistory_fo caseNomineeObjectiveHistory = new CaseNomineeObjectiveHistory_fo();

    // read list from service layer into return struct
    caseNomineeObjectiveHistory.caseNomineeObjectiveHistoryList_bo = caseNomineeObj.listCaseNomineeHistory(
      caseNomineeHistoryKey.caseNomineeHistoryKey);

    // read context description
    final CaseNomineeContextDescriptionKey caseNomineeContextDescriptionKey = new CaseNomineeContextDescriptionKey();

    caseNomineeContextDescriptionKey.caseNomineeID = caseNomineeHistoryKey.caseNomineeHistoryKey.caseNomineeHistoryKey.caseNomineeID;

    caseNomineeObjectiveHistory.caseNomineeContextDescription_fo = readCaseNomineeContextDescription(
      caseNomineeContextDescriptionKey);

    final CaseNominee caseNominee = CaseNomineeFactory.newInstance();

    curam.core.sl.entity.struct.CaseIDAndFromDateDtls caseIDAndFromDateDtls;

    final curam.core.sl.entity.struct.CaseNomineeKey caseNomineeKey = new curam.core.sl.entity.struct.CaseNomineeKey();

    caseNomineeKey.caseNomineeID = caseNomineeHistoryKey.caseNomineeHistoryKey.caseNomineeHistoryKey.caseNomineeID;
    caseIDAndFromDateDtls = caseNominee.readCaseID(caseNomineeKey);

    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = caseIDAndFromDateDtls.caseID;

    caseNomineeObjectiveHistory.caseNomineeContextDescription_fo.description = readCaseContextDescription(caseContextDescriptionKey).description;

    return caseNomineeObjectiveHistory;

  }

  // BEGIN, CR00190939, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public curam.core.facade.struct.CaseNomineeAssignmentHistoryDetailsList listCaseNomineeAssignmentHistory(
    final CaseNomineeObjectiveHistoryKey key) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // return structure
    final curam.core.facade.struct.CaseNomineeAssignmentHistoryDetailsList caseNomineeAssignmentHistoryDetailsList = new curam.core.facade.struct.CaseNomineeAssignmentHistoryDetailsList();

    // read list from service layer into return struct
    caseNomineeAssignmentHistoryDetailsList.dtls = caseNomineeObj.listCaseNomineeAssignmentHistory(
      key);

    // Read the case nominee name
    final curam.core.sl.struct.CaseNomineeViewKey caseNomineeViewKey = new curam.core.sl.struct.CaseNomineeViewKey();

    caseNomineeViewKey.caseNomineeViewKey.caseNomineeID = key.caseNomineeID;

    final curam.core.sl.struct.CaseNomineeViewDetails caseNomineeViewDetails = caseNomineeObj.viewCaseNomineeDetails(
      caseNomineeViewKey);

    caseNomineeAssignmentHistoryDetailsList.caseNomineeName.nomineeName = caseNomineeViewDetails.caseNomineeDetails.concernRoleName;

    return caseNomineeAssignmentHistoryDetailsList;
  }

  // END, CR00190939

  // BEGIN, CR00190939, GD
  // ___________________________________________________________________________
  /**
   * @param caseObjectiveKey
   * contains rules objective ID
   *
   * @return Case nominee objective history details
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listObjectiveAndDelPatternHistory()}.
   *
   * Method to return all NomineeCaseObjective records for an
   * Objective on a Case.
   */
  @Deprecated
  // END, CR00190939
  public ObjectiveHistoryDetails listObjectiveHistory(
    final CaseObjectiveKey caseObjectiveKey) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // return structure
    final ObjectiveHistoryDetails objectiveHistoryDetails = new ObjectiveHistoryDetails();

    // read list from service layer into return struct
    objectiveHistoryDetails.objectiveHistoryDetails = caseNomineeObj.listObjectiveHistory(
      caseObjectiveKey.caseObjectiveKey);

    // read context description
    final CaseObjectiveContextDescriptionKey caseObjectiveContextDescriptionKey = new CaseObjectiveContextDescriptionKey();

    caseObjectiveContextDescriptionKey.rulesObjectiveID = caseObjectiveKey.caseObjectiveKey.caseObjectiveKey.rulesObjectiveID;

    caseObjectiveContextDescriptionKey.caseID = caseObjectiveKey.caseObjectiveKey.caseObjectiveKey.caseID;

    objectiveHistoryDetails.caseObjectiveContextDescription = readCaseObjectiveContextDescription(
      caseObjectiveContextDescriptionKey);

    return objectiveHistoryDetails;
  }

  // BEGIN, CR00190939, GD
  // ___________________________________________________________________________
  /**
   * Method to return all NomineeCaseObjective records for an Objective on a
   * Case and the corresponding delivery pattern.
   *
   * @param caseObjectiveKey
   * contains rules objective ID
   *
   * @return Case nominee objective history details
   */
  public ObjectiveAndDelPatternHistoryDetailsList listObjectiveAndDelPatternHistory(
    final CaseObjectiveKey caseObjectiveKey) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    return caseNomineeObj.listObjectiveAndDelPatternHistory(
      caseObjectiveKey.caseObjectiveKey);

  }

  // END, CR00190939

  // BEGIN, CR00194084, GD
  // ___________________________________________________________________________
  /**
   * @param modifyCaseNomineeDetails
   * details of modified Case Nominee
   * @deprecated Since Curam 6.0, replaced by {@link #modifyCaseNominee1()}.
   *
   * Method to modify CaseNominee details.
   */
  @Deprecated
  public void modifyCaseNominee(
    final ModifyCaseNomineeDetails modifyCaseNomineeDetails) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // call service layer method
    caseNomineeObj.modifyCaseNominee(
      modifyCaseNomineeDetails.modifyCaseNomineeDetails);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void modifyCaseNominee1(
    final ModifyCaseNomineeDetails modifyCaseNomineeDetails) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // call service layer method
    caseNomineeObj.modifyCaseNominee1(
      modifyCaseNomineeDetails.modifyCaseNomineeDetails);
  }

  // END, CR00194084

  // ___________________________________________________________________________
  /**
   * Method to return Delivery patterns available for a case.
   *
   * @param productDeliveryPatternByCaseIDKey
   * contains caseID
   *
   * @return List of available product delivery patterns
   */
  public DeliveryPatternForCaseDetailsList listDeliveryPatternForCase(
    final curam.core.struct.ProductDeliveryPatternByCaseIDKey productDeliveryPatternByCaseIDKey)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // return structure
    final DeliveryPatternForCaseDetailsList deliveryPatternForCaseDetailsList = new DeliveryPatternForCaseDetailsList();

    final curam.core.sl.struct.ProductDeliveryPatternByCaseIDKey productDelPatByCaseIDKey = new curam.core.sl.struct.ProductDeliveryPatternByCaseIDKey();

    productDelPatByCaseIDKey.productDeliveryPatternByCaseIDKey.caseID = productDeliveryPatternByCaseIDKey.caseID;

    // read list from service layer into return struct
    deliveryPatternForCaseDetailsList.deliveryPatternForCaseDetailsList = caseNomineeObj.listDeliveryPatternForCase(
      productDelPatByCaseIDKey);

    return deliveryPatternForCaseDetailsList;

  }

  // BEGIN, CR00190939, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public curam.core.sl.struct.DeliveryPatternForCaseDetailsList listDeliveryPatternForNominee(
    final CaseNomineeDeliveryPatternKey caseNomineeDeliveryPatternKey)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // return structure
    final curam.core.sl.struct.DeliveryPatternForCaseDetailsList deliveryPatternForCaseDetailsList = new curam.core.sl.struct.DeliveryPatternForCaseDetailsList();

    // read list of current delivery patterns from service layer
    final curam.core.sl.struct.CaseNomineeDeliveryPatternDetailsList caseNomineeDeliveryPatternDetailsList = caseNomineeObj.listCurrentDeliveryPattern(
      caseNomineeDeliveryPatternKey);

    // convert service layer struct into lightweight facade struct
    for (int i = 0; i < caseNomineeDeliveryPatternDetailsList.dtls.size(); i++) {

      final CaseNomineeDeliveryPatternDetails caseNomineeDeliveryPatternDetails = caseNomineeDeliveryPatternDetailsList.dtls.item(
        i);

      final DeliveryPatternForCaseDetails deliveryPatternForCaseDetails = new DeliveryPatternForCaseDetails();

      deliveryPatternForCaseDetails.productDeliveryPatternID = caseNomineeDeliveryPatternDetails.productDeliveryPatternID;
      deliveryPatternForCaseDetails.productDeliveryPatternName = caseNomineeDeliveryPatternDetails.deliveryPatternName;

      deliveryPatternForCaseDetailsList.deliveryPatternForCaseDetailsList.addRef(
        deliveryPatternForCaseDetails);
    }

    return deliveryPatternForCaseDetailsList;
  }

  // END, CR00190939

  // BEGIN, CR00189687, GD
  // ___________________________________________________________________________
  /**
   * @param caseNomineeViewKey
   * contains caseNomineeID
   *
   * @return details of case nominee
   * @deprecated Since Curam 6.0, replaced by {@link #viewCaseNomineeDetails1()}
   * .
   *
   * Method to view a CaseNominee's details.
   */
  @Deprecated
  // END, CR00189687
  public CaseNomineeViewDetails viewCaseNomineeDetails(
    final CaseNomineeViewKey caseNomineeViewKey) throws AppException,
      InformationalException {

    // Return structure
    final CaseNomineeViewDetails caseNomineeViewDetails = new CaseNomineeViewDetails();

    // Retrieve nominee view details
    final CaseNomineeViewDetails1 caseNomineeViewDetails1 = viewCaseNomineeDetails1(
      caseNomineeViewKey);

    // Populate return struct
    caseNomineeViewDetails.caseNomineeContextDescription.assign(
      caseNomineeViewDetails1.caseNomineeContextDescription);
    caseNomineeViewDetails.caseNomineeViewDetails.assign(
      caseNomineeViewDetails1.caseNomineeViewDetails);

    return caseNomineeViewDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to read Case context information. Returns context string of the
   * format: "Case productType caseID concernRoleName"
   *
   * @param caseContextDescriptionKey
   * Contains caseID
   *
   * @return Context description for case
   */
  public CaseContextDescription readCaseContextDescription(
    final CaseContextDescriptionKey caseContextDescriptionKey) throws AppException,
      InformationalException {

    // return structure
    CaseContextDescription caseContextDescription = new CaseContextDescription();

    // Check the Environmental variable
    // Retrieve the Environment variable for the Appeals component
    // installation
    // setting. If the environment variable is present and set to 'true',
    // run
    // the Reflection code.
    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {

      // Setup, instantiation and execution of alternative
      // readCaseContextDescription within AppealCase class, via
      // reflection / method.invoke()
      Class<?> cls = null;
      // BEGIN, CR00023323, SK
      // BEGIN, CR00158377, RV
      final String className = ReflectionConst.coreToAppealDelegateWrapperClassName;
      // END, CR00158377
      final String methodName = ReflectionConst.readCaseContextMethodName;

      // END CR00023323

      try {
        // Load the class for AppealCase
        cls = Class.forName(className);

        // Create a method for the static newInstance constructor
        // BEGIN, CR00023323, SK
        final Method constructorMethod = cls.getMethod(
          ReflectionConst.kNewInstance);
        // END CR00023323
        final Object classObj = constructorMethod.invoke(cls);

        // Set the arguments to pass through
        final Object[] arguments = new Object[] { caseContextDescriptionKey };

        // Set the passed class types to the method
        // readCaseContextDescription
        final Class[] parameterTypes = new Class[] {
          CaseContextDescriptionKey.class };

        // Define the method readCaseContextDescription
        // BEGIN, CR00142355, CD
        final Method method = classObj.getClass().getMethod(methodName,
          parameterTypes);

        // END CR00142355

        // Now invoke the method
        caseContextDescription = (CaseContextDescription) method.invoke(
          classObj, arguments);

      } catch (final IllegalAccessException e) {// ignore - biz methods MUST be
        // public
      } catch (final ClassNotFoundException e) {

        final AppException ae = new AppException(
          BPOREFLECTION.ERR_REFLECTION_CLASS_NOT_FOUND);

        ae.arg(className);
        ae.arg(getClass().toString());
        // BEGIN, CR00163098, JC
        ae.arg(
          CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
          TransactionInfo.getProgramLocale()));
        // END, CR00163098, JC
        
        throw new RuntimeException(ae);

      } catch (final NoSuchMethodException e) {

        final AppException ae = new AppException(
          BPOREFLECTION.ERR_REFLECTION_NO_SUCH_METHOD);

        ae.arg(className);

        ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
        // BEGIN, CR00163098, JC
        ae.arg(
          CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
          TransactionInfo.getProgramLocale()));
        // END, CR00163098, JC
        
        throw new RuntimeException(ae);

      } catch (final IllegalArgumentException e) {

        final AppException ae = new AppException(
          BPOREFLECTION.ERR_ILLEGAL_FUNCTION_ARGUMENTS);

        // BEGIN, CR00049218, GM
        ae.arg(getClass().toString() + GeneralConst.gDot + methodName);
        // END, CR00049218

        ae.arg(className);
        // BEGIN, CR00163098, JC
        ae.arg(
          CodeTable.getOneItem(CASETYPECODE.TABLENAME, CASETYPECODE.APPEAL,
          TransactionInfo.getProgramLocale()));
        // END, CR00163098, JC
        
        throw new RuntimeException(ae);

      } catch (final InvocationTargetException e) {

        final AppException exc = new AppException(
          BPOREFLECTION.ERR_BPO_MESSAGE_RETURNED);

        exc.arg(e.getTargetException().getMessage());
        throw exc;
      }

      return caseContextDescription;
    }

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // ConcernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;
    // BEGIN, CR00049218, GM
    String productTypeDesc = CuramConst.gkEmpty;
    // END, CR00049218

    final int kBufSize = 256;

    // Set key to read CaseHeader
    caseHeaderKey.caseID = caseContextDescriptionKey.caseID;

    // Read CaseHeader
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Set key to read ConcernRole
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // Read ConcernRole
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    if ((caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.PRODUCTDELIVERY))
        || (caseHeaderDtls.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.LIABILITY))) {

      // ProductDelivery manipulation variables
      final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      ProductDeliveryDtls productDeliveryDtls;

      // Set key to read productDelivery
      productDeliveryKey.caseID = caseContextDescriptionKey.caseID;

      // Read ProductDelivery
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

      // BEGIN, CR00163098, JC
      productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
        productDeliveryDtls.productType, TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SCREENINGCASE)) {

      // ProductDelivery manipulation variables
      final curam.core.sl.entity.intf.Screening screeningObj = curam.core.sl.entity.fact.ScreeningFactory.newInstance();
      final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
      ScreeningName screeningName;

      // Set key to read Screening
      caseKeyStruct.caseID = caseContextDescriptionKey.caseID;

      // Read Screening
      screeningName = screeningObj.readName(caseKeyStruct);

      productTypeDesc = // BEGIN, HARP 44761, POH
        // BEGIN, CR00163098, JC
        CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME, screeningName.name,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery manipulation variables
      final curam.serviceplans.facade.struct.ServicePlanDeliveryKey servicePlanDeliveryKey = new curam.serviceplans.facade.struct.ServicePlanDeliveryKey();

      final curam.serviceplans.sl.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.sl.fact.ServicePlanDeliveryFactory.newInstance();

      servicePlanDeliveryKey.servicePlanDeliveryKey.key.caseID = caseContextDescriptionKey.caseID;

      // read service plan product type
      final curam.serviceplans.sl.struct.ServicePlanParticipantAndReferenceDetails spParticipantAndReferenceDetails = servicePlanDeliveryObj.readParticipantTypeAndReferenceDetails(
        servicePlanDeliveryKey.servicePlanDeliveryKey);

      productTypeDesc = CodeTable.getOneItem(SERVICEPLANTYPE.TABLENAME, // BEGIN, CR00163098, JC
        spParticipantAndReferenceDetails.servicePlanTypeStruct.servicePlanType,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC
    }

    // Create and initialize StringBuffer
    final StringBuffer contextDescription = new StringBuffer(kBufSize);

    // If case type is integrated case there will be no product type in the
    // context description.
    if ((caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.PRODUCTDELIVERY))
        || (caseHeaderDtls.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.LIABILITY))
          || (caseHeaderDtls.caseTypeCode.equals(
            curam.codetable.CASETYPECODE.SCREENINGCASE))) // END,
    // HARP
    // 44761
    {
      // BEGIN, CR00098942, SAI
      // BEGIN, CR00222190, ELG
      contextDescription.append(productTypeDesc).append(kSpace).append(caseHeaderDtls.caseReference).append(kSpace).append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.getProgramLocale())).append(concernRoleDtls.concernRoleName).append(kSpace).append(
        concernRoleDtls.primaryAlternateID);
      // END, CR00222190

      // END, CR00098942

    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.INTEGRATEDCASE)) {

      // BEGIN, CR00098942, SAI
      // BEGIN, CR00222190, ELG
      contextDescription.append(caseHeaderDtls.caseReference).append(kSpace).append(SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.getProgramLocale())).append(concernRoleDtls.concernRoleName).append(kSpace).append(
        concernRoleDtls.primaryAlternateID);
      // END, CR00222190
      // END, CR00098942

    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {
      // BEGIN, CR00085608 SK
      contextDescription.append(
        productTypeDesc + CuramConst.gkSpace + caseHeaderDtls.caseReference // BEGIN, CR00098942 SAI
        + CuramConst.gkSpace // END, CR00098942 SAI
        // BEGIN, CR00222190, ELG
        + SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
          TransactionInfo.getProgramLocale())
          // END, CR00222190
          + concernRoleDtls.concernRoleName
          + CuramConst.gkSpace
          + concernRoleDtls.primaryAlternateID);
      // END, CR00085608 SK

    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.INVESTIGATIONCASE)) {

      // InvestigationDelivery manipulation variables
      final curam.core.facade.intf.InvestigationDelivery investigationDeliveryObj = curam.core.facade.fact.InvestigationDeliveryFactory.newInstance();

      // read Investigation Delivery context description
      contextDescription.append(
        investigationDeliveryObj.getContextDescription(caseHeaderKey).description);
      // BEGIN, CR00353792, ZV
    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.PARTICIPANTDATACASE)) {
      
      final ConcernRoleTypeDetails concernRoleTypeDetails = concernRoleObj.readConcernRoleType(
        concernRoleKey);

      if (concernRoleTypeDetails.concernRoleType.equals(CONCERNROLETYPE.PERSON)) {
        contextDescription.append(
          PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PERSON.toString());
      } else if (concernRoleTypeDetails.concernRoleType.equals(
        CONCERNROLETYPE.PROSPECTPERSON)) {
        contextDescription.append(
          PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PROSPECT.toString());
      }
      
    }
    // END, CR00353792

    caseContextDescription.description = contextDescription.toString();

    return caseContextDescription;

  }

  // ___________________________________________________________________________
  /**
   * Method to read case and objective context specific information. Returns
   * context string of the format "Component ... for Case ..."
   *
   * @param caseObjectiveContextDescriptionKey
   * contains caseID and rules objectiveID
   *
   * @return Context description for case
   */
  @Override
  protected CaseObjectiveContextDescription readCaseObjectiveContextDescription(
    final CaseObjectiveContextDescriptionKey caseObjectiveContextDescriptionKey)
    throws AppException, InformationalException {

    // variables to read list of objectives
    final CaseNomineeCaseIDKey caseNomineeCaseIDKey = new CaseNomineeCaseIDKey();
    CaseNomineeObjectiveNameDetailsList caseNomineeObjectiveNameDetailsList;

    // return variable
    final CaseObjectiveContextDescription caseObjectiveContextDescription = new CaseObjectiveContextDescription();

    // read list of objectives available
    caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID = caseObjectiveContextDescriptionKey.caseID;

    caseNomineeObjectiveNameDetailsList = listObjective(caseNomineeCaseIDKey);

    // Create a localizable string based on the message entry
    final LocalisableString contextDescription = new LocalisableString(
      curam.message.FACADERESOURCE.INF_CASE_CONTEXT_DESCRIPTION);

    // lookup codetable value
    String objectiveName = "";

    // retrieve the one in which we're interested
    for (final curam.core.sl.entity.struct.CaseNomineeObjectiveNameDetails item : caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.items()) {
      if (item.rulesObjectiveID.equals(
        caseObjectiveContextDescriptionKey.rulesObjectiveID)) {
        objectiveName = curam.util.type.CodeTable.getOneItem(
          curam.codetable.RULESCOMPONENTTYPE.TABLENAME, item.objectiveCode);
        break;
      }
    }

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.struct.CaseSearchKey caseSearchKey = new curam.core.struct.CaseSearchKey();

    caseSearchKey.caseID = caseObjectiveContextDescriptionKey.caseID;
    final String caseReference = caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference;

    final StringBuffer contextString = new StringBuffer(objectiveName.length());

    // Populate Context Description string
    contextDescription.arg(caseReference);

    caseObjectiveContextDescription.description = contextDescription.toClientFormattedText();

    contextString.append(objectiveName);

    caseObjectiveContextDescription.description = contextString.toString();

    return caseObjectiveContextDescription;
  }

  // ___________________________________________________________________________
  /**
   * Creates a Case Participant Role on a case.
   *
   * @param details
   * Details to create a Concern Case Role.
   */
  public void createClientRole(final AddClientRoleDetails details)
    throws AppException, InformationalException {

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.struct.CaseParticipantRoleDetails caseParticipantRoleDetails = new curam.core.sl.struct.CaseParticipantRoleDetails();

    // Assign details to create a Concern Case Role
    caseParticipantRoleDetails.dtls.caseID = details.caseID;
    caseParticipantRoleDetails.dtls.participantRoleID = details.concernRoleID;
    caseParticipantRoleDetails.dtls.fromDate = details.startDate;

    // create Case Participant Role
    caseParticipantRole_boObj.insertCaseParticipantRole(
      caseParticipantRoleDetails);

  }

  // ___________________________________________________________________________
  /**
   * Creates a Case Participant Role on a case. Also links the new case member's
   * participant evidence to the case which they are being added to.
   *
   * @param details
   * Details to create a Concern Case Role.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void createCaseMember(final AddClientRoleDetails details)
    throws AppException, InformationalException {

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.struct.CaseParticipantRoleDetails caseParticipantRoleDetails = new curam.core.sl.struct.CaseParticipantRoleDetails();
    // BEGIN, CR00226837, PB
    final RedetermineTranslatorStruct redetermineTranslatorStruct = new RedetermineTranslatorStruct();
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();

    // END, CR00226837
    // Assign details to create a Concern Case Role
    caseParticipantRoleDetails.dtls.caseID = details.caseID;
    caseParticipantRoleDetails.dtls.participantRoleID = details.concernRoleID;
    caseParticipantRoleDetails.dtls.fromDate = details.startDate;

    caseParticipantRoleDetails.dtls.typeCode = CASEPARTICIPANTROLETYPE.MEMBER;
    caseParticipantRoleDetails.dtls.comments = details.comments;
    
    // BEGIN, CR00407868, SG
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = details.caseID;
    
    checkMaintainCaseSecurity(caseSecurityCheckKey);
    // END, CR00407868

    // BEGIN, CR00226315, PM
    // security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    participantSecurityCheckKey.participantID = details.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.MAINTAIN;
    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
      participantSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          GENERALCONCERN.ERR_CONCERNROLE_FV_CASEMEMBER_SENSITIVITY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00226315

    // create Case Participant Role
    caseParticipantRole_boObj.insertCaseParticipantRole(
      caseParticipantRoleDetails);

    // BEGIN, CR00235005, PB
    // BEGIN, CR00226837, PB
    redetermineTranslatorStruct.concernRoleID = details.concernRoleID;
    // END, CR00235005
    caseParticipantRoleObj.redetermineTranslator(redetermineTranslatorStruct);
    // END, CR00226837
    // BEGIN, CR00065831, AC
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = details.caseID;
    final IntegratedCaseType integratedCaseType = caseHeaderObj.readIntegratedCaseType(
      caseKey);

    final CaseIDConcernAndICTypeKey caseIDConcernAndICTypeKey = new CaseIDConcernAndICTypeKey();

    caseIDConcernAndICTypeKey.caseID = details.caseID;
    caseIDConcernAndICTypeKey.integratedCaseType = integratedCaseType.integratedCaseType;
    caseIDConcernAndICTypeKey.concernRoleID = details.concernRoleID;

    final EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

    evidenceControllerObj.retrieveAndLinkPrtcptDataForIntegratedCase(
      caseIDConcernAndICTypeKey);
    // END, CR00065831
    // BEGIN, CR00386292, AKr
    final CaseID caseID = new CaseID();

    caseID.caseID = details.caseID;
    final ConcernRoleIDList concernRoleIDList = new ConcernRoleIDList();
    final ConcernRoleID concernRoleID = new ConcernRoleID();

    concernRoleID.concernRoleID = details.concernRoleID;
    concernRoleIDList.dtls.addRef(concernRoleID);
    evidenceVerificationImpl.getVerificationImpl().verifyParticipantEvidencesForCase(
      concernRoleIDList, caseID);
    // END, CR00386292
  }

  // BEGIN, CR00150296, PDN
  // ___________________________________________________________________________
  /**
   * Creates a Case Participant Role on a case and links the new case member's
   * participant evidence to the case which they are being added to, for each
   * concern role ID supplied by the string tabulated list of concern role id's.
   *
   * @param details
   * Details to create a Concern Case Roles.
   */
  public void createCaseMembers(final AddMultiClientRoles details)
    throws AppException, InformationalException {

    // list needed to parse out concern role tab list
    StringList stringList = new StringList();

    // Convert the tab delimited string to a list of strings
    stringList = StringUtil.tabText2StringList(details.concernRoleIDTabList);

    final AddClientRoleDetails createCaseMemberDetails = new AddClientRoleDetails();

    // For each concern role id in the list, create a case member
    for (int i = 0; i < stringList.size(); i++) {

      createCaseMemberDetails.concernRoleID = Long.parseLong(stringList.item(i));
      createCaseMemberDetails.caseID = details.caseID;
      createCaseMemberDetails.comments = details.comments;
      createCaseMemberDetails.startDate = details.startDate;

      createCaseMember(createCaseMemberDetails);
    }

  }

  // ___________________________________________________________________________
  /**
   * @param key
   * The concern role ID of the primary case member.
   *
   * @return The list of active relationships that are not already members of
   * the case.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listRelationshipForCaseMember1()}.
   *
   * Retrieves a list of Person Relationship details for adding a
   * case member to an integrated case. The returned list removes
   * any cancelled relationships or any that are already a case
   * member.
   */
  @Deprecated
  public ListRelationshipForCaseMemberDetails listRelationshipForCaseMember(
    final ReadRelationshipListForCaseMemberKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00150390, PDN
    // Get the primary concern role of the case
    final curam.core.sl.intf.Case caseObj = CaseFactory.newInstance();
    final curam.core.sl.struct.CaseKey caseKey = new curam.core.sl.struct.CaseKey();

    caseKey.key.caseID = key.caseID;

    final long primaryConcernRoleID = caseObj.getConcernRoleDetailsByCaseID(caseKey).concernRoleID;

    // Maintain Concern Role Relationships object.
    final MaintainConcernRoleRelationships maintainRelationshipsObj = MaintainConcernRoleRelationshipsFactory.newInstance();

    final RelationshipConcernRoleIDKey relationshipConcernRoleIDKey = new RelationshipConcernRoleIDKey();

    relationshipConcernRoleIDKey.concernRoleID = primaryConcernRoleID;

    // Read the list of Person Relationship records.
    final MaintainConcernRoleRelationshipList maintainConcernRoleRelationshipList = maintainRelationshipsObj.searchActiveRelationshipsByConcernRoleID(
      relationshipConcernRoleIDKey);

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;
    viewCaseParticipantRole_boKey.showOnlyActive = true;
    ;

    // Read the list of case participant roles
    final ViewCaseParticipantRoleDetailsList existingMembersList = caseParticipantRoleObj.viewCaseMemberList(
      viewCaseParticipantRole_boKey);
    // END, CR00150390

    // Create a tree map object to store the relationship details.
    // The key is the concern role id and the value is the
    final TreeMap<Long, MaintainConcernRoleRelationshipRMDetails> treeMap = new TreeMap<Long, MaintainConcernRoleRelationshipRMDetails>();

    // Loop through the list of relationships and build up the tree map
    // to be used to filter the relationships
    for (int i = 0; i < maintainConcernRoleRelationshipList.dtls.size(); i++) {
      // Add it to the map
      treeMap.put(
        maintainConcernRoleRelationshipList.dtls.item(i).concernRoleID,
        maintainConcernRoleRelationshipList.dtls.item(i));
    }

    // Remove any relationships from the map that are already members
    for (int j = 0; j < existingMembersList.dtls.size(); j++) {
      treeMap.remove(existingMembersList.dtls.item(j).participantRoleID);
    }

    // Replace all the existing relationships from the return struct and add
    // the
    // filtered ones from the map
    maintainConcernRoleRelationshipList.dtls.clear();
    maintainConcernRoleRelationshipList.dtls.addAll(treeMap.values());

    // BEGIN, CR00151408, PDN
    // Define result structure and add the list case members
    final ListRelationshipForCaseMemberDetails listRelationshipForCaseMemberDetails = new ListRelationshipForCaseMemberDetails();

    listRelationshipForCaseMemberDetails.dtls = maintainConcernRoleRelationshipList;

    // Define context description variables
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    final curam.core.struct.CaseKey caseIDKey = new curam.core.struct.CaseKey();
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    // Set key to read caseHeader
    caseIDKey.caseID = key.caseID;

    // Read integrated case details
    final ICHomePageNameAndType icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(
      caseIDKey);

    // Set key to read context description
    caseContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to output object
    listRelationshipForCaseMemberDetails.description = CodeTable.getOneItem(
      PRODUCTCATEGORY.TABLENAME, icHomePageNameAndType.integratedCaseType)
        + GeneralConstants.kSpace
        + readCaseContextDescription(caseContextDescriptionKey).description;

    // Return the details.
    return listRelationshipForCaseMemberDetails;
    // END, CR00151408
  }

  // END, CR00150296

  // BEGIN, CR00205274, PB
  // ___________________________________________________________________________
  /**
   * Retrieves a list of Person Relationship details for adding a case member to
   * an integrated case. The returned list removes any cancelled relationships
   * or any that are already a case member.
   *
   * @param key
   * The concern role ID of the primary case member.
   *
   * @return The list of active relationships that are not already members of
   * the case.
   */

  public ListRelationshipForCaseMemberDetails1 listRelationshipForCaseMember1(
    final ReadRelationshipListForCaseMemberKey key) throws AppException,
      InformationalException {
    // Get the primary concern role of the case
    final curam.core.sl.intf.Case caseObj = CaseFactory.newInstance();
    final curam.core.sl.struct.CaseKey caseKey = new curam.core.sl.struct.CaseKey();

    caseKey.key.caseID = key.caseID;

    final long primaryConcernRoleID = caseObj.getConcernRoleDetailsByCaseID(caseKey).concernRoleID;

    // Maintain Concern Role Relationships object.
    final MaintainConcernRoleRelationships maintainRelationshipsObj = MaintainConcernRoleRelationshipsFactory.newInstance();

    // BEGIN, CR00289744, ELG
    CaseIDConcernRoleID caseIDConcernRoleID = new CaseIDConcernRoleID();

    caseIDConcernRoleID.caseID = key.caseID;
    caseIDConcernRoleID.concernRoleID = primaryConcernRoleID;

    // Read the list of Person Relationship records.
    final MaintainConcernRoleRelationshipList1 maintainConcernRoleRelationshipList1 = maintainRelationshipsObj.searchActiveRelationshipsByConcernRoleForCase(
      caseIDConcernRoleID);
    // END, CR00289744

    // CaseParticipantRole manipulation variables
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    // Set key to read list of client roles
    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;
    viewCaseParticipantRole_boKey.showOnlyActive = true;

    // Read the list of case participant roles
    final ViewCaseParticipantRoleDetailsList existingMembersList = caseParticipantRoleObj.viewCaseMemberList(
      viewCaseParticipantRole_boKey);

    // Create a tree map object to store the relationship details.
    // The key is the concern role id and the value is the
    final TreeMap<Long, MaintainConcernRoleRelationshipRMDetails1> treeMap = new TreeMap<Long, MaintainConcernRoleRelationshipRMDetails1>();

    // Loop through the list of relationships and build up the tree map
    // to be used to filter the relationships
    for (int i = 0; i < maintainConcernRoleRelationshipList1.dtls.size(); i++) {
      // Add it to the map
      treeMap.put(
        maintainConcernRoleRelationshipList1.dtls.item(i).concernRoleID,
        maintainConcernRoleRelationshipList1.dtls.item(i));
    }

    // Remove any relationships from the map that are already members
    for (int j = 0; j < existingMembersList.dtls.size(); j++) {
      treeMap.remove(existingMembersList.dtls.item(j).participantRoleID);
    }

    // BEGIN, CR00344436, MC
    // Remove any prospects that are case members that have been registered.
    ProspectPersonKey prospectPersonKey = new ProspectPersonKey();
    MaintainConcernRoleRelationshipRMDetails1 caseParticipantRoleDetails;
    long personConcernRoleID;
    
    for (int i = 0; i < maintainConcernRoleRelationshipList1.dtls.size(); i++) {
      caseParticipantRoleDetails = maintainConcernRoleRelationshipList1.dtls.item(
        i);
      
      if (caseParticipantRoleDetails.concernRoleType.equals(
        curam.codetable.CONCERNROLETYPE.PROSPECTPERSON)) {       
        // Read the person for the prospect
        prospectPersonKey.concernRoleID = caseParticipantRoleDetails.concernRoleID;
        personConcernRoleID = ProspectPersonFactory.newInstance().read(prospectPersonKey).personConcernRoleID;

        // If the primary client on the case is a registered prospect
        if (personConcernRoleID
          == CaseFactory.newInstance().getConcernRoleDetailsByCaseID(caseKey).concernRoleID) {
          treeMap.remove(caseParticipantRoleDetails.concernRoleID);
        }
        // Check if the person that the prospect was registered to is not also a case member 
        for (int x = 0; x < existingMembersList.dtls.size(); x++) {
          // If the prospect has been registered and the registered person is a member
          if (existingMembersList.dtls.item(x).participantRoleID
            == personConcernRoleID) {
            treeMap.remove(existingMembersList.dtls.item(x).participantRoleID);
          }
        }
      }
    }
    // END, CR00344436 
    
    // Replace all the existing relationships from the return struct and add
    // the
    // filtered ones from the map
    maintainConcernRoleRelationshipList1.dtls.clear();
    maintainConcernRoleRelationshipList1.dtls.addAll(treeMap.values());

    // Define result structure and add the list case members
    final ListRelationshipForCaseMemberDetails1 listRelationshipForCaseMemberDetails1 = new ListRelationshipForCaseMemberDetails1();

    listRelationshipForCaseMemberDetails1.dtls = maintainConcernRoleRelationshipList1;

    // Define context description variables
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    final curam.core.struct.CaseKey caseIDKey = new curam.core.struct.CaseKey();
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    // Set key to read caseHeader
    caseIDKey.caseID = key.caseID;

    // BEGIN, CR00240786, MC
    // Read integrated case details

    if (caseIDKey.caseID != 0
      && (!caseHeaderObj.readCaseTypeCode(caseIDKey).caseTypeCode.equals(
        CASETYPECODE.INVESTIGATIONCASE))) {
      final ICHomePageNameAndType icHomePageNameAndType = caseHeaderObj.readICHomePageNameAndType(
        caseIDKey);

      // Set key to read context description
      caseContextDescriptionKey.caseID = key.caseID;
      // Read context description and assign to output object
      listRelationshipForCaseMemberDetails1.description = CodeTable.getOneItem(
        PRODUCTCATEGORY.TABLENAME, icHomePageNameAndType.integratedCaseType)
          + GeneralConstants.kSpace
          + readCaseContextDescription(caseContextDescriptionKey).description;
    }
    // END, CR00240786
    // Return the details.
    return listRelationshipForCaseMemberDetails1;
  }

  // END, CR00205274

  // ___________________________________________________________________________
  /**
   * Approves evidence on a case.
   *
   * @param key
   * Key to approve the evidence
   *
   * @deprecated Since Curam 6.0.
   */
  @Deprecated
  public void approveEvidence(final ApproveEvidenceKey key) throws AppException,
      InformationalException {

    // MaintainEvidence BPO manipulation variables
    final curam.core.intf.MaintainEvidence maintainEvidenceObj = curam.core.fact.MaintainEvidenceFactory.newInstance();
    final EvidenceApprovalKey evidenceApprovalKey = new EvidenceApprovalKey();

    // Assign approval key details
    evidenceApprovalKey.assign(key);

    // Call MaintainEvidence BPO to approve evidence
    maintainEvidenceObj.approveEvidence(evidenceApprovalKey);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListEvidenceDetails listEvidence(final ListEvidenceKey key)
    throws AppException, InformationalException {

    // Create return object
    final ListEvidenceDetails listEvidenceDetails = new ListEvidenceDetails();

    // Manipulate Evidence Tree variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    final ListEvidenceTreeLessCanceledAndSupersededKey listEvidenceTreeLessCanceledAndSupersededKey = new ListEvidenceTreeLessCanceledAndSupersededKey();
    ListEvidenceTreeLessCanceledAndSupersededResult listEvidenceTreeLessCanceledAndSupersededResult;

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    listEvidenceTreeLessCanceledAndSupersededKey.key.caseID = key.caseID;
    listEvidenceTreeLessCanceledAndSupersededKey.key.statusCode = EVIDENCETREESTATUS.CANCELED;
    listEvidenceTreeLessCanceledAndSupersededKey.key.statusCode = EVIDENCETREESTATUS.SUPERSEDED;

    // Call API method to retrieve the evidence list
    listEvidenceTreeLessCanceledAndSupersededResult = caseEvidenceAPIObj.listEvidenceTreeLessCanceledAndSuperseded(
      listEvidenceTreeLessCanceledAndSupersededKey);

    // Check to see if list is populated
    if (!listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.isEmpty()) {

      final CaseEvidenceTreeKeyStruct caseEvidenceTreeKeyStruct = new CaseEvidenceTreeKeyStruct();
      ListGroupOnTreeResult listGroupOnTreeResult;

      // Set key to list groups on tree
      caseEvidenceTreeKeyStruct.caseEvidenceTreeID = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(0).caseEvidenceTreeID;

      // Call API method to list groups on tree
      listGroupOnTreeResult = caseEvidenceAPIObj.listGroupOnTree(
        caseEvidenceTreeKeyStruct);

      // Reserve space in return object
      listEvidenceDetails.evidenceDetailsList.dtls.ensureCapacity(
        listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.size());

      EvidenceDetails evidenceDetails;

      // Iterate through and process the list of evidences
      for (int i = 0; i
        < listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.size(); i++) {

        evidenceDetails = new EvidenceDetails();

        // Assign details
        evidenceDetails.evidenceID = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).caseEvidenceTreeID;
        evidenceDetails.effectiveFrom = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).effectiveFrom;
        evidenceDetails.statusCode = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).statusCode;
        evidenceDetails.versionNo = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).versionNo;
        // Only one product exists on demo products, so select first
        // element in list
        evidenceDetails.evidenceGroupNameCode = listGroupOnTreeResult.dtls.item(0).evidenceGroupNameCode;

        // Check to see if the effectiveFromDate is empty
        if (listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).effectiveFrom.isZero()) {

          // BEGIN, CR00222190, ELG
          evidenceDetails.evidenceFromStr = CASENOTE.INF_CASE_START_DATE.getMessageText(
            TransactionInfo.getProgramLocale());
          // END, CR00222190

        } else {

          // BEGIN, CR00086110, POB
          // Removing FormatDate usage from codebase
          evidenceDetails.evidenceFromStr = listEvidenceTreeLessCanceledAndSupersededResult.dtls.dtls.item(i).effectiveFrom.toString();
          // END, CR00086110
        }

        // Add details to return object
        listEvidenceDetails.evidenceDetailsList.dtls.addRef(evidenceDetails);
      }

    }

    // Set key to read context description
    caseContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listEvidenceDetails.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    return listEvidenceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Cancels a communication on a case.
   *
   * @param key
   * Key to cancel the communication.
   */
  public void cancelCommunication(final CancelCommunicationKey key)
    throws AppException, InformationalException {

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    final CancelConcernRoleCommKey cancelConcernRoleCommKey = new CancelConcernRoleCommKey();

    // Assign key details to cancel the communication
    cancelConcernRoleCommKey.assign(key);

    // Call MaintainConcernRoleComm BPO to cancel the communication
    maintainConcernRoleCommObj.cancelCommunication(cancelConcernRoleCommKey);
  }

  // ___________________________________________________________________________
  /**
   * Creates a communication on a case.
   *
   * @param details
   * Details to create the communication.
   *
   * @deprecated Since Curam 6.0, because all calls to {@link #curam.core.intf.MaintainConcernRoleComm} have been
   * replaced by {@link #curam.core.sl.impl.Communication}
   */
  @Deprecated
  public void createCommunication(final CreateCommunicationDetails details)
    throws AppException, InformationalException {

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    final curam.core.struct.CommunicationDetails communicationDetails = new curam.core.struct.CommunicationDetails();
    final MaintainCommunicationKey maintainCommunicationKey = new MaintainCommunicationKey();

    // Set key details to create the communication
    maintainCommunicationKey.caseID = details.caseID;
    maintainCommunicationKey.concernRoleID = details.concernRoleID;

    // Assign details to create the communication
    communicationDetails.assign(details);

    // Call MaintainConcernRoleComm BPO to create the communication
    maintainConcernRoleCommObj.createCommunication(maintainCommunicationKey,
      communicationDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modifies the details of a communication on a case.
   *
   * @param details
   * Details to modify the communication.
   */
  public void modifyCommunication(final ModifyCommunicationDetails details)
    throws AppException, InformationalException {

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    final curam.core.struct.CommunicationDetails communicationDetails = new curam.core.struct.CommunicationDetails();

    // Assign details to modify the communication
    communicationDetails.assign(details);

    // Call MaintainConcernRoleComm BPO to modify the communication
    maintainConcernRoleCommObj.modifyCommunication(communicationDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads details of a case communication.
   *
   * @param key
   * Key to read the communication details.
   *
   * @return Details of the communication.
   */
  public ReadCommunicationDetails readCommunication(final ReadCommunicationKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadCommunicationDetails readCommunicationDetails = new ReadCommunicationDetails();

    // MaintainConcernRoleComm manipulation variables
    final curam.core.intf.MaintainConcernRoleComm maintainConcernRoleCommObj = curam.core.fact.MaintainConcernRoleCommFactory.newInstance();
    final ReadConcernRoleCommKey readConcernRoleCommKey = new ReadConcernRoleCommKey();

    // Set key to read the case communication details
    readConcernRoleCommKey.communicationID = key.communicationID;

    // Call MaintainConcernRoleComm BPO to read the communication details
    // and assign to return object
    readCommunicationDetails.assign(
      maintainConcernRoleCommObj.readCommunication(readConcernRoleCommKey));

    return readCommunicationDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseNomineeModifyViewDetails readNomineeForUpdate(
    final CaseNomineeViewKey key) throws AppException, InformationalException {

    // service layer case nominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();
    final curam.core.sl.struct.CaseNomineeViewKey caseNomineeViewKey = new curam.core.sl.struct.CaseNomineeViewKey();

    final CaseNomineeContextDescriptionKey caseNomineeContextDescriptionKey = new CaseNomineeContextDescriptionKey();

    // return struct
    final CaseNomineeModifyViewDetails caseNomineeModifyViewDetails = new CaseNomineeModifyViewDetails();

    caseNomineeViewKey.caseNomineeViewKey.caseNomineeID = key.caseNomineeViewKey.caseNomineeViewKey.caseNomineeID;

    caseNomineeModifyViewDetails.caseNomineeModifyViewDetails = caseNomineeObj.viewCaseNomineeForUpdate(
      caseNomineeViewKey);

    caseNomineeContextDescriptionKey.caseNomineeID = caseNomineeViewKey.caseNomineeViewKey.caseNomineeID;

    caseNomineeModifyViewDetails.caseNomineeContextDescription_fo = readCaseNomineeContextDescription(
      caseNomineeContextDescriptionKey);

    return caseNomineeModifyViewDetails;
  }

  // BEGIN, CR00194084, GD
  // ___________________________________________________________________________
  /**
   * @param modifyCaseNomineeAddressDetails
   * contains modified case nominee address details
   * @deprecated Since Curam 6.0, replaced by {@link #modifyNomineeAddress()}.
   * This method has been deprecated as new processing has been
   * introduced when modifying a case nominee's address details.
   *
   * Updates the Case Nominee's Address information.
   */
  @Deprecated
  public void modifyCaseNomineeAddress(
    final ModifyCaseNomineeAddressDetails modifyCaseNomineeAddressDetails)
    throws AppException, InformationalException {

    // service layer case nominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    caseNomineeObj.modifyCaseNomineeAddress(
      modifyCaseNomineeAddressDetails.modifyDestinationDetails);
  }

  // END, CR00194084

  // ___________________________________________________________________________
  /**
   * @param modifyCaseNomineeBankAccountDetails
   * contains modified case nominee bank account details
   * @deprecated Since Curam 6.0, replaced by
   * {@link #modifyNomineeBankAccount()}. This method has been
   * deprecated as new processing has been introduced when modifying
   * a case nominee's bank account details.
   *
   * Updates the Case Nominee's Bank Account information.
   */
  @Deprecated
  public void modifyCaseNomineeBankAccount(
    final ModifyCaseNomineeBankAccountDetails modifyCaseNomineeBankAccountDetails)
    throws AppException, InformationalException {

    // service layer case nominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    caseNomineeObj.modifyCaseNomineeBankAccount(
      modifyCaseNomineeBankAccountDetails.modifyDestinationDetails);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void modifyCaseNomineeProdDelPattern(
    final curam.core.sl.struct.ModifyCaseNomineeProdDelPattDetails modifyCaseNomineeProdDelPatternDetails)
    throws AppException, InformationalException {

    // service layer case nominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    caseNomineeObj.modifyCaseNomineeProdDelPatt(
      modifyCaseNomineeProdDelPatternDetails);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList createCaseNomineeProdDelPattern(
    final CreateCaseNomineeProdDelPattDetails nomineeProdDelPattDtls)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // Call service layer method
    caseNomineeObj.createCaseNomineeProdDelPatt(nomineeProdDelPattDtls);

    // Create return object.
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }

    return informationMsgDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Resolves the case type code.
   *
   * @param key
   * Key to read the case type code.
   *
   * @return Contains the case type code.
   */
  public CaseTypeDetails resolveCaseType(final ReadCaseTypeKey key)
    throws AppException, InformationalException {

    // Create return object
    final CaseTypeDetails caseTypeDetails = new CaseTypeDetails();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;
    final CaseKey caseKey = new CaseKey();

    // Set key to read caseHeader
    caseHeaderKey.caseID = key.caseID;

    // Read caseHeader
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Set caseKey for reads inside if statement
    caseKey.caseID = key.caseID;

    caseTypeDetails.caseTypeCode.caseTypeCode = caseHeaderDtls.caseTypeCode;

    return caseTypeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Resolves the case home page name.
   *
   * @param key
   * Key to read the case home page name.
   *
   * @return Contains the case home page name.
   */
  public CaseHomePageDetails resolveCaseHomePageName(final ReadCaseHomePageKey key)
    throws AppException, InformationalException {

    // Create return object
    final CaseHomePageDetails caseHomePageDetails = new CaseHomePageDetails();

    // BEGIN, CR00365714, ZV
    final curam.piwrapper.caseheader.impl.CaseHeader caseHeader = caseHeaderDAO.get(
      key.caseID);

    caseHomePageDetails.homePageName = caseHeader.getHomePageName().getPageName();
    // END, CR00365714
    
    return caseHomePageDetails;
  }

  // BEGIN, CR00165745, PDN
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains caseID, calendar date and the calendar view type.
   *
   * @return Data representing case events and activities
   * @deprecated Since Curam 6.0, replaced by
   * {@link #searchCaseEventAndActivity1()}.
   *
   * Returns data representing case events and activities for a case
   * calendar.
   */
  @Deprecated
  public CaseEventAndActivityDetails searchCaseEventAndActivity(
    final SearchCaseEventAndActivityKey key) throws AppException,
      InformationalException {

    // CalendarData Objects
    final curam.core.sl.intf.CalendarData calendarDataObj = curam.core.sl.fact.CalendarDataFactory.newInstance();
    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // ViewCaseEvents Objects
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory.newInstance();
    ViewCaseEventDetailsList viewCaseEventDetailsList;
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();

    // Element details objects
    final ActivityElementDetails activityElementDetails = new ActivityElementDetails();
    final EventElementDetails eventElementDetails = new EventElementDetails();

    // Calendar data
    final CaseEventAndActivityDetails caseEventAndActivityDetails = new CaseEventAndActivityDetails();

    if (key.startDate.isZero()) {
      key.startDate = curam.util.type.Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;

    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Get case events and activities
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;
    viewCaseEventDetailsList = viewCaseEventsObj.readEventsByType(
      viewCaseEventsByCaseIDAndTypeKey);

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
      kBufferSize * viewCaseEventDetailsList.dtls.size());

    // BEGIN, CR00023323, SK
    xmlString.append(CuramCalendarHeaderConst.kCuramCalendarDataHeader);
    xmlString.append(
      CuramCalendarHeaderConst.kQuote
        + curam.util.type.CodeTable.getOneItem(CALENDARTYPE.TABLENAME,
        CALENDARTYPE.CASE)
        + CuramCalendarHeaderConst.kQuote);
    xmlString.append(CuramCalendarHeaderConst.kCloseBracket);
    xmlString.append(CuramCalendarHeaderConst.kSpace);
    // END, CR00023323
    // Loop through list of activities and events
    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      // If it's an activity
      if (viewCaseEventDetailsList.dtls.item(i).typeCode.equals(
        curam.codetable.CASEEVENTTYPE.ACTIVITY)) {

        // Set element details
        activityElementDetails.activityID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        activityElementDetails.acceptanceProvisionalInd = viewCaseEventDetailsList.dtls.item(i).acceptanceInd;
        activityElementDetails.activityTypeCode = curam.codetable.ACTIVITYTYPE.APPOINTMENT;
        activityElementDetails.allDayInd = viewCaseEventDetailsList.dtls.item(i).startAllDayInd;
        activityElementDetails.attendeeInd = viewCaseEventDetailsList.dtls.item(i).attendeeInd;
        activityElementDetails.endDateTime = viewCaseEventDetailsList.dtls.item(i).endDateTime;
        activityElementDetails.priorityCode = viewCaseEventDetailsList.dtls.item(i).priorityCode;
        activityElementDetails.readOnlyInd = viewCaseEventDetailsList.dtls.item(i).readOnlyInd;
        activityElementDetails.recurringInd = viewCaseEventDetailsList.dtls.item(i).recurringInd;
        activityElementDetails.startDateTime = viewCaseEventDetailsList.dtls.item(i).startDateTime;
        activityElementDetails.subject = viewCaseEventDetailsList.dtls.item(i).subject;
        activityElementDetails.timeStatusCode = viewCaseEventDetailsList.dtls.item(i).timeStatusCode;

        // Parse the activity
        calendarElementData = calendarDataObj.parseActivity(
          activityElementDetails, dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);

      } else {

        eventElementDetails.eventStartDate = viewCaseEventDetailsList.dtls.item(i).startDateTime;
        eventElementDetails.eventEndDate = viewCaseEventDetailsList.dtls.item(i).endDateTime;

        // This is an event
        eventElementDetails.eventID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        eventElementDetails.eventDescription = viewCaseEventDetailsList.dtls.item(i).subject;

        // Start date = end date for events
        eventElementDetails.eventDate = new curam.util.type.Date(
          viewCaseEventDetailsList.dtls.item(i).startDateTime.getCalendar());

        eventElementDetails.eventType = viewCaseEventDetailsList.dtls.item(i).typeCode;

        // if it is a event of type case decision with a status of
        // superseded
        // do not add to the calendar
        final curam.core.intf.CaseDecision caseDecisionObj = curam.core.fact.CaseDecisionFactory.newInstance();
        curam.core.struct.CaseDecisionDtls caseDecisionDtls = null;
        boolean caseEventTypeDecisionInd = true;

        final curam.core.struct.CaseDecisionKey caseDecisionKey = new curam.core.struct.CaseDecisionKey();

        caseDecisionKey.caseDecisionID = viewCaseEventDetailsList.dtls.item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          caseEventTypeDecisionInd = false;
        }

        // If event of type caseDecision, then only add to calendar if
        // an active
        // case decision
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode.equals(
            curam.codetable.CASEDECISIONSTATUS.CURRENT)) {

            // Parse the event
            calendarElementData = calendarDataObj.parseEvent(
              eventElementDetails, dateTimeRangeDetails);

            // Add it to the string
            xmlString.append(calendarElementData.calendarXMLString);
          }

        } else {

          // Parse the event
          calendarElementData = calendarDataObj.parseEvent(eventElementDetails,
            dateTimeRangeDetails);

          // Add it to the string
          xmlString.append(calendarElementData.calendarXMLString);

        }
      }

    }

    // Create CURAM_CALENDAR_DATA node footer.
    xmlString.append(CuramCalendarHeaderConst.kCuramCalendarDataFooter);
    // BEGIN, CR00023323, SK
    xmlString.append(CuramConst.gkSpace);
    // END, CR00023323
    caseEventAndActivityDetails.calendarXMLString = xmlString.toString();

    // Return the case context description.
    final CaseContextDescriptionKey contextDescriptionKey = new CaseContextDescriptionKey();

    contextDescriptionKey.caseID = key.caseID;
    caseEventAndActivityDetails.contextDescription = readCaseContextDescription(
      contextDescriptionKey);

    return caseEventAndActivityDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns data representing case events and activities for a case calendar.
   *
   * @param key
   * Contains caseID, calendar date and the calendar view type.
   *
   * @return Data representing case events and activities
   */
  public CaseEventAndActivityDetails1 searchCaseEventAndActivity1(
    final SearchCaseEventAndActivityKey key) throws AppException,
      InformationalException {
    // CalendarData Objects
    final curam.core.sl.intf.CalendarData calendarDataObj = curam.core.sl.fact.CalendarDataFactory.newInstance();
    final DateRangeKey dateRangeKey = new DateRangeKey();
    DateTimeRangeDetails dateTimeRangeDetails;
    CalendarElementData calendarElementData;

    // ViewCaseEvents Objects
    final curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory.newInstance();
    ViewCaseEventDetailsList viewCaseEventDetailsList;
    final ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();

    // Element details objects
    final ActivityElementDetails activityElementDetails = new ActivityElementDetails();
    final EventElementDetails eventElementDetails = new EventElementDetails();

    // Calendar data
    final CaseEventAndActivityDetails1 caseEventAndActivityDetails1 = new CaseEventAndActivityDetails1();

    if (key.startDate.isZero()) {
      key.startDate = curam.util.type.Date.getCurrentDate();
    }

    // Get date range for calendar
    dateRangeKey.calendarViewType = key.calendarViewType;
    dateRangeKey.startDate = key.startDate;

    dateTimeRangeDetails = calendarDataObj.getDateTimeRange(dateRangeKey);

    // Get case events and activities
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;
    viewCaseEventDetailsList = viewCaseEventsObj.readEventsByType(
      viewCaseEventsByCaseIDAndTypeKey);

    // Create CURAM_CALENDAR_DATA node header
    final StringBuffer xmlString = new StringBuffer(
      kBufferSize * viewCaseEventDetailsList.dtls.size());

    xmlString.append(CuramCalendarHeaderConst.kCuramCalendarDataHeader);
    xmlString.append(
      CuramCalendarHeaderConst.kQuote
        + curam.util.type.CodeTable.getOneItem(CALENDARTYPE.TABLENAME,
        CALENDARTYPE.CASE)
        + CuramCalendarHeaderConst.kQuote);
    xmlString.append(CuramCalendarHeaderConst.kCloseBracket);
    xmlString.append(CuramCalendarHeaderConst.kSpace);

    // Loop through list of activities and events
    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      // If it's an activity
      if (viewCaseEventDetailsList.dtls.item(i).typeCode.equals(
        curam.codetable.CASEEVENTTYPE.ACTIVITY)) {

        // Set element details
        activityElementDetails.activityID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        activityElementDetails.acceptanceProvisionalInd = viewCaseEventDetailsList.dtls.item(i).acceptanceInd;
        activityElementDetails.activityTypeCode = curam.codetable.ACTIVITYTYPE.APPOINTMENT;
        activityElementDetails.allDayInd = viewCaseEventDetailsList.dtls.item(i).startAllDayInd;
        activityElementDetails.attendeeInd = viewCaseEventDetailsList.dtls.item(i).attendeeInd;
        activityElementDetails.endDateTime = viewCaseEventDetailsList.dtls.item(i).endDateTime;
        activityElementDetails.priorityCode = viewCaseEventDetailsList.dtls.item(i).priorityCode;
        activityElementDetails.readOnlyInd = viewCaseEventDetailsList.dtls.item(i).readOnlyInd;
        activityElementDetails.recurringInd = viewCaseEventDetailsList.dtls.item(i).recurringInd;
        activityElementDetails.startDateTime = viewCaseEventDetailsList.dtls.item(i).startDateTime;
        activityElementDetails.subject = viewCaseEventDetailsList.dtls.item(i).subject;
        activityElementDetails.timeStatusCode = viewCaseEventDetailsList.dtls.item(i).timeStatusCode;

        // Parse the activity
        calendarElementData = calendarDataObj.parseActivity(
          activityElementDetails, dateTimeRangeDetails);

        // Add it to the string
        xmlString.append(calendarElementData.calendarXMLString);

      } else {

        eventElementDetails.eventStartDate = viewCaseEventDetailsList.dtls.item(i).startDateTime;
        eventElementDetails.eventEndDate = viewCaseEventDetailsList.dtls.item(i).endDateTime;

        // This is an event
        eventElementDetails.eventID = viewCaseEventDetailsList.dtls.item(i).relatedID;
        eventElementDetails.eventDescription = viewCaseEventDetailsList.dtls.item(i).subject;

        // Start date = end date for events
        eventElementDetails.eventDate = new curam.util.type.Date(
          viewCaseEventDetailsList.dtls.item(i).startDateTime.getCalendar());

        eventElementDetails.eventType = viewCaseEventDetailsList.dtls.item(i).typeCode;

        // if it is a event of type case decision with a status of
        // superseded
        // do not add to the calendar
        final curam.core.intf.CaseDecision caseDecisionObj = curam.core.fact.CaseDecisionFactory.newInstance();
        curam.core.struct.CaseDecisionDtls caseDecisionDtls = null;
        boolean caseEventTypeDecisionInd = true;

        final curam.core.struct.CaseDecisionKey caseDecisionKey = new curam.core.struct.CaseDecisionKey();

        caseDecisionKey.caseDecisionID = viewCaseEventDetailsList.dtls.item(i).relatedID;

        try {
          caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);
        } catch (final curam.util.exception.RecordNotFoundException e) {
          caseEventTypeDecisionInd = false;
        }

        // If event of type caseDecision, then only add to calendar if
        // an active
        // case decision
        if (caseEventTypeDecisionInd) {
          if (caseDecisionDtls.statusCode.equals(
            curam.codetable.CASEDECISIONSTATUS.CURRENT)) {

            // Parse the event
            calendarElementData = calendarDataObj.parseEvent(
              eventElementDetails, dateTimeRangeDetails);

            // Add it to the string
            xmlString.append(calendarElementData.calendarXMLString);
          }

        } else {

          // Parse the event
          calendarElementData = calendarDataObj.parseEvent(eventElementDetails,
            dateTimeRangeDetails);

          // Add it to the string
          xmlString.append(calendarElementData.calendarXMLString);

        }
      }

    }

    // Create CURAM_CALENDAR_DATA node footer.
    xmlString.append(CuramCalendarHeaderConst.kCuramCalendarDataFooter);

    xmlString.append(CuramConst.gkSpace);

    caseEventAndActivityDetails1.calendarXMLString = xmlString.toString();

    // Return the case context description.
    final CaseContextDescriptionKey contextDescriptionKey = new CaseContextDescriptionKey();

    contextDescriptionKey.caseID = key.caseID;
    caseEventAndActivityDetails1.contextDescription = readCaseContextDescription(
      contextDescriptionKey);

    // Determine if CPM and Appeals are installed
    if (Configuration.getBooleanProperty(EnvVars.ENV_CPM_ISINSTALLED)) {
      caseEventAndActivityDetails1.isCPMInstalled = true;
    }

    if (Configuration.getBooleanProperty(EnvVars.ENV_APPEALS_ISINSTALLED)) {
      caseEventAndActivityDetails1.isAppealsInstalled = true;
    }

    return caseEventAndActivityDetails1;
  }

  // END, CR00165745
  // BEGIN, CR00232960, JMA
  // ___________________________________________________________________________
  /**
   * Resolves the case context panel.
   *
   * @param key
   * Key to read the case context panel.
   *
   * @return Contains the case context panel name.
   */
  public ContextPanelName resolveContextPanel(final CaseContextPanelKey key)
    throws AppException, InformationalException {

    final ContextPanelName contextPanelName = new ContextPanelName();

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;
    final CaseKey caseKey = new CaseKey();

    // Set key to read caseHeader
    caseHeaderKey.caseID = key.caseID;

    // Read caseHeader
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Set caseKey for reads inside if statement
    caseKey.caseID = key.caseID;

    if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.PRODUCTDELIVERY)
        || (caseHeaderDtls.caseTypeCode.equals(
          curam.codetable.CASETYPECODE.LIABILITY))) {

      // ProductDelivery manipulation variable
      final curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
      final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      ProductDeliveryDtls productDeliveryDtls;

      // Set key to read productDelivery
      productDeliveryKey.caseID = key.caseID;

      // Read productDelivery
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);
      // BEGIN, CR00250584, RCB
      if (productDeliveryDtls.productType.equals(PRODUCTTYPE.PAYMENTCORRECTION)) {

        contextPanelName.homePageName = CuramConst.PaymentCorrectionPreviewPage;

      } else if (productDeliveryDtls.productType.equals(PRODUCTTYPE.LOAN)) {

        contextPanelName.homePageName = CuramConst.LiabilitySamplePreviewPage;

      } else if (productDeliveryDtls.productType.equals(
        PRODUCTTYPE.BENEFITOVERPAYMENT)) {

        contextPanelName.homePageName = CuramConst.BenefitSampleOverpaymentPreviewPage;

      } else if (productDeliveryDtls.productType.equals(
        PRODUCTTYPE.BENEFITUNDERPAYMENT)) {

        contextPanelName.homePageName = CuramConst.ICBenefitUnderPaymentPreviewPage;
      } else {
        // START,CR00247042,MJ
        Product productObj = ProductFactory.newInstance();
        ReadBenefitProductKey readBenefitProductKey = new ReadBenefitProductKey();

        readBenefitProductKey.productID = productDeliveryDtls.productID;
        ReadBenefitProductStruct1 benefitProduct = productObj.readBenefitProduct1(
          readBenefitProductKey);
        ProductKeyStruct productKeyStruct = new ProductKeyStruct();

        productKeyStruct.productID = productDeliveryDtls.productID;
        ReadLiabilityProductStruct1 liabilityProduct = productObj.readLiabilityProduct1(
          productKeyStruct);

        if (benefitProduct.benefitHomePageDetails.caseHomePageName.equals(
          CuramConst.kProductCaseHomePage)
            || liabilityProduct.liabilityProductDetails.caseHomePageName.equals(
              CuramConst.kProductCaseHomePage)) {
          contextPanelName.homePageName = CuramConst.productDeliveryPreviewPage;
        } else {
          contextPanelName.homePageName = CuramConst.ProductDeliveryTabPreviewPage;
        }
        // END,CR00247042,MJ
      }

    } else if (caseHeaderDtls.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.INTEGRATEDCASE)) {
      // START,CR00247042,MJ
      AdminIntegratedCase adminIntegratedCaseObj = AdminIntegratedCaseFactory.newInstance();
      AdminIntegratedCaseKey adminIntegratedCaseKey = new AdminIntegratedCaseKey();

      adminIntegratedCaseKey.adminIntegratedCaseID = caseHeaderDtls.integratedCaseID;

      IntegratedCaseTypeStruct icTypeStruct = new IntegratedCaseTypeStruct();

      icTypeStruct.integratedCaseType = caseHeaderDtls.integratedCaseType;
      AdminIntegratedCaseDtls adminIntegratedCaseDtls = adminIntegratedCaseObj.readAdminIntegratedCaseByType(
        icTypeStruct);

      if (adminIntegratedCaseDtls.homePageName.equals(
        CuramConst.integratedCaseHomePage)
          && caseHeaderDtls.integratedCaseType.equals(
            adminIntegratedCaseDtls.integratedCaseType)) {
        contextPanelName.homePageName = CuramConst.integratedCasePreviewPage;
      } else {
        contextPanelName.homePageName = CuramConst.IntegratedCaseTabPreviewPage;

      }
      // END,CR00247042,MJ


    } else if (caseHeaderDtls.caseTypeCode.equals(
      CASETYPECODE.INVESTIGATIONCASE)) {

      contextPanelName.homePageName = CuramConst.InvestigationPreviewPage;

    } else {
      // Display home details if no context panel details exist

      final ReadCaseHomePageKey readCaseHomePageKey = new ReadCaseHomePageKey();

      readCaseHomePageKey.caseID = key.caseID;

      final CaseHomePageDetails caseHomePageDetails = resolveCaseHomePageName(
        readCaseHomePageKey);

      contextPanelName.homePageName = caseHomePageDetails.homePageName;

    }
    // END, CR00250584

    contextPanelName.homePageName += CuramConst.kQuestion
      + CuramConst.gkPageParameterCaseID + CuramConst.gkEqualsNoSpaces
      + key.caseID;

    return contextPanelName;
  }

  // END, CR00232960
  // ___________________________________________________________________________
  /**
   * Submits reassigning all cases from one user to another for delayed
   * processing.
   *
   * @param details
   * Contains old and new user identifications.
   */
  public void submitReassignAllCasesToAnotherUser(
    final ReassignAllCasesDetails details) throws AppException,
      InformationalException {

    // WMInstanceData manipulation variables
    final curam.core.intf.WMInstanceData wmInstanceDataObj = curam.core.fact.WMInstanceDataFactory.newInstance();
    final WMInstanceDataDtls wmInstanceDataDtls = new WMInstanceDataDtls();

    // Deferred processing manipulation variables

    final curam.util.intf.DeferredProcessing dpEnactmentServiceObj = curam.util.fact.DeferredProcessingFactory.newInstance();

    // Create new WMInstanceData record
    wmInstanceDataDtls.assign(details);

    wmInstanceDataDtls.wm_instDataID = curam.util.type.UniqueID.nextUniqueID(
      curam.util.resources.KeySet.kKeySetDeferredProcessingTicket);

    wmInstanceDataDtls.enteredByID = curam.util.transaction.TransactionInfo.getProgramUser();

    wmInstanceDataObj.insert(wmInstanceDataDtls);

    dpEnactmentServiceObj.startProcess(DP_const.DP_REASSIGN_CASES,
      wmInstanceDataDtls.wm_instDataID);

  }

  // ___________________________________________________________________________
  /**
   * Modifies details of a client role.
   *
   * @param details
   * Modified client role details.
   */
  public void modifyClientRole(final ModifyClientRoleDetails details)
    throws AppException, InformationalException {

    // CaseParticipantRoleModifyDetails object
    final curam.core.sl.struct.CaseParticipantRoleModifyDetails caseParticipantRoleModifyDetails = new curam.core.sl.struct.CaseParticipantRoleModifyDetails();

    // CaseParticipantRole object
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    // Assign details for modify
    caseParticipantRoleModifyDetails.dtls.caseParticipantRoleID = details.caseParticipantRoleID;
    caseParticipantRoleModifyDetails.dtls.fromDate = details.fromDate;
    caseParticipantRoleModifyDetails.dtls.toDate = details.toDate;
    caseParticipantRoleModifyDetails.dtls.versionNo = details.versionNo;

    // Call business layer operation to perform the modify
    caseParticipantRole_boObj.modifyCaseParticipantRole(
      caseParticipantRoleModifyDetails);
  }

  // BEGIN, CR00213628, PB
  // ___________________________________________________________________________
  /**
   * Modifies translator required details of a client role.
   *
   * @param details
   * Modified translator required details.
   */
  public void modifyTranslatorRequiredDetails(
    final ModifyTranslatorRequiredDetails details) throws AppException,
      InformationalException {

    // CaseParticipantRoleModifyDetails object
    final ModifyTranslatorRequiredDetails modifyTranslatorRequiredDetails = new ModifyTranslatorRequiredDetails();

    // CaseParticipantRole object
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseParticipantRoleKey key = new curam.core.sl.entity.struct.CaseParticipantRoleKey();

    modifyTranslatorRequiredDetails.caseParticipantRoleID = details.caseParticipantRoleID;
    modifyTranslatorRequiredDetails.versionNo = details.versionNo;
    if (details.translationRequiredInd) {
      modifyTranslatorRequiredDetails.translationRequiredInd = false;
    } else {
      modifyTranslatorRequiredDetails.translationRequiredInd = true;
    }

    key.caseParticipantRoleID = details.caseParticipantRoleID;
    
    // BEGIN, CR00407868, SG
    final CaseParticipantRole_boKey caseParticipantRole_boKey = new CaseParticipantRole_boKey();

    caseParticipantRole_boKey.caseParticipantRoleID = details.caseParticipantRoleID;
    
    CaseParticipantRoleFactory.newInstance().checkDataBasedSecurity(
      caseParticipantRole_boKey);
    // END, CR00407868

    caseParticipantRole_boObj.modifyTranslatorRequired(key,
      modifyTranslatorRequiredDetails);

  }

  // END, CR00213628
  // ___________________________________________________________________________
  /**
   * Modifies details of a case member
   *
   * @param details
   * Case member details to be modified.
   */
  public void modifyCaseMember(final ModifyClientRoleDetails details)
    throws AppException, InformationalException {

    // CaseParticipantRoleModifyDetails object
    final curam.core.sl.struct.CaseParticipantRoleModifyDetails caseParticipantRoleModifyDetails = new curam.core.sl.struct.CaseParticipantRoleModifyDetails();

    // CaseParticipantRole object
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    // Assign details for modify
    caseParticipantRoleModifyDetails.dtls.caseParticipantRoleID = details.caseParticipantRoleID;
    caseParticipantRoleModifyDetails.dtls.fromDate = details.fromDate;
    caseParticipantRoleModifyDetails.dtls.toDate = details.toDate;
    // BEGIN, CR00109196 PA
    caseParticipantRoleModifyDetails.dtls.endReason = details.endReason;
    // END, CR00109196, PA
    caseParticipantRoleModifyDetails.dtls.versionNo = details.versionNo;

    caseParticipantRoleModifyDetails.dtls.comments = details.comments;
    // Call business layer operation to perform the modify
    caseParticipantRole_boObj.modifyCaseParticipantRole(
      caseParticipantRoleModifyDetails);
  }

  // ___________________________________________________________________________
  /**
   * Sets a client as primary on a case.
   *
   * @param key
   * Key to set a client role as the primary client on a case.
   */
  public void setAsPrimaryClient(final SetAsPrimaryClientKey key)
    throws AppException, InformationalException {

    // CaseParticipantRole object
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRole_boKey caseParticipantRole_boKey = new CaseParticipantRole_boKey();

    final SetAsPrimaryClientDetails setAsPrimaryClientDetails = new SetAsPrimaryClientDetails();

    // Assign key details to set client as primary
    caseParticipantRole_boKey.caseParticipantRoleID = key.caseParticipantRoleID;

    setAsPrimaryClientDetails.dtls.caseID = key.caseID;
    setAsPrimaryClientDetails.dtls.caseParticipantRoleID = key.caseParticipantRoleID;
    setAsPrimaryClientDetails.dtls.versionNo = key.versionNo;

    // Set client as primary
    caseParticipantRole_boObj.setToPrimaryClient(setAsPrimaryClientDetails);

  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to modify comments for a case participant.
   *
   * @param details
   * Modified participant role comments details.
   */
  public void modifyParticipantRoleComments(
    final CaseParticipantRoleModifyComments details) throws AppException,
      InformationalException {

    // CaseParticipantRole object
    final curam.core.sl.intf.CaseParticipantRole caseParticipantRole_boObj = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance();

    // Call business layer operation to perform the modify
    caseParticipantRole_boObj.modifyComments(
      details.caseParticipantRoleModifyComments);

  }

  // ___________________________________________________________________________
  /**
   * Protected method to list cases of a specific type for a user.
   *
   * @param key
   * Contains user name and case type code.
   *
   * @return List of case and participant details.
   */
  @Override
  protected ListCasesForUserDetails listCasesForUser(final OwnerAndTypeKey key)
    throws AppException, InformationalException {

    // List to be returned
    final ListCasesForUserDetails listCasesForUserDetails = new ListCasesForUserDetails();

    // MaintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
    CaseAndConcernSummaryDtlsList caseAndConcernSummaryDtlsList;

    // list user cases by type
    caseAndConcernSummaryDtlsList = maintainCaseObj.listUserCasesByType(key);

    listCasesForUserDetails.dtls.assign(caseAndConcernSummaryDtlsList);

    return listCasesForUserDetails;

  }

  // ___________________________________________________________________________
  /**
   * Protected method to list cases of a specific type for participant.
   *
   * @param key
   * Contains case participant ID and case type code.
   *
   * @return List of case and participant details.
   */
  @Override
  protected ListCasesForParticipantDetails listCasesForParticipant(
    final CasesByConcernRoleIDAndTypeKey key) throws AppException,
      InformationalException {

    // List to be returned
    final ListCasesForParticipantDetails listCasesForParticipantDetails = new ListCasesForParticipantDetails();

    // MaintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
    CaseAndConcernSummaryDtlsList caseAndConcernSummaryDtlsList;

    // list participant cases by type
    caseAndConcernSummaryDtlsList = maintainCaseObj.listParticipantCasesByType(
      key);

    // add details to output list
    listCasesForParticipantDetails.dtls.assign(caseAndConcernSummaryDtlsList);

    return listCasesForParticipantDetails;

  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to list all cases for a user.
   *
   * @param key
   * Contains user name.
   *
   * @return List of case and participant details.
   */
  public ListCasesForUserDetails listAllCasesForUser(
    final ListCaseByCurrentUserKey key) throws AppException, InformationalException {

    // OwnerAndType key
    final OwnerAndTypeKey ownerAndTypeKey = new OwnerAndTypeKey();

    // Set the key for reading
    // Note in this instance the case owner will always be a user
    ownerAndTypeKey.dtls.ownerID = key.casesByOwnerKey.ownerID;

    // Return the list of cases
    return listCasesForUser(ownerAndTypeKey);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListCasesForUserDetails listICsForUser(final ListCaseByCurrentUserKey key)
    throws AppException, InformationalException {

    // OwnerAndType key
    final OwnerAndTypeKey ownerAndTypeKey = new OwnerAndTypeKey();

    // Set the key for reading
    // Note in this instance the case owner will always be a user
    ownerAndTypeKey.dtls.ownerID = key.casesByOwnerKey.ownerID;
    ownerAndTypeKey.dtls.caseTypeCode = CASETYPECODE.INTEGRATEDCASE;

    // Return the list of cases
    return listCasesForUser(ownerAndTypeKey);

  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to list Screening Cases for a user.
   *
   * @param key
   * Contains user name.
   *
   * @return List of case and participant details.
   */
  public ListCasesForUserDetails listScreeningCasesForUser(
    final ListCaseByCurrentUserKey key) throws AppException, InformationalException {

    // OwnerAndType key
    final OwnerAndTypeKey ownerAndTypeKey = new OwnerAndTypeKey();

    // Set the key for reading
    // Note in this instance the case owner will always be a user
    ownerAndTypeKey.dtls.ownerID = key.casesByOwnerKey.ownerID;
    ownerAndTypeKey.dtls.caseTypeCode = CASETYPECODE.SCREENINGCASE;

    // Return the list of cases
    return listCasesForUser(ownerAndTypeKey);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListCasesForUserDetails listAssessmentCasesForUser(
    final ListCaseByCurrentUserKey key) throws AppException, InformationalException {

    // OwnerAndType key
    final OwnerAndTypeKey ownerAndTypeKey = new OwnerAndTypeKey();

    // Set the key for reading
    // Note in this instance the case owner will always be a user
    ownerAndTypeKey.dtls.ownerID = key.casesByOwnerKey.ownerID;
    ownerAndTypeKey.dtls.caseTypeCode = CASETYPECODE.ASSESSMENTDELIVERY;

    // Return the list of cases
    return listCasesForUser(ownerAndTypeKey);

  }

  // ___________________________________________________________________________
  /**
   * Presentation layer method to list Product Delivery Cases for a user.
   *
   * @param key
   * Contains user name.
   *
   * @return List of case and participant details.
   */
  public ListCasesForUserDetails listPDCasesForUser(final ListCaseByCurrentUserKey key)
    throws AppException, InformationalException {

    // OwnerAndType key
    final OwnerAndTypeKey ownerAndTypeKey = new OwnerAndTypeKey();

    // Set the key for reading
    // Note in this instance the case owner will always be a user
    ownerAndTypeKey.dtls.ownerID = key.casesByOwnerKey.ownerID;
    ownerAndTypeKey.dtls.caseTypeCode = CASETYPECODE.PRODUCTDELIVERY;

    // Return the list of cases
    return listCasesForUser(ownerAndTypeKey);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListCasesForParticipantDetails listICsForParticipant(
    final CaseParticipantRoleKey key) throws AppException, InformationalException {

    // CasesByConcernRoleIDAndType key
    final CasesByConcernRoleIDAndTypeKey casesByConcernRoleIDAndTypeKey = new CasesByConcernRoleIDAndTypeKey();

    // set the key for reading
    casesByConcernRoleIDAndTypeKey.concernRoleID = key.dtls.caseParticipantRoleID;
    casesByConcernRoleIDAndTypeKey.caseTypeCode = CASETYPECODE.INTEGRATEDCASE;

    // return the list of cases
    return listCasesForParticipant(casesByConcernRoleIDAndTypeKey);

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of Screening Cases for the specified participant.
   *
   * @param key
   * Contains case participant ID.
   *
   * @return List of case and participant details.
   */
  public ListCasesForParticipantDetails listScreeningCasesForParticipant(
    final CaseParticipantRoleKey key) throws AppException, InformationalException {

    // CasesByConcernRoleIDAndType key
    final CasesByConcernRoleIDAndTypeKey casesByConcernRoleIDAndTypeKey = new CasesByConcernRoleIDAndTypeKey();

    // set the key for reading
    casesByConcernRoleIDAndTypeKey.concernRoleID = key.dtls.caseParticipantRoleID;
    casesByConcernRoleIDAndTypeKey.caseTypeCode = CASETYPECODE.SCREENINGCASE;

    // return the list of cases
    return listCasesForParticipant(casesByConcernRoleIDAndTypeKey);

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListCasesForParticipantDetails listAssessmentCasesForParticipant(
    final CaseParticipantRoleKey key) throws AppException, InformationalException {

    // CasesByConcernRoleIDAndType key
    final CasesByConcernRoleIDAndTypeKey casesByConcernRoleIDAndTypeKey = new CasesByConcernRoleIDAndTypeKey();

    // set the key for reading
    casesByConcernRoleIDAndTypeKey.concernRoleID = key.dtls.caseParticipantRoleID;
    casesByConcernRoleIDAndTypeKey.caseTypeCode = CASETYPECODE.ASSESSMENTDELIVERY;

    // return the list of cases
    return listCasesForParticipant(casesByConcernRoleIDAndTypeKey);

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of Product Delivery Cases for the specified participant.
   *
   * @param key
   * Contains case participant ID.
   *
   * @return List of case and participant details.
   */
  public ListCasesForParticipantDetails listPDCasesForParticipant(
    final CaseParticipantRoleKey key) throws AppException, InformationalException {

    // CasesByConcernRoleIDAndType key
    final CasesByConcernRoleIDAndTypeKey casesByConcernRoleIDAndTypeKey = new CasesByConcernRoleIDAndTypeKey();

    // set the key for reading
    casesByConcernRoleIDAndTypeKey.concernRoleID = key.dtls.caseParticipantRoleID;
    casesByConcernRoleIDAndTypeKey.caseTypeCode = CASETYPECODE.PRODUCTDELIVERY;

    // return the list of cases
    return listCasesForParticipant(casesByConcernRoleIDAndTypeKey);

  }

  // ___________________________________________________________________________
  /**
   * Returns a list of all cases for the specified participant.
   *
   * @param key
   * Contains case participant ID.
   *
   * @return List of case and participant details.
   */
  public ListCasesForParticipantDetails listAllCasesForParticipant(
    final CaseParticipantRoleKey key) throws AppException, InformationalException {

    // List to be returned
    final ListCasesForParticipantDetails listCasesForParticipantDetails = new ListCasesForParticipantDetails();

    // MaintainCase manipulation variables
    final curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
    CaseAndConcernSummaryDtlsList caseAndConcernSummaryDtlsList;
    final CaseByConcernRoleIDKey caseByConcernRoleIDKey = new CaseByConcernRoleIDKey();

    caseByConcernRoleIDKey.concernRoleID = key.dtls.caseParticipantRoleID;

    // list participant cases by type
    caseAndConcernSummaryDtlsList = maintainCaseObj.listAllParticipantCases(
      caseByConcernRoleIDKey);

    // add details to output list
    listCasesForParticipantDetails.dtls.assign(caseAndConcernSummaryDtlsList);

    return listCasesForParticipantDetails;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public curam.core.facade.struct.ListEvidenceStatusHistoryResult listEvidenceStatusHistory(
    final curam.core.facade.struct.ListEvidenceStatusHistoryKey key)
    throws AppException, InformationalException {

    // Create return object
    final curam.core.facade.struct.ListEvidenceStatusHistoryResult listEvidenceStatusHistoryResultRet = new curam.core.facade.struct.ListEvidenceStatusHistoryResult();

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    curam.core.sl.struct.ListEvidenceStatusHistoryResult listEvidenceStatusHistoryResult;

    // Call API method to retrieve list of evidence status history records
    listEvidenceStatusHistoryResult = caseEvidenceAPIObj.listEvidenceStatusHistory(
      key.key);

    // Reserve space in return object
    listEvidenceStatusHistoryResultRet.list.details.ensureCapacity(
      listEvidenceStatusHistoryResult.historyList.dtls.size());

    // Evidence Status History manipulation variables
    EvidenceStatusHistoryDetails evidenceStatusHistoryDetails;

    // Iterate through the list
    for (int i = 0; i < listEvidenceStatusHistoryResult.historyList.dtls.size(); i++) {

      // Create new instance of evidenceStatusHistoryDetails
      evidenceStatusHistoryDetails = new EvidenceStatusHistoryDetails();

      // Assign evidence status history details
      evidenceStatusHistoryDetails.assign(
        listEvidenceStatusHistoryResult.historyList.dtls.item(i));

      if (listEvidenceStatusHistoryResult.historyList.dtls.item(i).effectiveFrom.isZero()) {

        // BEGIN, CR00222190, ELG
        evidenceStatusHistoryDetails.effectiveFromStr = CASENOTE.INF_CASE_START_DATE.getMessageText(
          TransactionInfo.getProgramLocale());
        // END, CR00222190

      } else {

        // Need to format effectiveFrom date as a string
        evidenceStatusHistoryDetails.effectiveFromStr = Locale.getFormattedDate(
          listEvidenceStatusHistoryResult.historyList.dtls.item(i).effectiveFrom.getDateTime());
      }

      // Add to return object
      listEvidenceStatusHistoryResultRet.list.details.addRef(
        evidenceStatusHistoryDetails);
    }

    return listEvidenceStatusHistoryResultRet;
  }

  // ___________________________________________________________________________
  /**
   * Resolves the evidence create page to be navigated to.
   *
   * @param key
   * Key to resolve evidence group page.
   *
   * @return Evidence create page.
   */
  public PageIdentifierResult resolveEvidenceCreatePage(
    final ResolveEvidencePageKey key) throws AppException, InformationalException {

    // Create return object
    final PageIdentifierResult pageIdentifierResult = new PageIdentifierResult();

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    final GetEvidencePageKey getEvidencePageKey = new GetEvidencePageKey();
    GetEvidencePageResult getEvidencePageResult;

    // Set key to get evidence create page
    getEvidencePageKey.caseEvidenceTreeID = key.caseEvidenceTreeID;
    getEvidencePageKey.evidenceType = key.evidenceType;
    getEvidencePageKey.pageType = PAGETYPE.CREATE;

    // Call API method to get evidence create page name
    getEvidencePageResult = caseEvidenceAPIObj.getEvidencePage(
      getEvidencePageKey);

    // Assign page identifier to return object
    pageIdentifierResult.pageIdentifier = getEvidencePageResult.pageIdentifier;

    return pageIdentifierResult;
  }

  // ___________________________________________________________________________
  /**
   * Resolves the evidence group page to be navigated to.
   *
   * @param key
   * Key to resolve evidence group page.
   *
   * @return Evidence group page.
   */
  public PageIdentifierResult resolveEvidenceGroupPage(
    final ResolveEvidenceGroupPageKey key) throws AppException,
      InformationalException {

    // Create return object
    final PageIdentifierResult pageIdentifierResult = new PageIdentifierResult();

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    final GetEvidenceGroupPageKey getEvidenceGroupPageKey = new GetEvidenceGroupPageKey();
    GetEvidenceGroupPageResult getEvidenceGroupPageResult;

    // Set key to get evidence group page
    getEvidenceGroupPageKey.caseEvidenceTreeID = key.caseEvidenceTreeID;
    getEvidenceGroupPageKey.evidenceGroupNameCode = key.evidenceGroupNameCode;
    getEvidenceGroupPageKey.pageType = PAGETYPE.EVIDENCEGROUP;

    // Call API method to get evidence group page
    getEvidenceGroupPageResult = caseEvidenceAPIObj.getEvidenceGroupPage(
      getEvidenceGroupPageKey);

    // Assign page identifier to return object
    pageIdentifierResult.pageIdentifier = getEvidenceGroupPageResult.pageIdentifier;

    return pageIdentifierResult;
  }

  // ___________________________________________________________________________
  /**
   * Resolves the evidence list page to be navigated to.
   *
   * @param key
   * Key to resolve the evidence list page.
   *
   * @return Evidence list page.
   */
  public PageIdentifierResult resolveEvidenceListPage(final ResolveEvidencePageKey key)
    throws AppException, InformationalException {

    // Create return object
    final PageIdentifierResult pageIdentifierResult = new PageIdentifierResult();

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    final GetEvidencePageKey getEvidencePageKey = new GetEvidencePageKey();
    GetEvidencePageResult getEvidencePageResult;

    // Set key to get evidence list page
    getEvidencePageKey.caseEvidenceTreeID = key.caseEvidenceTreeID;
    getEvidencePageKey.pageType = PAGETYPE.LIST;
    getEvidencePageKey.evidenceType = key.evidenceType;

    // Call API method to get evidence list page name
    getEvidencePageResult = caseEvidenceAPIObj.getEvidencePage(
      getEvidencePageKey);

    // Assign page identifier to return object
    pageIdentifierResult.pageIdentifier = getEvidencePageResult.pageIdentifier;

    return pageIdentifierResult;
  }

  // ___________________________________________________________________________
  /**
   * Resolves the evidence view page to be navigated to.
   *
   * @param key
   * Contain key to resolve the evidence view page.
   *
   * @return Evidence view page.
   */
  public PageIdentifierResult resolveEvidenceViewPage(final ResolveEvidencePageKey key)
    throws AppException, InformationalException {

    // Create return object
    final PageIdentifierResult pageIdentifierResult = new PageIdentifierResult();

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    final GetEvidencePageKey getEvidencePageKey = new GetEvidencePageKey();
    GetEvidencePageResult getEvidencePageResult;

    // Set key to get evidence view page
    getEvidencePageKey.caseEvidenceTreeID = key.caseEvidenceTreeID;
    getEvidencePageKey.pageType = PAGETYPE.VIEW;
    getEvidencePageKey.evidenceType = key.evidenceType;

    // Call API method to get evidence view page name
    getEvidencePageResult = caseEvidenceAPIObj.getEvidencePage(
      getEvidencePageKey);

    // Assign page identifier to return object
    pageIdentifierResult.pageIdentifier = getEvidencePageResult.pageIdentifier;

    return pageIdentifierResult;
  }

  // ___________________________________________________________________________
  /**
   * Resolves the site map page to be navigated to.
   *
   * @param key
   * Contains key to resolve the site map page.
   *
   * @return Evidence site map name.
   */
  public PageIdentifierResult resolveSiteMapPage(final ResolveSiteMapKey key)
    throws AppException, InformationalException {

    // Create return object
    final PageIdentifierResult pageIdentifierResult = new PageIdentifierResult();

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    final GetSiteMapKey getSiteMapKey = new GetSiteMapKey();
    GetSiteMapResult getSiteMapResult;

    // Set key to get site map name
    getSiteMapKey.caseEvidenceTreeID = key.caseEvidenceTreeID;
    getSiteMapKey.pageType = PAGETYPE.SITEMAP;

    // Call API method to get site map name
    getSiteMapResult = caseEvidenceAPIObj.getSiteMap(getSiteMapKey);

    // Assign page identifier to return object
    pageIdentifierResult.pageIdentifier = getSiteMapResult.pageIdentifier;

    return pageIdentifierResult;
  }

  // ___________________________________________________________________________
  /**
   * Resolves the evidence modify page.
   *
   * @param key
   * Contains key to resolve the evidence modify page
   *
   * @return Evidence modify page name.
   */
  public PageIdentifierResult resolveEvidenceModifyPage(final ResolveModifyPageKey key)
    throws AppException, InformationalException {

    // Create return object
    final PageIdentifierResult pageIdentifierResult = new PageIdentifierResult();

    // CaseEvidenceAPI manipulation variables
    final curam.core.sl.intf.CaseEvidenceAPI caseEvidenceAPIObj = curam.core.sl.fact.CaseEvidenceAPIFactory.newInstance();
    final GetEvidencePageWithEffectiveFromKey getEvidencePageWithEffectiveFromKey = new GetEvidencePageWithEffectiveFromKey();
    GetEvidencePageResult getEvidencePageResult;

    // Set key to get evidence modify page
    getEvidencePageWithEffectiveFromKey.caseEvidenceTreeID = key.caseEvidenceTreeID;
    getEvidencePageWithEffectiveFromKey.effectiveFrom = key.effectiveFrom;
    getEvidencePageWithEffectiveFromKey.evidenceType = key.evidenceType;
    getEvidencePageWithEffectiveFromKey.pageType = PAGETYPE.MODIFY;

    // Call API method to get evidence modify page
    getEvidencePageResult = caseEvidenceAPIObj.getEvidencePage(
      getEvidencePageWithEffectiveFromKey);

    // Assign page identifier to return object
    pageIdentifierResult.pageIdentifier = getEvidencePageResult.pageIdentifier;

    return pageIdentifierResult;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of eligible case members
   *
   * @param key
   * Case key
   *
   * @return List of eligible case group members for a case.
   */
  public CaseGroupEligibleMembersDtlsList readEligibleCaseGroupMembers(
    final CaseIDKey key) throws AppException, InformationalException {

    // returned details
    final CaseGroupEligibleMembersDtlsList caseGroupEligibleMembersDtlsList = new CaseGroupEligibleMembersDtlsList();

    // case group object and key
    final curam.core.intf.MaintainCaseGroups maintainCaseGroupsObj = curam.core.fact.MaintainCaseGroupsFactory.newInstance();
    final CaseGroupRMKey caseGroupRMKey = new CaseGroupRMKey();

    // set the case id
    caseGroupRMKey.caseID = key.dtls.dtls.caseID;

    // read the list of eligible members
    caseGroupEligibleMembersDtlsList.details = maintainCaseGroupsObj.readEligibleMembers(
      caseGroupRMKey);

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = key.dtls.dtls.caseID;

    // Read context description and assign to output object
    caseGroupEligibleMembersDtlsList.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    return caseGroupEligibleMembersDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of tasks on a specified case.
   *
   * @param key
   * Key to retrieve list of tasks on a case.
   *
   * @return List of tasks on the specified case.
   */
  public ListCaseTaskResult listCaseTask(final CaseKey key) throws AppException,
      InformationalException {

    // Create return object
    final ListCaseTaskResult listCaseTaskResult = new ListCaseTaskResult();

    // SearchTasksForConcernAndCaseDetails object
    final SearchTasksForConcernAndCaseDetails searchTasksForConcernAndCaseDetails = new SearchTasksForConcernAndCaseDetails();

    // WorkAllocationTask manipulation variables
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj = curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();
    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new SearchTaskForConcernOrCaseKey();

    // Set key to retrieve list of tasks on a case
    searchTaskForConcernOrCaseKey.details.linkedID = key.caseID;

    // Call BPO to retrieve list of tasks on case
    searchTasksForConcernAndCaseDetails.dtls = workAllocationTaskObj.listCaseTasks(
      searchTaskForConcernOrCaseKey);

    // Iterate through list to set the reservedBy flag
    for (int i = 0; i
      < searchTasksForConcernAndCaseDetails.dtls.dtls.dtls.size(); i++) {

      final curam.core.sl.entity.struct.TaskSearchDetails taskSearchDetails = new curam.core.sl.entity.struct.TaskSearchDetails();

      // Assign details to taskSearchDetails
      taskSearchDetails.assign(
        searchTasksForConcernAndCaseDetails.dtls.dtls.dtls.item(i));

      if (searchTasksForConcernAndCaseDetails.dtls.dtls.dtls.item(i).reservedBy.length()
        > 0) {

        taskSearchDetails.reservedByExistsInd = true;
      }

      listCaseTaskResult.taskList.dtls.dtls.dtls.addRef(taskSearchDetails);
    }

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to return object
    listCaseTaskResult.description = readCaseContextDescription(
      caseContextDescriptionKey);

    return listCaseTaskResult;
  }

  // BEGIN, CR00189687, GD
  // ___________________________________________________________________________
  /**
   * @return A list of delivery patterns for a nominee over a date range.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listCaseNomineeDelPatternHistory()}.
   *
   * Read A list of delivery patterns for a nominee over a date
   * range.
   */
  @Deprecated
  // END, CR00189687
  public SearchByCaseNomineeAndDateRangeDetailsList_fo listCaseNomineeFeqPatternHistory(
    final SearchByCaseNomineeAndDateRangeKey_fo searchByCaseNomineeAndDateRangeKey)
    throws AppException, InformationalException {

    // return object
    final SearchByCaseNomineeAndDateRangeDetailsList_fo searchByCaseNomineeAndDateRangeDetailsList = new SearchByCaseNomineeAndDateRangeDetailsList_fo();

    // service layer case nominee object
    final curam.core.sl.intf.CaseNominee caseNominee_boObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // Search by case nominee and date range key object
    SearchByCaseNomineeAndDateRangeKey_bo searchByCaseNomineeAndDateRangeKey_bo = new SearchByCaseNomineeAndDateRangeKey_bo();

    // populate the key
    searchByCaseNomineeAndDateRangeKey_bo = searchByCaseNomineeAndDateRangeKey.key;

    // Set the record status.
    searchByCaseNomineeAndDateRangeKey_bo.searchByCaseNomineeAndDateRangeKey.recordStatus = curam.codetable.RECORDSTATUS.DEFAULTCODE;

    // get list
    searchByCaseNomineeAndDateRangeDetailsList.list = caseNominee_boObj.searchByCaseNomineeAndDateRange(
      searchByCaseNomineeAndDateRangeKey_bo);

    // read context description
    final CaseNominee caseNominee = CaseNomineeFactory.newInstance();

    curam.core.sl.entity.struct.CaseIDAndFromDateDtls caseIDAndFromDateDtls;

    final curam.core.sl.entity.struct.CaseNomineeKey caseNomineeKey = new curam.core.sl.entity.struct.CaseNomineeKey();

    caseNomineeKey.caseNomineeID = searchByCaseNomineeAndDateRangeKey.key.searchByCaseNomineeAndDateRangeKey.caseNomineeID;
    caseIDAndFromDateDtls = caseNominee.readCaseID(caseNomineeKey);

    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = caseIDAndFromDateDtls.caseID;
    searchByCaseNomineeAndDateRangeDetailsList.caseNomineeContextDescription_fo.description = readCaseContextDescription(caseContextDescriptionKey).description;

    // return details
    return searchByCaseNomineeAndDateRangeDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseNomineeDeliveryPatternDetailsList listCaseNomineeCurrentDeliveryPattern(
    final CaseNomineeDeliveryPatternKey key) throws AppException,
      InformationalException {

    // return object
    final CaseNomineeDeliveryPatternDetailsList deliveryPatternDetailsList = new CaseNomineeDeliveryPatternDetailsList();

    // service layer case nominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    deliveryPatternDetailsList.dtls = caseNomineeObj.listCurrentDeliveryPattern(
      key);

    // read context description
    final CaseNominee caseNominee = CaseNomineeFactory.newInstance();

    curam.core.sl.entity.struct.CaseIDAndFromDateDtls caseIDAndFromDateDtls;

    final curam.core.sl.entity.struct.CaseNomineeKey caseNomineeKey = new curam.core.sl.entity.struct.CaseNomineeKey();

    caseNomineeKey.caseNomineeID = key.caseNomineeID;
    caseIDAndFromDateDtls = caseNominee.readCaseID(caseNomineeKey);

    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = caseIDAndFromDateDtls.caseID;
    deliveryPatternDetailsList.caseContextDescription.description = readCaseContextDescription(caseContextDescriptionKey).description;

    // Populate the nominee display name
    curam.core.sl.entity.struct.CaseNomineeDetails caseNomineeDetails;
    final curam.core.sl.entity.intf.CaseNominee caseNomineeEntObj = curam.core.sl.entity.fact.CaseNomineeFactory.newInstance();

    final curam.core.sl.entity.struct.CaseNomineeViewKey caseNomineeViewKey = new curam.core.sl.entity.struct.CaseNomineeViewKey();

    caseNomineeViewKey.caseNomineeID = key.caseNomineeID;

    caseNomineeDetails = caseNomineeEntObj.readCaseNomineeDetails(
      caseNomineeViewKey);

    deliveryPatternDetailsList.nomineeDtls.nomineeName = caseNomineeDetails.concernRoleName;

    // return details
    return deliveryPatternDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseNomineeDeliveryPatternDetailsList listCaseNomineeDelPatternHistory(
    final CaseNomineeDeliveryPatternKey key) throws AppException,
      InformationalException {

    // return object
    final CaseNomineeDeliveryPatternDetailsList deliveryPatternDetailsList = new CaseNomineeDeliveryPatternDetailsList();

    // service layer case nominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    deliveryPatternDetailsList.dtls = caseNomineeObj.listNomineeDeliveryPatternHistory(
      key);

    // read context description
    final CaseNominee caseNominee = CaseNomineeFactory.newInstance();

    curam.core.sl.entity.struct.CaseIDAndFromDateDtls caseIDAndFromDateDtls;

    final curam.core.sl.entity.struct.CaseNomineeKey caseNomineeKey = new curam.core.sl.entity.struct.CaseNomineeKey();

    caseNomineeKey.caseNomineeID = key.caseNomineeID;
    caseIDAndFromDateDtls = caseNominee.readCaseID(caseNomineeKey);

    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = caseIDAndFromDateDtls.caseID;
    deliveryPatternDetailsList.caseContextDescription.description = readCaseContextDescription(caseContextDescriptionKey).description;

    // Populate the nominee display name
    curam.core.sl.entity.struct.CaseNomineeDetails caseNomineeDetails;
    final curam.core.sl.entity.intf.CaseNominee caseNomineeEntObj = curam.core.sl.entity.fact.CaseNomineeFactory.newInstance();

    final curam.core.sl.entity.struct.CaseNomineeViewKey caseNomineeViewKey = new curam.core.sl.entity.struct.CaseNomineeViewKey();

    caseNomineeViewKey.caseNomineeID = key.caseNomineeID;

    caseNomineeDetails = caseNomineeEntObj.readCaseNomineeDetails(
      caseNomineeViewKey);

    deliveryPatternDetailsList.nomineeDtls.nomineeName = caseNomineeDetails.concernRoleName;

    // return details
    return deliveryPatternDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public InformationMsgDtlsList setDefaultNominee(
    final SetDefaultNomineeKey setDefaultNomineeKey) throws AppException,
      InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNominee_boObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // call service layer method
    caseNominee_boObj.setDefaultNominee(setDefaultNomineeKey.key);

    // BEGIN, CR00001839, SD
    // create return object.
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    final curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);

    }

    // return all informational messages
    return informationMsgDtlsList;
    // END, CR00001839
  }

  // BEGIN HARP 37088
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ReadAssessmentCaseDecisionDetails readAssessmentCaseDecision(
    final ReadAssessmentCaseDecisionKey readAssessmentCaseDecisionKey)
    throws AppException, InformationalException {

    // MaintainCaseDecision manipulation variables
    final curam.core.intf.MaintainCaseDecision maintainCaseDecisionObj = curam.core.fact.MaintainCaseDecisionFactory.newInstance();

    final CaseDecisionIDStruct caseDecisionIDStruct = new CaseDecisionIDStruct();

    // Create the return object
    final ReadAssessmentCaseDecisionDetails readAssessmentCaseDecisionDetails = new ReadAssessmentCaseDecisionDetails();

    // Populate return struct
    readAssessmentCaseDecisionDetails.getCaseDecisionDetailsResult = maintainCaseDecisionObj.getCaseDecisionDetails(
      readAssessmentCaseDecisionKey.caseDecisionStruct);

    // read the context description
    // Set key to get decision details
    caseDecisionIDStruct.caseDecisionID = readAssessmentCaseDecisionKey.caseDecisionStruct.caseDecisionID;

    // read the case ID
    final CaseDecisionCaseID caseDecisionCaseID = maintainCaseDecisionObj.getCaseID(
      caseDecisionIDStruct);

    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // read the context description
    caseContextDescriptionKey.caseID = caseDecisionCaseID.dtls.caseID;
    readAssessmentCaseDecisionDetails.description.description = readCaseContextDescription(caseContextDescriptionKey).description;

    // return details
    return readAssessmentCaseDecisionDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to list all Objectives available for a case
   *
   * @param key
   * contains caseID
   *
   * @return list of all objectives for this case.
   */
  public CaseNomineeObjectiveList listCaseObjective(final CaseListObjectiveKey key)
    throws AppException, InformationalException {

    // return structure
    final CaseNomineeObjectiveList caseNomineeObjectiveList = new CaseNomineeObjectiveList();
    CaseNomineeObjectiveDetails caseNomineeObjectiveDetails;

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();
    final CaseNomineeObjectiveNameDetailsList caseNomineeObjectiveNameDetailsList = new CaseNomineeObjectiveNameDetailsList();
    final CaseNomineeCaseIDKey caseNomineeCaseIDKey = new CaseNomineeCaseIDKey();

    caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID = key.caseID;

    // read list from service layer into returned struct
    caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList = caseNomineeObj.listObjective(
      caseNomineeCaseIDKey.caseNomineeCaseIDKey);

    // assign the objective to the return struct
    for (int i = 0; i
      < caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.size(); i++) {

      caseNomineeObjectiveDetails = new CaseNomineeObjectiveDetails();

      caseNomineeObjectiveDetails.objectiveCode = caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.item(i).objectiveCode;
      caseNomineeObjectiveDetails.rulesObjectiveID = caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.caseNomineeObjectiveNameDetailsList.item(i).rulesObjectiveID;

      // BEGIN, CR00209689, CSH
      // Check if the case is a payment correction and if
      // so only return the appropriate component
      final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = key.caseID;

      if (paymentCorrection.isOverPaymentPaymentCorrection(caseHeaderKey)
        && caseNomineeObjectiveDetails.objectiveCode.equals(
          RULESCOMPONENTTYPE.BENEFITUNDERPAYMENT)) {// do not display this component
      } else if (paymentCorrection.isUnderPaymentPaymentCorrection(
        caseHeaderKey)
          && caseNomineeObjectiveDetails.objectiveCode.equals(
            RULESCOMPONENTTYPE.BENEFITOVERPAYMENT)) {// do not display this component
      } else {

        caseNomineeObjectiveList.dtls.addRef(caseNomineeObjectiveDetails);
      }
      // END, CR00209689
    }

    // return details
    return caseNomineeObjectiveList;
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * contains concernRoleID
   * @return list of all active bank accounts for a case nominee.
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.facade.impl.Participant#listBankAccountString()}
   * . This method has been deprecated as new processing has been
   * introduced when modifying a case nominee's bank account
   * details. The user will now be presented with a list of bank
   * details displayed as a single string of text.
   *
   * Method to list all active bank accounts for a Case Nominee.
   */
  @Deprecated
  public ListCaseNomineeBankAccResult listCaseNomineeBankAccount(
    final ListCaseNomineeBankAccKey key) throws AppException,
      InformationalException {

    final ListCaseNomineeBankAccResult listCaseNomineeBankAccResult = new ListCaseNomineeBankAccResult();

    // Bank account maintenance object
    final MaintainConcernRoleBankAc maintainConcernRoleBankAcObj = MaintainConcernRoleBankAcFactory.newInstance();

    listCaseNomineeBankAccResult.result = maintainConcernRoleBankAcObj.readmultiByConcernRoleForNomineeWizard(
      key.key);

    return listCaseNomineeBankAccResult;
  }

  // BEGIN, CR00194084, GD
  // ___________________________________________________________________________
  /**
   * @param details
   * Details used to modify the nominee status
   * @deprecated Since Curam 6.0, replaced by {@link #expireCaseNominee1()}.
   *
   * Method to modify the nomineeStatus to 'expired'.
   */
  @Deprecated
  public void expireCaseNominee(final ModifyNomineeStatusDetails details)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    caseNomineeObj.expireCaseNominee(details.modifyNomineeStatusDetails);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void expireCaseNominee1(final ModifyNomineeStatusDetails details)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    caseNomineeObj.expireCaseNominee1(details.modifyNomineeStatusDetails);
  }

  // END, CR00194084

  // BEGIN, CR00190939, GD
  // ___________________________________________________________________________
  /**
   * @param key
   * contains caseID and nomineeStatus
   *
   * @return List of operational Nominees for case and their delivery
   * information
   * @deprecated Since Curam 6.0, replaced by {@link #listOperationalNominee1()}
   * .
   *
   * Method to return operational Nominees for a case.
   */
  @Deprecated
  // END, CR00190939
  public CaseNomineeAndStatusDetails listOperationalNominee(
    final CaseNomineeCaseIDAndStatusKey key) throws AppException,
      InformationalException {

    // CaseNominee manipulation variables
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();
    final CaseNomineeAndStatusDetails caseNomineeAndStatusDetails = new CaseNomineeAndStatusDetails();
    CaseNomineeAndStatusDetailsList caseNomineeAndStatusDetailsList = new CaseNomineeAndStatusDetailsList();

    // Case context description manipulation variable
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // BEGIN, CR00181451, SPD
    // Maintain Concern Role Details object
    final MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory.newInstance();

    // END, CR00181451

    key.caseNomineeCaseIDAndStatusKey.caseNomineeCaseIDAndStatusKey.nomineeStatus = CASENOMINEESTATUS.OPERATIONAL;

    // read operational list from service layer into return struct
    caseNomineeAndStatusDetailsList = caseNomineeObj.listOperationalNominee(
      key.caseNomineeCaseIDAndStatusKey);

    // BEGIN, CR00175165, SPD
    // BEGIN, CR00181451, SPD
    for (int i = 0; i
      < caseNomineeAndStatusDetailsList.caseNomineeAndStatusDetailsList.size(); i++) {

      final ConcernRolesDetails concernRolesDetails = new ConcernRolesDetails();

      // Assign details needed to append age to name
      concernRolesDetails.assign(
        caseNomineeAndStatusDetailsList.caseNomineeAndStatusDetailsList.item(i));

      // Append age to concern role name
      caseNomineeAndStatusDetailsList.caseNomineeAndStatusDetailsList.item(i).concernRoleName = maintainConcernRoleDetailsObj.appendAgeToName(concernRolesDetails).concernRoleName;
      // END, CR00181451
    }

    // read context description
    caseContextDescriptionKey.caseID = key.caseNomineeCaseIDAndStatusKey.caseNomineeCaseIDAndStatusKey.caseID;

    caseNomineeAndStatusDetails.caseContextDescription = readCaseContextDescription(
      caseContextDescriptionKey);
    caseNomineeAndStatusDetails.caseNomineeAndStatusDetailsList = caseNomineeAndStatusDetailsList;
    // END, CR00175165

    return caseNomineeAndStatusDetails;
  }

  // BEGIN, CR00190939, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseNomineeAndStatusDetails listOperationalNominee1(
    final CaseNomineeCaseIDAndStatusKey key) throws AppException,
      InformationalException {

    // CaseNominee manipulation variables
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();
    final CaseNomineeAndStatusDetails caseNomineeAndStatusDetails = new CaseNomineeAndStatusDetails();
    CaseNomineeAndStatusDetailsList caseNomineeAndStatusDetailsList = new CaseNomineeAndStatusDetailsList();

    // Maintain Concern Role Details object
    final MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory.newInstance();

    key.caseNomineeCaseIDAndStatusKey.caseNomineeCaseIDAndStatusKey.nomineeStatus = CASENOMINEESTATUS.OPERATIONAL;

    // read operational list from service layer into return struct
    caseNomineeAndStatusDetailsList = caseNomineeObj.listOperationalNominee(
      key.caseNomineeCaseIDAndStatusKey);

    // BEGIN, CR00193859, GD
    final ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();

    readEffectiveByDateKey.effectiveDate = Date.getCurrentDate();
    readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;

    for (int i = 0; i
      < caseNomineeAndStatusDetailsList.caseNomineeAndStatusDetailsList.size(); i++) {

      final ConcernRolesDetails concernRolesDetails = new ConcernRolesDetails();

      // Assign details needed to append age to name
      concernRolesDetails.assign(
        caseNomineeAndStatusDetailsList.caseNomineeAndStatusDetailsList.item(i));

      // Append age to concern role name
      caseNomineeAndStatusDetailsList.caseNomineeAndStatusDetailsList.item(i).concernRoleName = maintainConcernRoleDetailsObj.appendAgeToName(concernRolesDetails).concernRoleName;

      // find current delivery pattern for caseNomineeID
      readEffectiveByDateKey.caseNomineeID = caseNomineeAndStatusDetailsList.caseNomineeAndStatusDetailsList.item(i).caseNomineeID;

      final CaseNomineeDeliveryPatternDetails caseNomineeDeliveryPatternDetails = caseNomineeObj.readNearestDeliveryPattern(
        readEffectiveByDateKey);

      caseNomineeAndStatusDetailsList.caseNomineeAndStatusDetailsList.item(i).concernRoleName += CuramConst.gkSpace
        + CuramConst.gkDash + CuramConst.gkSpace
        + caseNomineeDeliveryPatternDetails.deliveryPatternName;
      // END, CR00193859
    }

    caseNomineeAndStatusDetails.caseNomineeAndStatusDetailsList = caseNomineeAndStatusDetailsList;

    return caseNomineeAndStatusDetails;
  }

  // END, CR00190939

  // BEGIN, CR00194084, GD
  // ___________________________________________________________________________
  /**
   * @param details
   * Details used to modify the nominee status
   *
   * @deprecated Since Curam 6.0, replaced by {@link #reactivateCaseNominee1()}.
   *
   * Method to modify the nomineeStatus to 'operational'.
   */
  @Deprecated
  // END, CR00194084
  public void reactivateCaseNominee(final ModifyNomineeStatusDetails details)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    caseNomineeObj.reactivateCaseNominee(details.modifyNomineeStatusDetails);
  }

  // BEGIN, CR00194084, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void reactivateCaseNominee1(final ModifyNomineeStatusDetails details)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    caseNomineeObj.reactivateCaseNominee1(details.modifyNomineeStatusDetails);
  }

  // END, CR00194084

  // BEGIN, CR00162569, PDN
  // ___________________________________________________________________________
  /**
   * @param listStatusHistoryKey
   * Contains caseID
   *
   * @return The list of case status history records.
   * @deprecated Since Curam 6.0, replaced by {@link #listStatusHistory1()}.
   *
   * Lists the status history records for a specific case.
   */
  @Deprecated
  public ListCaseStatusHistoryDetails listStatusHistory(
    final ListStatusHistoryKey listStatusHistoryKey) throws AppException,
      InformationalException {

    final ListCaseStatusHistoryDetails listCaseStatusHistoryDetails = new ListCaseStatusHistoryDetails();

    // ProductDeliveryHome manipulation variables
    final curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory.newInstance();
    final CaseStatusHistoryKey caseStatusHistoryKey = new CaseStatusHistoryKey();

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = listStatusHistoryKey.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = listStatusHistoryKey.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Set key to read case status history details
    caseStatusHistoryKey.caseID = listStatusHistoryKey.caseID;

    // Read case status history details and assign to output object
    final CaseStatusHistoryDetailsList caseStatusHistoryDetailsList = productDeliveryHomeObj.getCaseStatusHistory(
      caseStatusHistoryKey);

    // BEGIN, CR00150402, PDN
    // loop through list returned and assign struct to struct been returned
    for (int i = 0; i < caseStatusHistoryDetailsList.dtls.size(); i++) {

      final StatusHistoryCaseDetails statusHistoryCaseDetails = new StatusHistoryCaseDetails();

      statusHistoryCaseDetails.assign(caseStatusHistoryDetailsList.dtls.item(i));

      final boolean showDeferredProc = Configuration.getBooleanProperty(
        EnvVars.ENV_DPDISPLAYINSTATUSHISTORY);

      // Populate the return object with the details, if its not delayed
      // processing or if it is and the display of delayed processing are
      // allowed.
      if (statusHistoryCaseDetails.statusCode.equals(
        curam.codetable.CASESTATUS.DELAYEDPROC)
          && showDeferredProc) {
        listCaseStatusHistoryDetails.dtls.addRef(statusHistoryCaseDetails);
      } else if (!statusHistoryCaseDetails.statusCode.equals(
        curam.codetable.CASESTATUS.DELAYEDPROC)) {
        listCaseStatusHistoryDetails.dtls.addRef(statusHistoryCaseDetails);
      }
    }
    // END, CR00150402

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = listStatusHistoryKey.caseID;

    // Read context description and assign to output object
    listCaseStatusHistoryDetails.description = readCaseContextDescription(
      caseContextDescriptionKey);

    // Set the case menu data
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseContextDescriptionKey.caseID;

    final CaseMenuData caseMenuData = getCaseMenuDataDetails(caseHeaderKey);

    // Will be not set for specific cases e.g. stand alone cases
    if (caseMenuData != null) {
      listCaseStatusHistoryDetails.menuData.menuData = caseMenuData.menuData;
    }

    return listCaseStatusHistoryDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method replaces the deprecated method {@link #listStatusHistory()}
   * Lists the status history records for a specific case
   *
   * @param listStatusHistoryKey
   * Contains caseID
   *
   * @return The list of case status history records.
   */
  public ListCaseStatusHistoryDetails1 listStatusHistory1(
    final ListStatusHistoryKey listStatusHistoryKey) throws AppException,
      InformationalException {

    final ListCaseStatusHistoryDetails1 listCaseStatusHistoryDetails1 = new ListCaseStatusHistoryDetails1();

    // ProductDeliveryHome manipulation variables
    final curam.core.intf.ProductDeliveryHome productDeliveryHomeObj = curam.core.fact.ProductDeliveryHomeFactory.newInstance();
    final CaseStatusHistoryKey caseStatusHistoryKey = new CaseStatusHistoryKey();

    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = listStatusHistoryKey.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = listStatusHistoryKey.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }

    // Set key to read case status history details
    caseStatusHistoryKey.caseID = listStatusHistoryKey.caseID;

    // Read case status history details and assign to output object
    final CaseStatusHistoryDetailsList1 caseStatusHistoryDetailsList1 = productDeliveryHomeObj.getCaseStatusHistory1(
      caseStatusHistoryKey);

    // loop through list returned and assign struct to struct been returned
    // Users manipulation variables
    final Users usersObj = UsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();

    for (int i = 0; i < caseStatusHistoryDetailsList1.dtls.size(); i++) {

      final CaseStatusHistory caseStatusHistory = new CaseStatusHistory();

      caseStatusHistory.assign(caseStatusHistoryDetailsList1.dtls.item(i));

      // For backward compatibility support, Set the start and end date
      // time to
      // the start and end date if the start and end date times have not
      // been set.
      if (caseStatusHistory.startDateTime.isZero()) {
        caseStatusHistory.startDateTime = new DateTime(
          caseStatusHistory.startDate.getCalendar());
      }
      if (caseStatusHistory.endDateTime.isZero()) {
        caseStatusHistory.endDateTime = new DateTime(
          caseStatusHistory.endDate.getCalendar());
      }

      // Set the users full name from the user name
      usersKey.userName = caseStatusHistoryDetailsList1.dtls.item(i).userName;
      caseStatusHistory.userFullName = usersObj.getFullName(usersKey).fullname;

      final boolean showDeferredProc = Configuration.getBooleanProperty(
        EnvVars.ENV_DPDISPLAYINSTATUSHISTORY);

      // Populate the return object with the details, if its not delayed
      // processing or if it is and the display of delayed processing are
      // allowed.
      if (caseStatusHistory.statusCode.equals(
        curam.codetable.CASESTATUS.DELAYEDPROC)
          && showDeferredProc) {
        listCaseStatusHistoryDetails1.dtls.addRef(caseStatusHistory);
      } else if (!caseStatusHistory.statusCode.equals(
        curam.codetable.CASESTATUS.DELAYEDPROC)) {
        listCaseStatusHistoryDetails1.dtls.addRef(caseStatusHistory);
      }
    }

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = listStatusHistoryKey.caseID;

    // Read context description and assign to output object
    listCaseStatusHistoryDetails1.description = readCaseContextDescription(
      caseContextDescriptionKey);

    // Set the case menu data
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseContextDescriptionKey.caseID;

    final CaseMenuData caseMenuData = getCaseMenuDataDetails(caseHeaderKey);

    // Will be not set for specific cases e.g. stand alone cases
    if (caseMenuData != null) {
      listCaseStatusHistoryDetails1.menuData.menuData = caseMenuData.menuData;
    }

    return listCaseStatusHistoryDetails1;
  }

  // END, CR00162569

  // ___________________________________________________________________________
  /**
   * Reads the service Plan menu data
   *
   * @param key
   * Contains caseID
   *
   * @return The Case Menu Data.
   */
  public CaseMenuData getCaseMenuDataDetails(final CaseHeaderKey key)
    throws AppException, InformationalException {

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    CaseTypeCode caseTypeCode;
    final CaseMenuData menuData = new CaseMenuData();

    // Set key to read CaseHeader
    caseKey.caseID = key.caseID;

    // Read case type code
    caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    if (caseTypeCode.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {
      final ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanIntegratedCaseKey servicePlanIntegratedCaseKey = new ServicePlanIntegratedCaseKey();

      servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.servicePlanIntegratedCaseKey.caseID = caseKey.caseID;

      menuData.menuData = servicePlanDeliveryObj.getICServicePlanMenuData(servicePlanIntegratedCaseKey).menuData;

    }

    return menuData;
  }

  // BEGIN, CR00000541, SD
  // BEGIN, CR00028890, SPD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseNomineeIDReferenceNameRelationshipList listOperationalCaseNomineeDetails(
    final CaseNomineeCaseIDKey key) throws AppException, InformationalException {

    // struct to return the nominee list
    final CaseNomineeIDReferenceNameRelationshipList caseNomineeIDReferenceNameRelationshipList = new CaseNomineeIDReferenceNameRelationshipList();

    // CaseNominee service layer manipulation variables
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();
    final curam.core.sl.struct.CaseNomineeCaseIDAndStatusKey caseNomineeCaseIDAndStatusKey = new curam.core.sl.struct.CaseNomineeCaseIDAndStatusKey();

    // CaseNominee entity layer manipulation variables
    final curam.core.sl.entity.intf.CaseNominee caseNomineeEntityObj = curam.core.sl.entity.fact.CaseNomineeFactory.newInstance();

    // BEGIN, CR00181451, SPD
    // Maintain Concern Role Details object
    final MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory.newInstance();
    // END, CR00181451

    // Case context description manipulation variable
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // populate key for read
    caseNomineeCaseIDAndStatusKey.caseNomineeCaseIDAndStatusKey.caseID = key.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID;
    caseNomineeCaseIDAndStatusKey.caseNomineeCaseIDAndStatusKey.nomineeStatus = CASENOMINEESTATUS.OPERATIONAL;

    // read operational list from service layer into return struct
    caseNomineeIDReferenceNameRelationshipList.dtls = caseNomineeObj.listOperationalCaseNomineeDetails(
      caseNomineeCaseIDAndStatusKey);

    // BEGIN, CR00241632, KH
    final ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();

    readEffectiveByDateKey.effectiveDate = Date.getCurrentDate();
    readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
    // END, CR00241632

    // BEGIN, CR00175165, SPD
    // BEGIN, CR00181451, SPD
    // For each concern role name, append the age for display purposes
    for (int i = 0; i
      < caseNomineeIDReferenceNameRelationshipList.dtls.nomineeList.size(); i++) {

      final curam.core.sl.entity.struct.CaseNomineeViewKey caseNomineeViewKey = new curam.core.sl.entity.struct.CaseNomineeViewKey();
      curam.core.sl.entity.struct.CaseNomineeDetails caseNomineeDetails = new curam.core.sl.entity.struct.CaseNomineeDetails();
      final ConcernRolesDetails concernRolesDetails = new ConcernRolesDetails();

      caseNomineeViewKey.caseNomineeID = caseNomineeIDReferenceNameRelationshipList.dtls.nomineeList.item(i).caseNomineeID;

      caseNomineeDetails = caseNomineeEntityObj.readCaseNomineeDetails(
        caseNomineeViewKey);
      concernRolesDetails.assign(caseNomineeDetails);

      caseNomineeIDReferenceNameRelationshipList.dtls.nomineeList.item(i).concernRoleName = maintainConcernRoleDetailsObj.appendAgeToName(concernRolesDetails).concernRoleName;
      // END, CR00181451

      // BEGIN, CR00241632, KH
      // Find current delivery pattern for this case nominee
      readEffectiveByDateKey.caseNomineeID = caseNomineeIDReferenceNameRelationshipList.dtls.nomineeList.item(i).caseNomineeID;

      final CaseNomineeDeliveryPatternDetails caseNomineeDeliveryPatternDetails = caseNomineeObj.readNearestDeliveryPattern(
        readEffectiveByDateKey);

      caseNomineeIDReferenceNameRelationshipList.dtls.nomineeList.item(i).concernRoleName += CuramConst.gkSpace
        + CuramConst.gkDash + CuramConst.gkSpace
        + caseNomineeDeliveryPatternDetails.deliveryPatternName;
      // END, CR00241632
    }

    // Read context description
    caseContextDescriptionKey.caseID = key.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID;

    caseNomineeIDReferenceNameRelationshipList.caseContextDescription = readCaseContextDescription(
      caseContextDescriptionKey);
    // END, CR00175165

    return caseNomineeIDReferenceNameRelationshipList;
  }

  // ___________________________________________________________________________
  /**
   * Returns a list of objectives for the component popup. Uses a struct that
   * contains the nominee id popup domain definition.
   *
   * @param key
   * Contains caseID
   *
   * @return The Case Objective List
   */
  public CaseObjectiveIDCodeList listCaseObjectiveDetails(
    final CaseNomineeCaseIDKey key) throws AppException, InformationalException {

    // struct to return the component list
    final CaseObjectiveIDCodeList caseObjectiveIDCodeList = new CaseObjectiveIDCodeList();

    // CaseNominee manipulation variables
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // Case context description manipulation variable
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // read back list of component for a case
    caseObjectiveIDCodeList.dtls = caseNomineeObj.listCaseObjectiveDetails(
      key.caseNomineeCaseIDKey);

    // set key to read context description
    caseContextDescriptionKey.caseID = key.caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID;

    // read context description
    caseObjectiveIDCodeList.caseContextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    return caseObjectiveIDCodeList;
  }

  // END, CR00000541
  // END, CR00028890

  // BEGIN, CR00032741, DK
  // ___________________________________________________________________________
  /**
   * Retrieves the Case Participants by caseID and participant type
   *
   * @param key
   * Contains the case identifier
   * @return List of Case Participants
   */

  public SearchCaseParticipantDetailsList listCaseParticipant(
    // Moving to Case facade
    final SearchCaseParticipantDetailsKey key) throws AppException,
      InformationalException {

    return GeneralUtilityFactory.newInstance().listCaseParticipantByCaseIDType(
      key);

  }

  // END, CR00032741

  // ___________________________________________________________________________
  /**
   * Modifies an existing case supervisor details
   *
   * @param modifyDetails
   * modify details for supervisor
   */
  public void modifyCaseSupervisor(final ModifyCaseSupervisorDetails modifyDetails)
    throws AppException, InformationalException {

    // CaseUserRole manipulation variables
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final curam.core.sl.entity.struct.CaseUserRoleKey caseUserRoleKey = new curam.core.sl.entity.struct.CaseUserRoleKey();
    final ReasonEndDateComments reasonEndDateComments = new ReasonEndDateComments();

    // populate caseUserRoleID
    caseUserRoleKey.caseUserRoleID = modifyDetails.key.caseUserRoleID;

    // populate modify supervisor details
    reasonEndDateComments.reasonCode = modifyDetails.modifyDtls.reasonCode;
    reasonEndDateComments.endDate = modifyDetails.modifyDtls.endDate;
    reasonEndDateComments.comments = modifyDetails.modifyDtls.comments;

    // modify supervisor details
    caseUserRoleObj.modifySupervisor(caseUserRoleKey, reasonEndDateComments);
  }

  // BEGIN, CR00077040, PMD
  // ___________________________________________________________________________
  /**
   * Method to check if the appeals component is installed
   *
   * @return indicator indicating if the appeals component is installed
   */
  public AppealsInstalledInd checkForAppealsInstallation() throws AppException,
      InformationalException {

    // Return struct
    final AppealsInstalledInd appealsInstalledInd = new AppealsInstalledInd();

    // Retrieve the Environment variable for the Appeals
    // component installation setting.
    appealsInstalledInd.appealsInstalledInd = Configuration.getBooleanProperty(
      EnvVars.ENV_APPEALS_ISINSTALLED);

    return appealsInstalledInd;
  }

  // END, CR00077040

  // ___________________________________________________________________________
  /**
   * @param details
   * Contact Log id, case id and Contact Log Attendee details, user
   * name or concern role id
   *
   * @return Contact Log Attendee key
   * @deprecated Since Curam 6.0, replaced by {@link #addContactLogAttendee1()}.
   * New method passes additional 'I am a Contact Participant'
   * parameter to add new Contact Log Attendee.
   *
   * Method to add Attendee to Case Contact Log.
   */
  @Deprecated
  public ContactLogAttendeeKey addContactLogAttendee(
    final CreateCaseContactLogAttendeeDetails details) throws AppException,
      InformationalException {

    // BEGIN, CR00173401, ZV
    final CreateCaseContactLogAttendeeDetails1 createCaseContactLogAttendeeDetails = new CreateCaseContactLogAttendeeDetails1();

    createCaseContactLogAttendeeDetails.assign(details);

    // create case contact log attendee
    final ContactLogAttendeeKey contactLogAttendeeKey = addContactLogAttendee1(
      createCaseContactLogAttendeeDetails);

    details.assign(createCaseContactLogAttendeeDetails);

    return contactLogAttendeeKey;
    // END, CR00173401
  }

  // ___________________________________________________________________________
  /**
   * Method to cancel Case Contact Log record.
   *
   * @param details
   * Contains case id and Contact Log id
   */
  public void cancelContactLog(final CancelCaseContactLogDetails details)
    throws AppException, InformationalException {

    // Case Contact Log service object
    final curam.core.sl.intf.CaseContactLog caseContactLogObj = curam.core.sl.fact.CaseContactLogFactory.newInstance();

    // cancel case contact log
    caseContactLogObj.cancel(details);

  }

  // ___________________________________________________________________________
  /**
   * @param details
   * Contains case id and Contact Log details
   *
   * @return The Contact Log Key Objective List
   * @deprecated Since Curam 6.0, replaced by {@link #createContactLog1()}. New
   * method passes additional 'I am a Contact Participant' parameter
   * to create Contact Log Attendee.
   *
   * Method to create Contact Log and associate it to a case
   * provided.
   */
  @Deprecated
  public ContactLogKey createContactLog(final CreateCaseContactLogDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00173401, ZV
    final CreateCaseContactLogDetails1 createCaseContactLogDetails = new CreateCaseContactLogDetails1();

    createCaseContactLogDetails.assign(details);

    // create case contact log
    final ContactLogKey contactLogKey = createContactLog1(
      createCaseContactLogDetails);

    details.assign(createCaseContactLogDetails);

    return contactLogKey;
    // END, CR00173401
  }

  // ___________________________________________________________________________
  /**
   * @param key
   * Contains case id
   *
   * @return The Contact Log details List
   * @deprecated Since Curam 6.0, replaced by {@link #listContactLog1()}. New
   * method returns additional end date time field.
   *
   * Method to list Contact Log details for a case.
   */
  @Deprecated
  public ListCaseContactLogDetails listContactLog(final CaseKey key)
    throws AppException, InformationalException {

    // return case contact log list variable
    final ListCaseContactLogDetails listCaseContactLogDetails = new ListCaseContactLogDetails();

    // Contact Log service object and variable
    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();
    // BEGIN, CR00140221, ZV
    final curam.core.sl.struct.ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new curam.core.sl.struct.ContactLogLinkIDLinkTypeKey();

    // set case id to link id
    contactLogLinkIDLinkTypeKey.linkID = key.caseID;
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.CASE;

    // read contact log details list
    listCaseContactLogDetails.dtlsList = contactLogObj.list(
      contactLogLinkIDLinkTypeKey);
    // END, CR00140221

    // BEGIN, CR00140531, CL
    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i < listCaseContactLogDetails.dtlsList.dtls.size(); i++) {

      readContactLogDetails.contactLogDetails.assign(
        listCaseContactLogDetails.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj.formatContactLogPurpose(
        readContactLogDetails);

      listCaseContactLogDetails.dtlsList.dtls.item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
    }
    // END, CR00140531

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = key.caseID;

    // Read context description and assign to output object
    listCaseContactLogDetails.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    // return contact log details list for a case
    return listCaseContactLogDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to remove Case Contact Log Attendee.
   *
   * @param details
   * Contains case id, Contact Log id and attendee id,
   */
  public void removeCaseContactLogAttendee(
    final CancelCaseContactLogAttendeeDetails details) throws AppException,
      InformationalException {

    // Case Contact Log service object
    final curam.core.sl.intf.CaseContactLog caseContactLogObj = curam.core.sl.fact.CaseContactLogFactory.newInstance();

    // cancel case contact log attendee
    caseContactLogObj.cancelAttendee(details);

  }

  // BEGIN, CR00167103, SPD
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains case id and list of contact log ids
   *
   * @return The list of Contact Log preview notes details
   * @deprecated Since Curam 6.0, replaced by {@link #previewCaseContactLogs1()}
   * .
   *
   * Method to preview list of Case Contact Logs.
   */
  @Deprecated
  public PreviewCaseContactLogDetails previewCaseContactLogs(
    final PreviewCaseContactLogKey key) throws AppException, InformationalException {

    // return contact log preview details list variable
    final PreviewCaseContactLogDetails previewCaseContactLogDetails = new PreviewCaseContactLogDetails();

    if (key.actionControlID.equals(ACTIONCONTROLID.PREVIEW)
      || key.actionControlID.length() == 0) {

      // Contact Log service object
      final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

      // preview contact log list notes
      previewCaseContactLogDetails.widgetData = contactLogObj.getPreviewWidgetData(
        contactLogObj.previewList(key.previewContactLogKey));

      // CaseContextDescriptionKey object
      final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

      // Set key to read context description
      caseContextDescriptionKey.caseID = key.caseKey.caseID;

      // Read context description and assign to output object
      previewCaseContactLogDetails.contextDescription = readCaseContextDescription(
        caseContextDescriptionKey);

    }
    return previewCaseContactLogDetails;
  }

  // END, CR00167103

  // ___________________________________________________________________________
  /**
   * Returns a CaseID by Case Reference Number
   *
   * @param key
   * contains Case Reference Number.
   *
   * @return CaseID for the Case Reference Number.
   */
  public CaseIDDetails getCaseIDByCaseReference(final CaseReferenceSearchKey key)
    throws AppException, InformationalException {
    // Create return object
    final CaseIDDetails caseIDDtls = new CaseIDDetails();

    // CaseSearch manipulation variables
    final curam.core.intf.CaseSearch caseSearchObj = curam.core.fact.CaseSearchFactory.newInstance();
    final curam.core.struct.CaseReferenceSearchKey caseReferenceSearchKey = new curam.core.struct.CaseReferenceSearchKey();
    CaseSearchDetails caseSearchDetails;

    caseReferenceSearchKey.caseReference = key.caseReference;

    // Perform the search and map details to return object
    caseSearchDetails = caseSearchObj.readCaseIDByCaseReference(
      caseReferenceSearchKey);

    if (caseSearchDetails == null) {
      caseIDDtls.caseID = 0;
    } else {
      caseIDDtls.caseID = caseSearchDetails.caseID;
    }
    return caseIDDtls;
  }

  // BEGIN, CR00139531, ZV
  // ___________________________________________________________________________
  /**
   * Method to modify Case Contact Log details.
   *
   * @param details
   * Case Contact Log details to be updated
   */
  public void modifyContactLog(final ModifyCaseContactLogDetails details)
    throws AppException, InformationalException {

    // Case Contact Log service object
    final curam.core.sl.intf.CaseContactLog caseContactLogObj = curam.core.sl.fact.CaseContactLogFactory.newInstance();

    // modify case contact log details
    caseContactLogObj.modify1(details);
  }

  // ___________________________________________________________________________
  /**
   * Method to list Concern Case Participant Role details for Contact Log as tab
   * delimited string.
   *
   * @param key
   * Case ID and Contact Log ID key
   *
   * @return Concern Case Participant Role details tab delimited string.
   */
  public CaseParticipantTabList listContactLogConcernCaseParticipant(
    final CaseIDContactLogIDKey key) throws AppException, InformationalException {

    // Case Contact Log service object
    final curam.core.sl.intf.CaseContactLog caseContactLogObj = curam.core.sl.fact.CaseContactLogFactory.newInstance();

    // list Contact Log Concern Case Participant Role details
    return caseContactLogObj.listConcernCaseParticipantDetails(key);
  }

  // END, CR00139531

  // BEGIN, CR00140221, ZV
  // ___________________________________________________________________________
  /**
   * @param key
   * The criteria the Contact Logs should match.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by {@link #searchContactLog1()}. New
   * method returns additional end date time field.
   *
   * Search for Contact Logs that match the given search criteria.
   */
  @Deprecated
  public ContactLogListDtlsList searchContactLog(final ContactLogSearchKey key)
    throws AppException, InformationalException {
    // The return struct
    ContactLogListDtlsList contactLogListDtlsList = new ContactLogListDtlsList();

    // BEGIN, CR00120432, ZV
    if (key.actionControlID.equals(ACTIONCONTROLID.SEARCH)) {

      key.key.linkType = CONTACTLOGLINKTYPE.CASE;

      // Call the contact log service layer search method
      contactLogListDtlsList = ContactLogFactory.newInstance().searchContactLogs(
        key.key);

    }
    // END, CR00120432

    // BEGIN, CR00140531, CL
    // Contact Log service object
    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i < contactLogListDtlsList.dtls.size(); i++) {

      readContactLogDetails.contactLogDetails.assign(
        contactLogListDtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj.formatContactLogPurpose(
        readContactLogDetails);

      contactLogListDtlsList.dtls.item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
    }
    // END, CR00140531

    return contactLogListDtlsList;
  }

  // END, CR00140221

  // BEGIN, CR00175719, ZV
  // ___________________________________________________________________________
  /**
   * Lists the contact log contact participant and contact log concerning
   * participant records for a specified case.
   *
   * @param key
   * The case key
   *
   * @return The Case Contact Log Contact Participant and Concern Participant
   * details list
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ContactLogAttendeeAndConcernList listCaseContactLogAttendeeAndConcern(
    final CaseKey key) throws AppException, InformationalException {

    ContactLogAttendeeAndConcernList contactLogAttendeeAndConcernList = new ContactLogAttendeeAndConcernList();

    ContactLogAttendee contactLogAttendeeObj = ContactLogAttendeeFactory.newInstance();
    ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    ContactLogConcern contactLogConcernObj = ContactLogConcernFactory.newInstance();
    LinkIDLinkTypeRecordStatusKey linkIDLinkTypeRecordStatusKey = new LinkIDLinkTypeRecordStatusKey();

    contactLogLinkIDLinkTypeKey.linkID = key.caseID;
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.CASE;

    contactLogAttendeeAndConcernList.attendeeList = contactLogAttendeeObj.listByLinkID(
      contactLogLinkIDLinkTypeKey);

    linkIDLinkTypeRecordStatusKey.assign(contactLogLinkIDLinkTypeKey);

    // BEGIN, CR00243200, ZV
    contactLogAttendeeAndConcernList.concernList = contactLogConcernObj.listByLinkID(
      contactLogLinkIDLinkTypeKey);
    // END, CR00243200

    return contactLogAttendeeAndConcernList;
  }

  // BEGIN, CR00282028, IBM
  /**
   * Search for Case Contact Logs that match the given search criteria.
   *
   * @param key
   * The criteria the Contact Logs should match.
   *
   * @return contact log details list
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Case#searchContactLogs(ContactLogSearchKey1)}.
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchContactLogs(ContactLogSearchKey1) which returns the
   * informational message along with search contact log details as
   * well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public ContactLogSearchDetails searchContactLog1(final ContactLogSearchKey1 key)
    throws AppException, InformationalException {
    // END, CR00282028
    final ContactLogSearchDetails contactLogSearchDetails = new ContactLogSearchDetails();

    if (key.actionControlID.equals(ACTIONCONTROLID.SEARCH)) {

      key.key.key.linkType = CONTACTLOGLINKTYPE.CASE;

      contactLogSearchDetails.dtlsList = curam.core.sl.fact.ContactLogFactory.newInstance().searchContactLogs1(
        key.key);

    }

    final curam.core.sl.intf.ContactLog contactLogObj = curam.core.sl.fact.ContactLogFactory.newInstance();

    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i < contactLogSearchDetails.dtlsList.dtls.size(); i++) {

      readContactLogDetails.contactLogDetails.assign(
        contactLogSearchDetails.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj.formatContactLogPurpose(
        readContactLogDetails);

      contactLogSearchDetails.dtlsList.dtls.item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
    }
    // END, CR00140531

    return contactLogSearchDetails;
  }

  // ___________________________________________________________________________
  /**
   * Modifies reason and comments for a case owner.
   *
   * @param key
   * Case Owner key.
   * @param details
   * Case owner reassign reason and comments details.
   */
  public void modifyCaseOwnerReasonAndComments(
    final curam.core.sl.entity.struct.CaseUserRoleKey key,
    final CaseReassignReasonAndCommentsDetails details) throws AppException,
      InformationalException {

    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();

    caseUserRoleObj.modifyCaseOwnerReasonAndComments(key, details);

  }

  // END, CR00148805
  // BEGIN, CR00407986, AC
  // ___________________________________________________________________________
  /**
   * Method to list Contact Log details for a case.
   *
   * @param key
   * Contains case id
   *
   * @return The Contact Log details List
   * @deprecated and replaced by method listCaseContactLogs(CaseKey).
   * Since V6.0.5.4.see release notes of CR00407986.
   */
  @Deprecated
  public ListCaseContactLogDetails1 listContactLog1(final CaseKey key)
    throws AppException, InformationalException {
    final ListCaseContactLogDetails1 listCaseContactLogDetails = new ListCaseContactLogDetails1();

    // BEGIN, CR00301053, ZV
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00301053

    final ContactLog contactLogObj = ContactLogFactory.newInstance();

    final ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    contactLogLinkIDLinkTypeKey.linkID = key.caseID;
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.CASE;

    listCaseContactLogDetails.dtlsList = contactLogObj.list1(
      contactLogLinkIDLinkTypeKey);

    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i < listCaseContactLogDetails.dtlsList.dtls.size(); i++) {

      readContactLogDetails.contactLogDetails.assign(
        listCaseContactLogDetails.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj.formatContactLogPurpose(
        readContactLogDetails);

      listCaseContactLogDetails.dtlsList.dtls.item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
    }

    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = key.caseID;

    listCaseContactLogDetails.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    // return contact log details list for a case
    return listCaseContactLogDetails;
  }

  // END, CR00175719
  // END, CR00407986
  // BEGIN, CR00148820, MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ListTransactionsLogDetails listCaseRecentTransaction(
    final CaseHeaderKey caseKey) throws AppException, InformationalException {

    // Return Struct
    final ListTransactionsLogDetails listTransactionsLogDetails = new ListTransactionsLogDetails();

    // Case Transaction Log business process object
    final ReadTransactionLogDetailsList readTransactionLogDetailsList = new ReadTransactionLogDetailsList();

    final curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = caseKey.caseID;
    readTransactionLogDetailsList.transactionDetailsList = caseTransactionLogProvider.get().readAllTransactions(
      caseIDKey);

    // Read context description
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = caseKey.caseID;

    listTransactionsLogDetails.caseContextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    listTransactionsLogDetails.transactionDetailsList = readTransactionLogDetailsList;

    return listTransactionsLogDetails;
  }

  // END, CR00148820

  // BEGIN, CR00150153, ZV
  // ___________________________________________________________________________
  /**
   * Returns initial details to populate case search criteria.
   *
   * @return Initial details to populate case search criteria.
   */
  public InitialCaseSearchCriteria getCaseSearchCriteria() throws AppException,
      InformationalException {

    return CaseSearchFactory.newInstance().getCaseSearchCiteria();
  }

  // END, CR00150153

  // BEGIN, CR00162977, SPD
  // ___________________________________________________________________________
  /**
   * Returns a list of user details for all users who have or previously had a
   * role on the case regardless of status.
   *
   * @param key
   * The case identifier.
   *
   * @return List of users details
   */
  public UserNameDetailsList listAllCaseUsers(final CaseHeaderKey key)
    throws AppException, InformationalException {

    // Return struct
    final UserNameDetailsList userNameDetailsList = new UserNameDetailsList();

    // CaseUserRole API object
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();

    // BEGIN, CR00159871, SPD
    // Retrieve all case user roles for the case (including cancelled
    // status)
    userNameDetailsList.detailsList = caseUserRoleObj.listAllCaseUsers(key);

    // Determine whether any case users exist(ed)
    userNameDetailsList.details.result = caseUserRoleObj.doCaseUsersExist(key).result;
    // END, CR00159871

    // Read back the current case reviewer
    final UserNameAndFullName userNameAndFullName = caseUserRoleObj.readReviewer(
      key);

    // Populate current reviewer details
    userNameDetailsList.currentReviewer.userName = userNameAndFullName.userName;
    userNameDetailsList.currentReviewer.fullName = userNameAndFullName.fullName;

    return userNameDetailsList;
  }

  // END, CR00162977

  // BEGIN, CR00167103, SPD
  // BEGIN, CR00160632, Joao.Costa
  // BEGIN, CR00148040, ELG
  // ___________________________________________________________________________
  /**
   * Method to read the Contact Log details.
   *
   * @param key
   * Contains the contact log ID
   *
   * @return The Contact Log details
   */
  public CaseContactLogDetails readCaseContactLog(final CaseContactLogKey key)
    throws AppException, InformationalException {

    // Common variables
    final curam.core.facade.intf.ContactLog contactLog = curam.core.facade.fact.ContactLogFactory.newInstance();

    // return structure
    final CaseContactLogDetails caseContactLogDetails = new CaseContactLogDetails();

    // read contact log details
    final ContactLogKey contactLogKey = new ContactLogKey();

    contactLogKey.contactLogID = key.contactLogID;

    caseContactLogDetails.contactLogDetails = contactLog.readContactLog1(contactLogKey).readDetails;

    // read case context description
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = key.caseID;

    caseContactLogDetails.description = readCaseContextDescription(
      caseContextDescriptionKey);

    return caseContactLogDetails;
  }

  // END, CR00167103

  // ___________________________________________________________________________
  /**
   * Facade method to read case Contact Log attachments given the specified
   * contact log identifier and case identifier.
   *
   * @param key
   * contains the contact log identifier and case identifier.
   * @return CaseContactLogAttachmentDetails contains list of attachments and
   * case context description.
   * @throws AppException
   * , InformationalException
   */
  public CaseContactLogAttachmentDetails readCaseContactLogAttachments(
    final CaseContactLogKey key) throws AppException, InformationalException {
    // Common variables
    final curam.core.facade.intf.ContactLog contactLog = curam.core.facade.fact.ContactLogFactory.newInstance();

    // return structure
    final CaseContactLogAttachmentDetails caseContactLogAttachmentDetails = new CaseContactLogAttachmentDetails();

    // read attachments
    final ContactLogKey contactLogkey = new ContactLogKey();

    contactLogkey.contactLogID = key.contactLogID;
    caseContactLogAttachmentDetails.attachmentList = contactLog.readContactLogAttachments(
      contactLogkey);

    // read context description for the case
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = key.caseID;

    caseContactLogAttachmentDetails.description = readCaseContextDescription(
      caseContextDescriptionKey);

    return caseContactLogAttachmentDetails;

  }

  // END, CR00148040
  // END, CR00160632, Joao.Costa

  // BEGIN, CR00165038, ZV
  // ___________________________________________________________________________
  /**
   * Returns initial details to populate my cases search filter lists.
   *
   * @return Initial details to populate my cases search filter lists.
   */
  // BEGIN, CR00165038, ZV
  public MyCasesFilterList getMyCasesFilterList() throws AppException,
      InformationalException {
    // BEGIN, CR00166085, ZV
    final MyCasesFilterList myCasesFilterList = new MyCasesFilterList();

    myCasesFilterList.dtls = CaseSearchFactory.newInstance().getMyCasesFilterList();
    return myCasesFilterList;
    // END, CR00166085
  }

  // BEGIN, CR00166422, ZV
  // ___________________________________________________________________________
  /**
   * This method replaces the deprecated method {@link #addContactLogAttendee()}
   * Method to add Attendee to Case Contact Log. Passes additional 'I am a
   * Contact Participant' parameter to add new Contact Log Attendee.
   *
   * @param details
   * Contact Log id, case id and Contact Log Attendee details
   *
   * @return Contact Log Attendee key
   */
  public ContactLogAttendeeKey addContactLogAttendee1(
    final CreateCaseContactLogAttendeeDetails1 details) throws AppException,
      InformationalException {

    // create case contact log attendee
    return curam.core.sl.fact.CaseContactLogFactory.newInstance().createAttendee1(
      details);
  }

  // BEGIN, CR00226335,NRK
  // ___________________________________________________________________________
  /**
   * @param details
   * Contains case id and Contact Log details
   *
   * @return The Contact Log Key Objective List
   * @deprecated Since Curam 6.0, replaced by
   * {@link ContactLog#createContact(ContactLogWizardDetails)}. New
   * method uses contact log wizard details struct to implement the
   * wizard steps, the creation of contacts will go on to use the
   * existing ContactLog.create1() method in the service layer.New
   * method passes additional 'I am a Contact Participant' parameter
   * to create Contact Log Attendee.
   *
   * Method to create Contact Log and associate it to a case
   * provided.
   */
  @Deprecated
  public ContactLogKey createContactLog1(final CreateCaseContactLogDetails1 details)
    throws AppException, InformationalException {

    // create case contact log
    return curam.core.sl.fact.CaseContactLogFactory.newInstance().create1(
      details);
  }

  // END, CR00226335,NRK
  // END, CR00166422

  // BEGIN, CR00166342 SPD
  // ___________________________________________________________________________
  /**
   * Reads the details for a case attachment and the list of available case
   * members.
   *
   * @param key
   * case attachment identifier, case identifier.
   *
   * @return Details of the case attachment and list of case members
   */
  public ReadCaseAttachmentForModifyDetails readCaseAttachmentForModify(
    final ReadCaseAttachmentForModifyKey key) throws AppException,
      InformationalException {

    // return struct
    final ReadCaseAttachmentForModifyDetails details = new ReadCaseAttachmentForModifyDetails();

    // Instantiate facade object for integrated case
    final IntegratedCase integratedCaseObj = IntegratedCaseFactory.newInstance();

    // Populate return struct
    details.attachmentDetails = readCaseAttachment(key.attachmentKey);
    details.listMemberDetails = integratedCaseObj.listMemberDetails(
      key.listMemberKey);

    return details;
  }

  // END CR00166342
  // BEGIN, CR00342633, AC
  // BEGIN, CR00243200, ZV
  // BEGIN, CR00167103, SPD
  // ___________________________________________________________________________
  /**
   * Method to preview list of Case Contact Logs.
   *
   * @param key
   * Contains case id and list of contact log ids
   *
   * @return The list of Contact Log preview notes details
   *
   * @deprecated Since Curam 6.0.5.0, replaced with
   * {@link Case#previewCaseContactLogDetails(PreviewCaseContactLogIDKey)}. This method
   * selects the contact log with key of fixed size so the size of the key is increased.
   * See release note: CR00342633.
   */
  @Deprecated
  public PreviewCaseContactLogXMLDetails previewCaseContactLogs1(
    PreviewCaseContactLogKey key) throws AppException,
      InformationalException {

    // return contact log preview details list variable
    final PreviewCaseContactLogXMLDetails previewCaseContactLogDetails = new PreviewCaseContactLogXMLDetails();

    if (key.actionControlID.equals(ACTIONCONTROLID.PREVIEW)
      || key.actionControlID.length() == 0) {

      // Contact Log service object and variables
      final ContactLog contactLogObj = ContactLogFactory.newInstance();
      final PreviewContactLogKey1 previewContactLogKey1 = new PreviewContactLogKey1();

      previewContactLogKey1.linkType = CONTACTLOGLINKTYPE.CASE;
      previewContactLogKey1.multiSelectStr = key.previewContactLogKey.multiSelectStr;

      previewCaseContactLogDetails.dtls = contactLogObj.previewList1(
        previewContactLogKey1);

      // CaseContextDescriptionKey object
      final CaseContextDescriptionKey caseContextDescriptionKey = new
        CaseContextDescriptionKey();

      caseContextDescriptionKey.caseID = key.caseKey.caseID;

      // Read context description and assign to output object
      previewCaseContactLogDetails.description = readCaseContextDescription(
        caseContextDescriptionKey);
    }
    return previewCaseContactLogDetails;
  }

  // END, CR00167103
  // END, CR00243200
  // END, CR00342633
  // BEGIN, CR00167930 ZV
  // ___________________________________________________________________________
  /**
   * @return Details for the list of cases found.
   *
   * This method replaces the deprecated methods
   * {@link Organization#listCasesForOrgUnitOwner()},
   * {@link Organization#listCasesForPositionOwner()},
   * {@link Organization#listCasesForUser()} and
   * {@link WorkAllocation#listCasesForWorkQueueOwner()}, Search cases by
   * specified owner using default values.
   * @deprecated Since Curam 6.0 SP1, replaced by {@link #caseDefaultSearchByOwner1()}. This
   * method has been deprecated to introduce new message handling. See release note: CR00283614.
   */
  @Deprecated
  public CaseSearchByOwnerDetailsList caseDefaultSearchByOwner()
    throws AppException, InformationalException {

    final CaseSearchByOwnerDetailsList caseSearchByOwnerDetailsList = new CaseSearchByOwnerDetailsList();

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();
    // BEGIN, CR00201195, ZV
    final curam.core.struct.CaseSearchCriteria1 caseSearchCriteria = new curam.core.struct.CaseSearchCriteria1();
    // END, CR00201195

    final curam.core.struct.MyCasesFilterList filterList = caseSearchObj.getMyCasesFilterList();

    caseSearchCriteria.assign(filterList);

    // BEGIN, CR00203865, ZV
    // BEGIN, CR00201195, ZV
    caseSearchByOwnerDetailsList.dtls = CaseSearchFactory.newInstance().searchCaseByOwner(
      caseSearchCriteria);
    // END, CR00201195
    // END, CR00203865

    return caseSearchByOwnerDetailsList;
  }

  // BEGIN, CR00274833, ELG
  // ___________________________________________________________________________
  /**
   * This method replaces the deprecated method
   * {@link Case#caseDefaultSearchByOwner()},
   * Searches cases by current user as an owner using default values.
   *
   * @return Details for the list of cases found, and list of informational
   * messages.
   */
  public CaseSearchByOwnerResultList caseDefaultSearchByOwner1()
    throws AppException, InformationalException {

    final CaseSearchByOwnerResultList caseSearchByOwnerResultList = new CaseSearchByOwnerResultList();

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();
    final curam.core.struct.CaseSearchCriteria1 caseSearchCriteria = new curam.core.struct.CaseSearchCriteria1();
    final curam.core.struct.MyCasesFilterList filterList = caseSearchObj.getMyCasesFilterList();

    caseSearchCriteria.assign(filterList);

    caseSearchByOwnerResultList.dtls = CaseSearchFactory.newInstance().searchCaseByOwner(
      caseSearchCriteria);

    collectInformationals(caseSearchByOwnerResultList.msgList);

    return caseSearchByOwnerResultList;

  }

  // END, CR00274833


  // ___________________________________________________________________________
  /**
   * Stores user case search criteria values.
   *
   * @param caseSearchCriteria
   * User Case search criteria values to be stored.
   */
  public void storeCaseSearchCriteria(final CaseSearchCriteria1 details)
    throws AppException, InformationalException {

    CaseSearchFactory.newInstance().storeCaseSearchCriteria(details);
  }

  // END CR00167930

  // BEGIN, CR00172711, SPD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseNomineeID createCaseNominee1(final CreateNomineeDetails createDetails)
    throws AppException, InformationalException {

    // Return struct
    final CaseNomineeID caseNomineeID = new CaseNomineeID();

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    final CaseNomineeCreationDetails caseNomineeCreationDetails = new CaseNomineeCreationDetails();

    // BEGIN, CR00231961, ZV
    createDetails.details.regDetails.representativeRegistrationDetails.bankSortCode = createDetails.bankSortCode;
    // END, CR00231961

    // Validate selecting a nominee
    caseNomineeObj.validateSelectNominee(createDetails.details);

    // 1. Check if case participant has been selected
    if (createDetails.details.caseParticipantRoleID != 0) {
      createDetails.details.nomineeDetails.caseNomineeCreationDetails.concernRoleID = createDetails.details.caseParticipantRoleID;
    } // 2. Check if concern role has been selected
    else if (createDetails.details.concernRoleID != 0) {
      createDetails.details.nomineeDetails.caseNomineeCreationDetails.concernRoleID = createDetails.details.concernRoleID;
    } // 3. Check if a new nominee is being registered
    else if (createDetails.details.regDetails.representativeDtls.representativeName.length()
      > 0) {

      // Default registration date to today
      createDetails.details.regDetails.representativeRegistrationDetails.registrationDate = Date.getCurrentDate();
      createDetails.details.regDetails.representativeDtls.representativeType = REPRESENTATIVETYPE.NOMINEE;

      // service layer representative object
      final curam.core.sl.intf.Representative representativeObj = curam.core.sl.fact.RepresentativeFactory.newInstance();

      representativeObj.registerRepresentative(createDetails.details.regDetails);

      createDetails.details.nomineeDetails.caseNomineeCreationDetails.concernRoleID = createDetails.details.regDetails.representativeDtls.concernRoleID;
    }

    // Call into facade common functionality for creating a case nominee
    caseNomineeCreationDetails.caseNomineeCreationDetails = createDetails.details.nomineeDetails;

    createNomineeDetails(caseNomineeCreationDetails);

    // Create nominee for the specified case
    caseNomineeObj.createCaseNominee(createDetails.details.nomineeDetails);

    // Populate return struct
    caseNomineeID.caseNomineeID = createDetails.details.nomineeDetails.caseNomineeDtls.caseNomineeID;

    return caseNomineeID;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CreateDetailsForNomineeList listDetailsForNomineeCreation(final CaseIDKey key)
    throws AppException, InformationalException {

    // Return struct
    final CreateDetailsForNomineeList createDetailsForNomineeList = new CreateDetailsForNomineeList();

    // CaseParticipantRole service layer object
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();
    final ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();
    ViewCaseParticipantRoleDetailsList viewCaseParticipantRoleDetailsList = new ViewCaseParticipantRoleDetailsList();
    final CaseParticipantRoleIDAndNameDtlsList caseParticipantRoleIDAndNameDtlsList = new CaseParticipantRoleIDAndNameDtlsList();
    CaseParticipantRoleNameDetails caseParticipantRoleNameDetails;

    // DeliveryPattern list key variable
    final ProductDeliveryPatternByCaseIDKey productDeliveryPatternByCaseIDKey = new ProductDeliveryPatternByCaseIDKey();

    // BEGIN, CR00181451, SPD
    // Maintain Concern Role Details object
    final MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory.newInstance();

    // END, CR00181451

    // Set key to read participants for case
    viewCaseParticipantRole_boKey.dtls.caseID = key.dtls.dtls.caseID;
    viewCaseParticipantRole_boKey.showOnlyActive = true;

    // List all case participants
    viewCaseParticipantRoleDetailsList = caseParticipantRoleObj.listCaseParticipantsForIC(
      viewCaseParticipantRole_boKey);

    // Secure memory for return list
    caseParticipantRoleIDAndNameDtlsList.dtls.dtls.ensureCapacity(
      viewCaseParticipantRoleDetailsList.dtls.size());

    // BEGIN, CR00175165, SPD
    final String locale = TransactionInfo.getProgramLocale();
    final String codetable = NOMINEECONCERNROLETYPE.TABLENAME;

    final String[] codeTableItems = CodeTable.getAllCodes(codetable, locale);

    final List<String> permittedConcernRoleList = new ArrayList<String>(
      codeTableItems.length);

    for (final String codetableCode : codeTableItems) {
      permittedConcernRoleList.add(codetableCode);
    }
    // END, CR00175165

    // Populate return struct list
    for (int i = 0; i < viewCaseParticipantRoleDetailsList.dtls.size(); i++) {

      // BEGIN, CR00175165, SPD
      // BEGIN, CR00181451, SPD
      if (permittedConcernRoleList.contains(
        viewCaseParticipantRoleDetailsList.dtls.item(i).participantRoleType)) {

        caseParticipantRoleNameDetails = new CaseParticipantRoleNameDetails();

        // set up data for appending age to dropdown
        final ConcernRolesDetails concernRolesDetails = new ConcernRolesDetails();

        concernRolesDetails.concernRoleID = viewCaseParticipantRoleDetailsList.dtls.item(i).participantRoleID;
        concernRolesDetails.concernRoleType = viewCaseParticipantRoleDetailsList.dtls.item(i).participantRoleType;
        concernRolesDetails.concernRoleName = viewCaseParticipantRoleDetailsList.dtls.item(i).name;

        // Add age to concern role name in dropdown
        caseParticipantRoleNameDetails.concernRoleName = maintainConcernRoleDetailsObj.appendAgeToName(concernRolesDetails).concernRoleName;
        // END, CR00181451, SPD

        caseParticipantRoleNameDetails.caseParticipantRoleID = viewCaseParticipantRoleDetailsList.dtls.item(i).caseParticipantRoleID;
        caseParticipantRoleNameDetails.participantRoleID = viewCaseParticipantRoleDetailsList.dtls.item(i).participantRoleID;

        caseParticipantRoleIDAndNameDtlsList.dtls.dtls.addRef(
          caseParticipantRoleNameDetails);
      }
      // END, CR00175165
    }

    // Set key to read list of delivery pattern
    productDeliveryPatternByCaseIDKey.caseID = key.dtls.dtls.caseID;

    // Populate return struct
    createDetailsForNomineeList.caseParticipanRoleList = caseParticipantRoleIDAndNameDtlsList;
    createDetailsForNomineeList.deliveryPatternList = listDeliveryPatternForCase(
      productDeliveryPatternByCaseIDKey);

    return createDetailsForNomineeList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseNomineeViewDetails1 viewCaseNomineeDetails1(final CaseNomineeViewKey key)
    throws AppException, InformationalException {

    // Return structure
    final CaseNomineeViewDetails1 caseNomineeViewDetails1 = new CaseNomineeViewDetails1();

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // CaseParticipantRole_EO manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRole = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();
    CaseParticipantRole_eoCaseParticipantRoleID caseParticipantRoleCaseParticipantRoleID;

    // Variables used to read public office details
    final Location locationObj = LocationFactory.newInstance();
    final LocationKey locationKey = new LocationKey();
    String publicOfficeName;

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Read details from service layer into return struct
    caseNomineeViewDetails1.caseNomineeViewDetails = caseNomineeObj.viewCaseNomineeDetails(
      key.caseNomineeViewKey);

    caseIDParticipantRoleKey.participantRoleID = caseNomineeViewDetails1.caseNomineeViewDetails.caseNomineeDetails.concernRoleID;

    caseIDParticipantRoleKey.caseID = caseNomineeViewDetails1.caseNomineeViewDetails.caseNomineeDetails.caseID;

    // Reads caseParticipantRoleID
    caseParticipantRoleCaseParticipantRoleID = caseParticipantRole.readCaseParticipantRoleID(
      caseIDParticipantRoleKey);

    // Assign caseParticipantRoleID to the return object
    caseNomineeViewDetails1.caseNomineeViewDetails.caseParticipantRoleID = caseParticipantRoleCaseParticipantRoleID.caseParticipantRoleID;

    // Set the key for a public office read
    locationKey.locationID = caseNomineeViewDetails1.caseNomineeViewDetails.publicOfficeID;

    // Read publicOffice from database
    try {
      publicOfficeName = locationObj.read(locationKey).name;
    } catch (final curam.util.exception.RecordNotFoundException e) {
      publicOfficeName = null;
    }

    // Copy specific details
    if (publicOfficeName != null) {
      caseNomineeViewDetails1.caseNomineeViewDetails.publicOfficeName = publicOfficeName;
      caseNomineeViewDetails1.caseNomineeViewDetails.publicOfficeID = caseNomineeViewDetails1.caseNomineeViewDetails.publicOfficeID;
    }

    // Set key to read context description
    caseContextDescriptionKey.caseID = caseNomineeViewDetails1.caseNomineeViewDetails.caseNomineeDetails.caseID;

    // Populate return struct with context description
    caseNomineeViewDetails1.caseNomineeContextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    // Default Deactivate indicator
    caseNomineeViewDetails1.displayDeactivateInd = false;

    // Set Deactivate indicator based on status of nominee
    if (caseNomineeViewDetails1.caseNomineeViewDetails.nomineeStatus.equals(
      CASENOMINEESTATUS.OPERATIONAL)) {
      caseNomineeViewDetails1.displayDeactivateInd = true;
    }
    
    // BEGIN, CR00372248,GA    
    caseNomineeViewDetails1.ibanIndOpt = Configuration.getBooleanProperty(
      EnvVars.ENV_PARTICIPANT_ENABLE_IBAN_FUNCTIONALITY);
    // END, CR00372248

    return caseNomineeViewDetails1;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void createNomineeDetails(final CaseNomineeCreationDetails details)
    throws AppException, InformationalException {

    // BEGIN, CR00100893, PMD
    // Client merge manipulation variables
    final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // ConcernRole Key
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // BEGIN, CR00226315, PM
    // security variables
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    concernRoleKey.concernRoleID = details.caseNomineeCreationDetails.caseNomineeCreationDetails.concernRoleID;

    participantSecurityCheckKey.participantID = concernRoleKey.concernRoleID;
    // BEGIN, CR00415358, KRK
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    // END, CR00415358
    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
      participantSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_NOMINEE_SENSITIVITY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00226315

    // Check if the concern role has been marked as a duplicate
    final CuramInd curamInd = clientMergeObj.isConcernRoleDuplicate(
      concernRoleKey);

    // If the nominee is a duplicate, throw an exception
    if (curamInd.statusInd) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOCASENOMINEE.ERR_CASENOMINEE_XRV_DUPLICATE_CLIENT),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00100893
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void modifyNomineeAddress(final ModifyNomineeAddressDetails details)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    caseNomineeObj.modifyNomineeAddress(details.details);
  }

  // END, CR00172711

  // BEGIN, CR00231506, PDN
  // BEGIN CR00152332, SS
  // _____________________________________________________________________________
  /**
   * Retrieves a list of accessible case notes for a case.
   *
   * @param key
   * Contains the case identifier.
   * @return A list of accessible notes for the case. The list also comprises of
   * a noteAccessInd which will restrict the user to access the case
   * notes if the user sensitivity is less than case note sensitivity.
   * @throws AppException
   * @throws InformationalException
   * @deprecated -since Version 6.0
   * @deprecated - replaced by {@link #listAccessibleNotes1()}
   */
  @Deprecated
  public CaseAccessibleNotesList listAccessibleNotes(final CaseKey_fo key)
    throws AppException, InformationalException {

    final CaseAccessibleNotesList1 caseAccessibleNotesList1 = listAccessibleNotes1(
      key);

    final CaseAccessibleNotesList caseAccessibleNotesList = new CaseAccessibleNotesList();

    caseAccessibleNotesList.assign(caseAccessibleNotesList1);

    return caseAccessibleNotesList;
  }

  // _____________________________________________________________________________
  /**
   * Retrieves a list of accessible case notes for a case.
   *
   * @param key
   * Contains the case identifier.
   * @return A list of accessible notes for the case. The list also comprises of
   * a noteAccessInd which will restrict the user to access the case
   * notes if the user sensitivity is less than case note sensitivity.
   * @throws AppException
   * @throws InformationalException
   */
  public CaseAccessibleNotesList1 listAccessibleNotes1(final CaseKey_fo key)
    throws AppException, InformationalException {

    // Create an object to return the details
    final CaseAccessibleNotesList1 caseAccessibleNotesList = new CaseAccessibleNotesList1();

    // Case Note Object.
    final curam.core.sl.intf.CaseNote caseNoteObj = curam.core.sl.fact.CaseNoteFactory.newInstance();

    // CaseContextDescriptionKey object.
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // CaseHeaderKey object.
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // Case Header manipulation variables.
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // Set case key.
    caseKey.caseID = key.key.key.caseID;

    // Read case type code.
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // If case type is service plan, check service plan security.
    if (CASETYPECODE.SERVICEPLAN.equals(caseTypeCode.caseTypeCode)) {

      // ServicePlanDelivery facade.
      final curam.serviceplans.facade.intf.ServicePlanDelivery servicePlanDeliveryObj = curam.serviceplans.facade.fact.ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // Register the service plan security implementation.
      ServicePlanSecurityImplementationFactory.register();

      // Set the key.
      servicePlanSecurityKey.caseID = key.key.key.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // Check security.
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }

    // BEGIN, CR00184010, PDN
    caseAccessibleNotesList.details = caseNoteObj.listAccessibleNotesSorted1(
      key.key);
    // END, CR00184010

    // Set key to read context description.
    caseContextDescriptionKey.caseID = key.key.key.caseID;

    // Read context description and assign to output object.
    caseAccessibleNotesList.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    // Set the case menu data.
    caseHeaderKey.caseID = caseContextDescriptionKey.caseID;
    final CaseMenuData caseMenuData = getCaseMenuDataDetails(caseHeaderKey);

    // Will be not set for specific cases e.g. stand alone cases.
    if (caseMenuData != null) {
      caseAccessibleNotesList.menuData.menuData = caseMenuData.menuData;
    }

    return caseAccessibleNotesList;
  }

  // END, CR00231506

  // END CR00152332

  // BEGIN, CR00175612, SPD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void modifyNomineeBankAccount(final ModifyNomineeBankAcDetails modifyDetails)
    throws AppException, InformationalException {

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    // BEGIN, CR00231961, ZV
    modifyDetails.details.accountDetails.bankAcDetails.bankSortCode = modifyDetails.bankSortCode;
    // END, CR00231961

    caseNomineeObj.modifyNomineeBankAc(modifyDetails.details);

  }

  // END CR00175612, SPD

  // BEGIN, CR00194084, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public DefaultNomineeDelPattDetailsList listAvailableDefaultNomineeDelPatt(
    final CaseIDNomineeIDKey key) throws AppException, InformationalException {

    // Create return struct
    DefaultNomineeDelPattDetailsList defaultNomineeDelPattDetailsList = new DefaultNomineeDelPattDetailsList();

    // ServiceLayer CaseNominee object
    final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

    defaultNomineeDelPattDetailsList = caseNomineeObj.listAvailableDefaultNomineeDelPatt(
      key);

    return defaultNomineeDelPattDetailsList;
  }

  // END, CR00194084

  // BEGIN, CR00201195, ZV

  // ___________________________________________________________________________
  /**
   * @param key
   * Contains the case search criteria.
   *
   * @return Details for the list of cases found.
   *
   * Presentation layer method to search for a case.
   * @deprecated Since Curam 6.0 SP1, replaced by {@link #caseSearch2()}. This
   * method has been deprecated to introduce new message handling. See release note: CR00283614.
   */
  @Deprecated
  public CaseSearchList1 caseSearch1(final CaseSearchCriteria1 key)
    throws AppException, InformationalException {

    final CaseSearchList1 caseSearchList = new CaseSearchList1();

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    caseSearchList.listDtls = caseSearchObj.caseSearch(key);
    // BEGIN, CR00230649, JMA
    CaseContextPanelKey caseContextPanelKey;

    for (final CaseSearchDetails1 details : caseSearchList.listDtls.searchDtls) {

      caseContextPanelKey = new CaseContextPanelKey();

      caseContextPanelKey.caseID = details.caseID;

      details.contextPanelName = resolveContextPanel(caseContextPanelKey).homePageName;
    }
    // END, CR00230649
    return caseSearchList;
  }

  // END, CR00201195


  // BEGIN, CR00274833, ELG
  // ___________________________________________________________________________
  /**
   * Presentation layer method to search for a case.
   * This method replaces the deprecated method
   * {@link Case#caseSearch1()},
   *
   * @param key
   * Contains the case search criteria.
   *
   * @return Details for the list of cases found, and list of informational messages.
   */
  public CaseSearchResultList caseSearch2(CaseSearchCriteria1 key)
    throws AppException, InformationalException {

    final CaseSearchResultList caseSearchResultList = new CaseSearchResultList();
    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    caseSearchResultList.listDtls = caseSearchObj.caseSearch(key);

    CaseContextPanelKey caseContextPanelKey;

    for (final CaseSearchDetails1 details : caseSearchResultList.listDtls.searchDtls) {

      caseContextPanelKey = new CaseContextPanelKey();

      caseContextPanelKey.caseID = details.caseID;

      details.contextPanelName = resolveContextPanel(caseContextPanelKey).homePageName;
    }

    // Get informational messages here
    collectInformationals(caseSearchResultList.msgList);

    return caseSearchResultList;

  }

  // ___________________________________________________________________________
  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList param passed in.
   *
   * @param msgDtlsList
   * The list to add the informational messages to
   */
  @curam.util.type.AccessLevel(curam.util.type.AccessLevelType.INTERNAL)
  protected void collectInformationals(final InformationalMsgDtlsList msgDtlsList) {
    // Get the list of informationals
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    String[] infos = informationalManager.obtainInformationalAsString();

    for (String message : infos) {
      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;
      msgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00274833


  // BEGIN, CR00211081, MC
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public WizardProperties getICProductDeliveryCreateWizard()
    throws AppException, InformationalException {

    final WizardProperties wizardProperties = new WizardProperties();

    wizardProperties.wizardMenu = CuramConst.kCreateICProductDeliveryWizardProperties;

    return wizardProperties;
  }

  // END, CR00211081

  // BEGIN, CR00187598, SS
  /**
   * Returns a list of released workflow processes available for configuration
   * of ownership strategy with a case type.
   *
   * @return List of released workflow processes for ownership strategy
   * configuration for a case type.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public OwnershipStrategyDetailsList listWorkflowProcesses()
    throws AppException, InformationalException {

    final OwnershipStrategyDetailsList ownershipStrategyDetailsList = new OwnershipStrategyDetailsList();

    final ProcessAdmin processAdminObj = ProcessAdminFactory.newInstance();
    final ProcessSummaryDetailsList processSummaryDetailsList = processAdminObj.listLatestReleasedProcesses();

    for (int i = 0; i < processSummaryDetailsList.dtls.size(); i++) {

      final OwnershipStrategyDetails ownershipStrategyDetails = new OwnershipStrategyDetails();
      final ProcessSummaryDetails processSummaryDetails = processSummaryDetailsList.dtls.item(
        i);

      ownershipStrategyDetails.ownershipStrategyID = processSummaryDetails.processID;
      ownershipStrategyDetails.ownershipStrategyName = processSummaryDetails.name;

      ownershipStrategyDetailsList.dtls.addRef(ownershipStrategyDetails);
    }
    return ownershipStrategyDetailsList;
  }

  // END, CR00187598

  // BEGIN, CR00217942, ZV
  // ___________________________________________________________________________
  /**
   * Retrieves a list of active case participant roles for a case.
   *
   * @param key
   * The case to retrieve case participant roles for
   *
   * @return A list of active case participant roles for the case
   */
  public ActiveCaseParticipantRoleList listActiveCaseParticipantRole(
    final CaseIDAndRecordStatus key) throws AppException, InformationalException {

    final ActiveCaseParticipantRoleList activeCaseParticipantRoleList = new ActiveCaseParticipantRoleList();

    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();

    activeCaseParticipantRoleList.dtlsList = caseParticipantRoleObj.searchActiveByCaseID(
      key);

    return activeCaseParticipantRoleList;
  }

  // END, CR00217942

  // BEGIN, CR00216737, GYH
  /**
   * Returns primary case participant details for a given case ID.
   *
   * @param key
   * Contains case ID.
   *
   * @return Primary case participant details of a case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public CaseParticipantDetails getPrimaryCaseParticipantDetails(
    final curam.core.sl.struct.CaseKey key) throws AppException,
      InformationalException {
    final CaseParticipantDetails caseParticipantDetails = new CaseParticipantDetails();
    final curam.core.sl.entity.struct.CaseIDTypeCodeKey caseIDTypeCodeKey = new curam.core.sl.entity.struct.CaseIDTypeCodeKey();

    caseIDTypeCodeKey.caseID = key.key.caseID;
    caseIDTypeCodeKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    final CaseParticipantRoleFullDetails1 caseParticipantRoleDetails = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance().readByCaseIDAndTypeCode(
      caseIDTypeCodeKey);

    caseParticipantDetails.caseParticipantRoleID = caseParticipantRoleDetails.dtls.caseParticipantRoleID;
    caseParticipantDetails.participantRoleID = caseParticipantRoleDetails.dtls.participantRoleID;
    caseParticipantDetails.participantName = caseParticipantRoleDetails.dtls.name;
    return caseParticipantDetails;
  }

  // END, CR00216737

  // BEGIN, CR00221300, ZV
  // ___________________________________________________________________________
  /**
   * Creates a Case Relationship.
   *
   * @param details
   * Case relationship details.
   */
  // BEGIN, CR00409050, SG
  @AccessLevel(AccessLevelType.EXTERNAL)
  // END, CR00409050
  public void createRelationship1(final MaintainRelationshipDetails1 details)
    throws AppException, InformationalException {

    // MaintainRelatedCases manipulation variable
    final MaintainRelatedCases maintainRelatedCasesObj = MaintainRelatedCasesFactory.newInstance();

    // Call MaintainRelatedCases BPO to create the case relationship
    maintainRelatedCasesObj.createCaseRelationship1(
      details.maintainCaseRelationshipDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modifies a Case Relationship.
   *
   * @param details
   * case relationship details.
   */
  public void modifyRelationship1(final MaintainRelationshipDetails1 details)
    throws AppException, InformationalException {

    // Maintain Case relationship maintenance object
    final MaintainRelatedCases maintainRelatedCasesObj = MaintainRelatedCasesFactory.newInstance();

    // Case relationship maintenance object and key
    final curam.core.intf.CaseRelationship caseRelationshipObj = curam.core.fact.CaseRelationshipFactory.newInstance();
    final CaseRelationshipKey caseRelationshipKey = new CaseRelationshipKey();

    // Details returned from CaseRelationship.read
    CaseRelationshipDtls caseRelationshipDtls;

    caseRelationshipKey.caseRelationshipID = details.maintainCaseRelationshipDetails.caseRelationshipID;

    // Read the case relationship
    caseRelationshipDtls = caseRelationshipObj.read(caseRelationshipKey);

    if (caseRelationshipDtls.statusCode.equals(
      curam.codetable.RECORDSTATUS.CANCELLED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERAL.ERR_GENERAL_FV_NO_MODIFY_RECORD_CANCELLED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          17);
    }

    // Modify Case Relationship
    maintainRelatedCasesObj.modifyCaseRelationship1(
      details.maintainCaseRelationshipDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads a Case Relationship
   *
   * @param key
   * Case relationship identifier.
   *
   * @return Details of the case relationship.
   */
  public ReadRelationshipDetails1 readRelationship1(final ReadRelationshipKey key)
    throws AppException, InformationalException {

    // Create return object
    final ReadRelationshipDetails1 readRelationshipDetails = new ReadRelationshipDetails1();

    // MaintainRelatedCases manipulation variable
    final MaintainRelatedCases maintainRelatedCasesObj = MaintainRelatedCasesFactory.newInstance();

    key.maintainCaseRelationshipDetailsKey.caseID = key.caseID;

    // Call MaintainRelatedCases BPO to read the case relationship details
    readRelationshipDetails.maintainCaseRelationshipDetails = maintainRelatedCasesObj.readCaseRelationship1(
      key.maintainCaseRelationshipDetailsKey);

    // as the relationship can be in either of two directions, need to check
    // which relationship relates to the caseID, and swap them if necessary
    if (readRelationshipDetails.maintainCaseRelationshipDetails.relatedCaseID
      == key.caseID) {

      final long caseID = readRelationshipDetails.maintainCaseRelationshipDetails.relatedCaseID;

      final String caseReference = readRelationshipDetails.maintainCaseRelationshipDetails.relatedCaseReference;

      readRelationshipDetails.maintainCaseRelationshipDetails.relatedCaseID = readRelationshipDetails.maintainCaseRelationshipDetails.caseID;
      readRelationshipDetails.maintainCaseRelationshipDetails.relatedCaseReference = readRelationshipDetails.maintainCaseRelationshipDetails.caseReference;

      readRelationshipDetails.maintainCaseRelationshipDetails.caseID = caseID;
      readRelationshipDetails.maintainCaseRelationshipDetails.caseReference = caseReference;
    }

    return readRelationshipDetails;
  }

  // END, CR00221300

  // BEGIN, CR00221275, VM
  // ___________________________________________________________________________
  /**
   * Determines if a case is delivering a Curam Rules product or a CREOLE-aware
   * product.
   *
   * @param key
   * Case Header entity key.
   * @param approvalKey
   * Case Approval entity key
   *
   * @return whether the product being delivered is Curam Rules or CREOLE-aware,
   * together with a determinationID if the product type is
   * CREOLE-aware.
   */
  public IsCreoleProduct isCreoleProduct(final CaseHeaderKey key,
    final CaseApprovalKey approvalKey) throws AppException,
      InformationalException {

    final IsCreoleProduct result = new IsCreoleProduct();

    // BEGIN, CR00250786, MC
    // Read the case type if it is an Investigation the case is not CREOLE-aware
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;
    if (caseHeaderObj.readCaseTypeCode(caseKey).caseTypeCode.equals(
      CASETYPECODE.INVESTIGATIONCASE)) {
      result.result = CuramConst.kNO;

      return result;
    }
    // END, CR00250786

    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    productDeliveryKey.caseID = key.caseID;

    final ProductIDDetails details = ProductDeliveryFactory.newInstance().readProductID(
      productDeliveryKey);

    final CREOLEProductKey creoleProductKey = new CREOLEProductKey();

    creoleProductKey.productID = details.productID;

    final NotFoundIndicator nfIndicator = new NotFoundIndicator();

    CREOLEProductFactory.newInstance().read(nfIndicator, creoleProductKey);

    if (nfIndicator.isNotFound()) {
      result.result = CuramConst.kNO;
    } else {
      result.result = CuramConst.kYES;

      final CaseApprovalDtls approvalDtls = CaseApprovalFactory.newInstance().read(
        approvalKey);

      result.determinationID = approvalDtls.determinationID;
    }

    return result;
  }

  // END, CR00221275

  // BEGIN, CR00224703, ZV
  // ___________________________________________________________________________
  /**
   * Creates a case review.
   *
   * @param details
   * Details of the case review.
   */
  public void createReview1(final CreateReviewDetails1 details)
    throws AppException, InformationalException {

    // MaintainCaseReview manipulation variables
    final MaintainCaseReview maintainCaseReviewObj = MaintainCaseReviewFactory.newInstance();
    final MaintainCaseReviewDetails1 maintainCaseReviewDetails = new MaintainCaseReviewDetails1();

    // BEGIN, CR00150400, SPD
    // BEGIN, CR00162977, SPD
    // A reviewer must be entered
    if (details.reviewerID.length() == 0
      && details.previousUserID.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOMAINTAINCASEREVIEW.ERR_CASEREVIEW_FV_REVIEWER_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    // A user or a previous reviewer can be selected as the new
    // reviewer (but not both)
    if (details.reviewerID.length() > 0 && details.previousUserID.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOMAINTAINCASEREVIEW.ERR_CASEREVIEW_XFV_SET_REVIEWER),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00162977
    // END, CR00150400

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = details.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade manipulation variables
      final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = details.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kCreateSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Assign review details
    maintainCaseReviewDetails.assign(details);

    // BEGIN, CR00149193, SPD
    // Set the reviewer to selected previous reviewer
    if (details.reviewerID.length() == 0 && details.previousUserID.length() > 0) {
      maintainCaseReviewDetails.reviewerID = details.previousUserID;
    }
    // END, CR00149193

    // Call MaintainCaseReview BPO to create the case review.
    maintainCaseReviewObj.insertCaseReviewEvent1(maintainCaseReviewDetails);
  }

  // ___________________________________________________________________________
  /**
   * Modifies the details of a case review.
   *
   * @param details
   * The case review details.
   */
  public void modifyReview1(final ModifyReviewDetails1 details)
    throws AppException, InformationalException {

    // MaintainCaseReview manipulation variable
    final MaintainCaseReview maintainCaseReviewObj = MaintainCaseReviewFactory.newInstance();
    final MaintainCaseReviewDetails1 maintainCaseReviewDetails = new MaintainCaseReviewDetails1();

    // Case review entity objects
    final curam.core.intf.CaseReview caseReviewObj = curam.core.fact.CaseReviewFactory.newInstance();
    final CaseReviewKey caseReviewKey = new CaseReviewKey();
    CaseReviewDtls caseReviewDtls;

    // BEGIN, CR00162977, SPD
    // A reviewer must be entered
    if (details.reviewerID.length() == 0
      && details.previousUserID.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOMAINTAINCASEREVIEW.ERR_CASEREVIEW_FV_REVIEWER_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // A user or a previous user on the case can be selected as the new
    // reviewer (but not both)
    if (details.reviewerID.length() > 0 && details.previousUserID.length() > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOMAINTAINCASEREVIEW.ERR_CASEREVIEW_XFV_SET_REVIEWER),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    // END, CR00162977

    // Assign key details to read the case review
    caseReviewKey.caseReviewID = details.caseReviewID;

    // read case review event details.
    caseReviewDtls = caseReviewObj.read(caseReviewKey);

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = caseReviewDtls.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = caseReviewDtls.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kMaintainSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Assign review details
    maintainCaseReviewDetails.assign(details);

    // BEGIN, CR00162977, SPD
    // Set the reviewer to selected previous user on the case
    if (details.reviewerID.length() == 0 && details.previousUserID.length() > 0) {
      maintainCaseReviewDetails.reviewerID = details.previousUserID;
    }
    // END, CR00162977

    maintainCaseReviewDetails.caseID = caseReviewDtls.caseID;

    maintainCaseReviewDetails.typeCode = caseReviewDtls.typeCode;

    // Call the MaintainCaseReview BPO to modify the case review details.
    maintainCaseReviewObj.modifyCaseReviewEvent1(maintainCaseReviewDetails);
  }

  // ___________________________________________________________________________
  /**
   * Reads details of a case review.
   *
   * @param key
   * Key to read the case review details.
   *
   * @return Case review details
   */
  public ReadReviewDetails1 readReview1(final ReadReviewKey key)
    throws AppException, InformationalException {

    // Create a return object
    final ReadReviewDetails1 readReviewDetails = new ReadReviewDetails1();
    // MaintainCaseReview manipulation variables
    final MaintainCaseReview maintainCaseReviewObj = MaintainCaseReviewFactory.newInstance();
    final MaintainCaseReviewKey maintainCaseReviewKey = new MaintainCaseReviewKey();

    // Case event object
    final curam.core.intf.CaseEvent caseEventObj = curam.core.fact.CaseEventFactory.newInstance();

    // CaseEventNSReadKey object
    final CaseEventNSReadKey caseEventNSReadKey = new CaseEventNSReadKey();

    // CaseEventNSReadDetails object
    CaseEventNSReadDetails caseEventNSReadDetails;

    // Populate caseEventNSReadKey
    caseEventNSReadKey.relatedID = key.caseReviewID;

    // Get the case event details for this review
    caseEventNSReadDetails = caseEventObj.readByRelatedID(caseEventNSReadKey);

    // BEGIN, CR00001117, CM
    // Case Header manipulation variables
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    // set case key
    caseKey.caseID = caseEventNSReadDetails.caseID;

    // read case type code
    final CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    // if case type is service plan, check service plan security
    if (caseTypeCode.caseTypeCode.equals(
      curam.codetable.CASETYPECODE.SERVICEPLAN)) {

      // ServicePlanDelivery facade
      final ServicePlanDelivery servicePlanDeliveryObj = ServicePlanDeliveryFactory.newInstance();
      final ServicePlanSecurityKey servicePlanSecurityKey = new ServicePlanSecurityKey();

      // register the service plan security implementation
      ServicePlanSecurityImplementationFactory.register();

      // set the key
      servicePlanSecurityKey.caseID = caseEventNSReadDetails.caseID;
      servicePlanSecurityKey.securityCheckType = ServicePlanSecurity.kReadSecurityCheck;

      // check security
      servicePlanDeliveryObj.checkSecurity(servicePlanSecurityKey);
    }
    // END, CR00001117

    // Populate the maintainCaseReviewKey with the case event ID.
    maintainCaseReviewKey.caseEventID = caseEventNSReadDetails.caseEventID;

    // Assign key details to read the case review
    maintainCaseReviewKey.caseReviewID = key.caseReviewID;

    // Call MaintainCaseReview BPO to read the case review details and
    // assign
    // to return object
    readReviewDetails.assign(
      maintainCaseReviewObj.viewCaseReviewEvent1(maintainCaseReviewKey));

    // CaseContextDescriptionKey object
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    // Set key to read context description
    caseContextDescriptionKey.caseID = caseEventNSReadDetails.caseID;

    // Read context description and assign to output object
    readReviewDetails.contextDescription = readCaseContextDescription(
      caseContextDescriptionKey);

    return readReviewDetails;
  }

  // END, CR00224703

  // BEGIN, CR00248001, GYH
  /**
   * Returns product category code for the given case identifier.
   *
   * @param key
   * Contains case identifier.
   *
   * @return Product category code for the given case identifier.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ProductCategoryCode getProductCategoryCode(ReadCaseTypeKey key)
    throws AppException, InformationalException {

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    ProductCategoryCode productCategoryCode = new ProductCategoryCode();

    productCategoryCode.productCategoryCode = CaseHeaderFactory.newInstance().read(caseHeaderKey).integratedCaseType;
    return productCategoryCode;
  }

  // END, CR00248001

  // BEGIN, CR00282028, IBM
  /**
   * Search contact log details by given search criteria.
   *
   * @param contactLogSearchKey1
   * contains contact log search key.
   *
   * @return contact log details
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public SearchContactLogDetails searchContactLogs(
    final ContactLogSearchKey1 contactLogSearchKey1) throws AppException,
      InformationalException {
    SearchContactLogDetails searchContactLogDetails = new SearchContactLogDetails();

    if (ACTIONCONTROLID.SEARCH.equals(contactLogSearchKey1.actionControlID)) {

      contactLogSearchKey1.key.key.linkType = CONTACTLOGLINKTYPE.CASE;

      searchContactLogDetails.dtlsList = curam.core.sl.fact.ContactLogFactory.newInstance().searchContactLogs1(
        contactLogSearchKey1.key);
    }
    // BEGIN, CR00407986, AC
    final int kMaxNoCases;
    final String envMaxNoCases = Configuration.getProperty(
      EnvVars.ENV_CASES_MAXNOCONTACTLOGS);

    if (null == envMaxNoCases) {

      kMaxNoCases = EnvVars.ENV_CASES_MAXNOCONTACTLOGS_DEFAULT;
    } else {
      kMaxNoCases = Integer.parseInt(envMaxNoCases);
    }

    final ContactLog contactLogObj = ContactLogFactory.newInstance();
    final SearchContactLogDetails searchContactLogDetails1 = new SearchContactLogDetails();
    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    for (int i = 0; i < searchContactLogDetails.dtlsList.dtls.size()
      && i < kMaxNoCases; i++) {

      readContactLogDetails.contactLogDetails.assign(
        searchContactLogDetails.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj.formatContactLogPurpose(
        readContactLogDetails);

      searchContactLogDetails.dtlsList.dtls.item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
      searchContactLogDetails1.dtlsList.dtls.addRef(
        searchContactLogDetails.dtlsList.dtls.item(i));
    }

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] infos = informationalManager.obtainInformationalAsString();
    // END, CR00407986
    ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    contactLogLinkIDLinkTypeKey.linkID = contactLogSearchKey1.key.key.linkID;
    contactLogLinkIDLinkTypeKey.linkType = contactLogSearchKey1.key.key.linkType;
    final CaseContactLogList listCaseContactLogDetails = new CaseContactLogList();

    listCaseContactLogDetails.dtlsList = contactLogObj.list1(
      contactLogLinkIDLinkTypeKey);
    // BEGIN, CR00407986, AC
    if (searchContactLogDetails.dtlsList.dtls.size() >= kMaxNoCases) {
      final LocalisableString infoMessage = new LocalisableString(
        ENTCONTACTLOG.INF_ALL_CONTACTLOG_CANNOT_BE_DISPLAYED);

      infoMessage.arg(kMaxNoCases);
      // BEGIN, CR00414040, MV
      infoMessage.arg(searchContactLogDetails.dtlsList.dtls.size());
      // END, CR00414040
      informationalManager.addInformationalMsg(infoMessage,
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning);
    }
    infos = informationalManager.obtainInformationalAsString();
    for (String message : infos) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      searchContactLogDetails1.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }

    return searchContactLogDetails1;
    // END,CR00407986
  }

  // END, CR00282028

  // BEGIN, CR00292632, SG
  /**
   * {@inheritDoc}
   */
  @Override
  public CaseNomineeAndCountDetails listCaseNominees(
    FinancialInstructionAndCaseID key)
    throws AppException, InformationalException {

    final CaseNomineeAndCountDetails caseNomineeAndCountDetails = new CaseNomineeAndCountDetails();

    final ILICaseIDFinInstID iliCaseIDFinInstID = new ILICaseIDFinInstID();

    iliCaseIDFinInstID.caseID = key.caseID;
    iliCaseIDFinInstID.finInstructionID = key.financialInstructionID;

    InstructionLineItemDtlsList instructionLineItemDtlsList = InstructionLineItemFactory.newInstance().searchByCaseIDFinInstructionID(
      iliCaseIDFinInstID);

    boolean isThirdPartyPaymentInd = false;
    long caseID = 0;
    long originalCaseNomineeID = 0;

    if (0 <= instructionLineItemDtlsList.dtls.size()) {

      // If the financial instruction is linked to a third party payment, the
      // Case ID will not be specified. Get the Case ID and Case Nominee ID
      // from the financial component.
      // BEGIN, CR00321600, AC
      if (0 == instructionLineItemDtlsList.dtls.size()) {
        final FinancialComponentKey financialComponentKey = new FinancialComponentKey();
        final ILIFinInstructID finInstructionID = new ILIFinInstructID();

        finInstructionID.finInstructionID = key.financialInstructionID;
        // BEGIN, CR00359570, GA
        // Net zero amount third party payments will not have financial component associated with it. 
        // Hence, return an empty list of case nominees as the concept of case nominee is not applicable for third parties.
        final FinInstructionID financialInstructionID = new FinInstructionID();
        final NotFoundIndicator nfIndicator = new NotFoundIndicator();

        financialInstructionID.finInstructionID = key.financialInstructionID;
        final PaymentInstructionDtls paymentInstructionDtls = PaymentInstructionFactory.newInstance().readByFinInstructionID(
          nfIndicator, financialInstructionID);

        if (paymentInstructionDtls.amount.isZero()) {
          return caseNomineeAndCountDetails;
        }
        // END, CR00359570
        instructionLineItemDtlsList = InstructionLineItemFactory.newInstance().searchByFinInstructID(
          finInstructionID);
   
        financialComponentKey.financialCompID = instructionLineItemDtlsList.dtls.item(0).financialCompID;
        isThirdPartyPaymentInd = true;
        FinancialComponentDtls finCompDtls = FinancialComponentFactory.newInstance().read(
          financialComponentKey);

        // END, CR00321600
        caseID = finCompDtls.caseID;
        originalCaseNomineeID = finCompDtls.caseNomineeID;
      } else {
        caseID = instructionLineItemDtlsList.dtls.item(0).caseID;
        originalCaseNomineeID = instructionLineItemDtlsList.dtls.item(0).caseNomineeID;
      }

      final curam.core.sl.intf.CaseNominee caseNomineeObj = curam.core.sl.fact.CaseNomineeFactory.newInstance();

      final curam.core.sl.struct.CaseNomineeCaseIDKey caseNomineeCaseIDKey = new curam.core.sl.struct.CaseNomineeCaseIDKey();

      caseNomineeCaseIDKey.caseNomineeCaseIDKey.caseID = caseID;
      final CaseNomineeDetailsList caseNomineeDetailsList = caseNomineeObj.listCaseNominee(
        caseNomineeCaseIDKey);

      final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

      caseContextDescriptionKey.caseID = caseID;
      caseNomineeAndCountDetails.caseContextDescription = readCaseContextDescription(
        caseContextDescriptionKey);

      final MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory.newInstance();
      final ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();

      readEffectiveByDateKey.caseNomineeID = originalCaseNomineeID;
      readEffectiveByDateKey.effectiveDate = instructionLineItemDtlsList.dtls.item(0).coverPeriodFrom;
      readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
      CaseNomineeDeliveryPatternDetails caseNomineeDeliveryPatternDetails = caseNomineeObj.readNearestDeliveryPattern(
        readEffectiveByDateKey);

      String paymentFrequency = caseNomineeDeliveryPatternDetails.deliveryFrequency;

      readEffectiveByDateKey.effectiveDate = Date.getCurrentDate();

      for (CaseNomineeDetails caseNomineeDetails: caseNomineeDetailsList.caseNomineeDetailsList.items()) {
        readEffectiveByDateKey.caseNomineeID = caseNomineeDetails.caseNomineeID;
        caseNomineeDeliveryPatternDetails = caseNomineeObj.readNearestDeliveryPattern(
          readEffectiveByDateKey);
        boolean sameDeliveryFrequency = caseNomineeDeliveryPatternDetails.deliveryFrequency.equalsIgnoreCase(
          paymentFrequency);

        // Do not display the nominee who has received the payment OR any
        // nominee who has a delivery pattern with a different delivery
        // frequency to the payment OR any nominee who is inactive.
        if (CASENOMINEESTATUS.EXPIRED.equals(caseNomineeDetails.nomineeStatus)
          || caseNomineeDetails.caseNomineeID == originalCaseNomineeID
          || !sameDeliveryFrequency) {
          caseNomineeDetailsList.caseNomineeDetailsList.remove(
            caseNomineeDetails);
          continue;
        }

        final ConcernRolesDetails concernRolesDetails = new ConcernRolesDetails();

        concernRolesDetails.assign(caseNomineeDetails);
        caseNomineeDetails.concernRoleName = maintainConcernRoleDetailsObj.appendAgeToName(concernRolesDetails).concernRoleName;
        caseNomineeDetails.concernRoleName += CuramConst.gkSpace
          + CuramConst.gkDash + CuramConst.gkSpace
          + caseNomineeDeliveryPatternDetails.deliveryPatternName;
        
        // BEGIN, CR00314367, SG
        caseNomineeDetails.caseNomineeConcernRoleIDOpt = caseNomineeDetails.caseNomineeID
          + CuramConst.gkComma + caseNomineeDetails.concernRoleID;
        // END, CR00314367
      }

      caseNomineeAndCountDetails.caseNomineeDetailsList = caseNomineeDetailsList;
      if (0 < caseNomineeDetailsList.caseNomineeDetailsList.size()
        || isThirdPartyPaymentInd) {
        caseNomineeAndCountDetails.defaultNomineeOnlyInd = false;
      } else {
        caseNomineeAndCountDetails.defaultNomineeOnlyInd = true;
      }
    }
   
    return caseNomineeAndCountDetails;
    
  }

  // END, CR00292632
  // BEGIN, CR00321600, AC
  @Override
  public CaseIDDetails getCaseIDByConcernRoleID(final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;
    final CaseIDDetails caseIDDetails = new CaseIDDetails();
    final CaseKey caseKey = new CaseKey();
    CaseIDStructList caseIDStructList = caseHeaderObj.searchCaseIDByConcernRoleID(
      concernRoleKey);

    for (CaseIDStruct caseIDStruct:caseIDStructList.dtls.items()) {
      caseKey.caseID = caseIDStruct.caseID;
      caseIDDetails.caseID = caseIDStruct.caseID;
    }

    return caseIDDetails;
  }

  // END, CR00321600
  // BEGIN, CR00342633, AC
  /**
   * Preview Contact Log Details for case.
   *
   * @param previewCaseContactLogIDKey
   * contains contact log preview key.
   *
   * @return preview caseContact Log details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public PreviewCaseContactLogXMLDetails previewCaseContactLogDetails(
    PreviewCaseContactLogIDKey previewCaseContactLogIDkey) throws AppException,
      InformationalException {
    final PreviewCaseContactLogXMLDetails previewCaseContactLogDetails = new PreviewCaseContactLogXMLDetails();

    // BEGIN, CR00348506, AC
    if (previewCaseContactLogIDkey.actionControlID.equals(
      ACTIONCONTROLID.PREVIEW)
        || previewCaseContactLogIDkey.actionControlID.length() == 0) {
      // END, CR0348506
      final curam.core.sl.struct.PreviewCaseContactLogKey previewContactLogKey = new 
        curam.core.sl.struct.PreviewCaseContactLogKey();
    
      previewContactLogKey.linkType = CONTACTLOGLINKTYPEEntry.CASE.getCode();
      
      previewContactLogKey.multiSelectStr = previewCaseContactLogIDkey.dtls.multiSelectStr;

      previewCaseContactLogDetails.dtls = ContactLogFactory.newInstance().previewContactLogList(
        previewContactLogKey);

      final CaseContextDescriptionKey caseContextDescriptionKey = new
        CaseContextDescriptionKey();

      caseContextDescriptionKey.caseID = previewCaseContactLogIDkey.casekey.caseID;

      previewCaseContactLogDetails.description = readCaseContextDescription(
        caseContextDescriptionKey);
    }
    return previewCaseContactLogDetails;

  }

  // END, CR00342633
  
  // BEGIN, CR00407868, SG
  /**
   * Checks if the user has maintain rights on the case.
   *
   * @param key ID of the case that is being checked.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException
   * (GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS) if the user
   * does not have any privilege.
   * @throws AppException
   * (GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS) if the user has restricted 
   * privilege.
   * @throws AppException
   * (GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS) if the user has read
   * only privilege.
   */
  public void checkMaintainCaseSecurity(final CaseSecurityCheckKey key)
    throws AppException, InformationalException {
    
    if (0 != key.caseID) {
    
      final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
      
      key.type = DataBasedSecurity.kMaintainSecurityCheck;
  
      final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
        key);
  
      if (!dataBasedSecurityResult.result) {
        if (dataBasedSecurityResult.readOnly) {
          ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS), 
            ValidationManagerConst.kSetOne, 0);
        } else if (dataBasedSecurityResult.restricted) {
          ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS), 
            ValidationManagerConst.kSetOne, 0);
        } else {
          ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS), 
            ValidationManagerConst.kSetOne, 0);
        }
      }
      
    }

  }

  // END, CR00407868

  // BEGIN, CR00407986, AC
  /**
   * Method to list Contact Log details for a case.
   *
   *
   * @param key
   * Contains case id
   *
   * @return The Contact Log details List
   */
  public CaseContactLogList listCaseContactLogs(final CaseKey key)
    throws AppException, InformationalException {
    final CaseContactLogList listCaseContactLogDetails = new CaseContactLogList();

    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;

    DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    final ContactLog contactLogObj = ContactLogFactory.newInstance();

    final ContactLogLinkIDLinkTypeKey contactLogLinkIDLinkTypeKey = new ContactLogLinkIDLinkTypeKey();

    contactLogLinkIDLinkTypeKey.linkID = key.caseID;
    contactLogLinkIDLinkTypeKey.linkType = CONTACTLOGLINKTYPE.CASE;
    final int kMaxNoCases;
    final String envMaxNoCases = Configuration.getProperty(
      EnvVars.ENV_CASES_MAXNOCONTACTLOGS);

    if (null == envMaxNoCases) {

      kMaxNoCases = EnvVars.ENV_CASES_MAXNOCONTACTLOGS_DEFAULT;
    } else {
      kMaxNoCases = Integer.parseInt(envMaxNoCases);
    }
    listCaseContactLogDetails.dtlsList = contactLogObj.list1(
      contactLogLinkIDLinkTypeKey);
    final CaseContactLogList listCaseContactLogDetails1 = new CaseContactLogList();
  
    ReadContactLogDetails readContactLogDetails = new ReadContactLogDetails();

    // Format the purpose field for display
    for (int i = 0; i < listCaseContactLogDetails.dtlsList.dtls.size()
      && i < kMaxNoCases; i++) {

      readContactLogDetails.contactLogDetails.assign(
        listCaseContactLogDetails.dtlsList.dtls.item(i));

      readContactLogDetails = contactLogObj.formatContactLogPurpose(
        readContactLogDetails);
      listCaseContactLogDetails.dtlsList.dtls.item(i).purpose = readContactLogDetails.contactLogDetails.purpose;
     
      listCaseContactLogDetails1.dtlsList.dtls.addRef(
        listCaseContactLogDetails.dtlsList.dtls.item(i));
    }
    final CaseContextDescriptionKey caseContextDescriptionKey = new CaseContextDescriptionKey();

    caseContextDescriptionKey.caseID = key.caseID;
    listCaseContactLogDetails1.caseContext = readCaseContextDescription(
      caseContextDescriptionKey);
    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (listCaseContactLogDetails.dtlsList.dtls.size() > kMaxNoCases) {
      final LocalisableString infoMessage = new LocalisableString(
        ENTCONTACTLOG.INF_ALL_CONTACTLOG_CANNOT_BE_DISPLAYED);

      infoMessage.arg(kMaxNoCases);
      infoMessage.arg(listCaseContactLogDetails.dtlsList.dtls.size());
      informationalManager.addInformationalMsg(infoMessage,
        GeneralConstants.kEmpty,
        InformationalElement.InformationalType.kWarning);
    }
    final String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      listCaseContactLogDetails1.dtls.dtls.addRef(informationalMsgDtls);
    }
    return listCaseContactLogDetails1;
  }

  // END, CR00407986
  
  // BEGIN, CR00409511, SG
  /**
   * Stores user case search criteria values.
   *
   * @param caseSearchCriteria Search criteria options to be stored.
   *
   * @return informational messages to be displayed to the user.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public InformationMsgDtlsList storeCaseSearchCriteria1(
    final CaseSearchCriteria1 caseSearchCriteria)
    throws AppException, InformationalException {

    CaseSearchFactory.newInstance().storeCaseSearchCriteria(caseSearchCriteria);
    
    final InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    InformationalMsgDtls informationalMsgDtls = null;
    
    for (String warning: informationalManager.obtainInformationalAsString()) {

      informationalMsgDtls = new InformationalMsgDtls();
      informationalMsgDtls.informationMsgTxt = warning;
      informationMsgDtlsList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
      
    }
    
    return informationMsgDtlsList;
    
  }

  // END, CR00409511  

  // ___________________________________________________________________________
  /**
   * Determines if a case is delivering a Curam Rules product or a
   * CREOLE-aware product.
   *
   * @param approvalKey
   * Case Approval entity key
   *
   * @param key
   * Case Header entity key.
   * @return whether the product being delivered is Curam Rules or
   * CREOLE-aware, together with a determinationID if the product type
   * is CREOLE-aware.
   */
  public CERDecisionDetails isCERDecision(
    curam.core.facade.struct.CaseDecisionKey key) throws AppException,
      InformationalException {

    // Read Decision Record
    curam.core.struct.CaseDecisionKey caseDecisionKey = new curam.core.struct.CaseDecisionKey();
    curam.core.intf.CaseDecision caseDecisionObj = curam.core.fact.CaseDecisionFactory.newInstance();

    caseDecisionKey.caseDecisionID = key.caseDecisionID;
    CaseDecisionDtls caseDecisionDtls = caseDecisionObj.read(caseDecisionKey);

    // Return details
    CERDecisionDetails cerDecisionDetails = new CERDecisionDetails();

    cerDecisionDetails.caseDecisionID = key.caseDecisionID;
    cerDecisionDetails.decisionFromDate = caseDecisionDtls.decisionFromDate;
    if (isCreoleProduct(caseDecisionDtls.caseID)) {

      CREOLECaseDecisionKey creoleCaseDecisionKey = new CREOLECaseDecisionKey();

      creoleCaseDecisionKey.caseDecisionID = key.caseDecisionID;
      cerDecisionDetails.determinationID = CREOLECaseDecisionFactory.newInstance().read(creoleCaseDecisionKey).creoleCaseDeterminationID;
      cerDecisionDetails.result = CuramConst.kYES;
    } else {
      cerDecisionDetails.result = CuramConst.kNO;
    }

    return cerDecisionDetails;
  }

  /**
   * Helper method to check if a case is using creole or classic rules.
   *
   * @param caseID
   * Case identifier.
   * @return Indicator if case is using creole rules.
   * @throws AppException
   * @throws InformationalException
   */
  private boolean isCreoleProduct(long caseID) throws AppException,
      InformationalException {

    boolean result = false;

    // Read the case type if it is an Investigation the case is not
    // CREOLE-aware
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseKey caseKey = new CaseKey();

    caseKey.caseID = caseID;
    if (caseHeaderObj.readCaseTypeCode(caseKey).caseTypeCode.equals(
      CASETYPECODE.INVESTIGATIONCASE)) {
      return result;
    }

    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    productDeliveryKey.caseID = caseID;

    final ProductIDDetails details = ProductDeliveryFactory.newInstance().readProductID(
      productDeliveryKey);

    final CREOLEProductKey creoleProductKey = new CREOLEProductKey();

    creoleProductKey.productID = details.productID;

    final NotFoundIndicator nfIndicator = new NotFoundIndicator();

    CREOLEProductFactory.newInstance().read(nfIndicator, creoleProductKey);

    if (!nfIndicator.isNotFound()) {
      result = true;
    }

    return result;
  }

}
