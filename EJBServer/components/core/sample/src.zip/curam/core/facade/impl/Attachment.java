/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import com.google.inject.Inject;

import curam.attachmentlink.impl.AttachmentLink;
import curam.attachmentlink.impl.AttachmentLinkDAO;
import curam.attachmentlink.struct.AttachmentLinkDetails;
import curam.attachmentlink.struct.AttachmentLinkKey;
import curam.attachmentlink.struct.CancelAttachmentKey;
import curam.core.struct.AttachmentKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This process class provides the functionality for the Attachment facade layer.
 */
public abstract class Attachment extends curam.core.facade.base.Attachment {

  // Add injection for using the new API
  public Attachment() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected AttachmentLinkDAO attachmentLinkDAO;
  
  // BEGIN, CR00146458, VR
  @Inject 
  protected curam.attachment.impl.Attachment attachment;
  
  // END, CR00146458

  // ___________________________________________________________________________
  /**
   * Method to set an Attachment status to Cancelled
   *
   * @param key Contains attachment link id and attachment version no
   */
  public void cancelAttachment(CancelAttachmentKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00375285, BL
    // Get a reference to the link for this attachment and pass the attachment
    // link version number into the attachmentLink cancel method  
    AttachmentLink attachmentLinkObj = attachmentLinkDAO.get(
      key.attachmentLinkKey);

    attachmentLinkObj.cancel(attachmentLinkObj.getVersionNo());
    // END, CR00375285, BL

  }

  // ___________________________________________________________________________
  /**
   * Method to update attachment details.
   *
   * @param details Contains attachment link details
   */
  public void modifyAttachment(AttachmentLinkDetails details)
    throws AppException, InformationalException {

    attachmentLinkDAO.get(details.attachmentLinkDtls.attachmentLinkID).modify(
      details);

  }

  // ___________________________________________________________________________
  /**
   * Method to read attachment content.
   *
   * @param key Contains attachment link id
   *
   * @return The attachment file name and document data
   */
  public AttachmentLinkDetails readAttachment(AttachmentLinkKey key)
    throws AppException, InformationalException {

    AttachmentLink attachmentLink = attachmentLinkDAO.get(key.attachmentLinkID);

    AttachmentLinkDetails attachmentLinkDetails = new AttachmentLinkDetails();
   
    AttachmentKey attachmentKey = new AttachmentKey();

    attachmentLinkDetails.attachmentLinkDtls.attachmentLinkID = attachmentLink.getID();
    attachmentLinkDetails.attachmentLinkDtls.attachmentID = attachmentLink.getAttachmentID();
    attachmentLinkDetails.attachmentLinkDtls.description = attachmentLink.getDescription();
    attachmentLinkDetails.attachmentLinkDtls.sensitivityCode = attachmentLink.getSensitivityCode().getCode();
    attachmentLinkDetails.attachmentLinkDtls.recordStatus = attachmentLink.getLifecycleState().getCode();
    attachmentLinkDetails.attachmentLinkDtls.relatedObjectID = attachmentLink.getRelatedObjectID();
    attachmentLinkDetails.attachmentLinkDtls.relatedObjectType = attachmentLink.getRelatedObjectType().getCode();
    attachmentLinkDetails.attachmentLinkDtls.participantRoleID = attachmentLink.getParticipantRoleID();
    attachmentLinkDetails.attachmentLinkDtls.versionNo = attachmentLink.getVersionNo();
    attachmentLinkDetails.attachmentLinkDtls.creatorUserName = attachmentLink.getCreator();

    attachmentLink.checkSensitivity();

    attachmentKey.attachmentID = attachmentLinkDetails.attachmentLinkDtls.attachmentID;
    // BEGIN, CR00146458, VR
    attachmentLinkDetails.attachmentDtls = attachment.read(attachmentKey);
    // END, CR00146458

    return attachmentLinkDetails;
  }
}
