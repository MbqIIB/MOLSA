/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright (c) 2005-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.facade.impl;


import curam.cefwidgets.docbuilder.impl.ContentPanelBuilder;
import curam.cefwidgets.docbuilder.impl.ImageBuilder;
import curam.cefwidgets.docbuilder.impl.LinkBuilder;
import curam.cefwidgets.docbuilder.impl.ListBuilder;
import curam.cefwidgets.docbuilder.impl.helper.impl.DocBuilderHelperFactory;
import curam.cefwidgets.docbuilder.impl.helper.impl.EntryOptions;
import curam.cefwidgets.utilities.impl.RendererConfig;
import curam.cefwidgets.utilities.impl.RendererConfig.RendererConfigType;
import curam.codetable.TASKPRIORITY;
import curam.codetable.TASKSTATUS;
import curam.core.facade.pdt.struct.WorkflowGraphDetails;
import curam.core.facade.struct.AddTaskCommentDetails;
import curam.core.facade.struct.DeferTaskDetails;
import curam.core.facade.struct.ListHistoryForTaskDetails;
import curam.core.facade.struct.ModifyTimeWorkedDetails;
import curam.core.facade.struct.MultipleTaskDetails;
import curam.core.facade.struct.ReallocateTaskDetails;
import curam.core.facade.struct.ReserveTaskDetails;
import curam.core.facade.struct.RestartTaskDetails;
import curam.core.facade.struct.TaskAssignmentDetails;
import curam.core.facade.struct.TaskAssignmentDetails1;
import curam.core.facade.struct.TaskContextPanelDetails;
import curam.core.facade.struct.TaskCreateDetails;
import curam.core.facade.struct.TaskDeadlineDetails;
import curam.core.facade.struct.TaskForwardDetails;
import curam.core.facade.struct.TaskHistoryTextDetails;
import curam.core.facade.struct.TaskManagementContextDescription;
import curam.core.facade.struct.TaskManagementTaskKey;
import curam.core.facade.struct.TaskPriorityDetails;
import curam.core.facade.struct.TaskTimeWorkedDetails;
import curam.core.facade.struct.UnreserveTaskDetails;
import curam.core.facade.struct.ViewTaskDetails;
import curam.core.impl.CuramConst;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.sl.fact.TaskHistoryTextGeneratorFactory;
import curam.core.sl.fact.TaskManagementFactory;
import curam.core.sl.impl.TaskHistoryText;
import curam.core.sl.impl.TaskManagementUtility;
import curam.core.sl.intf.TaskHistoryTextGenerator;
import curam.core.sl.struct.HistoryForTaskDetails;
import curam.core.sl.struct.ReserveTaskDetailsList;
import curam.core.sl.struct.TaskAssigneeDetailsList;
import curam.core.sl.struct.TaskHistoryInformationDetails;
import curam.core.sl.struct.TaskHistoryInformationDetailsList;
import curam.core.sl.struct.TaskHistoryKey;
import curam.core.sl.struct.TaskVersionNoDetails;
import curam.message.BPOTASKMANAGEMENT;
import curam.message.SEPARATOR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.DateTime;
import curam.util.type.StringList;


/**
 * This process class provides the functionality for the Task Management
 * facade methods.
 */
public abstract class TaskManagement extends curam.core.facade.base.TaskManagement {

  // BEGIN HARP 46914, JR
  // BEGIN, CR00023323, SK
  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by
   * {@link SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.getProgramLocale())}.
   * Constant for the separator used in the context description.
   * Replacement reason - static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note <CR00219408>.
   */
  @Deprecated
  protected static final String kSeparator = // BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();
  // END, CR00163471, JC
  // END, CR00222190
  // END, CR00023323
  // END HARP 46914
  /**
   * Method allows to add a comment to a task. The user adding the comment does
   * not need to have the task reserved. This will allow users to comment on
   * tasks reserved by other users.
   *
   * @param addTaskCommentDetails task comment details to be added
   */
  public void addComment(AddTaskCommentDetails addTaskCommentDetails)
    throws AppException, InformationalException {

    // Task Management BPO
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Add the comment
    taskManagementObj.addComment(addTaskCommentDetails.taskCommentDetails);
  }

  // ___________________________________________________________________________
  /**
   * Method to close existing task.
   *
   * @param taskKey task key to be closed
   */
  public void close(TaskManagementTaskKey taskKey) throws AppException,
      InformationalException {

    // Task Management BPO
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Add the comment
    taskManagementObj.close(taskKey.taskKey);

  }

  // ___________________________________________________________________________
  /**
   * Method to create a new task.
   *
   * @param taskCreateDetails details of the task to be created
   */
  public void create(TaskCreateDetails taskCreateDetails)
    throws AppException, InformationalException {

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Create the task
    taskManagementObj.create(taskCreateDetails.taskDetails);

  }

  // ___________________________________________________________________________
  /**
   * Method to defer a reserved task. Deferring a task effectively parks the
   * task until a later date.
   *
   * @param deferTaskDetails details of the task to be deferred
   */
  public void defer(DeferTaskDetails deferTaskDetails)
    throws AppException, InformationalException {

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Defer the task
    taskManagementObj.defer(deferTaskDetails.deferTaskDetails);
  }

  // ___________________________________________________________________________
  /**
   * Method allows to forward a task to a job, position, organization unit,
   * user, work queue or allocation target. This un-reserves the task therefore
   * making the task available to any user to whom the task is now assigned.
   *
   * @param forwardTaskDetails details of the task to be forwarded
   */
  public void forward(TaskForwardDetails forwardTaskDetails)
    throws AppException, InformationalException {

    // BEGIN HARP 45296
    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Forward the task
    taskManagementObj.forward(forwardTaskDetails.forwardTaskDetails);

    // END HARP 45296

  }

  // ___________________________________________________________________________
  /**
   * Method to modify the total time worked on a particular task.
   *
   * @param modifyTimeWorkedDetails time worked of the task details
   */
  public void modifyTimeWorked(ModifyTimeWorkedDetails modifyTimeWorkedDetails)
    throws AppException, InformationalException {

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Modify total time worked on the task
    taskManagementObj.modifyTimeWorked(
      modifyTimeWorkedDetails.timeWorkedDetails);
  }
  
  // ___________________________________________________________________________
  /**
   * Modifies the priority of the specified task.
   *
   * @param modifyPriorityDetails The task priority details to be updated.
   */
  public void modifyPriority(TaskPriorityDetails taskPriorityDetails)
    throws AppException, InformationalException {

    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Modify the priority details of a task.
    taskManagementObj.modifyPriority(taskPriorityDetails.priorityDetails);
  }
  
  // ___________________________________________________________________________
  /**
   * Modifies the deadline of the specified task.
   *
   * @param modifyPriorityDetails The task priority details to be updated.
   */
  public void modifyDeadline(TaskDeadlineDetails taskDeadlineDetails)
    throws AppException, InformationalException {

    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Modify total time worked on the task
    taskManagementObj.modifyDeadline(taskDeadlineDetails.deadlineDetails);
  }
  
  // ___________________________________________________________________________
  /**
   * Method allows to reallocate a task. Reallocation of a task invokes the
   * tasks initial allocation strategy. This results in the task being
   * reassigned to the item (group of users or work queue) to which it was
   * originally assigned.
   *
   * @param reallocateTaskDetails details of the task to be reallocated
   */
  public void reallocate(ReallocateTaskDetails reallocateTaskDetails)
    throws AppException, InformationalException {

    // BEGIN HARP 45296. CC
    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Reallocate the task
    taskManagementObj.reallocate(reallocateTaskDetails.reallocateTaskDetails);

    // END HARP 45296

  }

  // ___________________________________________________________________________
  /**
   * Method allows to reserve a task. A reserved task may only be actioned by
   * the user who has reserved the task. For example, a user can reserve a task
   * assigned to a work queue to which they are currently subscribed. Once the
   * work queue task is reserved by the user, it will be removed from the work
   * queue so that other subscribers to the work queue will not be able to
   * reserve the task.
   *
   * @param reserveTaskDetails details of the task to be reserved
   */
  public void reserve(ReserveTaskDetails reserveTaskDetails)
    throws AppException, InformationalException {

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Reserve the task
    taskManagementObj.reserve(reserveTaskDetails.reserveTaskDetails);

  }

  // ___________________________________________________________________________
  /**
   * Method to restart a task manually.
   *
   * @param restartTaskDetails details of the task to be restarted
   */
  public void restart(RestartTaskDetails restartTaskDetails)
    throws AppException, InformationalException {

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Restart the task
    taskManagementObj.restart(restartTaskDetails.restartTaskDetails);

  }

  // ___________________________________________________________________________
  /**
   * Method allows to un-reserve a task. A task can be un-reserved if the task
   * is currently reserved by the current user. Once a task is un-reserved it
   * is once again available to the user, organization unit, position, job,
   * allocation target or work queue to which it was previously assigned. The
   * task is available again for reservation.
   *
   * @param unreserveTaskDetails details of the task to be unreserved
   */
  public void unreserve(UnreserveTaskDetails unreserveTaskDetails)
    throws AppException, InformationalException {

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Un-reserve the task
    taskManagementObj.unreserve(unreserveTaskDetails.unreserveTaskDetails);
  }
  
  // ___________________________________________________________________________
  /**
   * This method reserves multiple tasks.
   *
   * @param taskList A tabbed delimited string of task ID and version number
   * pairs. The task ID is separated from the version number by the pipe
   * character, while each task ID and version number pair is separated by a
   * tab character e.g. TaskID|VersionNo    TaskID|VersionNo    TaskID|VersionNo
   *
   * If an exception occurs while reserving a task, the method continues
   * reserving the next task. When complete an informational is returned
   * detailing any exceptions that occurred.
   */
  public void reserveMultipleTasks(MultipleTaskDetails taskList)
    throws AppException, InformationalException {
    StringList taskIDAndVersionNoList = StringUtil.tabText2StringListWithTrim(
      taskList.taskDetails);

    ReserveTaskDetailsList reserveTaskDetailsList = new ReserveTaskDetailsList();

    for (int i = 0; i < taskIDAndVersionNoList.size(); i++) {
      StringList taskIDAndVersionNo = StringUtil.delimitedText2StringListWithTrim(
        taskIDAndVersionNoList.item(i), CuramConst.gkPipeDelimiterChar);

      curam.core.sl.struct.ReserveTaskDetails taskDetails = new curam.core.sl.struct.ReserveTaskDetails();

      taskDetails.taskID = new Long(taskIDAndVersionNo.item(0)).longValue();
      taskDetails.comments = CuramConst.gkEmpty;
      taskDetails.versionNo = new Integer(taskIDAndVersionNo.item(1)).intValue();
      reserveTaskDetailsList.dtls.addRef(taskDetails);
    }

    TaskManagementFactory.newInstance().reserveMultipleTasks(
      reserveTaskDetailsList);
  }

  // END, CR00203667  
  
  // ___________________________________________________________________________  
  // BEGIN, CR00021458, SP
  /**
   * Method returns the time worked on a particular task.
   *
   * @param taskKey The unique identifier of the task
   *
   * @return Task time worked details
   */
  public TaskTimeWorkedDetails readTimeWorked(TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    // BEGIN HARP 64356
    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Create return object
    TaskTimeWorkedDetails taskTimeWorkedDetails = new TaskTimeWorkedDetails();

    // Register the security implementation
    SecurityImplementationFactory.register();

    // Read the total time worked on the task
    taskTimeWorkedDetails.taskTimeWorkedDetails = taskManagementObj.readTimeWorked(
      taskKey.taskKey);

    return taskTimeWorkedDetails;
    // END HARP 64356
  }  

  // ___________________________________________________________________________
  /**
   * Returns the priority details of a task.
   *
   * @param taskKey The identifier of a task whose priority details will be
   * returned.
   *
   * @return The priority details of a task.
   */
  public TaskPriorityDetails readPriorityDetails(TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    final curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();
    TaskPriorityDetails taskPriorityDetails = new TaskPriorityDetails();

    // Read the priority details of a task.
    taskPriorityDetails.priorityDetails = taskManagementObj.readPriorityDetails(
      taskKey.taskKey);
    return taskPriorityDetails;
  }
  
  // ___________________________________________________________________________
  /**
   * Returns the deadline details of a task.
   *
   * @param taskKey The identifier of a task whose deadline details will be
   * returned.
   *
   * @return The deadline details of the task.
   */
  public TaskDeadlineDetails readDeadlineDetails(TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    final curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();
    TaskDeadlineDetails taskDeadlineDetails = new TaskDeadlineDetails();

    // Modify total time worked on the task
    taskDeadlineDetails.deadlineDetails = taskManagementObj.readDeadlineDetails(
      taskKey.taskKey);
    return taskDeadlineDetails;
  }
  
  // ___________________________________________________________________________  
  /**
   * This method returns the Version Number for a task.
   *
   * @param taskKey A key struct containing the task ID.
   *
   * This is used for certain actions to be performed on a task
   * where the the version No is required.
   */
  public TaskVersionNoDetails readTaskVersionNo(
    curam.core.sl.struct.TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    // Task Management Object
    curam.core.sl.intf.TaskManagement taskMgtObj = TaskManagementFactory.newInstance();

    return taskMgtObj.readTaskVersionNo(taskKey);
  }  
  
  // ___________________________________________________________________________
  /**
   * Format XML data for a product delivery case tab details.
   *
   * @param details
   * Product Delivery case details.
   * @param paymentDetails
   * Product Delivery case last and next payment details.
   *
   * @return ContentPanelBuilder.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public TaskContextPanelDetails getTaskContextPanelDetails(
    TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Create return object
    curam.core.sl.struct.ViewTaskDetails taskDetails = new curam.core.sl.struct.ViewTaskDetails();

    // Get task details
    taskDetails = taskManagementObj.viewTaskHome(taskKey.taskKey);

    ContentPanelBuilder containerPanel = ContentPanelBuilder.createPanel(
      CuramConst.gkTaskContainerPanel);
    
    // Create a content panel using the content panel builder to build the xml
    // required. The id for this content panel is task-details. This should
    // be unique id.
    ContentPanelBuilder contentPanelBuilder = ContentPanelBuilder.createPanel(
      CuramConst.gkTaskContextPanelDetails);

    contentPanelBuilder.addRoundedCorners();

    contentPanelBuilder.addlocalisableStringItem(
      new LocalisableString(BPOTASKMANAGEMENT.INF_TASK_NUMBER_LABEL).arg(taskDetails.taskID).toClientFormattedText(), 
      CuramConst.gkTaskContextHeader);
    
    EntryOptions cellLabel = DocBuilderHelperFactory.getEntryOptions(
      CuramConst.gkTaskContextTableCellLabel);
    EntryOptions cellValue = DocBuilderHelperFactory.getEntryOptions(
      CuramConst.gkTaskContextTableCellValue);
    
    // Add a list item with 6 columns
    ListBuilder taskDetailsList = ListBuilder.createHorizontalList(6);

    taskDetailsList.addRow();

    taskDetailsList.addEntry(1, 1, 
      new LocalisableString(BPOTASKMANAGEMENT.INF_STATUS_LABEL), cellLabel);
    taskDetailsList.addEntry(2, 1, 
      CodeTable.getOneItem(TASKSTATUS.TABLENAME, taskDetails.status, 
      TransactionInfo.getProgramLocale()),
      cellValue);

    taskDetailsList.addEntry(3, 1, 
      new LocalisableString(BPOTASKMANAGEMENT.INF_WORKED_ON_BY_LABEL), 
      cellLabel);
    
    LinkBuilder linkBuilder = LinkBuilder.createLink(
      taskDetails.reservedByFullName, CuramConst.gkUserDetailsPage);

    linkBuilder.addParameter(CuramConst.gkPageParameterUserName,
      taskDetails.reservedBy);
    linkBuilder.openAsModal();
    RendererConfig linkRendererConfig = new RendererConfig(
      RendererConfigType.STYLE, CuramConst.gkLink);
    
    EntryOptions linkValue = DocBuilderHelperFactory.getEntryOptions(
      CuramConst.gkTaskContextTableLink);    

    taskDetailsList.addEntry(4, 1, linkBuilder, linkRendererConfig, linkValue);

    taskDetailsList.addEntry(5, 1, 
      new LocalisableString(BPOTASKMANAGEMENT.INF_DEADLINE_LABEL), cellLabel);
    taskDetailsList.addEntry(6, 1, taskDetails.dueDateTime, cellValue);
    
    taskDetailsList.addRow();
    
    taskDetailsList.addEntry(1, 2, 
      new LocalisableString(BPOTASKMANAGEMENT.INF_PRIORITY_LABEL), cellLabel);
    taskDetailsList.addEntry(2, 2, 
      CodeTable.getOneItem(TASKPRIORITY.TABLENAME, taskDetails.priority, 
      TransactionInfo.getProgramLocale()),
      cellValue);
    
    taskDetailsList.addEntry(3, 2, 
      new LocalisableString(BPOTASKMANAGEMENT.INF_TIME_WORKED_LABEL), cellLabel);
    taskDetailsList.addEntry(4, 2, taskDetails.totalTimeWorked, cellValue);

    taskDetailsList.addEntry(5, 2, 
      new LocalisableString(BPOTASKMANAGEMENT.INF_LAST_ASSIGNED_LABEL), 
      cellLabel);
    taskDetailsList.addEntry(6, 2, taskDetails.assignedDateTime, cellValue);
    
    contentPanelBuilder.addSingleListItem(taskDetailsList,
      CuramConst.gkTaskContextPanelTable);
    
    ContentPanelBuilder subjectContent = ContentPanelBuilder.createPanel(
      CuramConst.gkTaskContextSubjectDetails);

    // if the deadline is not the zero date then create the over due icon if the 
    // task deadline is before now.
    String icon = CuramConst.gkScheduleIcon;

    if (!taskDetails.dueDateTime.equals(DateTime.kZeroDateTime) 
      && taskDetails.dueDateTime.before(DateTime.getCurrentDateTime())) {
      icon = CuramConst.gkTimeOverIcon;
    }

    ImageBuilder image = ImageBuilder.createImage(icon, CuramConst.gkEmpty);

    image.setImageResource(CuramConst.gkImageFile);

    subjectContent.addImageItem(image);
    
    subjectContent.addStringItem(taskDetails.subject,
      CuramConst.gkTaskContextSubjectLabel);
    
    contentPanelBuilder.addWidgetItem(subjectContent, CuramConst.gkStyle,
      CuramConst.gkContentPanel);
    
    containerPanel.addWidgetItem(contentPanelBuilder, CuramConst.gkStyle,
      CuramConst.gkContentPanel, CuramConst.gkTaskContentPanel);
    
    TaskContextPanelDetails contextPanelDetails = new TaskContextPanelDetails();

    contextPanelDetails.xmlPanelData = containerPanel.toString();
    return contextPanelDetails;
  }

  // ___________________________________________________________________________
  /**
   * Method to return context description for specified task.
   *
   * @param taskKey The unique identifier of the task
   *
   * @return Task context description details
   */
  public TaskManagementContextDescription readContextDescription(
    TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    // Create return object
    TaskManagementContextDescription taskManagementContextDescription = new TaskManagementContextDescription();

    // Workflow task key
    curam.util.workflow.struct.TaskKey readTaskKey = new curam.util.workflow.struct.TaskKey();

    // BEGIN HARP 46914, JR
    readTaskKey.taskID = taskKey.taskKey.taskID;

    StringBuffer contextDescription = new StringBuffer();

    contextDescription.append(

      curam.util.workflow.impl.LocalizableStringResolver.getTaskStringResolver().getActivityNameForTask(
        readTaskKey));
    // BEGIN, CR00098942, SAI
    contextDescription.append(CuramConst.gkSpace);
    // END, CR00098942
    // BEGIN, CR00222190, ELG
    contextDescription.append(
      SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
        TransactionInfo.getProgramLocale()));
    // END, CR00222190
    contextDescription.append(taskKey.taskKey.taskID);

    taskManagementContextDescription.contextDescription = contextDescription.toString();
    // END HARP 46914
    return taskManagementContextDescription;

  }
  
  // ___________________________________________________________________________
  /**
   * Retrieves the XML necessary to visualize a process instance associated
   * with a task.
   *
   * @param taskKey The unique identifier of the task.
   *
   * @return an XML representation of a graphical view of the process instance
   * associated with a task.
   */
  public WorkflowGraphDetails visualiseProcessInstanceForTask(
    TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    // Task Management BPO
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Create the return struct.
    final WorkflowGraphDetails workflowGraphDetails = new WorkflowGraphDetails();

    // Retrieve the process instance.
    long processInstanceID = taskManagementObj.readProcessInstanceForTask(taskKey.taskKey).processInstanceID;

    // Generate the graph data for this process instance.
    curam.util.workflow.struct.ProcessInstanceID processInstanceKey = new curam.util.workflow.struct.ProcessInstanceID();

    processInstanceKey.processInstanceID = processInstanceID;

    curam.util.workflow.struct.WorkflowGraphDetails workflowGraphDetailsInf = curam.util.workflow.impl.ProcessInstanceAdmin.getInstanceGraph(
      processInstanceKey);

    workflowGraphDetails.workflowGraphXML = workflowGraphDetailsInf.workflowGraphXML;
    workflowGraphDetails.name = workflowGraphDetailsInf.name;

    return workflowGraphDetails;
  }  
  
  // ___________________________________________________________________________
  /**
   * Method to display all of the events that have occurred during the task
   * life cycle.
   *
   * @param taskKey task key
   *
   * @return Task history details list
   */
  public ListHistoryForTaskDetails viewHistoryList(TaskManagementTaskKey
    taskKey)
    throws AppException, InformationalException {

    // Create the return object
    ListHistoryForTaskDetails listTaskHistoryDetails = new ListHistoryForTaskDetails();

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Get task history details
    listTaskHistoryDetails.taskHistoryDetailsList = taskManagementObj.viewHistoryList(
      taskKey.taskKey);

    // Return task history details
    return listTaskHistoryDetails;

  }

  // ___________________________________________________________________________
  /**
   * Method returns the details regarding a specific task.
   *
   * @param taskKey The unique identifier of the task
   *
   * @return Task details
   */
  public ViewTaskDetails viewTaskHome(TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Create return object
    ViewTaskDetails viewTaskDetails = new ViewTaskDetails();

    // Get task details
    viewTaskDetails.taskDetails = taskManagementObj.viewTaskHome(
      taskKey.taskKey);

    // Create the page title, and set as context description
    StringBuffer contextDescription = new StringBuffer();

    contextDescription.append(viewTaskDetails.taskDetails.taskID);
    // BEGIN, CR00098942, SAI
    contextDescription.append(CuramConst.gkSpace);
    // END, CR00098942
    // BEGIN, CR00222190, ELG
    contextDescription.append(
      SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
        TransactionInfo.getProgramLocale()));
    // END, CR00222190
    contextDescription.append(viewTaskDetails.taskDetails.subject);
    TaskManagementContextDescription taskManagementContextDescription = new TaskManagementContextDescription();

    taskManagementContextDescription.contextDescription = contextDescription.toString();
    viewTaskDetails.taskManagementContextDescription = taskManagementContextDescription;

    // Return task details
    return viewTaskDetails;
  }

  // ___________________________________________________________________________
  /**
   * Displays task history text for the specified task. The order of the
   * returned records is by most recent first.
   *
   * @param taskKey The unique identifier of the task
   *
   * @return Task history text details
   */
  public TaskHistoryTextDetails viewHistoryText(TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    // Create return object
    TaskHistoryTextDetails taskHistoryTextDetails = new TaskHistoryTextDetails();

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    // Get task history text
    taskHistoryTextDetails.taskHistoryDetailsList = taskManagementObj.viewHistoryTextOrderedByChangeDateTimeLatestFirst(
      taskKey.taskKey);

    // Use the task ID as context description
    TaskManagementContextDescription taskManagementContextDescription = new TaskManagementContextDescription();

    taskManagementContextDescription.contextDescription = new Long(taskKey.taskKey.taskID).toString();
    taskHistoryTextDetails.taskManagementContextDescription = taskManagementContextDescription;

    // Return task history text details
    return taskHistoryTextDetails;
  }
  
  // ___________________________________________________________________________
  /**
   * Retrieves the list of users and work queues currently assigned to a task.
   *
   * @param taskKey The unique identifier of the task.
   *
   * @return the list of users and work queues currently assigned to a task.
   */
  public TaskAssignmentDetails1 viewAssignmentList1(
    TaskManagementTaskKey taskKey) throws AppException,
      InformationalException {

    TaskAssignmentDetails1 taskAssignmentDetails1 = new TaskAssignmentDetails1();

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    taskAssignmentDetails1.taskAssignmentDetails = taskManagementObj.viewAssignmentList1(
      taskKey.taskKey);

    return taskAssignmentDetails1;
  }

  // END, CR00175973

  // BEGIN, CR00202966, AMD
  // ___________________________________________________________________________
  /**
   * Retrieves the "Assigned To" and "Assignee Type" information for a task. The
   * information is returned in a single list which is ordered by Users,
   * Organization Units, Positions, Jobs and Work Queues.
   *
   * @param taskKey task key
   *
   * @return the list of assigned users and work queues for a task.
   */
  public TaskAssigneeDetailsList viewAssignmentsForTask(
    curam.core.sl.struct.TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    return taskManagementObj.viewAssignmentsForTask(taskKey);

  }

  // END, CR00202966

  /**
   * Method to display all of the events that have occurred during the task
   * life cycle.
   *
   * @param taskKey task key
   *
   * @return Task history details list
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link #viewHistoryForTaskList(curam.core.sl.struct.TaskManagementTaskKey)}. 
   * See release note CR00265629.
   */
  @Deprecated
  public curam.core.sl.struct.TaskHistoryAndCommentsDetailsList viewHistoryAndCommentsList(
    curam.core.sl.struct.TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    return taskManagementObj.viewHistoryAndCommentsList(taskKey);
  }

  /**
   * Method to display the converted history and comments
   * for the task.
   *
   * @param TaskHistoryKey is the task history key
   *
   * @return Task for history details
   *
   * @deprecated Since Curam 6.0 SP1, replaced by 
   * {@link #viewTaskHistoryDetails(TaskHistoryKey)}. See release note 
   * CR00265629.
   */
  @Deprecated
  public curam.core.sl.struct.TaskHistoryAndCommentsDetails viewHistoryForTaskDetails(
    final TaskHistoryKey key) throws AppException, InformationalException {

    // set up the result
    final curam.core.sl.struct.TaskHistoryAndCommentsDetails result = new curam.core.sl.struct.TaskHistoryAndCommentsDetails();
    final TaskHistoryTextGenerator historyTextGeneratorObj = TaskHistoryTextGeneratorFactory.newInstance();

    // get the converted comments and history text
    HistoryForTaskDetails details = historyTextGeneratorObj.convertToText(key);

    // assign values to the result
    result.changedDateTime = details.changedDateTime;
    result.comments = details.comments;
    result.newValue = TaskManagementUtility.processTaskHistoryNewValue(
      details.taskType, details.newValue);
    result.oldValue = TaskManagementUtility.processTaskHistoryOldValue(
      details.taskType, details.oldValue);
    result.taskChangeType = details.taskType;
    result.taskHistoryID = details.taskHistoryID;
    result.userName = details.userName;
    result.versionNo = details.versionNo;
    return result;
  }
  
  // BEGIN, CR00175973, PDN
  // ___________________________________________________________________________
  /**
   * Retrieves the list of users and work queues currently assigned to a task.
   *
   * @param taskKey The unique identifier of the task.
   *
   * @return the list of users and work queues currently assigned to a task.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link #viewAssignmentList1(TaskManagementTaskKey)}.
   */
  @Deprecated
  public TaskAssignmentDetails viewAssignmentList(TaskManagementTaskKey taskKey)
    throws AppException, InformationalException {

    TaskAssignmentDetails taskAssignmentDetails = new TaskAssignmentDetails();

    taskAssignmentDetails.assign(viewAssignmentList1(taskKey));

    return taskAssignmentDetails;
  }

  /**
   * Gets the task history information for a specified task history identifier.
   *
   * @param key The task history identifier.
   *
   * @return The task history details.
   */
  public TaskHistoryInformationDetails viewTaskHistoryDetails(TaskHistoryKey key)
    throws AppException, InformationalException {

    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    return taskManagementObj.viewTaskHistoryDetails(key);
  }

  /**
   * Gets the all task history events for a specified task identifier.
   *
   * @param taskKey The task identifier.
   *
   * @return A list of task history events for the specified task.
   */
  public TaskHistoryInformationDetailsList viewHistoryForTaskList(
    curam.core.sl.struct.TaskManagementTaskKey taskKey) throws AppException,
      InformationalException {

    // Task Management service layer object
    curam.core.sl.intf.TaskManagement taskManagementObj = curam.core.sl.fact.TaskManagementFactory.newInstance();

    return taskManagementObj.viewHistoryForTaskList(taskKey);
  }  
  
}
