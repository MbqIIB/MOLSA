/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26 
 *
 * Copyright IBM Corporation 2005, 2013-2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

package curam.core.facade.infrastructure.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import com.google.inject.Inject;

import curam.cefwidgets.docbuilder.impl.XMLBuilder;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASETYPECODE;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.EVIDENCECATEGORY;
import curam.codetable.EVIDENCECHANGEREASON;
import curam.codetable.EVIDENCEDESCRIPTORSTATUS;
import curam.codetable.impl.CASEEVIDENCEEntry;
import curam.codetable.impl.EVIDENCEDESCRIPTORSTATUSEntry;
import curam.core.facade.infrastructure.fact.EvidenceFactory;
import curam.core.facade.infrastructure.struct.ActiveEvdInstanceDtls;
import curam.core.facade.infrastructure.struct.ActiveEvdInstanceDtlsList;
import curam.core.facade.infrastructure.struct.ActiveEvidenceDetails;
import curam.core.facade.infrastructure.struct.ActiveEvidenceDetailsList;
import curam.core.facade.infrastructure.struct.ApplyAllChangesReturnDtls;
import curam.core.facade.infrastructure.struct.ApplyChangesDetails;
import curam.core.facade.infrastructure.struct.ApplyChangesReturnDtls;
import curam.core.facade.infrastructure.struct.ApplyUserChangesReturnDtls;
import curam.core.facade.infrastructure.struct.ApprovedEvidenceApprovalRequestDetails;
import curam.core.facade.infrastructure.struct.AttributionDetailsList;
import curam.core.facade.infrastructure.struct.CaseEvidenceDetails;
import curam.core.facade.infrastructure.struct.CaseEvidenceDetailsKey;
import curam.core.facade.infrastructure.struct.CaseIDAndEvidenceCategoryKey;
import curam.core.facade.infrastructure.struct.CaseIDAndLongEvidenceTypeList;
import curam.core.facade.infrastructure.struct.CaseIDRelatedIDAndEvidenceTypeDtls;
import curam.core.facade.infrastructure.struct.CaseIDRelatedIDAndEvidenceTypeDtlsList;
import curam.core.facade.infrastructure.struct.CaseMembersAndTransferEvidenceList;
import curam.core.facade.infrastructure.struct.DetailsForEvidenceTransfer;
import curam.core.facade.infrastructure.struct.EvdInstanceChangeDtls;
import curam.core.facade.infrastructure.struct.EvdInstanceChangeDtlsList;
import curam.core.facade.infrastructure.struct.EvidenceCatDashboardDetails;
import curam.core.facade.infrastructure.struct.EvidenceCatDashboardDetailsList;
import curam.core.facade.infrastructure.struct.EvidenceCategoryAndTypes;
import curam.core.facade.infrastructure.struct.EvidenceCategoryDetailsList;
import curam.core.facade.infrastructure.struct.EvidenceContextDescription;
import curam.core.facade.infrastructure.struct.EvidenceCorrectionDtls;
import curam.core.facade.infrastructure.struct.EvidenceCorrectionDtlsList;
import curam.core.facade.infrastructure.struct.EvidenceDetails;
import curam.core.facade.infrastructure.struct.EvidenceDetailsList;
import curam.core.facade.infrastructure.struct.EvidenceFlowDetails;
import curam.core.facade.infrastructure.struct.EvidenceIssuesDetails;
import curam.core.facade.infrastructure.struct.EvidenceIssuesDetailsList;
import curam.core.facade.infrastructure.struct.EvidenceKey;
import curam.core.facade.infrastructure.struct.EvidenceListDetails;
import curam.core.facade.infrastructure.struct.EvidenceListKey;
import curam.core.facade.infrastructure.struct.EvidenceObjectSummaryHeaderDetails;
import curam.core.facade.infrastructure.struct.EvidenceParticipantDtls;
import curam.core.facade.infrastructure.struct.EvidenceSiteMapDetails;
import curam.core.facade.infrastructure.struct.EvidenceTabSummaryHeaderDetails;
import curam.core.facade.infrastructure.struct.EvidenceTypeAndParticipantIDDetails;
import curam.core.facade.infrastructure.struct.EvidenceTypeDashboardDetails;
import curam.core.facade.infrastructure.struct.EvidenceTypeDashboardDetailsList;
import curam.core.facade.infrastructure.struct.EvidenceTypeDescription;
import curam.core.facade.infrastructure.struct.EvidenceTypeDetails;
import curam.core.facade.infrastructure.struct.EvidenceTypeWorkspaceListDetails;
import curam.core.facade.infrastructure.struct.ListAllActiveEVDInstanceWorkspaceDtls;
import curam.core.facade.infrastructure.struct.ListAllEvidenceDtls;
import curam.core.facade.infrastructure.struct.ListAllForActiveWorkspaceDtls;
import curam.core.facade.infrastructure.struct.ListAllForInEditWorkspaceDtls;
import curam.core.facade.infrastructure.struct.ListAllInEditDtls;
import curam.core.facade.infrastructure.struct.ListEvidenceChangeHistoryResult;
import curam.core.facade.infrastructure.struct.ListICAttributionDatesResult;
import curam.core.facade.infrastructure.struct.PageNameDetails;
import curam.core.facade.infrastructure.struct.RejectedEvidenceApprovalRequestDetails;
import curam.core.facade.infrastructure.struct.SetPendingRemovalReturnDtls;
import curam.core.facade.infrastructure.struct.TransferEvidenceKey;
import curam.core.facade.intf.MenuData;
import curam.core.facade.struct.ICProductDeliveryMenuDataKey;
import curam.core.facade.struct.IntegratedCaseMenuDataKey;
import curam.core.fact.CachedConcernRoleFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.EvidenceUpdatesAllowed;
import curam.core.impl.ProductHookManager;
import curam.core.intf.CachedConcernRole;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.ApprovalRequestKey;
import curam.core.sl.entity.struct.CaseEvidenceTreeDtls;
import curam.core.sl.entity.struct.CaseEvidenceTreeKey;
import curam.core.sl.entity.struct.CaseIDAndParticipantIDDetails;
import curam.core.sl.entity.struct.CaseIDAndStatusKey;
import curam.core.sl.entity.struct.CaseIDParticipantRoleKey;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.CaseParticipantRoleKey;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.impl.CaseTypeEvidence;
import curam.core.sl.impl.LocalizableXMLStringHelper;
import curam.core.sl.impl.PostponeVerificationInterface;
import curam.core.sl.impl.VerificationInterface;
import curam.core.sl.infrastructure.entity.fact.EvidenceChangeHistoryFactory;
import curam.core.sl.infrastructure.entity.fact.EvidenceDescriptorFactory;
import curam.core.sl.infrastructure.entity.intf.EvidenceChangeHistory;
import curam.core.sl.infrastructure.entity.intf.EvidenceDescriptor;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.CaseIDAndStatuses;
import curam.core.sl.infrastructure.entity.struct.ChangeUserDetails;
import curam.core.sl.infrastructure.entity.struct.CorrectionSetIDDetails;
import curam.core.sl.infrastructure.entity.struct.EvidenceChangeHistoryDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceChangeHistoryDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDashboardDetails;
import curam.core.sl.infrastructure.entity.struct.EvidenceDashboardDetailsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtls;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorDtlsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorIDAndStatusDetailsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceDescriptorKey;
import curam.core.sl.infrastructure.entity.struct.EvidenceParticipantIDNameDetailsList;
import curam.core.sl.infrastructure.entity.struct.EvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.ParticipantDataIndDetails;
import curam.core.sl.infrastructure.entity.struct.RelatedIDAndEvidenceTypeKey;
import curam.core.sl.infrastructure.entity.struct.RelatedIDEvidenceTypeAndCaseIDKey;
import curam.core.sl.infrastructure.entity.struct.SharedInstanceIDCaseIDStatusCode;
import curam.core.sl.infrastructure.entity.struct.SuccessionID;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EvidenceControllerInterface;
import curam.core.sl.infrastructure.impl.EvidenceIssues;
import curam.core.sl.infrastructure.impl.EvidenceMap;
import curam.core.sl.infrastructure.impl.EvidenceVerification;
import curam.core.sl.infrastructure.impl.GeneralConst;
import curam.core.sl.infrastructure.impl.StandardEvidenceInterface;
import curam.core.sl.infrastructure.intf.EvidenceController;
import curam.core.sl.infrastructure.struct.ApplyWIPChangeDetails;
import curam.core.sl.infrastructure.struct.ApprovalRequestHistoryDetailsList;
import curam.core.sl.infrastructure.struct.BusinessObjectEvidenceTypeKey;
import curam.core.sl.infrastructure.struct.BusinessObjectSummaryList;
import curam.core.sl.infrastructure.struct.DiscardPendingRemoveKey;
import curam.core.sl.infrastructure.struct.ECActiveEvidenceDtlsList;
import curam.core.sl.infrastructure.struct.ECApprovalRequestDtls;
import curam.core.sl.infrastructure.struct.ECWIPChangeDetails;
import curam.core.sl.infrastructure.struct.ECWIPChangeDtls;
import curam.core.sl.infrastructure.struct.ECWIPDtls;
import curam.core.sl.infrastructure.struct.ECWIPNewAndUpdateDtls;
import curam.core.sl.infrastructure.struct.ECWIPRemoveDtls;
import curam.core.sl.infrastructure.struct.ECWarningsDtls;
import curam.core.sl.infrastructure.struct.ECWarningsDtlsList;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.EvidenceKeyList;
import curam.core.sl.infrastructure.struct.EvidencePeriod;
import curam.core.sl.infrastructure.struct.EvidenceRejectionDetails;
import curam.core.sl.infrastructure.struct.EvidenceSiteMapDetailsList;
import curam.core.sl.infrastructure.struct.EvidenceTypeAdminDetails;
import curam.core.sl.infrastructure.struct.EvidenceTypeAdminDetailsList;
import curam.core.sl.infrastructure.struct.EvidenceTypeAndDesc;
import curam.core.sl.infrastructure.struct.EvidenceTypeAndDescList;
import curam.core.sl.infrastructure.struct.EvidenceTypeWorkspaceDetails;
import curam.core.sl.infrastructure.struct.EvidenceTypeWorkspaceKey;
import curam.core.sl.infrastructure.struct.IssueDetails;
import curam.core.sl.infrastructure.struct.IssueDetailsList;
import curam.core.sl.infrastructure.struct.ListParticipantEvidenceKey;
import curam.core.sl.infrastructure.struct.ListParticipantEvidenceResult;
import curam.core.sl.infrastructure.struct.PendingApprovalDtls;
import curam.core.sl.infrastructure.struct.TransferEvidenceDetails;
import curam.core.sl.infrastructure.struct.TransferEvidenceDetails1;
import curam.core.sl.infrastructure.struct.ViewApprovalRequestDetails;
import curam.core.sl.struct.AssociationDetails;
import curam.core.sl.struct.CaseIDParticipantIDEvidenceTypeKey;
import curam.core.sl.struct.EvidenceCaseKey;
import curam.core.sl.struct.ParticipantIDNameDetails;
import curam.core.sl.struct.ParticipantIDNameDetailsList;
import curam.core.sl.struct.ReturnEvidenceDetails;
import curam.core.sl.struct.ViewCaseParticipantRole_boKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceAndTypeDetails;
import curam.core.struct.CaseReferenceCRNameAltIDDetails;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.datastore.entity.struct.DatastoreEntityKey;
import curam.datastore.impl.Datastore;
import curam.datastore.impl.DatastoreFactory;
import curam.datastore.impl.Entity;
import curam.datastore.impl.NoSuchSchemaException;
import curam.evidence.impl.EvidenceTypeFactory;
import curam.message.BPOEVIDENCE;
import curam.message.BPOEVIDENCECONST;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.message.EVIDENCEDASHBOARD;
import curam.message.FACADEEVIDENCE;
import curam.message.PDCEVIDENCEDESCRIPTION;
import curam.message.impl.BPOEVIDENCECONTROLLERExceptionCreator;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.piwrapper.impl.ClientURI;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;
import curam.util.type.StringList;
import curam.wizard.util.impl.CodetableUtil;


/**
 * @see curam.core.facade.infrastructure.intf.Evidence
 */

public abstract class Evidence extends curam.core.facade.infrastructure.base.Evidence {

  // BEGIN, CR00216737, GYH
  // protected variables used in the parsing evidence information passed
  // in from the client.
  protected static final int kElementsInTabList = 5;

  protected static final int kFirstElement = 0;

  protected static final int kSecondElement = 1;

  protected static final int kThirdElement = 2;

  protected static final int kFourthElement = 3;

  protected static final int kFifthElement = 4;

  // END, CR00216737
  // BEGIN, CR00223998, ELG
  // Sixth element is for new and updated indicator. It is used in the
  // facade only.
  protected static final int kSixthElement = 5;

  // END, CR00223998

  // BEGIN, CR00188098, PB
  /**
   * A hash map reference of the case evidence type module which is registered
   * in the registry.
   */
  @Inject
  protected Map<String, CaseTypeEvidence> caseTypeEvidenceMap;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  @Inject
  protected EvidenceIssues evidenceIssues;

  @Inject
  protected EvidenceVerification evidenceVerification;

  @Inject
  protected EvidenceURIHelper evidenceURIHelper;
  
  // BEGIN, CR00427296, AKr
  @Inject
  protected PostponeVerificationInterface postponeVerificationInterface;
  // END, CR00427296
  /**
   * Default constructor for the class.
   */
  public Evidence() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00188098
  // BEGIN, CR00032741, DK
  /*
   * Generic mechanism to combine two different sorts. This Comparator is used
   * when we want to order a list based on two different fields. We define a
   * generic CompositeComparator that combines the logic of two individual
   * Comparators. We refer to the two Comparators as the major and minor
   * comparators. The major comparator has priority over the minor comparator.
   * If the major comparator returns < 0 or > 0, then that result is passed
   * back. The minor comparator's result is used only if the major comparator
   * returns 0
   */

  public class CompositeComparator implements Comparator {
    protected Comparator major;

    protected Comparator minor;

    public CompositeComparator(Comparator major, Comparator minor) {
      this.major = major;
      this.minor = minor;
    }

    /**
     * Default Constructor.
     */
    public CompositeComparator() {// Default constructor
    }

    /**
     * {@inheritDoc}
     */
    public int compare(final Object o1, final Object o2) {
      int result = major.compare(o1, o2);

      if (result != 0) {
        return result;
      } else {
        return minor.compare(o1, o2);
      }
    }

    public void setMajor(final Comparator major) {
      this.major = major;
    }

    public void setMinor(final Comparator minor) {
      this.minor = minor;
    }

  }


  /*
   * Comparator used when ordering list of WIP evidences by evidence description
   */
  public class WIPEvidenceDescComparator implements Comparator {

    /**
     * Default Constructor.
     */
    public WIPEvidenceDescComparator() {
      super();
    }

    /**
     * {@inheritDoc}
     */
    public int compare(final Object o1, final Object o2) {
      // BEGIN, CR00071077, GM
      String evType1 = CuramConst.gkEmpty;
      String evType2 = CuramConst.gkEmpty;

      // END, CR00071077

      if (o1.getClass().equals(new ECWIPNewAndUpdateDtls().getClass())) {
        evType1 = ((ECWIPNewAndUpdateDtls) o1).evidenceType;
        evType2 = ((ECWIPNewAndUpdateDtls) o2).evidenceType;
      } else if (o1.getClass().equals(new ECWIPRemoveDtls().getClass())) {
        evType1 = ((ECWIPRemoveDtls) o1).evidenceType;
        evType2 = ((ECWIPRemoveDtls) o2).evidenceType;
      } else {
        return 0;
      }
      // BEGIN, CR00072947, GM
      String a = CuramConst.gkEmpty;
      String b = CuramConst.gkEmpty;

      // END, CR00072947

      // BEGIN, CR00100972, VM
      try {
        // BEGIN, CR00163098, JC
        a = CodeTable.getOneItem(CASEEVIDENCE.TABLENAME, evType1,
          TransactionInfo.getProgramLocale());
        b = CodeTable.getOneItem(CASEEVIDENCE.TABLENAME, evType2,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } catch (AppException app) {
        AppException ae = new AppException(
          BPOEVIDENCE.ERR_SORTING_WIP_EVIDENCE_BY_DESCRIPTION, app);

        throw new AppRuntimeException(ae);
      } catch (InformationalException inf) {
        AppException ae = new AppException(
          BPOEVIDENCE.ERR_SORTING_WIP_EVIDENCE_BY_DESCRIPTION, inf);

        throw new AppRuntimeException(ae);
      }
      // END, CR00100972

      return a.compareTo(b);
    }

  }


  /*
   * Comparator used when ordering list of WIP evidences by participant name
   */
  public class WIPEvidenceParticipantNameComparator implements Comparator {

    /**
     * Default Constructor.
     */
    public WIPEvidenceParticipantNameComparator() {
      super();
    }

    /**
     * {@inheritDoc}
     */
    public int compare(final Object o1, final Object o2) {
      // BEGIN, CR00071077, GM
      String concernRoleName1 = CuramConst.gkEmpty;
      String concernRoleName2 = CuramConst.gkEmpty;

      // END, CR00071077

      if (o1.getClass().equals(new ECWIPNewAndUpdateDtls().getClass())) {
        concernRoleName1 = ((ECWIPNewAndUpdateDtls) o1).concernRoleName;
        concernRoleName2 = ((ECWIPNewAndUpdateDtls) o2).concernRoleName;
      } else if (o1.getClass().equals(new ECWIPRemoveDtls().getClass())) {
        concernRoleName1 = ((ECWIPRemoveDtls) o1).concernRoleName;
        concernRoleName2 = ((ECWIPRemoveDtls) o2).concernRoleName;
      }

      return concernRoleName1.compareTo(concernRoleName2);
    }

  }


  /*
   * Comparator used to order a list by participant name
   */
  // BEGIN, CR00222660, PF
  public class ParticipantIDNameDetailsComparator implements Comparator<ParticipantIDNameDetails> {

    public ParticipantIDNameDetailsComparator() {
      super();
    }

    public int compare(ParticipantIDNameDetails o1, ParticipantIDNameDetails o2) {

      return o1.participantName.compareTo(o2.participantName);
    }

  }
  // END, CR00222660

  // ___________________________________________________________________________
  /**
   * Method to sort a list of participant details by name.
   *
   * @param input
   * Input structure containing a list of participant details
   */
  protected void sortListByParticipant(ParticipantIDNameDetailsList input)
    throws AppException, InformationalException {
    // BEGIN, CR00222660, PF
    // Sort the input data by name
    Comparator<ParticipantIDNameDetails> participantIDNameDetailsComparator = new ParticipantIDNameDetailsComparator();
    ArrayList<ParticipantIDNameDetails> arrayList = new ArrayList<ParticipantIDNameDetails>();

    arrayList.addAll(input.dtls);
    Collections.sort(arrayList, participantIDNameDetailsComparator);

    // Empty list in order to re-use
    input.dtls.clear();

    // Copy entries into the list structure
    for (int i = 0; i < arrayList.size(); i++) {

      input.dtls.addRef(arrayList.get(i));
    }

  }

  /*
   * Comparator used to order a list by evidence type description
   */
  public class EvidenceDescComparator implements Comparator<EvidenceTypeAndDesc> {

    public EvidenceDescComparator() {
      super();
    }

    public int compare(EvidenceTypeAndDesc o1, EvidenceTypeAndDesc o2) {

      // BEGIN, CR00072947, GM
      String a = CuramConst.gkEmpty;
      String b = CuramConst.gkEmpty;

      // END, CR00072947

      // BEGIN, CR00100972, VM
      try {
        // BEGIN, CR00163098, JC
        a = CodeTable.getOneItem(CASEEVIDENCE.TABLENAME, o1.evidenceType,
          TransactionInfo.getProgramLocale());
        b = CodeTable.getOneItem(CASEEVIDENCE.TABLENAME, o2.evidenceType,
          TransactionInfo.getProgramLocale());
        // END, CR00163098, JC
      } catch (AppException app) {
        AppException ae = new AppException(
          BPOEVIDENCE.ERR_SORTING_WIP_EVIDENCE_BY_DESCRIPTION, app);

        throw new AppRuntimeException(ae);
      } catch (InformationalException inf) {
        AppException ae = new AppException(
          BPOEVIDENCE.ERR_SORTING_WIP_EVIDENCE_BY_DESCRIPTION, inf);

        throw new AppRuntimeException(ae);
      }
      // END, CR00100972

      return a.compareTo(b);
    }

  }
  // END, CR00222660

  // ___________________________________________________________________________
  /**
   * Method to sort the in edit workspace list of evidences by participant name
   * and evidence type description.
   *
   * @param input
   * List of evidences to be displayed on the workspace
   */
  protected void sortInEditListByParticipantAndEvidenceDesc(ECWIPDtls input) {

    CompositeComparator compComparator = new CompositeComparator();

    // Sort In Edit Evidence firstly by participantName and then by evidenceType

    // Set the major Comparator (i.e. Comparator that takes priority)
    // as the WIPEvidenceParticipantNameComparator which sorts by
    // concernRoleName
    compComparator.setMajor(new WIPEvidenceParticipantNameComparator());

    // Set the minor Comparator as the WIPEvidenceDescComparator
    // which sorts by evidence type description
    compComparator.setMinor(new WIPEvidenceDescComparator());

    ArrayList newAndUpdateList = new ArrayList();

    newAndUpdateList.addAll(input.newAndUpdateList.dtls);
    Collections.sort(newAndUpdateList, compComparator);

    // Empty list in order to re-use
    input.newAndUpdateList.dtls.clear();

    // Copy entries into the list structure
    for (int i = 0; i < newAndUpdateList.size(); i++) {
      input.newAndUpdateList.dtls.addRef(
        (ECWIPNewAndUpdateDtls) newAndUpdateList.get(i));
    }

    ArrayList removeList = new ArrayList();

    removeList.addAll(input.removeList.dtls);
    Collections.sort(removeList, compComparator);

    // Empty list in order to re-use
    input.removeList.dtls.clear();

    // Copy entries into the list structure
    for (int i = 0; i < removeList.size(); i++) {
      input.removeList.dtls.addRef((ECWIPRemoveDtls) removeList.get(i));
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to sort a list by evidence type description.
   *
   * @param input
   * Input structure containing a list of evidence types and
   * descriptions
   */
  protected void sortListByEvidenceDesc(EvidenceTypeAndDescList input)
    throws AppException, InformationalException {

    // BEGIN, CR00222660, PF
    // Sort the input data by evidence description
    Comparator<EvidenceTypeAndDesc> evidenceDescComparator = new EvidenceDescComparator();
    ArrayList<EvidenceTypeAndDesc> arrayList = new ArrayList<EvidenceTypeAndDesc>();

    arrayList.addAll(input.dtls);
    Collections.sort(arrayList, evidenceDescComparator);

    // Empty list in order to re-use
    input.dtls.clear();

    // Copy entries into the list structure
    for (int i = 0; i < arrayList.size(); i++) {

      input.dtls.addRef(arrayList.get(i));
    }
    // END, CR00222660

  }

  // END, CR00032741

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Sets the Evidence identified by input Evidence Descriptor key as 'Pending 
   * Removal' and returns the details object for the same evidence.
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Evidence Descriptor entity key.
   *
   * @return Details of evidence pending removal.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public SetPendingRemovalReturnDtls setPendingRemovalForActiveEvidence(
    EvidenceDescriptorKey key) throws AppException, InformationalException {

    // Call controller operation to remove evidence
    EvidenceControllerFactory.newInstance().removeEvidence(key);

    SetPendingRemovalReturnDtls setPendingRemovalReturnDtls = new SetPendingRemovalReturnDtls();

    setPendingRemovalReturnDtls.warnings = EvidenceControllerFactory.newInstance().getWarnings();

    return setPendingRemovalReturnDtls;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Discards 'pending removal' from active evidences. Discards the pending 
   * removal evidence (by setting the <code>pendingRemovalInd</code> field on 
   * the EvidenceDescriptor entity to <code>false</code>). If the change has 
   * been submitted for approval and/or if the user does not have sufficient 
   * privileges to discard pending removal evidences, exception is thrown.
   *
   * @boread Evidence
   *
   * @bowrite EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Contains EvidenceDescriptor key and details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public void clearPendingRemovalForActiveEvidence(DiscardPendingRemoveKey key)
    throws AppException, InformationalException {

    // Call controller operation to discard pending removal evidences
    EvidenceControllerFactory.newInstance().discardPendingRemove(key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Discards the pending update evidence (by setting the 
   * <code>statusCode</code> of the EvidenceDescriptor to Canceled).
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Evidence Descriptor entity key.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public void discardPendingUpdate(final EvidenceDescriptorKey key)
    throws AppException, InformationalException {

    // Call controller operation to discard pending update evidences
    EvidenceControllerFactory.newInstance().discardPendingUpdate(key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns view page name details depending on evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key
   *
   * @return Page name details
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public PageNameDetails readViewPage(EvidenceKey key) throws AppException,
      InformationalException {

    // Return object
    PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails = EvidenceControllerFactory.newInstance().readViewPage(
      key.key);

    return pageNameDetails;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns modify page name details depending on evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public PageNameDetails readModifyPage(EvidenceKey key) throws AppException,
      InformationalException {

    // Return object
    PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the modify page
    pageNameDetails.pageDetails = EvidenceControllerFactory.newInstance().readModifyPage(
      key.key);

    return pageNameDetails;
  }

  // BEGIN, CR00223998, ELG
  // ___________________________________________________________________________
  /**
   * @param key
   * Contains a case identifier
   *
   * @return List of all evidences for applying changes
   * @deprecated Since Curam 6.0, replaced with
   * {@link #listAllForApplyChanges1(CaseKey)}. As part of evidence
   * processing enhancements the return apply changes evidence list
   * had to be changed. See release note: CR00223998.
   *
   * Lists all evidences for applying changes.
   */
  @Deprecated
  // END, CR00223998
  public ECWIPDtls listAllForApplyChanges(CaseKey key) throws AppException,
      InformationalException {

    // Call method for retrieving the list of all work in progress details
    return EvidenceControllerFactory.newInstance().listWorkInProgress(key);
  }

  // BEGIN, CR00223998, ELG
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all evidences for applying changes.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier and, optionally, an evidence type.
   *
   * @return List of all evidences for applying changes
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  // BEGIN, CR00245734, CD
  public ECWIPChangeDetails listAllForApplyChanges1(CaseIDAndEvidenceTypeKey key)
    throws AppException, InformationalException {
    // END, CR00245734
    EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

    return evidenceControllerObj.listWorkInProgressDetails(key);

  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all Evidence for validating changes.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier and, optionally, an evidence type.
   *
   * @return List of all evidences for validating changes
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ECWIPChangeDetails listAllForValidateChanges(CaseIDAndEvidenceTypeKey key)
    throws AppException, InformationalException {

    // get the full list
    ECWIPChangeDetails fullList = listAllForApplyChanges1(key);

    //
    // filter out participant evidence
    //

    ECWIPChangeDetails filteredList = new ECWIPChangeDetails();

    filteredList.filterByTypeInd = fullList.filterByTypeInd;

    // EvidenceController business object
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    EvidenceTypeKey evTypeKey = new EvidenceTypeKey();

    for (ECWIPChangeDtls changeDtls: fullList.changeList.dtls) {

      evTypeKey.evidenceType = changeDtls.evidenceType;
      if (!evidenceControllerObj.isEvidenceParticipantData(evTypeKey)) {
        filteredList.changeList.dtls.add(changeDtls);
      }

    }

    return filteredList;

  }

  // END, CR00223998

  // BEGIN, CR00223998, ELG
  // ___________________________________________________________________________
  /**
   * @param caseKey
   * Contains a case identifier
   * @param details
   * Contains a tabbed evidence list
   *
   * @return ApplyChangesReturnDtls warnings that occurred while applying the
   * changes
   * @deprecated Since Curam 6.0, replaced with
   * {@link #applyChanges1(CaseKey, ApplyWIPChangeDetails)}. As part
   * of evidence processing enhancements the evidence for apply
   * changes is now passed in as single tabbed list. See release
   * note: CR00223998.
   *
   * Applies changes on the (tabbed) list of evidence passed into
   * the function.
   */
  @Deprecated
  // END, CR00223998
  public ApplyChangesReturnDtls applyChanges(CaseKey caseKey,
    ApplyChangesDetails details) throws AppException, InformationalException {

    // EvidenceController business object
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // Call method to apply changes
    evidenceControllerObj.applyChanges(caseKey, details.details);

    // Return the warnings
    ApplyChangesReturnDtls applyChangesReturnDtls = new ApplyChangesReturnDtls();

    applyChangesReturnDtls.warnings = evidenceControllerObj.getWarnings();

    return applyChangesReturnDtls;
  }

  // BEGIN, CR00223998, ELG
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Applies changes on the (tabbed) list of evidences passed into the method 
   * to the given case. This tabbed list includes new, modified, and pending 
   * deletion evidences.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param caseKey Contains a case identifier.
   *
   * @param tabbedList Contains a tabbed list of evidence changes to be 
   * applied.
   *
   * @return Warnings that occurred while applying the changes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ApplyChangesReturnDtls applyChanges1(final CaseKey key,
    final ApplyWIPChangeDetails tabbedList) throws AppException,
      InformationalException {

    // EvidenceController business object
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    curam.core.sl.infrastructure.struct.ApplyChangesDetails applyChangesDetails = convertChangeListToApplyChangesDetails(
      tabbedList.changeList);

    // Call method to apply changes
    evidenceControllerObj.applyChanges(key, applyChangesDetails);

    // Return the warnings
    ApplyChangesReturnDtls applyChangesReturnDtls = new ApplyChangesReturnDtls();

    applyChangesReturnDtls.warnings = evidenceControllerObj.getWarnings();

    return applyChangesReturnDtls;

  }

  /**
   * Helper method for converting tab separated evidence list to two lists -
   * newAndUpdateList & removeList.
   *
   * @param tabList
   * Tab separated list of evidence data to be parsed.
   *
   * @return Structure containing newAndUpdateList & removeList tab separated
   * lists.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected curam.core.sl.infrastructure.struct.ApplyChangesDetails convertChangeListToApplyChangesDetails(
    final String tabList) {

    // Return structure
    curam.core.sl.infrastructure.struct.ApplyChangesDetails applyChangesDetails = new curam.core.sl.infrastructure.struct.ApplyChangesDetails();

    // Variables for evidence details
    String evidenceDescriptorIDStr;
    String evidenceIDStr;
    String evidenceTypeStr;
    String correctionSetIDStr;
    String successionIDStr;
    boolean newAndUpdatedInd;

    // New and Update List
    StringList sourceList = StringUtil.tabText2StringList(tabList);

    StringBuffer newAndUpdateStringBuffer = new StringBuffer();
    StringBuffer removeStringBuffer = new StringBuffer();

    final int numElementsInList = kElementsInTabList + CuramConst.gkOne;

    int newAndUpdateListElementCount = 0;
    int removeListElementCount = 0;

    for (int i = 0; i < sourceList.size(); i++) {

      StringList evidenceDetailsList = StringUtil.delimitedText2StringList(
        sourceList.item(i), CuramConst.gkPipeDelimiterChar);

      if (evidenceDetailsList.size() != numElementsInList) {
        continue;
      }

      evidenceDescriptorIDStr = evidenceDetailsList.item(kFirstElement);
      evidenceIDStr = evidenceDetailsList.item(kSecondElement);
      evidenceTypeStr = evidenceDetailsList.item(kThirdElement);
      correctionSetIDStr = evidenceDetailsList.item(kFourthElement);
      successionIDStr = evidenceDetailsList.item(kFifthElement);
      newAndUpdatedInd = Boolean.parseBoolean(
        evidenceDetailsList.item(kSixthElement));

      if (newAndUpdatedInd) {

        if (newAndUpdateListElementCount > 0) {
          newAndUpdateStringBuffer.append(CuramConst.gkTabDelimiterChar);
        }

        newAndUpdateStringBuffer.append(evidenceDescriptorIDStr);
        newAndUpdateStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        newAndUpdateStringBuffer.append(evidenceIDStr);
        newAndUpdateStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        newAndUpdateStringBuffer.append(evidenceTypeStr);
        newAndUpdateStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        newAndUpdateStringBuffer.append(correctionSetIDStr);
        newAndUpdateStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        newAndUpdateStringBuffer.append(successionIDStr);

        newAndUpdateListElementCount++;

      } else {

        if (removeListElementCount > 0) {
          removeStringBuffer.append(CuramConst.gkTabDelimiterChar);
        }

        removeStringBuffer.append(evidenceDescriptorIDStr);
        removeStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        removeStringBuffer.append(evidenceIDStr);
        removeStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        removeStringBuffer.append(evidenceTypeStr);
        removeStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        removeStringBuffer.append(correctionSetIDStr);
        removeStringBuffer.append(CuramConst.gkPipeDelimiterChar);
        removeStringBuffer.append(successionIDStr);

        removeListElementCount++;

      }

    }

    applyChangesDetails.newAndUpdateList = newAndUpdateStringBuffer.toString();
    applyChangesDetails.removeList = removeStringBuffer.toString();

    return applyChangesDetails;

  }

  // END, CR00223998

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Applies all changes in Evidences to case, specified by case key, key.
   *
   * Before applying changes, all evidences are checked to ensure that they 
   * have been approved and activation is allowed.
   *
   * If changes could not be applied, appropriate warnings are added to 
   * <code>InformationalManager</Code>.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @param caseKey Contains a case identifier.
   *
   * @return ApplyAllChangesReturnDtls warnings that occurred while applying 
   * the changes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ApplyAllChangesReturnDtls applyAllChanges(CaseKey caseKey)
    throws AppException, InformationalException {

    // EvidenceController business object
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    // Call method to apply all changes
    evidenceControllerObj.applyAllChanges(caseKey);

    // Return the warnings
    ApplyAllChangesReturnDtls applyAllChangesReturnDtls = new ApplyAllChangesReturnDtls();

    applyAllChangesReturnDtls.warnings = evidenceControllerObj.getWarnings();

    return applyAllChangesReturnDtls;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Applies changes to evidences, to the case, identified by key, where the 
   * currently logged in user was the most recent user to modify the evidences. 
   * Before applying changes, evidences are checked to ensure that they have 
   * been approved and activation is allowed.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param caseKey Contains a case identifier.
   *
   * @return List of warnings that occurred while applying the changes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ApplyUserChangesReturnDtls applyUserChanges(CaseKey caseKey)
    throws AppException, InformationalException {

    // EvidenceController business object
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    evidenceControllerObj.applyUserChanges(caseKey);

    // Return the warnings
    ApplyUserChangesReturnDtls applyUserChangesReturnDtls = new ApplyUserChangesReturnDtls();

    applyUserChangesReturnDtls.warnings = evidenceControllerObj.getWarnings();

    return applyUserChangesReturnDtls;
  }

  // BEGIN, CR00031254, CD
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all evidence of a given type for a given case to populate the 
   * evidence workspace.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Key to retrieve list of evidence consisting of a caseID and 
   * evidenceType
   *
   * @return List of Evidence
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceListDetails listEvidence(EvidenceListKey key)
    throws AppException, InformationalException {

    // Instantiate the return struct
    EvidenceListDetails evidenceListDetails = new EvidenceListDetails();

    // EvidenceController business object
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    evidenceListDetails.dtls = evidenceControllerObj.listAllForEvidenceListPage(
      key.key);
    CaseKey caseKey = new CaseKey();

    // Retrieve context description
    // BEGIN, CR00080440, CD
    caseKey.caseID = key.key.caseID;

    evidenceListDetails.contextDescription.contextDescription = getContextDescription(caseKey).contextDescription;
    // END, CR00080440
    // BEGIN, CR00100757, CH
    // Putting back in the showVerificationCluster
    // BEGIN, CR00077979, CH
    // The showVerificationCluster boolean has been removed as a temporary
    // measure. For this reason the code is being commented out rather
    // than being removed.
    // BEGIN, CR00032741, DK
    if (evidenceListDetails.dtls.verificationDtlsList.verificationDtls.size()
      > 0) {

      evidenceListDetails.showVerificationCluster = true;
    }
    // END, CR00032741
    // END, CR00077979
    // END, CR00100757

    return evidenceListDetails;
  }

  // END, CR00031254

  // BEGIN, CR00224418, EC
  
  // BEGIN, CR00397587, PS
  /**
   * Lists a summary of all business objects for the supplied evidence type 
   * optionally filtered by a related succession ID.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Key to retrieve list of business objects
   *
   * @return List of summaries of business objects.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public BusinessObjectSummaryList listBusinessObjectsForEvidenceType(
    BusinessObjectEvidenceTypeKey key) throws AppException,
      InformationalException {
    // BEGIN, CR00389944, ZV
    String displayDeletedEvidence = Configuration.getProperty(
      EnvVars.ENV_DISPLAY_DELETED_EVIDENCE);

    if (displayDeletedEvidence == null) {
      displayDeletedEvidence = EnvVars.ENV_DISPLAY_DELETED_EVIDENCE;
    }
    
    key.includeExcludedStatus = displayDeletedEvidence.equals(
      EnvVars.ENV_VALUE_YES);    
    // END, CR00389944
    return EvidenceControllerFactory.newInstance().listBusinessObjectsForEvidenceType(
      key);
  }

  // END, CR00224418
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns a list of evidence change history records.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key.
   *
   * @return Evidence history details list for display.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ListEvidenceChangeHistoryResult listEvidenceChangeHistory(
    EvidenceKey key) throws AppException, InformationalException {

    // Return object
    ListEvidenceChangeHistoryResult listEvidenceChangeHistoryResult = new ListEvidenceChangeHistoryResult();

    // Call the method to retrieve the list of evidence change history
    // records
    listEvidenceChangeHistoryResult.detailsList = EvidenceControllerFactory.newInstance().listEvidenceChangeHistory(
      key.key);

    return listEvidenceChangeHistoryResult;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Applies attribution on a product delivery case where some or all of the 
   * evidence is stored at the related Integrated Case level.
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Contains the case identifier.
   *
   * @return List of informational warnings.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ECWarningsDtlsList performProductDeliveryAttribution(CaseKey key)
    throws AppException, InformationalException {

    // Call the method for attributing evidence
    EvidenceControllerFactory.newInstance().performProductDeliveryAttribution(
      key, new EvidenceKeyList());

    return EvidenceControllerFactory.newInstance().getWarnings();
  }

  // ___________________________________________________________________________
  /**
   * Validates the selected evidence records of one evidence type.
   *
   * @param key Contains a case identifier
   *
   * @param dtls List of evidence records to be validated.
   *
   * @deprecated Replaced by validateChanges1 for usability changes.
   * @deprecated -since v6.0.
   */
  public void validateChanges(CaseKey key, ApplyChangesDetails dtls)
    throws AppException, InformationalException {

    // Call the method for apply changes
    EvidenceControllerFactory.newInstance().validateChanges(dtls.details);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Validates the selected evidence records of one evidence type.
   *
   * @bowrite EvidenceController
   *
   * @param key Contains a case identifier.
   *
   * @param dtls List of evidence records to be validated.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public void validateChanges1(final CaseIDAndEvidenceTypeKey key, final ApplyWIPChangeDetails dtls)
    throws AppException, InformationalException {

    curam.core.sl.infrastructure.struct.ApplyChangesDetails applyChangesDetails = convertChangeListToApplyChangesDetails(
      dtls.changeList);

    // Call the method for apply changes
    EvidenceControllerFactory.newInstance().validateChanges(applyChangesDetails);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * List attribution periods for evidence associated with the Integrated Case.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence Descriptor entity key.
   *
   * @return List of evidence attribution details for an integrated case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ListICAttributionDatesResult listICAttributionDates(
    EvidenceDescriptorKey key) throws AppException, InformationalException {

    // Return object
    ListICAttributionDatesResult listICAttributionDatesResult = new ListICAttributionDatesResult();

    // Call method to retrieve a list of integrated case evidence
    // attribution dates
    listICAttributionDatesResult.dtls = EvidenceControllerFactory.newInstance().listICAttributionDates(
      key);

    return listICAttributionDatesResult;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists the attribution dates for an evidence descriptor identifier.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence Descriptor entity key.
   *
   * @return List of evidence attribution details for a product delivery.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public AttributionDetailsList listAttributionDates(EvidenceDescriptorKey key)
    throws AppException, InformationalException {

    // Return object
    AttributionDetailsList attributionDetailsList = new AttributionDetailsList();

    // Call the method to retrieve a list of attribution dates
    attributionDetailsList.dtls = EvidenceControllerFactory.newInstance().listAttributionDates(
      key);

    return attributionDetailsList;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns a list of all evidence that have pending changes for approval or 
   * removal for a specific case. Called during case processing by the 
   * caseworker.
   *
   * @boread Evidence
   *
   * @param key Contains a case identifier.
   *
   * @return List of all pending approval or pending removal changes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  
  // BEGIN, CR00019750, VM
  public ECApprovalRequestDtls listAllForApproveReject(CaseKey key)
    throws AppException, InformationalException {

    // Return object
    ECApprovalRequestDtls ecApprovalRequestDtls = new ECApprovalRequestDtls();

    EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

    // Call method for retrieving the list of all pending approval records
    ECWIPDtls ecWIPDtls = evidenceControllerObj.listWorkInProgressApprovalRequested(
      key);

    for (int i = 0; i < ecWIPDtls.newAndUpdateList.dtls.size(); i++) {

      PendingApprovalDtls pendingApprovalDtls = new PendingApprovalDtls();

      pendingApprovalDtls.assign(ecWIPDtls.newAndUpdateList.dtls.item(i));

      ecApprovalRequestDtls.pendingApprovalList.dtls.add(pendingApprovalDtls);
    }

    for (int i = 0; i < ecWIPDtls.removeList.dtls.size(); i++) {

      PendingApprovalDtls pendingApprovalDtls = new PendingApprovalDtls();

      pendingApprovalDtls.assign(ecWIPDtls.removeList.dtls.item(i));

      ecApprovalRequestDtls.pendingApprovalList.dtls.add(pendingApprovalDtls);
    }

    return ecApprovalRequestDtls;
    // END, CR00019750
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Rejects a list of evidence Approval Requests made by a caseworker.
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param details List of evidence to reject approval requests.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public void rejectApprovalRequests(
    RejectedEvidenceApprovalRequestDetails details) throws AppException,
      InformationalException {

    EvidenceControllerFactory.newInstance().rejectApprovalRequests(
      details.details);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Approves multiple approval requests for evidences listed in the input 
   * tabbed list.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param details Tabbed list of evidence approval requests to approve.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public void approveApprovalRequests(
    ApprovedEvidenceApprovalRequestDetails details) throws AppException,
      InformationalException {

    EvidenceControllerFactory.newInstance().approveApprovalRequests(
      details.details);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Approves an approval request made against a piece of Evidence. 
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key EvidenceKey to identify evidence row for approval.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public void approveApprovalRequest(
    curam.core.sl.infrastructure.struct.EvidenceKey key) throws AppException,
      InformationalException {

    EvidenceControllerFactory.newInstance().approveApprovalRequest(key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Rejects an Approval Request made by a caseworker against a piece of 
   * Evidence.
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key EvidenceKey to identify evidence row for rejection.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public void rejectApprovalRequest(
    curam.core.sl.infrastructure.struct.EvidenceKey key,
    EvidenceRejectionDetails details) throws AppException,
      InformationalException {

    EvidenceControllerFactory.newInstance().rejectApprovalRequest(key, details);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Reads the approval request details for a evidence.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key EvidenceKey for this row of evidence.
   *
   * @return Approval Request details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ViewApprovalRequestDetails readApprovalRequestDetails(
    ApprovalRequestKey key) throws AppException, InformationalException {

    return EvidenceControllerFactory.newInstance().readApprovalRequest(key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns Evidence Descriptor details for an evidence entity.
   *
   * @boread Evidence
   *
   * @param key Evidence Descriptor entity key.
   *
   * @return Details for Evidence Descriptor associated with this evidence.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceDescriptorDtlsList readEvidenceDescriptor(
    EvidenceDescriptorKey key) throws AppException, InformationalException {

    // Return object
    EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = new EvidenceDescriptorDtlsList();

    evidenceDescriptorDtlsList.dtls.add(
      EvidenceControllerFactory.newInstance().readEvidenceDescriptorDtls(key));

    return evidenceDescriptorDtlsList;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Retrieves the context description for a specific piece of Evidence.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key CaseKey Contains a case identifier.
   *
   * @return Evidence context description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  
  // BEGIN, CR00080440, CD
  public EvidenceContextDescription getContextDescription(CaseKey key)
    // END, CR00080440
    throws AppException, InformationalException {

    // Create return object
    EvidenceContextDescription evidenceContextDescription = new EvidenceContextDescription();

    // BEGIN, CR00031254, CD
    // set up the context description
    LocalisableString description = new LocalisableString(
      FACADEEVIDENCE.EVIDENCECONTEXTDESCRIPTION);

    // CaseHeader manipulation variables
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseKey caseKey = new CaseKey();

    CaseReferenceCRNameAltIDDetails caseReferenceCRNameAltIDDetails;

    // read case details to get case reference number and participant name
    caseKey.caseID = key.caseID;
    caseReferenceCRNameAltIDDetails = caseHeaderObj.readCaseReferenceConcernRoleNameAndAlternateID(
      caseKey);

    // BEGIN, CR00032741, DK
    String caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey).caseTypeCode;

    // BEGIN, CR00163098, JC
    String caseTypeValue = curam.util.type.CodeTable.getOneItem(
      CASETYPECODE.TABLENAME, caseTypeCode, TransactionInfo.getProgramLocale());
    // END, CR00163098, JC
    // BEGIN, CR00188098, PB
    CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(caseTypeCode);

    // BEGIN CR00197474, PB
    if (null == caseTypeEvidence) {
      AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, caseTypeCode,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
    // END CR00197474
    caseTypeValue = caseTypeEvidence.getCaseTypeDescription(caseKey);

    // END, CR00188098
    // Add the items to the localizable string
    description.arg(caseTypeValue);
    // END, CR00032741
    description.arg(caseReferenceCRNameAltIDDetails.caseReference);
    description.arg(caseReferenceCRNameAltIDDetails.concernRoleName);
    description.arg(caseReferenceCRNameAltIDDetails.primaryAlternateID);
    // END, CR00031254

    // Assign it to the return object
    evidenceContextDescription.contextDescription = description.toClientFormattedText();

    return evidenceContextDescription;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns a list of all approval requests for a specific piece of evidence.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key EvidenceDescriptorKey Contains a EvidenceDescriptor identifier.
   *
   * @return List of Approval Request history details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ApprovalRequestHistoryDetailsList listApprovalRequestHistory(
    EvidenceDescriptorKey key) throws AppException, InformationalException {

    return EvidenceControllerFactory.newInstance().listApprovalRequestHistory(
      key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all 'In Edit' and 'Pending Removal' evidences for the current user.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier.
   *
   * @return List of all evidences for applying user changes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ECWIPDtls listAllForUserApplyChanges(CaseKey key) throws AppException,
      InformationalException {

    // Call method for retrieving the list of all work in progress details
    // for the current user
    return EvidenceControllerFactory.newInstance().listWorkInProgressForUser(
      key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Creates an association of the evidence with another given 
   * evidence record. This method returns the details of the evidence that was 
   * associated with and warnings, if any. 
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param dtls The association details of the Evidence that needs to be 
   * associated.
   *
   * @return Details of the Evidence record that was associated.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ReturnEvidenceDetails createAssociation(AssociationDetails dtls)
    throws AppException, InformationalException {
    // create association for the evidence record and populate the return
    // details
    return EvidenceControllerFactory.newInstance().createAssociation(dtls);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Cancels a pre existing association of the evidence with another 
   * given evidence record. This method returns the details of the evidence, 
   * with which the association was canceled, along with warnings, if any. 
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param dtls The identifiers of the association.
   *
   * @return Details of the modified record.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ReturnEvidenceDetails cancelAssociation(AssociationDetails dtls)
    throws AppException, InformationalException {
    // cancel associations of the evidence record and populate the return
    // details
    return EvidenceControllerFactory.newInstance().cancelAssociation(dtls);
  }

  // BEGIN, CR00397587, PS
  // BEGIN, CR00058169, VM
  // ___________________________________________________________________________
  /**
   * Returns the name of view snapshot evidence page for a given piece of 
   * evidence.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence Descriptor entity key.
   *
   * @return Evidence Snapshot page name.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public PageNameDetails readViewSnapshotPage(EvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the view snapshot page
    pageNameDetails.pageDetails = EvidenceControllerFactory.newInstance().readViewSnapshotPage(
      key.key);

    return pageNameDetails;
  }

  // END, CR00058169

  // BEGIN, CR00066544, VM
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns a unique list of active evidence types pertaining to the specified 
   * participant.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Concern Role entity key.
   *
   * @return Unique list of evidence types pertaining to the specified 
   * participant.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ListParticipantEvidenceResult listEvidenceTypeForParticipant(
    ConcernRoleKey key) throws AppException, InformationalException {

    ListParticipantEvidenceKey listParticipantEvidenceKey = new ListParticipantEvidenceKey();

    listParticipantEvidenceKey.key.participantID = key.concernRoleID;

    return EvidenceControllerFactory.newInstance().listActiveEvidenceForParticipant(
      listParticipantEvidenceKey);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns all active evidence for the specified case, evidence type and 
   * participant.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains the caseID and evidence type.
   *
   * @param concernRoleKey Concern Role entity key of the participant whose 
   * Evidence is being retrieved.
   *
   * @return List of active evidence for the specified case and participant.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceListDetails listEvidenceForTransfer(
    CaseIDAndEvidenceTypeKey key, ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {

    // Return object
    EvidenceListDetails evidenceListDetails = new EvidenceListDetails();

    ListParticipantEvidenceKey listParticipantEvidenceKey = new ListParticipantEvidenceKey();

    listParticipantEvidenceKey.key.participantID = concernRoleKey.concernRoleID;

    ListParticipantEvidenceResult listParticipantEvidenceResult = EvidenceControllerFactory.newInstance().listActiveEvidenceForParticipant(
      listParticipantEvidenceKey);

    // BEGIN, CR00087761, VM
    EvidenceListKey evidenceListKey = new EvidenceListKey();
    // END, CR00087761

    EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    evidenceListKey.key.caseID = key.caseID;

    for (int i = 0; i < listParticipantEvidenceResult.result.dtls.size(); i++) {

      evidenceTypeKey.evidenceType = listParticipantEvidenceResult.result.dtls.item(i).evidenceType;

      // BEGIN, CR00087761, VM
      if (!EvidenceControllerFactory.newInstance().isEvidenceParticipantData(
        evidenceTypeKey)) {
        // END, CR00087761

        // BEGIN, CR00101193, VM
        // Filter out the records by the case we're currently on
        RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey = new RelatedIDAndEvidenceTypeKey();

        relatedIDAndEvidenceTypeKey.evidenceType = listParticipantEvidenceResult.result.dtls.item(i).evidenceType;
        relatedIDAndEvidenceTypeKey.relatedID = listParticipantEvidenceResult.result.dtls.item(i).relatedID;

        EvidenceDescriptorDtls evidenceDescriptorDtls = EvidenceDescriptorFactory.newInstance().readByRelatedIDAndType(
          relatedIDAndEvidenceTypeKey);

        if (evidenceDescriptorDtls.caseID == key.caseID) {
          // END, CR00101193

          evidenceListKey.key.evidenceType = listParticipantEvidenceResult.result.dtls.item(i).evidenceType;

          EvidenceListDetails tempEvidenceListDetails = listEvidence(
            evidenceListKey);

          // BEGIN, CR00101611, VM
          for (int j = 0; j
            < tempEvidenceListDetails.dtls.activeList.dtls.size(); j++) {

            // Find a match
            if (tempEvidenceListDetails.dtls.activeList.dtls.item(j).evidenceDescriptorID
              == evidenceDescriptorDtls.evidenceDescriptorID) {
              evidenceListDetails.dtls.activeList.dtls.addRef(
                tempEvidenceListDetails.dtls.activeList.dtls.item(j));
              break;
            }
          }
          // END, CR00101611
        }
      }
    }
    return evidenceListDetails;
  }

  // BEGIN, CR00245135, ELG
  // ___________________________________________________________________________
  /**
   * @param details
   * Contains the evidence transfer details.
   * @return List of informational warnings
   * @deprecated Since Curam 6.0, replaced with {@link #transferEvidence1(TransferEvidenceDetails1)}.
   * This method was deprecated as part of the evidence processing
   * enhancements. Please see release note: CR00245135.
   *
   * Transfers the evidence from one case to another for a specified
   * participant.
   */
  public ECWarningsDtlsList transferEvidence(TransferEvidenceDetails details)
    throws AppException, InformationalException {

    // Return object
    ECWarningsDtlsList ecWarningsDtlsList = new ECWarningsDtlsList();

    EvidenceControllerFactory.newInstance().transferParticipantEvidence(details);

    return ecWarningsDtlsList;

  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Transfers the evidence from one case to another for a specified 
   * participant.
   *
   * @boread Evidence
   *
   * @bowrite EvidenceController
   *
   * @param details Contains the evidence transfer details.
   *
   * @return List of informational warnings
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ECWarningsDtlsList transferEvidence1(
    final TransferEvidenceDetails1 details)
    throws AppException, InformationalException {

    ECWarningsDtlsList ecWarningsDtlsList = new ECWarningsDtlsList();

    if (!details.actionIDProperty.equals(CuramConst.kNO)) {

      EvidenceControllerFactory.newInstance().transferParticipantEvidence1(
        details);

    }

    if (details.actionIDProperty.equals(CuramConst.kYES)
      || details.actionIDProperty.equals(CuramConst.kNO)) {

      final DatastoreEntityKey datastoreEntityKey = new DatastoreEntityKey();

      datastoreEntityKey.entityID = details.datastoreEntityID;
      getDeleteEvidenceTransferDatastore(datastoreEntityKey);

    }

    return ecWarningsDtlsList;

  }

  // END, CR00245135

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns case participant details for transferring participant evidence 
   * from one case to another.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @boread CaseParticipant
   *
   * @param toCaseKey Case Header entity key of the case to which evidence is 
   * being transferred.
   *
   * @param key Case Participant Role of the member whose evidence is being 
   * transferred.
   *
   * @return Details for transferring participant evidence from one case to 
   * another.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public DetailsForEvidenceTransfer getDetailsForEvidenceTransfer(
    CaseHeaderKey toCaseKey, CaseParticipantRoleKey key) throws AppException,
      InformationalException {

    // Return object
    DetailsForEvidenceTransfer detailsForEvidenceTransfer = new DetailsForEvidenceTransfer();

    // Read the Case Participant Role entity
    CaseParticipantRoleDtls caseParticipantRoleDtls = CaseParticipantRoleFactory.newInstance().read(
      key);

    detailsForEvidenceTransfer.caseID = toCaseKey.caseID;
    detailsForEvidenceTransfer.caseParticipantRoleID = key.caseParticipantRoleID;
    detailsForEvidenceTransfer.participantRoleID = caseParticipantRoleDtls.participantRoleID;

    return detailsForEvidenceTransfer;
  }

  // END, CR00066544

  // BEGIN, CR00032741, DK
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all active evidence for a case, filtering by participant and/or 
   * evidenceType.
   *
   * @boread Evidence
   *
   * @boread Participant
   *
   * @boread Case
   *
   * @param key Contains a case identifier, participant identifier and an 
   * Evidence type code.
   *
   * @return List of 'Active' evidence
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ListAllForActiveWorkspaceDtls listAllForActiveWorkspace(
    CaseIDParticipantIDEvidenceTypeKey key) throws AppException,
      InformationalException {

    // create the return struct
    ListAllForActiveWorkspaceDtls listAllForActiveWorkspaceDtls = new ListAllForActiveWorkspaceDtls();

    //
    // Create default drop down "ALL" entries
    //

    EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();

    // BEGIN, CR00109753, SK
    LocalisableString messageAll = new LocalisableString(
      curam.message.BPOEVIDENCECONST.INF_CONST_ALL);

    evidenceTypeAndDesc.evidenceType = CuramConst.gkEmpty;
    evidenceTypeAndDesc.evidenceDesc = messageAll.getMessage(
      TransactionInfo.getProgramLocale());

    listAllForActiveWorkspaceDtls.evidenceTypeList.dtls.addRef(
      evidenceTypeAndDesc);

    ParticipantIDNameDetails participantIDNameDetails = new ParticipantIDNameDetails();

    participantIDNameDetails.participantID = 0;
    participantIDNameDetails.participantName = messageAll.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00109753
    listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls.addRef(
      participantIDNameDetails);

    // Call method for retrieving the list of all active details
    CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = key.caseIDKey.caseID;

    ECActiveEvidenceDtlsList activeEvidenceList = EvidenceControllerFactory.newInstance().listActive(
      caseKey);

    // Create drop down lists and filter list of evidence
    for (int i = 0; i < activeEvidenceList.dtls.size(); i++) {

      // Add to participant drop down if this is not a duplicate
      boolean newParticipant = true;

      participantIDNameDetails = new ParticipantIDNameDetails();
      participantIDNameDetails.participantID = activeEvidenceList.dtls.item(i).participantID;
      participantIDNameDetails.participantName = activeEvidenceList.dtls.item(i).concernRoleName;

      for (int j = 0; j
        < listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls.size(); j++) {
        ParticipantIDNameDetails current = listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls.item(
          j);

        if (current.participantID == participantIDNameDetails.participantID) {
          newParticipant = false;
          break;
        }
      }

      if (newParticipant) {
        listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls.add(
          participantIDNameDetails);
      }

      // Add to evidence type drop down if this is not a duplicate
      boolean newEvidenceType = true;

      evidenceTypeAndDesc = new EvidenceTypeAndDesc();
      evidenceTypeAndDesc.evidenceType = activeEvidenceList.dtls.item(i).evidenceType;
      // BEGIN, CR00163098, JC
      evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
        CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      for (int j = 0; j
        < listAllForActiveWorkspaceDtls.evidenceTypeList.dtls.size(); j++) {
        EvidenceTypeAndDesc current = listAllForActiveWorkspaceDtls.evidenceTypeList.dtls.item(
          j);

        if (current.evidenceType.equals(evidenceTypeAndDesc.evidenceType)) {
          newEvidenceType = false;
          break;
        }
      }

      if (newEvidenceType) {
        listAllForActiveWorkspaceDtls.evidenceTypeList.dtls.add(
          evidenceTypeAndDesc);
      }

      if ((key.evidenceType.equals(CuramConst.gkEmpty)
        || evidenceTypeAndDesc.evidenceType.equals(key.evidenceType))
          && ((key.participantKey.key.participantID == 0)
            || (participantIDNameDetails.participantID
              == key.participantKey.key.participantID))) {

        listAllForActiveWorkspaceDtls.activeList.dtls.add(
          activeEvidenceList.dtls.item(i));

      }
    }

    sortListByParticipant(
      listAllForActiveWorkspaceDtls.participantIDNameDetailsList);
    sortListByEvidenceDesc(listAllForActiveWorkspaceDtls.evidenceTypeList);

    //
    // get the menu and the context details
    //

    // BEGIN, CR00080440, CR00122110, CD, VM
    listAllForActiveWorkspaceDtls.menuData = determineMenuData(key).menuData;

    listAllForActiveWorkspaceDtls.filteredEvidenceType = key.evidenceType;
    listAllForActiveWorkspaceDtls.filteredParticipantID = key.participantKey.key.participantID;

    // Set the context details
    listAllForActiveWorkspaceDtls.contextDescription = getContextDescription(
      caseKey);
    // END, CR00080440, CR00122110

    return listAllForActiveWorkspaceDtls;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all 'In Edit' and 'Pending Removal' evidences for a case, filtering 
   * by participant and evidenceType.
   *
   * @boread Evidence
   *
   * @boread Participant
   *
   * @boread Case
   *
   * @param key Contains a case identifier, participant identifier and an 
   * Evidence type code.
   *
   * @return List of 'In Edit' and 'Pending Removal' evidence
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ListAllForInEditWorkspaceDtls listAllForInEditWorkspace(
    CaseIDParticipantIDEvidenceTypeKey key) throws AppException,
      InformationalException {

    // create the return struct
    ListAllForInEditWorkspaceDtls listAllForInEditWorkspaceDtls = new ListAllForInEditWorkspaceDtls();

    //
    // Create default drop down "ALL" entries
    //

    EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();
    // BEGIN, CR00109753, SK
    LocalisableString messageAll = new LocalisableString(
      BPOEVIDENCECONST.INF_CONST_ALL);

    evidenceTypeAndDesc.evidenceType = CuramConst.gkEmpty;
    evidenceTypeAndDesc.evidenceDesc = messageAll.getMessage(
      TransactionInfo.getProgramLocale());

    listAllForInEditWorkspaceDtls.evidenceTypeList.dtls.add(evidenceTypeAndDesc);

    ParticipantIDNameDetails participantIDNameDetails = new ParticipantIDNameDetails();

    participantIDNameDetails.participantID = 0;
    participantIDNameDetails.participantName = messageAll.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00109753

    listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls.add(
      participantIDNameDetails);

    // Call method for retrieving the list of all in edit details
    CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = key.caseIDKey.caseID;

    ECWIPDtls ecWIPDtls = EvidenceControllerFactory.newInstance().listAllForInEditWorkspace(
      caseKey);

    // Add to drop down lists and filter list of "In Edit" evidence
    for (int i = 0; i < ecWIPDtls.newAndUpdateList.dtls.size(); i++) {

      // Add to participant drop down if this is not a duplicate
      boolean newParticipant = true;

      participantIDNameDetails = new ParticipantIDNameDetails();
      participantIDNameDetails.participantID = ecWIPDtls.newAndUpdateList.dtls.item(i).participantID;
      participantIDNameDetails.participantName = ecWIPDtls.newAndUpdateList.dtls.item(i).concernRoleName;

      for (int j = 0; j
        < listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls.size(); j++) {
        ParticipantIDNameDetails current = listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls.item(
          j);

        if (current.participantID == participantIDNameDetails.participantID) {
          newParticipant = false;
          break;
        }
      }

      if (newParticipant) {
        listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls.add(
          participantIDNameDetails);
      }

      // Add to evidence type drop down if this is not a duplicate
      boolean newEvidenceType = true;

      evidenceTypeAndDesc = new EvidenceTypeAndDesc();
      evidenceTypeAndDesc.evidenceType = ecWIPDtls.newAndUpdateList.dtls.item(i).evidenceType;
      // BEGIN, CR00163098, JC
      evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
        CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      for (int j = 0; j
        < listAllForInEditWorkspaceDtls.evidenceTypeList.dtls.size(); j++) {
        EvidenceTypeAndDesc current = listAllForInEditWorkspaceDtls.evidenceTypeList.dtls.item(
          j);

        if (current.evidenceType.equals(evidenceTypeAndDesc.evidenceType)) {
          newEvidenceType = false;
          break;
        }
      }

      if (newEvidenceType) {
        listAllForInEditWorkspaceDtls.evidenceTypeList.dtls.add(
          evidenceTypeAndDesc);
      }

      if ((key.evidenceType.equals(CuramConst.gkEmpty)
        || evidenceTypeAndDesc.evidenceType.equals(key.evidenceType))
          && ((key.participantKey.key.participantID == 0)
            || (participantIDNameDetails.participantID
              == key.participantKey.key.participantID))) {

        listAllForInEditWorkspaceDtls.wipDtls.newAndUpdateList.dtls.add(
          ecWIPDtls.newAndUpdateList.dtls.item(i));

      }
    }

    // Add to drop down lists and filter list of "Pending Removal" evidence
    for (int i = 0; i < ecWIPDtls.removeList.dtls.size(); i++) {

      // Add to participant drop down if this is not a duplicate
      boolean newParticipant = true;

      participantIDNameDetails = new ParticipantIDNameDetails();
      participantIDNameDetails.participantID = ecWIPDtls.removeList.dtls.item(i).participantID;
      participantIDNameDetails.participantName = ecWIPDtls.removeList.dtls.item(i).concernRoleName;

      for (int j = 0; j
        < listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls.size(); j++) {
        ParticipantIDNameDetails current = listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls.item(
          j);

        if (current.participantID == participantIDNameDetails.participantID) {
          newParticipant = false;
          break;
        }
      }

      if (newParticipant) {
        listAllForInEditWorkspaceDtls.participantIDNameDetailsList.dtls.add(
          participantIDNameDetails);
      }

      // Add to evidence type drop down if this is not a duplicate
      boolean newEvidenceType = true;

      evidenceTypeAndDesc = new EvidenceTypeAndDesc();
      evidenceTypeAndDesc.evidenceType = ecWIPDtls.removeList.dtls.item(i).evidenceType;
      // BEGIN, CR00163098, JC
      evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
        CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType,
        TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      for (int j = 0; j
        < listAllForInEditWorkspaceDtls.evidenceTypeList.dtls.size(); j++) {
        EvidenceTypeAndDesc current = listAllForInEditWorkspaceDtls.evidenceTypeList.dtls.item(
          j);

        if (current.evidenceType.equals(evidenceTypeAndDesc.evidenceType)) {
          newEvidenceType = false;
          break;
        }
      }

      if (newEvidenceType) {
        listAllForInEditWorkspaceDtls.evidenceTypeList.dtls.add(
          evidenceTypeAndDesc);
      }

      if ((key.evidenceType.equals(CuramConst.gkEmpty)
        || evidenceTypeAndDesc.evidenceType.equals(key.evidenceType))
          && ((key.participantKey.key.participantID == 0)
            || (participantIDNameDetails.participantID
              == key.participantKey.key.participantID))) {

        listAllForInEditWorkspaceDtls.wipDtls.removeList.dtls.add(
          ecWIPDtls.removeList.dtls.item(i));
      }
    }

    sortListByParticipant(
      listAllForInEditWorkspaceDtls.participantIDNameDetailsList);
    sortListByEvidenceDesc(listAllForInEditWorkspaceDtls.evidenceTypeList);
    sortInEditListByParticipantAndEvidenceDesc(
      listAllForInEditWorkspaceDtls.wipDtls);

    //
    // get the menu and the context details
    //

    // Set the menu and context details
    // BEGIN, CR00122110, VM
    listAllForInEditWorkspaceDtls.menuData = determineMenuData(key).menuData;
    // END, CR00122110

    // BEGIN, CR00080440, CD
    listAllForInEditWorkspaceDtls.filteredEvidenceType = key.evidenceType;
    listAllForInEditWorkspaceDtls.filteredParticipantID = key.participantKey.key.participantID;

    // Set the context details
    listAllForInEditWorkspaceDtls.contextDescription = getContextDescription(
      caseKey);
    // END, CR00080440

    // BEGIN, CR00119847, DG
    //
    // Set the indicator for the Synchronize evidence link
    //
    // Get the list of Indirect evidence to be synchronized for this case
    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    CaseIDAndStatusKey identicalKey = new CaseIDAndStatusKey();

    identicalKey.caseID = key.caseIDKey.caseID;
    identicalKey.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;

    CaseIDAndStatusKey nonIdenticalKey = new CaseIDAndStatusKey();

    nonIdenticalKey.caseID = key.caseIDKey.caseID;
    nonIdenticalKey.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;

    if (evidenceDescriptorObj.searchByCaseIDAndStatus(nonIdenticalKey).dtls.isEmpty()
      && evidenceDescriptorObj.searchByCaseIDAndStatus(identicalKey).dtls.isEmpty()) {
      listAllForInEditWorkspaceDtls.synchronizeLinkInd = false;
    } else {
      listAllForInEditWorkspaceDtls.synchronizeLinkInd = true;
    }
    // END, CR00119847

    return listAllForInEditWorkspaceDtls;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all top level evidence types and descriptions for a case. This is 
   * used primarily for retrieving the site map details. It is also used to 
   * populate the create evidence drop down list.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier.
   *
   * @return List of top level evidence types and descriptions
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceTypeAndDescList listTopLevelEvidenceTypesAndDescs(CaseKey key)
    throws AppException, InformationalException {

    return EvidenceControllerFactory.newInstance().listTopLevelEvidenceTypesAndDescs(
      key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns the site map details for the product.
   *
   * @boread Evidence
   *
   * @param key Contains the case identifier.
   *
   * @return The site map details for the SampleEGProduct product.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceSiteMapDetailsList readEvidenceSiteMapDetails(CaseKey key)
    throws AppException, InformationalException {

    return EvidenceControllerFactory.newInstance().readEvidenceSiteMapDetails(
      key);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns the input parameter, in this default implementation.
   *
   * @param key Contains the evidence type.
   *
   * @return Contains the evidence type.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceTypeDetails getEvidenceType(EvidenceTypeDetails key)
    throws AppException, InformationalException {

    return key;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns the input parameter, in this default implementation.
   *
   * @param key Contains the evidence type and participant identifier.
   *
   * @return Contains the evidence type and participant identifier.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceTypeAndParticipantIDDetails getEvidenceTypeAndParticipantID(
    EvidenceTypeAndParticipantIDDetails key) throws AppException,
      InformationalException {

    return key;
  }

  // END, CR00032741

  // BEGIN, CR00078225, CD
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Determines if the evidence type is of type 'Participant Data'.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Participant
   *
   * @param key Contains the evidence type of the participant data E.g. Person.
   *
   * @return Returns <code>true</code> if the evidence is of type 'Participant 
   * Data'. Otherwise <code>false</code> is returned in ParticipantDataInd 
   * return object.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ParticipantDataIndDetails isEvidenceParticipantData(EvidenceTypeKey key)
    throws AppException, InformationalException {

    // create the return struct
    ParticipantDataIndDetails participantDataIndDetails = new ParticipantDataIndDetails();

    // Call controller operation to determine if it's participant evidence
    participantDataIndDetails.participantDataInd = EvidenceControllerFactory.newInstance().isEvidenceParticipantData(
      key);

    return participantDataIndDetails;
  }

  // END, CR00078225

  // BEGIN, CR00080440, CD
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all evidence types along with their associated descriptions for a 
   * given case.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Contains a case identifier.
   *
   * @return List of evidence types and descriptions.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceTypeAndDescList listEvidenceTypeAndDesc(CaseKey key)
    throws AppException, InformationalException {

    // get all evidence for the case
    EvidenceTypeAndDescList evidenceTypeAndDescList = EvidenceControllerFactory.newInstance().listEvidenceTypeAndDesc(
      key);

    EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

    // Filter participant evidence out of the list.
    // As we are removing items from the list, work back from the end.
    for (int i = evidenceTypeAndDescList.dtls.size() - 1; i >= 0; i--) {
      evidenceTypeKey.evidenceType = evidenceTypeAndDescList.dtls.item(i).evidenceType;
      if (isEvidenceParticipantData(evidenceTypeKey).participantDataInd) {
        evidenceTypeAndDescList.dtls.remove(i);
      }
    }
    // BEGIN, CR00092862, CD
    // sort the list alphabetically by evidence description
    sortListByEvidenceDesc(evidenceTypeAndDescList);
    // END, CR00092862
    return evidenceTypeAndDescList;
  }

  // END, CR00080440

  // BEGIN, CR00119048, MR
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns case evidence tree details for an Evidence.
   *
   * @param key Case evidence tree key
   *
   * @return Case evidence tree details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public CaseEvidenceTreeDtls readCaseEvidenceTree(CaseEvidenceTreeKey key)
    throws AppException, InformationalException {

    // Details to be returned.
    CaseEvidenceTreeDtls caseEvidenceTreeDtls = new CaseEvidenceTreeDtls();

    // CaseEvidenceTree manipulation variables
    curam.core.sl.entity.intf.CaseEvidenceTree caseEvidenceTreeObj = curam.core.sl.entity.fact.CaseEvidenceTreeFactory.newInstance();

    try {
      caseEvidenceTreeDtls = caseEvidenceTreeObj.read(key);
    } catch (RecordNotFoundException e) {// do nothing.
    }
    // Return the details.
    return caseEvidenceTreeDtls;
  }

  // END, CR00119048

  // BEGIN, CR00121379, MR
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Retrieves evidence type description for an Evidence.
   *
   * @boread Evidence
   *
   * @param key Evidence type.
   *
   * @return Evidence type description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceTypeDescription getEvidenceTypeDescription(
    EvidenceTypeDetails key) throws AppException, InformationalException {

    // Details to be returned.
    EvidenceTypeDescription evidenceTypeDescription = new EvidenceTypeDescription();

    evidenceTypeDescription.evidenceTypeDesc = CodeTable.getOneItem(
      CASEEVIDENCE.TABLENAME, key.evidenceType,
      TransactionInfo.getProgramLocale());

    return evidenceTypeDescription;
  }

  // END, CR00121379

  // BEGIN, CR00122110, VM
  // ___________________________________________________________________________
  /**
   * Generates the menu data for a Product Delivery on an Integrated Case.
   *
   * @param key
   * - Contains the case identifier.
   *
   * @return Menu data for a product delivery.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  protected curam.core.facade.infrastructure.struct.MenuData getICProductDeliveryMenuData(
    CaseKey key) throws AppException, InformationalException {

    curam.core.facade.infrastructure.struct.MenuData menuData = new curam.core.facade.infrastructure.struct.MenuData();

    ProductHookManager productHookManager = new ProductHookManager();

    CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance().readCaseTypeCode(
      key);

    MenuData menuDataObj = productHookManager.getMenuDataHook(
      caseTypeCode.caseTypeCode);

    ICProductDeliveryMenuDataKey icMenuDataKey = new ICProductDeliveryMenuDataKey();

    icMenuDataKey.caseID = key.caseID;

    menuData.menuData = menuDataObj.getICProductDeliveryMenuData(icMenuDataKey).menuData;

    return menuData;
  }

  // ___________________________________________________________________________
  /**
   * Returns the Menu Data for an Integrated Case.
   *
   * @param key
   * - Integrated Case identifier.
   *
   * @return Menu Data for the Integrated Case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  protected curam.core.facade.infrastructure.struct.MenuData getIntegratedCaseMenuData(
    IntegratedCaseMenuDataKey key) throws AppException,
      InformationalException {

    curam.core.facade.infrastructure.struct.MenuData menuData = new curam.core.facade.infrastructure.struct.MenuData();

    CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance().readCaseTypeCode(
      caseKey);

    ProductHookManager productHookManager = new ProductHookManager();

    MenuData menuDataObj = productHookManager.getMenuDataHook(
      caseTypeCode.caseTypeCode);

    menuData.menuData = menuDataObj.getIntegratedCaseMenuData(key).menuData;

    return menuData;
  }

  // ___________________________________________________________________________
  /**
   * Function to determine the correct menu data for a case. This will differ
   * depending on whether the case is an Integrated Case or a Product Delivery
   * within an Integrated Case.
   *
   * @param key
   * - Contains the identifier of the case whose menu data is being
   * retrieved.
   * @return The menu data for the case
   *
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  protected curam.core.facade.infrastructure.struct.MenuData determineMenuData(
    CaseIDParticipantIDEvidenceTypeKey key) throws AppException,
      InformationalException {

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseIDKey.caseID;

    CaseHeaderDtls caseHeaderDtls = CaseHeaderFactory.newInstance().read(
      caseHeaderKey);

    if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {

      IntegratedCaseMenuDataKey integratedCaseMenuDataKey = new IntegratedCaseMenuDataKey();

      integratedCaseMenuDataKey.caseID = key.caseIDKey.caseID;

      return getIntegratedCaseMenuData(integratedCaseMenuDataKey);

    } else if (caseHeaderDtls.caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY)) {

      if (caseHeaderDtls.integratedCaseID != 0) {

        CaseKey caseKey = new CaseKey();

        caseKey.caseID = key.caseIDKey.caseID;

        return getICProductDeliveryMenuData(caseKey);
      }
    }

    return null;
  }

  // END, CR00122110

  // ___________________________________________________________________________
  // BEGIN CR00199453, MC
  
  // BEGIN, CR00397587, PS
  /**
   * Returns a list of evidence instance for the supplied key. Evidence 
   * instance represent a group of evidence types having the same succession 
   * id.
   *
   * @boread Evidence
   *
   * @boread Participant
   *
   * @param key The key based on which the evidence instance list is filtered.
   *
   * @return the list of evidence instances.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceTypeWorkspaceListDetails listDistinctEvidence(
    final EvidenceTypeWorkspaceKey key) throws AppException,
      InformationalException {
    final EvidenceTypeWorkspaceListDetails evidenceListDetails = new EvidenceTypeWorkspaceListDetails();
    final EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    final CaseKey caseKey = new CaseKey();
    final EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();
    final LocalisableString messageAll = new LocalisableString(
      BPOEVIDENCECONST.INF_CONST_ALL);
    Map<Long, String> participantMap = new Hashtable<Long, String>();
    ParticipantIDNameDetails participantIDNameDetails = new ParticipantIDNameDetails();

    evidenceListDetails.dtls = evidenceControllerObj.listEvidenceTypes(key);
    caseKey.caseID = key.caseID;
    evidenceListDetails.contextDescription.contextDescription = getContextDescription(caseKey).contextDescription;

    // Create default drop down "ALL" entries.
    evidenceTypeAndDesc.evidenceType = CuramConst.gkEmpty;
    evidenceTypeAndDesc.evidenceDesc = messageAll.getMessage(
      TransactionInfo.getProgramLocale());
    participantIDNameDetails.participantID = 0;
    participantIDNameDetails.participantName = messageAll.getMessage(
      TransactionInfo.getProgramLocale());
    evidenceListDetails.participantList.dtls.add(participantIDNameDetails);

    // Add to drop down lists to filter by participant.
    for (EvidenceTypeWorkspaceDetails evidenceTypeWorkspaceDetails : evidenceListDetails.dtls.list.items()) {
      participantIDNameDetails = new ParticipantIDNameDetails();
      participantIDNameDetails.participantID = evidenceTypeWorkspaceDetails.participantID;
      participantIDNameDetails.participantName = evidenceTypeWorkspaceDetails.concernRoleName;
      participantMap = new Hashtable<Long, String>();
      participantMap.put(participantIDNameDetails.participantID,
        participantIDNameDetails.participantName);
    }

    if (!participantMap.isEmpty()) {
      Iterator<Long> iterate = participantMap.keySet().iterator();

      while (iterate.hasNext()) {
        participantIDNameDetails = new ParticipantIDNameDetails();
        participantIDNameDetails.participantID = iterate.next();
        participantIDNameDetails.participantName = participantMap.get(
          participantIDNameDetails.participantID);
        evidenceListDetails.participantList.dtls.add(participantIDNameDetails);
      }
    }
    evidenceListDetails.evidenceType = CodeTable.getOneItemForUserLocale(
      CASEEVIDENCE.TABLENAME, key.evidenceType);
    return evidenceListDetails;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns a list of evidence instance for the supplied key on search. 
   * Evidence instance represent a group of evidence types having the same 
   * succession id.
   *
   * @boread Evidence
   *
   * @param key The key based on which the evidence instance list is filtered.
   *
   * @return the list of evidence instances.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceTypeWorkspaceListDetails listDistinctEvidenceOnSearch(
    final EvidenceTypeWorkspaceKey key) throws AppException,
      InformationalException {
    final EvidenceTypeWorkspaceListDetails evidenceListDetails = listDistinctEvidence(
      key);

    evidenceListDetails.isSearch = true;
    return evidenceListDetails;
  }

  // BEGIN, CR00397587, PS
  /**
   * Sets the evidence status within the <code>EvidenceDescriptor</code> entity 
   * to <code>EvidenceDescriptorStatus.CANCELLED</code>. The input key to this 
   * method contains the evidence descriptor id, based on which the succession 
   * id of the evidence type is retrieved. All <code>EvidenceDescriptor</code> 
   * records having this succession id will have it's status set to canceled.
   *
   * @boread Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key ID of the deleted Evidence to be canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public void deleteEvidenceFromWorkspace(final EvidenceDescriptorKey key)
    throws AppException, InformationalException {
    final EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    evidenceControllerObj.deleteEvidenceFromWorkspace(key);
  }

  // END, CR00199453
  // BEGIN, CR00204924, GSP

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Lists all 'Active' evidences for a case, filtering by participant and 
   * evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Participant
   *
   * @param key Contains a case identifier, participant identifier and an 
   * evidence type.
   *
   * @return List of 'Active' evidence instance details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ListAllActiveEVDInstanceWorkspaceDtls listAllActiveEVDInstanceWorkspaceDtls(
    CaseIDParticipantIDEvidenceTypeKey key) throws AppException,
      InformationalException {

    // create the return struct
    ListAllActiveEVDInstanceWorkspaceDtls listAllForActiveWorkspaceDtls = new ListAllActiveEVDInstanceWorkspaceDtls();

    // Create default drop down "ALL" entries
    EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();

    LocalisableString messageAll = new LocalisableString(
      curam.message.BPOEVIDENCECONST.INF_CONST_ALL);

    evidenceTypeAndDesc.evidenceType = CuramConst.gkEmpty;
    evidenceTypeAndDesc.evidenceDesc = messageAll.getMessage(
      TransactionInfo.getProgramLocale());

    listAllForActiveWorkspaceDtls.evidenceTypeList.dtls.addRef(
      evidenceTypeAndDesc);

    ParticipantIDNameDetails participantIDNameDetails = new ParticipantIDNameDetails();

    participantIDNameDetails.participantID = 0;
    participantIDNameDetails.participantName = messageAll.getMessage(
      TransactionInfo.getProgramLocale());
    listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls.addRef(
      participantIDNameDetails);

    // Call method for retrieving the list of all active details
    CaseKey caseKey = new curam.core.struct.CaseKey();

    caseKey.caseID = key.caseIDKey.caseID;

    ActiveEvdInstanceDtlsList activeEvdInstanceDtlsList = EvidenceControllerFactory.newInstance().listAllactiveEvdInstances(
      caseKey);

    // Create drop down lists and filter list of evidence
    for (int i = 0; i < activeEvdInstanceDtlsList.dtls.size(); i++) {

      // Add to participant drop down if this is not a duplicate
      boolean newParticipant = true;

      participantIDNameDetails = new ParticipantIDNameDetails();
      participantIDNameDetails.participantID = activeEvdInstanceDtlsList.dtls.item(i).participantID;
      participantIDNameDetails.participantName = activeEvdInstanceDtlsList.dtls.item(i).concernRoleName;

      for (int j = 0; j
        < listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls.size(); j++) {
        ParticipantIDNameDetails current = listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls.item(
          j);

        if (current.participantID == participantIDNameDetails.participantID) {
          newParticipant = false;
          break;
        }
      }

      if (newParticipant) {
        listAllForActiveWorkspaceDtls.participantIDNameDetailsList.dtls.add(
          participantIDNameDetails);
      }

      // Add to evidence type drop down if this is not a duplicate
      boolean newEvidenceType = true;

      evidenceTypeAndDesc = new EvidenceTypeAndDesc();
      evidenceTypeAndDesc.evidenceType = activeEvdInstanceDtlsList.dtls.item(i).evidenceType;
      evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
        CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType,
        TransactionInfo.getProgramLocale());

      for (int j = 0; j
        < listAllForActiveWorkspaceDtls.evidenceTypeList.dtls.size(); j++) {
        EvidenceTypeAndDesc current = listAllForActiveWorkspaceDtls.evidenceTypeList.dtls.item(
          j);

        if (current.evidenceType.equals(evidenceTypeAndDesc.evidenceType)) {
          newEvidenceType = false;
          break;
        }
      }

      if (newEvidenceType) {
        listAllForActiveWorkspaceDtls.evidenceTypeList.dtls.add(
          evidenceTypeAndDesc);
      }

      if ((key.evidenceType.equals(CuramConst.gkEmpty)
        || evidenceTypeAndDesc.evidenceType.equals(key.evidenceType))
          && ((key.participantKey.key.participantID == 0)
            || (participantIDNameDetails.participantID
              == key.participantKey.key.participantID))) {

        listAllForActiveWorkspaceDtls.activeEvdInstanceDtlsList.dtls.add(
          activeEvdInstanceDtlsList.dtls.item(i));
      }
    }

    sortListByParticipant(
      listAllForActiveWorkspaceDtls.participantIDNameDetailsList);
    sortListByEvidenceDesc(listAllForActiveWorkspaceDtls.evidenceTypeList);

    // get the filter and the context details
    listAllForActiveWorkspaceDtls.filteredEvidenceType = key.evidenceType;
    listAllForActiveWorkspaceDtls.filteredParticipantID = key.participantKey.key.participantID;

    // Set the context details
    listAllForActiveWorkspaceDtls.contextDescription = getContextDescription(
      caseKey);

    // BEGIN, CR00242523, CSH
    VerificationInterface verificationObj = evidenceVerification.getVerificationImpl();

    int numVerifications = verificationObj.listOutstandingVerificationsForCase(key.caseIDKey).dtls.size();
    // BEGIN, CR00222660, PF
    int numIssues = evidenceIssues.listIssuesForCase(key.caseIDKey.caseID).dtls.size();

    // END, CR00222660

    if ((numVerifications > 0) || (numIssues > 0)) {
      listAllForActiveWorkspaceDtls.hasVerificationsOrIssues = true;
    } else {
      listAllForActiveWorkspaceDtls.hasVerificationsOrIssues = false;
    }
    // END, CR00242523

    return listAllForActiveWorkspaceDtls;
  }

  // BEGIN, CR00397587, PS
  /**
   * Lists all succession evidence changes on an 'Active' evidence instance.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier, participant identifier and evidence 
   * type.
   *
   * @return List of evidence instance changes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvdInstanceChangeDtlsList listActiveEvdInstanceChanges(
    curam.core.sl.infrastructure.entity.struct.SuccessionID key)
    throws AppException, InformationalException {
    final EvidenceController evidenceController = EvidenceControllerFactory.newInstance();
    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList = evidenceController.listActiveEvdInstanceChanges(
      key);

    // BEGIN, CR00287546, ELG
    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsListRet = new EvdInstanceChangeDtlsList();

    // BEGIN, CR00242523, CSH
    evdInstanceChangeDtlsListRet.verificationOrIssuesExist = false;

    for (EvdInstanceChangeDtls details : evdInstanceChangeDtlsList.dtlsList) {

      if ((details.verificationOrIssuesExist)
        && (!evdInstanceChangeDtlsListRet.verificationOrIssuesExist)) {
        // Indicates if any of the list items has a verification or issue
        evdInstanceChangeDtlsListRet.verificationOrIssuesExist = true;
      }

      if ((!details.statusCode.equals(EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT))
        && (!details.statusCode.equals(
          EVIDENCEDESCRIPTORSTATUS.IDENTICALREJECTED))) {
        evdInstanceChangeDtlsListRet.dtlsList.addRef(details);
      }

    }
    // END, CR00242523

    // BEGIN, CR00250011, PMD
    if (Configuration.getBooleanProperty(EnvVars.ENV_EVIDENCE_BROKER_ENABLED)) {
      evdInstanceChangeDtlsListRet.evdBrokerEnabled = true;
    }
    // END, CR00250011
    evdInstanceChangeDtlsListRet.inEditExistInd = evdInstanceChangeDtlsList.inEditExistInd;

    return evdInstanceChangeDtlsListRet;
    // END, CR00287546

  }

  // BEGIN, CR00397587, PS
  // ____________________________________________________________________________
  /**
   * Lists all succession evidence changes on an Evidence instance.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier, participant identifier and evidence 
   * type.
   *
   * @return List of evidence instance changes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvdInstanceChangeDtlsList listEvdInstanceChanges(SuccessionID key)
    throws AppException, InformationalException {

    final EvidenceController evidenceController = EvidenceControllerFactory.newInstance();

    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList = evidenceController.listEvdInstanceChanges(
      key);

    // BEGIN, CR00389944, ZV
    String displayDeletedEvidence = Configuration.getProperty(
      EnvVars.ENV_DISPLAY_DELETED_EVIDENCE);

    if (displayDeletedEvidence == null) {
      displayDeletedEvidence = EnvVars.ENV_DISPLAY_DELETED_EVIDENCE;
    }
    
    boolean displayDeletedEvidenceInd = displayDeletedEvidence.equals(
      EnvVars.ENV_VALUE_YES);
    
    // BEGIN, CR00287546, ELG
    // return structure
    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsListRet = new EvdInstanceChangeDtlsList();

    // BEGIN, CR00242523, CSH
    evdInstanceChangeDtlsListRet.verificationOrIssuesExist = false;
    for (EvdInstanceChangeDtls details : evdInstanceChangeDtlsList.dtlsList) {

      if ((details.verificationOrIssuesExist)
        && (!evdInstanceChangeDtlsListRet.verificationOrIssuesExist)) {
        // Indicates if any of the list items has a verification or issue
        evdInstanceChangeDtlsListRet.verificationOrIssuesExist = true;
      }
      
      if ((!details.statusCode.equals(EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT))
        && (!details.statusCode.equals(
          EVIDENCEDESCRIPTORSTATUS.IDENTICALREJECTED)) 
          && (displayDeletedEvidenceInd 
            || !details.statusCode.equals(EVIDENCEDESCRIPTORSTATUS.CANCELED))) {
        evdInstanceChangeDtlsListRet.dtlsList.addRef(details);
      }
       
    }
    // END, CR00242523
    // END, CR00389944

    // BEGIN, CR00250011, PMD
    if (Configuration.getBooleanProperty(EnvVars.ENV_EVIDENCE_BROKER_ENABLED)) {
      evdInstanceChangeDtlsListRet.evdBrokerEnabled = true;
    }
    // END, CR00250011

    evdInstanceChangeDtlsListRet.inEditExistInd = evdInstanceChangeDtlsList.inEditExistInd;

    return evdInstanceChangeDtlsListRet;
    // END, CR00287546

  }

  // BEGIN, CR00397587, PS
  /**
   * Lists all succession evidence changes on an 'In Edit' evidence instance.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier, participant identifier and evidence 
   * type.
   *
   * @return List of evidence instance changes.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvdInstanceChangeDtlsList listInEditEvdInstanceChanges(
    final SuccessionID key) throws AppException, InformationalException {

    final EvidenceController evidenceController = EvidenceControllerFactory.newInstance();

    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList = evidenceController.listInEditEvdInstanceChanges(
      key);

    // BEGIN, CR00242523, CSH
    // Check if any issues or verifications exist
    evdInstanceChangeDtlsList.verificationOrIssuesExist = false;
    for (int i = 0; i < evdInstanceChangeDtlsList.dtlsList.size(); i++) {

      if (evdInstanceChangeDtlsList.dtlsList.item(i).verificationOrIssuesExist) {

        // Indicates if any of the list items has a verification or issue
        evdInstanceChangeDtlsList.verificationOrIssuesExist = true;
        break;
      }
    }
    // END, CR00242523

    // BEGIN, CR00250011, PMD
    if (Configuration.getBooleanProperty(EnvVars.ENV_EVIDENCE_BROKER_ENABLED)) {
      evdInstanceChangeDtlsList.evdBrokerEnabled = true;
    }
    // END, CR00250011

    return evdInstanceChangeDtlsList;
  }

  // END, CR00204924

  // BEGIN, CR00397587, PS
  /**
   * Returns a list of evidence types grouped by categories and parent evidence 
   * types as an XML string to be displayed on the evidence dash-board.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Contains a case identifier and a participant identifier.
   *
   * @return Evidence types in an XML string format.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceSiteMapDetails getEvidenceDashboardData(CaseIDAndParticipantIDDetails key)
    throws AppException, InformationalException {
     
    // BEGIN, CR00295440, PMD
    EvidenceSiteMapDetails evidenceSiteMapDetails = new EvidenceSiteMapDetails();

    // Instance of helper class to build the XML
    final XMLBuilder xml = new XMLBuilder(
      EvidenceDashboardConst.kEvidenceDashboard);

    xml.addAttribute(EvidenceDashboardConst.kCaseID, Long.toString(key.caseID));

    // BEGIN, CR00233058, DG
    final LocalisableString issueText = new LocalisableString(
      EVIDENCEDASHBOARD.INF_ISSUE_TEXT);
    final LocalisableString verificationText = new LocalisableString(
      EVIDENCEDASHBOARD.INF_VERIFICATION_TEXT);
    final LocalisableString ineditText = new LocalisableString(
      EVIDENCEDASHBOARD.INF_INEDIT_TEXT);
    final LocalisableString notRecordedText = new LocalisableString(
      EVIDENCEDASHBOARD.INF_NOT_RECORDED_TEXT);
    final LocalisableString recordedText = new LocalisableString(
      EVIDENCEDASHBOARD.INF_RECORDED_TEXT);
    final LocalisableString allText = new LocalisableString(
      EVIDENCEDASHBOARD.INF_ALL_TEXT);

    xml.addAttribute(EvidenceDashboardConst.kIssueText,
      issueText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kVerificationText,
      verificationText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kIneditText,
      ineditText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kNotRecordedText,
      notRecordedText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kRecordedText,
      recordedText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kAllText,
      allText.getMessage(TransactionInfo.getProgramLocale()));
    // END, CR00233058

    // BEGIN, CR00289015, SD
    // Accessibility related text being added
    final LocalisableString selectedText = new LocalisableString(
      EVIDENCEDASHBOARD.INF_ACCESS_SELECTED_TEXT);
    final LocalisableString expandText = new LocalisableString(
      EVIDENCEDASHBOARD.INF_ACCESS_STATE_EXPAND_TEXT);
    final LocalisableString collapseText = new LocalisableString(
      EVIDENCEDASHBOARD.INF_ACCESS_STATE_COLLAPSE_TEXT);

    xml.addAttribute(EvidenceDashboardConst.kSelectedText,
      selectedText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kExpandText,
      expandText.getMessage(TransactionInfo.getProgramLocale()));
    xml.addAttribute(EvidenceDashboardConst.kCollapseText,
      collapseText.getMessage(TransactionInfo.getProgramLocale()));
    // END, CR00289015

    EvidenceDashboardDetailsList evidenceDashboardDetailsList = EvidenceTypeFactory.newInstance().getEvidenceDashboardDetails(
      key);

    String currentCategory = "";
    String locale = TransactionInfo.getProgramLocale();
    boolean categoryProcessed = false;

    EvidenceCatDashboardDetailsList evidenceCatDashboardDetailsList = new EvidenceCatDashboardDetailsList();
    EvidenceCatDashboardDetails evidenceCatDashboardDetails = null;
    EvidenceTypeDashboardDetailsList evidenceTypeDashboardDetailsList = null;

    Comparator<EvidenceCatDashboardDetails> evidenceCategoryComparator = new SortDashboardEvdCategoriesBySortOrderAndDesc();
    Comparator<EvidenceTypeDashboardDetails> evidenceTypeComparator = new SortDashboardEvdTypesBySortOrderAndDesc();

    CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey = new CaseIDAndEvidenceTypeKey();

    caseIDAndEvidenceTypeKey.caseID = key.caseID;
    // BEGIN, CR00361859, CSH
    // Sort this list by category
    if (!evidenceDashboardDetailsList.dtls.isEmpty()) {
      Collections.sort(evidenceDashboardDetailsList.dtls,
        new Comparator<EvidenceDashboardDetails>() {
        public int compare(final EvidenceDashboardDetails obj1,
          final EvidenceDashboardDetails obj2) {

          // BEGIN, CR00434343, JAY
          String type1 = CodetableUtil.getCachedCodetableDescription(
            EVIDENCECATEGORY.TABLENAME, obj1.category);
          String type2 = CodetableUtil.getCachedCodetableDescription(
            EVIDENCECATEGORY.TABLENAME, obj2.category);

          // END, CR00434343, JAY
          
          return type1.compareTo(type2);
        }
      });
    }
    // END, CR00361859

    // Get all relevant category and evidence type details and sort into the correct order
    for (EvidenceDashboardDetails evidenceDashboardDetails : evidenceDashboardDetailsList.dtls) {
      if (!currentCategory.equals(evidenceDashboardDetails.category)
        || !categoryProcessed) {

        if (categoryProcessed) {
          Collections.sort(evidenceTypeDashboardDetailsList.evdTypeDetails,
            evidenceTypeComparator);
          evidenceCatDashboardDetails.evdTypeList = evidenceTypeDashboardDetailsList;
          evidenceCatDashboardDetailsList.evdCatDetails.addRef(
            evidenceCatDashboardDetails);
        }

        currentCategory = evidenceDashboardDetails.category;
        evidenceCatDashboardDetails = new EvidenceCatDashboardDetails();
        evidenceCatDashboardDetails.category = evidenceDashboardDetails.category;
        evidenceCatDashboardDetails.description = CodeTable.getOneItem(
          EVIDENCECATEGORY.TABLENAME, evidenceDashboardDetails.category, locale);
        evidenceCatDashboardDetails.sortOrder = CodeTable.sortOrder(
          EVIDENCECATEGORY.TABLENAME, currentCategory, locale);
        categoryProcessed = true;
        evidenceTypeDashboardDetailsList = new EvidenceTypeDashboardDetailsList();
      }

      EvidenceTypeDashboardDetails evidenceTypeDashboardDetails = new EvidenceTypeDashboardDetails();

      evidenceTypeDashboardDetails.type = evidenceDashboardDetails.evidenceType;
      evidenceTypeDashboardDetails.description = CodeTable.getOneItem(
        CASEEVIDENCE.TABLENAME, evidenceDashboardDetails.evidenceType, locale);
      evidenceTypeDashboardDetails.sortOrder = evidenceDashboardDetails.sortOrder;
      evidenceTypeDashboardDetails.inEditCount = evidenceDashboardDetails.inEditCount;
      evidenceTypeDashboardDetails.isRecorded = evidenceDashboardDetails.isRecorded;

      if (evidenceDashboardDetails.isRecorded) {
        caseIDAndEvidenceTypeKey.evidenceType = evidenceDashboardDetails.evidenceType;
        evidenceTypeDashboardDetails.numVerifications = evidenceVerification.getVerificationImpl().listOutstandingVerificationForEvidenceWorkspace(caseIDAndEvidenceTypeKey).verificationDtls.size();
        evidenceTypeDashboardDetails.numIssues = evidenceIssues.listIssuesForEvidenceType(key.caseID, CASEEVIDENCEEntry.get(evidenceDashboardDetails.evidenceType)).dtls.size();
      }

      evidenceTypeDashboardDetailsList.evdTypeDetails.addRef(
        evidenceTypeDashboardDetails);
    }

    if (evidenceTypeDashboardDetailsList != null
      && !evidenceTypeDashboardDetailsList.evdTypeDetails.isEmpty()) {
      Collections.sort(evidenceTypeDashboardDetailsList.evdTypeDetails,
        evidenceTypeComparator);
      evidenceCatDashboardDetails.evdTypeList = evidenceTypeDashboardDetailsList;
      evidenceCatDashboardDetailsList.evdCatDetails.addRef(
        evidenceCatDashboardDetails);

      Collections.sort(evidenceCatDashboardDetailsList.evdCatDetails,
        evidenceCategoryComparator);
    }

    for (EvidenceCatDashboardDetails xmlCatDashboardDetails : evidenceCatDashboardDetailsList.evdCatDetails) {

      xml.createTag(EvidenceDashboardConst.kEvidenceCategory);
      xml.addAttribute(EvidenceDashboardConst.kEvidenceCategoryName,
        xmlCatDashboardDetails.description);
      xml.addAttribute(EvidenceDashboardConst.kSortOrder,
        String.valueOf(xmlCatDashboardDetails.sortOrder));

      for (EvidenceTypeDashboardDetails xmlEvidenceTypeDashboardDetails : xmlCatDashboardDetails.evdTypeList.evdTypeDetails) {

        xml.createTag(EvidenceDashboardConst.kEvidence);
        xml.addAttribute(EvidenceDashboardConst.kEvidenceName,
          xmlEvidenceTypeDashboardDetails.description);
        xml.addAttribute(EvidenceDashboardConst.kEvidenceType,
          xmlEvidenceTypeDashboardDetails.type);
        xml.addAttribute(EvidenceDashboardConst.kInEdit,
          Integer.toString(xmlEvidenceTypeDashboardDetails.inEditCount));

        if (xmlEvidenceTypeDashboardDetails.isRecorded) {
          xml.addAttribute(EvidenceDashboardConst.kIsRecorded,
            EvidenceDashboardConst.kTrue);
        } else {
          xml.addAttribute(EvidenceDashboardConst.kIsRecorded,
            EvidenceDashboardConst.kFalse);
        }

        xml.addAttribute(EvidenceDashboardConst.kVerifications,
          Integer.toString(xmlEvidenceTypeDashboardDetails.numVerifications));
        xml.addAttribute(EvidenceDashboardConst.kIssues,
          Integer.toString(xmlEvidenceTypeDashboardDetails.numIssues));
        xml.addAttribute(EvidenceDashboardConst.kSortOrder,
          Long.toString(xmlEvidenceTypeDashboardDetails.sortOrder));
        xml.closeTag(); // </EVIDENCE>
      }
      xml.closeTag(); // </EVIDENCE_CATEGORY>
    }

    xml.closeTag(); // </EVIDENCE_DASHBOARD>

    evidenceSiteMapDetails.evidenceTypes = xml.getXmlString();
    // END, CR00295440

    return evidenceSiteMapDetails;
  }

  // BEGIN, CR00230454, ELG
  /**
   * Gets sorted evidence category details set from the
   * EvidenceTypeAdminDetailsList list.
   *
   * @param detailsList
   * Contains EvidenceTypeAdminDetailsList.
   * @param addAllAndPreferedInd
   * Flag to indicate should 'All' and 'Preferred' categories be added
   * to the sorted set.
   * @return Sorted set of evidence category details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected SortedSet<EvidenceCategoryDetails> getSortedEvidenceCategoriesFromList(
    final EvidenceTypeAdminDetailsList detailsList,
    final boolean addAllAndPreferedInd) throws AppException,
      InformationalException {

    // BEGIN, CR00296357, ELG
    // Return set.
    SortedSet<EvidenceCategoryDetails> evidenceCategories;

    if (addAllAndPreferedInd) {

      // get a list of unique categories on the case
      evidenceCategories = new TreeSet<EvidenceCategoryDetails>(
        new SortEvidenceCategoryBySortOrderAndNameComparator());

      final String locale = TransactionInfo.getProgramLocale();

      evidenceCategories.add(
        new EvidenceCategoryDetails(EVIDENCECATEGORY.ALL,
        CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME, EVIDENCECATEGORY.ALL,
        locale),
        CodeTable.sortOrder(EVIDENCECATEGORY.TABLENAME, EVIDENCECATEGORY.ALL,
        locale)));

      evidenceCategories.add(
        new EvidenceCategoryDetails(EVIDENCECATEGORY.PREFERRED,
        CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME,
        EVIDENCECATEGORY.PREFERRED, locale),
        CodeTable.sortOrder(EVIDENCECATEGORY.TABLENAME,
        EVIDENCECATEGORY.PREFERRED, locale)));

      evidenceCategories = getSortedEvidenceCategoriesFromListToSet(
        evidenceCategories, detailsList);

    } else {

      evidenceCategories = getSortedEvidenceCategoriesFromListToSet(null,
        detailsList);

    }
    // END, CR00296357

    return evidenceCategories;

  }

  // END, CR00230454

  // BEGIN, CR00296357, ELG
  /**
   * Adds EvidenceTypeAdminDetailsList list items to the sorted set specified.
   * If the sorted set is not specified, then this method creates the
   * new sorted set and then populates it using the list items from
   * EvidenceTypeAdminDetailsList. After adding the list items it returns
   * the sorted set. This utility method intended for local use only.
   *
   * @param evidenceCategorySet
   * Contains sorted set of evidence category details to which the
   * list item data must be added.
   * @param detailsList
   * Contains EvidenceTypeAdminDetailsList list.
   * @return Sorted set of evidence category details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected SortedSet<EvidenceCategoryDetails> getSortedEvidenceCategoriesFromListToSet(
    final SortedSet<EvidenceCategoryDetails> evidenceCategorySet,
    final EvidenceTypeAdminDetailsList detailsList) throws AppException,
      InformationalException {

    // Return set.
    SortedSet<EvidenceCategoryDetails> evidenceCategories;

    if (evidenceCategorySet == null) {
      evidenceCategories = new TreeSet<EvidenceCategoryDetails>(
        new SortEvidenceCategoryBySortOrderAndNameComparator());
    } else {
      evidenceCategories = evidenceCategorySet;
    }

    final String locale = TransactionInfo.getProgramLocale();

    for (EvidenceTypeAdminDetails evidenceTypeAdminDetails : detailsList.dtls.items()) {

      EvidenceCategoryDetails evidenceCategoryDetails = new EvidenceCategoryDetails(
        evidenceTypeAdminDetails.category,
        CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME,
        evidenceTypeAdminDetails.category, locale),
        CodeTable.sortOrder(EVIDENCECATEGORY.TABLENAME,
        evidenceTypeAdminDetails.category, locale));

      // Add new categories to the list.
      if (!evidenceCategories.contains(evidenceCategoryDetails)) {
        evidenceCategories.add(evidenceCategoryDetails);
      }

    }

    return evidenceCategories;

  }

  /**
   * Gets sorted evidence category details set from the
   * EvidenceTypeAdminDetailsList list.
   *
   * @param detailsList
   * Contains EvidenceTypeAdminDetailsList.
   * @param addAllAndPreferedInd
   * Flag to indicate should 'All' and 'Preferred' categories be added
   * to the sorted set.
   * @param caseID Unique ID of the case for which evidence category details
   * must be retrieved.
   * @return Sorted set of evidence category details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected SortedSet<EvidenceCategoryDetails> getSortedEvidenceCategoriesFromListForCase(
    final EvidenceTypeAdminDetailsList detailsList,
    final boolean addAllAndPreferedInd, final long caseID) throws AppException,
      InformationalException {

    // get a list of unique categories on the case
    final SortedSet<EvidenceCategoryDetails> evidenceCategories = new TreeSet<EvidenceCategoryDetails>(
      new SortEvidenceCategoryBySortOrderAndNameComparator());

    final String locale = TransactionInfo.getProgramLocale();

    if (addAllAndPreferedInd) {

      final CaseKey caseKey = new CaseKey();

      caseKey.caseID = caseID;

      // Get evidence types
      final EvidenceTypeAdminDetailsList evidenceTypeAdminDetailsList = EvidenceControllerFactory.newInstance().listEvidenceTypes(
        caseKey);

      boolean preferredFoundInd = false;

      // Check are there any preferred evidence types
      for (EvidenceTypeAdminDetails evidenceTypeAdminDetails : evidenceTypeAdminDetailsList.dtls.items()) {

        if ((!evidenceTypeAdminDetails.participantDataInd)
          && evidenceTypeAdminDetails.quickLinkInd) {
          preferredFoundInd = true;
          break;
        }

      }

      if (preferredFoundInd) {

        evidenceCategories.add(
          new EvidenceCategoryDetails(EVIDENCECATEGORY.PREFERRED,
          CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME,
          EVIDENCECATEGORY.PREFERRED, locale),
          CodeTable.sortOrder(EVIDENCECATEGORY.TABLENAME,
          EVIDENCECATEGORY.PREFERRED, locale)));

      }

      evidenceCategories.add(
        new EvidenceCategoryDetails(EVIDENCECATEGORY.ALL,
        CodeTable.getOneItem(EVIDENCECATEGORY.TABLENAME, EVIDENCECATEGORY.ALL,
        locale),
        CodeTable.sortOrder(EVIDENCECATEGORY.TABLENAME, EVIDENCECATEGORY.ALL,
        locale)));

    }

    return getSortedEvidenceCategoriesFromListToSet(evidenceCategories,
      detailsList);

  }
  // END, CR00296357



  /*
   * protected class to represent an evidence type in the dash board data
   */
  protected class EvidenceXMLDetails {

    String name;

    String evidenceType;

    int inEdit;

    boolean isRecorded;

    int verifications;

    int issues;

    long sortOrder;

    EvidenceXMLDetails(String name, String evidenceType, int inEdit,
      boolean isRecorded, int verifications, int issues, long sortOrder) {
      this.name = name;
      this.evidenceType = evidenceType;
      this.inEdit = inEdit;
      this.isRecorded = isRecorded;
      this.verifications = verifications;
      this.issues = issues;
      this.sortOrder = sortOrder;
    }

    public boolean equals(Object o) {
      return this.evidenceType.equals(((EvidenceXMLDetails) o).evidenceType);
    }
  }


  // ___________________________________________________________________________
  /**
   * SortEvidenceXMLDetailsBySortOrderAndName Comparator.
   */
  protected class SortEvidenceXMLDetailsBySortOrderAndNameComparator implements
    Comparator<EvidenceXMLDetails> {

    public SortEvidenceXMLDetailsBySortOrderAndNameComparator() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sort based on evidence category code sort order and name.
     */
    public int compare(final EvidenceXMLDetails o1, final EvidenceXMLDetails o2) {

      int result = Long.valueOf(o1.sortOrder).compareTo(
        Long.valueOf(o2.sortOrder));

      if (result == 0) {
        return o1.name.compareTo(o2.name);
      }
      return result;
    }
  }


  /*
   * protected class to represent an evidence category in the dash board data
   */
  protected class EvidenceCategoryDetails {

    String code;

    String description;

    int sortOrder;

    EvidenceCategoryDetails(String code, String description, int sortOrder) {
      this.code = code;
      this.description = description;
      this.sortOrder = sortOrder;
    }

    public boolean equals(Object o) {
      return this.code.equals(((EvidenceCategoryDetails) o).code);
    }
  }


  // ___________________________________________________________________________
  /**
   * SortEvidenceCategoryBySortOrderAndName Comparator.
   */
  protected class SortEvidenceCategoryBySortOrderAndNameComparator implements
    Comparator<EvidenceCategoryDetails> {

    public SortEvidenceCategoryBySortOrderAndNameComparator() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sort based on evidence category code sort order and name.
     */
    public int compare(final EvidenceCategoryDetails o1,
      final EvidenceCategoryDetails o2) {

      int result = Integer.valueOf(o1.sortOrder).compareTo(
        Integer.valueOf(o2.sortOrder));

      if (result == 0) {
        return o1.description.compareTo(o2.description);
      }
      return result;
    }
  }


  // BEGIN, CR00295440, PMD
  // ___________________________________________________________________________
  /**
   * SortDashboardEvdCategoriesBySortOrderAndDesc Comparator.
   */
  protected class SortDashboardEvdCategoriesBySortOrderAndDesc
    implements Comparator<EvidenceCatDashboardDetails> {

    public SortDashboardEvdCategoriesBySortOrderAndDesc() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sort based on evidence category sort order and description.
     */
    public int compare(final EvidenceCatDashboardDetails o1,
      final EvidenceCatDashboardDetails o2) {

      int result = Long.valueOf(o1.sortOrder).compareTo(
        Long.valueOf(o2.sortOrder));

      if (result == 0) {
        return o1.description.compareTo(o2.description);
      }
      return result;
    }
  }


  // ___________________________________________________________________________
  /**
   * SortDashboardEvdTypesBySortOrderAndDesc Comparator.
   */
  protected class SortDashboardEvdTypesBySortOrderAndDesc
    implements Comparator<EvidenceTypeDashboardDetails> {

    public SortDashboardEvdTypesBySortOrderAndDesc() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sort based on evidence type sort order and description.
     */
    public int compare(
      final EvidenceTypeDashboardDetails o1, final EvidenceTypeDashboardDetails o2) {

      int result = Long.valueOf(o1.sortOrder).compareTo(
        Long.valueOf(o2.sortOrder));

      if (result == 0) {
        return o1.description.compareTo(o2.description);
      }
      return result;
    }
  }
  // END, CR00295440

  // END, CR00230638

  // BEGIN, CR00213278, MC
  
  // BEGIN, CR00397587, PS
  /**
   * Retrieves the evidence flow data.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param caseID ID of the case.
   *
   * @return The evidence flow data.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceFlowDetails getEvidenceFlowDetails(CaseID caseID)
    throws AppException, InformationalException {
    EvidenceFlowDetails evidenceFlowDetails = new EvidenceFlowDetails();
    EvidenceController evidenceController = EvidenceControllerFactory.newInstance();

    evidenceFlowDetails.flowData = evidenceController.getEvidenceFlowDetails(
      caseID);

    // Add synchronized link indicator
    CaseIDAndStatusKey identicalKey = new CaseIDAndStatusKey();

    identicalKey.caseID = caseID.caseID;
    identicalKey.statusCode = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;

    CaseIDAndStatusKey nonIdenticalKey = new CaseIDAndStatusKey();

    nonIdenticalKey.caseID = caseID.caseID;
    nonIdenticalKey.statusCode = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;

    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    if (evidenceDescriptorObj.searchByCaseIDAndStatus(nonIdenticalKey).dtls.isEmpty()
      && evidenceDescriptorObj.searchByCaseIDAndStatus(identicalKey).dtls.isEmpty()) {
      evidenceFlowDetails.synchronizeLinkInd = false;
    } else {
      evidenceFlowDetails.synchronizeLinkInd = true;
    }

    return evidenceFlowDetails;
  }

  // END, CR00213278

  // BEGIN, CR00214296, MC
  
  // BEGIN, CR00397587, PS
  /**
   * Returns a list of participants for a case with evidence.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param caseID The caseID for which the list of participants having 
   * evidence are to be retrieved.
   *
   * @return List of participant names and id.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceParticipantIDNameDetailsList getEvidenceParticipantListForCase(
    CaseID caseID) throws AppException, InformationalException {
    EvidenceController evidenceController = EvidenceControllerFactory.newInstance();

    return evidenceController.getEvidenceParticipantListForCase(caseID);
  }

  // END, CR00214296

  // END, EVDMGMT

  // BEGIN, CR00397587, PS
  /**
   * Returns details of Evidence and case for given SuccessionID.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key The succession identifier.
   *
   * @return The evidence identifier and type as well as the case identifier.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceCaseKey getEvidenceAndCaseFromSuccession(SuccessionID key)
    throws AppException, InformationalException {

    EvidenceDescriptorDtls lastInSuccession = EvidenceControllerFactory.newInstance().getBusinessObjectDescriptor(
      key);

    EvidenceCaseKey evidenceCaseKey = new EvidenceCaseKey();

    evidenceCaseKey.caseIDKey.caseID = lastInSuccession.caseID;
    evidenceCaseKey.evidenceKey.evidenceID = lastInSuccession.relatedID;
    evidenceCaseKey.evidenceKey.evType = lastInSuccession.evidenceType;
    return evidenceCaseKey;
  }

  // BEGIN, CR00216737, GYH
  
  // BEGIN, CR00397587, PS
  /**
   * Returns case participant and related evidence details for transferring 
   * participant evidence from one case to another.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Participant
   *
   * @boread Case
   *
   * @param key Contains case participant and case identifier details.
   *
   * @return Case participant and related evidence details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public CaseEvidenceDetails getEvidenceDetailsForTransfer(
    final CaseEvidenceDetailsKey key) throws AppException,
      InformationalException {
    CaseEvidenceDetails caseEvidenceDetails = new CaseEvidenceDetails();
    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleID;
    final CaseParticipantRoleDtls caseParticipantRoleDtls = CaseParticipantRoleFactory.newInstance().read(
      caseParticipantRoleKey);
    final DetailsForEvidenceTransfer detailsForEvidenceTransfer = new DetailsForEvidenceTransfer();

    detailsForEvidenceTransfer.caseID = key.caseID;
    detailsForEvidenceTransfer.caseParticipantRoleID = key.caseParticipantRoleID;
    detailsForEvidenceTransfer.participantRoleID = caseParticipantRoleDtls.participantRoleID;
    caseEvidenceDetails.evidenceDetails = detailsForEvidenceTransfer;
    caseEvidenceDetails.toCaseID = key.details.toCaseID;
    if (key.actionIDProperty.equals(CuramConst.kYES)) {

      // To case reference must be specified to transfer evidence.
      if (0 == key.details.toCaseID) {
        AppException appException = new AppException(
          BPOEVIDENCECONTROLLER.ERR_CONTROLLER_FV_TO_CASE_REFRENCE_NUMBER_ENTERED);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          appException,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

      // At least one evidence must be selected to transfer evidence.
      if (key.details.evidenceTransferList.equals(CuramConst.gkEmpty)) {
        AppException appException = new AppException(
          BPOEVIDENCECONTROLLER.ERR_CONTROLLER_FV_EVIDENCE_RECORD_MUST_BE_SELECTED);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          appException,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }

      Datastore datastoreObj = null;

      try {
        datastoreObj = DatastoreFactory.newInstance().openDatastore(
          GeneralConst.kEvidenceTransferData);
      } catch (NoSuchSchemaException e) {// do nothing.
      }
      DatastoreEntityKey datastoreEntityKey = new DatastoreEntityKey();

      datastoreEntityKey.entityID = key.datastoreEntityID;
      Entity evidenceTransferDetails = getEntity(datastoreEntityKey);

      if (0
        == evidenceTransferDetails.getAttribute(GeneralConst.kEvidenceTransferList).length()) {
        evidenceTransferDetails.setAttribute(GeneralConst.kCaseID,
          String.valueOf(key.caseID));
        evidenceTransferDetails.setAttribute(GeneralConst.kEvidenceTransferList,
          key.details.evidenceTransferList);
        evidenceTransferDetails = datastoreObj.addRootEntity(
          evidenceTransferDetails);
        caseEvidenceDetails.datastoreEntityID = evidenceTransferDetails.getUniqueID();
      }
    }
    return caseEvidenceDetails;
  }

  // BEGIN, CR00397587, PS
  /**
   * Returns list of evidence to be transferred from one case to another case 
   * along with confirmation message.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @boread Participant
   *
   * @param key Contains case participant and case identifier details.
   *
   * @return List of evidence to be transferred from one case to another case 
   * along with confirmation message.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceListDetails listTransferEvidenceForConfirmation(
    final CaseEvidenceDetailsKey key) throws AppException,
      InformationalException {

    // First get the tab list of evidence to be transferred from data store and
    // then parse as list of evidence types.
    EvidenceListDetails evidenceListDetails = new EvidenceListDetails();
    DatastoreEntityKey datastoreEntityKey = new DatastoreEntityKey();

    datastoreEntityKey.entityID = key.details.datastoreEntityID;
    Entity evidenceDetails = getEntity(datastoreEntityKey);
    String evidenceTransferList = evidenceDetails.getAttribute(
      GeneralConst.kEvidenceTransferList);
    EvidenceKeyList evidenceKeyList = parseHelper(evidenceTransferList);

    for (curam.core.sl.infrastructure.struct.EvidenceKey evidenceKey : evidenceKeyList.dtls.items()) {
      ECWIPNewAndUpdateDtls ecWIPNewAndUpdateDtls = new ECWIPNewAndUpdateDtls();

      ecWIPNewAndUpdateDtls.evidenceID = evidenceKey.evidenceID;
      ecWIPNewAndUpdateDtls.evidenceType = evidenceKey.evidenceType;
      ecWIPNewAndUpdateDtls.correctionSetID = evidenceKey.correctionSetID;
      ecWIPNewAndUpdateDtls.evidenceDescriptorID = evidenceKey.evidenceDescriptorID;
      ecWIPNewAndUpdateDtls.successionID = evidenceKey.successionID;
      EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = evidenceKey.evidenceID;
      eiEvidenceKey.evidenceType = evidenceKey.evidenceType;
      ecWIPNewAndUpdateDtls.period = getPeriodAsString(
        EvidenceControllerFactory.newInstance().getPeriodForEvidenceRecord(
          eiEvidenceKey));
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = key.details.participantRoleID;
      ecWIPNewAndUpdateDtls.concernRoleName = CachedConcernRoleFactory.newInstance().readConcernRoleName(concernRoleKey).concernRoleName;
      // Get last user who updated this evidence row
      EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = evidenceKey.evidenceDescriptorID;
      ChangeUserDetails changeUserDetails = EvidenceChangeHistoryFactory.newInstance().readUserForLatestChange(
        evidenceDescriptorKey);
      LocalisableString latestActivity = new LocalisableString(
        BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY);

      latestActivity.arg(changeUserDetails.changeUser);
      latestActivity.arg(changeUserDetails.changeDateTime);
      ecWIPNewAndUpdateDtls.latestActivity = latestActivity.getMessage(
        TransactionInfo.getProgramLocale());

      // BEGIN, CR00241203, POB
      EvidenceMap map = curam.core.sl.infrastructure.impl.EvidenceController.getEvidenceMap();

      StandardEvidenceInterface standardEvidenceInterface = map.getEvidenceType(
        eiEvidenceKey.evidenceType);

      EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = standardEvidenceInterface.getDetailsForListDisplay(
        eiEvidenceKey);

      // BEGIN, CR00244064, CD
      // Summary may now be marked up as client formatted text.
      // Ensure that this assignment keeps to it's original contract.
      ecWIPNewAndUpdateDtls.summary = LocalizableXMLStringHelper.toPlainText(
        eiFieldsForListDisplayDtls.summary);
      // END, CR00244064
      // END, CR00241203

      evidenceListDetails.dtls.newAndUpdateList.dtls.addRef(
        ecWIPNewAndUpdateDtls);
    }

    // Construct the evidence to be transferred confirmation message.
    CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

    caseParticipantRoleKey.caseParticipantRoleID = key.caseParticipantRoleID;
    CaseKey fromCaseKey = new CaseKey();

    fromCaseKey.caseID = key.caseID;
    CaseReferenceAndTypeDetails fromCaseReferenceAndTypeDetails = CaseHeaderFactory.newInstance().readCaseReferenceAndTypeByCaseID(
      fromCaseKey);
    CaseKey toCaseKey = new CaseKey();

    toCaseKey.caseID = key.details.toCaseID;
    CaseReferenceAndTypeDetails toCaseReferenceAndTypeDetails = CaseHeaderFactory.newInstance().readCaseReferenceAndTypeByCaseID(
      toCaseKey);
    AppException appException = new AppException(
      BPOEVIDENCECONTROLLER.ERR_CONTROLLER_TRANSFER_EVIDENCE_CONFIRMATION);

    appException.arg(
      curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance().readFullName(caseParticipantRoleKey).fullName);
    appException.arg(getSourceCaseDescription(fromCaseKey));
    appException.arg(fromCaseReferenceAndTypeDetails.caseReference);
    appException.arg(getSourceCaseDescription(toCaseKey));
    appException.arg(toCaseReferenceAndTypeDetails.caseReference);
    evidenceListDetails.confirmationMessage = appException.getMessage(
      ProgramLocale.getDefaultServerLocale());
    return evidenceListDetails;
  }

  // BEGIN, CR00397587, PS
  /**
   * Returns a list of all active case members of a case. Also returns active 
   * evidences for the specified case and participant.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @boread Participant
   *
   * @param key Contains concern role and case identifier details.
   *
   * @param concernRoleKey Key of the concern role
   *
   * @return List of all active case members of a case. Also returns active 
   * evidences for the specified case and participant.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public CaseMembersAndTransferEvidenceList listCaseMembersAndEvidenceForTransfer(
    final CaseIDAndEvidenceTypeKey key, final ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {

    CaseMembersAndTransferEvidenceList caseMembersAndTransferEvidenceList = new CaseMembersAndTransferEvidenceList();

    // Get list of case members.
    ViewCaseParticipantRole_boKey viewCaseParticipantRole_boKey = new ViewCaseParticipantRole_boKey();

    viewCaseParticipantRole_boKey.dtls.caseID = key.caseID;
    viewCaseParticipantRole_boKey.showOnlyActive = true;
    caseMembersAndTransferEvidenceList.caseMembers = curam.core.sl.fact.CaseParticipantRoleFactory.newInstance().viewCaseMemberList(
      viewCaseParticipantRole_boKey);

    // Get the default case participant.
    if (0 == concernRoleKey.concernRoleID) {
      final curam.core.sl.entity.struct.CaseIDTypeCodeKey caseIDTypeCodeKey = new curam.core.sl.entity.struct.CaseIDTypeCodeKey();

      caseIDTypeCodeKey.caseID = key.caseID;
      caseIDTypeCodeKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
      caseMembersAndTransferEvidenceList.filteredParticipantID = CaseParticipantRoleFactory.newInstance().readByCaseIDAndTypeCode(caseIDTypeCodeKey).dtls.caseParticipantRoleID;
    } else {
      CaseIDParticipantRoleKey caseIDParticipantRoleKey = new CaseIDParticipantRoleKey();

      caseIDParticipantRoleKey.caseID = key.caseID;
      caseIDParticipantRoleKey.participantRoleID = concernRoleKey.concernRoleID;
      caseMembersAndTransferEvidenceList.filteredParticipantID = CaseParticipantRoleFactory.newInstance().readCaseParticipantRoleID(caseIDParticipantRoleKey).caseParticipantRoleID;
    }

    // Get the list of evidence for a given concern role and case identifier.
    ECActiveEvidenceDtlsList activeEvidenceDtlsList = listEvidenceForTransfer(key, concernRoleKey).dtls.activeList;
    ActiveEvidenceDetailsList activeEvidenceDetailsList = new ActiveEvidenceDetailsList();

    for (curam.core.sl.infrastructure.struct.ECActiveEvidenceDtls activeEvidenceDtls : activeEvidenceDtlsList.dtls.items()) {
      ActiveEvidenceDetails activeEvidenceDetails = new ActiveEvidenceDetails();

      activeEvidenceDetails.evidenceDetails.assign(activeEvidenceDtls);

      EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = activeEvidenceDtls.evidenceID;
      eiEvidenceKey.evidenceType = activeEvidenceDtls.evidenceType;
      activeEvidenceDetails.period = getPeriodAsString(
        EvidenceControllerFactory.newInstance().getPeriodForEvidenceRecord(
          eiEvidenceKey));

      // Get last user who updated this evidence row
      EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = activeEvidenceDtls.evidenceDescriptorID;
      ChangeUserDetails changeUserDetails = EvidenceChangeHistoryFactory.newInstance().readUserForLatestChange(
        evidenceDescriptorKey);
      LocalisableString latestActivity = new LocalisableString(
        BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY);

      latestActivity.arg(changeUserDetails.changeUser);
      latestActivity.arg(changeUserDetails.changeDateTime);
      activeEvidenceDetails.latestActivity = latestActivity.getMessage(
        TransactionInfo.getProgramLocale());
      activeEvidenceDetailsList.activeEvidenceList.addRef(activeEvidenceDetails);
    }
    caseMembersAndTransferEvidenceList.evidenceList.assign(
      activeEvidenceDetailsList);

    return caseMembersAndTransferEvidenceList;
  }

  /**
   * Returns data store entity object for the given data store ID. If the object
   * is not created before, then it creates the one and returns.
   *
   * @param key
   * Contains data store identifier.
   *
   * @return Data store entity object.
   */
  protected Entity getEntity(final DatastoreEntityKey datastoreEntityKey) {
    Datastore datastoreObj = null;

    try {
      datastoreObj = DatastoreFactory.newInstance().openDatastore(
        GeneralConst.kEvidenceTransferData);
    } catch (NoSuchSchemaException e) {// do nothing.
    }
    Entity evidenceTransferDetails = null;

    if (0 == datastoreEntityKey.entityID) {
      evidenceTransferDetails = datastoreObj.newEntity(
        GeneralConst.kEvidenceTransferData);
    } else {
      evidenceTransferDetails = datastoreObj.readEntity(
        datastoreEntityKey.entityID);
    }
    return evidenceTransferDetails;
  }

  /**
   * Deletes evidence transfer data store entity object for the given data store
   * ID.
   *
   * @param key
   * Contains data store identifier.
   */
  protected void getDeleteEvidenceTransferDatastore(
    final DatastoreEntityKey datastoreEntityKey) {
    Datastore datastoreObj = null;

    try {
      datastoreObj = DatastoreFactory.newInstance().openDatastore(
        GeneralConst.kEvidenceTransferData);
    } catch (NoSuchSchemaException e) {// do nothing.
    }
    datastoreObj.readEntity(datastoreEntityKey.entityID).delete();
  }

  /**
   * Helper method for parsing evidence list.
   *
   * @param tabList
   * Contains list of evidence data to be parsed.
   *
   * @return Parsed evidence details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected EvidenceKeyList parseHelper(String tabList) throws AppException,
      InformationalException {
    EvidenceKeyList evidenceKeyList = new EvidenceKeyList();
    StringList evidenceIDAndTypeList = StringUtil.tabText2StringList(tabList);

    for (int i = 0; i < evidenceIDAndTypeList.size(); i++) {
      StringList evidenceIDAndTypeStringList = StringUtil.delimitedText2StringList(
        evidenceIDAndTypeList.item(i), '|');

      if (evidenceIDAndTypeStringList.size() != kElementsInTabList) {
        continue;
      }
      curam.core.sl.infrastructure.struct.EvidenceKey evidenceKey = new curam.core.sl.infrastructure.struct.EvidenceKey();

      evidenceKey.evidenceDescriptorID = Long.parseLong(
        evidenceIDAndTypeStringList.item(kFirstElement));
      evidenceKey.evidenceID = Long.parseLong(
        evidenceIDAndTypeStringList.item(kSecondElement));
      evidenceKey.evidenceType = evidenceIDAndTypeStringList.item(kThirdElement);
      evidenceKey.correctionSetID = evidenceIDAndTypeStringList.item(
        kFourthElement);
      evidenceKey.successionID = Long.parseLong(
        evidenceIDAndTypeStringList.item(kFifthElement));
      evidenceKeyList.dtls.addRef(evidenceKey);
    }
    return evidenceKeyList;
  }

  // END, CR00216737

  // BEGIN, CR00225417, GYH
  /**
   * This method renders the effective period of an evidence record as a string.
   *
   * @param evidencePeriod
   * The effective period of an evidence record
   * @return The period rendered as a string
   */
  protected String getPeriodAsString(final EvidencePeriod evidencePeriod) {

    LocalisableString period = null;

    if (evidencePeriod.endDate.isZero()) {
      period = new LocalisableString(
        BPOEVIDENCECONTROLLER.INF_PERIOD_NO_END_DATE);
      period.arg(evidencePeriod.startDate);
    } else {
      period = new LocalisableString(BPOEVIDENCECONTROLLER.INF_PERIOD);

      period.arg(evidencePeriod.startDate);
      period.arg(evidencePeriod.endDate);
    }

    return period.getMessage(TransactionInfo.getProgramLocale());

  }

  /**
   * Returns source case description for the given case identifier.
   *
   * @param key
   * Containing case identifier.
   *
   * @return Source case description.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * {@link BPOEVIDENCECONTROLLER#ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED}
   * - if the case type being passed is not having the corresponding
   * handler to support the required functionality.
   */
  protected String getSourceCaseDescription(final CaseKey caseKey)
    throws AppException, InformationalException {
    CaseTypeCode caseTypeCode = CaseHeaderFactory.newInstance().readCaseTypeCode(
      caseKey);
    CaseTypeEvidence caseTypeEvidence = caseTypeEvidenceMap.get(
      caseTypeCode.caseTypeCode);

    if (null == caseTypeEvidence) {
      AppException e = new AppException(
        BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_TYPE_NOT_SUPPORTED);

      e.arg(
        CodeTable.getOneItem(CASETYPECODE.TABLENAME, caseTypeCode.caseTypeCode,
        TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    return caseTypeEvidence.getCaseTypeDescription(caseKey);
  }

  // END, CR00225417

  // BEGIN, CR00397587, PS
  /**
   * Returns the header details for the evidence business object summary.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread ConcernRole
   *
   * @boread Participant
   *
   * @param key The succession identifier.
   *
   * @return The header details for the evidence business object summary.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceObjectSummaryHeaderDetails readObjectSummaryHeaderDetails(
    SuccessionID key) throws AppException, InformationalException {

    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();

    EvidenceDescriptorDtls lastInSuccession = evidenceControllerObj.getBusinessObjectDescriptor(
      key);

    // get the evidence type
    CodeTableItemIdentifier evidenceTypeArg = new CodeTableItemIdentifier(
      curam.codetable.CASEEVIDENCE.TABLENAME, lastInSuccession.evidenceType);

    // get the participant name
    String participantNameArg = CuramConst.gkEmpty;

    if (lastInSuccession.participantID != 0) {
      // ConcernRole manipulation variables
      CachedConcernRole concernRoleObj = CachedConcernRoleFactory.newInstance();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = lastInSuccession.participantID;
      participantNameArg = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;
    }
    EvidenceObjectSummaryHeaderDetails evidenceObjectSummaryHeaderDetails = new EvidenceObjectSummaryHeaderDetails();

    if (lastInSuccession.participantID != 0) {
      // ConcernRole manipulation variables
      CachedConcernRole concernRoleObj = CachedConcernRoleFactory.newInstance();
      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = lastInSuccession.participantID;
      participantNameArg = concernRoleObj.readConcernRoleName(concernRoleKey).concernRoleName;

      evidenceObjectSummaryHeaderDetails.tabName = new LocalisableString(FACADEEVIDENCE.EVIDENCEOBJECTTABNAME).arg(evidenceTypeArg).arg(participantNameArg).toClientFormattedText();

      evidenceObjectSummaryHeaderDetails.tabTitle = new LocalisableString(FACADEEVIDENCE.EVIDENCEOBJECTSUMMARYTITLE).arg(evidenceTypeArg).arg(participantNameArg).toClientFormattedText();

    } else {

      evidenceObjectSummaryHeaderDetails.tabName = new LocalisableString(FACADEEVIDENCE.EVIDENCEOBJECTTABNAME_NO_PARTICIPANT).arg(evidenceTypeArg).toClientFormattedText();

      evidenceObjectSummaryHeaderDetails.tabTitle = new LocalisableString(FACADEEVIDENCE.EVIDENCEOBJECTSUMMARYTITLE_NO_PARTICIPANT).arg(evidenceTypeArg).toClientFormattedText();

    }

    return evidenceObjectSummaryHeaderDetails;
  }

  // BEGIN, CR00397587, PS
  // ____________________________________________________________________________
  /**
   * Returns the tab name and title for the Evidence Type Workspace tab.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key Case ID and Evidence Type
   *
   * @return Name and title for the tab.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceObjectSummaryHeaderDetails readWorkspaceTypeSummaryDetails(
    curam.core.facade.infrastructure.struct.CaseIDAndEvidenceTypeKey key)
    throws AppException, InformationalException {

    EvidenceObjectSummaryHeaderDetails evidenceObjectSummaryHeaderDetails = new EvidenceObjectSummaryHeaderDetails();

    curam.piwrapper.caseheader.impl.CaseHeader caseHeader = caseHeaderDAO.get(
      key.caseID);

    // get the case name
    String caseNameArg = caseHeader.getAdminCaseConfiguration().getLinkText();

    // get the case reference
    String caseReference = caseHeader.getCaseReference();

    // get the evidence type
    CodeTableItemIdentifier evidenceTypeArg = new CodeTableItemIdentifier(
      curam.codetable.CASEEVIDENCE.TABLENAME, key.evidenceType);

    evidenceObjectSummaryHeaderDetails.tabName = new LocalisableString(FACADEEVIDENCE.EVIDENCE_TYPEWORKSPACE_TABNAME).arg(evidenceTypeArg).arg(caseNameArg).arg(caseReference).toClientFormattedText();

    evidenceObjectSummaryHeaderDetails.tabTitle = new LocalisableString(FACADEEVIDENCE.EVIDENCE_TYPEWORKSPACE_TABTITLE).arg(evidenceTypeArg).arg(caseNameArg).arg(caseReference).toClientFormattedText();

    return evidenceObjectSummaryHeaderDetails;
  }

  // BEGIN, CR00397587, PS
  /**
   * Returns the header details for the evidence tab summary.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key The case identifier.
   *
   * @return The header details for the evidence tab summary.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceTabSummaryHeaderDetails readEvidenceTabHeaderDetails(
    CaseKey key) throws AppException, InformationalException {

    EvidenceTabSummaryHeaderDetails tabSummaryHeaderDetails = new EvidenceTabSummaryHeaderDetails();

    curam.piwrapper.caseheader.impl.CaseHeader caseHeader = caseHeaderDAO.get(
      key.caseID);

    // get the case name
    String caseNameArg = caseHeader.getAdminCaseConfiguration().getLinkText();

    // get the case reference
    String caseReference = caseHeader.getCaseReference();

    // set the tab name and title
    tabSummaryHeaderDetails.tabName = new LocalisableString(FACADEEVIDENCE.EVIDENCETABNAME).arg(caseNameArg).arg(caseReference).toClientFormattedText();
    tabSummaryHeaderDetails.tabTitle = new LocalisableString(FACADEEVIDENCE.EVIDENCETABTITLE).arg(caseNameArg).arg(caseReference).toClientFormattedText();

    return tabSummaryHeaderDetails;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Sets active evidences to 'Pending Removal'.
   *
   * @boread Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Evidence Succession identifier.
   *
   * @return Details of the Evidence which has had its status set to "Pending 
   * Removal".
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public SetPendingRemovalReturnDtls setPendingRemovalForActiveObject(
    SuccessionID key) throws AppException, InformationalException {

    // get the descriptor
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    EvidenceDescriptorDtls lastInSuccession = evidenceControllerObj.getBusinessObjectDescriptor(
      key);
    EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = lastInSuccession.evidenceDescriptorID;

    // Call controller operation to remove evidence
    evidenceControllerObj.removeEvidence(evidenceDescriptorKey);

    SetPendingRemovalReturnDtls setPendingRemovalReturnDtls = new SetPendingRemovalReturnDtls();

    setPendingRemovalReturnDtls.warnings = evidenceControllerObj.getWarnings();

    return setPendingRemovalReturnDtls;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Discards the pending update evidence (by setting the 
   * <code>statusCode</code> of the EvidenceDescriptor to Canceled).
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Evidence Succession identifier.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public void discardPendingUpdateObject(SuccessionID key) throws AppException,
      InformationalException {

    // get the descriptor
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    EvidenceDescriptorDtls lastInSuccession = evidenceControllerObj.getBusinessObjectDescriptor(
      key);
    EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = lastInSuccession.evidenceDescriptorID;

    // Call controller operation to discard pending update evidences
    evidenceControllerObj.discardPendingUpdate(evidenceDescriptorKey);
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Discards 'pending removal' from active evidences. Discards the pending 
   * removal evidence (by setting the <code>pendingRemovalInd</code> field on 
   * the EvidenceDescriptor entity to <code>false</code>). If the change has 
   * been submitted for approval and/or if the user does not have sufficient 
   * privileges to discard pending removal evidences, exception is thrown.
   *
   * @boread Evidence
   *
   * @bowrite EvidenceController
   *
   * @bowrite Evidence
   *
   * @bowrite EvidenceController
   *
   * @param key Evidence Succession identifier.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public void clearPendingRemovalForActiveObject(SuccessionID key)
    throws AppException, InformationalException {

    // get the descriptor
    EvidenceControllerInterface evidenceControllerObj = (EvidenceControllerInterface) EvidenceControllerFactory.newInstance();
    EvidenceDescriptorDtls lastInSuccession = evidenceControllerObj.getBusinessObjectDescriptor(
      key);

    DiscardPendingRemoveKey discardPendingRemoveKey = new DiscardPendingRemoveKey();

    discardPendingRemoveKey.key.evidenceDescriptorID = lastInSuccession.evidenceDescriptorID;
    discardPendingRemoveKey.details.versionNo = lastInSuccession.versionNo;

    // Call controller operation to discard pending removal evidences
    evidenceControllerObj.discardPendingRemove(discardPendingRemoveKey);
  }

  // BEGIN, CR00397587, PS
  // BEGIN, CR00226297, GYH
  /**
   * Lists evidence types along with their associated descriptions for a given 
   * case and evidence category.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Contains case identifier and evidence category.
   *
   * @return Lists evidence types along with their associated descriptions.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceCategoryAndTypes listEvidenceTypes(
    final CaseIDAndEvidenceCategoryKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00230454, ELG
    // return structure
    EvidenceCategoryAndTypes evidenceCategoryAndTypes = new EvidenceCategoryAndTypes();

    evidenceCategoryAndTypes.filteredCategory = key.category;

    CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    EvidenceTypeAdminDetailsList evidenceTypeAdminDetailsList = EvidenceControllerFactory.newInstance().listEvidenceTypes(
      caseKey);

    // Filter participant evidence out of the list.
    for (EvidenceTypeAdminDetails evidenceTypeAdminDetails : evidenceTypeAdminDetailsList.dtls.items()) {

      if (!evidenceTypeAdminDetails.participantDataInd
        && (evidenceTypeAdminDetails.category.equals(key.category)
          || (evidenceTypeAdminDetails.category.length() == 0)
          || key.category.equals(EVIDENCECATEGORY.ALL)
          || (key.category.equals(EVIDENCECATEGORY.PREFERRED)
            && evidenceTypeAdminDetails.quickLinkInd))) {

        EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

        eiEvidenceKey.evidenceType = evidenceTypeAdminDetails.evidenceType;

        EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();

        evidenceTypeAndDesc.evidenceType = evidenceTypeAdminDetails.evidenceType;
        evidenceTypeAndDesc.evidenceDesc = EvidenceControllerFactory.newInstance().readEvidenceTypeDescription(eiEvidenceKey).description;

        if (StringHelper.isEmpty(evidenceTypeAndDesc.evidenceDesc)) {
          evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
            CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType);
        }

        evidenceCategoryAndTypes.evidenceTypes.dtls.addRef(evidenceTypeAndDesc);

      }

    }
    // END, CR00230454

    return evidenceCategoryAndTypes;
  }
  
  /**
   * Lists editable evidence types along with their associated descriptions for a given 
   * case and evidence category.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Contains case identifier and evidence category.
   *
   * @return Lists editable evidence types along with their associated descriptions.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public EvidenceCategoryAndTypes listEditableEvidenceTypes(
    final CaseIDAndEvidenceCategoryKey key) throws AppException,
      InformationalException {

    // BEGIN, CR00230454, ELG
    // return structure
    EvidenceCategoryAndTypes evidenceCategoryAndTypes = new EvidenceCategoryAndTypes();

    evidenceCategoryAndTypes.filteredCategory = key.category;

    CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    EvidenceTypeAdminDetailsList evidenceTypeAdminDetailsList = EvidenceControllerFactory.newInstance().listEvidenceTypes(
      caseKey);

    // Filter participant evidence out of the list.
    for (EvidenceTypeAdminDetails evidenceTypeAdminDetails : evidenceTypeAdminDetailsList.dtls.items()) {

      if (!evidenceTypeAdminDetails.readOnly
        && (!evidenceTypeAdminDetails.participantDataInd
          && (evidenceTypeAdminDetails.category.equals(key.category)
            || (evidenceTypeAdminDetails.category.length() == 0)
            || key.category.equals(EVIDENCECATEGORY.ALL)
            || (key.category.equals(EVIDENCECATEGORY.PREFERRED)
              && evidenceTypeAdminDetails.quickLinkInd)))) {

        EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

        eiEvidenceKey.evidenceType = evidenceTypeAdminDetails.evidenceType;

        EvidenceTypeAndDesc evidenceTypeAndDesc = new EvidenceTypeAndDesc();

        evidenceTypeAndDesc.evidenceType = evidenceTypeAdminDetails.evidenceType;
        evidenceTypeAndDesc.evidenceDesc = EvidenceControllerFactory.newInstance().readEvidenceTypeDescription(eiEvidenceKey).description;

        if (StringHelper.isEmpty(evidenceTypeAndDesc.evidenceDesc)) {
          evidenceTypeAndDesc.evidenceDesc = CodeTable.getOneItem(
            CASEEVIDENCE.TABLENAME, evidenceTypeAndDesc.evidenceType);
        }

        evidenceCategoryAndTypes.evidenceTypes.dtls.addRef(evidenceTypeAndDesc);

      }

    }
    // END, CR00230454

    return evidenceCategoryAndTypes;
  }  

  // BEGIN, CR00230454, ELG
  
  // BEGIN, CR00397587, PS
  /**
   * Returns a list of evidence categories for the case.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains case ID.
   *
   * @return List of evidence categories.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceCategoryDetailsList getEvidenceCategoryList(final CaseKey key)
    throws AppException, InformationalException {

    // return structure
    EvidenceCategoryDetailsList evidenceCategoryDetailsList = new EvidenceCategoryDetailsList();

    EvidenceTypeAdminDetailsList evidenceTypeAdminDetailsList = EvidenceControllerFactory.newInstance().listEvidenceTypes(
      key);

    // BEGIN, CR00296357, ELG
    SortedSet<EvidenceCategoryDetails> evidenceCategoryDetailsSet = getSortedEvidenceCategoriesFromListForCase(
      evidenceTypeAdminDetailsList, true, key.caseID);
    // END, CR00296357

    // loop variable
    curam.core.facade.infrastructure.struct.EvidenceCategoryDetails evidenceCategoryDtls;

    // populate the category selection list
    for (EvidenceCategoryDetails evdCategoryDetails : evidenceCategoryDetailsSet) {

      evidenceCategoryDtls = new curam.core.facade.infrastructure.struct.EvidenceCategoryDetails();
      evidenceCategoryDtls.categoryCode = evdCategoryDetails.code;
      evidenceCategoryDtls.categoryDescription = evdCategoryDetails.description;
      if (!evdCategoryDetails.code.equals(EVIDENCECATEGORY.PARTICIPANTDATA)) {
        evidenceCategoryDetailsList.dtls.addRef(evidenceCategoryDtls);
      }

    }

    return evidenceCategoryDetailsList;

  }

  // END, CR00230454

  // BEGIN, CR00397587, PS
  /**
   * Returns the case ID and evidence category identifier. Passes the case ID 
   * and evidence category identifier onto the next page.
   *
   * @param key Contains case identifier and evidence category.
   *
   * @return Returns the case ID and evidence category identifier.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public CaseIDAndEvidenceCategoryKey getCaseAndEvidenceCategoryDetails(
    final CaseIDAndEvidenceCategoryKey key) throws AppException,
      InformationalException {
    return key;
  }

  // END, CR00226297

  // BEGIN, CR00224982, POB
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns business object page name details depending on evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public PageNameDetails readBusinessObjectPage(final SuccessionID key)
    throws AppException, InformationalException {

    // Return object
    PageNameDetails pageNameDetails = new PageNameDetails();

    EvidenceCaseKey evCaseKey = getEvidenceAndCaseFromSuccession(key);

    EIEvidenceKey eiEvKey = new EIEvidenceKey();

    eiEvKey.evidenceType = evCaseKey.evidenceKey.evType;

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails = EvidenceControllerFactory.newInstance().readBusinessObjectPage(
      eiEvKey);

    return pageNameDetails;
  }

  // END, CR00224982

  // BEGIN, CR00239880, POB
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns create page name details depending on evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public PageNameDetails readHistoryRecordPage(final EvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails = EvidenceControllerFactory.newInstance().readHistoryRecordPage(
      key.key);

    return pageNameDetails;
  }

  // END, CR00239880

  // BEGIN, CR00251167, CD
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns the business object page name for the evidence type of the given 
   * succession ID.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public PageNameDetails readBusinessObjectVerificationsPage(final SuccessionID key)
    throws AppException, InformationalException {

    // Return object
    PageNameDetails pageNameDetails = new PageNameDetails();

    EvidenceCaseKey evCaseKey = getEvidenceAndCaseFromSuccession(key);

    EIEvidenceKey eiEvKey = new EIEvidenceKey();

    eiEvKey.evidenceType = evCaseKey.evidenceKey.evType;

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails = EvidenceControllerFactory.newInstance().readBusinessObjectVerificationsPage(
      eiEvKey);

    return pageNameDetails;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns the Business Object Issues page name for the evidence type of the 
   * given succession ID.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @boread Case
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public PageNameDetails readBusinessObjectIssuesPage(final SuccessionID key)
    throws AppException, InformationalException {

    // Return object
    PageNameDetails pageNameDetails = new PageNameDetails();

    EvidenceCaseKey evCaseKey = getEvidenceAndCaseFromSuccession(key);

    EIEvidenceKey eiEvKey = new EIEvidenceKey();

    eiEvKey.evidenceType = evCaseKey.evidenceKey.evType;

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails = EvidenceControllerFactory.newInstance().readBusinessObjectIssuesPage(
      eiEvKey);

    return pageNameDetails;
  }

  // END, CR00251167

  // BEGIN, CR00224675, POB
  
  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns create page name details depending on evidence type. workspaces.
   *
   * @boread Evidence
   *
   * @boread PageNameDetails
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public PageNameDetails readCreatePage(final EvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails = EvidenceControllerFactory.newInstance().readCreatePage(
      key.key);

    return pageNameDetails;
  }

  // BEGIN, CR00397587, PS
  // ___________________________________________________________________________
  /**
   * Returns workspace page name details depending on evidence type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence key.
   *
   * @return Page name details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public PageNameDetails readWorkspacePage(final EvidenceKey key)
    throws AppException, InformationalException {

    // Return object
    PageNameDetails pageNameDetails = new PageNameDetails();

    // Call the method for retrieving the view page
    pageNameDetails.pageDetails = EvidenceControllerFactory.newInstance().readWorkspacePage(
      key.key);

    return pageNameDetails;
  }

  // END, CR00224675

  // BEGIN, CR00397587, PS
  /**
   * Lists the correction history for a given Evidence record.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Evidence record identifier
   *
   * @return A list of corrections for the evidence record.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceCorrectionDtlsList listEvidenceCorrectionHistory(
    final EIEvidenceKey key) throws AppException, InformationalException {

    // Details to return
    EvidenceCorrectionDtlsList evidenceCorrectionDtlsList = new EvidenceCorrectionDtlsList();

    // Retrieve the Evidence Descriptor record for this evidence
    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

    RelatedIDAndEvidenceTypeKey relatedIDAndEvidenceTypeKey = new RelatedIDAndEvidenceTypeKey();

    relatedIDAndEvidenceTypeKey.evidenceType = key.evidenceType;
    relatedIDAndEvidenceTypeKey.relatedID = key.evidenceID;
    EvidenceDescriptorDtls evidenceDescriptorDtls = evidenceDescriptorObj.readByRelatedIDAndType(
      relatedIDAndEvidenceTypeKey);

    // Read the related correction records
    CorrectionSetIDDetails correctionSetIDDetails = new CorrectionSetIDDetails();

    correctionSetIDDetails.caseID = evidenceDescriptorDtls.caseID;
    correctionSetIDDetails.correctionSetID = evidenceDescriptorDtls.correctionSetID;
    EvidenceDescriptorIDAndStatusDetailsList correctionList = evidenceDescriptorObj.searchAllRelatedDescriptorIDsByCorrectionSetID(
      correctionSetIDDetails);

    for (int i = 0; i < correctionList.dtls.size(); i++) {
      EvidenceCorrectionDtls evidenceCorrectionDtls = new EvidenceCorrectionDtls();

      // Read the evidence descriptor for this record
      EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = correctionList.dtls.item(i).evidenceDescriptorID;
      EvidenceDescriptorDtls evidenceDescriptorDtls2 = evidenceDescriptorObj.read(
        evidenceDescriptorKey);

      // BEGIN, CR00335498, GYH
      // Unaccepted shared evidence should not be displayed on evidence correction history
      EVIDENCEDESCRIPTORSTATUSEntry evidencedescriptorstatusEntry = EVIDENCEDESCRIPTORSTATUSEntry.get(
        evidenceDescriptorDtls2.statusCode);

      if (EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALINEDIT.equals(
        evidencedescriptorstatusEntry)
          || EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALDISCARDED.equals(
            evidencedescriptorstatusEntry)
            || EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALREJECTED.equals(
              evidencedescriptorstatusEntry)
              || EVIDENCEDESCRIPTORSTATUSEntry.IDENTICALREMOVALACCEPTED.equals(
                evidencedescriptorstatusEntry)
                || EVIDENCEDESCRIPTORSTATUSEntry.NONIDENTICALINEDIT.equals(
                  evidencedescriptorstatusEntry)
                  || EVIDENCEDESCRIPTORSTATUSEntry.NONIDENTICALRESOLVED.equals(
                    evidencedescriptorstatusEntry)) {
        continue;
      }
      // END, CR00335498
      evidenceCorrectionDtls.evidenceID = evidenceDescriptorDtls2.relatedID;

      // Set the period
      EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      eiEvidenceKey.evidenceID = evidenceDescriptorDtls2.relatedID;
      eiEvidenceKey.evidenceType = evidenceDescriptorDtls2.evidenceType;
      evidenceCorrectionDtls.period = getPeriodAsString(
        evidenceControllerObj.getPeriodForEvidenceRecord(eiEvidenceKey));

      // BEGIN, CR00233161, CD
      // Get the Change Summary
      EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

      evidenceTypeKey.evidenceType = evidenceDescriptorDtls2.evidenceType;

      // for participant evidence the change reason does not apply
      if (isEvidenceParticipantData(evidenceTypeKey).participantDataInd) {

        LocalisableString description = new LocalisableString(
          BPOEVIDENCECONTROLLER.INF_DESCRIPTION_PARTICIPANT);

        description.arg(evidenceDescriptorDtls2.receivedDate);
        evidenceCorrectionDtls.changeSummary = description.toClientFormattedText();

      } else {

        LocalisableString description = new LocalisableString(
          BPOEVIDENCECONTROLLER.INF_DESCRIPTION);

        description.arg(evidenceDescriptorDtls2.receivedDate);
        description.arg(
          new CodeTableItemIdentifier(EVIDENCECHANGEREASON.TABLENAME,
          evidenceDescriptorDtls2.changeReason));
        evidenceCorrectionDtls.changeSummary = description.toClientFormattedText();

      }
      // END, CR00233161

      // Updated By
      ChangeUserDetails changeUserDetails = EvidenceChangeHistoryFactory.newInstance().readUserForLatestChange(
        evidenceDescriptorKey);
      LocalisableString latestActivity = new LocalisableString(
        BPOEVIDENCECONTROLLER.INF_LAST_ACTIVITY);

      UsersKey usersKey = new UsersKey();

      usersKey.userName = changeUserDetails.changeUser;

      UserFullname fullname = UserAccessFactory.newInstance().getFullName(
        usersKey);

      latestActivity.arg(fullname.fullname);
      latestActivity.arg(changeUserDetails.changeDateTime);
      evidenceCorrectionDtls.updatedBy = latestActivity.toClientFormattedText();

      // Add to return list
      evidenceCorrectionDtlsList.dtls.addRef(evidenceCorrectionDtls);
    }

    // Return list
    return evidenceCorrectionDtlsList;
  }

  // BEGIN, CR00397587, PS
  /**
   * Lists all of the Issues for a case.
   *
   * @boread Evidence
   *
   * @boread Issue
   *
   * @param key Case identifier.
   *
   * @return A list of issues for the case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceIssuesDetailsList listIssuesForCase(final CaseKey key)
    throws AppException, InformationalException {

    // Retrieve the list of issues for the case
    final IssueDetailsList issueDetailsList = evidenceIssues.listIssuesForCase(
      key.caseID);

    return getIssueDetails(key.caseID, issueDetailsList);
  }

  // BEGIN, CR00397587, PS
  /**
   * Lists all of the issues for a given evidence record.
   *
   * @boread Evidence
   *
   * @boread Issue
   *
   * @param key Evidence record identifier.
   *
   * @return A list of issues for the evidence record.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceIssuesDetailsList listIssuesForEvidence(final SuccessionID key)
    throws AppException, InformationalException {

    // Retrieve the list of issues for the evidence type
    long caseID = EvidenceDescriptorFactory.newInstance().readCaseIDForBusinessObject(key).caseID;
    final IssueDetailsList issueDetailsList = evidenceIssues.listIssuesForEvidenceType(
      caseID, key.successionID);

    return getIssueDetails(caseID, issueDetailsList);
  }

  /**
   * Helper method to setup the list of Evidence Issue details.
   *
   * @param caseID
   * Case identifier.
   * @param issueDetailsList
   * The Evidence Issues.
   *
   * @return A list of issues to display on client.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected EvidenceIssuesDetailsList getIssueDetails(long caseID,
    final IssueDetailsList issueDetailsList) throws AppException,
      InformationalException {

    EvidenceIssuesDetailsList evidenceIssuesDetailsList = new EvidenceIssuesDetailsList();
    EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();
    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    // BEGIN, CR00230584, ELG
    // Loop variables
    IssueDetails issueDetails;
    EvidenceIssuesDetails evidenceIssuesDetails;

    // END, CR00230584

    for (int i = 0; i < issueDetailsList.dtls.size(); i++) {

      // BEGIN, CR00230584, ELG
      evidenceIssuesDetails = new EvidenceIssuesDetails();

      // Note, that only issueID, description, caseID and evidenceType
      // are guaranteed to be set in IssueDetails after call to EvidenceIssues
      // interface methods. All other details in IssueDetails are not mandatory
      // (for return) and can be set or not, depending on the particular issue.
      issueDetails = issueDetailsList.dtls.item(i);

      // Retrieve the evidence ID. This is used for the modify evidence link
      if (issueDetails.evidenceDescriptorID != 0) {

        evidenceDescriptorKey.evidenceDescriptorID = issueDetails.evidenceDescriptorID;
        evidenceIssuesDetails.evidenceID = evidenceDescriptorObj.read(evidenceDescriptorKey).relatedID;

      }

      evidenceIssuesDetails.evidenceType = issueDetails.evidenceType;
      evidenceIssuesDetails.subject = issueDetails.description;
      evidenceIssuesDetails.evidenceDescriptorID = issueDetails.evidenceDescriptorID;
      // END, CR00230584

      evidenceIssuesDetailsList.dtls.addRef(evidenceIssuesDetails);

    }

    evidenceIssuesDetailsList.caseID = caseID;

    return evidenceIssuesDetailsList;
  }

  // BEGIN, CR00397587, PS
  /**
   * Lists all of the issues for a given evidence type.
   *
   * @boread Evidence
   *
   * @boread Issue
   *
   * @param key Evidence type identifier.
   *
   * @return A list of evidence issues for a given evidence type.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public EvidenceIssuesDetailsList listIssuesForEvidenceType(
    final EvidenceTypeWorkspaceKey key) throws AppException,
      InformationalException {
    // Retrieve the list of issues for the case
    final IssueDetailsList issueDetailsList = evidenceIssues.listIssuesForEvidenceType(
      key.caseID, CASEEVIDENCEEntry.get(key.evidenceType));

    return getIssueDetails(key.caseID, issueDetailsList);
  }

  // BEGIN, CR00229824, EC

  // BEGIN, CR00397587, PS
  /**
   * Lists all 'In Edit' and 'Pending Removal' evidences for a case, filtering 
   * by Participant and Evidence Type.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key Contains a case identifier, Participant identifier and an 
   * Evidence Type code.
   *
   * @return List of 'In Edit' and 'Pending Removal' Evidence
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ListAllInEditDtls listAllInEdit(CaseIDParticipantIDEvidenceTypeKey key)
    throws AppException, InformationalException {

    ListAllInEditDtls listAllInEditDtls = EvidenceControllerFactory.newInstance().listAllInEdit(
      key);
   
    // BEGIN, CR00428387, GK
    for (curam.core.sl.infrastructure.struct.EvidenceParticipantDtls evidenceParticipantDtlsObj : listAllInEditDtls.evidenceParticipantDtlsList.dtls) {
      if (evidenceParticipantDtlsObj.verificationOrIssuesExist) {
        listAllInEditDtls.hasVerificationsOrIssues = true;
      }
      if (evidenceParticipantDtlsObj.isUnevaluatedEvidence) {
        listAllInEditDtls.hasUnevaluatedEvidenceOpt = true;
      }
    } 
    // END, CR00428387

    return listAllInEditDtls;
  }

  // END, CR00229824

  // BEGIN, CR00397587, PS
  // ____________________________________________________________________________
  /**
   * Returns a list of business objects for the given case id and list of 
   * Evidence types.
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key CaseID and list of evidence types.
   *
   * @return List of business objects.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public BusinessObjectSummaryList listPossibleRelatedObjects(
    CaseIDAndLongEvidenceTypeList key) throws AppException,
      InformationalException {

    BusinessObjectSummaryList returnStruct = new BusinessObjectSummaryList();

    List<String> evidenceTypeList = StringUtil.delimitedText2StringList(
      key.evidenceTypeList, '|');

    EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

    BusinessObjectEvidenceTypeKey businessObjectTypeKey = new BusinessObjectEvidenceTypeKey();

    businessObjectTypeKey.caseID = key.caseID;

    SuccessionID successionID = new SuccessionID();

    for (String evidenceType : evidenceTypeList) {

      businessObjectTypeKey.evidenceType = evidenceType;
      BusinessObjectSummaryList summaryList = evidenceControllerObj.listBusinessObjectsForEvidenceType(
        businessObjectTypeKey);

      for (int i = 0; i < summaryList.dtls.size(); i++) {
        successionID.successionID = summaryList.dtls.item(i).successionID;
        EvdInstanceChangeDtlsList changeList = listActiveEvdInstanceChanges(
          successionID);

        if (changeList.dtlsList.size() != 1
          || !changeList.dtlsList.item(0).pendingRemovalInd) {
          returnStruct.dtls.addRef(summaryList.dtls.item(i));
        }
      }

    }

    return returnStruct;
  }

  // BEGIN, CR00397587, PS
  // ____________________________________________________________________________
  /**
   * Returns a list of business objects for a given caseID and list of evidence 
   * types
   *
   * @boread Evidence
   *
   * @boread EvidenceController
   *
   * @param key CaseID and list of evidence types.
   *
   * @return List of business objects.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public BusinessObjectSummaryList listBusinessObjects(
    CaseIDAndLongEvidenceTypeList key) throws AppException,
      InformationalException {

    BusinessObjectSummaryList returnStruct = new BusinessObjectSummaryList();

    List<String> evidenceTypeList = StringUtil.delimitedText2StringList(
      key.evidenceTypeList, '|');

    EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

    BusinessObjectEvidenceTypeKey businessObjectTypeKey = new BusinessObjectEvidenceTypeKey();

    businessObjectTypeKey.caseID = key.caseID;

    for (String evidenceType : evidenceTypeList) {

      businessObjectTypeKey.evidenceType = evidenceType;
      BusinessObjectSummaryList summaryList = evidenceControllerObj.listBusinessObjectsForEvidenceType(
        businessObjectTypeKey);

      returnStruct.dtls.addAll(summaryList.dtls);
    }

    return returnStruct;
  }

  // BEGIN, CR00236468, GYH
  
  // BEGIN, CR00397587, PS
  /**
   * Returns an informational message about the incoming evidence for a given 
   * case identifier.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key Contains case identifier.
   *
   * @return An informational message about the incoming evidence.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ECWarningsDtlsList getIncomingEvidenceInformation(final CaseKey key)
    throws AppException, InformationalException {

    // Check if there are any incoming evidence for the given case identifier.
    boolean isIncomingEvidenceFound = false;
    // BEGIN, CR00379700, SSK
    final CaseIDAndStatuses caseIDAndStatuses = new CaseIDAndStatuses();

    caseIDAndStatuses.caseID = key.caseID;
    caseIDAndStatuses.statusCode1 = EVIDENCEDESCRIPTORSTATUS.IDENTICALINEDIT;
    caseIDAndStatuses.statusCode2 = EVIDENCEDESCRIPTORSTATUS.NONIDENTICALINEDIT;
    final EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();
    
    if (!evidenceDescriptorObj.searchEvidenceByCaseIDAndStatus(caseIDAndStatuses).dtls.isEmpty()) {
      isIncomingEvidenceFound = true;
    }
    // END, CR00379700
    
    // If there are any incoming evidence for the given case identifier then
    // construct and return the informational message about the incoming
    // evidence.
    ECWarningsDtlsList ecWarningsDtlsList = new ECWarningsDtlsList();
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (isIncomingEvidenceFound) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        BPOEVIDENCECONTROLLERExceptionCreator.INF_INCOMING_EVIDENCE_INFORMATION(),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      String warnings[] = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

        ecWarningsDtls.msg = warnings[i];
        ecWarningsDtlsList.dtls.addRef(ecWarningsDtls);
      }
    }

    return ecWarningsDtlsList;
  }

  // END, CR00236468

  // BEGIN, CR00265745, JMA
  
  // BEGIN, CR00397587, PS
  /**
   * Delegates to the listCaseMembersAndEvidenceForTransfer method or the 
   * getEvidenceDetailsForTransfer method based on the action id passed in.
   *
   * @boread Evidence
   *
   * @boread Participant
   *
   * @boread Case
   *
   * @param key Evidence Transfer key.
   *
   * @return Evidence Transfer Details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public curam.core.facade.infrastructure.struct.TransferEvidenceDetails transferEvidenceDetails(
    TransferEvidenceKey key) throws AppException, InformationalException {

    curam.core.facade.infrastructure.struct.TransferEvidenceDetails transferEvidenceDetails = new curam.core.facade.infrastructure.struct.TransferEvidenceDetails();

    if (key.actionIDProperty.equals(CuramConst.kYES)) {

      key.dtls.actionIDProperty = CuramConst.kYES;
      transferEvidenceDetails.dtls = getEvidenceDetailsForTransfer(key.dtls);

    } else {

      ConcernRoleKey concernRoleKey = new ConcernRoleKey();
      CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();
      CaseParticipantRoleKey caseParticipantRoleKey = new CaseParticipantRoleKey();

      if (key.dtls.caseParticipantRoleID != 0) {

        caseParticipantRoleKey.caseParticipantRoleID = key.dtls.caseParticipantRoleID;

        concernRoleKey.concernRoleID = caseParticipantRoleObj.readParticipantRoleDetails(caseParticipantRoleKey).concernRoleID;

      } else {

        final curam.core.sl.entity.struct.CaseIDTypeCodeKey caseIDTypeCodeKey = new curam.core.sl.entity.struct.CaseIDTypeCodeKey();

        caseIDTypeCodeKey.caseID = key.caseIDAndEvidenceKey.caseID;
        caseIDTypeCodeKey.typeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
        caseParticipantRoleKey.caseParticipantRoleID = CaseParticipantRoleFactory.newInstance().readByCaseIDAndTypeCode(caseIDTypeCodeKey).dtls.caseParticipantRoleID;

        concernRoleKey.concernRoleID = caseParticipantRoleObj.readParticipantRoleDetails(caseParticipantRoleKey).concernRoleID;
      }

      CaseIDAndEvidenceTypeKey caseIDAndEvidenceTypeKey = new CaseIDAndEvidenceTypeKey();

      caseIDAndEvidenceTypeKey.caseID = key.caseIDAndEvidenceKey.caseID;
      caseIDAndEvidenceTypeKey.evidenceType = key.caseIDAndEvidenceKey.evidenceType;

      transferEvidenceDetails.caseMemberEvidenceList = listCaseMembersAndEvidenceForTransfer(
        caseIDAndEvidenceTypeKey, concernRoleKey);

    }

    return transferEvidenceDetails;

  }

  // END, CR00265745
  // BEGIN, CR00279713, AC
  
  // BEGIN, CR00397587, PS
  /**
   * Returns case ID for an Evidence.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key Case Evidence Tree Key.
   *
   * @return Case ID.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public CaseID readCaseID(CaseEvidenceTreeKey key) throws AppException, InformationalException {
    final CaseID caseID = new CaseID();
    final CaseEvidenceTreeDtls caseEvidenceTreeDtls = readCaseEvidenceTree(key);

    caseID.caseID = caseEvidenceTreeDtls.caseID;
    return caseID;
  }

  // BEGIN, CR00397587, PS
  /**
   * Returns case ID , related ID and the Evidence type details for an 
   * Evidence.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key Evidence Descriptor Key.
   *
   * @return Case ID, related ID and the Evidence type details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public CaseIDRelatedIDAndEvidenceTypeDtlsList readCaseIDandEvidenceType(
    EvidenceDescriptorKey key)
    throws AppException, InformationalException {

    final CaseIDRelatedIDAndEvidenceTypeDtlsList caseIDRelatedIDAndEvidenceTypeDtlsList = new
      CaseIDRelatedIDAndEvidenceTypeDtlsList();
    CaseIDRelatedIDAndEvidenceTypeDtls caseIDRelatedIDAndEvidenceTypeDtls;

    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = readEvidenceDescriptor(
      key);

    for (EvidenceDescriptorDtls dtls:evidenceDescriptorDtlsList.dtls.items()) {
      caseIDRelatedIDAndEvidenceTypeDtls = new CaseIDRelatedIDAndEvidenceTypeDtls();
      caseIDRelatedIDAndEvidenceTypeDtls.caseID = dtls.caseID;
      caseIDRelatedIDAndEvidenceTypeDtls.evidenceType = dtls.evidenceType;
      caseIDRelatedIDAndEvidenceTypeDtls.relatedID = dtls.relatedID;
      caseIDRelatedIDAndEvidenceTypeDtlsList.dtls.addRef(
        caseIDRelatedIDAndEvidenceTypeDtls);
    }

    return caseIDRelatedIDAndEvidenceTypeDtlsList;
  }

  // END, CR00233772
  // BEGIN, CR00345678, ZV
  // ___________________________________________________________________________
  /**
   * Generates the menu data for a Participant Data Case.
   *
   * @param key Contains the case identifier.
   *
   * @return Menu data for a participant data case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  protected curam.core.facade.infrastructure.struct.MenuData getParticipantDataCaseMenuData(
    CaseKey key) throws AppException, InformationalException {

    curam.core.facade.infrastructure.struct.MenuData menuData = new curam.core.facade.infrastructure.struct.MenuData();

    ProductHookManager productHookManager = new ProductHookManager();

    MenuData menuDataObj = productHookManager.getMenuDataHook(
      CASETYPECODE.PARTICIPANTDATACASE);

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    menuData.menuData = menuDataObj.getParticipantDataCaseMenuData(caseHeaderKey).menuData;

    return menuData;
  }

  // END, CR00345678


  // BEGIN, CR00352812, BF
  
  // BEGIN, CR00397587, PS
  /**
   * Retrieves the list of ALL evidence (active and in edit) associated with the 
   * case.
   *
   * @param key Contains a case identifier.
   *
   * @return result A list of 'In Edit' and 'Active' evidence for the Case.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00397587
  public ListAllEvidenceDtls listAllEvidence(
    final curam.core.facade.infrastructure.struct.CaseKey caseKey)
    throws AppException, InformationalException {

    ListAllEvidenceDtls result = new ListAllEvidenceDtls();

    final CaseIDParticipantIDEvidenceTypeKey caseIDEvidenceTypeKey = new CaseIDParticipantIDEvidenceTypeKey();

    caseIDEvidenceTypeKey.caseIDKey.caseID = caseKey.caseID;

    result.caseID = caseKey.caseID;
    final ListAllInEditDtls inEditEvd = EvidenceControllerFactory.newInstance().listAllInEdit(
      caseIDEvidenceTypeKey);

    // assign in-edit evidence to return struct
    result = assignInEditEvidenceParticipantDtlsList(result, inEditEvd);
    result.caseID = caseKey.caseID;

    final curam.core.struct.CaseKey key = new curam.core.struct.CaseKey();

    key.caseID = caseKey.caseID;
    final ActiveEvdInstanceDtlsList activeEvdInstanceDtlsList = EvidenceControllerFactory.newInstance().listAllactiveEvdInstances(
      key);

    // assign active evidence to return struct.
    result = assignActiveEvidenceParticipantDtlsList(result,
      activeEvdInstanceDtlsList);
    // BEGIN, CR00424202, JD
    
    // Create a new instance of interface EvidenceUpdatesAllowed.
    // And determine whether a case, depending on it's status will allow for
    // Enabling/Disabling page-level actions.
    final EvidenceUpdatesAllowed evidenceUpdatesAllowed = new EvidenceUpdatesAllowed();
    boolean evidenceUpdatesAllowedInd = evidenceUpdatesAllowed.isUpdatesAllowed(
      key);
    
    // Set the appropriate indicator in return struct
    if (evidenceUpdatesAllowedInd == false) {
      result.caseUpdatesAllowed = false;
      
      // Set the readOnlyInd to true for each evidence item, to disable the row-level actions
      for (int i = 0; i
        < result.evidenceParticipantDtlsList.dtls.items().length; i++) {
        result.evidenceParticipantDtlsList.dtls.item(i).readOnlyInd = true;
      }
    } else {
      result.caseUpdatesAllowed = true;
    }
    
    // END, CR00424202, JD

    return result;

  }

  /**
   * Assigns in-edit evidence details to return list.
   *
   * @param listAllEvidenceDtls
   * The overall return structure that will contain both active and
   * in-edit evidence.
   * @param inEditEvidenceDtls
   * The In-Edit Evidence details retrieved.
   *
   * @return The overall return structure that will contain both active and
   * in-edit evidence.
   */
  private ListAllEvidenceDtls assignInEditEvidenceParticipantDtlsList(
    final ListAllEvidenceDtls listAllEvidenceDtls,
    final ListAllInEditDtls inEditEvidenceDtls) throws AppException,
      InformationalException {

    for (final curam.core.sl.infrastructure.struct.EvidenceParticipantDtls evidenceParticipantDtls : inEditEvidenceDtls.evidenceParticipantDtlsList.dtls) {
      final EvidenceParticipantDtls newEvidenceParticipantDtls = new EvidenceParticipantDtls();

      newEvidenceParticipantDtls.activeEvidence = false;
      newEvidenceParticipantDtls.caseID = evidenceParticipantDtls.caseID;
      newEvidenceParticipantDtls.endDate = evidenceParticipantDtls.endDate;
      newEvidenceParticipantDtls.evidenceType = evidenceParticipantDtls.evidenceType;
      newEvidenceParticipantDtls.latestActivity = evidenceParticipantDtls.latestActivity;
      newEvidenceParticipantDtls.participantID = evidenceParticipantDtls.participantID;
      newEvidenceParticipantDtls.participantName = evidenceParticipantDtls.participantName;
      newEvidenceParticipantDtls.period = evidenceParticipantDtls.period;
      newEvidenceParticipantDtls.startDate = evidenceParticipantDtls.startDate;
      newEvidenceParticipantDtls.successionID = evidenceParticipantDtls.successionID;
      newEvidenceParticipantDtls.summary = evidenceParticipantDtls.summary;
      // BEGIN, CR00417992, DG
      newEvidenceParticipantDtls.readOnlyInd = evidenceParticipantDtls.readOnlyInd;
      // END, CR00417992

      populateEvidenceIDandDescriptorID(newEvidenceParticipantDtls);
      newEvidenceParticipantDtls.evidenceDetailsPanelURL = determineEvidencePagePanel(newEvidenceParticipantDtls).getURI();

      // Do not show the InEdit Record Succession twice if already exists in the
      // Active Record on this case.
      if (!isEvidenceSharedIntancePresentOnActiveEvidence(
        newEvidenceParticipantDtls)) {
        listAllEvidenceDtls.evidenceParticipantDtlsList.dtls.add(
          newEvidenceParticipantDtls);
      }

    }

    return listAllEvidenceDtls;
  }

  /**
   * Assigns active evidence details to return list.
   *
   * @param listAllEvidenceDtlsResult
   * The return struct where the evidenceParticipant details will be
   * added to.
   * @param activeEvdDetails
   * The active evidence details.
   * @return The details of all the evidence.
   */
  private ListAllEvidenceDtls assignActiveEvidenceParticipantDtlsList(
    final ListAllEvidenceDtls listAllEvidenceDtlsResult,
    final ActiveEvdInstanceDtlsList activeEvdDetails) throws AppException,
      InformationalException {

    for (final ActiveEvdInstanceDtls activeEvdInstanceDtls : activeEvdDetails.dtls) {
      final EvidenceParticipantDtls newEvidenceParticipantDtls = new EvidenceParticipantDtls();

      newEvidenceParticipantDtls.activeEvidence = true;
      newEvidenceParticipantDtls.endDate = activeEvdInstanceDtls.endDate;
      newEvidenceParticipantDtls.evidenceType = activeEvdInstanceDtls.evidenceType;
      newEvidenceParticipantDtls.latestActivity = activeEvdInstanceDtls.latestActivity;
      newEvidenceParticipantDtls.participantID = activeEvdInstanceDtls.participantID;
      newEvidenceParticipantDtls.participantName = activeEvdInstanceDtls.concernRoleName;
      newEvidenceParticipantDtls.period = activeEvdInstanceDtls.period;
      newEvidenceParticipantDtls.startDate = activeEvdInstanceDtls.startDate;
      newEvidenceParticipantDtls.successionID = activeEvdInstanceDtls.successionID;
      newEvidenceParticipantDtls.summary = activeEvdInstanceDtls.summary;
      newEvidenceParticipantDtls.caseID = listAllEvidenceDtlsResult.caseID;
      // BEGIN, CR00417992, DG
      newEvidenceParticipantDtls.readOnlyInd = activeEvdInstanceDtls.readOnlyInd;
      // END, CR00417992
      
      // populate the evidence descriptorID and evidenceID
      populateEvidenceIDandDescriptorID(newEvidenceParticipantDtls);
      newEvidenceParticipantDtls.evidenceDetailsPanelURL = determineEvidencePagePanel(newEvidenceParticipantDtls).getURI();

      // If only one instance exist for this active record, set the indicator.
      final SuccessionID successionIDKey = new SuccessionID();

      successionIDKey.successionID = newEvidenceParticipantDtls.successionID;
      if (listActiveEvdInstanceChanges(successionIDKey).dtlsList.size() == 1) {
        newEvidenceParticipantDtls.activeWithSingleInstanceInd = true;
      }

      // Add details to result
      listAllEvidenceDtlsResult.evidenceParticipantDtlsList.dtls.add(
        newEvidenceParticipantDtls);

    }

    return listAllEvidenceDtlsResult;
  }

  /**
   * Assigns the evidenceID and evidenceDescriptorID for evidence.
   *
   * @param evidenceParticipantDtls
   * The Evidence Participant Details.
   *
   */
  private void populateEvidenceIDandDescriptorID(
    final EvidenceParticipantDtls evidenceParticipantDtls)
    throws AppException, InformationalException {

    EvdInstanceChangeDtlsList evdInstanceChangeDtlsList = new EvdInstanceChangeDtlsList();
    final SuccessionID successionID = new SuccessionID();

    successionID.successionID = evidenceParticipantDtls.successionID;

    if (!evidenceParticipantDtls.activeEvidence) {
      evdInstanceChangeDtlsList = listInEditEvdInstanceChanges(successionID);
      evidenceParticipantDtls.evidenceDescriptorID = evdInstanceChangeDtlsList.dtlsList.get(CuramConst.gkZero).evidenceDescriptorID;
      evidenceParticipantDtls.evidenceID = evdInstanceChangeDtlsList.dtlsList.get(CuramConst.gkZero).evidenceID;
    } else if ((evidenceParticipantDtls.activeEvidence)
      && (listActiveEvdInstanceChanges(successionID).dtlsList.size() == 1)) {
      // Should ever be one
      evdInstanceChangeDtlsList = listActiveEvdInstanceChanges(successionID);
      evidenceParticipantDtls.evidenceDescriptorID = evdInstanceChangeDtlsList.dtlsList.get(CuramConst.gkZero).evidenceDescriptorID;
      evidenceParticipantDtls.evidenceID = evdInstanceChangeDtlsList.dtlsList.get(CuramConst.gkZero).evidenceID;
    } else {

      // If multiple instances get the latest one
      evdInstanceChangeDtlsList = listActiveEvdInstanceChanges(successionID);
      final int position = checkForEffectiveDate(evdInstanceChangeDtlsList);

      evidenceParticipantDtls.evidenceDescriptorID = evdInstanceChangeDtlsList.dtlsList.get(position).evidenceDescriptorID;
      evidenceParticipantDtls.evidenceID = evdInstanceChangeDtlsList.dtlsList.get(position).evidenceID;
    }
  }

  /**
   * Determines the evidence preview panel page details based on the evidence
   * details.
   *
   * @param evidenceParticipantDtls
   * The specific evidence details.
   *
   * @return ClientURI The preview panel URI page to be displayed.
   */
  private ClientURI determineEvidencePagePanel(
    final EvidenceParticipantDtls evidenceParticipantDtls)
    throws AppException, InformationalException {

    // Determine if there are multiple instance of the evidence record
    final SuccessionID sucessionIDKey = new SuccessionID();

    sucessionIDKey.successionID = evidenceParticipantDtls.successionID;

    // If multiple instances for this evidence record exist
    if (evidenceParticipantDtls.activeEvidence
      && EvidenceFactory.newInstance().listActiveEvdInstanceChanges(sucessionIDKey).dtlsList.size()
        > 1) {
      return evidenceURIHelper.getEvidenceListMultipleInstancesURI(
        evidenceParticipantDtls.successionID);
    } else {
      return evidenceURIHelper.getEvidenceDetailsPanelURI(
        evidenceParticipantDtls);
    }
  }

  /**
   * Determines if an InEdit Evidence succession record shares the same
   * sharedInstanceID on any active record on a specified case. If this
   * succession already exist for an active record, returns true.
   *
   * @param evidenceParticipantDtls
   * The specific evidence details.
   *
   * @return Indicator to determine if the sharedInstanceID already exists on an
   * active record.
   */
  private boolean isEvidenceSharedIntancePresentOnActiveEvidence(
    final EvidenceParticipantDtls evidenceParticipantDtls)
    throws AppException, InformationalException {

    // Determine if there are other instances of the sharedInstanceID on an
    // active record.
    final SharedInstanceIDCaseIDStatusCode sharedInstanceKey = new SharedInstanceIDCaseIDStatusCode();
    final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

    evidenceDescriptorKey.evidenceDescriptorID = evidenceParticipantDtls.evidenceDescriptorID;

    final EvidenceDescriptor evidenceDecscriptorObj = EvidenceDescriptorFactory.newInstance();

    // Searches for all active records with the same shared instance ID on the
    // specified case.
    final long sharedInstanceID = evidenceDecscriptorObj.read(evidenceDescriptorKey).sharedInstanceID;

    sharedInstanceKey.sharedInstanceID = sharedInstanceID;

    sharedInstanceKey.caseID = evidenceParticipantDtls.caseID;
    sharedInstanceKey.statusCode = EVIDENCEDESCRIPTORSTATUS.ACTIVE;

    if (evidenceDecscriptorObj.searchActiveBySharedInstanceIDCaseID(sharedInstanceKey).dtls.size()
      > 0) {
      // An active shared instanceID exists for this record.
      return true;
    }
    return false;
  }

  /**
   * Returns the correct position of the latest {@link #evidenceDescriptorID} in
   * a list of {@link #EvdInstanceChangeDtlsList}.
   *
   * @param evdInstanceChangeDtlsList
   * The evidence Details
   * @return The position of the latest {@link #evidenceDescriptorID} in a list
   * of {@link #EvdInstanceChangeDtlsList}.
   */
  private int checkForEffectiveDate(
    final EvdInstanceChangeDtlsList evdInstanceChangeDtlsList)
    throws AppException, InformationalException {
    int loopControl = 0;
    int returnPosition = 0;
    DateTime changedDatetime = null;
    DateTime latestChangedDatetime = null;

    // loop through the Evidence Change History to get the most up to date
    // evidence entry
    for (final EvdInstanceChangeDtls evdInstanceChangeDtls : evdInstanceChangeDtlsList.dtlsList) {
      final EvidenceChangeHistory evidenceChangeHistoryObj = EvidenceChangeHistoryFactory.newInstance();
      final EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();

      evidenceDescriptorKey.evidenceDescriptorID = evdInstanceChangeDtls.evidenceDescriptorID;
      final EvidenceChangeHistoryDtlsList evidenceChangeHistoryDtlsList = evidenceChangeHistoryObj.searchByEvidenceDescriptorID(
        evidenceDescriptorKey);

      for (final EvidenceChangeHistoryDtls evidenceChangeHistoryDtls : evidenceChangeHistoryDtlsList.dtls) {
        if (latestChangedDatetime == null) {
          latestChangedDatetime = evidenceChangeHistoryDtls.changeDateTime;
        } else {
          if (evidenceChangeHistoryDtls.changeDateTime.after(
            latestChangedDatetime)) {
            latestChangedDatetime = evidenceChangeHistoryDtls.changeDateTime;
          }
        }
      }
      if (changedDatetime == null) {
        changedDatetime = latestChangedDatetime;
        returnPosition = loopControl;
      }
      if (latestChangedDatetime.after(changedDatetime)) {
        changedDatetime = latestChangedDatetime;
        returnPosition = loopControl;
      }
      loopControl++;
    }
    return returnPosition;

  }

  // END, CR00352812


  /**
   * Retrieve a list of Evidence succession record details for the specified
   * successionId.
   * @param key the successionId on which to retrieve the evidence details
   * list.
   * @return EvidenceDetailsList the list of evidence details for each
   * succession record.
   * @throws AppException generic application exception.
   * @throws InformationalException generic informational exception
   */
  public EvidenceDetailsList listEvidenceSuccessions(
    curam.core.sl.infrastructure.entity.struct.SuccessionID key)
    throws AppException, InformationalException {

    EvidenceDetailsList evidenceList = new EvidenceDetailsList();

    EvdInstanceChangeDtlsList changeList = listActiveEvdInstanceChanges(key);

    if (changeList.dtlsList.size() > 0) {

      for (int i = 0; i < changeList.dtlsList.size(); i++) {
        final EvidenceDetails evidenceDetails = new EvidenceDetails();

        evidenceDetails.caseID = changeList.dtlsList.get(i).caseID;
        evidenceDetails.evidenceDescriptorID = changeList.dtlsList.get(i).evidenceDescriptorID;
        evidenceDetails.evidenceID = changeList.dtlsList.get(i).evidenceID;
        evidenceDetails.successionID = changeList.dtlsList.get(i).successionID;
        evidenceDetails.source = changeList.dtlsList.get(i).source;
        evidenceDetails.updatedBy = changeList.dtlsList.get(i).latestActivity;
        evidenceDetails.period = changeList.dtlsList.get(i).period;
        evidenceDetails.evidenceType = changeList.dtlsList.get(i).evidenceType;

        EvidenceDescriptorKey evidenceDescriptorKey = new EvidenceDescriptorKey();
        EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

        evidenceDescriptorKey.evidenceDescriptorID = changeList.dtlsList.get(i).evidenceDescriptorID;
        EvidenceDescriptorDtls evidenceDescriptorDtls2 = evidenceDescriptorObj.read(
          evidenceDescriptorKey);

        EvidenceTypeKey evidenceTypeKey = new EvidenceTypeKey();

        evidenceTypeKey.evidenceType = evidenceDescriptorDtls2.evidenceType;

        if (isEvidenceParticipantData(evidenceTypeKey).participantDataInd) {

          LocalisableString description = new LocalisableString(
            BPOEVIDENCECONTROLLER.INF_DESCRIPTION_PARTICIPANT);

          description.arg(evidenceDescriptorDtls2.receivedDate);
          evidenceDetails.changeSummary = description.toClientFormattedText();

        } else {

          LocalisableString description = new LocalisableString(
            BPOEVIDENCECONTROLLER.INF_DESCRIPTION);

          description.arg(evidenceDescriptorDtls2.receivedDate);
          description.arg(
            new CodeTableItemIdentifier(EVIDENCECHANGEREASON.TABLENAME,
            evidenceDescriptorDtls2.changeReason));
          evidenceDetails.changeSummary = description.toClientFormattedText();

        }

        // Read the source of the evidence
        final LocalisableString source = getEvidenceSource(evidenceDetails);

        evidenceDetails.source = source.toClientFormattedText();

        evidenceList.dtls.add(evidenceDetails);
      }
    }

    return evidenceList;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves the originating source of this evidence record. If the
   * evidence was shared via the evidence broker this will return the name of
   * the originating case, otherwise the source will be the participant record.
   *
   * @param concernRoleKey
   * The unique identifier for the participant.
   *
   * @param pdcEvidence
   * The evidence details.
   *
   * @return Text displaying the source of the evidence in the user's locale.
   */
  protected LocalisableString getEvidenceSource(EvidenceDetails evidenceDetails)
    throws AppException, InformationalException {

    // Create a place holder for the source of the evidence
    String tempSource = CuramConst.gkEmpty;

    // Get the evidence descriptor record
    EvidenceDescriptorDtls evidenceDescriptorDtls = new EvidenceDescriptorDtls();
    EvidenceDescriptor evidenceDescriptorObj = EvidenceDescriptorFactory.newInstance();

    RelatedIDEvidenceTypeAndCaseIDKey relEvKey = new RelatedIDEvidenceTypeAndCaseIDKey();

    relEvKey.caseID = evidenceDetails.caseID;
    relEvKey.evidenceType = evidenceDetails.evidenceType;
    relEvKey.relatedID = evidenceDetails.evidenceID;

    evidenceDescriptorDtls = evidenceDescriptorObj.readByRelatedIDTypeAndCaseID(
      relEvKey);

    // Check if the evidence was shared from another case
    if (evidenceDescriptorDtls.sharedInd) {

      // Get the case type of the source case
      CaseKey sourceCaseKey = new CaseKey();

      sourceCaseKey.caseID = evidenceDescriptorDtls.sourceCaseID;
      // BEGIN, CR00364401, ZV
      tempSource = getSourceCaseDescription(sourceCaseKey);
      // END, CR00364401
    } else {

      // Check the concern role type

      CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
      CaseKey caseKey = new CaseKey();

      CaseReferenceCRNameAltIDDetails caseReferenceCRNameAltIDDetails;

      CaseHeaderKey cKey = new CaseHeaderKey();

      cKey.caseID = evidenceDetails.caseID;
      // read case details to get case reference number and participant name
      caseKey.caseID = evidenceDetails.caseID;
      caseReferenceCRNameAltIDDetails = caseHeaderObj.readCaseReferenceConcernRoleNameAndAlternateID(
        caseKey);

      final ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();
      final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(cKey);

      // Check the concern role type
      final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;
      final ConcernRoleTypeDetails concernRoleTypeDetails = concernRoleObj.readConcernRoleType(
        concernRoleKey);

      // Dependency on PDC here should be removed but due to time-line on localization
      // new entries in core message files will need to wait.
      if (concernRoleTypeDetails.concernRoleType.equals(CONCERNROLETYPE.PERSON)) {

        tempSource = PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PERSON.toString();
      } else if (concernRoleTypeDetails.concernRoleType.equals(
        CONCERNROLETYPE.PROSPECTPERSON)) {

        tempSource = PDCEVIDENCEDESCRIPTION.INF_PDC_EV_SOURCE_PROSPECT.toString();
      }
    }

    final LocalisableString source = new LocalisableString(PDCEVIDENCEDESCRIPTION.PDC_GEN_DESC).arg(
      tempSource);

    return source;
  }
  
  // BEGIN, CR00426702, GK
  /**
   * Returns an informational message about the un evaluated evidence for a given 
   * case identifier.
   *
   * @boread Evidence
   *
   * @boread Case
   *
   * @param key Contains case identifier.
   *
   * @return An informational message about the unevaluated evidence.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ECWarningsDtlsList getUnevaluatedEvidenceInformation(final CaseKey key)
    throws AppException, InformationalException {

    // Check if there are any unevaluated evidence for the given case identifier.
    boolean isUnevaluatedEvidenceFound = false;
    CaseID caseID = new CaseID();

    caseID.caseID = key.caseID;
    // BEGIN, CR00427296, AKr
    final EvidenceDescriptorDtlsList evidenceDescriptorDtlsList = postponeVerificationInterface.listEvidenceswithpostponedVerifications(
      caseID);
    
    isUnevaluatedEvidenceFound = evidenceDescriptorDtlsList.dtls.size() > 0;  
    // END, CR00427296
    // If there are any un evaluated evidence for the given case identifier then
    // construct and return the informational message about the unevaluated
    // evidence.
    final ECWarningsDtlsList ecWarningsDtlsList = new ECWarningsDtlsList();
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    if (isUnevaluatedEvidenceFound) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        BPOEVIDENCECONTROLLERExceptionCreator.INF_UNEVALUATED_EVIDENCE_INFORMATION(),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kWarning,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      String warnings[] = informationalManager.obtainInformationalAsString();

      for (int i = 0; i < warnings.length; i++) {
        ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

        ecWarningsDtls.msg = warnings[i];
        ecWarningsDtlsList.dtls.addRef(ecWarningsDtls);
      }
    }

    return ecWarningsDtlsList;
  }
  // END, CR00426702

}
