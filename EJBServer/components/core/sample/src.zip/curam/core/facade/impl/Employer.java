/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright  2002-2007, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import curam.codetable.CONCERNROLETYPE;
import curam.codetable.EMPLOYERRELATIONSHIPTYPES;
import curam.codetable.RELATIONSHIPTYPECODE;
import curam.codetable.impl.RELATIONSHIPTYPECODEEntry;
import curam.core.events.CONCERNROLERELATIONSHIP;
import curam.core.facade.fact.ParticipantContextFactory;
import curam.core.facade.fact.ParticipantFactory;
import curam.core.facade.intf.Participant;
import curam.core.facade.struct.AddressString;
import curam.core.facade.struct.AllParticipantSearchDetails;
import curam.core.facade.struct.AllParticipantSearchKey;
import curam.core.facade.struct.AllParticipantSearchResult;
import curam.core.facade.struct.BankAccountListForRedirectionDetails;
import curam.core.facade.struct.BankAccountString;
import curam.core.facade.struct.CancelCommunicationKey;
import curam.core.facade.struct.CancelContactKey;
import curam.core.facade.struct.CancelEmployerRelationshipKey;
import curam.core.facade.struct.CancelParticipantAddressKey;
import curam.core.facade.struct.CancelParticipantAlternateIDKey;
import curam.core.facade.struct.CancelParticipantBankAccountKey;
import curam.core.facade.struct.CancelParticipantCommunicationExceptionKey;
import curam.core.facade.struct.CancelParticipantEmailAddressKey;
import curam.core.facade.struct.CancelParticipantNoteDetails;
import curam.core.facade.struct.CancelParticipantPhoneNumberKey;
import curam.core.facade.struct.CancelParticipantWebAddressDetails;
import curam.core.facade.struct.CancelTradingStatusKey;
import curam.core.facade.struct.CommunicationDetailList;
import curam.core.facade.struct.ConcernRoleKeyStruct;
import curam.core.facade.struct.ConcernRoleTypeDetails;
import curam.core.facade.struct.ContactContextDescriptionDetails;
import curam.core.facade.struct.ContactContextDescriptionKey;
import curam.core.facade.struct.CreateContactDetails;
import curam.core.facade.struct.CreateContactFromUnregisteredParticipant;
import curam.core.facade.struct.CreateEmailCommunicationDetails;
import curam.core.facade.struct.CreateFreeformCommunication;
import curam.core.facade.struct.CreateHomePhoneNumber;
import curam.core.facade.struct.CreateMailingAddress;
import curam.core.facade.struct.CreateParticipantAddressDetails;
import curam.core.facade.struct.CreateParticipantAdminRoleDetails;
import curam.core.facade.struct.CreateParticipantAlternateIDDetails;
import curam.core.facade.struct.CreateParticipantBankAccountDetails;
import curam.core.facade.struct.CreateParticipantEmailAddressDetails;
import curam.core.facade.struct.CreateParticipantPhoneDetails;
import curam.core.facade.struct.CreateTemplateCommunication;
import curam.core.facade.struct.CreateWorkPhoneNumber;
import curam.core.facade.struct.CreatedRelationshipDetails;
import curam.core.facade.struct.EmployerAlternateSearchKey;
import curam.core.facade.struct.EmployerNameAndAddressDetails;
import curam.core.facade.struct.EmployerReadDetails;
import curam.core.facade.struct.EmployerRegistrationResult;
import curam.core.facade.struct.EmployerRelationshipRMDetails;
import curam.core.facade.struct.EmployerSearchDetailsResult;
import curam.core.facade.struct.EmployerSearchKey1;
import curam.core.facade.struct.EmployerSearchResult1;
import curam.core.facade.struct.EndDeductionDetails;
import curam.core.facade.struct.FormattedAddressList;
import curam.core.facade.struct.FormattedBankAccountList;
import curam.core.facade.struct.InformationMsgDtlsList;
import curam.core.facade.struct.InsertPrimaryResAddress;
import curam.core.facade.struct.ListCaseDetails;
import curam.core.facade.struct.ListCaseKey_fo;
import curam.core.facade.struct.ListConcernContactDetails;
import curam.core.facade.struct.ListContactDetails;
import curam.core.facade.struct.ListContactKey;
import curam.core.facade.struct.ListDuplicateParticipantFinancials;
import curam.core.facade.struct.ListDuplicateParticipantInteractionDetails;
import curam.core.facade.struct.ListDuplicateParticipantIssuedPaymentInstrument;
import curam.core.facade.struct.ListInteractionDetails;
import curam.core.facade.struct.ListInteractionKey;
import curam.core.facade.struct.ListParticipantFinancials;
import curam.core.facade.struct.ListParticipantFinancials1;
import curam.core.facade.struct.ListParticipantFinancialsKey;
import curam.core.facade.struct.ListParticipantIssuedPaymentInstrument;
import curam.core.facade.struct.ListParticipantTaskKey_eo;
import curam.core.facade.struct.ListTemplateByTypeAndParticipantKey;
import curam.core.facade.struct.ListTemplateByTypeAndParticpant;
import curam.core.facade.struct.MaintainConcernRoleKey;
import curam.core.facade.struct.MaintainEmployerRelationshipDetails;
import curam.core.facade.struct.MaintainParticipantAddressDetails;
import curam.core.facade.struct.MaintainParticipantAlternateIDDetails;
import curam.core.facade.struct.MaintainParticipantBankAccountDetails;
import curam.core.facade.struct.MaintainParticipantBankAccountWithTextSortCodeDetails;
import curam.core.facade.struct.MaintainParticipantCommunicationExceptionDetails;
import curam.core.facade.struct.MaintainParticipantEmailAddressDetails;
import curam.core.facade.struct.MaintainParticipantPhoneDetails;
import curam.core.facade.struct.MaintainTradingStatusDetails;
import curam.core.facade.struct.ModifiedAddressDetails;
import curam.core.facade.struct.ModifiedAlternateIDDetails;
import curam.core.facade.struct.ModifiedRelationshipDetails;
import curam.core.facade.struct.ModifyCommDetails;
import curam.core.facade.struct.ModifyConcernContactDetails;
import curam.core.facade.struct.ModifyContactDetails;
import curam.core.facade.struct.ModifyEmployerDetails;
import curam.core.facade.struct.ModifyEmployerReturnDetails;
import curam.core.facade.struct.ModifyParticipantNoteDetails;
import curam.core.facade.struct.ModifyParticipantNoteDetails1;
import curam.core.facade.struct.ModifySentCommunicationDetails;
import curam.core.facade.struct.ParticipantAddressStringList;
import curam.core.facade.struct.ParticipantAdministratorDetails;
import curam.core.facade.struct.ParticipantAdministratorDetailsList;
import curam.core.facade.struct.ParticipantAssessmentsList;
import curam.core.facade.struct.ParticipantBankAccountRedirectionKey;
import curam.core.facade.struct.ParticipantBankAccountRedirectionKey1;
import curam.core.facade.struct.ParticipantBankAccountStringList;
import curam.core.facade.struct.ParticipantCommunicationKey;
import curam.core.facade.struct.ParticipantContextDescriptionKey;
import curam.core.facade.struct.ParticipantContextDetails;
import curam.core.facade.struct.ParticipantContextKey;
import curam.core.facade.struct.ParticipantHomePageName;
import curam.core.facade.struct.ParticipantInvestigationList;
import curam.core.facade.struct.ParticipantKey;
import curam.core.facade.struct.ParticipantNoteDetails;
import curam.core.facade.struct.ParticipantNoteKey;
import curam.core.facade.struct.ParticipantNoteList;
import curam.core.facade.struct.ParticipantNoteList1;
import curam.core.facade.struct.ParticipantScreeningList;
import curam.core.facade.struct.ParticipantWebAddressDetails;
import curam.core.facade.struct.ParticipantWebAddressKey;
import curam.core.facade.struct.ParticipantWebAddressList;
import curam.core.facade.struct.ParticipantWebAddressListKey;
import curam.core.facade.struct.PrintCommunicationKey;
import curam.core.facade.struct.ReadActiveBankAccountList;
import curam.core.facade.struct.ReadAddressHistoryList;
import curam.core.facade.struct.ReadAddressHistoryListKey;
import curam.core.facade.struct.ReadAttachmentKey;
import curam.core.facade.struct.ReadCommDetails;
import curam.core.facade.struct.ReadCommKey;
import curam.core.facade.struct.ReadCommunicationAttachmentDetails;
import curam.core.facade.struct.ReadConcernContactDetails;
import curam.core.facade.struct.ReadContactDetails;
import curam.core.facade.struct.ReadContactKey;
import curam.core.facade.struct.ReadDuplicateParticipantConcernRoleList;
import curam.core.facade.struct.ReadDuplicateParticipantDeductionList;
import curam.core.facade.struct.ReadEmployerDetailsDetails;
import curam.core.facade.struct.ReadEmployerDetailsKey;
import curam.core.facade.struct.ReadEmployerHistoryList;
import curam.core.facade.struct.ReadEmployerHistoryListKey;
import curam.core.facade.struct.ReadEmployerHomeDetails;
import curam.core.facade.struct.ReadEmployerHomeKey;
import curam.core.facade.struct.ReadEmployerRelationshipDetails;
import curam.core.facade.struct.ReadEmployerRelationshipKey;
import curam.core.facade.struct.ReadEmployerRelationshipList;
import curam.core.facade.struct.ReadEmployerRelationshipListKey;
import curam.core.facade.struct.ReadInteractionDetails;
import curam.core.facade.struct.ReadInteractionKey;
import curam.core.facade.struct.ReadParticipantActiveAddressList;
import curam.core.facade.struct.ReadParticipantAddressDetails;
import curam.core.facade.struct.ReadParticipantAddressKey;
import curam.core.facade.struct.ReadParticipantAddressList;
import curam.core.facade.struct.ReadParticipantAddressListKey;
import curam.core.facade.struct.ReadParticipantAdminRoleList;
import curam.core.facade.struct.ReadParticipantAdminRoleListKey;
import curam.core.facade.struct.ReadParticipantAltIDHistoryList;
import curam.core.facade.struct.ReadParticipantAltIDHistoryListKey;
import curam.core.facade.struct.ReadParticipantAlternateIDDetails;
import curam.core.facade.struct.ReadParticipantAlternateIDKey;
import curam.core.facade.struct.ReadParticipantAlternateIDList;
import curam.core.facade.struct.ReadParticipantAlternateIDListKey;
import curam.core.facade.struct.ReadParticipantBankAcHistoryList;
import curam.core.facade.struct.ReadParticipantBankAcHistoryListKey;
import curam.core.facade.struct.ReadParticipantBankAccountDetails;
import curam.core.facade.struct.ReadParticipantBankAccountKey;
import curam.core.facade.struct.ReadParticipantBankAccountList;
import curam.core.facade.struct.ReadParticipantBankAccountListKey;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionDetails;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionKey;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionList;
import curam.core.facade.struct.ReadParticipantCommunicationExceptionListKey;
import curam.core.facade.struct.ReadParticipantConcernRoleKey;
import curam.core.facade.struct.ReadParticipantConcernRoleList;
import curam.core.facade.struct.ReadParticipantDeductionList;
import curam.core.facade.struct.ReadParticipantDeductionList1;
import curam.core.facade.struct.ReadParticipantEmailAddressDetails;
import curam.core.facade.struct.ReadParticipantEmailAddressKey;
import curam.core.facade.struct.ReadParticipantEmailAddressList;
import curam.core.facade.struct.ReadParticipantEmailAddressListKey;
import curam.core.facade.struct.ReadParticipantFormattedAddressListKey;
import curam.core.facade.struct.ReadParticipantFormattedBankAccountListKey;
import curam.core.facade.struct.ReadParticipantNoteDetails;
import curam.core.facade.struct.ReadParticipantNoteDetails1;
import curam.core.facade.struct.ReadParticipantPhoneNumberDetails;
import curam.core.facade.struct.ReadParticipantPhoneNumberKey;
import curam.core.facade.struct.ReadParticipantPhoneNumberList;
import curam.core.facade.struct.ReadParticipantPhoneNumberListKey;
import curam.core.facade.struct.ReadParticipantWebAddressDetails;
import curam.core.facade.struct.ReadTradingStatusDetails;
import curam.core.facade.struct.ReadTradingStatusKey;
import curam.core.facade.struct.ReadTradingStatusList;
import curam.core.facade.struct.ReadTradingStatusListKey;
import curam.core.facade.struct.RecordExistingCommunicationDetails;
import curam.core.facade.struct.SearchCaseKey_fo;
import curam.core.facade.struct.SendEmailCommKey;
import curam.core.facade.struct.TasksForConcernAndCaseDetails;
import curam.core.facade.struct.TasksForDuplicateConcernAndCaseDetails;
import curam.core.facade.struct.TradingStatusMessageList;
import curam.core.facade.struct.UpdateBankAccPaymentDtlsKey;
import curam.core.fact.EmployerSearchRouterFactory;
import curam.core.fact.MaintainConcernRoleDetailsFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.EmployerSearchRouter;
import curam.core.intf.MaintainConcernRoleDetails;
import curam.core.sl.infrastructure.impl.CuramCalendarHeaderConst;
import curam.core.sl.infrastructure.impl.XmlMetaDataConst;
import curam.core.sl.infrastructure.struct.ECWarningsDtls;
import curam.core.struct.BankAccountRMDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmployerDetails;
import curam.core.struct.EmployerReadDtls;
import curam.core.struct.EmployerReadDtlsList;
import curam.core.struct.EmployerSearchDetails;
import curam.core.struct.EmployerSearchResult;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.MaintainConcernRoleRelationshipDetails;
import curam.core.struct.MaintainConcernRoleRelationshipKey;
import curam.core.struct.MaintainConcernRoleRelationshipList;
import curam.core.struct.MaintainTradingStatusKey;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ReadConcernRoleKey;
import curam.core.struct.ReadEmployerResult;
import curam.message.GENERALSEARCH;
import curam.message.SEPARATOR;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for the Employer presentation
 * layer.
 */
public abstract class Employer extends curam.core.facade.base.Employer {

  // BEGIN, CR00233791, DJ
  protected static final String kItem = XmlMetaDataConst.kItem;

  protected static final String kDesc = XmlMetaDataConst.kDesc;

  protected static final String kType = XmlMetaDataConst.kType;

  protected static final String kPageID = XmlMetaDataConst.kPageID;

  protected static final String kNavigationMenu = XmlMetaDataConst.kNavigationMenu;

  protected static final String kParam = XmlMetaDataConst.kParam;

  protected static final String kName = XmlMetaDataConst.kName;

  protected static final String kValue = XmlMetaDataConst.kValue;

  protected static final String kTypePerson = XmlMetaDataConst.kTypePerson;

  protected static final String kParamConcernRoleID = XmlMetaDataConst.kParamConcernRoleID;

  protected static final String kCommaSpace = CuramConst.gkComma
    + CuramConst.gkSpace;

  @Deprecated
  protected static final String kSeparator = SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();

  protected static final String kSpace = CuramCalendarHeaderConst.kSpace;

  // BEGIN, CR00238338, PF
  @Deprecated
  protected static final int kMinimumPhoneNumberLength = CuramConst.gkMinimumPhoneNumberLength;
  // END, CR00238338
  // END, CR00233791

  // ___________________________________________________________________________
  /**
   * Searches for an employer by primary alternate ID.
   *
   * @param key
   * reference number to be searched for
   *
   * @return Employer details
   * @deprecated Since Curam 6.0.5.3, replaced by {@link #searchByReferenceNumber()}
   */
  public EmployerReadDetails readByReferenceNumber(
    EmployerAlternateSearchKey key) throws AppException,
      InformationalException {

    // Employer Search object.
    curam.core.intf.EmployerSearchRouter employerSearchRouterObj = curam.core.fact.EmployerSearchRouterFactory.newInstance();

    // Details to be returned.
    EmployerReadDetails employerReadDetails = new EmployerReadDetails();

    // Call the search.
    EmployerReadDtls employerReadDtls = employerSearchRouterObj.readByReferenceNumber(
      key.alternateIDSearchKey);

    if (employerReadDtls != null) {
      employerReadDetails.employerReadDtls = employerReadDtls;
    }

    // Return the details.
    return employerReadDetails;
  }
  
  // ___________________________________________________________________________
  /**
   * Searches for an employer by primary alternate ID.
   *
   * @param key
   * reference number to be searched for
   *
   * @return Employer details.
   * @return Employer details
   */
  public EmployerReadDtlsList searchByReferenceNumber(
    EmployerAlternateSearchKey key) throws AppException,
      InformationalException {

    curam.core.intf.EmployerSearchRouter employerSearchRouterObj = curam.core.fact.EmployerSearchRouterFactory.newInstance();
    
    EmployerReadDtlsList employerReadDtlsList = new EmployerReadDtlsList();
    
    // Call the search.
    employerReadDtlsList = employerSearchRouterObj.searchByReferenceNumber(
      key.alternateIDSearchKey);    
    
    return employerReadDtlsList;
    
  }  

  // ___________________________________________________________________________
  /**
   * @param key
   * data to be searched for.
   *
   * @return Employer details.
   * @return Employer details
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}
   *
   * Searches for an employer by Concern Role ID.
   */
  @Deprecated
  public curam.core.facade.struct.EmployerSearchResult search(
    curam.core.facade.struct.EmployerSearchKey key) throws AppException,
      InformationalException {

    // Employer Search object.
    curam.core.intf.EmployerSearchRouter employerSearchRouterObj = curam.core.fact.EmployerSearchRouterFactory.newInstance();

    // Details to be returned.
    curam.core.facade.struct.EmployerSearchResult employerSearchResult = new curam.core.facade.struct.EmployerSearchResult();

    // Call the search.
    EmployerSearchResult empSearchResult = employerSearchRouterObj.search(
      key.employerSearchKey);

    if (empSearchResult != null) {

      employerSearchResult.employerSearchResult = empSearchResult;
    }

    // Return the details.
    return employerSearchResult;
  }

  // ___________________________________________________________________________
  /**
   * Sets Employer Trading Status record to canceled.
   *
   * @param key
   * identifies trading status to be canceled.
   *
   * @return Trading Status informational messages.
   * @return Trading Status informational messages
   */
  public TradingStatusMessageList cancelTradingStatus(
    CancelTradingStatusKey key)
    throws AppException, InformationalException {

    // Maintain Employer Trading Status object.
    curam.core.intf.MaintainEmployerTradingStatus maintainEmployerTradingStatusObj = curam.core.fact.MaintainEmployerTradingStatusFactory.newInstance();

    // Details to be returned.
    TradingStatusMessageList tradingStatusMessageList = new TradingStatusMessageList();

    // Cancel the Employer Trading Status.
    tradingStatusMessageList.informationalMsgDtlsList = maintainEmployerTradingStatusObj.cancelTradingStatus(
      key.cancelEmployerTradingStatusKey);

    // Return the details.
    return tradingStatusMessageList;
  }

  // ___________________________________________________________________________
  /**
   * Creates an employer trading status record.
   *
   * @param details
   * employer trading details
   */
  public void createTradingStatus(MaintainTradingStatusDetails details)
    throws AppException, InformationalException {

    // Maintain Employer Trading Status object and key.
    curam.core.intf.MaintainEmployerTradingStatus maintainEmployerTradingStatusObj = curam.core.fact.MaintainEmployerTradingStatusFactory.newInstance();

    MaintainTradingStatusKey maintainTradingStatusKey = new MaintainTradingStatusKey();

    // Get the Concern Role ID from the key.
    maintainTradingStatusKey.concernRoleID = details.tradingStatusDetails.concernRoleID;

    // Create the Trading Status record.
    maintainEmployerTradingStatusObj.createTradingStatus(
      maintainTradingStatusKey, details.tradingStatusDetails);
  }

  // ___________________________________________________________________________
  /**
   * Retrieves a list of employer trading status records.
   *
   * @param key
   * identifies employer trading status.
   *
   * @return A trading status list for the Employer.
   */
  public ReadTradingStatusList listTradingStatus(ReadTradingStatusListKey key)
    throws AppException, InformationalException {

    // Maintain Employer Trading Status object.
    curam.core.intf.MaintainEmployerTradingStatus maintainEmployerTradingStatusObj = curam.core.fact.MaintainEmployerTradingStatusFactory.newInstance();

    // Details to be returned.
    ReadTradingStatusList readTradingStatusList = new ReadTradingStatusList();

    // Retrieve the list of trading status's.
    readTradingStatusList.tradingStatusRMDetailsList = maintainEmployerTradingStatusObj.readmultiByConcernRole(
      key.maintainTradingStatusKey);

    // Get the context description for the concern role
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.maintainTradingStatusKey.concernRoleID;

    readTradingStatusList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details
    return readTradingStatusList;
  }

  // ___________________________________________________________________________
  /**
   * Modifies an employer trading status record.
   *
   * @param details
   * employer trading status details.
   *
   * @return Trading Status informational messages.
   * @return Trading Status informational messages
   */
  public TradingStatusMessageList modifyTradingStatus(
    MaintainTradingStatusDetails details) throws AppException,
      InformationalException {

    // Maintain Employer Trading Status object and key.
    curam.core.intf.MaintainEmployerTradingStatus maintainEmployerTradingStatusObj = curam.core.fact.MaintainEmployerTradingStatusFactory.newInstance();

    MaintainTradingStatusKey maintainTradingStatusKey = new MaintainTradingStatusKey();

    // Details to be returned.
    TradingStatusMessageList tradingStatusMessageList = new TradingStatusMessageList();

    // Get the Concern Role ID from the key.
    maintainTradingStatusKey.concernRoleID = details.tradingStatusDetails.concernRoleID;

    // Modify the Trading Status record.
    maintainEmployerTradingStatusObj.modifyTradingStatus(
      maintainTradingStatusKey, details.tradingStatusDetails);

    // BEGIN, CR00016578, SPD
    // Create an informational manager
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    String[] warnings = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = warnings[i];
      tradingStatusMessageList.informationalMsgDtlsList.dtls.addRef(
        informationalMsgDtls);
    }
    // END, CR00016578

    // Return the details.
    return tradingStatusMessageList;
  }

  // __________________________________________________________________________
  /**
   * Reads employer trading status record.
   *
   * @param key
   * identifies the employer trading status record.
   *
   * @return Trading Status details for the Employer.
   */
  public ReadTradingStatusDetails readTradingStatus(ReadTradingStatusKey key)
    throws AppException, InformationalException {

    // Maintain Employer Trading Status object.
    curam.core.intf.MaintainEmployerTradingStatus maintainEmployerTradingStatusObj = curam.core.fact.MaintainEmployerTradingStatusFactory.newInstance();

    // Details to be returned.
    ReadTradingStatusDetails readTradingStatusDetails = new ReadTradingStatusDetails();

    // Read the Trading Status details.
    readTradingStatusDetails.tradingStatusDetails = maintainEmployerTradingStatusObj.readTradingStatus(
      key.readEmployerTradingStatusKey);

    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = readTradingStatusDetails.tradingStatusDetails.concernRoleID;

    readTradingStatusDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the Employer Trading Status details.
    return readTradingStatusDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reads an employers home page details and further details.
   *
   * @param key
   * identifies employer concerned.
   *
   * @return The Employer details.
   */
  public ReadEmployerHomeDetails readHomePageDetails(ReadEmployerHomeKey key)
    throws AppException, InformationalException {

    // Employer Home Page object.
    curam.core.intf.EmployerHomePage employerHomePageObj = curam.core.fact.EmployerHomePageFactory.newInstance();

    // Maintain Concern Role Details object and key.
    curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Details to be returned.
    ReadEmployerHomeDetails readEmployerHomeDetails = new ReadEmployerHomeDetails();

    // Struct returned from Employer Home Page read.
    ReadEmployerResult readEmployerResult;

    // Struct returned from Employer Further Details read.
    EmployerDetails employerDetails;

    // Get the Concern Role ID from the key.
    maintainConcernRoleKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    // Read the Employer Home Page details.
    readEmployerResult = employerHomePageObj.read(key.concernRoleHomePageKey);

    // Read the Employer Further Details.
    employerDetails = maintainConcernRoleDetailsObj.readEmployer(
      maintainConcernRoleKey);

    // Assign the returned details.
    readEmployerHomeDetails.employerHomeDetails.assign(employerDetails);
    readEmployerHomeDetails.employerHomeDetails.assign(
      readEmployerResult.details);

    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.concernRoleHomePageKey.concernRoleID;

    readEmployerHomeDetails.participantContextDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the Employer Home Page details.
    return readEmployerHomeDetails;
  }

  // ___________________________________________________________________________
  /**
   * Register an employer
   *
   * @param details
   * details of the employer to be registered
   *
   * @return details from the operation.
   * @return details from the operation
   */
  public EmployerRegistrationResult register(
    curam.core.facade.struct.EmployerRegistrationDetails details)
    throws AppException, InformationalException {

    // Employer maintenance object
    curam.core.intf.EmployerRegistration employerRegistrationObj = curam.core.fact.EmployerRegistrationFactory.newInstance();

    // Concern role entity objects
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Read concern ID from ConcernRole, if necessary
    if (details.employerRegistrationDetails.relatedConcernRoleID != 0) {
      concernRoleKey.concernRoleID = details.employerRegistrationDetails.relatedConcernRoleID;
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      // Set concern ID in registration details
      details.employerRegistrationDetails.concernID = concernRoleDtls.concernID;
    }

    // Details to be returned
    EmployerRegistrationResult employerRegistrationResult = new EmployerRegistrationResult();

    // Register employer
    employerRegistrationResult.registrationIDDetails = employerRegistrationObj.registerEmployer(
      details.employerRegistrationDetails);

    // BEGIN, CR00078486, POH
    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      employerRegistrationResult.warnings.dtls.addRef(ecWarningsDtls);
    }
    // END, CR00078486

    // Return details
    return employerRegistrationResult;
  }

  // ___________________________________________________________________________
  /**
   * Cancels an employer relationship record
   *
   * @param key
   * key of the employer relationship which is to be canceled
   */
  public void cancelRelationship(CancelEmployerRelationshipKey key)
    throws AppException, InformationalException {

    // Relationship maintenance object
    curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Cancel the relationship
    maintainConcernRoleRelationshipsObj.cancelRelationship(
      key.cancelRelationshipDetailsKey);
  }

  // BEGIN, CR00077847, POH
  // ___________________________________________________________________________
  /**
   * Creates an employer relationship record
   *
   * @param details
   * concern role identifier & concern role phone number details
   * @return CreatedRelationshipDetails
   * List of informationals - if any exist - to be displayed to user
   */
  public CreatedRelationshipDetails createRelationship(
    MaintainEmployerRelationshipDetails details)
    throws AppException, InformationalException {

    // return struct
    CreatedRelationshipDetails createdRelationshipDetails = new CreatedRelationshipDetails();

    // Relationship maintenance object
    curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails = new MaintainConcernRoleRelationshipDetails();

    // Assign relationship details
    maintainConcernRoleRelationshipDetails.assign(
      details.employerRelationshipDetails);

    // Create Relationship
    maintainConcernRoleRelationshipsObj.createRelationshipByAltID(
      maintainConcernRoleRelationshipDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      createdRelationshipDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return createdRelationshipDetails;
  }

  // END, CR00077847

  // ___________________________________________________________________________
  /**
   * Retrieves a list of relationship records for an employer
   *
   * @param key
   * employer identifier
   *
   * @return list of relationships found
   */
  public ReadEmployerRelationshipList listRelationship(
    ReadEmployerRelationshipListKey key) throws AppException,
      InformationalException {

    // Relationship maintenance object
    curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Details to be returned
    ReadEmployerRelationshipList readEmployerRelationshipList = new ReadEmployerRelationshipList();

    EmployerRelationshipRMDetails employerRelationshipRMDetails;

    MaintainConcernRoleRelationshipList maintainConcernRoleRelationshipList;

    // Read list of relationships
    maintainConcernRoleRelationshipList = maintainConcernRoleRelationshipsObj.readmultiByConcernRoleID(
      key.relationshipsByConcernRoleIDKey);

    readEmployerRelationshipList.employerRelationshipRMDetails.ensureCapacity(
      maintainConcernRoleRelationshipList.dtls.size());

    for (int i = 0; i < maintainConcernRoleRelationshipList.dtls.size(); i++) {
      // BEGIN, CR00337134, MC
      // Filter out prospect employers that are the parent of this registered employer 
      if (!maintainConcernRoleRelationshipList.dtls.item(i).concernRoleType.equals(
        CONCERNROLETYPE.PROSPECTEMPLOYER)
          && !maintainConcernRoleRelationshipList.dtls.item(i).relationshipType.equals(
            EMPLOYERRELATIONSHIPTYPES.PARENT)) {
        
        employerRelationshipRMDetails = new EmployerRelationshipRMDetails();
        
        employerRelationshipRMDetails.assign(
          maintainConcernRoleRelationshipList.dtls.item(i));
        readEmployerRelationshipList.employerRelationshipRMDetails.addRef(
          employerRelationshipRMDetails);
      }
      // END, CR00337134
    }

    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.relationshipsByConcernRoleIDKey.concernRoleID;

    readEmployerRelationshipList.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return Details
    return readEmployerRelationshipList;
  }

  // BEGIN, CR00077847, POH
  // ___________________________________________________________________________
  /**
   * Modifies a relationship record for an employer
   *
   * @param details
   * employer identifier & employer relationship details
   * @return ModifiedRelationshipDetails
   * List of informationals - if any exist - to be displayed to user
   */
  public ModifiedRelationshipDetails modifyRelationship(
    MaintainEmployerRelationshipDetails details)
    throws AppException, InformationalException {

    // return struct
    ModifiedRelationshipDetails modifiedRelationshipDetails = new ModifiedRelationshipDetails();

    // Relationship maintenance object and key
    curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();
    MaintainConcernRoleRelationshipKey maintainConcernRoleRelationshipKey = new MaintainConcernRoleRelationshipKey();

    MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails = new MaintainConcernRoleRelationshipDetails();

    // Assign relationship details
    maintainConcernRoleRelationshipDetails.assign(
      details.employerRelationshipDetails);

    // Get concern role relationship id from key
    maintainConcernRoleRelationshipKey.concernRoleRelationshipID = details.employerRelationshipDetails.concernRoleRelationshipID;

    // Modify Relationship
    maintainConcernRoleRelationshipsObj.modifyRelationshipByAltID(
      maintainConcernRoleRelationshipKey,
      maintainConcernRoleRelationshipDetails);

    curam.util.exception.InformationalManager informationalManager = curam.util.transaction.TransactionInfo.getInformationalManager();

    // obtain any informationals created
    String[] warnings = informationalManager.obtainInformationalAsString();

    // populate return struct with informationals
    for (int i = 0; i < warnings.length; i++) {
      ECWarningsDtls ecWarningsDtls = new ECWarningsDtls();

      ecWarningsDtls.msg = warnings[i];
      modifiedRelationshipDetails.warnings.dtls.addRef(ecWarningsDtls);
    }

    // return details
    return modifiedRelationshipDetails;
  }

  // END, CR00077847

  // ___________________________________________________________________________
  /**
   * Reads a relationship record for an employer
   *
   * @param key
   * employer relationship key.
   *
   * @return relationship details found.
   */
  public ReadEmployerRelationshipDetails readRelationship(
    ReadEmployerRelationshipKey key) throws AppException,
      InformationalException {

    // Relationship maintenance object and key
    curam.core.intf.MaintainConcernRoleRelationships maintainConcernRoleRelationshipsObj = curam.core.fact.MaintainConcernRoleRelationshipsFactory.newInstance();

    // Details to be returned
    ReadEmployerRelationshipDetails readEmployerRelationshipDetails = new ReadEmployerRelationshipDetails();

    MaintainConcernRoleRelationshipDetails maintainConcernRoleRelationshipDetails;

    // Read relationship details
    maintainConcernRoleRelationshipDetails = maintainConcernRoleRelationshipsObj.readRelationship(
      key.maintainConcernRoleRelationshipKey);

    readEmployerRelationshipDetails.employerRelationshipDetails.assign(
      maintainConcernRoleRelationshipDetails);

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = maintainConcernRoleRelationshipDetails.concernRoleID;

    readEmployerRelationshipDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return Details
    return readEmployerRelationshipDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieve a list of cases by concern role ID
   *
   * @param key
   * identifier of employer concerned.
   *
   * @return A list of cases for the employer.
   */
  public ListCaseDetails listCase(ListCaseKey_fo key) throws AppException,
      InformationalException {

    // Maintain Case maintenance object and key
    curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();

    // Details to be returned
    ListCaseDetails listCaseDetails = new ListCaseDetails();

    // Set status code for search
    key.casesByConcernRoleIDKey.statusCode = curam.codetable.CASESTATUSSEARCH.ALL;

    // Retrieve the list of cases
    // BEGIN, CR00221180, ZV
    listCaseDetails.caseHeaderConcernRoleDetailsList.assign(
      maintainCaseObj.getCasesByConcernRoleID1(key.casesByConcernRoleIDKey));
    // END, CR00221180

    // Context key
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.casesByConcernRoleIDKey.concernRoleID;

    listCaseDetails.participantContextDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // return details
    return listCaseDetails;
  }

  // ___________________________________________________________________________
  /**
   * Updates an employer with new details.
   *
   * @param details
   * Modified details of the Employer.
   *
   * @return Informational messages.
   */
  public ModifyEmployerReturnDetails modifyEmployer(
    ModifyEmployerDetails details) throws AppException,
      InformationalException {

    // Employer maintenance object and key
    curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Details to be returned
    ModifyEmployerReturnDetails modifyEmployerReturnDetails = new ModifyEmployerReturnDetails();

    // Get the concern role ID from the modify details.
    maintainConcernRoleKey.concernRoleID = details.readEmployerDetails.concernRoleID;

    // Struct passed to modifyEmployer
    EmployerDetails employerDetails = new EmployerDetails();

    employerDetails.assign(details.readEmployerDetails);

    // Modify the employer
    modifyEmployerReturnDetails.informationalMsgDtlsList = maintainConcernRoleDetailsObj.modifyEmployer(
      maintainConcernRoleKey, employerDetails);

    // Return details
    return modifyEmployerReturnDetails;
  }

  // ___________________________________________________________________________
  /**
   * Retrieves details for the specified employer.
   *
   * @param key
   * Unique identifier for the Employer.
   *
   * @return Employer details.
   * @return Employer details
   */
  public ReadEmployerDetailsDetails readEmployerDetails(
    ReadEmployerDetailsKey key) throws AppException, InformationalException {

    // Employer maintenance object and key
    curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
    curam.core.struct.MaintainConcernRoleKey maintainConcernRoleKey = new curam.core.struct.MaintainConcernRoleKey();

    // Details to be returned
    ReadEmployerDetailsDetails readEmployerDetailsDetails = new ReadEmployerDetailsDetails();

    // Get the concern role ID from the search key.
    maintainConcernRoleKey.concernRoleID = key.maintainConcernRoleKey.concernRoleID;

    // Details struct for the Employer read
    EmployerDetails employerDetails;

    // Read the employer details
    employerDetails = maintainConcernRoleDetailsObj.readEmployer(
      maintainConcernRoleKey);
    readEmployerDetailsDetails.readEmployerDetails.assign(employerDetails);

    // Context key
    // BEGIN, CR00060595, PCAL
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = readEmployerDetailsDetails.readEmployerDetails.concernRoleID;

    readEmployerDetailsDetails.participantContextDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return Details
    return readEmployerDetailsDetails;
  }

  // ___________________________________________________________________________
  /**
   * Returns the employer's full name and address.
   *
   * @param key
   * Contains the employer's concern role identifier.
   *
   * @return EmployerNameAndAddressDetails The employer's full name and address.
   */
  public EmployerNameAndAddressDetails readFullNameAndAddress(
    ReadEmployerDetailsKey key) throws AppException, InformationalException {

    // Create return object
    EmployerNameAndAddressDetails employerNameAndAddressDetails = new EmployerNameAndAddressDetails();

    // MaintainConcernRoleDetails manipulation variables
    curam.core.intf.MaintainConcernRoleDetails maintainConcernRoleDetailsObj = curam.core.fact.MaintainConcernRoleDetailsFactory.newInstance();
    ReadConcernRoleKey readConcernRoleKey = new ReadConcernRoleKey();
    curam.core.struct.ReadContactDetails readContactDetails;

    // Set key to read concern role details
    readConcernRoleKey.concernRoleID = key.maintainConcernRoleKey.concernRoleID;

    // Call MaintainConcernRoleDetails BPO to read employer's full name and
    // address
    readContactDetails = maintainConcernRoleDetailsObj.readAllContactDetails(
      readConcernRoleKey);

    // Assign details to return object
    employerNameAndAddressDetails.assign(readContactDetails);

    return employerNameAndAddressDetails;
  }

  // BEGIN, CR00060595, PCAL
  // ___________________________________________________________________________
  /**
   * Method returns a list of Employer Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key The Employer record the snapshots are associated with.
   *
   * @return The list of Employer snapshot details
   */
  public ReadEmployerHistoryList listEmployerHistory(
    ReadEmployerHistoryListKey key)
    throws AppException, InformationalException {

    // Return struct
    ReadEmployerHistoryList readEmployerHistoryList = new ReadEmployerHistoryList();

    // Retrieve the list of snap shot summary details
    MaintainConcernRoleDetails maintainConcernRoleDetailsObj = MaintainConcernRoleDetailsFactory.newInstance();

    readEmployerHistoryList.historyDtls = maintainConcernRoleDetailsObj.listEmployerHistory(
      key.historyKey);

    // Get the context description by reading the concern role of
    // the Employer record associated with the list of Snapshots
    ParticipantContextDescriptionKey participantContextDescriptionKey = new ParticipantContextDescriptionKey();

    participantContextDescriptionKey.concernRoleID = key.historyKey.concernRoleID;

    readEmployerHistoryList.participantContextDetails.participantContextDescriptionDetails = ParticipantContextFactory.newInstance().readContextDescription(
      participantContextDescriptionKey);

    // Return the details
    return readEmployerHistoryList;
  }

  // END, CR00060595

  // BEGIN, CR00218664, ZV
  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria.
   *
   * @param key
   * employer data to be searched for.
   *
   * @return Employer details found
   * @deprecated Since Curam 6.0 SP2, replaced with {@link
   * Employer#searchEmployer(EmployerSearchKey1)}.
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchEmployer(EmployerSearchKey1) which returns the
   * informational message along with search employer details as
   * well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public EmployerSearchResult1 search1(EmployerSearchKey1 key)
    throws AppException, InformationalException {
    // END, CR00282028
    EmployerSearchRouter employerSearchRouterObj = EmployerSearchRouterFactory.newInstance();

    EmployerSearchResult1 employerSearchResult = new EmployerSearchResult1();

    employerSearchResult.dtls = employerSearchRouterObj.search1(key.key);

    return employerSearchResult;
  }

  // END, CR00218664

  // BEGIN, CR00219812, ZV
  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria. Does not return
   * names as hyperlinks as this is for popup pages.
   *
   * @param key
   * employer data to be searched for.
   *
   * @return Employer details found
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Employer#searchEmployerForPopup(EmployerSearchKey1)}.
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchEmployerForPopup(EmployerSearchKey1) which returns the
   * informational message along with search employer details as
   * well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public EmployerSearchResult1 search1ForPopup(EmployerSearchKey1 key)
    throws AppException, InformationalException {
    // END, CR00282028
    EmployerSearchRouter employerSearchRouterObj = EmployerSearchRouterFactory.newInstance();

    EmployerSearchResult1 employerSearchResult = new EmployerSearchResult1();

    key.key.disableLinkInd = true;

    employerSearchResult.dtls = employerSearchRouterObj.search1(key.key);

    return employerSearchResult;
  }

  // END, CR00219812

  // BEGIN, CR00233791, DJ
  /**
   * Cancels a concern role address record.
   *
   * @param key
   * contains the concern role address which is to be canceled
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelAddress(final CancelParticipantAddressKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelAddress(key);
  }

  /**
   * Cancels a concern role alternate id record.
   *
   * @param key
   * contains the concern role alternate id which is being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelAlternateID(final CancelParticipantAlternateIDKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelAlternateID(key);
  }

  /**
   * Cancels a communication on a case.
   *
   * @param key
   * contains the key to cancel the communication.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  public void cancelCommunication(final CancelCommunicationKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelCommunication(key);
  }

  /**
   * Cancels a concern role communication exception record.
   *
   * @param key
   * contains the ID of the communication exception being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelCommunicationException(
    final CancelParticipantCommunicationExceptionKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelCommunicationException(key);
  }

  /**
   * Cancels a contact record.
   *
   * @param key
   * contains the contact ID for the record being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelContact(final CancelContactKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelContact(key);
  }

  /**
   * Cancel an email address for a participant.
   *
   * @param key
   * contains the ID of the email address being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelEmailAddress(final CancelParticipantEmailAddressKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelEmailAddress(key);
  }

  /**
   * Cancel a note for a participant.
   *
   * @param details
   * contains the details to create a participant note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelNote(final CancelParticipantNoteDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelNote(details);
  }

  /**
   * Cancel a bank account for a participant.
   * This method handles the cancellation of normal bank account
   * as well as joint accounts.
   *
   * @param key contains the ID of the bank account being canceled.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public InformationMsgDtlsList cancelParticipantBankAccount(
    final CancelParticipantBankAccountKey key)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList = delegate.cancelParticipantBankAccount(key);
    return informationMsgDtlsList;
  }

  /**
   * Cancels a phone number record.
   *
   * @param key
   * contains the concern role phone number ID of the phone record being
   * canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelPhoneNumber(final CancelParticipantPhoneNumberKey key)
    throws AppException, InformationalException {
    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelPhoneNumber(key);
  }

  /**
   * Cancel a web address for a participant.
   *
   * @param details
   * contains the details of the web address to cancel
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelWebAddress(final CancelParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.cancelWebAddress(details);
  }

  /**
   * Creates a concern role address record.
   *
   * @param details
   * contains the concern role ID and the address details.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantAddressDetails createAddress(
    final MaintainParticipantAddressDetails details)
    throws AppException, InformationalException {

    CreateParticipantAddressDetails createParticipantAddressDetails = new CreateParticipantAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    createParticipantAddressDetails = delegate.createAddress(details);
    return createParticipantAddressDetails;
  }

  /**
   * Create a administrator for the concernRole specified.
   *
   * @param participantAdministratorDetails
   * The administrator details being entered.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public void createAdministrator(
    final ParticipantAdministratorDetails participantAdministratorDetails)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createAdministrator(participantAdministratorDetails);
  }

  /**
   * Create a new administrator for the concernRole supplied.
   *
   * @param details
   * contains the administrator role details being entered.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Person#createAdministrator(ParticipantAdministratorDetails)}
   */
  @Deprecated
  public void createAdminRole(final CreateParticipantAdminRoleDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createAdminRole(details);
  }

  /**
   * Creates a concern role alternate id record.
   *
   * @param details
   * contains the concern role ID and alternate id details being
   * entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantAlternateIDDetails createAlternateID(
    final MaintainParticipantAlternateIDDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    CreateParticipantAlternateIDDetails createParticipantAlternateIDDetails = new CreateParticipantAlternateIDDetails();

    createParticipantAlternateIDDetails = delegate.createAlternateID(details);
    return createParticipantAlternateIDDetails;
  }

  /**
   * Cancel a bank account for a participant.
   *
   * @param key
   * contains the ID of the bank account being canceled.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void cancelBankAccount(CancelParticipantBankAccountKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    // BEGIN, CR00247430, MR
    delegate.cancelParticipantBankAccount(key);
    // END, CR00247430
  }

  /**
   * Creates a concern role communication exception record.
   *
   * @param details
   * contains the concern role communication exception details being
   * entered.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createCommunicationException(details);
  }

  /**
   * Create a contact.
   *
   * @param details
   * contains the contact details being entered
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createContact(final CreateContactDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createContact(details);
  }

  /**
   * Creates a contact record for a participant who was not previously
   * registered.
   *
   * @param details
   * contains the registration details for the contact
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createContactFromUnregisteredParticipant(
    final CreateContactFromUnregisteredParticipant details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createContactFromUnregisteredParticipant(details);
  }

  /**
   * Create a new email address for a participant.
   *
   * @param details
   * contains the email address details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantEmailAddressDetails createEmailAddress(
    final MaintainParticipantEmailAddressDetails details)
    throws AppException, InformationalException {

    CreateParticipantEmailAddressDetails createParticipantEmailAddressDetails = new CreateParticipantEmailAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    createParticipantEmailAddressDetails = delegate.createEmailAddress(details);
    return createParticipantEmailAddressDetails;
  }

  /**
   * Creates an email communication.
   *
   * @param details
   * contains the details to create the email communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated since Curam v6, replaced with
   * {@link Communication#createEmail(
   * curam.core.facade.struct.CreateEmailCommDetails)}
   */
  @Deprecated
  public void createEmailCommunication(
    final CreateEmailCommunicationDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createEmailCommunication(details);
  }

  /**
   * Creates a freeform communication.
   *
   * @param details
   * contains the details to create the freeform communication.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  public void createFreeformCommunincation(
    final CreateFreeformCommunication details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createFreeformCommunincation(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the home phone number is
   * created
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createHomePhoneNumber(final CreateHomePhoneNumber key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createHomePhoneNumber(key);
  }

  /**
   * This method creates a mailing address for a participant.
   *
   * @param key
   * Identifies the participant for whom the mailing address is created
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createMailingAddress(final CreateMailingAddress key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createMailingAddress(key);
  }

  /**
   * Create a note for a participant.
   *
   * @param details
   * contains the participant note details being entered.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createNote(final ParticipantNoteDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createNote(details);
  }

  /**
   * Creates a concern role phone number record.
   *
   * @param details
   * contains the concern role identifier & concern role phone number
   * details
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantPhoneDetails createPhoneNumber(
    final MaintainParticipantPhoneDetails details)
    throws AppException, InformationalException {

    CreateParticipantPhoneDetails createParticipantPhoneDetails = new CreateParticipantPhoneDetails();
    Participant delegate = ParticipantFactory.newInstance();

    createParticipantPhoneDetails = delegate.createPhoneNumber(details);
    return createParticipantPhoneDetails;
  }

  /**
   * Creates a template communication.
   *
   * @param details
   * contains the details to create the template communication.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  public void createTemplateCommunication(
    final CreateTemplateCommunication details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createTemplateCommunication(details);
  }

  /**
   * Create a new web address for a participant.
   *
   * @param details
   * contains the web address details being entered
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createWebAddress(details);
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the work phone number is
   * created.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void createWorkPhoneNumber(final CreateWorkPhoneNumber key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.createWorkPhoneNumber(key);
  }

  /**
   * Display the address given as a single line. The address is formatted base
   * on the ENV_ADDRESSSTRINGFORMAT environment variable.
   *
   * @param OtherAddressData The address formatted with its descriptors i.e.
   * ADD1=Line1, ADD2=Line2, ADD3=Line3 ...
   *
   * @return AddressString, the address given as a single line.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public AddressString displaySingleLineAddress(
    final OtherAddressData otherAddressData)
    throws AppException, InformationalException {

    AddressString addressString = new AddressString();
    Participant delegate = ParticipantFactory.newInstance();

    addressString = delegate.displaySingleLineAddress(otherAddressData);
    return addressString;
  }

  /**
   * Ends all active deductions on a case for a participant.
   *
   * @param details
   * Contains the  concern role ID & the case ID
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void endDeduction(final EndDeductionDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.endDeduction(details);
  }

  /**
   * Formats the bank account details for a participant. The bank details
   * are formatted to display as a single line of text. The formatting is
   * decided by a system variable.
   *
   * @param bankAccountRMDtls bank account details to be formatted
   *
   * @return Formatted string of bank account details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public BankAccountString formatBankAcDetailsString(
    final BankAccountRMDtls bankAccountRMDtls)
    throws AppException, InformationalException {

    BankAccountString bankAccountString = new BankAccountString();
    Participant delegate = ParticipantFactory.newInstance();

    bankAccountString = delegate.formatBankAcDetailsString(bankAccountRMDtls);
    return bankAccountString;
  }

  /**
   * This method creates a home phone number for a participant.
   *
   * @param key
   * Identifies the participant for whom the primary residence address
   * is created
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void insertPrimaryResidenceAddress(final InsertPrimaryResAddress key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.insertPrimaryResidenceAddress(key);
  }

  /**
   * Retrieves a list of active address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of active addresses returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantActiveAddressList listActiveAddresses(
    final ReadParticipantAddressListKey key)
    throws AppException, InformationalException {

    final ReadParticipantActiveAddressList readParticipantActiveAddressList = new ReadParticipantActiveAddressList();
    Participant delegate = ParticipantFactory.newInstance();

    delegate.listActiveAddresses(key);
    return readParticipantActiveAddressList;
  }

  /**
   * Method to list all active bank accounts for a Case Nominee.
   *
   * @param key
   * contains the concernRoleID
   *
   * @return list of all active bank accounts for a participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadActiveBankAccountList listActiveBankAccount(
    final ReadParticipantBankAccountListKey key) throws AppException,
      InformationalException {

    final ReadActiveBankAccountList readActiveBankAccountList = new ReadActiveBankAccountList();
    Participant delegate = ParticipantFactory.newInstance();

    delegate.listActiveBankAccount(key);
    return readActiveBankAccountList;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains concernRoleID and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated since Curam V6.0. This method is replaced by
   * {@link #listActiveBankAccountForRedirection1()}.
   */
  @Deprecated
  public BankAccountListForRedirectionDetails listActiveBankAccountForRedirection(
    final ParticipantBankAccountRedirectionKey key)
    throws AppException, InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails = new BankAccountListForRedirectionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    bankAccountListForRedirectionDetails = delegate.listActiveBankAccountForRedirection(
      key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Method to list all active bank accounts for a Participant bank account
   * redirection.
   *
   * @param key contains bank account id and bank account number
   *
   * @return list of all active participant bank accounts, context description
   * and redirection context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public BankAccountListForRedirectionDetails listActiveBankAccountForRedirection1(
    ParticipantBankAccountRedirectionKey1 key)
    throws AppException, InformationalException {

    BankAccountListForRedirectionDetails bankAccountListForRedirectionDetails = new BankAccountListForRedirectionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    bankAccountListForRedirectionDetails = delegate.listActiveBankAccountForRedirection1(
      key);
    return bankAccountListForRedirectionDetails;
  }

  /**
   * Retrieves a list of address records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAddressList listAddress(final ReadParticipantAddressListKey key)
    throws AppException, InformationalException {

    ReadParticipantAddressList readParticipantAddressList = new
      ReadParticipantAddressList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAddressList = delegate.listAddress(key);
    return readParticipantAddressList;
  }

  /**
   * Method returns a list of Address Snapshot details, and the date-of-creation
   * for each Snapshot record.
   *
   * @param key contains the Address record the snapshots are associated with.
   *
   * @return The list of Address snapshot summary details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadAddressHistoryList listAddressHistory(final ReadAddressHistoryListKey key)
    throws AppException, InformationalException {

    ReadAddressHistoryList readAddressHistoryList = new ReadAddressHistoryList();
    Participant delegate = ParticipantFactory.newInstance();

    readAddressHistoryList = delegate.listAddressHistory(key);
    return  readAddressHistoryList;
  }

  /**
   * Retrieves a list of address records for a concern role and displays them as
   * strings.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of addresses returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantAddressStringList listAddressString(
    final ReadParticipantAddressListKey key)
    throws AppException, InformationalException {

    final ParticipantAddressStringList participantAddressStringList = new
      ParticipantAddressStringList();
    final Participant delegate = ParticipantFactory.newInstance();

    delegate.listAddressString(key);
    return participantAddressStringList;
  }

  /**
   * Retrieves a list of administrators for the specified concern role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is
   * returned.
   *
   * @return The list of administrators returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ParticipantAdministratorDetailsList listAdministrators(
    ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList = new ParticipantAdministratorDetailsList();
    Participant delegate = ParticipantFactory.newInstance();

    participantAdministratorDetailsList = delegate.listAdministrators(
      readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administrators for the specified duplicate concern
   * role.
   *
   * @param readParticipantAdminRoleListKey
   * The concern role ID for which a list of administrators is returned
   *
   * @return The list of administrators for the duplicate concern role
   * specified.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  public ParticipantAdministratorDetailsList listAdministratorsForDuplicateParticipant(
    ReadParticipantAdminRoleListKey readParticipantAdminRoleListKey)
    throws AppException, InformationalException {

    ParticipantAdministratorDetailsList participantAdministratorDetailsList = new ParticipantAdministratorDetailsList();
    Participant delegate = ParticipantFactory.newInstance();

    participantAdministratorDetailsList = delegate.listAdministratorsForDuplicateParticipant(
      readParticipantAdminRoleListKey);
    return participantAdministratorDetailsList;
  }

  /**
   * Retrieves a list of administration roles for the specified concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministrators(ReadParticipantAdminRoleListKey)}
   */
  @Deprecated
  public ReadParticipantAdminRoleList listAdminRole(
    final ReadParticipantAdminRoleListKey key)
    throws AppException, InformationalException {

    ReadParticipantAdminRoleList readParticipantAdminRoleList = new ReadParticipantAdminRoleList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAdminRoleList = delegate.listAdminRole(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of administration roles for the specified duplicate
   * concern role.
   *
   * @param key
   * contains the concern role ID for which a list of admin roles is
   * returned
   *
   * @return The list of admin roles returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated since Curam v6, replaced with
   * {@link Person#listAdministratorsForDuplicateParticipant(
   * ReadParticipantAdminRoleListKey)}
   */
  @Deprecated
  public ReadParticipantAdminRoleList listAdminRoleForDuplicate(
    final ReadParticipantAdminRoleListKey key)
    throws AppException, InformationalException {

    ReadParticipantAdminRoleList readParticipantAdminRoleList = new ReadParticipantAdminRoleList();
    Participant delegate = ParticipantFactory.newInstance();

    delegate.listAdminRoleForDuplicate(key);
    return readParticipantAdminRoleList;
  }

  /**
   * Retrieves a list of alternate id records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of alternate ID's is
   * returned.
   *
   * @return The list of alternate ID's returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAlternateIDList listAlternateID(
    final ReadParticipantAlternateIDListKey key)
    throws AppException, InformationalException {

    ReadParticipantAlternateIDList readParticipantAlternateIDList = new ReadParticipantAlternateIDList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAlternateIDList = delegate.listAlternateID(key);
    return readParticipantAlternateIDList;
  }

  /**
   * Method returns a list of AlternateID Snapshot summary details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key contains the alternateID of the AlternateID record the snapshots
   * are  associated with.
   *
   * @return The list of AlternateID snapshot details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAltIDHistoryList listAlternateIDHistory(
    final ReadParticipantAltIDHistoryListKey key)
    throws AppException, InformationalException {

    ReadParticipantAltIDHistoryList readParticipantAltIDHistoryList = new ReadParticipantAltIDHistoryList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAltIDHistoryList = delegate.listAlternateIDHistory(key);
    return readParticipantAltIDHistoryList;
  }

  /**
   * Method returns a list of Assessments for the participant.
   *
   * @param concernRoleKey contains the concern role that the assessments were
   * created for.
   *
   * @return The list of Assessments for the concern role.
   */
  public ParticipantAssessmentsList listAssessments(
    final ConcernRoleKey concernRoleKey)
    throws AppException, InformationalException {

    ParticipantAssessmentsList participantAssessmentsList = new ParticipantAssessmentsList();
    Participant delegate = ParticipantFactory.newInstance();

    participantAssessmentsList = delegate.listAssessments(concernRoleKey);
    return participantAssessmentsList;
  }

  /**
   * Retrieves a list of bank accounts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of bank accounts is
   * returned.
   *
   * @return The list of bank accounts returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantBankAccountList listBankAccount(
    ReadParticipantBankAccountListKey key)
    throws AppException, InformationalException {

    ReadParticipantBankAccountList readParticipantBankAccountList = new  ReadParticipantBankAccountList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAccountList = delegate.listBankAccount(key);
    return readParticipantBankAccountList;
  }

  /**
   * Method returns a list of ConcernRole Bank Account Snapshot details, and the
   * date-of-creation for each Snapshot record.
   *
   * @param key contains the ConcernRole Bank Account record the snapshots are
   * associated with.
   *
   * @return The list of ConcernRole Bank Account snapshot details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantBankAcHistoryList listBankAccountHistory(
    ReadParticipantBankAcHistoryListKey key)
    throws AppException, InformationalException {

    ReadParticipantBankAcHistoryList readParticipantBankAcHistoryList = new ReadParticipantBankAcHistoryList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAcHistoryList = delegate.listBankAccountHistory(key);
    return readParticipantBankAcHistoryList;
  }

  /**
   * Lists the formatted bank account details. The bank details
   * are formatted to display as a single line of text.
   *
   * @param key concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantBankAccountStringList listBankAccountString(
    MaintainConcernRoleKey key) throws AppException, InformationalException {

    ParticipantBankAccountStringList participantBankAccountStringList = new ParticipantBankAccountStringList();
    Participant delegate = ParticipantFactory.newInstance();

    participantBankAccountStringList = delegate.listBankAccountString(key);
    return participantBankAccountStringList;
  }

  /**
   * Lists all communications by case ID.
   *
   * @param key Contains the case identifier.
   * @return List of communications on the case.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CommunicationDetailList listCommunication(
    ParticipantCommunicationKey key)
    throws AppException, InformationalException {

    CommunicationDetailList communicationDetailList = new CommunicationDetailList();
    Participant delegate = ParticipantFactory.newInstance();

    communicationDetailList = delegate.listCommunication(key);
    return communicationDetailList;
  }

  /**
   * Retrieves a list of communication exception records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of communication
   * exceptions  are returned.
   *
   * @return The list of communication exceptions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantCommunicationExceptionList listCommunicationException(
    ReadParticipantCommunicationExceptionListKey key)
    throws AppException, InformationalException {

    ReadParticipantCommunicationExceptionList readParticipantCommunicationExceptionList = new ReadParticipantCommunicationExceptionList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantCommunicationExceptionList = delegate.listCommunicationException(
      key);
    return readParticipantCommunicationExceptionList;
  }

  /**
   * Retrieves a list of client role records for a concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantConcernRoleList listConcernRole(
    ReadParticipantConcernRoleKey key)
    throws AppException, InformationalException {

    ReadParticipantConcernRoleList readParticipantConcernRoleList = new ReadParticipantConcernRoleList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantConcernRoleList = delegate.listConcernRole(key);
    return readParticipantConcernRoleList;
  }

  /**
   * Retrieves a list of client role records for a duplicate concern role.
   *
   * @param key
   * contains the concern role ID for which a list of client roles is
   * returned
   *
   * @return The list of client roles returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadDuplicateParticipantConcernRoleList listConcernRoleForDuplicate(
    ReadParticipantConcernRoleKey key)
    throws AppException, InformationalException {

    ReadDuplicateParticipantConcernRoleList readDuplicateParticipantConcernRoleList = new ReadDuplicateParticipantConcernRoleList();
    Participant delegate = ParticipantFactory.newInstance();

    readDuplicateParticipantConcernRoleList = delegate.listConcernRoleForDuplicate(
      key);
    return readDuplicateParticipantConcernRoleList;
  }

  // BEGIN, CR00294967, MV
  /**
   * A list of contacts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, 
   * replaced by {@link #listConcernContact()}. 
   * The return struct of the current method listContact has an aggregation 
   * to the struct ConcernContactRMDtls, the attribute statusCode in the struct
   * ConcernContactRMDtls is modeled with a domain of CONTACTSTATUS code-table,
   * but the corresponding entity attribute ConcernRoleContactDtls.statusCode
   * is modeled with a domain of RECORD_STATUS_CODE. So new method is introduced 
   * to return new struct ListConcernContactDetails which has an aggregation 
   * to the new struct ConcernContactRMultiDtls where the attribute 
   * statusCode is modeled with a domain of RECORD_STATUS_CODE.
   * See release note: CEF-8999.
   */
  @Deprecated
  // END, CR00294967
  public ListContactDetails listContact(ListContactKey key)
    throws AppException, InformationalException {

    ListContactDetails listContactDetails = new ListContactDetails();
    Participant delegate = ParticipantFactory.newInstance();

    listContactDetails = delegate.listContact(key);
    return listContactDetails;
  }
  
  // BEGIN, CR00294967, MV 
  /**
   * Lists the contacts for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of contacts is
   * returned.
   *
   * @return The list of contacts returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListConcernContactDetails listConcernContact(final ListContactKey key)
    throws AppException, InformationalException {

    ListConcernContactDetails listConcernContactDetails = new ListConcernContactDetails();
    final Participant delegate = ParticipantFactory.newInstance();

    listConcernContactDetails = delegate.listConcernContact(key);
    return listConcernContactDetails;
  }

  // END, CR00294967

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */

  public ReadParticipantDeductionList listDeduction(ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ReadParticipantDeductionList readParticipantDeductionList = new ReadParticipantDeductionList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantDeductionList = delegate.listDeduction(key);
    return readParticipantDeductionList;
  }

  /**
   * Retrieves a list of deduction records for a concern role.
   *
   * @param key
   * The concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantDeductionList1 listDeduction1(ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ReadParticipantDeductionList1 readParticipantDeductionList1 = new ReadParticipantDeductionList1();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantDeductionList1 = delegate.listDeduction1(key);
    return readParticipantDeductionList1;
  }

  /**
   * Retrieves a list of deduction records for a duplicate concern role.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of deductions returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadDuplicateParticipantDeductionList listDeductionForDuplicate(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ReadDuplicateParticipantDeductionList readDuplicateParticipantDeductionList = new ReadDuplicateParticipantDeductionList();
    Participant delegate = ParticipantFactory.newInstance();

    readDuplicateParticipantDeductionList = delegate.listDeductionForDuplicate(
      key);
    return readDuplicateParticipantDeductionList;
  }

  /**
   * Retrieves a list of email addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of email addresses
   * is returned.
   *
   * @return The list of email addresses returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantEmailAddressList listEmailAddress(
    ReadParticipantEmailAddressListKey key)
    throws AppException, InformationalException {

    ReadParticipantEmailAddressList readParticipantEmailAddressList = new ReadParticipantEmailAddressList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantEmailAddressList = delegate.listEmailAddress(key);
    return readParticipantEmailAddressList;
  }

  /**
   * Lists all addresses for a participant formatted for use in a pop-up list.
   *
   * @param readParticipantFormattedAddressListKey
   * contains concernRoleID
   *
   * @return List of formatted addresses for participant
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public FormattedAddressList listFormattedAddress(
    ReadParticipantFormattedAddressListKey
    readParticipantFormattedAddressListKey)
    throws AppException, InformationalException {

    FormattedAddressList formattedAddressList = new FormattedAddressList();
    Participant delegate = ParticipantFactory.newInstance();

    formattedAddressList = delegate.listFormattedAddress(
      readParticipantFormattedAddressListKey);
    return formattedAddressList;
  }

  /**
   * Reads formatted bankAccount data for a Participant.
   *
   * @param readParticipantFormattedBankAccountListKey
   * contains concernRoleID
   *
   * @return List of formatted bank accounts for participant
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public FormattedBankAccountList listFormattedBankAccount(
    ReadParticipantFormattedBankAccountListKey
    readParticipantFormattedBankAccountListKey)
    throws AppException, InformationalException {

    FormattedBankAccountList formattedBankAccountList = new FormattedBankAccountList();
    Participant delegate = ParticipantFactory.newInstance();

    formattedBankAccountList = delegate.listFormattedBankAccount(
      readParticipantFormattedBankAccountListKey);
    return formattedBankAccountList;
  }

  /**
   * Retrieves a list of clients interaction details.
   *
   * @param key
   * contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListInteractionDetails listInteraction(final ListInteractionKey key)
    throws AppException, InformationalException {

    ListInteractionDetails listInteractionDetails = new ListInteractionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    listInteractionDetails = delegate.listInteraction(key);
    return listInteractionDetails;
  }

  /**
   * Retrieves a list of duplicate client interaction details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client interaction records and context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListDuplicateParticipantInteractionDetails listInteractionForDuplicate(
    final ListInteractionKey key)
    throws AppException, InformationalException {

    ListDuplicateParticipantInteractionDetails listDuplicateParticipantInteractionDetails = new ListDuplicateParticipantInteractionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantInteractionDetails = delegate.listInteractionForDuplicate(
      key);
    return listDuplicateParticipantInteractionDetails;
  }

  /**
   * Method returns a list of Investigations for the participant.
   *
   * @param key contains the  concern role that the investigations
   * were created for.
   *
   * @return The list of Investigations for the concern role.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantInvestigationList listInvestigations(
    final SearchCaseKey_fo key)
    throws AppException, InformationalException {

    ParticipantInvestigationList participantInvestigationList = new ParticipantInvestigationList();
    Participant delegate = ParticipantFactory.newInstance();

    participantInvestigationList = delegate.listInvestigations(key);
    return participantInvestigationList;
  }

  /**
   * Retrieves a list of issued payment instruments for a concern role, where
   * the client is the concern or the nominee.
   *
   * @param key
   * contains the concern role identifier
   *
   * @return The list of payment instruments returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListParticipantIssuedPaymentInstrument listIssuedPaymentInstrument(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ListParticipantIssuedPaymentInstrument listParticipantIssuedPaymentInstrument = new ListParticipantIssuedPaymentInstrument();
    Participant delegate = ParticipantFactory.newInstance();

    listParticipantIssuedPaymentInstrument = delegate.listIssuedPaymentInstrument(
      key);
    return listParticipantIssuedPaymentInstrument;
  }

  /**
   * Retrieves a list of duplicate client issued payment instrument details.
   *
   * @param key Contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListDuplicateParticipantIssuedPaymentInstrument listIssuedPaymentInstrumentForDuplicate(
    ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ListDuplicateParticipantIssuedPaymentInstrument listDuplicateParticipantIssuedPaymentInstrument = new
      ListDuplicateParticipantIssuedPaymentInstrument();
    Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantIssuedPaymentInstrument = delegate.listIssuedPaymentInstrumentForDuplicate(
      key);
    return listDuplicateParticipantIssuedPaymentInstrument;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Retrieve a list of notes for a participant.
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated - replaced by {@link #listNote1()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  public ParticipantNoteList listNote(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList participantNoteList = new ParticipantNoteList();
    Participant delegate = ParticipantFactory.newInstance();

    participantNoteList = delegate.listNote(key);
    return participantNoteList;
  }

  /**
   * Retrieve a list of notes for a participant.
   *
   * @param key
   * Identifies a participant.
   *
   * @return The list of notes returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantNoteList1 listNote1(final ParticipantKey key)
    throws AppException, InformationalException {

    ParticipantNoteList1 participantNoteList = new ParticipantNoteList1();
    Participant delegate = ParticipantFactory.newInstance();

    participantNoteList = delegate.listNote1(key);
    return participantNoteList;
  }

  // END, CR00231506

  /**
   * @param key
   * contains the key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #listParticipantFinancial1()}.
   * Returns a list of financials for a participant.
   */
  @Deprecated
  public ListParticipantFinancials listParticipantFinancial(
    final ListParticipantFinancialsKey key) throws AppException,
      InformationalException {
    ListParticipantFinancials listParticipantFinancials = new ListParticipantFinancials();
    Participant delegate = ParticipantFactory.newInstance();

    listParticipantFinancials = delegate.listParticipantFinancial(key);
    return listParticipantFinancials;
  }

  /**
   * Returns a list of financials for a participant.
   *
   * @param key
   * Key to read a participant's financials.
   *
   * @return List of the participant's financials.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListParticipantFinancials1 listParticipantFinancial1(
    ListParticipantFinancialsKey key)
    throws AppException, InformationalException {

    ListParticipantFinancials1 listParticipantFinancials1 = new  ListParticipantFinancials1();
    Participant delegate = ParticipantFactory.newInstance();

    listParticipantFinancials1 = delegate.listParticipantFinancial1(key);
    return listParticipantFinancials1;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListDuplicateParticipantFinancials listParticipantFinancialForDuplicate(
    final ListParticipantFinancialsKey key) throws AppException,
      InformationalException {

    ListDuplicateParticipantFinancials listDuplicateParticipantFinancials = new ListDuplicateParticipantFinancials();
    Participant delegate = ParticipantFactory.newInstance();

    listDuplicateParticipantFinancials = delegate.listParticipantFinancialForDuplicate(
      key);
    return listDuplicateParticipantFinancials;
  }

  /**
   * Returns a list of tasks for a participant.
   *
   * @param key
   * contains the key to return a list of tasks for a participant.
   *
   * @return List of tasks for a participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public TasksForConcernAndCaseDetails listParticipantTask(
    final ListParticipantTaskKey_eo key)
    throws AppException, InformationalException {

    TasksForConcernAndCaseDetails tasksForConcernAndCaseDetails = new TasksForConcernAndCaseDetails();
    Participant delegate = ParticipantFactory.newInstance();

    tasksForConcernAndCaseDetails = delegate.listParticipantTask(key);
    return tasksForConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of duplicate client financial details.
   *
   * @param key contains the concern role identifier.
   *
   * @return A list of client payment instrument records and context
   * description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public TasksForDuplicateConcernAndCaseDetails listParticipantTaskForDuplicate(
    final ListParticipantTaskKey_eo key)
    throws AppException, InformationalException {

    TasksForDuplicateConcernAndCaseDetails tasksForDuplicateConcernAndCaseDetails = new TasksForDuplicateConcernAndCaseDetails();
    Participant delegate = ParticipantFactory.newInstance();

    tasksForDuplicateConcernAndCaseDetails = delegate.listParticipantTaskForDuplicate(
      key);
    return tasksForDuplicateConcernAndCaseDetails;
  }

  /**
   * Retrieves a list of phone number records for a concern role.
   *
   * @param key
   * contains the concern role id for which a list of phone numbers are
   * returned.
   *
   * @return The list of phone numbers returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantPhoneNumberList listPhoneNumber(
    final ReadParticipantPhoneNumberListKey key)
    throws AppException, InformationalException {

    ReadParticipantPhoneNumberList readParticipantPhoneNumberList = new ReadParticipantPhoneNumberList();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantPhoneNumberList = delegate.listPhoneNumber(key);
    return readParticipantPhoneNumberList;
  }

  /**
   * Lists screening cases for the specified participant.
   *
   * @param key Identifies the concern role
   *
   * @return The screening cases for the participant as read from the database.
   */
  public ParticipantScreeningList listScreeningCases(final SearchCaseKey_fo key)
    throws AppException, InformationalException {

    ParticipantScreeningList participantScreeningList = new ParticipantScreeningList();
    Participant delegate = ParticipantFactory.newInstance();

    participantScreeningList = delegate.listScreeningCases(key);
    return participantScreeningList;
  }

  /**
   * Returns a list of templates based on template type and the participant
   * identifier.
   *
   * @param key
   * contains the key to read the list of templates.
   *
   * @return List of templates for participant.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ListTemplateByTypeAndParticpant listTemplateByTypeAndParticipant(
    final ListTemplateByTypeAndParticipantKey key)
    throws AppException, InformationalException {

    ListTemplateByTypeAndParticpant listTemplateByTypeAndParticpant = new ListTemplateByTypeAndParticpant();
    Participant delegate = ParticipantFactory.newInstance();

    listTemplateByTypeAndParticpant = delegate.listTemplateByTypeAndParticipant(
      key);
    return listTemplateByTypeAndParticpant;
  }

  /**
   * Retrieves a list of web addresses for a participant.
   *
   * @param key
   * contains the concern role ID for which a list of web addresses is
   * returned
   * @return The list of web addresses returned from the database
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantWebAddressList listWebAddress(
    final ParticipantWebAddressListKey key)
    throws AppException, InformationalException {

    ParticipantWebAddressList participantWebAddressList = new ParticipantWebAddressList();
    Participant delegate = ParticipantFactory.newInstance();

    participantWebAddressList = delegate.listWebAddress(key);
    return participantWebAddressList;
  }

  /**
   * Modifies an address record for a concern role.
   *
   * @param details
   * contains the concern role ID and concern role address details.
   *
   * @return ModifiedAddressDetails modified address details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ModifiedAddressDetails modifyAddress(
    final MaintainParticipantAddressDetails details)
    throws AppException, InformationalException {

    ModifiedAddressDetails modifiedAddressDetails = new ModifiedAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    modifiedAddressDetails = delegate.modifyAddress(details);
    return modifiedAddressDetails;
  }

  /**
   * Modifies an alternate id record for a concern role.
   *
   * @param details
   * contains the concern role ID and alternate id detail being
   * modified.
   *
   * @return ModifiedAlternateIDDetails modified alternateID details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ModifiedAlternateIDDetails modifyAlternateID(
    final MaintainParticipantAlternateIDDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ModifiedAlternateIDDetails modifiedAlternateIDDetails = new ModifiedAlternateIDDetails();

    modifiedAlternateIDDetails = delegate.modifyAlternateID(details);
    return modifiedAlternateIDDetails;
  }

  /**
   * @param details
   * contains the bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #modifyBankAccountWithTextSortCode()}.
   * Modify the bank account details for a participant.
   */
  @Deprecated
  public InformationMsgDtlsList modifyBankAccount(
    final MaintainParticipantBankAccountDetails details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList = delegate.modifyBankAccount(details);
    return informationMsgDtlsList;
  }

  /**
   * Modifies the details of a communication.
   *
   * @param details
   * contains the details to modify the communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Deprecated
  public void modifyCommunication(final ModifyCommDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyCommunication(details);
  }

  /**
   * Modifies a communication exception record for a concern role.
   *
   * @param details
   * contains the concern role communication exception details being
   * modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyCommunicationException(
    final MaintainParticipantCommunicationExceptionDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyCommunicationException(details);
  }
  
  // BEGIN, CR00294967, MV
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #modifyConcernContact()}.
   * The parameter struct of the current method modifyContact has
   * an aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to have new parameter ModifyConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  // END, CR00294967
  public void modifyContact(final ModifyContactDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyContact(details);
  }
  
  // BEGIN, CR00294967, MV  
  /**
   * Modifies a contact for a participant.
   *
   * @param details
   * contains the contact details and key.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyConcernContact(final ModifyConcernContactDetails details)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyConcernContact(details);
  }

  // END, CR00294967

  /**
   * Modify the details of an email address for a participant.
   *
   * @param details
   * contains the email address details being modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyEmailAddress(
    final MaintainParticipantEmailAddressDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyEmailAddress(details);
  }

  // BEGIN, CR00231506, PDN
  /**
   * Modify the details of a note for a participant.
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated - replaced by {@link #modifyNote1()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  public void modifyNote(final ModifyParticipantNoteDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyNote(details);
  }

  /**
   * Modify the details of a note for a participant.
   *
   * @param details
   * contains the participant note details to modify the note.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyNote1(final ModifyParticipantNoteDetails1 details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyNote1(details);
  }

  // END, CR00231506

  /**
   * Modifies a phone number record for a concern role.
   *
   * @param details
   * contains the concern role id and concern role phone number details
   * that  will be modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyPhoneNumber(final MaintainParticipantPhoneDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyPhoneNumber(details);
  }

  /**
   * Modifies the details of a sent communication.
   *
   * @param details
   * contains the details of the sent communication to be modified.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifySentCommunication(
    final ModifySentCommunicationDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifySentCommunication(details);
  }

  /**
   * Modify the details of a web address for a participant.
   *
   * @param details
   * contains the web address details being modified
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void modifyWebAddress(final ParticipantWebAddressDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.modifyWebAddress(details);
  }

  /**
   * Prints a communication.
   *
   * @param details
   * contains details to print the communication.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void printCommunication(final PrintCommunicationKey details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.printCommunication(details);
  }

  /**
   * Reads an address record for a concern role.
   *
   * @param key
   * contains the concern role address key.
   *
   * @return The address details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAddressDetails readAddress(
    final ReadParticipantAddressKey key)
    throws AppException, InformationalException {

    ReadParticipantAddressDetails readParticipantAddressDetails = new  ReadParticipantAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAddressDetails = delegate.readAddress(key);
    return readParticipantAddressDetails;
  }

  /**
   * Reads an alternate id record for a concern role.
   *
   * @param key
   * contains the concern role alternate id of the record being read.
   *
   * @return The alternate ID details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantAlternateIDDetails readAlternateID(
    final ReadParticipantAlternateIDKey key)
    throws AppException, InformationalException {

    ReadParticipantAlternateIDDetails readParticipantAlternateIDDetails = new ReadParticipantAlternateIDDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantAlternateIDDetails = delegate.readAlternateID(key);
    return readParticipantAlternateIDDetails;
  }

  /**
   * Read the details of a participants bank account.
   *
   * @param key
   * contains the bank account ID of the record being read.
   *
   * @return The bank account details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantBankAccountDetails readBankAccount(
    final ReadParticipantBankAccountKey key)
    throws AppException, InformationalException {

    ReadParticipantBankAccountDetails readParticipantBankAccountDetails = new ReadParticipantBankAccountDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantBankAccountDetails = delegate.readBankAccount(key);
    return readParticipantBankAccountDetails;
  }

  /**
   * Reads details of a communication.
   *
   * @param key
   * contains the communication identifier.
   *
   * @return Details of the communication.
   *
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   * @deprecated
   */
  @Deprecated
  public ReadCommDetails readCommunication(final ReadCommKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ReadCommDetails readCommDetails = new ReadCommDetails();

    readCommDetails = delegate.readCommunication(key);
    return readCommDetails;
  }

  /**
   * Reads details of a communication attachment.
   *
   * @param key
   * contains the key to read the communication attachment details.
   *
   * @return ReadCommunicationAttachmentDetails Details of the communication
   * attachment.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadCommunicationAttachmentDetails readCommunicationAttachment(
    final ReadAttachmentKey key) throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ReadCommunicationAttachmentDetails readCommunicationAttachmentDetails = new ReadCommunicationAttachmentDetails();

    readCommunicationAttachmentDetails = delegate.readCommunicationAttachment(
      key);
    return readCommunicationAttachmentDetails;
  }

  /**
   * Reads a communication exception record for a concern role.
   *
   * @param key
   * contains the communication exception ID of the record being read.
   *
   * @return The communication exception details found returned from the
   * database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantCommunicationExceptionDetails readCommunicationException(
    final ReadParticipantCommunicationExceptionKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ReadParticipantCommunicationExceptionDetails readParticipantCommunicationExceptionDetails = new ReadParticipantCommunicationExceptionDetails();

    readParticipantCommunicationExceptionDetails = delegate.readCommunicationException(
      key);
    return readParticipantCommunicationExceptionDetails;
  }

  /**
   * Reads the concernRoleType for a concernRole.
   *
   * @param key
   * contains the concern role ID for which the concernRoleType is read
   *
   * @return The concernRoleType.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ConcernRoleTypeDetails readConcernRoleType(
    final ReadParticipantConcernRoleKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ConcernRoleTypeDetails concernRoleTypeDetails = new ConcernRoleTypeDetails();

    concernRoleTypeDetails = delegate.readConcernRoleType(key);
    return concernRoleTypeDetails;
  }

  // BEGIN, CR00294967, MV
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @deprecated Since Curam 6.0 SP3, replaced by {@link #readConcernContact()}. The
   * return struct of the current method readContact has an
   * aggregation to the struct ConcernContactDtls, the attribute
   * statusCode in the struct ConcernContactDtls is modeled with a
   * domain of CONTACTSTATUS code-table, but the corresponding
   * entity attribute ConcernRoleContactDtls.statusCode is modeled
   * with a domain of RECORD_STATUS_CODE. So new method is
   * introduced to return new struct ReadConcernContactDetails
   * which has an aggregation to the new struct
   * ConcernContactRMultiDtls where the attribute statusCode is
   * modeled with a domain of RECORD_STATUS_CODE. See release note:
   * CEF-8999.
   */
  // END, CR00294967
  public ReadContactDetails readContact(final ReadContactKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ReadContactDetails readContactDetails = new ReadContactDetails();

    readContactDetails = delegate.readContact(key);
    return readContactDetails;
  }
  
  // BEGIN, CR00294967, MV 
  /**
   * Reads a contact for a participant.
   *
   * @param key
   * contains the contact ID for which a contact is returned.
   *
   * @return The contact details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadConcernContactDetails readConcernContact(final ReadContactKey key)
    throws AppException, InformationalException {

    final Participant delegate = ParticipantFactory.newInstance();
    ReadConcernContactDetails readConcernContactDetails = new ReadConcernContactDetails();

    readConcernContactDetails = delegate.readConcernContact(key);
    return readConcernContactDetails;
  }

  // END, CR00294967

  /**
   * Read the context description for a concern role ID.
   *
   * @param key
   * contains the concern role ID for which the description is
   * retrieved.
   *
   * @return The returned description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantContextDetails readContextDescription(
    final ParticipantContextKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();
    ParticipantContextDetails participantContextDetails = new ParticipantContextDetails();

    participantContextDetails = delegate.readContextDescription(key);
    return participantContextDetails;
  }

  /**
   * Read the details for a participants email address.
   *
   * @param key
   * contains the email address ID of the record being read.
   *
   * @return The email address details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantEmailAddressDetails readEmailAddress(
    final ReadParticipantEmailAddressKey key)
    throws AppException, InformationalException {

    ReadParticipantEmailAddressDetails readParticipantEmailAddressDetails = new ReadParticipantEmailAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantEmailAddressDetails = delegate.readEmailAddress(key);
    return readParticipantEmailAddressDetails;
  }

  /**
   * Retrieves a person's interaction details.
   *
   * @param key
   * identifies interaction to be found.
   *
   * @return A person's interaction details found.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadInteractionDetails readInteraction(final ReadInteractionKey key)
    throws AppException, InformationalException {

    ReadInteractionDetails readInteractionDetails = new ReadInteractionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readInteractionDetails = delegate.readInteraction(key);
    return readInteractionDetails;
  }

  // BEGIN, CR00231506, PDN
  /**
   * Read the details of a note for a participant.
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated - replaced by {@link #premodifyNote1()}
   * @deprecated -since Version 6.0
   */
  @Deprecated
  public ReadParticipantNoteDetails readNote(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails readParticipantNoteDetails = new ReadParticipantNoteDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote(key);
    return readParticipantNoteDetails;
  }

  /**
   * Read the details of a note for a participant.
   *
   * @param key
   * Identifies a participant note.
   *
   * @return The notes details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantNoteDetails1 readNote1(final ParticipantNoteKey key)
    throws AppException, InformationalException {

    ReadParticipantNoteDetails1 readParticipantNoteDetails = new ReadParticipantNoteDetails1();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantNoteDetails = delegate.readNote1(key);
    return readParticipantNoteDetails;
  }

  // END, CR00231506


  /**
   * Read the Contact Context Description Details for a Participant.
   *
   * @param key
   * contains the contact ID the context description is returned for.
   *
   * @return The contact context description.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ContactContextDescriptionDetails readParticipantContactContextDescription(
    final ContactContextDescriptionKey key)
    throws AppException, InformationalException {

    ContactContextDescriptionDetails contactContextDescriptionDetails = new ContactContextDescriptionDetails();
    Participant delegate = ParticipantFactory.newInstance();

    contactContextDescriptionDetails = delegate.readParticipantContactContextDescription(
      key);
    return contactContextDescriptionDetails;
  }

  /**
   * Reads a phone number record for a concern role.
   *
   * @param key contains the concern role phone number ID.
   *
   * @return The phone number details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantPhoneNumberDetails readPhoneNumber(
    final ReadParticipantPhoneNumberKey key)
    throws AppException, InformationalException {

    ReadParticipantPhoneNumberDetails readParticipantPhoneNumberDetails = new  ReadParticipantPhoneNumberDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantPhoneNumberDetails = delegate.readPhoneNumber(key);
    return readParticipantPhoneNumberDetails;
  }

  /**
   * Read the details for a participants web address.
   *
   * @param key
   * contains the web address ID of the record being read.
   *
   * @return The web address details returned from the database.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ReadParticipantWebAddressDetails readWebAddress(
    final ParticipantWebAddressKey key)
    throws AppException, InformationalException {

    ReadParticipantWebAddressDetails readParticipantWebAddressDetails = new ReadParticipantWebAddressDetails();
    Participant delegate = ParticipantFactory.newInstance();

    readParticipantWebAddressDetails = delegate.readWebAddress(key);
    return readParticipantWebAddressDetails;
  }

  /**
   * Records an existing communication.
   *
   * @param details
   * contains the details of the existing communication.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   *
   * @deprecated
   */
  @Deprecated
  public void recordExistingCommunication(
    final RecordExistingCommunicationDetails details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.recordExistingCommunication(details);
  }

  /**
   * Removes an address record for a concern role.
   *
   * @param key contains the concern role address key
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void removeAddress(final ReadParticipantAddressKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.removeAddress(key);
  }

  /**
   * Resolves the home page for prospect person and prospect employer.
   *
   * Security checks are not applied in this method as it must be used from
   * the resolve script only.
   *
   * @param key contains the concern Role ID of the record being read.
   *
   * @return The home page name.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public ParticipantHomePageName resolveProspectHome(
    final ConcernRoleKeyStruct key)
    throws AppException, InformationalException {

    ParticipantHomePageName participantHomePageName = new ParticipantHomePageName();
    Participant delegate = ParticipantFactory.newInstance();

    participantHomePageName = delegate.resolveProspectHome(key);
    return participantHomePageName;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Searches for all Participants by specified search criteria.
   *
   * @param key Participant search criteria
   *
   * @return Participant details found
   *
   * @throws InformationalException Informational Exception
   * @throws AppException Application Exception
   *
   * @deprecated Since Curam 6.0 SP2, replaced with {@link 
   * Employer#searchParticipantDetails(AllParticipantSearchKey)}
   *
   * This method is deprecated as informational messages are not returned. This 
   * method is replaced by searchParticipantDetails(AllParticipantSearchKey) 
   * which returns the informational message along with participant details 
   * as well. See release note: CS-09152/CR00290965.
   */
  @Deprecated
  public AllParticipantSearchResult searchParticipant(
    AllParticipantSearchKey key)
    throws AppException, InformationalException {
    // END, CR00290965
    
    AllParticipantSearchResult allParticipantSearchResult = new AllParticipantSearchResult();
    Participant delegate = ParticipantFactory.newInstance();

    allParticipantSearchResult = delegate.searchParticipant(key);
    return allParticipantSearchResult;
  }

  /**
   * Sends an email communication.
   *
   * @Deprecated
   * @param details
   * contains the details to send the communication.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  @Deprecated
  public void sendEmailCommunication(final SendEmailCommKey details)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.sendEmailCommunication(details);
  }

  /**
   * Updates the payment details for all cases, where the old bank account was
   * being paid, to the new bank account.
   *
   * @param key
   * contains the concern role ID and the bank
   * account ID of the bank for which payment will now be made to.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public void updateBankAccountPaymentDetails(
    final UpdateBankAccPaymentDtlsKey key)
    throws AppException, InformationalException {

    Participant delegate = ParticipantFactory.newInstance();

    delegate.updateBankAccountPaymentDetails(key);
  }

  /**
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   * @deprecated Since Curam 6.0, replaced by
   * {@link #createBankAccountWithTextSortCode()}.
   * Create a new bank account for a participant.
   */
  @Deprecated
  public CreateParticipantBankAccountDetails createBankAccount(
    MaintainParticipantBankAccountDetails details)
    throws AppException, InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails = new CreateParticipantBankAccountDetails();
    Participant delegate = ParticipantFactory.newInstance();

    createParticipantBankAccountDetails = delegate.createBankAccount(details);
    return createParticipantBankAccountDetails;
  }

  /**
   * Create a new bank account for a participant.
   *
   * @param details
   * The bank account details being entered.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public CreateParticipantBankAccountDetails createBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    CreateParticipantBankAccountDetails createParticipantBankAccountDetails = new CreateParticipantBankAccountDetails();
    Participant delegate = ParticipantFactory.newInstance();

    createParticipantBankAccountDetails = delegate.createBankAccountWithTextSortCode(
      details);
    return createParticipantBankAccountDetails;
  }

  /**
   * Modify the bank account details for a participant.
   *
   * @param details
   * The bank account details being modified.
   *
   * @return A list of informational messages.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public InformationMsgDtlsList modifyBankAccountWithTextSortCode(
    final MaintainParticipantBankAccountWithTextSortCodeDetails details)
    throws AppException, InformationalException {

    InformationMsgDtlsList informationMsgDtlsList = new InformationMsgDtlsList();
    Participant delegate = ParticipantFactory.newInstance();

    informationMsgDtlsList = delegate.modifyBankAccountWithTextSortCode(details);
    return informationMsgDtlsList;
  }

  // END, CR00233791

  // BEGIN, CR00264512, ZV
  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria. Excludes prospect
   * employers. Does not return names as hyperlinks as this is for popup pages.
   *
   * @param key
   * employer data to be searched for.
   *
   * @return Employer details found
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link Employer#searchEmployerWithoutProspectForPopup(EmployerSearchKey1)}
   *
   * This method is deprecated as informational messages are not
   * returned. This method is replaced by
   * searchEmployerWithoutProspectForPopup(EmployerSearchKey1) which
   * returns the informational message along with search employer
   * details as well. See release note: CS-09152/CR00282028.
   */
  @Deprecated
  public EmployerSearchResult1 searchWithoutProspectForPopup(
    EmployerSearchKey1 key) throws AppException, InformationalException {
    // END, CR00282028
    EmployerSearchRouter employerSearchRouterObj = EmployerSearchRouterFactory.newInstance();

    EmployerSearchResult1 employerSearchResult = new EmployerSearchResult1();

    key.key.disableLinkInd = true;

    employerSearchResult.dtls = employerSearchRouterObj.search1(key.key);

    for (int i = 0; i < employerSearchResult.dtls.dtlsList.size(); i++) {
      if (employerSearchResult.dtls.dtlsList.item(i).employerTabDetailsURL.substring(CuramConst.gkZero, CuramConst.gkProspectEmployerTabDetailsPage.length()).equals(
        CuramConst.gkProspectEmployerTabDetailsPage)) {
        employerSearchResult.dtls.dtlsList.remove(i--);
      }
    }

    // BEGIN, CR00264925, ZV
    // If no search results are found, alert user
    if (employerSearchResult.dtls.dtlsList.isEmpty()) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(GENERALSEARCH.INF_SEARCH_NORECORDSFOUND),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);

      informationalManager.failOperation();

    }
    // END, CR00264925

    return employerSearchResult;
  }

  // END, CR00264512

  // BEGIN, CR00282028, IBM
  /**
   * Searches for an employer by specified search criteria.
   *
   * @param employerSearchKey1
   * contains employer search key.
   *
   * @return employer details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.     
   */
  public EmployerSearchDetailsResult searchEmployer(
    final EmployerSearchKey1 employerSearchKey1) throws AppException,
      InformationalException {
    
    EmployerSearchRouter employerSearchRouterObj = EmployerSearchRouterFactory.newInstance();

    EmployerSearchDetailsResult employerSearchResult = new EmployerSearchDetailsResult();

    employerSearchResult.dtls = employerSearchRouterObj.search1(
      employerSearchKey1.key);

    collectInformationalMsgs(employerSearchResult.informationalMsgDtls);

    return employerSearchResult;
  }
  
  /**
   * Searches for an employer by specified search criteria. This is used for 
   * popup pages and does not return names as hyperlinks.
   *
   * @param employerSearchKey1
   * contains employer search key.
   *
   * @return employer details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature. 
   */
  public EmployerSearchDetailsResult searchEmployerForPopup(
    final EmployerSearchKey1 employerSearchKey1) throws AppException,
      InformationalException {
    
    EmployerSearchRouter employerSearchRouterObj = EmployerSearchRouterFactory.newInstance();

    EmployerSearchDetailsResult employerSearchResult = new EmployerSearchDetailsResult();

    employerSearchKey1.key.disableLinkInd = true;

    employerSearchResult.dtls = employerSearchRouterObj.search1(
      employerSearchKey1.key);
    
    collectInformationalMsgs(employerSearchResult.informationalMsgDtls);
    
    return employerSearchResult;
  }

  /**
   * Searches for an employer by specified search criteria. Excludes prospect
   * employers. This is used for popup pages and does not return names as hyperlinks.
   *
   * @param employerSearchKey1
   * contains employer search key.
   *
   * @return employer details
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature. 
   */
  public EmployerSearchDetailsResult searchEmployerWithoutProspectForPopup(
    final EmployerSearchKey1 employerSearchKey1) throws AppException,
      InformationalException {
    
    EmployerSearchRouter employerSearchRouterObj = EmployerSearchRouterFactory.newInstance();

    EmployerSearchDetailsResult employerSearchResult = new EmployerSearchDetailsResult();

    employerSearchKey1.key.disableLinkInd = true;

    employerSearchResult.dtls = employerSearchRouterObj.search1(
      employerSearchKey1.key);
    
    // Checks the tab details and remove from employer search details list 
    for (int i = 0; i < employerSearchResult.dtls.dtlsList.size(); i++) {
      if (CuramConst.gkProspectEmployerTabDetailsPage.equals(
        employerSearchResult.dtls.dtlsList.item(i).employerTabDetailsURL.substring(
          CuramConst.gkZero, 
          CuramConst.gkProspectEmployerTabDetailsPage.length()))) {
        employerSearchResult.dtls.dtlsList.remove(i--);
      }
    }

    if (employerSearchResult.dtls.dtlsList.isEmpty()) {

      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(GENERALSEARCH.INF_SEARCH_NORECORDSFOUND),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);

      informationalManager.failOperation();
    }
    
    collectInformationalMsgs(employerSearchResult.informationalMsgDtls);
    
    return employerSearchResult;
  }

  /**
   * Collects the list of informations from the InformationalManager and add
   * them to the msgDtlsList parameter passed in.
   *
   * @param msgDtlsList
   * contains informational message details.
   */
  protected void collectInformationalMsgs(
    final InformationalMsgDtlsList informationalMsgDtlsList) {

    final InformationalManager informationalManager = TransactionInfo.getInformationalManager();
    
    final String[] infos = informationalManager.obtainInformationalAsString();

    for (String message : infos) {
      
      final InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = message;

      informationalMsgDtlsList.dtls.addRef(informationalMsgDtls);
    }
  }

  // END, CR00282028

  // BEGIN, CR00290965, IBM
  /**
   * Searches for all participants by specified search criteria.
   *
   * @param allParticipantSearchKey contains all participant search key
   *
   * @return participant search details
   *
   * @throws InformationalException Informational Exception
   * @throws AppException Application Exception
   */
  public AllParticipantSearchDetails searchParticipantDetails(
    final AllParticipantSearchKey allParticipantSearchKey) throws AppException, InformationalException {
    
    AllParticipantSearchDetails allParticipantSearchDetails = new AllParticipantSearchDetails();
    
    Participant participant = ParticipantFactory.newInstance();

    allParticipantSearchDetails = participant.searchParticipantDetails(
      allParticipantSearchKey);
    
    return allParticipantSearchDetails;
  }
  // END, CR00290965
}

