/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.codetable.impl.TARGETSYSTEMSTATUSEntry;
import curam.core.facade.struct.TargetSystemDetails;
import curam.core.facade.struct.TargetSystemDetailsList;
import curam.core.facade.struct.TargetSystemKey;
import curam.core.fact.UsersFactory;
import curam.core.struct.UsersKey;
import curam.ctm.sl.entity.struct.TargetSystemDtlsList;
import curam.ctm.targetsystem.impl.TargetSystem;
import curam.ctm.targetsystem.impl.TargetSystemDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This facade class manages a {@link curam.ctm.targetsystem.impl.TargetSystem
 * TargetSystem}. It stores the details of the target system.
 */
public abstract class MaintainTargetSystem extends curam.core.facade.base.MaintainTargetSystem {

  /**
   * Reference to {@link curam.ctm.targetsystem.impl.TargetSystem TargetSystem}.
   */
  @Inject
  protected TargetSystemDAO targetSystemDAO;

  /**
   * Default constructor.
   */
  public MaintainTargetSystem() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a target system details. This method also sets the status of the
   * target system to 'Active'.
   *
   * @param details
   * Contains the target system name and URL.
   *
   * @return The key of the target system.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TargetSystemKey createTargetSystem(final TargetSystemDetails details)
    throws AppException, InformationalException {
    final TargetSystemKey targetSystemKey = new TargetSystemKey();
    
    // BEGIN, CR00314845, PB
    // BEGIN, CR00313513, PB
    final TargetSystem targetSystem = targetSystemDAO.createTargetSystem(
      details.dtls.systemName, details.dtls.rootURL);

    // END, CR00313513
    // END, CR00314845

    targetSystemKey.systemID = targetSystem.getID();
    return targetSystemKey;
  }

  /**
   * Deletes a target system details logically and sets the target system status
   * to 'Canceled'.
   *
   * @param key
   * Contains key of a target system.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void deleteTargetSystem(final TargetSystemKey key)
    throws AppException, InformationalException {
    final TargetSystem targetSystem = targetSystemDAO.get(key.systemID);

    targetSystem.setStatus(TARGETSYSTEMSTATUSEntry.CANCELED);
    targetSystem.modify(targetSystem.getVersionNo());
  }

  /**
   * Returns a list of all target system configured.
   *
   * @return The list of all target systems.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TargetSystemDetailsList listTargetSystems() throws AppException,
      InformationalException {
    final TargetSystemDetailsList targetSystemDetailsList = new TargetSystemDetailsList();
    final List<TargetSystem> targetSystems = targetSystemDAO.readAll();

    for (final TargetSystem targetSystem : targetSystems) {
      targetSystemDetailsList.dtls.addRef(getTargetSystemFields(targetSystem));
    }
    return targetSystemDetailsList;
  }

  /**
   * Returns a list of all active target systems.
   *
   * @return The list of active target systems.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TargetSystemDtlsList listAvailableSystems() throws AppException,
      InformationalException {
    final TargetSystemDtlsList targetSystemDtlsList = new TargetSystemDtlsList();
    final List<TargetSystem> targetSystems = targetSystemDAO.readAll();

    for (final TargetSystem targetSystem : targetSystems) {
      if (TARGETSYSTEMSTATUSEntry.ACTIVE.getCode().equals(
        targetSystem.getStatus().getCode())) {
        targetSystemDtlsList.dtls.addRef(
          getTargetSystemFields(targetSystem).dtls);
      }
    }
    return targetSystemDtlsList;
  }

  /**
   * Modifies a target system details. User can modify target system name and
   * root URL if the record status is 'Active'.
   *
   * @param details
   * Contains the target system details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyTargetSystem(TargetSystemDetails details)
    throws AppException, InformationalException {
    final TargetSystem targetSystem = targetSystemDAO.get(details.dtls.systemID);

    setTargetSystemFields(targetSystem, details);
    targetSystem.modify(details.dtls.versionNo);
  }

  /**
   * Views a target system details consisting of system name, created date,
   * status, created user and system URL specified during creation.
   *
   * @param key
   * Contains key of the target system.
   *
   * @return The target system details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TargetSystemDetails viewTargetSystem(final TargetSystemKey key)
    throws AppException, InformationalException {
    return getTargetSystemFields(targetSystemDAO.get(key.systemID));
  }

  /**
   * Gets the target system details from an TargetSystem instance.
   *
   * @param targetSystem
   * TargetSysteminstance.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected TargetSystemDetails getTargetSystemFields(
    final curam.ctm.targetsystem.impl.TargetSystem targetSystem) 
    throws AppException, InformationalException {
    TargetSystemDetails targetSystemDetails = new TargetSystemDetails();

    targetSystemDetails.dtls.systemID = targetSystem.getID();
    targetSystemDetails.dtls.systemName = targetSystem.getSystemName();
    targetSystemDetails.dtls.rootURL = targetSystem.getRootURL();
    UsersKey userskey = new UsersKey();

    userskey.userName = targetSystem.getCreatedBy();
    targetSystemDetails.dtls.createdBy = UsersFactory.newInstance().readUserFullname(userskey).fullname; 
    targetSystemDetails.dtls.createdDate = targetSystem.getCreationDate();
    targetSystemDetails.dtls.status = targetSystem.getStatus().getCode();
    targetSystemDetails.dtls.versionNo = targetSystem.getVersionNo();
    if (targetSystem.getStatus().equals(TARGETSYSTEMSTATUSEntry.CANCELED)) {
      targetSystemDetails.recordCanceledInd = true;
    } else {
      targetSystemDetails.recordCanceledInd = false;
    }
    return targetSystemDetails;
  }

  /**
   * Sets the target system details to an TargetSystem instance.
   *
   * @param targetSystem
   * TargetSystem instance.
   * @param details
   * Target system details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void setTargetSystemFields(
    final curam.ctm.targetsystem.impl.TargetSystem targetSystem,
    final TargetSystemDetails details) throws AppException,
      InformationalException {
    targetSystem.setSystemName(details.dtls.systemName);
    targetSystem.setRootURL(details.dtls.rootURL);
  }
}
