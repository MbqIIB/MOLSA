/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.facade.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.core.facade.struct.CaseIDKey;
import curam.core.facade.struct.ReadTransactionLogDetailsList;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * This process class provides the functionality for the Case Transaction Log
 * presentation layer.
 */

public abstract class CaseTransactionLog extends curam.core.facade.base.CaseTransactionLog {

  // BEGIN CR00108134, GBA
  // Add injection for using the new CaseTransactionLog API
  public CaseTransactionLog() {
    GuiceWrapper.getInjector().injectMembers(this);
  }
  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;
  // END CR00108134


  // ___________________________________________________________________________
  /**
   * Fetches the list of all transactions for a given case.
   *
   * @param key - CaseIDKey The case id.
   *
   * @return ReadTransactionLogDetailsList The list of transaction logs.
   */

  public ReadTransactionLogDetailsList listAllChanges(CaseIDKey key)
    throws AppException, InformationalException {

    // Case Transaction Log business process object
    ReadTransactionLogDetailsList readTransactionLogDetailsList = new ReadTransactionLogDetailsList();

    curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    caseIDKey.caseID = key.dtls.dtls.caseID;
    // BEGIN CR00108134, GBA
    readTransactionLogDetailsList.transactionDetailsList = caseTransactionLogProvider.get().readAllTransactions(
      caseIDKey);
    // END CR00108134

    return readTransactionLogDetailsList;
  }

}
