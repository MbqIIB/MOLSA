/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2007, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.ActivityByCaseAndConcernKey;
import curam.core.struct.AssessmentSummaryDetailsList;
import curam.core.struct.CaseMemberActivityDtls;
import curam.core.struct.CaseMemberKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.GetSCMemberDetailsResult;
import curam.core.struct.IntegCaseActivityDtlsList;
import curam.core.struct.PersonDtls;
import curam.core.struct.PersonKey;
import curam.core.struct.ProspectPersonDtls;
import curam.core.struct.ProspectPersonKey;
import curam.core.struct.ViewICClientAssessmentKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Reads the details for the client home page on a screening case.
 *
 */
public abstract class CaseMemberHomePage extends curam.core.base.CaseMemberHomePage {

  // ___________________________________________________________________________
  /**
   * Description:
   *  Reads the details for the client home page on a screening case.
   *
   * @param key Contains ConcernRoleID
   *
   * @return ClientHomePageDetails - Member's header details
   *         AssessmentSummaryDetailsList - Member's assessment details list
   *         CaseMemberTaskList - Member's tasks list
   *         CaseMemberActivityList - Member's activities list
   *
   */
  public GetSCMemberDetailsResult getSCMemberDetails(CaseMemberKey key)
    throws AppException, InformationalException {

    GetSCMemberDetailsResult getSCMemberDetailsResult =
      new GetSCMemberDetailsResult();

    // Variables to read person details
    curam.core.intf.Person personObj =
      curam.core.fact.PersonFactory.newInstance();
    PersonDtls personDtls;
    PersonKey personKey = new PersonKey();

    // Variables to read prospect person
    curam.core.intf.ProspectPerson prospectPersonObj =
      curam.core.fact.ProspectPersonFactory.newInstance();
    ProspectPersonDtls prospectPersonDtls;
    ProspectPersonKey prospectPersonKey = new ProspectPersonKey();

    // Variable to read concern role details
    curam.core.intf.ConcernRole concernRoleObj =
      curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Variables to read assessments
    curam.core.intf.MaintainAssessments maintainAssessmentsObj =
      curam.core.fact.MaintainAssessmentsFactory.newInstance();
    ViewICClientAssessmentKey viewICClientAssessmentKey =
      new ViewICClientAssessmentKey();
    AssessmentSummaryDetailsList assessmentSummaryDetailsList;

    // Variables for activity read
    ActivityByCaseAndConcernKey activityByCaseAndConcernKey =
      new ActivityByCaseAndConcernKey();
    curam.core.intf.MaintainActivity maintainActivityObj =
      curam.core.fact.MaintainActivityFactory.newInstance();
    CaseMemberActivityDtls caseMemberActivityDtls;

    IntegCaseActivityDtlsList integCaseActivityDtlsList;

    // Check the concernRoleType to determine whether to do a person read or a
    // prospectPerson read.
    // Get the concern role ID
    concernRoleKey.concernRoleID = key.concernRoleID;

    // Read the concern role information
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // If concernRoleType is a prospect person then do a prospectPerson read.
    if (concernRoleDtls.concernRoleType.equals(
      curam.codetable.CONCERNROLETYPE.PROSPECTPERSON)) {

      // Set the key
      prospectPersonKey.concernRoleID = key.concernRoleID;
      // Read prospectPerson data from database
      prospectPersonDtls = prospectPersonObj.read(prospectPersonKey);

      // Get prospectPerson data from record to result structure
      getSCMemberDetailsResult.dtls.deceasedDate =
        prospectPersonDtls.dateOfDeath;
      getSCMemberDetailsResult.dtls.nationality =
        prospectPersonDtls.nationalityCode;
      getSCMemberDetailsResult.dtls.dateOfBirth =
        prospectPersonDtls.dateOfBirth;
      getSCMemberDetailsResult.dtls.alternateRefNumber =
        prospectPersonDtls.primaryAlternateID;
      getSCMemberDetailsResult.dtls.sex = prospectPersonDtls.gender;
      getSCMemberDetailsResult.dtls.maritalStatus =
        prospectPersonDtls.maritalStatusCode;

      if (!prospectPersonDtls.dateOfDeath.isZero()
        && prospectPersonDtls.dateOfDeathVerInd) {

        getSCMemberDetailsResult.dtls.deceasedInd = true;

      } else {

        getSCMemberDetailsResult.dtls.deceasedInd = false;
      }
    } // else do a Person read
    else {
      // set the key
      personKey.concernRoleID = key.concernRoleID;
      // read person data from database

      personDtls = personObj.read(personKey);

      // Get person data from record to result structure
      getSCMemberDetailsResult.dtls.assign(personDtls);
      getSCMemberDetailsResult.dtls.deceasedDate = personDtls.dateOfDeath;
      getSCMemberDetailsResult.dtls.nationality = personDtls.nationalityCode;
      getSCMemberDetailsResult.dtls.dateOfBirth = personDtls.dateOfBirth;
      getSCMemberDetailsResult.dtls.alternateRefNumber =
        personDtls.primaryAlternateID;
      getSCMemberDetailsResult.dtls.sex = personDtls.gender;
      getSCMemberDetailsResult.dtls.maritalStatus =
        personDtls.maritalStatusCode;

      if (!personDtls.dateOfDeath.isZero() && personDtls.dateOfDeathVerInd) {

        getSCMemberDetailsResult.dtls.deceasedInd = true;

      } else {

        getSCMemberDetailsResult.dtls.deceasedInd = false;
      }
    }

    // Set the full name of client to output
    getSCMemberDetailsResult.dtls.fullName = concernRoleDtls.concernRoleName;

    // Set the concern role type and concern role id of client to output
    getSCMemberDetailsResult.dtls.concernRoleType =
      concernRoleDtls.concernRoleType;
    getSCMemberDetailsResult.dtls.concernRoleID = concernRoleDtls.concernRoleID;

    // Add in the read for the list of assessments here
    viewICClientAssessmentKey.caseID = key.caseID;
    viewICClientAssessmentKey.concernRoleID = key.concernRoleID;

    assessmentSummaryDetailsList =
      maintainAssessmentsObj.viewICClientAssessments(viewICClientAssessmentKey);

    getSCMemberDetailsResult.assessmentList.assign(assessmentSummaryDetailsList);

    // Set the key for reading the list of Activities the client has on this SC
    activityByCaseAndConcernKey.concernRoleID = key.concernRoleID;
    activityByCaseAndConcernKey.caseID = key.caseID;

    integCaseActivityDtlsList =
      maintainActivityObj.readIntegCaseClientActivities(
        activityByCaseAndConcernKey);

    getSCMemberDetailsResult.activityList.dtls.ensureCapacity(
      integCaseActivityDtlsList.dtls.size());

    // Iterate through all activities

    for (int i = 0; i < integCaseActivityDtlsList.dtls.size(); i++) {

      caseMemberActivityDtls = new CaseMemberActivityDtls();

      caseMemberActivityDtls.assign(integCaseActivityDtlsList.dtls.item(i));
      caseMemberActivityDtls.eventType = curam.codetable.CASEEVENTTYPE.ACTIVITY;

      getSCMemberDetailsResult.activityList.dtls.addRef(caseMemberActivityDtls);
    }

    return getSCMemberDetailsResult;
  }

}
