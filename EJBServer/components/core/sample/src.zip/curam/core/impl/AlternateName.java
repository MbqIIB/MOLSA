/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.ArrayList;
import java.util.HashMap;

import curam.codetable.ALTERNATENAMETYPE;
import curam.codetable.CASEEVIDENCE;
import curam.codetable.ENTITYATTRIBUTENAMES;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.IndexAlternateNameSynchronizationFactory;
import curam.core.intf.AlternateNameSnapshot;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.AlternateNameDtls;
import curam.core.struct.AlternateNameKey;
import curam.core.struct.AlternateNameReadMultiStatusStruct;
import curam.core.struct.AlternateNameSnapshotDtls;
import curam.core.struct.AlternateNameSnapshotKey;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.PhoneticEncoderDetails;
import curam.core.struct.PhoneticEncoderKey;
import curam.message.PARTICIPANTDATACASE;
import curam.message.SUMMARYDETAILS;
import curam.pdc.fact.PDCUtilFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.core.intf.IndexAlternateNameSynchronization;
import curam.util.exception.RecordNotFoundException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;


/**
 * implements curam.core.impl.AlternateName
 */
public abstract class AlternateName extends curam.core.base.AlternateName
  implements ParticipantEvidenceInterface {

  protected class AlternateNameCache {
    public AlternateNameCache() {
      map = new HashMap<Long, AlternateNameDtls>();
      transactionID = 0;
    }

    HashMap<Long, AlternateNameDtls> map;

    int transactionID;
  }

  protected static ThreadLocal<AlternateNameCache> cachedReadDetailsTL = new ThreadLocal<AlternateNameCache>();

  // BEGIN, CR00065902, MMC
  // ___________________________________________________________________________
  /**
   * To create a new snapshot record of the alternateName entity, specifically
   * for its use as a ParticpantEvidence.
   *
   * @param key
   * Evidence key for the alternateName Entity to snapshot
   * @return the retEIEvidenceKey to access the snapshot
   */
  public EIEvidenceKey createSnapshot(EIEvidenceKey key) throws AppException,
      InformationalException {

    // return structure
    EIEvidenceKey retEIEvidenceKey = new EIEvidenceKey();

    // Entity and Entity-snapshot objects
    AlternateNameSnapshot alternateNameSnapshotObj = curam.core.fact.AlternateNameSnapshotFactory.newInstance();
    curam.core.intf.AlternateName alternateNameObj = curam.core.fact.AlternateNameFactory.newInstance();

    AlternateNameKey alternateNameKey = new AlternateNameKey();

    alternateNameKey.alternateNameID = key.evidenceID;

    AlternateNameDtls alternateNameDtls = alternateNameObj.read(
      alternateNameKey);
    AlternateNameSnapshotDtls alternateNameSnapshotDtls = new AlternateNameSnapshotDtls();

    // Populate snapshot
    alternateNameSnapshotDtls.assign(alternateNameDtls);
    // BEGIN, CR00065902, MMC
    alternateNameSnapshotDtls.creationDateTime = DateTime.getCurrentDateTime();
    // END, CR00065902
    alternateNameSnapshotObj.insert(alternateNameSnapshotDtls);

    retEIEvidenceKey.evidenceID = alternateNameSnapshotDtls.alternateNameSnapshotID;
    retEIEvidenceKey.evidenceType = CASEEVIDENCE.ALTERNATENAME;

    return retEIEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Inserts AlternateName evidence on modification
   *
   * @param dtls
   * Object containing details of entity
   * @param origKey
   * EIEvidenceKey for entity to insert
   * @param parentKey
   * EIEvidenceKey for parent
   * @return the eiEvidenceKey to access the inserted evidence
   */
  public EIEvidenceKey insertEvidenceOnModify(Object dtls,
    EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException,
      InformationalException {
    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((AlternateNameDtls) dtls);

    eiEvidenceKey.evidenceID = ((AlternateNameDtls) dtls).alternateNameID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.ALTERNATENAME;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * reads all AlternateName Entities by its Parent ID
   *
   * @param key
   * EIEvidenceKey param containing the parent ID
   * @return the EIEvidenceKeyList with the Parent specified
   */
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key)
    throws AppException, InformationalException {
    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * return list for validation
   *
   * @param evKey
   * EIEvidenceKey param
   * @return the EIEvidenceKeyList to validate
   */
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey)
    throws AppException, InformationalException {
    // This evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * run validations
   *
   * @param evKey
   * EIEvidenceKey
   * @param evKeyList
   * EIEvidenceKeyList
   * @param mode
   * Validate Mode
   */
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList,
    ValidateMode mode) throws AppException, InformationalException {// This
    // evidence
    // interface
    // method
    // is
    // currently
    // not
    // implemented
    // for
    // participant evidence.
  }

  // ___________________________________________________________________________
  /**
   * remove Entity
   *
   * @param key
   * EIEvidenceKey for entity to remove
   * @param dtls
   * Object containing details of entity to remove
   */
  public void removeEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {
    // Entity key
    AlternateNameKey alternateNameKey = new AlternateNameKey();

    // Set entity key for modify
    alternateNameKey.alternateNameID = key.evidenceID;

    // Modify details
    modify(alternateNameKey, (AlternateNameDtls) dtls);

  }

  // ___________________________________________________________________________
  /**
   * Clear cached data in cachedReadDetailsTL
   */
  protected void clearCaches() {
    AlternateNameCache cache = cachedReadDetailsTL.get();

    if (cache != null) {
      cache.map.clear();
    } else {
      cache = new AlternateNameCache();
      cachedReadDetailsTL.set(cache);
    }
    cache.transactionID = TransactionInfo.getIdentifierForThisThread();

  }

  // __________________________________________________________________________
  /**
   * Inserts details into database. The cache is cleared first.
   *
   * @param details
   * Contains entity details to insert
   */
  @Override
  public void insert(AlternateNameDtls details) throws AppException,
      InformationalException {
    this.clearCaches();
    super.insert(details);

  }

  // __________________________________________________________________________
  /**
   * Modifies details in the database Entity. The cache is cleared first.
   *
   * @param key
   * Contains key to access entity details
   * @param details
   * Contains details to modify
   */
  @Override
  public void modify(AlternateNameKey key, AlternateNameDtls details)
    throws AppException, InformationalException {

    // We want to clear the cache in case for some reason the database
    // evidence is required e.g. if the evidence was updated by another user.
    // So to ensure we have the correct evidence, clear the cache and force a
    // read from the database
    this.clearCaches();

    // BEGIN, CR00250206, ZV
    AlternateNameDtls readAlternateNameDtls = read(key);

    IndexAlternateNameSynchronization alternateNameSynchronizationObj = IndexAlternateNameSynchronizationFactory.newInstance();

    boolean indexRemovedInd = false;

    // remove GSS index and insert new one if concern role id is changed
    // or update current index if other details are changed
    if (readAlternateNameDtls.concernRoleID != details.concernRoleID) {
      alternateNameSynchronizationObj.remove(readAlternateNameDtls);
      indexRemovedInd = true;
    }

    super.modify(key, details);

    if (indexRemovedInd) {
      alternateNameSynchronizationObj.insert(details);
    } else {
      alternateNameSynchronizationObj.modify(key, details);
    }
    // END, CR00250206

    // The reason why we have to clear the cache here is a result of how the
    // evidence controller performs the modifying of evidence. PreModifying the
    // record it reads the details (first time it reads the details so will be
    // read from database and cached). The record is modified and post
    // modifying, the evidence controller calls performValidation
    // (validates the record) which requires a read of the evidence. The cached
    // evidence has stored the evidence PRIOR to the modification of the record.
    // Therefore we want to go to the database to read the modified evidence and
    // as a result clear the cache post modification.
    this.clearCaches();

  }

  // ___________________________________________________________________________
  /**
   * Calculates the AttributionDates For entity, specifically for its use as a
   * ParticpantEvidence.
   *
   * @param caseKey
   * @param evKey
   * @return the AttributedDateDetails
   */
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey,
    EIEvidenceKey evKey) throws AppException, InformationalException {

    AttributedDateDetails retAttributedDateDetails = new AttributedDateDetails();

    // BEGIN, CR00060591, POH
    // There are no dates which correspond to "from" and "to" dates
    // so these are set to zeroDate
    retAttributedDateDetails.fromDate = curam.util.type.Date.kZeroDate;
    retAttributedDateDetails.toDate = curam.util.type.Date.kZeroDate;
    // END, CR00060591

    return retAttributedDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * Get evidence details for the list display
   *
   * @param key
   * Evidence key containing the evidenceID and evidenceType
   *
   * @return the details to be displayed on the list page
   */
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key)
    throws AppException, InformationalException {

    // return struct
    EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // BEGIN, CR00060473, MMC
    // manipulation variables

    try {
      // BEGIN, CR00060607, POH
      // Populate the alternateNameKey with passed in parameter,
      // and read AlternateName details
      AlternateNameKey alternateNameKey = new AlternateNameKey();
      curam.core.intf.AlternateName alternateNameObj = curam.core.fact.AlternateNameFactory.newInstance();

      alternateNameKey.alternateNameID = key.evidenceID;
      AlternateNameDtls alternateNameDtls = alternateNameObj.read(
        alternateNameKey);

      // set start and end dates
      eiFieldsForListDisplayDtls.startDate = curam.util.type.Date.kZeroDate;
      eiFieldsForListDisplayDtls.endDate = curam.util.type.Date.kZeroDate;
      // END, CR00060607

      // Set the summary details.
      // BEGIN, CR00241068, CD
      LocalisableString message = new LocalisableString(
        SUMMARYDETAILS.ALTERNATE_NAME);

      message.arg(
        CodeTable.getOneItem(ALTERNATENAMETYPE.TABLENAME,
        alternateNameDtls.nameType));
      message.arg(alternateNameDtls.fullName);

      // BEGIN, CR00244064, CD
      eiFieldsForListDisplayDtls.summary = message.toClientFormattedText();
      // END, CR00244064
      // END, CR00241068

    } // If the AlternateName record is not found, then the ID passed in must
    // belong to a AlternateNameSnapshot record
    catch (RecordNotFoundException rnfe) {

      // Read the AlternateNameSnapshot details
      AlternateNameSnapshotKey alternateNameSnapshotKey = new AlternateNameSnapshotKey();

      alternateNameSnapshotKey.alternateNameSnapshotID = key.evidenceID;
      AlternateNameSnapshotDtls alternateNameSnapshotDtls = curam.core.fact.AlternateNameSnapshotFactory.newInstance().read(
        alternateNameSnapshotKey);

      // BEGIN, CR00060607, POH
      // set start and end dates
      eiFieldsForListDisplayDtls.startDate = curam.util.type.Date.kZeroDate;
      eiFieldsForListDisplayDtls.endDate = curam.util.type.Date.kZeroDate;
      // END, CR00060607

      // BEGIN, CR00241068, CD
      LocalisableString message = new LocalisableString(SUMMARYDETAILS.ADDRESS);

      message.arg(
        CodeTable.getOneItem(ALTERNATENAMETYPE.TABLENAME,
        alternateNameSnapshotDtls.nameType));
      message.arg(alternateNameSnapshotDtls.fullName);

      // BEGIN, CR00244064, CD
      eiFieldsForListDisplayDtls.summary = message.toClientFormattedText();
      // END, CR00244064
      // END, CR00241068

    }

    // END, CR00060473
    return eiFieldsForListDisplayDtls;

  }

  // ___________________________________________________________________________
  /**
   * Inserts evidence details - overrides Participant Evidence inherited
   * abstract method
   *
   * @param dtls
   * Object containing details of entity
   * @param parentKey
   * Key for parent
   *
   * @return the key for inserted evidence
   */
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey)
    throws AppException, InformationalException {
    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((AlternateNameDtls) dtls);

    eiEvidenceKey.evidenceID = ((AlternateNameDtls) dtls).alternateNameID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.ALTERNATENAME;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies evidence details - overrides Participant Evidence inherited
   * abstract method
   *
   * @param key
   * Evidence key containing the evidenceID and evidenceType
   * @param dtls
   * Object containing details of entity
   */
  public void modifyEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {
    // AlternateName entity key
    AlternateNameKey alternateNameKey = new AlternateNameKey();

    // Set entity key for modify
    alternateNameKey.alternateNameID = key.evidenceID;

    // Modify details
    modify(alternateNameKey, (AlternateNameDtls) dtls);

  }

  // ___________________________________________________________________________
  /**
   * Read evidence details - overrides Participant Evidence inherited abstract
   * method
   *
   * @param key
   * EIEvidenceKey to read
   * @return the entity details read
   */
  public Object readEvidence(EIEvidenceKey key) throws AppException,
      InformationalException {

    // Entity and Entity-snapshot objects
    AlternateNameSnapshot alternateNameSnapshotObj = curam.core.fact.AlternateNameSnapshotFactory.newInstance();

    // BEGIN, CR00060473, MMC
    curam.core.intf.AlternateName alternateNameObj = curam.core.fact.AlternateNameFactory.newInstance();
    AlternateNameDtls alternateNameDtls = new AlternateNameDtls();

    // Attempt to read the record using the evidenceID passed in, if a record is
    // found return the details as an object.
    // If no record is found attempt to read the snapshot record using the
    // passed in evidenceID.
    // If a record is found return the details as an object.

    try {
      AlternateNameKey alternateNameKey = new AlternateNameKey();

      alternateNameKey.alternateNameID = key.evidenceID;
      alternateNameDtls = alternateNameObj.read(alternateNameKey);
      return alternateNameDtls;

    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot alternateName entity
      AlternateNameSnapshotKey alternateNameSnapshotKey = new AlternateNameSnapshotKey();

      alternateNameSnapshotKey.alternateNameSnapshotID = key.evidenceID;
      AlternateNameSnapshotDtls alternateNameSnapshotDtls = alternateNameSnapshotObj.read(
        alternateNameSnapshotKey);

      alternateNameDtls.assign(alternateNameSnapshotDtls);
      return alternateNameDtls;
    }
    // END, CR00060473

  }

  // _____________________________________________________________________________
  /**
   * Formats alternate name for a person
   *
   * @param details
   * Alternate name details
   */
  @Override
  protected void autovalidate(AlternateNameDtls details) throws AppException,
      InformationalException {
    setFullName(details);
  }

  // _____________________________________________________________________________
  /**
   * Formats full name for a person This method should be customized in line
   * with local preferences to form a full name. Customer is free to assemble a
   * full name from this method's parameters. The full name will be returned
   * back to the caller through method's parameter.
   *
   * @param details
   * Name details
   */
  @Override
  protected void setFullName(AlternateNameDtls details) throws AppException,
      InformationalException {
    StringBuffer sBuff = new StringBuffer();
    boolean fForename = false;
    boolean fSurname = false;

    // first forename
    if (details.firstForename.length() > 0) {
      sBuff.append(details.firstForename);
      fForename = true;
    }

    // surname
    if (details.surname.length() > 0) {

      if (fForename) {
        sBuff.append(CuramConst.gkSpace);
      }

      sBuff.append(details.surname);
      fSurname = true;
    }

    if ((!fForename) && (!fSurname)) {
      AppException e = new AppException(
        curam.message.BPOALTERNATENAME.ERR_ALTERNATENAME_XFV_NAMES_EMPTY);

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    } else {
      details.fullName = sBuff.toString();
    }

  }

  // BEGIN, CR00059697, SSK
  // ___________________________________________________________________________
  /**
   * Method to search for records on a participant entity by concernRoleID.
   *
   * @param key
   * - The unique concernRoleID of the participant.
   * @return A list of EIEvidenceKey objects each containing a
   * evidenceID/evidenceType pair.
   */
  public EIEvidenceKeyList readAllByConcernRoleID(ConcernRoleIDKey key)
    throws AppException, InformationalException {
    // BEGIN, CR00060375, MMC
    // return struct
    EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    // manipulation variables
    curam.core.intf.AlternateName alternateNameObj = curam.core.fact.AlternateNameFactory.newInstance();

    AlternateNameReadMultiStatusStruct alternateNameReadMultiStatusStruct = new AlternateNameReadMultiStatusStruct();

    // BEGIN, CR00065999, JPG
    // populate the concernRoleAddress key with passed in parameter
    alternateNameReadMultiStatusStruct.concernRoleID = key.concernRoleID;
    alternateNameReadMultiStatusStruct.nameStatus = RECORDSTATUS.NORMAL;

    // read list of concernRoleAddress records for concernRole
    curam.core.struct.NameReadMultiDtlsList nameReadMultiDtlsList = alternateNameObj.searchActiveByConcernRole(
      alternateNameReadMultiStatusStruct);

    // END, CR00065999

    // loop through returned list adding each returned ID to returned struct.
    for (int i = 0; i < nameReadMultiDtlsList.dtls.size(); i++) {

      // Instantiate struct
      EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

      // populate details
      eiEvidenceKey.evidenceID = nameReadMultiDtlsList.dtls.item(i).alternateNameID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.ALTERNATENAME;

      // add details to return struct
      eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
    }
    return eiEvidenceKeyList;
    // END, CR00060375, MMC
  }

  // END, CR00059697
  // BEGIN, CR00065902

  // BEGIN, CR00069014, JPG
  // ___________________________________________________________________________
  /**
   * Method to compare attributes on two records of the same entity type. It
   * then returns an ArrayList of strings with the names of each attribute that
   * was different between them.
   *
   * @param key
   * - Contains an evidenceID / evidenceType pairing
   * @param dtls
   * - a struct of the same type as the key containing the attributes
   * to be compared against
   *
   * @return A list of Strings. Each represents an attribute name that differed.
   */
  public ArrayList<String> getChangedAttributeList(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Declare the return list to hold the names of the attributes that changed
    ArrayList<String> attributesChanged = new ArrayList<String>();

    // Create alternateNameDtls structs to allow a comparison of what is
    // in the database and what is in the struct dtls.
    AlternateNameDtls alternateNameCompareDtls1 = new AlternateNameDtls();
    AlternateNameDtls alternateNameCompareDtls2 = new AlternateNameDtls();

    try {

      curam.core.intf.AlternateName alternateNameObj = curam.core.fact.AlternateNameFactory.newInstance();

      AlternateNameKey alternateNameKey = new AlternateNameKey();

      alternateNameKey.alternateNameID = key.evidenceID;

      // read AlternateName details
      alternateNameCompareDtls1 = alternateNameObj.read(alternateNameKey);

      // Populate the AlternateName struct that will be compared against
      alternateNameCompareDtls2.assign((AlternateNameDtls) dtls);

    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot AlternateName entity
      curam.core.intf.AlternateNameSnapshot alternateNameSnapshotObj = curam.core.fact.AlternateNameSnapshotFactory.newInstance();

      AlternateNameSnapshotKey alternateNameSnapshotKey = new AlternateNameSnapshotKey();

      // populate the AlternateName snapshot key with passed in parameter
      alternateNameSnapshotKey.alternateNameSnapshotID = key.evidenceID;

      // Read the AlternateName snapshot details
      alternateNameCompareDtls2.assign(
        alternateNameSnapshotObj.read(alternateNameSnapshotKey));

      // Populate the AlternateName struct that will be compared against
      alternateNameCompareDtls1.assign((AlternateNameDtls) dtls);
    }

    if (alternateNameCompareDtls1.alternateNameID
      != alternateNameCompareDtls2.alternateNameID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.ALTERNATENAMEID);
    }
    if (alternateNameCompareDtls1.concernRoleID
      != alternateNameCompareDtls2.concernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEID);
    }
    if (!alternateNameCompareDtls1.title.equals(alternateNameCompareDtls2.title)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.TITLE);
    }
    if (!alternateNameCompareDtls1.firstForename.equals(
      alternateNameCompareDtls2.firstForename)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.FIRSTFORENAME);
    }
    if (!alternateNameCompareDtls1.otherForename.equals(
      alternateNameCompareDtls2.otherForename)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.OTHERFORENAME);
    }
    if (!alternateNameCompareDtls1.surname.equals(
      alternateNameCompareDtls2.surname)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.SURNAME);
    }
    if (!alternateNameCompareDtls1.nameSuffix.equals(
      alternateNameCompareDtls2.nameSuffix)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.NAMESUFFIX);
    }
    if (!alternateNameCompareDtls1.nameType.equals(
      alternateNameCompareDtls2.nameType)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.NAMETYPE);
    }
    if (!alternateNameCompareDtls1.nameStatus.equals(
      alternateNameCompareDtls2.nameStatus)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.NAMESTATUS);
    }
    if (!alternateNameCompareDtls1.comments.equals(
      alternateNameCompareDtls2.comments)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COMMENTS);
    }
    if (!alternateNameCompareDtls1.initials.equals(
      alternateNameCompareDtls2.initials)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.INITIALS);
    }

    return attributesChanged;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if the attributes that changed during a modify require
   * reassessment to be run when they are applied.
   *
   * @param attributesChanged
   * - A list of Strings. Each represents the name of an attribute that
   * changed
   *
   * @return true if Reassessment required
   */
  public boolean checkForReassessment(ArrayList attributesChanged)
    throws AppException, InformationalException {

    return true;

    /*
     * Implement code here if you wish to only reassess modifications to
     * participant evidence when specified attributes are changed during the
     * modification. Currently this method returns true so any modifications to
     * participant evidence will trigger reassessment. To Implement set an
     * indicator to false and check the attributesChanged list for the
     * attributes that require reassessment. If one is found set the in
     * indicator to true
     */
  }

  // END, CR00069014

  // BEGIN, CR00076104, PMD
  // ___________________________________________________________________________
  /**
   * When Participant Data Case is enabled an Application Exception will be thrown
   * when this method is called.  
   *
   * @param details Alternate Name details to be inserted.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   * @throws InformationalException
   */  
  @Override
  protected void preinsert(AlternateNameDtls details) throws AppException,
      InformationalException {

    // BEGIN, CR00346296, PMD
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.concernRoleID;
        
    if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {    
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    }   
    // END, CR00346296
    
    // Convert alternate name details to upper case
    convertDetailsToUpper(details);
    // BEGIN, CR00077564, PD
    // Encode alternate name surname
    phoneticEncodeSurname(details);
    // END, CR00077564

  }

  // ___________________________________________________________________________
  /**
   * When Participant Data Case is enabled an Application Exception will be thrown
   * when this method is called.  
   *
   * @param key Alternate Name ID.
   * @param details Alternate Name details to be modified.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   * @throws InformationalException
   */  
  @Override
  protected void premodify(AlternateNameKey key, AlternateNameDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00346296, PMD
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.concernRoleID;
        
    if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {    
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    }   
    // END, CR00346296
    
    // Convert alternate name details to upper case
    convertDetailsToUpper(details);
    phoneticEncodeSurname(details);
    // END, CR00077564

  }

  // ___________________________________________________________________________
  /**
   * Method to convert the alternate name details to upper case
   *
   * @param details
   * the alternate name details
   */
  @Override
  protected void convertDetailsToUpper(AlternateNameDtls details)
    throws AppException, InformationalException {

    // Convert the firstForename and surname to upper case
    details.upperFirstForename = details.firstForename.toUpperCase();
    details.upperSurname = details.surname.toUpperCase();

  }

  // END, CR00076104

  // BEGIN, CR00077564, PD
  // ___________________________________________________________________________
  /**
   * Method to encode alternate surname using double meta phone algorithm
   *
   * @param details
   * the alternate name details
   */
  protected void phoneticEncodeSurname(AlternateNameDtls details)
    throws AppException, InformationalException {

    curam.core.intf.PhoneticEncoder phoneticEncoderObj = curam.core.fact.PhoneticEncoderFactory.newInstance();
    PhoneticEncoderKey phoneticEncoderKey = new PhoneticEncoderKey();
    PhoneticEncoderDetails phoneticEncoderDetails = new PhoneticEncoderDetails();

    phoneticEncoderKey.surname = details.surname;
    phoneticEncoderDetails = phoneticEncoderObj.encode(phoneticEncoderKey);
    details.phoneticEncoding = phoneticEncoderDetails.phoneticEncodingCode;

  }

  // END, CR00077564

  // BEGIN, CR00078922, CC
  // ___________________________________________________________________________
  /**
   * When Participant Data Case is enabled an Application Exception will be thrown
   * when this method is called.  
   *
   * @param details Alternate Name details that have been inserted.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   * @throws InformationalException
   */  
  @Override
  protected void postinsert(AlternateNameDtls details) throws AppException,
      InformationalException {
    
    // Synchronize the indexed staging database with the update to alternate
    // name entity
    curam.core.intf.IndexAlternateNameSynchronization alternateNameSynchronizationObj = IndexAlternateNameSynchronizationFactory.newInstance();

    alternateNameSynchronizationObj.insert(details);
  }

  // END, CR00078922, CC

  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    return new Date();
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    return new Date();
  }

  // END, CR002204022

  // BEGIN, CR00346296, PMD
  @Override
  protected void postpdcInsert(AlternateNameDtls details) 
    throws AppException, InformationalException {

    // Synchronize the indexed staging database with the update to alternate
    // name entity
    curam.core.intf.IndexAlternateNameSynchronization alternateNameSynchronizationObj = IndexAlternateNameSynchronizationFactory.newInstance();

    alternateNameSynchronizationObj.insert(details);    
  }

  @Override
  protected void prepdcInsert(AlternateNameDtls details) 
    throws AppException, InformationalException {

    // Convert alternate name details to upper case
    convertDetailsToUpper(details);
    // Encode alternate name surname
    phoneticEncodeSurname(details);
  }

  @Override
  protected void prepdcModify(AlternateNameKey key, AlternateNameDtls details)
    throws AppException, InformationalException {

    // Convert alternate name details to upper case
    convertDetailsToUpper(details);
    phoneticEncodeSurname(details);
  }
  // END, CR00346296
}
