/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.CaseGroupCaseIDMemberEndDateKey;
import curam.core.struct.CaseGroupsDtls;
import curam.core.struct.CaseGroupsKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Implements Case Groups.
 *
 */
public abstract class CaseGroups extends curam.core.base.CaseGroups {

  // ___________________________________________________________________________
  /**
   * This method to set modify details.
   *
   * @param key the case client group ID
   * @param details the case group details being modified.
   *
   */
  protected void premodifyCaseGroupEndDate(
    CaseGroupsKey key,
    CaseGroupsDtls details)
    throws AppException, InformationalException {

    // set the end date to current date.
    details.endDate = curam.util.type.Date.getCurrentDate();
  }

  // ___________________________________________________________________________
  /**
   * This method locates Cases by CaseID only.
   *
   * @param key the case ID, concern role Id and end date
   *
   */
  protected void presearchExistingGroupCaseMember(
    CaseGroupCaseIDMemberEndDateKey key)
    throws AppException, InformationalException {

    // set the end date to current date.
    key.endDate = curam.util.type.Date.getCurrentDate();
  }

}
