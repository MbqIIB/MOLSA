/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.CreateWriteOffInstructionResult;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.FinancialInstructionStatusDtls;
import curam.core.struct.WriteOffInstructionDetails;
import curam.core.struct.WriteOffInstructionDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code for creating a write-off instruction.
 *
 */
public abstract class CreateWriteOff extends curam.core.base.CreateWriteOff {

  // ___________________________________________________________________________
  /**
   * To create a write-off instruction and its associated financial instruction
   * and financial instruction status records.
   *
   * @param writeOffInstructionDetails Write-off instruction details
   *
   * @return Created write-off instruction's identifiers
   */
  public CreateWriteOffInstructionResult createWriteOffInstruction(
    WriteOffInstructionDetails writeOffInstructionDetails)
    throws AppException, InformationalException {

    CreateWriteOffInstructionResult createWriteOffInstructionResult =
      new CreateWriteOffInstructionResult();

    // financialInstruction manipulation variables
    FinancialInstructionDtls financialInstructionDtls =
      new FinancialInstructionDtls();
    curam.core.intf.FinancialInstruction financialInstructionObj =
      curam.core.fact.FinancialInstructionFactory.newInstance();
    long financialInstructionID = 0;

    // writeOff manipulation variables
    WriteOffInstructionDtls writeOffInstructionDtls =
      new WriteOffInstructionDtls();
    curam.core.intf.WriteOffInstruction writeOffInstructionObj =
      curam.core.fact.WriteOffInstructionFactory.newInstance();
    long writeOffInstructionID = 0;

    // financialInstruction manipulation variables
    FinancialInstructionStatusDtls financialInstructionStatusDtls =
      new FinancialInstructionStatusDtls();
    curam.core.intf.FinancialInstructionStatus financialInstructionStatusObj =
      curam.core.fact.FinancialInstructionStatusFactory.newInstance();

    // uniqueID manipulation variable
    curam.core.intf.UniqueID uniqueIDObj =
      curam.core.fact.UniqueIDFactory.newInstance();

    // Generate unique identifiers
    writeOffInstructionID = uniqueIDObj.getNextID();

    financialInstructionID = uniqueIDObj.getNextID();

    // Financial instruction details
    financialInstructionDtls.finInstructionID = financialInstructionID;
    financialInstructionDtls.typeCode =
      curam.codetable.FINANCIALINSTRUCTION.WRITEOFF;
    financialInstructionDtls.concernRoleID =
      writeOffInstructionDetails.concernRoleID;
    financialInstructionDtls.statusCode =
      curam.codetable.FININSTRUCTIONSTATUS.DEFAULTCODE;
    financialInstructionDtls.amount = writeOffInstructionDetails.amount;
    financialInstructionDtls.effectiveDate =
      writeOffInstructionDetails.effectiveDate;
    financialInstructionDtls.postingDate =
      curam.util.type.Date.getCurrentDate();
    financialInstructionDtls.creditDebitType =
      curam.codetable.CREDITDEBIT.CREDIT;
    financialInstructionDtls.currencyTypeCode =
      writeOffInstructionDetails.currencyTypeCode;
    financialInstructionDtls.currencyExchangeID =
      writeOffInstructionDetails.currencyExchangeID;
    financialInstructionDtls.instrumentGenInd =
      writeOffInstructionDetails.instrumentGenInd;
    financialInstructionDtls.comments = writeOffInstructionDetails.comments;

    // insert financialInstruction record
    financialInstructionObj.insert(financialInstructionDtls);

    // reversal Instruction details
    writeOffInstructionDtls.assign(writeOffInstructionDetails);

    writeOffInstructionDtls.wrOffInstructionID = writeOffInstructionID;
    writeOffInstructionDtls.finInstructionID = financialInstructionID;
    writeOffInstructionDtls.typeCode =
      curam.codetable.WRITEOFFINSTRUCTION.DEFAULTCODE;
    writeOffInstructionDtls.creationDate =
      curam.util.transaction.TransactionInfo.getSystemDate();

    // insert writeOffInstruction record
    writeOffInstructionObj.insert(writeOffInstructionDtls);

    financialInstructionStatusDtls.finInstructionStatusID =
      uniqueIDObj.getNextID();
    financialInstructionStatusDtls.finInstructionID = financialInstructionID;
    financialInstructionStatusDtls.statusCode =
      curam.codetable.FININSTRUCTIONSTATUS.DEFAULTCODE;
    financialInstructionStatusDtls.statusDate =
      curam.util.transaction.TransactionInfo.getSystemDate();

    // insert financialInstructionStatus record
    financialInstructionStatusObj.insert(financialInstructionStatusDtls);

    // map output parameters
    createWriteOffInstructionResult.writeOffInstructionDetails.assign(
      writeOffInstructionDtls);

    createWriteOffInstructionResult.financialInstructionDetails.assign(
      financialInstructionDtls);

    return createWriteOffInstructionResult;
  }

}
