/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASETYPECODE;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.MaintainContractAssistantFactory;
import curam.core.intf.CachedCaseHeader;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseParticipantRole_eoCaseIDKey;
import curam.core.sl.entity.struct.ReadActiveICClientDtlsList;
import curam.core.sl.fact.BookmarkFactory;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.SpecialCautionFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.intf.Bookmark;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.SpecialCaution;
import curam.core.sl.struct.ActiveSpecialCautionDisplayIndicator;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.CountCaseBookmarkKey;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.SpecialCautionConcernKey;
import curam.core.struct.CaseAndConcernSummaryDtlsList;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CasesByCaseIDAndTypeKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.Count;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.GetFurtherDetailsResult;
import curam.core.struct.GetIntegCaseTabDetailsResult;
import curam.core.struct.GetIntegratedCaseDetailsResult;
import curam.core.struct.ICAssessmentDeliveryDtls;
import curam.core.struct.ICEventDetails;
import curam.core.struct.ICProductDeliveryDtls;
import curam.core.struct.ICTabDetails;
import curam.core.struct.IntegratedCaseHomeKey;
import curam.core.struct.ModifyICFurtherDtls;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ReadBasicContactDetailsKey;
import curam.core.struct.ReadBasicContactDetailsResult;
import curam.core.struct.ViewCaseEventDetailsList;
import curam.core.struct.ViewCaseEventsByCaseIDAndTypeKey;
import curam.message.BPOCASEEVENTS;
import curam.message.BPOINTEGRATEDCASEHOME;
import curam.message.GENERALCASE;
import curam.message.GENERALCONCERN;
import curam.serviceplans.sl.entity.fact.OutcomeFactory;
import curam.serviceplans.sl.entity.intf.Outcome;
import curam.serviceplans.sl.entity.struct.OutcomeKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTableItemIdentifier;


/**
 * Code for populating the integrated case home page with the case details
 * IntegratedCaseHome for Curam
 */
public abstract class IntegratedCaseHome extends curam.core.base.IntegratedCaseHome {

  // constants for quicker string buffer manipulations
  public static final int kSpaceLength = CuramConst.gkSpace.length();

  public static final int kMaxLongStringLength = Math.max(
    String.valueOf(Long.MAX_VALUE).length(),
    String.valueOf(Long.MIN_VALUE).length());

  // BEGIN CR00108134, GBA
  // Add injection for using the new CaseTransactionLog API
  public IntegratedCaseHome() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END CR00108134

  /**
   * Takes in a caseID and returns the Integrated Case Details for the home
   * page.
   *
   * @param key
   * Integrated Case Home Key
   *
   * @return getIntegratedCaseDetailsResult Contains case header details, a list
   * of tasks on the case, a list of product deliveries and a list of
   * case events.
   */
  public GetIntegratedCaseDetailsResult getIntegratedCaseDetails(
    IntegratedCaseHomeKey key) throws AppException, InformationalException {

    // The results
    GetIntegratedCaseDetailsResult getIntegratedCaseDetailsResult = new GetIntegratedCaseDetailsResult();

    // Case header entity and details
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // MaintainCase manipulation variables
    curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();
    CaseAndConcernSummaryDtlsList caseAndConcernSummaryDtlsList;
    CasesByCaseIDAndTypeKey casesByCaseIDAndTypeKey = new CasesByCaseIDAndTypeKey();

    // View activity entity and details
    curam.core.intf.ViewCaseEvents viewCaseEventsObj = curam.core.fact.ViewCaseEventsFactory.newInstance();
    ViewCaseEventsByCaseIDAndTypeKey viewCaseEventsByCaseIDAndTypeKey = new ViewCaseEventsByCaseIDAndTypeKey();
    ViewCaseEventDetailsList viewCaseEventDetailsList;

    // Concern role entity and details
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // Product delivery entity and details
    curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
    ProductDeliveryDtls productDeliveryDtls;
    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    // BEGIN, CR00060051, PMD
    // CaseUserRole manipulation variables
    CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();
    // END, CR00060051

    // elements of the ICProductDeliveriesList
    ICProductDeliveryDtls icProductDeliveryDtls;

    // elements of the ICAssessmentDeliveriesList
    ICAssessmentDeliveryDtls icAssessmentDeliveryDtls;

    // elements of ICEvents list
    ICEventDetails icEventDetails;

    caseHeaderKey.caseID = key.caseID;

    // Read case header
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    getIntegratedCaseDetailsResult.integratedCaseHeaderDtls.assign(
      caseHeaderDtls);

    // BEGIN, CR00060051, PMD

    // Read the case owner
    CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(caseHeaderKey);

    // If the owner type is a user, display the user full name.
    // If the owner type is not of type user, display the organization
    // object reference name (this will be either an organization unit name,
    // a position name or a work queue name)
    if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.USER)) {
      getIntegratedCaseDetailsResult.integratedCaseHeaderDtls.ownerName = caseOwnerDetails.userFullName;
    } else {
      getIntegratedCaseDetailsResult.integratedCaseHeaderDtls.ownerName = caseOwnerDetails.orgObjectReferenceName;
    }
    // END, CR00060051

    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // Read concern role
    concernRoleDtls = concernRoleObj.read(concernRoleKey);
    
    // BEGIN, CR00226619, PM
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    // perform concern role sensitivity check
    participantSecurityCheckKey.participantID = caseHeaderDtls.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
      participantSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCONCERN.ERR_CONCERNROLE_FV_SENSITIVE);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00226619
    
    getIntegratedCaseDetailsResult.integratedCaseHeaderDtls.concernRoleName = concernRoleDtls.concernRoleName;

    // list all product deliveries
    casesByCaseIDAndTypeKey.dtls.caseID = key.caseID;
    casesByCaseIDAndTypeKey.dtls.caseTypeCode = CASETYPECODE.PRODUCTDELIVERY;

    caseAndConcernSummaryDtlsList = maintainCaseObj.listCasesByTypeAndParentCaseID(
      casesByCaseIDAndTypeKey);

    getIntegratedCaseDetailsResult.icProductDeliveriesList.dtls.ensureCapacity(
      caseAndConcernSummaryDtlsList.list.dtls.size());

    for (int k = 0; k < caseAndConcernSummaryDtlsList.list.dtls.size(); k++) {

      icProductDeliveryDtls = new ICProductDeliveryDtls();
      icProductDeliveryDtls.assign(
        caseAndConcernSummaryDtlsList.list.dtls.item(k));

      productDeliveryKey.caseID = caseAndConcernSummaryDtlsList.list.dtls.item(k).caseID;

      // read product delivery
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

      icProductDeliveryDtls.productID = productDeliveryDtls.productID;

      getIntegratedCaseDetailsResult.icProductDeliveriesList.dtls.addRef(
        icProductDeliveryDtls);
    }

    // list all assessment deliveries
    casesByCaseIDAndTypeKey.dtls.caseID = key.caseID;
    casesByCaseIDAndTypeKey.dtls.caseTypeCode = CASETYPECODE.ASSESSMENTDELIVERY;

    caseAndConcernSummaryDtlsList = maintainCaseObj.listCasesByTypeAndParentCaseID(
      casesByCaseIDAndTypeKey);

    getIntegratedCaseDetailsResult.icProductDeliveriesList.dtls.ensureCapacity(
      caseAndConcernSummaryDtlsList.list.dtls.size());

    for (int k = 0; k < caseAndConcernSummaryDtlsList.list.dtls.size(); k++) {

      icAssessmentDeliveryDtls = new ICAssessmentDeliveryDtls();
      icAssessmentDeliveryDtls.assign(
        caseAndConcernSummaryDtlsList.list.dtls.item(k));

      getIntegratedCaseDetailsResult.icAssessmentDeliveriesList.dtls.addRef(
        icAssessmentDeliveryDtls);
    }

    // Get all the events for the integrated case
    viewCaseEventsByCaseIDAndTypeKey.caseID = key.caseID;

    viewCaseEventDetailsList = viewCaseEventsObj.readEventsForIntegCases(
      viewCaseEventsByCaseIDAndTypeKey);

    getIntegratedCaseDetailsResult.icEventDetailsList.dtls.ensureCapacity(
      viewCaseEventDetailsList.dtls.size());

    StringBuffer tmp = new StringBuffer();

    for (int i = 0; i < viewCaseEventDetailsList.dtls.size(); i++) {

      if (viewCaseEventDetailsList.dtls.item(i).endDateTime.isZero()) {

        viewCaseEventDetailsList.dtls.item(i).endDateTime = viewCaseEventDetailsList.dtls.item(i).startDateTime;

      }

      String caseString = curam.message.BPOINTEGRATEDCASEHOME.INF_CASEHEADER_CASETITLE// BEGIN, CR00163471, JC
        .getMessageText(
        TransactionInfo.getProgramLocale());

      // END, CR00163471, JC

      tmp.setLength(0); // empties the buffer.

      tmp.ensureCapacity(
        viewCaseEventDetailsList.dtls.item(i).subject.length() + kSpaceLength
        + caseString.length() + kSpaceLength + kMaxLongStringLength);

      // Add caseID to the subject text
      tmp.append(viewCaseEventDetailsList.dtls.item(i).subject).append(CuramConst.gkSpace).append(caseString).append(CuramConst.gkSpace).append(
        viewCaseEventDetailsList.dtls.item(i).caseID);

      icEventDetails = new ICEventDetails();

      viewCaseEventDetailsList.dtls.item(i).subject = tmp.toString();

      icEventDetails.assign(viewCaseEventDetailsList.dtls.item(i));

      getIntegratedCaseDetailsResult.icEventDetailsList.dtls.addRef(
        icEventDetails);

    }

    return getIntegratedCaseDetailsResult;
  }

  /**
   * Returns the further details for the Integrated Case from the case header
   *
   *
   * @param key
   * Integrated Case Home Key
   *
   * @return GetFurtherDetailsResult further details
   */
  public GetFurtherDetailsResult getFurtherDetails(IntegratedCaseHomeKey key)
    throws AppException, InformationalException {

    // The results.
    GetFurtherDetailsResult getFurtherDetailsResult = new GetFurtherDetailsResult();

    // Variables to read case header details
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // Variables to read concern role details
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    curam.core.intf.MaintainContractAssistant maintainContractAssistantObj = MaintainContractAssistantFactory.newInstance();

    // Variables for readBasicContactDetails method
    ReadBasicContactDetailsKey readBasicContactDetailsKey = new ReadBasicContactDetailsKey();
    ReadBasicContactDetailsResult readBasicContactDetailsResult;

    // BEGIN, CR00060051, PMD
    // CaseUserRole manipulation variables
    curam.core.sl.intf.CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    // END, CR00060051

    // BEGIN, CR00092078, SPD
    // Bookmark manipulation variables
    Bookmark bookmarkObj = BookmarkFactory.newInstance();
    CountCaseBookmarkKey countCaseBookmarkKey = new CountCaseBookmarkKey();

    // END, CR00092078

    // Call a caseHeader entity read using the input key.caseID as the key
    caseHeaderKey.caseID = key.caseID;

    // Read the case header
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Assign the resulting caseHeader Dtls to the corresponding fields of the
    // output dtls struct
    getFurtherDetailsResult.integratedCaseFurtherDtls.assign(caseHeaderDtls);

    // Outcome entity and key
    Outcome outcomeObj = OutcomeFactory.newInstance();
    OutcomeKey outcomeKey = new OutcomeKey();

    // set outcome key
    if (caseHeaderDtls.expectedOutcome != 0) {
      outcomeKey.outcomeID = caseHeaderDtls.expectedOutcome;

      getFurtherDetailsResult.integratedCaseFurtherDtls.outcomeName = outcomeObj.readName(outcomeKey).name;
    }

    // BEGIN, CR00060051, PMD
    // Read the case owner
    CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(caseHeaderKey);

    // END, CR00060051

    // BEGIN, CR00066677, CM
    // Set the case owner details
    getFurtherDetailsResult.integratedCaseFurtherDtls.caseOwnerName = caseOwnerDetails.orgObjectReferenceName;
    getFurtherDetailsResult.integratedCaseFurtherDtls.caseOwnerType = caseOwnerDetails.orgObjectType;
    getFurtherDetailsResult.integratedCaseFurtherDtls.orgObjectReference = caseOwnerDetails.orgObjectReference;
    getFurtherDetailsResult.integratedCaseFurtherDtls.userName = caseOwnerDetails.userName;

    // if the type is a user, display the user full name
    if (caseOwnerDetails.orgObjectType.equals(ORGOBJECTTYPE.USER)) {

      // Set orgObjectReferenceName
      getFurtherDetailsResult.integratedCaseFurtherDtls.caseOwnerName = caseOwnerDetails.userFullName;
    }
    // END, CR00066677

    getFurtherDetailsResult.integratedCaseFurtherDtls.receiptDate = caseHeaderDtls.receivedDate;

    // Perform a ConcernRole entity read
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // Read the concern role
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    getFurtherDetailsResult.integratedCaseFurtherDtls.primaryClient = concernRoleDtls.concernRoleName;

    // Get the basic contact details
    readBasicContactDetailsKey.concernRoleID = caseHeaderDtls.concernRoleID;
    readBasicContactDetailsKey.primaryAddressID = concernRoleDtls.primaryAddressID;
    readBasicContactDetailsKey.primaryPhoneNumberID = concernRoleDtls.primaryPhoneNumberID;
    // BEGIN, CR00272990, KRK
    readBasicContactDetailsResult = maintainContractAssistantObj.readBasicContactDetailsForIC(
      readBasicContactDetailsKey);
    // END, CR00272990 

    getFurtherDetailsResult.primaryClientContactDtls.assign(
      readBasicContactDetailsResult.basicContactDetails);

    // BEGIN, CR00092078, SPD
    // populate key
    // BEGIN, CR00093024, SPD
    countCaseBookmarkKey.dtls.userName = TransactionInfo.getProgramUser();
    // END, CR00093024
    countCaseBookmarkKey.dtls.caseID = key.caseID;

    // return number of case bookmarks for the current user
    Count count = bookmarkObj.countCaseBookmark(countCaseBookmarkKey);

    // check if a case bookmark record exists, the default is false
    if (count.numberOfRecords > 0) {

      getFurtherDetailsResult.caseIsUserBookmarkInd = true;
    }
    // END, CR00092078

    // BEGIN, CR00115696, PA
    // Instance of special caution service layer object
    SpecialCaution specialCautionObj = SpecialCautionFactory.newInstance();

    SpecialCautionConcernKey specialCautionConcernKey = new SpecialCautionConcernKey();
    ActiveSpecialCautionDisplayIndicator activeSpecialCautionDisplayIndicator = new ActiveSpecialCautionDisplayIndicator();

    // assigning concern role id to SpecialCautionConcernKey struct
    specialCautionConcernKey.concernRoleID = caseHeaderDtls.concernRoleID;
    // invoking displayActiveSpecialCautionIndicator() method on special caution
    // object
    activeSpecialCautionDisplayIndicator = specialCautionObj.displayActiveSpecialCautionIndicator(
      specialCautionConcernKey);
    // assigning special caution indicator value to ReadPersonResult struct
    getFurtherDetailsResult.specialCautionIndicator = activeSpecialCautionDisplayIndicator.displayIndicator;
    // END, CR00115696, PA

    return getFurtherDetailsResult;
  }

  /**
   * This method allows the Integrated Case Home Page and Further Details Page
   * data to be updated.
   *
   * @param dtls
   * Modified Integrated Case Further Details.
   */
  public void modifyIntegratedCaseDetails(ModifyICFurtherDtls dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00103023, CW
    // Variables to read case header details
    CachedCaseHeader cachedCaseHeader = CachedCaseHeaderFactory.newInstance();
    // END, CR00103023
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // based on domain CURAM_DATE
    curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // Perform all the relevant date validations on the input dtls struct
    if (dtls.registrationDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(curam.message.GENERALCASE.ERR_CASE_REGISTRATION_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    if (!dtls.expectedEndDate.isZero()) {

      if (dtls.expectedEndDate.before(dtls.registrationDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOINTEGRATEDCASEHOME.ERR_CASEHEADER_XFV_END_DATE_AFTER_REGDATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      if (dtls.expectedEndDate.before(dtls.receiptDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOINTEGRATEDCASEHOME.ERR_CASEHEADER_XFV_END_DATE_AFTER_RECEIPTDATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    }

    if (dtls.registrationDate.before(dtls.receiptDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERALCASE.ERR_CASEHEADER_XFV_RECEIPTDATE_LARGE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (dtls.registrationDate.after(currentDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERALCASE.ERR_CASEHEADER_XFV_REGDATE_LARGE),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (dtls.outcomeCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERALCASE.ERR_CASE_OUTCOME_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (dtls.objectiveCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERALCASE.ERR_CASE_OBJECTIVE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (dtls.priorityCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERALCASE.ERR_CASE_PRIORITY_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Call a caseHeader entity read using the input key.caseID as the key
    caseHeaderKey.caseID = dtls.caseID;

    // BEGIN, CR00103023, CW
    // Read the case header
    caseHeaderDtls = cachedCaseHeader.read(caseHeaderKey);
    // END, CR00103023

    // Assign the relevant input dtls values to the corresponding fields of
    // the caseHeaderDtls struct
    caseHeaderDtls.assign(dtls);

    caseHeaderDtls.receivedDate = dtls.receiptDate;

    // BEGIN, CR00103023, CW
    // Modify the caseHeader entity
    cachedCaseHeader.modify(caseHeaderKey, caseHeaderDtls);
    // END, CR00103023

    // BEGIN, CR00057457, AK
    // Log Transaction Details
    if (dtls != null && dtls.caseID != 0) {

      // BEGIN CR00108134, GBA
      CodeTableItemIdentifier caseTypeCodeTableItemIdentifier = new CodeTableItemIdentifier(
        CASETYPECODE.TABLENAME, caseHeaderDtls.caseTypeCode);

      LocalisableString description = new LocalisableString(BPOCASEEVENTS.HEADER_MODIFIED).arg(caseTypeCodeTableItemIdentifier).arg(
        caseHeaderDtls.caseReference);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.CASEHEADER_MODIFY, description, dtls.caseID,
        CuramConst.kDefaultRelatedID);
      // END CR00108134
    }
    // END, CR00057457
  }

  /**
   * Readmulti used to get the details and id's for the tabs for each integrated
   * case
   *
   * @param key
   * Integrated Case Home Key
   *
   * @return getIntegCaseTabDetailResult - IC Tab Details
   */
  public GetIntegCaseTabDetailsResult getIntegCaseTabDetails(
    IntegratedCaseHomeKey key) throws AppException, InformationalException {

    // The results
    GetIntegCaseTabDetailsResult getIntegCaseTabDetailsResult = new GetIntegCaseTabDetailsResult();

    // TabDetails struct
    ICTabDetails icTabDetails;

    // Case Participant Role manipulation variables
    CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();
    ReadActiveICClientDtlsList readActiveICClientDtlsList;
    CaseParticipantRole_eoCaseIDKey caseParticipantRoleCaseIDKey = new CaseParticipantRole_eoCaseIDKey();

    // Case Header variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // Concern Role variables
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    icTabDetails = new ICTabDetails();

    icTabDetails.tabID = key.caseID;

    String tabName = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_CASEHOMEFIRSTTABNAME);

    if (tabName == null) {
      tabName = EnvVars.ENV_CASEHOMEFIRSTTABNAME_DEFAULT;
    }

    icTabDetails.tabName = tabName;

    // there is always at least 2 tab details
    getIntegCaseTabDetailsResult.icTabDetailsList.dtls.ensureCapacity(2);

    // Setting the first tab details to contain the caseID and the name Home.
    getIntegCaseTabDetailsResult.icTabDetailsList.dtls.addRef(icTabDetails);

    caseHeaderKey.caseID = key.caseID;

    // Reading the caseHeader details to get the primary clients concernRoleID
    caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Setting the key for the concernRole Read
    concernRoleKey.concernRoleID = caseHeaderDtls.concernRoleID;

    // Reading the concernRole details
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    getIntegCaseTabDetailsResult.integratedCaseHeaderDtls.assign(caseHeaderDtls);
    getIntegCaseTabDetailsResult.integratedCaseHeaderDtls.concernRoleName = concernRoleDtls.concernRoleName;

    icTabDetails = new ICTabDetails();

    // Setting the name and id to appear for the second tab
    icTabDetails.tabID = caseHeaderDtls.concernRoleID;
    icTabDetails.tabName = concernRoleDtls.concernRoleName;

    // Setting the primary client's name and id to appear on the second tab
    getIntegCaseTabDetailsResult.icTabDetailsList.dtls.addRef(icTabDetails);

    caseParticipantRoleCaseIDKey.caseID = key.caseID;

    // Reading all the active clients for an Integrated Case
    readActiveICClientDtlsList = caseParticipantRoleObj.readActiveICCaseParticipantRole(
      caseParticipantRoleCaseIDKey);

    // For each active client returned in the list the concernRoleID and
    // concernRoleName is mapped into the tabDetailsList to appear on the tabs
    for (int i = 0; i < readActiveICClientDtlsList.dtls.size(); i++) {

      // To eliminate the primary client's name from appearing twice.
      if (readActiveICClientDtlsList.dtls.item(i).dtls.participantRoleID
        != caseHeaderDtls.concernRoleID) {

        icTabDetails = new ICTabDetails();

        icTabDetails.tabID = readActiveICClientDtlsList.dtls.item(i).dtls.participantRoleID;
        icTabDetails.tabName = readActiveICClientDtlsList.dtls.item(i).dtls.name;

        getIntegCaseTabDetailsResult.icTabDetailsList.dtls.addRef(icTabDetails);

      }

    }

    return getIntegCaseTabDetailsResult;
  }

}
