/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2002, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;

import curam.codetable.CURRENCY;
import curam.codetable.METHODOFDELIVERY;
import curam.codetable.RECORDSTATUS;
import curam.core.sl.event.impl.PaymentInstrumentEvent;
import curam.core.sl.fact.ClientInteractionFactory;
import curam.core.fact.ControlChequeNumberFactory;
import curam.core.fact.ControlLedgerNumberFactory;
import curam.core.fact.ControlVoucherNumberFactory;
import curam.core.fact.CurrencyExchangeFactory;
import curam.core.fact.PaymentInstrumentFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.CurrencyExchange;
import curam.core.intf.PaymentInstrument;
import curam.core.sl.intf.ClientInteraction;
import curam.core.sl.struct.ClientInteractionDetails;
import curam.core.struct.CreatePaymentInstructionResult;
import curam.core.struct.CurrencyExchangeDateTypeStructRef;
import curam.core.struct.CurrencyExchangeIDDetails;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.FinancialInstructionStatusDtls;
import curam.core.struct.PaymentInstructionDtls;
import curam.core.struct.PaymentInstrumentDtls;
import curam.core.struct.PmtInstructionDetails;
import curam.core.struct.PmtInstrumentDetails;
import curam.message.GENERALADMIN;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * Code for creating a payments plan.
 *
 */
public abstract class CreatePayments extends curam.core.base.CreatePayments {

  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by
   * {@link curam.message.BPOCREATEPAYMENTS.INF_PAYMENT.getMessageText(TransactionInfo.getProgramLocale())}.
   * Replacement reason - static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note <CR00219408>.
   */
  @Deprecated
  protected static final String kInteractionDescription = // BEGIN, CR00163471, JC
    curam.message.BPOCREATEPAYMENTS.INF_PAYMENT.getMessageText();
  // END, CR00163471, JC
  // END, CR00222190

  // BEGIN, CR00207419, RK
  @Inject
  protected EventDispatcherFactory<PaymentInstrumentEvent> paymentInstrumentEventsDispatcher;

  // BEGIN, CR00372433, SG
  @Inject
  protected FinancialManagerHooks financialManagerHooks;
  // END, CR00372433
  
  /**
   * Constructor for the class to allow Guice injection.
   */
  public CreatePayments() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00207419

  // ___________________________________________________________________________
  /**
   * Create a payment instrument record.
   *
   * @param pmtInstrumentDtls input payment instrument details
   *
   * @return payment instrument details inserted
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public PaymentInstrumentDtls createPmtInstrument(PmtInstrumentDetails
    pmtInstrumentDtls) throws AppException, InformationalException {

    // PaymentInstrument details
    PaymentInstrumentDtls paymentInstrumentDtls = new PaymentInstrumentDtls();
    
    // Set paymentInstrument details
    paymentInstrumentDtls.amount = pmtInstrumentDtls.pmtAmount;
    
    // BEGIN, CR00372433, SG
    paymentInstrumentDtls.effectiveDate = financialManagerHooks.setPaymentInstrumentEffectiveDate(pmtInstrumentDtls).date;
    // END, CR00372433

    paymentInstrumentDtls.deliveryMethodType = pmtInstrumentDtls.deliveryMethodType;
    paymentInstrumentDtls.concernRoleID = pmtInstrumentDtls.concernRoleID;
    paymentInstrumentDtls.concernRoleName = pmtInstrumentDtls.concernRoleName;
    paymentInstrumentDtls.caseNomineeID = pmtInstrumentDtls.caseNomineeID;
    paymentInstrumentDtls.nomineeName = pmtInstrumentDtls.nomineeName;
    paymentInstrumentDtls.nomineeAlternateID = pmtInstrumentDtls.nomineeAlternateID;
    paymentInstrumentDtls.addressID = pmtInstrumentDtls.addressID;
    paymentInstrumentDtls.reconcilStatusCode = curam.codetable.PMTRECONCILIATIONSTATUS.DEFAULTCODE;
    paymentInstrumentDtls.currencyTypeCode = pmtInstrumentDtls.currencyTypeCode;
    paymentInstrumentDtls.currencyExchangeID = pmtInstrumentDtls.currencyExchangeID;
    // BEGIN, CR00003380, SD
    paymentInstrumentDtls.invalidatedInd = false;
    // END, CR00003380

    paymentInstrumentDtls.pslipInstructionID = pmtInstrumentDtls.pslipInstructionID;

    // Read the 'GenerateInstrumentRefNo' parameter from ApplicationParameter
    // file
    String genInstrumentRefNo = Configuration.getProperty(
      EnvVars.ENV_GENINSTRUMENTREFNO);

    if (genInstrumentRefNo == null) {

      genInstrumentRefNo = EnvVars.ENV_GENINSTRUMENTREFNO_DEFAULT;
    }

    if (pmtInstrumentDtls.deliveryMethodType.equals(METHODOFDELIVERY.EFT)) {
      
      // BEGIN, CR00163471, JC
      paymentInstrumentDtls.referenceText = curam.message.BPOCREATEPAYMENTS.INF_EFT_PAYMENTS.getMessageText(
        TransactionInfo.getProgramLocale());
      // END, CR00163471, JC

      paymentInstrumentDtls.bankAccountID = pmtInstrumentDtls.bankAccountID;

    } else {

      if (pmtInstrumentDtls.deliveryMethodType.equals(METHODOFDELIVERY.CASH)) {

        if (genInstrumentRefNo.equalsIgnoreCase(EnvVars.ENV_VALUE_YES) // END, HARP 58911
          && !pmtInstrumentDtls.manualPaymentInd) {
          ControlLedgerNumberFactory.newInstance().getNextLedgerNumber();
        }

        paymentInstrumentDtls.referenceNumber = pmtInstrumentDtls.ledgerNo;

      } else {

        if (pmtInstrumentDtls.deliveryMethodType.equals(METHODOFDELIVERY.CHEQUE)) {

          if (genInstrumentRefNo.equalsIgnoreCase(EnvVars.ENV_VALUE_YES) // END, HARP 58911
            && !pmtInstrumentDtls.manualPaymentInd) {

            ControlChequeNumberFactory.newInstance().getNextChequeNumber();

          } else {

            paymentInstrumentDtls.referenceNumber = pmtInstrumentDtls.chequeNo;
          }

        } else {

          if (pmtInstrumentDtls.deliveryMethodType.equals(
            METHODOFDELIVERY.VOUCHER)) {

            if (genInstrumentRefNo.equalsIgnoreCase(EnvVars.ENV_VALUE_YES) // END, HARP 58911
              && !pmtInstrumentDtls.manualPaymentInd) {

              ControlVoucherNumberFactory.newInstance().getNextVoucherNumber();

            } else {

              paymentInstrumentDtls.referenceNumber = pmtInstrumentDtls.voucherNo;
            }

          }

        }

      }
    }

    // PaymentInstrument identifier
    long paymentInstrumentID = 0;

    // Assign unique ID
    paymentInstrumentID = UniqueIDFactory.newInstance().getNextID();

    paymentInstrumentDtls.pmtInstrumentID = paymentInstrumentID;
    paymentInstrumentDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();
    // BEGIN, CR00096630,GM
    // BEGIN, HARP 75628, GSP
    // Check if the currency exchange id is the
    // appropriate one in accordance with the effective date of the
    // paymentInstrumentDtls. So do a read on the CURRENCYEXCHANGE table to
    // find the appropriate currency exchange id for the effective
    // date and the corresponding currency type

    CurrencyExchangeDateTypeStructRef currencyExchangeDateTypeStructRefObj = new curam.core.struct.CurrencyExchangeDateTypeStructRef();

    currencyExchangeDateTypeStructRefObj.currencyTypeCode = paymentInstrumentDtls.currencyTypeCode;
    currencyExchangeDateTypeStructRefObj.statusCode = RECORDSTATUS.NORMAL;
    currencyExchangeDateTypeStructRefObj.theDate = paymentInstrumentDtls.effectiveDate;

    boolean isExchRateConfigured = true;

    try {
      // BEGIN, CR00279098, KRK
      CurrencyExchange currencyExchangeobj = CurrencyExchangeFactory.newInstance();   
      CurrencyExchangeIDDetails currencyExchangeIDDetails = currencyExchangeobj.readCurrencyExchangeIDByDateType(
        currencyExchangeDateTypeStructRefObj);

      paymentInstrumentDtls.currencyExchangeID = currencyExchangeIDDetails.currencyExchangeID;
      // END, CR00279098
    } catch (RecordNotFoundException e) {
      isExchRateConfigured = false;
    } finally {
      
      // BEGIN, CR00279098, KRK
      PaymentInstrument paymentInstrumentObj = PaymentInstrumentFactory.newInstance();

      // END, CR00279098
      
      // BEGIN,  CR00281699, AC
      if (isExchRateConfigured
        || Configuration.getProperty(EnvVars.ENV_BASECURRENCY).equals(
          paymentInstrumentDtls.currencyTypeCode)) {
            
        paymentInstrumentObj.insert(paymentInstrumentDtls);
            
        paymentInstrumentEventsDispatcher.get(PaymentInstrumentEvent.class).paymentIssued(
          paymentInstrumentDtls);
        // END,  CR00281699
      
        // BEGIN, CR00339627, CSH  
      } else {
        
        final AppException ae = new AppException(
          GENERALADMIN.ERR_CURRENCYEXCHANGE_RNFE_DATE_TYPE);

        ae.arg(currencyExchangeDateTypeStructRefObj.theDate);
        ae.arg(
          CodeTable.getOneItem(CURRENCY.TABLENAME,
          currencyExchangeDateTypeStructRefObj.currencyTypeCode, 
          TransactionInfo.getProgramLocale().toString()));

        throw ae;
      }
      // END, CR00339627
    }
    
    // END, CR00278597
    // END, HARP 75628
    // END,CR00096630


    return paymentInstrumentDtls;
  }

  // ___________________________________________________________________________
  /**
   * Create a payment instruction record.
   *
   * @param pmtInstructionDtls input payment instruction details
   *
   * @return payment instruction details and financial instruction details
   */
  public CreatePaymentInstructionResult createPmtInstruction(
    PmtInstructionDetails pmtInstructionDtls)
    throws AppException, InformationalException {

    // createPaymentInstructionResult variable
    CreatePaymentInstructionResult createPaymentInstructionResult = new CreatePaymentInstructionResult();

    // paymentInstruction identifier
    long paymentInstructionID = 0;

    // financialInstruction identifier
    long financialInstructionID = 0;

    // financialInstruction manipulation variables
    curam.core.intf.FinancialInstruction financialInstructionObj = curam.core.fact.FinancialInstructionFactory.newInstance();
    FinancialInstructionDtls financialInstructionDtls = new FinancialInstructionDtls();

    // paymentInstruction manipulation variables
    curam.core.intf.PaymentInstruction paymentInstructionObj = curam.core.fact.PaymentInstructionFactory.newInstance();
    PaymentInstructionDtls paymentInstructionDtls = new PaymentInstructionDtls();

    // uniqueID manipulation variables
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // generate uniqueID for paymentInstruction
    paymentInstructionID = uniqueIDObj.getNextID();

    // generate uniqueID for financialInstruction
    financialInstructionID = uniqueIDObj.getNextID();

    // set financialInstruction details for insert
    financialInstructionDtls.finInstructionID = financialInstructionID;

    // typeCode is set to 'Payment' (PMT)
    financialInstructionDtls.typeCode = curam.codetable.FINANCIALINSTRUCTION.PAYMENT;
    financialInstructionDtls.concernRoleID = pmtInstructionDtls.concernRoleID;

    // statusCode is set to 'Created' (CRE)
    financialInstructionDtls.statusCode = curam.codetable.FININSTRUCTIONSTATUS.CREATED;
    financialInstructionDtls.amount = pmtInstructionDtls.amount;
    financialInstructionDtls.effectiveDate = pmtInstructionDtls.effectiveDate;
    // BEGIN, CR00053049 MC
    // BEGIN, HARP 72783, GSP
    financialInstructionDtls.postingDate = curam.util.transaction.TransactionInfo.getSystemDate();
    // END, HARP 72783
    // END, CR00053049

    // creditDebitType is set to 'Debit' (DBT)
    financialInstructionDtls.creditDebitType = curam.codetable.CREDITDEBIT.DEBIT;
    financialInstructionDtls.currencyTypeCode = pmtInstructionDtls.currencyTypeCode;
    financialInstructionDtls.currencyExchangeID = pmtInstructionDtls.currencyExchangeID;
    financialInstructionDtls.instrumentGenInd = pmtInstructionDtls.instrumentGenInd;
    financialInstructionDtls.comments = pmtInstructionDtls.comments;

    // insert financialInstruction
    financialInstructionObj.insert(financialInstructionDtls);

    // set paymentInstruction details
    paymentInstructionDtls.assign(pmtInstructionDtls);

    paymentInstructionDtls.pmtInstrumentID = 0;
    paymentInstructionDtls.pmtInstructionID = paymentInstructionID;
    paymentInstructionDtls.finInstructionID = financialInstructionID;
    // BEGIN, HARO 48658, KH
    paymentInstructionDtls.creationDate = curam.util.transaction.TransactionInfo.getSystemDate();

    // insert paymentInstruction
    paymentInstructionObj.insert(paymentInstructionDtls);

    // financialInstructionStatus identifier
    long finInstructionStatusID = 0;

    // assign unique ID
    finInstructionStatusID = uniqueIDObj.getNextID();

    // financialInstructionStatus manipulation variables
    curam.core.intf.FinancialInstructionStatus financialInstructionStatusObj = curam.core.fact.FinancialInstructionStatusFactory.newInstance();
    FinancialInstructionStatusDtls finInstructionStatusDtls = new FinancialInstructionStatusDtls();

    // set finInstructionStatus details
    finInstructionStatusDtls.finInstructionID = financialInstructionID;

    // statusCode is set to 'Created' (CRE)
    finInstructionStatusDtls.statusCode = curam.codetable.FININSTRUCTIONSTATUS.CREATED;
    finInstructionStatusDtls.statusDate = curam.util.transaction.TransactionInfo.getSystemDate();
    finInstructionStatusDtls.finInstructionStatusID = finInstructionStatusID;

    // insert financialInstructionStatus
    financialInstructionStatusObj.insert(finInstructionStatusDtls);

    // map output parameters
    createPaymentInstructionResult.financialInstructionDetails.assign(
      financialInstructionDtls);

    createPaymentInstructionResult.paymentInstructionDetails.assign(
      paymentInstructionDtls);

    // call into sample interaction center
    // and record the client interaction for this communication
    // BEGIN, CR00192165, VM
    ClientInteractionDetails clientInteractionDtls = new ClientInteractionDetails();
    ClientInteraction clientInteractionObj = ClientInteractionFactory.newInstance();

    clientInteractionDtls.dtls.concernRoleID = paymentInstructionDtls.concernRoleID;
    clientInteractionDtls.dtls.relatedID = paymentInstructionDtls.finInstructionID;
    clientInteractionObj.recordClientInteractionPayment(clientInteractionDtls);
    // END, CR00192165

    return createPaymentInstructionResult;
  }

}
