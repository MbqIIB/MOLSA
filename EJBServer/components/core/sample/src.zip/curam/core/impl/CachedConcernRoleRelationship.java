/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import org.apache.log4j.Logger;

import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.core.struct.ConcernRoleRelationshipDtls;
import curam.core.struct.ConcernRoleRelationshipKey;
import curam.core.struct.ReciprocalRelationshipKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * @see curam.core.intf.CachedConcernRoleRelationship 
 */
public abstract class CachedConcernRoleRelationship extends curam.core.base.CachedConcernRoleRelationship {

  protected static ThreadLocal cachedConcernRoleRelationshipDtls = new ThreadLocal();

  // ___________________________________________________________________________

  // Logger for the caching output
  // BEGIN, CR00023323, SK
  public static final String kBatchCachingCategory = Trace.kDefaultTraceCategory
    + ExtensionConst.kBatchStreamCategory;
  // END, CR00023323
  public static final Logger kBatchLauncherCacheLogger = Logger.getLogger(
    kBatchCachingCategory);

  public static final boolean logging;
  // BEGIN, CR00069782, GSP
  // BEGIN, HARP 71561, MR
  public static int kBufferSize = 1024;
  // END, HARP 71561
  // END, CR00069782
  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;
  // BEGIN CR00052232, GSP
  // static to indicate if online caching is enabled
  public static final boolean onlineCachingEnabled;
  // END CR00052232

  // ___________________________________________________________________________
  static {

    cachingEnabled = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);
    // BEGIN CR00052232, GSP
    onlineCachingEnabled = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_ONLINE_CACHING_ENABLED);
    // END CR00052232

    // get the value of the logging enabled environment variable
    String logging_enabled = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED);

    if (logging_enabled == null) {
      logging_enabled = EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED_DEFAULT;
    }

    if (logging_enabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {

      logging = true;

    } else {
      logging = false;
    }

  }

  // ___________________________________________________________________________
  /*
   * Class to provide comparator and clear operation for
   * ConcernRoleRelationshipDtls
   */
  class ConcernRoleRelationshipDtlsBuffer extends CircularBuffer {

    public ConcernRoleRelationshipDtlsBuffer() {
      super(kBufferSize);
    }

    // Comparator operation
    public boolean itemsEqual(Object o1, Object o2) {

      ConcernRoleRelationshipDtls concernRoleRelationshipDtls1 = (ConcernRoleRelationshipDtls) o1;
      ConcernRoleRelationshipDtls concernRoleRelationshipDtls2 = (ConcernRoleRelationshipDtls) o2;

      return (concernRoleRelationshipDtls1.concernRoleRelationshipID
        == concernRoleRelationshipDtls2.concernRoleRelationshipID);
    }

    // clear operation
    public void clearItem(Object o) {

      ConcernRoleRelationshipDtls concernRoleRelationshipDtls = (ConcernRoleRelationshipDtls) o;

      concernRoleRelationshipDtls.concernRoleRelationshipID = 0;
    }

  }


  // ___________________________________________________________________________
  /**
   * class to hold the cached ConcernRoleRelationshipDtlsCacheRecord
   */
  protected class ConcernRoleRelationshipDtlsCacheRecord {
    int transactionID = 0;

    ConcernRoleRelationshipDtlsBuffer concernRoleRelationshipDtlsBuffer = new ConcernRoleRelationshipDtlsBuffer();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ConcernRoleRelationshipDtls read(ConcernRoleRelationshipKey key)
    throws AppException, InformationalException {

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    // concernRoleRelationshipDtls variable
    ConcernRoleRelationshipDtls concernRoleRelationshipDtls;

    ConcernRoleRelationshipDtlsCacheRecord concernRoleRelationshipDtlsCacheRecord = new ConcernRoleRelationshipDtlsCacheRecord();

    ConcernRoleRelationshipDtlsBuffer concernRoleRelDtlsBuffer = new ConcernRoleRelationshipDtlsBuffer();

    // BEGIN CR00052232, GSP

    // if caching is enabled, check the cache for the concern role
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {
      // END CR00052232
      concernRoleRelationshipDtlsCacheRecord = (ConcernRoleRelationshipDtlsCacheRecord) cachedConcernRoleRelationshipDtls.get();

      if (concernRoleRelationshipDtlsCacheRecord != null) {

        concernRoleRelDtlsBuffer = concernRoleRelationshipDtlsCacheRecord.concernRoleRelationshipDtlsBuffer;

        // if this is a deferred transaction, we must also check
        // that the transaction numbers match
        if (concernRoleRelDtlsBuffer != null
          // BEGIN CR00052232, GSP
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            // END CR00052232
            && TransactionInfo.getIdentifierForThisThread()
              != concernRoleRelationshipDtlsCacheRecord.transactionID) {

          concernRoleRelDtlsBuffer = null;
        }

        if (concernRoleRelDtlsBuffer != null) {

          // try to find the data in the cache
          ConcernRoleRelationshipDtls searchKey = new ConcernRoleRelationshipDtls();

          // set key to find concernRoleRelationship
          searchKey.concernRoleRelationshipID = key.concernRoleRelationshipID;
          concernRoleRelationshipDtls = (ConcernRoleRelationshipDtls) concernRoleRelDtlsBuffer.find(
            searchKey);

          // if found map to dtls and exit
          if (concernRoleRelationshipDtls != null) {

            return concernRoleRelationshipDtls;
          }
        }
      }
    }

    // concernRoleRelationship manipulation variables
    curam.core.intf.ConcernRoleRelationship concernRoleRelationshipObj = curam.core.fact.ConcernRoleRelationshipFactory.newInstance();

    // read concernRoleRelationship
    concernRoleRelationshipDtls = concernRoleRelationshipObj.read(key);

    // if this was a cache miss (and caching is enabled), refresh the cache
    // BEGIN CR00052232, GSP
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {
      // END CR00052232
      concernRoleRelDtlsBuffer = new ConcernRoleRelationshipDtlsBuffer();

      concernRoleRelDtlsBuffer.insert(concernRoleRelationshipDtls);
      concernRoleRelationshipDtlsCacheRecord = new ConcernRoleRelationshipDtlsCacheRecord();
      concernRoleRelationshipDtlsCacheRecord.concernRoleRelationshipDtlsBuffer = concernRoleRelDtlsBuffer;
      concernRoleRelationshipDtlsCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();

      cachedConcernRoleRelationshipDtls.set(
        concernRoleRelationshipDtlsCacheRecord);
    }

    return concernRoleRelationshipDtls;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void clearCache() throws AppException, InformationalException {

    // clear the thread local
    cachedConcernRoleRelationshipDtls.set(null);
  }

  // BEGIN CR00052232, GSP
  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ConcernRoleRelationshipDtls readReciprocalRelationship(ReciprocalRelationshipKey key) throws AppException, InformationalException {

    ConcernRoleRelationshipDtls concernRoleRelationshipDtls = new ConcernRoleRelationshipDtls();

    boolean reloadCache = true;

    // variable to hold transaction type
    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    // if caching is enabled, check the cache for the concern role
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {

      // try to find the data in the cache
      ConcernRoleRelationshipDtls searchKey = new ConcernRoleRelationshipDtls();

      searchKey.concernRoleRelationshipID = key.concernRoleRecipRelationID;

      ConcernRoleRelationshipDtlsCacheRecord concernRoleRelationshipDtlsCacheRecord = (ConcernRoleRelationshipDtlsCacheRecord) cachedConcernRoleRelationshipDtls.get();

      if (concernRoleRelationshipDtlsCacheRecord != null) {

        concernRoleRelationshipDtls = (ConcernRoleRelationshipDtls) concernRoleRelationshipDtlsCacheRecord.concernRoleRelationshipDtlsBuffer.find(
          searchKey);

        if (concernRoleRelationshipDtls != null) {

          reloadCache = false;

          // if this is a deferred transaction, we must also check
          // that the transaction numbers match
          if (!reloadCache
            && (transactionType.equals(TransactionType.kDeferred)
              || transactionType.equals(TransactionType.kOnline))
              && TransactionInfo.getIdentifierForThisThread()
                != concernRoleRelationshipDtlsCacheRecord.transactionID) {

            reloadCache = true;
          }
        }
      }

    }

    // Otherwise we need to read the Person data
    if (reloadCache) {
      ConcernRoleRelationshipKey concernRoleRelationshipKey = new ConcernRoleRelationshipKey();

      concernRoleRelationshipKey.concernRoleRelationshipID = key.concernRoleRecipRelationID;
      concernRoleRelationshipDtls = reloadCache(concernRoleRelationshipKey);
    }

    return concernRoleRelationshipDtls;

  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ConcernRoleRelationshipDtls reloadCache(ConcernRoleRelationshipKey key) throws AppException, InformationalException {
    // variable to hold transaction type
    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    // concernRoleRelationship manipulation variables
    curam.core.intf.ConcernRoleRelationship concernRoleRelationshipObj = curam.core.fact.ConcernRoleRelationshipFactory.newInstance();

    ConcernRoleRelationshipDtls concernRoleRelationshipDtls;

    ConcernRoleRelationshipDtlsCacheRecord concernRoleRelationshipDtlsCacheRecord;

    // read concernRoleRelationship
    
    // BEGIN CR00089887, GSP    
    
    ReciprocalRelationshipKey reciprocalRelationshipkey = new ReciprocalRelationshipKey();

    reciprocalRelationshipkey.concernRoleRecipRelationID = key.concernRoleRelationshipID;
    concernRoleRelationshipDtls = concernRoleRelationshipObj.readReciprocalRelationship(
      reciprocalRelationshipkey);
    
    // END CR00089887 
    
    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {

      concernRoleRelationshipDtlsCacheRecord = new ConcernRoleRelationshipDtlsCacheRecord();

      concernRoleRelationshipDtlsCacheRecord.concernRoleRelationshipDtlsBuffer.insert(
        concernRoleRelationshipDtls);

      concernRoleRelationshipDtlsCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();

      cachedConcernRoleRelationshipDtls.set(
        concernRoleRelationshipDtlsCacheRecord);
    }

    return concernRoleRelationshipDtls;
  }
  // END CR00052232
}
