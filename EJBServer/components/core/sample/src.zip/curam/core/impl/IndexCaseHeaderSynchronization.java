/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.struct.CaseAppealIndicatorDetails;
import curam.core.struct.CaseExpectedDatesAndOutcomesModifyDetails;
import curam.core.struct.CaseHeaderDateDetails;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseHeaderStatus;
import curam.core.struct.CaseHeaderStatusAndFromDateDtls;
import curam.core.struct.CaseIDConcernRoleID;
import curam.core.struct.CaseStartDateDetails;
import curam.core.struct.OwnerOrgObjectLinkID;
import curam.core.struct.SynchronizeEventsDetails;
import curam.events.CASE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class performs updates to the Search Server staging database when 
 * modifications are made to the Case Header entity
 */
public abstract class IndexCaseHeaderSynchronization extends
  curam.core.base.IndexCaseHeaderSynchronization {
  
  // ___________________________________________________________________________
  /**
   * Raise an event as a result of the case header entity insert operation
   * 
   * @param dtls the case header details
   *
   */
  public void insert(final CaseHeaderDtls dtls) throws AppException,
      InformationalException {
    
    // BEGIN, CR00091119, DMC
    final SynchronizeEvents synchronizeEventsObj = 
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails = 
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = CASE.INSERT_CASE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = CASE.INSERT_CASE.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.caseID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
    // END, CR00091119
  }

  // BEGIN, CR00092134, DMC
  // ___________________________________________________________________________
  /**
   * Raise an event as a result of the case header entity modify operation
   * 
   * @param key caseHeaderKey
   * @param dtls caseHeaderDtls
   *
   */
  public void modify(final CaseHeaderKey key, final CaseHeaderDtls dtls)
    throws AppException, InformationalException {
    
    sendModifyEvent(key);
  }

  // ___________________________________________________________________________
  /**
   * Raise an event as a result of the case header entity modify case header dates operation
   * 
   * @param key caseHeaderKey
   * @param dtls caseHeaderDateDetails
   *
   */
  public void modifyCaseHeaderDates(final CaseHeaderKey key,
    final CaseHeaderDateDetails dtls) throws AppException,
      InformationalException {
    
    sendModifyEvent(key);
  }

  // ___________________________________________________________________________
  /**
   * Raise an event as a result of the case header entity modify case header status operation
   * 
   * @param key caseHeaderKey
   * @param dtls caseHeaderStatusAndFromDateDtls
   *
   */
  public void modifyCaseHeaderStatus(final CaseHeaderKey key,
    final CaseHeaderStatusAndFromDateDtls dtls) throws AppException,
      InformationalException {
    
    sendModifyEvent(key);
  }

  // ___________________________________________________________________________
  /**
   * Raise an event as a result of the case header entity modify case owner operation
   * 
   * @param key caseIDConcernRoleID
   * @param dtls ownerOrgObjectLinkID
   *
   */
  public void modifyCaseOwner(final CaseIDConcernRoleID key,
    final OwnerOrgObjectLinkID dtls) throws AppException,
      InformationalException {
    
    final SynchronizeEvents synchronizeEventsObj = 
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails = 
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = CASE.MODIFY_CASE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = CASE.MODIFY_CASE.eventType;
    synchronizeEventsDetails.primaryEventData = key.caseID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
  }

  // ___________________________________________________________________________
  /**
   * Raise an event as a result of the case header entity modify case start date operation
   * 
   * @param key caseHeaderKey
   * @param dtls CaseStartDateDetails
   *
   */
  public void modifyCaseStartDate(final CaseHeaderKey key,
    final CaseStartDateDetails dtls) throws AppException,
      InformationalException {
    
    sendModifyEvent(key);
  }

  // ___________________________________________________________________________
  /**
   * Raise an event as a result of the case header entity modify expected dates and outcomes operation
   * 
   * @param key caseHeaderKey
   * @param dtls caseExpectedDatesAndOutcomesModifyDetails
   *
   */
  public void modifyExpectedDatesAndOutcomes(final CaseHeaderKey key,
    final CaseExpectedDatesAndOutcomesModifyDetails dtls)
    throws AppException, InformationalException {
    
    sendModifyEvent(key);
  }

  // ___________________________________________________________________________
  /**
   * Raise an event as a result of the case header entity modify status operation
   * 
   * @param key caseHeaderKey
   * @param dtls caseHeaderStatus
   *
   */
  public void modifyStatus(final CaseHeaderKey key, final CaseHeaderStatus dtls)
    throws AppException, InformationalException {
    
    sendModifyEvent(key);
  }
  
  // ___________________________________________________________________________
  /**
   * Raise an event as a result of the case header entity modify appeal indicator
   * 
   * @param key caseHeaderKey
   * @param dtls caseAppealIndicatorDetails
   *
   */
  public void modifyAppealIndicator(final CaseHeaderKey key, final CaseAppealIndicatorDetails dtls)
    throws AppException, InformationalException {
    
    sendModifyEvent(key);
  }
  
  // ___________________________________________________________________________
  /**
   * Send a modify event indicating that the case header has been updated
   *
   * @param key the case header key
   */  
  // BEGIN, CR00198672, VK
  protected void sendModifyEvent(final CaseHeaderKey key) 
    throws AppException, InformationalException {
    // END, CR00198672
    final SynchronizeEvents synchronizeEventsObj = 
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails = 
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = CASE.MODIFY_CASE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = CASE.MODIFY_CASE.eventType;
    synchronizeEventsDetails.primaryEventData = key.caseID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
  }
  // END, CR00092134
}
