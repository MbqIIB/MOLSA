/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.struct.BatchProcessingID;
import curam.core.struct.BatchProcessingSkippedRecord;
import curam.core.struct.BatchProcessingSkippedRecordList;
import curam.core.struct.GenerateInstrumentsKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This wrapper is used to allow the batch streaming infrastructure to invoke
 * the reporting for the GenerateInstruments batch program.
 */
public class GenerateInstrumentsStreamWrapper implements BatchStream {

  protected curam.core.intf.GenerateInstrumentsStream generateInstrumentsStreamObj;

  // ___________________________________________________________________________
  /**
   * Constructor, takes an instance of the class implementing the
   * GenerateInstruments batch program
   */
  public GenerateInstrumentsStreamWrapper(curam.core.intf.GenerateInstrumentsStream generateInstrumentsStream) {

    generateInstrumentsStreamObj = generateInstrumentsStream;

  }

  // ___________________________________________________________________________
  /**
   * Call the getChunkResult method of the GenerateinstructionLineItemsStream
   */
  public String getChunkResult(int skippedCasesCount)
    throws AppException, InformationalException {

    return generateInstrumentsStreamObj.getChunkResult(skippedCasesCount);

  }

  // ___________________________________________________________________________
  /**
   * Call the processRecord method of the GenerateinstructionLineItemsStream
   */
  public BatchProcessingSkippedRecord processRecord(
    BatchProcessingID batchProcessingID,
    Object parameters)
    throws AppException, InformationalException {

    return generateInstrumentsStreamObj.processRecord(batchProcessingID,
      (GenerateInstrumentsKey) parameters);

  }

  // ___________________________________________________________________________
  /**
   * Call the processChunk method of the GenerateinstructionLineItemsStream
   */
  public void processSkippedCases(BatchProcessingSkippedRecordList batchProcessingSkippedRecordList)
    throws AppException, InformationalException {

    generateInstrumentsStreamObj.processSkippedCases(
      batchProcessingSkippedRecordList);

  }

}
