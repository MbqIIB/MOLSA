/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2003 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.CaseDetailsForDateDeterminationDtls;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.DateList;
import curam.core.struct.DateStruct;
import curam.core.struct.PaymentPeriodDeterminationKey;
import curam.core.struct.PaymentPeriodDeterminationResult;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Code to determine payment dates for a given Case.
 *
 */
public abstract class DeterminePaymentDate extends curam.core.base.DeterminePaymentDate {

  // ___________________________________________________________________________
  /**
   * This method determines the final payment date of the case, either the final
   * payment date in the current certification period or the final payment
   * date based on the end date of the case.
   *
   * @param caseDetailsForDateDeterminationDtls Details of the case for date
   * determination
   *
   * @return The final payment date of the case
   */
  public PaymentPeriodDeterminationResult determineEndPaymentDate(
    CaseDetailsForDateDeterminationDtls caseDetailsForDateDeterminationDtls)
    throws AppException, InformationalException {

    // paymentPeriodDeterminationResult variable
    PaymentPeriodDeterminationResult paymentPeriodDeterminationResult = null;

    // used to store the end date of the case and next certification date.
    curam.util.type.Date endDate;

    curam.util.type.Date expectedEndDate;

    endDate = caseDetailsForDateDeterminationDtls.endDate;
    expectedEndDate = caseDetailsForDateDeterminationDtls.expectedEndDate;

    // calculate the next payment date after the end date if it is set
    // or expected end date otherwise
    if (!endDate.isZero()) {

      // use endDate
      PaymentPeriodDeterminationKey newKey = new PaymentPeriodDeterminationKey();

      newKey.dateOfCalculation = endDate;

      // determine next payment date
      paymentPeriodDeterminationResult = determineNextPaymentDate(newKey,
        caseDetailsForDateDeterminationDtls);

    } else {

      if (!expectedEndDate.isZero()) {

        // use expectedEndDate
        PaymentPeriodDeterminationKey newKey = new PaymentPeriodDeterminationKey();

        newKey.dateOfCalculation = expectedEndDate;

        // determine next payment date
        paymentPeriodDeterminationResult = determineNextPaymentDate(newKey,
          caseDetailsForDateDeterminationDtls);

      } else {

        // throw Exception - not valid business scenario
        AppException e = new AppException(
          curam.message.BPODETERMINEPAYMENTDATE.ERR_PAYMENTPERIOD_FV_END_DATE_EMPTY);
        // CaseHeader manipulation variables
        curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
        CaseSearchKey caseSearchKey = new CaseSearchKey();
  
        caseSearchKey.caseID = caseDetailsForDateDeterminationDtls.caseID;
        e.arg(
          caseHeaderObj.readCaseReferenceByCaseID(caseSearchKey).caseReference); 
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }

    }

    return paymentPeriodDeterminationResult;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to determine the next payment date for a given case,
   * based on the Product Delivery Frequency, checking for an override on the
   * Service Delivery entity.
   *
   * @param paymentPeriodDeterminationKey Contains date of calculation
   * @param caseDetailsForDateDeterminationDtls Case details for date
   * determination
   *
   * @return Next payment date for the case
   */
  public PaymentPeriodDeterminationResult determineNextPaymentDate(
    PaymentPeriodDeterminationKey paymentPeriodDeterminationKey,
    CaseDetailsForDateDeterminationDtls caseDetailsForDateDeterminationDtls)
    throws AppException, InformationalException {

    // paymentPeriodDeterminationResult variable
    PaymentPeriodDeterminationResult paymentPeriodDeterminationResult = new PaymentPeriodDeterminationResult();

    // used to store the delivery pattern for this case.
    curam.util.type.FrequencyPattern paymentPattern = new curam.util.type.FrequencyPattern(
      caseDetailsForDateDeterminationDtls.paymentPattern);

    // calculate date based on pattern
    // if after effective date then loop forward
    if (paymentPeriodDeterminationKey.dateOfCalculation.after(
      caseDetailsForDateDeterminationDtls.effectiveDate)) {

      paymentPeriodDeterminationResult.paymentDate = caseDetailsForDateDeterminationDtls.effectiveDate;

      while (paymentPeriodDeterminationResult.paymentDate.before(
        paymentPeriodDeterminationKey.dateOfCalculation)) {

        paymentPeriodDeterminationResult.paymentDate = paymentPattern.getNextOccurrence(
          paymentPeriodDeterminationResult.paymentDate);
      }

      return paymentPeriodDeterminationResult;
    }

    // if equal then it's the next one
    if (paymentPeriodDeterminationKey.dateOfCalculation.equals(
      caseDetailsForDateDeterminationDtls.effectiveDate)) {

      paymentPeriodDeterminationResult.paymentDate = paymentPattern.getNextOccurrence(
        caseDetailsForDateDeterminationDtls.effectiveDate);
    }

    // if less - loop backward.
    if (paymentPeriodDeterminationKey.dateOfCalculation.before(
      caseDetailsForDateDeterminationDtls.effectiveDate)) {

      paymentPeriodDeterminationResult.paymentDate = caseDetailsForDateDeterminationDtls.effectiveDate;

      while (paymentPeriodDeterminationResult.paymentDate.after(
        paymentPeriodDeterminationKey.dateOfCalculation)) {

        paymentPeriodDeterminationResult.paymentDate = paymentPattern.getPrevOccurrence(
          paymentPeriodDeterminationResult.paymentDate);
      }

      // have to go one too far and loop forward one.
      paymentPeriodDeterminationResult.paymentDate = paymentPattern.getNextOccurrence(
        paymentPeriodDeterminationResult.paymentDate);

      return paymentPeriodDeterminationResult;
    }

    return paymentPeriodDeterminationResult;

  }

  // ___________________________________________________________________________
  /**
   * This method gets all the payment dates between the two dates which are
   * passed in as the first two elements in a DateList.
   *
   * @param dateList Contains two payment dates
   * @param caseDetailsForDateDeterminationDtls Case details for date
   * determination
   */
  public void determineAllPaymentDates(DateList dateList,
    CaseDetailsForDateDeterminationDtls caseDetailsForDateDeterminationDtls)
    throws AppException, InformationalException {

    if (caseDetailsForDateDeterminationDtls.effectiveDate.isZero()) {
      return;
    }

    // used to store the delivery pattern for this case.
    curam.util.type.FrequencyPattern paymentPattern;

    // used to store the effective (first payment) date for this case.
    curam.util.type.Date effectiveDate;

    DateStruct tempDate;

    // temp local, used to add dates to the DateList
    curam.util.type.Date firstDate;

    curam.util.type.Date secondDate;

    // This processing is based on the assumption that the input list contains
    // two dates, the payment dates between these two dates are then calculated
    // And the list returned contains the { first date, N * Payment Date(s),
    // second date }.
    firstDate = dateList.dtls.item(0).date;
    secondDate = dateList.dtls.item(dateList.dtls.size() - 1).date;
    dateList.dtls.clear();

    // if the second date is zero we should use the endDate
    if (secondDate.isZero()) {

      // paymentPeriodDeterminationResult variable
      PaymentPeriodDeterminationResult paymentPeriodDeterminationResult;

      paymentPeriodDeterminationResult = determineEndPaymentDate(
        caseDetailsForDateDeterminationDtls);

      secondDate = paymentPeriodDeterminationResult.paymentDate;
    }

    effectiveDate = caseDetailsForDateDeterminationDtls.effectiveDate;

    paymentPattern = new curam.util.type.FrequencyPattern(
      caseDetailsForDateDeterminationDtls.paymentPattern);

    // if first date > effective date
    if (firstDate.after(effectiveDate)) {

      tempDate = new DateStruct();

      tempDate.date = effectiveDate;

      // loop until tempDate > first date
      while (tempDate.date.before(firstDate)) {

        tempDate.date = paymentPattern.getNextOccurrence(tempDate.date);
      }

      // add to list until > second date
      while (tempDate.date.before(secondDate)) {

        dateList.dtls.addRef((DateStruct) tempDate.deepClone());

        tempDate.date = paymentPattern.getNextOccurrence(tempDate.date);
      }

      dateList.dtls.addRef(tempDate);

      return;
    }

    // if first date < effective date
    if (firstDate.before(effectiveDate)) {

      tempDate = new DateStruct();

      tempDate.date = effectiveDate;

      // loop until tempDate > first date
      while (tempDate.date.after(firstDate)) {

        tempDate.date = paymentPattern.getPrevOccurrence(tempDate.date);
      }

      // get first payment date after start date
      if (!tempDate.date.equals(firstDate)) {

        tempDate.date = paymentPattern.getNextOccurrence(tempDate.date);
      }

      // add to list until > second date
      while (tempDate.date.before(secondDate)) {

        dateList.dtls.addRef((DateStruct) tempDate.deepClone());

        tempDate.date = paymentPattern.getNextOccurrence(tempDate.date);
      }

      dateList.dtls.addRef(tempDate);
      return;
    }

    tempDate = new DateStruct();

    tempDate.date = effectiveDate;

    // loop forward adding to list until > second date
    while (tempDate.date.before(secondDate)) {

      dateList.dtls.addRef((DateStruct) tempDate.deepClone());

      tempDate.date = paymentPattern.getNextOccurrence(tempDate.date);
    }

    dateList.dtls.addRef(tempDate);
  }

}
