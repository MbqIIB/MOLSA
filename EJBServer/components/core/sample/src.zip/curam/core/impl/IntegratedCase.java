/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2003, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.Map;

import com.google.inject.Inject;
import com.google.inject.Provider;

import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASERELATIONSHIPREASONCODE;
import curam.codetable.CASERELATIONSHIPTYPECODE;
import curam.codetable.CASETRANSACTIONEVENTS;
import curam.codetable.CASETYPECODE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TASKSTATUS;
import curam.codetable.VERIFICATIONCONTROLLER;
import curam.codetable.impl.CASEEVENTTYPEEntry;
import curam.codetable.impl.CASEREACTIVATEREASONEntry;
import curam.codetable.impl.CASESTATUSEntry;
import curam.codetable.impl.CASETRANSACTIONEVENTSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.fact.OrganizationFactory;
import curam.core.facade.intf.Organization;
import curam.core.facade.struct.LanguageLocaleDetails;
import curam.core.facade.struct.LanguageLocaleMapKey;
import curam.core.facade.struct.SearchTasksForConcernAndCaseDetails;
import curam.core.facade.struct.UserSkillKey;
import curam.core.facade.struct.UserSkillLanguageDetails;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.CaseReactivationFactory;
import curam.core.fact.CaseStatusFactory;
import curam.core.fact.CloseCaseFactory;
import curam.core.fact.CreateProductDeliveryAssistantFactory;
import curam.core.fact.MaintainCaseClosureAssistantFactory;
import curam.core.fact.MaintainRelatedCasesFactory;
import curam.core.fact.MaintainUsersFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.CaseReactivation;
import curam.core.intf.CaseStatus;
import curam.core.intf.CloseCase;
import curam.core.intf.MaintainCaseClosureAssistant;
import curam.core.intf.MaintainRelatedCases;
import curam.core.intf.MaintainUsers;
import curam.core.intf.SystemUser;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.fact.CaseParticipantRoleFactory;
import curam.core.sl.entity.intf.CaseParticipantRole;
import curam.core.sl.entity.struct.CaseParticipantRoleDtls;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.fact.CaseFactory;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.ClientMergeFactory;
import curam.core.sl.fact.LanguageLocaleMapFactory;
import curam.core.sl.fact.UserSkillFactory;
import curam.core.sl.impl.CaseTransactionLogIntf;
import curam.core.sl.impl.IntegratedCaseValidator;
import curam.core.sl.impl.VerificationInterface;
import curam.core.sl.infrastructure.fact.EvidenceControllerFactory;
import curam.core.sl.infrastructure.impl.EvidenceVerificationImpl;
import curam.core.sl.infrastructure.intf.EvidenceController;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.ClientMerge;
import curam.core.sl.intf.LanguageLocaleMap;
import curam.core.sl.intf.UserSkill;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.IsUserSupervisor;
import curam.core.sl.struct.ListUserSkillTypeStatusKey;
import curam.core.sl.struct.OwnerInd;
import curam.core.sl.struct.OwnershipStrategyDetails;
import curam.core.sl.struct.SearchTaskForConcernOrCaseKey;
import curam.core.sl.struct.UserSkillDetails;
import curam.core.struct.ActivityDtls;
import curam.core.struct.ActivityDtlsList;
import curam.core.struct.ActivityKey;
import curam.core.struct.AddPDCaseToIntegratedCaseResult;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.AdminIntegratedCaseDtls;
import curam.core.struct.CaseEventByCaseIDKey;
import curam.core.struct.CaseEventDtls;
import curam.core.struct.CaseEventDtlsList;
import curam.core.struct.CaseEventKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseIDConcernAndICTypeKey;
import curam.core.struct.CaseIDDetailsList;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReactivationDtls;
import curam.core.struct.CaseReferenceAndStatusDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseSecurityCheckKey;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.ClientListDetails;
import curam.core.struct.CloseCaseEventKey;
import curam.core.struct.ClosureDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleID;
import curam.core.struct.ConcernRoleIDList;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.CuramInd;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.ICClientList;
import curam.core.struct.ICClientListKey;
import curam.core.struct.ICClosureDtls;
import curam.core.struct.IntegratedCaseIDKey;
import curam.core.struct.IntegratedCaseKey;
import curam.core.struct.IntegratedCaseRegistrationDetails;
import curam.core.struct.IntegratedCaseRegistrationDetails1;
import curam.core.struct.IntegratedCaseTypeStruct;
import curam.core.struct.MaintainCaseHeaderDetails;
import curam.core.struct.MaintainCaseRelationshipDetails;
import curam.core.struct.MaintainCaseRelationshipDetails1;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PrimaryAddressBankAccountAndPrefPublicOffice;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ReactivationDtls;
import curam.core.struct.RegisterProductDeliveryKey;
import curam.core.struct.SearchActivityByCaseKey;
import curam.core.struct.SecurityResult;
import curam.core.struct.UpdateCaseStatusReasonEndKey1;
import curam.core.struct.UserNameKey;
import curam.core.struct.UsersKey;
import curam.events.CASE;
import curam.events.Verification;
import curam.message.BPOCASEEVENTS;
import curam.message.BPOCLIENTMERGE;
import curam.message.BPOEVIDENCECONTROLLER;
import curam.message.BPOMAINTAINCASECLOSURE;
import curam.message.BPOMAINTAINPRODUCTDELIVERY;
import curam.message.GENERALCASE;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.ReadmultiMaxException;
import curam.util.exception.RecordNotFoundException;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.ProgramLocale;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.NotFoundIndicator;


/**
 * Code for creating and maintaining integrated cases
 */
public abstract class IntegratedCase extends curam.core.base.IntegratedCase {

  // BEGIN, CR00282451, VMI
  /**
   * Reference to IntegratedCaseValidator instances.
   */
  @Inject
  private Map<String, IntegratedCaseValidator> integratedCaseValidatorMap;

  // END, CR00282451
  
  @Inject 
  EvidenceVerificationImpl evidenceVerificationImpl;
 
  // BEGIN, CR00284804, CW
  /**
   * Variables to track user case permissions for security checks.
   */
  protected static final int kUserMaintain = 1;

  protected static final int kUserRead = 2;

  // END, CR00284804

  // BEGIN CR00108134, GBA
  // Add injection for using the new CaseTransactionLog API
  public IntegratedCase() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  protected Provider<CaseTransactionLogIntf> caseTransactionLogProvider;

  // END CR00108134

  /**
   * The method is called by the client at the end of the integrated Case
   * registration wizard, it takes a list of clients and creates a case header
   * and adds the clients as concern case roles and adds the clients to the
   * IntegratedCaseClients list. Also links the primary client's participant
   * evidence to the integrated case which is being created.
   *
   * @param dtls
   * Integrated case registration details
   *
   * @return contains id of the integrated case created
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   * @deprecated Since Curam6.0, replaced with
   * {@link IntegratedCase#createIntegratedCase1()}.
   */
  @Override
  @Deprecated
  public IntegratedCaseIDKey createIntegratedCase(
    final IntegratedCaseRegistrationDetails dtls) throws AppException,
      InformationalException {

    // integrated Case ID Key
    final IntegratedCaseIDKey integratedCaseIDKey = new IntegratedCaseIDKey();

    // Case header entity and details
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();
    // BEGIN, CR00060051, PMD
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    // END, CR00060051

    // Case status entity and details
    final curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
    final CaseStatusDtls caseStatusDtls = new CaseStatusDtls();

    // CaseParticipantRole manipulation variables
    final curam.core.sl.entity.intf.CaseParticipantRole caseParticipantRoleObj = curam.core.sl.entity.fact.CaseParticipantRoleFactory.newInstance();
    final CaseParticipantRoleDtls caseParticipantRoleDtls = new CaseParticipantRoleDtls();

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // Local variables
    // UniqueID entity
    final curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // key and list used for getting client list details
    final ICClientListKey iCClientListKey = new ICClientListKey();
    ICClientList iCClientList;

    // maintainRelatedCases manipulation variables
    final curam.core.intf.MaintainRelatedCases maintainRelatedCasesObj = curam.core.fact.MaintainRelatedCasesFactory.newInstance();
    final MaintainCaseRelationshipDetails maintainCaseRelationshipDetails = new MaintainCaseRelationshipDetails();

    // BEGIN, CR00099541, PMD
    validateIntegratedCaseDetails(dtls);
    // END, CR00099541

    // struct mapping
    caseHeaderDtls.assign(dtls);

    // Get a unique id
    caseHeaderDtls.caseID = uniqueIDObj.getNextID();

    caseHeaderDtls.planID = 0;
    caseHeaderDtls.integratedCaseID = 0;
    caseHeaderDtls.registrationDate = curam.util.type.Date.getCurrentDate();
    caseHeaderDtls.expectedStartDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.concernRoleID = dtls.primaryClientID;
    caseHeaderDtls.expectedEndDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.startDate = curam.util.type.Date.getCurrentDate();
    caseHeaderDtls.endDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.effectiveDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.statusCode = curam.codetable.CASESTATUS.OPEN;
    caseHeaderDtls.classificationCode = curam.codetable.CASECLASSIFICATION.DEFAULTCODE;
    caseHeaderDtls.objectiveCode = curam.codetable.CASEOBJECTIVE.DEFAULTCODE;
    caseHeaderDtls.outcomeCode = curam.codetable.CASEOUTCOME.DEFAULTCODE;
    // BEGIN, CR00049218, GM
    caseHeaderDtls.comments = CuramConst.gkEmpty;
    // END, CR00049218
    caseHeaderDtls.caseTypeCode = curam.codetable.CASETYPECODE.INTEGRATEDCASE;
    caseHeaderDtls.firstReviewDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.defaultDeliveryMethodType = curam.codetable.METHODOFDELIVERY.DEFAULTCODE;
    caseHeaderDtls.integratedCaseType = dtls.integratedCaseType;
    // BEGIN, CR00347149, KH
    // Use the base currency specified in the application properties
    String baseCurrency = Configuration.getProperty(EnvVars.ENV_BASECURRENCY);

    if (baseCurrency == null) {
      baseCurrency = EnvVars.ENV_BASECURRENCY_DEFAULT; 
    }
    caseHeaderDtls.defaultCurrencyTypeCode = baseCurrency;
    // END, CR00347149

    // BEGIN, CR00060051, PMD
    // the owner ID is update when the CaseUserRole is created
    caseHeaderDtls.ownerOrgObjectLinkID = 0;
    // END, CR00060051

    caseHeaderDtls.receivedDate = curam.util.type.Date.getCurrentDate();
    caseHeaderDtls.priorityCode = dtls.priorityCode;

    // set the case reference
    caseHeaderDtls.caseReference = curam.core.sl.fact.CaseFactory.newInstance().getCaseReference(caseHeaderDtls).caseReference;

    // insert CaseHeader
    caseHeaderObj.insert(caseHeaderDtls);

    // BEGIN, CR00114562, CR00118995, KH
    // Create case user roles first, to ensure there is a case owner for any
    // security checks performed later
    // BEGIN, CR00060051, PMD
    // Set the case header key to be the current case id
    caseHeaderKey.caseID = caseHeaderDtls.caseID;

    // Create the case owner this will default to the current user
    caseUserRoleObj.createOwner(caseHeaderKey, new OrgObjectLinkDtls());
    // END, CR00060051, CR00114562, CR00118995

    // get client list details
    iCClientListKey.caseClientList = dtls.caseClientList;
    iCClientList = getClientListDetails(iCClientListKey);

    // For each client in the list
    for (int i = 0; i < iCClientList.dtls.size(); i++) {

      caseParticipantRoleDtls.participantRoleID = iCClientList.dtls.item(i).concernRoleID;
      caseParticipantRoleDtls.caseID = caseHeaderDtls.caseID;
      caseParticipantRoleDtls.fromDate = caseHeaderDtls.startDate;
      caseParticipantRoleDtls.toDate = caseHeaderDtls.endDate;

      caseParticipantRoleObj.insert(caseParticipantRoleDtls);
    }

    // insert case status details
    caseStatusDtls.caseStatusID = uniqueIDObj.getNextID();

    caseStatusDtls.caseID = caseHeaderDtls.caseID;
    caseStatusDtls.statusCode = caseHeaderDtls.statusCode;
    caseStatusDtls.startDate = caseHeaderDtls.startDate;
    // Set the user name
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    caseStatusDtls.userName = systemUserObj.getUserDetails().userName;

    caseStatusObj.insert(caseStatusDtls);

    // return caseID
    integratedCaseIDKey.caseID = caseHeaderDtls.caseID;

    // If this integrated case is being created from a screening case
    // then create a case relationship record
    if (dtls.relatedCaseID != 0) {
      maintainCaseRelationshipDetails.caseID = caseHeaderDtls.caseID;
      maintainCaseRelationshipDetails.relatedCaseID = dtls.relatedCaseID;
      maintainCaseRelationshipDetails.primaryClientID = caseHeaderDtls.concernRoleID;
      maintainCaseRelationshipDetails.startDate = curam.util.type.Date.getCurrentDate();
      maintainCaseRelationshipDetails.statusCode = curam.codetable.RECORDSTATUS.NORMAL;
      maintainCaseRelationshipDetails.typeCode = curam.codetable.CASERELATIONSHIPTYPECODE.INTEGSCREENING;
      maintainCaseRelationshipDetails.caseTypeCode = caseHeaderDtls.caseTypeCode;

      maintainCaseRelationshipDetails.reasonCode = curam.codetable.CASERELATIONSHIPREASONCODE.DEFAULTCODE;

      maintainRelatedCasesObj.createCaseRelationship(
        maintainCaseRelationshipDetails);

    }

    // BEGIN, CR00065924, AC
    final CaseIDConcernAndICTypeKey caseIDConcernAndICTypeKey = new CaseIDConcernAndICTypeKey();

    caseIDConcernAndICTypeKey.caseID = caseHeaderDtls.caseID;
    caseIDConcernAndICTypeKey.integratedCaseType = caseHeaderDtls.integratedCaseType;
    caseIDConcernAndICTypeKey.concernRoleID = caseHeaderDtls.concernRoleID;

    final EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

    evidenceControllerObj.retrieveAndLinkPrtcptDataForIntegratedCase(
      caseIDConcernAndICTypeKey);
    // END, CR00065924,

    // BEGIN, CR00022728, RR
    if (caseHeaderDtls.caseID != 0) {

      // Log Transaction Details
      // BEGIN CR00108134, GBA
      final CodeTableItemIdentifier caseTypeCodeTableItemIdentifier = new CodeTableItemIdentifier(
        CASETYPECODE.TABLENAME, caseHeaderDtls.caseTypeCode);

      final LocalisableString description = new LocalisableString(BPOCASEEVENTS.HEADER_CREATED).arg(caseTypeCodeTableItemIdentifier).arg(
        caseHeaderDtls.caseReference);

      // BEGIN CR00108593, GBA
      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.CASEHEADER_CREATED, description,
        caseHeaderDtls.caseID, CuramConst.kDefaultRelatedID);
      // END CR00108593
      // END CR00108134
    }
    // END, CR00022728

    return integratedCaseIDKey;
  }

  // BEGIN, CR00300347, BF
  // BEGIN, CR00205110, PB

  /**
   * The method is called by the client at the end of the integrated Case
   * registration wizard, it takes a list of clients and creates a case header
   * and adds the clients as concern case roles and adds the clients to the
   * IntegratedCaseClients list. Also links the primary client's participant
   * evidence to the integrated case which is being created.
   *
   * @param dtls
   * Integrated case registration details
   *
   * @return contains id of the integrated case created
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public IntegratedCaseIDKey createIntegratedCase1(
    final IntegratedCaseRegistrationDetails1 dtls) throws AppException,
      InformationalException {

    // We are setting the case start date here to the current date
    // This was the previous processing for this method and do
    // not want it to change.
    dtls.startDate = Date.getCurrentDate();

    // Create integrated case.
    final IntegratedCaseIDKey integratedCaseIDKey = createIntegratedCaseWithSpecifiedStartDate(
      dtls);

    return integratedCaseIDKey;

  }

  // END, CR00298702

  // BEGIN, CR00298702 BF.
  /**
   * The method creates an integrated case with a specified start date. This
   * involved creation of a case header, adding the clients as concern case
   * roles and adding the clients to the IntegratedCaseClients list. Also links
   * the primary client's participant evidence to the integrated case which is
   * being created. NOTE: If the start date has not been passed in, then the
   * start date will be defaulted to the current date.
   *
   * @param dtls
   * Integrated case registration details
   *
   * @return contains id of the integrated case created
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public IntegratedCaseIDKey createIntegratedCaseWithSpecifiedStartDate(
    final IntegratedCaseRegistrationDetails1 dtls) throws AppException,
      InformationalException {

    // integrated Case ID Key
    final IntegratedCaseIDKey integratedCaseIDKey = new IntegratedCaseIDKey();

    // Case header entity and details
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderDtls caseHeaderDtls = new CaseHeaderDtls();
    // BEGIN, CR00060051, PMD
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    // END, CR00060051

    // Case status entity and details
    final CaseStatus caseStatusObj = CaseStatusFactory.newInstance();
    final CaseStatusDtls caseStatusDtls = new CaseStatusDtls();

    // CaseParticipantRole manipulation variables
    final CaseParticipantRole caseParticipantRoleObj = CaseParticipantRoleFactory.newInstance();
    // BEGIN, CR00280559, MV
    CaseParticipantRoleDtls caseParticipantRoleDtls = null;
    // END, CR00280559

    // CaseUserRole manipulation variables
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    // BEGIN, CR00236214, PB
    final String locale = ProgramLocale.getDefaultServerLocale();
    final LanguageLocaleDetails languageLocaleDetails = new LanguageLocaleDetails();
    final LanguageLocaleMap languageLocaleMapObj = LanguageLocaleMapFactory.newInstance();
    final LanguageLocaleMapKey languageLocaleMapKey = new LanguageLocaleMapKey();
    // END, CR00236214
    // Local variables
    // UniqueID entity
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // key and list used for getting client list details
    final ICClientListKey iCClientListKey = new ICClientListKey();
    ICClientList iCClientList;

    // maintainRelatedCases manipulation variables
    final MaintainRelatedCases maintainRelatedCasesObj = MaintainRelatedCasesFactory.newInstance();
    // BEGIN, CR00221300, ZV
    final MaintainCaseRelationshipDetails1 maintainCaseRelationshipDetails = new MaintainCaseRelationshipDetails1();
    // END, CR00221300
    final IntegratedCaseRegistrationDetails integratedCaseRegistrationDetails = new IntegratedCaseRegistrationDetails();

    integratedCaseRegistrationDetails.assign(dtls);
    // BEGIN, CR00099541, PMD
    validateIntegratedCaseDetails(integratedCaseRegistrationDetails);

    // END, CR00099541

    // struct mapping
    caseHeaderDtls.assign(dtls);

    // Get a unique id
    caseHeaderDtls.caseID = uniqueIDObj.getNextID();

    caseHeaderDtls.planID = 0;
    caseHeaderDtls.integratedCaseID = 0;
    caseHeaderDtls.registrationDate = curam.util.type.Date.getCurrentDate();
    caseHeaderDtls.expectedStartDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.concernRoleID = dtls.primaryClientID;
    caseHeaderDtls.expectedEndDate = curam.util.type.Date.kZeroDate;

    caseHeaderDtls.endDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.effectiveDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.statusCode = curam.codetable.CASESTATUS.OPEN;
    caseHeaderDtls.classificationCode = curam.codetable.CASECLASSIFICATION.DEFAULTCODE;
    caseHeaderDtls.objectiveCode = curam.codetable.CASEOBJECTIVE.DEFAULTCODE;
    caseHeaderDtls.outcomeCode = curam.codetable.CASEOUTCOME.DEFAULTCODE;
    // BEGIN, CR00049218, GM
    caseHeaderDtls.comments = CuramConst.gkEmpty;
    // END, CR00049218
    caseHeaderDtls.caseTypeCode = curam.codetable.CASETYPECODE.INTEGRATEDCASE;
    caseHeaderDtls.firstReviewDate = curam.util.type.Date.kZeroDate;
    caseHeaderDtls.defaultDeliveryMethodType = curam.codetable.METHODOFDELIVERY.DEFAULTCODE;
    caseHeaderDtls.integratedCaseType = dtls.integratedCaseType;
    // BEGIN, CR00347149, KH
    // Use the base currency specified in the application properties
    String baseCurrency = Configuration.getProperty(EnvVars.ENV_BASECURRENCY);

    if (baseCurrency == null) {
      baseCurrency = EnvVars.ENV_BASECURRENCY_DEFAULT; 
    }
    caseHeaderDtls.defaultCurrencyTypeCode = baseCurrency;
    // END, CR00347149

    // Set start date to date passed in.
    if (!dtls.startDate.equals(curam.util.type.Date.kZeroDate)) {
      caseHeaderDtls.startDate = dtls.startDate;
    } else { // If not set - set to current date.
      caseHeaderDtls.startDate = curam.util.type.Date.getCurrentDate();
    }

    // BEGIN, CR00060051, PMD
    // the owner ID is update when the CaseUserRole is created
    caseHeaderDtls.ownerOrgObjectLinkID = 0;
    // END, CR00060051

    caseHeaderDtls.receivedDate = curam.util.type.Date.getCurrentDate();
    caseHeaderDtls.priorityCode = dtls.priorityCode;

    // set the case reference
    caseHeaderDtls.caseReference = CaseFactory.newInstance().getCaseReference(caseHeaderDtls).caseReference;

    // insert CaseHeader
    caseHeaderObj.insert(caseHeaderDtls);

    // BEGIN, CR00114562, CR00118995, KH
    // Create case user roles first, to ensure there is a case owner for any
    // security checks performed later
    // BEGIN, CR00060051, PMD
    // Set the case header key to be the current case id
    caseHeaderKey.caseID = caseHeaderDtls.caseID;

    // BEGIN, CR00205193, SS
    // Check if a workflow is configured for the particular integrated case
    // type.
    final curam.core.intf.AdminIntegratedCase adminICObj = curam.core.fact.AdminIntegratedCaseFactory.newInstance();
    final IntegratedCaseTypeStruct key = new IntegratedCaseTypeStruct();

    key.integratedCaseType = dtls.integratedCaseType;
    final NotFoundIndicator nfInd = new NotFoundIndicator();

    // Retrieve the ownershipStrategyName configured for this case type.
    if (!StringUtil.isNullOrEmpty(key.integratedCaseType)) {
      final AdminIntegratedCaseDtls adminIntegratedCaseDtls = adminICObj.readAdminIntegratedCaseByType(
        nfInd, key);

      if (!nfInd.isNotFound()
        && !StringUtil.isNullOrEmpty(
          adminIntegratedCaseDtls.ownershipStrategyName)) {
        final CaseKey caseID = new CaseKey();

        caseID.caseID = caseHeaderKey.caseID;
        final OwnershipStrategyDetails ownershipStrategyDetails = new OwnershipStrategyDetails();

        ownershipStrategyDetails.ownershipStrategyName = adminIntegratedCaseDtls.ownershipStrategyName;
        caseUserRoleObj.createOwnerBasedOnOwnershipStrategy(caseID,
          ownershipStrategyDetails);
      } else {

        // Create the case owner and this will default to the current user.
        caseUserRoleObj.createOwner(caseHeaderKey, new OrgObjectLinkDtls());
      }
    } else {

      // Create the case owner and this will default to the current user.
      caseUserRoleObj.createOwner(caseHeaderKey, new OrgObjectLinkDtls());
    }
    // END, CR00205193

    // END, CR00060051, CR00114562, CR00118995

    // BEGIN, CR00284804, CW
    // Perform security check to determine if case creation should proceed
    checkCaseSecurity(caseHeaderDtls.caseID, kUserMaintain);
    // END, CR00284804

    // get client list details
    iCClientListKey.caseClientList = dtls.caseClientList;
    iCClientList = getClientListDetails(iCClientListKey);
    ConcernRoleIDList concernRoleIDList = new ConcernRoleIDList();

    // For each client in the list
    for (int i = 0; i < iCClientList.dtls.size(); i++) {
      // BEGIN, CR00280559, MV
      caseParticipantRoleDtls = new CaseParticipantRoleDtls();
      // END, CR00280559
      caseParticipantRoleDtls.participantRoleID = iCClientList.dtls.item(i).concernRoleID;
      caseParticipantRoleDtls.caseID = caseHeaderDtls.caseID;
      caseParticipantRoleDtls.fromDate = caseHeaderDtls.startDate;
      caseParticipantRoleDtls.toDate = caseHeaderDtls.endDate;

      // BEGIN, CR00208321, PB
      final curam.core.intf.AdminIntegratedCase adminIntegratedCaseObj = curam.core.fact.AdminIntegratedCaseFactory.newInstance();

      final IntegratedCaseTypeStruct integratedCaseTypeStruct = new IntegratedCaseTypeStruct();

      // BEGIN, CR00213628, PB
      integratedCaseTypeStruct.integratedCaseType = caseHeaderDtls.integratedCaseType;
      // END, CR00213628
      final NotFoundIndicator nfIndicator = new NotFoundIndicator();

      AdminIntegratedCaseDtls adminIntegratedCaseDtls = new AdminIntegratedCaseDtls();

      adminIntegratedCaseDtls = adminIntegratedCaseObj.readAdminIntegratedCaseByType(
        nfIndicator, integratedCaseTypeStruct);

      final SystemUser systemUserObj = SystemUserFactory.newInstance();

      final ListUserSkillTypeStatusKey listUserSkillTypeStatuskey = new ListUserSkillTypeStatusKey();
      final UserSkill userSkillObj = UserSkillFactory.newInstance();
      UserSkillDetails userSkillDetails = new UserSkillDetails();
      final Organization organisationObj = OrganizationFactory.newInstance();

      listUserSkillTypeStatuskey.userName = systemUserObj.getUserDetails().userName;

      listUserSkillTypeStatuskey.skillType = curam.codetable.SKILLTYPE.LANGUAGES;
      listUserSkillTypeStatuskey.recordStatus = RECORDSTATUS.NORMAL;
      if (!nfIndicator.isNotFound()) {
        try {
          userSkillDetails = userSkillObj.listByUserSkillStatus(
            listUserSkillTypeStatuskey);
        } catch (final RecordNotFoundException e) {}
        UserSkillLanguageDetails userSkillLanguageDetails = new UserSkillLanguageDetails();
        final UserSkillKey userSkillKey = new UserSkillKey();

        userSkillKey.userSkillKey.userSkillID = userSkillDetails.details.userSkillID;
        try {
          userSkillLanguageDetails = organisationObj.viewUserLanguagesSkill(
            userSkillKey);
        } catch (final RecordNotFoundException e) {}
        // Concern role entity, key and details
        final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
        final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
        ConcernRoleDtls concernRoleDtls;

        concernRoleKey.concernRoleID = iCClientList.dtls.item(i).concernRoleID;
        concernRoleDtls = concernRoleObj.read(concernRoleKey);

        // BEGIN, CR00236214, PB
        languageLocaleMapKey.key.key.languageCode = concernRoleDtls.preferredLanguage;
        try {
          languageLocaleDetails.dtls = languageLocaleMapObj.readLanguageLocaleMap(
            languageLocaleMapKey.key);
        } catch (final RecordNotFoundException e) {// Do nothing
        }
        // END, CR00236214

        if (adminIntegratedCaseDtls.adminTranslationRequiredInd) {

          if (userSkillLanguageDetails.dtlsList.dtls.size() > 0) {
            for (int j = 0; j < userSkillLanguageDetails.dtlsList.dtls.size(); j++) {
              // BEGIN, CR00236214, PB
              if (userSkillLanguageDetails.dtlsList.dtls.item(j).languageCode.equals(
                concernRoleDtls.preferredLanguage)
                  || locale.equals(languageLocaleDetails.dtls.localeIdentifier)) {
                caseParticipantRoleDtls.translationRequiredInd = false;
              } // END, CR00236214
              else {
                caseParticipantRoleDtls.translationRequiredInd = true;
              }
            }
          } else {
            // BEGIN, CR00236214, PB
            if (concernRoleDtls.preferredLanguage.equals(CuramConst.gkEmpty)) {
              caseParticipantRoleDtls.translationRequiredInd = false;
            } else {
              if (locale.equals(languageLocaleDetails.dtls.localeIdentifier)) {
                caseParticipantRoleDtls.translationRequiredInd = false;
              } else {
                caseParticipantRoleDtls.translationRequiredInd = true;
              }
            }
            // END, CR00236214
          }
          // END, CR00213628
          // END, CR00216992
        }
      }
      // END, CR00208321

      if (dtls.translationRequiredInd) {
        caseParticipantRoleDtls.translationRequiredInd = dtls.translationRequiredInd;
      }

      caseParticipantRoleObj.insert(caseParticipantRoleDtls);
      if (caseParticipantRoleDtls.typeCode.equals(
        CASEPARTICIPANTROLETYPE.MEMBER)
          || caseParticipantRoleDtls.typeCode.equals(
            CASEPARTICIPANTROLETYPE.PRIMARY)) {
      
        ConcernRoleID concernRoleID = new ConcernRoleID();

        concernRoleID.concernRoleID = caseParticipantRoleDtls.participantRoleID;
        concernRoleIDList.dtls.addRef(concernRoleID);
      }
    }

    // insert case status details
    caseStatusDtls.caseStatusID = uniqueIDObj.getNextID();

    caseStatusDtls.caseID = caseHeaderDtls.caseID;
    caseStatusDtls.statusCode = caseHeaderDtls.statusCode;
    caseStatusDtls.startDate = caseHeaderDtls.startDate;
    // Set the user name
    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    caseStatusDtls.userName = systemUserObj.getUserDetails().userName;

    caseStatusObj.insert(caseStatusDtls);

    // return caseID
    integratedCaseIDKey.caseID = caseHeaderDtls.caseID;

    // If this integrated case is being created from a screening case
    // then create a case relationship record
    if (dtls.relatedCaseID != 0) {
      maintainCaseRelationshipDetails.caseID = caseHeaderDtls.caseID;
      maintainCaseRelationshipDetails.relatedCaseID = dtls.relatedCaseID;
      maintainCaseRelationshipDetails.primaryClientID = caseHeaderDtls.concernRoleID;
      maintainCaseRelationshipDetails.startDate = Date.getCurrentDate();
      maintainCaseRelationshipDetails.statusCode = RECORDSTATUS.NORMAL;
      maintainCaseRelationshipDetails.typeCode = CASERELATIONSHIPTYPECODE.INTEGSCREENING;
      maintainCaseRelationshipDetails.caseTypeCode = caseHeaderDtls.caseTypeCode;

      maintainCaseRelationshipDetails.reasonCode = CASERELATIONSHIPREASONCODE.DEFAULTCODE;

      // BEGIN, CR00221300, ZV
      maintainRelatedCasesObj.createCaseRelationship1(
        maintainCaseRelationshipDetails);
      // END, CR00221300

    }

    // BEGIN, CR00065924, AC
    final CaseIDConcernAndICTypeKey caseIDConcernAndICTypeKey = new CaseIDConcernAndICTypeKey();

    caseIDConcernAndICTypeKey.caseID = caseHeaderDtls.caseID;
    caseIDConcernAndICTypeKey.integratedCaseType = caseHeaderDtls.integratedCaseType;
    caseIDConcernAndICTypeKey.concernRoleID = caseHeaderDtls.concernRoleID;

    final EvidenceController evidenceControllerObj = EvidenceControllerFactory.newInstance();

    evidenceControllerObj.retrieveAndLinkPrtcptDataForIntegratedCase(
      caseIDConcernAndICTypeKey);
    // END, CR00065924,
    // BEGIN, CR00386292, AKr    
    CaseID caseID = new CaseID();

    caseID.caseID = caseHeaderDtls.caseID;
    evidenceVerificationImpl.getVerificationImpl().verifyParticipantEvidencesForCase(
      concernRoleIDList, caseID);
    // END, CR00386292
    // BEGIN, CR00022728, RR
    if (caseHeaderDtls.caseID != 0) {

      // Log Transaction Details
      // BEGIN CR00108134, GBA
      final CodeTableItemIdentifier caseTypeCodeTableItemIdentifier = new CodeTableItemIdentifier(
        CASETYPECODE.TABLENAME, caseHeaderDtls.caseTypeCode);

      final LocalisableString description = new LocalisableString(BPOCASEEVENTS.HEADER_CREATED).arg(caseTypeCodeTableItemIdentifier).arg(
        caseHeaderDtls.caseReference);

      // BEGIN CR00108593, GBA
      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTS.CASEHEADER_CREATED, description,
        caseHeaderDtls.caseID, CuramConst.kDefaultRelatedID);
      // END CR00108593
      // END CR00108134
    }
    // END, CR00022728

    return integratedCaseIDKey;
  }

  // END, CR00300347

  // BEGIN, CR00284804, CW
  // ___________________________________________________________________________
  /**
   * Perform security check for the given caseID. This will determine whether
   * the user has the necessary security rights to create the case.
   *
   * @param caseID
   * The case being created.
   * @param checkType
   * The type of check to be performed.
   *
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void checkCaseSecurity(final long caseID, final int checkType)
    throws AppException, InformationalException {

    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = caseID;

    if (kUserRead == checkType) {
      caseSecurityCheckKey.type = DataBasedSecurity.kReadSecurityCheck;
    } else {
      caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;
    }

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOEVIDENCECONTROLLER.ERR_CONTROLLER_CASE_SECURITY_CHECK_FAILED),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
  }

  // END, CR00284804

  // END, CR00205110
  /**
   * Returns client details list
   *
   * @param key
   * integrated case client list key
   *
   * @return integrated case client list
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public ICClientList getClientListDetails(final ICClientListKey key)
    throws AppException, InformationalException {

    // Integrated Case Client List
    final ICClientList iCClientList = new ICClientList();

    // Concern role entity, key and details
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls;

    // Address entity, key and details
    final curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    final AddressKey addressKey = new AddressKey();
    AddressDtls addressDtls;
    final OtherAddressData otherAddressData = new OtherAddressData();

    // elements of the ICClientList

    ClientListDetails clientListDetails;

    // variables for manipulating of integrated case client list
    curam.util.type.StringList ICClientIDStringList;

    ICClientIDStringList = curam.util.resources.StringUtil.tabText2StringList(
      key.caseClientList);

    for (int i = 0; i < ICClientIDStringList.size(); i++) {

      // read ConcernRole from database
      concernRoleKey.concernRoleID = java.lang.Long.parseLong(
        ICClientIDStringList.item(i));

      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      if (!concernRoleDtls.concernRoleType.equals(
        curam.codetable.CONCERNROLETYPE.SERVICESUPPLIER)) {

        // set Address key to ConcerRoleAddress details
        // struct addressID element
        addressKey.addressID = concernRoleDtls.primaryAddressID;
        addressDtls = addressObj.read(addressKey);

        // set address and name for client list
        otherAddressData.addressData = addressDtls.addressData;

        addressObj.getOneLineAddressString(otherAddressData);

        clientListDetails = new ClientListDetails();

        clientListDetails.address = otherAddressData.addressData;

        clientListDetails.concernFullName = concernRoleDtls.concernRoleName;
        clientListDetails.concernRoleID = concernRoleDtls.concernRoleID;
        clientListDetails.concernRoleType = concernRoleDtls.concernRoleType;

        if (concernRoleDtls.concernRoleType.equals(
          curam.codetable.CONCERNROLETYPE.PROSPECTPERSON)
            || concernRoleDtls.concernRoleType.equals(
              curam.codetable.CONCERNROLETYPE.PROSPECTEMPLOYER)) {

          clientListDetails.concernIsProspectInd = true;

        } else {

          clientListDetails.concernIsProspectInd = false;
        }

        iCClientList.dtls.addRef(clientListDetails);

      }

    }

    return iCClientList;
  }

  /**
   * Adds a product delivery case to the Integrated case
   *
   * @param ICkey
   * integrated caseID
   * @param key
   * the product delivery case details
   *
   * @return contains RegisterProductDeliveryDetails and
   * RegisterProductDeliveryKey
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public AddPDCaseToIntegratedCaseResult addPDCaseToIntegratedCase(
    final IntegratedCaseIDKey ICkey, final RegisterProductDeliveryKey key)
    throws AppException, InformationalException {

    // struct containing integrated case client list
    final AddPDCaseToIntegratedCaseResult addPDCaseToIntegratedCaseResult = new AddPDCaseToIntegratedCaseResult();

    // Data manipulation variables
    final MaintainCaseHeaderDetails maintainCaseHeaderDetails = new MaintainCaseHeaderDetails();

    // Object for creating product delivery
    final curam.core.intf.CreateProductDeliveryAssistant createProductDeliveryAssistantObj = CreateProductDeliveryAssistantFactory.newInstance();

    // object for creating product delivery for integrated case
    final curam.core.intf.CreatePDForIntegratedCase createPDForIntegratedCaseObj = curam.core.fact.CreatePDForIntegratedCaseFactory.newInstance();

    // concernRole manipulation variables
    final curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    PrimaryAddressBankAccountAndPrefPublicOffice primaryAddressBankAccountAndPrefPublicOffice;
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set the key value for the read.
    concernRoleKey.concernRoleID = key.clientID;

    // read concernRole entity
    primaryAddressBankAccountAndPrefPublicOffice = concernRoleObj.readPrimaryAddressBankAccountAndPrefPublicOffice(
      concernRoleKey);

    // set integrated Case ID for product delivery before calling
    // setServicePlan struct mapping
    maintainCaseHeaderDetails.caseID = ICkey.caseID;

    addPDCaseToIntegratedCaseResult.registerProductDeliveryDetails = createPDForIntegratedCaseObj.setICProductDelivery(
      key, maintainCaseHeaderDetails);

    createProductDeliveryAssistantObj.genericProductDelivery(key,
      maintainCaseHeaderDetails, primaryAddressBankAccountAndPrefPublicOffice);

    // invoke Verification Application to create verifications
    // for product delivery
    Class verificationFactoryObj;
    final curam.util.internal.codetable.intf.CodeTable codeTableInterface = CodeTableFactory.newInstance();
    final CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    ctitemKey.code = VERIFICATIONCONTROLLER.VC1;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = curam.codetable.VERIFICATIONCONTROLLER.TABLENAME;
    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC
    final String description = ctitem.description;
    VerificationInterface verificationObj = null;

    try {
      verificationFactoryObj = Class.forName(description);
      verificationObj = (VerificationInterface) verificationFactoryObj.newInstance();
    } catch (final ClassNotFoundException cnfe) {// Do Nothing
    } catch (final IllegalAccessException iae) {// Do Nothing
    } catch (final SecurityException se) {// Do Nothing
    } catch (final IllegalArgumentException iae) {// Do Nothing
    } catch (final InstantiationException ie) {// Do Nothing
    }

    final ProductDeliveryKey pdKey = new ProductDeliveryKey();

    pdKey.caseID = addPDCaseToIntegratedCaseResult.registerProductDeliveryDetails.caseID;
    final IntegratedCaseKey ICKey = new IntegratedCaseKey();

    ICKey.integratedCaseID = ICkey.caseID;

    verificationObj.createProductDeliveryVerifications(ICKey, pdKey);

    return addPDCaseToIntegratedCaseResult;
  }

  /**
   * Close this integrated case.
   *
   * @param ICClosureDtls
   * key Struct containing the closure details
   *
   * @throws AppException
   * @throws InformationalException
   */
  @Override
  public void closeIntegratedCase(final ICClosureDtls key) throws AppException,
      InformationalException {

    // BEGIN, CR00163245, MC
    // Modify and or raise the events required for case closure
    raiseCaseClosedEvent(key);

    // Modify the activities associated with this case
    cancelCaseActivities(key);

    // Perform validations on the case closure
    validateCloseCase(key);

    // Check the environment variable used to state if a case can be closed
    // with active tasks
    validateCloseCaseWithActiveTasks(key);

    //
    // Close the case
    //
    // CloseCase manipulation variables
    final curam.core.intf.CloseCase closeCaseObj = curam.core.fact.CloseCaseFactory.newInstance();
    final ClosureDtls closureDtls = new ClosureDtls();
    // BEGIN, CR00220971, ZV
    final UpdateCaseStatusReasonEndKey1 updateCaseStatusReasonEndKey = new UpdateCaseStatusReasonEndKey1();

    // END, CR00220971

    // update case status
    updateCaseStatusReasonEndKey.statusCode = curam.codetable.CASESTATUS.CLOSED;
    updateCaseStatusReasonEndKey.caseID = key.caseID;
    updateCaseStatusReasonEndKey.reasonCode = key.reasonCode;
    updateCaseStatusReasonEndKey.endDate = curam.util.type.Date.getCurrentDate();
    updateCaseStatusReasonEndKey.comments = key.comments;

    // Set the user name
    final curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    updateCaseStatusReasonEndKey.userName = systemUserObj.getUserDetails().userName;

    // BEGIN, CR00220971, ZV
    closeCaseObj.updateCaseStatus1(updateCaseStatusReasonEndKey);
    // END, CR00220971

    // create ticket
    closureDtls.closureDate = curam.util.type.Date.getCurrentDate();
    closureDtls.caseID = key.caseID;
    closureDtls.reasonCode = key.reasonCode;
    closureDtls.comments = key.comments;
    
    // BEGIN, CR00343325, AC
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    closeCaseObj.createTickets(closureDtls);
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    caseHeaderKey.caseID = closureDtls.caseID;
    CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    if (key.caseID != 0) {

      final CodeTableItemIdentifier caseTypeCodeTableItemIdentifier = new CodeTableItemIdentifier(
        CASETYPECODE.TABLENAME, caseHeaderDtls.caseTypeCode);

      final LocalisableString description = new LocalisableString(BPOCASEEVENTS.INTEGRATED_CASE_CLOSED).arg(caseTypeCodeTableItemIdentifier).arg(
        caseHeaderDtls.caseReference);

      caseTransactionLogProvider.get().recordCaseTransaction(
        CASETRANSACTIONEVENTSEntry.CASE_CLOSED.getCode(), description,
        caseHeaderDtls.caseID, CuramConst.kDefaultRelatedID);
    }
    // END, CR00343325
  }

  // END, CR00163245
  // BEGIN, CR00099541, PMD
  /**
   * Method to validate the integrated case creation details.
   *
   * @param details
   * the integrated case creation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void validateIntegratedCaseDetails(
    final IntegratedCaseRegistrationDetails details) throws AppException,
      InformationalException {

    // Client merge manipulation variables
    final ClientMerge clientMergeObj = ClientMergeFactory.newInstance();

    // Set the key to be that of the primary client
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = details.primaryClientID;

    // Check if the primary client has been marked as a duplicate
    final CuramInd curamInd = clientMergeObj.isConcernRoleDuplicate(
      concernRoleKey);

    // If the primary client is a duplicate, throw an exception
    if (curamInd.statusInd) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOCLIENTMERGE.ERR_CREATE_INTEGRATED_CASE_DUPLICATE_CLIENT),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00066601, NG
    // Users entity object
    // BEGIN, CR00081378, NG
    final curam.core.struct.UsersKey usersKey = new curam.core.struct.UsersKey();
    final curam.core.intf.MaintainUsers maintainUsersObj = curam.core.fact.MaintainUsersFactory.newInstance();

    // struct to hold details to determine user closed status
    SecurityResult securityResult = new SecurityResult();

    // If user is closed than not allowed to create case
    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();
    securityResult = maintainUsersObj.checkCloseUser(usersKey);
    if (!securityResult.result) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOINTEGRATEDCASE.ERR_CASE_CREATION_XFV_USER_IS_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00081378
    // END, CR00066601
  }

  // END, CR00099541

  // BEGIN, CR00162676, MC
  /**
   * Validate details of the case to be closed:
   *
   * @param key
   * ICClosureDtls The details to identify the case to be closed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void validateCloseCase(final ICClosureDtls key) throws AppException,
      InformationalException {

    // BEGIN, CR00226619, PM
    final DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    final CaseSecurityCheckKey caseSecurityCheckKey = new CaseSecurityCheckKey();

    caseSecurityCheckKey.caseID = key.caseID;
    caseSecurityCheckKey.type = DataBasedSecurity.kMaintainSecurityCheck;

    final DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkCaseSecurity1(
      caseSecurityCheckKey);

    if (!dataBasedSecurityResult.result) {
      if (dataBasedSecurityResult.readOnly) {
        throw new AppException(
          GENERALCASE.ERR_CASESECURITY_CHECK_READONLY_RIGHTS);
      } else if (dataBasedSecurityResult.restricted) {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_RIGHTS);
      } else {
        throw new AppException(GENERALCASE.ERR_CASESECURITY_CHECK_ACCESS_RIGHTS);
      }
    }
    // END, CR00226619

    // CaseHeader manipulation variables
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // CaseUserRole manipulation variables
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // read caseHeader
    final CaseSearchKey caseSearchKey = new CaseSearchKey();
    CaseReferenceAndStatusDetails caseReferenceAndStatusDetails;

    caseSearchKey.caseID = key.caseID;

    caseReferenceAndStatusDetails = caseHeaderObj.readCaseReferenceAndStatusByCaseID(
      caseSearchKey);

    if (caseReferenceAndStatusDetails.statusCode.equals(
      curam.codetable.CASESTATUS.CLOSED)) {
      final AppException e = new AppException(
        curam.message.BPOMAINTAINCASECLOSURE.ERR_CASEHEADER_FV_CASECLOSED);

      e.arg(caseReferenceAndStatusDetails.caseReference);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // BEGIN, CR00060051, PMD
    // Set the username to be the current user
    final UserNameKey currentUserKey = new UserNameKey();

    currentUserKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    // BEGIN, CR00068673, MG
    caseHeaderKey.caseID = key.caseID;
    // END, CROOO68673

    // Check if the user is the case owner or part of an
    // organization object that is the case owner
    final OwnerInd ownerInd = caseUserRoleObj.isUserCaseOwner(currentUserKey,
      caseHeaderKey);

    // Check if the user is a supervisor
    final IsUserSupervisor isUserSupervisor = caseUserRoleObj.isUserSupervisor(
      caseHeaderKey, currentUserKey);

    if (!ownerInd.ownerInd && !isUserSupervisor.isUserSupervisor) {

      final AppException e = new AppException(
        curam.message.BPOINTEGRATEDCASE.ERR_CASECLOSURE_XFV_USER);

      e.arg(caseReferenceAndStatusDetails.caseReference);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00060051
    // variable to store list of Case IDs
    final CaseIDDetailsList caseIDDetailsList = caseHeaderObj.searchListOfCaseIDs(
      caseHeaderKey);

    for (int i = 0; i < caseIDDetailsList.dtls.size(); i++) {

      caseHeaderKey.caseID = caseIDDetailsList.dtls.item(i).caseID;
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      // perform validation to check status is closed
      if (!caseHeaderDtls.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOMAINTAINCASECLOSURE.ERR_CASEHEADER_FV_CASEOPEN),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    }
  }

  /**
   * Validate if a case can be closed with active tasks or not.
   *
   * @param key
   * ICClosureDtls Details to identify the case being closed.
   *
   * @return InformationalMsgDtlsList an informational message stating that
   * there are active tasks on the closed case.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void validateCloseCaseWithActiveTasks(final ICClosureDtls key)
    throws InformationalException, AppException {

    //
    // The case cannot be closed while there are active tasks
    //
    final curam.core.sl.intf.WorkAllocationTask workAllocationTaskObj = curam.core.sl.fact.WorkAllocationTaskFactory.newInstance();

    // BEGIN, CR00159857, MC
    // Environment variable to define if a case can be closed without manually
    // closing all of the task on it first
    boolean closeCaseWithTasks = false;
    String closeCaseWithTasksProperty = Configuration.getProperty(
      EnvVars.ENV_CLOSE_CASE_WITH_TASKS);

    if (closeCaseWithTasksProperty.length() == 0
      || closeCaseWithTasksProperty == null) {
      closeCaseWithTasksProperty = EnvVars.ENV_CLOSE_CASE_WITH_TASKS_DEFAULT;
    }

    closeCaseWithTasks = closeCaseWithTasksProperty.equalsIgnoreCase(
      EnvVars.ENV_VALUE_YES);

    final SearchTaskForConcernOrCaseKey searchTaskForConcernOrCaseKey = new SearchTaskForConcernOrCaseKey();

    final SearchTasksForConcernAndCaseDetails searchTasksForConcernAndCaseDetails = new SearchTasksForConcernAndCaseDetails();

    searchTaskForConcernOrCaseKey.details.linkedID = key.caseID;

    searchTasksForConcernAndCaseDetails.dtls = workAllocationTaskObj.listCaseTasks(
      searchTaskForConcernOrCaseKey);

    final int numTasks = searchTasksForConcernAndCaseDetails.dtls.dtls.dtls.size();
    int numberOfTasks = numTasks;

    // check that each task is either COMPLETED or CLOSED (Closed is covered in
    // the query)
    for (int i = 0; i < numTasks; i++) {

      if (searchTasksForConcernAndCaseDetails.dtls.dtls.dtls.item(i).status.equals(
        TASKSTATUS.COMPLETED)) {
        numberOfTasks--;
      }
    }

    // If this task is not completed and the case cannot be closed with
    // outstanding tasks
    if (numberOfTasks > 0 && !closeCaseWithTasks) {

      // If any of the tasks for this case are not completed throw an exception
      throw (new AppException(
        curam.message.BPOCLOSECASE.ERR_CLOSECASE_ACTIVE_TASKS));
    }
    // END, CR00159857
  }

  /**
   * Raise and modify the case events associated with this case closure.
   *
   * @param key
   * ICClosureDtls Details to identify the case being closed.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void raiseCaseClosedEvent(final ICClosureDtls key)
    throws AppException, InformationalException {

    // CaseEvent manipulation variables
    final curam.core.intf.CaseEvent caseEventObj = curam.core.fact.CaseEventFactory.newInstance();
    final CaseEventKey caseEventKey = new CaseEventKey();
    CaseEventDtls caseEventDtls;
    final CaseEventByCaseIDKey caseEventByCaseIDKey = new CaseEventByCaseIDKey();
    CaseEventDtlsList caseEventDtlsList;

    // If Verification Workflow exist, Raise the workflow closeCase Event
    final Event dueDateChangedEvent = new Event();

    dueDateChangedEvent.eventKey = Verification.CaseClosed;
    dueDateChangedEvent.primaryEventData = key.caseID;
    dueDateChangedEvent.secondaryEventData = CuramConst.gkCaseClosed;

    EventService.raiseEvent(dueDateChangedEvent);

    // read all case events
    caseEventByCaseIDKey.caseID = key.caseID;
    caseEventDtlsList = caseEventObj.searchByCaseID(caseEventByCaseIDKey);

    for (int i = 0; i < caseEventDtlsList.dtls.size(); i++) {

      if (!caseEventDtlsList.dtls.item(i).statusCode.equals(
        curam.codetable.CASEEVENTSTATUS.CLOSED)) {

        caseEventDtls = caseEventDtlsList.dtls.item(i);

        caseEventKey.caseEventID = caseEventDtlsList.dtls.item(i).caseEventID;
        caseEventDtls.statusCode = curam.codetable.CASEEVENTSTATUS.CLOSED;

        // modify case event
        caseEventObj.modify(caseEventKey, caseEventDtls);
      }
    }
  }

  /**
   * Cancel the activities associated with this case.
   *
   * @param key
   * ICClosureDtls Details to identify the case being closed.
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws InformationalException
   * @throws AppException
   * Generic Exception Signature.
   * @throws AppException
   */
  @Override
  public void cancelCaseActivities(final ICClosureDtls key)
    throws AppException, InformationalException {

    // Activity manipulation variables
    final curam.core.intf.Activity activityObj = curam.core.fact.ActivityFactory.newInstance();
    final ActivityKey activityKey = new ActivityKey();
    ActivityDtls activityDtls = new ActivityDtls();
    final SearchActivityByCaseKey searchActivityByCaseKey = new SearchActivityByCaseKey();
    ActivityDtlsList activityDtlsList;

    // read all activities
    searchActivityByCaseKey.caseID = key.caseID;
    searchActivityByCaseKey.recordStatusCode = curam.codetable.RECORDSTATUS.NORMAL;

    try {
      activityDtlsList = activityObj.searchByCase(searchActivityByCaseKey);
    } catch (final ReadmultiMaxException readmultiMaxEx) {
      throw new AppException(
        curam.message.GENERAL.ERR_GENERAL_MAX_RECORDS_EXCEEDED);
    }

    for (int i = 0; i < activityDtlsList.dtls.size(); i++) {

      activityDtls = activityDtlsList.dtls.item(i);

      activityDtls.recordStatusCode = curam.codetable.RECORDSTATUS.CANCELLED;
      activityKey.activityID = activityDtlsList.dtls.item(i).activityID;

      // Modify activity.
      activityObj.modify(activityKey, activityDtls);
    }

  }

  // END, CR00162676
  // BEGIN, CR00168014, AK
  /**
   * Changes the Integrated case status to Open when the Product Delivery case
   * associated with it is reactivated.
   *
   * @param reactivationDtls
   * The case reactivation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void reopenCase(final ReactivationDtls reactivationDtls)
    throws AppException, InformationalException {
    final curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    final curam.core.intf.CloseCase closeCaseObj = curam.core.fact.CloseCaseFactory.newInstance();
    final curam.core.intf.MaintainCaseClosureAssistant maintainCaseClosureAssistantObj = curam.core.fact.MaintainCaseClosureAssistantFactory.newInstance();
    final curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();
    final UserNameKey userNameKey = new UserNameKey();

    // Read the Integrated Case Details.
    final CaseHeaderKey integratedCaseHeaderKey = new CaseHeaderKey();

    integratedCaseHeaderKey.caseID = reactivationDtls.caseID;
    userNameKey.userName = TransactionInfo.getProgramUser();

    // Update the Case Status to Open.
    if (curam.codetable.CASESTATUS.CLOSED.equals(
      caseHeaderObj.read(integratedCaseHeaderKey).statusCode)) {
      // BEGIN, CR00220971, ZV
      final UpdateCaseStatusReasonEndKey1 updateIntegratedCasekey = new UpdateCaseStatusReasonEndKey1();

      // END, CR00220971
      updateIntegratedCasekey.caseID = integratedCaseHeaderKey.caseID;
      updateIntegratedCasekey.endDate = curam.util.type.Date.kZeroDate;
      updateIntegratedCasekey.statusCode = curam.codetable.CASESTATUS.OPEN;
      updateIntegratedCasekey.reasonCode = "";
      // BEGIN, CR00220971, ZV
      closeCaseObj.updateCaseStatus1(updateIntegratedCasekey);
      // END, CR00220971

      // Check if the current user is the owner of the integrated case.
      final ReactivationDtls integratedCaseReactivationDtls = new ReactivationDtls();

      integratedCaseReactivationDtls.caseID = integratedCaseHeaderKey.caseID;
      if (!caseUserRoleObj.isUserCaseOwner(userNameKey, integratedCaseHeaderKey).ownerInd) {
        // Send the case owner notification of the case reactivation.
        maintainCaseClosureAssistantObj.createReactivationTicket(
          integratedCaseReactivationDtls);
      }
    }
  }

  // END, CR00168014

  // BEGIN, CR00282451, VMI
  /**
   * Reopens a closed integrated case.
   *
   * @param reactivationDtls
   * Details of the case being reopened.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void reopenICCase(final ReactivationDtls reactivationDtls)
    throws AppException, InformationalException {

    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final UserNameKey userNameKey = new UserNameKey();

    caseHeaderKey.caseID = reactivationDtls.caseID;
    final CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

    // Invokes the default validation on reopening of integrated case.
    validateCaseReopen(reactivationDtls);

    if (null != caseHeaderDtls.integratedCaseType) {
      final StringBuffer validatorKey = new StringBuffer(30);

      validatorKey.append(caseHeaderDtls.caseTypeCode);
      validatorKey.append(CuramConst.gkUnderscore);
      validatorKey.append(caseHeaderDtls.integratedCaseType);

      final IntegratedCaseValidator integratedCaseValidator = integratedCaseValidatorMap.get(
        validatorKey.toString());

      if (null != integratedCaseValidator) {
        // Invokes the customized validation for an integrated case type.
        integratedCaseValidator.validateCaseReopen(reactivationDtls);
      }
    }

    final CaseReactivationDtls caseReactivationDtls = new CaseReactivationDtls();
    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();
    final CaseReactivation caseReactivationObj = CaseReactivationFactory.newInstance();
    final CloseCaseEventKey closeCaseEventKey = new CloseCaseEventKey();
    final CloseCase closeCaseObj = CloseCaseFactory.newInstance();

    caseReactivationDtls.assign(reactivationDtls);
    if (Date.kZeroDate.equals(reactivationDtls.reactivationDate)) {
      caseReactivationDtls.reactivationDate = Date.getCurrentDate();
    }
    caseReactivationDtls.caseReactivationID = uniqueIDObj.getNextID();
    caseReactivationDtls.recordStatus = RECORDSTATUSEntry.DEFAULT().getCode();
    caseReactivationObj.insert(caseReactivationDtls);

    if (CASESTATUSEntry.CLOSED.getCode().equalsIgnoreCase(
      caseHeaderDtls.statusCode)) {
      closeCaseEventKey.caseID = reactivationDtls.caseID;
      closeCaseEventKey.eventTypeCode = CASEEVENTTYPEEntry.CASECLOSURE.getCode();
      closeCaseObj.closeCaseEvent(closeCaseEventKey);
    }

    final Event event = new Event();

    event.eventKey.eventClass = CASE.REOPEN_CASE.eventClass;
    event.eventKey.eventType = CASE.REOPEN_CASE.eventType;
    event.primaryEventData = reactivationDtls.caseID;
    EventService.raiseEvent(event);

    final UpdateCaseStatusReasonEndKey1 updateCaseStatusReasonEndKey = new UpdateCaseStatusReasonEndKey1();

    updateCaseStatusReasonEndKey.endDate = Date.kZeroDate;
    updateCaseStatusReasonEndKey.caseID = reactivationDtls.caseID;
    updateCaseStatusReasonEndKey.statusCode = CASESTATUSEntry.OPEN.getCode();
    updateCaseStatusReasonEndKey.reasonCode = reactivationDtls.reasonCode;

    final StringBuffer comments = new StringBuffer(30);

    comments.append(
      BPOMAINTAINPRODUCTDELIVERY.INF_CASE_REOPENED.getMessageText());
    comments.append(
      CodeTable.getOneItemForUserLocale(CASEREACTIVATEREASONEntry.TABLENAME,
      reactivationDtls.reasonCode));
    if (reactivationDtls.comments.trim().length() > 0) {
      comments.append(CuramConst.kSeparator);
      comments.append(reactivationDtls.comments);
    }

    updateCaseStatusReasonEndKey.comments = comments.toString();
    updateCaseStatusReasonEndKey.userName = TransactionInfo.getProgramUser();
    closeCaseObj.updateCaseStatus1(updateCaseStatusReasonEndKey);

    final MaintainCaseClosureAssistant maintainCaseClosureAssistantObj = MaintainCaseClosureAssistantFactory.newInstance();
    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();

    userNameKey.userName = TransactionInfo.getProgramUser();

    // If the user performing the action is not the case owner then
    // sends the case owner notification of the case reopen.
    if (!caseUserRoleObj.isUserCaseOwner(userNameKey, caseHeaderKey).ownerInd) {
      maintainCaseClosureAssistantObj.createReactivationTicket(reactivationDtls);
    }
    final LocalisableString description = new LocalisableString(BPOCASEEVENTS.INTEGRATED_CASE_REOPENED).arg(
      caseHeaderDtls.caseReference);

    caseTransactionLogProvider.get().recordCaseTransaction(
      CASETRANSACTIONEVENTSEntry.CASE_REOPENED.getCode(), description,
      reactivationDtls.caseID, reactivationDtls.caseID);
  }

  /**
   * Validates the case reopen functionality.
   *
   * @param reactivationDtls
   * Details of the case being reopened.
   *
   * @throws InformationalException
   * Generic Exception signature.
   * @throws AppException
   * {@link BPOMAINTAINCASECLOSURE#ERR_CASEREACTIVATION_REASON_EMPTY}
   * - if reason code not present.
   * @throws AppException
   * {@link BPOMAINTAINCASECLOSURE#ERR_CASEREACTIVATION_XRV_CASE_OWNER_CLOSED}
   * - if case owner is not active.
   * @throws AppException
   * {@link BPOMAINTAINCASECLOSURE#ERR_CASEREACTIVATION_CASESTATUS_INCORRECT}
   * - if case is not in closed state.
   */
  @Override
  protected void validateCaseReopen(final ReactivationDtls reactivationDtls)
    throws AppException, InformationalException {
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    if (0 == reactivationDtls.reasonCode.length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINCASECLOSURE.ERR_CASEREACTIVATION_REASON_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    caseHeaderKey.caseID = reactivationDtls.caseID;
    final CaseStatusCode caseStatusCode = caseHeaderObj.readCaseStatus(
      caseHeaderKey);

    // Only case with CLOSED status can be reactivated.
    if (!CASESTATUSEntry.CLOSED.getCode().equals(caseStatusCode.statusCode)) {
      final AppException appException = new AppException(
        BPOMAINTAINCASECLOSURE.ERR_CASEREACTIVATION_CASESTATUS_INCORRECT);

      appException.arg(
        CodeTable.getOneItem(CASESTATUSEntry.TABLENAME,
        caseStatusCode.statusCode, TransactionInfo.getProgramLocale()));
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        appException,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    final CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();
    final MaintainUsers maintainUsersObj = MaintainUsersFactory.newInstance();
    final UsersKey usersKey = new UsersKey();
    final CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(
      caseHeaderKey);

    usersKey.userName = caseOwnerDetails.userName;
    final SecurityResult securityResult = maintainUsersObj.checkCloseUser(
      usersKey);

    // If current case owner is closed then case can not be reactivated.
    if (!securityResult.result) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINCASECLOSURE.ERR_CASEREACTIVATION_XRV_CASE_OWNER_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // END, CR00282451
}
