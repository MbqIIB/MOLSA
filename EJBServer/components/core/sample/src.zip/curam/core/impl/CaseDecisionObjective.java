/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004, 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.text.DecimalFormatSymbols;
import java.util.Locale;

import curam.core.fact.CaseDecisionObjectiveFactory;
import curam.core.fact.CaseDecisionObjectiveOverflowFactory;
import curam.core.intf.CaseDecisionObjectiveOverflow;
import curam.core.struct.CaseDecisionComponentDecisionIDKey;
import curam.core.struct.CaseDecisionObjectiveDtls;
import curam.core.struct.CaseDecisionObjectiveDtlsList;
import curam.core.struct.CaseDecisionObjectiveKey;
import curam.core.struct.CaseDecisionObjectiveOverflowDtls;
import curam.core.struct.CaseDecisionObjectiveOverflowDtlsList;
import curam.core.struct.CaseDecisionObjectiveOverflowReadmultiKey;
import curam.core.struct.GetDecisionObjectiveByIDKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.ProgramLocale;
import curam.util.rules.FixedNumericFormatConversion;


/**
 * Maintenance class for case decision objective.
 */
public abstract class CaseDecisionObjective extends curam.core.base.CaseDecisionObjective {

  // BEGIN, CR00093733, CW
  /**
   * Max length of a string array element for compressed CaseDecisionObjective
   * relatedReference data 
   */
  protected static final int MAX_LENGTH = 4000;
  // END, CR00093733

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readDecisionObjectiveByID
   */
  public CaseDecisionObjectiveDtls getDecisionObjectiveByID(GetDecisionObjectiveByIDKey key)
    throws AppException, InformationalException {
    return CaseDecisionObjectiveFactory.newInstance().readDecisionObjectiveByID(
      key);
  }

  // BEGIN, CR00068167, KH
  // BEGIN, CR00093733, CW
  // ___________________________________________________________________________
  /**
   * Set unique ID prior to insert if not already specified. Also write any
   * CaseDecisionObjective relatedReference data overflow to the
   * database where present, and at the same time determine which part of the
   * relatedReference to be written to the CaseDecisionObjective table.
   * <p>
   * This method is also responsible for converting the localized objective
   * amount into the EN format for storage.
   *
   * @param caseDecisionObjectiveDtls case decision objective entity data for
   * insert.
   */
  protected void preinsert(CaseDecisionObjectiveDtls caseDecisionObjectiveDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00275981, KH
    /*
     * The value specified will have been localized. It must be stored in the
     * EN locale format, so it may need to be converted here.
     */
    
    // This is the locale used by the Money class to localize the amount
    Locale defaultLocale = ProgramLocale.parseLocale(
      ProgramLocale.getDefaultServerLocale());
    
    DecimalFormatSymbols defaultSymbols = new DecimalFormatSymbols(
      defaultLocale);
    String defGroupingSeparator = String.valueOf(
      defaultSymbols.getGroupingSeparator());
    DecimalFormatSymbols englishSymbols = new DecimalFormatSymbols(
      Locale.ENGLISH);
    
    String stringValue = caseDecisionObjectiveDtls.value;
    
    // Replace grouping separator(s) with empty string(s)
    stringValue = stringValue.replace(defGroupingSeparator, CuramConst.gkEmpty);
    // Replace decimal separator with EN decimal separator
    stringValue = stringValue.replace(defaultSymbols.getDecimalSeparator(), 
      englishSymbols.getDecimalSeparator());
    
    caseDecisionObjectiveDtls.value = stringValue;
    // END, CR00275981

    if (caseDecisionObjectiveDtls.caseDecisionObjectiveID == 0L) {

      caseDecisionObjectiveDtls.caseDecisionObjectiveID = curam.core.fact.UniqueIDFactory.newInstance().getNextID();
    }
    
    // Write any data overflow on relatedReference field to the overflow table
    final String relatedReference = caseDecisionObjectiveDtls.relatedReference;
    String[] relatedReferenceOverflowData = null;

    if (relatedReference.length() > MAX_LENGTH) {

      caseDecisionObjectiveDtls.overflowInd = true;
      // Turn the relatedReference field into a String array
      relatedReferenceOverflowData = stringToStringArray(relatedReference);
      // First item in the String array is used to populate the 
      // CaseDecisionObjective.relatedReference field
      caseDecisionObjectiveDtls.relatedReference = relatedReferenceOverflowData[0].toString();

      persistRelatedReferenceOverflowData(relatedReferenceOverflowData, 
        caseDecisionObjectiveDtls.caseDecisionObjectiveID);
    } else {
      // No overflow data necessary
      caseDecisionObjectiveDtls.overflowInd = false;
      caseDecisionObjectiveDtls.relatedReference = relatedReference;
    }
    // END, CR00093733
  }

  // END, CR00068167
  
  // BEGIN, CR00275981, KH
  // ___________________________________________________________________________
  /**
   * This method is responsible for converting the objective value from the
   * EN format back into its default locale.
   *
   * @param details Case decision objective tag entity data for insert.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Typical database exceptions.
   */
  protected void postinsert(CaseDecisionObjectiveDtls details)
    throws AppException, InformationalException {

    details.value = FixedNumericFormatConversion.convertEnglishFormatToMoney(details.value).toString();
  }

  // END, CR00275981

  // BEGIN, CR00093733, CW
  // ___________________________________________________________________________
  /**
   * Post read to read caseDecisionObjective relatedReference data overflow from
   * the database where present. It is also responsible for converting the 
   * objective amount from the EN format used when storing it on the database 
   * to the default locale.
   *
   * @param key the key containing the caseDecisionObjectiveID
   *
   * @param caseDecisionObjectiveDtls The details of the caseDecisionObjective
   * for which the relatedReference overflow is to be read from the database.
   * Also contains the value which must be converted to the default locale.
   *
   * @throws AppException Typical database exceptions.
   * @throws InformationalException Generic Exception Signature.
   */
  protected void postread(
    CaseDecisionObjectiveKey key, 
    CaseDecisionObjectiveDtls caseDecisionObjectiveDtls) 
    throws AppException, InformationalException {

    if (caseDecisionObjectiveDtls.overflowInd) {
      final String relatedReferenceString = readRelatedReferenceOverflowData(
        caseDecisionObjectiveDtls.relatedReference, 
        caseDecisionObjectiveDtls.caseDecisionObjectiveID);

      caseDecisionObjectiveDtls.relatedReference = relatedReferenceString;
    }
    
    // BEGIN, CR00275981, KH
    /*
     * The value on the database will be stored in the EN locale. It should
     * be converted to the default locale.
     */
    caseDecisionObjectiveDtls.value = FixedNumericFormatConversion.convertEnglishFormatToMoney(caseDecisionObjectiveDtls.value).toString();
    // END, CR00275981
  }

  // END, CR00093733

  // BEGIN, CR00093733, CW
  // ___________________________________________________________________________
  /**
   * Post search to read caseDecisionObjective relatedReference data overflow 
   * from the database where present for each of the records in the list. It is
   * also responsible for converting the objective amounts from the EN format
   * used when storing it on the database to the default locale.
   *
   * @param key the key containing the caseDecisionComponentDecisionID
   * @param caseDecisionObjectiveDtlsList List of details of the 
   * caseDecisionObjective for which the relatedReference overflow is to be 
   * read from the database and for which the value must be converted to the
   * default locale.
   *
   * @throws AppException Typical database exceptions.
   * @throws InformationalException Generic Exception Signature.
   */
  protected void postsearchByCaseDecisionID(
    CaseDecisionComponentDecisionIDKey key, 
    CaseDecisionObjectiveDtlsList caseDecisionObjectiveDtlsList) 
    throws AppException, InformationalException {

    // BEGIN, CR00101858, KH
    if (caseDecisionObjectiveDtlsList != null) {
    
      /*
       * For each item in the CaseDecisionObjectiveDtls list we need to go to
       * the overflow table to populate the relatedReference field
       */
      for (int i = 0; i < caseDecisionObjectiveDtlsList.dtls.size(); i++) {

        CaseDecisionObjectiveDtls caseDecisionObjectiveDtls = caseDecisionObjectiveDtlsList.dtls.item(
          i);
      
        // Read the overflow data where applicable
        if (caseDecisionObjectiveDtls.overflowInd) {
          final String relatedReferenceString = readRelatedReferenceOverflowData(
            caseDecisionObjectiveDtls.relatedReference, 
            caseDecisionObjectiveDtls.caseDecisionObjectiveID);

          caseDecisionObjectiveDtls.relatedReference = relatedReferenceString;
        }
        
        // BEGIN, CR00275981, KH
        /*
         * The value on the database will be stored in the EN locale. It should
         * be converted to the default locale.
         */
        caseDecisionObjectiveDtls.value = FixedNumericFormatConversion.convertEnglishFormatToMoney(caseDecisionObjectiveDtls.value).toString();
        // END, CR00275981
      } // end for i
    }
    // END, CR00101858
  }

  // END, CR00093733

  // BEGIN, CR00093733, CW
  // ___________________________________________________________________________
  /**
   * Pre remove to remove any caseDecisionObjective relatedReference data 
   * overflow from the database where present.
   *
   * @param key the unique key of the caseDecisionObjective for which the 
   * relatedReference overflow is to be removed from the database.
   *
   * @throws AppException Typical database exceptions.
   * @throws InformationalException Generic Exception Signature.
   */
  protected void preremove(CaseDecisionObjectiveKey key) 
    throws AppException, InformationalException {

    // Read overflowInd for the caseDecisionObjective
    CaseDecisionObjectiveDtls caseDecisionObjectiveDtls = readOverflowInd(key);

    if (caseDecisionObjectiveDtls.overflowInd) {

      final CaseDecisionObjectiveOverflow caseDecisionObjectiveOverflow = CaseDecisionObjectiveOverflowFactory.newInstance();

      caseDecisionObjectiveOverflow.removeAllEntriesForCaseDecisionObjective(
        key);
    }
  }

  // END, CR00093733

  // BEGIN, CR00093733, CW
  // ___________________________________________________________________________
  /**
   * Converts a string to a string array
   *
   * @param inputStr Input string to be converted
   * @return String array
   *
   * @throws AppException Typical database exceptions.
   * @throws InformationalException Generic Exception Signature.
   */
  public String[] stringToStringArray(String inputStr)
    throws AppException, InformationalException {

    // Check for null or empty input string
    if ((inputStr == null) || (inputStr.length() == 0)) {
      return new String[0];
    }

    // Calculate the size of the array
    int numberOfStrings = (inputStr.length() / MAX_LENGTH);

    if ((inputStr.length() % MAX_LENGTH) > 0) {
      numberOfStrings++;
    }

    // Set up string array based on calculated size
    String[] str = new String[numberOfStrings];

    for (int i = 0; i < numberOfStrings; i++) {

      // If we're on the last one
      if (numberOfStrings == (i + 1)) {

        // If the first element was the last one
        if (i == 0) {
          str[i] = inputStr.substring(0, inputStr.length());
        } else {
          str[i] = inputStr.substring(MAX_LENGTH * (i), inputStr.length());
        }

      } else {

        str[i] = inputStr.substring(MAX_LENGTH * (i), MAX_LENGTH * (i + 1));
      }
    }

    return str;
  }

  // END, CR00093733

  // BEGIN, CR00093733, CW
  // ___________________________________________________________________________
  /**
   * Persists caseDecisionObjective relatedReference data overflow to the 
   * database, done in the event of the relatedReference being too large to fit
   * in a single VARCHAR column in the database.
   *
   * @param relatedReferenceOverflowData a String array containing the process
   * instance relatedReference overflow data to be persisted.
   * @param caseDecisionObjectiveID the id of the caseDecisionObjective with 
   * which the relatedReference is associated.
   *
   * @throws AppException Typical database exceptions.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected static void persistRelatedReferenceOverflowData(
    final String[] relatedReferenceOverflowData, 
    final long caseDecisionObjectiveID)
    throws AppException, InformationalException {
    // END, CR00198672
    final CaseDecisionObjectiveOverflow caseDecisionObjectiveOverflow = CaseDecisionObjectiveOverflowFactory.newInstance();

    final CaseDecisionObjectiveOverflowDtls caseDecisionObjectiveOverflowDtls = new CaseDecisionObjectiveOverflowDtls();

    final int numberOfEntries = relatedReferenceOverflowData.length;

    for (int i = 1; i < numberOfEntries; i++) {

      // For each item in the array we insert a CaseDecisionObjectiveOverflow record
      caseDecisionObjectiveOverflowDtls.caseDecisionObjectiveID = caseDecisionObjectiveID;
      caseDecisionObjectiveOverflowDtls.sequenceNo = i - 1;
      caseDecisionObjectiveOverflowDtls.relatedReference = relatedReferenceOverflowData[i].toString();
      caseDecisionObjectiveOverflow.insert(caseDecisionObjectiveOverflowDtls);
    }
  }

  // END, CR00093733

  // BEGIN, CR00093733, CW
  // ___________________________________________________________________________
  /**
   * Reads caseDecisionObjective relatedReference data overflow from the 
   * database.
   *
   * @param relatedReference the String representing the caseDecisionObjective
   * relatedReference data object which the overflow data will be appended to.
   * @param caseDecisionObjectiveID the id of the caseDecisionObjective which 
   * the relatedReference data object is associated with.
   *
   * @return a String representing the whole relatedReference data object.
   *
   * @throws AppException Typical database exceptions.
   * @throws InformationalException Generic Exception Signature.
   */
  // BEGIN, CR00198672, VK
  protected static String readRelatedReferenceOverflowData(
    final String relatedReferenceString, final long caseDecisionObjectiveID)
    throws AppException, InformationalException {
    // END, CR00198672
    final CaseDecisionObjectiveOverflow caseDecisionObjectiveOverflow = CaseDecisionObjectiveOverflowFactory.newInstance();

    CaseDecisionObjectiveOverflowReadmultiKey entityKey = new CaseDecisionObjectiveOverflowReadmultiKey();

    entityKey.caseDecisionObjectiveID = caseDecisionObjectiveID;

    // Read all CaseDecisionObjectiveOverflow records for the caseDecisionObjectiveID
    final CaseDecisionObjectiveOverflowDtlsList caseDecisionObjectiveOverflowDtlsList = caseDecisionObjectiveOverflow.searchByCaseDecisionObjectiveID(
      entityKey);

    final int numberOfRecords = caseDecisionObjectiveOverflowDtlsList.dtls.size();

    final StringBuffer relatedReferenceWithOverflowDataStringBuffer = new StringBuffer(
      relatedReferenceString);

    for (int i = 0; i < numberOfRecords; i++) {
      // For each item in the list caseDecisionObjectiveOverflowDtlsList we take
      // relatedReference field and append to return String
      relatedReferenceWithOverflowDataStringBuffer.append(
        (caseDecisionObjectiveOverflowDtlsList.dtls.get(i)).relatedReference);
    }

    // Return the full relatedReference field
    return relatedReferenceWithOverflowDataStringBuffer.toString();
  }
  // END, CR00093733

}
