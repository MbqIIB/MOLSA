/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


/**
 * Constants for Deferred Processing Enactment
 *
 */
public abstract class DP_const {

  public static final String DP_ASSESS_CASE = new String("ASSESSCASE");

  public static final String DP_CLOSE_CASE = new String("CLOSECASE");

  public static final String DP_CREOLE_ELIGIBILITY_REASSESSMENT = new String(
    "CREOLEELIGIBILITYREASSESSMENT");

  public static final String DP_PUBLISH_RATE_CHANGES_TO_CREOLE_RULE_OBJECTS = new String(
    "PUBLISHRATECHANGESTOCREOLERULEOBJECTS");

  public static final String DP_PUBLISH_CREOLE_RULE_SET_CHANGES = new String(
    "PUBLISHCREOLERULESETCHANGES");

  public static final String DP_PUBLISH_CREOLE_PRODUCT_CHANGES = new String(
    "PUBLISHCREOLEPRODUCTCHANGES");

  public static final String DP_PUBLISH_PROPAGATOR_CONFIGURGATION_CHANGES = new String(
    "PUBLISHPROPCONFIGCHANGES");

  public static final String DP_CREOLE_RECALCULATION = new String(
    "CREOLERECALCULATION");

  public static final String DP_ELIGIBILITY_ASSESSMENT = new String(
    "ELIGIBILITYASSESSMENT");

  public static final String DP_MANUAL_PAYMENT_ALLOCATION = new String(
    "MANPMTALLOC");

  public static final String DP_PROCESS_LIABILITY = new String("PROCLBY");

  public static final String DP_PROCESS_PAYMENT = new String("PROCPMT");

  public static final String DP_PRODUCT_DELIVERY_APPROVAL = new String(
    "PDAPPROVAL");

  public static final String DP_REASSIGN_CASES = new String("REASSIGNCASES");

  public static final String DP_REGENERATE_CASE_FINANCIAL_COMPONENTS = new String(
    "REGENCASEFCS");

  public static final String DP_SUPPLIER_RETURN_PROCESSING = new String(
    "SUPPLIERRETURNPROCESSING");

  public static final String DP_TRANSFER_BANK_ACCOUNT_FOR_PAYMENT = new String(
    "TRANSFERBANKACCPAYMENT");

  public static final String DP_WORKFLOW_ERROR_HANDLING = new String(
    "Workflow Error Handling");
  
  // BEGIN, CR00232980, PMD
  public static final String DP_GEN_CASE_AUDITS = new String("GENCASEAUDITS");  
  // END, CR00232980
  
  // BEGIN, CR00275791, CW
  public static final String DP_GEN_PRODUCT_RULE_SET = new String(
    "GENPRODUCTRULESET");  
  // END, CR00275791
  
  
  // BEGIN, CR00298785, RB
  public static final String DP_PERFORM_DEFERRED_RECALCULATIONS_FROM_PRECEDENT_CHANGE_SET = new String(
    "PERFORM_DEFERRED_RECALCULATIONS_FROM_PRECEDENT_CHANGE_SET");  
  // END, CR00298785
}
