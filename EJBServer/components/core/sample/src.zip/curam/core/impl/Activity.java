/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.fact.ActivityFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.struct.ActivityDtls;
import curam.core.struct.SearchForActivityOverlapKey;
import curam.core.struct.UniqueIDKeySet;
import curam.message.BPOACTIVITY;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Any activity about which the organization would like to record information.
 */
public abstract class Activity extends curam.core.base.Activity {

  /**
   * Generates a unique activityID.
   *
   * @param details
   * Activity details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  protected void preinsert(final ActivityDtls details) throws AppException,
      InformationalException {

    // BEGIN, CR00225767, MR
    if (0 == details.activityID) {

      // BEGIN, CR00260989, MR
      final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

      // BEGIN, CR00293207, SS
      uniqueIDKeySet.keySetName = KeySets.KEY_SET_ACTIVITY;
      // END, CR00293207

      details.activityID = UniqueIDFactory.newInstance().getNextIDFromKeySet(
        uniqueIDKeySet);
      // END, CR00260989
    }
    // END, CR00225767
  }

  /**
   * Validates the Activity Details
   *
   * @param details
   * returned activity details
   */
  @Override
  protected void autovalidate(final ActivityDtls details) throws AppException,
      InformationalException {

    // Variable to keep account of whether there's a user etc for an
    // activity
    int count = 0;

    // Subject must not accept spaces

    if (details.subject.trim().length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_FV_SUBJECT_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Activity type must not be blank
    if (details.activityTypeCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_FV_TYPE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Start Date/time must not be blank
    if (details.startDateTime.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_FV_START_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // End Date/time must not be blank
    if (details.endDateTime.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_FV_END_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Priority must not be blank
    if (details.priorityCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_FV_PRIORITY_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Time status must not be blank
    if (details.timeStatusCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_FV_TIME_STATUS_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // End Date Time must not be before the start date/time
    if (details.endDateTime.before(details.startDateTime)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_XFV_END_DATE_TIME),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Location ID or location name must not be blank
    if ((details.locationID != 0) && (details.locationName.length() > 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_XFV_LOCATION),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // A user, or organization should be supplied
    // for an activity (but only one of them)
    if (details.userName.length() > 0) {
      count++;
    }

    if (details.organisationID != 0) {
      count++;
    }

    // if count == 0, then nothing was supplied
    // if count > 1, then more than one thing was supplied
    if (count != 1) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOACTIVITY.ERR_ACTIVITY_XFV_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  /**
   * Determines whether the input ID fields will be converted to a NULL value
   * for use in SQL and sets the indicator fields accordingly. This avoids the
   * need for database-specific CAST statements in the generated SQL.
   *
   * @param key
   * the key struct used for the read
   */
  @Override
  protected void presearchForAnyUserOverlap(final SearchForActivityOverlapKey key)
    throws AppException, InformationalException {
    key.activityIDIsNull = (key.activityID == 0);
    key.recurrenceIDIsNull = (key.recurrenceID == 0);
  }

  /**
   * Determines whether the input ID fields will be converted to a NULL value
   * for use in SQL and sets the indicator fields accordingly. This avoids the
   * need for database-specific CAST statements in the generated SQL.
   *
   * @param key
   * the key struct used for the read
   */
  @Override
  protected void presearchForAnyOrganisationOverlap(
    final SearchForActivityOverlapKey key) throws AppException,
      InformationalException {
    key.activityIDIsNull = (key.activityID == 0);
    key.recurrenceIDIsNull = (key.recurrenceID == 0);
  }

  /**
   * @superseded - replaced by readLatestUserOverlap
   */
  @Override
  public curam.core.struct.OverlapResult searchForLatestUserOverlap(
    final curam.core.struct.SearchForActivityOverlapKey key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {
    return ActivityFactory.newInstance().readLatestUserOverlap(key);
  }

  /**
   * @superseded - replaced by readEarliestUserOverlap
   */
  @Override
  public curam.core.struct.OverlapResult searchForEarliestUserOverlap(
    final curam.core.struct.SearchForActivityOverlapKey key)
    throws curam.util.exception.AppException,
      curam.util.exception.InformationalException {
    return ActivityFactory.newInstance().readEarliestUserOverlap(key);
  }
}
