/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.Comparator;

import com.google.inject.Inject;

import curam.codetable.BATCHPROCESSNAME;
import curam.codetable.CASESTATUS;
import curam.codetable.PRODUCTCOVERPERIOD;
import curam.codetable.RECORDSTATUS;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.GenerateInstructionLineItemsFactory;
import curam.core.fact.MaintainFinancialComponentFactory;
import curam.core.fact.ProductDeliveryPatternInfoFactory;
import curam.core.fact.UsersFactory;
import curam.core.intf.CaseHeader;
import curam.core.intf.ProductDeliveryPatternInfo;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.struct.CaseNomineeProdDelPatternDtls;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.ReadEffectiveByDateKey;
import curam.core.sl.infrastructure.assessment.codetable.impl.CASEASSESSMENTDETERMINATIONREASONEntry;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngineEntity;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculator;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculatorFactory;
import curam.core.sl.infrastructure.impl.TaskDefinitionIDConst;
import curam.core.sl.infrastructure.propagator.impl.CERMetaDataLoadUtility;
import curam.core.struct.Amount;
import curam.core.struct.BatchProcessStreamKey;
import curam.core.struct.BatchProcessingID;
import curam.core.struct.BatchProcessingSkippedRecord;
import curam.core.struct.BatchProcessingSkippedRecordList;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseID;
import curam.core.struct.CaseNomineeAmountList;
import curam.core.struct.CaseStatusCode;
import curam.core.struct.DateStruct;
import curam.core.struct.DetermineEligibilityKey;
import curam.core.struct.FCCaseID;
import curam.core.struct.FCCaseIDDateRangeStatusMOD;
import curam.core.struct.FCCoverDate;
import curam.core.struct.FCProcessingDtls;
import curam.core.struct.FinCompCoverPeriod;
import curam.core.struct.FinancialComponentDtlsList;
import curam.core.struct.FinancialProcessingDetails;
import curam.core.struct.GenILIsProcessChunkResult;
import curam.core.struct.GenerateInstructionLineItemsKey;
import curam.core.struct.GetDateRangeForFCRetrievalKey;
import curam.core.struct.GetDateRangeForFCRetrievalResult;
import curam.core.struct.PDPIByProdDelPatIDStatusAndDateKey;
import curam.core.struct.ProcessCounters;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryPatternInfoDtls;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductFinancialDtlsSumm;
import curam.core.struct.ProductFinancialDtlsSummList;
import curam.core.struct.ProductKey;
import curam.core.struct.SimulateInd;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.FrequencyPattern;
import curam.util.type.NotFoundIndicator;


/**
 * Batch module to identify Financial Components to process.
 */
public abstract class GenerateInstructionLineItemsStream extends curam.core.base.GenerateInstructionLineItemsStream {

  protected static final GenILIsProcessChunkResult totalGenILIsProcessChunkResult = new GenILIsProcessChunkResult();

  // BEGIN, CR00174295, CD
  @Inject
  protected DeterminationCalculatorFactory determinationCalculatorFactory;

  /**
   * Constructor.
   */
  public GenerateInstructionLineItemsStream() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00211744, VM
  @Inject
  protected AssessmentEngineEntity assessmentEngineEntity;
  // END, CR00211744

  // ___________________________________________________________________________
  /**
   * Comparator for ProductFinancialDtlsSumm struct, comparison
   * based on productID
   */
  public class ProductFinancialDtlsSummComparator implements
    Comparator<ProductFinancialDtlsSumm> {

    public int compare(ProductFinancialDtlsSumm o1, ProductFinancialDtlsSumm o2) {

      return (o1.productID == o2.productID)
        ? 0
        : (o1.productID < o2.productID) ? -1 : 1;
    }
  }

  // ___________________________________________________________________________
  /**
   * This method is the driver for this processing. It looks up the
   * current instance of the batch program and processes chunks of
   * data until no further chunks exist to be processed.
   *
   * @param batchProcessStreamKey
   * The identifier for the instance of the batch program
   * (if any)
   */
  public void process(BatchProcessStreamKey batchProcessStreamKey)
    throws AppException, InformationalException {

    // BEGIN, CR00390475, SD
    final CERMetaDataLoadUtility loadObj = new CERMetaDataLoadUtility();

    loadObj.loadCERRuleSetCache();
    // END, CR00390475
    
    BatchStreamHelper batchStreamHelper = new BatchStreamHelper();
    GenerateInstructionLineItemsStreamWrapper generateInstructionLineItemsStreamWrapper = new GenerateInstructionLineItemsStreamWrapper(
      this);

    // register the security implementation
    SecurityImplementationFactory.register();

    if (batchProcessStreamKey.instanceID.length() == 0) {

      batchProcessStreamKey.instanceID = BATCHPROCESSNAME.GENERATE_ILIS;

    }

    batchStreamHelper.runStream(batchProcessStreamKey,
      generateInstructionLineItemsStreamWrapper);

  }

  // ___________________________________________________________________________
  /**
   * This method returns the result of processing this chunk as a
   * string
   *
   * @param skippedCasesCount
   * The number of cases skipped in this chunk
   */
  public String getChunkResult(int skippedCasesCount)
    throws AppException, InformationalException {

    StringBuffer result = new StringBuffer();

    totalGenILIsProcessChunkResult.casesSkippedCount += skippedCasesCount;

    result.append(totalGenILIsProcessChunkResult.caseProcessCount);
    result.append(CuramConst.gkTabDelimiterChar);
    result.append(totalGenILIsProcessChunkResult.casesSkippedCount);
    result.append(CuramConst.gkTabDelimiterChar);
    result.append(totalGenILIsProcessChunkResult.fcProcessCount);
    result.append(CuramConst.gkTabDelimiterChar);
    result.append(totalGenILIsProcessChunkResult.iliCreatedCount);

    // reset the values in totalGenILIsProcessChunkResult
    totalGenILIsProcessChunkResult.caseProcessCount = 0;
    totalGenILIsProcessChunkResult.casesSkippedCount = 0;
    totalGenILIsProcessChunkResult.fcProcessCount = 0;
    totalGenILIsProcessChunkResult.iliCreatedCount = 0;

    return result.toString();

  }

  // ___________________________________________________________________________
  /**
   * This method generates the instruction line items due for a
   * case, reassessing it once over the entire period covered by
   * all the instruction line items to be generated for the case.
   *
   * @param batchProcessingID
   * The details of the case to be processed
   * @param generateInstructionLineItemsKey
   * The key for this batch program
   */
  public BatchProcessingSkippedRecord processRecord(
    BatchProcessingID batchProcessingID,
    GenerateInstructionLineItemsKey generateInstructionLineItemsKey)
    throws AppException, InformationalException {

    // caseHeader manipulation variables
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    caseHeaderKey.caseID = batchProcessingID.recordID;
    // BEGIN, CR00281980, AC
    NotFoundIndicator nfIndicator = new NotFoundIndicator();
    CaseStatusCode caseStatusCode = caseHeaderObj.readStatus(nfIndicator,
      caseHeaderKey);

    if (!nfIndicator.isNotFound()) {
      // END, CR00281980

      // BEGIN, CR00029067, RPM
      /*
       * Issue: Case still pays out even though case has been
       * closed
       *
       * Fix : The conditions that existed in Online(Interactive)
       * Payment Generation have been replicated here.
       */
      // BEGIN, CR00102570, CW
      /*
       * No financial components should be processed if the case
       * status is suspended and the
       * curam.miscapp.payuptosuspendeddate property is set to NO.
       */
      Boolean issuePaymentToSuspendDate = Configuration.getBooleanProperty(
        EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE,
        Configuration.getBooleanProperty(
          EnvVars.ENV_ISSUE_PAYMENTS_TO_SUSPENDED_DATE_DEFAULT));

      /*
       * No financial components should be processed if the case
       * status is closed and the curam.miscapp.payuptocloseddate
       * property is set to NO.
       */
      Boolean issuePaymentToClosedDate = Configuration.getBooleanProperty(
        EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE,
        Configuration.getBooleanProperty(
          EnvVars.ENV_ISSUE_PAYMENTS_TO_CLOSED_DATE_DEFAULT));

      /*
       * If the property that indicates whether or not a suspended
       * case should be paid up to the suspension date is not true
       * AND the property indicating whether or not a closed case
       * should be paid up to closure date is not true then we only
       * pay active and pending closure cases.
       */

      if (!issuePaymentToSuspendDate && !issuePaymentToClosedDate) {

        // BEGIN, CR00281980, AC
        if (!caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)
          && !caseStatusCode.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {
          // END, CR00281980


          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOGENERATEPAYMENT.ERR_GENPAYMENT_ACTIVEPENDINGCLOSURECASES_ONLY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
        }

      } else if (issuePaymentToSuspendDate && !issuePaymentToClosedDate) {

        /*
         * If the property that indicates whether or not a
         * suspended case should be paid up to the suspension date
         * is true AND the property indicating whether or not a
         * closed case should be paid up to closure date is not
         * true then we only pay active, suspended and pending
         * closure cases.
         */
        // BEGIN, CR00281980, AC
        if (!caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)
          && !caseStatusCode.statusCode.equals(CASESTATUS.SUSPENDED)
          && !caseStatusCode.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {
          // END, CR00281980

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOGENERATEPAYMENT.ERR_GENPAYMENT_ACTIVESUSPENDEDCASES_ONLY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
        }

      } else if (!issuePaymentToSuspendDate && issuePaymentToClosedDate) {

        /*
         * If the property that indicates whether or not a
         * suspended case should be paid up to the suspension date
         * is not true AND the property indicating whether or not a
         * closed case should be paid up to closure date is true
         * then we only pay active, closed and pending closure
         * cases.
         */
        // BEGIN, CR00281980, AC
        if (!caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)
          && !caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)
          && !caseStatusCode.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {
          // END, CR00281980

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOGENERATEPAYMENT.ERR_GENPAYMENT_ACTIVECLOSEDCASES_ONLY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
        }

      } else {

        /*
         * If the property that indicates whether or not a
         * suspended case should be paid up to the suspension date
         * is true AND the property indicating whether or not a
         * closed case should be paid up to closure date is true
         * then we only pay active, suspended, closed and pending
         * closure cases.
         */
        // BEGIN, CR00281980, AC
        if (!caseStatusCode.statusCode.equals(CASESTATUS.ACTIVE)
          && !caseStatusCode.statusCode.equals(CASESTATUS.SUSPENDED)
          && !caseStatusCode.statusCode.equals(CASESTATUS.CLOSED)
          && !caseStatusCode.statusCode.equals(CASESTATUS.PENDINGCLOSURE)) {
          // END, CR00281980


          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOGENERATEPAYMENT.ERR_GENPAYMENT_ACTIVESUSPENDEDCLOSEDCASES_ONLY),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
        }
      }
      // END, CR00102570
      // END, CR00029067
    }

    GenILIsProcessChunkResult genILIsProcessChunkResult = new GenILIsProcessChunkResult();
    FCCaseIDDateRangeStatusMOD fcCaseIDDateRangeStatusMOD = new FCCaseIDDateRangeStatusMOD();
    FinancialComponentDtlsList financialComponentDtlsList = new FinancialComponentDtlsList();
    ProcessCounters processCounters;
    ProductFinancialDtlsSummList productFinancialDtlsSummList = new ProductFinancialDtlsSummList();
    DateStruct inputDate = new DateStruct();
    DateStruct calculatedDate = new DateStruct();
    curam.core.intf.MaintainFinancialCalendar maintainFinancialCalendarObj = curam.core.fact.MaintainFinancialCalendarFactory.newInstance();
    curam.core.intf.MaintainFinancialComponent maintainFinancialComponentObj = curam.core.fact.MaintainFinancialComponentFactory.newInstance();
    curam.core.intf.ProcessFinancialComponent processFinancialComponentObj = curam.core.fact.ProcessFinancialComponentFactory.newInstance();
    curam.core.intf.FinancialComponent financialComponentObj = curam.core.fact.FinancialComponentFactory.newInstance();
    FinCompCoverPeriod finCompCoverPeriod;
    DetermineEligibilityKey determineEligibilityKey = new DetermineEligibilityKey();
    FinancialProcessingDetails finProcessingDetails = new FinancialProcessingDetails();

    // Variables to hold the sorted FCs
    FinancialComponentDtlsList utilityDeductionFCDtlsList = new FinancialComponentDtlsList();
    FinancialComponentDtlsList primaryFCDtlsList = new FinancialComponentDtlsList();

    // reset the from & to date of the reassessment
    determineEligibilityKey.toDate = Date.kZeroDate;
    determineEligibilityKey.fromDate = Date.kZeroDate;

    // Read all FCs for this case (by CaseID, status & due date
    // range)
    fcCaseIDDateRangeStatusMOD.caseID = batchProcessingID.recordID;
    fcCaseIDDateRangeStatusMOD.statusCode = curam.codetable.FINCOMPONENTSTATUS.LIVE;
    fcCaseIDDateRangeStatusMOD.nomineeDelivMethod = generateInstructionLineItemsKey.deliveryMethod;

    // BEGIN, CR00180684, VM
    /*
     * Perform a sanity check here processingDateFrom and
     * processingDateTo should be populated at this point, but we
     * need to make sure
     */
    if (generateInstructionLineItemsKey.processingDateFrom.isZero()
      && generateInstructionLineItemsKey.processingDateTo.isZero()) {
      GenerateInstructionLineItemsFactory.newInstance().setProcessingDates(
        generateInstructionLineItemsKey);
    }
    // END, CR00180684

    fcCaseIDDateRangeStatusMOD.processingDateFrom = generateInstructionLineItemsKey.processingDateFrom;
    fcCaseIDDateRangeStatusMOD.processingDateTo = generateInstructionLineItemsKey.processingDateTo;

    // GenerateInstructionLineItems business layer object
    curam.core.intf.GenerateInstructionLineItems generateInstructionLineItemsObj = curam.core.fact.GenerateInstructionLineItemsFactory.newInstance();
    GetDateRangeForFCRetrievalKey getDateRangeForFCRetrievalKey = new GetDateRangeForFCRetrievalKey();

    // Set key to retrieve date range
    getDateRangeForFCRetrievalKey.dateFrom = generateInstructionLineItemsKey.processingDateFrom;
    getDateRangeForFCRetrievalKey.dateTo = generateInstructionLineItemsKey.processingDateTo;

    // Call method to retrieve the date range to search for FCs
    GetDateRangeForFCRetrievalResult getDateRangeForFCRetrievalResult = generateInstructionLineItemsObj.getDateRangeForFCRetrieval(
      getDateRangeForFCRetrievalKey);

    fcCaseIDDateRangeStatusMOD.processingDateFrom = getDateRangeForFCRetrievalResult.dateFrom;
    fcCaseIDDateRangeStatusMOD.processingDateTo = getDateRangeForFCRetrievalResult.dateTo;

    /*
     * Retrieve list of caseIDs to be processed based on the key
     * calculated above
     */
    financialComponentDtlsList = financialComponentObj.getDetailsForGenerateILIsCase(
      fcCaseIDDateRangeStatusMOD);

    ProductFinancialDtlsSumm productFinancialDtlsSumm = getProductFinancialDtlsSumm(
      batchProcessingID);

    /*
     * Determine the earliest coverFromDate and latest coverToDate
     * for the payments to be issued. This will be used as the
     * cover period of any deductions and also for reassessment (if
     * required).
     */
    for (int j = 0; j < financialComponentDtlsList.dtls.size(); j++) {

      /*
       * Related FC types should not be included in this processing
       * as they are applied based on the base FC
       */
      if (!((financialComponentDtlsList.dtls.item(j).categoryCode.equals(
        curam.codetable.FINCOMPONENTCATEGORY.HOUSEHOLDBUDGETITEM))
          || (financialComponentDtlsList.dtls.item(j).categoryCode.equals(
            curam.codetable.FINCOMPONENTCATEGORY.CASEDEDUCTIONITEM)))) {

        finCompCoverPeriod = maintainFinancialComponentObj.calculateFullCoverPeriod(
          financialComponentDtlsList.dtls.item(j), productFinancialDtlsSumm,
          generateInstructionLineItemsKey.processingDateTo);

        // work out the earliest FromDate
        if (determineEligibilityKey.fromDate.isZero()
          || determineEligibilityKey.fromDate.after(
            finCompCoverPeriod.coverPeriodFrom)) {

          determineEligibilityKey.fromDate = finCompCoverPeriod.coverPeriodFrom;
        }

        // work out the latest ToDate
        if (determineEligibilityKey.toDate.isZero()
          || determineEligibilityKey.toDate.before(
            finCompCoverPeriod.coverPeriodTo)) {

          determineEligibilityKey.toDate = finCompCoverPeriod.coverPeriodTo;
        }
      }
    }

    // BEGIN, CR00088799, CM
    /*
     * If the from and to dates are null here, it indicates that no
     * 'Primary' FCs exist for the period being paid. This does not
     * necessarily mean the non-existence of 'Secondary' FCs, i.e.
     * deduction based. However, assessing the case at this point
     * is not really possible (without the dates) and it's probably
     * a performance gain in not assessing the case when there is
     * no payment due.
     */
    if (determineEligibilityKey.fromDate.isZero()
      && (determineEligibilityKey.toDate.isZero())) {
      return null;
    }
    // END, CR00088799

    final boolean hasDecisionChanged;

    // Only reassess the case if needed
    if (!financialComponentDtlsList.dtls.isEmpty()) {

      final DeterminationCalculator determinationCalculator = determinationCalculatorFactory.newInstanceForCaseID(
        batchProcessingID.recordID);

      determineEligibilityKey.caseID = batchProcessingID.recordID;
      determineEligibilityKey.reconciliationInd = false;
      // BEGIN, CR00404897, CW
      // Only reassess the case if needed
      if (Configuration.getBooleanProperty(
        EnvVars.ENV_GENERATEINSTRUCTIONLINEITEMS_DONT_REASSESS_CASE)) {
        
        hasDecisionChanged = false;
      } else {
        
        // reassess Curam Rules case
        hasDecisionChanged = determinationCalculator.hasDecisionChanged(
          determineEligibilityKey,
            CASEASSESSMENTDETERMINATIONREASONEntry.CASEREASSESSMENT);
      }
      // END, CR00404897
      
    } else {
      hasDecisionChanged = false;
    }

    /*
     * if the decision has changed we need to re-read the
     * financials
     */
    if (hasDecisionChanged) {

      financialComponentDtlsList = financialComponentObj.getDetailsForGenerateILIsCase(
        fcCaseIDDateRangeStatusMOD);

      productFinancialDtlsSumm = getProductFinancialDtlsSumm(batchProcessingID);

      /*
       * Re-evaluate from and to dates after reassessment has
       * completed
       */
      determineEligibilityKey.fromDate = Date.kZeroDate;
      determineEligibilityKey.toDate = Date.kZeroDate;

      for (int j = 0; j < financialComponentDtlsList.dtls.size(); j++) {

        /*
         * Related FC types should not be included in this
         * processing as they are applied based on the base FC
         */
        if (!((financialComponentDtlsList.dtls.item(j).categoryCode.equals(
          curam.codetable.FINCOMPONENTCATEGORY.HOUSEHOLDBUDGETITEM))
            || (financialComponentDtlsList.dtls.item(j).categoryCode.equals(
              curam.codetable.FINCOMPONENTCATEGORY.CASEDEDUCTIONITEM)))) {

          finCompCoverPeriod = maintainFinancialComponentObj.calculateFullCoverPeriod(
            financialComponentDtlsList.dtls.item(j), productFinancialDtlsSumm,
            generateInstructionLineItemsKey.processingDateTo);

          // work out the earliest FromDate
          if (determineEligibilityKey.fromDate.isZero()
            || determineEligibilityKey.fromDate.after(
              finCompCoverPeriod.coverPeriodFrom)) {

            determineEligibilityKey.fromDate = finCompCoverPeriod.coverPeriodFrom;
          }

          // work out the latest ToDate
          if (determineEligibilityKey.toDate.isZero()
            || determineEligibilityKey.toDate.before(
              finCompCoverPeriod.coverPeriodTo)) {

            determineEligibilityKey.toDate = finCompCoverPeriod.coverPeriodTo;
          }
        }
      } // end for j
    }

    // Process FCs
    if (!recordAlreadyInFinancialSummList(productFinancialDtlsSummList,
      productFinancialDtlsSumm)) {

      productFinancialDtlsSummList.dtls.addRef(productFinancialDtlsSumm);

    }

    inputDate.date = generateInstructionLineItemsKey.processingDateTo;

    // Sort the FCs
    maintainFinancialComponentObj.sortFCsByFinCompType(
      financialComponentDtlsList, utilityDeductionFCDtlsList, primaryFCDtlsList);

    if (utilityDeductionFCDtlsList.dtls.size() > 0) {

      utilityDeductionFCDtlsList = maintainFinancialComponentObj.orderDeductionFCsByPriority(
        utilityDeductionFCDtlsList);
    }

    /*
     * Variable to hold the payments amounts per component for each
     * nominee
     */
    CaseNomineeAmountList paymentAmountList = new CaseNomineeAmountList();
    // BEGIN, CR00019290, KH
    /*
     * Variable to hold the tax amounts per component for each
     * nominee
     */
    CaseNomineeAmountList taxAmountList = new CaseNomineeAmountList();
    // END, CR00019290

    // Variable to hold the total payment amount
    curam.util.type.Money paymentTotal = curam.util.type.Money.kZeroMoney;
    // BEGIN, CR00019290, KH
    // Variable to hold the total tax amount
    curam.util.type.Money taxTotal = curam.util.type.Money.kZeroMoney;
    // END, CR00019290

    // Variables to hold date manipulation variables
    curam.util.type.Date latestDueDate = new curam.util.type.Date();
    curam.util.type.Date latestNextProcessingDate = new curam.util.type.Date();

    // Now process the primary FCs
    for (int j = 0; j < primaryFCDtlsList.dtls.size(); j++) {

      finProcessingDetails.deliveryMethodType = primaryFCDtlsList.dtls.item(j).nomineeDelivMethod;
      finProcessingDetails.processingDate = generateInstructionLineItemsKey.processingDateTo;
      calculatedDate.date = maintainFinancialCalendarObj.getNextValidDate(finProcessingDetails).nextValidDate;

      /*
       * If the next valid date for the specified delivery method
       * and processing date is greater than or equal to the FCs
       * next processing date, process the component
       */
      if (!calculatedDate.date.before(
        primaryFCDtlsList.dtls.item(j).nextProcessingDate)) {

        processCounters = processFinancialComponentObj.processComponent(
          primaryFCDtlsList.dtls.item(j), productFinancialDtlsSummList,
          inputDate, calculatedDate);

        genILIsProcessChunkResult.iliCreatedCount += processCounters.countILIsCreated;
        genILIsProcessChunkResult.fcProcessCount += processCounters.countFCsProcessed;

        // Variable to hold the current payment amount
        Amount amount = new Amount();

        amount.amount = processCounters.paymentTotal;

        // Add this amount to the payment amounts for the nominee
        maintainFinancialComponentObj.setCaseNomineePaymentAmount(
          primaryFCDtlsList.dtls.item(j), paymentAmountList, amount);

        /*
         * Add the amount returned from this FC to the total
         * payment amount
         */
        paymentTotal = new curam.util.type.Money(
          paymentTotal.getValue() + processCounters.paymentTotal.getValue());

        // BEGIN, CR00019290, KH
        amount.amount = processCounters.taxTotal;

        // Add this amount to the tax amounts for the nominee
        maintainFinancialComponentObj.setCaseNomineePaymentAmount(
          primaryFCDtlsList.dtls.item(j), taxAmountList, amount);

        /*
         * Add the tax amount returned from this FC to the total
         * tax amount
         */
        taxTotal = new curam.util.type.Money(
          taxTotal.getValue() + processCounters.taxTotal.getValue());
        // END, CR00019290

        /*
         * Check the dates returned from this FC against the latest
         * dates
         */
        if (processCounters.fcDates.dueDate.after(latestDueDate)) {
          latestDueDate = processCounters.fcDates.dueDate;
        }
        if (processCounters.fcDates.nextProcessingDate.after(
          latestNextProcessingDate)) {
          latestNextProcessingDate = processCounters.fcDates.nextProcessingDate;
        }
      }

    } // end for j

    /*
     * Have we processed any payment FCs and do we have any
     * deductions?
     */
    if (!latestNextProcessingDate.isZero()
      && (utilityDeductionFCDtlsList.dtls.size() != 0)) {

      /*
       * We have processed at least one payment FC so we can
       * consider deductions and utility payments now
       */
      productFinancialDtlsSummList.amounts.paymentTotal = new curam.util.type.Money(
        paymentTotal.getValue());
      productFinancialDtlsSummList.deductionAmount.amount = curam.util.type.Money.kZeroMoney;

      /*
       * Assign nominee payment amounts for use during deduction
       * processing
       */
      productFinancialDtlsSummList.amounts.nomineePaymentAmountList = paymentAmountList;

      // Variables used to get the deductible amounts
     
      // BEGIN, CR00281980, AC
      CaseNomineeAmountList deductibleAmountList;
      // END,CR00281980
      CaseID caseID = new CaseID();

      caseID.caseID = batchProcessingID.recordID;

      deductibleAmountList = maintainFinancialComponentObj.calculateDeductibleAmount(
        paymentAmountList, caseID);

      // BEGIN, CR00029461, SPD
      SimulateInd simulateInd = new SimulateInd();

      simulateInd.simulateInd = false;

      /*
       * Remove any deduction FCs which are associated with
       * non-deductible components (they can never be processed)
       */
      utilityDeductionFCDtlsList = maintainFinancialComponentObj.filterFCsForEligibleDeductions(
        utilityDeductionFCDtlsList, deductibleAmountList, simulateInd);
      // END, CR00029461

      // BEGIN, CR00019290, KH
      // Now adjust the deductible amount with the Tax
      if (taxTotal.getValue() > 0) {

        maintainFinancialComponentObj.deductTax(deductibleAmountList,
          taxAmountList);
      }
      // END, CR00019290

      /*
       * Need to use the latest dueDate and nextProcessingDate when
       * processing the deduction FCs
       */
      productFinancialDtlsSummList.dates.dueDate = latestDueDate;
      productFinancialDtlsSummList.dates.nextProcessingDate = latestNextProcessingDate;

      // Set cover period from date to match the payment
      productFinancialDtlsSummList.coverPeriodDates.coverPeriodFrom = determineEligibilityKey.fromDate;

      // FCCaseID manipulation variables
      FCCaseID fCCaseID = new FCCaseID();

      // Set the key value
      fCCaseID.caseID = batchProcessingID.recordID;

      // Get latest cover period to date
      FCCoverDate fcCoverDate = maintainFinancialComponentObj.getLatestCoverPeriodTo(
        fCCaseID);

      /*
       * Set cover period to date to match the last date actually
       * paid on the case, since the haltPaymentProcessing hook can
       * stop payment FC processing before the intended cover
       * period to date has been reached and we want the
       * deduction/utility cover period to match the payment cover
       * period
       */
      productFinancialDtlsSummList.coverPeriodDates.coverPeriodTo = fcCoverDate.coverDate;

      // Now process deductions and utility payments
      for (int j = 0; j < utilityDeductionFCDtlsList.dtls.size(); j++) {

        // BEGIN, CR00099210, ELG
        // Update the cover period from date if necessary
        if (utilityDeductionFCDtlsList.dtls.item(j).startDate.after(
          determineEligibilityKey.fromDate)) {

          productFinancialDtlsSummList.coverPeriodDates.coverPeriodFrom = utilityDeductionFCDtlsList.dtls.item(j).startDate;
        } else {
          productFinancialDtlsSummList.coverPeriodDates.coverPeriodFrom = determineEligibilityKey.fromDate;

        }
        // END, CR00099210

        // Set the calculation date to match the cover period
        calculatedDate.date = productFinancialDtlsSummList.coverPeriodDates.coverPeriodTo;

        /*
         * We need to adjust the calculation date if paying in
         * arrears
         */
        if ((utilityDeductionFCDtlsList.dtls.item(j).coverPeriodType.equals(
          PRODUCTCOVERPERIOD.ISSUEINARREARS))
            || (utilityDeductionFCDtlsList.dtls.item(j).coverPeriodType.equals(
              PRODUCTCOVERPERIOD.ISSUEINARREARSDAYOFFSET))) {

          /*
           * If the frequency is a zero pattern getNextOccurance
           * will not work, so we need to get the delivery
           * frequency from the nominee
           */
          if (utilityDeductionFCDtlsList.dtls.item(j).frequency.equals(
            FrequencyPattern.kZeroFrequencyPattern.toString())) {

            // CaseNomineeProdDelPattern manipulation variables
            CaseNomineeProdDelPatternDtls caseNomineeProdDelPatternDtls = new CaseNomineeProdDelPatternDtls();
            ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();

            // ProductDeliveryPatternInfo manipulation variables
            ProductDeliveryPatternInfo productDeliveryPatternInfoObj = ProductDeliveryPatternInfoFactory.newInstance();
            ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls;
            PDPIByProdDelPatIDStatusAndDateKey pdpiByProdDelPatIDStatusAndDateKey = new PDPIByProdDelPatIDStatusAndDateKey();

            // Set up key to read CaseNomineeProdDelPattern
            readEffectiveByDateKey.caseNomineeID = utilityDeductionFCDtlsList.dtls.item(j).caseNomineeID;
            readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
            readEffectiveByDateKey.effectiveDate = Date.getCurrentDate();

            // BEGIN, CR00211744, VM
            caseNomineeProdDelPatternDtls = assessmentEngineEntity.getCaseNomineePatternByEffectiveDate(
              readEffectiveByDateKey);
            // END, CR00211744

            // Set up key to read ProductDeliveryPatternInfo
            pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = caseNomineeProdDelPatternDtls.productDeliveryPatternID;
            pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;
            pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = Date.getCurrentDate();

            /*
             * Get the delivery frequency from the product delivery
             * pattern info
             */
            productDeliveryPatternInfoDtls = productDeliveryPatternInfoObj.readNearestProdDelPatInfo(
              pdpiByProdDelPatIDStatusAndDateKey);

            // Change the delivery frequency on the FC
            utilityDeductionFCDtlsList.dtls.item(j).frequency = productDeliveryPatternInfoDtls.deliveryFrequency;
          }

          // BEGIN, CR00286687, KH
          // Roll the calculation date forward by one delivery frequency
          calculatedDate.date = new FrequencyPattern(utilityDeductionFCDtlsList.dtls.item(j).frequency).getNextOccurrence(
            productFinancialDtlsSummList.coverPeriodDates.coverPeriodTo);
          
          final FCProcessingDtls fcProcessingDtls = new FCProcessingDtls();

          fcProcessingDtls.frequencyPattern = utilityDeductionFCDtlsList.dtls.item(j).frequency;
          fcProcessingDtls.deliveryMethod = utilityDeductionFCDtlsList.dtls.item(j).nomineeDelivMethod;

          fcProcessingDtls.coverPeriodOffset = utilityDeductionFCDtlsList.dtls.item(j).coverPeriodOffset;
          fcProcessingDtls.deliveryMethodOffset = utilityDeductionFCDtlsList.dtls.item(j).deliveryMethodOffset;
          fcProcessingDtls.coverPeriodType = utilityDeductionFCDtlsList.dtls.item(j).coverPeriodType;
          
          // Apply any offsets to the calculation date
          fcProcessingDtls.dueDate = calculatedDate.date;

          MaintainFinancialComponentFactory.newInstance().setNextProcessingDate(
            fcProcessingDtls);

          calculatedDate.date = fcProcessingDtls.nextProcessingDate;
          // END, CR00286687
        }

        // Get the deductible component amounts for this nominee
        for (int k = 0; k < deductibleAmountList.nominee.size(); k++) {

          if (deductibleAmountList.nominee.item(k).caseNomineeID
            == utilityDeductionFCDtlsList.dtls.item(j).caseNomineeID) {

            /*
             * Assign deductible amounts for use during deduction
             * processing
             */
            productFinancialDtlsSummList.deductionAmount.deductibleAmountList = deductibleAmountList.nominee.item(
              k);
          }
        }

        /*
         * If the next valid date for the specified delivery method
         * and processing date is greater than or equal to the FC's
         * next processing date, process the component
         */
        if (!calculatedDate.date.before(
          utilityDeductionFCDtlsList.dtls.item(j).nextProcessingDate)) {

          processCounters = processFinancialComponentObj.processComponent(
            utilityDeductionFCDtlsList.dtls.item(j),
            productFinancialDtlsSummList, inputDate, calculatedDate);

          genILIsProcessChunkResult.iliCreatedCount += processCounters.countILIsCreated;
          genILIsProcessChunkResult.fcProcessCount += processCounters.countFCsProcessed;

          // Update total deduction amount
          productFinancialDtlsSummList.deductionAmount.amount = new curam.util.type.Money(
            processCounters.fcDeductionAmount.amount.getValue());
        }
      }// end for j
    }

    genILIsProcessChunkResult.caseProcessCount++;

    storeResults(genILIsProcessChunkResult);
    return null;
  }

  // ___________________________________________________________________________
  /**
   * Aggregate the results of processing a single chunk into the
   * running total
   *
   * @param genILIsProcessChunkResult
   * The results of processing the current chunk
   */
  public void storeResults(
    GenILIsProcessChunkResult genILIsProcessChunkResult)
    throws AppException, InformationalException {

    totalGenILIsProcessChunkResult.caseProcessCount += genILIsProcessChunkResult.caseProcessCount;
    totalGenILIsProcessChunkResult.casesSkippedCount += genILIsProcessChunkResult.casesSkippedCount;
    totalGenILIsProcessChunkResult.fcProcessCount += genILIsProcessChunkResult.fcProcessCount;
    totalGenILIsProcessChunkResult.iliCreatedCount += genILIsProcessChunkResult.iliCreatedCount;

  }

  // ___________________________________________________________________________
  /**
   * Is this Financial Summary already in the list
   *
   * @param productFinancialDtlsSummList
   * The Financial Summary list
   * @param productFinancialDtlsSumm
   * The Financial Summary record
   *
   * @return True if the record is already in the list, false
   * otherwise
   */
  // BEGIN, CR00198672, VK
  protected boolean recordAlreadyInFinancialSummList(
    ProductFinancialDtlsSummList productFinancialDtlsSummList,
    ProductFinancialDtlsSumm productFinancialDtlsSumm) {
    // END, CR00198672
    boolean result = false;
    ProductFinancialDtlsSumm currentProductFinancialDtlsSumm;

    for (int i = 0; i < productFinancialDtlsSummList.dtls.size(); i++) {
      currentProductFinancialDtlsSumm = productFinancialDtlsSummList.dtls.item(
        i);

      if (productFinancialDtlsSumm.productID
        == currentProductFinancialDtlsSumm.productID) {
        result = true;
        break;
      }
    }

    return result;
  }

  // ___________________________________________________________________________
  /**
   * This method gets the ProductFinancialDtlsSumm for the
   * specified case
   *
   * @param batchProcessingID
   * The ID of the case being processed
   *
   * @return The ProductFinancialDtlsSumm
   */
  public ProductFinancialDtlsSumm getProductFinancialDtlsSumm(
    BatchProcessingID batchProcessingID) throws AppException,
      InformationalException {

    curam.core.intf.CachedProduct cachedProductObj = curam.core.fact.CachedProductFactory.newInstance();
    ProductKey productKey = new ProductKey();
    ProductDtls productDtls;

    curam.core.intf.CachedProductDelivery cachedProductDeliveryObj = curam.core.fact.CachedProductDeliveryFactory.newInstance();
    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
    ProductDeliveryDtls productDeliveryDtls;

    ProductFinancialDtlsSumm productFinancialDtlsSumm = new ProductFinancialDtlsSumm();

    productDeliveryKey.caseID = batchProcessingID.recordID;
    productDeliveryDtls = cachedProductDeliveryObj.read(productDeliveryKey);

    productFinancialDtlsSumm.productID = productDeliveryDtls.productID;

    productKey.productID = productDeliveryDtls.productID;
    productDtls = cachedProductObj.read(productKey);

    productFinancialDtlsSumm.adjustmentFrequency = productDtls.adjustmentFrequency;
    productFinancialDtlsSumm.certGracePeriod = productDtls.certGracePeriod;
    productFinancialDtlsSumm.coverPeriodType = productDtls.coverPeriodType;

    return productFinancialDtlsSumm;

  }

  // ___________________________________________________________________________
  /**
   * This method processes the cases skipped by the processing to
   * generate instruction line items for the case. The case owner
   * will be informed of the issue.
   *
   * @param batchProcessingSkippedRecordList
   * The list of cases skipped during ILI generation
   */
  public void processSkippedCases(
    BatchProcessingSkippedRecordList batchProcessingSkippedRecordList)
    throws AppException, InformationalException {

    // For each case
    for (int i = 0; i < batchProcessingSkippedRecordList.dtls.size(); i++) {

      // create a task
      createTask(batchProcessingSkippedRecordList.dtls.item(i));
    }

  }

  // ___________________________________________________________________________
  /**
   * This method creates the task to notify the case owner that the
   * financial processing for this case failed and it needs to be
   * investigated.
   *
   * @param batchProcessingSkippedRecord
   * The record ID of the case which could not be
   * processed and the associated error message
   */
  public void createTask(
    BatchProcessingSkippedRecord batchProcessingSkippedRecord)
    throws AppException, InformationalException {

    // caseHeader manipulation variables
    curam.core.intf.CachedCaseHeader cachedCaseHeaderObj = curam.core.fact.CachedCaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    CaseHeaderDtls caseHeaderDtls;

    // notification manipulation variables
    curam.core.intf.Notification notificationObj = curam.core.fact.NotificationFactory.newInstance();

    // WorkAllocationTask service layer object
    StandardManualTaskDtls standardManualTaskDtls = new StandardManualTaskDtls();

    // BEGIN, CR00213430, AK
    OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();
    OrgObjectLink orgObjectLinkObj = OrgObjectLinkFactory.newInstance();
    OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    Users userObj = UsersFactory.newInstance();
    UsersKey userKey = new UsersKey();
    UsersDtls usersDtls = new UsersDtls();
    NotFoundIndicator nfIndicator = new NotFoundIndicator();
    String userLocale;
    // END, CR00213430

    // BEGIN, CR00074750, CM
    // check the environment variable
    String genILISFailure = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_GENILISFAILURETICKET);

    if (genILISFailure == null) {

      genILISFailure = EnvVars.ENV_GENILISFAILURETICKET_DEFAULT;
    }

    if (genILISFailure.equalsIgnoreCase(EnvVars.ENV_VALUE_NO)) {
      return;
    }
    // END, CR00074750

    AppException subjectMsg = new AppException(
      curam.message.BPOGENERATEINSTRUCTIONLINEITEMSSTREAM.INF_GENERATE_ILIS_FAILURE_SUB);

    AppException reasonMsg = new AppException(
      curam.message.BPOGENERATEINSTRUCTIONLINEITEMSSTREAM.INF_GENERATE_ILIS_FAILURE_TXT);

    // set key to read caseHeader
    caseHeaderKey.caseID = batchProcessingSkippedRecord.recordID;

    // read caseHeader
    caseHeaderDtls = cachedCaseHeaderObj.read(caseHeaderKey);
    // BEGIN, CR00213430, AK
    caseHeaderKey.caseID = caseHeaderDtls.caseID;
    orgObjectLinkKey.orgObjectLinkID = caseHeaderObj.readCaseOwner(caseHeaderKey).ownerOrgObjectLinkID;
    orgObjectLinkDtls = orgObjectLinkObj.read(orgObjectLinkKey);
    userKey.userName = orgObjectLinkDtls.userName;
    usersDtls = userObj.read(nfIndicator, userKey);
    if (!nfIndicator.isNotFound()) {
      userLocale = usersDtls.defaultLocale;
    } else {
      userLocale = TransactionInfo.getProgramLocale();
    }

    // Add case reference to task subject
    subjectMsg.arg(caseHeaderDtls.caseReference);

    // Add reason to task message
    reasonMsg.arg(batchProcessingSkippedRecord.errorMessage);

    // BEGIN, CR00163236, CL
    // set notification details
    standardManualTaskDtls.dtls.taskDtls.subject = subjectMsg.getMessage(
      userLocale);
    standardManualTaskDtls.dtls.taskDtls.comments = reasonMsg.getMessage(
      userLocale);
    // END, CR00163236
    // END, CR00213430
    // BEGIN, CR00023618, SK
    standardManualTaskDtls.dtls.taskDtls.taskDefinitionID = TaskDefinitionIDConst.generateFinancialsTaskDefinitionID;
    // END, CR00023618

    // Set concerning details
    standardManualTaskDtls.dtls.concerningDtls.caseID = caseHeaderDtls.caseID;

    // BEGIN, CR00154259, SK
    standardManualTaskDtls.dtls.concerningDtls.participantRoleID = caseHeaderDtls.concernRoleID;
    // END, CR00154259

    // create notification
    // BEGIN, CR00069238, MG
    notificationObj.sendCaseOwnerNotification(standardManualTaskDtls);
    // END, CR00069238
  }

}
