/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import com.google.inject.Inject;

import curam.codetable.CASESTATUS;
import curam.codetable.CASEUNSUSPENDREASON;
import curam.codetable.COMMUNICATIONSTATUS;
import curam.codetable.impl.CMISNAMINGTYPEEntry;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.core.fact.ConcernRoleFactory;
import curam.core.intf.ConcernRole;
import curam.core.sl.entity.fact.LanguageLocaleMapFactory;
import curam.core.sl.entity.intf.LanguageLocaleMap;
import curam.core.sl.entity.struct.LanguageLocaleMapDtls;
import curam.core.sl.entity.struct.LanguageLocaleMapKey;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.core.sl.struct.LanguageLocaleMapDetails;
import curam.core.sl.struct.ProFormaReturnDocDetails;
import curam.core.struct.AddressKey;
import curam.core.struct.CaseContractDocumentKey;
import curam.core.struct.CaseContractDtls;
import curam.core.struct.CaseContractKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseReferenceProductNameConcernRoleName;
import curam.core.struct.CaseStatusDtls;
import curam.core.struct.CaseStatusDtlsList;
import curam.core.struct.CaseStatusSearchByCaseIDKey;
import curam.core.struct.ClosureDtls;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleCommunicationKey;
import curam.core.struct.ConcernRoleDocumentDetails;
import curam.core.struct.ConcernRoleDocumentKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameAndAlternateID;
import curam.core.struct.CurrentCaseStatusKey;
import curam.core.struct.GetCaseClosureSupplierKey;
import curam.core.struct.InformationalMsgDtls;
import curam.core.struct.InformationalMsgDtlsList;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ProFormaDocumentData;
import curam.core.struct.ReadCaseClosureKey;
import curam.core.struct.ReadParticipantRoleIDDetails;
import curam.message.BPOCOMMUNICATION;
import curam.message.GENERALCASE;
import curam.util.administration.struct.XSLTemplateDetailsList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.internal.xml.struct.XSLTemplateKey;
import curam.util.persistence.GuiceWrapper;
import curam.util.transaction.TransactionInfo;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.intf.XSLTemplateUtility;


/**
 * Controls pro forma printing of documents for concern roles.
 */
public abstract class ConcernRoleDocuments extends curam.core.base.ConcernRoleDocuments {

  // BEGIN, CR00295922, CD
  @Inject
  private CMISAccessInterface cmisAccess;
  // END, CR00295922

  // BEGIN, CR00296459, CD
  /**
   * Add injection.
   */
  protected ConcernRoleDocuments() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // END, CR00296459
  
  // ___________________________________________________________________________
  /**
   * This method prints a specified document for the specified concern role.
   *
   * @param key
   * contains concernRoleID, caseID, documentID (in)
   * @param details
   * ConcerRoleDocumentDetails (in)
   *
   * @return The document name and contents.
   */
  public ProFormaReturnDocDetails printAndPreviewDocument(ConcernRoleDocumentKey key,
    ConcernRoleDocumentDetails details) throws AppException,
      InformationalException {

    // pro forma document data to be populated
    ProFormaDocumentData proFormaDocumentData = new ProFormaDocumentData();

    // populate the user data
    curam.core.intf.ConcernRoleDocumentGeneration concernRoleDocumentGenerationObj = curam.core.fact.ConcernRoleDocumentGenerationFactory.newInstance();
    // BEGIN, CR00003578, RV
    // get the closure details
    curam.core.intf.MaintainCaseClosure maintainCaseClosureObj = curam.core.fact.MaintainCaseClosureFactory.newInstance();
    ReadCaseClosureKey readCaseClosureKey = new ReadCaseClosureKey();
    // BEGIN, CR00148072, SS
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // BEGIN, CR00161292, ZV
    if (key.caseID != 0) {
      
      CaseHeaderDtls caseHeaderDtls;

      caseHeaderKey.caseID = key.caseID;
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);
      readCaseClosureKey.caseID = key.caseID;
      ClosureDtls closureDtls = new ClosureDtls();

      if (caseHeaderDtls.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)
        || caseHeaderDtls.statusCode.equals(
          curam.codetable.CASESTATUS.PENDINGCLOSURE)) {
        closureDtls = maintainCaseClosureObj.readCaseClosure(readCaseClosureKey);
      } else {
        closureDtls.closureDate = null;
      }
      // END, CR00148072
      if (closureDtls.closureDate != null) {
        proFormaDocumentData.caseClosureDate = closureDtls.closureDate;
        proFormaDocumentData.caseID = key.caseID;
      }
      // END, CR00003578
    }
    
    // BEGIN, CR00161765, ZV
    concernRoleDocumentGenerationObj.getUserData(proFormaDocumentData);
    // END, CR00161765
    // END, CR00161292

    // populate the concern role data (if it exists)
    if (key.concernRoleID != 0) {

      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      // if this it a service supplier communication for a case closure the
      // details returned are for the service supplier.
      concernRoleKey.concernRoleID = key.concernRoleID;
      concernRoleDocumentGenerationObj.getConcernRoleData(concernRoleKey,
        proFormaDocumentData);
    }

    // Read the communication an obtain required address.
    if (details.communicationID != 0) {

      // Concern role communication object and access structures
      curam.core.intf.ConcernRoleCommunication concernRoleCommObj = curam.core.fact.ConcernRoleCommunicationFactory.newInstance();
      ConcernRoleCommunicationKey concernRoleCommunicationKey = new ConcernRoleCommunicationKey();
      AddressKey addressKey = new AddressKey();

      concernRoleCommunicationKey.communicationID = details.communicationID;
      addressKey.addressID = concernRoleCommObj.read(concernRoleCommunicationKey).addressID;

      // Address object and access structures
      curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
      OtherAddressData otherAddressData = new OtherAddressData();

      // Copy concern role address information to document data
      otherAddressData.addressData = addressObj.read(addressKey).addressData;
      addressObj.getLongFormat(otherAddressData);
      proFormaDocumentData.concernRoleAddress = otherAddressData.addressData;
    }

    // populate the case data (if it exists - could be a direct
    // communication with a person, employer etc, i.e. not part of a case).
    if (key.caseID != 0) {
      proFormaDocumentData = populateCaseDetails(key, details,
        proFormaDocumentData);      
    }

    // print the populated document
    return concernRoleDocumentGenerationObj.generatePrintAndPreviewXMLDocument(
      details, proFormaDocumentData);

  }
  
  // ___________________________________________________________________________
  /**
   * This method prints a specified document for the specified concern role.
   *
   * @param key
   * contains concernRoleID, caseID, documentID (in)
   * @param details
   * ConcerRoleDocumentDetails (in)
   */
  public void printDocument(ConcernRoleDocumentKey key,
    ConcernRoleDocumentDetails details) throws AppException,
      InformationalException {

    // pro forma document data to be populated
    ProFormaDocumentData proFormaDocumentData = new ProFormaDocumentData();

    // populate the user data
    curam.core.intf.ConcernRoleDocumentGeneration concernRoleDocumentGenerationObj = curam.core.fact.ConcernRoleDocumentGenerationFactory.newInstance();
    // BEGIN, CR00003578, RV
    // get the closure details
    curam.core.intf.MaintainCaseClosure maintainCaseClosureObj = curam.core.fact.MaintainCaseClosureFactory.newInstance();
    ReadCaseClosureKey readCaseClosureKey = new ReadCaseClosureKey();
    // BEGIN, CR00148072, SS
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // BEGIN, CR00161292, ZV
    if (key.caseID != 0) {
      
      CaseHeaderDtls caseHeaderDtls;

      caseHeaderKey.caseID = key.caseID;
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);
      readCaseClosureKey.caseID = key.caseID;
      ClosureDtls closureDtls = new ClosureDtls();

      if (caseHeaderDtls.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)
        || caseHeaderDtls.statusCode.equals(
          curam.codetable.CASESTATUS.PENDINGCLOSURE)) {
        closureDtls = maintainCaseClosureObj.readCaseClosure(readCaseClosureKey);
      } else {
        closureDtls.closureDate = null;
      }
      // END, CR00148072
      if (closureDtls.closureDate != null) {
        proFormaDocumentData.caseClosureDate = closureDtls.closureDate;
        proFormaDocumentData.caseID = key.caseID;
      }
      // END, CR00003578
    }
    
    // BEGIN, CR00161765, ZV
    concernRoleDocumentGenerationObj.getUserData(proFormaDocumentData);
    // END, CR00161765
    // END, CR00161292

    // BEGIN, CR00295922, CD
    ConcernRoleCommunicationDtls concernRoleCommDtls = null;

    // END, CR00295922

    // populate the concern role data (if it exists)
    if (key.concernRoleID != 0) {

      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      // if this it a service supplier communication for a case closure the
      // details returned are for the service supplier.
      concernRoleKey.concernRoleID = key.concernRoleID;
      concernRoleDocumentGenerationObj.getConcernRoleData(concernRoleKey,
        proFormaDocumentData);
    }

    // Read the communication an obtain required address.
    if (details.communicationID != 0) {

      // Concern role communication object and access structures
      curam.core.intf.ConcernRoleCommunication concernRoleCommObj = curam.core.fact.ConcernRoleCommunicationFactory.newInstance();
      ConcernRoleCommunicationKey concernRoleCommunicationKey = new ConcernRoleCommunicationKey();
      AddressKey addressKey = new AddressKey();

      concernRoleCommunicationKey.communicationID = details.communicationID;
      concernRoleCommDtls = concernRoleCommObj.read(concernRoleCommunicationKey);
      addressKey.addressID = concernRoleCommDtls.addressID;

      // Address object and access structures
      curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
      OtherAddressData otherAddressData = new OtherAddressData();

      // Copy concern role address information to document data
      otherAddressData.addressData = addressObj.read(addressKey).addressData;
      addressObj.getLongFormat(otherAddressData);
      proFormaDocumentData.concernRoleAddress = otherAddressData.addressData;
    }

    // populate the case data (if it exists - could be a direct
    // communication with a person, employer etc, i.e. not part of a case).
    if (key.caseID != 0) {
      proFormaDocumentData = populateCaseDetails(key, details,
        proFormaDocumentData);      
    }

    // BEGIN, CR00295922, CD
    // print the populated document
    ProFormaReturnDocDetails proFormaDtls = concernRoleDocumentGenerationObj.generatePrintAndPreviewXMLDocument(
      details, proFormaDocumentData);

    if (null != concernRoleCommDtls
      && concernRoleCommDtls.communicationStatus.equals(
        COMMUNICATIONSTATUS.SENT)
        && cmisAccess.isCMISEnabledFor(
          CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {

      if (cmisAccess.contentExists(details.communicationID,
        CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {
        // modify the file on the content management system
        cmisAccess.modify(details.communicationID,
          CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION, 
          proFormaDtls.fileDate.copyBytes(), null);
      } else {
        // save the contents to the content management system
        cmisAccess.create(details.communicationID,
          CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION,
          proFormaDtls.fileDate.copyBytes(), proFormaDtls.fileName,
          CMISNAMINGTYPEEntry.PROFORMA_GENERIC, null);
      }

    }
    // END, CR00295922

  }

  // ___________________________________________________________________________
  /**
   * This method previews a specified document for the specified concern role.
   *
   * @param key
   * contains concernRoleID, caseID, documentID (in)
   * @param details
   * ConcerRoleDocumentDetails (in)
   *
   * @return The document name and contents.
   */
  public ProFormaReturnDocDetails previewDocument(ConcernRoleDocumentKey key, ConcernRoleDocumentDetails details) throws AppException, InformationalException {

    // pro forma document data to be populated
    ProFormaDocumentData proFormaDocumentData = new ProFormaDocumentData();

    // Return type
    ProFormaReturnDocDetails proFormaReturnDocDetails = new ProFormaReturnDocDetails();    
    
    // populate the user data
    curam.core.intf.ConcernRoleDocumentGeneration concernRoleDocumentGenerationObj = curam.core.fact.ConcernRoleDocumentGenerationFactory.newInstance();

    // get the closure details
    curam.core.intf.MaintainCaseClosure maintainCaseClosureObj = curam.core.fact.MaintainCaseClosureFactory.newInstance();
    ReadCaseClosureKey readCaseClosureKey = new ReadCaseClosureKey();

    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    if (key.caseID != 0) {
      
      CaseHeaderDtls caseHeaderDtls;

      caseHeaderKey.caseID = key.caseID;
      caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);
      readCaseClosureKey.caseID = key.caseID;
      ClosureDtls closureDtls = new ClosureDtls();

      if (caseHeaderDtls.statusCode.equals(curam.codetable.CASESTATUS.CLOSED)
        || caseHeaderDtls.statusCode.equals(
          curam.codetable.CASESTATUS.PENDINGCLOSURE)) {
        closureDtls = maintainCaseClosureObj.readCaseClosure(readCaseClosureKey);
      } else {
        closureDtls.closureDate = null;
      }

      if (closureDtls.closureDate != null) {
        proFormaDocumentData.caseClosureDate = closureDtls.closureDate;
        proFormaDocumentData.caseID = key.caseID;
      }

    }
    
    concernRoleDocumentGenerationObj.getUserData(proFormaDocumentData);

    // populate the concern role data (if it exists)
    if (key.concernRoleID != 0) {

      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      // if this it a service supplier communication for a case closure the
      // details returned are for the service supplier.
      concernRoleKey.concernRoleID = key.concernRoleID;
      concernRoleDocumentGenerationObj.getConcernRoleData(concernRoleKey,
        proFormaDocumentData);
    }

    // Read the communication an obtain required address.
    if (details.communicationID != 0) {

      // Concern role communication object and access structures
      curam.core.intf.ConcernRoleCommunication concernRoleCommObj = curam.core.fact.ConcernRoleCommunicationFactory.newInstance();
      ConcernRoleCommunicationKey concernRoleCommunicationKey = new ConcernRoleCommunicationKey();
      AddressKey addressKey = new AddressKey();

      concernRoleCommunicationKey.communicationID = details.communicationID;
      addressKey.addressID = concernRoleCommObj.read(concernRoleCommunicationKey).addressID;

      // Address object and access structures
      curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
      OtherAddressData otherAddressData = new OtherAddressData();

      // Copy concern role address information to document data
      otherAddressData.addressData = addressObj.read(addressKey).addressData;
      addressObj.getLongFormat(otherAddressData);
      proFormaDocumentData.concernRoleAddress = otherAddressData.addressData;
    }

    // populate the case data (if it exists - could be a direct
    // communication with a person, employer etc, i.e. not part of a case).
    if (key.caseID != 0) {
      proFormaDocumentData = populateCaseDetails(key, details,
        proFormaDocumentData);
    }

    // print the populated document
    proFormaReturnDocDetails = concernRoleDocumentGenerationObj.generateAndPreviewXMLDocument(
      details, proFormaDocumentData);    
    
    return proFormaReturnDocDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method helps populate case details for case communications.
   *
   * @param key
   * contains concernRoleID, caseID, documentID (in)
   * @param details
   * ConcerRoleDocumentDetails (in)
   *
   * @return ProFormaDocumentData
   */
  protected ProFormaDocumentData populateCaseDetails(ConcernRoleDocumentKey key, ConcernRoleDocumentDetails details, ProFormaDocumentData proFormaDocumentData) 
    throws AppException, InformationalException {
    
    curam.core.intf.ConcernRoleDocumentGeneration concernRoleDocumentGenerationObj = curam.core.fact.ConcernRoleDocumentGenerationFactory.newInstance();  
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();    
    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    // populate the case ID
    proFormaDocumentData.caseID = key.caseID;

    // maintainCase manipulation variables to retrieve case reference and
    // product name.
    curam.core.intf.MaintainCase maintainCaseObj = curam.core.fact.MaintainCaseFactory.newInstance();

    curam.core.sl.struct.CaseIDKey caseIDKey = new curam.core.sl.struct.CaseIDKey();

    // get the case reference and product name.
    caseIDKey.caseID = key.caseID;
    CaseReferenceProductNameConcernRoleName caseReferenceProductNameConcernRoleName = maintainCaseObj.readCaseReferenceConcernRoleNameProductNameByCaseID(
      caseIDKey);

    proFormaDocumentData.caseReference = caseReferenceProductNameConcernRoleName.caseReference;

    proFormaDocumentData.productType = caseReferenceProductNameConcernRoleName.productName;

    // XSLTemplate Obj, XSLTemplateKey and XSLTemplateInstDtls structs
    curam.util.internal.xml.intf.XSLTemplate xslTemplateObj = curam.util.internal.xml.fact.XSLTemplateFactory.newInstance();
    curam.util.internal.xml.struct.XSLTemplateDtls xslTemplateDtls;
    curam.util.internal.xml.struct.XSLTemplateKey xslTemplateKey = new curam.util.internal.xml.struct.XSLTemplateKey();

    xslTemplateKey.templateID = key.documentID;

    if ((details.localeIdentifier == null)
      || (details.localeIdentifier.length() == 0)) {
      xslTemplateKey.localeIdentifier = TransactionInfo.getProgramLocale();
    } else {
      xslTemplateKey.localeIdentifier = details.localeIdentifier;
    }

    // read the template details
    try {

      xslTemplateDtls = xslTemplateObj.read(xslTemplateKey);

    } catch (curam.util.exception.RecordNotFoundException e) {

      AppException ae = new AppException(
        curam.message.GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE);

      ae.arg(xslTemplateKey.templateID);
      throw ae;

    }

    // is it a client communication for a case closure?
    if (xslTemplateDtls.templateIDCode.equals(
      curam.codetable.TEMPLATEIDCODE.CASECLOSURECLIENTNOTIFICATION)
        || xslTemplateDtls.templateIDCode.equals(
          curam.codetable.TEMPLATEIDCODE.CASEREACTIVATIONCLIENTCOMMUNICATION)) {

      // populate the case closure data
      GetCaseClosureSupplierKey getCaseClosureSupplierKey = new GetCaseClosureSupplierKey();
      
      getCaseClosureSupplierKey.caseID = key.caseID;
      
      try {
        
        concernRoleDocumentGenerationObj.getCaseClosureClientData(
          getCaseClosureSupplierKey, proFormaDocumentData);          
        
      } catch (AppException ae) {
        if (ae.getCatEntry().equals(GENERALCASE.ERR_CASEEVENT_RNFE_CASE)) {
          throw new AppException(
            BPOCOMMUNICATION.ERR_COMM_XRV_CASE_NEVER_CLOSED);
        }           
      } catch (InformationalException ae) { 
        if (ae.getMessage().equals(GENERALCASE.ERR_CASEEVENT_RNFE_CASE)) {
          throw new AppException(
            BPOCOMMUNICATION.ERR_COMM_XRV_CASE_NEVER_CLOSED);
        }         
      }

      // or is it a supplier communication for a case closure
    } else if (xslTemplateDtls.templateIDCode.equals(
      curam.codetable.TEMPLATEIDCODE.CASECLOSURESUPPLIERNOTIFICATION)) {

      curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
      CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();
      CaseStatusDtls caseStatusDtls;

      // BEGIN, CR00166384, JMA
      currentCaseStatusKey.caseID = key.caseID;
      // END, CR00166384
      
      try {
        // BEGIN, CR00224271, ZV
        caseStatusDtls = caseStatusObj.readCurrentStatusByCaseID1(
          currentCaseStatusKey);
        // END, CR00224271

      } catch (curam.util.exception.RecordNotFoundException e) {

        AppException ae = new AppException(
          curam.message.GENERALCASE.ERR_CASESTATUS_RNFE_CASE);

        ae.arg(caseReferenceProductNameConcernRoleName.caseReference);

        throw ae;
      }

      // BEGIN, CR00166384, JMA
      // is the case closed or pending closure?
      if (!caseStatusDtls.statusCode.equals(
        curam.codetable.CASESTATUS.PENDINGCLOSURE)
          && !caseStatusDtls.statusCode.equals(
            curam.codetable.CASESTATUS.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOCOMMUNICATION.ERR_COMM_XRV_CASE_NOT_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
        
      }                
      
      if (key.concernRoleID != 0) {

        // CaseHeader manipulation variables to retrieve participant role id.
        caseHeaderKey.caseID = key.caseID;

        // ConcernRole manipulation variables to retrieve participant name and
        // alternate id.
        curam.core.intf.ConcernRole concernObj = curam.core.fact.ConcernRoleFactory.newInstance();
        ConcernRoleKey concernRoleKey = new ConcernRoleKey();

        // as the concern role details returned above are for the service
        // supplier we need to get the participant details.

        ReadParticipantRoleIDDetails readParticipantRoleIDDetails = caseHeaderObj.readParticipantRoleID(
          caseHeaderKey);

        concernRoleKey.concernRoleID = readParticipantRoleIDDetails.concernRoleID;

        ConcernRoleNameAndAlternateID concernRoleNameAndAlternateID = concernObj.readConcernRoleNameAndAlternateID(
          concernRoleKey);

        // assign the case participant details.
        proFormaDocumentData.concernRoleName = concernRoleNameAndAlternateID.concernRoleName;
        proFormaDocumentData.alternateID = concernRoleNameAndAlternateID.primaryAlternateID;

      }

    } // if the case has been suspended find the reason
    else if (xslTemplateDtls.templateIDCode.equals(
      curam.codetable.TEMPLATEIDCODE.CASESUSPENDEDCLIENTCOMMUNICATION)) {

      CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();

      currentCaseStatusKey.caseID = key.caseID;

      curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();

      // populate the reason code
      // BEGIN, CR00224271, ZV
      proFormaDocumentData.reason = caseStatusObj.readCurrentStatusByCaseID1(currentCaseStatusKey).reasonCode;
      // END, CR00224271

      proFormaDocumentData.caseSuspendReason = curam.util.type.CodeTable.getOneItem(
        curam.codetable.CASESUSPENDREASON.TABLENAME,
        proFormaDocumentData.reason);
      
      if (proFormaDocumentData.caseSuspendReason.equals("")) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOCOMMUNICATION.ERR_COMM_XRV_CASE_NOT_SUSPENDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);          
      }

    } // if the case has been unsuspended find the reason.
    else if (xslTemplateDtls.templateIDCode.equals(
      curam.codetable.TEMPLATEIDCODE.CASEUNSUSPENDEDCLIENTCOMMUNICATION)) {

      CurrentCaseStatusKey currentCaseStatusKey = new CurrentCaseStatusKey();

      currentCaseStatusKey.caseID = key.caseID;

      curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();

      CaseStatusSearchByCaseIDKey caseStatusSearchByCaseIDKey = new CaseStatusSearchByCaseIDKey();

      caseStatusSearchByCaseIDKey.caseID = key.caseID;
      
      CaseStatusDtlsList caseStatusDtlsList = caseStatusObj.searchByCaseID(
        caseStatusSearchByCaseIDKey);

      for (int i = 0; i < caseStatusDtlsList.dtls.size(); i++) {
        
        // if the case status is Open, has an unsuspended reason code and a blank end date
        // then it is the most current Unsuspended reason to use
        if (caseStatusDtlsList.dtls.item(i).statusCode.equals(CASESTATUS.OPEN)
          && caseStatusDtlsList.dtls.item(i).endDate.isZero()
          && (caseStatusDtlsList.dtls.item(i).reasonCode.equals(
            CASEUNSUSPENDREASON.NEWEVIDENCE)
              || caseStatusDtlsList.dtls.item(i).reasonCode.equals(
                CASEUNSUSPENDREASON.SUSPENDEDINERROR))) {
          
          proFormaDocumentData.caseUnsuspendReason = curam.util.type.CodeTable.getOneItem(
            curam.codetable.CASEUNSUSPENDREASON.TABLENAME,
            caseStatusDtlsList.dtls.item(i).reasonCode);           
          
        }         
      }
      // BEGIN, CR00164917, JMA
      if (proFormaDocumentData.caseUnsuspendReason.equals("")) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(BPOCOMMUNICATION.ERR_COMM_XRV_CASE_NOT_UNSUSPENDED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);          
      }
      // END, CR00164917
    }
    
    return proFormaDocumentData;
    
  }  
  
  // ___________________________________________________________________________
  /**
   * This method prints a Case Contract.
   *
   * @param key
   * contains concernRoleID, caseID, documentID, caseContractID
   * @param details
   * ConcerRoleDocumentDetails
   *
   * @return InformationalMsgDtlsList informational messages
   */
  public InformationalMsgDtlsList printCaseContract(
    CaseContractDocumentKey key, ConcernRoleDocumentDetails details)
    throws AppException, InformationalException {

    // return value
    InformationalMsgDtlsList informationalMsgDtlsListRet = new InformationalMsgDtlsList();

    // ConcernRoleDocument variables
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ProFormaDocumentData proFormaDocumentData = new ProFormaDocumentData();
    CaseContractDocumentKey caseContractDocumentKey = new CaseContractDocumentKey();
    ProFormaDocumentData proFormaDocumentDataContract;

    // structure for adding to return list

    InformationalMsgDtls informationalMsgDtls;

    // Case Contract variables
    curam.core.intf.CaseContract caseContractObj = curam.core.fact.CaseContractFactory.newInstance();
    CaseContractKey caseContractKey = new CaseContractKey();
    CaseContractDtls caseContractDtls;

    // concern role document generation object
    curam.core.intf.ConcernRoleDocumentGeneration concernRoleDocumentGenerationObj = curam.core.fact.ConcernRoleDocumentGenerationFactory.newInstance();

    // case header manipulation objects
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    concernRoleKey.concernRoleID = key.concernRoleID;

    // set the caseID so that the correct user info is retrieved
    proFormaDocumentData.caseID = key.caseID;

    concernRoleDocumentGenerationObj.getUserData(proFormaDocumentData);

    if (concernRoleKey.concernRoleID != 0) {
      concernRoleDocumentGenerationObj.getConcernRoleData(concernRoleKey,
        proFormaDocumentData);
    }

    // Set up the key to read the Case Contract Document details
    caseContractDocumentKey.caseContractID = key.caseContractID;
    caseContractDocumentKey.caseID = key.caseID;
    proFormaDocumentDataContract = concernRoleDocumentGenerationObj.getCaseContractData(
      caseContractDocumentKey);

    proFormaDocumentData.dtls.ensureCapacity(
      proFormaDocumentDataContract.dtls.size());

    for (int i = 0; i < proFormaDocumentDataContract.dtls.size(); i++) {

      proFormaDocumentData.dtls.addRef(
        proFormaDocumentDataContract.dtls.item(i));

    }

    // The generated document is is displaying the caseID instead of the case
    // reference number. Here we replace the caseID with the case reference
    // number so that the document displays correctly.
    caseHeaderKey.caseID = key.caseID;

    proFormaDocumentData.caseID = Long.parseLong(
      caseHeaderObj.read(caseHeaderKey).caseReference);

    concernRoleDocumentGenerationObj.generateAndPrintXMLDocument(details,
      proFormaDocumentData);

    // Perform a modify case contract to set the isPrinted indicator to true
    // after a contract is printed

    // Set the key for the case contract read
    caseContractKey.caseContractID = key.caseContractID;
    caseContractDtls = caseContractObj.read(caseContractKey);

    // Set the printed indicator to true
    caseContractDtls.isPrintedInd = true;

    // inform the user that the document is printed

    informationalMsgDtls = new InformationalMsgDtls();

    informationalMsgDtls.informationMsgTxt = curam.message.BPOCONCERNROLEDOCUMENTS.INF_CONCERNROLEDOCUMENTS_ISPRINTED.getMessageText();

    informationalMsgDtlsListRet.dtls.addRef(informationalMsgDtls);

    caseContractObj.modify(caseContractKey, caseContractDtls);

    return informationalMsgDtlsListRet;

  }

  // BEGIN, CR00146629, SK
  // ___________________________________________________________________________
  /**
   * This method returns locale information for a concernRole.
   * If the system does not find the locale from language locale map, 
   * then it will return locale from Transactionifo.getProgramLocale().
   *
   * @param key Concern Role key 
   *
   * @return locale information for a concern role from Language Locale Map 
   * list
   * * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public LanguageLocaleMapDetails getLocaleInfo(ConcernRoleKey key)
    throws AppException, InformationalException {

    ConcernRole concernRoleObj = ConcernRoleFactory.newInstance();

    LanguageLocaleMapDetails languageLocaleMapDetails = new LanguageLocaleMapDetails();

    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    // BEGIN, CR00169926, SK
    try {
      concernRoleDtls = concernRoleObj.read(key);
    } catch (curam.util.exception.RecordNotFoundException e) {// do nothing, languageLocaleMapDetails will be set to default server
      // locale in else block which is defined at the end.
    }
    // END, CR00169926
    // If the preferred Language for a concernRole is not null then retrieve
    // the locale value from the Language Locale Map with the preferred
    // Language code.

    if ((null != concernRoleDtls.preferredLanguage)
      && (0 != concernRoleDtls.preferredLanguage.length())) {
      LanguageLocaleMap languageLocaleMapObj = LanguageLocaleMapFactory.newInstance();
      LanguageLocaleMapDtls languageLocaleMapDtls = new curam.core.sl.entity.struct.LanguageLocaleMapDtls();
      LanguageLocaleMapKey languageLocalekey = new LanguageLocaleMapKey();

      languageLocalekey.languageCode = concernRoleDtls.preferredLanguage;
      try {
        languageLocaleMapDtls = languageLocaleMapObj.read(languageLocalekey);
        languageLocaleMapDetails.dtls.localeIdentifier = languageLocaleMapDtls.localeIdentifier;

        // BEGIN, CR00234230, PB
        XSLTemplateKey xslTemplateKey = new XSLTemplateKey();

        xslTemplateKey.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;
        XSLTemplateUtility xSLTemplateUtility = XSLTemplateUtilityFactory.newInstance();
        XSLTemplateDetailsList xSLTemplateDetailsList = new XSLTemplateDetailsList();

        xSLTemplateDetailsList = xSLTemplateUtility.getAllTemplates();
        int templateListSize = xSLTemplateDetailsList.dtls.size();
        int finaltemplateListSize = 0;

        // Checks if there is template for the locale which is being
        // returned.
        for (int i = 0; i < templateListSize; i++) {
          if (xSLTemplateDetailsList.dtls.item(i).locale.equals(
            languageLocaleMapDetails.dtls.localeIdentifier)) {
            // BEGIN, CR00237291, PM 
            ++finaltemplateListSize;
            break;
            // END, CR00237291
          }
        }
        if (finaltemplateListSize == 0) {
          languageLocaleMapDetails.dtls.localeIdentifier = TransactionInfo.getProgramLocale();
        }
        // END, CR00234230

      } catch (curam.util.exception.RecordNotFoundException e) {
        languageLocaleMapDetails.dtls.localeIdentifier = TransactionInfo.getProgramLocale();
      }
    } else {
      languageLocaleMapDetails.dtls.localeIdentifier = TransactionInfo.getProgramLocale();
    }
    return languageLocaleMapDetails;
  }        
  // END, CR00146629
    
}
