/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.sl.struct.TaskQueryCriteria;
import curam.core.sl.struct.TaskSearchKey;
import curam.core.sl.struct.TaskSearchResult;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Task search lucene index search
 *
 *
 * @deprecated Since Curam 6.0 SP1, there is no index task search functionality.
 * See release note CR00222551.
 */
@Deprecated
public abstract class IndexTaskSearch extends curam.core.base.IndexTaskSearch {
  // ___________________________________________________________________________
  /**
   * @param taskSearchKey data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @deprecated Since Curam 6.0. This method has been replaced by 
   * {@link #curam.core.intf.TaskSearchRouter.searchTask(TaskQueryCriteria)}. 
   * The task search functionality has been enhanced for Curam 6.0 therefore 
   * this method is no longer used. See release note CR00221722.
   *
   * Performs a lucene index search for tasks using the specified search
   * criteria.
   *
   * @deprecated Since Curam 6.0, there is no index task search functionality.
   * See release note CR00221722.
   */
  @Deprecated
  public TaskSearchResult taskSearch(final TaskSearchKey taskSearchKey)
    throws AppException, InformationalException {
    return null;
  }

}
