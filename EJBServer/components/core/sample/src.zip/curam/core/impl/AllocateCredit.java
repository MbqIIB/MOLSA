/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2004, 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.AllocatedAmt;
import curam.core.struct.AllocationBalance;
import curam.core.struct.AllocationCase;
import curam.core.struct.AllocationFinInstructionID;
import curam.core.struct.AllocationLineDtls;
import curam.core.struct.CaseIDStatusCodeCreditDebitType;
import curam.core.struct.ILICategoryDtls;
import curam.core.struct.ILIStatusCode;
import curam.core.struct.ILIUnprocessedAmt;
import curam.core.struct.InstructionLineItemDetails;
import curam.core.struct.InstructionLineItemDtls;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.InstructionLineItemID;
import curam.core.struct.InstructionLineItemKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductKey;
import curam.core.struct.RelatedILIDetailsList;
import curam.core.struct.RelatedILIidentifier;
import curam.core.struct.StatusCodeUnprocessedAmt;
import curam.core.struct.StatusFinInstructID;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.Money;


/**
 * Code for allocating credits against debits.
 *
 */
public abstract class AllocateCredit extends curam.core.base.AllocateCredit {

  // ___________________________________________________________________________
  /**
   * Take the input repayment details, find the Case it is repaying
   * and allocate the credit to that case.
   *
   *
   * @param repmtILI repayment key
   */
  public void allocateRepayment(InstructionLineItemDtls repmtILI)
    throws AppException, InformationalException {

    AllocationCase allocationCase = new AllocationCase();

    allocationCase.caseID = repmtILI.caseID;

    allocateCreditByCase(repmtILI, allocationCase);

  }

  // ___________________________________________________________________________
  /**
   * To retrieve all the outstanding Instruction Line Items for the specified
   * Case and allocate the Credit to them.
   *
   *
   * @param creditILI credit instruction line item
   * @param allocationCase allocation case
   */
  public void allocateCreditByCase(InstructionLineItemDtls creditILI,
    AllocationCase allocationCase) throws AppException, InformationalException {

    // Checking that the input ILI has a valid allocation amount
    if (creditILI.unprocessedAmount.isNegative()) {

      AppException e = new AppException(
        curam.message.BPOALLOCATECREDIT.ERR_ILI_FV_ALLOC_AMT_NEGATIVE);

      e.arg(creditILI.instructLineItemID);
      e.setLoggable(true);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
    }

    AllocationBalance allocationBalance;

    allocationBalance = retrieveDebitAllocByCase(creditILI, allocationCase);

    // update  the credit instruction line item
    // credit instruction line item key
    InstructionLineItemKey cdtILIKey = new InstructionLineItemKey();

    cdtILIKey.instructLineItemID = creditILI.instructLineItemID;

    StatusCodeUnprocessedAmt unprocAmtStatus = new StatusCodeUnprocessedAmt();

    unprocAmtStatus.versionNo = creditILI.versionNo;

    if (allocationBalance.allocationBalance.isZero()) {

      unprocAmtStatus.unprocessedAmount = allocationBalance.allocationBalance;
      // "ALL"
      unprocAmtStatus.statusCode = curam.codetable.ILISTATUS.ALLOCATED;

    } else {

      unprocAmtStatus.unprocessedAmount = allocationBalance.allocationBalance;

      // "PRO"
      if (creditILI.instructionLineItemType.equals(
        curam.codetable.ILITYPE.REPAYMENTEXPECTED)) {
        unprocAmtStatus.statusCode = curam.codetable.ILISTATUS.UNPROCESSED;
      } else {
        unprocAmtStatus.statusCode = curam.codetable.ILISTATUS.PROCESSED;
      }

    }

    curam.core.fact.InstructionLineItemFactory.newInstance().modifyStatusUnprocessedAmt(
      cdtILIKey, unprocAmtStatus);

    // update the new versionNo, resulting from the modify, onto the creditILI
    creditILI.versionNo = unprocAmtStatus.versionNo;

  }

  // ___________________________________________________________________________
  /**
   * Retrieve all the outstanding Instruction Line Items for the specified
   * Financial Instruction and allocate the Credit to them.
   *
   *
   * @param creditILI credit instruction line item
   * @param allocatedFinInstructionID allocated financial instruction ID
   */
  public void allocateCreditByFinancialInstruction(
    InstructionLineItemDtls creditILI, AllocationFinInstructionID
    allocatedFinInstructionID) throws AppException, InformationalException {

    AllocationBalance allocationBalance;

    if (creditILI.unprocessedAmount.isNegative()) {

      AppException e = new AppException(
        curam.message.BPOALLOCATECREDIT.ERR_ILI_FV_ALLOC_AMT_NEGATIVE);

      e.arg(creditILI.instructLineItemID);
      e.setLoggable(true);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    allocationBalance = retrieveDebitAllocByFinInstID(creditILI,
      allocatedFinInstructionID);

    // update the credit instruction line item
    InstructionLineItemKey cdtILIKey = new InstructionLineItemKey();

    cdtILIKey.instructLineItemID = creditILI.instructLineItemID;

    if (allocationBalance.allocationBalance.isZero()) {

      StatusCodeUnprocessedAmt unprocAmtStatus = new StatusCodeUnprocessedAmt();

      curam.util.type.Money zeroAmount = curam.util.type.Money.kZeroMoney;

      unprocAmtStatus.unprocessedAmount = zeroAmount;
      // "ALL"
      unprocAmtStatus.statusCode = curam.codetable.ILISTATUS.ALLOCATED;
      unprocAmtStatus.versionNo = creditILI.versionNo;
      curam.core.intf.InstructionLineItem instrLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();

      instrLineItemObj.modifyStatusUnprocessedAmt(cdtILIKey, unprocAmtStatus);

      // update the new versionNo, resulting from the modify, onto the
      // creditILI
      creditILI.versionNo = unprocAmtStatus.versionNo;

    } else {

      ILIUnprocessedAmt cdtUnprocAmt = new ILIUnprocessedAmt();

      cdtUnprocAmt.unprocessedAmount = allocationBalance.allocationBalance;
      cdtUnprocAmt.versionNo = creditILI.versionNo;

      curam.core.fact.InstructionLineItemFactory.newInstance().modifyUnprocessedAmt(
        cdtILIKey, cdtUnprocAmt);

      // update the new versionNo, resulting from the modify, onto the creditILI
      creditILI.versionNo = cdtUnprocAmt.versionNo;

    }

  }

  // ___________________________________________________________________________
  /**
   * Retrieve specified Instruction Line Items and allocate the credit to it.
   *
   *
   * @param creditILI credit instruction line item
   * @param dbtILI debit  instruction line item
   * @param allocatedAmt allocated amount.
   */
  public void allocateCreditByILI(InstructionLineItemDtls creditILI,
    InstructionLineItemDtls dbtILI, AllocatedAmt allocatedAmt)
    throws AppException, InformationalException {

    // "CDT"
    if (dbtILI.creditDebitType.equals(curam.codetable.CREDITDEBIT.CREDIT)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(curam.message.BPOALLOCATECREDIT.ERR_ILI_XRV_CDT_TO_CDT),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    updateDebitAllocations(creditILI, dbtILI, allocatedAmt);

    // update  the credit instruction line item
    if (allocatedAmt.amount.isPositive()) {

      // an allocation occurred, therefore update the credit allocation
      InstructionLineItemKey cdtILIKey = new InstructionLineItemKey();

      cdtILIKey.instructLineItemID = creditILI.instructLineItemID;

      if (creditILI.unprocessedAmount.getValue()
        == allocatedAmt.amount.getValue()) {

        StatusCodeUnprocessedAmt unprocAmtStatus = new StatusCodeUnprocessedAmt();

        curam.util.type.Money zeroAmount = curam.util.type.Money.kZeroMoney;

        unprocAmtStatus.unprocessedAmount = zeroAmount;

        // "ALL"
        unprocAmtStatus.statusCode = curam.codetable.ILISTATUS.ALLOCATED;
        unprocAmtStatus.versionNo = creditILI.versionNo;

        curam.core.fact.InstructionLineItemFactory.newInstance().modifyStatusUnprocessedAmt(
          cdtILIKey, unprocAmtStatus);

        // update the new versionNo, resulting from the modify, onto the
        // creditILI
        creditILI.versionNo = unprocAmtStatus.versionNo;

      } else {

        ILIUnprocessedAmt cdtUnprocAmt = new ILIUnprocessedAmt();

        cdtUnprocAmt.versionNo = creditILI.versionNo;

        cdtUnprocAmt.unprocessedAmount = new curam.util.type.Money(
          creditILI.unprocessedAmount.getValue()
            - allocatedAmt.amount.getValue());

        curam.core.fact.InstructionLineItemFactory.newInstance().modifyUnprocessedAmt(
          cdtILIKey, cdtUnprocAmt);

        // update the new versionNo, resulting from the modify, onto the
        // creditILI
        creditILI.versionNo = cdtUnprocAmt.versionNo;

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Determine the correct allocation amount, create an allocation line for
   * that amount and update the debit Instruction Line Item appropriately.
   *
   *
   * @param creditILI credit instruction line item
   * @param dbtILI debit  instruction line item
   * @param allocatedAmt allocated amount.
   */
  public void updateDebitAllocations(InstructionLineItemDtls creditILI,
    InstructionLineItemDtls dbtILI, AllocatedAmt allocatedAmt)
    throws AppException, InformationalException {

    // instructionLineItem manipulation variables
    curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();
    InstructionLineItemKey dbtILIKey = new InstructionLineItemKey();

    // uniqueID manipulation variable
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // product manipulation variables
    ProductDtls productDtls;

    boolean debitFullyAllocated = false;

    dbtILIKey.instructLineItemID = dbtILI.instructLineItemID;

    // check that the amount values are valid for allocation
    if ((dbtILI.unprocessedAmount.isNegative())
      && (!dbtILI.instructLineItemCategory.equals(
        curam.codetable.ILICATEGORY.LIABILITYINSTRUCTION))) {

      AppException e = new AppException(
        curam.message.BPOALLOCATECREDIT.ERR_ILI_FV_ALLOC_AMT_NEGATIVE);

      e.arg(dbtILI.instructLineItemID);
      e.setLoggable(true);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 5);
    }

    if (creditILI.unprocessedAmount.isNegative()) {

      AppException e = new AppException(
        curam.message.BPOALLOCATECREDIT.ERR_ILI_FV_ALLOC_AMT_NEGATIVE);

      e.arg(creditILI.instructLineItemID);
      e.setLoggable(true);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    if (dbtILI.caseID != 0) {

      // productDelivery manipulation variables
      curam.core.intf.ProductDelivery productDeliveryObj = curam.core.fact.ProductDeliveryFactory.newInstance();
      ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
      ProductDeliveryDtls productDeliveryDtls;

      // product manipulation variables
      curam.core.intf.Product productObj = curam.core.fact.ProductFactory.newInstance();
      ProductKey productKey = new ProductKey();

      // set key to read the productDelivery entity
      productDeliveryKey.caseID = dbtILI.caseID;

      // read the productDelivery entity
      productDeliveryDtls = productDeliveryObj.read(productDeliveryKey);

      // set key to read the product entity
      productKey.productID = productDeliveryDtls.productID;

      // read the product entity
      productDtls = productObj.read(productKey);

    } else {
      productDtls = null;
    }

    if (creditILI.instructionLineItemType.equals(
      curam.codetable.ILITYPE.OVERALLOCATION)) {

      // Create the allocation line
      curam.core.intf.AllocationLine allocationLineObj = curam.core.fact.AllocationLineFactory.newInstance();
      AllocationLineDtls allocDtls = new AllocationLineDtls();

      allocDtls.allocationLineID = uniqueIDObj.getNextID();

      allocDtls.instructLineItemID = creditILI.instructLineItemID;
      allocDtls.relatedLineItemID = dbtILI.instructLineItemID;
      allocDtls.allocationDate = curam.util.type.Date.getCurrentDate();
      allocDtls.amount = allocatedAmt.amount;
      allocDtls.statusCode = curam.codetable.ALLOCATIONSTATUS.ACTIVE;

      // insert allocationLine record
      allocationLineObj.insert(allocDtls);

    } else {

      // nothing left on the Debit to allocate, change the status to processed
      // except for those ILI's with a category code of 'LBY' as these will
      // always be available for allocation until reconciliation occurs.
      if ((!dbtILI.instructLineItemCategory.equals(
        curam.codetable.ILICATEGORY.LIABILITYINSTRUCTION))
          && (dbtILI.unprocessedAmount.isZero())) {

        // instructionLineItem manipulation variables
        ILIStatusCode iliStatus = new ILIStatusCode();

        // set status to Allocated
        iliStatus.statusCode = curam.codetable.ILISTATUS.ALLOCATED;
        iliStatus.versionNo = dbtILI.versionNo;

        // update the status of the ILI to Allocated
        instructionLineItemObj.modifyStatusCode(dbtILIKey, iliStatus);

      } else {

        // Now using the allocatedAmt that is passed in
        if (dbtILI.unprocessedAmount.getValue()
          > allocatedAmt.amount.getValue()) {

          debitFullyAllocated = false;

        } else {

          if (productDtls != null) {

            if (!productDtls.overAllocationInd) {

              debitFullyAllocated = true;
            }

          } else if (dbtILI.caseID == 0) {

            debitFullyAllocated = true;
          }

        }

        // allocationLine manipulation variables
        curam.core.intf.AllocationLine allocationLineObj = curam.core.fact.AllocationLineFactory.newInstance();
        AllocationLineDtls allocDtls = new AllocationLineDtls();

        allocDtls.allocationLineID = uniqueIDObj.getNextID();

        allocDtls.instructLineItemID = creditILI.instructLineItemID;
        allocDtls.relatedLineItemID = dbtILI.instructLineItemID;
        allocDtls.allocationDate = curam.util.type.Date.getCurrentDate();
        allocDtls.amount = allocatedAmt.amount;
        allocDtls.statusCode = curam.codetable.ALLOCATIONSTATUS.DEFAULTCODE;

        // insert the allocationLine record
        allocationLineObj.insert(allocDtls);

        curam.util.type.Money zeroAmount = curam.util.type.Money.kZeroMoney;

        if (debitFullyAllocated) {

          StatusCodeUnprocessedAmt iliStatusUnprocAmt = new StatusCodeUnprocessedAmt();

          // set details for modification
          iliStatusUnprocAmt.unprocessedAmount = zeroAmount;
          iliStatusUnprocAmt.statusCode = curam.codetable.ILISTATUS.ALLOCATED;
          iliStatusUnprocAmt.versionNo = dbtILI.versionNo;

          // update the status of the ILI to Allocated
          instructionLineItemObj.modifyStatusUnprocessedAmt(dbtILIKey,
            iliStatusUnprocAmt);

          // update new versionNo resulting from the modify onto the creditILI
          dbtILI.versionNo = iliStatusUnprocAmt.versionNo;

        } else {

          ILIUnprocessedAmt iliUnprocAmt = new ILIUnprocessedAmt();

          iliUnprocAmt.unprocessedAmount = new curam.util.type.Money(
            dbtILI.unprocessedAmount.getValue()
              - allocatedAmt.amount.getValue());

          iliUnprocAmt.versionNo = dbtILI.versionNo;

          // modify the ILI record
          instructionLineItemObj.modifyUnprocessedAmt(dbtILIKey, iliUnprocAmt);

          // Update new versionNo resulting from the modify, onto the creditILI
          dbtILI.versionNo = iliUnprocAmt.versionNo;

        }

      }

    }

  }

  // ___________________________________________________________________________
  /**
   * Allocation of a payment received. Calling the allocateCreditByILI method
   * using the allocated amount along with the credit and debit ILI's.
   *
   *
   * @param pmtRecvdILI  credit instruction line item (ILI)
   * @param debitILI debit  instruction line item (ILI)
   * @param allocatedAmt allocated amount
   */
  public void allocatePaymentReceived(InstructionLineItemDtls pmtRecvdILI,
    InstructionLineItemDtls debitILI, AllocatedAmt allocatedAmt)
    throws AppException, InformationalException {

    ILICategoryDtls iliCategoryDtls = new ILICategoryDtls();

    iliCategoryDtls.instructionLineItemType = curam.codetable.ILITYPE.ALLOCATEDPMTRECVD;
    iliCategoryDtls.statusCode = curam.codetable.ILISTATUS.ALLOCATED;
    iliCategoryDtls.creditDebitType = pmtRecvdILI.creditDebitType;
    iliCategoryDtls.unprocessedAmount = curam.util.type.Money.kZeroMoney;

    allocate(pmtRecvdILI, debitILI, allocatedAmt, iliCategoryDtls);
  }

  // ___________________________________________________________________________
  /**
   * To retrieve all the debit  Instruction Line Items for the specified Case
   * to allocate to.
   *
   *
   * @param creditILI credit instruction line item
   * @param allocationCase allocation case
   *
   * @return Allocation Balance
   */
  public AllocationBalance retrieveDebitAllocByCase(
    InstructionLineItemDtls creditILI, AllocationCase allocationCase)
    throws AppException, InformationalException {

    AllocationBalance allocationBalance = new AllocationBalance();

    allocationBalance.allocationBalance = creditILI.unprocessedAmount;

    // retrieve the debit instruction line items to allocate to.
    InstructionLineItemDtlsList iliDtlsList;

    CaseIDStatusCodeCreditDebitType iliCaseStatusCBT = new CaseIDStatusCodeCreditDebitType();

    boolean allocateCase = false;

    iliCaseStatusCBT.caseID = allocationCase.caseID;

    // "PRO"
    iliCaseStatusCBT.statusCode = curam.codetable.ILISTATUS.PROCESSED;

    // "DBT"
    iliCaseStatusCBT.creditDebitType = curam.codetable.CREDITDEBIT.DEBIT;

    iliDtlsList = curam.core.fact.InstructionLineItemFactory.newInstance().searchByCaseIDStatusCodeCreditDebitType(
      iliCaseStatusCBT);

    // i - "begin" iterator, which is increased until reaches "end"
    // j - "end" iterator which is constant and points to the end of the list.
    int i;

    // all constant objects must be initialized, therefore the initialization
    // is not inside the for loop
    final int j = iliDtlsList.dtls.size();

    for (i = 0; i < j; i++) {

      if (allocationBalance.allocationBalance.isZero()) {

        break;

      } else {

        allocateCase = true;

        if ((creditILI.instructionLineItemType.equals(
          curam.codetable.ILITYPE.REPAYMENTEXPECTED))
            && ((!iliDtlsList.dtls.item(i).instructionLineItemType.equals(
              curam.codetable.ILITYPE.LOANLIABILITY))
                && (!iliDtlsList.dtls.item(i).instructionLineItemType.equals(
                  curam.codetable.ILITYPE.INTERESTAPPLIED)))) {

          allocateCase = false;
        }

        if ((creditILI.instructionLineItemType.equals(
          curam.codetable.ILITYPE.LOANREPAYMENT))
            && (!iliDtlsList.dtls.item(i).instructionLineItemType.equals(
              curam.codetable.ILITYPE.REPAYMENTDUE))) {

          allocateCase = false;
        }

        if ((iliDtlsList.dtls.item(i).instructLineItemCategory.equals(
          curam.codetable.ILICATEGORY.REVERSALINSTRUCTION))
            && (iliDtlsList.dtls.item(i).instructionLineItemType.equals(
              curam.codetable.ILITYPE.ALLOCATEDREVERSAL))) {

          RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();

          RelatedILIDetailsList relatedILIDetailsList;

          relatedILIidentifier.instructLineItemID = iliDtlsList.dtls.item(i).instructLineItemID;
          relatedILIidentifier.type = curam.codetable.ILIRELATIONSHIP.REVERSALS;

          relatedILIDetailsList = curam.core.fact.InstructionLineItemFactory.newInstance().searchRelatedILIByRelatedLineItemIDType(
            relatedILIidentifier);

          // Related instruction line item details list iterator
          for (int k = 0; k < relatedILIDetailsList.dtls.size(); k++) {

            if ((relatedILIDetailsList.dtls.item(k).instructionLineItemType.equals(
              curam.codetable.ILITYPE.REPAYMENTEXPECTED))
                && (creditILI.instructionLineItemType.equals(
                  curam.codetable.ILITYPE.REPAYMENTEXPECTED))) {

              allocateCase = true;
              break;
            }

            if ((relatedILIDetailsList.dtls.item(k).instructionLineItemType.equals(
              curam.codetable.ILITYPE.REPAYMENTDUE))
                && (creditILI.instructionLineItemType.equals(
                  curam.codetable.ILITYPE.LOANREPAYMENT))) {

              allocateCase = true;
              break;
            }

          }

        }

        if (allocateCase) {

          if (iliDtlsList.dtls.item(i).unprocessedAmount.isNegative()) {

            AppException e = new AppException(
              curam.message.BPOALLOCATECREDIT.ERR_ILI_FV_ALLOC_AMT_NEGATIVE);

            e.arg(iliDtlsList.dtls.item(i).instructLineItemID);
            e.setLoggable(true);
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
              e,
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
          }

          // Pick the allocation amount
          if (iliDtlsList.dtls.item(i).unprocessedAmount.isZero()) {

            // nothing left on the debit to allocate, change the status to
            // processed
            InstructionLineItemKey iliKey = new InstructionLineItemKey();
            ILIStatusCode iliStatus = new ILIStatusCode();
            curam.core.intf.InstructionLineItem InstructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();

            iliKey.instructLineItemID = iliDtlsList.dtls.item(i).instructLineItemID;
            iliStatus.statusCode = curam.codetable.ILISTATUS.ALLOCATED;
            iliStatus.versionNo = iliDtlsList.dtls.item(i).versionNo;

            InstructionLineItemObj.modifyStatusCode(iliKey, iliStatus);

          } else {

            AllocatedAmt allocatedAmt = new AllocatedAmt();

            // decide on the allocation amount to use for this debit ILI
            if (iliDtlsList.dtls.item(i).unprocessedAmount.getValue()
              >= allocationBalance.allocationBalance.getValue()) {

              allocatedAmt.amount = allocationBalance.allocationBalance;

            } else {

              allocatedAmt.amount = iliDtlsList.dtls.item(i).unprocessedAmount;
            }

            updateDebitAllocations(creditILI, iliDtlsList.dtls.item(i),
              allocatedAmt);

            allocationBalance.allocationBalance = new curam.util.type.Money(
              allocationBalance.allocationBalance.getValue()
                - allocatedAmt.amount.getValue());

          }

        }

      }

    }

    return allocationBalance;
  }

  // ___________________________________________________________________________
  /**
   * To retrieve all the debit  Instruction Line Items for the
   * specifiedFinancial Instruction to allocate to.
   *
   * @param creditILI credit instruction line item
   * @param allocatedFinInstructionID allocated financial instruction ID
   */
  public AllocationBalance retrieveDebitAllocByFinInstID(
    InstructionLineItemDtls creditILI,
    AllocationFinInstructionID allocatedFinInstructionID)
    throws AppException, InformationalException {

    AllocationBalance allocationBalance = new AllocationBalance();

    allocationBalance.allocationBalance = creditILI.unprocessedAmount;

    // retrieve the debit instruction line items to allocate to.
    InstructionLineItemDtlsList iliDtlsList;
    StatusFinInstructID statusFinInstr = new StatusFinInstructID();

    statusFinInstr.finInstructionID = allocatedFinInstructionID.finInstructionID;

    // "PRO"
    statusFinInstr.statusCode = curam.codetable.ILISTATUS.PROCESSED;

    iliDtlsList = curam.core.fact.InstructionLineItemFactory.newInstance().searchByFinInstructStatus(
      statusFinInstr);

    // i - "begin" iterator, which is increased until reaches "end"
    // j - "end" iterator which is constant and points to the end of the list.
    // all constant objects must be initialized, therefore the initialization
    // is not inside the for loop
    final int j = iliDtlsList.dtls.size();

    for (int i = 0; i < j; i++) {

      // We cannot put this condition into one statement like
      // ((i < j) || (allocationBalance == 0))
      // due to the early loop termination possibility, which can occur.
      if (allocationBalance.allocationBalance.isZero()) {
        break;
      }

      if (iliDtlsList.dtls.item(i).creditDebitType.equals(
        curam.codetable.CREDITDEBIT.CREDIT)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOALLOCATECREDIT.ERR_ILI_XRV_CDT_TO_CDT),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      // check that the debit ILI has a valid allocation amount
      if (iliDtlsList.dtls.item(i).unprocessedAmount.isNegative()) {

        AppException e = new AppException(
          curam.message.BPOALLOCATECREDIT.ERR_ILI_FV_ALLOC_AMT_NEGATIVE);

        e.arg(iliDtlsList.dtls.item(i).instructLineItemID);
        e.setLoggable(true);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          4);
      }

      // Pick the allocation amount
      if (iliDtlsList.dtls.item(i).unprocessedAmount.isZero()) {

        // nothing left on the debit to allocate, change the status to processed
        InstructionLineItemKey iliKey = new InstructionLineItemKey();
        ILIStatusCode iliStatus = new ILIStatusCode();

        iliKey.instructLineItemID = iliDtlsList.dtls.item(i).instructLineItemID;
        iliStatus.statusCode = curam.codetable.ILISTATUS.ALLOCATED;
        iliStatus.versionNo = iliDtlsList.dtls.item(i).versionNo;

        curam.core.fact.InstructionLineItemFactory.newInstance().modifyStatusCode(
          iliKey, iliStatus);

      } else {

        AllocatedAmt allocatedAmt = new AllocatedAmt();

        if (iliDtlsList.dtls.item(i).unprocessedAmount.getValue()
          >= allocationBalance.allocationBalance.getValue()) {

          allocatedAmt.amount = allocationBalance.allocationBalance;

        } else {

          allocatedAmt.amount = iliDtlsList.dtls.item(i).unprocessedAmount;
        }

        updateDebitAllocations(creditILI, iliDtlsList.dtls.item(i),
          allocatedAmt);

        allocationBalance.allocationBalance = new curam.util.type.Money(
          allocationBalance.allocationBalance.getValue()
            - allocatedAmt.amount.getValue());

      }

    }

    return allocationBalance;
  }

  // ___________________________________________________________________________
  /**
   * To allocate a Deduction Adjustment InstructionLineItem to a debit
   * InstructionLineItem.
   *
   * @param dedAdjILI Instruction Line Item Dtls
   * @param debitILI Instruction Line Item Dtls
   * @param allocatedAmt Allocated Amount
   */
  public void allocateDeductionAdjustment(InstructionLineItemDtls dedAdjILI,
    InstructionLineItemDtls debitILI, AllocatedAmt allocatedAmt)
    throws AppException, InformationalException {

    ILICategoryDtls iliCategoryDtls = new ILICategoryDtls();

    iliCategoryDtls.instructionLineItemType = curam.codetable.ILITYPE.ALLOCATEDDEDUCTIONADJ;
    iliCategoryDtls.statusCode = curam.codetable.ILISTATUS.ALLOCATED;
    iliCategoryDtls.creditDebitType = dedAdjILI.creditDebitType;
    iliCategoryDtls.unprocessedAmount = curam.util.type.Money.kZeroMoney;

    allocate(dedAdjILI, debitILI, allocatedAmt, iliCategoryDtls);
  }

  // ___________________________________________________________________________
  /**
   * Description:
   * To allocate a credit InstructionLineItem against a debit
   * InstructionLineItem where the credit amount exceeds the debit
   * unprocessed amount.
   *
   *
   * @param creditILI credit Instruction Line Item Dtls
   * @param debitILI debit Instruction Line Item Dtls
   * @param overallocatedAmt Allocated Amount
   */
  public void overallocateCreditTransaction(InstructionLineItemDtls creditILI,
    InstructionLineItemDtls debitILI, AllocatedAmt overallocatedAmt)
    throws AppException, InformationalException {

    ILICategoryDtls iliCategoryDtls = new ILICategoryDtls();

    iliCategoryDtls.instructionLineItemType = curam.codetable.ILITYPE.OVERALLOCATION;
    iliCategoryDtls.statusCode = curam.codetable.ILISTATUS.PROCESSED;
    iliCategoryDtls.creditDebitType = curam.codetable.CREDITDEBIT.CREDIT;
    iliCategoryDtls.unprocessedAmount = overallocatedAmt.amount;

    allocate(creditILI, debitILI, overallocatedAmt, iliCategoryDtls);
  }

  // ___________________________________________________________________________
  /**
   * Allocation of a payment. Using the allocated amount along with the credit
   * and debit ILI's.
   *
   * @param instructionLineItemDtls  Credit instruction line item details
   * @param debitILI Debit instruction line item details
   * @param allocatedAmt Allocated amount
   * @param iliCategoryDtls Instruction line item category details
   */
  public void allocate(InstructionLineItemDtls instructionLineItemDtls,
    InstructionLineItemDtls debitILI, AllocatedAmt allocatedAmt,
    ILICategoryDtls iliCategoryDtls)
    throws AppException, InformationalException {

    // maintainInstructionLineItem manipulation variables
    curam.core.intf.MaintainInstructionLineItem maintainInstructionLineItemObj = curam.core.fact.MaintainInstructionLineItemFactory.newInstance();

    // instructionLineItem manipulation variables
    InstructionLineItemDetails iliDetails = new InstructionLineItemDetails();
    InstructionLineItemKey cdtILIKey = new InstructionLineItemKey();
    InstructionLineItemDtls allocatedILI = new InstructionLineItemDtls();
    curam.core.intf.InstructionLineItem instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();
    InstructionLineItemID iliID;

    // Based on CURAM_AMOUNT
    curam.util.type.Money zeroAmount = curam.util.type.Money.kZeroMoney;

    // Create InstructionLineItem
    iliDetails.amount = allocatedAmt.amount;

    iliDetails.unprocessedAmount = iliCategoryDtls.unprocessedAmount;
    iliDetails.instructionLineItemType = iliCategoryDtls.instructionLineItemType;
    iliDetails.statusCode = iliCategoryDtls.statusCode;
    iliDetails.creditDebitType = iliCategoryDtls.creditDebitType;

    iliDetails.instructLineItemCategory = instructionLineItemDtls.instructLineItemCategory;
    iliDetails.financialCompID = instructionLineItemDtls.financialCompID;
    iliDetails.effectiveDate = instructionLineItemDtls.effectiveDate;
    iliDetails.finInstructionID = instructionLineItemDtls.finInstructionID;
    iliDetails.concernRoleID = instructionLineItemDtls.concernRoleID;
    iliDetails.deliveryMethodType = instructionLineItemDtls.deliveryMethodType;
    iliDetails.currencyTypeCode = instructionLineItemDtls.currencyTypeCode;
    iliDetails.currencyExchangeID = instructionLineItemDtls.currencyExchangeID;
    iliDetails.adjustmentInd = instructionLineItemDtls.adjustmentInd;
    iliDetails.adjustmentFrequency = instructionLineItemDtls.adjustmentFrequency;
    iliDetails.nextAdjustmentDate = instructionLineItemDtls.nextAdjustmentDate;
    iliDetails.instrumentGenInd = instructionLineItemDtls.instrumentGenInd;

    iliDetails.coverPeriodFrom = debitILI.coverPeriodFrom;
    iliDetails.coverPeriodTo = debitILI.coverPeriodTo;
    iliDetails.caseID = debitILI.caseID;
    iliDetails.caseNomineeID = debitILI.caseNomineeID;
    iliDetails.primaryClientID = debitILI.primaryClientID;
    iliDetails.fundID = debitILI.fundID;
    // BEGIN, CR00074927, JI
    iliDetails.dueDate = curam.util.type.Date.kZeroDate;
    iliDetails.inRespectOfID = 0;
    // END, CR00074927

    // add instructionLineItem
    iliID = maintainInstructionLineItemObj.addInstructionLineItem(iliDetails);

    // Mapping one-to-one the from iliDetails to allocatedILI
    allocatedILI.assign(iliDetails);

    // Mapping versionNo to allocatedILI
    allocatedILI.versionNo = iliID.versionNo;
    allocatedILI.instructLineItemID = iliID.instructionLineItemID;

    // Creating an Allocation between this new Payment Received ILI and the
    // debit
    updateDebitAllocations(allocatedILI, debitILI, allocatedAmt);

    // Update the existing (unallocated) payment received instruction line item
    if (allocatedAmt.amount.isPositive()) {

      // an allocation occurred, therefore update the credit allocation
      cdtILIKey.instructLineItemID = instructionLineItemDtls.instructLineItemID;

      Money tempAmount = new Money(
        instructionLineItemDtls.unprocessedAmount.getValue()
          - allocatedAmt.amount.getValue());

      if (tempAmount.isZero()) {

        StatusCodeUnprocessedAmt unprocAmtStatus = new StatusCodeUnprocessedAmt();

        unprocAmtStatus.unprocessedAmount = zeroAmount;
        unprocAmtStatus.statusCode = curam.codetable.ILISTATUS.ALLOCATED;
        unprocAmtStatus.versionNo = instructionLineItemDtls.versionNo;

        instructionLineItemObj.modifyStatusUnprocessedAmt(cdtILIKey,
          unprocAmtStatus);

        // return the attributes that have just been updated
        instructionLineItemDtls.versionNo = unprocAmtStatus.versionNo;
        instructionLineItemDtls.statusCode = curam.codetable.ILISTATUS.ALLOCATED;
        instructionLineItemDtls.unprocessedAmount = zeroAmount;

      } else {

        ILIUnprocessedAmt cdtUnprocAmt = new ILIUnprocessedAmt();

        cdtUnprocAmt.versionNo = instructionLineItemDtls.versionNo;
        cdtUnprocAmt.unprocessedAmount = tempAmount;

        // modify instructionLineItem record
        instructionLineItemObj.modifyUnprocessedAmt(cdtILIKey, cdtUnprocAmt);

        // return the attributes that have just been updated
        instructionLineItemDtls.versionNo = cdtUnprocAmt.versionNo;
        instructionLineItemDtls.unprocessedAmount = cdtUnprocAmt.unprocessedAmount;
      }

    }

  }
}
