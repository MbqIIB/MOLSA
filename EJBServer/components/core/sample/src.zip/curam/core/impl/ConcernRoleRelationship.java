/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import java.util.ArrayList;
import java.util.HashMap;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.ENTITYATTRIBUTENAMES;
import curam.codetable.RECORDSTATUS;
import curam.codetable.RELATIONSHIPTYPECODE;
import curam.core.events.CONCERNROLERELATIONSHIP;
import curam.core.fact.ConcernRoleRelSnapshotFactory;
import curam.core.intf.ConcernRoleRelSnapshot;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleRelSnapshotDtls;
import curam.core.struct.ConcernRoleRelSnapshotKey;
import curam.core.struct.ConcernRoleRelationshipDtls;
import curam.core.struct.ConcernRoleRelationshipKey;
import curam.core.struct.RelationshipByConcernRoleIDStatusKey;
import curam.message.PARTICIPANTDATACASE;
import curam.message.SUMMARYDETAILS;
import curam.pdc.fact.PDCUtilFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;


public abstract class ConcernRoleRelationship extends curam.core.base.ConcernRoleRelationship
  implements ParticipantEvidenceInterface {

  // BEGIN, CR00059580, MMC

  protected class ConcernRoleRelationshipCache {
    public ConcernRoleRelationshipCache() {
      map = new HashMap<Long, ConcernRoleRelationshipDtls>();
      transactionID = 0;
    }
    HashMap<Long, ConcernRoleRelationshipDtls> map;
    int transactionID;
  }
  protected static ThreadLocal<ConcernRoleRelationshipCache> cachedReadDetailsTL = new ThreadLocal<ConcernRoleRelationshipCache>();
  // BEGIN, CR00065902, MMC

  // ___________________________________________________________________________
  /**
   * Clear cached data in cachedReadDetailsTL
   */
  protected void clearCaches() {
    ConcernRoleRelationshipCache cache = cachedReadDetailsTL.get();

    if (cache != null) {
      cache.map.clear();
    } else {
      cache = new ConcernRoleRelationshipCache();
      cachedReadDetailsTL.set(cache);
    }
    cache.transactionID = TransactionInfo.getIdentifierForThisThread();

  }

  // __________________________________________________________________________
  /**
   * Inserts details into database. The cache is cleared first.
   *
   * @param details  Contains entity details
   */
  public void insert(ConcernRoleRelationshipDtls details) throws AppException, InformationalException {
    this.clearCaches();
    super.insert(details);
  }

  // __________________________________________________________________________
  /**
   * Modifies details in the database Entity. The cache is cleared first.
   *
   * @param key  Contains key to access entity details
   * @param details  Contains details to modify
   */
  public void modify(ConcernRoleRelationshipKey key, ConcernRoleRelationshipDtls details) throws AppException, InformationalException {
    // We want to clear the cache in case for some reason the database
    // evidence is required e.g. if the evidence was updated by another user.
    // So to ensure we have the correct evidence, clear the cache and force a
    // read from the database
    this.clearCaches();

    super.modify(key, details);

    // The reason why we have to clear the cache here is a result of how the
    // evidence controller performs the modifying of evidence. PreModifying the
    // record it reads the details (first time it reads the details so will be
    // read from database and cached). The record is modified and post
    // modifying, the evidence controller calls performValidation
    // (validates the record) which requires a read of the evidence. The cached
    // evidence has stored the evidence PRIOR to the modification of the record.
    // Therefore we want to go to the database to read the modified evidence and
    // as a result clear the cache post modification.
    this.clearCaches();
  }

  // ___________________________________________________________________________
  /**
   * Calculates the AttributionDates For entity,
   * specifically for its use as a ParticpantEvidence.
   *
   * @param caseKey
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return AttributedDateDetails
   */
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey, EIEvidenceKey evKey) throws AppException, InformationalException {
   
    AttributedDateDetails retAttributedDateDetails = new AttributedDateDetails();
    
    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    ConcernRoleRelationshipDtls concernRoleRelationshipDtls = read(evKey);

    // END, CR00240667    

    retAttributedDateDetails.fromDate = concernRoleRelationshipDtls.startDate;
    retAttributedDateDetails.toDate = concernRoleRelationshipDtls.endDate;
    return retAttributedDateDetails;
  }

  /**
   * Reads the entity details given the evidence record identifier.
   *
   * @param key The evidence record identifier.
   *
   * @return The entity details.
   *
   * @throws InformationalException
   * @throws AppException
   */
  protected ConcernRoleRelationshipDtls read(EIEvidenceKey evKey)
    throws AppException, InformationalException {
    
    curam.core.intf.ConcernRoleRelationship concernRoleRelationshipObj = curam.core.fact.ConcernRoleRelationshipFactory.newInstance();
  
    ConcernRoleRelationshipKey concernRoleRelationshipKey = new ConcernRoleRelationshipKey();

    concernRoleRelationshipKey.concernRoleRelationshipID = evKey.evidenceID;
    ConcernRoleRelationshipDtls concernRoleRelationshipDtls = new ConcernRoleRelationshipDtls();

    // BEGIN, CR00067890, POH
    // read concernRoleRelationship details
    try {
      concernRoleRelationshipDtls = concernRoleRelationshipObj.read(
        concernRoleRelationshipKey);
    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot concernRoleRelationship entity
      ConcernRoleRelSnapshotKey concernRoleRelationshipSnapshotKey = new ConcernRoleRelSnapshotKey();

      ConcernRoleRelSnapshot concernRoleRelationshipSnapshotObj = ConcernRoleRelSnapshotFactory.newInstance();

      // BEGIN, CR00068202, POH
      // populate the concernRoleRelationship snapshot key with passed in parameter
      concernRoleRelationshipSnapshotKey.concernRoleRelshipSnapshotID = evKey.evidenceID;
      // END, CR00068202

      // read concernRoleRelationship snapshot details
      ConcernRoleRelSnapshotDtls concernRoleRelationshipSnapshotDtls = concernRoleRelationshipSnapshotObj.read(
        concernRoleRelationshipSnapshotKey);

      concernRoleRelationshipDtls.assign(concernRoleRelationshipSnapshotDtls);
    }
    // END, CR00067890
    return concernRoleRelationshipDtls;
  }

  // ___________________________________________________________________________
  /**
   * Get evidence details for the list display
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @return Evidence details to be displayed on the list page
   */
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key) throws AppException, InformationalException {
    // Return object
    EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // BEGIN, CR00060473, MMC

    try {
      // ConcernRoleRelationship entity key
      ConcernRoleRelationshipKey concernRoleRelationshipKey = new ConcernRoleRelationshipKey();

      // Read the ConcernRoleRelationship entity to get display details
      concernRoleRelationshipKey.concernRoleRelationshipID = key.evidenceID;

      curam.core.intf.ConcernRoleRelationship concernRoleRelationshipObj = curam.core.fact.ConcernRoleRelationshipFactory.newInstance();
      ConcernRoleRelationshipDtls concernRoleRelationshipDtls = concernRoleRelationshipObj.read(
        concernRoleRelationshipKey);

      // Set the start / end dates
      eiFieldsForListDisplayDtls.startDate = concernRoleRelationshipDtls.startDate;
      eiFieldsForListDisplayDtls.endDate = concernRoleRelationshipDtls.endDate;

      // Set the summary details.
      curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

      curam.core.struct.ConcernRoleKey concernRoleKey = new curam.core.struct.ConcernRoleKey();

      concernRoleKey.concernRoleID = concernRoleRelationshipDtls.relConcernRoleID;
      curam.core.struct.ConcernRoleDtls concernRoleDtls = concernRoleObj.read(
        concernRoleKey);
      
      // BEGIN, CR00241068, CD
      LocalisableString message = new LocalisableString(
        SUMMARYDETAILS.RELATIONSHIP);

      message.arg(
        CodeTable.getOneItem(RELATIONSHIPTYPECODE.TABLENAME,
        concernRoleRelationshipDtls.relationshipType));
      message.arg(concernRoleDtls.concernRoleName);

      eiFieldsForListDisplayDtls.summary = message.getMessage(
        ProgramLocale.getDefaultServerLocale());
      // END, CR00241068

    } // If the ConcernRoleRelationship record is not found, then the ID passed in must
    // belong to a ConcernRoleRelationshipSnapshot record
    catch (RecordNotFoundException rnfe) {

      // BEGIN, CR00068202, POH
      // Read the ConcernRoleRelationshipSnapshot details
      ConcernRoleRelSnapshotKey concernRoleRelSnapshotKey = new ConcernRoleRelSnapshotKey();

      concernRoleRelSnapshotKey.concernRoleRelshipSnapshotID = key.evidenceID;
      // END, CR00068202

      ConcernRoleRelSnapshotDtls concernRoleRelSnapshotDtls = curam.core.fact.ConcernRoleRelSnapshotFactory.newInstance().read(
        concernRoleRelSnapshotKey);

      // Set the start / end dates
      eiFieldsForListDisplayDtls.startDate = concernRoleRelSnapshotDtls.startDate;
      eiFieldsForListDisplayDtls.endDate = concernRoleRelSnapshotDtls.endDate;

      // Set the summary details.
      curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

      curam.core.struct.ConcernRoleKey concernRoleKey = new curam.core.struct.ConcernRoleKey();

      concernRoleKey.concernRoleID = concernRoleRelSnapshotDtls.relConcernRoleID;
      curam.core.struct.ConcernRoleDtls concernRoleDtls = concernRoleObj.read(
        concernRoleKey);

      // BEGIN, CR00241068, CD
      LocalisableString message = new LocalisableString(
        SUMMARYDETAILS.RELATIONSHIP);

      message.arg(
        CodeTable.getOneItem(RELATIONSHIPTYPECODE.TABLENAME,
        concernRoleRelSnapshotDtls.relationshipType));
      message.arg(concernRoleDtls.concernRoleName);

      eiFieldsForListDisplayDtls.summary = message.getMessage(
        ProgramLocale.getDefaultServerLocale());
      // END, CR00241068
    }
    // END, CR00060473

    return eiFieldsForListDisplayDtls;
  }

  // ___________________________________________________________________________
  /**
   * Inserts evidence details - overrides Participant Evidence inherited abstract method
   *
   * @param dtls Object containing details of entity
   * @param parentKey Key for parent
   *
   * @return eiEvidenceKey - key for inserted evidence
   */
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey) throws AppException, InformationalException {
    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ConcernRoleRelationshipDtls) dtls);

    eiEvidenceKey.evidenceID = ((ConcernRoleRelationshipDtls) dtls).concernRoleRelationshipID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLERELATIONSHIP;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Inserts ConcernRoleRelationship evidence on modification
   *
   * @param dtls Object containing details of entity
   * @param origKey EIEvidenceKey for entity to insert
   * @param parentKey EIEvidenceKey for parent
   * @return the EIEvidenceKey to access the inserted evidence
   */
  public EIEvidenceKey insertEvidenceOnModify(Object dtls, EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException, InformationalException {
    // BEGIN HARP CR00060473, MMC

    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ConcernRoleRelationshipDtls) dtls);

    eiEvidenceKey.evidenceID = ((ConcernRoleRelationshipDtls) dtls).concernRoleRecipRelationID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLERELATIONSHIP;

    return eiEvidenceKey;
    // END HARP CR00060473
  }

  // ___________________________________________________________________________
  /**
   * Modifies evidence details - overrides Participant Evidence inherited abstract method
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @param dtls Object containing details of entity
   */
  public void modifyEvidence(EIEvidenceKey key, Object dtls) throws AppException, InformationalException {
    // ConcernRoleRelationship entity key
    ConcernRoleRelationshipKey concernRoleRelationshipKey = new ConcernRoleRelationshipKey();

    // Set entity key for modify
    concernRoleRelationshipKey.concernRoleRelationshipID = key.evidenceID;

    // Modify details
    modify(concernRoleRelationshipKey, (ConcernRoleRelationshipDtls) dtls);
  }

  // ___________________________________________________________________________
  /**
   * reads all ConcernRoleRelationship Entities by its Parent ID
   *
   * @param key EIEvidenceKey, the evidence key of the parent
   * @return the EIEvidenceKeyList of children
   */
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key) throws AppException, InformationalException {
    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Read evidence details - overrides Participant Evidence inherited abstract method
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @return the Object with the readEvidence details
   */
  public Object readEvidence(EIEvidenceKey key) throws AppException, InformationalException {
    // BEGIN, CR00059688, POH
    curam.core.intf.ConcernRoleRelSnapshot concernRoleRelationshipSnapshotObj = curam.core.fact.ConcernRoleRelSnapshotFactory.newInstance();

    curam.core.intf.ConcernRoleRelationship concernRoleRelationshipObj = curam.core.fact.ConcernRoleRelationshipFactory.newInstance();
    ConcernRoleRelationshipDtls concernRoleRelationshipDtls = new ConcernRoleRelationshipDtls();

    // BEGIN, CR00060473, MMC
    // Attempt to read the record using the evidenceID passed in, if a record is found return the details as an object.
    // If no record is found attempt to read the snapshot record using the passed in evidenceID.
    // If a record is found return the details as an object.

    try {

      ConcernRoleRelationshipKey concernRoleRelationshipKey = new ConcernRoleRelationshipKey();

      concernRoleRelationshipKey.concernRoleRelationshipID = key.evidenceID;
      concernRoleRelationshipDtls = concernRoleRelationshipObj.read(
        concernRoleRelationshipKey);

      return concernRoleRelationshipDtls;

    } catch (RecordNotFoundException recordNotFoundException) {

      // BEGIN, CR00068202, POH
      // If no record has been return for ID passed
      // read from the snapshot entity
      curam.core.struct.ConcernRoleRelSnapshotKey concernRoleRelationshipSnapshotKey = new curam.core.struct.ConcernRoleRelSnapshotKey();

      concernRoleRelationshipSnapshotKey.concernRoleRelshipSnapshotID = key.evidenceID;
      // END, CR00068202

      curam.core.struct.ConcernRoleRelSnapshotDtls concernRoleRelationshipSnapshotDtls = concernRoleRelationshipSnapshotObj.read(
        concernRoleRelationshipSnapshotKey);

      concernRoleRelationshipDtls.assign(concernRoleRelationshipSnapshotDtls);
      return concernRoleRelationshipDtls;
    }
    // END, CR00060473


  }

  // ___________________________________________________________________________
  /**
   * return list for validation
   *
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return the EIEvidenceKeyList for validation
   */
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey) throws AppException, InformationalException {
    // This evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * run validations
   *
   * @param evKey EIEvidenceKey
   * @param evKeyList EIEvidenceKeyList
   * @param mode Validate Mode
   */
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList, ValidateMode mode) throws AppException, InformationalException {// This evidence interface method is currently not implemented for
    // participant evidence.
  }

  // BEGIN, CR00059195, POH
  // ___________________________________________________________________________
  /**
   * To create a new snapshot record of the ConcernRoleRelationship entity,
   * specifically for its use as a ParticpantEvidence.
   *
   * @param key the key to access the entity for which to create a snapshot
   * @return the key to access the snapshot
   */
  public EIEvidenceKey createSnapshot(EIEvidenceKey key) throws AppException, InformationalException {
    EIEvidenceKey retEIEvidenceKey = new EIEvidenceKey();
    // BEGIN, CR00059688, POH
    curam.core.intf.ConcernRoleRelSnapshot concernRoleRelationshipSnapshotObj = curam.core.fact.ConcernRoleRelSnapshotFactory.newInstance();

    curam.core.intf.ConcernRoleRelationship concernRoleRelationshipObj = curam.core.fact.ConcernRoleRelationshipFactory.newInstance();

    ConcernRoleRelationshipKey concernRoleRelationshipKey = new ConcernRoleRelationshipKey();

    concernRoleRelationshipKey.concernRoleRelationshipID = key.evidenceID;

    ConcernRoleRelationshipDtls concernRoleRelationshipDtls = concernRoleRelationshipObj.read(
      concernRoleRelationshipKey);

    curam.core.struct.ConcernRoleRelSnapshotDtls concernRoleRelationshipSnapshotDtls = new curam.core.struct.ConcernRoleRelSnapshotDtls();

    // END, CR00059688
    concernRoleRelationshipSnapshotDtls.assign(concernRoleRelationshipDtls);
    concernRoleRelationshipSnapshotDtls.creationDateTime = DateTime.getCurrentDateTime();
    concernRoleRelationshipSnapshotObj.insert(
      concernRoleRelationshipSnapshotDtls);

    // BEGIN, CR00068202, POH
    retEIEvidenceKey.evidenceID = concernRoleRelationshipSnapshotDtls.concernRoleRelshipSnapshotID;
    retEIEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLERELATIONSHIP;
    // END, CR00068202

    return retEIEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * remove Entity
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @param dtls of entity to remove
   */
  public void removeEvidence(EIEvidenceKey key, Object dtls) throws AppException, InformationalException {
    // BEGIN HARP CR00060473, MMC
    // Entity key
    ConcernRoleRelationshipKey concernRoleRelationshipKey = new ConcernRoleRelationshipKey();

    // Set entity key for modify
    concernRoleRelationshipKey.concernRoleRelationshipID = key.evidenceID;

    // Modify details
    modify(concernRoleRelationshipKey, (ConcernRoleRelationshipDtls) dtls);
    // END HARP CR00060473
  }

  // END, CR00059195

  // ___________________________________________________________________________
  /**
   * Raise a post Insert event
   *
   * @param details for the concernRoleRelationship record.
   */
  protected void postinsert(ConcernRoleRelationshipDtls details)
    throws AppException, InformationalException {

    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLERELATIONSHIP.INSERT_CONCERN_ROLE_RELATIONSHIP;
    // END, CR00047242

    event.primaryEventData = details.concernRoleRelationshipID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // END, CR00059580


  // ___________________________________________________________________________
  /**
   * Raise a post Modify event
   *
   * @param key concernRoleRelationship key to modify
   * @param details details for the concernRoleRelationship record.
   */
  protected void postmodify(ConcernRoleRelationshipKey key,
    ConcernRoleRelationshipDtls details) throws AppException,
      InformationalException {

    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLERELATIONSHIP.MODIFY_CONCERN_ROLE_RELATIONSHIP;
    // END, CR00047242

    event.primaryEventData = details.concernRoleRelationshipID;
    curam.util.events.impl.EventService.raiseEvent(event);

  }

  // ___________________________________________________________________________
  /**
   * Raise a post remove event
   *
   * @param key concernRoleRelationship key to remove
   */
  protected void postremove(ConcernRoleRelationshipKey key)
    throws AppException, InformationalException {

    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLERELATIONSHIP.REMOVE_CONCERN_ROLE_RELATIONSHIP;
    // END, CR00047242

    event.primaryEventData = key.concernRoleRelationshipID;
    curam.util.events.impl.EventService.raiseEvent(event);
  }

  // BEGIN, CR00059697, SK
  // ___________________________________________________________________________
  /**
   * Method to search for records on a participant entity by concernRoleID.
   *
   * @param key - The unique concernRoleID of the participant.
   *
   * @return A list of EIEvidenceKey objects each containing a evidenceID/evidenceType pair.
   */
  public EIEvidenceKeyList readAllByConcernRoleID(ConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00060375, MMC
    // return struct
    EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    // manipulation variables
    EIEvidenceKey eiEvidenceKey;

    // BEGIN, CR00065999, JPG
    RelationshipByConcernRoleIDStatusKey relationshipByConcernRoleIDStatusKey = new RelationshipByConcernRoleIDStatusKey();
    curam.core.intf.ConcernRoleRelationship concernRoleRelationshipObj = curam.core.fact.ConcernRoleRelationshipFactory.newInstance();

    // populate the concernRoleRelationship key with passed in parameter
    relationshipByConcernRoleIDStatusKey.concernRoleID = key.concernRoleID;
    relationshipByConcernRoleIDStatusKey.statusCode = RECORDSTATUS.NORMAL;

    // read list of concernRoleRelationship records for concernRole
    curam.core.struct.ConcernRoleRelationshipDtlsList concernRoleRelationshipDtlsList = concernRoleRelationshipObj.searchByConcernRoleIDAndStatus(
      relationshipByConcernRoleIDStatusKey);

    // END, CR00065999

    // loop through returned list adding each returned ID to returned struct.
    for (int i = 0; i < concernRoleRelationshipDtlsList.dtls.size(); i++) {

      // Instantiate struct
      eiEvidenceKey = new EIEvidenceKey();

      // populate details
      eiEvidenceKey.evidenceID = concernRoleRelationshipDtlsList.dtls.item(i).concernRoleRelationshipID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLERELATIONSHIP;

      // add details to return struct
      eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
    }
    return eiEvidenceKeyList;
    // END, CR00060375, MMC

  }

  // END, CR00059697
  // END, CR00065902

  // BEGIN, CR00069014, JPG
  // ___________________________________________________________________________
  /**
   * Method to compare attributes on two records of the same entity type.
   * It then returns an ArrayList of strings with the names of each attribute that was
   * different between them.
   *
   * @param key - Contains an evidenceID / evidenceType pairing
   * @param dtls - a struct of the same type as the key containing the attributes
   * to be compared against
   *
   * @return A list of Strings. Each represents an attribute name that differed.
   */
  public ArrayList<String> getChangedAttributeList(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Declare the return list to hold the names of the attributes that changed
    ArrayList<String> attributesChanged = new ArrayList<String>();

    // Create ConcernRoleRelationship structs to allow a comparison of what is
    // in the database and what is in the struct dtls.
    ConcernRoleRelationshipDtls concernRoleRelationshipCompareDtls1 = new ConcernRoleRelationshipDtls();
    ConcernRoleRelationshipDtls concernRoleRelationshipCompareDtls2 = new ConcernRoleRelationshipDtls();

    try {

      curam.core.intf.ConcernRoleRelationship concernRoleRelationshipObj = curam.core.fact.ConcernRoleRelationshipFactory.newInstance();

      ConcernRoleRelationshipKey concernRoleRelationshipKey = new ConcernRoleRelationshipKey();

      concernRoleRelationshipKey.concernRoleRelationshipID = key.evidenceID;

      // read ConcernRoleRelationship details
      concernRoleRelationshipCompareDtls1 = concernRoleRelationshipObj.read(
        concernRoleRelationshipKey);

      // Populate the ConcernRoleRelationship struct that will be compared against
      concernRoleRelationshipCompareDtls2.assign(
        (ConcernRoleRelationshipDtls) dtls);

    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot ConcernRoleRelSnapshot entity
      curam.core.intf.ConcernRoleRelSnapshot concernRoleRelSnapshotObj = curam.core.fact.ConcernRoleRelSnapshotFactory.newInstance();

      ConcernRoleRelSnapshotKey concernRoleRelSnapshotKey = new ConcernRoleRelSnapshotKey();

      // populate the ConcernRoleRelSnapshot key with passed in parameter
      concernRoleRelSnapshotKey.concernRoleRelshipSnapshotID = key.evidenceID;

      // Read the ConcernRoleAlternateID snapshot details
      concernRoleRelationshipCompareDtls2.assign(
        concernRoleRelSnapshotObj.read(concernRoleRelSnapshotKey));

      // Populate the concernRoleRelSnapshot struct that will be compared against
      concernRoleRelationshipCompareDtls1.assign(
        (ConcernRoleRelationshipDtls) dtls);
    }

    if (concernRoleRelationshipCompareDtls1.concernRoleID
      != concernRoleRelationshipCompareDtls2.concernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEID);
    }
    if (concernRoleRelationshipCompareDtls1.relConcernRoleID
      != concernRoleRelationshipCompareDtls2.relConcernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.RELCONCERNROLEID);
    }
    if (!concernRoleRelationshipCompareDtls1.concernRoleType.equals(
      concernRoleRelationshipCompareDtls2.concernRoleType)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLETYPE);
    }
    if (!concernRoleRelationshipCompareDtls1.relConcernRoleType.equals(
      concernRoleRelationshipCompareDtls2.relConcernRoleType)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.RELCONCERNROLETYPE);
    }
    if (!concernRoleRelationshipCompareDtls1.startDate.equals(
      concernRoleRelationshipCompareDtls2.startDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STARTDATE);
    }
    if (!concernRoleRelationshipCompareDtls1.endDate.equals(
      concernRoleRelationshipCompareDtls2.endDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.ENDDATE);
    }
    if (!concernRoleRelationshipCompareDtls1.relationshipType.equals(
      concernRoleRelationshipCompareDtls2.relationshipType)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.RELATIONSHIPTYPE);
    }
    if (!concernRoleRelationshipCompareDtls1.relEndReasonCode.equals(
      concernRoleRelationshipCompareDtls2.relEndReasonCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.RELENDREASONCODE);
    }
    if (!concernRoleRelationshipCompareDtls1.statusCode.equals(
      concernRoleRelationshipCompareDtls2.statusCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STATUSCODE);
    }
    if (!concernRoleRelationshipCompareDtls1.comments.equals(
      concernRoleRelationshipCompareDtls2.comments)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COMMENTS);
    }
    if (concernRoleRelationshipCompareDtls1.concernRoleRelationshipID
      != concernRoleRelationshipCompareDtls2.concernRoleRelationshipID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLERELATIONSHIPID);
    }
    if (concernRoleRelationshipCompareDtls1.concernRoleRecipRelationID
      != concernRoleRelationshipCompareDtls2.concernRoleRecipRelationID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLERECIPRELATIONID);
    }

    return attributesChanged;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if the attributes that changed during a modify require
   * reassessment to be run when they are applied.
   *
   * @param attributesChanged - A list of Strings. Each represents the name of an
   * attribute that changed
   *
   * @return true if Reassessment required
   */
  public boolean checkForReassessment(ArrayList attributesChanged)
    throws AppException, InformationalException {

    return true;

    /*
     * Implement code here if you wish to only reassess modifications
     * to participant evidence when specified attributes are
     * changed during the modification. Currently this method
     * returns true so any modifications to participant evidence
     * will trigger reassessment.
     * To Implement set an indicator to false and check the attributesChanged
     * list for the attributes that require reassessment. If one is found
     * set the in indicator to true
     */
  }

  // END, CR00069014
  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    // BEGIN, CR00240667, CD
    return read(evKey).endDate;
    // END, CR00240667
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    // BEGIN, CR00240667, CD
    return read(evKey).startDate;
    // END, CR00240667
  }

  // END, CR002204022
  
  
  // BEGIN, CR00354902, ELG
  /**
   * When Participant Data Case is enabled an Application Exception will be thrown
   * when this method is called.  
   *
   * @param details Concern Role Relationship details to insert.
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_PARTICIPANT_INVOCATION_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   * @throws InformationalException
   */
  @Override
  protected void preinsert(final ConcernRoleRelationshipDtls details)
    throws AppException, InformationalException {
    
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey concernRoleKeyRelated = new ConcernRoleKey();
   
    concernRoleKey.concernRoleID = details.concernRoleID;
    concernRoleKeyRelated.concernRoleID = details.relConcernRoleID;
        
    if ((PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled)
      || (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKeyRelated).enabled)) {
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    }   
    
  }

  /**
   * When Participant Data Case is enabled an Application Exception will be thrown
   * when this method is called.  
   *
   * @param key Concern Role Relationship key to modify.
   * @param details Modified Concern Role Relationship details.
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_PARTICIPANT_INVOCATION_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   * @throws InformationalException
   */
  @Override
  protected void premodify(final ConcernRoleRelationshipKey key,
    final ConcernRoleRelationshipDtls details) throws AppException,
      InformationalException {
    
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey concernRoleKeyRelated = new ConcernRoleKey();
   
    concernRoleKey.concernRoleID = details.concernRoleID;
    concernRoleKeyRelated.concernRoleID = details.relConcernRoleID;
        
    if ((PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled)
      || (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKeyRelated).enabled)) {
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    }   
    
  }

  /**
   * When Participant Data Case is enabled an Application Exception will be thrown
   * when this method is called.
   *
   * @param key Concern Role Relationship key to remove.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_PARTICIPANT_INVOCATION_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   * @throws InformationalException
   */
  @Override
  protected void preremove(final ConcernRoleRelationshipKey key) throws AppException,
      InformationalException {
    
    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    final ConcernRoleKey concernRoleKeyRelated = new ConcernRoleKey();
    final ConcernRoleRelationshipDtls concernRoleRelationshipDtls = read(key);

    concernRoleKey.concernRoleID = concernRoleRelationshipDtls.concernRoleID;
    concernRoleKeyRelated.concernRoleID = concernRoleRelationshipDtls.relConcernRoleID;
        
    if ((PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled)
      || (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKeyRelated).enabled)) {
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    }   
    
  }

  // ___________________________________________________________________________
  /**
   * Raise a post Insert event. This method must be used only from PDCRelationships API.
   *
   * @param details for the concernRoleRelationship record.
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  protected void postpdcInsert(final ConcernRoleRelationshipDtls details)
    throws AppException, InformationalException {
    
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLERELATIONSHIP.INSERT_CONCERN_ROLE_RELATIONSHIP;
    // END, CR00047242

    event.primaryEventData = details.concernRoleRelationshipID;
    curam.util.events.impl.EventService.raiseEvent(event);
    
  }

  // ___________________________________________________________________________
  /**
   * Raise a post Modify event. This method must be used only from PDCRelationships API.
   *
   * @param key concernRoleRelationship key to modify
   * @param details details for the concernRoleRelationship record.
   * @throws InformationalException
   * @throws AppException
   */
  @Override
  protected void postpdcModify(final ConcernRoleRelationshipKey key,
    final ConcernRoleRelationshipDtls details) throws AppException,
      InformationalException {
    
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    // BEGIN, CR00047242, NG
    event.eventKey = CONCERNROLERELATIONSHIP.MODIFY_CONCERN_ROLE_RELATIONSHIP;
    // END, CR00047242

    event.primaryEventData = details.concernRoleRelationshipID;
    curam.util.events.impl.EventService.raiseEvent(event);
    
  }
  // END, CR00354902
  
}
