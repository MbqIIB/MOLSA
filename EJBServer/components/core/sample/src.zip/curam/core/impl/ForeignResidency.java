/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.ArrayList;
import java.util.HashMap;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.COUNTRY;
import curam.codetable.ENTITYATTRIBUTENAMES;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.ForeignResidencyFactory;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ForeignResidencyDtls;
import curam.core.struct.ForeignResidencyKey;
import curam.core.struct.ForeignResidencySnapshotDtls;
import curam.core.struct.ForeignResidencySnapshotKey;
import curam.message.SUMMARYDETAILS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;


/**
 * This entity will record ForeignResidency details for a person.
 *
 */
public abstract class ForeignResidency extends curam.core.base.ForeignResidency  implements ParticipantEvidenceInterface {

  protected class ForeignResidencyCache {
    public ForeignResidencyCache() {
      map = new HashMap<Long, ForeignResidencyDtls>();
      transactionID = 0;
    }
    HashMap<Long, ForeignResidencyDtls> map;
    int transactionID;
  }

  protected static ThreadLocal<ForeignResidencyCache> cachedReadDetailsTL = new ThreadLocal<ForeignResidencyCache>();
  // BEGIN, CR00065902, MMC

  // ___________________________________________________________________________
  /**
   * remove Entity
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @param  dtls of entity to remove
   */
  public void removeEvidence(EIEvidenceKey key, Object dtls) throws AppException, InformationalException {

    // BEGIN, CR00065924, AC
    // Entity Key
    ForeignResidencyKey foreignResidencyKey = new ForeignResidencyKey();

    // Set entity key for modify
    foreignResidencyKey.foreignResidencyID = key.evidenceID;

    // Modify details
    modify(foreignResidencyKey, (ForeignResidencyDtls) dtls);
    // END, CR00065924
  }

  // ___________________________________________________________________________
  /**
   * Inserts ForeignResidency evidence on modification
   *
   * @param dtls Object containing details of entity
   * @param origKey EIEvidenceKey for entity to insert
   * @param parentKey EIEvidenceKey for parent
   * @return the EIEvidenceKey to access the inserted evidence
   */
  public EIEvidenceKey insertEvidenceOnModify(Object dtls, EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException, InformationalException {
    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ForeignResidencyDtls) dtls);

    eiEvidenceKey.evidenceID = ((ForeignResidencyDtls) dtls).foreignResidencyID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.FOREIGNRESIDENCY;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * reads all ForeignResidency Entities by their Parent ID
   *
   * @param key EIEvidenceKey, the evidence key of the parent
   * @return the EIEvidenceKeyList of children
   */
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key) throws AppException, InformationalException {
    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * return list for validation
   *
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return the EIEvidenceKeyList for validation
   */
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey) throws AppException, InformationalException {
    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * run validations
   *
   * @param evKey EIEvidenceKey
   * @param evKeyList EIEvidenceKeyList
   * @param mode Validate Mode
   */
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList, ValidateMode mode) throws AppException, InformationalException {// This evidence interface method is currently not implemented for
    // participant evidence.
  }

  // ___________________________________________________________________________
  /**
   * Clear cached data in cachedReadDetailsTL
   */
  protected void clearCaches() {
    ForeignResidencyCache cache = cachedReadDetailsTL.get();

    if (cache != null) {
      cache.map.clear();
    } else {
      cache = new ForeignResidencyCache();
      cachedReadDetailsTL.set(cache);
    }
    cache.transactionID = TransactionInfo.getIdentifierForThisThread();

  }

  // ___________________________________________________________________________
  /**
   * calcAttributionDatesForCase
   * Calculates the AttributionDates For entity,
   * specifically for its use as a ParticpantEvidence.
   *
   * @param caseKey
   * @param evKey Evidence key containing the evidenceID and evidenceType
   * @return AttributedDateDetails
   */
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey, EIEvidenceKey evKey) throws AppException, InformationalException {
    
    AttributedDateDetails retAttributedDateDetails =
      new AttributedDateDetails();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    ForeignResidencyDtls foreignResidencyDtls = read(evKey);
    // END, CR00240667  

    retAttributedDateDetails.fromDate = foreignResidencyDtls.startDate;
    retAttributedDateDetails.toDate = foreignResidencyDtls.endDate;
    return retAttributedDateDetails;
  }

  /**
   * Reads the entity details given the evidence record identifier.
   * 
   * @param key The evidence record identifier.
   * 
   * @return The entity details.
   * 
   * @throws AppException
   * @throws InformationalException
   */
  protected ForeignResidencyDtls read(EIEvidenceKey key) throws AppException,
      InformationalException {
    // ForeignResidency object
    curam.core.intf.ForeignResidency foreignResidencyObj =
      ForeignResidencyFactory.newInstance();
    ForeignResidencyKey foreignResidencyKey = new ForeignResidencyKey();

    foreignResidencyKey.foreignResidencyID = key.evidenceID;
    ForeignResidencyDtls foreignResidencyDtls = new ForeignResidencyDtls();

    // BEGIN, CR00067890, POH
    // read person details
    try {
      foreignResidencyDtls = foreignResidencyObj.read(foreignResidencyKey);
    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot foreignResidency entity
      ForeignResidencySnapshotKey foreignResidencySnapshotKey =
        new ForeignResidencySnapshotKey();

      curam.core.intf.ForeignResidencySnapshot foreignResidencySnapshotObj =
        curam.core.fact.ForeignResidencySnapshotFactory.newInstance();

      // BEGIN, CR00068202, PON
      // populate foreignResidency snapshot key with passed in parameter
      foreignResidencySnapshotKey.foreignResSnapshotID = key.evidenceID;
      // END, CR00068202

      // read foreignResidency snapshot details
      ForeignResidencySnapshotDtls foreignResidencySnapshotDtls =
        foreignResidencySnapshotObj.read(foreignResidencySnapshotKey);

      foreignResidencySnapshotDtls.assign(foreignResidencySnapshotDtls);
    }
    // END, CR00067890
    return foreignResidencyDtls;
  }

  // ___________________________________________________________________________
  /**
   * Get evidence details for the list display
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @return Evidence details to be displayed on the list page
   */
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key) throws AppException, InformationalException {
    // Return object
    EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls =
      new EIFieldsForListDisplayDtls();

    // BEGIN, CR00060473, MMC
    // manipulation variables
    try {

      // ForeignResidency entity key
      ForeignResidencyKey foreignResidencyKey = new ForeignResidencyKey();

      // Read the ForeignResidency entity to get display details
      foreignResidencyKey.foreignResidencyID = key.evidenceID;

      curam.core.intf.ForeignResidency foreignResidencyObj =
        curam.core.fact.ForeignResidencyFactory.newInstance();
      ForeignResidencyDtls foreignResidencyDtls =
        foreignResidencyObj.read(foreignResidencyKey);

      // Set the start / end dates
      eiFieldsForListDisplayDtls.startDate = foreignResidencyDtls.startDate;
      eiFieldsForListDisplayDtls.endDate = foreignResidencyDtls.endDate;

      // Set the summary details.
      // BEGIN, CR00241068, CD
      LocalisableString message = new LocalisableString(SUMMARYDETAILS.FOREIGN_RESIDENCY);
      message.arg(CodeTable.getOneItem(COUNTRY.TABLENAME,
        foreignResidencyDtls.countryCode)); 
      eiFieldsForListDisplayDtls.summary = 
        message.getMessage(ProgramLocale.getDefaultServerLocale());
      // END, CR00241068
      
    } // If the ForeignResidency record is not found, then the ID passed in must
    // belong to an ForeignResidencySnapshot record
    catch (RecordNotFoundException rnfe) {

      // Read the ForeignResidencySnapshot details
      curam.core.struct.ForeignResidencySnapshotKey foreignResidencySnapshotKey =
        new curam.core.struct.ForeignResidencySnapshotKey();

      // BEGIN, CR00068202, POH
      foreignResidencySnapshotKey.foreignResSnapshotID = key.evidenceID;
      // END, CR00068202
      curam.core.struct.ForeignResidencySnapshotDtls foreignResidencySnapshotDtls =
        curam.core.fact.ForeignResidencySnapshotFactory.newInstance().read(
          foreignResidencySnapshotKey);

      // Set the start / end dates
      eiFieldsForListDisplayDtls.startDate =
        foreignResidencySnapshotDtls.startDate;
      eiFieldsForListDisplayDtls.endDate = foreignResidencySnapshotDtls.endDate;

      // Set the summary details.
      // BEGIN, CR00241068, CD
      LocalisableString message = new LocalisableString(SUMMARYDETAILS.FOREIGN_RESIDENCY);
      message.arg(CodeTable.getOneItem(COUNTRY.TABLENAME,
        foreignResidencySnapshotDtls.countryCode)); 
      eiFieldsForListDisplayDtls.summary = 
        message.getMessage(ProgramLocale.getDefaultServerLocale());
      // END, CR00241068
    }

    // END, CR00060473

    return eiFieldsForListDisplayDtls;
  }

  // ___________________________________________________________________________
  /**
   * Inserts evidence details - overrides Participant Evidence inherited abstract method
   *
   * @param dtls Object containing details of entity
   * @param parentKey Key for parent
   *
   * @return eiEvidenceKey - key for inserted evidence
   */
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey) throws AppException, InformationalException {
    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ForeignResidencyDtls) dtls);

    eiEvidenceKey.evidenceID = ((ForeignResidencyDtls) dtls).foreignResidencyID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.FOREIGNRESIDENCY;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modifies evidence details - overrides Participant Evidence inherited abstract method
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @param dtls Object containing details of entity
   */
  public void modifyEvidence(EIEvidenceKey key, Object dtls) throws AppException, InformationalException {
    // ForeignResidency entity key
    ForeignResidencyKey foreignResidencyKey = new ForeignResidencyKey();

    // Set entity key for modify
    foreignResidencyKey.foreignResidencyID = key.evidenceID;

    // Modify details
    modify(foreignResidencyKey, (ForeignResidencyDtls) dtls);
  }

  // ___________________________________________________________________________
  /**
   * Read evidence details - overrides Participant Evidence inherited abstract method
   *
   * @param key Evidence key containing the evidenceID and evidenceType
   * @return the Object with the readEvidence details
   */
  public Object readEvidence(EIEvidenceKey key) throws AppException, InformationalException {
    // ForeignResidency object
    curam.core.intf.ForeignResidencySnapshot foreignResidencySnapshotObj =
      curam.core.fact.ForeignResidencySnapshotFactory.newInstance();

    curam.core.intf.ForeignResidency foreignResidencyObj =
      curam.core.fact.ForeignResidencyFactory.newInstance();
    ForeignResidencyDtls foreignResidencyDtls = new ForeignResidencyDtls();

    // BEGIN, CR00060473, MMC
    // Attempt to read the record using the evidenceID passed in, if a record
    // is found return the details as an object.
    // If no record is found attempt to read the snapshot record using the passed
    // in evidenceID. If a record is found return the details as an object.
    try {
      ForeignResidencyKey foreignResidencyKey = new ForeignResidencyKey();

      foreignResidencyKey.foreignResidencyID = key.evidenceID;
      foreignResidencyDtls = foreignResidencyObj.read(foreignResidencyKey);
      return foreignResidencyDtls;

    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot ForeignResidency entity
      curam.core.struct.ForeignResidencySnapshotKey foreignResidencySnapshotKey =
        new curam.core.struct.ForeignResidencySnapshotKey();

      // BEGIN, CR00068202, POH
      foreignResidencySnapshotKey.foreignResSnapshotID = key.evidenceID;
      // END, CR00068202

      curam.core.struct.ForeignResidencySnapshotDtls foreignResidencySnapshotDtls =
        foreignResidencySnapshotObj.read(foreignResidencySnapshotKey);

      foreignResidencyDtls.assign(foreignResidencySnapshotDtls);

      return foreignResidencyDtls;
    }
    // END, CR00060473
  }

  // ___________________________________________________________________________
  /**
   * To create a new snapshot record of the ForeignResidency entity,
   * specifically for its use as a ParticpantEvidence.
   *
   * @param key the key to access the entity for which to create a snapshot
   * @return the key to access the snapshot
   */
  public EIEvidenceKey createSnapshot(EIEvidenceKey key) throws AppException, InformationalException {
    EIEvidenceKey retEIEvidenceKey = new EIEvidenceKey();
    curam.core.intf.ForeignResidencySnapshot foreignResidencySnapshotObj =
      curam.core.fact.ForeignResidencySnapshotFactory.newInstance();

    // Entity and Entity-snapshot objects
    curam.core.intf.ForeignResidency foreignResidencyObj =
      curam.core.fact.ForeignResidencyFactory.newInstance();

    ForeignResidencyKey foreignResidencyKey = new ForeignResidencyKey();

    foreignResidencyKey.foreignResidencyID = key.evidenceID;

    ForeignResidencyDtls foreignResidencyDtls =
      foreignResidencyObj.read(foreignResidencyKey);

    ForeignResidencySnapshotDtls foreignResidencySnapshotDtls =
      new ForeignResidencySnapshotDtls();

    // Populate snapshot
    foreignResidencySnapshotDtls.assign(foreignResidencyDtls);

    foreignResidencySnapshotDtls.creationDateTime =
      DateTime.getCurrentDateTime();
    foreignResidencySnapshotObj.insert(foreignResidencySnapshotDtls);

    // BEGIN, CR00068202, POH
    retEIEvidenceKey.evidenceID =
      foreignResidencySnapshotDtls.foreignResSnapshotID;
    // END, CR00068202
    retEIEvidenceKey.evidenceType = CASEEVIDENCE.FOREIGNRESIDENCY;

    return retEIEvidenceKey;
  }

  // __________________________________________________________________________
  /**
   * Inserts details into database. The cache is cleared first.
   *
   * @param details  Contains entity details
   */
  public void insert(ForeignResidencyDtls details) throws AppException, InformationalException {
    this.clearCaches();
    super.insert(details);
  }

  // __________________________________________________________________________
  /**
   * Modifies details in the database Entity. The cache is cleared first.
   *
   * @param key  Contains key to access entity details
   * @param details  Contains details to modify
   */
  public void modify(ForeignResidencyKey key, ForeignResidencyDtls details) throws AppException, InformationalException {
    // We want to clear the cache in case for some reason the database
    // evidence is required e.g. if the evidence was updated by another user.
    // So to ensure we have the correct evidence, clear the cache and force a
    // read from the database
    this.clearCaches();

    super.modify(key, details);

    // The reason why we have to clear the cache here is a result of how the
    // evidence controller performs the modifying of evidence. PreModifying the
    // record it reads the details (first time it reads the details so will be
    // read from database and cached). The record is modified and post
    // modifying, the evidence controller calls performValidation
    // (validates the record) which requires a read of the evidence. The cached
    // evidence has stored the evidence PRIOR to the modification of the record.
    // Therefore we want to go to the database to read the modified evidence and
    // as a result clear the cache post modification.
    this.clearCaches();
  }

  // BEGIN, CR00059697, SSK
  // ___________________________________________________________________________
  /**
   * Method to search for records on a participant entity by concernRoleID.
   *
   * @param key - The unique concernRoleID of the participant.
   *
   * @return A list of EIEvidenceKey objects each containing a evidenceID/evidenceType pair.
   */
  public EIEvidenceKeyList readAllByConcernRoleID(ConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00060375, MMC
    // return struct
    EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();

    // manipulation variables
    EIEvidenceKey eiEvidenceKey;

    // BEGIN, CR00065999, JPG
    ConcernRoleIDStatusCodeKey concernRoleIDStatusCodeKey =
      new ConcernRoleIDStatusCodeKey();

    curam.core.intf.ForeignResidency foreignResidencyObj =
      curam.core.fact.ForeignResidencyFactory.newInstance();

    // populate the ForeignResidency key with passed in parameter
    concernRoleIDStatusCodeKey.concernRoleID = key.concernRoleID;
    concernRoleIDStatusCodeKey.statusCode = RECORDSTATUS.NORMAL;

    // read list of ForeignResidency records for concernRole
    curam.core.struct.ForeignResidencyReadMultiDtlsList foreignResidencyReadMultiDtlsList =
      foreignResidencyObj.searchByConcernRoleIDAndStatus(
        concernRoleIDStatusCodeKey);

    // END, CR00065999

    // loop through returned list adding each returned ID to returned struct.
    for (int i = 0; i < foreignResidencyReadMultiDtlsList.dtls.size(); i++) {

      // Instantiate struct
      eiEvidenceKey = new EIEvidenceKey();

      // populate details
      eiEvidenceKey.evidenceID =
        foreignResidencyReadMultiDtlsList.dtls.item(i).foreignResidencyID;
      eiEvidenceKey.evidenceType = CASEEVIDENCE.FOREIGNRESIDENCY;

      // add details to return struct
      eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);
    }
    return eiEvidenceKeyList;
    // END, CR00060375, MMC

  }

  // END, CR00059697

  // BEGIN, CR00060407, SSK
  protected void dummy() throws AppException, InformationalException {// Dummy method to force factory class to extend the impl class instead of the base class.
  }

  // END, CR00060407

  // BEGIN, CR00069014, JPG
  // ___________________________________________________________________________
  /**
   * Method to compare attributes on two records of the same entity type.
   * It then returns an ArrayList of strings with the names of each attribute that was
   * different between them.
   *
   * @param key - Contains an evidenceID / evidenceType pairing
   * @param dtls - a struct of the same type as the key containing the attributes
   * to be compared against
   *
   * @return A list of Strings. Each represents an attribute name that differed.
   */
  public ArrayList<String> getChangedAttributeList(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Declare the return list to hold the names of the attributes that changed
    ArrayList<String> attributesChanged = new ArrayList<String>();

    // Create ForeignResidencyDtls structs to allow a comparison of what is
    // in the database and what is in the struct dtls.
    ForeignResidencyDtls foreignResidencyCompareDtls1 =
      new ForeignResidencyDtls();
    ForeignResidencyDtls foreignResidencyCompareDtls2 =
      new ForeignResidencyDtls();

    try {

      curam.core.intf.ForeignResidency foreignResidencyObj =
        curam.core.fact.ForeignResidencyFactory.newInstance();

      ForeignResidencyKey foreignResidencyKey = new ForeignResidencyKey();

      foreignResidencyKey.foreignResidencyID = key.evidenceID;

      // read ForeignResidency details
      foreignResidencyCompareDtls1 =
        foreignResidencyObj.read(foreignResidencyKey);

      // Populate the ForeignResidency struct that will be compared against
      foreignResidencyCompareDtls2.assign((ForeignResidencyDtls) dtls);

    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot ForeignResidency entity
      curam.core.intf.ForeignResidencySnapshot foreignResidencySnapshotObj =
        curam.core.fact.ForeignResidencySnapshotFactory.newInstance();

      ForeignResidencySnapshotKey foreignResidencySnapshotKey =
        new ForeignResidencySnapshotKey();

      // populate the ForeignResidency snapshot key with passed in parameter
      foreignResidencySnapshotKey.foreignResSnapshotID = key.evidenceID;

      // Read the ForeignResidency snapshot details
      foreignResidencyCompareDtls2.assign(
        foreignResidencySnapshotObj.read(foreignResidencySnapshotKey));

      // Populate the ForeignResidency struct that will be compared against
      foreignResidencyCompareDtls1.assign((ForeignResidencyDtls) dtls);
    }

    if (foreignResidencyCompareDtls1.foreignResidencyID
      != foreignResidencyCompareDtls2.foreignResidencyID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.FOREIGNRESIDENCYID);
    }
    if (foreignResidencyCompareDtls1.concernRoleID
      != foreignResidencyCompareDtls2.concernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEID);
    }
    if (!foreignResidencyCompareDtls1.startDate.equals(
      foreignResidencyCompareDtls2.startDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STARTDATE);
    }
    if (!foreignResidencyCompareDtls1.endDate.equals(
      foreignResidencyCompareDtls2.endDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.ENDDATE);
    }
    if (!foreignResidencyCompareDtls1.reasonCode.equals(
      foreignResidencyCompareDtls2.reasonCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.REASONCODE);
    }
    if (!foreignResidencyCompareDtls1.countryCode.equals(
      foreignResidencyCompareDtls2.countryCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COUNTRYCODE);
    }
    if (!foreignResidencyCompareDtls1.statusCode.equals(
      foreignResidencyCompareDtls2.statusCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STATUSCODE);
    }
    if (!foreignResidencyCompareDtls1.comments.equals(
      foreignResidencyCompareDtls2.comments)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COMMENTS);
    }

    return attributesChanged;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if the attributes that changed during a modify require
   * reassessment to be run when they are applied.
   *
   * @param attributesChanged - A list of Strings. Each represents the name of an
   * attribute that changed
   *
   * @return true if Reassessment required
   */
  public boolean checkForReassessment(ArrayList attributesChanged)
    throws AppException, InformationalException {

    return true;

    /* Implement code here if you wish to only reassess modifications
     * to participant evidence when specified attributes are
     * changed during the modification. Currently this method
     * returns true so any modifications to participant evidence
     * will trigger reassessment.
     * To Implement set an indicator to false and check the attributesChanged
     * list for the attributes that require reassessment. If one is found
     * set the in indicator to true
     */
  }

  // END, CR00069014
  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   * 
   * @param evKey The evidence key.
   * 
   */
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    // BEGIN, CR00240667, CD
    return read(evKey).endDate;
    // END, CR00240667
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   * 
   * @param evKey The evidence key.
   * 
   */
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    // BEGIN, CR00240667, CD
    return read(evKey).startDate;
    // END, CR00240667
  }
  // END, CR002204022
}
