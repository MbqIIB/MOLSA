/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.struct.FinInstructionID;
import curam.core.struct.PaymentInstructionDtls;
import curam.core.struct.PaymentInstructionKey;
import curam.core.struct.PmtInstrAmount;
import curam.core.struct.PmtInstrumentIDversNo;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Raise an events for lucene index search as a result of entity updates
 * 
 */
public abstract class IndexPaymentInstructionSynchronization extends curam.core.base.IndexPaymentInstructionSynchronization {

  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment instruction entity insert operation
   * 
   * @param dtls The payment instruction details
   *
   */
  public void insert(final PaymentInstructionDtls dtls) throws AppException, InformationalException {// This will post the event indicating that the specific payment instruction has been updated
  }
  
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment instruction entity modify amount operation
   * 
   * @param paymentInstructionKey The payment instruction identifier
   * @param pmtInstrAmount Payment amount
   * 
   */
  public void modifyAmount(final PaymentInstructionKey paymentInstructionKey, final PmtInstrAmount pmtInstrAmount)
    throws AppException, InformationalException {// This will post the event indicating that the specific payment instruction has been updated
  }
  
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the payment instruction entity modify payment instrument operation
   * 
   * @param paymentInstructionKey The payment instruction identifier
   * @param pmtInstrumentIDversNo The payment instruction version number
   *
   */
  public void modifyPmtInstrumentID(final PaymentInstructionKey paymentInstructionKey, final PmtInstrumentIDversNo pmtInstrumentIDversNo) 
    throws AppException, InformationalException {// This will post the event indicating that the specific payment instruction has been updated
  }
  
  // ___________________________________________________________________________
  /**
   * Raise an events as a result of the address entity modify payment instrument operation
   * 
   * @param finInstructionID The financial instruction identifier
   * @param pmtInstrumentIDversNo The payment instruction version number
   *
   */
  public void modifyPmtInstrumentIDByFinInstructionID(final FinInstructionID finInstructionID, final PmtInstrumentIDversNo pmtInstrumentIDversNo) 
    throws AppException, InformationalException {// This will post the event indicating that the specific payment instruction has been updated
  }

}
