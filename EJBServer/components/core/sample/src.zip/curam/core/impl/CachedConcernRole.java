/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2008, 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import curam.core.sl.infrastructure.impl.ExtensionConst;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameAndAlternateID;
import curam.core.struct.ConcernRoleNameDetails;
import curam.core.struct.ParticipantRoleAddressDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.resources.Trace;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * @see curam.core.intf.CachedConcernRole 
 */
public abstract class CachedConcernRole extends curam.core.base.CachedConcernRole {

  protected static ThreadLocal<ConcernRoleCache> cachedConcerRole = new ThreadLocal<ConcernRoleCache>();

  protected static ThreadLocal<ParticipantRoleAddressCached> cachedParticipantRoleAddress = new ThreadLocal<ParticipantRoleAddressCached>();

  // Logger for the caching output
  // BEGIN, CR00053248, GM
  public static final String kBatchCachingCategory = Trace.kDefaultTraceCategory
    + ExtensionConst.kBatchCachingCategory;
  // END, CR00053248
  public static final Logger kBatchLauncherCacheLogger = Logger.getLogger(
    kBatchCachingCategory);

  public static final boolean logging;

  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;

  // static to indicate if online caching is enabled
  public static final boolean onlineCachingEnabled;

  // static to hold the logging_enabled environmental Variable
  static {

    cachingEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);

    onlineCachingEnabled = Configuration.getBooleanProperty(
      EnvVars.ENV_ONLINE_CACHING_ENABLED);

    String logging_enabled = Configuration.getProperty(
      EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED);

    if (logging_enabled == null) {
      logging_enabled = EnvVars.ENV_BATCH_PROCESS_LOGGING_ENABLED_DEFAULT;
    }

    if (logging_enabled.equalsIgnoreCase(EnvVars.ENV_VALUE_YES)) {
      logging = true;
    } else {
      logging = false;
    }
  }

  // ___________________________________________________________________________
  /**
   * Class to hold the cached concern roles
   */
  protected class ConcernRoleCache {

    public Map<Long, ConcernRoleDtls> concernRoleMap = new HashMap<Long, ConcernRoleDtls>(); // the key is the concern role ID
    public int transactionID = 0;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ConcernRoleDtls read(ConcernRoleKey key)
    throws AppException, InformationalException {
    
    final ConcernRoleDtls result = new ConcernRoleDtls();

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    // if caching is enabled, check the cache for the concern role
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {

      ConcernRoleCache concernRoleCache = cachedConcerRole.get();

      if ((concernRoleCache != null)
        && (TransactionInfo.getIdentifierForThisThread()
          == concernRoleCache.transactionID)) {

        Long concernRoleIDL = new Long(key.concernRoleID);

        ConcernRoleDtls concernRoleDtls = concernRoleCache.concernRoleMap.get(
          concernRoleIDL);

        if (concernRoleDtls == null) {
          return result.assign(loadDtlsCache(key)); // cache miss
        } else {
          return result.assign(concernRoleDtls);
        }

      } else { // cache is not initialized or different transaction
        clearCache();
      }
    }

    return result.assign(loadDtlsCache(key));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ConcernRoleNameDetails readConcernRoleName(ConcernRoleKey key)
    throws AppException, InformationalException {

    ConcernRoleNameDetails concernRoleNameDetails = new ConcernRoleNameDetails();

    concernRoleNameDetails.concernRoleName = read(key).concernRoleName;

    return concernRoleNameDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to load a concern role into the cache.
   *
   * @param key Concern Role entity key
   * @return Concern Role entity details
   */
  protected ConcernRoleDtls loadDtlsCache(ConcernRoleKey key)
    throws AppException, InformationalException {

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    // ConcernRole manipulation variables
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    ConcernRoleCache concernRoleCache = new ConcernRoleCache();

    // read the concern role
    ConcernRoleDtls concernRoleDtls = concernRoleObj.read(key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {

      // BEGIN, CR00091590, VM
      // Add the concern role to the cache
      Long concernRoleIDL = new Long(key.concernRoleID);

      concernRoleCache.concernRoleMap.put(concernRoleIDL, concernRoleDtls);
      concernRoleCache.transactionID = TransactionInfo.getIdentifierForThisThread();
      cachedConcerRole.set(concernRoleCache);
      // END, CR00091590
    }

    return concernRoleDtls;
  }

  // ___________________________________________________________________________
  /**
   * Clears the cache.
   */
  protected void clearCache() throws AppException, InformationalException {

    ConcernRoleCache concernRoleCache = new ConcernRoleCache();

    concernRoleCache.transactionID = TransactionInfo.getIdentifierForThisThread();

    cachedConcerRole.set(concernRoleCache);

    cachedParticipantRoleAddress.set(null);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ConcernRoleNameAndAlternateID readConcernRoleNameAndAlternateID(ConcernRoleKey key)
    throws AppException, InformationalException {

    ConcernRoleNameAndAlternateID concernRoleNameAndAlternateID = new ConcernRoleNameAndAlternateID();

    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();

    boolean reloadCache = true;

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    // if caching is enabled, check the cache for the concern role
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {

      // try to find the data in the cache
      ConcernRoleCache concernRoleCache = cachedConcerRole.get();

      if (concernRoleCache != null) {
        Long concernRoleIDL = new Long(key.concernRoleID);

        concernRoleDtls = concernRoleCache.concernRoleMap.get(concernRoleIDL);

        if (concernRoleDtls != null) {
          concernRoleNameAndAlternateID.concernRoleName = concernRoleDtls.concernRoleName;
          concernRoleNameAndAlternateID.primaryAlternateID = concernRoleDtls.primaryAlternateID;

          reloadCache = false;

          // if this is a deferred transaction, we must also check
          // that the transaction numbers match
          if (!reloadCache
            && (transactionType.equals(TransactionType.kDeferred)
              || transactionType.equals(TransactionType.kOnline))
              && TransactionInfo.getIdentifierForThisThread()
                != concernRoleCache.transactionID) {
            reloadCache = true;
          }
        }
      }
    }

    // Otherwise we need to read the Person data
    if (reloadCache) {
      concernRoleDtls = loadDtlsCache(key);
      concernRoleNameAndAlternateID.concernRoleName = concernRoleDtls.concernRoleName;
      concernRoleNameAndAlternateID.primaryAlternateID = concernRoleDtls.primaryAlternateID;
    }

    return concernRoleNameAndAlternateID;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ParticipantRoleAddressDetails readParticipantRoleAddress(ConcernRoleKey key)
    throws AppException, InformationalException {

    ParticipantRoleAddressDetails participantRoleAddressDetails = new ParticipantRoleAddressDetails();

    boolean reloadCache = true;

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    // if caching is enabled, check the cache for the concern role
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {

      // try to find the data in the cache
      ParticipantRoleAddressCached participantRoleAddressCached = cachedParticipantRoleAddress.get();

      if (participantRoleAddressCached != null) {

        participantRoleAddressDetails.assign(
          participantRoleAddressCached.participantRoleAddressDetails);
        reloadCache = false;

        // if this is a deferred transaction, we must also check
        // that the transaction numbers match
        if (!reloadCache
          && (transactionType.equals(TransactionType.kDeferred)
            || transactionType.equals(TransactionType.kOnline))
            && TransactionInfo.getIdentifierForThisThread()
              != participantRoleAddressCached.transactionID) {

          reloadCache = true;
        }
      }
    }

    // Otherwise we need to read the Person data
    if (reloadCache) {
      participantRoleAddressDetails = loadParticipantRoleAddressDtlsCache(key);
    }

    return participantRoleAddressDetails;
  }

  // ___________________________________________________________________________
  /**
   * class used to cache the Employment details
   *
   */
  class ConcernRoleCached {

    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();
    int transactionID = 0;
  }


  // ___________________________________________________________________________
  /**
   * class used to cache the ParticipantRoleAddress details
   *
   */
  class ParticipantRoleAddressCached {

    ParticipantRoleAddressDetails participantRoleAddressDetails = new ParticipantRoleAddressDetails();
    int transactionID = 0;
  }

  // ___________________________________________________________________________
  /**
   * This method is used to load a concern role into the cache.
   *
   * @param key Concern Role entity key
   * @return ParticipantRole Address details
   */
  protected ParticipantRoleAddressDetails loadParticipantRoleAddressDtlsCache
    (ConcernRoleKey key)throws AppException, InformationalException {

    // variable to hold transaction type
    TransactionType transactionType = TransactionInfo.getTransactionType();

    // ConcernRole manipulation variables
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ParticipantRoleAddressCached participantRoleAddressCached = new ParticipantRoleAddressCached();

    // read the concern role
    ParticipantRoleAddressDetails participantRoleAddressDetails = concernRoleObj.readParticipantRoleAddress(
      key);

    // If this was a cache miss (and caching is enabled), refresh the cache
    if ((transactionType.equals(TransactionType.kBatch) && cachingEnabled)
      || (transactionType.equals(TransactionType.kDeferred) && cachingEnabled)
      || (transactionType.equals(TransactionType.kOnline)
        && onlineCachingEnabled)) {

      // BEGIN, CR00091590, VM
      participantRoleAddressCached.participantRoleAddressDetails.assign(
        participantRoleAddressDetails);
      participantRoleAddressCached.transactionID = TransactionInfo.getIdentifierForThisThread();
      cachedParticipantRoleAddress.set(participantRoleAddressCached);
      // END, CR00091590
    }

    return participantRoleAddressDetails;
  }

}
