/*
 * IBM Confidential 
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2014.
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office.
 */

package curam.core.impl;


import curam.approvalrequest.impl.ApprovalRequest;
import curam.util.type.FrequencyPattern;
import curam.util.type.Money;


/**
 * This class assigns values to the Curam constants.
 *
 * Please be careful when adding new constants to this file that it both: *
 * provides a level of abstraction from the value it represents * has a
 * meaningful name, but not a repetition of the literal value of the constant
 */
public abstract class CuramConst {

  // BEGIN, CR00228866, DJ
  // BEGIN, CR00238338, PF
  /**
   * @deprecated Since 6.0, There is no direct replacement for this constant
   * because it's use is questionable. Instead the validations
   * which relied on it have been rewritten to be more
   * customizable.
   */
  @Deprecated
  public static final int gkMinimumPhoneNumberLength = 3;
  // END, CR00228866
  // END, CR00238338

  public static final String gkUnderscore = "_";
  // BEGIN, CR00368946, GA
  public static final String gkPipeComma = "|,";
  // END, CR00368946

  public static final char gkUnderscoreChar = '_';

  public static final String gkSqlWildcard = "%";

  // BEGIN, CR00298781, ZV
  public static final String gkSqlSingleWildcard = "_";
  // END, CR00298781

  public static final char gkSqlWildcardChar = '%';

  // BEGIN, CR00100777 ,BD
  public static final String gkRegexWildcardChar = ".*";

  // END, CR00100777
  public static final char gkDotChar = '.';

  // Report outlay constants
  public static final String gkPipeDelimiter = "|";

  // BEGIN, CR00187787, MR
  /**
   * Constant for pipe string - "\\|".
   */
  public static final String gkPipe = "\\|";

  // END, CR00187787

  // BEGIN, CR00229467, KH
  /**
   * Constant for dot delimiter string - "\\."
   */
  public static final String gkDotDelimiter = "\\.";

  // END, CR00229467

  public static final char gkPipeDelimiterChar = '|';

  public static final String gkColonSpace = ": ";

  public static final String gkComma = ",";

  public static final String gkNewLine = "\n";

  public static final char gkNewLineChar = '\n';

  public static final String gkTabDelimiter = "\t";

  public static final char gkTabDelimiterChar = '\t';

  public static final String gkDollar = "$";

  public static final String gkLineSeparator = "_______________________________________________________________________________\n";

  public static final String gkStatementSeparator = "__________________________________________________________________________________\n";

  public static final String gkTaskSeparator = "...............................................................................\n";

  public static final String gkStringZero = "0";

  public static final String gkDecimalDoubleZero = "0.00";

  public static final double gkDoubleZero = 0.0;

  public static final String gkDataFileExt = ".dat";

  public static final String gkLogFileExt = ".log";

  public static final String gkCertificationFrequency = "000000000";

  public static final String gkFrom = "from: ";

  public static final String gkTo = " to: ";

  public static final String gkStringTo = " to ";

  public static final String gkSpace = " ";

  public static final char gkSpaceChar = ' ';

  public static final String gkEquals = " = ";

  public static final char gkEqualsNoSpaces = '=';

  public static final String gkDoubleSpace = "  ";

  public static final String gkDash = "-";

  public static final char gkDashChar = '-';

  public static final String gkRoundOpeningBracket = "(";

  public static final char gkRoundOpeningBracketChar = '(';

  public static final String gkRoundClosingBracket = ")";

  public static final char gkRoundClosingBracketChar = ')';

  public static final String gkDefaultFrequencyPattern = new FrequencyPattern().toString();

  public static final String gkSlash = " / ";

  // BEGIN, CR00274950, CW
  public static final String gkWhiteSpace = "\\W";
  // END, CR00274950

  // BEGIN, CR00204851, ELG
  public static final char gkSlashChar = '/';

  // END, CR00204851

  // BEGIN, CR00119215, CW
  public static final String kLessThan = "<";

  public static final String kGreaterThan = ">";

  // BEGIN, CR00220313, ELG
  public static final char kGreaterThanChar = '>';

  // END, CR00220313

  public static final char kQuoteChar = '"';

  // END, CR00119215

  public static final long gkNumberOfSecondsInMinute = 60;

  public static final long gkNumberOfSecondsInDay = 86400;

  public static final long gkNumberOfSecondsInHour = 3600;

  // BEGIN, CR00238338, PF
  public static final int gkNumberOfDaysInAWeek = 7;

  public static final int gkNumberOfDaysInTwoWeeks = 14;

  public static final int gkOneHundredPercent = 100;

  public static final int gkNumberOfMonthsInAYear = 12;

  public static final int gkNumberOfHoursInADay = 24;
  // END, CR00238338

  public static final short gkWorkingPatternPeriod = 14;

  // Length of gkTabDelimiter
  public static final short gkTabDelimiterLength = 1;

  // ///////////////////////////////////////////////////////////////////////////

  // BEGIN, CR00238338, PF
  /**
   * @deprecated Since 6.0, There is no direct replacement for this constant
   * because it's use is questionable. Instead the code which
   * relied on it has been rewritten to be more customizable.
   */
  @Deprecated
  public static final String gkThirty = "30";

  /**
   * @deprecated Since 6.0, There is no direct replacement for this constant
   * because it's use is questionable. Instead the code which
   * relied on it has been rewritten to be more customizable.
   */
  @Deprecated
  public static final String gkOneEighty = "180";

  /**
   * @deprecated Since 6.0, There is no direct replacement for this constant
   * because it's use is questionable. Instead the code which
   * relied on it has been rewritten to be more customizable.
   */
  @Deprecated
  public static final String gkThreeSixtyFive = "365";

  /**
   * @deprecated Since 6.0, replaced by @see gkOneHundredPercent
   */
  @Deprecated
  public static final int gkOneHundred = 100;

  /**
   * @deprecated Since 6.0, There is no direct replacement for this constant
   * because it's use is questionable. Instead the code which
   * relied on it has been rewritten to be more customizable.
   */
  @Deprecated
  public static final int gkSeven = 7;

  // BEGIN, CR00107061 MR
  /**
   * Global constant for zero - this (and gkOne) are special case values,
   * further numeric constants named after their value should not be added.
   */
  public static final int gkZero = 0;

  // BEGIN, CR00150923, ZV
  /**
   * Global constant for one - this (and gkZero) are special case values,
   * further numeric constants named after their value should not be added.
   */
  public static final int gkOne = 1;

  // END CR00150923
  // BEGIN, CR00190352, JMA
  /**
   * @deprecated Since 6.0, replaced by @see gkNumberOfMonthsInAYear
   */
  @Deprecated
  public static final int gkTwelve = 12;

  /**
   * @deprecated Since 6.0, There is no direct replacement for this constant
   * because it's use is questionable. Instead the code which
   * relied on it has been rewritten to be more customizable.
   */
  @Deprecated
  public static final int gkTwo = 2;

  // END, CR00190352
  // END, CR00107061
  // BEGIN HARP 40472, CC
  /**
   * @deprecated Since 6.0, replaced by @see gkNumberOfHoursInADay
   */
  @Deprecated
  public static final int gkTwentyFour = 24;
  // END, CR00238338
  // END HARP 40472

  // BEGIN, CR00023618, SK
  public static final String gkModifiableIndex = "1";

  // END, CR00023323
  public static final String gkAll = "ALL";

  public static final int gkRetryCount = 3;

  public static final String gkRestricted = "******";

  // BEGIN, CR00069996, SK
  public static final String gkSubGoalDetailsRestricted = "********";

  // END, CR00069996
  public static final String gkHighPriority = "1";

  public static final String gkLowPriority = "3";

  // BEGIN, CR00086767, CM
  public static final int gkCaseWorkQueue = 2;

  // END, CR00086767

  // ///////////////////////////////////////////////////////////////////////////

  public static final String gkLoadSupplierReturns = "LoadSupplierReturns";

  public static final String gkGeneralLedgerInterface = "GeneralLedgerInterface";

  public static final String gkGeneralLedgerInterfacePaymentsIssued = "Payments Issued ";

  public static final String gkGeneralLedgerInterfacePaymentsReceived = "Payments Received ";

  public static final String gkGeneralLedgerInterfaceLiabilities = "Liabilities ";

  // BEGIN, CR00190258, CL
  /**
   * @deprecated Since 5.2 SP3, replaced by
   * curam.util.exception.LocalisableString
   * (curam.message.GENERALCONCERN.TEXT_ANONYMOUS) .getMessage()
   *
   * This constant is deprecated because it did not facilitate
   * localization. See release note CR00190258.
   */
  @Deprecated
  public static final String gkAnonymousName = "Anonymous";

  /**
   * @deprecated Since 5.2 SP3, replaced by
   * curam.util.exception.LocalisableString
   * (curam.message.GENERALCONCERN.TEXT_ANONYMOUS) .getMessage()
   *
   * This constant is deprecated because it did not facilitate
   * localization. See release note CR00190258.
   */
  @Deprecated
  public static final String gkAnonymousAddressLine = "Anonymous";

  // END, CR00190258

  // Constant for empty string
  public static final String gkEmpty = "";

  protected static final int kStringNotFound = "".indexOf(" "); // -1

  public static final String gkRoot = "ROOT";

  public static final String gkFields = "FIELDS";

  public static final String gkField = "FIELD";

  public static final String gkName = "NAME";

  public static final String gkValue = "VALUE";

  public static final String gkPersonName = "personName";

  public static final String gkAddressLine1 = "addressLine1";

  public static final String gkAddressLine2 = "addressLine2";

  public static final String gkAddressLine3 = "addressLine3";

  public static final String gkAddressLine4 = "addressLine4";

  public static final String gkAddressLine5 = "addressLine5";

  public static final String gkCounty = "county";

  public static final String gkCity = "city";

  // BEGIN, CR00222456, ZV
  public static final String gkState = "state";

  // END, CR00222456

  public static final String gkZip = "zip";

  public static final String gkCountry = "country";

  // BEGIN, CR00142625, PDN
  public static final String gkNotes = "notes";

  public static final String gkNote = "note";

  public static final String gkDomain = "domain";

  public static final String gkDate = "date";

  public static final String gkSVRDATETIME = "SVR_DATETIME";

  public static final String gkUsername = "username";

  public static final String gkSimpleDateFormat = "yyyy-MM-dd HH:mm:ss";

  public static final String gkUnchecked = "unchecked";

  public static final String gkXml = "xml";

  public static final String gkOmitxmldeclaration = "omit-xml-declaration";

  public static final String gkYes = "yes";

  public static final String gkNo = "no";

  public static final String gkIndent = "indent";

  public static final String gkEncoding = "encoding";

  // BEGIN, CR00221232, SK
  public static final String kTreeSelectedPath = "lastSelectedPath";

  // END CR00221232

  public static final String gkUTF8 = "UTF-8";

  // BEGIN, CR00173137, JMA
  public static final String gkPercentage = "%";

  // END, CR00173137
  // END, CR00142625

  // BEGIN, CR00104198, ELG
  // BEGIN, CR00219873, ELG
  /**
   * English constant for "Address Unavailable" indication. This constant must
   * not be used for display anywhere. Instead of it
   * curam.util.exception.LocalisableString
   * (curam.message.BPOADDRESS.TEXT_ADDRESS_UNAVAILABLE).getMessage().
   * localized constant must be used for display.
   */
  // END, CR00219873
  public static final String kNoAddressForParticipant = "Address Unavailable";

  // BEGIN,CR00190258, CL
  // BEGIN,CR00104445, SAI
  /**
   * @deprecated Since 5.2 SP3, this constant is now hard coded where needed.
   *
   * This constant is deprecated because it did not facilitate
   * localization. See release note CR00190258.
   *
   * {@link curam.core.impl.AddressData#getAddressDataForLocale()}
   */
  // BEGIN, CR00277220, ELG
  @Deprecated
  public static final String gkDefaultAddressData = "1" + gkNewLine + "0"
    + gkNewLine + "US" + gkNewLine + "US" + gkNewLine + "1" + gkNewLine + "0"
    + gkNewLine + "ZIP=" + gkNewLine + "ADD3=" + gkNewLine + "ADD2="
    + kNoAddressForParticipant + gkNewLine + "CITY=" + gkNewLine + "ADD1="
    + gkNewLine + "STATE=" + gkNewLine;
  // END, CR00277220

  // BEGIN, CR00099876, SD
  /**
   * @deprecated Since 5.2 SP3, this constant is now hard coded where needed.
   *
   * This constant is deprecated because it did not facilitate
   * localization. See release note CR00190258.
   *
   * {@link curam.core.impl.AddressData#getAddressDataForLocale()}
   * .
   */
  // BEGIN, CR00277220, ELG
  @Deprecated
  public static final String gkUSCountyAddressData = "1" + gkNewLine + "0"
    + gkNewLine + "US" + gkNewLine + "US" + gkNewLine + "1" + gkNewLine + "0"
    + gkNewLine + "ZIP=" + gkNewLine + "ADD3=" + gkNewLine + "USCOUNTY="
    + gkNewLine + "ADD2=" + kNoAddressForParticipant + gkNewLine + "CITY="
    + gkNewLine + "ADD1=" + gkNewLine + "STATE=" + gkNewLine;
  // END, CR00277220

  // END, CR00099876
  // END, CR00104445
  /**
   * @deprecated Since 5.2 SP3, this constant is now hard coded where needed.
   *
   * This constant is deprecated because it did not facilitate
   * localization. See release note CR00190258.
   *
   * {@link curam.core.impl.AddressData#getAddressDataForLocale()}
   * .
   */
  @Deprecated
  public static final String gkGBAddressData = "1" + gkNewLine + "0"
    + gkNewLine + "UK" + gkNewLine + "GB" + gkNewLine + "1" + gkNewLine + "0"
    + gkNewLine + "ADD1=" + kNoAddressForParticipant + gkNewLine + "ADD2="
    + gkNewLine + "ADD3=" + gkNewLine + "ADD4=" + gkNewLine + "ADD5="
    + gkNewLine + "CITY=" + gkNewLine + "POSTCODE=" + gkNewLine + "COUNTRY="
    + gkNewLine;

  // BEGIN, CR00103736, ELG
  /**
   * @deprecated Since 5.2 SP3, this constant is now hard coded where needed.
   *
   * This constant is deprecated because it did not facilitate
   * localization. See release note CR00190258.
   *
   * {@link curam.core.impl.AddressData#getAddressDataForLocale()}
   * .
   */
  @Deprecated
  public static final String gkFreeformAddressData = "1" + gkNewLine + "0"
    + gkNewLine + "FREEFORM" + gkNewLine + "US" + gkNewLine + "1" + gkNewLine
    + "0" + gkNewLine + kNoAddressForParticipant + gkNewLine;

  // END, CR00103736
  // END, CR00104198

  // BEGIN, CR00113430, ELG
  public static final String gkGBLocale = "en_GB";
  // END, CR00113430

  public static final String gkDELocale = "de_DE";
  // END, CR00190258

  /**
   * @deprecated Since 6.0.4.0. The generated Verification event class is now
   * used instead {@link curam.events.Verification}.
   */
  @Deprecated
  public static final String gkVerificationEventClass = "Verification";

  /**
   * @deprecated Since 6.0.4.0. The generated Verification event type is now
   * used instead {@link curam.events.Verification#CaseClosed}.
   */
  @Deprecated
  public static final String gkCaseClosedEventType = "CaseClosed";

  // Verification Workflow close case Status
  public static final long gkCaseClosed = 3;

  /**
   * @deprecated Since 6.0.4.0. The generated Deduction event class is now
   * used instead {@link curam.events.Deductions}.
   */
  @Deprecated
  public static final String gkDeductionEventClass = "Deductions";

  /**
   * @deprecated Since 6.0.4.0. The generated Deduction event type is now used
   * instead {@link curam.events.Deductions#CreateDeduction()}.
   */
  @Deprecated
  public static final String gkCreateDeductionEventType = "CreateDeduction";

  /**
   * @deprecated Since 6.0.4.0. The generated Deduction event type is now used
   * instead {@link curam.events.Deductions#ModifyDeduction()}.
   */
  @Deprecated
  public static final String gkModifyDeductionEventType = "ModifyDeduction";

  /**
   * @deprecated Since 6.0.4.0. The generated Deduction event type is now used
   * instead {@link curam.events.Deductions#SkipDeduction()}.
   */
  @Deprecated
  public static final String gkSkipDeductionEventType = "SkipDeduction";

  /**
   * @deprecated Since 6.0.4.0. The generated Deduction event type is now used
   * instead {@link curam.events.Deductions#ActivateDeduction()}.
   */
  @Deprecated
  public static final String gkActivateDeductionEventType = "ActivateDeduction";

  /**
   * @deprecated Since 6.0.4.0. The generated Deduction event type is now used
   * instead {@link curam.events.Deductions#DeactivateDeduction()}
   * .
   */
  @Deprecated
  public static final String gkDeactivateDeductionEventType = "DeactivateDeduction";

  /**
   * @deprecated Since 6.0.4.0. The generated Deduction event type is now used
   * instead {@link curam.events.Deductions#CancelDeduction()}.
   */
  @Deprecated
  public static final String gkCancelDeductionEventType = "CancelDeduction";

  /**
   * @deprecated Since 6.0.4.0. The generated Deduction event type is now used
   * instead {@link curam.events.Deductions#ExpireDeduction()}.
   */
  @Deprecated
  public static final String gkExpireDeductionEventType = "ExpireDeduction";

  /**
   * @deprecated Since 6.0.4.0. The generated Deduction event type is now used
   * instead
   * {@link curam.events.Deductions#DeductionPaidLiability()}.
   */
  @Deprecated
  public static final String gkDeductionPaidLiabilityEventType = "DeductionPaidLiability";

  // Public access system user types.
  public static final String gkExternalUser = "EXTERNAL";

  public static final String gkInternalUser = "INTERNAL";

  // BEGIN, CR00066677, CM
  // Case Owner Home Pages
  public static final String gkUserHomePage = "Organization_userHome";

  public static final String gkOrgUnitHomePage = "Organization_orgUnitHome";

  public static final String gkPositionHomePage = "Organization_viewPosition";

  public static final String gkWorkQueueHomePage = "WorkAllocation_viewWorkQueue";

  // END, CR00066677

  // BEGIN, CR00143146, ZV
  // View Case Owner Pages
  public static final String gkViewUserPage = "Organization_viewUserDetails";

  public static final String gkViewOrgUnitPage = "Organization_viewOrgUnitDetails";

  public static final String gkViewPositionPage = "Organization_viewPositionDetails";

  public static final String gkViewWorkQueuePage = "WorkAllocation_viewWorkQueueDetails";

  // END, CR00143146

  // BEGIN, CR00091182, CM
  // Service Plan SubGoal Pages
  public static final String gkSelectNewPlannedSubGoalPage = "ServicePlanDelivery_selectNewPlannedSubGoal";

  public static final String gkNewPlannedSubGoalPage = "ServicePlanDelivery_newPlannedSubGoal";

  // END, CR00091182

  // BEGIN, CR00093416, CM
  // Service Plan Planned Group SubGoal Pages
  public static final String gkSelectPlannedSubGoalPage = "ServicePlanDelivery_selectPlannedSubGoal";

  public static final String gkCreatePlannedSubGoalPage = "ServicePlanDelivery_createPlannedSubGoal";

  // END, CR00093416

  // BEGIN, CR 00032741, DK
  public static final Money ZERO_MONEY = new Money(0.00f);

  public static final Double MIN_PERCENT = new Double(0.00f);

  public static final Double MAX_PERCENT = new Double(100.00f);

  // END, CR 00032741

  // for ISCommon
  // BEGIN, CR00070163, MR
  public static final String gkNull = "Null";

  // END, CR00070163

  /**
   * Identifier for separator.
   */
  public static final String kSeparator = " - ";

  public static final String kYES = new String("YES");

  public static final String kNO = new String("NO");

  public static final String kOtf = "OTF";

  public static final String gkHandleUnprocessedRecords = "Handling unprocessed rows";

  public static final String gkCaseReassessmentFactClass = "curam.isu.sl.fact.ISUCaseReassessmentFactory";

  public static final String gkCaseReassessmentClassMethod = "restartProcessingBasedOnComponentDetails";

  public static final String kProcessName = new String(
    "NoSupervisorExistingForCaseOwner");

  // BEGIN, CR00086767, CM
  public static final String kApprovalProcessName = new String(
    "NoSupervisorExistingForCaseApproval");

  // END, CR00086767

  // BEGIN, CR00114568, CW
  // Evidence Broker workflow process names
  public static final String kIdenticalSharingEvidenceUpdate = new String(
    "IdenticalSharingEvidenceUpdate");

  public static final String kNonIdenticalSharingEvidenceUpdate = new String(
    "NonIdenticalSharingEvidenceUpdate");

  public static final String kCaseParticipantCreationEvidenceSharing = new String(
    "CaseParticipantCreationEvidenceSharing");

  // END, CR00114568

  public static final String kInitialContextFactory = "com.sun.jndi.cosnaming.CNCtxFactory";

  public static final String kProviderURL = "iiop://localhost:900";

  public static final String kAuthenticationObject = "CuramRMIAuthentication";

  // BEGIN, CR00085608 SK
  /**
   * Identifier for holding question mark symbol.
   */
  public static final String kQuestion = "?";

  public static final String gkAddress = "Address";

  // END, CR00085608 SK

  // Constants page names for agenda
  public static final boolean kSUBMIT_ON_NEXT = true;

  public static final boolean kINITIAL_PAGE = true;

  public static final boolean kNO_SUBMIT_ON_NEXT = false;

  public static final boolean kNON_INITIAL_PAGE = false;

  public static final String koriginalConcernRoleID = "originalConcernRoleID";

  public static final String kduplicateConcernRoleID = "duplicateConcernRoleID";

  public static final String kcontextDescription = "contextDescription";

  public static final String kconcernRoleMergeID = "concernRoleMergeID";

  public static final String kconcernRoleID = "concernRoleID";

  public static final String kParticipant_mergeAddressesPage = "Participant_mergeAddresses";

  public static final String kParticipant_mergeAlternativeIDsPage = "Participant_mergeAlternativeIDs";

  public static final String kParticipant_mergeAlternativeNamesPage = "Participant_mergeAlternativeNames";

  public static final String kParticipant_mergeBankAccountsPage = "Participant_mergeBankAccounts";

  public static final String kParticipant_mergeCitizenshipsPage = "Participant_mergeCitizenships";

  public static final String kParticipant_mergeCommunicationExceptionsPage = "Participant_mergeCommunicationExceptions";

  public static final String kParticipant_mergeContactsPage = "Participant_mergeContacts";

  public static final String kParticipant_mergeEducationPage = "Participant_mergeEducation";

  public static final String kParticipant_mergeEmailAddressesPage = "Participant_mergeEmailAddresses";

  public static final String kParticipant_mergeEmploymentPage = "Participant_mergeEmployment";

  // BEGIN, CR00099404, CM
  public static final String kParticipant_mergeForeignResidenciesPage = "Participant_mergeForeignResidencies";

  // END, CR00099404
  public static final String kParticipant_mergeNotesPage = "Participant_mergeNotes1";

  public static final String kParticipant_mergePhoneNumbersPage = "Participant_mergePhoneNumbers";

  public static final String kParticipant_mergeRelationshipsPage = "Participant_mergeRelationships";

  public static final String kParticipant_mergeWebAddressesPage = "Participant_mergeWebAddresses";

  public static final String kParticipant_mergeSummaryPage = "Participant_mergeSummary";

  // BEGIN, CR00146028, SS
  public static final String kParticipant_mergeSpecialCautionPage = "Participant_mergeSpecialCaution";

  // END, CR00146028
  // BEGIN, CR00100109, PDN
  public static final String kconcernRoleDuplicateID = "concernRoleDuplicateID";

  public static final String kParticipant_mergeSummaryForViewDuplicate = "Participant_mergeSummaryForViewDuplicate";

  public static final String kParticipant_viewDuplicate = "Participant_viewDuplicate";

  // END, CR00100109
  public static final String kParticipant_listDuplicates = "Participant_listDuplicates";

  // BEGIN, CR00100213, PDN
  public static final String kUnused = "unused";

  // END, CR00100213
  // BEGIN, CR00099881, CSH
  public static final String kPerson_listCase = "Person_listCase";

  public static final String kPerson_listCaseForDuplicate = "Person_listCaseForDuplicate";

  public static final String kPerson_listIssue = "Person_listIssue";

  public static final String kPerson_listIssueForDuplicate = "Person_listIssueForDuplicate";

  public static final String kServicePlanDelivery_listForPerson = "ServicePlanDelivery_listForPerson";

  public static final String kServicePlanDelivery_listForDuplicatePerson = "ServicePlanDelivery_listForDuplicatePerson";

  // END, CR00099881

  // BEGIN, CR00100651, CSH
  public static final String kPerson_listCommunication = "Person_listCommunication";

  public static final String kPerson_listCommunicationForDuplicate = "Person_listCommunicationForDuplicate";

  public static final String kPerson_listDeduction = "Person_listDeduction";

  public static final String kPerson_listDeductionForDuplicate = "Person_listDeductionForDuplicate";

  public final static String kPerson_listFinancial = "Person_listFinancial1";

  public static final String kPerson_listFinancialForDuplicate = "Person_listFinancialForDuplicate";

  public static final String kPerson_listInsuranceConsolidation = "Person_listInsuranceConsolidation";

  public static final String kPerson_listInsuranceConsolidationForDuplicate = "Person_listInsuranceConsolidationForDuplicate";

  public static final String kPerson_listInsuranceLineItem = "Person_listInsuranceLineItem";

  public static final String kPerson_listInsuranceLineItemForDuplicate = "Person_listInsuranceLineItemForDuplicate";

  public static final String kPerson_listInteraction = "Person_listInteraction";

  public static final String kPerson_listInteractionForDuplicate = "Person_listInteractionForDuplicate";

  public final static String kPerson_listFinancialInstrument = "Person_listFinancialInstrument1";

  public static final String kPerson_listFinancialInstrumentForDuplicate = "Person_listFinancialInstrumentForDuplicate1";

  public static final String kPerson_listRole = "Person_listRole";

  public static final String kPerson_listRoleForDuplicate = "Person_listRoleForDuplicate";

  public static final String kPerson_listTask = "Person_listTask";

  public static final String kPerson_listTaskForDuplicate = "Person_listTaskForDuplicate";

  public static final String kPerson_listAdminRoleForDuplicate = "Person_listAdminRoleForDuplicate";

  public static final String kPerson_listAdminRole = "Person_listAdminRole";

  public static final String kVerificationApplication_PersonVerificationList = "VerificationApplication_PersonVerificationList";

  public static final String kVerificationApplication_PersonVerificationListForDuplicate = "VerificationApplication_PersonVerificationListForDuplicate";

  public static final String kVerificationApplication_PersonOutstandingVerificationList = "VerificationApplication_PersonOutstandingVerificationList";

  public static final String kVerificationApplication_POutstandingVerificationListForDuplicate = "VerificationApplication_POutstandingVerificationListForDuplicate";

  // END, CR00100651
  // BEGIN, CR00144945, SS
  // BEGIN, CR00147819, ZV
  public static final String kPerson_listIncidents = "Incident_listIncidentsForParticipant1";

  public static final String kPerson_listIncidentsForDuplicate = "Incident_listIncidentsForDuplicateParticipant1";

  public static final String kPerson_listIncidents2 = "Incident_listIncidentsForParticipant2";

  public static final String kPerson_listIncidentsForDuplicate2 = "Incident_listIncidentsForDuplicateParticipant2";

  // END, CR00147819
  // END, CR00144945
  // BEGIN, CR00102900, CSH
  // Constants for client merge soft link tabs
  public static final String kURL = "URL";

  public static final String kTabName = "TAB_NAME";

  public static final String kTabImage = "TAB_IMAGE";

  public static final String kFocus = "FOCUS";

  public static final String kFront = "front";

  public static final String kBack = "back";

  public static final String kUserLocale = "userLocale";

  public static final String kConcernImage = "../Images/concern.gif";

  public static final String kDuplicateImage = "../Images/concernrole_duplicate.jpg";

  public static final String kPageSuffix = "Page.do?concernRoleID=";

  // END, CR00102900
  // Constants for Contact Log Preview renderer XML data
  public static final String kContactLog = "ContactLog";

  public static final String kStartDateTime = "startDateTime";

  // BEGIN, CR00265985, JMA
  public static final String gkContactLogPreview = "contact-log-preview";
  public static final String gkContactLogSpacer = "contact-log-spacer";
  public static final String gkContactLogHeader = "cl-table-header";
  public static final String gkNarrative = "narrative";

  // BEGIN, CR00120074, ZV
  public static final String kContactLogType = "contactLogType";

  public static final String kPurpose = "purpose";

  public static final String kLocation = "location";

  public static final String kMethod = "method";

  public static final String kParticipantList = "participantList";

  // BEGIN, CR00139531, ZV
  public static final String kConcernList = "concernList";

  // END, CR00139531
  // END, CR00120074
  public static final String kNote = "Note";

  public static final String kNoteText = "noteText";

  // BEGIN CR00108593, GBA
  /**
   * RelatedID to pass when transaction log record relates to Default page.
   */
  public static final long kDefaultRelatedID = 0;

  // END CR00108593

  // BEGIN, CR00119218, CD
  public static final String kDomainSVR_STRING = "SVR_STRING";

  // END, CR00119218
  // BEGIN, CR00122256, BD
  public static final String kDomainRESOURCE_PROPERTY = "RESOURCE_PROPERTY";

  // END, CR00122256

  // BEGIN, CR00146449, MR
  /**
   * Daily Frequency Pattern.
   */
  public static final String gkDailyFrequencyPattern = "000100000";

  /**
   * Weekly Frequency Pattern.
   */
  public static final String gkWeeklyFrequencyPattern = "100100000";

  /**
   * Monthly Frequency Pattern.
   */
  public static final String gkMonthlyFrequencyPattern = "200100000";

  /**
   * Yearly Frequency Pattern.
   */
  public static final String gkYearlyFrequencyPattern = "300100000";

  // END, CR00146449

  // BEGIN, CR00157011, MC
  // Facade scope objects.
  public static final String gkAddressExpiryError = "AddressExpiryError";

  public static final String gkBankAccountExpiryError = "BankExpiryError";

  // END, CR00157011
  // BEGIN, CR00146629, SK
  public static final String kCodeTableName_Locale = "Locale";

  public static final String gkXsltemplateNotProceed = "XsltemplateNotProceed";

  public static final String gkXsltemplateProceed = "XsltemplateProceed";

  // END, CR00146629
  // BEGIN CR00143146, ZV
  /**
   * Identifier for holding the hyperlink on email id.
   */
  public static final String kMailLink = "mailto:";

  // END CR00143146

  // BEGIN CR00150153, ZV
  public static final String gkColon = ":";

  // END CR00150153

  // BEGIN, CR00161566, MC
  /**
   * Notification defined in the PDT to notify the user that the reassessment
   * of their case is complete.
   */
  public static final String gkNoteHistoryIncidents = "Incidents";

  public static final String gkNoteHistoryNotes = "Notes";
  // BEGIN, CR00406083, VT
  public static final String gkNarrativeText = "Narrative";
  // END, CR00406083

  // END, CR00161566

  // BEGIN, CR00160780, SPD
  /**
   * Notification defined in the PDT to notify the user that the reassessment
   * of their case is complete.
   */
  public static final String kCaseReassessmentNotification = "CASEREASSESSMENTNOTIFICATION";

  // END, CR00160780

  // BEGIN, CR00164008, JMA
  /**
   * The Preview document to be generated when a Pro Forma communications is
   * previewed.
   */
  public static final String kProFormaDocumentPreview = "ProFormaDocumentPreview.pdf";

  // END, CR00164008

  // BEGIN CR00164412, PDN
  public static final int gkMaxCommentLength = 200;

  // END CR00164412

  // BEGIN, CR00158767, LD
  /**
   * Initials count for Person name. FirstForename + OtherForename + Surname
   */
  public static final int kPersonNameInitialsCount = 3;

  // END, CR00158767

  // BEGIN, CR00165038, ZV
  /**
   * My Cases search filter user owner item.
   */

  /**
   * @deprecated Since 6.0.4.0, replaced by
   * curam.util.exception.LocalisableString
   * (curam.message.GENERALSEARCH
   * .INF_SEARCH_CURRENT_USER).getMessage().
   */
  @Deprecated
  public static final String gkUserOwner = "Me";

  /**
   * My Cases search filter organization object owner item prefix.
   */

  /**
   * @deprecated Since 6.0.4.0, replaced by
   * curam.util.exception.LocalisableString
   * (curam.message.GENERALSEARCH
   * .INF_SEARCH_CURRENT_USER_ORG_OBJECT).getMessage().
   */
  @Deprecated
  public static final String gkOrgObjectOwnerPrefix = "My";

  /**
   * User case search filters.
   */
  public static final String kUserSearchCaseTypeList = "CaseTypeList";

  public static final String kUserSearchCaseStatusList = "CaseStatusList";

  public static final String kUserSearchCaseOwnerList = "CaseOwnerList";

  // END, CR00165038

  // BEGIN, CR00203865, ZV
  /**
   * User investigation search filters.
   */
  public static final String kUserSearchInvestigationTypeList = "InvestigationTypeList";

  public static final String kUserSearchInvestigationStatusList = "InvestigationStatusList";

  public static final String kUserSearchInvestigationOwnerList = "InvestigationOwnerList";

  /**
   * Investigation search criteria status text constant.
   */
  public static final String gkSearchStatusInvestigations = "Investigations";

  // END, CR00203865

  // BEGIN CR00159706, MH
  /**
   * Maximum length allowed for the summary details.
   */
  public static final int gkMaxContractSummaryLength = 50;

  // END CR00159706

  // BEGIN CR00166614, SPD
  // Identifier of the root node for notes. The closing bracket is not
  // included to cater for the possible existence of attribute values
  public static final String gkRootNotesSearchString = "<notes";

  // END CR00166614

  public static final String kPlanItemPage = "Default";

  // BEGIN, CR00161962, KY
  // For Enhanced User Inbox
  // Identifier for constant ALL
  public static final String kcode_All = "ALL";

  // Identifier for constant 0
  public static final long kassignedID_All = 0;

  // For User Preference
  public final static String MAX_TASKS = "max.tasks";

  public final static String DEFAULT_OU = "default.org.unit";

  public final static String DEFAULT_WQ = "default.work.queue";

  public final static String DEFAULT_FILTER = "default.filter";

  /**
   * The default list size for the inbox pods.
   */
  public final static String DEFAULT_INBOX_POD_LIST_SIZE = "default.inbox.pod.list.size";

  // For Organizational objects
  public final static String kOrganisationUnit = "ORGANISATION_UNIT";

  public final static String kPosition = "POSITION";

  public final static String kJob = "JOB";

  public final static String kWorkQueue = "WORK_QUEUE";

  // END, CR00161962

  // BEGIN CR00167930, ZV
  /**
   * Search criteria status text constants.
   */

  /**
   * @deprecated Since 6.0.4.0, replaced by
   * curam.util.exception.LocalisableString
   * (curam.message.BPOCASESEARCH.
   * INF_BPOCASESEARCH_CASE_SEARCH_CRITERIA_TEXT_TYPE_OWNER_STATUS
   * ).getMessage().
   */
  @Deprecated
  public static final String gkSearchStatusCases = "Cases";

  /**
   * @deprecated Since 6.0.4.0, replaced by
   * curam.util.exception.LocalisableString
   * (curam.message.BPOCASESEARCH.
   * INF_BPOCASESEARCH_CASE_SEARCH_CRITERIA_TEXT_TYPE_OWNER_STATUS
   * ).getMessage().
   */
  @Deprecated
  public static final String gkSearchStatusType = "for type(s)";

  // BEGIN CR00174336, ZV
  /**
   * @deprecated Since 6.0.4.0, replaced by
   * curam.util.exception.LocalisableString
   * (curam.message.BPOCASESEARCH.
   * INF_BPOCASESEARCH_CASE_SEARCH_CRITERIA_TEXT_ALL_TYPES_OWNER_STATUS
   * ).getMessage().
   */
  @Deprecated
  public static final String gkSearchStatusAllTypes = "for all types";

  // END CR00174336
  /**
   * @deprecated Since 6.0.4.0, replaced by
   * curam.util.exception.LocalisableString
   * (curam.message.BPOCASESEARCH.
   * INF_BPOCASESEARCH_CASE_SEARCH_CRITERIA_TEXT_TYPE_OWNER_STATUS
   * ).getMessage().
   */
  @Deprecated
  public static final String gkSearchStatusOwner = "owned by";

  /**
   * @deprecated Since 6.0.4.0, replaced by
   * curam.util.exception.LocalisableString
   * (curam.message.BPOCASESEARCH.
   * INF_BPOCASESEARCH_CASE_SEARCH_CRITERIA_TEXT_TYPE_OWNER_STATUS
   * ).getMessage().
   */
  @Deprecated
  public static final String gkSearchStatusStatus = "with a status of";

  // END CR00167930

  // BEGIN CR00174336, ZV
  /**
   * Search criteria status rich text XML constants.
   */
  public static final String gkXMLContent = "content";

  public static final String gkXMLStrong = "strong";

  // END CR00174336

  // BEGIN, CR00183167, ZV
  public static final String gkNotesTextPath = "//notes/note/content";

  // END, CR00183167

  // BEGIN, CR00183984, ELG
  // Meetings constants
  /**
   * The constant for a using a comma as a separator.
   */
  public static final String kCommaSeparator = ", ";

  /**
   * The constant representation for the value zero as a long.
   */
  public static final long kLongZero = 0;

  // sensitivity identifiers
  public static final String kReadAccess = "Read";

  public static final String kModifyAccess = "Modify";

  public static final String kCreate = "Create";

  public static final String kDelete = "Delete";

  public static final String kDefaultSensitivityCode = "1";

  // Meeting Minutes Constants
  public static final String gkSubject = "subject";

  public static final String gkAttribute = "attribute";

  public static final String gkActionAssignmentTaskDef = "MEETINGACTION";

  // BEGIN, CR00245108, CW
  public static final String gkMeetingActionNoCaseTaskDef = "MEETINGACTIONNOCASE";
  // END, CR00245108

  public static final String gkWdo = "wdo";

  // BEGIN, CR00221236, CW
  public static final String gkValueLowerCase = "value";

  public static final String gkNameLowerCase = "name";

  // END, CR00221236
  // BEGIN, CR00219482, CW
  // Core Meetings pages
  public static final String gkCalendarMeetingRichTextDetailsPage = "CalendarMeetingDetails_richTextModify";

  public static final String gkCalendarMeetingAttendencePage = "CalendarMeetingAttendence_modify";

  public static final String gkCalendarMeetingRichTextNotesPage = "CalendarMeetingNotes_richTextModify";

  public static final String gkCalendarMeetingRichTextDecisionsPage = "CalendarMeetingDecisions_richTextModify";

  public static final String gkCalendarMeetingActionsPage = "CalendarMeetingActions_modify";

  public static final String gkCalendarMeetingFilesPage = "CalendarMeetingMinutes_addAttachmentsFromList";

  public static final String gkCalendarMeetingCasesPage = "CalendarMeetingCases_modify";

  public static final String gkCalendarMeetingMinutesSummaryPage = "CalendarMeetingMinutes_viewSummary";

  public static final String gkCalendarListMinutesPage = "CalendarMeetingDetails_listMeetingsForSEF";

  public static final String gkCalendarViewMeetingPage = "CalendarMeeting_viewMeeting";

  // END, CR00219482

  public static final String gkListMinutesPage = "MeetingDetails_listMeetingsForSEF";

  public static final String gkViewMeetingPage = "Meeting_viewMeeting";

  public static final boolean gkSUBMIT_ON_NEXT = true;

  public static final boolean gkNO_SUBMIT_ON_NEXT = false;

  public static final boolean gkINITIAL_PAGE = true;

  public static final boolean gkNON_INITIAL_PAGE = false;

  public static final char gkTAB = '\t';

  public static final char gkBAR = '|';

  public static final int gkSixty = 60;

  public static final int gkNoHoursInDay = 24;

  public static final String gkMeetingIDParameter = "meetingID";

  public static final String gkCaseIDParameter = "caseID";

  public static final String gkActivityParameter = "activityID";

  public static final String gkCannotDoThis = "cannot do this";

  public static final String gkSemiColon = ";";

  public static final String gkPriority = "Priority";

  public static final String gkImportance = "Importance";

  public static final String gkROOTCloseTag = "</ROOT>";

  public static final String gKROOTOpenTag = "<ROOT>";

  /**
   * The data type to be used for the Meeting Minutes report sent to all
   * invitees.
   */
  public static final String gkApplicationPDF = "application/pdf";

  // Date formats that may be used
  /**
   * The following are the allowed date formats that may be used in the
   * convert date to string method. Examples: Input date time = 26 February
   * 2008 13.21.05 kDateFormatTimeNoSeconds e.g. 13.21
   * kDateFormatStandardEUDate = 26/02/2008 kDateFormatLongMonthWord = 26
   * February 2008
   */
  public static final String gkDateFormatTimeNoSeconds = "HH:mm";

  public static final String gkDateFormatStandardEUDate = "dd/MM/yyyy";

  public static final String gkDateFormatLongMonthWord = "dd MMMM yyyy";

  public static final String gkPARSE_RICH_TEXT_NODE = "parseRichTextNode";

  public static final String gkAllFONT = "*/FONT";

  public static final String gkROOT = "ROOT";

  public static final String gkTEXTFORMAT = "TEXTFORMAT";

  // Byte Array Data Source Constants
  public static final String gkISOStandard_8859_1 = "iso-8859-1";

  public static final String gkApplicationOctetStream = "application/octet-stream";

  public static final String gkByteArrayDataSource = "ByteArrayDataSource";

  public static final String gkNoDataString = "no data";

  // Workflow Helper Constants
  public static final String gkFullStop = ".";

  public static final String gkCuramEnableWorflowEvent = "curam.enable.workflow.event.";

  public static final String gkCommaDelimiter = ",";

  public static final char gkCommaDelimiterChar = ',';

  /**
   * The default case details provider implementation.
   */
  public static final String gkDefaultCaseDetailsRetriever = "ANY_TYPE";

  // END, CR00183984

  // BEGIN, CR00184356, JMA
  /**
   * Tab Panel Constants.
   */
  public static final String gkExtension = "Ext";

  // END, CR00184356

  // BEGIN, CR00190252, NP
  // Input field limits
  // BEGIN, CR00312010, AKr
  public static final int kUpperFIRSTNAME = 65;

  public static final int kUpperSURNAME = 65;

  public static final int kUpperBIRTHNAME = 65;

  public static final int kUpperMOTHERBIRTHSURNAME = 65;

  public static final int kUpperTRADINGNAME = 131;

  public static final int kUpperREGISTEREDNAME = 131;

  // END, CR00312010

  public static final int kUpperNAME = 131;

  public static final int kUpperUSERNAME = 64;

  public static final int kUpperROLENAME = 50;

  public static final int kUpperADDRESSELEMENTVALUE = 256;

  // END, CR00190252

  // BEGIN, CR00190101, CD
  public static String kYesLowerCase = "yes";

  // END, CR00190101
  // BEGIN, CR00190069, JMA
  /**
   * Renderer constants for tab panels. *
   */
  public static final String gkContentPanelImagePanelWidth = "content-panel-detail image-panel-width";

  public static final String gkBorderContainer = "border-container";

  public static final String gkContainerPanel = "container-panel";

  public static final String gkContainerPanelIC = "container-panel-ic";

  public static final String gkContainerPanelPD = "pd-container-panel";

  public static final String gkContainerPanelOverpayment = "overpay-container-panel";

  public static final String gkContainerPanelUnderpayment = "underpay-container-panel";

  public static final String gkContainerPanelInvestigation = "investigation-container-panel";

  public static final String gkContainerPanelIncident = "incident-container-panel";

  public static final String gkContainerPanelPerson = "person-container-panel";

  public static final String gkContainerPanelEmployer = "employer-container-panel";

  public static final String gkContentPanel = "content-panel";

  public static final String gkPersonImagePanel = "content-panel-detail person-image-panel";

  public static final String gkPersonDetailsPanel = "content-panel-detail person-details-panel";

  public static final String gkPersonDetailsPanelOneCol = "content-panel-detail person-details-panel-onecol";

  public static final String gkPersonDetailsPanelNoLinks = "content-panel-detail person-details-panel-no-links";

  public static final String gkPersonLinksPanel = "content-panel-detail person-links-panel";

  public static final String gkPersonLinksPanelOneCol = "content-panel-detail person-links-panel-onecol";

  public static final String gkICLinksPanel = "content-panel-detail ic-links-panel";

  public static final String gkEmployerImagePanel = "content-panel-detail employer-image-panel";

  public static final String gkEmployerDetailsPanel = "content-panel-detail employer-details-panel";

  public final static String gkEmployerWorkforcePanel = "employer-workforce-panel";

  public final static String gkEmployerWorkforceDetail = "employer-workforce-detail";

  public static final String gkContentPanelIncident = "content-panel-detail incident-content-panel";

  public static final String gkCaseParticipantPanel = "content-panel-detail case-participant-panel";

  public static final String gkCaseParticipantPanelSingle = "content-panel-detail case-participant-panel ic-single-member";

  public static final String gkInvestigationContentPanel = "content-panel-detail investigation-content-panel";

  public static final String gkInvestigationLinksPanel = "content-panel-detail investigation-links-panel";

  public static final String gkLeft = "left";

  public static final String gkCenter = "center";

  public static final String gkRight = "right";

  public static final String gkStyle = "style";

  public static final String gkLink = "link";

  public static final String gkTopPanel = "top-panel";

  public static final String gkBottomPanel = "bottom-panel";

  public static final String gkImage = "image";

  public static final String gkIcon = "icon";

  public static final String gkIconEmail = "IconEmail";

  public static final String gkIconPhone = "IconPhone";

  public static final String gkIconFax = "IconFax";

  public static final String gkIconWeb = "IconWeb";

  public static final String gkIconInvestigation = "IconInvestigation";

  public static final String gkIconLegalAction = "IconLegalAction";

  public static final String gkIconIncident = "IconIncident";

  public static final String gkIconAppeal = "IconAppeal";

  public static final String gkIconIssue = "IconIssue";

  public static final String gkIconCCV = "IconCCV";

  public static final String gkIconMap = "IconMap";

  public static final String gkIconProspectPerson = "IconProspectPerson";

  public static final String gkIconDuplicatePerson = "IconDuplicatePerson";

  public static final String gkIcoProspectEmployer = "IconProspectEmployer";

  public static final String gkEmail = "email";

  public static final String gkMailto = "mailto:";

  public static final String gkPhoneNumber = "phonenumber";

  public static final String gkFaxNumber = "faxnumber";

  public static final String gkWaterMark = "watermark";

  public static final String gkProspectDupWaterMark = "prospectdupwatermark";

  public static final String gkRendererImages = "curam.widget.render.infrastructure.i18n.Image";

  public static final String gkPersonSearchName = "personsearchname";

  /**
   * Tab details constants. *
   */
  public static final String gkTabDetails = "tab-details";

  public static final String gkContentParticipantName = "content-name";

  public static final String gkContentParticipantID = "content-participant-id";

  public static final String gkContentAddress = "content-address";

  public static final String gkContentSex = "content-sex";

  public static final String gkContentAge = "content-age";

  public static final String gkContentMap = "content-map";

  public static final String gkContentContacts = "content-contacts";

  public static final String gkTabLinks = "tab-links";

  public final static String gkGenderCode = "GENDER_CODE";

  public static final String gkContentWebAddress = "content-web-address";

  public static final String gkIndustryTypeCode = "INDUSTRY_TYPE_CODE";

  public static final String gkEmployerRelatedCompanies = "employer-related-companies";

  public static final String gkEmployerContentIndustry = "employer-content-industry";

  /**
   * Participant Tab Details links constants. *
   */
  public static final String gkInvestigations = "investigations";

  public static final String gkLegalActions = "legal-actions";

  public static final String gkIncidents = "incidents";

  public static final String gkAppeals = "appeals";

  public static final String gkIssues = "issues";

  public static final String gkCitizenContextViewer = "citizen-context-viewer";

  public static final String gkPersonFileDownLoadLink = "../servlet/FileDownload?pageID=Person_homeTabDetails&concernRoleID=";

  public static final String gkCaseMemberFileDownLoadLink = "../servlet/FileDownload?pageID=Person_homeTabDetails&concernRoleID=";

  public static final String gkConcernRoleImageID = "concernRoleImageID";

  public static final String gkConcernRoleID = "concernRoleID";

  public static final String gkAddressID = "addressID";

  public static final String gkThumbnail = "tab-thumbnail";

  public static final String gkEmployerThumbnail = "employer-tab-thumbnail";

  public static final String gkEmployerIcon = "IconEmployer";

  public static final String gkIconSpecialCaution = "IconSpecialCaution";

  public static final String gkIconSpecialCautionList = "IconListSpecialCaution";

  public static final String gkLeftCornerImage = "left-corner-image";

  public static final String gkRightCornerImage = "right-corner-image";

  public static final String gkGenericMale = "IconGenericMale";

  public static final String gkGenericFemale = "IconGenericFemale";

  public static final String gkParticipantImage = "participant-image";

  public static final String gkEmployerImage = "employer-image";

  public static final String gkEditLink = "edit-link";

  public static final String gkEditPhoto = "Add Picture";

  public static final String gkRemovePhoto = "Remove Picture";

  // END, CR00190069
  // Person tab links constants
  public static final String gkPersonInvestigationPage = "Person_listInvestigationPage.do";

  public static final String gkPersonIssuePage = "Person_listIssuePage.do";

  public static final String gkPersonIncidentsPage = "Incident_listIncidentsForParticipant1Page.do";

  // Employer tab links constants
  public static final String gkEmployerRelatedCompanyPage = "Employer_listRelatedCompanyPage.do";

  // BEGIN, CR00191022, ZV
  /**
   * Case Tab details constants. *
   */
  public static final String gkStyleSingleList = "single-list";

  public static final String gkStyleLink = "link";

  public static final String gkStyleHeader = "header";

  // BEGIN, CR00191703, ZV
  public static final String gkStyleWatermark = "watermark";

  public static final String gkStyleRotator = "rotator";

  public static final String gkStyleStackContainer = "stack-container";

  public static final String gkTableList = "table-list";

  // BEGIN, CR00204212, ZV
  public static final String gkStyleBirt = "birt";

  // BEGIN, CR00204212, ZV
  public static final String gkIconCaseOwner = "IconCaseOwner";

  public static final String gkIconAllegation = "IconCCV";

  public static final String gkIconOpenAllegation = "IconAllegation";

  public static final String gkIconDecidedAllegation = "IconDecidedAllegation";

  public static final String gkIconPayment = "IconPayments";

  public static final String gkIconAllegationRole = "IconCCV";

  public static final String gkIconContactLog = "IconCCV";

  public static final String gkIconVerification = "IconVerification";

  public static final String gkIconEvidenceInEdit = "IconEvidenceInEdit";

  public static final String gkIconUnderpayment = "IconUnderpayments";

  public static final String gkIconOverpayment = "IconOverpayments";

  public static final String gkIconDecision = "IconCCV";

  public static final String gkIconCaseReview = "IconScheduleBlue";

  public static final String gkIconEmployerWorkforce = "IconAllegationBlue";

  public static final String gkContactToolTip = "contact-tooltip-panel";

  public static final String gkOpenAllegationToolTip = "open-allegation-tooltip-panel";

  public static final String gkDecidedAllegationToolTip = "decided-allegation-tooltip-panel";

  public static final String gkCaseMemberListContenPanelID = "case-member-list-panel";

  public static final String gkCaseMemberPhotoContenPanelID = "case-member-photo-panel";

  public static final String gkPersonNameIcons = "person-name-icons";

  public static final String gkICCaseOwnerPanel = "ic-case-owner-panel";

  public static final String gkICCaseOwnerIcon = "ic-case-owner-icon";

  public static final String gkICCaseOwner = "ic-case-owner";

  public final static String gkICCaseStatus = "ic-case-status";

  public final static String gkICStatus = "ic-status";

  public static final String gkListIcon = "list-icon";

  public static final String gkImageLinks = "image-links";

  /**
   * Benefit Sample constants. *
   */
  public static final String gkProductDeliveryDetails = "pd-details";

  public final static String gkProductDeliveryContentPanel = "content-panel-detail pd-content-panel";

  public final static String gkProductDeliveryContentPanelOneCol = "content-panel-detail pd-content-panel-onecol";

  public final static String gkProductDeliveryLinksPanel = "content-panel-detail pd-links-panel";

  public final static String gkProductDeliveryLinksPanelOneCol = "content-panel-detail pd-links-panel-onecol";

  public final static String gkProductDeliveryRef = "pd-reference";

  public final static String gkProductDeliveryRefID = "pd-reference-id";

  public final static String gkProductRelatedCase = "pd-related-ic-case";

  public final static String gkProductDeliveryStart = "started";

  public final static String gkProductDeliveryCertified = "certified";

  public final static String gkProductDeliveryDetailsTable = "pd-details-table";

  public final static String gkProductDeliveryCaseStatus = "pd-case-status";

  public final static String gkProductDeliveryStatus = "pd-status";

  public static final String gkProductDeliveryCaseOwnerPanel = "pd-case-owner-panel";

  public static final String gkProductDeliveryCaseOwnerIcon = "pd-case-owner-icon";

  public static final String gkProductDeliveryCaseOwner = "pd-case-owner";

  public final static String gkPDDecisionContent = "decision-content";

  public final static String gkNextReviewLabel = "next-review-label";

  public final static String gkNextReview = "next-review";

  /**
   * Underpayment constants. *
   */
  public final static String gkPaymentDetails = "Payment Details";

  public final static String gkUnderpaymentContentPanel = "content-panel-detail underpayment-content-panel";

  public final static String gkPaymentContentPanel = "content-panel-detail payment-content-panel";

  public final static String gkUnderpaymentTabDetails = "underpayment-tab-details";

  public final static String gkUnderpaymentDetails = "underpayment-details";

  public final static String gkUnderpaymentType = "underpayment-type";

  public final static String gkUnderpaymentRefID = "underpayment-related-ic-case";

  public final static String gkUnderpaymentTable = "underpay-details-table";

  public final static String gkUnderpaymentTabPayment = "underpayment-tab-payment";

  public final static String gkPaymentIcon = "payment-icon";

  public final static String gkPaymentDetailsTable = "payment-details-table";

  public final static String gkPaymentTitle = "payment-title";

  /**
   * Overpayment constants. *
   */
  public final static String gkOverpaymentContentPanel = "content-panel-detail overpayment-content-panel";

  public final static String gkOverpaymentTabDetails = "overpayment-tab-details";

  public final static String gkOverpaymentDetails = "overpayment-details";

  public final static String gkOverpaymentType = "overpayment-type";

  public final static String gkOverPaymentRefID = "overpayment-related-ic-case";

  public final static String gkOverpaymentTable = "overpayment-details-table";

  public final static String gkOverpaymentTable2 = "overpayment-details-table2";

  public final static String gkOverpaymentChartPanel = "content-panel-detail overpayment-chart-panel";

  public final static String gkOverpaymentChartDetail = "overpayment-chart-detail";

  /**
   * Case Tab domain constants. *
   */
  public final static String gkDomainInvestigationType = "INVESTIGATION_CONFIG_TYPE";

  public final static String gkDomainCaseStatus = "CASE_STATUS_CODE";

  public final static String gkDomainAllegationType = "ALLEGATION_TYPE_CODE";

  public final static String gkDomainFinding = "FINDING_CODE";

  public final static String gkDomainRelationshipType = "RELATIONSHIP_TYPE_CODE";

  // END, CR00191703

  /**
   * Case Tab link page constants. *
   */
  public static final String gkCaseHomePage = "Case_resolveCaseHomePage.do";

  public static final String gkCaseOwnerHomePage = "Case_resolveOrgObjectTypeHomePage.do";

  public static final String gkCitizenContextViewerPage = "Participant_resolvePage.do";

  public static final String gkParticipantHomePage = "Participant_resolvePage.do";

  public static final String gkSpecialCautionListPage = "SpecialCaution_tabListPage.do";

  public static final String gkViewFinInstructionPage = "Financial_resolveInstructionView1Page.do";

  // BEGIN, CR00244988, VM
  public static final String gkViewUnderpaymentFinInstructionPage = "Financial_resolveUnderpaymentInstructionViewPage.do";
  public static final String gkFinInstructionID = "finInstructionID";
  // END, CR00244988

  /**
   * Preview panel page name constants. *
   */
  // BEGIN, CR00250584, RCB
  public static final String ProductDeliveryTabPreviewPage = "ProductDelivery_tabDetailsPreviewPage.do";
  public static final String IntegratedCaseTabPreviewPage = "IntegratedCase_tabDetailsPreviewPage.do";
  public static final String PaymentCorrectionPreviewPage = "PaymentCorrection_tabDetailsPreviewPage.do";
  public static final String LiabilitySamplePreviewPage = "LiabilitySample_tabDetailsPage.do";
  public static final String BenefitSampleOverpaymentPreviewPage = "BenefitSampleOverpayment_tabDetailsPreviewPage.do";
  public static final String ICBenefitUnderPaymentPreviewPage = "ICBenefitUnderPayment_tabDetailsPreviewPage.do";
  public static final String InvestigationPreviewPage = "Investigation_homeTabDetailsPreviewPage.do";

  /**
   * String constant for Legal Status Navigation Item.
   */
  public static final String kLegalStatus = "LegalStatus";

  /**
   * String constant for Services Navigation Item.
   */
  public static final String kServices = "Services";

  /**
   * String constant for Referrals Navigation Item.
   */
  public static final String kReferrals = "Referrals";

  /**
   * String constant for Participants Navigation Item.
   */
  public static final String kParticipants = "Participants";

  /**
   * String constant for Participants Folder Navigation Item.
   */
  public static final String kParticipantsFolder = "ParticipantsFolder";

  /**
   * String constant for Appeals Navigation Item.
   */
  public static final String kAppeals = "Appeals";

  /**
   * String constant for Legal Actions Folder Navigation Item.
   */
  public static final String kLegalActions = "LegalActions";

  // END,CR00247042,MJ
  // BEGIN, CR00191614, MC
  public static final String gkOverpaymentDeductionsListPage = "BenefitSampleOverpayment_listDeductionsPage.do";

  // END, CR00191614
  public static final String gkProductDeliveryDecisionViewPage = "ProductDelivery_viewDecisionPage.do";

  public static final String gkProductDeliveryDeductionListPage = "ICSportingGrantSample_listCurrentDeductionPage.do";

  public static final String gkInvestigationAllegationListPage = "InvestigationDelivery_listAllegation1Page.do";

  public static final String gkProductDeliveryIssuesListPage = "ICSportingGrantSample_listIssuePage.do";

  // BEGIN, CR00203321, ZV
  public static final String gkIntegratedCaseIssuesListPage = "ICSampleSportingGrant_listIssuePage.do";

  // END, CR00203321
  public static final String gkInvestigationHomePage = "Investigation_resolveHomePage.do";

  /**
   * Case Tab link page parameter constants. *
   */
  public static final String gkPageParameterCaseID = "caseID";

  public static final String gkPageParameterProductType = "productType";

  public static final String gkPageParameterICCaseType = "icType";

  public static final String gkPageParameterConcernRoleID = "concernRoleID";

  public static final String gkPageParameterUserName = "userName";

  public static final String gkPageParameterOrgObjectReference = "orgObjectReference";

  public static final String gkPageParameterOrgObjectType = "orgObjectType";

  public static final String gkPageParameterInstructionID = "instructionID";

  public static final String gkPageParameterInstructionType = "instructionType";

  public static final String gkPageParameterDecisionID = "decisionID";

  // END, CR00191022

  // END, CR00193568
  public static final String gkListRowOdd = "odd";

  public static final String gkListRowEven = "even";

  public static final String gkStackContainerTitlePhoto = "photo view";

  public static final String gkStackContainerTitleList = "list view";

  public static final String gkStyleStackContainerList = "stack-container-list";

  public static final String gkStyleStackContainerPhoto = "stack-container-photo";

  public static final String gkPanelCaseMemberList = "tab-case-list";

  public static final String gkStyleCaseMemberList = "thumbnail-picker";

  public static final String gkIDRotator = "Rotator_Demo";

  public static final String gkIDStackContainer = "stackContainer";

  public static final String gkIDStackContainerFiveImages = "stackCon-fiveimages";

  public static final String gkIDStackContainerFourImages = "stackCon-fourimages";

  // END, CR00193568

  // BEGIN, CR00194113, ZV
  /**
   * Incident Tab link page constants. *
   */
  public static final String gkUserDetailsPage = "Organization_viewUserDetailsPage.do";

  public static final String gkIncidentParticipantListPage = "IncidentParticipant_listIncidentParticipantPage.do";

  /**
   * Incident Tab link page parameter constants. *
   */
  public static final String gkPageParameterIncidentID = "incidentID";

  /**
   * Incident Tab domain constants. *
   */
  public final static String gkDomainIncidentSeverity = "INCIDENT_SEVERITY";

  public final static String gkDomainIncidentType = "INCIDENT_TYPE";

  public final static String gkDomainIncidentReportMethod = "INCIDENT_REPORT_METHOD";

  public static final String gkIncidentStatusDomain = "INCIDENT_STATUS";

  public static final String gkIncidentTabDetails = "incident-tab-details";

  public static final String gkIncidentDetails = "incident-details";

  public static final String gkIncidentType = "content-incident-type";

  public static final String gkIncidentDate = "incident-date";

  public static final String gkIncidentTime = "incident-time";

  public static final String gkIncidentParticipants = "incident-participants";

  public static final String gkLinkDetail = "link-detail";

  public static final String gkIncidentDetailsTable = "incident-details-table";

  public static final String gkStatusDate = "incident-opened-date";

  public static final String gkStatusBy = "incident-opened-by";

  public static final String gkReportedDetails = "reported-details";

  public static final String gkReportedBy = "reported-by";

  public static final String gkReportedByPerson = "reported-by-person";

  public static final String gkReportedByDate = "reported-by-date";

  public static final String gkReportedByAddress = "reported-by-address";

  public static final String gkReportedByClear = "reported-by-clear";

  public static final String gkReportedByPhone = "reported-by-phone";

  public static final String gkReportedPhone = "phonenumber";

  public static final String gkReportedByEmail = "reported-by-email";

  public static final String gkReportedByTable = "reported-by-table";

  public static final String gkReportedEmail = "email";

  public static final String gkIconScheduleBlue = "IconScheduleBlue";

  // END, CR00194113

  // Investigation tab constants
  public static final String gkTabThumnbnailTitle = "tab-thumbnail-with-title";

  public static final String gkNameOneTitle = "name-one-title";

  public static final String gkNameTwoTitle = "name-two-title";

  public static final String gkAge = "age";

  public static final String gkAgeDisplay = "age-display-only";

  public static final String gkRelationship = "relationship";

  public static final String gkRightTable = "right-table";

  public static final String gkInvestigationTabDetails = "investigation-tab-details";

  public static final String gkInvestigationDetails = "investigation-details";

  public static final String gkInvestigationReference = "investigation-reference";

  public static final String gkInvestigationStatusLabel = "status-label";

  public static final String gkInvestigationStatus = "status";

  public static final String gkInvestigationClear = "clear";

  public static final String gkInvestigationTypeLabel = "type-label";

  public static final String gkInvestigationType = "type";

  public static final String gkInvestigationDateLabel = "registered-date-label";

  public static final String gkInvestigationDate = "registered-date";

  public static final String gkContactContent = "contact-content";

  public static final String gkInvestigationDetailTable = "invest-details-table";

  public static final String gkContactContentDetail = "contact-content-detail";

  public static final String gkInitialContactTable = "inital-contact-table";

  public static final String gkLatestContactTable = "latest-contact-table";

  public static final String gkInvCaseOwnerPanel = "inv-case-owner-panel";

  public static final String gkInvCaseOwnerIcon = "inv-case-owner-icon";

  public static final String gkInvCaseOwner = "inv-case-owner";

  public static final String gkAgreeWithWatermark = "agree-with-watermark";

  public static final String gkResolutionWatermark = "resoluton-watermark";

  public static final String gkResolutionDateWatermark = "resoluton-date-watermark";

  /**
   * Participant map constants. *
   */
  public static final String gkMap = "map";

  public static final String gkGoogleMapXML = "GOOGLE_MAP_XML";

  public static final String gkGoogleMapLicense = "license";
  
  // BEGIN, CR00404602, DM
  public static final String gkGoogleMapAPIUrl = "apiURL";
  // END, CR00404602

  public static final String gkGoogleMapAPIKey = "apiKey";
  
  public static final String gkData = "data";

  public static final String gkMapAddress = "address";

  public static final String gkLatitude = "latitude";

  public static final String gkLongitude = "longitude";

  public static final String gkAddressMapPage = "Address_mapPage.do";

  public static final String gkTempAddress = "Lansdowne Road, Ballsbridge, Dublin 4, Ireland";

  /**
   * Tooltip constants. *
   */
  public static final String gkTooltipShadow = "tooltip-shadow";

  public static final String gkTooltipOuterPanel = "tooltip-outer-panel";

  public static final String gkTooltipTitle = "tooltip-title";

  public static final String gkTooltipTitleNoLink = "tooltip-title-nolink";

  public static final String gkTooltipInnerPanel = "tooltip-inner-panel";

  public static final String gkInvestigationContent = "investigation-content";

  public static final String gkInvestigationRef = "investigation-ref";

  public static final String gkIncidentContent = "incident-content";

  public static final String gkIncidentTooltipDate = "incident-date";

  public static final String gkIncidentText = "incident-text";

  public static final String gkIncidentTypeLink = "incident-type";

  public static final String gkSpecialCautionTypes = "spec-caution-types";

  public static final String gkPersonTooltipDetail = "person-tooltip-detail";

  public static final String gkTooltipAddress = "tooltip-address";

  public static final String gkTooltipPhone = "tooltip-phone";

  public static final String gkTooltipPhoneNum = "tooltip-phonenumber";

  public static final String gkTooltipEmail = "tooltip-email";

  public static final String gkTooltipEmailAddress = "tooltip-emailaddress";

  public static final String gkMoreLink = "more-link";

  public static final String gkTooltipForLinks = "tooltip-outer-panel links-tooltips";

  public static final String gkLinkContent = "link-content";

  public static final String gkSpecCautTooltip = "tooltip-shadow speccaution-tooltip-width";

  public static final String gkDetailsTooltip = "tooltip-shadow details-tooltip-width";

  public static final String gkInvestigationsTooltip = "tooltip-shadow investig-tooltip-width";

  public static final String gkIncidentsTooltip = "tooltip-shadow incident-tooltip-width";

  public static final String gkPersonTooltipOrientation = "{TR:'TL', TL:'TL', BL:'BL', BR:'BL'}";

  public static final String gkIncidentTooltipOrientation = "{TR:'BL', TR:'TL', TL:'BR', BR:'BL'}";

  public static final String gkInvestigationTooltipOrientation = "{TR:'BL', TR:'TL', TL:'BR', BR:'BL'}";

  public static final String gkFillerDiv = "filler-div";

  // BEGIN, CR00196256, POH
  /**
   * The constant for the radius of the earth in kilometers.
   */
  public static final int kRadiusOfEarthKilometers = 6371;

  /**
   * The constant for the radius of the earth in miles.
   */
  public static final int kRadiusOfEarthMiles = 3963;

  // END, CR00196256

  // BEGIN, CR00202673, ZV
  /**
   * The constant for query XML data version.
   */
  public static final String gkQueryVersion6 = "6.0";

  // END, CR00202673

  // BEGIN, CR00202817, PMD
  public static final String kCaseAuditSampleICWizardProperties = "CaseAuditSampleICWizard.properties";

  // END, CR00202817

  // BEGIN, CR00221010, PDN
  public static final String kPersonalizedPageWizardProperties = "PersonalizedPageWizard.properties";

  public static final String kPersonalizedPageEditWizardProperties = "PersonalizedPageEditWizard.properties";

  // END, CR00221010

  // BEGIN, CR00203956, GD
  public static final String kCaseAuditSamplePDWizardProperties = "CaseAuditSamplePDWizard.properties";

  public static final String kCaseAuditSampleLPDWizardProperties = "CaseAuditSampleLPDWizard.properties";

  public static final String kCaseAuditSampleInvestigationCaseWizardProperties = "CaseAuditSampleInvestigationCaseWizard.properties";

  // END, CR00203956

  // BEGIN, CR00211081, MC
  // Returns the name of the properties file for the Integrated Case Product
  // Delivery creation wizard.
  public final static String kCreateICProductDeliveryWizardProperties = "CreateICProductDeliveryWizard.properties";

  // END, CR00211081
  // Return the name of the properties file for the issue delivery wizard.
  public final static String kCreateIssueDeliveryForPDWizardProperties = "CreateIssueDeliveryForPDWizard.properties";
  // BEGIN, CR00211901, MC
  // Return the name of the properties file for the issue delivery wizard.
  public final static String kCreateIssueDeliveryWizardProperties = "CreateIssueDeliveryWizard.properties";

  // Return the name of the properties file for the capture manual payment
  // wizard.
  public final static String kCaptureManualPaymentWizardProperties = "CaptureManualPaymentWizard.properties";

  // Return the name of the properties file for the Applied Fixed Deduction
  // wizard.
  public final static String kAppliedFixedDeductionWizardProperties = "AppliedFixedDeductionWizard.properties";

  // Return the name of the properties file for the Applied Variable Deduction
  // wizard.
  public final static String kAppliedVariableDeductionWizardProperties = "AppliedVariableDeductionWizard.properties";

  // END, CR00211901

  // BEGIN, CR00218063, MC
  // Return the name of the properties file for the client participation
  // wizards.
  public final static String kCreateWeeklyClientParticipationWizardProperties = "CreateWeeklyClientParticipationWizard.properties";

  // END, CR00218063

  // BEGIN, CR00369134, KRK
  /**
   * String constant to reference the Reissue Applied Deduction Wizard.
   */
  public final static String kReissueAppliedDeductionWizardProperties = "ReissueAppliedDeductionWizard.properties";

  /**
   * String constant to reference the Reissue Un-applied Deduction Wizard.
   */
  public final static String kReissueUnappliedDeductionWizardProperties = "ReissueUnappliedDeductionWizard.properties";
  // END, CR00369134

  // BEGIN, CR00203745, PMD
  public static final String kSystematicSamplingStartIndex = "x";

  public static final String kSystematicSamplingInterval = "n";

  // END, CR00203745
  /**
   * Financial resolver constant. *
   */
  public static final String gkNewInstance = "newInstance";

  // BEGIN, CR00199929, SS
  public static final String gkCALocale = "en_CA";

  public static final String gkCanadianREWithSpace = "([A-Za-z]\\d[A-Za-z] \\d[A-Za-z]\\d)$";

  public static final String gkCanadianRE = "([A-Za-z]\\d[A-Za-z]\\d[A-Za-z]\\d)$";

  public static final String gkCanadianREWithQM = "([A-Za-z]\\d[A-Za-z] ?\\d[A-Za-z]\\d)$";
  // END, CR00199929

  // BEGIN, CR00345882, SPD
  public static final String gkZH_TWLocale = "zh_TW";
  public static final String gkZH_CNLocale = "zh_CN";
  public static final String gkJALocale = "ja";
  public static final String gkKOLocale = "ko";

  // Five digit postal format
  public static final String gkFiveDigitPostalFormat = "^([0-9]{5})$";

  // six digit postal format
  public static final String gkSixDigitPostalFormat = "^([0-9]{6})$";

  // Six digit postal format which includes a dash, XXX-XXX
  public static final String gkSixDigitDashPostalFormat = "^([0-9]{3})(-)([0-9]{3})$";

  // Seven digit postal format which includes a dash, XXX-XXXX
  public static final String gkSevenDigitDashPostalFormat = "^([0-9]{3})(-)([0-9]{4})$";
  // END, CR00345882

  // BEGIN, CR00203103, CR00224704, CSH, CW
  /**
   * Constants for the Reassessment Results BIRT Chart.
   */
  public static final String gkReassessmentResultChart = "AllComponentsGraphicalBenefitStatement";

  public static final String gkReassessmentResultChartForComponent = "SingleComponentGraphicalBenefitStatement";

  public static final String gkParam_RP_noupID = "noupID";

  public static final String gkParam_RP_rulesObjectiveID = "rulesObjectiveID";

  // END, CR00203103, CR00224704

  // BEGIN, CR00223475, ELG
  // BEGIN, CR00211704, GD
  public static final String gkParam_CA_auditPlanID = "RP_auditPlanID";

  public static final String gkParam_CA_caseAuditSize = "RP_caseAuditSize";

  // END, CR00211704
  public static final String gkAuditPlanFocusAreaReportName = "AuditPlanFocusAreaReport";

  // END, CR00223475

  // BEGIN, CR00205401, GYH
  /**
   * Sentinel constant to indicate the wild card value.
   */
  public static final long gkSentinelValue = -1;

  // END, CR00205401

  // BEGIN, CR00204212, ZV
  /**
   * Constants for the Overpayment Case Financials BIRT Chart.
   */

  // BEGIN, CR00223475, ELG
  public static final String gkBIRTOverpaymentCaseFinancialReport = "OverpaymentCaseFinancialReport";

  // END, CR00223475

  // BEGIN, CR00224704, CW
  /**
   * Constant for the Overpayment Payment Correction Case Financials BIRT
   * Chart.
   */
  public static final String gkBIRTPaymentCorrectionOPFinancialReport = "PaymentCorrectionOverpaymentFinancialReport";

  // END, CR00224704

  // BEGIN, CR00231628, CL
  /**
   * Constants for the BIRT Chart parameters.
   */
  public static final String gkParam_ConcernRoleID = "concernRoleID";

  // END, CR00231628

  // BEGIN, CR00224704, CW
  public static final String gkParam_CaseID = "&caseID";

  // END, CR00224704

  /**
   * Constant for the Employer workforce BIRT Chart.
   */
  // BEGIN, CR00223475, ELG
  public static final String gkBIRTEmployerWorkforceReport = "EmployerWorkforceReport";

  public static final String gkBIRTProspectEmployerWorkforceReport = "ProspectEmployerWorkforceReport";

  // END, CR00223475

  // END, CR00204212

  // BEGIN, CR00209773, ZV
  /**
   * Constants for the Participant tab details pages.
   */
  public static final String gkPersonTabDetailsPage = "Person_homeTabDetailsPreviewPage.do";

  public static final String gkProspectPersonTabDetailsPage = "ProspectPerson_homeTabDetailsPreviewPage.do";

  public static final String gkEmployerTabDetailsPage = "Employer_homeDetailsPreviewPage.do";

  public static final String gkProspectEmployerTabDetailsPage = "ProspectEmployer_homeTabDetailsPreviewPage.do";

  public static final String gkProductProviderTabDetailsPage = "ProductProvider_tabDetailsPage.do";

  public static final String gkServiceSupplierTabDetailsPage = "ServiceSupplier_homeTabDetailsPage.do";

  public static final String gkUtilityTabDetailsPage = "Utility_homeTabDetailsPage.do";

  public static final String gkInformationProviderTabDetailsPage = "InformationProvider_homeTabDetailsPage.do";

  public static final String gkEducationInstituteTabDetailsPage = "EducationalInstitute_homeTabDetailsPage.do";

  public static final String gkExternalPartyTabDetailsPage = "ExternalParty_homeTabDetailsPage.do";

  // BEGIN, CR00223370, ZV
  /**
   * Constants for the Participant client pages
   */
  public static final String gkProductProviderPage = "ProductProvider_homePage.do";

  public static final String gkServiceSupplierPage = "ServiceSupplier_homePagePage.do";

  public static final String gkUtilityPage = "Utility_homePage.do";

  public static final String gkInformationProviderPage = "InformationProvider_homePage.do";

  public static final String gkEducationInstitutePage = "EducationalInstitute_homePage.do";

  public static final String gkExternalPartyPage = "ExternalParty_homePage.do";

  // END, CR00223370

  /**
   * Constants for the Case tab details pages.
   */
  // BEGIN, CR00250584, RCB
  public static final String gkIntegratedCaseTabDetailsPage = "IntegratedCase_tabDetailsPage.do";

  public static final String gkProductDeliveryTabDetailsPage = "ProductDelivery_tabDetailsPage.do";
  // END, CR00250584

  public static final String gkInvestigationTabDetailsPage = "Investigation_homeTabDetailsPreviewPage.do";

  public static final String gkOverpaymentCaseTabDetailsPage = "BenefitSampleOverpayment_tabDetailsPage.do";

  public static final String gkUnderpaymantCaseTabDetailsPage = "ICBenefitUnderPayment_tabDetailsPage.do";

  /**
   * Constant for the Incident tab details page.
   */
  public static final String gkIncidentTabDetailsPage = "Incident_viewIncidentTabDetailPreviewPage.do";

  public static final String gkViewIncidentDetailsPage = "Incident_viewIncident1Page.do";

  /**
   * Constants for the SQL operations.
   */
  public static final String gkSqlUnionOperator = "UNION";

  public static final String gkSqlUnionAllOperator = "UNION ALL";

  public static final String gkSqlOROperator = "OR";

  // END, CR00209773

  // BEGIN, CR00203667, AMD
  /**
   * The user filter XML element for deadline available task search criteria.
   */
  public static final String DEADLINE_DUE_USER_FILTER = "DeadlineDue";

  /**
   * The user filter XML element for priority available task search criteria.
   */
  public static final String PRIORITY_LIST_USER_FILTER = "PriorityList";

  /**
   * The user filter XML element for organization object available task search
   * criteria.
   */
  public static final String ORG_OBJECT_LIST_USER_FILTER = "OrgObjectList";

  // END, CR00203667, AMD

  // BEGIN, CR00207224, PB
  
  /**
   * Constants for sharing evidences through the 'EvidenceBrokerDP' deferred process
   */
  public static final String gkEvidenceShare = "EVIDENCE_SHARE";
    
  // BEGIN, CR00397427, RPB
  public static final String gkEvidenceShareBulk = "EVIDENCE_SHARE_BULK";
  // END, CR00397427
  
  // BEGIN, CR00427655, RPB
  /**
   * Constants for the deferred process to roll back the status of evidences.
   */
  public static final String gkEvidenceBrokerRollBack = "EVIDENCE_BROKER_ROLLBACK";

  // END, CR00427655

  public static final String gkExternalEvidenceShare = "EXT_EVIDENCE_SHARE";

  public static final String gkEvidenceRemoval = "EVIDENCE_REMOVAL";

  public static final String gkExternalEvidenceRemoval = "EXT_EVIDENCE_REMOVAL";

  public static final String gkEvidenceForCaseParticipant = "SHARE_EVIDENCE_CP";

  /**
   * Constants for sharing evidences through the 'EvidenceBrokerWithAutoAcceptOnlyDP' deferred process
   */  
  public static final String gkEvidenceShareAutoAcceptOnly = "EVIDENCE_SHARE_AUTO_ACCEPT_ONLY";
  
  // BEGIN, CR00397427, RPB
  public static final String gkEvidenceShareBulkAutoAcceptOnly = "EVIDENCE_SHARE_BULK_AUTO_ACCEPT_ONLY";
  // END, CR00397427

  public static final String gkEvidenceShareAutoAcceptOnlyExternal = "EVIDENCE_SHARE_AUTO_ACCEPT_ONLY_SHARE_EXTERNAL";

  public static final String gkEvidenceShareAutoAcceptOnlyRemoval = "EVIDENCE_SHARE_AUTO_ACCEPT_ONLY_SHARE_REMOVAL";

  public static final String gkEvidenceShareAutoAcceptOnlyExtRemoval = "EVIDENCE_SHARE_AUTO_ACCEPT_ONLY_SHARE_EXT_REMOVAL";

  public static final String gkEvidenceShareAutoAcceptOnlyCaseParticipant = "EVIDENCE_SHARE_AUTO_ACCEPT_ONLY_SHARE_CSE_PARTCPNT";
  
  /**
   * Constants for sharing evidences through the 'EvidenceBrokerOnlyDP' deferred process
   */  
  public static final String gkEvidenceShareBrokerOnly = "EVIDENCE_SHARE_BROKER_ONLY";
  
  // BEGIN, CR00397427, RPB
  public static final String gkEvidenceShareBulkBrokerOnly = "EVIDENCE_SHARE_BULK_BROKER_ONLY";
  // END, CR00397427

  public static final String gkEvidenceShareBrokerOnlyExternal = "EVIDENCE_SHARE_BROKER_ONLY_EXTERNAL";

  public static final String gkEvidenceShareBrokerOnlyRemoval = "EVIDENCE_SHARE_BROKER_ONLY_REMOVAL";

  public static final String gkEvidenceShareBrokerOnlyExtRemoval = "EVIDENCE_SHARE_BROKER_ONLY_EXT_REMOVAL";

  public static final String gkEvidenceShareBrokerOnlyCaseParticipant = "EVIDENCE_SHARE_BROKER_ONLY_EVD_CASE_PARTCPNT";

  /**
   * Logger for the web service output.
   */
  public static final String gkWebServiceCategory = ".WebService";
  // END, CR00207224

  // BEGIN, CR00210762, PMD
  /**
   * Case Audit Tab domain constants. *
   */
  public final static String gkDomainCaseAuditStatus = "CASE_AUDIT_STATUS";

  // BEGIN, CR00251308, PMD
  public final static String gkDomainAuditItem = "CATEGORY_TYPE_NAME";
  // END, CR00251308

  public final static String gkDomainAuditPlanUserAccess = "AUDIT_PLAN_USER_ACCESS";

  /**
   * Case Audit Tab link page constants. *
   */
  public static final String gkAuditorDetailsPage = "CaseAudit_resolveAuditorHomePage.do";

  public final static String gkListAuditorsPage = "CaseAudit_listAssigneesPage.do";

  // BEGIN, CR00251197, CW
  public static final String gkListEvent = "listEvent";

  public static final String gkListMeetingMinutes = "listMeetingMinutes";

  public static final String gkListMeetingsForCase = "ListMeetingsForCase";

  public static final String gkListMeetingMinutesForCase = "ListMeetingMinutesForCase";

  public static final String gkIncomeAssistanceBenefitSample = "IncomeAssistanceBenefitSample";

  public static final String gkCase = "Case";
  // END, CR00251197

  public final static String gkListFocusAreasPage = "CaseAudit_listAuditPlanFocusAreasPage.do";

  /**
   * Case Audit Tab link page parameter constants. *
   */
  public static final String gkPageParameterAuditorID = "auditorID";

  public static final String gkPageParameterAuditPlanID = "auditPlanID";

  // BEGIN, CR00225043, GD
  public static final String gkReportParameterAuditPlanID = "auditPlanID";

  public static final String gkReportParameterCaseAuditID = "caseAuditID";

  public static final String gkReportParameterCaseAuditStatusTableName = "statusTableName";

  public static final String gkReportParameterFocusAreaSatisfiedTableName = "focusAreaSatisfiedTableName";

  // END, CR00225043

  /**
   * Renderer constants for case audit tab panels. *
   */
  public static final String gkCaseAuditContainerPanel = "caseaudit-container-panel";

  public static final String gkCaseAuditContentPanel = "content-panel-detail caseaudit-content-panel";

  public final static String gkCaseAuditTabDetails = "caseaudit-tab-details";

  public final static String gkCaseAuditDetails = "caseaudit-details";

  public final static String gkCaseAuditRef = "caseaudit-reference";

  public final static String gkCaseAuditPlanRef = "caseauditplan-reference";

  public final static String gkCaseAuditRefID = "caseaudit-reference-id";

  public final static String gkCaseAuditLink = "audit-case-link";

  public final static String gkCaseAuditDetailsTable = "caseaudit-details-table";

  public final static String gkCaseAuditDetailsTable2 = "caseaudit-details-table2";

  public final static String gkCaseAuditExtraDetailContent = "caseaudit-extradetails-content";

  public final static String gkCaseAuditExtraDetailContentDetail = "caseaudit-extradetails-content-detail";

  public final static String gkCaseAuditCaseOwnerTable = "caseaudit-caseowner-table";

  public final static String gkCaseAuditOwnerImage = "audit-owner-image";

  public final static String gkCaseAuditTimeLimitTable = "caseaudit-timelimit-table";

  public final static String gkScheduleDetail = "schedule-detail";

  public final static String gkCaseAuditReportContent = "content-panel-detail caseaudit-report-content-panel";

  public static final String gkCaseAuditReportDetails = "caseaudit-report-details";

  public static final String gkCaseAuditNoReport = "no-chart-text";

  public static final String gkCaseAuditFocusAreasContent = "caseaudit-focusareas-content";

  public static final String gkCaseAuditFocusAreasContentDetail = "caseaudit-focusareas-content-detail";

  public static final String gkCaseAuditFocusAreasTable = "caseaudit-focusareas-table";

  public static final String gkCaseAuditFocusAreasTitle = "focus-area-title";

  public static final String gkCaseAuditChartContentPanel = "caseaudit-chart-content-panel";

  /**
   * Case Audit content panel image constants. *
   */
  public static final String gkIconAtTimeLimitBlue = "IconAtTimeLimitBlue";

  public static final String gkIconGoodTimeBlue = "IconGoodTimeBlue";

  public static final String gkIconAttention = "IconAttention";

  // BEGIN, CR00223475, ELG
  /**
   * Case Audit reporting constants. *
   */
  public static final String gkAuditPlanProgressChart = "AuditPlanProgressBarChart";

  public static final String gkCaseAuditFocusAreasChart = "CaseAuditFocusAreas";

  /**
   * Investigation Summary report. *
   */
  public static final String gkInvestigationsSummaryReportName = "InvestigationsSummary";

  // END, CR00223475
  // END, CR00210762

  // BEGIN, CR00208641, SS
  // BEGIN, CR00187598, SS
  // BEGIN, CR00216640, GSP
  /**
   * 'Pending Owner Assignment' details constants.
   */
  public static final long kPendingOwnerWorkQueueID = 2003;

  public static final String kPendingOwnerWorkqueueName = "PENDING OWNER ASSIGNMENT";

  /**
   * 'Temporary Owner Assignment' details constants.
   */
  public static final long kTemporaryOwnerWorkQueueID = 2001;

  public static final String kTemporaryOwnerWorkqueueName = "TEMPORARY OWNER ASSIGNMENT";

  /**
   * 'Sample Owner Assignment' details constants.
   */
  public static final long kSampleOwnerWorkQueueID = 2002;

  public static final String kSampleOwnerWorkqueueName = "SAMPLE OWNER ASSIGNMENT";

  // END, CR00216640
  // END, CR00187598
  // END, CR00208641

  // BEGIN, CR00210198, PMD
  // Returns the name of the properties file for the Case Audit Fixed Query
  // wizard.
  public final static String kCaseAuditFixedQueryWizardProperties = "CaseAuditFixedQueryWizard.properties";

  // END, CR00210198

  // BEGIN, CR00208706, NRK
  /**
   * String constant with reference to the Investigation Contact log wizard
   * menu properties.
   *
   */
  // BEGIN, CR00225856, NRK
  public static final String kCreateContactLogWizard = "CreateCaseContactLogWizard.properties";

  /**
   * String constant with reference to the Investigation Contact log wizard
   * menu properties.
   *
   */
  public static final String kModifyContactLogWizard = "ModifyCaseContactLogWizard.properties";

  // END, CR00225856, NRK
  /**
   * String constant referring the data-store name.
   */
  public static final String kDataStoreName = "ContactLogWizard";

  /**
   * String constant for Store action.
   */
  public static final String kStoreAction = "Store";

  /**
   * String constant for Cancel action.
   */
  public static final String kCancelAction = "Cancel";

  /**
   * String constant for Next action.
   */
  public static final String kNextAction = "Next";

  /**
   * String constant for Back action.
   */
  public static final String kBackAction = "Back";

  /**
   * String constant for Save & Exit action.
   */
  public static final String kSaveAndExitAction = "Save & Exit";

  /**
   * String constant for Save action.
   */
  public static final String kSaveAction = "Save";

  /**
   * String constant for Save action.
   */
  public static final String kSearchAction = "Search";

  /**
   * String constant for Next page action. The word Next cannot be used as an
   * action id.
   */
  public static final String kNextPageAction = "NextPage";

  /**
   * String constant for reset search page action.
   */
  public static final String kResetAction = "ResetPage";

  /**
   * String constant for the CaseID attribute.
   */
  public static final String kCaseIDAttribute = "CaseID";

  /**
   * String constant for the LinkID attribute.
   */
  public static final String kLinkIDAttribute = "LinkID";

  /**
   * String constant for the Concerning Participant attribute.
   */
  public static final String kConcerningParticipantsAttribute = "ConcerningParticipants";

  /**
   * String constant for the Purpose attribute.
   */
  public static final String kPurposeAttribute = "Purpose";

  /**
   * String constant for the Location attribute.
   */
  public static final String kLocationAttribute = "Location";

  /**
   * String constant for the Start Date label.
   */
  public static final String kStartDateLabel = "Start Date";

  /**
   * String constant for the Location Description attribute.
   */
  public static final String kLocationDescriptionAttribute = "LocationDescription";

  /**
   * String constant for the Start date attribute.
   */
  public static final String kStartDateAttribute = "StartDate";

  /**
   * String constant for the Type attribute.
   */
  public static final String kTypeAttribute = "Type";

  /**
   * String constant for the End date attribute.
   */
  public static final String kEndDateAttribute = "EndDate";

  /**
   * String constant for the Method attribute.
   */
  public static final String kMethodAttribute = "Method";

  /**
   * String constant for the Author attribute.
   */
  public static final String kAuthorAttribute = "Author";

  /**
   * String constant for the Narrative text attribute.
   */
  public static final String kNarrativeAttribute = "Narrative";

  /**
   * String constant for the Case participant attribute.
   */
  public static final String kCaseParticipantsAttribute = "CaseParticipants";

  /**
   * String constant for the Registered participant type attribute.
   */
  public static final String kRegisteredParticipantTypeAttribute = "RegisteredParticipantType";

  /**
   * String constant for the Registered participant attribute.
   */
  public static final String kRegisteredParticipantAttribute = "RegisteredParticipant";

  /**
   * String constant for the Participant name attribute.
   */
  public static final String kParticipantNameAttribute = "ParticipantName";

  /**
   * String constant for the User name attribute.
   */
  public static final String kUserNameAttribute = "UserName";

  /**
   * String constant for the File name attribute.
   */
  public static final String kFileNameAttribute = "FileName";

  /**
   * String constant for the File Content attribute.
   */
  public static final String kFileContentsAttribute = "FileContents";

  /**
   * String constant for the File location attribute.
   */
  public static final String kFileLocationAttribute = "FileLocation";

  /**
   * String constant for the File reference attribute.
   */
  public static final String kFileReferenceAttribute = "FileReference";

  /**
   * String constant for the File type attribute.
   */
  public static final String kFileTypeAttribute = "FileType";

  /**
   * String constant for the File description attribute.
   */
  public static final String kFileDescriptionAttribute = "FileDescription";

  // END, CR00208706, NRK

  // BEGIN, CR00213907, PB
  /**
   * String constant for the Translator Required attribute.
   */
  public static final boolean gkTranslatorRequired = true;

  // END, CR00213907

  // BEGIN, CR00213944, GP
  /**
   * String constant for the background style.
   */
  public static final String gkBackground = "background";

  // END, CR00213944

  // BEGIN, CR00217577, AMD
  /**
   * The task redirection tab ID.
   */
  public static final String kTaskRedirectionNavigationTabID = "TaskRedirection";

  /**
   * The task allocation blocking tab ID.
   */
  public static final String kTaskAllocationBlockingNavigationTabID = "TaskAllocationBlocking";

  /**
   * The SID for clearing a task redirection.
   */
  public static final String kClearTaskRedirectionSID = "UserTaskRedirection.clearTaskRedirectionForUser";

  /**
   * The SID for creating a task redirection.
   */
  public static final String kCreateTaskRedirectionSID = "UserTaskRedirection.redirectTasksForUser";

  /**
   * The SID for viewing a task redirection.
   */
  public static final String kViewTaskRedirectionSID = "UserTaskRedirection.listTaskRedirectionHistoryForUser";

  /**
   * The SID for clearing a task allocation blocking.
   */
  public static final String kClearAllocationBlockingSID = "UserTaskAllocationBlocking.clearTaskAllocationBlockForUser";

  /**
   * The SID for creating a task allocation blocking.
   */
  public static final String kCreateAllocationBlockingSID = "UserTaskAllocationBlocking.blockTaskAllocationForUser";

  /**
   * The SID for viewing a task allocation blocking.
   */
  public static final String kViewAllocationBlockingSID = "UserTaskAllocationBlocking.listTaskAllocationBlockingHistoryForUser";

  // END, CR00217577

  // BEGIN, CR00319899, KRK
  /**
   * The SID for viewing a special cautions.
   */
  public static final String kViewSpecialCautionSID = "SpecialCaution.listSpecialCautions";
  // END, CR00319899

  // BEGIN, CR00218133, ZV
  /**
   * Constants for the Person homepages.
   */
  public static final String gkPersonHomePage = "Person_homePagePage.do";

  // BEGIN, CR00354096, BD
  public static final String gkPersonResolveHomePage = "Person_resolveHomePagePage.do";
  // END, CR00354096

  public static final String gkProspectPersonHomePage = "ProspectPerson_homePagePage.do";

  // END, CR00218133

  // BEGIN, CR00361188, BD
  public static final String gkProspectPersonResolveHomePage = "ProspectPerson_resolveHomePagePage.do";
  // END, CR00361188

  // BEGIN, CR00346860, BD

  public static final String gkPersonHomePDCPage = "Person_homePagePDCPage.do";

  public static final String gkProspectPersonHomePDCPage = "ProspectPerson_homePagePDCPage.do";

  // END, CR00346860

  // BEGIN, CR00218664, ZV
  /**
   * Constants for the Employer homepages.
   */
  public static final String gkEmployerHomePage = "Employer_homePage.do";

  public static final String gkProspectEmployerHomePage = "ProspectEmployer_homePage.do";

  // END, CR00218664

  // BEGIN, CR00222063, POH
  /**
   * String Constant for the name of the collaboration tab identifier.
   */
  public static final String gkCollaborationFolder = "CollaborationFolder";

  // END, CR00222063

  // BEGIN, CR00217857, PMD
  // Returns the name of the properties file for the Case Audit External
  // Service
  // wizard.
  public final static String kCaseAuditExternalServiceWizardProperties = "CaseAuditExternalServiceWizard.properties";

  // END, CR00217857

  // BEGIN, CR00214400, GSP
  public static final String gkAnd = " and ";

  // END, , CR00214400

  // BEGIN, CR00217067, GP
  /**
   * Constant representing the value of organization units for an organization
   * structure page.
   */
  public static final String gkOrgUnitsForOrgStructurePage = "Organization_listOrgUnitsForOrgStructurePage.do?organisationStructureID=";

  /**
   * Constant representing the value of organization positions for an
   * organization structure page.
   */
  public static final String gkOrgStructurePositionsPage = "Organization_listOrgStructurePositionsPage.do?organisationStructureID=";

  /**
   * Constant representing the value of organization users for an organization
   * structure page.
   */
  public static final String gkOrgStructureUsersPage = "Organization_listOrgStructureUsersPage.do?organisationStructureID=";

  /**
   * Constant representing the value of organization locations for an
   * organization structure page.
   */
  public static final String gkOrgStructureLocantionsPage = "Organization_listLocationPage.do?locationStructureID=";

  /**
   * Constant representing the organization summary element of pod xml.
   */
  public static final String kOrganizationSummary = "organizationsummary";

  /**
   * Constant representing the organization details style of pod xml.
   */
  public static final String kOrganizationDetails = "organization-details";

  /**
   * Constant representing the organization units element of pod xml.
   */
  public static final String kOrganizationUnits = "organizationunits";

  /**
   * Constant representing the organization positions element of pod xml.
   */
  public static final String kOrganizationPositions = "organizationpositions";

  /**
   * Constant representing the organization users element of pod xml.
   */
  public static final String kOrganizationUsers = "organizationusers";

  /**
   * Constant representing the organization locations element of pod xml.
   */
  public static final String kOrganizationLocations = "organizationlocantions";

  /**
   * Constant representing the text resource required by pod.
   */
  public static final String gkTextResource = "textresource";

  // END, CR00217067

  // BEGIN CR00221505, ZV
  // BEGIN CR00231644, ZV
  public static final String gkWildcardSearch = "*";

  public static final String gkSingleWildcardSearch = "?";

  // END CR00231644
  // END CR00221505

  // BEGIN CR00222438, MC
  /**
   * Constants representing the delete pages for the communications formats.
   */

  /**
   * Used to tell the URI_SOURCE_NAME renderer to store the return page (rpu)
   * for the link that uses this constant.
   */
  public static final String gkStoreCuramReturnPage = "curam:";

  /**
   * Participant delete draft email communication.
   */
  // BEGIN CR00289903, ZV
  public final static String kdeleteDraftEmailPageIdentifier = "Participant_deleteDraftEmailCommunication1Page.do";
  // END CR00289903

  /**
   * Participant delete Microsoft Word communication.
   */
  public final static String kdeleteMSWordPageIdentifier = "Participant_deleteMSWordCommunicationPage.do";

  /**
   * Participant delete pro forma communication.
   */
  public final static String kdeleteProFormaPageIdentifier = "Participant_deleteProFormaCommunicationPage.do";

  /**
   * Participant delete recorded communication.
   */
  public final static String kdeleteRecordedCommunicationPageIdentifier = "Participant_deleteCommunicationWithAttach1Page.do";

  // END CR00222438

  // BEGIN, CR00225521, GSP
  /**
   * Constant for SVR_INT64 domain definition.
   */
  public static final String kDomainSVR_INT64 = "SVR_INT64";

  /**
   * Constant for CASE_REFERENCE domain definition.
   */
  public static final String kDomainCASE_REFERENCE = "CASE_REFERENCE";

  public static final String kCaseReferenceNumber = "Case Reference Number";

  // END, CR00225521

  // BEGIN, CR00226335, NRK
  /**
   * String constant with reference to the CEF Incidents Contact log wizard
   * menu properties.
   *
   */
  public static final String kCreateIncidentContactLogWizard = "CreateIncidentContactLogWizard.properties";

  /**
   * String constant with reference to the CEF Incidents Contact log wizard
   * menu properties.
   *
   */
  public static final String kModifyIncidentContactLogWizard = "ModifyIncidentContactLogWizard.properties";

  // END, CR00226335,NRK

  // BEGIN, CR00230062, CSH
  /**
   * String constant used by currency symbol formatting on the server.
   *
   */
  public static final String gkBefore = "before";

  /**
   * String constant used by currency symbol formatting on the server.
   *
   */
  public static final String gkAfter = "after";

  // END, CR00230062
  // BEGIN, CR00226335, MC
  /**
   * String constant to reference the Register Person Wizard.
   */
  public static final String kRegisterPersonWizardProperties = "RegisterPersonWizard.properties";

  // BEGIN, CR00356064, BD
  /**
   * String constant to reference the Register Person for Participant Data
   * Case Wizard.
   */
  public static final String kRegisterPersonForPDCWizardProperties = "RegisterPersonForPDCWizard.properties";

  /**
   * String constant to reference the Register Person Wizard Start Page.
   */
  public static final String kRegisterPersonWizardStartPage = "RegisterPerson_duplicateCheckWizard";

  /**
   * String constant to reference the Register Person for Participant Data
   * Case Wizard Start Page.
   */
  public static final String kRegisterPersonForPDCWizardStartPage = "RegisterPerson_duplicateCheckForPDCWizard";

  /**
   * String constant to reference the Add Prospect Person Wizard.
   */
  public static final String kAddProspectPersonWizardProperties = "AddProspectPersonWizard.properties";

  /**
   * String constant to reference the Add Prospect Person for Participant Data
   * Case Wizard.
   */
  public static final String kAddProspectPersonForPDCWizardProperties = "AddProspectPersonForPDCWizard.properties";

  /**
   * String constant to reference the Add Prospect Person Wizard Start Page.
   */
  public static final String kAddProspectPersonWizardStartPage = "AddProspectPerson_duplicateCheckWizard";

  /**
   * String constant to reference the Add Prospect Person for Participant Data
   * Case Wizard Start Page.
   */
  public static final String kAddProspectPersonForPDCWizardStartPage = "AddProspectPerson_duplicateCheckForPDCWizard";

  /**
   * String constant to reference the Register Prospect as a Person for
   * Participant Data Case Wizard properties.
   */
  public static final String kRegisterProspectAsPersonForPDCWizard = "RegisterProspectAsPersonForPDCWizard.properties";

  // END, CR00356064
  /**
   * String constant to reference the Register Prospect as a Person Wizard
   * properties.
   */
  public static final String kRegisterProspectAsPersonWizard = "RegisterProspectAsPersonWizard.properties";

  /**
   * String constant to reference the Register Prospect as a Employer Wizard
   * properties.
   */
  public static final String kRegisterProspectAsEmployerWizard = "RegisterProspectAsEmployerWizard.properties";

  /**
   * String constant to reference the Register Employer Wizard.
   */
  public static final String kRegisterEmployerWizardProperties = "RegisterEmployerWizard.properties";

  /**
   * String constant to reference the Register Employer Wizard Start Page.
   */
  public static final String kRegisterEmployerWizardStartPage = "RegisterEmployer_duplicateCheckWizard";

  /**
   * String constant to reference the Add Prospect Employer Wizard.
   */
  public static final String kAddProspectEmployerWizardProperties = "AddProspectEmployerWizard.properties";

  /**
   * String constant to reference the Add Prospect Employer Wizard Start Page.
   */
  public static final String kAddProspectEmployerWizardStartPage = "AddProspectEmployer_duplicateCheckWizard";

  /**
   * String constant to reference the Register Utility Wizard.
   */
  public static final String kRegisterUtilityWizardProperties = "RegisterUtilityWizard.properties";

  /**
   * String constant to reference the Register Utility Wizard Start Page.
   */
  public static final String kRegisterUtilityWizardStartPage = "RegisterUtility_duplicateCheckWizard";

  /**
   * String constant to reference the Register Product Provider Wizard.
   */
  public static final String kRegisterProductProviderWizardProperties = "RegisterProductProviderWizard.properties";

  /**
   * String constant to reference the Register Product Provider Wizard Start
   * Page.
   */
  public static final String kRegisterProductProviderWizardStartPage = "RegisterProductProvider_duplicateCheckWizard";

  /**
   * String constant to reference the Register Service Supplier Wizard.
   */
  public static final String kRegisterServiceSupplierWizardProperties = "RegisterServiceSupplierWizard.properties";

  /**
   * String constant to reference the Register Service Supplier Wizard Start
   * Page.
   */
  public static final String kRegisterServiceSupplierWizardStartPage = "RegisterServiceSupplier_duplicateCheckWizard";

  /**
   * String constant to reference the Register Educational Institute Wizard.
   */
  public static final String kRegisterEducationalInstituteWizardProperties = "RegisterEducationalInstituteWizard.properties";

  /**
   * String constant to reference the Register Educational Institute Wizard
   * Start Page.
   */
  public static final String kRegisterEducationalInstituteWizardStartPage = "RegisterEducationalInstitute_duplicateCheckWizard";

  /**
   * String constant to reference the Register External Party Wizard.
   */
  public static final String kRegisterExternalPartyWizardProperties = "RegisterExternalPartyWizard.properties";

  /**
   * String constant to reference the Register External Party Wizard Start
   * Page.
   */
  public static final String kRegisterExternalPartyWizardStartPage = "RegisterExternalParty_duplicateCheckWizard";

  /**
   * String constant to reference the Register Information Provider Wizard.
   */
  public static final String kRegisterInformationProviderWizardProperties = "RegisterInformationProviderWizard.properties";

  /**
   * String constant to reference the Register Information Provider Wizard
   * Start Page.
   */
  public static final String kRegisterInformationProviderWizardStartPage = "RegisterInformationProvider_duplicateCheckWizard";

  // BEGIN, CR00238677
  /**
   * The constant for the manual task workflow in relation to where the
   * supervisor must approve or reject a submitted record utilizing the
   * {@link ApprovalRequest} functionality.
   */
  public static final String kAPPROVALREQUESTAPPROVEREJECTTASK = "APPROVALREQUESTAPPROVEREJECTTASK";

  // END, CR00238677

  // END, CR00226335
  // BEGIN, CR00227793, NS
  public static final int gkMinusOne = -1;

  // END, CR00227793

  // BEGIN, CR00227750,MJ
  /**
   * String constant for Tilde.
   */
  public static final String kTilde = "~";
  // END, CR00227750,MJ

  // BEGIN, CR00242751, VM
  public static final String kAssistanceBenefitSample = "PT2501";
  public static final String kAssistanceICSample = "PC2500";
  // END, CR00242751

  // BEGIN, CR00243200, ZV
  /**
   * Contact log domain constants. *
   */
  public final static String gkDomainContactLogType = "CONTACT_LOG_TYPE";

  public final static String gkDomainContactLogLocation = "CONTACT_LOG_LOCATION";

  public final static String gkDomainContactLogMethod = "CONTACT_LOG_METHOD";

  public final static String gkDomainNoteText = "NOTE_TEXT";
  // END, CR00243200

  // BEGIN, CR00243405, JS
  /**
   * The evidence flow <code>String</code>.
   */
  public static final String kEvidenceFlow = "evidenceflow";

  /**
   * The evidence flow for .NAV attributes
   */
  public static final String kEvidenceFlowNav = "EvidenceFlow";
  
  /**
   * The case id lower case attribute.
   */
  public static final String kCaseIDLowerCaseAttribute = "caseid";

  // END, CR00243405

  // BEGIN, CR00244295, PMD
  public static final String kEllipsis = "\u2026";
  // END, CR00244295

  // BEGIN, CR00245352, ZV
  public static final String gkSqlWildCardComparisonOperator = "like";
  // END, CR00245352

  // BEGIN, CR00247429, GYH
  /**
   * String constant to reference the curam.ldap.online.user.export.enabled
   * property.
   */
  public static final String LDAP_ONLINE_USER_EXPORT_ENABLED = "curam.ldap.online.user.export.enabled";

  /**
   * String constant to reference the LDAP context factory.
   */
  public static final String LDAP_CONTEXT_FACTORY = "com.sun.jndi.ldap.LdapCtxFactory";

  /**
   * String constant for phone extension symbol.
   */
  public static final String gkPhoneExtensionSymbol = " x ";

  /**
   * Constants for LDAP user details.
   */
  public static final String EMAIL_ADDRESS = "mail";

  public static final String FAX_NUMBER = "fax";

  public static final String MOBILE_PHONE_NUMBER = "mobile";

  public static final String TELEPHONE_NUMBER = "telephoneNumber";

  public static final String DISPLAY_NAME = "displayName";

  public static final String TITLE = "title";

  public static final String GIVEN_NAME = "givenName";

  public static final String SHA_ENCRYPTION_HEADER = "{SHA}";

  public static final String USER_PASSWORD = "userPassword";

  public static final String USER_NAME = "uid";

  public static final String SURNAME = "sn";

  public static final String COMMON_NAME = "cn";

  public static final String DISTINGUISHED_NAME = "dn";

  public static final String OBJECT_CLASS_INET_ORG_PERSON = "inetOrgPerson";

  public static final String OBJECT_CLASS_ORGANIZATIONAL_PERSON = "organizationalPerson";

  public static final String OBJECT_CLASS_PERSON = "person";

  public static final String OBJECT_CLASS_TOP = "top";

  public static final String OBJECT_CLASS = "objectClass";

  // END, CR00247429

  // BEGIN, CR00266519, ELG
  /**
   * The name of the description attribute on the entity class.
   */
  public static final String gkDescriptionAttributeName = "description";
  // END, CR00266519

  // Task Context Panel Style Sheet Constants
  public static final String gkTaskContainerPanel = "task-container-panel";
  public static final String gkTaskContextHeader = "task-context-header";
  public static final String gkTaskContextTableCellLabel = "task-context-table-cell-label";
  public static final String gkTaskContextTableCellValue = "task-context-table-cell-value";
  public static final String gkTaskContextSubjectDetails = "task-context-subject-details";
  public static final String gkTaskContextSubjectLabel = "task-context-subject-label";
  public static final String gkTaskContentPanel = "task-content-panel";
  public static final String gkTaskContextPanelDetails = "task-context-panel-details";
  public static final String gkTaskContextPanelTable = "task-context-table";
  public static final String gkTaskContextTableLink = "task-context-table-link";
  public static final String gkTimeOverIcon = "TimeOverIcon";
  public static final String gkScheduleIcon = "ScheduleIcon";
  public static final String gkImageFile = "curam.util.properties.global.Image";

  // BEGIN, CR00252599, VM
  public static final String kSampleSportingGrantRegistrarClass = "curam.sample.sl.fact.SampleSportingGrantEvidenceRegistrarFactory";
  // END, CR00252599

  // BEGIN, CR00257963, ZV
  public static final String gkBackslash = "\\";
  // END, CR00257963

  // BEGIN,CR00261491,MJ
  /**
   * DefaultIC Product Delivery Properties.
   */
  public final static String kCreateDefaultICProductDeliveryWizardProperties = "DefaultICProduct.properties";

  /**
   * The maximum length for auto generated code table codes.
   */
  public static final int kMaxProductPrefixLength = 3;

  /**
   * The maximum length of a code table code.
   */
  public static final int kCodetableCodeLength = 10;

  /**
   * Defines the maximum number of attempts to generate e unique code table
   * code.
   */
  public static final int kMaxCodegenerationAttempts = 100;

  /**
   * Key Set Name for Product Name.
   */
  public static final String KEY_SET_DYNAMICPRODUCT_NAME = "DPNAME";

  /**
   * Key Set Name for Product Type.
   */
  public static final String KEY_SET_DYNAMICPRODUCT_TYPE = "DPTYPE";

  /**
   * String constant for data store name.
   */
  public static String kProductWizardDataStore = "ProductWizard";

  /**
   * String constant for entity name.
   */
  public static String kProductEntity = "Product";

  /**
   * String constant for Product Provision entity name.
   */
  public static String kProductProviderEntity = "ProductProvision";

  /**
   * String constant for Provision Location entity name.
   */
  public static String kProvisionLocationEntity = "ProvisionLocation";

  /**
   * String constant for Product DeliveryPattern entity name.
   */
  public static String kDeliveryPatternEntity = "ProductDeliveryPattern";

  /**
   * String constant for Product DeliveryPatternIfno entity name.
   */
  public static String kDeliveryPatternInfoEntity = "ProductDeliveryPatternInfo";

  /**
   * String constant for ProductCategory entity.
   */
  public static String kProductCategoryEntity = "ProductCategory";

  /**
   * String constant for Benefit Product wizard menu.
   */
  public static String kBenefitWizardMenuProperties = "BenefitProduct.properties";

  /**
   * String constant for CREOLEProduct entity name.
   */
  public static String kCreoleProductEntity = "CREOLEProduct";

  /**
   * String constant for Liability Product wizard menu.
   */
  public static String kLiabilityWizardMenuProperties = "LiabilityProduct.properties";

  /**
   * String constant for Dynamic Product CaseHomePage.
   */
  public static String kProductCaseHomePage = "DefaultICProduct_home";

  /**
   * String constant for Cancel ActionID.
   */
  public static String CANCEL_ACTION = "cancel";

  /**
   * String constant for Next ActionID.
   */
  public static String NEXT_ACTION = "next";

  /**
   * String constant for Back ActionID.
   */
  public static String BACK_ACTION = "back";

  /**
   * String constant for Finish ActionID.
   */
  public static String FINISH_ACTION = "finish";

  /**
   * String constant for the Weekly Frequency.
   */
  public static String kWeekly = "Weekly";

  /**
   * String constant for the Daily Frequency.
   */
  public static String kDaily = "Daily";

  /**
   * String constant for the BiMonthly Frequency.
   */
  public static String kBiMonthly = "BiMonthly";

  /**
   * String constant for the Monthly Frequency.
   */
  public static String kMonthly = "Monthly";

  /**
   * String constant for the Yearly Frequency.
   */
  public static String kYearly = "Yearly";

  /**
   * Default Delivery Method value for Benefit.
   */
  public static long kEFT = 1;

  /**
   * Default Delivery Method value for Liability.
   */
  public static long kInvoice = 4;

  /**
   * Start Date Attribute Name.
   */
  public static String startDateAttribute = "startDate";

  /**
   * End Date Attribute Name.
   *
   */
  public static String endDateAttribute = "endDate";

  /**
   * Category Code Attribute Name.
   */
  public static String categoryAttribute = "categoryCode";

  /**
   * Attribute Name of ProductID.
   */
  public static String productIDAttribute = "productID";

  /**
   * Suffix for Product Type.
   */
  public static String kProductTypeSuffix = "DPT";

  /**
   * Default Maximum Deduction Rate.
   */
  public static double kMaxDeductRate = 100.00;

  /**
   * Default Minimum Deduction Amount.
   */
  public static double kMinDeductionAmount = 5.00;

  /**
   * Employer Home Page Name.
   */
  public static String integratedCaseEmployerHomePage = "DefaultICEmployer_resolveCaseParticipantHome";

  /**
   * Integrated Case Home Page Name.
   */
  public static String integratedCaseHomePage = "DefaultIC_home";

  /**
   * Provider Home Page Name.
   */
  public static String integratedCaseInformationProviderHomePage = "DefaultICInformationProvider_resolveCaseParticipantHome";

  /**
   * Member Home Page Name.
   */
  public static String integratedCaseMemberHomePage = "DefaultICMember_resolveCaseParticipantHome";

  /**
   * Person Home Page Name.
   */
  public static String integratedCasePersonHomePage = "DefaultICPerson_resolveCaseParticipantHome";

  /**
   * PPHome Page Name.
   */
  public static String integratedCaseProspectPersonHomePage = "DefaultICProspectPerson_resolveCaseParticipantHome";

  /**
   * Product Provider Home Page Name.
   */
  public static String integratedCaseProductProviderHomePage = "DefaultICProductProvider_resolveCaseParticipantHome";

  /**
   * Representative Home Page Name.
   */
  public static String integratedCaseRepresentativeHomePage = "DefaultICRepresentative_resolveCaseParticipantHome";

  /**
   * Service Supplier Home Page Name.
   */
  public static String integratedCaseServiceSupplierHomePage = "DefaultICServiceSupplier_resolveCaseParticipantHome";

  /**
   * Utility Home Page Name.
   */
  public static String integratedCaseUtilityHomePage = "DefaultICUtility_resolveCaseParticipantHome";

  /**
   * The maximum length for auto generated integrated case type code table
   * codes.
   */
  public static final int kMaxIntegratedCaseTypeCodePrefixLength = 3;

  /**
   * Integrated Case Tab Preview.
   */
  public static final String integratedCasePreviewPage = "DefaultIC_tabDetailsPreviewPage.do";

  /**
   * Product Delivery Preview Page.
   */
  public static final String productDeliveryPreviewPage = "DefaultICProduct_tabDetailsPreviewPage.do";

  /**
   * Key Set Name for Integrated Case Type Name.
   */
  public static final String KEY_SET_DYNAMICPRODUCT_IC = "ICTNAME";
  // END,CR00261491,MJ

  // BEGIN, CR00266809, ZV
  public static final int gkMaxApplicationSearchTextLength = 40;
  // END, CR00266809

  // BEGIN, CR00291914, GYH
  /**
   * A constant identifier for EvidenceTypeDefinitionCache.
   */
  public static final String kEvidenceTypeDefinitionCacheIdentifier = new String(
    "EvidenceTypeDefinitionCache");
  // END, CR00291914

  // BEGIN, CR00303990, PB
  public static final String gkDoubleQuote = "\"";
  // END, CR00303990

  // BEGIN, CR00336353, KH
  /**
   * A constant used when creating case decisions to indicate the the tag
   * information is too large to store on the case decision itself and must
   * instead be taken from the case decision objective tags directly.
   */
  public static final String gkNotAvailable = "NOT_AVAILABLE";
  // END, CR00336353

  // BEGIN, CR00335807, SSK
  /**
   * A constant to represent 2 columns.
   */
  public static final int gkNumberOfColumns_2 = 2;

  /**
   * A constant to represent chart type.
   */
  // BEGIN, CR00339370, ZV
  /**
   * @deprecated Since 6.0.5.0, replaced by
   * {@link curam.core.sl.pods.impl.PodsConst#kAuditPlanSummaryChartTypeLabel}
   * . Hard coded value replaced by localisable property.
   */
  @Deprecated
  public static final String gkChartType = "Chart Type";
  // END, CR00339370
  // END, CR00335807

  // BEGIN, CR00353792, ZV
  // Constants PDC page names for client merge agenda
  public static final String gkParticipant_mergeAddressEvidencePage = "Participant_mergeAddressEvidence";
  public static final String gkParticipant_mergeAlternateIDEvidencePage = "Participant_mergeAlternateIDEvidence";
  public static final String gkParticipant_mergeAlternateNameEvidencePage = "Participant_mergeAlternateNameEvidence";
  public static final String gkParticipant_mergeBankAccountEvidencePage = "Participant_mergeBankAccountEvidence";
  public static final String gkParticipant_mergeEmailAddressEvidencePage = "Participant_mergeEmailAddressEvidence";
  public static final String gkParticipant_mergePhoneNumberEvidencePage = "Participant_mergePhoneNumberEvidence";
  // BEGIN, CR00355808, ZV
  public static final String gkParticipant_mergeRelationshipEvidencePage = "Participant_mergeRelationshipEvidence";
  // END, CR00355808
  // END, CR00353792

  // BEGIN, CR00365714, ZV
  /**
   * Default case homepage name
   */
  public static final String gkCaseNoHomePage = "Case_resolveCaseNoHome";
  // END, CR00365714 
  
  // BEGIN, CR00399253, IBM
  public static final String CONTACT_LOG_CACHE_NAME = "INTERNAL_CURAM_CASE_DATA_CACHE";

  public static final String CONTACT_LOG_CASE_ID = "CASE_ID";

  public static final String CONTACT_LOG_CASE_PARTICIPANT_ROLE_ID_TAB_LIST = "CASE_PARTICIPANT_ROLE_ID_TAB_LIST";

  public static final String CONTACT_LOG_CASE_PARTICIPANT_ROLE_ID = "CASE_PARTICIPANT_ROLE_ID";
  // END, CR00399253
  
  // BEGIN, CR00380472, MV
  // Nine digit postal format which includes a dash, XXXXX-XXXX
  public static final String gkUSValidZIP = "^\\d{5}(-\\d{4})?$";
  
  // BEGIN, CR00400273, MV
  /**
   * Constants to represent configuration validation error message to check and skip the error. 0 indicated the error message used for issue delivery approve resolution. 
   */
  public static final String gkERR_USER_NOT_SUPERVISOR_0 = "bpoproductdeliveryapproval.err_user_fv_not_supervisor|a|0";

  /**
   * Constants to represent configuration validation error message to check and skip the error. 1 indicated the error message used for issue delivery reject resolution. 
   */
  public static final String gkERR_USER_NOT_SUPERVISOR_1 = "bpoproductdeliveryapproval.err_user_fv_not_supervisor|a|1";

  /**
   * Constants to represent configuration validation error message to check and skip the error. 2 indicated the error message used for approving Product delivery case. 
   */
  public static final String gkERR_USER_NOT_SUPERVISOR_2 = "bpoproductdeliveryapproval.err_user_fv_not_supervisor|a|2";

  /**
   * Constants to represent configuration validation error message to check and skip the error. 3 indicated the error message used for rejecting Product delivery case. 
   */
  public static final String gkERR_USER_NOT_SUPERVISOR_3 = "bpoproductdeliveryapproval.err_user_fv_not_supervisor|a|3";

  /**
   * Constants to represent configuration validation error message to check and skip the error. 4 indicated the error message used for rejecting Product delivery case. 
   */
  public static final String gkERR_USER_NOT_SUPERVISOR_4 = "bpoproductdeliveryapproval.err_user_fv_not_supervisor|a|4";

  /**
   * Constants to represent configuration validation error message to check and skip the error. 5 indicated the error message used for approving investigation delivery case. 
   */
  public static final String gkERR_USER_NOT_SUPERVISOR_5 = "bpoproductdeliveryapproval.err_user_fv_not_supervisor|a|5";

  /**
   * Constants to represent configuration validation error message to check and skip the error. 6 indicated the error message used for rejecting investigation delivery case. 
   */
  public static final String gkERR_USER_NOT_SUPERVISOR_6 = "bpoproductdeliveryapproval.err_user_fv_not_supervisor|a|6";

  /**
   * Constants to represent configuration validation error message to check and skip the error. 7 indicated the error message used for rejecting investigation delivery case. 
   */
  public static final String gkERR_USER_NOT_SUPERVISOR_7 = "bpoproductdeliveryapproval.err_user_fv_not_supervisor|a|7";
  // END, CR00400273
  
  // BEGIN, CR00406851, MV
  /**
   * Constants to represent configuration validation error message to check and skip the error. 
   */
  public static final String gkERR_USER_NOT_AUTHORIZED = "bpoassessmentdelivery.err_assesment_case_approve_reject_not_authorized|a|";
  // END
  // END, CR00380472

  // BEGIN, CR00398084, SSK
  /**
   * Represents the name for evidence broker workflow process names for In-Edit evidence sharing.
   */
  public static final String kIdenticalInEditSharingEvidenceUpdate = new String(
    "IdenticalInEditSharingEvidenceUpdate");

  /**
   * Represents the name for evidence broker workflow process names for case participant creation.
   */
  public static final String kCaseParticipantCreationEvidenceInEditSharing = new String(
    "CaseParticipantCreationEvidenceInEditSharing");

  // END, CR00398084
  
  // BEGIN, CR00398181, MV
  // Constant for string Maintain
  public static final String gkMaintain = "Maintain";
  // END, CR00398181

  // BEGIN, CR00409298, SS
  public static final String gkAuthorTextPath = "//notes/note/author";
  public static final String gkTimeZoneTextPath = "//notes/note/timeZone";
  // END, CR00409298
  // BEGIN, CR00415760, AC
  public static final String gkdateTimeZoneTextPath = "//notes/note/date";
  // END, CR00415760
  // BEGIN, CR00408306, MV
  /**
   * Constants to represent the notes text - Created as a result of. 
   */
  public static final String gk_NOTE_CREATED_ASARESULTOF = "Created as a result of";
  
  /**
   * Constants to represent the notes text - Modified as a result of. 
   */
  public static final String gk_NOTE_MODIFIED_ASARESULTOF = "Modified as a result of";
  // END, CR00408306
  // BEGIN, CR00414184, GK
  public static final String gkAND = " AND ";

  public static final String gkOR = " OR ";
  // END, CR00414184
  
  // BEGIN, CR00414292, GK
  /**
   * Represents Identical evidence data. 
   */
  public static final String kIdenticalEvidenceData = "IdenticalEvidenceData";
  
  /**
   * Represents Identical evidence details in transaction cache. 
   */
  public static final String kIdenticalEvidenceDetailsTransactionCache = "IdenticalEvidenceDetailsTransactionCache";
  
  /**
   * Represents existing shared instance ID. 
   */
  public static final String kExistingSharedInstanceID = "ExistingSharedInstanceID";
  
  /**
   * Represents new shared instance ID. 
   */
  public static final String kNewSharedInstanceID = "NewSharedInstanceID";
  
  /**
   * Represents shared evidence type. 
   */
  public static final String kSharedEvidenceType = "SharedEvidenceType";
  // END, CR00414292
  // BEGIN, CR00409381, MV
  // Constant for string - /.
  public static final String gkSlashString = "/";
  // Constant for string - M.
  public static final String gkStringMonth = "M";
  // Constant for string - y.
  public static final String gkStringYear = "y";
  // Constant for string - /.
  public static final String gkStringDate = "d";
  // END, CR00409381

  // BEGIN, CR00415560, RB
  // Substring to support for different date formats.
  public static final String gkSimpleTimeFormat = " HH:mm:ss";

  // Substring to support for different date formats.
  public static final String gkSpaceForDateFormat = "\\s";

  // Substring to support for different date formats.
  public static final String gkPatternSearchRight = ")(.*)";

  // Substring to support for different date formats.
  public static final String gkPatternSearchLeft = "(.*)(";
  // END, CR00415560
  // BEGIN, CR00417650, RD
  public static final String kMergeInProgress = "MergeInProgress";
  // END, CR00417650
  // BEGIN, CR00417671, GK
  public static final String gkSystemLineSeparatorKey = "line.separator";
  // END, CR00417671
  
  public static final String gkDeferredProcessErrorsBar = "DeferredProcessErrorsBar";
  
  public static final String gkWorkFlowProcessInstanceErrorsBar = "WorkFlowProcessInstanceErrorsBar";
  
  public static final String gkWorkFlowLocale = "p_Locale";
  
  public static final String gkWorkFlowStartDate = "p_StartDate";
  
  public static final String gkWorkFlowEndDate = "p_EndDate";
  
  public static final String gkDeferredStartDate = "fromDate";
  
  public static final String gkDeferredEndDate = "toDate";
  
  // BEGIN, CR00434151, ZV
  public static final String kDomainADDRESS_DATA = "ADDRESS_DATA";
  // END, CR00434151
  public static final String gkConstLRE = "\u202A";
  public static final String gkConstRLE = "\u202B"; 
  public static final String gkConstAR = "ar";
  
} 

