/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2007, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.LOCATIONACCESSTYPE;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.InfoProviderSearchDtls;
import curam.core.struct.InfoProviderSearchKey;
import curam.core.struct.InfoProviderSearchResult;
import curam.message.BPOINFORMATIONPROVIDERSEARCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * @deprecated Since Curam 6.0, This class is replaced by
 * {@link curam.core.sl.impl.ParticipantSearch}
 *
 * Information Provider search interface for the Curam Application
 */
@Deprecated
public abstract class InformationProviderSearch extends curam.core.base.InformationProviderSearch {

  /**
   * @param infoProviderSearchKey data on which the searched will be based
   *
   * @return The details of any records found
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.sl.impl.ParticipantSearch#search(ParticipantSearchKey)}
   *
   * Method to perform an information provider search
   */
  @Deprecated
  public InfoProviderSearchResult search(InfoProviderSearchKey infoProviderSearchKey)
    throws AppException, InformationalException {

    curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
      new AppException(
        BPOINFORMATIONPROVIDERSEARCH.ERR_INFORMATIONPROVIDERSEARCH_UNIMPLEMENTED),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
        0);
    // Should not reach this point without throwing a validation 
    return null;

  }

  /**
   * @param infoProviderSearchDtls data on which the search will be based
   *
   * @deprecated Since Curam 6.0, replaced by
   * {@link curam.core.sl.impl.ParticipantSearch#restrictResults(ParticipantSearchDtls)}
   *
   * Method to perform an information provider search
   */
  @Deprecated
  public void restrictResults(InfoProviderSearchDtls infoProviderSearchDtls)
    throws AppException, InformationalException {

    // concern role variables
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // set search key for concern role
    concernRoleKey.concernRoleID = infoProviderSearchDtls.concernRoleID;

    // do concern role search
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // BEGIN, CR00226619, PM
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    // perform concern role sensitivity check
    participantSecurityCheckKey.participantID = concernRoleKey.concernRoleID;

    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
      participantSecurityCheckKey);

    if (dataBasedSecurityResult.restricted) {
      // Return no details to client if User does not have access
      infoProviderSearchDtls.name = infoProviderSearchDtls.address = infoProviderSearchDtls.city = CuramConst.gkRestricted;
      infoProviderSearchDtls.restricted = true;
      return;
    }

    // If the location data security is on then access denied
    if (!dataBasedSecurityResult.result) {
      infoProviderSearchDtls.referenceNumber = null;
    }
    // END, CR00226619
  }

}
