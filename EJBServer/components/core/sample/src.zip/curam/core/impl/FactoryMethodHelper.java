/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;

import java.lang.reflect.Method;

import curam.core.sl.infrastructure.impl.ReflectionConst;
import curam.message.FACTORYMETHODCREATION;
import curam.util.exception.AppException;

/**
 * Helper class to construct the 'newInstance' method object from the
 * registrar's factory class object.
 * 
 */
public class FactoryMethodHelper {

  /**
   * Returns the 'newInstance' method object for a given registrar factory
   * class.
   * 
   * @param registrarFactoryClass
   *          Contains registrar factory class instance of type Class.
   * 
   * @return The 'newInstance' method object of a registrar factory class being
   *         passed.
   * 
   *         <p>
   *         It throws the exception when there is an issue to construct the
   *         'newInstance' method object on the factory class being passed.
   *         <ul>
   *         <li>
   *         {@link FACTORYMETHODCREATION#ERR_FACTORY_METHOD_CREATION_ISSUE}-If
   *         system fails to construct the 'newInstance' method object on the
   *         factory class being passed.</li>
   *         </ul>
   *         </p>
   */
  public static Method getNewInstanceMethod(final Class registrarFactoryClass) {
    Method newInstance = null;

    try {
      newInstance = registrarFactoryClass.getMethod(
          ReflectionConst.kNewInstance, new Class[0]);
    } catch (SecurityException se) {
      throw new RuntimeException(new AppException(
          FACTORYMETHODCREATION.ERR_FACTORY_METHOD_CREATION_ISSUE).arg(
          registrarFactoryClass.getName()).initCause(se));
    } catch (NoSuchMethodException nme) {
      throw new RuntimeException(new AppException(
          FACTORYMETHODCREATION.ERR_FACTORY_METHOD_CREATION_ISSUE).arg(
          registrarFactoryClass.getName()).initCause(nme));
    }
    return newInstance;
  };
}
