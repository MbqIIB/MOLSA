/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2013.
 *
 * The source code for this program is not published or otherwise divested 
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.ArrayList;
import java.util.HashMap;

import curam.codetable.CASEEVIDENCE;
import curam.codetable.CASEPARTICIPANTROLETYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.CONCERNROLETYPE;
import curam.codetable.DUPLICATESTATUS;
import curam.codetable.ENTITYATTRIBUTENAMES;
import curam.codetable.INCIDENTPARTICIPANTROLE;
import curam.codetable.INCIDENTSTATUS;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.EmployerFactory;
import curam.core.fact.InformationProviderFactory;
import curam.core.fact.PersonFactory;
import curam.core.fact.ProductProviderFactory;
import curam.core.fact.ServiceSupplierFactory;
import curam.core.fact.UtilityFactory;
import curam.core.sl.entity.fact.ExternalPartyFactory;
import curam.core.sl.entity.fact.RepresentativeFactory;
import curam.core.sl.entity.struct.ExternalPartyDtls;
import curam.core.sl.entity.struct.ExternalPartyKey;
import curam.core.sl.entity.struct.RepresentativeDtls;
import curam.core.sl.entity.struct.RepresentativeKey;
import curam.core.sl.infrastructure.entity.struct.AttributedDateDetails;
import curam.core.sl.infrastructure.impl.ParticipantEvidenceInterface;
import curam.core.sl.infrastructure.struct.EIEvidenceKey;
import curam.core.sl.infrastructure.struct.EIEvidenceKeyList;
import curam.core.sl.infrastructure.struct.EIFieldsForListDisplayDtls;
import curam.core.sl.infrastructure.struct.ValidateMode;
import curam.core.sl.struct.ConcernRoleIDKey;
import curam.core.struct.CaseKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleIDStatusCodeKey;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.ConcernRoleNameAndVersion;
import curam.core.struct.ConcernRoleSnapshotDtls;
import curam.core.struct.ConcernRoleSnapshotKey;
import curam.core.struct.ConcernRoleTypeDetails;
import curam.core.struct.DateStruct;
import curam.core.struct.EmployerDtls;
import curam.core.struct.EmployerKey;
import curam.core.struct.InformationProviderDtls;
import curam.core.struct.InformationProviderKey;
import curam.core.struct.PersonDtls;
import curam.core.struct.PersonKey;
import curam.core.struct.PersonTabDtlsKey;
import curam.core.struct.ProductProviderDtls;
import curam.core.struct.ProductProviderKey;
import curam.core.struct.ProspectPersonTabDtlsKey;
import curam.core.struct.RepresentativeConcernRoleKey;
import curam.core.struct.RepresentativeSummaryDetails;
import curam.core.struct.ServiceSupplierDtls;
import curam.core.struct.ServiceSupplierKey;
import curam.core.struct.UtilityDtls;
import curam.core.struct.UtilityKey;
import curam.events.CONCERNROLE;
import curam.message.BPOMAINTAINCONCERNROLEDETAILS;
import curam.message.PARTICIPANTDATACASE;
import curam.message.SUMMARYDETAILS;
import curam.pdc.fact.PDCUtilFactory;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.exception.RecordNotFoundException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;


/**
 * Concern Role Definition: Concern Role dictates the nature of the social
 * security agency's interaction with the concern.
 *
 */
public abstract class ConcernRole extends curam.core.base.ConcernRole implements
  ParticipantEvidenceInterface {

  // BEGIN, CR00059195, POH

  // ___________________________________________________________________________
  /**
   * Set the key values to read a Person on
   *
   * @param key
   * Person Key
   */
  @Override
  protected void prereadPerson(PersonTabDtlsKey key) throws AppException,
      InformationalException {

    key.duplicateStatusCode = DUPLICATESTATUS.MARKED;
    key.recordStatusCode = RECORDSTATUS.NORMAL;
    key.incidentParticipantRole = INCIDENTPARTICIPANTROLE.AGAINST;
    key.incidentStatusCode = INCIDENTSTATUS.OPEN;
    key.issueCaseTypeCode = CASETYPECODE.ISSUE;
    key.primaryClientTypeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    key.investigationCaseTypeCode = CASETYPECODE.INVESTIGATIONCASE;
    key.closedCaseStatus = CASESTATUS.CLOSED;
    key.cancelledCaseStatus = CASESTATUS.CANCELED;

  }

  // ___________________________________________________________________________
  /**
   * Set the key values to read a Prospect Person on
   *
   * @param key
   * Prospect Person Key
   */
  @Override
  protected void prereadProspectPerson(ProspectPersonTabDtlsKey key)
    throws AppException, InformationalException {

    key.duplicateStatusCode = DUPLICATESTATUS.MARKED;
    key.recordStatusCode = RECORDSTATUS.NORMAL;
    key.primaryClientTypeCode = CASEPARTICIPANTROLETYPE.PRIMARY;
    key.investigationCaseTypeCode = CASETYPECODE.INVESTIGATIONCASE;
    key.closedCaseStatus = CASESTATUS.CLOSED;
    key.cancelledCaseStatus = CASESTATUS.CANCELED;

  }

  protected static ThreadLocal<ConcernRoleCache> cachedReadTL = new ThreadLocal<ConcernRoleCache>();

  // ___________________________________________________________________________
  /**
   * Clear cached data in cachedReadTL
   */
  protected void clearCaches() {
    ConcernRoleCache cache = cachedReadTL.get();

    if (cache != null) {
      cache.map.clear();
    } else {
      cache = new ConcernRoleCache();
      cachedReadTL.set(cache);
    }
    cache.transactionID = TransactionInfo.getIdentifierForThisThread();

  }

  // ___________________________________________________________________________
  /**
   * Caching Details for Improved Performance
   */
  protected class ConcernRoleCache {
    public ConcernRoleCache() {
      map = new HashMap<Long, ConcernRoleDtls>();
      transactionID = 0;
    }

    HashMap<Long, ConcernRoleDtls> map;

    int transactionID;
  }

  // ___________________________________________________________________________
  /**
   * Calculate the attribution dates for the case
   *
   * @param caseKey
   * Contains the case identifier
   * @param evKey
   * Contains the evidenceID and evidenceType
   *
   * @return The attribution dates for the entity
   */
  public AttributedDateDetails calcAttributionDatesForCase(CaseKey caseKey,
    EIEvidenceKey evKey) throws AppException, InformationalException {

    // return struct
    AttributedDateDetails attributedDateDetails = new AttributedDateDetails();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    ConcernRoleDtls concernRoleDtls = read(evKey);

    // END, CR00240667

    // populate return struct
    attributedDateDetails.fromDate = concernRoleDtls.startDate;
    attributedDateDetails.toDate = concernRoleDtls.endDate;

    return attributedDateDetails;
  }

  // ___________________________________________________________________________
  /**
   * Gets evidence details for the list display
   *
   * @param key
   * Evidence key containing the evidenceID and evidenceType
   *
   * @return Evidence details to be displayed on the list page
   */
  public EIFieldsForListDisplayDtls getDetailsForListDisplay(EIEvidenceKey key)
    throws AppException, InformationalException {

    // return struct
    EIFieldsForListDisplayDtls eiFieldsForListDisplayDtls = new EIFieldsForListDisplayDtls();

    // BEGIN, CR00240667, CD
    // call out to read method (extracted for re-use)
    ConcernRoleDtls concernRoleDtls = read(key);

    // END, CR00240667

    // set start and end dates
    eiFieldsForListDisplayDtls.startDate = concernRoleDtls.startDate;
    eiFieldsForListDisplayDtls.endDate = concernRoleDtls.startDate;

    // Set the summary details.
    // BEGIN, CR00241068, CD
    LocalisableString message = new LocalisableString(
      SUMMARYDETAILS.CLIENT_DETAILS);

    message.arg(
      CodeTable.getOneItem(CONCERNROLETYPE.TABLENAME,
      concernRoleDtls.concernRoleType));
    message.arg(concernRoleDtls.registrationDate);
    eiFieldsForListDisplayDtls.summary = message.getMessage(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00241068
    
    return eiFieldsForListDisplayDtls;

  }

  /**
   * Reads the entity details given the evidence record identifier.
   *
   * @param key The evidence record identifier.
   *
   * @return The entity details.
   *
   * @throws InformationalException
   * @throws AppException
   */
  protected ConcernRoleDtls read(EIEvidenceKey key) throws AppException,
      InformationalException {
    // manipulation variables
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // populate the concernRoleKey with passed in parameter
    concernRoleKey.concernRoleID = key.evidenceID;

    // BEGIN, CR00060494, JPG
    try {
      // read concernRole details
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot concernRole entity
      ConcernRoleSnapshotKey concernRoleSnapshotKey = new ConcernRoleSnapshotKey();
      ConcernRoleSnapshotDtls concernRoleSnapshotDtls = new ConcernRoleSnapshotDtls();
      curam.core.intf.ConcernRoleSnapshot concernRoleSnapshotObj = curam.core.fact.ConcernRoleSnapshotFactory.newInstance();

      // populate the concernRole snapshot key with passed in parameter
      concernRoleSnapshotKey.concernRoleSnapshotID = key.evidenceID;

      // read concernRole snapshot details
      concernRoleSnapshotDtls = concernRoleSnapshotObj.read(
        concernRoleSnapshotKey);
      concernRoleDtls.assign(concernRoleSnapshotDtls);
    }
    // END, CR00060494
    return concernRoleDtls;
  }

  // ___________________________________________________________________________
  /**
   * Inserts ConcernRole evidence
   *
   * @param parentKey
   * Key containing
   *
   * @return Key containing the evidenceID and evidenceType
   */
  public EIEvidenceKey insertEvidence(Object dtls, EIEvidenceKey parentKey)
    throws AppException, InformationalException {

    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ConcernRoleDtls) dtls);

    eiEvidenceKey.evidenceID = ((ConcernRoleDtls) dtls).concernRoleID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLE;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Inserts ConcernRole evidence on modification
   * @param origKey
   *
   * @param parentKey
   * Key containing
   *
   * @return Key containing the evidenceID and evidenceType
   */
  public EIEvidenceKey insertEvidenceOnModify(Object dtls,
    EIEvidenceKey origKey, EIEvidenceKey parentKey) throws AppException,
      InformationalException {

    // Return object
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    insert((ConcernRoleDtls) dtls);

    eiEvidenceKey.evidenceID = ((ConcernRoleDtls) dtls).concernRoleID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLE;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Modify ConcernRole evidence
   *
   * @param key
   * Evidence key containing evidenceID and evidenceType
   * @param dtls
   * ConcernRole entity details
   */
  public void modifyEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {
    // ConcernRole entity key
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set entity key for modify
    concernRoleKey.concernRoleID = key.evidenceID;

    // Modify details
    modify(concernRoleKey, (ConcernRoleDtls) dtls);

  }

  // ___________________________________________________________________________
  /**
   * Insert ConcernRole evidence
   *
   * @param details
   * - ConcernRole entity details
   */
  @Override
  public void insert(ConcernRoleDtls details) throws AppException,
      InformationalException {

    this.clearCaches();
    super.insert(details);
  }

  // ___________________________________________________________________________
  /**
   * Modify ConcernRole evidence
   *
   * @param key
   * - the uniqueID of the ConcernRole record
   * @param details
   * - ConcernRole details
   */
  @Override
  public void modify(ConcernRoleKey key, ConcernRoleDtls details)
    throws AppException, InformationalException {
    // We want to clear the cache in case for some reason the database
    // evidence is required e.g. if the evidence was updated by another user.
    // So to ensure we have the correct evidence, clear the cache and force a
    // read from the database
    this.clearCaches();

    super.modify(key, details);

    // The reason why we have to clear the cache here is a result of how the
    // evidence controller performs the modifying of evidence. PreModifying the
    // record it reads the details (first time it reads the details so will be
    // read from database and cached). The record is modified and post
    // modifying, the evidence controller calls performValidation
    // (validates the record) which requires a read of the evidence. The cached
    // evidence has stored the evidence PRIOR to the modification of the record.
    // Therefore we want to go to the database to read the modified evidence and
    // as a result clear the cache post modification.
    this.clearCaches();
  }

  // ___________________________________________________________________________
  /**
   * Read all child record identifiers.
   *
   * @param key
   * Evidence key for the parent evidence record
   *
   * @return A list of child record evidence keys for the parent
   */
  public EIEvidenceKeyList readAllByParentID(EIEvidenceKey key)
    throws AppException, InformationalException {
    // this evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // ___________________________________________________________________________
  /**
   * Read ConcernRole evidence
   *
   * @param key
   * Evidence key containing evidenceID and evidenceType
   *
   * @return ConcernRole or ConcernRoleSnapshot entity details
   */
  public Object readEvidence(EIEvidenceKey key) throws AppException,
      InformationalException {

    // manipulation variables
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // populate the concernRole key with passed in parameter
    concernRoleKey.concernRoleID = key.evidenceID;

    try {
      // read concernRole details
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      return concernRoleDtls;

    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been return for ID passed
      // read from the snapshot concernRole entity
      concernRoleDtls = new ConcernRoleDtls();
      ConcernRoleSnapshotKey concernRoleSnapshotKey = new ConcernRoleSnapshotKey();
      ConcernRoleSnapshotDtls concernRoleSnapshotDtls = new ConcernRoleSnapshotDtls();
      curam.core.intf.ConcernRoleSnapshot concernRoleSnapshotObj = curam.core.fact.ConcernRoleSnapshotFactory.newInstance();

      // populate the concernRole snapshot key with passed in parameter
      concernRoleSnapshotKey.concernRoleSnapshotID = key.evidenceID;

      // read concernRole snapshot details
      concernRoleSnapshotDtls = concernRoleSnapshotObj.read(
        concernRoleSnapshotKey);

      // BEGIN, CR00060045, POH
      concernRoleDtls.assign(concernRoleSnapshotDtls);
      // replace primary key on concernRoleDtls with concernRoleSnapshot
      // primary key concernRoleSnapshotID
      concernRoleDtls.concernRoleID = concernRoleSnapshotDtls.concernRoleSnapshotID;

      return concernRoleDtls;
      // END, CR00060045
    }

  }

  // ___________________________________________________________________________
  /**
   * Selects all the records for validations
   *
   * @param evKey
   * Contains an evidenceID / evidenceType pairing
   *
   * @return List of evidenceID / evidenceType pairings
   */
  public EIEvidenceKeyList selectForValidation(EIEvidenceKey evKey)
    throws AppException, InformationalException {
    // This evidence interface method is currently not implemented for
    // participant evidence.
    return new EIEvidenceKeyList();
  }

  // BEGIN, CR00167614, JMA
  // ___________________________________________________________________________
  /**
   * Reads the next payment date for a concern role
   *
   * @param key
   * Concern Role Key
   *
   * @return next payment date for concern role
   */
  public DateStruct readNextPaymentDate(ConcernRoleKey key)
    throws AppException, InformationalException {

    DateStruct dateStruct = new DateStruct();

    ConcernRoleTypeDetails concernRoleTypeDetails = ConcernRoleFactory.newInstance().readConcernRoleType(
      key);

    if (concernRoleTypeDetails.concernRoleType.equals(CONCERNROLETYPE.PERSON)) {
      PersonKey personKey = new PersonKey();

      personKey.concernRoleID = key.concernRoleID;

      PersonDtls personDtls = PersonFactory.newInstance().read(personKey);

      dateStruct.date = personDtls.nextPaymentDate;
    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.EMPLOYER)) {

      EmployerKey employerKey = new EmployerKey();

      employerKey.concernRoleID = key.concernRoleID;

      EmployerDtls employerDtls = EmployerFactory.newInstance().read(
        employerKey);

      dateStruct.date = employerDtls.nextPaymentDate;
    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.PRODUCTPROVIDER)) {

      ProductProviderKey productProviderKey = new ProductProviderKey();

      productProviderKey.concernRoleID = key.concernRoleID;

      ProductProviderDtls productProviderDtls = ProductProviderFactory.newInstance().read(
        productProviderKey);

      dateStruct.date = productProviderDtls.nextPaymentDate;
    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.INFORMATIONPROVIDER)) {

      InformationProviderKey informationProviderKey = new InformationProviderKey();

      informationProviderKey.concernRoleID = key.concernRoleID;

      InformationProviderDtls informationProviderDtls = InformationProviderFactory.newInstance().read(
        informationProviderKey);

      dateStruct.date = informationProviderDtls.nextPaymentDate;
    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.REPRESENTATIVE)) {

      RepresentativeKey representativeKey = new RepresentativeKey();

      representativeKey.concernRoleID = key.concernRoleID;

      curam.core.sl.entity.struct.RepresentativeDtls representativeDtls = RepresentativeFactory.newInstance().read(
        representativeKey);

      dateStruct.date = representativeDtls.nextPaymentDate;
    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.SERVICESUPPLIER)) {

      ServiceSupplierKey serviceSupplierKey = new ServiceSupplierKey();

      serviceSupplierKey.concernRoleID = key.concernRoleID;

      ServiceSupplierDtls serviceSupplierDtls = ServiceSupplierFactory.newInstance().read(
        serviceSupplierKey);

      dateStruct.date = serviceSupplierDtls.nextPaymentDate;
    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.UTILITY)) {

      UtilityKey utilityKey = new UtilityKey();

      utilityKey.concernRoleID = key.concernRoleID;

      UtilityDtls utilityDtls = UtilityFactory.newInstance().read(utilityKey);

      dateStruct.date = utilityDtls.nextPaymentDate;
      // BEGIN, CR00183799, JMA
    } else if (concernRoleTypeDetails.concernRoleType.equals(
      CONCERNROLETYPE.EXTERNALPARTY)) {

      ExternalPartyKey externalPartyKey = new ExternalPartyKey();

      externalPartyKey.concernRoleID = key.concernRoleID;

      ExternalPartyDtls externalPartyDtls = ExternalPartyFactory.newInstance().read(
        externalPartyKey);

      dateStruct.date = externalPartyDtls.nextPaymentDate;
    }
    // END, CR00183799
    return dateStruct;

  }

  // END, CR00167614
  // ___________________________________________________________________________
  /**
   * Validates evidence details
   *
   * @param evKey
   * Evidence key
   * @param evKeyList
   * Evidence key list
   * @param mode
   * Validate mode (insert, delete, applyChanges, modify)
   */
  public void validate(EIEvidenceKey evKey, EIEvidenceKeyList evKeyList,
    ValidateMode mode) throws AppException, InformationalException {// This
    // evidence
    // interface
    // method
    // is
    // currently
    // not
    // implemented
    // for
    // participant evidence.
  }

  // ___________________________________________________________________________
  /**
   * Create a snapshot record of the concernRole record
   *
   * @param key
   * Evidence key
   *
   * @return EIEvidenceKey - the id of the newly created snapshot record
   */
  public EIEvidenceKey createSnapshot(EIEvidenceKey key) throws AppException,
      InformationalException {

    // return struct
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // BEGIN, CR00061193, POH
    // unique id generator class
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();
    // END, CR00061193

    // manipulation variables
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();
    ConcernRoleSnapshotDtls concernRoleSnapshotDtls = new ConcernRoleSnapshotDtls();
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    curam.core.intf.ConcernRoleSnapshot concernRoleSnapshotObj = curam.core.fact.ConcernRoleSnapshotFactory.newInstance();

    // populate the key with passed in parameter
    concernRoleKey.concernRoleID = key.evidenceID;

    // read ConcernRole details
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // BEGIN, CR00060045, POH
    // populate snapshot details
    concernRoleSnapshotDtls.assign(concernRoleDtls);
    // END, CR00060045, POH

    // BEGIN, CR00061193, POH
    concernRoleSnapshotDtls.concernRoleSnapshotID = uniqueIDObj.getNextID();
    // END, CR00061193

    // insert snapshot record
    concernRoleSnapshotObj.insert(concernRoleSnapshotDtls);

    // populate return struct
    eiEvidenceKey.evidenceID = concernRoleSnapshotDtls.concernRoleSnapshotID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLE;

    return eiEvidenceKey;
  }

  // ___________________________________________________________________________
  /**
   * Method removing participant evidence. This method is called when
   * participant evidence is being cancelled
   *
   * @param key
   * - Contains an evidenceID / evidenceType pairing
   * @param dtls
   * - Modified evidence details
   */
  public void removeEvidence(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Entity key
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // Set entity key for modify
    concernRoleKey.concernRoleID = key.evidenceID;

    // Modify details
    modify(concernRoleKey, (ConcernRoleDtls) dtls);

  }

  // END, CR00059195

  // ___________________________________________________________________________
  /**
   * Invokes validation prior to insertion of concern role details.
   *
   * @param details
   * Details of concern role to be inserted.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   */
  @Override
  protected void preinsert(ConcernRoleDtls details) throws AppException,
      InformationalException {

    if ((details.concernRoleType.equals(CONCERNROLETYPE.PERSON) 
      || details.concernRoleType.equals(CONCERNROLETYPE.PROSPECTPERSON)) 
        && PDCUtilFactory.newInstance().getPDCEnabledFlag().enabled) {      
      
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
      
    } else {
      if (details.sensitivity.length() == 0) {
        details.sensitivity = curam.codetable.CONCERNNOTESENSITIVITY.DEFAULTCODE;
      }
    }
    // BEGIN, CR00386994, MV
    GuiceWrapper.getInjector().getProvider(CachedSecurityDetails.class).get().clearCache();
    // END, CR00386994
  }

  // ___________________________________________________________________________
  /**
   * Invokes validation prior to insertion of concern role details.
   *
   * @param key
   * contains concern role ID.
   * @param details
   * Modified details of concern role.
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   */
  @Override
  protected void premodify(ConcernRoleKey key, ConcernRoleDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00346492, ZV
    if (PDCUtilFactory.newInstance().isPDCEnabled(key).enabled) {      
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    } else {
      // sensitivity must be supplied
      if (details.sensitivity.length() == 0) {

        throw new AppException(
          curam.message.BPOCONCERNROLE.ERR_CONCERNROLE_FV_SENSITIVITY_EMPTY);
      }
    }
    // END, CR00346492
    // BEGIN, CR00386994, MV
    GuiceWrapper.getInjector().getProvider(CachedSecurityDetails.class).get().clearCache();
    // END, CR00386994
  }

  // ___________________________________________________________________________
  /**
   * Invokes validation prior to modification of representative summary details
   *
   * @param key
   * contains ConcernRoleID
   * @param details
   * modified RepresentativeSummaryDetails
   * @param representativeDtls
   * modified details of representative entity
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   */
  @Override
  protected void premodifyRepresentativeSummaryDetails(
    RepresentativeConcernRoleKey key, RepresentativeSummaryDetails details,
    curam.core.sl.entity.struct.RepresentativeDtls representativeDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00346492, ZV
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = key.concernRoleID;
    
    if (PDCUtilFactory.newInstance().isPDCEnabled(concernRoleKey).enabled) {      
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    } else {
      // validate incoming data
      validateRepresentativeSummaryDetails(details);
    }
    // END, CR00346492

  }

  // ___________________________________________________________________________
  /**
   * Validates that registration date, preferred communication method and
   * sensitivity have been entered before narrow modification. Also validates
   * the end date (if it has been entered by the user)
   *
   * @param representativeSummaryDetails
   * modified RepresentativeSummaryDetails
   */
  public void validateRepresentativeSummaryDetails(
    RepresentativeSummaryDetails representativeSummaryDetails)
    throws AppException, InformationalException {

    // registration date must be supplied
    if (representativeSummaryDetails.registrationDate.equals(
      curam.util.type.Date.kZeroDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCONCERNROLE.ERR_CONCERNROLE_FV_REGISTRATIONDATE_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00016578, SPD
    // get today's date
    Date currentDate = Date.getCurrentDate();

    // registration date cannot be in the future
    if (representativeSummaryDetails.registrationDate.after(currentDate)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINCONCERNROLEDETAILS.ERR_CONCERNROLE_XFV_REGISTRATIONDATE_LARGE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // if entered, the end date cannot be earlier than the registration date
    if (!representativeSummaryDetails.endDate.isZero()) {

      if (representativeSummaryDetails.endDate.before(
        representativeSummaryDetails.registrationDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            BPOMAINTAINCONCERNROLEDETAILS.ERR_CONCERNROLE_FV_ENDDATE),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

    }
    // END, CR00016578

    // preferred communication method must be supplied
    if (representativeSummaryDetails.prefCommMethod.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCONCERNROLE.ERR_CONCERNROLE_FV_PREF_COMM_METHOD_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);

    }

    // sensitivity must be supplied
    if (representativeSummaryDetails.sensitivity.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCONCERNROLE.ERR_CONCERNROLE_FV_SENSITIVITY_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // representative name must not be empty
    if (representativeSummaryDetails.concernRoleName.length() == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOCONCERNROLE.ERR_CONCERNROLE_FV_NAME_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * Modifies representative entity after concern role modification has
   * completed
   *
   * @param key
   * contains ConcernRoleID
   * @param details
   * modified RepresentativeSummaryDetails
   * @param representativeDtls
   * modified details of representative entity
   */
  @Override
  protected void postmodifyRepresentativeSummaryDetails(
    RepresentativeConcernRoleKey key, RepresentativeSummaryDetails details,
    curam.core.sl.entity.struct.RepresentativeDtls representativeDtls)
    throws AppException, InformationalException {

    // Synchronize the indexed staging database with the update to the
    // ConcernRole entity.
    curam.core.intf.IndexConcernRoleSynchronization indexConcernRoleSynchronization = curam.core.fact.IndexConcernRoleSynchronizationFactory.newInstance();

    indexConcernRoleSynchronization.modifyRepresentativeSummaryDetails(key,
      details, representativeDtls);

    // variables used to modify representative entity
    curam.core.sl.entity.intf.Representative representativeObj = curam.core.sl.entity.fact.RepresentativeFactory.newInstance();
    RepresentativeKey representativeKey = new RepresentativeKey();

    curam.core.sl.entity.struct.RepresentativeDtls representativeReadDtls;

    // modify representative entity
    representativeKey.concernRoleID = key.concernRoleID;

    // retrieve representative record
    representativeReadDtls = representativeObj.read(representativeKey);

    // based on domain CURAM_DATE
    curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // if the payment frequency has been changed then we need to reset the next
    // payment date
    if (representativeDtls.paymentFrequency.length() == 0) {

      representativeDtls.nextPaymentDate = curam.util.type.Date.kZeroDate;

    } else if (!(representativeReadDtls.paymentFrequency.equals(
      representativeDtls.paymentFrequency))) {

      String frequencyPattern = representativeDtls.paymentFrequency;

      representativeDtls.nextPaymentDate = new curam.util.type.FrequencyPattern(frequencyPattern).getNextOccurrence(
        currentDate);
    } else {

      representativeDtls.nextPaymentDate = representativeReadDtls.nextPaymentDate;
    }

    representativeObj.modify(representativeKey, representativeDtls);

    // BEGIN, CR00091865, CW
    // Raise the modify concern role event
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = CONCERNROLE.MODIFY_CONCERN_ROLE;

    event.primaryEventData = representativeDtls.concernRoleID;
    curam.util.events.impl.EventService.raiseEvent(event);
    // END, CR00091865
  }

  // BEGIN, CR00059697, SK
  // ___________________________________________________________________________
  /**
   * Method to search for records on a participant entity by concernRoleID.
   *
   * @param key
   * - The unique concernRoleID of the participant.
   *
   * @return A list of EIEvidenceKey objects each containing a
   * evidenceID/evidenceType pair.
   */
  public EIEvidenceKeyList readAllByConcernRoleID(ConcernRoleIDKey key)
    throws AppException, InformationalException {

    // BEGIN, CR00060407, SSK

    // Check if a record exists for this concern.

    // manipulation variables
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();
    ConcernRoleDtls concernRoleDtls = new ConcernRoleDtls();
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

    // populate the key with passed in parameter
    concernRoleKey.concernRoleID = key.concernRoleID;

    // read concernRole details
    try {
      concernRoleDtls = concernRoleObj.read(concernRoleKey);
    } catch (RecordNotFoundException rnfe) {

      // if no record found return an empty EIEvidenceKeyList
      return new EIEvidenceKeyList();
    }

    // manipulation variables
    EIEvidenceKeyList eiEvidenceKeyList = new EIEvidenceKeyList();
    EIEvidenceKey eiEvidenceKey = new EIEvidenceKey();

    // populate details
    eiEvidenceKey.evidenceID = concernRoleDtls.concernRoleID;
    eiEvidenceKey.evidenceType = CASEEVIDENCE.CONCERNROLE;

    // add details to return struct
    eiEvidenceKeyList.dtls.addRef(eiEvidenceKey);

    return eiEvidenceKeyList;
    // END, CR00060407

  }

  // END, CR00059697

  // BEGIN, CR00069014, JPG
  // ___________________________________________________________________________
  /**
   * Method to compare attributes on two records of the same entity type. It
   * then returns an ArrayList of strings with the names of each attribute that
   * was different between them.
   *
   * @param key
   * - Contains an evidenceID / evidenceType pairing
   * @param dtls
   * - a struct of the same type as the key containing the attributes
   * to be compared against
   *
   * @return A list of Strings. Each represents an attribute name that differed.
   */
  public ArrayList<String> getChangedAttributeList(EIEvidenceKey key, Object dtls)
    throws AppException, InformationalException {

    // Declare the return list to hold the names of the attributes that changed
    ArrayList<String> attributesChanged = new ArrayList<String>();

    // Create ConcernRoleDtls structs to allow a comparison of what is
    // in the database and what is in the struct dtls.
    ConcernRoleDtls concernRoleCompareDtls1 = new ConcernRoleDtls();
    ConcernRoleDtls concernRoleCompareDtls2 = new ConcernRoleDtls();

    try {

      curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();

      ConcernRoleKey concernRoleKey = new ConcernRoleKey();

      concernRoleKey.concernRoleID = key.evidenceID;

      // read ConcernRole details
      concernRoleCompareDtls1 = concernRoleObj.read(concernRoleKey);

      // Populate the ConcernRole struct that will be compared against
      concernRoleCompareDtls2.assign((ConcernRoleDtls) dtls);

    } catch (RecordNotFoundException recordNotFoundException) {

      // If no record has been returned for ID passed
      // read from the snapshot ConcernRole entity
      curam.core.intf.ConcernRoleSnapshot concernRoleSnapshotObj = curam.core.fact.ConcernRoleSnapshotFactory.newInstance();

      ConcernRoleSnapshotKey concernRoleSnapshotKey = new ConcernRoleSnapshotKey();

      // populate the ConcernRole snapshot key with passed in parameter
      concernRoleSnapshotKey.concernRoleSnapshotID = key.evidenceID;

      // Read the ConcernRole snapshot details
      concernRoleCompareDtls2.assign(
        concernRoleSnapshotObj.read(concernRoleSnapshotKey));

      // Populate the ConcernRole struct that will be compared against
      concernRoleCompareDtls1.assign((ConcernRoleDtls) dtls);
    }

    if (concernRoleCompareDtls1.concernID != concernRoleCompareDtls2.concernID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNID);
    }
    if (concernRoleCompareDtls1.concernRoleID
      != concernRoleCompareDtls2.concernRoleID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLEID);
    }
    if (!concernRoleCompareDtls1.concernRoleType.equals(
      concernRoleCompareDtls2.concernRoleType)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLETYPE);
    }
    if (!concernRoleCompareDtls1.creationDate.equals(
      concernRoleCompareDtls2.creationDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CREATIONDATE);
    }
    if (!concernRoleCompareDtls1.registrationDate.equals(
      concernRoleCompareDtls2.registrationDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.REGISTRATIONDATE);
    }
    if (!concernRoleCompareDtls1.startDate.equals(
      concernRoleCompareDtls2.startDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STARTDATE);
    }
    if (!concernRoleCompareDtls1.endDate.equals(concernRoleCompareDtls2.endDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.ENDDATE);
    }
    if (!concernRoleCompareDtls1.statusCode.equals(
      concernRoleCompareDtls2.statusCode)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.STATUSCODE);
    }
    if (!concernRoleCompareDtls1.concernRoleName.equals(
      concernRoleCompareDtls2.concernRoleName)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.CONCERNROLENAME);
    }
    if (!concernRoleCompareDtls1.primaryAlternateID.equals(
      concernRoleCompareDtls2.primaryAlternateID)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PRIMARYALTERNATEID);
    }
    if (!concernRoleCompareDtls1.comments.equals(
      concernRoleCompareDtls2.comments)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.COMMENTS);
    }
    if (!concernRoleCompareDtls1.primaryAlternateID.equals(
      concernRoleCompareDtls2.primaryAlternateID)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PRIMARYALTERNATEID);
    }
    if (concernRoleCompareDtls1.primaryPhoneNumberID
      != concernRoleCompareDtls2.primaryPhoneNumberID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PRIMARYPHONENUMBERID);
    }
    if (concernRoleCompareDtls1.primaryEmailAddressID
      != concernRoleCompareDtls2.primaryEmailAddressID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PRIMARYEMAILADDRESSID);
    }
    if (concernRoleCompareDtls1.primaryBankAccountID
      != concernRoleCompareDtls2.primaryBankAccountID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PRIMARYBANKACCOUNTID);
    }
    if (!concernRoleCompareDtls1.regUserName.equals(
      concernRoleCompareDtls2.regUserName)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.REGUSERNAME);
    }
    if (concernRoleCompareDtls1.prefPublicOfficeID
      != concernRoleCompareDtls2.prefPublicOfficeID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PREFPUBLICOFFICEID);
    }
    if (!concernRoleCompareDtls1.preferredLanguage.equals(
      concernRoleCompareDtls2.preferredLanguage)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PREFERREDLANGUAGE);
    }
    if (!concernRoleCompareDtls1.sensitivity.equals(
      concernRoleCompareDtls2.sensitivity)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.SENSITIVITY);
    }
    if (!concernRoleCompareDtls1.prefCommFromDate.equals(
      concernRoleCompareDtls2.prefCommFromDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PREFCOMMFROMDATE);
    }
    if (!concernRoleCompareDtls1.prefCommToDate.equals(
      concernRoleCompareDtls2.prefCommToDate)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PREFCOMMTODATE);
    }
    if (!concernRoleCompareDtls1.prefCommMethod.equals(
      concernRoleCompareDtls2.prefCommMethod)) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PREFCOMMMETHOD);
    }
    if (concernRoleCompareDtls1.primaryWebAddressID
      != concernRoleCompareDtls2.primaryWebAddressID) {
      attributesChanged.add(ENTITYATTRIBUTENAMES.PRIMARYWEBADDRESSID);
    }

    return attributesChanged;
  }

  // ___________________________________________________________________________
  /**
   * Method to check if the attributes that changed during a modify require
   * reassessment to be run when they are applied.
   *
   * @param attributesChanged
   * - A list of Strings. Each represents the name of an attribute that
   * changed
   *
   * @return true if Reassessment required
   */
  public boolean checkForReassessment(ArrayList attributesChanged)
    throws AppException, InformationalException {

    return true;

    /*
     * Implement code here if you wish to only reassess modifications to
     * participant evidence when specified attributes are changed during the
     * modification. Currently this method returns true so any modifications to
     * participant evidence will trigger reassessment. To Implement set a
     * indicator to false and check the attributesChanged list for the
     * attributes that require reassessment. If one is found set the in
     * indicator to true
     */
  }

  // END, CR00069014
  // ___________________________________________________________________________
  /**
   * Invokes validation after the insertion of concern role details.
   *
   * @param details
   * Details of concern role to be inserted.
   */
  @Override
  protected void postinsert(ConcernRoleDtls details) throws AppException,
      InformationalException {
    // Synchronize the indexed staging database with the update to the
    // ConcernRole entity.
    curam.core.intf.IndexConcernRoleSynchronization indexConcernRoleSynchronization = curam.core.fact.IndexConcernRoleSynchronizationFactory.newInstance();

    indexConcernRoleSynchronization.insert(details);

  }

  // ___________________________________________________________________________
  /**
   * Raise a post Modify event
   *
   * @param key
   * Identifier of the record that has been modified
   * @param details
   * The updated details for the record
   */
  @Override
  protected void postmodify(ConcernRoleKey key, ConcernRoleDtls details)
    throws AppException, InformationalException {
    // Synchronize the indexed staging database with the update to the
    // ConcernRole entity.
    curam.core.intf.IndexConcernRoleSynchronization indexConcernRoleSynchronization = curam.core.fact.IndexConcernRoleSynchronizationFactory.newInstance();

    indexConcernRoleSynchronization.modify(key, details);

    // raise an event
    // BEGIN, CR00080234, MG
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = CONCERNROLE.MODIFY_CONCERN_ROLE;

    event.primaryEventData = details.concernRoleID;
    curam.util.events.impl.EventService.raiseEvent(event);
    // END, CR00080234

  }

  // ___________________________________________________________________________
  /**
   * Post modify concern role name details
   *
   * @param key
   * The concern role key
   * @param concernRoleNameAndVersion
   * The concern role name and version
   */
  @Override
  protected void postmodifyConcernRoleName(ConcernRoleKey key,
    ConcernRoleNameAndVersion concernRoleNameAndVersion) throws AppException,
      InformationalException {
    // Synchronize the indexed staging database with the update to the
    // ConcernRole entity.
    curam.core.intf.IndexConcernRoleSynchronization indexConcernRoleSynchronization = curam.core.fact.IndexConcernRoleSynchronizationFactory.newInstance();

    indexConcernRoleSynchronization.modifyConcernRoleName(key,
      concernRoleNameAndVersion);

  }

  // BEGIN, CR00220422, PF
  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getEndDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    // BEGIN, CR00240667, CD
    return read(evKey).endDate;
    // END, CR00240667
  }

  /**
   * Method to return the business start date for the evidence type.
   * Returns a null date, triggering the defaulting in the Evidence infrastructure
   *
   * @param evKey The evidence key.
   */
  public Date getStartDate(EIEvidenceKey evKey) throws AppException,
      InformationalException {
    // BEGIN, CR00240667, CD
    return read(evKey).startDate;
    // END, CR00240667
  }

  // END, CR002204022

  // BEGIN, CR00224875, ZV
  /**
   * Ensures that only 'active' concern roles are read by the
   * searchActiveConcernRoleAddressAndName method.
   *
   * @param key Contains concern role id and status code.
   */
  @Override
  protected void presearchActiveConcernRoleAddressAndName(
    final ConcernRoleIDStatusCodeKey key)
    throws AppException, InformationalException {
    key.statusCode = RECORDSTATUS.NORMAL;
  }

  // END, CR00224875

  // BEGIN, CR00346492, ZV
  // ___________________________________________________________________________
  /**
   * Invokes validation prior to modification of concern role name details
   *
   * @param key
   * contains ConcernRoleID
   * @param concernRoleNameAndVersion
   * modified concern role name and version number
   *
   * @throws AppException(PARTICIPANTDATACASE.ERR_PDC_ENABLED_NOT_ALLOWED)
   * If Participant Data Case is enabled.
   */
  @Override
  protected void premodifyConcernRoleName(ConcernRoleKey key,
    ConcernRoleNameAndVersion concernRoleNameAndVersion) throws AppException,
      InformationalException {

    if (PDCUtilFactory.newInstance().isPDCEnabled(key).enabled) {      
      throw new AppException(
        PARTICIPANTDATACASE.ERR_PDC_ENABLED_INVOCATION_NOT_ALLOWED);          
    }

  }

  // ___________________________________________________________________________
  /**
   * Invokes validation after the insertion of concern role details.
   *
   * @param details
   * Details of concern role to be inserted.
   */
  @Override
  protected void postpdcInsert(ConcernRoleDtls details) throws AppException,
      InformationalException {
    // Synchronize the indexed staging database with the update to the
    // ConcernRole entity.
    curam.core.intf.IndexConcernRoleSynchronization indexConcernRoleSynchronization = curam.core.fact.IndexConcernRoleSynchronizationFactory.newInstance();

    indexConcernRoleSynchronization.insert(details);
  }

  // ___________________________________________________________________________
  /**
   * Invokes validation prior to insertion of concern role details.
   *
   * @param details
   * Details of concern role to be inserted.
   */
  @Override
  protected void prepdcInsert(ConcernRoleDtls details) throws AppException,
      InformationalException {

    if (details.sensitivity.length() == 0) {
      details.sensitivity = curam.codetable.CONCERNNOTESENSITIVITY.DEFAULTCODE;
    }

  }

  // ___________________________________________________________________________
  /**
   * Raise a post Modify event
   *
   * @param key
   * Identifier of the record that has been modified
   * @param details
   * The updated details for the record
   */
  @Override
  protected void postpdcModify(ConcernRoleKey key, ConcernRoleDtls details)
    throws AppException, InformationalException {
    // Synchronize the indexed staging database with the update to the
    // ConcernRole entity.
    curam.core.intf.IndexConcernRoleSynchronization indexConcernRoleSynchronization = curam.core.fact.IndexConcernRoleSynchronizationFactory.newInstance();

    indexConcernRoleSynchronization.modify(key, details);

    // raise an event
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = CONCERNROLE.MODIFY_CONCERN_ROLE;

    event.primaryEventData = details.concernRoleID;
    curam.util.events.impl.EventService.raiseEvent(event);
  }

  // ___________________________________________________________________________
  /**
   * Invokes validation prior to insertion of concern role details.
   *
   * @param key
   * contains concern role ID.
   * @param details
   * Modified details of concern role.
   */
  @Override
  protected void prepdcModify(ConcernRoleKey key, ConcernRoleDtls details)
    throws AppException, InformationalException {

    // sensitivity must be supplied
    if (details.sensitivity.length() == 0) {

      throw new AppException(
        curam.message.BPOCONCERNROLE.ERR_CONCERNROLE_FV_SENSITIVITY_EMPTY);
    }

  }

  // ___________________________________________________________________________
  /**
   * Modifies representative entity after concern role modification has
   * completed
   *
   * @param key
   * contains ConcernRoleID
   * @param details
   * modified RepresentativeSummaryDetails
   * @param representativeDtls
   * modified details of representative entity
   */
  @Override
  protected void postpdcModifyRepresentativeSummaryDetails(
    RepresentativeConcernRoleKey key, RepresentativeSummaryDetails details,
    RepresentativeDtls representativeDtls) throws AppException,
      InformationalException {

    // Synchronize the indexed staging database with the update to the
    // ConcernRole entity.
    curam.core.intf.IndexConcernRoleSynchronization indexConcernRoleSynchronization = curam.core.fact.IndexConcernRoleSynchronizationFactory.newInstance();

    indexConcernRoleSynchronization.modifyRepresentativeSummaryDetails(key,
      details, representativeDtls);

    // variables used to modify representative entity
    curam.core.sl.entity.intf.Representative representativeObj = curam.core.sl.entity.fact.RepresentativeFactory.newInstance();
    RepresentativeKey representativeKey = new RepresentativeKey();

    curam.core.sl.entity.struct.RepresentativeDtls representativeReadDtls;

    // modify representative entity
    representativeKey.concernRoleID = key.concernRoleID;

    // retrieve representative record
    representativeReadDtls = representativeObj.read(representativeKey);

    // based on domain CURAM_DATE
    curam.util.type.Date currentDate = curam.util.type.Date.getCurrentDate();

    // if the payment frequency has been changed then we need to reset the next
    // payment date
    if (representativeDtls.paymentFrequency.length() == 0) {

      representativeDtls.nextPaymentDate = curam.util.type.Date.kZeroDate;

    } else if (!(representativeReadDtls.paymentFrequency.equals(
      representativeDtls.paymentFrequency))) {

      String frequencyPattern = representativeDtls.paymentFrequency;

      representativeDtls.nextPaymentDate = new curam.util.type.FrequencyPattern(frequencyPattern).getNextOccurrence(
        currentDate);
    } else {

      representativeDtls.nextPaymentDate = representativeReadDtls.nextPaymentDate;
    }

    representativeObj.modify(representativeKey, representativeDtls);

    // Raise the modify concern role event
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = CONCERNROLE.MODIFY_CONCERN_ROLE;

    event.primaryEventData = representativeDtls.concernRoleID;
    curam.util.events.impl.EventService.raiseEvent(event);
  }

  // ___________________________________________________________________________
  /**
   * Invokes validation prior to modification of representative summary details
   *
   * @param key
   * contains ConcernRoleID
   * @param details
   * modified RepresentativeSummaryDetails
   * @param representativeDtls
   * modified details of representative entity
   */
  @Override
  protected void prepdcModifyRepresentativeSummaryDetails(
    RepresentativeConcernRoleKey key, RepresentativeSummaryDetails details,
    RepresentativeDtls representativeDtls) throws AppException,
      InformationalException {

    // validate incoming data
    validateRepresentativeSummaryDetails(details);

  }

  // ___________________________________________________________________________
  /**
   * Post modify concern role name details
   *
   * @param key
   * The concern role key
   * @param concernRoleNameAndVersion
   * The concern role name and version
   */
  @Override
  protected void postpdcModifyConcernRoleName(ConcernRoleKey key,
    ConcernRoleNameAndVersion concernRoleNameAndVersion) throws AppException,
      InformationalException {
    // Synchronize the indexed staging database with the update to the
    // ConcernRole entity.
    curam.core.intf.IndexConcernRoleSynchronization indexConcernRoleSynchronization = curam.core.fact.IndexConcernRoleSynchronizationFactory.newInstance();

    indexConcernRoleSynchronization.modifyConcernRoleName(key,
      concernRoleNameAndVersion);

  }
  // END, CR00346492
}
