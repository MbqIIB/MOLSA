/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2003, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2003-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.ADDRESSELEMENTTYPE;
import curam.codetable.LOCATIONACCESSTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.sl.fact.ParticipantSearchFactory;
import curam.core.sl.intf.ParticipantSearch;
import curam.core.sl.struct.ParticipantSecurityCheckKey;
import curam.core.sl.struct.SQLStatement;
import curam.core.sl.struct.SearchCriteriaString;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.AlternateIDSearchKey;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.DataBasedSecurityResult;
import curam.core.struct.DisableLinkIndicatorDetails;
import curam.core.struct.EmployerAltIDSearchKey;
import curam.core.struct.EmployerAltSearchDetails;
import curam.core.struct.EmployerAltSearchKey;
import curam.core.struct.EmployerDatabaseSearchKey;
import curam.core.struct.EmployerDatabaseSearchKey1;
import curam.core.struct.EmployerDtls;
import curam.core.struct.EmployerDtlsList;
import curam.core.struct.EmployerDynamicSearchKey;
import curam.core.struct.EmployerReadDtls;
import curam.core.struct.EmployerReadDtlsList;
import curam.core.struct.EmployerSearchDetails;
import curam.core.struct.EmployerSearchDtls;
import curam.core.struct.EmployerSearchDtls1;
import curam.core.struct.EmployerSearchKey;
import curam.core.struct.EmployerSearchKey1;
import curam.core.struct.EmployerSearchResult;
import curam.core.struct.EmployerSearchResult1;
import curam.core.struct.EmployerSummaryDetails;
import curam.core.struct.EmployerSummaryDetailsList;
import curam.core.struct.OtherAddressData;
import curam.core.struct.ReadEmployerSummaryKey;
import curam.core.struct.SearchMessageDtls;
import curam.message.GENERAL;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;


/**
 * Employer search in Database
 *
 */
public abstract class DatabaseEmployerSearch extends curam.core.base.DatabaseEmployerSearch {

  // ___________________________________________________________________________
  /**
   * @param key data on which the searched will be based
   *
   * @return The details of any records found
   *
   * @deprecated Since Curam 6.0, replaced by {@link #search1()}
   *
   * Performs a database search for employers using the specified search
   * criteria, or performs a database read if the alternate ID is specified.
   */
  @Override
  @Deprecated
  public EmployerSearchResult search(EmployerSearchKey key)
    throws AppException, InformationalException {

    // Employer Objects
    EmployerSearchResult employerSearchResult = new EmployerSearchResult();
    EmployerSummaryDetailsList employerSummaryDetailsList = new EmployerSummaryDetailsList();
    ReadEmployerSummaryKey readEmployerSummaryKey = new ReadEmployerSummaryKey();

    // If the reference number is specified no need to process the complicated
    // query
    if (key.referenceNumber.length() == 0) {

      EmployerDatabaseSearchKey employerDatabaseSearchKey = calculateKey(key);

      // BEGIN, CR00077040, PMD
      // Set the key to search using the dynamic SQL API
      EmployerDynamicSearchKey employerDynamicSearchKey = new EmployerDynamicSearchKey();

      employerDynamicSearchKey.assign(employerDatabaseSearchKey);
      employerDynamicSearchKey.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;
      employerDynamicSearchKey.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;

      // Build SQL
      StringBuffer sBuf = new StringBuffer();

      sBuf.append("SELECT Employer.primaryAlternateID, ");
      sBuf.append("Employer.concernRoleID, Employer.tradingName, ");
      sBuf.append("Employer.registeredName, ConcernRole.sensitivity, ");
      sBuf.append("addressLine1.elementValue, city.elementValue ");
      sBuf.append("INTO :primaryAlternateID, :concernRoleID, :tradingName, ");
      sBuf.append(":registeredName, :sensitivity, :addressLine1, :city ");
      sBuf.append("FROM Employer, ConcernRole, ");
      sBuf.append("AddressElement addressLine1, AddressElement city ");
      sBuf.append("WHERE ConcernRole.concernRoleID = Employer.concernRoleID ");
      sBuf.append("AND addressLine1.addressID = ConcernRole.primaryAddressID ");
      sBuf.append("AND addressLine1.elementType = :addressLine1Type ");
      sBuf.append("AND city.addressID = ConcernRole.primaryAddressID ");
      sBuf.append("AND city.elementType = :cityType");

      if (employerDatabaseSearchKey.searchByTradingName) {

        sBuf.append(" AND Employer.upperTradingName like :tradingName");
      }

      if (employerDatabaseSearchKey.searchByRegisteredName) {

        sBuf.append(" AND Employer.upperRegisteredName like :registeredName");
      }

      if (employerDatabaseSearchKey.searchByAddressLine1) {

        sBuf.append(" AND addressLine1.upperElementValue like :addressLine1");
      }

      if (employerDatabaseSearchKey.searchByCity) {

        sBuf.append(" AND city.upperElementValue  like :city");
      }

      try {
        // Call dynamic SQL API to execute SQL
        // BEGIN, CR00232051, GD
        CuramValueList<EmployerSummaryDetails> curamValueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
          curam.core.struct.EmployerSummaryDetails.class,
          employerDynamicSearchKey, false, sBuf.toString());

        // END, CR00232051

        // Add the search results to the return list
        for (int i = 0; i < curamValueList.size(); i++) {
          // BEGIN, CR00232051, GD
          employerSummaryDetailsList.dtls.addRef(curamValueList.get(i));
          // END, CR00232051
        }
      } catch (curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage = // BEGIN, CR00163471, JC
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS.getMessageText(
          TransactionInfo.getProgramLocale());
        // END, CR00163471, JC

        employerSearchResult.messages.dtls.addRef(recordFoundMessage);
      }
      // END, CR00077040
      // BEGIN CR00020852, SG
    } else {
      // set the search key
      readEmployerSummaryKey.primaryAlternateID = key.referenceNumber;

      // BEGIN, CR00077040, PMD
      readEmployerSummaryKey.addressLine1Type = curam.codetable.ADDRESSELEMENTTYPE.LINE1;
      readEmployerSummaryKey.cityType = curam.codetable.ADDRESSELEMENTTYPE.CITY;
      // BEGIN,CR00231519,ZV
      readEmployerSummaryKey.statusCode = RECORDSTATUS.NORMAL;
      // END,CR00231519

      // Build SQL
      StringBuffer sBuf = new StringBuffer();

      sBuf.append("SELECT Employer.tradingName, ");
      sBuf.append("Employer.registeredName, Employer.primaryAlternateID, ");
      sBuf.append("Employer.concernRoleID, ConcernRole.sensitivity, ");
      sBuf.append("city.elementValue, addressLine1.elementValue ");
      sBuf.append("INTO :tradingName, :registeredName, ");
      sBuf.append(":primaryAlternateID, :concernRoleID, :sensitivity, ");
      sBuf.append(":city, :addressLine1 ");
      sBuf.append("FROM Employer, ConcernRole, ");
      sBuf.append("AddressElement city, AddressElement addressLine1 ");
      sBuf.append("WHERE ConcernRole.concernRoleID IN (");
      sBuf.append("SELECT concernRoleID FROM concernRoleAlternateID ");
      // BEGIN,CR00096720,GM
      // BEGIN,CR00231519,ZV
      sBuf.append(
        "WHERE concernRoleAlternateID.alternateID = :primaryAlternateID ");
      sBuf.append("AND concernRoleAlternateID.statuscode = :statusCode) ");
      // END,CR00231519
      // END,CR00096720

      sBuf.append("AND Employer.concernRoleID = ConcernRole.concernRoleID ");
      sBuf.append("AND (city.addressID = ConcernRole.primaryAddressID ");
      sBuf.append("AND city.elementType = :cityType) ");
      sBuf.append("AND (addressLine1.addressID = ConcernRole.primaryAddressID ");
      sBuf.append("AND addressLine1.elementType = :addressLine1Type)");

      try {

        // Call dynamic SQL API to execute SQL
        // BEGIN, CR00232051, GD
        CuramValueList<EmployerSummaryDetails> curamValueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
          curam.core.struct.EmployerSummaryDetails.class,
          readEmployerSummaryKey, false, sBuf.toString());

        // END, CR00232051

        for (int i = 0; i < curamValueList.size(); i++) {
          // BEGIN, CR00232051, GD
          employerSummaryDetailsList.dtls.addRef(curamValueList.get(i));
          // END, CR00232051
        }
      } catch (curam.util.exception.ReadmultiMaxException e) {

        SearchMessageDtls recordFoundMessage;

        // if number of results exceed the maximum limit
        // pass an informational message to client.
        recordFoundMessage = new SearchMessageDtls();

        recordFoundMessage.searchMessage = // BEGIN, CR00163471, JC
          curam.message.GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS.getMessageText(
          TransactionInfo.getProgramLocale());
        // END, CR00163471, JC

        employerSearchResult.messages.dtls.addRef(recordFoundMessage);
      }
      // END, CR00077040
    }
    // END CR00020852

    employerSearchResult.result.numRecordsFound = employerSummaryDetailsList.dtls.size();

    for (int i = 0; i < employerSummaryDetailsList.dtls.size(); i++) {

      // Search details
      EmployerSearchDtls employerSearchDtls = new EmployerSearchDtls();

      EmployerSummaryDetails employerSummaryDetails = employerSummaryDetailsList.dtls.item(
        i);

      employerSearchDtls.assign(employerSummaryDetails);

      employerSearchDtls.businessAddress = employerSummaryDetails.addressLine1;
      employerSearchDtls.businessCity = employerSummaryDetails.city;

      restrictResults(employerSearchDtls);

      if (employerSearchDtls.referenceNumber != null) {
        employerSearchResult.details.dtls.addRef(employerSearchDtls);
      } else {
        employerSearchResult.result.numRecordsFound = employerSearchResult.result.numRecordsFound
          - 1;
      }
    }

    return employerSearchResult;

  }

  // ___________________________________________________________________________
  /**
   * Reads employer's information from database
   *
   * @param key employer reference number
   *
   * @return Employer read details structure
   * @deprecated Since Curam 6.0.5.3, replaced by {@link #searchByReferenceNumber()}
   */
  @Override
  public EmployerReadDtls readByReferenceNumber(AlternateIDSearchKey key)
    throws AppException, InformationalException {
    EmployerReadDtls details = new EmployerReadDtls();

    // variables for employer
    curam.core.intf.Employer employerObj = curam.core.fact.EmployerFactory.newInstance();
    EmployerAltSearchDetails employerAltSearchDetails;
    EmployerAltSearchKey employerAltSearchKey = new EmployerAltSearchKey();

    // concern role variables
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // address variables
    curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    AddressDtls addressDtls;
    AddressKey addressKey = new AddressKey();

    OtherAddressData otherAddressData = new OtherAddressData();

    // set search key from parameter
    employerAltSearchKey.primaryAlternateID = key.alternateID;

    employerAltSearchKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    // do employer search
    employerAltSearchDetails = employerObj.readByAlternateID(
      employerAltSearchKey);

    // set search key for concern role according employer found
    concernRoleKey.concernRoleID = employerAltSearchDetails.concernRoleID;
    // do concern role search
    concernRoleDtls = concernRoleObj.read(concernRoleKey);

    // BEGIN, CR00226315, PM
    DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
    ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

    // perform concern role sensitivity check
    participantSecurityCheckKey.participantID = employerAltSearchDetails.concernRoleID;
    participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
    DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
      participantSecurityCheckKey);

    if (dataBasedSecurityResult.restricted) {

      // Return no details to client if User does not have access
      details.tradingName = CuramConst.gkRestricted;
      details.addressData = CuramConst.gkRestricted;
      details.concernID = 0;
      details.restricted = true;
      return details;

    } else {

      // set search key according the concern role found
      addressKey.addressID = concernRoleDtls.primaryAddressID;
      // do address search
      addressDtls = addressObj.read(addressKey);
      // set the return values
      details.tradingName = employerAltSearchDetails.tradingName;
      otherAddressData.addressData = addressDtls.addressData;
      addressObj.getAddressStrings(otherAddressData);
      details.addressData = otherAddressData.addressData;
      details.concernID = concernRoleDtls.concernID;
      details.restricted = false;
    }

    // If the location data security is on then access denied
    if (!dataBasedSecurityResult.result) {
      return null;
    }
    // END, CR00226315

    return details;
  }

  // ___________________________________________________________________________
  /**
   * Reads employer's information from database
   *
   * @param key employer reference number
   *
   * @return A list of Employer details
   */
  public EmployerReadDtlsList searchByReferenceNumber(AlternateIDSearchKey key)
    throws AppException, InformationalException {

    EmployerReadDtlsList detailsList = new EmployerReadDtlsList();

    // variables for employer
    curam.core.intf.Employer employerObj = curam.core.fact.EmployerFactory.newInstance();
    EmployerDtlsList employerDtlsList;
    EmployerReadDtls employerReadDtls = new EmployerReadDtls();
    
    EmployerAltIDSearchKey employerAltIDSearchKey = new EmployerAltIDSearchKey();

    // concern role variables
    curam.core.intf.ConcernRole concernRoleObj = curam.core.fact.ConcernRoleFactory.newInstance();
    ConcernRoleDtls concernRoleDtls;
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    // address variables
    curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();
    AddressDtls addressDtls;
    AddressKey addressKey = new AddressKey();

    OtherAddressData otherAddressData = new OtherAddressData();

    // set search key from parameter
    employerAltIDSearchKey.primaryAlternateID = key.alternateID;

    // do employer search
    employerDtlsList = employerObj.searchByPrimaryAltID(employerAltIDSearchKey);
    
    for (EmployerDtls employerDtls : employerDtlsList.dtls) {
      
      // set search key for concern role according employer found
      concernRoleKey.concernRoleID = employerDtls.concernRoleID;
      // do concern role search
      concernRoleDtls = concernRoleObj.read(concernRoleKey);

      // BEGIN, CR00226315, PM
      DataBasedSecurity dataBasedSecurity = SecurityImplementationFactory.get();
      ParticipantSecurityCheckKey participantSecurityCheckKey = new ParticipantSecurityCheckKey();

      // perform concern role sensitivity check
      participantSecurityCheckKey.participantID = employerDtls.concernRoleID;
      participantSecurityCheckKey.type = LOCATIONACCESSTYPE.READ;
      DataBasedSecurityResult dataBasedSecurityResult = dataBasedSecurity.checkParticipantSecurity(
        participantSecurityCheckKey);

      if (dataBasedSecurityResult.restricted) {

        // Return no details to client if User does not have access
        employerReadDtls.tradingName = CuramConst.gkRestricted;
        employerReadDtls.addressData = CuramConst.gkRestricted;
        employerReadDtls.concernID = 0;
        employerReadDtls.restricted = true;

      } else {

        // set search key according the concern role found
        addressKey.addressID = concernRoleDtls.primaryAddressID;
        // do address search
        addressDtls = addressObj.read(addressKey);
        // set the return values
        employerReadDtls.tradingName = employerDtls.tradingName;
        otherAddressData.addressData = addressDtls.addressData;
        addressObj.getAddressStrings(otherAddressData);
        employerReadDtls.addressData = otherAddressData.addressData;
        employerReadDtls.concernID = concernRoleDtls.concernID;
        employerReadDtls.restricted = false;
      }
      detailsList.dtlsList.add(employerReadDtls);
    }

    return detailsList;
  }

  // ___________________________________________________________________________
  /**
   * @param key employer search details
   *
   * @return Key for database search
   *
   * @deprecated Since Curam 6.0, replaced by {@link #calculateKey1()}
   *
   * Calculates the details of the database search key based on the key
   */
  @Override
  @Deprecated
  protected EmployerDatabaseSearchKey calculateKey(EmployerSearchKey key)
    throws AppException, InformationalException {

    EmployerDatabaseSearchKey employerDatabaseSearchKey = new EmployerDatabaseSearchKey();

    // BEGIN, CR00104704, GSP
    // Assign the key values
    employerDatabaseSearchKey.tradingName = key.tradingName.toUpperCase()
      + CuramConst.gkSqlWildcard;

    employerDatabaseSearchKey.registeredName = key.registeredName.toUpperCase()
      + CuramConst.gkSqlWildcard;

    employerDatabaseSearchKey.addressLine1 = key.businessAddress.toUpperCase()
      + CuramConst.gkSqlWildcard;

    employerDatabaseSearchKey.city = key.businessCity.toUpperCase()
      + CuramConst.gkSqlWildcard;
    // END, CR00104704

    // If a parameter is specified set the searchBy indicator for that parameter
    employerDatabaseSearchKey.searchByTradingName = (key.tradingName.length()
      > 0);
    employerDatabaseSearchKey.searchByRegisteredName = (key.registeredName.length()
      > 0);
    employerDatabaseSearchKey.searchByAddressLine1 = (key.businessAddress.length()
      > 0);
    employerDatabaseSearchKey.searchByCity = (key.businessCity.length() > 0);

    return employerDatabaseSearchKey;
  }

  // BEGIN, CR00218664, ZV
  // ___________________________________________________________________________
  /**
   * Calculates the details of the database search key based on the key
   *
   * @param key employer search details
   *
   * @return Key for database search
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected EmployerDatabaseSearchKey1 calculateKey1(EmployerSearchKey1 key)
    throws AppException, InformationalException {

    EmployerDatabaseSearchKey1 employerDatabaseSearchKey = new EmployerDatabaseSearchKey1();

    employerDatabaseSearchKey.referenceNumber = key.referenceNumber;

    if (key.tradingName.length() > 0) {
      employerDatabaseSearchKey.tradingName = key.tradingName.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

    if (key.registeredName.length() > 0) {
      employerDatabaseSearchKey.registeredName = key.registeredName.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

    if (key.addressDtls.addressLine1.length() > 0) {
      employerDatabaseSearchKey.addressLine1 = key.addressDtls.addressLine1.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

    if (key.addressDtls.addressLine2.length() > 0) {
      employerDatabaseSearchKey.addressLine2 = key.addressDtls.addressLine2.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

    if (key.addressDtls.city.length() > 0) {
      employerDatabaseSearchKey.city = key.addressDtls.city.toUpperCase()
        + CuramConst.gkSqlWildcard;
    }

    employerDatabaseSearchKey.cityType = ADDRESSELEMENTTYPE.CITY;
    employerDatabaseSearchKey.recordStatus = RECORDSTATUS.NORMAL;

    employerDatabaseSearchKey.addressLine1Type = ADDRESSELEMENTTYPE.LINE1;
    employerDatabaseSearchKey.addressLine2Type = ADDRESSELEMENTTYPE.LINE2;

    return employerDatabaseSearchKey;
  }

  // ___________________________________________________________________________
  /**
   * Format SQL select statement for employer and prospect employer search
   *
   * @param key Employer search criteria
   *
   * @return SQL select statement for employer and prospect employer search
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  protected SQLStatement formatSQL(EmployerDatabaseSearchKey1 key)
    throws AppException, InformationalException {

    SQLStatement sqlStatement = new SQLStatement();

    ParticipantSearch participantSearchObj = ParticipantSearchFactory.newInstance();
    SearchCriteriaString searchCriteriaString = new SearchCriteriaString();

    String sqlMainSelectStr = new String();
    String sqlSelectStr = new String();
    String sqlIntoStr = new String();
    String sqlEmployerFromStr = new String();
    String sqlProspectEmployerFromStr = new String();
    String sqlFromStr = new String();
    String sqlWhereStr = new String();
    String sqlEmployerWhereStr = new String();
    String sqlProspectEmployerWhereStr = new String();
    String sqlSortingStr = new String();

    sqlMainSelectStr = "SELECT tradingName, ";
    sqlMainSelectStr += "registeredName, ";
    sqlMainSelectStr += "primaryAlternateID, ";
    sqlMainSelectStr += "concernRoleID, ";
    sqlMainSelectStr += "concernRoleType, ";
    sqlMainSelectStr += "primaryBusinessAddress ";

    // BEGIN, CR00265086, ZV
    sqlSelectStr = "SELECT DISTINCT tradingName, ";
    // END, CR00265086
    sqlSelectStr += "registeredName, ";
    sqlSelectStr += "ConcernRole.primaryAlternateID, ";
    sqlSelectStr += "ConcernRole.concernRoleID, ";
    sqlSelectStr += "ConcernRole.concernRoleType, ";
    sqlSelectStr += "PrimaryAddress.addressData primaryBusinessAddress ";

    sqlIntoStr = "INTO :tradingName, ";
    sqlIntoStr += ":registeredName, ";
    sqlIntoStr += ":primaryAlternateID, ";
    sqlIntoStr += ":concernRoleID, ";
    sqlIntoStr += ":concernRoleType, ";
    sqlIntoStr += ":primaryBusinessAddress ";

    sqlEmployerFromStr = "FROM Employer, ";

    sqlProspectEmployerFromStr = "FROM ProspectEmployer, ";

    sqlFromStr = "ConcernRole, ";
    sqlFromStr += "Address PrimaryAddress ";

    sqlEmployerWhereStr = "WHERE ConcernRole.concernRoleID = ";
    sqlEmployerWhereStr += "Employer.concernRoleID ";

    sqlProspectEmployerWhereStr = "WHERE ConcernRole.concernRoleID = ";
    sqlProspectEmployerWhereStr += "ProspectEmployer.concernRoleID ";
    sqlProspectEmployerWhereStr += "AND ProspectEmployer.employerConcernRoleID IS NULL ";

    sqlWhereStr = "AND ConcernRole.primaryAddressID = ";
    sqlWhereStr += "PrimaryAddress.addressID ";

    sqlSortingStr = "ORDER BY tradingName, registeredName ";

    if (key.referenceNumber.length() > 0) {

      sqlMainSelectStr += ", alternateID ";
      sqlSelectStr += ", ConcernRoleAlternateID.alternateID ";

      sqlIntoStr += ", :alternateID ";

      sqlFromStr += ", ConcernRoleAlternateID ";

      sqlWhereStr += "AND ConcernRoleAlternateID.concernRoleID = ";
      sqlWhereStr += "ConcernRole.concernRoleID ";
      sqlWhereStr += "AND ConcernRoleAlternateID.alternateID = ";
      sqlWhereStr += ":referenceNumber ";
      sqlWhereStr += "AND ConcernRoleAlternateID.statusCode = :recordStatus ";
    }

    if (key.tradingName.length() > 0) {
      searchCriteriaString.string = key.tradingName;
      sqlWhereStr += "AND upperTradingName ";
      sqlWhereStr += participantSearchObj.getWildcardSearchOperator(searchCriteriaString).sqlStatement
        + " :tradingName ";
    }

    if (key.registeredName.length() > 0) {
      searchCriteriaString.string = key.registeredName;
      sqlWhereStr += "AND upperRegisteredName ";
      sqlWhereStr += participantSearchObj.getWildcardSearchOperator(searchCriteriaString).sqlStatement
        + " :registeredName ";
    }

    if (key.addressLine1.length() > 0 || key.addressLine2.length() > 0
      || key.city.length() > 0) {

      sqlMainSelectStr += ", addressData ";
      sqlSelectStr += ", Address.addressData ";

      sqlIntoStr += ", :businessAddress ";

      sqlFromStr += ", ConcernRoleAddress, Address ";

      sqlWhereStr += "AND ConcernRole.concernRoleID = ";
      sqlWhereStr += "ConcernRoleAddress.concernRoleID ";
      sqlWhereStr += "AND ConcernRoleAddress.addressID = Address.addressID ";
      sqlWhereStr += "AND ConcernRoleAddress.statusCode = :recordStatus ";

      if (key.addressLine1.length() > 0) {
        searchCriteriaString.string = key.addressLine1;

        sqlFromStr += ", AddressElement AddressLine1 ";

        sqlWhereStr += "AND ConcernRoleAddress.addressID = ";
        sqlWhereStr += "AddressLine1.addressID ";
        sqlWhereStr += "AND AddressLine1.elementType = :addressLine1Type ";
        sqlWhereStr += "AND AddressLine1.upperElementValue ";
        sqlWhereStr += participantSearchObj.getWildcardSearchOperator(searchCriteriaString).sqlStatement
          + " :addressLine1 ";
      }

      if (key.addressLine2.length() > 0) {
        searchCriteriaString.string = key.addressLine2;

        sqlFromStr += ", AddressElement AddressLine2 ";

        sqlWhereStr += "AND ConcernRoleAddress.addressID = ";
        sqlWhereStr += "AddressLine2.addressID ";
        sqlWhereStr += "AND AddressLine2.elementType = :addressLine2Type ";
        sqlWhereStr += "AND AddressLine2.upperElementValue ";
        sqlWhereStr += participantSearchObj.getWildcardSearchOperator(searchCriteriaString).sqlStatement
          + " :addressLine2 ";
      }

      if (key.city.length() > 0) {
        searchCriteriaString.string = key.city;

        sqlFromStr += ", AddressElement AddressCity ";

        sqlWhereStr += "AND ConcernRoleAddress.addressID = ";
        sqlWhereStr += "AddressCity.addressID ";
        sqlWhereStr += "AND AddressCity.elementType = :cityType ";
        sqlWhereStr += "AND AddressCity.upperElementValue ";
        sqlWhereStr += participantSearchObj.getWildcardSearchOperator(searchCriteriaString).sqlStatement
          + " :city ";
      }

    }

    sqlStatement.sqlStatement = sqlMainSelectStr;
    sqlStatement.sqlStatement += sqlIntoStr;
    sqlStatement.sqlStatement += "FROM (";
    sqlStatement.sqlStatement += sqlSelectStr + sqlEmployerFromStr + sqlFromStr
      + sqlEmployerWhereStr + sqlWhereStr;
    sqlStatement.sqlStatement += " UNION ALL " + sqlSelectStr
      + sqlProspectEmployerFromStr + sqlFromStr + sqlProspectEmployerWhereStr
      + sqlWhereStr;
    // BEGIN, CR00253958, ZV
    sqlStatement.sqlStatement += ") Employer " + sqlSortingStr;
    // END, CR00253958


    return sqlStatement;
  }

  // ___________________________________________________________________________
  /**
   * Performs a database search for employers using the specified search
   * criteria.
   *
   * @param key data on which the employer search will be based
   *
   * @return The details of any employer records found
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  @Override
  public EmployerSearchResult1 search1(EmployerSearchKey1 key)
    throws AppException, InformationalException {

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    EmployerSearchResult1 employerSearchResult = new EmployerSearchResult1();

    EmployerDatabaseSearchKey1 employerDatabaseSearchKey = calculateKey1(key);

    // BEGIN, CR00232051, GD
    CuramValueList<EmployerSearchDtls1> curamValueList = new CuramValueList<EmployerSearchDtls1>(
      EmployerSearchDtls1.class);

    // END, CR00232051

    try {

      // BEGIN, CR00282028, IBM
      // Call dynamic SQL API to execute SQL
      curamValueList = DynamicDataAccess.executeNsMulti(
        EmployerSearchDtls1.class, employerDatabaseSearchKey, false, true,
        formatSQL(employerDatabaseSearchKey).sqlStatement);
      // END, CR00282028

    } catch (curam.util.exception.ReadmultiMaxException e) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        new AppException(GENERAL.INF_GENERAL_SEARCH_TOO_MANY_RECORDS),
        CuramConst.gkEmpty, InformationalElement.InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      informationalManager.failOperation();
    }

    DisableLinkIndicatorDetails disableLinkIndicatorDetails = new DisableLinkIndicatorDetails();

    disableLinkIndicatorDetails.disableLinkInd = key.disableLinkInd;

    for (int i = 0; i < curamValueList.size(); i++) {

      EmployerSearchDetails employerSearchDetails = processSearchDetails(
        curamValueList.get(i), disableLinkIndicatorDetails);

      if (employerSearchDetails != null) {
        employerSearchResult.dtlsList.addRef(employerSearchDetails);
      }
    }

    return employerSearchResult;

  }
  // END, CR00218664

}
