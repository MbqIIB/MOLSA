/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005, 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.codetable.RULESCOMPONENTTYPE;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.intf.AllocationLine;
import curam.core.intf.CashReceived;
import curam.core.intf.ChequeReceived;
import curam.core.intf.FinancialInstruction;
import curam.core.intf.InstructionLineItem;
import curam.core.intf.LiabilityInstruction;
import curam.core.intf.ReversalInstruction;
import curam.core.intf.LiabilityInstrument;
import curam.core.intf.PaymentInstruction;
import curam.core.intf.PaymentInstrument;
import curam.core.intf.PaymentReceivedInstruction;
import curam.core.intf.PaymentReceivedInstrument;
import curam.core.intf.StandingOrder;
import curam.core.sl.entity.intf.CaseNominee;
import curam.core.sl.entity.struct.CaseNomineeDtls;
import curam.core.sl.entity.struct.CaseNomineeKey;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculator;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculatorFactory;
import curam.core.sl.infrastructure.assessment.impl.EligibilityEntitlementRuleSet;
import curam.core.sl.infrastructure.assessment.impl.ObjectiveType;
import curam.core.sl.infrastructure.assessment.impl.OverUnderPaymentBreakdown;
import curam.core.sl.infrastructure.fact.FinancialAdapterFactory;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrectionEvidence;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrectionFCLink;
import curam.core.sl.infrastructure.paymentcorrection.impl.PaymentCorrectionFCLinkDAO;
import curam.core.sl.infrastructure.paymentcorrection.struct.SearchByFinancialComponentIDKey;
import curam.core.struct.ALInstructLineItemID;
import curam.core.struct.AllocationLineDtls;
import curam.core.struct.CashReceivedDtls;
import curam.core.struct.CashReceivedKey;
import curam.core.struct.ChequeReceivedDtls;
import curam.core.struct.ChequeReceivedKey;
import curam.core.struct.ExportSearchDtls;
import curam.core.struct.FICreationDateRange;
import curam.core.struct.FIEffectiveDateRange;
import curam.core.struct.FinInstructionID;
import curam.core.struct.FinancialComponentID;
import curam.core.struct.FinancialInstructionDtls;
import curam.core.struct.FinancialInstructionDtlsList;
import curam.core.struct.ILIFinInstructID;
import curam.core.struct.InstructionLineItemDtls;
import curam.core.struct.InstructionLineItemDtlsList;
import curam.core.struct.InstructionLineItemKey;
import curam.core.struct.LiabilityFinInstructionID;
import curam.core.struct.LiabilityInstructionDtls;
import curam.core.struct.LiabilityInstructionID;
import curam.core.struct.LiabilityInstrumentDtls;
import curam.core.struct.PaymentInstructionDtls;
import curam.core.struct.PaymentInstrumentDtls;
import curam.core.struct.PaymentInstrumentKey;
import curam.core.struct.PaymentReceivedInstructionDtls;
import curam.core.struct.PaymentReceivedInstrumentDtls;
import curam.core.struct.PaymentReceivedInstrumentKey;
import curam.core.struct.PmtRecvFinInstructionID;
import curam.core.struct.RelatedILIDetailsList;
import curam.core.struct.RelatedILIidentifier;
import curam.core.struct.ReversalFinInstructionID;
import curam.core.struct.ReversalInstructionDtls;
import curam.core.struct.StandingOrderDtls;
import curam.core.struct.StandingOrderKey;
import curam.core.struct.ValidateExportSearchDtlsResult;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.DatabaseException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;


/**
 * Provides functionality to export financial instruction details
 * to the General Ledger.
 */

public abstract class GeneralLedgerInterface extends curam.core.base.GeneralLedgerInterface {

  protected final static int kEmailMessageSize = 2048;

  // bizinterface instances declared at class scope for efficiency
  // as they are used in for loops in the class methods.
  protected AllocationLine allocationLineObj;
  protected CashReceived cashReceivedObj;
  protected ChequeReceived chequeReceivedObj;
  protected FinancialInstruction financialInstructionObj;
  protected InstructionLineItem instructionLineItemObj;
  protected LiabilityInstruction liabilityInstructionObj;
  protected LiabilityInstrument liabilityInstrumentObj;
  protected CaseNominee caseNomineeObj;
  protected PaymentInstruction paymentInstructionObj;
  protected PaymentInstrument paymentInstrumentObj;
  protected PaymentReceivedInstruction paymentReceivedInstructionObj;
  protected PaymentReceivedInstrument paymentReceivedInstrumentObj;
  protected ReversalInstruction reversalInstructionObj;
  protected StandingOrder standingOrderObj;

  protected curam.core.impl.CuramBatch curamBatchObj;
  
  // BEGIN, CR00210273, CW
  /**
   * Reference to PaymentCorrectionEvidenceDAO.
   */
  @Inject
  protected PaymentCorrectionFCLinkDAO paymentCorrectionFCLinkDAO;
  
  @Inject
  protected DeterminationCalculatorFactory determinationCalculatorFactory;

  // END, CR00210273
  
  // BEGIN, CR00071077, GM
  protected static String eRPAdapterEnabledErrMsg = CuramConst.gkEmpty;
  // END, CR00071077

  
  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  public GeneralLedgerInterface() {

    cashReceivedObj = curam.core.fact.CashReceivedFactory.newInstance();
    chequeReceivedObj = curam.core.fact.ChequeReceivedFactory.newInstance();
    allocationLineObj = curam.core.fact.AllocationLineFactory.newInstance();
    financialInstructionObj = curam.core.fact.FinancialInstructionFactory.newInstance();
    instructionLineItemObj = curam.core.fact.InstructionLineItemFactory.newInstance();
    liabilityInstructionObj = curam.core.fact.LiabilityInstructionFactory.newInstance();
    liabilityInstrumentObj = curam.core.fact.LiabilityInstrumentFactory.newInstance();
    caseNomineeObj = curam.core.sl.entity.fact.CaseNomineeFactory.newInstance();
    paymentInstructionObj = curam.core.fact.PaymentInstructionFactory.newInstance();
    paymentInstrumentObj = curam.core.fact.PaymentInstrumentFactory.newInstance();
    paymentReceivedInstructionObj = curam.core.fact.PaymentReceivedInstructionFactory.newInstance();
    paymentReceivedInstrumentObj = curam.core.fact.PaymentReceivedInstrumentFactory.newInstance();
    reversalInstructionObj = curam.core.fact.ReversalInstructionFactory.newInstance();
    standingOrderObj = curam.core.fact.StandingOrderFactory.newInstance();

    curamBatchObj = new curam.core.impl.CuramBatch();
    // BEGIN, CR00210273, CW
    GuiceWrapper.getInjector().injectMembers(this);
    // END, CR00210273

  }

  // ___________________________________________________________________________
  /**
   * Prints the financial details for all financial instructions matching
   * the search criteria. For each financial instruction that matches, the
   * instruction details are printed as well as the details of its associated
   * instruction line item(s).
   *
   * @param exportSearchDtls The search details specifying which financial
   * instructions should be printed.
   */
  public void exportFinancialDetails(ExportSearchDtls exportSearchDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00073939, JI
    // If the ERP Adapter is enabled do not execute the batch job
    // and write an error message into the log file
    // BEGIN, CR00080249, CW
    if (FinancialAdapterFactory.newInstance().isFinancialAdapterEnabled()) {
      // END, CR00080249
      
      // Construct the error message
      curamBatchObj.setStartTime();
      // BEGIN, CR00077050, CW
      // BEGIN, CR00076996, KH
      eRPAdapterEnabledErrMsg = // BEGIN, CR00163471, JC
        curam.message.EXTERNALERPVALIDATIONS.ERR_ERP_ADAPTER_ENABLED_BATCH_JOB.getMessageText(
        ProgramLocale.getDefaultServerLocale())
          // END, CR00163471, JC
          + CuramConst.gkNewLine
          + CuramConst.gkNewLine;
      // END, CR00076996
      // END, CR00077050
      curamBatchObj.setEndTime();
   
      // send an e-mail with the summary of batch job.
      sendBatchJobSummaryEmail(0, 0, 0);
      // If the ERP Adapter is not enabled run the batch job
    } else {
      // END, CR00073939
    
      // register the security implementation
      SecurityImplementationFactory.register();
  
      // check that the search details are valid
      ValidateExportSearchDtlsResult validateExportSearchDtlsResult = validateSearchDtls(
        exportSearchDtls);
  
      if (validateExportSearchDtlsResult.skipRecordInd.skipRecordInd) {
  
        // send e-mail
        sendBatchJobErrorEmail(validateExportSearchDtlsResult);
  
        return;
      }
  
      // output print stream for the general ledger
      java.io.PrintStream outStream;
      String ledgerOutputFileName = generateLedgerOutputFileName(
        exportSearchDtls);
  
      // open stream in output mode
      try {
        outStream = new java.io.PrintStream(
          new java.io.FileOutputStream(ledgerOutputFileName));
      } catch (java.io.FileNotFoundException e) {
        throw new curam.util.exception.AppRuntimeException(e);
      }
  
      // check for file open failure
      if (outStream.checkError()) {
  
        AppException e = new AppException(
          curam.message.BPOGENERALLEDGERINTERFACE.ERR_GENERALLEDGER_FILE_OPEN);
  
        e.arg(ledgerOutputFileName);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }
  
      // counters to keep account of the records processed
      int paymentsIssued = 0;
      int liabilitiesIssued = 0;
      int paymentsReceived = 0;
  
      // read in all the financial instructions that match
      // the specified search criteria
      FinancialInstructionDtlsList financialInstructionDtlsList;
  
      // test to see if this is an effective or creation date search
      if (exportSearchDtls.creationDateSearchInd) {
  
        // perform a creation date range search
        FICreationDateRange fiCreationDateRange = new FICreationDateRange();
  
        // populate with the search date range
        fiCreationDateRange.creationDateFrom = exportSearchDtls.dateFrom;
        fiCreationDateRange.creationDateTo = exportSearchDtls.dateTo;
  
        // search financialInstruction entity
        financialInstructionDtlsList = financialInstructionObj.searchByCreationDateRange(
          fiCreationDateRange);
  
      } else {
  
        // perform an effective date range search
        FIEffectiveDateRange fIEffectiveDateRange = new FIEffectiveDateRange();
  
        // populate with the search date range
        fIEffectiveDateRange.effectiveDateFrom = exportSearchDtls.dateFrom;
        fIEffectiveDateRange.effectiveDateTo = exportSearchDtls.dateTo;
  
        // search financialInstruction entity
        financialInstructionDtlsList = financialInstructionObj.searchByEffectiveDateRange(
          fIEffectiveDateRange);
      }
  
      //
      // loop through all the instructions found and for each one
      // print out its header details and then print out the
      // details of all the instruction line items that relate to it.
      //
  
      FinancialInstructionDtls currentInstruction;
      // BEGIN, CR00051657, GM
      String referenceNumber = CuramConst.gkEmpty;

      // END, CR00051657
  
      for (int i = 0; i < financialInstructionDtlsList.dtls.size(); i++) {
  
        currentInstruction = financialInstructionDtlsList.dtls.item(i);
  
        // find the instruction's reference number (to print out later on)
  
        // PAYMENT Instruction
        if (currentInstruction.typeCode.equals(
          curam.codetable.FINANCIALINSTRUCTION.PAYMENT)) {
  
          referenceNumber = getPaymentInstructionRefNo(currentInstruction);
  
          if (currentInstruction.instrumentGenInd) {
            paymentsIssued++;
          }
  
          // LIABILITY Instruction
        } else if (
          currentInstruction.typeCode.equals(
          curam.codetable.FINANCIALINSTRUCTION.LIABILITY)) {
  
          referenceNumber = getLiabilityInstructionRefNo(currentInstruction);
  
          if (currentInstruction.instrumentGenInd) {
            liabilitiesIssued++;
          }
  
          // PAYMENTRECEIVED Instruction
        } else if (
          currentInstruction.typeCode.equals(
          curam.codetable.FINANCIALINSTRUCTION.PAYMENTRECEIVED)) {
  
          referenceNumber = getPaymentReceivedInstructionRefNo(
            currentInstruction);
          paymentsReceived++;
  
          // REVERSAL Instruction
        } else if (
          currentInstruction.typeCode.equals(
          curam.codetable.FINANCIALINSTRUCTION.REVERSAL)) {
  
          referenceNumber = getReversalInstructionRefNo(currentInstruction);
        }
  
        // write the current instruction's details to file
        outStream.print(
          getFinancialInstructionDetailsForOutput(currentInstruction,
          referenceNumber));
  
        //
        // find all the financial line items related to the current instruction
        //
  
        // set key to read instructionLineItem
        ILIFinInstructID iLIFinInstructID = new ILIFinInstructID();
  
        iLIFinInstructID.finInstructionID = currentInstruction.finInstructionID;
  
        // read instructionLineItem entity
        InstructionLineItemDtlsList iliDtlsList = instructionLineItemObj.searchByFinInstructID(
          iLIFinInstructID);
  
        // if the list is empty throw an error
        if (iliDtlsList.dtls.isEmpty()) {
  
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              curam.message.BPOGENERALLEDGERINTERFACE.ERR_GENERALLEDGER_NORECORD_FINLINEITEM),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              1);
        }
  
        // loop through all the instruction line items and
        // write their details to the stream
        for (int j = 0; j < iliDtlsList.dtls.size(); j++) {
  
          long relatedLineItemID = getRelatedLineItemID(
            iliDtlsList.dtls.item(j));
  
          outStream.print(
            getInstructionLineItemDetailsForOutput(iliDtlsList.dtls.item(j),
            relatedLineItemID));
        }
  
      }
  
      // close the print stream
      outStream.close();
  
      // send an e-mail with the summary of batch job.
      sendBatchJobSummaryEmail(paymentsIssued, liabilitiesIssued,
        paymentsReceived);
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates an ExportSearchDtls structure, checking that its date from and
   * date to members have been set and the fromDate is before the toDate.
   *
   * @param exportSearchDtls The search details to validate.
   */
  public ValidateExportSearchDtlsResult validateSearchDtls(ExportSearchDtls exportSearchDtls)
    throws AppException, InformationalException {

    // validateExportSearchDtlsResult manipulation variable
    ValidateExportSearchDtlsResult validateExportSearchDtlsResult = new ValidateExportSearchDtlsResult();

    try {

      validateExportSearchDtls(exportSearchDtls);

    } catch (AppException appException) {

      // BEGIN, CR00163236, CL
      validateExportSearchDtlsResult.messages.informationMsgTxt = appException.getMessage(
        TransactionInfo.getProgramLocale());
      // END, CR00163236
      validateExportSearchDtlsResult.skipRecordInd.skipRecordInd = true;
    }

    return validateExportSearchDtlsResult;
  }

  // ___________________________________________________________________________
  /**
   * Validates an ExportSearchDtls structure, checking that its date from and
   * date to members have been set and the fromDate is before the toDate.
   *
   * @param exportSearchDtls The search details to validate.
   */
  public void validateExportSearchDtls(ExportSearchDtls exportSearchDtls)
    throws AppException, InformationalException {

    // if date from is blank
    if (exportSearchDtls.dateFrom.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOGENERALLEDGERINTERFACE.ERR_GENERALLEDGER_NOFROMDATE_SUPPLIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // if date to is blank
    if (exportSearchDtls.dateTo.isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOGENERALLEDGERINTERFACE.ERR_GENERALLEDGER_NOTODATE_SUPPLIED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // If startDate is Later than endDate
    if (exportSearchDtls.dateTo.before(exportSearchDtls.dateFrom)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.GENERAL.ERR_GENERAL_XFV_FROM_DATE_TO_DATE),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          21);
    }

  }

  // ___________________________________________________________________________
  /**
   * Creates a filename to use for writing the output. The filename is
   * generated using the exportSearchDtls so that its name represents
   * the time period of the instructions it contains.
   *
   * @param exportSearchDtls The export search details which the instruction
   * details to be exported will match.
   *
   * @return The filename.
   */
  public String generateLedgerOutputFileName(
    ExportSearchDtls exportSearchDtls) {

    final int kOutputFileNameSize = 256;
    StringBuffer ledgerOutputFilenameBuffer = new StringBuffer(
      kOutputFileNameSize);

    // create file name
    ledgerOutputFilenameBuffer.append(CuramConst.gkGeneralLedgerInterface).append(CuramConst.gkUnderscore).append(curam.util.resources.Locale.getFormattedDateTime(exportSearchDtls.dateFrom.getDateTime(), curam.util.resources.Locale.Date_dmy)).append(CuramConst.gkUnderscore).append(curam.util.resources.Locale.getFormattedDateTime(exportSearchDtls.dateFrom.getDateTime(), curam.util.resources.Locale.Time_ISO)).append(CuramConst.gkUnderscore).append(curam.util.resources.Locale.getFormattedDateTime(exportSearchDtls.dateTo.getDateTime(), curam.util.resources.Locale.Date_dmy)).append(CuramConst.gkUnderscore).append(curam.util.resources.Locale.getFormattedDateTime(exportSearchDtls.dateTo.getDateTime(), curam.util.resources.Locale.Time_ISO)).append(
      CuramConst.gkDataFileExt);

    return ledgerOutputFilenameBuffer.toString();
  }

  // ___________________________________________________________________________
  /**
   * Gets the reference number for a payment financial instruction.
   *
   * @param financialInstructionDtls The financial instruction details.
   *
   * @return The payment instruction's reference number.
   */
  public String getPaymentInstructionRefNo(
    FinancialInstructionDtls financialInstructionDtls)
    throws AppException, InformationalException {
    // BEGIN, CR00049218, GM
    String referenceNumber = CuramConst.gkEmpty;
    // END, CR00049218
    FinInstructionID finInstructionID = new FinInstructionID();

    finInstructionID.finInstructionID = financialInstructionDtls.finInstructionID;

    // read paymentInstruction entity
    PaymentInstructionDtls pmtInstructionDtls = paymentInstructionObj.readByFinInstructionID(
      finInstructionID);

    if (financialInstructionDtls.instrumentGenInd) {

      if (pmtInstructionDtls.pmtInstrumentID != 0) {

        // populate financial instruction ID to retrieve
        // Payment Instrument details
        PaymentInstrumentKey paymentInstrumentKey = new PaymentInstrumentKey();

        paymentInstrumentKey.pmtInstrumentID = pmtInstructionDtls.pmtInstrumentID;

        // read paymentInstrument entity
        PaymentInstrumentDtls paymentInstrumentDtls = paymentInstrumentObj.read(
          paymentInstrumentKey);

        referenceNumber = paymentInstrumentDtls.referenceNumber;

      }

    }

    return referenceNumber;

  }

  // ___________________________________________________________________________
  /**
   * Gets the reference number for a liability financial instruction.
   *
   * @param financialInstructionDtls The financial instruction details.
   *
   * @return The liability instruction's reference number.
   */
  public String getLiabilityInstructionRefNo(
    FinancialInstructionDtls financialInstructionDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00049218, GM
    String referenceNumber = CuramConst.gkEmpty;
    // END, CR00049218
    // populate financial instruction ID to retrieve Liability details
    LiabilityFinInstructionID liabilityFinInstructionID = new LiabilityFinInstructionID();

    liabilityFinInstructionID.finInstructionID = financialInstructionDtls.finInstructionID;

    // read liabilityInstruction
    LiabilityInstructionDtls liabilityInstructionDtls = liabilityInstructionObj.readByFinInstructionID(
      liabilityFinInstructionID);

    if (financialInstructionDtls.instrumentGenInd) {

      // populate liability instruction ID to retrieve
      // liability instruction details
      LiabilityInstructionID liabilityInstructionID = new LiabilityInstructionID();

      liabilityInstructionID.liabInstructionID = liabilityInstructionDtls.liabInstructionID;

      // read liabilityInstrument
      LiabilityInstrumentDtls liabilityInstrumentDtls = liabilityInstrumentObj.readByLiabilityInstructionID(
        liabilityInstructionID);

      referenceNumber = String.valueOf(liabilityInstrumentDtls.liabInstrumentID);

    }

    return referenceNumber;

  }

  // ___________________________________________________________________________
  /**
   * Gets the reference number for a payment received financial instruction.
   *
   * @param financialInstructionDtls The financial instruction details.
   *
   * @return The payment received instruction's reference number.
   */
  public String getPaymentReceivedInstructionRefNo(
    FinancialInstructionDtls financialInstructionDtls)
    throws AppException, InformationalException {

    // BEGIN, CR00049218, GM
    String referenceNumber = CuramConst.gkEmpty;
    // END, CR00049218

    // populate financial instruction ID to retrieve
    // Payment Received details
    PmtRecvFinInstructionID pmtRecvFinInstructionID = new PmtRecvFinInstructionID();

    pmtRecvFinInstructionID.finInstructionID = financialInstructionDtls.finInstructionID;

    // read paymentReceivedInstruction
    PaymentReceivedInstructionDtls pmtReceivedInstructionDtls = paymentReceivedInstructionObj.readByFinInstructionID(
      pmtRecvFinInstructionID);

    //
    // if the instruction exists then find out its reference number,
    // based on the method of receipt type - CHEQUE, CASH or GIRO.
    //

    if (pmtReceivedInstructionDtls.pmtRecInstrumentID != 0) {

      // populate Received Instruction ID
      PaymentReceivedInstrumentKey paymentReceivedInstrumentKey = new PaymentReceivedInstrumentKey();

      paymentReceivedInstrumentKey.pmtRecInstrumentID = pmtReceivedInstructionDtls.pmtRecInstrumentID;

      PaymentReceivedInstrumentDtls paymentReceivedInstrumentDtls = paymentReceivedInstrumentObj.read(
        paymentReceivedInstrumentKey);

      // CHEQUE
      if (paymentReceivedInstrumentDtls.receiptMethodCode.equals(
        curam.codetable.METHODOFRECEIPT.CHEQUE)) {

        // populate Received Instruction ID
        ChequeReceivedKey chequeReceivedKey = new ChequeReceivedKey();

        chequeReceivedKey.pmtRecInstrumentID = pmtReceivedInstructionDtls.pmtRecInstrumentID;

        // retrieve the Check details
        ChequeReceivedDtls chequeReceivedDtls = chequeReceivedObj.read(
          chequeReceivedKey);

        referenceNumber = chequeReceivedDtls.chequeNumber;

        // CASH
      } else if (
        paymentReceivedInstrumentDtls.receiptMethodCode.equals(
        curam.codetable.METHODOFRECEIPT.CASH)) {

        // populate Received Instruction ID
        CashReceivedKey cashReceivedKey = new CashReceivedKey();

        cashReceivedKey.pmtRecInstrumentID = pmtReceivedInstructionDtls.pmtRecInstrumentID;

        // retrieve the ledger number if paid cash
        CashReceivedDtls cashReceivedDtls = cashReceivedObj.read(
          cashReceivedKey);

        referenceNumber = cashReceivedDtls.ledgerNumber;

        // GIRO
      } else if (
        paymentReceivedInstrumentDtls.receiptMethodCode.equals(
        curam.codetable.METHODOFRECEIPT.GIRO)) {

        // populate financial instrument ID to retrieve
        // standing order details
        StandingOrderKey standingOrderKey = new StandingOrderKey();

        standingOrderKey.pmtRecInstrumentID = pmtReceivedInstructionDtls.pmtRecInstrumentID;

        // read standingOrder entity
        StandingOrderDtls standingOrderDtls = standingOrderObj.read(
          standingOrderKey);

        referenceNumber = standingOrderDtls.originSortCode + CuramConst.gkSpace
          + standingOrderDtls.originAccNumber;
      }

    }

    return referenceNumber;

  }

  // ___________________________________________________________________________
  /**
   * Gets the reference number for a reversal financial instruction.
   *
   * @param financialInstructionDtls The financial instruction details.
   *
   * @return The reversal instruction's reference number.
   */
  public String getReversalInstructionRefNo(
    FinancialInstructionDtls financialInstructionDtls)
    throws AppException, InformationalException {

    // set key to read reversalInstruction
    ReversalFinInstructionID reversalFinInstructionID = new ReversalFinInstructionID();

    reversalFinInstructionID.finInstructionID = financialInstructionDtls.finInstructionID;

    // read reversalInstruction entity
    ReversalInstructionDtls reversalInstructionDtls = reversalInstructionObj.readByFinInstructionID(
      reversalFinInstructionID);

    return String.valueOf(reversalInstructionDtls.revInstructionID);

  }

  // ___________________________________________________________________________
  /**
   * Generates a string containing the details of a financial instruction
   * which is suitable for printing.
   *
   * @param financialInstructionDtls The financial instruction to summarize.
   * @param referenceNumber The financial instruction's reference number, this
   * is output as part of the string.
   *
   * @return The financial instruction details in a string format.
   */
  public String getFinancialInstructionDetailsForOutput(
    FinancialInstructionDtls financialInstructionDtls,
    String referenceNumber) {

    final int headerBufferSize = 4096;

    StringBuffer headerBuffer = new StringBuffer(headerBufferSize);

    // creating header details
    headerBuffer.append(String.valueOf(financialInstructionDtls.finInstructionID)).append(CuramConst.gkSlash).append(financialInstructionDtls.amount.toString()).append(CuramConst.gkSlash).append(curam.util.resources.Locale.getFormattedDateTime(financialInstructionDtls.effectiveDate.getDateTime(), curam.util.resources.Locale.Date_ISO8601_complete)).append(CuramConst.gkSlash).append(referenceNumber).append(CuramConst.gkNewLine).append(
      CuramConst.gkNewLine);

    return headerBuffer.toString();

  }

  // ___________________________________________________________________________
  /**
   * Retrieves the ID of an instruction line item related to a specified
   * instruction line item.
   *
   * @param instructionLineItemDtls The instruction line item whose related
   * instruction line item we want to find.
   *
   * @return The ID of the related instruction item if there is one. If no
   * related instruction line item exists then the ID will be zero.
   */
  public long getRelatedLineItemID(
    InstructionLineItemDtls instructionLineItemDtls)
    throws AppException, InformationalException {

    long relatedLineItemID = 0;

    final int kOneElement = 1;

    if ((instructionLineItemDtls.instructLineItemCategory.equals(
      curam.codetable.ILICATEGORY.WRITEOFFINSTRUCTION))
        || ((instructionLineItemDtls.instructLineItemCategory.equals(
          curam.codetable.ILICATEGORY.PAYMENTRECEIVEDINSTRUCTION))
            && (instructionLineItemDtls.instructionLineItemType.equals(
              curam.codetable.ILITYPE.ALLOCATEDPMTRECVD)))) {

      // allocationLine manipulation variables
      ALInstructLineItemID alInstructLineItemID = new ALInstructLineItemID();
      AllocationLineDtls allocationLineDtls;

      // populate instruction Line Item ID to retrieve allocationLine
      // details
      alInstructLineItemID.instructLineItemID = instructionLineItemDtls.instructLineItemID;
      allocationLineDtls = allocationLineObj.readByInstructLineItemID(
        alInstructLineItemID);

      relatedLineItemID = allocationLineDtls.relatedLineItemID;

    } else if (
      instructionLineItemDtls.instructLineItemCategory.equals(
      curam.codetable.ILICATEGORY.REVERSALINSTRUCTION)) {

      // related instructionLineItem manipulation variables
      RelatedILIidentifier relatedILIidentifier = new RelatedILIidentifier();
      RelatedILIDetailsList relatedILIDtlsList;

      // set key to search for related instructionLineItems
      relatedILIidentifier.instructLineItemID = instructionLineItemDtls.instructLineItemID;
      relatedILIidentifier.type = curam.codetable.ILICATEGORY.REVERSALINSTRUCTION;

      // search for related instructionLineItems
      relatedILIDtlsList = instructionLineItemObj.searchRelatedILIByRelatedLineItemIDType(
        relatedILIidentifier);

      if (relatedILIDtlsList.dtls.isEmpty()) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          new AppException(
            curam.message.BPOGENERALLEDGERINTERFACE.ERR_GENERALLEDGER_NORECORD_FINLINEITEM),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
            0);
      }

      if (relatedILIDtlsList.dtls.size() == kOneElement) {

        relatedLineItemID = relatedILIDtlsList.dtls.item(0).instructLineItemID;
      }

    }

    return relatedLineItemID;

  }

  // ___________________________________________________________________________
  /**
   * Generates a string representing an instruction line item which is suitable
   * for printing.
   *
   * @param instructionLineItemDtls The instruction line item to summarize.
   * @param relatedLineItemID The ID of a related instruction line item which
   * is part of the string.
   *
   * @return A printable string representing the instruction line item.
   */
  public String getInstructionLineItemDetailsForOutput(
    InstructionLineItemDtls instructionLineItemDtls,
    long relatedLineItemID)
    throws AppException, InformationalException {
    // nomineeCaseLink manipulation variables
    CaseNomineeKey caseNomineeKey = new CaseNomineeKey();
    CaseNomineeDtls caseNomineeDtls;

    final int stDetailStringSize = 4096;
    StringBuffer stDtlsString = new StringBuffer(stDetailStringSize);

    // i is the InstructionLineItemDtls vector
    if (instructionLineItemDtls.caseNomineeID != 0) {

      // set key to read nomineeCaseLink entity
      caseNomineeKey.caseNomineeID = instructionLineItemDtls.caseNomineeID;

      // read nomineeCaseLink entity
      caseNomineeDtls = caseNomineeObj.read(caseNomineeKey);

    } else {

      caseNomineeDtls = new CaseNomineeDtls();
      caseNomineeDtls.caseNomineeID = 0;
    }
    // BEGIN, CR00210273, CW
    // Retrieve rules component information to append to the string
    String iliRulesComponent = getRulesComponentTypeForLineItem(
      instructionLineItemDtls);
   
    // Generate Block 3 Details - Tab Delimited output
    // populated from InstructionLineItemDetails
    stDtlsString.append(String.valueOf(instructionLineItemDtls.instructLineItemID)).append(CuramConst.gkTabDelimiter).append(String.valueOf(relatedLineItemID)).append(CuramConst.gkTabDelimiter).append(instructionLineItemDtls.amount.toString()).append(CuramConst.gkTabDelimiter).append(instructionLineItemDtls.unprocessedAmount.toString()).append(CuramConst.gkTabDelimiter).append(instructionLineItemDtls.instructLineItemCategory).append(CuramConst.gkTabDelimiter).append(instructionLineItemDtls.instructionLineItemType).append(CuramConst.gkTabDelimiter).append(curam.util.resources.Locale.getFormattedDateTime(instructionLineItemDtls.coverPeriodFrom.getDateTime(), curam.util.resources.Locale.Date_ISO8601_complete)).append(CuramConst.gkTabDelimiter).append(curam.util.resources.Locale.getFormattedDateTime(instructionLineItemDtls.coverPeriodTo.getDateTime(), curam.util.resources.Locale.Date_ISO8601_complete)).append(CuramConst.gkTabDelimiter).append(curam.util.resources.Locale.getFormattedDateTime(instructionLineItemDtls.effectiveDate.getDateTime(), curam.util.resources.Locale.Date_ISO8601_complete)).append(CuramConst.gkTabDelimiter).append(curam.util.resources.Locale.getFormattedDateTime(instructionLineItemDtls.creationDate.getDateTime(), curam.util.resources.Locale.Date_ISO8601_complete)).append(CuramConst.gkTabDelimiter).append(instructionLineItemDtls.statusCode).append(CuramConst.gkTabDelimiter).append(String.valueOf(instructionLineItemDtls.caseID)).append(CuramConst.gkTabDelimiter).append(String.valueOf(instructionLineItemDtls.financialCompID)).append(CuramConst.gkTabDelimiter).append(String.valueOf(instructionLineItemDtls.finInstructionID)).append(CuramConst.gkTabDelimiter).append(String.valueOf(instructionLineItemDtls.concernRoleID)).append(CuramConst.gkTabDelimiter).append(String.valueOf(caseNomineeDtls.caseNomineeID)).append(CuramConst.gkTabDelimiter).append(String.valueOf(instructionLineItemDtls.primaryClientID)).append(CuramConst.gkTabDelimiter).append(instructionLineItemDtls.deliveryMethodType).append(CuramConst.gkTabDelimiter).append(String.valueOf(instructionLineItemDtls.currencyExchangeID)).append(CuramConst.gkTabDelimiter).append(instructionLineItemDtls.currencyTypeCode).append(CuramConst.gkTabDelimiter).append(String.valueOf(instructionLineItemDtls.adjustmentInd)).append(CuramConst.gkTabDelimiter).append(instructionLineItemDtls.adjustmentFrequency).append(CuramConst.gkTabDelimiter).append(curam.util.resources.Locale.getFormattedDateTime(instructionLineItemDtls.nextAdjustmentDate.getDateTime(), curam.util.resources.Locale.Date_ISO8601_complete)).append(CuramConst.gkTabDelimiter).append(String.valueOf(instructionLineItemDtls.instrumentGenInd)).append(CuramConst.gkTabDelimiter).append(String.valueOf(instructionLineItemDtls.fundID)).append(CuramConst.gkTabDelimiter).append(iliRulesComponent).append(CuramConst.gkNewLine).append(
      CuramConst.gkNewLine);
    // END, CR00210273
    return stDtlsString.toString();

  }

  // BEGIN, CR00210273, CW
  // ___________________________________________________________________________
  /**
   * Gets the rules component type for an instruction line item.
   * Payment correction evidence must exist for the ILI in order for this 
   * method to retrieve the rules component string. Otherwise an empty string
   * will be returned.
   *
   * @param instructionLineItemDtls The instruction line item details.
   *
   * @return The rules component type.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public String getRulesComponentTypeForLineItem(
    InstructionLineItemDtls instructionLineItemDtls) throws AppException,
      InformationalException, DatabaseException, AppRuntimeException {
    
    // 1. Read FC for ILI
    InstructionLineItemKey instructionLineItemKey = new InstructionLineItemKey();

    instructionLineItemKey.instructLineItemID = instructionLineItemDtls.instructLineItemID;
    
    FinancialComponentID financialComponent = InstructionLineItemFactory.newInstance().readFinComponentID(
      instructionLineItemKey);
    
    // 2. Read PaymentCorrectionFCLink for the FC to get PCEvidence record    
    SearchByFinancialComponentIDKey searchByFinancialComponentIDKey = new SearchByFinancialComponentIDKey();

    searchByFinancialComponentIDKey.financialComponentID = financialComponent.financialCompID;

    // Retrieve the link record: this list will not contain more than one item
    List<PaymentCorrectionFCLink> pcEvidenceFCLinkList = paymentCorrectionFCLinkDAO.searchByFinancialComponentID(
      searchByFinancialComponentIDKey);
    
    //
    // 3. Read the PaymentCorrectionEvidence record for the 
    // PaymentCorrectionFCLink and determine the rules component type
    // for the associated OverUnderPaymentBreakdown
    //
    if (pcEvidenceFCLinkList.isEmpty()) {
      
      // return an empty string if there is nothing in the list
      return CuramConst.gkEmpty;
    } else {
      
      // There will always be only one element in the link list if populated
      PaymentCorrectionEvidence pcEvidence = pcEvidenceFCLinkList.get(0).getPaymentCorrectionEvidence();
    
      // Read OverUnderPaymentBreakdown record to get rules objective id
      OverUnderPaymentBreakdown overUnderPaymentBreakdown = pcEvidence.getOverUnderPaymentBreakdown();
    
      // Get the ruleSet determination calculator for the original benefit case
      final DeterminationCalculator determinationCalculator = determinationCalculatorFactory.newInstanceForCaseID(
        pcEvidence.getRelatedCaseID());

      // Retrieve rule set using the determination calculator
      EligibilityEntitlementRuleSet ruleSet = determinationCalculator.getEligibilityEntitlementRuleSet(
        instructionLineItemDtls.coverPeriodFrom);
      
      // Use the ruleSet to look up the rules component type for the 
      // rules objective id on the OverUnderPaymentBreakdown
      String rulesObjective = overUnderPaymentBreakdown.getRulesObjective();
     
      ObjectiveType ruleSetObjType = ruleSet.getObjectiveType(rulesObjective);
     
      String rulesComponentType = CodeTable.getOneItem(
        RULESCOMPONENTTYPE.TABLENAME, ruleSetObjType.getName().getCode());

      return rulesComponentType;
    }
    
  }

  // END, CR00210273

  // ___________________________________________________________________________
  /**
   * Sends an e-mail to the user containing a summary of the completed
   * batch job.
   *
   * @param paymentsIssued The number of payments issued during the batch job
   * @param liabilitiesIssued The number of liabilities issued during the batch
   * job
   * @param paymentsReceived The number of payments received during the batch
   * job
   */
  public void sendBatchJobSummaryEmail(
    int paymentsIssued,
    int liabilitiesIssued,
    int paymentsReceived)
    throws AppException, InformationalException {

    // the size of the emailMessage StringBuffer is based on the
    // data written to the buffer
    StringBuffer emailMessage = new StringBuffer(kEmailMessageSize);

    // set output file id
    curamBatchObj.outputFileID = CuramConst.gkGeneralLedgerInterface;

    // set e-mail subject
    curamBatchObj.setEmailSubject(
      curam.message.BPOGENERALLEDGERINTERFACE.INF_GENERALLEDGERINTERFACE_SUB);

    // create e-mail message
    // BEGIN, CR00073939, JI
    emailMessage.append(CuramConst.gkNewLine).append(eRPAdapterEnabledErrMsg).append(CuramConst.gkGeneralLedgerInterfacePaymentsIssued).append(CuramConst.gkEquals).append(String.valueOf(paymentsIssued)).append(CuramConst.gkNewLine).append(CuramConst.gkNewLine).append(CuramConst.gkGeneralLedgerInterfaceLiabilities).append(CuramConst.gkEquals).append(String.valueOf(liabilitiesIssued)).append(CuramConst.gkNewLine).append(CuramConst.gkNewLine).append(CuramConst.gkGeneralLedgerInterfacePaymentsReceived).append(CuramConst.gkEquals).append(String.valueOf(paymentsReceived)).append(CuramConst.gkNewLine).append(
      CuramConst.gkNewLine);
    // END, CR00073939
    
    // set emailMessage for sending
    curamBatchObj.emailMessage = emailMessage.toString();

    // send e-mail
    curamBatchObj.sendEmail();

  }

  // ___________________________________________________________________________
  /**
   * Sends an e-mail to the user containing a summary of the completed
   * batch job.
   *
   */
  public void sendBatchJobErrorEmail(
    ValidateExportSearchDtlsResult validateExportSearchDtlsResult)
    throws AppException, InformationalException {

    // the size of the emailMessage StringBuffer is based on the
    // data written to the buffer
    StringBuffer emailMessage = new StringBuffer(kEmailMessageSize);

    // set output file id
    curamBatchObj.outputFileID = CuramConst.gkGeneralLedgerInterface;

    // set e-mail subject
    curamBatchObj.setEmailSubject(
      curam.message.BPOGENERALLEDGERINTERFACE.INF_GENERALLEDGERINTERFACE_SUB);

    // create e-mail message
    emailMessage.append(validateExportSearchDtlsResult.messages.informationMsgTxt).append(
      CuramConst.gkNewLine);

    // set emailMessage for sending
    curamBatchObj.emailMessage = emailMessage.toString();

    // send e-mail
    curamBatchObj.sendEmail();

  }
  
}
