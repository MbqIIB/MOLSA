/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.fact.UniqueIDFactory;
import curam.core.struct.ActivityRecurrenceDtls;
import curam.core.struct.UniqueIDKeySet;
import curam.message.BPOMAINTAINACTIVITY;
import curam.message.GENERALADMIN;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * recurrence details validation
 *
 */
public abstract class ActivityRecurrence extends curam.core.base.ActivityRecurrence {

  // ___________________________________________________________________________
  /**
   * Performs any pre-insert functionality.
   *
   * @param details
   * Activity recurrence details.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  protected void preinsert(final ActivityRecurrenceDtls details)
    throws AppException, InformationalException {

    // BEGIN, CR00260989, MR
    // BEGIN, CR00261512, PB
    if (0 == details.recurrenceID) {
      final UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

      // BEGIN, CR00293207, SS
      uniqueIDKeySet.keySetName = KeySets.KEY_SET_ACTIVITYRECURRENCE;
      // END, CR00293207

      details.recurrenceID = UniqueIDFactory.newInstance().getNextIDFromKeySet(
        uniqueIDKeySet);
    }
    // END, CR00261512
    // END, CR00260989

  }

  // ___________________________________________________________________________
  /**
   * validates activity recurrence details
   *
   * @param details
   * activity recurrence details to be validated
   */
  @Override
  protected void autovalidate(final ActivityRecurrenceDtls details)
    throws AppException, InformationalException {

    // check if start date of recurrence is set
    if (details.startDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERALADMIN.ERR_ACTIVITYRECURRENCE_START_DATE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // check if end date of recurrence is not less than end date if
    // it is provided
    if (!details.endDate.isZero() && details.endDate.before(details.startDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERALADMIN.ERR_ACTIVITYRECURRENCE_END_DATE_TIME),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // check if number of occurrences and end date are both provided
    if (!details.endDate.isZero() && (details.numberOfOccurrences != 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(GENERALADMIN.ERR_ACTIVITYRECURRENCE_OCCURRENCES_DATES),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Check for non zero values
    if (details.endDate.isZero() && details.numberOfOccurrences < 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOMAINTAINACTIVITY.ERR_ACTIVITYRECURRENCE_NEGATIVE_OCCURRENCES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Maximum number of occurrences
    final int iMaxOccurrences = MaintainUserActivity.getProperty(
      EnvVars.ENV_MAXNUMBEROFOCCURRENCES,
      EnvVars.ENV_MAXNUMBEROFOCCURRENCES_DEFAULT);

    if (details.numberOfOccurrences > iMaxOccurrences) {
      final AppException e = new AppException(
        BPOMAINTAINACTIVITY.ERR_ACTIVITY_FV_NUMBER_OF_OCCURRENCES);

      e.arg(details.numberOfOccurrences);
      e.arg(iMaxOccurrences);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

}
