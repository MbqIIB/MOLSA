/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2006, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2006-2007, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.HashSet;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.BUSINESSSTATUS;
import curam.codetable.CASEDECISIONRESULTCODE;
import curam.codetable.FINCOMPONENTCATEGORY;
import curam.codetable.FINCOMPONENTSTATUS;
import curam.codetable.FINCOMPONENTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.CachedCaseHeaderFactory;
import curam.core.fact.CachedProductDeliveryFactory;
import curam.core.fact.CachedProductDeliveryPatternInfoFactory;
import curam.core.fact.CachedProductFactory;
import curam.core.fact.CaseDecisionObjectiveFactory;
import curam.core.fact.CaseDeductionItemFCLinkFactory;
import curam.core.fact.CaseDeductionItemFactory;
import curam.core.fact.DeliveryMethodFactory;
import curam.core.fact.FinancialComponentFactory;
import curam.core.fact.InstructionLineItemFactory;
import curam.core.fact.MaintainCaseDecisionFactory;
import curam.core.fact.MaintainFinancialComponentFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.intf.CachedCaseHeader;
import curam.core.intf.CachedProduct;
import curam.core.intf.CachedProductDelivery;
import curam.core.intf.CachedProductDeliveryPatternInfo;
import curam.core.intf.CaseDeductionItem;
import curam.core.intf.CaseDeductionItemFCLink;
import curam.core.intf.DeliveryMethod;
import curam.core.intf.FinancialComponent;
import curam.core.intf.InstructionLineItem;
import curam.core.intf.MaintainFinancialComponent;
import curam.core.intf.UniqueID;
import curam.core.sl.entity.struct.CaseNomineeCaseIDKey;
import curam.core.sl.entity.struct.CaseNomineeDtls;
import curam.core.sl.entity.struct.CaseNomineeForCaseDetails;
import curam.core.sl.entity.struct.CaseNomineeForCaseDetailsList;
import curam.core.sl.entity.struct.CaseNomineeKey;
import curam.core.sl.entity.struct.CaseNomineeObjectiveHistoryKey;
import curam.core.sl.entity.struct.CaseNomineeProdDelPatternDtls;
import curam.core.sl.entity.struct.ReadEffectiveByDateKey;
import curam.core.sl.fact.CaseNomineeFactory;
import curam.core.sl.infrastructure.assessment.impl.AssessmentEngineEntity;
import curam.core.sl.intf.CaseNominee;
import curam.core.sl.struct.CaseNomineeObjectiveHistoryDetailsList;
import curam.core.sl.struct.GetNomineeForObjectiveKey;
import curam.core.sl.struct.GetNomineeForObjectiveResult;
import curam.core.struct.CaseDecisionComponentDecisionIDKey;
import curam.core.struct.CaseDecisionObjectiveDtlsList;
import curam.core.struct.CaseDecisionSummaryList;
import curam.core.struct.CaseDeductionItemDtls;
import curam.core.struct.CaseDeductionItemDtlsList;
import curam.core.struct.CaseDeductionItemFCLinkDtls;
import curam.core.struct.CaseDeductionItemFCLinkDtlsList;
import curam.core.struct.CaseDeductionItemID;
import curam.core.struct.CaseDeductionItemKey;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseIDStatusBusStatusCaseEndDateLastPaidDate;
import curam.core.struct.Count;
import curam.core.struct.DeductionItemFinCompDetails;
import curam.core.struct.DeductionItemFinCompDetailsList;
import curam.core.struct.DeliveryMethodDtls;
import curam.core.struct.DeliveryMethodKey;
import curam.core.struct.FCCoverDate;
import curam.core.struct.FCProcessingDtls;
import curam.core.struct.FinComponentID;
import curam.core.struct.FinancialComponentDtls;
import curam.core.struct.FinancialComponentID;
import curam.core.struct.FinancialComponentKey;
import curam.core.struct.GetLatestCoverPeriodToForCaseAndObjectiveKey;
import curam.core.struct.MaintainCaseDecisionCaseIDKey;
import curam.core.struct.PDPIByProdDelPatIDStatusAndDateKey;
import curam.core.struct.ProductDeliveryDtls;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryPatternInfoDtls;
import curam.core.struct.ProductDtls;
import curam.core.struct.ProductKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;


/**
 * Class to generate Financial Components for any Case Deduction Items
 * associated with a given case.
 */
public abstract class DeductionFCGeneration extends curam.core.base.DeductionFCGeneration {

  // BEGIN, CR00211744, VM
  public DeductionFCGeneration() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  @Inject
  AssessmentEngineEntity assessmentEngineEntity;
  // END, CR00211744

  // ___________________________________________________________________________
  /**
   * This method creates the financial component(s) required for any case
   * deduction item(s) associated with the given case. It also sets up a
   * link between the case deduction item(s) and the FCs generated from it.
   *
   * @param caseHeaderKey the ID of the case.
   */
  public void createDeductionFCs(CaseHeaderKey caseHeaderKey)
    throws AppException, InformationalException {

    // caseDeductionItemFCLink manipulation variables
    CaseDeductionItemFCLink caseDeductionItemFCLinkObj = CaseDeductionItemFCLinkFactory.newInstance();
    CaseDeductionItemFCLinkDtls caseDeductionItemFCLinkDtls = new CaseDeductionItemFCLinkDtls();

    // maintainFinancialComponent manipulation variables
    MaintainFinancialComponent maintainFinancialComponentObj = MaintainFinancialComponentFactory.newInstance();

    // Variable to hold details of the deduction FCs
    DeductionItemFinCompDetailsList deductionItemFCDtlsList = new DeductionItemFinCompDetailsList();

    // uniqueID object
    UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // Get list of Deduction FCs
    deductionItemFCDtlsList = generateDeductionFCDetails(caseHeaderKey);

    for (int i = 0; i < deductionItemFCDtlsList.dtls.size(); i++) {

      // Add Deduction Item FC
      FinComponentID deductionItemFinComponentID = maintainFinancialComponentObj.addDeductionItemFinComp(
        deductionItemFCDtlsList.dtls.item(i));

      // Set caseDeductionItemFCLinkDtls for insert
      caseDeductionItemFCLinkDtls.caseDeductionItemFCLinkID = uniqueIDObj.getNextID();
      caseDeductionItemFCLinkDtls.financialComponentID = deductionItemFinComponentID.finComponentID;
      caseDeductionItemFCLinkDtls.caseDeductionItemID = deductionItemFCDtlsList.dtls.item(i).caseDeductionItemID;

      // Insert caseDeductionItemFCLink
      caseDeductionItemFCLinkObj.insert(caseDeductionItemFCLinkDtls);

    } // end for i
  }

  // ___________________________________________________________________________
  /**
   * This method generates a list of the financial component(s) details for any
   * case deduction item(s) associated with the given case.
   *
   * @param caseHeaderKey the ID of the case.
   *
   * @return DeductionItemFinCompDetailsList a list containing the details of
   * the deduction FCs.
   */
  public DeductionItemFinCompDetailsList generateDeductionFCDetails(
    CaseHeaderKey caseHeaderKey)
    throws AppException, InformationalException {

    // caseHeader manipulation variables
    CaseHeaderDtls caseHeaderDtls;
    CachedCaseHeader cachedCaseHeaderObj = CachedCaseHeaderFactory.newInstance();

    // productDelivery manipulation variables
    CachedProductDelivery cachedProductDeliveryObj = CachedProductDeliveryFactory.newInstance();
    ProductDeliveryDtls productDeliveryDtls;
    ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    // product manipulation variables
    ProductKey productKey = new ProductKey();
    ProductDtls productDtls;
    CachedProduct cachedProductObj = CachedProductFactory.newInstance();

    // maintainFinancialComponent manipulation variables
    MaintainFinancialComponent maintainFinancialComponentObj = MaintainFinancialComponentFactory.newInstance();

    // caseDeductionItem manipulation variables
    CaseDeductionItem caseDeductionItemObj = CaseDeductionItemFactory.newInstance();
    CaseDeductionItemDtlsList caseDeductionItemDtlsList;
    // BEGIN, CR00003850
    CaseIDStatusBusStatusCaseEndDateLastPaidDate caseIDStatusBusStatusCaseEndDateLastPaidDate = new CaseIDStatusBusStatusCaseEndDateLastPaidDate();
    DeductionItemFinCompDetailsList deductionItemFCDtlsList = new DeductionItemFinCompDetailsList();
    DeductionItemFinCompDetails deductionItemFCDtls;

    // Read caseHeader
    caseHeaderDtls = cachedCaseHeaderObj.read(caseHeaderKey);

    // Set key to read productDelivery
    productDeliveryKey.caseID = caseHeaderKey.caseID;
    productDeliveryDtls = cachedProductDeliveryObj.read(productDeliveryKey);

    // Set key to read product
    productKey.productID = productDeliveryDtls.productID;
    productDtls = cachedProductObj.read(productKey);
    
    // BEGIN, CR00283273, KH
    // Get all eligible objectives on the case
    Set<String> objectives = new HashSet<String>();
    
    MaintainCaseDecisionCaseIDKey activeDecisionsKey = new MaintainCaseDecisionCaseIDKey();

    activeDecisionsKey.caseID = caseHeaderKey.caseID;
    
    CaseDecisionSummaryList activeDecisionList = MaintainCaseDecisionFactory.newInstance().getActiveCaseDecisions(
      activeDecisionsKey);
    
    for (int i = 0; i < activeDecisionList.dtls.size(); i++) {
      
      if (activeDecisionList.dtls.item(i).resultCode.equals(
        CASEDECISIONRESULTCODE.ELIGIBLE)) {
        
        // Find all the objectives for this eligible decision
        CaseDecisionComponentDecisionIDKey key = new CaseDecisionComponentDecisionIDKey();

        key.caseDecisionID = activeDecisionList.dtls.item(i).caseDecisionID;
        
        CaseDecisionObjectiveDtlsList cdoDtlsList = CaseDecisionObjectiveFactory.newInstance().searchByCaseDecisionID(
          key);
    
        for (int j = 0; j < cdoDtlsList.dtls.size(); j++) {
          objectives.add(cdoDtlsList.dtls.item(j).objectiveID);
        } // end for j
      }
    } // end for i
    
    Date earliestFCCoverDate = Date.kZeroDate;
    
    GetLatestCoverPeriodToForCaseAndObjectiveKey fcCaseID = new GetLatestCoverPeriodToForCaseAndObjectiveKey();

    fcCaseID.key.caseID = caseHeaderKey.caseID;
    
    // For each eligible objective on the case find the latest payment date. 
    for (String objective : objectives) {
      
      fcCaseID.key.rulesObjectiveID = objective;
      
      FCCoverDate currentFCCoverDate = maintainFinancialComponentObj.getLatestCoverPeriodToForCaseAndObjective(
        fcCaseID);
      
      // If any component has not been paid then the earliest date should not be set
      if (currentFCCoverDate.coverDate.isZero()) {
        earliestFCCoverDate = Date.kZeroDate;
        break;
      }

      /*
       * If the earliest date has not been set OR the earliest date and the 
       * current date have both been set but the current date is earlier, 
       * then set the earliest date to the current date
       */
      if (earliestFCCoverDate.isZero()
        || (!earliestFCCoverDate.isZero()
          && currentFCCoverDate.coverDate.before(earliestFCCoverDate))) {
        
        earliestFCCoverDate = currentFCCoverDate.coverDate;
      }
    }
    
    FCCoverDate fcCoverDate = new FCCoverDate();

    fcCoverDate.coverDate = earliestFCCoverDate;
    // END, CR00283273
    
    // BEGIN, CR00003850, CR00017151, KH
    // If the case has never been paid, set to the case start date
    if (fcCoverDate.coverDate.isZero()) {

      fcCoverDate.coverDate = caseHeaderDtls.startDate;
    }
    // END, CR00017151

    // Set key to read case deduction items
    caseIDStatusBusStatusCaseEndDateLastPaidDate.caseID = caseHeaderKey.caseID;
    caseIDStatusBusStatusCaseEndDateLastPaidDate.status = RECORDSTATUS.NORMAL;
    caseIDStatusBusStatusCaseEndDateLastPaidDate.businessStatus = BUSINESSSTATUS.ACTIVE;
    caseIDStatusBusStatusCaseEndDateLastPaidDate.caseEndDate = caseHeaderDtls.expectedEndDate;
    caseIDStatusBusStatusCaseEndDateLastPaidDate.caseLastPaidDate = fcCoverDate.coverDate;

    caseDeductionItemDtlsList = caseDeductionItemObj.searchByCaseIDStatusBusinessStatusStartDateEndDate(
      caseIDStatusBusStatusCaseEndDateLastPaidDate);
    // END, CR00003850

    // Fill out the CDI list for all relevant nominees
    caseDeductionItemDtlsList = getNomineesForDeductions(
      caseDeductionItemDtlsList);

    // BEGIN, CR00431540, CSH
    // Filter out any CDIs where the associated FCs should not be regenerated
    for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

      CaseDeductionItemFCLink caseDeductionItemFCLinkObj = CaseDeductionItemFCLinkFactory.newInstance();
      curam.core.struct.CaseDeductionItem caseDeductionItem = new curam.core.struct.CaseDeductionItem();
      CaseDeductionItemFCLinkDtlsList cdifcDtlsList = new CaseDeductionItemFCLinkDtlsList();

      caseDeductionItem.caseDeductionItemID = caseDeductionItemDtlsList.dtls.item(i).caseDeductionItemID;
      
      // Read the Financial Components(s) associated with the Case Deduction Item 
      cdifcDtlsList = caseDeductionItemFCLinkObj.searchByCaseDeductionItem(
        caseDeductionItem);
      
      int countClosedFCs = 0;
      
      for (int j = 0; j < cdifcDtlsList.dtls.size(); j++) {      
        
        // Check for Closed deduction financial components
        FinancialComponent financialComponentObj = FinancialComponentFactory.newInstance();
        FinancialComponentKey financialComponentKey = new  FinancialComponentKey();
        FinancialComponentDtls financialComponentDtls = new  FinancialComponentDtls();

        financialComponentKey.financialCompID = cdifcDtlsList.dtls.item(j).financialComponentID;
        financialComponentDtls = financialComponentObj.read(
          financialComponentKey);
        
        if (financialComponentDtls.statusCode.equals(
          FINCOMPONENTSTATUS.CLOSED_OUTOFDATE)) {
          countClosedFCs++;
        }  
      }
                             
      for (int k = 0; k < cdifcDtlsList.dtls.size(); k++) {
        
        // For each case deduction item, if any associated financial components  
        // have been Closed, check if these have been realized into ILIs
        if (countClosedFCs > 0) {
          
          // If the ILIs have been generated and the deduction end date has been 
          // set, then filter these out to prevent them from being regenerated          
          Count iliCount = new Count();
          InstructionLineItem instructionLineItemObj = InstructionLineItemFactory.newInstance();
          FinancialComponentID fcID = new FinancialComponentID();

          fcID.financialCompID = cdifcDtlsList.dtls.item(k).financialComponentID;
          iliCount = instructionLineItemObj.countByFinancialCompID(fcID);          
            
          if (iliCount.numberOfRecords > 0) {
                        
            if (!caseDeductionItemDtlsList.dtls.item(i).endDate.isZero()) {
              caseDeductionItemDtlsList.dtls.remove(i);
              i--;
              break;
            }
          }          
        }
      } // end for k    
    } // END, CR00431540
    
    // Loop through the remaining CDIs and create the financial components
    for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

      // BEGIN, CR00003905, KH
      // If the case has been paid, we only want CDIs which have no end date or
      // which end after the last paid to date of the case.
      if (fcCoverDate.coverDate.equals(caseHeaderDtls.startDate)
        || caseDeductionItemDtlsList.dtls.item(i).endDate.isZero()
        || caseDeductionItemDtlsList.dtls.item(i).endDate.after(
          fcCoverDate.coverDate)) {

        deductionItemFCDtls = new DeductionItemFinCompDetails();

        // Set common deduction FC details
        deductionItemFCDtls.adjustmentInd = false;
        deductionItemFCDtls.caseDecisionID = 0;
        deductionItemFCDtls.caseID = caseHeaderKey.caseID;
        deductionItemFCDtls.caseType = caseHeaderDtls.caseTypeCode;
        deductionItemFCDtls.componentCategory = FINCOMPONENTCATEGORY.CASEDEDUCTIONITEM;
        deductionItemFCDtls.componentType = FINCOMPONENTTYPE.DEDUCTIONPAYMENT;
        deductionItemFCDtls.fundID = productDtls.fundID;
        deductionItemFCDtls.primaryClientID = caseHeaderDtls.concernRoleID;
        deductionItemFCDtls.productID = 0;
        // BEGIN, CR00074927, JI
        deductionItemFCDtls.inRespectOfID = caseHeaderDtls.concernRoleID;
        // END, CR00074927

        // Set CDI specific deduction FC details
        deductionItemFCDtls.amount = caseDeductionItemDtlsList.dtls.item(i).amount;
        deductionItemFCDtls.caseNomineeID = caseDeductionItemDtlsList.dtls.item(i).caseNomineeID;
        deductionItemFCDtls.concernRoleID = caseDeductionItemDtlsList.dtls.item(i).concernRoleID;
        deductionItemFCDtls.rate = caseDeductionItemDtlsList.dtls.item(i).rate;
        deductionItemFCDtls.rulesObjectiveID = caseDeductionItemDtlsList.dtls.item(i).rulesObjectiveID;

        // BEGIN, CR00003905, KH
        // If the case has been paid, any new deduction FCs created must start
        // after the last paid to date of the case.
        if (fcCoverDate.coverDate.equals(caseHeaderDtls.startDate)
          || caseDeductionItemDtlsList.dtls.item(i).startDate.after(
            fcCoverDate.coverDate)) {

          deductionItemFCDtls.startDate = caseDeductionItemDtlsList.dtls.item(i).startDate;

        } else { // Otherwise they will start the day after the last paid to date

          deductionItemFCDtls.startDate = fcCoverDate.coverDate.addDays(1);
        }
        // END, CR00003905

        // Is the CDI end date set?
        if (caseDeductionItemDtlsList.dtls.item(i).endDate.isZero()) {

          // No, use expected end date from case
          deductionItemFCDtls.endDate = caseHeaderDtls.expectedEndDate;

        } else {

          // Yes, use CDI end date
          deductionItemFCDtls.endDate = caseDeductionItemDtlsList.dtls.item(i).endDate;
        }

        // Set up the nominee specific details
        setNomineeFCDetails(deductionItemFCDtls);

        // Set dueDate & nextProcessingDate
        // Is this an 'in arrears' cover period?
        if ((deductionItemFCDtls.coverPeriodType.equals(
          curam.codetable.PRODUCTCOVERPERIOD.ISSUEINARREARS))
            || (deductionItemFCDtls.coverPeriodType.equals(
              curam.codetable.PRODUCTCOVERPERIOD.ISSUEINARREARSDAYOFFSET))) {

          deductionItemFCDtls.dueDate = new curam.util.type.FrequencyPattern(deductionItemFCDtls.frequency).getNextOccurrence(
            deductionItemFCDtls.startDate);

        } else { // This is an 'in advance' cover period

          // If the start date is a product recurrence date (e.g. a Monday if
          // paying weekly) then getPrevOccurence() will return the previous
          // Monday. We don't want this, we want to keep the current date. To
          // solve this problem we will add a day to our simulation date (to make
          // it Tuesday). Now getPrevOccurence() returns the date we need.

          deductionItemFCDtls.dueDate = new curam.util.type.FrequencyPattern(deductionItemFCDtls.frequency).getPrevOccurrence(
            deductionItemFCDtls.startDate.addDays(1));
        }

        // financial component processing details
        FCProcessingDtls fcProcessingDtls = new FCProcessingDtls();

        fcProcessingDtls.frequencyPattern = deductionItemFCDtls.frequency;
        fcProcessingDtls.deliveryMethod = deductionItemFCDtls.nomineeDelivMethod;
        fcProcessingDtls.dueDate = deductionItemFCDtls.dueDate;
        fcProcessingDtls.coverPeriodOffset = deductionItemFCDtls.coverPeriodOffset;
        fcProcessingDtls.deliveryMethodOffset = deductionItemFCDtls.deliveryMethodOffset;
        fcProcessingDtls.coverPeriodType = deductionItemFCDtls.coverPeriodType;

        // Set next processing date
        maintainFinancialComponentObj.setNextProcessingDate(fcProcessingDtls);

        deductionItemFCDtls.nextProcessingDate = fcProcessingDtls.nextProcessingDate;

        // Set Case Deduction Item ID for use in link table
        deductionItemFCDtls.caseDeductionItemID = caseDeductionItemDtlsList.dtls.item(i).caseDeductionItemID;

        // Add FC to deductions list
        deductionItemFCDtlsList.dtls.addRef(deductionItemFCDtls);

      } // end if (case paid and end date check)
      // END, CR00003905

    }

    return deductionItemFCDtlsList;
  }

  // ___________________________________________________________________________
  /**
   * This method populates the nominee specific information required on the FC.
   *
   * @param deductionItemFCDtls The deduction FC details to be updated.
   */
  protected void setNomineeFCDetails(DeductionItemFinCompDetails deductionItemFCDtls)
    throws AppException, InformationalException {

    // caseNominee entity layer manipulation variables
    curam.core.sl.entity.intf.CaseNominee caseNomineeObj = curam.core.sl.entity.fact.CaseNomineeFactory.newInstance();
    CaseNomineeDtls caseNomineeDtls = new CaseNomineeDtls();
    CaseNomineeKey caseNomineeKey = new CaseNomineeKey();

    // caseNomineeProdDelPattern manipulation variables
    CaseNomineeProdDelPatternDtls caseNomineeProdDelPatternDtls = new CaseNomineeProdDelPatternDtls();
    ReadEffectiveByDateKey readEffectiveByDateKey = new ReadEffectiveByDateKey();

    // deliveryMethod manipulation variables
    DeliveryMethod deliveryMethodObj = DeliveryMethodFactory.newInstance();
    DeliveryMethodKey deliveryMethodKey = new DeliveryMethodKey();
    DeliveryMethodDtls deliveryMethodDtls;

    // productDeliveryPatternInfo manipulation variables
    CachedProductDeliveryPatternInfo cachedProductDeliveryPatternInfoObj = CachedProductDeliveryPatternInfoFactory.newInstance();
    PDPIByProdDelPatIDStatusAndDateKey pdpiByProdDelPatIDStatusAndDateKey = new PDPIByProdDelPatIDStatusAndDateKey();
    ProductDeliveryPatternInfoDtls productDeliveryPatternInfoDtls;

    // BEGIN, CR00280098, AKr
    Date effectiveDate;

    if (Date.getCurrentDate().after(deductionItemFCDtls.startDate)) {
      effectiveDate = Date.getCurrentDate();
    } else {
      effectiveDate = deductionItemFCDtls.startDate;
    }
    // END, CR00280098
    caseNomineeKey.caseNomineeID = deductionItemFCDtls.caseNomineeID;
    caseNomineeDtls = caseNomineeObj.read(caseNomineeKey);

    deductionItemFCDtls.currencyType = caseNomineeDtls.currencyType;

    readEffectiveByDateKey.caseNomineeID = caseNomineeKey.caseNomineeID;
    readEffectiveByDateKey.statusCode = RECORDSTATUS.NORMAL;
    // BEGIN, CR00280098, AKr
    readEffectiveByDateKey.effectiveDate = effectiveDate;
    // END, CR00280098

    // BEGIN, CR00211744, VM
    caseNomineeProdDelPatternDtls = assessmentEngineEntity.getCaseNomineePatternByEffectiveDate(
      readEffectiveByDateKey);
    // END, CR00211744

    // Set up key to read ProductDeliveryPatternInfo
    pdpiByProdDelPatIDStatusAndDateKey.productDeliveryPatternID = caseNomineeProdDelPatternDtls.productDeliveryPatternID;
    pdpiByProdDelPatIDStatusAndDateKey.recordStatus = RECORDSTATUS.NORMAL;

    // BEGIN, CR00280098, AKr
    pdpiByProdDelPatIDStatusAndDateKey.effectiveDate = effectiveDate;
    // END, CR00280098

    // Get the product delivery pattern info
    productDeliveryPatternInfoDtls = cachedProductDeliveryPatternInfoObj.readNearestProdDelPatInfo(
      pdpiByProdDelPatIDStatusAndDateKey);

    // Set the FC delivery pattern details
    deductionItemFCDtls.frequency = productDeliveryPatternInfoDtls.deliveryFrequency;
    deductionItemFCDtls.coverPeriodOffset = productDeliveryPatternInfoDtls.offset;
    deductionItemFCDtls.coverPeriodType = productDeliveryPatternInfoDtls.coverPattern;

    // Set up key to read DeliveryMethod
    deliveryMethodKey.deliveryMethodID = productDeliveryPatternInfoDtls.deliveryMethodID;

    // Get the delivery method details
    deliveryMethodDtls = deliveryMethodObj.read(deliveryMethodKey);

    // Set the FC delivery method details
    deductionItemFCDtls.nomineeDelivMethod = deliveryMethodDtls.name;
    deductionItemFCDtls.deliveryMethodOffset = deliveryMethodDtls.offset;
  }

  // ___________________________________________________________________________
  /**
   * This method will determine the nominee(s) for each case deduction item
   * (CDI), adding additional CDIs as necessary where the deduction applies
   * to multiple nominees over its lifetime.
   *
   * @param caseDeductionItemDtlsList the initial list of case deduction items
   *
   * @return newCaseDeductionItemDtlsList the updated list of CDIs
   */
  protected CaseDeductionItemDtlsList getNomineesForDeductions(
    CaseDeductionItemDtlsList caseDeductionItemDtlsList)
    throws AppException, InformationalException {

    // Variable to hold the full list of case deduction items
    CaseDeductionItemDtlsList newCaseDeductionItemDtlsList = new CaseDeductionItemDtlsList();

    // caseNominee service layer manipulation variables
    // BEGIN, CR00190939, GD
    CaseNomineeObjectiveHistoryKey caseNomineeObjectiveHistoryKey = new CaseNomineeObjectiveHistoryKey();
    CaseNomineeObjectiveHistoryDetailsList caseNomineeObjectiveHistoryDetailsList = new CaseNomineeObjectiveHistoryDetailsList();
    // END, CR00190939
    CaseNominee caseNomineeSLObj = CaseNomineeFactory.newInstance();
    GetNomineeForObjectiveKey getNomineeForObjectiveKey = new GetNomineeForObjectiveKey();
    GetNomineeForObjectiveResult getNomineeForObjectiveResult = new GetNomineeForObjectiveResult();

    // caseNominee entity layer manipulation variables
    curam.core.sl.entity.intf.CaseNominee caseNomineeObj = curam.core.sl.entity.fact.CaseNomineeFactory.newInstance();
    CaseNomineeForCaseDetailsList caseNomineeForCaseDetailsList = new CaseNomineeForCaseDetailsList();
    CaseNomineeForCaseDetails caseNomineeForCaseDetails = new CaseNomineeForCaseDetails();
    CaseNomineeCaseIDKey caseNomineeCaseIDKey = new CaseNomineeCaseIDKey();

    // Loop through the original case deduction items
    for (int i = 0; i < caseDeductionItemDtlsList.dtls.size(); i++) {

      // Get current CDI
      CaseDeductionItemDtls currentCaseDeductionItemDtls = caseDeductionItemDtlsList.dtls.item(
        i);

      // Do we have a rules objective ID?
      if (currentCaseDeductionItemDtls.rulesObjectiveID.length() != 0) {

        // Set key to find nominee(s)
        getNomineeForObjectiveKey.caseID = currentCaseDeductionItemDtls.caseID;
        getNomineeForObjectiveKey.rulesObjectiveID = currentCaseDeductionItemDtls.rulesObjectiveID;
        getNomineeForObjectiveKey.concernRoleID = currentCaseDeductionItemDtls.concernRoleID;
        getNomineeForObjectiveKey.fromDate = currentCaseDeductionItemDtls.startDate;
        getNomineeForObjectiveKey.toDate = currentCaseDeductionItemDtls.endDate;

        // Get the Nominee(s) assigned for the period
        getNomineeForObjectiveResult = caseNomineeSLObj.getNomineeForObjective(
          getNomineeForObjectiveKey);

        // For each assignment we will add a separate CDI
        for (int j = 0; j
          < getNomineeForObjectiveResult.getObjectiveDetailsList.size(); j++) {

          CaseDeductionItemDtls newCaseDeductionItemDtls = new CaseDeductionItemDtls();

          newCaseDeductionItemDtls.assign(currentCaseDeductionItemDtls);
          newCaseDeductionItemDtls.caseNomineeID = getNomineeForObjectiveResult.getObjectiveDetailsList.item(j).caseNomineeID;
          newCaseDeductionItemDtls.startDate = getNomineeForObjectiveResult.getObjectiveDetailsList.item(j).fromDate;
          newCaseDeductionItemDtls.endDate = getNomineeForObjectiveResult.getObjectiveDetailsList.item(j).toDate;

          newCaseDeductionItemDtlsList.dtls.addRef(newCaseDeductionItemDtls);

        } // end for j

      } else {

        // BEGIN, CR00002218, KH
        // Clear list for re-use
        caseNomineeForCaseDetailsList.dtls.clear();
        // END, CR00002218

        // Do we have a case nominee ID?
        if (currentCaseDeductionItemDtls.caseNomineeID != 0) {

          // Add current nominee to nominee list
          caseNomineeForCaseDetails.caseNomineeID = currentCaseDeductionItemDtls.caseNomineeID;

          caseNomineeForCaseDetailsList.dtls.addRef(caseNomineeForCaseDetails);

        } else {

          // Add all nominees to nominee list
          caseNomineeCaseIDKey.caseID = currentCaseDeductionItemDtls.caseID;
          caseNomineeForCaseDetailsList = caseNomineeObj.searchByCaseID(
            caseNomineeCaseIDKey);
        }

        // Loop through all nominees in list
        for (int j = 0; j < caseNomineeForCaseDetailsList.dtls.size(); j++) {

          // BEGIN, CR00190939, GD
          // Set key to find nominee component history
          caseNomineeObjectiveHistoryKey.caseNomineeID = caseNomineeForCaseDetailsList.dtls.item(j).caseNomineeID;
          caseNomineeObjectiveHistoryKey.statusCode = RECORDSTATUS.DEFAULTCODE;

          // Get the nominee history
          caseNomineeObjectiveHistoryDetailsList = caseNomineeSLObj.listCaseNomineeObjectiveHistory(
            caseNomineeObjectiveHistoryKey);

          // For each assignment we will add a separate CDI
          for (int k = 0; k
            < caseNomineeObjectiveHistoryDetailsList.dtls.size(); k++) {
            
            // BEGIN, CR00287427, KH
            // if this assignment ends before the deduction starts we should skip it
            if (!caseNomineeObjectiveHistoryDetailsList.dtls.item(k).toDate.isZero()
              && caseNomineeObjectiveHistoryDetailsList.dtls.item(k).toDate.before(
                currentCaseDeductionItemDtls.startDate)) {
              continue; // skip this assignment
            }
            // END, CR00287427

            // Variable to hold new CDI details
            CaseDeductionItemDtls newCaseDeductionItemDtls = new CaseDeductionItemDtls();

            // Copy over the default details and the nominee ID
            newCaseDeductionItemDtls.assign(currentCaseDeductionItemDtls);
            newCaseDeductionItemDtls.caseNomineeID = caseNomineeForCaseDetailsList.dtls.item(j).caseNomineeID;

            // Only want assignments that are valid
            if (!caseNomineeObjectiveHistoryDetailsList.dtls.item(k).fromDate.isZero()) {

              // Set start and end dates using the component assignment info
              
              // BEGIN, CR00287427, KH
              /*
               * Only change the deduction FC start date if it is earlier than
               * the assignment from date.
               */
              if (newCaseDeductionItemDtls.startDate.before(
                caseNomineeObjectiveHistoryDetailsList.dtls.item(k).fromDate)) {
                newCaseDeductionItemDtls.startDate = caseNomineeObjectiveHistoryDetailsList.dtls.item(k).fromDate;
              }
              
              /*
               * Only change the deduction FC end date if it is later than the
               * assignment to date (and the assignment to date is set).
               */
              if (!caseNomineeObjectiveHistoryDetailsList.dtls.item(k).toDate.isZero()
                && newCaseDeductionItemDtls.endDate.after(
                  caseNomineeObjectiveHistoryDetailsList.dtls.item(k).toDate)) {
                newCaseDeductionItemDtls.endDate = caseNomineeObjectiveHistoryDetailsList.dtls.item(k).toDate;
              }
              // END, CR00287427

              // Add new CDI to list
              newCaseDeductionItemDtlsList.dtls.addRef(newCaseDeductionItemDtls);

            } else if (caseNomineeObjectiveHistoryDetailsList.dtls.item(k).fromCaseStartDateInd
              == true) {
              // END, CR00190939
              // In this situation we are dealing with the default nominee.
              // Since we don't have a specific component to deduct from,
              // we only want one CDI from the deduction start date.

              // Add new CDI to list
              newCaseDeductionItemDtlsList.dtls.addRef(newCaseDeductionItemDtls);

              break; // break out of k loop
            }
          } // end for k
        } // end for j
      }
    } // end for i

    // BEGIN, CR00037209, KH
    // We need to consolidate any overlapping CDI which are for the same nominee
    // and which have been generated from the same original case deduction item

    // Variable to hold the consolidated list of case deduction items
    CaseDeductionItemDtlsList consolidatedCDIList = new CaseDeductionItemDtlsList();

    // Loop through the new case deduction items
    for (int i = 0; i < newCaseDeductionItemDtlsList.dtls.size(); i++) {

      // Get current CDI
      CaseDeductionItemDtls currentCaseDeductionItemDtls = newCaseDeductionItemDtlsList.dtls.item(
        i);

      // This indicates that it is a unique CDI
      boolean uniqueCDI = true;

      // Check each entry in the consolidated CDI list
      for (int j = 0; j < consolidatedCDIList.dtls.size(); j++) {

        // Are the 2 new CDIs from the same original CDI (and for the same nominee)?
        if ((consolidatedCDIList.dtls.item(j).caseDeductionItemID
          == currentCaseDeductionItemDtls.caseDeductionItemID)
            && (consolidatedCDIList.dtls.item(j).caseNomineeID
              == currentCaseDeductionItemDtls.caseNomineeID)) {

          // Yes, it's not unique. We won't add this CDI to our filtered list
          uniqueCDI = false;

          // Instead, we will extend the dates (if necessary)
          if (currentCaseDeductionItemDtls.startDate.before(
            consolidatedCDIList.dtls.item(j).startDate)) {

            consolidatedCDIList.dtls.item(j).startDate = currentCaseDeductionItemDtls.startDate;
          }

          // If the CDI end date is a 'zero date' this is the equivalent of
          // the case end date and therefore cannot be extended further
          if ((!consolidatedCDIList.dtls.item(j).endDate.equals(Date.kZeroDate))
            && (currentCaseDeductionItemDtls.endDate.equals(Date.kZeroDate)
              || (currentCaseDeductionItemDtls.endDate.after(
                consolidatedCDIList.dtls.item(j).endDate)))) {

            consolidatedCDIList.dtls.item(j).endDate = currentCaseDeductionItemDtls.endDate;
          }

          break; // for j
        }
      } // end for j

      // Have we found a unique CDI?
      if (uniqueCDI) {

        // Yes, so add it to our filtered list
        consolidatedCDIList.dtls.addRef(currentCaseDeductionItemDtls);
      }
    } // end for i

    return consolidatedCDIList;
    // END, CR00037209
  }
  
  // BEGIN, CR00369134, KRK
  /**
   * Generates the financial component details for a
   * case deduction item associated with the given case.
   *
   * @param caseDeductionItemID The deduction ID of the case.
   *
   * @return DeductionItemFinCompDetails The details of the deduction FCs.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public DeductionItemFinCompDetails getDeductionFCDetails(
    final CaseDeductionItemID caseDeductionItemID) throws AppException,
      InformationalException {

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();
    final DeductionItemFinCompDetails deductionItemFCDtls = new DeductionItemFinCompDetails();
    final CaseDeductionItemKey caseDeductionItemKey = new CaseDeductionItemKey();

    caseDeductionItemKey.caseDeductionItemID = caseDeductionItemID.caseDeductionItemID;

    final CaseDeductionItemDtls caseDeductionItemDtls = CaseDeductionItemFactory.newInstance().read(
      caseDeductionItemKey);

    caseHeaderKey.caseID = caseDeductionItemDtls.caseID;

    final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();

    productDeliveryKey.caseID = caseHeaderKey.caseID;
    final ProductDeliveryDtls productDeliveryDtls = CachedProductDeliveryFactory.newInstance().read(
      productDeliveryKey);

    final ProductKey productKey = new ProductKey();

    productKey.productID = productDeliveryDtls.productID;

    final ProductDtls productDtls = CachedProductFactory.newInstance().read(
      productKey);

    final CaseHeaderDtls caseHeaderDtls = CachedCaseHeaderFactory.newInstance().read(
      caseHeaderKey);

    deductionItemFCDtls.adjustmentInd = false;
    deductionItemFCDtls.caseDecisionID = 0;
    deductionItemFCDtls.caseID = caseDeductionItemDtls.caseID;
    deductionItemFCDtls.caseType = caseHeaderDtls.caseTypeCode;
    deductionItemFCDtls.componentCategory = FINCOMPONENTCATEGORY.CASEDEDUCTIONITEM;
    deductionItemFCDtls.componentType = FINCOMPONENTTYPE.DEDUCTIONPAYMENT;
    deductionItemFCDtls.fundID = productDtls.fundID;
    deductionItemFCDtls.primaryClientID = caseHeaderDtls.concernRoleID;
    deductionItemFCDtls.productID = productDtls.productID;
    deductionItemFCDtls.inRespectOfID = caseHeaderDtls.concernRoleID;
    deductionItemFCDtls.amount = caseDeductionItemDtls.amount;
    deductionItemFCDtls.caseNomineeID = caseDeductionItemDtls.caseNomineeID;
    deductionItemFCDtls.concernRoleID = caseDeductionItemDtls.concernRoleID;
    deductionItemFCDtls.rate = caseDeductionItemDtls.rate;
    deductionItemFCDtls.rulesObjectiveID = caseDeductionItemDtls.rulesObjectiveID;
    deductionItemFCDtls.startDate = caseDeductionItemDtls.startDate;
    deductionItemFCDtls.endDate = caseDeductionItemDtls.endDate;

    setNomineeFCDetails(deductionItemFCDtls);

    if ((deductionItemFCDtls.coverPeriodType.equals(
      curam.codetable.PRODUCTCOVERPERIOD.ISSUEINARREARS))
        || (deductionItemFCDtls.coverPeriodType.equals(
          curam.codetable.PRODUCTCOVERPERIOD.ISSUEINARREARSDAYOFFSET))) {

      deductionItemFCDtls.dueDate = new curam.util.type.FrequencyPattern(deductionItemFCDtls.frequency).getNextOccurrence(
        deductionItemFCDtls.startDate);

    } else {
      deductionItemFCDtls.dueDate = new curam.util.type.FrequencyPattern(deductionItemFCDtls.frequency).getPrevOccurrence(
        deductionItemFCDtls.startDate.addDays(1));
    }

    final FCProcessingDtls fcProcessingDtls = new FCProcessingDtls();

    fcProcessingDtls.frequencyPattern = deductionItemFCDtls.frequency;
    fcProcessingDtls.deliveryMethod = deductionItemFCDtls.nomineeDelivMethod;
    fcProcessingDtls.dueDate = deductionItemFCDtls.dueDate;
    fcProcessingDtls.coverPeriodOffset = deductionItemFCDtls.coverPeriodOffset;
    fcProcessingDtls.deliveryMethodOffset = deductionItemFCDtls.deliveryMethodOffset;
    fcProcessingDtls.coverPeriodType = deductionItemFCDtls.coverPeriodType;

    MaintainFinancialComponentFactory.newInstance().setNextProcessingDate(
      fcProcessingDtls);

    deductionItemFCDtls.nextProcessingDate = fcProcessingDtls.nextProcessingDate;

    deductionItemFCDtls.caseDeductionItemID = caseDeductionItemDtls.caseDeductionItemID;

    return deductionItemFCDtls;
  }
  // END, CR00369134

}
