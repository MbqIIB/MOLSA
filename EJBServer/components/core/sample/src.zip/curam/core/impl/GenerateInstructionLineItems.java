/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import java.util.StringTokenizer;

import com.google.inject.Inject;

import curam.codetable.BATCHPROCESSNAME;
import curam.codetable.FINCOMPONENTSTATUS;
import curam.core.fact.FinancialComponentFactory;
import curam.core.fact.GenerateInstructionLineItemsStreamFactory;
import curam.core.sl.infrastructure.assessment.impl.DeterminationCalculatorFactory;
import curam.core.sl.infrastructure.propagator.impl.CERMetaDataLoadUtility;
import curam.core.struct.BatchProcessChunkDtlsList;
import curam.core.struct.BatchProcessDtls;
import curam.core.struct.BatchProcessingIDList;
import curam.core.struct.ChunkMainParameters;
import curam.core.struct.ExclusionDtlsList;
import curam.core.struct.FinCalendarDeliveryMethod;
import curam.core.struct.GenILIsProcessChunkResult;
import curam.core.struct.GenerateInstructionLineItemsKey;
import curam.core.struct.GetDateRangeForFCRetrievalKey;
import curam.core.struct.GetDateRangeForFCRetrievalResult;
import curam.core.struct.GetDetailsForGenerateILIsKey;
import curam.piwrapper.caseheader.impl.ProductDeliveryDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.ProgramLocale;
import curam.util.type.Date;


/**
 * Batch module to identify Financial Components to process.
 *
 */
public abstract class GenerateInstructionLineItems extends curam.core.base.GenerateInstructionLineItems {

  /**
   * The initial value used for the keySet used for the chunks
   */
  protected static final int kFirstKeyValue = 1;

  /*
   * NB class member variables for these environment variables enable the
   * running of batch processing with different configurations within a single
   * test suite
   */
  protected final int kChunkSize;

  protected final boolean kDontRunStream;

  protected final int kChunkKeyReadWait;

  protected final int kUnProcessedChunkReadWait;

  protected final boolean kProcessUnProcessedChunks;

  @Inject
  protected DeterminationCalculatorFactory determinationCalculatorFactory;

  @Inject
  protected ProductDeliveryDAO productDeliveryDAO;

  // ___________________________________________________________________________
  /**
   * Constructor.
   */
  public GenerateInstructionLineItems() {
    GuiceWrapper.getInjector().injectMembers(this);

    /**
     * Look up the environment variables used to control the processing
     */

    // Get the value of the GENILIs Chunk Size environment variable
    final String chunkSize = Configuration.getProperty(
      EnvVars.ENV_GENERATEINSTRUCTIONLINEITEMS_CHUNK_SIZE);

    // If it's not set, use the default
    if (chunkSize == null) {

      kChunkSize = EnvVars.ENV_GENERATEINSTRUCTIONLINEITEMS_CHUNK_SIZE_DEFAULT;

    } else {

      // Convert string value to integer
      kChunkSize = Integer.parseInt(chunkSize);

    }

    // Get the value of the GENILIs Don't Run Stream environment
    // variable
    kDontRunStream = Configuration.getBooleanProperty(
      EnvVars.ENV_GENERATEINSTRUCTIONLINEITEMS_DONT_RUN_STREAM);

    // Get the value of the GENILIs Chunk Key read wait environment
    // variable
    final String chunkKeyReadWait = Configuration.getProperty(
      EnvVars.ENV_GENERATEINSTRUCTIONLINEITEMS_CHUNK_KEY_WAIT_INTERVAL);

    // If it's not set, use the default
    if (chunkKeyReadWait == null) {

      kChunkKeyReadWait = EnvVars.ENV_GENERATEINSTRUCTIONLINEITEMS_CHUNK_KEY_WAIT_INTERVAL_DEFAULT;

    } else {

      // Convert string value to integer
      kChunkKeyReadWait = Integer.parseInt(chunkKeyReadWait);

    }

    /*
     * Get the value of the GENILIs UnProcessed Chunk read wait environment
     * variable
     */
    final String unProcessedChunkReadWait = Configuration.getProperty(
      EnvVars.ENV_GENERATEINSTRUCTIONLINEITEMS_UNPROCESSED_CHUNK_WAIT_INTERVAL);

    // If it's not set, use the default
    if (unProcessedChunkReadWait == null) {

      kUnProcessedChunkReadWait = EnvVars.ENV_GENERATEINSTRUCTIONLINEITEMS_UNPROCESSED_CHUNK_WAIT_INTERVAL_DEFAULT;

    } else {

      // Convert string value to integer
      kUnProcessedChunkReadWait = Integer.parseInt(unProcessedChunkReadWait);

    }

    /*
     * Get the value of the GENILIs process unprocessed Chunks environment
     * variable
     */
    kProcessUnProcessedChunks = Configuration.getBooleanProperty(
      EnvVars.ENV_GENERATEINSTRUCTIONLINEITEMS_PROCESS_UNPROCESSED_CHUNKS);

  }

  // ___________________________________________________________________________
  /**
   * To identify and process each Financial Component of a particular
   * deliveryMethod that reaches its due date within the specified time period.
   *
   * @param generateInstructionLineItemsKey
   * financial component processing date range, delivery method type
   * and product
   */
  public void processAllFinancialComponentsDue(
    final GenerateInstructionLineItemsKey generateInstructionLineItemsKey)
    throws AppException, InformationalException {

    // BEGIN, CR00390475, SD
    final CERMetaDataLoadUtility loadObj = new CERMetaDataLoadUtility();

    loadObj.loadCERRuleSetCache();
    // END, CR00390475
    
    final BatchStreamHelper batchStreamHelper = new BatchStreamHelper();
    final ChunkMainParameters chunkMainParameters = new ChunkMainParameters();
    final curam.core.intf.GenerateInstructionLineItemsStream generateInstructionLineItemsStreamObj = GenerateInstructionLineItemsStreamFactory.newInstance();
    final GenerateInstructionLineItemsStreamWrapper generateInstructionLineItemsStreamWrapper = new GenerateInstructionLineItemsStreamWrapper(
      generateInstructionLineItemsStreamObj);
    final GenerateinstructionLineItemsWrapper generateinstructionLineItemsWrapper = new GenerateinstructionLineItemsWrapper(
      this);

    // Set the start time of the program
    batchStreamHelper.setStartTime();

    // BEGIN, CR00180684, VM
    final BatchProcessingIDList batchProcessingIDList = getCaseListForProcessing(
      generateInstructionLineItemsKey);

    // END, CR00180684

    chunkMainParameters.chunkSize = kChunkSize;
    chunkMainParameters.dontRunStream = kDontRunStream;
    chunkMainParameters.processUnProcessedChunks = kProcessUnProcessedChunks;
    chunkMainParameters.startChunkKey = kFirstKeyValue;
    chunkMainParameters.unProcessedChunkReadWait = kUnProcessedChunkReadWait;

    batchStreamHelper.runChunkMain(generateInstructionLineItemsKey.instanceID,
      generateInstructionLineItemsKey, generateinstructionLineItemsWrapper,
      batchProcessingIDList, chunkMainParameters,
      generateInstructionLineItemsStreamWrapper);
  }

  // ___________________________________________________________________________
  /**
   * This method composes and sends the batch report for this batch program.
   *
   * @param instanceID
   * @param batchProcessDtls
   * @param processedBatchProcessChunkDtlsList
   * @param unprocessedBatchProcessChunkDtlsList
   */
  public void sendBatchReport(final String instanceID,
    final BatchProcessDtls batchProcessDtls,
    final BatchProcessChunkDtlsList processedBatchProcessChunkDtlsList,
    final BatchProcessChunkDtlsList unprocessedBatchProcessChunkDtlsList)
    throws AppException, InformationalException {

    long totalNumberOfCasesProcessed = 0;
    long totalNumberOfCasesSkipped = 0;
    long totalNumberOfFCsProcessed = 0;
    long totalNumberOfILIsGenerated = 0;
    final long totalNumberOfUnprocessedChunks = unprocessedBatchProcessChunkDtlsList.dtls.size();

    GenILIsProcessChunkResult genILIsProcessChunkResult;

    // curamBatch manipulation variable
    final curam.core.impl.CuramBatch curamBatchObj = new curam.core.impl.CuramBatch();

    // the StringBuffer size is based on the data being written to
    // to the buffer
    final int kEmailMessageBufSize = 512;
    final StringBuffer emailMessage = new StringBuffer(kEmailMessageBufSize);

    // For each processed chunk, gather the stats
    for (int i = 0; i < processedBatchProcessChunkDtlsList.dtls.size(); i++) {

      genILIsProcessChunkResult = decodeProcessChunkResult(
        processedBatchProcessChunkDtlsList.dtls.item(i).resultSummary);
      totalNumberOfCasesProcessed += genILIsProcessChunkResult.caseProcessCount;
      totalNumberOfCasesSkipped += genILIsProcessChunkResult.casesSkippedCount;
      totalNumberOfFCsProcessed += genILIsProcessChunkResult.fcProcessCount;
      totalNumberOfILIsGenerated += genILIsProcessChunkResult.iliCreatedCount;

    }

    if (totalNumberOfUnprocessedChunks > 0) {

      final AppException errChunksSkippedText = new AppException(
        curam.message.BPOGENERATEINSTRUCTIONLINEITEMS.ERR_CHUNKS_SKIPPED);

      errChunksSkippedText.arg(totalNumberOfUnprocessedChunks);
      errChunksSkippedText.arg(totalNumberOfUnprocessedChunks * kChunkSize);

      // BEGIN, CR00163236, CL
      // append to StringBuffer
      emailMessage.append(CuramConst.gkNewLine).append(errChunksSkippedText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
        CuramConst.gkNewLine);
      // END, CR00163236

    }

    // Create the text strings to send to the email report
    final AppException infTotalCasesText = new AppException(
      curam.message.BPOGENERATEINSTRUCTIONLINEITEMS.INF_CASE_RECORDS_PROCESSED);

    infTotalCasesText.arg(totalNumberOfCasesProcessed);

    // BEGIN, CR00163236, CL
    // append to StringBuffer
    emailMessage.append(CuramConst.gkNewLine).append(infTotalCasesText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    if (totalNumberOfCasesSkipped > 0) {

      final AppException infTotalSkippedCasesText = new AppException(
        curam.message.BPOGENERATEINSTRUCTIONLINEITEMS.INF_CASE_RECORDS_SKIPPED);

      infTotalSkippedCasesText.arg(totalNumberOfCasesSkipped);

      // BEGIN, CR00163236, CL
      // append to StringBuffer
      emailMessage.append(CuramConst.gkNewLine).append(infTotalSkippedCasesText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
        CuramConst.gkNewLine);
      // END, CR00163236

    }

    final AppException infTotalFCText = new AppException(
      curam.message.BPOGENERATEINSTRUCTIONLINEITEMS.INF_FC_RECORDS_PROCESSED);

    infTotalFCText.arg(totalNumberOfFCsProcessed);

    // BEGIN, CR00163236, CL
    // append to StringBuffer
    emailMessage.append(CuramConst.gkNewLine).append(infTotalFCText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    final AppException infTotalILIText = new AppException(
      curam.message.BPOGENERATEINSTRUCTIONLINEITEMS.INF_ILI_RECORDS_CREATED);

    infTotalILIText.arg(totalNumberOfILIsGenerated);

    // BEGIN, CR00163236, CL
    // append to StringBuffer
    emailMessage.append(CuramConst.gkNewLine).append(infTotalILIText.getMessage(ProgramLocale.getDefaultServerLocale())).append(
      CuramConst.gkNewLine);
    // END, CR00163236

    curamBatchObj.emailMessage = emailMessage.toString();

    // constructing the Email Subject
    curamBatchObj.setEmailSubject(
      curam.message.BPOGENERATEINSTRUCTIONLINEITEMS.INF_GENERATEILI_SUB);

    // set output file id
    curamBatchObj.outputFileID = // BEGIN, CR00163471, JC
      curam.message.BPOGENERATEINSTRUCTIONLINEITEMS.INF_GENERATE_ILIS.getMessageText(
      ProgramLocale.getDefaultServerLocale());
    // END, CR00163471, JC

    // set the elapsed time
    curamBatchObj.setStartTime(batchProcessDtls.startDateTime);
    curamBatchObj.setEndTime();

    // send email
    curamBatchObj.sendEmail();
  }

  // ___________________________________________________________________________
  /**
   * This method takes string form of the result of the processing and turns it
   * back into a struct
   *
   * @param resultString
   * The results as a string
   *
   * @return The struct form of the results
   */
  public GenILIsProcessChunkResult decodeProcessChunkResult(
    final String resultString) {

    final GenILIsProcessChunkResult genILIsProcessChunkResult = new GenILIsProcessChunkResult();
    final StringTokenizer st = new StringTokenizer(resultString);
    int elementNumber = 0;

    while (st.hasMoreTokens()) {

      elementNumber++;
      switch (elementNumber) {
      case 1:
        genILIsProcessChunkResult.caseProcessCount = Integer.parseInt(
          st.nextToken());
        break;

      case 2:
        genILIsProcessChunkResult.casesSkippedCount = Integer.parseInt(
          st.nextToken());
        break;

      case 3:
        genILIsProcessChunkResult.fcProcessCount = Integer.parseInt(
          st.nextToken());
        break;

      case 4:
        genILIsProcessChunkResult.iliCreatedCount = Integer.parseInt(
          st.nextToken());
        break;

      default:
        st.nextToken();
        break;
      }

    }

    return genILIsProcessChunkResult;
  }

  // ___________________________________________________________________________
  /**
   * Find the extreme date range over which Financial Components must be
   * searched on for the GenerateInstructionLineItems batch process.
   *
   * @param getDateRangeForFCRetrievalKey
   * Contains the parameters specified for the batch process
   *
   * @return Date range, calculated based on the exclusion dates for all
   * delivery methods, over which FCs must be searched on
   */
  public GetDateRangeForFCRetrievalResult getDateRangeForFCRetrieval(
    final GetDateRangeForFCRetrievalKey getDateRangeForFCRetrievalKey)
    throws AppException, InformationalException {

    // MaintainFinancialCalendar business objects
    final curam.core.intf.MaintainFinancialCalendar maintainFinancialCalendarObj = curam.core.fact.MaintainFinancialCalendarFactory.newInstance();
    final GetDateRangeForFCRetrievalResult getDateRangeForFCRetrievalResult = new GetDateRangeForFCRetrievalResult();

    ExclusionDtlsList exclusionDtlsList = new ExclusionDtlsList();

    /*
     * If a delivery method has been entered we only want to get the exclusion
     * dates for that particular method
     */
    if (getDateRangeForFCRetrievalKey.deliveryMethod.length() == 0) {

      // Retrieve date range across all methods
      exclusionDtlsList = maintainFinancialCalendarObj.getExclusionDatesForAllMethods();

    } else {
      // Retrieve date range for a specific method
      final FinCalendarDeliveryMethod finCalendarDeliveryMethod = new FinCalendarDeliveryMethod();

      finCalendarDeliveryMethod.deliveryMethodType = getDateRangeForFCRetrievalKey.deliveryMethod;
      exclusionDtlsList = maintainFinancialCalendarObj.getExclusionDates(
        finCalendarDeliveryMethod);
    }

    if (!exclusionDtlsList.dtls.isEmpty()) {

      final int lastRecordPos = exclusionDtlsList.dtls.size() - 1;

      getDateRangeForFCRetrievalResult.dateFrom = exclusionDtlsList.dtls.item(0).exclusionDate;

      getDateRangeForFCRetrievalResult.dateTo = exclusionDtlsList.dtls.item(lastRecordPos).exclusionDate;
    }

    // If there were no exclusion dates specified
    if (getDateRangeForFCRetrievalResult.dateFrom.isZero()
      && getDateRangeForFCRetrievalResult.dateTo.isZero()) {

      if (!getDateRangeForFCRetrievalKey.dateFrom.after(
        getDateRangeForFCRetrievalKey.dateTo)) {

        getDateRangeForFCRetrievalResult.dateFrom = getDateRangeForFCRetrievalKey.dateFrom;
        getDateRangeForFCRetrievalResult.dateTo = getDateRangeForFCRetrievalKey.dateTo;
      }

    } else { // if exclusion dates exist, need to find the
      // extremities

      // Find earliest from date
      if (getDateRangeForFCRetrievalResult.dateFrom.after(
        getDateRangeForFCRetrievalKey.dateFrom)) {

        getDateRangeForFCRetrievalResult.dateFrom = getDateRangeForFCRetrievalKey.dateFrom;
      }

      // Find latest to date
      if (getDateRangeForFCRetrievalResult.dateTo.before(
        getDateRangeForFCRetrievalKey.dateTo)) {

        getDateRangeForFCRetrievalResult.dateTo = getDateRangeForFCRetrievalKey.dateTo;
      }

    }

    return getDateRangeForFCRetrievalResult;
  }

  // BEGIN, CR00180684, VM
  // ___________________________________________________________________________
  /**
   * Retrieves the list of cases for which instruction line items needs to be
   * generated.
   *
   * @param key
   * - Contains the delivery method and product identifier
   */
  public BatchProcessingIDList getCaseListForProcessing(
    final GenerateInstructionLineItemsKey key) throws AppException,
      InformationalException {

    final GetDetailsForGenerateILIsKey getDetailsForGenerateILIsKey = new GetDetailsForGenerateILIsKey();

    final GetDateRangeForFCRetrievalKey getDateRangeForFCRetrievalKey = new GetDateRangeForFCRetrievalKey();

    if (key.instanceID.length() == 0) {
      key.instanceID = BATCHPROCESSNAME.GENERATE_ILIS;
    }

    setProcessingDates(key);

    // Set key to retrieve date range to search for FCs
    getDateRangeForFCRetrievalKey.dateFrom = key.processingDateFrom;
    getDateRangeForFCRetrievalKey.dateTo = key.processingDateTo;
    getDateRangeForFCRetrievalKey.deliveryMethod = key.deliveryMethod;

    // Call local method to retrieve the date range
    final GetDateRangeForFCRetrievalResult result = getDateRangeForFCRetrieval(
      getDateRangeForFCRetrievalKey);

    // Identify the records to process
    getDetailsForGenerateILIsKey.processingDateFrom = result.dateFrom;
    getDetailsForGenerateILIsKey.processingDateTo = result.dateTo;
    getDetailsForGenerateILIsKey.deliveryMethod = key.deliveryMethod;
    getDetailsForGenerateILIsKey.productID = key.productID;
    getDetailsForGenerateILIsKey.statusCode = FINCOMPONENTSTATUS.LIVE;

    final BatchProcessingIDList batchProcessingIDList = FinancialComponentFactory.newInstance().getDetailsForGenerateILIs(
      getDetailsForGenerateILIsKey);

    return batchProcessingIDList;
  }

  // ___________________________________________________________________________
  /**
   * Sets the processingDateFrom and processingDateTo for retrieving the cases
   * to process.
   *
   * @param key
   * - Contains the delivery method and product identifier
   */
  public void setProcessingDates(final GenerateInstructionLineItemsKey key)
    throws AppException, InformationalException {

    // If no processingDateTo is specified use the current date
    if (key.processingDateTo.isZero()) {
      key.processingDateTo = Date.getCurrentDate();
    }

    /*
     * Check if the processingDate is before the processingDateTo and do not
     * process anything later than processingDate
     */
    if (!key.processingDateTo.isZero() && !key.processingDate.isZero()
      && key.processingDate.before(key.processingDateTo)) {
      key.processingDateTo = key.processingDate;
    }

    /*
     * If processingDateFrom specified is later than processingDateTo, force the
     * processingDateFrom to be a zero date.
     */
    if (!key.processingDateFrom.isZero()
      && key.processingDateFrom.after(key.processingDateTo)) {
      key.processingDateFrom = Date.kZeroDate;
    }
  }
  // END, CR00180684
}
