/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2003-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

/**
 * Functions for manipulating CaseRelationship entity.
 */

package curam.core.impl;


import curam.core.struct.CaseIDRelatedCaseID;
import curam.core.struct.CaseIDs;
import curam.core.struct.CaseRelationshipDtlsList;
import curam.core.struct.CountCaseRelationshipsKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


public abstract class CaseRelationship extends curam.core.base.CaseRelationship {

  // ___________________________________________________________________________
  /**
   * Determines whether the input ID field will be converted to a NULL value
   * for use in SQL and sets the indicator field accordingly.
   * This avoids the need for database-specific CAST statements in the
   * generated SQL.
   *
   * @param key the key struct used for the read
   */
  protected void precountRelatedCasesByRelatedCaseID(CountCaseRelationshipsKey key)
    throws AppException, InformationalException {
    key.caseRelationshipIDIsNull = (key.caseRelationshipID == 0);
  }

  // BEGIN, CR00092334, VM
  // ___________________________________________________________________________
  /**
   * Retrieves a list of Case Relationship records where the caseID
   * <code>key.caseID</code> is related to the caseID
   * <code>key.relatedCaseID</code>.
   *
   * @param key Contains a caseID and relatedCaseID
   * @return Case Relationship entity dtls list
   */
  public CaseRelationshipDtlsList searchByCaseIDRelatedCaseID(CaseIDs key)
    throws AppException, InformationalException {

    // Return object
    CaseRelationshipDtlsList caseRelationshipDtlsList =
      new CaseRelationshipDtlsList();

    CaseIDRelatedCaseID caseIDRelatedCaseID = new CaseIDRelatedCaseID();

    // Set key for first read
    caseIDRelatedCaseID.caseID = key.caseID;
    caseIDRelatedCaseID.relatedCaseID = key.relatedCaseID;

    CaseRelationshipDtlsList firstList =
      searchByCaseIDRelatedCaseID(caseIDRelatedCaseID);

    // Set key for second read
    caseIDRelatedCaseID.relatedCaseID = key.caseID;
    caseIDRelatedCaseID.caseID = key.relatedCaseID;

    CaseRelationshipDtlsList secondList =
      searchByCaseIDRelatedCaseID(caseIDRelatedCaseID);

    caseRelationshipDtlsList.dtls.addAll(firstList.dtls);
    caseRelationshipDtlsList.dtls.addAll(secondList.dtls);

    return caseRelationshipDtlsList;
  }
  // END, CR00092334

}
