/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2002-2005, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.BatchConsolidationRetDtls;
import curam.core.struct.BatchProcessingDate;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.ProgramLocale;
import curam.util.transaction.TransactionInfo;


/**
 * Code for batch consolidation.
 *
 */
public abstract class ConsolidationProcess extends curam.core.base.ConsolidationProcess {

  // ___________________________________________________________________________
  /**
   * This process is used for batch consolidation of an insurance return. This
   * process takes a processing date.
   *
   * @param batchProcessingDate The business date for which the batch process
   *                            will be run. If this is set, this is the date
   *                            that will be returned by 'getCurrentDate'.
   *
   */
  public void batchConsolidation(BatchProcessingDate batchProcessingDate)
    throws AppException, InformationalException {

    // curamBatch object
    curam.core.impl.CuramBatch curamBatchObj = new curam.core.impl.CuramBatch();

    // processConsolidation manipulation variables
    curam.core.intf.ProcessConsolidation processConsolidationObj =
      curam.core.fact.ProcessConsolidationFactory.newInstance();
    BatchConsolidationRetDtls batchConsolidationRetDtls;

    // BEGIN, CR00070532, "PA"

    /* curam.core.intf.FormatDate formatDateObj =
     FormatDateAsStringDtls formatDateAsStringDtls; */
    
    // END, CR00070532
    // the buffer length is based on the max length that it can be
    final int kStringBufSize = 1024;
    StringBuffer emailMessage = new StringBuffer(kStringBufSize);

    // timing info
    curam.util.type.DateTime startTime;
    curam.util.type.DateTime endTime;
    curam.util.type.DateTime elapsedTime;

    // register the security implementation
    SecurityImplementationFactory.register();

    // set start time for batch logging
    startTime = curam.util.transaction.TransactionInfo.getSystemDateTime();

    batchConsolidationRetDtls =
      processConsolidationObj.readRecordsForConsolidation();

    // set end time for batch logging
    endTime = curam.util.transaction.TransactionInfo.getSystemDateTime();

    // find elapsed time
    elapsedTime =
      new curam.util.type.DateTime((endTime.asLong() - startTime.asLong()));

    // create the text strings to send to the email report
    AppException runtimeText =
      new AppException(curam.message.GENERALBATCH.INF_JOB_RUNTIME);

    // BEGIN, CR00070532, "PA"
    
    // BEGIN, CR00086110, POB
    // Format Start Time
    
    /* formatDateAsStringKey.inputDate = startTime;

     // format elapsed time
     runtimeText.arg(Locale.getFormattedTime(elapsedTime));
     // END, CR00086110
     
     runtimeText.arg(formatDateAsStringDtls.stringDate);*/
    
    // set runtime text
    runtimeText.arg(
      startTime.toString() + CuramConst.gkSpace
      + TransactionInfo.getServerTimeZone().getID());
    
    // append date to runtime text
    runtimeText.arg(
      elapsedTime.toString() + CuramConst.gkSpace
      + TransactionInfo.getServerTimeZone().getID());
    
    // END, CR00070532
    
    // BEGIN, CR00163236, CL
    emailMessage.append(CuramConst.gkNewLine).append(runtimeText.getMessage(ProgramLocale.getDefaultServerLocale()))
      .append(
      CuramConst.gkNewLine);
    // END, CR00163236

    // number of records read
    AppException numRecords =
      new AppException(
        curam.message.BPOCONSOLIDATIONPROCESS.INF_TOTAL_RECORDS_READ);

    numRecords.arg(batchConsolidationRetDtls.recordsReadTotal);
    // BEGIN, CR00163236, CL
    String result = numRecords.getMessage(ProgramLocale.getDefaultServerLocale());
    // END, CR00163236

    emailMessage.append(CuramConst.gkNewLine).append(result).append(
      CuramConst.gkNewLine);

    // number of consolidations performed
    AppException numConsolidation =
      new AppException(
        curam.message.BPOCONSOLIDATIONPROCESS.INF_TOTAL_CONSOLIDATIONS_PERFORMED);

    numConsolidation.arg(batchConsolidationRetDtls.consolidationTotal);
    // BEGIN, CR00163236, CL
    String consolResult = numConsolidation.getMessage(ProgramLocale.getDefaultServerLocale());
    // END, CR00163236

    emailMessage.append(CuramConst.gkNewLine).append(consolResult).append(
      CuramConst.gkNewLine);

    // set emailMessage for sending mail
    curamBatchObj.emailMessage = emailMessage.toString();

    // constructing the Email Subject
    curamBatchObj.setEmailSubject(
      curam.message.BPOCONSOLIDATIONPROCESS.INF_CONSOLIDATEINSURANCERETURNS_SUB);

    // set output file id
    curamBatchObj.outputFileID =
      //BEGIN, CR00163471, JC
      curam.message.BPOCONSOLIDATIONPROCESS.INF_CONSOL_INS_RETURN.getMessageText(ProgramLocale.getDefaultServerLocale());
      //END, CR00163471, JC

    // send mail
    curamBatchObj.sendEmail();
  }

}
