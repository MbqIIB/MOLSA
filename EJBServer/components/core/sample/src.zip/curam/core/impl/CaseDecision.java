/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2004, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.fact.CaseDecisionFactory;
import curam.core.struct.CaseDecisionDtls;
import curam.core.struct.CaseID;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * This process class provides the functionality for the Case Decision entity.
 */
public abstract class CaseDecision extends curam.core.base.CaseDecision {

  // ___________________________________________________________________________
  /**
   * This method processes a Case Decision record post eligibility.
   *
   * @param key case decision details.
   *
   */
  public void postEligibility(CaseDecisionDtls key)
    throws AppException, InformationalException {
    /**
     * This method will allow any required custom processing with Case Decision
     * details after they have been stored as part of determine eligibility
     * processing.
     *
     * It is only called from real product delivery eligibility processing.
     *
     * This method is called from the core store method in the
     * ManipulateCaseDecisions class.
     *
     */
  }

  // ___________________________________________________________________________
  /**
   * This method processes a Case post eligibility.
   *
   * @param key case ID.
   *
   */
  public void processActiveDecisions(CaseID key)
    throws AppException, InformationalException {
    /**
     * This method will allow any required custom processing with a Case ID
     * after they have been stored as part of determine eligibility
     * processing.
     *
     * It is only called from real product delivery eligibility processing.
     *
     * This method is called from the core store method in the
     * ManipulateCaseDecisions class.
     *
     */
  }

  // BEGIN, CR00220728, KH
  // ___________________________________________________________________________
  /**
   * Sets the creation date on the case decision record being inserted.
   */
  @Override
  protected void preinsert(CaseDecisionDtls details) 
    throws AppException, InformationalException {

    details.creationDate = TransactionInfo.getSystemDate();
  }
  // END, CR00220728

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readNearestFromDate
   */
  public curam.core.struct.NearestDecisionDateDetails getNearestFromDate(curam.core.struct.NearestDecisionDateKey nearestDecisionDateKey) throws curam.util.exception.AppException, curam.util.exception.InformationalException {
    return CaseDecisionFactory.newInstance().readNearestFromDate(
      nearestDecisionDateKey);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by readNearestToDate
   */
  public curam.core.struct.NearestDecisionDateDetails getNearestToDate(curam.core.struct.NearestDecisionDateKey nearestDecisionDateKey) throws curam.util.exception.AppException, curam.util.exception.InformationalException {
    return CaseDecisionFactory.newInstance().readNearestToDate(
      nearestDecisionDateKey);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchByCaseDecisionSetInstanceID
   */
  public curam.core.struct.CaseDecisionDtlsList listByCaseDecisionSetInstanceID(curam.core.sl.entity.struct.CaseDecisionSetInstanceIDKey key) throws curam.util.exception.AppException, curam.util.exception.InformationalException {
    return CaseDecisionFactory.newInstance().searchByCaseDecisionSetInstanceID(
      key);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchByCaseIDStatus
   */
  public curam.core.struct.CaseDecisionKeyList listByCaseIDStatus(curam.core.struct.CaseIDStatusKey key) throws curam.util.exception.AppException, curam.util.exception.InformationalException {
    return CaseDecisionFactory.newInstance().searchByCaseIDStatus(key);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchDecisionsInActiveSet
   */
  public curam.core.struct.CaseDecisionKeyList listDecisionsInActiveSet(curam.core.struct.CaseIDStatusKey key) throws curam.util.exception.AppException, curam.util.exception.InformationalException {
    return CaseDecisionFactory.newInstance().searchDecisionsInActiveSet(key);
  }

  // ___________________________________________________________________________
  /**
   * @superseded - replaced by searchByParentCase
   */
  public curam.core.struct.CaseDecisionIDEffectiveDateList listByParentCase(curam.core.struct.CaseIDStatusKey key) throws curam.util.exception.AppException, curam.util.exception.InformationalException {
    return CaseDecisionFactory.newInstance().searchByParentCase(key);
  }

}
