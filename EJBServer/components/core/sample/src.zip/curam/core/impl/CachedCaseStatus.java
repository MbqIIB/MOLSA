/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2002-2005, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.core.struct.CaseStatusDetailsList;
import curam.core.struct.CaseStatusDtlsList;
import curam.core.struct.CaseStatusSearchByCaseIDKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.transaction.TransactionInfo.TransactionType;


/**
 * @see curam.core.intf.CachedCaseStatus 
 */
public abstract class CachedCaseStatus extends curam.core.base.CachedCaseStatus {

  // Globals used to store the cached record
  protected static ThreadLocal cachedCaseStatusDtls = new ThreadLocal();

  // static to indicate if caching is enabled
  public static final boolean cachingEnabled;

  // ___________________________________________________________________________
  // static to hold the cachingEnabled environment variable
  static {

    cachingEnabled = curam.util.resources.Configuration.getBooleanProperty(
      EnvVars.ENV_BATCH_CACHING_ENABLED);
  }

  // ___________________________________________________________________________
  /**
   * class to hold the cached CaseStatusDtlsCacheRecord
   */
  protected class CaseStatusDtlsCacheRecord {
    int transactionID = 0;
    long caseID = 0;
    CaseStatusDtlsList caseStatusDtlsList = new CaseStatusDtlsList();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseStatusDetailsList searchByCaseID(CaseStatusSearchByCaseIDKey key)
    throws AppException, InformationalException {

    // return value
    CaseStatusDetailsList caseStatusDetailsListRet = new CaseStatusDetailsList();

    CaseStatusDtlsCacheRecord caseStatusDtlsCacheRecord = (CaseStatusDtlsCacheRecord) cachedCaseStatusDtls.get();

    TransactionType transactionType = curam.util.transaction.TransactionInfo.getTransactionType();

    boolean reloadCache = true;

    if (caseStatusDtlsCacheRecord != null) {

      // If this is a batch transaction or deferred processing
      // (and caching is enabled), and we've hit
      // the cache we do not need to reload the cache
      if (((transactionType.equals(TransactionType.kBatch)
        || transactionType.equals(TransactionType.kDeferred))
          && cachingEnabled)
            && (caseStatusDtlsCacheRecord.caseID == key.caseID)) {

        // caseStatusDetailsListRet.dtls and caseStatusDtlsList.dtls are
        // different classes loop is required to assign between them
        caseStatusDetailsListRet.dtls.ensureCapacity(
          caseStatusDtlsCacheRecord.caseStatusDtlsList.dtls.size());

        for (int i = 0; i
          < caseStatusDtlsCacheRecord.caseStatusDtlsList.dtls.size(); i++) {

          caseStatusDetailsListRet.dtls.addRef(
            caseStatusDtlsCacheRecord.caseStatusDtlsList.dtls.item(i));
        }

        reloadCache = false;
      }

      // if this is a deferred transaction, we must also check
      // that the transaction numbers match
      if (!reloadCache
        && transactionType.equals(TransactionInfo.TransactionType.kDeferred)
        && (caseStatusDtlsCacheRecord.transactionID
          != TransactionInfo.getIdentifierForThisThread())) {

        reloadCache = true;
      }
    }

    if (reloadCache) {

      // Otherwise we need to read the CaseHeader data
      curam.core.intf.CaseStatus caseStatusObj = curam.core.fact.CaseStatusFactory.newInstance();
      CaseStatusDtlsList caseStatusDtlsListLocal;

      caseStatusDtlsListLocal = caseStatusObj.searchByCaseID(key);

      // If this was a cache miss (and caching is enabled), refresh the cache
      if ((transactionType.equals(TransactionType.kBatch)
        || transactionType.equals(TransactionType.kDeferred))
          && cachingEnabled) {
    
        caseStatusDtlsCacheRecord = new CaseStatusDtlsCacheRecord();  
        caseStatusDtlsCacheRecord.caseID = key.caseID;
        caseStatusDtlsCacheRecord.caseStatusDtlsList = caseStatusDtlsListLocal;
        caseStatusDtlsCacheRecord.transactionID = TransactionInfo.getIdentifierForThisThread();

        cachedCaseStatusDtls.set(caseStatusDtlsCacheRecord);
      }

      // caseStatusDetailsListRet.dtls and caseStatusDtlsList.dtls are
      // different classes loop is required to assign between them
      caseStatusDetailsListRet.dtls.ensureCapacity(
        caseStatusDtlsCacheRecord.caseStatusDtlsList.dtls.size());

      int i;

      for (i = 0; i < caseStatusDtlsCacheRecord.caseStatusDtlsList.dtls.size(); i++) {

        caseStatusDetailsListRet.dtls.addRef(
          caseStatusDtlsCacheRecord.caseStatusDtlsList.dtls.item(i));
      }
      // end of assignment dtls.dtls = caseStatusDtlsList.dtls
    }

    return caseStatusDetailsListRet;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void clearCache() throws AppException, InformationalException {

    // Set the thread local object to null
    cachedCaseStatusDtls.set(null);
  }

}
