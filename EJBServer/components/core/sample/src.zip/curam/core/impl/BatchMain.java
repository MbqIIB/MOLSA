/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2004, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.struct.BatchProcessChunkDtlsList;
import curam.core.struct.BatchProcessDtls;
import curam.core.struct.BatchProcessStreamKey;
import curam.core.struct.BatchProcessingResult;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Blob;
import curam.util.type.Implementable;


/**
 * This interface is used to allow the batch streaming infrastructure to invoke
 * the reporting for of a given batch program.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
@Implementable
public interface BatchMain {

  public BatchProcessingResult doExtraProcessing(BatchProcessStreamKey batchProcessStreamKey,
    Blob batchProcessParameters) throws AppException, InformationalException;

  public void sendBatchReport(String instanceID,
    BatchProcessDtls batchProcessDtls,
    BatchProcessChunkDtlsList processedBatchProcessChunkDtlsList,
    BatchProcessChunkDtlsList unprocessedBatchProcessChunkDtlsList) throws AppException, InformationalException;

}
