/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.core.impl;


import curam.core.fact.SynchronizeEventsFactory;
import curam.core.intf.SynchronizeEvents;
import curam.core.sl.entity.struct.ConcernRoleDuplicateDtls;
import curam.core.sl.entity.struct.ConcernRoleDuplicateKey;
import curam.core.struct.SynchronizeEventsDetails;
import curam.events.CONCERNROLEDUPLICATE;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * This class performs updates to the Search Server staging database when 
 * modifications are made to the ConcernRoleDuplicate entity
 */
public class IndexConcernRoleDuplicateSynchronization extends
  curam.core.base.IndexConcernRoleDuplicateSynchronization {

  // ___________________________________________________________________________
  /**
   * Raise an event as a result of the ConcernRoleDuplicate entity insert operation
   * This event should result in synchronization of the ConcernRoleEntity details on the 
   * Search Server staging database.
   * 
   * @param dtls ConcernRoleDuplicate details
   *
   */
  public void insert(ConcernRoleDuplicateDtls dtls) throws AppException,
      InformationalException {
    
    // BEGIN, CR00104332, CW
    final SynchronizeEvents synchronizeEventsObj = 
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails = 
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = 
      CONCERNROLEDUPLICATE.INSERT_CONCERN_ROLE_DUPLICATE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = 
      CONCERNROLEDUPLICATE.INSERT_CONCERN_ROLE_DUPLICATE.eventType;
    synchronizeEventsDetails.primaryEventData = dtls.concernRoleDuplicateID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
    // END, CR00104332    

  }

  // ___________________________________________________________________________
  /**
   * Raise an event as a result of the ConcernRoleDuplicate entity modify operation
   * This event should result in synchronization of the ConcernRoleEntity details on the 
   * Search Server staging database.
   * 
   * @param key ConcernRoleDuplicate identifier
   * @param dtls ConcernRoleDuplicate details
   *
   */
  public void modify(ConcernRoleDuplicateKey key, ConcernRoleDuplicateDtls dtls)
    throws AppException, InformationalException {

    // BEGIN, CR00104332, CW
    final SynchronizeEvents synchronizeEventsObj = 
      SynchronizeEventsFactory.newInstance();

    SynchronizeEventsDetails synchronizeEventsDetails = 
      new SynchronizeEventsDetails();

    synchronizeEventsDetails.eventKey.eventClass = 
      CONCERNROLEDUPLICATE.MODIFY_CONCERN_ROLE_DUPLICATE.eventClass;
    synchronizeEventsDetails.eventKey.eventType = 
      CONCERNROLEDUPLICATE.MODIFY_CONCERN_ROLE_DUPLICATE.eventType;
    synchronizeEventsDetails.primaryEventData = key.concernRoleDuplicateID;

    synchronizeEventsObj.raiseEvent(synchronizeEventsDetails);
    // END, CR00104332       

  }

}
