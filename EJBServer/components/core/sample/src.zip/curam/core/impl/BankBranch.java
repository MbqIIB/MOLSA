/*
 * IBM Confidential
 *
 * OCO Source Materials
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2002, 2013
 *
 * The source code for this program is not published or otherwise divested
 * of its trade secrets, irrespective of what has been deposited with the US Copyright Office
 */

/*
 * Copyright 2002-2007, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.core.impl;


import curam.codetable.RECORDSTATUS;
import curam.core.events.BANKBRANCH;
import curam.core.fact.BankFactory;
import curam.core.intf.Bank;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.struct.AccountsByBranchAndStatusStruct;
import curam.core.struct.BankAccountStatusBankBranchKey;
import curam.core.struct.BankBranchDtls;
import curam.core.struct.BankBranchDtlsList;
import curam.core.struct.BankBranchKey;
import curam.core.struct.BankBranchSortCodeStatusKey;
import curam.core.struct.BankKey;
import curam.core.struct.BankKeyStructRef;
import curam.core.struct.SortCodeStruct;
import curam.core.struct.SwiftBusinessIdentifierCode;
import curam.message.BPOBANKBRANCH;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * Implementation of functions to be executed before insert, modify, etc.
 *
 */
public abstract class BankBranch extends curam.core.base.BankBranch {

  /**
   * Function for checking if bank branch name and sortCode are
   * provided
   *
   * @param details Structure containing bank details
   */
  protected void autovalidate(BankBranchDtls details) throws AppException, InformationalException {

    // variables, used to read bank information
    curam.core.intf.Bank bankObj = curam.core.fact.BankFactory.newInstance();
    BankKey bankKey = new BankKey();

    // check that the input Bank is valid.
    bankKey.bankID = details.bankID;

    // read bank information to verify bank exists
    bankObj.read(bankKey);

    // BEGIN, CR00371769, VT
    final StringBuffer validationString = new StringBuffer();
    // END, CR00371769

    // variables, used to read bank branch according to sort code
    SortCodeStruct sortCodeStruct = new SortCodeStruct();
    BankBranchDtlsList bankBranchDtlsList;

    sortCodeStruct.assign(details);

    boolean recordFound = true;

    // read bank branch according to sort code
    bankBranchDtlsList = searchBySortCode(sortCodeStruct);

    if (bankBranchDtlsList.dtls.isEmpty()) {
      recordFound = false;
    }

    if (recordFound) {

      for (int i = 0; i < bankBranchDtlsList.dtls.size(); i++) {

        // validation required only for active records.
        if (bankBranchDtlsList.dtls.item(i).statusCode.equals(
          curam.codetable.RECORDSTATUS.NORMAL)) {

          // The ID's will be equal when the sortCode has not changed.
          if (details.bankBranchID
            != bankBranchDtlsList.dtls.item(i).bankBranchID) {

            AppException e = new AppException(
              curam.message.BPOBANKBRANCH.ERR_BANKBRANCH_DRE_SORTCODE);

            e.arg(details.bankSortCode);

            // BEGIN, CR00371769, VT
            validationString.append(CuramConst.gkNewLine).append(
              e.getMessage(TransactionInfo.getProgramLocale()));
            // END, CR00371769
          }

        }

      }

    }

    // BEGIN, CR00371769, VT
    final SwiftBusinessIdentifierCode swiftBusinessIdentifierCode = new SwiftBusinessIdentifierCode();

    swiftBusinessIdentifierCode.assign(details);

    // Set recordFound true
    recordFound = true;

    bankBranchDtlsList = searchByBic(swiftBusinessIdentifierCode);

    if (bankBranchDtlsList.dtls.isEmpty()) {
      recordFound = false;
    }
    if (recordFound) {
      for (final BankBranchDtls bankBranchDtls : bankBranchDtlsList.dtls) {

        if (RECORDSTATUS.NORMAL.equals(bankBranchDtls.statusCode)) {
          if (details.bankBranchID != bankBranchDtls.bankBranchID) {

            AppException e = new AppException(
              BPOBANKBRANCH.ERR_BANKBRANCH_DRE_BIC);

            e.arg(details.bic);

            validationString.append(CuramConst.gkNewLine).append(
              e.getMessage(TransactionInfo.getProgramLocale()));
          }

        }
      }
    }

    if (validationString.length() > 0) {

      AppException e = new AppException(
        BPOBANKBRANCH.ERR_BANKBRANCH_VALIDATION_FAILURE_LIST);

      e.arg(validationString);
      ValidationManagerFactory.getManager().throwWithLookup(e,
        ValidationManagerConst.kSetOne, 0);

    }
    // END, CR00371769
  }

  /**
   * Check the sort code to ensure that there is not another branch with
   * this sort code, before updating record
   *
   * @param key Contains identifier of bank branch
   * @param details Contains bank branch ID and sort code
   */
  protected void premodify(BankBranchKey key, BankBranchDtls details)
    throws AppException, InformationalException { // Sort code modification was relocated to AdminBankBranch.modifyBankBranch() method.
    // BEGIN, CR00388421, MV
    convertDetailsToUpper(details);
    // END, CR00388421
  }

  /**
   * Check that the input Bank is valid
   *
   * @param key Contains ID of bank ID
   */
  protected void presearchByBankID(BankKeyStructRef key) throws AppException, InformationalException {
    // variables, used to read bank information
    curam.core.intf.Bank bankObj = curam.core.fact.BankFactory.newInstance();
    BankKey bankKey = new BankKey();

    bankKey.bankID = key.bankID;

    // try to read the bank record - verifies exists

    bankObj.read(bankKey);

  }

  // BEGIN, CR00371769, VT
  /**
   * Check that the input Bank is valid
   *
   * @param key
   * Contains ID of bank ID
   */

  protected void presearchBranchByBankID(BankKeyStructRef key)
    throws AppException, InformationalException {

    Bank bankObj = BankFactory.newInstance();
    final BankKey bankKey = new BankKey();

    bankKey.bankID = key.bankID;

    // try to read the bank record - verifies exists
    bankObj.read(bankKey);
  }

  // END, CR00371769



  /**
   * Method to close a bank branch if there are no open accounts
   *
   * @param details Structure to contain new bank branch details
   */
  public void close(BankBranchDtls details) throws AppException, InformationalException {

    // declarations
    BankBranchKey bankBranchKey = new BankBranchKey();

    curam.core.intf.BankAccount bankAccountObj = curam.core.fact.BankAccountFactory.newInstance();

    BankAccountStatusBankBranchKey bankAccountStatusBankBranchKey = new BankAccountStatusBankBranchKey();

    AccountsByBranchAndStatusStruct accountsByBranchAndStatusStruct;

    bankAccountStatusBankBranchKey.bankBranchID = details.bankBranchID;
    bankAccountStatusBankBranchKey.bankAccountStatus = curam.codetable.BANKACCOUNTSTATUS.DEFAULTCODE;
    bankAccountStatusBankBranchKey.statusCode = curam.codetable.RECORDSTATUS.NORMAL;

    // perform count of open bank accounts
    accountsByBranchAndStatusStruct = bankAccountObj.countAccountsByBankAccountStatusAndBranch(
      bankAccountStatusBankBranchKey);

    // Throw exception if there are open accounts
    if (accountsByBranchAndStatusStruct.numberOfAccounts != 0) {

      AppException e = new AppException(
        curam.message.BPOBANKBRANCH.ERR_BANKBRANCH_XRV_AT_LEAST_ONE_OPEN_ACCOUNT);

      e.arg(details.name);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    if (details.endDate.isZero()) {

      details.endDate = curam.util.type.Date.getCurrentDate();

    }

    details.bankBranchStatus = curam.codetable.BANKBRANCHSTATUS.CLOSED;
    bankBranchKey.bankBranchID = details.bankBranchID;

    // update the bank branch

    modify(bankBranchKey, details);

  }

  /**
   * Ensures that the bank branch status is always active
   *
   * @param key Contains the bank branch details
   */
  protected void presearchBranchNameBankNameBySortCodeStatus(BankBranchSortCodeStatusKey key)
    throws AppException, InformationalException {

    key.status = curam.codetable.RECORDSTATUS.NORMAL;

  }

  /**
   * Raise a post Modify event
   *
   * @param key Identifier of the record that has been modified
   * @param details The updated details for the record
   */
  protected void postmodify(BankBranchKey key, BankBranchDtls details) throws AppException, InformationalException {

    // BEGIN, CR00080234, MG
    curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = BANKBRANCH.MODIFY_BANKBRANCH;

    event.primaryEventData = details.bankBranchID;
    curam.util.events.impl.EventService.raiseEvent(event);
    // END, CR00080234

  }
  
  // BEGIN, CR00388421, MV
  /**
   * Called before the insert operation.
   *
   * @param details The details for the new person record
   */
  protected void preinsert(final BankBranchDtls details)
    throws AppException, InformationalException {

    convertDetailsToUpper(details);
  }

  /**
   * Method to convert the bank branch details to upper case.
   *
   * @param details the person details
   */
  public void convertDetailsToUpper(final BankBranchDtls details) throws AppException,
      InformationalException {
    details.upperBankSortCode = details.bankSortCode.toUpperCase();
    details.upperBic = details.bic.toUpperCase();
    details.upperName = details.name.toUpperCase();
  }
  // END, CR00388421
}
