/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalrequest.impl;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.util.exception.InformationalException;
import curam.util.persistence.OptimisticLockModifiable;

/**
 * 
 * Links an approval request and a related type.
 */
@ImplementedBy(ApprovalRequestLinkImpl.class)
interface ApprovalRequestLink extends ApprovalRequestLinkAccessor,
    OptimisticLockModifiable {

  /**
   * Creates an approval request link that combines an approval request and a
   * related type for that approval request.
   * 
   * @param approvalRequestID
   *          The identifier for the approval request.
   * @param relatedID
   *          The identifier for the related type.
   * @param relatedType
   *          The related type that is linked to the approval request.
   * @deprecated Since Curam 6.0 SP1, replaced with
   *             {@link #createApprovalRequestLink(ApprovalRequest, long, APPROVALRELATEDTYPEEntry)}
   *             . The replacing method now passes the {@link ApprovalRequest}
   *             as a parameter rather than identifier. See release note:
   *             CR00265938.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  @Deprecated
  void createApprovalRequestLink(final long approvalRequestID,
      final long relatedID, final APPROVALRELATEDTYPEEntry relatedType)
      throws InformationalException;

  /**
   * Creates an approval request link that combines an approval request and a
   * related type for that approval request.
   * 
   * @param approvalRequest
   *          The approval request.
   * @param relatedID
   *          The identifier for the related type.
   * @param relatedType
   *          The related type that is linked to the approval request.
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  void createApprovalRequestLink(final ApprovalRequest approvalRequest,
      final long relatedID, final APPROVALRELATEDTYPEEntry relatedType)
      throws InformationalException;

  /**
   * Sets the status of this approval request link to be APPROVED.
   * 
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  void approve() throws InformationalException;

  /**
   * Sets the status of this approval request link to be REJECTED.
   * 
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  void reject() throws InformationalException;

  /**
   * Returns the approval request identifier for the approval request link.
   * 
   * @return long approval request identifier.
   */
  long getApprovalRequestID();

}
