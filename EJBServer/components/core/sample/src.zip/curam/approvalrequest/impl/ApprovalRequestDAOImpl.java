/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalrequest.impl;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.core.sl.entity.impl.ApprovalRequestAdapter;
import curam.core.sl.entity.struct.ApprovalRequestDtls;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;


/**
 * Implementation class for ApprovalRequestDAO.
 */
@Singleton
// BEGIN, CR00183334, PS
public class ApprovalRequestDAOImpl extends StandardDAOImpl<ApprovalRequest, ApprovalRequestDtls> implements
  ApprovalRequestDAO {
  // END. CR00183334
  protected static final ApprovalRequestAdapter adapter = new ApprovalRequestAdapter();

  @Inject
  protected ApprovalRequestLinkDAO approvalRequestLinkDAO;

  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected ApprovalRequestDAOImpl() {
    // no-arg constructor for use only by Guice.
    // END, CR00183334
    super(adapter, ApprovalRequest.class);
  }

  /**
   * {@inheritDoc}
   */
  public ApprovalRequest getApprovalRequest(final long relatedID,
    final APPROVALRELATEDTYPEEntry relatedType) throws InformationalException {

    return get(
      approvalRequestLinkDAO.getApprovalRequestID(relatedID, relatedType));

  }

  /**
   * {@inheritDoc}
   */
  public List<? extends ApprovalRequestAccessor> searchByRelatedIDAndRelatedType(
    final long relatedID, final APPROVALRELATEDTYPEEntry relatedType)
    throws InformationalException {
    List<ApprovalRequestLink> approvalRequestLinkList = approvalRequestLinkDAO.readByRelatedIDAndRelatedType(
      relatedID, relatedType.getCode());
    List<ApprovalRequest> approvalRequestList = new ArrayList<ApprovalRequest>();

    for (ApprovalRequestLink approvalRequestLink : approvalRequestLinkList) {
      approvalRequestList.add(get(approvalRequestLink.getApprovalRequestID()));
    }
    return Collections.unmodifiableList(approvalRequestList);
  }

}
