/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalrequest.impl;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.APPROVALREQUESTSTATUSEntry;
import curam.codetable.impl.REJECTIONREASONEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.Date;

/**
 * Provides Immutable objects and getters for the approval request.
 * 
 */
@ImplementedBy(ApprovalRequestImpl.class)
public interface ApprovalRequestAccessor extends StandardEntity,
    Lifecycle<APPROVALREQUESTSTATUSEntry> {

  /**
   * Returns the status for the approval request link. This will be the same
   * status as the one recorded for the approval request that this object is
   * linked to.
   * 
   * @return APPROVALREQUESTSTATUSEntry holding the status for this approval
   *         request link.
   */
  public APPROVALREQUESTSTATUSEntry getStatus();

  /**
   * Returns the approval request rejection reason.
   * 
   * @return Code table code for the rejection reason.
   */
  public REJECTIONREASONEntry getApprovalRejectionReason();

  /**
   * Returns the approval request rejection comments.
   * 
   * @return comments on rejection of the approval request.
   */
  public String getApprovalRejectionComments();

  /**
   * 
   * Returns the decision for an approval request.
   * 
   * @return Decision for an approval request.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  public String getDecision() throws InformationalException, AppException;

  /**
   * Returns the full name for the user that made the approval request decision.
   * 
   * @return Full name for the user that made the approval request decision.
   */
  public String getDecisionUserFullName() throws InformationalException,
      AppException;

  /**
   * Returns the user name for the user that made the decision for the approval
   * request.
   * 
   * @return User name for the user that made the decision for the approval
   *         request.
   */
  public String getDecisionByUserName();

  /**
   * Returns the date that the decision was made.
   * 
   * @return Date that the decision was made.
   */
  public Date getDecisionDate();

  /**
   * Returns the date that the approval request was made.
   * 
   * @return Date that the approval request was made.
   */
  public Date getRequestDate();

  /**
   * Returns the full name for the user that made the approval request.
   * 
   * @return The full name for the user that made the approval request.
   */
  public String getRequestedByFullname() throws InformationalException,
      AppException;

  /**
   * Returns the user name for the user that made the approval request.
   * 
   * @return User name for the user that made the approval request.
   */
  public String getRequestedByUsername();

}
