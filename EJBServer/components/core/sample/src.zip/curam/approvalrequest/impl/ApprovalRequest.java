/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.approvalrequest.impl;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.APPROVALRELATEDTYPEEntry;
import curam.codetable.impl.REJECTIONREASONEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.OptimisticLockModifiable;

/**
 * 
 * Mutator for the approval request.
 */

@ImplementedBy(ApprovalRequestImpl.class)
public interface ApprovalRequest extends ApprovalRequestAccessor,
    OptimisticLockModifiable {

  /**
   * Creates an approval request in state submitted. Creates pre and post submit
   * events that allow specific processing. For example, security checks and
   * creation of tasks.
   * 
   * @param requestedByUser
   *          The user that requested the submit.
   * @param relatedID
   *          The identifier for the related type that is linked to the approval
   *          request.
   * @param relatedType
   *          The related type linked to the approval request.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  public void submit(final String requestedByUser, final long relatedID,
      final APPROVALRELATEDTYPEEntry relatedType)
      throws InformationalException, AppException;

  /**
   * Sets the approval request status to be approved. Creates pre and post
   * approve events that allow specific processing. For example, security checks
   * and cessation of tasks.
   * 
   * @param approvedByUser
   *          The user approving the approval request.
   * @param relatedID
   *          The identifier for the related type that is linked to the approval
   *          request.
   * @param relatedType
   *          The related type linked to the approval request.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  public void approve(final String approvedByUser, final long relatedID,
      final APPROVALRELATEDTYPEEntry relatedType)
      throws InformationalException, AppException;

  /**
   * Sets the approval request status to be rejected. Create pre and post reject
   * events that allow processing specific to the type of entity being rejected.
   * 
   * @param rejectedByUser
   *          The user rejecting the approval request.
   * @param relatedID
   *          The identifier for the related type that is linked to the approval
   *          request.
   * @param relatedType
   *          The related type linked to the approval request.
   * @param rejectionReason
   *          Code table code to indicate why the request was rejected.
   * @param rejectionComments
   *          User entered remarks indicating why the approval was rejected.
   * @throws InformationalException
   *           Generic Exception Signature.
   * @throws AppException
   *           Generic Exception Signature.
   */
  public void reject(final String rejectedByUser, final long relatedID,
      final APPROVALRELATEDTYPEEntry relatedType,
      final REJECTIONREASONEntry rejectionReason, final String rejectionComments)
      throws InformationalException, AppException;

}
