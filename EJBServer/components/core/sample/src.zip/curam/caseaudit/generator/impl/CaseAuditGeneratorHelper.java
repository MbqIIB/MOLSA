/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.generator.impl;

import curam.core.facade.struct.CaseLoadDetails;
import curam.core.facade.struct.NumberAndPercentageOfCases;
import curam.core.impl.CuramConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

public class CaseAuditGeneratorHelper {

  // ___________________________________________________________________________
  /**
   * Method to determine the number or percentage of cases to process based on
   * information entered by the user. If the user entered the number of cases, 
   * this method will determine the percentage of cases. Alternatively, if the
   * user entered the percentage of cases, this method will determine the
   * number of cases that this percentage represents.
   *
   * @param key the number of cases or percentage of cases as entered by 
   *        the user and the case load size.
   *
   * @return the number and percentage of cases to process.
   * 
   * @throws AppException
   * @throws InformationalException
   */  
  public NumberAndPercentageOfCases determineNumCasesToProcess(
    final CaseLoadDetails key) throws AppException, InformationalException {

    NumberAndPercentageOfCases numberAndPercentageOfCases = 
      new NumberAndPercentageOfCases();
      
    int numberOfCasesToProcess = 0;
    double percentageOfCasesToProcess = 0;
    double numberOfCasesToProcessDouble = 0;
    double masterListSizeDouble = key.totalCases;
    // BEGIN, CR00238338, PF
    if (key.numberOfCases > 0) {

      numberOfCasesToProcess = key.numberOfCases;
      // Need to convert to double to ensure that result of division is a double
      numberOfCasesToProcessDouble = numberOfCasesToProcess;
      percentageOfCasesToProcess = Math.round((
        numberOfCasesToProcessDouble / masterListSizeDouble)
          * CuramConst.gkOneHundredPercent);
    } else if (key.percentageOfCases > 0) {
        numberOfCasesToProcess = (int)Math.round(
          (key.percentageOfCases / CuramConst.gkOneHundredPercent) * key.totalCases);
        percentageOfCasesToProcess = key.percentageOfCases;
    } else {
        numberOfCasesToProcess = key.totalCases;
        percentageOfCasesToProcess = CuramConst.gkOneHundredPercent;
    }
    // END, CR00238338
    numberAndPercentageOfCases.numberOfCases = numberOfCasesToProcess;
    numberAndPercentageOfCases.percentageOfCases = percentageOfCasesToProcess;
    
    return numberAndPercentageOfCases;
  }

}
