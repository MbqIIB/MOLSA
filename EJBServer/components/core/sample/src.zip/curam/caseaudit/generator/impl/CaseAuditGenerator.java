/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.generator.impl;

import curam.core.facade.struct.CaseSampleKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;

public interface CaseAuditGenerator {

  // ___________________________________________________________________________
  /**
   * Generates the sample list of cases for audit based on the supplied search 
   * criteria, query or external service. This method filters the list using 
   * the algorithm associated with the case type for this audit plan. 
   * The number of cases returned in the list is also restricted by the number 
   * of cases or percentage of cases specified by the user.
   *
   * @param key The search criteria, percentage/number of cases to generate and 
   *          any algorithm parameters.
   * 
   * @throws AppException
   * @throws InformationalException
   */
  public void generateCaseAudits(CaseSampleKey key) 
    throws AppException, InformationalException;
  
  // ___________________________________________________________________________
  /**
   * Records the criteria entered by the audit coordinator during case sample
   * generation.
   *
   * @param key The search criteria, percentage/number of cases to generate and 
   *          any algorithm parameters.
   *          
   */
  public void recordSelectionCriteria(CaseSampleKey key) 
    throws AppException, InformationalException;
}
