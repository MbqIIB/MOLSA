/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.caseaudit.entity.struct.AuditPlanFocusAreaDtls;
import curam.codetable.impl.AUDITCASEFOCUSAREAEntry;
import curam.message.impl.ENTAUDITPLANFOCUSAREAExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.StringHelper;


/**
 * Implementation for AuditPlanFocusArea.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditPlanFocusArea
 */
// BEGIN, CR00183334, PS
public class AuditPlanFocusAreaImpl extends SingleTableEntityImpl<AuditPlanFocusAreaDtls> implements AuditPlanFocusArea {
  // END, CR00183334

  @Inject
  protected AuditPlanDAO auditPlanDAO;
  
  @Inject 
  protected CaseAuditDAO caseAuditDAO;
  
  @Inject
  protected FocusAreaFindingDAO focusAreaFindingDAO;

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected AuditPlanFocusAreaImpl() {
    // no-arg constructor for use only by Guice
    // END, CR00183334
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the audit plan focus area. 
   *
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
    
    AuditPlan auditPlan = getAuditPlan();
    Set<CaseAudit> caseAuditList = caseAuditDAO.searchByAuditPlan(auditPlan);
    
    for (CaseAudit caseAudit : caseAuditList) {      
      FocusAreaFinding focusAreaFinding = focusAreaFindingDAO.newInstance();

      focusAreaFinding.setAuditPlanFocusArea(this);
      focusAreaFinding.setCaseAudit(caseAudit);
      focusAreaFinding.insert();
    }
  }

  // ___________________________________________________________________________
  /**
   * Removes the audit plan focus area. (Note: This is a physical delete).
   *
   */
  @Override
  public void remove() throws InformationalException {
    super.remove();
  }
 
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {

    if (getDtls().auditPlanID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANFOCUSAREAExceptionCreator.ERR_FV_MANDATORY_AUDIT_PLAN_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setAuditPlan(final AuditPlan auditPlan) {
    getDtls().auditPlanID = auditPlan.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setFocusArea(
    final AUDITCASEFOCUSAREAEntry focusArea) {
    getDtls().focusAreaCode = focusArea.getCode();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AuditPlan getAuditPlan() {
    return auditPlanDAO.get(getDtls().auditPlanID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AUDITCASEFOCUSAREAEntry getFocusArea() {
    return AUDITCASEFOCUSAREAEntry.get(getDtls().focusAreaCode);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {

    if (StringHelper.isEmpty(getDtls().focusAreaCode)) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANFOCUSAREAExceptionCreator.ERR_FV_MANDATORY_FOCUS_AREA_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }    
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// None Required
  }

}
