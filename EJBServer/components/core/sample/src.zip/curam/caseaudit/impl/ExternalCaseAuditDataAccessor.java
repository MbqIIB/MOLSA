/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.List;

import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.core.struct.Count;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;


/**
 * ExternalCaseAuditData Accessor for 
 * {@linkplain curam.caseaudit.impl.ExternalCaseAuditDataAccessor}.
 *
 */
public interface ExternalCaseAuditDataAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Returns the name that represents the set of case identifiers supplied by 
   * an external source. 
   *
   * @return The name that represents the set of case identifiers supplied by 
   * an external source.
   */
  public String getName();

  // ___________________________________________________________________________
  /**
   * Returns a list of External Case Audit Data Items of a specified case type
   * that are associated with this External Case Audit Data record.
   *
   * @param caseType
   * the type of case.
   * @param category
   * the category of case. 
   *
   * @return A list of External Case Audit Data Items of a specified case type
   * that are associated with this External Case Audit Data record.
   */
  public List<ExternalCaseAuditDataItem> getExternalCaseAuditDataItemsByType(
    final CASETYPECODEEntry caseType, final CASECATTYPECODEEntry category)
    throws AppException, InformationalException;
 
  // BEGIN, CR00290965, IBM
  /**
   * Retrieves the total number of external case audit data items of a specified 
   * case type that are associated with an external case audit data record.
   *
   * @param casetypecodeEntry the type of case.
   * @param casecattypecodeEntry the category of case.
   *
   * @return total number of specified case type that are associated with 
   * an external case audit data record.
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  public Count countExternalCaseAuditDataItemsByType(
    final CASETYPECODEEntry casetypecodeEntry, 
    final CASECATTYPECODEEntry casecattypecodeEntry) 
    throws AppException, InformationalException;
  
  // END, CR00290965
}
