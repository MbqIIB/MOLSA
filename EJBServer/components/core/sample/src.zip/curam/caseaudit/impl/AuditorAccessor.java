/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import curam.codetable.impl.AUDITORTYPEEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;
import curam.util.type.Date;

/**
 * Auditor Accessor for
 * {@linkplain curam.caseaudit.impl.Auditor}.
 *
 */
public interface AuditorAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Returns the name of the auditor.
   *
   * @return The name of the auditor.
   */
  public String getAuditorName();
  
  // ___________________________________________________________________________
  /**
   * Returns the audit plan.
   *
   * @return The audit plan.
   */
  public AuditPlan getAuditPlan();
  
  // ___________________________________________________________________________
  /**
   * Returns the audit team.
   *
   * @return The audit team.
   */
  public AuditTeam getAuditTeam();
  
  // ___________________________________________________________________________
  /**
   * Returns the auditor type.
   *
   * @return The auditor type.
   */
  public AUDITORTYPEEntry getAuditorType();  

  // ___________________________________________________________________________
  /**
   * Returns the date that the auditor was added to the audit plan.
   *
   * @return The date.
   */
  public Date getDateAdded();

  // ___________________________________________________________________________
  /**
   * Returns whether the auditor type is AUDITORUSER or not.
   *
   * @return whether the auditor type is AUDITORUSER or not.
   */
  public boolean isUser();

  // ___________________________________________________________________________
  /**
   * Returns whether the auditor type is AUDITORTEAM or not.
   *
   * @return whether the auditor type is AUDITORTEAM or not.
   */
  public boolean isTeam();

  // ___________________________________________________________________________
  /**
   * Returns the full name of the auditor user or audit team.
   *
   * @return The full name of the auditor or team.
   */
  public String getName() throws AppException, InformationalException;
}
