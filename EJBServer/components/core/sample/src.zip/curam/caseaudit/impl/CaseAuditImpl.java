/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.google.inject.Inject;

import curam.caseaudit.entity.struct.AllCaseAuditsCompleteNotificationDetails;
import curam.caseaudit.entity.struct.CaseAuditAuditorAssignmentNotificationDetails;
import curam.caseaudit.entity.struct.CaseAuditCompleteNotificationDetails;
import curam.caseaudit.entity.struct.CaseAuditDtls;
import curam.caseaudit.entity.struct.CaseAuditKey;
import curam.caseaudit.entity.struct.FeedbackRequiredTaskDetails;
import curam.caseaudit.entity.struct.ViewFindingsNotificationDetails;
import curam.caseaudit.fact.CaseAuditSecurityManagementFactory;
import curam.caseaudit.fact.CaseAuditTaskManagementFactory;
import curam.caseaudit.intf.CaseAuditSecurityManagement;
import curam.caseaudit.struct.CaseAuditSecurityKey;
import curam.caseaudit.struct.ValidateCaseAuditUserActionKey;
import curam.codetable.CASEAUDITSTATUS;
import curam.codetable.impl.AUDITORTYPEEntry;
import curam.codetable.impl.AUDITPLANSTATUSEntry;
import curam.codetable.impl.AUDITPLANUSERACCESSEntry;
import curam.codetable.impl.CASEAUDITSTATUSEntry;
import curam.codetable.impl.CASEAUDITTRANSACTIONTYPEEntry;
import curam.codetable.impl.FOCUSAREASATISFIEDEntry;
import curam.core.impl.KeySets;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.UserNameAndFullName;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.UniqueIDKeySet;
import curam.core.struct.UserNameKey;
import curam.core.struct.UserNameKeyList;
import curam.events.CASEAUDIT;
import curam.message.BPOCASEAUDITTRANSACTIONEVENTS;
import curam.message.impl.ENTCASEAUDITExceptionCreator;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.StringHelper;


/**
 * Implementation for CaseAudit.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.CaseAudit
 */
// BEGIN, CR00183334, PS
public class CaseAuditImpl extends SingleTableEntityImpl<CaseAuditDtls>
  implements CaseAudit {
  // END, CR00183334

  @Inject
  protected AuditorDAO auditorDAO;

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected CaseAuditDAO caseAuditDAO;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  @Inject
  protected AuditPlanFocusAreaDAO auditPlanFocusAreaDAO;

  @Inject
  protected FocusAreaFindingDAO focusAreaFindingDAO;

  @Inject
  protected CaseAuditFeedbackDAO caseAuditFeedbackDAO;

  @Inject
  protected CaseAuditTransactionLogDAO caseAuditTransactionLogDAO;

  // ___________________________________________________________________________
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected CaseAuditImpl() {
    // no-arg constructor for use only by Guice
    // END, CR00183334
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the case audit record.
   *
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();

    AuditPlan auditPlan = getAuditPlan();
    
    // BEGIN, CR00210526, GD
    // validate that user can access the case audit type.
    validateUserAccess();
    // END, CR00210526
    
    List<AuditPlanFocusArea> auditPlanFocusAreaList = auditPlanFocusAreaDAO.searchBy(
      auditPlan);

    for (AuditPlanFocusArea auditPlanFocusArea : auditPlanFocusAreaList) {

      FocusAreaFinding focusAreaFinding = focusAreaFindingDAO.newInstance();

      focusAreaFinding.setCaseAudit(this);
      focusAreaFinding.setAuditPlanFocusArea(auditPlanFocusArea);
      focusAreaFinding.insert();
    }

    insertCaseAddedToAuditPlanTransaction();
  }

  // BEGIN, CR00210526, GD
  // ___________________________________________________________________________
  /**
   * Validates that user can access the case audit type.
   */
  protected void validateUserAccess() throws InformationalException {
    
    // Get the logged in user
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    
    // verify that the current user has access to this case audit type
    CaseAuditSecurityManagement caseAuditSecurityManagementObj = CaseAuditSecurityManagementFactory.newInstance();
    
    CaseAuditSecurityKey caseAuditSecurityKey = new CaseAuditSecurityKey();

    caseAuditSecurityKey.auditPlanID = getAuditPlan().getID();
        
    try {
      caseAuditSecurityKey.userName = userAccessObj.getUserDetails().userName;
      caseAuditSecurityManagementObj.checkCaseAuditSecurity(
        caseAuditSecurityKey);
    } catch (AppException ae) {
      ValidationHelper.addValidationError(ae);
    }
  }

  // END, CR00210526

  // ___________________________________________________________________________
  /**
   * Inserts a new case audit transaction log record to record that a case has
   * been added to the audit plan.
   *
   * @throws InformationalException
   */
  protected void insertCaseAddedToAuditPlanTransaction()
    throws InformationalException {

    LocalisableString description = new LocalisableString(BPOCASEAUDITTRANSACTIONEVENTS.CASE_ADDED_TO_AUDITPLAN).arg(getCase().getCaseReference()).arg(
      getAuditPlan().getAuditPlanReference());

    createCaseAuditTransactionLog(
      CASEAUDITTRANSACTIONTYPEEntry.CASE_ADDED_TO_AUDITPLAN,
      description.getMessage(TransactionInfo.getProgramLocale()),
      getCase().getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new case audit transaction log record to record that the auditor
   * has been removed from the case.
   *
   * @param auditorID The unique id of the auditor being removed
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void insertAuditorRemovedTransaction(final long auditorID)
    throws InformationalException, AppException {

    // retrieve the details of the auditor being removed
    Auditor auditor = auditorDAO.get(auditorID);

    LocalisableString description = new LocalisableString(BPOCASEAUDITTRANSACTIONEVENTS.AUDITOR_REMOVED).arg(auditor.getName()).arg(
      getCase().getCaseReference());

    createCaseAuditTransactionLog(CASEAUDITTRANSACTIONTYPEEntry.AUDITOR_REMOVED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new case audit transaction log record to record that the audit
   * team has been removed from the case.
   *
   * @param auditorID The unique id of the audit team being removed
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void insertAuditTeamRemovedTransaction(final long auditorID)
    throws InformationalException, AppException {

    // retrieve the details of the auditor being removed
    Auditor auditor = auditorDAO.get(auditorID);

    LocalisableString description = new LocalisableString(BPOCASEAUDITTRANSACTIONEVENTS.AUDIT_TEAM_REMOVED).arg(auditor.getName()).arg(
      getCase().getCaseReference());

    createCaseAuditTransactionLog(
      CASEAUDITTRANSACTIONTYPEEntry.AUDIT_TEAM_REMOVED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new case audit transaction log record to record that the auditor
   * has been assigned to the case.
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void insertAuditorAssignedTransaction()
    throws InformationalException, AppException {

    LocalisableString description = new LocalisableString(BPOCASEAUDITTRANSACTIONEVENTS.AUDITOR_ASSIGNED).arg(getAuditor().getName()).arg(
      getCase().getCaseReference());

    createCaseAuditTransactionLog(
      CASEAUDITTRANSACTIONTYPEEntry.AUDITOR_ASSIGNED,
      description.getMessage(TransactionInfo.getProgramLocale()),
      getAuditor().getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new case audit transaction log record to record that the audit
   * has been reassigned to a different auditor / audit team.
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void insertAuditReassignedTransaction(final Auditor previousAuditor)
    throws InformationalException, AppException {

    LocalisableString description = new LocalisableString(BPOCASEAUDITTRANSACTIONEVENTS.AUDIT_REASSIGNED).arg(previousAuditor.getName()).arg(
      getAuditor().getName());

    createCaseAuditTransactionLog(
      CASEAUDITTRANSACTIONTYPEEntry.AUDIT_REASSIGNED,
      description.getMessage(TransactionInfo.getProgramLocale()),
      getAuditor().getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new case audit transaction log record to record that the audit
   * tea, has been assigned to the case.
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void insertAuditTeamAssignedTransaction()
    throws InformationalException, AppException {

    LocalisableString description = new LocalisableString(BPOCASEAUDITTRANSACTIONEVENTS.AUDIT_TEAM_ASSIGNED).arg(getAuditor().getName()).arg(
      getCase().getCaseReference());

    createCaseAuditTransactionLog(
      CASEAUDITTRANSACTIONTYPEEntry.AUDIT_TEAM_ASSIGNED,
      description.getMessage(TransactionInfo.getProgramLocale()),
      getAuditor().getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new case audit transaction log record to record that findings
   * have been completed on the case.
   *
   * @throws InformationalException
   */
  protected void insertFindingsCompletedTransaction()
    throws InformationalException {

    LocalisableString description = new LocalisableString(BPOCASEAUDITTRANSACTIONEVENTS.FINDINGS_COMPLETED).arg(
      getCase().getCaseReference());

    createCaseAuditTransactionLog(
      CASEAUDITTRANSACTIONTYPEEntry.FINDINGS_COMPLETED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new case audit transaction log record to record that the audit on
   * the case has been completed.
   *
   * @throws InformationalException
   */
  protected void insertCaseAuditCompletedTransaction()
    throws InformationalException {

    LocalisableString description = new LocalisableString(BPOCASEAUDITTRANSACTIONEVENTS.CASE_AUDIT_COMPLETED).arg(
      getCase().getCaseReference());

    createCaseAuditTransactionLog(
      CASEAUDITTRANSACTIONTYPEEntry.CASE_AUDIT_COMPLETED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new case audit transaction log record to record that feedback has
   * been completed on the case.
   * @throws AppException
   */
  protected void insertFeedbackCompletedTransaction()
    throws InformationalException {

    LocalisableString description = new LocalisableString(BPOCASEAUDITTRANSACTIONEVENTS.FEEDBACK_COMPLETED).arg(
      getCase().getCaseReference());

    createCaseAuditTransactionLog(
      CASEAUDITTRANSACTIONTYPEEntry.FEEDBACK_COMPLETED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Helper method to insert a case audit transaction log record.
   *
   * @param transactionType The value of the schedule start date
   * @param description Transaction log description text
   * @param relatedID Optional value for the id of the related object
   *
   * @throws InformationalException
   */
  protected void createCaseAuditTransactionLog(
    final CASEAUDITTRANSACTIONTYPEEntry transactionType,
    final String description, final long relatedID)
    throws InformationalException {

    CaseAuditTransactionLog caseAuditTransactionLog = caseAuditTransactionLogDAO.newInstance();

    caseAuditTransactionLog.setCaseAudit(this);
    caseAuditTransactionLog.setTransactionType(transactionType);
    caseAuditTransactionLog.setUserName(TransactionInfo.getProgramUser());
    caseAuditTransactionLog.setRelatedID(relatedID);
    caseAuditTransactionLog.setDescription(description);
    caseAuditTransactionLog.insert();
  }

  // BEGIN, CR00219064, GD
  // ____________________________________________________________________________
  /**
   * Create a notification to inform auditor assigned to the case audit that 
   * feedback has been provided. Where the case audit is assigned to a team, 
   * each team member will receive the notification. 
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void createCaseAuditAuditorAssignmentNotification(
    final Auditor auditor)
    throws InformationalException {

    CaseAuditAuditorAssignmentNotificationDetails caseAuditAuditorAssignmentNotificationDetails = new CaseAuditAuditorAssignmentNotificationDetails();

    caseAuditAuditorAssignmentNotificationDetails.caseAuditID = getID();
    caseAuditAuditorAssignmentNotificationDetails.caseReference = getCase().getCaseReference();
    
    // case audit is being assigned to auditor 
    if (auditor.isUser()) {

      // Send notification to auditor
      caseAuditAuditorAssignmentNotificationDetails.auditor = auditor.getAuditorName();

      try {
        CaseAuditTaskManagementFactory.newInstance().sendCaseAuditAuditorAssignmentNotification(
          caseAuditAuditorAssignmentNotificationDetails);
      } catch (AppException ae) {
        ValidationHelper.addValidationError(ae);
      }
    } // Case audit is being assigned to audit team 
    else if (auditor.isTeam()) {

      // Send notification to all auditors on the audit team
      List<AuditTeamMember> members = auditor.getAuditTeam().getMembers();
      
      for (AuditTeamMember member : members) {

        // Send notification to audit team member 
        caseAuditAuditorAssignmentNotificationDetails.auditor = member.getAuditor().getAuditorName();

        try {
          CaseAuditTaskManagementFactory.newInstance().sendCaseAuditAuditorAssignmentNotification(
            caseAuditAuditorAssignmentNotificationDetails);
        } catch (AppException ae) {
          ValidationHelper.addValidationError(ae);
        }
      }
    }
  }

  // END, CR00219064


  // ___________________________________________________________________________
  /**
   * Modifies the case audit record.
   *
   * @param versionNo
   * The version number of the case audit record.
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {

    // BEGIN, CR00210526, GD
    // validate that user can access the case audit type.
    validateUserAccess();
    // END, CR00210526
    
    super.modify(versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Removes the case audit. (Note: This is a physical delete).
   *
   * @param versionNo The version number to remove
   */
  @Override
  public void remove(final Integer versionNo) throws InformationalException {

    // BEGIN, CR00182287, GD
    validateRemoval();
    // END, CR00182287

    List<FocusAreaFinding> focusAreaFindingList = focusAreaFindingDAO.searchByCaseAudit(
      this);

    for (FocusAreaFinding focusAreaFinding : focusAreaFindingList) {
      int findingVersion = focusAreaFinding.getVersionNo();

      focusAreaFinding.remove(findingVersion);
    }
    super.remove(versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Validates that the user can remove the case audit.
   *
   * Cases can only be removed from an audit plan when the audit plan is in a
   * status of 'pending' or if the audit plan is in a status of 'in progress',
   * the case audit must be in an 'open' status (I.E. that individual case has
   * not yet been assigned to a user to work on but other cases in the audit
   * plan have - this is only allowed when the cases in the audit plan were
   * manually selected by the coordinator).
   *
   */
  protected void validateRemoval() {
    // BEGIN, CR00182287, GD
    if (!getAuditPlan().getLifecycleState().equals(AUDITPLANSTATUSEntry.PENDING)
      && (!getAuditPlan().getLifecycleState().equals(
        AUDITPLANSTATUSEntry.DELAYPROC))) {

      if (!(getDtls().caseAuditStatus.equals(CASEAUDITSTATUS.OPEN)
        && (getAuditPlan().getLifecycleState().equals(
          AUDITPLANSTATUSEntry.INPROGRESS)))) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTCASEAUDITExceptionCreator.ERR_XRV_CANNOT_REMOVE_CASE_AUDIT_INVALID_STATUS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }
    // END, CR00182287
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public CaseHeader getCase() {

    return caseHeaderDAO.get(getDtls().caseID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getCaseAuditReference() {
    return getDtls().caseAuditReference;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setCase(final CaseHeader caseHeader) {
    getDtls().caseID = caseHeader.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setComments(final String comments) {

    getDtls().comments = comments;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setAuditPlan(final AuditPlan auditPlan) {
    getDtls().auditPlanID = auditPlan.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AuditPlan getAuditPlan() {
    return auditPlanDAO.get(getDtls().auditPlanID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Auditor getAuditor() {
    return auditorDAO.get(getDtls().auditorID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Date getDateAssigned() {
    return getDtls().dateAssigned;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void assign(final Auditor auditor, final int versionNo)
    throws AppException, InformationalException {

    // detect if this is an assignment or reassignment
    boolean reassignment = false;
    Auditor previousAuditor = getAuditor();

    if (previousAuditor.getID() != 0) {
      reassignment = true;
    }

    if (auditor.getID() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_FV_CONTRIBUTOR_REQUIRED_FOR_ASSIGNED_STATE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    String caseAuditStatus = getDtls().caseAuditStatus;

    // Only case audits in the Open or Assigned status can be assigned.
    if (!caseAuditStatus.equals(CASEAUDITSTATUSEntry.OPEN.getCode())
      && !caseAuditStatus.equals(CASEAUDITSTATUSEntry.ASSIGNED.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_FV_STATUS_OPEN_OR_ASSIGNED_REQUIRED_FOR_ASSIGNED_STATE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    
    getDtls().auditorID = auditor.getID();
    getDtls().caseAuditStatus = CASEAUDITSTATUSEntry.ASSIGNED.getCode();
    getDtls().dateAssigned = curam.util.type.Date.getCurrentDate();
    
    modify(versionNo);

    // BEGIN, CR00210526, GD
    // validate that this auditor has access to this case audit type
    auditor.validateAuditorAccess();
    // END, CR00210526
    
    if (reassignment) {
      // insert reassignment transaction
      insertAuditReassignedTransaction(previousAuditor);
    } else {
      if (getAuditor().isUser()) {
        insertAuditorAssignedTransaction();
      } else {
        insertAuditTeamAssignedTransaction();
      }
    }
    
    // BEGIN, CR00219064, GD
    // send notification to auditor / audit team  
    createCaseAuditAuditorAssignmentNotification(auditor);
    // END, CR00219064

    // move audit plan to In Progress if not already
    AuditPlan auditPlan = getAuditPlan();
    int apVersionNo = auditPlan.getVersionNo();

    auditPlan.beginAudit(apVersionNo);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws AppException
   */
  public void removeAuditor(final int versionNo)
    throws InformationalException, AppException {

    String caseAuditStatus = getDtls().caseAuditStatus;
    long auditorID = getDtls().auditorID;

    // Only case audits in the Assigned status can be un-assigned.
    if (!caseAuditStatus.equals(CASEAUDITSTATUSEntry.ASSIGNED.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_FV_STATUS_ASSIGNED_REQUIRED_FOR_OPEN_STATE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      ValidationHelper.failIfErrorsExist();
    }

    AUDITORTYPEEntry auditorType = getAuditor().getAuditorType();

    getDtls().auditorID = 0;
    getDtls().caseAuditStatus = CASEAUDITSTATUSEntry.OPEN.getCode();

    modify(versionNo);

    if (auditorType.equals(AUDITORTYPEEntry.AUDITUSER)) {
      insertAuditorRemovedTransaction(auditorID);
    } else {
      insertAuditTeamRemovedTransaction(auditorID);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void completeFindings(final int versionNo)
    throws AppException, InformationalException {

    // Validate that the user can complete the findings
    CaseAuditSecurityManagement caseAuditSecurityManagementObj = CaseAuditSecurityManagementFactory.newInstance();
    
    ValidateCaseAuditUserActionKey validateCaseAuditUserActionKey = new ValidateCaseAuditUserActionKey();

    validateCaseAuditUserActionKey.caseAuditID = getID();
    
    caseAuditSecurityManagementObj.validateCaseAuditUserAction(
      validateCaseAuditUserActionKey);
    
    // check to make sure findings have been completed
    List<FocusAreaFinding> focusAreaFindingsList = getFocusAreaFindings();

    boolean negativeFocusAreas = false;

    for (FocusAreaFinding focusAreaFindingObj : focusAreaFindingsList) {

      if (focusAreaFindingObj.getFocusAreaSatisfied().equals(
        FOCUSAREASATISFIEDEntry.NOT_SPECIFIED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTCASEAUDITExceptionCreator.ERR_FV_CANNOT_COMPLETE_WITHOUT_FOCUS_AREA_FINDINGS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      } else if (focusAreaFindingObj.getFocusAreaSatisfied().equals(
        FOCUSAREASATISFIEDEntry.NO)) {

        negativeFocusAreas = true;
      }
    }

    // check to make sure case audit findings have been entered
    // BEGIN, CR00221556, GD
    if (StringHelper.isEmpty(getDtls().findingsText)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_FV_CANNOT_COMPLETE_WITHOUT_FINDINGS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00221556

    AuditPlan auditPlan = getAuditPlan();
    boolean feedbackRequired = false;

    if (auditPlan.getUserAccess().equals(
      AUDITPLANUSERACCESSEntry.VIEWFINDINGSPROVIDEFEEDBACK)) {

      feedbackRequired = true;

    } else if (auditPlan.getUserAccess().equals(
      AUDITPLANUSERACCESSEntry.VIEWFINDPROVIDEFBACKONLYFANOTSATISFIED)
        && negativeFocusAreas) {

      feedbackRequired = true;
    }

    if (feedbackRequired) {

      getDtls().caseAuditStatus = CASEAUDITSTATUSEntry.FINDINGSCOMPLETEAWAITINGFEEDBACK.getCode();

      // Send a task to the case owners and supervisor
      createFeedbackTask();
      modify(versionNo);

      // BEGIN, CR00212093, GD
    } else {
      // END, CR00212093
      // Send a notification to the case owners and supervisor
      createViewFindingsNotification();
      complete(versionNo);
    }
    insertFindingsCompletedTransaction();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void complete(final int versionNo)
    throws AppException, InformationalException {

    // Validate that the user can complete the case audit
    CaseAuditSecurityManagement caseAuditSecurityManagementObj = CaseAuditSecurityManagementFactory.newInstance();
    
    ValidateCaseAuditUserActionKey validateCaseAuditUserActionKey = new ValidateCaseAuditUserActionKey();

    validateCaseAuditUserActionKey.caseAuditID = getID();
    
    caseAuditSecurityManagementObj.validateCaseAuditUserAction(
      validateCaseAuditUserActionKey);

    if (isFeedbackRequired()) {

      // Validate that at least one feedback has been received
      validateFeedback();

      List<CaseAuditFeedback> caseAuditFeedbackList = getCaseAuditFeedback();

      // ensure feedback tasks are closed on all outstanding feedback records
      for (CaseAuditFeedback caseAuditFeedback : caseAuditFeedbackList) {

        if (!caseAuditFeedback.isFeedbackComplete()) {

          Event feedbackReceivedEvent = new Event();

          feedbackReceivedEvent.eventKey.eventClass = CASEAUDIT.FEEDBACKRECEIVED.eventClass;
          feedbackReceivedEvent.eventKey.eventType = CASEAUDIT.FEEDBACKRECEIVED.eventType;
          feedbackReceivedEvent.primaryEventData = caseAuditFeedback.getID();

          try {
            EventService.raiseEvent(feedbackReceivedEvent);
          } catch (AppException ae) {
            ValidationHelper.addValidationError(ae);
          }
        }
      }
    }

    getDtls().caseAuditStatus = CASEAUDITSTATUSEntry.COMPLETE.getCode();
    modify(versionNo);

    insertCaseAuditCompletedTransaction();

    // Send a notification to the coordinator
    createCaseAuditCompleteNotification();

    // If ALL case audits on the audit plan are complete,
    // send a notification to the coordinator
    Set<CaseAudit> allCaseAudits = getAuditPlan().getCaseAudits();
    boolean allComplete = true;

    // Are they all complete?
    for (CaseAudit caseAudit : allCaseAudits) {
      if (!caseAudit.getLifecycleState().equals(CASEAUDITSTATUSEntry.COMPLETE)) {
        allComplete = false;
        break;
      }
    }

    if (allComplete) {
      createAllCaseAuditsCompleteNotification();
    }
  }

  // ___________________________________________________________________________
  /**
   * Method to return the current lifecycle state (Case Audit Status).
   *
   * @return The current status of the case audit
   */
  public CASEAUDITSTATUSEntry getLifecycleState() {
    return CASEAUDITSTATUSEntry.get(getDtls().caseAuditStatus);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<FocusAreaFinding> getFocusAreaFindings() {
    return focusAreaFindingDAO.searchByCaseAudit(this);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {

    validateAuditPlanCase();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link ENTCASEAUDIT#ERR_FV_MANDATORY_CASE_ID_NOT_SET} -
   * If mandatory case id not specified.</li>
   * <li>
   * {@link ENTCASEAUDIT#ERR_FV_MANDATORY_AUDIT_PLAN_NOT_SET} -
   * If mandatory audit plan not specified.</li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    if (getDtls().caseID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_FV_MANDATORY_CASE_ID_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getDtls().auditPlanID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_FV_MANDATORY_AUDIT_PLAN_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Method to set the default values for a new case audit object. Case audits
   * by default have a case audit status of open and a generated unique case id.
   */
  public void setNewInstanceDefaults() {

    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();
    UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    try {

      // Create a unique, readable reference identifier for a case audit
      uniqueIDKeySet.keySetName = KeySets.KEY_SET_AUDITPLAN;
      getDtls().caseAuditReference = String.valueOf(
        uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet));
    } catch (AppException ae) {
      throw new AppRuntimeException(ae);
    } catch (InformationalException ie) {
      throw new AppRuntimeException(ie);
    }

    // case audits initially start in the OPEN state
    getDtls().caseAuditStatus = CASEAUDITSTATUSEntry.OPEN.getCode();
  }

  // ___________________________________________________________________________
  /**
   * Validates that the case has not already been selected for the audit plan.
   */
  protected void validateAuditPlanCase() {

    List<curam.caseaudit.impl.CaseAudit> results = caseAuditDAO.searchByAuditPlanAndCase(
      this.getAuditPlan(), this.getCase());

    if (results.size() > 1) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_FV_CASE_ALREADY_SELECTED_FOR_AUDIT(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setCaseAuditFindings(final String findings)
    throws AppException, InformationalException {

    CaseAuditKey caseAuditKey = new CaseAuditKey();

    caseAuditKey.caseAuditID = getDtls().caseAuditID;

    // Validate that the user can modify the findings
    CaseAuditSecurityManagement caseAuditSecurityManagementObj = CaseAuditSecurityManagementFactory.newInstance();
    
    ValidateCaseAuditUserActionKey validateCaseAuditUserActionKey = new ValidateCaseAuditUserActionKey();

    validateCaseAuditUserActionKey.caseAuditID = getID();
    
    caseAuditSecurityManagementObj.validateCaseAuditUserAction(
      validateCaseAuditUserActionKey);

    // BEGIN, CR00221556, GD
    getDtls().findingsText = findings;
    // END, CR00221556
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getCaseAuditFindings()
    throws AppException, InformationalException {
    // BEGIN, CR00221556, GD
    return getDtls().findingsText;
    // END, CR00221556
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public boolean areFindingsEntered() {
    // BEGIN, CR00221556, GD
    return !StringHelper.isEmpty(getDtls().findingsText);
    // END, CR00221556
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public boolean isFeedbackRequired() {

    boolean feedbackRequired = false;
    AuditPlan auditPlan = getAuditPlan();

    if (auditPlan.getUserAccess().equals(
      AUDITPLANUSERACCESSEntry.VIEWFINDINGSPROVIDEFEEDBACK)) {

      feedbackRequired = true;

    } else if (auditPlan.getUserAccess().equals(
      AUDITPLANUSERACCESSEntry.VIEWFINDPROVIDEFBACKONLYFANOTSATISFIED)) {

      List<FocusAreaFinding> focusAreaFindingsList = getFocusAreaFindings();

      for (FocusAreaFinding focusAreaFindingObj : focusAreaFindingsList) {

        if (focusAreaFindingObj.getFocusAreaSatisfied().equals(
          FOCUSAREASATISFIEDEntry.NO)) {

          feedbackRequired = true;
        }
      }
    }

    return feedbackRequired;
  }

  // ____________________________________________________________________________
  /**
   * Method to return the case owner resolved to a set of username strings.
   *
   * @return Set of username strings
   */
  protected Set<String> getCaseOwnersAndSupervisors()
    throws AppException, InformationalException {

    Set<String> ownerSupervisorSet = new TreeSet<String>();

    CaseHeader caseHeader = getCase();

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseHeader.getID();

    CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();

    // Get the case owners and add them to the set
    UserNameKeyList caseOwners = caseUserRoleObj.listOwnerForCase(caseHeaderKey);

    for (int i = 0; i < caseOwners.dtls.size(); i++) {

      ownerSupervisorSet.add(caseOwners.dtls.item(i).userName);
    }

    // Get the case supervisor and add to the set if one exists
    UserNameAndFullName supervisor = caseUserRoleObj.readSupervisor(
      caseHeaderKey);

    if (!StringHelper.isEmpty(supervisor.userName)) {

      ownerSupervisorSet.add(supervisor.userName);
    } else {
      // If none exists, get the owners supervisor
      UserNameKey userNameKey = caseUserRoleObj.readSupervisorForCaseOwner(
        caseHeaderKey);

      ownerSupervisorSet.add(userNameKey.userName);
    }

    return ownerSupervisorSet;
  }

  // ____________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void feedbackReceived(final int versionNo)
    throws InformationalException {

    // first check for a valid current state
    if (!getLifecycleState().equals(
      CASEAUDITSTATUSEntry.FINDINGSCOMPLETEAWAITINGFEEDBACK)
        && !getLifecycleState().equals(CASEAUDITSTATUSEntry.FEEDBACKRECEIVED)) {
      return;
    }

    List<CaseAuditFeedback> caseAuditFeedbackList = getCaseAuditFeedback();

    boolean atLeastOneFeedbackComplete = false;
    boolean allFeedbackComplete = true;

    for (CaseAuditFeedback caseAuditFeedback : caseAuditFeedbackList) {

      if (caseAuditFeedback.isFeedbackComplete()) {
        atLeastOneFeedbackComplete = true;
      } else {
        allFeedbackComplete = false;
      }
    }

    if (allFeedbackComplete) {
      getDtls().caseAuditStatus = CASEAUDITSTATUSEntry.FEEDBACKCOMPLETE.getCode();
      modify(versionNo);
      insertFeedbackCompletedTransaction();
      return;
    }

    if (atLeastOneFeedbackComplete) {
      getDtls().caseAuditStatus = CASEAUDITSTATUSEntry.FEEDBACKRECEIVED.getCode();
      modify(versionNo);
    }
  }

  // ____________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<CaseAuditFeedback> getCaseAuditFeedback() {
    return caseAuditFeedbackDAO.searchByCaseAudit(this);
  }

  // ____________________________________________________________________________
  /**
   * Method to send a task to the case owners and supervisor.
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void createFeedbackTask()
    throws AppException, InformationalException {

    // create tasks for case owners and supervisors
    FeedbackRequiredTaskDetails feedbackRequiredTaskDetails = new FeedbackRequiredTaskDetails();

    Set<String> caseOwnersAndSupervisors = new TreeSet<String>();

    try {
      caseOwnersAndSupervisors = getCaseOwnersAndSupervisors();
    } catch (AppException ae) {
      ValidationHelper.addValidationError(ae);
    }

    feedbackRequiredTaskDetails.caseAuditID = getID();
    feedbackRequiredTaskDetails.caseAuditRef = getDtls().caseAuditReference;

    // for each possible case owner
    for (String caseOwnerSupervisor : caseOwnersAndSupervisors) {
      // create the feedback record
      CaseAuditFeedback caseAuditFeedback = caseAuditFeedbackDAO.newInstance();

      caseAuditFeedback.setFeedbackComplete(false);
      caseAuditFeedback.setCaseAudit(this);
      caseAuditFeedback.setUsername(caseOwnerSupervisor);

      caseAuditFeedback.insert();

      feedbackRequiredTaskDetails.caseAuditFeedbackID = caseAuditFeedback.getID();
      feedbackRequiredTaskDetails.feedbackUser = caseOwnerSupervisor;

      try {
        CaseAuditTaskManagementFactory.newInstance().sendFeedbackRequiredTask(
          feedbackRequiredTaskDetails);
      } catch (AppException ae) {
        ValidationHelper.addValidationError(ae);
      }
    }
  }

  // ____________________________________________________________________________
  /**
   * Method to create a notification to the case owners and supervisor.
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void createViewFindingsNotification()
    throws AppException, InformationalException {

    Set<String> caseOwnersAndSupervisors = new TreeSet<String>();

    try {
      caseOwnersAndSupervisors = getCaseOwnersAndSupervisors();
    } catch (AppException ae) {
      ValidationHelper.addValidationError(ae);
    }

    ViewFindingsNotificationDetails viewFindingsNotificationDetails = new ViewFindingsNotificationDetails();

    viewFindingsNotificationDetails.caseAuditID = getID();
    viewFindingsNotificationDetails.caseAuditRef = getDtls().caseAuditReference;
    viewFindingsNotificationDetails.caseID = getCase().getID();

    for (String caseOwnerSupervisor : caseOwnersAndSupervisors) {

      viewFindingsNotificationDetails.user = caseOwnerSupervisor;

      try {
        CaseAuditTaskManagementFactory.newInstance().sendViewFindingsNotification(
          viewFindingsNotificationDetails);
      } catch (AppException ae) {
        ValidationHelper.addValidationError(ae);
      }
    }
  }

  // ____________________________________________________________________________
  /**
   * Method to create a notification to inform the audit coordinator that
   * the case audit is complete.
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void createCaseAuditCompleteNotification()
    throws AppException, InformationalException {

    CaseAuditCompleteNotificationDetails caseAuditCompleteNotificationDetails = new CaseAuditCompleteNotificationDetails();

    caseAuditCompleteNotificationDetails.caseAuditID = getID();
    caseAuditCompleteNotificationDetails.caseReference = getCase().getCaseReference();
    caseAuditCompleteNotificationDetails.coordinator = getAuditPlan().getCoordinator();

    CaseAuditTaskManagementFactory.newInstance().sendCaseAuditCompleteNotification(
      caseAuditCompleteNotificationDetails);
  }

  // ____________________________________________________________________________
  /**
   * Method to create a notification to inform the audit coordinator that
   * all case audits on an audit plan have been completed.
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void createAllCaseAuditsCompleteNotification()
    throws AppException, InformationalException {

    AllCaseAuditsCompleteNotificationDetails allCaseAuditsCompleteNotificationDetails = new AllCaseAuditsCompleteNotificationDetails();

    allCaseAuditsCompleteNotificationDetails.auditPlanID = getAuditPlan().getID();
    allCaseAuditsCompleteNotificationDetails.auditPlanRef = getAuditPlan().getAuditPlanReference();
    allCaseAuditsCompleteNotificationDetails.coordinator = getAuditPlan().getCoordinator();

    CaseAuditTaskManagementFactory.newInstance().sendAllCaseAuditsCompleteNotification(
      allCaseAuditsCompleteNotificationDetails);
  }

  // ___________________________________________________________________________
  /**
   * Validate that all necessary feedback has been received.
   *
   */
  protected void validateFeedback() {

    boolean oneFeedbackComplete = false;
    // Get all feedback records for the case audit
    List<CaseAuditFeedback> caseAuditFeedbackList = getCaseAuditFeedback();

    for (CaseAuditFeedback caseAuditFeedback : caseAuditFeedbackList) {
      // Check are any complete
      if (caseAuditFeedback.isFeedbackComplete()) {
        oneFeedbackComplete = true;
        break;
      }
    }

    // At least one feedback record must be complete
    if (!oneFeedbackComplete) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_XRV_CANNOT_COMPLETE_MIN_ONE_FEEDBACK_REQUIRED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }
}
