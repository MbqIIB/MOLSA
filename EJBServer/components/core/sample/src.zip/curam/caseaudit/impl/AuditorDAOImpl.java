/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.ArrayList;
import java.util.List;

import com.google.inject.Singleton;

import curam.caseaudit.entity.impl.AuditorAdapter;
import curam.caseaudit.entity.struct.AuditTeamKey;
import curam.caseaudit.entity.struct.AuditorDtls;
import curam.caseaudit.fact.CaseAuditSecurityManagementFactory;
import curam.caseaudit.struct.CaseAuditSecurityKey;
import curam.core.struct.UsersKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;


/**
 * Data access Implementation for
 * {@linkplain curam.caseaudit.impl.Auditor}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditTeamDAO
 */
@Singleton
// BEGIN, CR00183334, PS
public class AuditorDAOImpl extends StandardDAOImpl<Auditor, AuditorDtls>
  implements AuditorDAO {
  // END, CR00183334
  protected static final AuditorAdapter adapter = new AuditorAdapter();

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<Auditor> searchByAuditPlanAndTeam(final AuditPlan auditPlan, 
    final AuditTeamKey key) {
    // BEGIN, CR00266672, GD
    return newList(
      adapter.searchByAuditPlanAndTeam(auditPlan.getID(), key.auditTeamID));
    // END, CR00266672
  }

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected AuditorDAOImpl() {
    // END, CR00183334
    super(adapter, Auditor.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<Auditor> searchByAuditPlan(final AuditPlan auditPlan) {
    // BEGIN, CR00266672, GD
    return newList(adapter.searchByAuditPlan(auditPlan.getID()));
    // END, CR00266672
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<Auditor> searchByAuditPlanAndUser(
    final AuditPlan auditPlan, final UsersKey key) {
    
    // BEGIN, CR00266672, GD
    return newList(
      adapter.searchByAuditPlanAndUser(key.userName, auditPlan.getID()));
    // END, CR00266672
  }
  
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<Auditor> searchByUserName(final String userName) {
    // BEGIN, CR00266672, GD
    return newList(adapter.searchByUser(userName));
    // END, CR00266672
  }
  
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Auditor readByAuditTeam(final AuditTeam team) {

    // BEGIN, CR00266672, GD
    return getEntity(adapter.readByAuditTeam(team.getID()));
    // END, CR00266672
  }
  
  // BEGIN, CR00210526, GD
  // ___________________________________________________________________________
  /**
   * Filters a list of Auditors removing any auditors that don't have security 
   * access to the case audit type. 
   */
  protected List<Auditor> filterAuditorListBySID(
    final List<Auditor> auditorList) {
    
    List<Auditor> filteredList = new ArrayList<Auditor>();
    
    for (Auditor auditor : auditorList) {
      if (auditor.isUser()) {
        if (checkAuditorBySID(auditor)) {
          filteredList.add(auditor);
        }
      } else {
        filteredList.add(auditor);
      }      
    }
    
    return filteredList;
  }
  
  // ___________________________________________________________________________
  /**
   * Checks if the auditor has access to this audit plan. 
   */
  protected boolean checkAuditorBySID(final Auditor auditor) {
       
    boolean returnValue = false;
    
    // if Auditor is null return true
    if (auditor == null) {
      return true;
    }
    
    curam.caseaudit.intf.CaseAuditSecurityManagement securityObj = CaseAuditSecurityManagementFactory.newInstance();
    
    CaseAuditSecurityKey caseAuditSecurityKey = new CaseAuditSecurityKey();
    
    caseAuditSecurityKey.auditPlanID = auditor.getAuditPlan().getID();
    caseAuditSecurityKey.userName = auditor.getAuditorName();
    try {
      securityObj.checkCaseAuditSecurity(caseAuditSecurityKey);
      returnValue = true;
    } catch (AppException e) {// invalid security don't add auditor to list
    } catch (InformationalException e) {// invalid security don't add auditor to list
    }
    
    return returnValue;
  }
  // END, CR00210526
}
