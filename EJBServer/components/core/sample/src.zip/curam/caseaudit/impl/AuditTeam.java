/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import java.util.List;

import com.google.inject.ImplementedBy;

import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.OptimisticLockRemovable;

/**
 * Service layer class having operations for managing Audit Teams.
 * 
 */
@ImplementedBy(AuditTeamImpl.class)
public interface AuditTeam extends Insertable, OptimisticLockModifiable,
  OptimisticLockRemovable, AuditTeamAccessor {

  /**
   * Creates the AuditTeam and also inserts an Auditor record for the team.
   * 
   * @param auditPlan
   *          The audit plan to which the team is being added.
   *  
   * @throws InformationalException
   *           Generic Exception Signature.
   */
  public void insert(AuditPlan auditPlan) throws InformationalException;

  // ___________________________________________________________________________
  /**
   * Sets the audit team name.
   * 
   * @param value
   *          The name of the audit team.
   */
  public void setName(final String value);

  // ___________________________________________________________________________
  /**
   * Returns list of the audit team members.
   * 
   * @return The members.
   */
  public List<AuditTeamMember> getMembers();

  // BEGIN, CR00202947, GD
  // ___________________________________________________________________________
  /**
   * Updates the list of audit team members on the audit team.
   * 
   * @param members 
   *          The list of Auditor records to be added to the audit team
   *             
   * @throws AppException
   *          Generic Exception Signature.
   * @throws InformationalException
   *          Generic Exception Signature.
   */
  public void setMembers(final List<Auditor> members) 
    throws AppException, InformationalException;
  // END, CR00202947

}
