/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import java.util.List;

import com.google.inject.ImplementedBy;

import curam.caseaudit.entity.struct.AuditTeamKey;
import curam.core.struct.UsersKey;
import curam.util.persistence.StandardDAO;

/**
 * Data access for {@linkplain curam.caseaudit.impl.Auditor}.
 */
@ImplementedBy(AuditorDAOImpl.class)
public interface AuditorDAO extends StandardDAO<Auditor> {

  // ___________________________________________________________________________
  /**
   * Retrieves a list of auditor records for a specified audit plan.
   *
   * @param auditPlan
   *          the plan to search on.
   *
   * @return all the instances that are associated with the plan.
   */
  public List<Auditor> searchByAuditPlan(
    final AuditPlan auditPlan);
  
  // ___________________________________________________________________________
  /**
   * Retrieves a list of auditor records for a specified audit plan and user.
   *
   * @param auditPlan
   *          the plan to search on.
   * @param key
   *          the user to search on.         
   *
   * @return all the instances that are associated with the plan and user.
   */
  public List<Auditor> searchByAuditPlanAndUser(
    final AuditPlan auditPlan, final UsersKey key);
  
  // ___________________________________________________________________________
  /**
   * Retrieves a list of auditor records for a specified audit plan and team.
   *
   * @param auditPlan
   *          the plan to search on.
   * @param key
   *          the team to search on.         
   *
   * @return all the instances that are associated with the plan and team.
   */
  public List<Auditor> searchByAuditPlanAndTeam(
    final AuditPlan auditPlan, final AuditTeamKey key);
  
  // ___________________________________________________________________________
  /**
   * Retrieves a list of auditor records for a specified user.
   *
   * @param userName
   *          the user to search on.         
   *
   * @return all the instances that are associated with the user.
   */
  public List<Auditor> searchByUserName(final String userName);
  
  // ___________________________________________________________________________
  /**
   * Retrieves a list of auditor records for a specified audit team.
   *
   * @param auditTeam
   *          the team to search on.         
   *
   * @return all auditor instances that are associated with the team.
   */
  public Auditor readByAuditTeam(final AuditTeam auditTeam);

}
