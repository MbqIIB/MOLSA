/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2009, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;

import com.google.inject.Inject;

import curam.caseaudit.entity.impl.AuditPlanAdapter;
import curam.caseaudit.entity.struct.AssignCoordinatorNotificationDetails;
import curam.caseaudit.entity.struct.AuditPlanDtls;
import curam.caseaudit.entity.struct.CaseSampleListGeneratedNotificationDetails;
import curam.caseaudit.entity.struct.FocusAreaStats;
import curam.caseaudit.entity.struct.FocusAreaStatsList;
import curam.caseaudit.entity.struct.ScheduledAuditPlanNotificationDetails;
import curam.caseaudit.fact.CaseAuditSecurityManagementFactory;
import curam.caseaudit.fact.CaseAuditTaskManagementFactory;
import curam.caseaudit.intf.CaseAuditSecurityManagement;
import curam.caseaudit.intf.CaseAuditTaskManagement;
import curam.caseaudit.struct.CaseAuditSecurityKey;
import curam.codetable.AUDITCASEFOCUSAREA;
import curam.codetable.AUDITPLANSTATUS;
import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.impl.AUDITCASEFOCUSAREAEntry;
import curam.codetable.impl.AUDITPLANPRIORITYEntry;
import curam.codetable.impl.AUDITPLANPURPOSEEntry;
import curam.codetable.impl.AUDITPLANSTATUSEntry;
import curam.codetable.impl.AUDITPLANTRANSACTIONTYPEEntry;
import curam.codetable.impl.AUDITPLANUSERACCESSEntry;
import curam.codetable.impl.CASEAUDITSTATUSEntry;
import curam.codetable.impl.FOCUSAREASATISFIEDEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.impl.KeySets;
import curam.core.sl.entity.struct.CaseUserRoleDetails;
import curam.core.sl.fact.CaseUserRoleFactory;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.sl.intf.CaseUserRole;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.CaseUserRoleCaseIDKey;
import curam.core.sl.struct.CaseUserRoleDetailsList;
import curam.core.struct.UniqueIDKeySet;
import curam.core.struct.UsersKey;
import curam.message.BPOAUDITPLANTRANSACTIONEVENTS;
import curam.message.BPOCASEUSERROLE;
import curam.message.impl.ENTAUDITPLANExceptionCreator;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.selectionquery.impl.SelectionQuery;
import curam.selectionquery.impl.SelectionQueryDAO;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.LocalisableString;
import curam.util.exception.InformationalElement.InformationalType;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.StringHelper;


/**
 * Implementation for AuditPlan.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditPlan
 */
// BEGIN, CR00183334, PS
public class AuditPlanImpl extends SingleTableEntityImpl<AuditPlanDtls>
  implements AuditPlan {
  // END, CR00183334

  @Inject
  protected CaseAuditDAO caseAuditDAO;

  @Inject
  protected AuditCaseConfigDAO auditCaseConfigDAO;

  @Inject
  protected AuditPlanFocusAreaDAO auditPlanFocusAreaDAO;

  @Inject
  protected AuditPlanTransactionLogDAO auditPlanTransactionLogDAO;

  @Inject
  protected AuditPlanDAO auditPlanDAO;

  @Inject
  protected AuditPlanCriteriaDAO auditPlanCriteriaDAO;

  @Inject
  protected SelectionQueryDAO selectionQueryDAO;

  // ___________________________________________________________________________
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected AuditPlanImpl() {
    // no-arg constructor for use only by Guice
    // END, CR00183334
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the audit plan record.
   *
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
    
    // BEGIN, CR00210526, GD
    // validate the coordinator and current user have correct security access
    validateCoordinatorAccess();
    validateCurrentUserAccess();
    // END, CR00210526, GD

    insertAuditPlanCreatedTransaction();
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new audit plan transaction log record to record that a new audit
   * plan has been created.
   *
   * @throws InformationalException
   */
  protected void insertAuditPlanCreatedTransaction()
    throws InformationalException {

    LocalisableString description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.AUDIT_PLAN_CREATED).arg(
      this.getAuditPlanReference());

    createAuditPlanTransactionLog(
      AUDITPLANTRANSACTIONTYPEEntry.AUDIT_PLAN_CREATED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new audit plan transaction log record to record that the
   * coordinator of the audit plan has changed.
   *
   * @throws InformationalException
   * @throws AppException
   */
  protected void insertCoordinatorChangedTransaction(
    final String previousCoordinator, final String newCoordinator)
    throws InformationalException, AppException {

    UserAccess userAccessObj = UserAccessFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    usersKey.userName = previousCoordinator;
    String previousCoordinatorFullName = userAccessObj.getFullName(usersKey).fullname;

    usersKey.userName = newCoordinator;
    String newCoordinatorFullName = userAccessObj.getFullName(usersKey).fullname;

    LocalisableString description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.COORDINATOR_CHANGED).arg(previousCoordinatorFullName).arg(
      newCoordinatorFullName);

    createAuditPlanTransactionLog(
      AUDITPLANTRANSACTIONTYPEEntry.COORDINATOR_CHANGED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new audit plan transaction log record to record that a new audit
   * plan has been created.
   *
   * @throws InformationalException
   */
  protected void insertAuditPlanCompletedTransaction()
    throws InformationalException {

    LocalisableString description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.AUDIT_PLAN_COMPLETED).arg(
      this.getAuditPlanReference());

    createAuditPlanTransactionLog(
      AUDITPLANTRANSACTIONTYPEEntry.AUDIT_PLAN_COMPLETED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new audit plan transaction log record to record that the schedule
   * was removed from the audit plan.
   *
   * @param scheduleStartDate
   * The value of the schedule end date
   *
   * @param scheduleEndDate
   * The value of the schedule start date
   * @throws InformationalException
   */
  protected void insertScheduleRemovedTransaction(final Date scheduleStartDate,
    final Date scheduleEndDate) throws InformationalException {

    LocalisableString description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.SCHEDULE_REMOVED).arg(this.getAuditPlanReference()).arg(scheduleStartDate).arg(
      scheduleEndDate);

    createAuditPlanTransactionLog(
      AUDITPLANTRANSACTIONTYPEEntry.SCHEDULE_REMOVED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new audit plan transaction log record to record that the schedule
   * was changed on the audit plan.
   *
   * @param oldScheduleStartDate
   * The schedule start date before it was modified
   * @param oldScheduleEndDate
   * The schedule end date before it was modified
   * @param newScheduleStartDate
   * The new value of the schedule start date
   * @param newScheduleEndDate
   * The new value of the schedule end date
   *
   * @throws InformationalException
   */
  protected void insertScheduleChangedTransaction(
    final Date oldScheduleStartDate, final Date oldScheduleEndDate,
    final Date newScheduleStartDate, final Date newScheduleEndDate)
    throws InformationalException {

    LocalisableString description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.SCHEDULE_CHANGED).arg(oldScheduleStartDate).arg(oldScheduleEndDate).arg(newScheduleStartDate).arg(
      newScheduleEndDate);

    createAuditPlanTransactionLog(
      AUDITPLANTRANSACTIONTYPEEntry.SCHEDULE_CHANGED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a new audit plan transaction log record to record that the schedule
   * was changed on the audit plan.
   *
   * @param scheduleStartDate
   * The value of the schedule end date
   *
   * @param scheduleEndDate
   * The value of the schedule start date
   * @throws InformationalException
   */
  protected void insertScheduleAddedTransaction(final Date scheduleStartDate,
    final Date scheduleEndDate) throws InformationalException {

    LocalisableString description = new LocalisableString(BPOAUDITPLANTRANSACTIONEVENTS.SCHEDULE_ADDED).arg(scheduleStartDate).arg(scheduleEndDate).arg(
      this.getAuditPlanReference());

    createAuditPlanTransactionLog(AUDITPLANTRANSACTIONTYPEEntry.SCHEDULE_ADDED,
      description.getMessage(TransactionInfo.getProgramLocale()), getID());
  }

  // ___________________________________________________________________________
  /**
   * Inserts a audit plan transaction log record.
   *
   * @param transactionType
   * The value of the schedule start date
   * @param description
   * Transaction log description text
   * @param relatedID
   * Optional value for the id of the related object
   *
   * @throws InformationalException
   */
  protected void createAuditPlanTransactionLog(
    final AUDITPLANTRANSACTIONTYPEEntry transactionType,
    final String description, final long relatedID)
    throws InformationalException {

    AuditPlanTransactionLog auditPlanTransactionLog = auditPlanTransactionLogDAO.newInstance();

    auditPlanTransactionLog.setAuditPlan(this);
    auditPlanTransactionLog.setTransactionType(transactionType);
    auditPlanTransactionLog.setUserName(TransactionInfo.getProgramUser());
    auditPlanTransactionLog.setRelatedID(relatedID);
    auditPlanTransactionLog.setDescription(description);
    auditPlanTransactionLog.insert();
  }
  
  // BEGIN, CR00222185, GD 
  // ____________________________________________________________________________
  /**
   * Create a notifications to the case owner and case supervisor, informing 
   * them that case(s) that they are the case owner / supervisor of are 
   * scheduled for audit. 
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void createScheduledAuditPlanNotification()
    throws AppException, InformationalException {

    ScheduledAuditPlanNotificationDetails scheduledAuditPlanNotificationDetails;

    Map<String, Set<String>> supervisorCaseRefList = new HashMap<String, Set<String>>(); 
    Map<String, Set<String>> caseownerCaseRefList = new HashMap<String, Set<String>>(); 
    
    // Loop list of cases on the audit plan create list of cases for each 
    // supervisor and each case owner
    Set<CaseAudit> caseAuditSet = getCaseAudits();
    
    CaseAuditTaskManagement caseAuditTaskManagementObj = CaseAuditTaskManagementFactory.newInstance();

    for (CaseAudit caseAudit : caseAuditSet) {
      
      String caseReference = caseAudit.getCase().getCaseReference();
           
      CaseHeader caseHeader = caseAudit.getCase();

      CaseUserRoleCaseIDKey caseUserRoleCaseIDKey = new CaseUserRoleCaseIDKey();

      caseUserRoleCaseIDKey.dtls.caseID = caseHeader.getID();

      CaseUserRole caseUserRoleObj = CaseUserRoleFactory.newInstance();

      // Get the case owners and add them to the set
      CaseUserRoleDetailsList caseUserRoleDetailsList = caseUserRoleObj.listCaseUserRoles(
        caseUserRoleCaseIDKey);
      
      // Don't display any message in relation to the supervisor being 
      // dynamically assigned
      TransactionInfo.getInformationalManager().acceptWarning(
        CuramConst.gkEmpty,
        new AppException(BPOCASEUSERROLE.INF_SUPERVISOR_DYNAMICALLY_ASSIGNED));
      
      for (int i = 0; i < caseUserRoleDetailsList.dtls.size(); i++) {
        CaseUserRoleDetails caseUserRoleDetails = caseUserRoleDetailsList.dtls.item(i).dtls;
        
        if (caseUserRoleDetails.typeCode.equals(CASEUSERROLETYPE.OWNER)) {
          String caseowner = caseUserRoleDetails.ownerDetails.userName;

          if (caseownerCaseRefList.containsKey(caseowner)) {
            // add case reference to existing set
            caseownerCaseRefList.get(caseowner).add(caseReference);
          } else {
            // create case reference set for this case owner
            Set<String> caseReferenceList = new HashSet<String>();

            caseReferenceList.add(caseReference);
            caseownerCaseRefList.put(caseowner, caseReferenceList);
          }          
        } else if (caseUserRoleDetails.typeCode.equals(
          CASEUSERROLETYPE.SUPERVISOR)) {
          String supervisor = caseUserRoleDetails.ownerDetails.userName;

          if (supervisorCaseRefList.containsKey(supervisor)) {
            // add case reference to existing set
            supervisorCaseRefList.get(supervisor).add(caseReference);
          } else {
            // create case reference set for this supervisor
            Set<String> caseReferenceList = new HashSet<String>();

            caseReferenceList.add(caseReference);
            supervisorCaseRefList.put(supervisor, caseReferenceList);
          }
        }
      }
    }
    
    // loop list of supervisors 
    Set <String> supervisors = supervisorCaseRefList.keySet();
    
    for (String supervisor : supervisors) {
      Set <String> caseReferences = supervisorCaseRefList.get(supervisor);
      
      scheduledAuditPlanNotificationDetails = new ScheduledAuditPlanNotificationDetails();
      scheduledAuditPlanNotificationDetails.username = supervisor;
      
      scheduledAuditPlanNotificationDetails.caseRefList = createCaseReferenceList(
        caseReferences);
        
      caseAuditTaskManagementObj.sendScheduledAuditPlanSupervisorNotification(
        scheduledAuditPlanNotificationDetails);
    }
    
    // loop list of case owners 
    Set <String> caseowners = caseownerCaseRefList.keySet();
    
    for (String caseowner : caseowners) {
      Set <String> caseReferences = caseownerCaseRefList.get(caseowner);
      
      scheduledAuditPlanNotificationDetails = new ScheduledAuditPlanNotificationDetails();
      scheduledAuditPlanNotificationDetails.username = caseowner;
      scheduledAuditPlanNotificationDetails.caseRefList = createCaseReferenceList(
        caseReferences);
      
      caseAuditTaskManagementObj.sendScheduledAuditPlanCaseownerNotification(
        scheduledAuditPlanNotificationDetails);
    }
    
    // Check that no informational warnings other than those expecting, were 
    // generated.
    TransactionInfo.getInformationalManager().failOperation(); 
  }  

  // END, CR00222185
  
  
  // BEGIN, CR00219064, GD 
  // ____________________________________________________________________________
  /**
   * Create a notification to inform the audit coordinator that the random case
   * sample has been generated. 
   *
   * @throws AppException
   * @throws InformationalException
   */
  protected void createCaseSampleListGeneratedNotification()
    throws AppException, InformationalException {

    CaseSampleListGeneratedNotificationDetails caseSampleListGeneratedNotificationDetails = new CaseSampleListGeneratedNotificationDetails();

    caseSampleListGeneratedNotificationDetails.auditPlanID = getID();
    caseSampleListGeneratedNotificationDetails.auditPlanRef = getAuditPlanReference();
    caseSampleListGeneratedNotificationDetails.coordinator = getCoordinator();

    CaseAuditTaskManagementFactory.newInstance().sendCaseSampleListGeneratedNotification(
      caseSampleListGeneratedNotificationDetails);
  }

  // END, CR00219064

  // ___________________________________________________________________________
  /**
   * Modifies the audit plan record.
   *
   * @param versionNo
   * The version number of the audit plan record.
   * @throws InformationalException
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {

    validateStatus();
    
    // Check that the audit plan has not been cancelled
    if (!getRecordStatus().equals(RECORDSTATUSEntry.NORMAL)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_RV_CANNOT_MODIFY_CANCELLED_AUDIT_PLAN(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    
    // BEGIN, CR00210526, GD
    // validate the coordinator and current user have correct security access
    validateCoordinatorAccess();
    validateCurrentUserAccess();
    // END, CR00210526
    
    super.modify(versionNo);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void changeCoordinator(final Integer versionNo,
    final String coordinator) throws AppException, InformationalException {

    String previousCoordinator = getCoordinator();

    // save the full name of the user reassigning the audit plan
    UsersKey usersKey = new UsersKey();
    UserAccess userAccessObj = UserAccessFactory.newInstance();

    usersKey.userName = userAccessObj.getUserDetails().userName;
    String reassignedByFullName = userAccessObj.getUserDetails(usersKey).fullName.toUpperCase();

    setCoordinator(coordinator);

    modify(versionNo);

    if (reassignedByFullName != null
      && !reassignedByFullName.equals(CuramConst.gkEmpty)) {

      // send a notification to the new coordinator
      CaseAuditTaskManagement caseAuditTaskManagementObj = CaseAuditTaskManagementFactory.newInstance();
      AssignCoordinatorNotificationDetails assignCoordinatorNotificationDtls = new AssignCoordinatorNotificationDetails();

      assignCoordinatorNotificationDtls.auditPlanID = getID();
      assignCoordinatorNotificationDtls.auditPlanReference = getDtls().auditPlanReference;
      assignCoordinatorNotificationDtls.newCoordUserName = getDtls().coordinator;
      assignCoordinatorNotificationDtls.reassignedByFullName = reassignedByFullName;

      caseAuditTaskManagementObj.sendAssignCoordinatorRoleNotification(
        assignCoordinatorNotificationDtls);
    }

    insertCoordinatorChangedTransaction(previousCoordinator, coordinator);
  }

  // ___________________________________________________________________________
  /**
   * Sets the status of the audit plan to cancelled.
   *
   * @param versionNo
   * The version number of the audit plan.
   * @throws InformationalException
   */
  public void cancel(final int versionNo) throws InformationalException {

    validateStatus();

    if (!getDtls().auditPlanStatus.equals(AUDITPLANSTATUS.PENDING)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_XFV_CANNOT_CANCEL_AUDITPLAN_UNLESS_STATUS_PENDING(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Check that it's not possible to remove a cancelled audit plan.
    if (getRecordStatus().equals(RECORDSTATUSEntry.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_RV_CANNOT_MODIFY_REMOVE_AUDIT_PLAN(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    getDtls().recordStatus = RECORDSTATUSEntry.CANCELLED.getCode();
    super.modify(versionNo);
  }

  // ___________________________________________________________________________
  /**
   * Method to return the current lifecycle state of the audit plan.
   *
   * @return The current lifecycle state
   */
  public AUDITPLANSTATUSEntry getLifecycleState() {
    return AUDITPLANSTATUSEntry.get(getDtls().auditPlanStatus);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getDtls().comments;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setComments(final String comments) {
    getDtls().comments = comments;

    final long commentsLength = getDtls().comments.length();

    if (commentsLength > AuditPlanAdapter.kMaxLength_comments) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_FV_COMMENTS_LONG(
          AuditPlanAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public boolean areCasesUserSelected() {
    return getDtls().casesUserSelected;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AUDITPLANUSERACCESSEntry getUserAccess() {
    return AUDITPLANUSERACCESSEntry.get(getDtls().userAccess);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getCoordinator() {
    return getDtls().coordinator;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getCreatedBy() {
    return getDtls().createdBy;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Date getCreatedDate() {
    return getDtls().createdDate;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public int getNumberCases() {
    return getDtls().numberCases;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public double getPercentageCases() {
    return getDtls().percentageCases;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AUDITPLANPRIORITYEntry getPriority() {
    return AUDITPLANPRIORITYEntry.get(getDtls().priority);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AUDITPLANPURPOSEEntry getPurpose() {
    return AUDITPLANPURPOSEEntry.get(getDtls().purpose);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public RECORDSTATUSEntry getRecordStatus() {
    return RECORDSTATUSEntry.get(getDtls().recordStatus);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getScheduleComments() {
    return getDtls().scheduleComments;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Date getScheduledEndDate() {
    return getDtls().scheduledEndDate;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Date getScheduledStartDate() {
    return getDtls().scheduledStartDate;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<CaseAudit> getCaseAudits() {
    return caseAuditDAO.searchByAuditPlan(this);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getAuditPlanReference() {
    return getDtls().auditPlanReference;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getSummaryFindings() throws AppException,
      InformationalException {
    // BEGIN, CR00221556, GD
    return getDtls().findingsText;
    // END, CR00221556
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public SelectionQuery getSelectionQuery() 
    throws AppException, InformationalException {
    return selectionQueryDAO.get(getDtls().selectionQueryID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setUserAccess(final AUDITPLANUSERACCESSEntry userAccess) {
    getDtls().userAccess = userAccess.getCode();

    // If user involvement has been modified check that the status
    // of the audit plan is Pending
    if (!getLifecycleState().equals(AUDITPLANSTATUSEntry.PENDING)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_RV_CANNOT_MODIFY_USER_ACCESS_STATUS_NOT_PENDING(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setCasesUserSelected(final boolean casesUserSelected) {
    getDtls().casesUserSelected = casesUserSelected;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @throws InformationalException
   * @throws AppException
   */
  public void setCoordinator(final String coordinator)
    throws AppException, InformationalException {

    // BEGIN, CR00385977, KRK
    // Check the security roles are restricted for assignments.
    final boolean isUserRoleRestricted = Configuration.getBooleanProperty(
      EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES_DEFAULT));

    // END, CR00385977
    
    // set the coordinator
    getDtls().coordinator = coordinator;

    // BEGIN, CR00385977, KRK
    if (isUserRoleRestricted) {
    
      // Validate the role name against current user.
      final UsersKey usersKey = new UsersKey();

      usersKey.userName = coordinator;
      
      final String roleName = UserAccessFactory.newInstance().getUserDetails(usersKey).roleName;

      if (!CaseAuditConst.kCoordinatorUserRoleName.equals(roleName)) {

        ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTAUDITPLANExceptionCreator.ERR_FV_COORD_BADUSER(
            CaseAuditConst.kCoordinatorUserRoleName),
            ValidationManagerConst.kSetOne,
            0);
      }
    }
    // END, CR00385977
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setNumberCases(final int numberCases) {
    getDtls().numberCases = numberCases;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setPercentageCases(final double percentageCases) {
    getDtls().percentageCases = percentageCases;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setPriority(final AUDITPLANPRIORITYEntry priority) {
    getDtls().priority = priority.getCode();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setPurpose(final AUDITPLANPURPOSEEntry purpose) {
    getDtls().purpose = purpose.getCode();

    if (!getLifecycleState().equals(AUDITPLANSTATUSEntry.PENDING)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_RV_CANNOT_MODIFY_PURPOSE_STATUS_NOT_PENDING(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setScheduleComments(final String scheduleComments) {
    getDtls().scheduleComments = scheduleComments;
  }

  // ___________________________________________________________________________
  /**
   * Sets the scheduled end date of this audit plan.
   *
   * @param scheduledEndDate
   * The scheduled end date of this audit plan
   */
  protected void setScheduledEndDate(final Date scheduledEndDate) {
    getDtls().scheduledEndDate = scheduledEndDate;
  }

  // ___________________________________________________________________________
  /**
   * Sets the scheduled start date of this audit plan.
   *
   * @param scheduledStartDate
   * The scheduled start date of this audit plan
   */
  protected void setScheduledStartDate(final Date scheduledStartDate) {
    getDtls().scheduledStartDate = scheduledStartDate;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setAuditCaseConfig(final AuditCaseConfig auditCaseConfig) {
    getDtls().auditCaseConfigID = auditCaseConfig.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setSelectionQuery(final SelectionQuery selectionQuery) 
    throws AppException, InformationalException {
    getDtls().selectionQueryID = selectionQuery.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setSummaryFindings(final String findings)
    throws AppException, InformationalException {

    // BEGIN, CR00189182, AF
    // Ensure that some text has been entered for Summary Findings
    String tmpString = findings;

    String removedSpacesString = tmpString.replaceAll("[\\s]+", "").replaceAll("<br/>", "").replaceAll(
      "[\\u00A0]+", "");

    if (removedSpacesString.trim().length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_XFV_TEXT_FOR_AUDIT_PLAN_FINDINGS_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00189182

    // Validate that the user can modify the findings
    validateUser();

    // BEGIN, CR00221556, GD
    getDtls().findingsText = findings;
    // END, CR00221556
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public boolean areSummaryFindingsEntered() {
    // BEGIN, CR00221556, GD
    return !StringHelper.isEmpty(getDtls().findingsText);
    // END, CR00221556
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public boolean areAllCaseAuditsComplete() {
    boolean allComplete = true;
    // make sure all audits are complete
    Set<CaseAudit> caseAuditSet = getCaseAudits();

    for (CaseAudit caseAudit : caseAuditSet) {

      if (!caseAudit.getLifecycleState().equals(CASEAUDITSTATUSEntry.COMPLETE)) {
        allComplete = false;
        // BEGIN, CR00202947, GD
        break;
        // END, CR00202947
      }
    }

    return allComplete;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AuditCaseConfig getAuditCaseConfig() {
    return auditCaseConfigDAO.get(getDtls().auditCaseConfigID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @throws InformationalException
   */
  public void setSchedule(final Date scheduleStartDate,
    final Date scheduleEndDate) throws InformationalException {

    // if this is a modification to an existing record
    if (getID() != null) {

      AuditPlan existingAuditPlan = auditPlanDAO.get(getID());
      Date oldScheduleStartDate = existingAuditPlan.getScheduledStartDate();
      Date oldScheduleEndDate = existingAuditPlan.getScheduledEndDate();

      // Detect if audit plan schedule has been added or modified
      if ((!oldScheduleStartDate.equals(scheduleStartDate))
        || (!oldScheduleEndDate.equals(scheduleEndDate))) {
        // schedule has been changed but is it a new schedule or a modification
        // to an existing schedule

        if ((oldScheduleStartDate.isZero()) && (oldScheduleEndDate.isZero())) {
          // new schedule
          insertScheduleAddedTransaction(scheduleStartDate, scheduleEndDate);
        } else {
          // modified schedule
          insertScheduleChangedTransaction(oldScheduleStartDate,
            oldScheduleEndDate, scheduleStartDate, scheduleEndDate);
        }
      }
    }

    setScheduledStartDate(scheduleStartDate);
    setScheduledEndDate(scheduleEndDate);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   *
   * @throws InformationalException
   */
  public void removeSchedule(final int versionNo)
    throws InformationalException {

    if (getLifecycleState().equals(AUDITPLANSTATUSEntry.PENDING)) {
      Date scheduleStartDate = getScheduledStartDate();
      Date scheduleEndDate = getScheduledEndDate();

      setScheduleComments("");
      setScheduledStartDate(Date.kZeroDate);
      setScheduledEndDate(Date.kZeroDate);
      modify(versionNo);
      insertScheduleRemovedTransaction(scheduleStartDate, scheduleEndDate);

    } else {
      InformationalManager infoManager = TransactionInfo.getInformationalManager();

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_AUDIT_PLAN_CANNOT_DELETE_SCHEDULE(),
        "", InformationalType.kError,
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

      infoManager.failOperation();
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00222185, GD
  public void beginAudit(final int versionNo) 
    throws AppException, InformationalException {
    // END, CR00222185

    // BEGIN, CR00223243, GD
    // check to see if the audit is already in progress, if it is do nothing. 
    if (getLifecycleState().equals(AUDITPLANSTATUSEntry.INPROGRESS)) {
      return;
    }
    // END, CR00223243
    
    validateStatus();

    // all case audits must be assigned
    Set<CaseAudit> caseAuditSet = getCaseAudits();

    if (caseAuditSet.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_XRV_CASE_AUDITS_REQUIRED_FOR_INPROGRESS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    boolean atLeastOneCaseAuditAssigned = false;

    for (CaseAudit caseAudit : caseAuditSet) {

      if (caseAudit.getLifecycleState().equals(CASEAUDITSTATUSEntry.ASSIGNED)) {
        atLeastOneCaseAuditAssigned = true;
        break;
      }
    }

    if (!atLeastOneCaseAuditAssigned) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_XFV_CASE_AUDITS_MUST_BE_ASSIGNED_FOR_INPROGRESS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Check that at least one focus area has been associated
    List<AuditPlanFocusArea> auditPlanFocusAreaList = auditPlanFocusAreaDAO.searchBy(
      this);

    if (auditPlanFocusAreaList.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_XRV_FOCUS_AREA_REQUIRED_FOR_INPROGRESS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    getDtls().auditPlanStatus = AUDITPLANSTATUSEntry.INPROGRESS.getCode();

    super.modify(versionNo);
    
    // BEGIN, CR00222185, GD
    // Send Scheduled Audit Plan Notification if the 
    if (!getUserAccess().equals(AUDITPLANUSERACCESSEntry.NOACCESS)) {
      createScheduledAuditPlanNotification();
    }
    // END, CR00222185
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void complete(final int versionNo) throws InformationalException {

    validateStatus();

    // make sure all audits are complete
    Set<CaseAudit> caseAuditSet = getCaseAudits();

    for (CaseAudit caseAudit : caseAuditSet) {

      if (!caseAudit.getLifecycleState().equals(CASEAUDITSTATUSEntry.COMPLETE)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTAUDITPLANExceptionCreator.ERR_XFV_CASE_AUDITS_MUST_BE_COMPLETE_BEFORE_COMPLETION(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }

    // BEGIN, CR00189182 AF
    // Ensure that some summary findings have been recorded for the audit plan
    if (!areSummaryFindingsEntered()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_XFV_AUDIT_PLAN_FINDINGS_MUST_BE_SPECIFIED_BEFORE_COMPLETION(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    // END, CR00189182
    // Ensure the Audit plan is in progress before it can be completed.
    if (!getLifecycleState().equals(AUDITPLANSTATUSEntry.INPROGRESS)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_AUDIT_PLAN_INVALID_STATE_TO_COMPLETE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    getDtls().auditPlanStatus = AUDITPLANSTATUSEntry.COMPLETE.getCode();

    super.modify(versionNo);

    insertAuditPlanCompletedTransaction();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * Cross field validations
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link ENTAUDITPLAN#ERR_FV_SCHEDULED_START_DATE_TOO_BIG} -
   * If the scheduled start date is after the scheduled end date.</li>
   * <li>
   * {@link ENTAUDITPLAN#ERR_AUDIT_PLAN_INVALID_STATE_TO_COMPLETE} -
   * If the scheduled start date or end date is not specified and the user is trying to
   * change the status of the audit plan to 'In Progress'.</li>
   *
   */
  public void crossFieldValidation() {

    if (!getDtls().scheduledStartDate.isZero()
      && !getDtls().scheduledEndDate.isZero()
      && getDtls().scheduledStartDate.after(getDtls().scheduledEndDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_FV_SCHEDULED_START_DATE_TOO_BIG(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!getLifecycleState().equals(AUDITPLANSTATUSEntry.PENDING)
      && !getLifecycleState().equals(AUDITPLANSTATUSEntry.DELAYPROC)) {

      // scheduled start date or end must be set
      if (getDtls().scheduledStartDate.isZero()
        || getDtls().scheduledEndDate.isZero()) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTAUDITPLANExceptionCreator.ERR_AUDIT_PLAN_INVALID_STATE_TO_COMPLETE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * Mandatory field validations
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link ENTAUDITPLAN#ERR_FV_MANDATORY_USER_ACCESS_NOT_SET} -
   * If user access level is not specified.</li>
   * <li>
   * {@link ENTAUDITPLAN#ERR_FV_MANDATORY_PURPOSE_NOT_SET} -
   * If mandatory purpose is not specified.</li>
   * <li>
   * {@link ENTAUDITPLAN#ERR_FV_MANDATORY_PRIORITY_NOT_SET} -
   * If mandatory priority is not specified.</li>
   * <li>
   * {@link ENTAUDITPLAN#ERR_FV_MANDATORY_COORDINATOR_NOT_SET} -
   * If mandatory coordinator is not specified.</li>
   * <li>
   * {@link ENTAUDITPLAN#ERR_FV_MANDATORY_AUDIT_CASE_CONFIG_NOT_SET} -
   * If the audit plan is not associated with an audit case config record.</li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    if (getDtls().userAccess.equals(
      AUDITPLANUSERACCESSEntry.NOT_SPECIFIED.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_FV_MANDATORY_USER_ACCESS_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getDtls().purpose.equals(AUDITPLANPURPOSEEntry.NOT_SPECIFIED.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_FV_MANDATORY_PURPOSE_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getDtls().priority.equals(
      AUDITPLANPRIORITYEntry.NOT_SPECIFIED.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_FV_MANDATORY_PRIORITY_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (StringHelper.isEmpty(getDtls().coordinator)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_FV_MANDATORY_COORDINATOR_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getDtls().auditCaseConfigID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_FV_MANDATORY_AUDIT_CASE_CONFIG_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {

    UserAccess userAccessObj = UserAccessFactory.newInstance();
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();
    UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    try {
      // Create a unique, readable reference identifier for an audit plan.
      uniqueIDKeySet.keySetName = KeySets.KEY_SET_AUDITPLAN;
      getDtls().auditPlanReference = String.valueOf(
        uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet));
      getDtls().createdBy = userAccessObj.getUserDetails().userName;

    } catch (AppException ae) {
      throw new AppRuntimeException(ae);
    } catch (InformationalException ie) {
      throw new AppRuntimeException(ie);
    }

    getDtls().createdDate = Date.getCurrentDate();
    getDtls().auditPlanStatus = AUDITPLANSTATUSEntry.PENDING.getCode();
    getDtls().recordStatus = RECORDSTATUSEntry.NORMAL.getCode();
  }

  // ___________________________________________________________________________
  /**
   * Validates the audit plan status.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link ENTAUDITPLAN#ERR_RV_CANNOT_MODIFY_CANCELLED_AUDIT_PLAN} -
   * If you are modifying an audit plan that has been cancelled. </li>
   * <li>
   * {@link ENTAUDITPLAN#ERR_RV_CANNOT_MODIFY_COMPLETE_AUDIT_PLAN} -
   * If you are modifying an audit plan that has been completed. </li>
   * </ul>
   */
  protected void validateStatus() {

    // Check that the audit plan has not been completed
    if (getLifecycleState().equals(AUDITPLANSTATUSEntry.COMPLETE)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_RV_CANNOT_MODIFY_COMPLETE_AUDIT_PLAN(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public FocusAreaStatsList listFocusAreaStats() throws AppException,
      InformationalException {

    FocusAreaStatsList focusAreaStatsList = new FocusAreaStatsList();
    FocusAreaStats focusAreaStats;

    // Get all focus areas for the audit plan
    List<AuditPlanFocusArea> auditPlanFocusAreaList = auditPlanFocusAreaDAO.searchBy(
      this);

    for (AuditPlanFocusArea auditPlanFocusArea : auditPlanFocusAreaList) {

      focusAreaStats = new FocusAreaStats();

      // Retrieve pre defined focus area
      focusAreaStats.focusAreaText = CodeTable.getOneItemForUserLocale(
        AUDITCASEFOCUSAREA.TABLENAME,
        auditPlanFocusArea.getFocusArea().getCode());

      focusAreaStats.auditFocusAreaID = auditPlanFocusArea.getID();

      focusAreaStats.numSatisfied = caseAuditDAO.searchCaseAuditsForFocusArea(this, auditPlanFocusArea, FOCUSAREASATISFIEDEntry.YES).size();

      focusAreaStats.numNotSatisfied = caseAuditDAO.searchCaseAuditsForFocusArea(this, auditPlanFocusArea, FOCUSAREASATISFIEDEntry.NO).size();

      focusAreaStats.numNotExamined = caseAuditDAO.searchCaseAuditsForFocusArea(this, auditPlanFocusArea, FOCUSAREASATISFIEDEntry.NOT_SPECIFIED).size();

      focusAreaStatsList.dtls.addRef(focusAreaStats);
    }
    return focusAreaStatsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<AuditPlanFocusArea> getSelectedFocusAreas() {

    List<AuditPlanFocusArea> selectedFocusAreas = new ArrayList<AuditPlanFocusArea>();

    List<AuditPlanFocusArea> auditPlanFocusAreas = auditPlanFocusAreaDAO.searchBy(
      this);

    for (AuditPlanFocusArea auditPlanFocusArea : auditPlanFocusAreas) {

      if (!auditPlanFocusArea.getFocusArea().equals(
        AUDITCASEFOCUSAREAEntry.NOT_SPECIFIED)) {

        selectedFocusAreas.add(auditPlanFocusArea);
      }
    }

    return selectedFocusAreas;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public SortedSet<AuditPlanCriteria> getSelectedCriteria() {
    return auditPlanCriteriaDAO.searchByAuditPlan(this);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void clearCaseLoad() throws InformationalException {

    Set<curam.caseaudit.impl.CaseAudit> caseAudits = getCaseAudits();

    for (curam.caseaudit.impl.CaseAudit caseAudit : caseAudits) {
      caseAudit.remove(caseAudit.getVersionNo());
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void clearSelectionCriteria() throws InformationalException {

    SortedSet<AuditPlanCriteria> selectedCriteria = getSelectedCriteria();

    for (AuditPlanCriteria criteria : selectedCriteria) {
      criteria.remove();
    }
  }

  // ___________________________________________________________________________
  /**
   * Validates that the user can modify summary findings and complete the audit
   * plan. i.e. the user is either the audit coordinator
   *
   */
  protected void validateUser() {

    // Get the logged in user
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    String currentUser;

    try {
      currentUser = userAccessObj.getUserDetails().userName;
    } catch (AppException ae) {
      throw new AppRuntimeException(ae);
    } catch (InformationalException ie) {
      throw new AppRuntimeException(ie);
    }

    // Is the user the coordinator
    boolean isCoordinator = this.getCoordinator().equals(currentUser);

    // BEGIN, CR00385977, KRK
    // Check the security roles are restricted for assignments.
    final boolean isUserRoleRestricted = Configuration.getBooleanProperty(
      EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES_DEFAULT));   
    
    if (isUserRoleRestricted) {    
      if (!isCoordinator) {

        ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTAUDITPLANExceptionCreator.ERR_XRV_CANNOT_MODIFY_AUDIT_PLAN_INVALID_USER(),
          ValidationManagerConst.kSetOne, 0);
      }
    }       
    // END, CR00385977
  }
  
  // BEGIN, CR00210526, GD
  // ___________________________________________________________________________
  /**
   * Validates that the coordinator has security access to the audit plan.
   *
   * @throws InformationalException
   */
  protected void validateCoordinatorAccess() throws InformationalException {
    
    if (!StringHelper.isEmpty(getCoordinator())) {
      validateUserAccess(getCoordinator());
    } 
  }

  // ___________________________________________________________________________
  /**
   * Validates that current user has security access to the audit plan.
   */
  protected void validateCurrentUserAccess() throws InformationalException {
    
    // Get the logged in user
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    
    try {
      validateUserAccess(userAccessObj.getUserDetails().userName);
    } catch (AppException ae) {
      ValidationHelper.addValidationError(ae);
    }
  }
  
  // ___________________________________________________________________________
  /**
   * Validates that current user has security access to the audit plan.
   */
  protected void validateUserAccess(final String userName) 
    throws InformationalException {
    
    // verify that the current user has access to this case audit type
    CaseAuditSecurityManagement caseAuditSecurityManagementObj = CaseAuditSecurityManagementFactory.newInstance();
    
    CaseAuditSecurityKey caseAuditSecurityKey = new CaseAuditSecurityKey();

    caseAuditSecurityKey.auditPlanID = getID();
        
    try {
      caseAuditSecurityKey.userName = userName;
      caseAuditSecurityManagementObj.checkCaseAuditSecurity(
        caseAuditSecurityKey);
    } catch (AppException ae) {
      ValidationHelper.addValidationError(ae);
    }
  }

  // END, CR00210526
  
  // BEGIN, CR00219064, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void caseSampleListGenerated() 
    throws AppException, InformationalException {
    createCaseSampleListGeneratedNotification();
  }

  // END, CR00219064
  
  // BEGIN, CR00222185, GD
  // ___________________________________________________________________________
  /**
   * Build case reference comma separated list.
   * @param caseReferences set of case reference numbers
   * @return comma separated case reference list
   */
  protected String createCaseReferenceList(final Set <String> caseReferences) {
    StringBuffer caseReferenceList = new StringBuffer();
    
    // build case reference comma separated list 
    for (String caseReference : caseReferences) {
      caseReferenceList.append(caseReference);
      caseReferenceList.append(CuramConst.gkComma);
      caseReferenceList.append(CuramConst.gkSpace);
    }
    
    return caseReferenceList.substring(0, caseReferenceList.length() - 2);
  }

  // END, CR00222185

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void delayedProcessingPending(final int versionNo) 
    throws AppException, InformationalException {
    
    getDtls().auditPlanStatus = AUDITPLANSTATUSEntry.DELAYPROC.getCode();
    super.modify(versionNo);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void auditPlanPending(final int versionNo) 
    throws AppException, InformationalException {
    
    if (getLifecycleState().equals(AUDITPLANSTATUSEntry.DELAYPROC)) {
      getDtls().auditPlanStatus = AUDITPLANSTATUSEntry.PENDING.getCode();
      super.modify(versionNo);      
    } else {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITPLANExceptionCreator.ERR_AUDIT_PLAN_INVALID_STATE_FOR_PENDING(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }    
  }

  // BEGIN, CR00290965, IBM
  /**
   * Retrieves the total number of focus areas on an audit plan list 
   * details count.
   *
   * @return the statistics on the focus areas list details.
   *
   * @throws AppException   Generic Exception Signature.
   * @throws InformationalException   Generic Exception Signature. 
   */
  public FocusAreaStatsList listFocusAreaStatsCount() throws AppException,
      InformationalException {
    
    FocusAreaStatsList focusAreaStatsList = new FocusAreaStatsList();
    FocusAreaStats focusAreaStats;

    List<AuditPlanFocusArea> auditPlanFocusAreaList = auditPlanFocusAreaDAO.searchBy(
      this);

    for (AuditPlanFocusArea auditPlanFocusArea : auditPlanFocusAreaList) {

      focusAreaStats = new FocusAreaStats();

      focusAreaStats.focusAreaText = CodeTable.getOneItemForUserLocale(
        AUDITCASEFOCUSAREA.TABLENAME,
        auditPlanFocusArea.getFocusArea().getCode());

      focusAreaStats.auditFocusAreaID = auditPlanFocusArea.getID();

      focusAreaStats.numSatisfied = caseAuditDAO.countCaseAuditByFocusArea(this, auditPlanFocusArea, FOCUSAREASATISFIEDEntry.YES).numberOfRecords;

      focusAreaStats.numNotSatisfied = caseAuditDAO.countCaseAuditByFocusArea(this, auditPlanFocusArea, FOCUSAREASATISFIEDEntry.NO).numberOfRecords;

      focusAreaStats.numNotExamined = caseAuditDAO.countCaseAuditByFocusArea(this, auditPlanFocusArea, FOCUSAREASATISFIEDEntry.NOT_SPECIFIED).numberOfRecords;

      focusAreaStatsList.dtls.addRef(focusAreaStats);
    }
    return focusAreaStatsList;
  }
  // END, CR00290965
  
  
}
