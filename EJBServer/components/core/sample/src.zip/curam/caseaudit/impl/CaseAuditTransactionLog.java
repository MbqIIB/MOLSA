/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.CASEAUDITTRANSACTIONTYPEEntry;
import curam.util.persistence.Insertable;

/**
 * CaseAuditTransactionLog.
 * 
 */
@ImplementedBy(CaseAuditTransactionLogImpl.class)
public interface CaseAuditTransactionLog extends Insertable,
    CaseAuditTransactionLogAccessor {

  // ____________________________________________________________________________
  /**
   * Sets the CaseAudit record associated with this CaseAuditTransactionLog.
   * 
   * @param caseAudit
   *          The CaseAudit record associated with this CaseAuditTransactionLog
   */
  public void setCaseAudit(final CaseAudit caseAudit);

  // ____________________________________________________________________________
  /**
   * Sets the transaction type for this CaseAuditTransactionLog.
   * 
   * @param transactionType
   *          The transaction type of this CaseAuditTransactionLog
   */
  public void setTransactionType(
      final CASEAUDITTRANSACTIONTYPEEntry transactionType);

  // ___________________________________________________________________________
  /**
   * Sets the name of the user that created the CaseAuditTransactionLog record.
   * 
   * @param userName
   *          The name of the user that created the CaseAuditTransactionLog.
   */
  public void setUserName(final String userName);

  // ___________________________________________________________________________
  /**
   * Sets the description of the CaseAuditTransactionLog record.
   * 
   * @param description
   *          The description of the CaseAuditTransactionLog.
   */
  public void setDescription(final String description);

  // ___________________________________________________________________________
  /**
   * Sets the relatedID, the unique ID of the record the case audit transaction
   * log record relates to.
   * 
   * @param relatedID
   *          The unique ID of the related record.
   */
  public void setRelatedID(final long relatedID);

}
