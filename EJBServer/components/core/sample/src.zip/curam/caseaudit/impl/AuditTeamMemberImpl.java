/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2009, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.caseaudit.entity.struct.AuditTeamMemberDtls;
import curam.core.impl.EnvVars;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.infrastructure.impl.ValidationManagerConst;
import curam.core.sl.infrastructure.impl.ValidationManagerFactory;
import curam.core.struct.UsersKey;
import curam.message.impl.ENTAUDITTEAMMEMBERExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.resources.Configuration;


/**
 * Implementation for AuditTeamMember.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditTeamMember
 */
// BEGIN, CR00183334, PS
public class AuditTeamMemberImpl extends SingleTableEntityImpl<AuditTeamMemberDtls> implements AuditTeamMember {
  // END, CR00183334

  @Inject
  protected AuditorDAO auditorDAO;
  
  @Inject
  protected AuditTeamDAO auditTeamDAO;
  
  @Inject
  protected AuditTeamMemberDAO auditTeamMemberDAO;

  // ___________________________________________________________________________
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected AuditTeamMemberImpl() {
    // no-arg constructor for use only by Guice
    // END, CR00183334
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the member record.
   *
   */
  @Override
  public void insert() throws InformationalException {
    super.insert();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   * @throws InformationalException 
   * @throws AppException 
   */
  public void setAuditor(final Auditor auditor) 
    throws AppException, InformationalException {
    
    // BEGIN, CR00385977, KRK
    // Check the security roles are restricted for assignments.
    final boolean isUserRoleRestricted = Configuration.getBooleanProperty(
      EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_CASE_AUDIT_LIMITED_SECURITY_ROLES_DEFAULT));

    // END, CR00385977
    
    // set the auditor
    getDtls().auditorID = auditor.getID();   

    // BEGIN, CR00385977, KRK
    if (isUserRoleRestricted) {
      // Validate the role name against current user.
      final UsersKey usersKey = new UsersKey();
      
      usersKey.userName = auditor.getAuditorName();
      final String roleName = UserAccessFactory.newInstance().getUserDetails(usersKey).roleName;

      if (!CaseAuditConst.kAuditorUserRoleName.equals(roleName)
        && !CaseAuditConst.kCoordinatorUserRoleName.equals(roleName)) {

        ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          ENTAUDITTEAMMEMBERExceptionCreator.ERR_FV_AUDITOR_BADUSER(
            CaseAuditConst.kAuditorUserRoleName,
            CaseAuditConst.kCoordinatorUserRoleName),
            ValidationManagerConst.kSetOne,
            0);
      }
    }
    // END, CR00385977
    
    // BEGIN, CR00210526, GD
    // validate auditor has access to this case audit type
    auditor.validateAuditorAccess();
    // END, CR00210526

  }
  
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setAuditTeam(final AuditTeam auditTeam) {
    getDtls().teamID = auditTeam.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Auditor getAuditor() {
    return auditorDAO.get(getDtls().auditorID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {
    validateDuplicates();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {
        
    if (getDtls().teamID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITTEAMMEMBERExceptionCreator.ERR_FV_MANDATORY_AUDIT_TEAM_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getDtls().auditorID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITTEAMMEMBERExceptionCreator.ERR_FV_MANDATORY_USER_NAME_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// None Required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AuditTeam getAuditTeam() {
    return auditTeamDAO.get(getDtls().teamID);
  }
  
  // ___________________________________________________________________________
  /**
   * Validates that the user has not already been selected for the team.
   */
  protected void validateDuplicates() {

    List<curam.caseaudit.impl.AuditTeamMember> results = auditTeamMemberDAO.searchByAuditTeam(
      getAuditTeam());

    boolean duplicate = false;

    for (AuditTeamMember member: results) {
      if (member.getID() != this.getID()
        && member.getAuditor().equals(this.getAuditor())) {
        duplicate = true;
      }
    }
    
    if (duplicate) {      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITTEAMMEMBERExceptionCreator.ERR_XRV_DUPLICATE_MEMBER_EXISTS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }
}
