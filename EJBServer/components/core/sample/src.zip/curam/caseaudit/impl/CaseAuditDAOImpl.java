/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.google.inject.Singleton;

import curam.caseaudit.entity.impl.CaseAuditAdapter;
import curam.caseaudit.entity.struct.CaseAuditDtls;
import curam.caseaudit.fact.CaseAuditSecurityManagementFactory;
import curam.caseaudit.struct.CaseAuditSecurityKey;
import curam.codetable.impl.CASEAUDITSTATUSEntry;
import curam.codetable.impl.FOCUSAREASATISFIEDEntry;
import curam.core.facade.struct.CaseAuditListFilterKey;
import curam.core.facade.struct.MyCaseAuditSearchCriteria;
import curam.core.facade.struct.SearchAllCaseAuditsKey;
import curam.core.impl.CuramConst;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.Count;
import curam.core.struct.UserNameKey;
import curam.message.impl.ENTCASEAUDITExceptionCreator;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.DatabaseException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalElement.InformationalType;
import curam.util.persistence.StandardDAOImpl;
import curam.util.persistence.ValidationHelper;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringHelper;
import curam.util.type.StringList;
import curam.codetable.CASEAUDITSTATUS;


/**
 * Data access Implementation for {@linkplain curam.caseaudit.impl.CaseAudit}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.CaseAuditDAO
 */
@Singleton
// BEGIN, CR00183334, PS
public class CaseAuditDAOImpl extends StandardDAOImpl<CaseAudit, CaseAuditDtls>
  implements CaseAuditDAO {
  // END, CR00183334
  protected static final CaseAuditAdapter adapter = new CaseAuditAdapter();
    
  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected CaseAuditDAOImpl() {
    // END, CR00183334
    super(adapter, CaseAudit.class);
  }

  // ___________________________________________________________________________
  /**
   * CaseAudit Comparator.
   */
  protected class CaseAuditComparator implements Comparator<CaseAudit> {

    public CaseAuditComparator() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sort based on case audit reference.
     */
    public int compare(final CaseAudit o1, final CaseAudit o2) {
      long o1Ref = Long.parseLong(o1.getCaseAuditReference());
      long o2Ref = Long.parseLong(o2.getCaseAuditReference());

      if (o1Ref > o2Ref) {
        return 1;
      } else if (o1Ref < o2Ref) {
        return -1;
      } else {
        return 0;
      }
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<CaseAudit> searchByAuditPlan(final AuditPlan auditPlan) {
    // BEGIN, CR00210526, GD
    return filterCaseAuditSetBySID(
      newSet(adapter.searchByAuditPlanID(auditPlan.getID())));
    // END, CR00210526
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<CaseAudit> searchCaseAudits(final AuditPlan auditPlan,
    final String caseAuditReference, final Auditor auditor,
    final FOCUSAREASATISFIEDEntry focusAreasMet,
    final CASEAUDITSTATUSEntry caseAuditStatus) throws AppException,
      InformationalException {

    Set<CaseAudit> caseAuditSet = new TreeSet<CaseAudit>(
      new CaseAuditComparator());
    List<String> criteria = new ArrayList<String>();
    boolean atLeastOneCriteriaSpecified = false;
    CaseAuditListFilterKey key = new CaseAuditListFilterKey();

    if (auditPlan != null && auditPlan.getID() != 0) {
      atLeastOneCriteriaSpecified = true;
      key.auditPlanID = auditPlan.getID();
      criteria.add("auditPlanID = :auditPlanID");
    }

    if (caseAuditReference != null && caseAuditReference.length() != 0) {
      atLeastOneCriteriaSpecified = true;
      key.caseAuditReference = caseAuditReference;
      criteria.add("caseAuditReference = :caseAuditReference");
    }

    if (auditor != null && auditor.getID() != 0) {
      atLeastOneCriteriaSpecified = true;
      key.auditor = auditor.getID();
      criteria.add("auditorID = :auditor");
    }

    if (!caseAuditStatus.equals(CASEAUDITSTATUSEntry.NOT_SPECIFIED)) {
      atLeastOneCriteriaSpecified = true;
      key.caseAuditStatus = caseAuditStatus.getCode();
      criteria.add("caseAuditStatus = :caseAuditStatus");
    }

    if (!atLeastOneCriteriaSpecified) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_RV_NO_SEARCH_CRITERIA_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
      ValidationHelper.failIfErrorsExist();
    }

    StringBuffer sBuf = new StringBuffer();

    // BEGIN, CR00221556, GD
    sBuf.append("SELECT caseAuditID, auditPlanID, caseID, auditorID, ");
    sBuf.append("caseAuditReference, comments,caseAuditStatus, dateAssigned, ");
    sBuf.append("findingsText, versionNo INTO :caseAuditID, :auditPlanID, ");
    sBuf.append(":caseID, :auditorID, :caseAuditReference, ");
    sBuf.append(":comments, :caseAuditStatus, :dateAssigned, ");
    sBuf.append(":findingsText, :versionNo ");
    sBuf.append("FROM CASEAUDIT WHERE ");
    // END, CR00221556
    for (String condition : criteria) {
      sBuf.append(condition);
      // If this is the last element, just add a space
      if (criteria.indexOf(condition) == (criteria.size() - 1)) {
        sBuf.append(" ");
      } else {
        // Otherwise add AND
        sBuf.append(" AND ");
      }
    }
    sBuf.append("ORDER BY caseAuditID");
    
    // BEGIN, CR00316292, PMD
    // BEGIN, CR00290965, IBM
    // BEGIN, CR00316292, PMD
    // Call dynamic SQL API to execute SQL
    CuramValueList<CaseAuditDtls> curamValueList = DynamicDataAccess.executeNsMulti(
      CaseAuditDtls.class, key, false, false, sBuf.toString());

    // END, CR00316292
    // END, CR00290965
    // END, CR00316292
    
    for (int i = 0; i < curamValueList.size(); i++) {

      // Check if focus area satisfied is a search criteria
      if (!focusAreasMet.equals(FOCUSAREASATISFIEDEntry.NOT_SPECIFIED)) {

        // Check for any focus areas that have not been satisfied
        curam.caseaudit.impl.CaseAudit caseAudit = getEntity(
          curamValueList.get(i));

        List<FocusAreaFinding> focusAreaFindings = caseAudit.getFocusAreaFindings();

        boolean returnCase = false;

        for (FocusAreaFinding finding : focusAreaFindings) {

          // If a value of No for Focus Area Satisfied has been selected
          // as a search criteria and there is at least one case audit
          // finding which has not been satisfied then return
          if ((focusAreasMet.equals(FOCUSAREASATISFIEDEntry.NO))
            && (finding.getFocusAreaSatisfied().equals(
              FOCUSAREASATISFIEDEntry.NO))) {

            returnCase = true;
            break;
          } else // If a value of Yes for Focus Area Satisfied has been selected
          // as a search criteria and there is at least one case audit
          // finding which has been satisfied then return
          if ((focusAreasMet.equals(FOCUSAREASATISFIEDEntry.YES))
            && (finding.getFocusAreaSatisfied().equals(
              FOCUSAREASATISFIEDEntry.YES))) {

            returnCase = true;
            break;
          }
        }

        if (returnCase) {
          
          // BEGIN, CR00210526, GD
          CaseAudit caseAuditObj = getEntity(curamValueList.get(i)); 
          
          if (checkCaseAuditBySID(caseAuditObj)) {
            caseAuditSet.add(caseAuditObj);
          }
          // END, CR00210526
        }
      } else {

        // BEGIN, CR00210526, GD
        CaseAudit caseAuditObj = getEntity(curamValueList.get(i));
        
        if (checkCaseAuditBySID(caseAuditObj)) {
          caseAuditSet.add(caseAuditObj);
        }
        // END, CR00210526
      }
    }

    if (caseAuditSet.size() == 0) {

      if (searchByAuditPlan(auditPlan).size() != 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
          ENTCASEAUDITExceptionCreator.ERR_XFV_NO_RECORDS_MATCH_SEARCH_CRITERIA(),
          CuramConst.gkEmpty, InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      }
    }
    return caseAuditSet;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<CaseAudit> searchCaseAuditsForFocusArea(final AuditPlan auditPlan,
    final AuditPlanFocusArea auditPlanFocusArea,
    final FOCUSAREASATISFIEDEntry focusAreaMet) throws AppException,
      InformationalException {

    if (auditPlan == null || auditPlanFocusArea == null) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_RV_NO_SEARCH_CRITERIA_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
      ValidationHelper.failIfErrorsExist();
    }

    Set<CaseAudit> caseAuditSet = new TreeSet<CaseAudit>(
      new CaseAuditComparator());
    List<String> criteria = new ArrayList<String>();
    CaseAuditListFilterKey key = new CaseAuditListFilterKey();

    key.auditPlanID = auditPlan.getID();
    key.auditPlanFocusAreaID = auditPlanFocusArea.getID();

    criteria.add("CaseAudit.auditPlanID = :auditPlanID");
    criteria.add("CaseAudit.auditPlanID = AuditPlanFocusArea.auditPlanID");
    criteria.add("AuditPlanFocusArea.auditFocusAreaID = :auditPlanFocusAreaID");
    criteria.add(
      "AuditPlanFocusArea.auditFocusAreaID = "
        + "FocusAreaFinding.auditPlanFocusAreaID");
    criteria.add("CaseAudit.caseAuditID = FocusAreaFinding.caseAuditID"); 
    
    if (focusAreaMet.getCode().equals(CuramConst.gkEmpty)) {
      criteria.add("FocusAreaFinding.areaSatisfied IS NULL");
    } else {
      key.focusAreasMet = focusAreaMet.getCode();
      criteria.add("FocusAreaFinding.areaSatisfied = :focusAreasMet");
    }

    StringBuffer sBuf = new StringBuffer();

    // BEGIN, CR00221556, GD
    sBuf.append("SELECT CaseAudit.caseAuditID, CaseAudit.auditPlanID, caseID,");
    sBuf.append(" auditorID, caseAuditReference, comments, ");
    sBuf.append("caseAuditStatus, CaseAudit.dateAssigned, ");
    sBuf.append("CaseAudit.findingsText, CaseAudit.versionNo");
    sBuf.append(" INTO :caseAuditID, :auditPlanID, :caseID, :auditorID,");
    sBuf.append(" :caseAuditReference, :comments, :caseAuditStatus,");
    sBuf.append(" :dateAssigned, :findingsText, :versionNo FROM CASEAUDIT, ");
    sBuf.append("AUDITPLANFOCUSAREA, FOCUSAREAFINDING WHERE ");
    // END, CR00221556
    for (String condition : criteria) {
      sBuf.append(condition);
      // If this is the last element, just add a space
      if (criteria.indexOf(condition) == (criteria.size() - 1)) {
        sBuf.append(" ");
      } else {
        // Otherwise add AND
        sBuf.append(" AND ");
      }
    }
    sBuf.append("ORDER BY caseAuditID");

    // BEGIN, CR00290965, IBM
    // Call dynamic SQL API to execute SQL
    CuramValueList<CaseAuditDtls> curamValueList = DynamicDataAccess.executeNsMulti(
      CaseAuditDtls.class, key, false, true, sBuf.toString());

    // END, CR00290965
    
    for (int i = 0; i < curamValueList.size(); i++) {
      
      // BEGIN, CR00210526, GD
      CaseAudit caseAuditObj = getEntity(curamValueList.get(i)); 

      if (checkCaseAuditBySID(caseAuditObj)) {
        caseAuditSet.add(caseAuditObj);
      }
      // END, CR00210526
    }

    return caseAuditSet;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<CaseAudit> searchByAuditPlanAndCase(final AuditPlan auditPlan,
    final CaseHeader caseHeader) {
    // BEGIN, CR00210526, GD
    return filterCaseAuditListBySID(
      newList(
        adapter.searchByAuditPlanAndCaseID(auditPlan.getID(),
        caseHeader.getID())));
    // END, CR00210526
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<CaseAudit> searchByAuditPlanAndStatus(final AuditPlan auditPlan,
    final CASEAUDITSTATUSEntry caseAuditStatus) {

    // BEGIN, CR00210526, GD
    return filterCaseAuditListBySID(
      newList(
        adapter.searchByAuditPlanAndStatus(auditPlan.getID(),
        caseAuditStatus.getCode())));
    // END, CR00210526
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<CaseAudit> searchAllCaseAudits(final String auditPlanRef,
    final String caseAuditRef, final AuditCaseConfig auditCaseConfig,
    final CASEAUDITSTATUSEntry caseAuditStatus, final String auditor,
    final String coordinator) throws AppException, InformationalException {

    SearchAllCaseAuditsKey key = new SearchAllCaseAuditsKey();

    boolean atLeastOneCriteriaSpecifiedInd = false;
    boolean auditPlanNeededInd = false;

    StringBuffer selectBuf = new StringBuffer();
    StringBuffer fromBuf = new StringBuffer();
    StringBuffer whereBuf = new StringBuffer();

    List<String> criteria = new ArrayList<String>();
    List<String> apCriteria = new ArrayList<String>();

    List<CaseAudit> caseAuditList = new ArrayList<CaseAudit>();

    if (!StringHelper.isEmpty(caseAuditRef)) {
      atLeastOneCriteriaSpecifiedInd = true;
      criteria.add("CaseAudit.caseAuditReference = :caseAuditReference");
      key.caseAuditReference = caseAuditRef;
    }

    if (!caseAuditStatus.equals(CASEAUDITSTATUSEntry.NOT_SPECIFIED)) {
      atLeastOneCriteriaSpecifiedInd = true;
      criteria.add("CaseAudit.caseAuditStatus = :caseAuditStatus");
      key.caseAuditStatus = caseAuditStatus.getCode();
    }

    if (auditCaseConfig != null) {
      atLeastOneCriteriaSpecifiedInd = true;
      auditPlanNeededInd = true;
      apCriteria.add("AuditPlan.auditCaseConfigID = :auditCaseConfig");
      key.auditCaseConfig = auditCaseConfig.getID();
    }

    if (!StringHelper.isEmpty(auditPlanRef)) {
      atLeastOneCriteriaSpecifiedInd = true;
      auditPlanNeededInd = true;
      apCriteria.add("AuditPlan.auditPlanReference = :auditPlanReference");
      key.auditPlanReference = auditPlanRef;
    }

    if (!StringHelper.isEmpty(coordinator)) {
      atLeastOneCriteriaSpecifiedInd = true;
      auditPlanNeededInd = true;
      apCriteria.add("AuditPlan.coordinator = :coordinator");
      key.coordinator = coordinator;
    }
    
    // BEGIN, CR00229926, GD
    // BEGIN, CR00219367, GD
    if (!StringHelper.isEmpty(auditor)) {
      atLeastOneCriteriaSpecifiedInd = true;
      auditPlanNeededInd = true;

      StringBuffer auditorWhereBuf = new StringBuffer();
      
      auditorWhereBuf.append("( CaseAudit.auditorID in ");
      auditorWhereBuf.append("(SELECT auditorID ");
      auditorWhereBuf.append("FROM AUDITOR ");
      auditorWhereBuf.append("WHERE Auditor.userName = :auditor "); 
      auditorWhereBuf.append("UNION ");
      auditorWhereBuf.append("SELECT A2.auditorID ");
      auditorWhereBuf.append("FROM AUDITOR A1, AUDITOR A2, AUDITTEAMMEMBER ");
      auditorWhereBuf.append("WHERE A1.userName = :auditor AND ");
      auditorWhereBuf.append("AuditTeamMember.auditorID = A1.auditorID AND ");
      auditorWhereBuf.append("AuditTeamMember.teamID = A2.auditTeamID ))");
      apCriteria.add(auditorWhereBuf.toString());
      key.auditor = auditor;
    }
    // END, CR00219367
    // END, CR00229926

    // ensure at least one criteria specified
    if (!atLeastOneCriteriaSpecifiedInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_RV_NO_SEARCH_CRITERIA_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);

      ValidationHelper.failIfErrorsExist();
    }

    // setup select part of SQL statement
    // BEGIN, CR00221556, GD
    selectBuf.append("SELECT CaseAudit.caseAuditID, CaseAudit.auditPlanID, ");
    selectBuf.append("CaseAudit.caseID, CaseAudit.auditorID, ");
    selectBuf.append(" CaseAudit.caseAuditReference, ");
    selectBuf.append("CaseAudit.comments, CaseAudit.caseAuditStatus, ");
    selectBuf.append("CaseAudit.dateAssigned, CaseAudit.findingsText, ");
    selectBuf.append("CaseAudit.versionNo ");
    selectBuf.append("INTO :caseAuditID, :auditPlanID, :caseID, :auditorID, ");
    selectBuf.append(" :caseAuditReference, :comments, ");
    selectBuf.append(":caseAuditStatus, :dateAssigned, :findingsText, ");
    selectBuf.append(":versionNo ");
    // END, CR00221556
    
    // setup the tables to select from
    fromBuf.append("FROM CASEAUDIT");
    if (auditPlanNeededInd) {
      fromBuf.append(", AUDITPLAN");
    }

    whereBuf.append(" WHERE ");
    for (int i = 0; i < criteria.size(); i++) {
      whereBuf.append(criteria.get(i));
      if (i < criteria.size() - 1) {
        whereBuf.append(" AND ");
      }
    }
    if (auditPlanNeededInd) {
      if (criteria.size() != 0) {
        whereBuf.append(" AND ");
      }
      whereBuf.append("CaseAudit.auditPlanID = AuditPlan.auditPlanID AND ");
      for (int i = 0; i < apCriteria.size(); i++) {
        whereBuf.append(apCriteria.get(i));
        if (i < apCriteria.size() - 1) {
          whereBuf.append(" AND ");
        }
      }
    }
    
    // BEGIN, CR00290965, IBM
    // Call dynamic SQL API to execute SQL
    CuramValueList<CaseAuditDtls> curamValueList = DynamicDataAccess.executeNsMulti(
      CaseAuditDtls.class, key, false, true, 
      selectBuf.toString() + fromBuf.toString() + whereBuf.toString());

    // END, CR00290965

    for (int i = 0; i < curamValueList.size(); i++) {
   
      // BEGIN, CR00210526, GD
      CaseAudit caseAuditObj = getEntity(curamValueList.get(i));
      
      if (checkCaseAuditBySID(caseAuditObj)) {
        caseAuditList.add(caseAuditObj);
      }
      // END, CR00210526
    }

    return caseAuditList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<CaseAudit> searchByAssignedAuditorAndStatus(
    final StringList assignedToList, final StringList statusList)
    throws AppException, InformationalException {

    MyCaseAuditSearchCriteria key = new MyCaseAuditSearchCriteria();
    List<CaseAudit> caseAuditList = new ArrayList<CaseAudit>();

    // Create the list of user/teams assigned case audits
    StringBuffer assignedString = new StringBuffer();

    assignedString.append("(");
    
    for (int i = 0; i < assignedToList.size(); i++) {

      // BEGIN, CR00394955, BL
      if (checkSQLInputFormat(assignedToList.item(i), "[-0-9]+")) {
    
        assignedString.append(assignedToList.item(i));
        if (i < (assignedToList.size() - 1)) {
          assignedString.append(", ");
        }
      }
      // END, CR00394955
    }
    assignedString.append(")");

    // Create the list of audit status values to search on
    StringBuffer statusString = new StringBuffer();

    statusString.append("(");
    
    for (int i = 0; i < statusList.size(); i++) {

      // BEGIN, CR00394955, BL 
      if (checkSQLInputCode(statusList.item(i), CASEAUDITSTATUS.TABLENAME)) {
    
        // statusString.append("'");
        statusString.append("'");
        statusString.append(statusList.item(i));
        statusString.append("'");
        if (i < (statusList.size() - 1)) {
          statusString.append(", ");
        }
      }
      // END, CR00394955
    }
    statusString.append(")");

    StringBuffer sBuf = new StringBuffer();
    StringBuffer whereBuf = new StringBuffer();
    StringBuffer orderBuf = new StringBuffer();
    
    // BEGIN, CR00221556, GD
    sBuf.append("SELECT caseAuditID, auditPlanID, caseID, auditorID, ");
    sBuf.append("caseAuditReference, dateAssigned, comments, ");
    sBuf.append("caseAuditStatus, findingsText, versionNo INTO :caseAuditID,");
    sBuf.append(":auditPlanID, :caseID, :auditorID,");
    sBuf.append(" :caseAuditReference, :dateAssigned, :comments, ");
    sBuf.append(":caseAuditStatus, :findingsText, :versionNo ");
    sBuf.append("FROM CASEAUDIT ");
    // END, CR00221556
    
    if (assignedString.length() > 2) {
      whereBuf.append(" WHERE auditorID IN " + assignedString.toString());
    } else {
      whereBuf.append(" WHERE auditorID IN (null)");
    }
         
    if (!statusList.isEmpty()) {      
      whereBuf.append(" AND caseAuditStatus IN " + statusString.toString());
    }
    orderBuf.append(" ORDER BY caseAuditID");

    sBuf.append(whereBuf);
    sBuf.append(orderBuf);
        
    // BEGIN, CR00290965, IBM
    // Call dynamic SQL API to execute SQL
    CuramValueList<CaseAuditDtls> curamValueList = DynamicDataAccess.executeNsMulti(
      CaseAuditDtls.class, key, false, true, sBuf.toString());

    // END, CR00290965
    
    for (int i = 0; i < curamValueList.size(); i++) {

      // BEGIN, CR00210526, GD
      CaseAudit caseAuditObj = getEntity(curamValueList.get(i)); 
      
      if (checkCaseAuditBySID(caseAuditObj)) {
        caseAuditList.add(caseAuditObj);
      }
      // END, CR00210526
    }

    return caseAuditList;
  }

  // BEGIN, CR00394955, BL
  /***
   * Method to check an input string that will be used in a SQL statement has the correct format. 
   * Can be used to ensure no malicious content is passed in for SQL injection attack
   *
   * @param sqlInput - the input string
   * @param checkExpression - regular expression that the input string must match
   * @return Boolean whether the input string matches the expression
   *
   */
  private Boolean checkSQLInputFormat(String sqlInput, String checkExpression) {
    return sqlInput.matches(checkExpression);
  }
  
  /***
   * Method to check an input string that will be used in a SQL statement is a valid code. 
   * Can be used to ensure no malicious content is passed in for SQL injection attack
   *
   * @param sqlInput - the input string
   * @param codeTableName - the name of the code table that the code must be from
   * @return Boolean whether the code is a valid one
   *
   */
  private Boolean checkSQLInputCode(String sqlInput, String codeTableName) 
    throws DatabaseException, AppRuntimeException, AppException, InformationalException {
    return !(curam.util.type.CodeTable.getOneItem(codeTableName, sqlInput).equalsIgnoreCase(
      CuramConst.gkEmpty));
  }

  // END, CR00394955
  
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<CaseAudit> searchByUserName(final String userName)
    throws AppException, InformationalException {

    Set<CaseAudit> caseAuditSet = new TreeSet<CaseAudit>(
      new CaseAuditComparator());

    UserNameKey key = new UserNameKey();

    key.userName = userName;

    StringBuffer selectBuf = new StringBuffer();
    StringBuffer fromBuf = new StringBuffer();
    StringBuffer whereBuf = new StringBuffer();

    // Get the list of case audits assigned directly to the user
    // setup select part of SQL statement
    // BEGIN, CR00221556, GD
    selectBuf.append("SELECT CaseAudit.caseAuditID, CaseAudit.auditPlanID, ");
    selectBuf.append("CaseAudit.caseID, CaseAudit.auditorID, ");
    selectBuf.append("CaseAudit.caseAuditReference, ");
    selectBuf.append("CaseAudit.comments, CaseAudit.caseAuditStatus, ");
    selectBuf.append("CaseAudit.dateAssigned, CaseAudit.findingsText, ");
    selectBuf.append("CaseAudit.versionNo ");
    selectBuf.append("INTO :caseAuditID, :auditPlanID, :caseID, :auditorID, ");
    selectBuf.append(":caseAuditReference, :comments, ");
    selectBuf.append(":caseAuditStatus, :dateAssigned, :findingsText, ");
    selectBuf.append(":versionNo ");
    // END, CR00221556
    
    // setup the tables to select from
    fromBuf.append("FROM CASEAUDIT, AUDITOR ");

    whereBuf.append("WHERE Auditor.userName = :userName ");
    whereBuf.append("AND CaseAudit.auditorID = Auditor.auditorID");

    // Call dynamic SQL API to execute SQL
    CuramValueList<CaseAuditDtls> curamValueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
      curam.caseaudit.entity.struct.CaseAuditDtls.class, key, false,
      selectBuf.toString() + fromBuf.toString() + whereBuf.toString());

    for (int i = 0; i < curamValueList.size(); i++) {
      caseAuditSet.add(getEntity(curamValueList.get(i)));
    }

    selectBuf = new StringBuffer();
    fromBuf = new StringBuffer();
    whereBuf = new StringBuffer();

    // Get the list of case audits assigned to any teams
    // that the user is a part of
    // setup select part of SQL statement
    // BEGIN, CR00221556, GD
    selectBuf.append("SELECT CaseAudit.caseAuditID, CaseAudit.auditPlanID, ");
    selectBuf.append("CaseAudit.caseID, CaseAudit.auditorID, ");
    selectBuf.append("CaseAudit.caseAuditReference, ");
    selectBuf.append("CaseAudit.comments, CaseAudit.caseAuditStatus, ");
    selectBuf.append("CaseAudit.dateAssigned, CaseAudit.findingsText, ");
    selectBuf.append("CaseAudit.versionNo ");
    selectBuf.append("INTO :caseAuditID, :auditPlanID, :caseID, :auditorID, ");
    selectBuf.append(":caseAuditReference, :comments, ");
    selectBuf.append(":caseAuditStatus, :dateAssigned, :findingsText, ");
    selectBuf.append(":versionNo ");
    // END, CR00221556

    // setup the tables to select from
    fromBuf.append("FROM CASEAUDIT, AUDITOR, AUDITTEAMMEMBER ");

    whereBuf.append("WHERE Auditor.userName = :userName ");
    whereBuf.append("AND AuditTeamMember.auditorID = Auditor.auditorID ");
    whereBuf.append("AND AuditTeamMember.teamID = Auditor.auditTeamID ");
    whereBuf.append("AND CaseAudit.auditorID = Auditor.auditorID");

    // Call dynamic SQL API to execute SQL
    curamValueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
      curam.caseaudit.entity.struct.CaseAuditDtls.class, key, false,
      selectBuf.toString() + fromBuf.toString() + whereBuf.toString());

    // Append the case audits to the overall list
    for (int i = 0; i < curamValueList.size(); i++) {
      
      // BEGIN, CR00210526, GD
      CaseAudit caseAuditObj = getEntity(curamValueList.get(i));
      
      if (checkCaseAuditBySID(caseAuditObj)) {
        caseAuditSet.add(caseAuditObj);
      }
      // END, CR00210526
    }

    return caseAuditSet;
  }
  
  // BEGIN, CR00210526, GD
  // ___________________________________________________________________________
  /**
   * Checks if the current user has access to this case audit. 
   */
  protected boolean checkCaseAuditBySID(
    final CaseAudit caseAudit) {
    
    boolean returnValue = false;
    
    // if CaseAudit is null return true
    if (caseAudit == null) {
      return true;
    }
    
    String currentUser;
   
    // Get the logged in user
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    
    curam.caseaudit.intf.CaseAuditSecurityManagement securityObj = CaseAuditSecurityManagementFactory.newInstance();
    
    CaseAuditSecurityKey caseAuditSecurityKey = new CaseAuditSecurityKey();
    
    try {
        
      currentUser = userAccessObj.getUserDetails().userName;
      
      caseAuditSecurityKey.auditPlanID = caseAudit.getAuditPlan().getID();
      caseAuditSecurityKey.userName = currentUser;
      
      securityObj.checkCaseAuditSecurity(caseAuditSecurityKey);
      returnValue = true;
    } catch (AppException e) {// invalid security 
    } catch (InformationalException e) {// invalid security 
    }
    
    return returnValue;
  }

  // ___________________________________________________________________________
  /**
   * Filters a list of case audits removing any case audits that the current 
   * user doesn't have access to. 
   */
  protected List<CaseAudit> filterCaseAuditListBySID(
    final List<CaseAudit> caseAuditList) {
    
    List<CaseAudit> filteredList = new ArrayList<CaseAudit>();

    for (CaseAudit caseAudit : caseAuditList) {      
      if (checkCaseAuditBySID(caseAudit)) {
        filteredList.add(caseAudit);
      }            
    }
    
    return filteredList;
  }
  
  // ___________________________________________________________________________
  /**
   * Filters a list of case audits removing any case audits that the current 
   * user doesn't have access to. 
   */
  protected Set<CaseAudit> filterCaseAuditSetBySID(
    final Set<CaseAudit> caseAuditSet) {
    
    Set<CaseAudit> filteredSet = new HashSet<CaseAudit>();

    for (CaseAudit caseAudit : caseAuditSet) {      
      if (checkCaseAuditBySID(caseAudit)) {
        filteredSet.add(caseAudit);
      }            
    }
    
    return filteredSet;
  }

  // END, CR00210526, GD

  // BEGIN, CR00290965, IBM
  /**
   * Retrieves the total number of case audit plan count with the given 
   * specified search criteria.
   *
   * @param auditPlan contains audit plan for which case audit records are required
   * @param auditPlanFocusArea contains audit plan focus area
   * @param focusAreaMet whether or not the focus area was satisfied
   *
   * @return count of case audit focus area
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  public Count countCaseAuditByFocusArea(final AuditPlan auditPlan, 
    final AuditPlanFocusArea auditPlanFocusArea, 
    final FOCUSAREASATISFIEDEntry focusAreaMet) 
    throws AppException, InformationalException {

    if (null == auditPlan || null == auditPlanFocusArea) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTCASEAUDITExceptionCreator.ERR_RV_NO_SEARCH_CRITERIA_SPECIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 3);
      ValidationHelper.failIfErrorsExist();
    }

    List<String> criteria = new ArrayList<String>();
    CaseAuditListFilterKey key = new CaseAuditListFilterKey();

    key.auditPlanID = auditPlan.getID();
    key.auditPlanFocusAreaID = auditPlanFocusArea.getID();

    criteria.add("CaseAudit.auditPlanID = :auditPlanID");
    criteria.add("CaseAudit.auditPlanID = AuditPlanFocusArea.auditPlanID");
    criteria.add("AuditPlanFocusArea.auditFocusAreaID = :auditPlanFocusAreaID");
    criteria.add(
      "AuditPlanFocusArea.auditFocusAreaID = "
        + "FocusAreaFinding.auditPlanFocusAreaID");
    criteria.add("CaseAudit.caseAuditID = FocusAreaFinding.caseAuditID"); 
    
    if (CuramConst.gkEmpty.equals(focusAreaMet.getCode())) {
      criteria.add("FocusAreaFinding.areaSatisfied IS NULL");
    } else {
      key.focusAreasMet = focusAreaMet.getCode();
      criteria.add("FocusAreaFinding.areaSatisfied = :focusAreasMet");
    }

    StringBuffer sBuf = new StringBuffer();

    sBuf.append("SELECT COUNT(*) ");
    sBuf.append(" INTO :numberOfRecords ");
    sBuf.append(" FROM CASEAUDIT, ");
    sBuf.append("AUDITPLANFOCUSAREA, FOCUSAREAFINDING WHERE ");

    for (String condition : criteria) {
      sBuf.append(condition);
      // If this is the last element, just add a space
      if (criteria.indexOf(condition) == (criteria.size() - 1)) {
        sBuf.append(" ");
      } else {
        // Otherwise add AND
        sBuf.append(" AND ");
      }
    }

    // Call dynamic SQL API to execute SQL
    Count count = (Count) DynamicDataAccess.executeNs(Count.class, key, false,
      sBuf.toString());
    
    return count;
  }
  // END, CR00290965
}
