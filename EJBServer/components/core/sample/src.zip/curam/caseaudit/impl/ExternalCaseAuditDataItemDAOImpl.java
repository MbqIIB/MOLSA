/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.ArrayList;
import java.util.List;

import com.google.inject.Singleton;

import curam.caseaudit.entity.impl.ExternalCaseAuditDataItemAdapter;
import curam.caseaudit.entity.struct.ExtCADataTypeAndCategory;
import curam.caseaudit.entity.struct.ExternalCaseAuditDataItemDtls;
import curam.codetable.CASETYPECODE;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.core.struct.Count;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;


/**
 * Data access Implementation for 
 * {@linkplain curam.caseaudit.impl.ExternalCaseAuditDataItem}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.ExternalCaseAuditDataItemDAO
 */
@Singleton
public class ExternalCaseAuditDataItemDAOImpl extends StandardDAOImpl<ExternalCaseAuditDataItem, 
  ExternalCaseAuditDataItemDtls> implements ExternalCaseAuditDataItemDAO {

  protected static final ExternalCaseAuditDataItemAdapter adapter = new ExternalCaseAuditDataItemAdapter();

  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  protected ExternalCaseAuditDataItemDAOImpl() {
    super(adapter, ExternalCaseAuditDataItem.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<ExternalCaseAuditDataItem> searchByExternalCaseAuditDataAndCaseType(
    final ExternalCaseAuditData externalCaseAuditData, 
    final CASETYPECODEEntry caseType, final CASECATTYPECODEEntry category) 
    throws AppException, InformationalException {

    List<ExternalCaseAuditDataItem> externalCaseAuditDataItemList = new ArrayList<ExternalCaseAuditDataItem>();
    
    ExtCADataTypeAndCategory extCADataTypeAndCategory = new ExtCADataTypeAndCategory();

    extCADataTypeAndCategory.externalCaseAuditDataID = externalCaseAuditData.getID();
    extCADataTypeAndCategory.caseType = caseType.getCode();
    extCADataTypeAndCategory.category = category.getCode();
    
    StringBuffer finalBuf = new StringBuffer();
    StringBuffer selectBuf = new StringBuffer();
    StringBuffer intoBuf = new StringBuffer();
    StringBuffer fromBuf = new StringBuffer();
    StringBuffer whereBuf = new StringBuffer();

    selectBuf.append("SELECT ExtCADataItem.externalCaseAuditDataItemID, ");
    selectBuf.append("ExtCADataItem.externalCaseAuditDataID, ");
    selectBuf.append("ExtCADataItem.caseID ");    

    intoBuf.append("INTO :externalCaseAuditDataItemID, ");
    intoBuf.append(":externalCaseAuditDataID, :caseID ");

    fromBuf.append("FROM ExternalCaseAuditData ExtCAData,");
    fromBuf.append(" ExternalCaseAuditDataItem ExtCADataItem,");    
    fromBuf.append(" CaseHeader");    

    whereBuf.append(
      " WHERE ExtCAData.externalCaseAuditDataID = :externalCaseAuditDataID");
    whereBuf.append(" AND ExtCADataItem.caseID = CaseHeader.caseID");
    whereBuf.append(" AND CaseHeader.caseTypeCode = :caseType");
    
    if (caseType.getCode().equals(CASETYPECODE.INVESTIGATIONCASE)) {

      fromBuf.append(", InvestigationDelivery InvDel");
      whereBuf.append(" AND CaseHeader.caseID = InvDel.caseID");
      whereBuf.append(" AND InvDel.investigationType = :category");

    } else if (caseType.getCode().equals(CASETYPECODE.SCREENINGCASE)) {

      fromBuf.append(", Screening, ScreeningConfiguration ScreeningConfig");
      whereBuf.append(" AND CaseHeader.caseID = Screening.caseID");
      whereBuf.append(" AND Screening.screeningConfigID =");
      whereBuf.append(" ScreeningConfig.screeningConfigID");
      whereBuf.append(" AND ScreeningConfiguration.name = :category");

    } else if (caseType.getCode().equals(CASETYPECODE.INTEGRATEDCASE)) {
        
      whereBuf.append(" AND CaseHeader.integratedCaseType = :category");
        
    } else if (caseType.getCode().equals(CASETYPECODE.PRODUCTDELIVERY)
      || caseType.equals(CASETYPECODE.LIABILITY)) {
      
      fromBuf.append(", ProductDelivery");
      whereBuf.append(" AND CaseHeader.caseID = ProductDelivery.caseID");
      whereBuf.append(" AND ProductDelivery.productType = :category");
    }

    finalBuf.append(selectBuf);
    finalBuf.append(intoBuf);
    finalBuf.append(fromBuf);
    finalBuf.append(whereBuf);
    
    // BEGIN, CR00290965, IBM
    // Call dynamic SQL API to execute SQL
    CuramValueList<ExternalCaseAuditDataItemDtls> curamValueList = DynamicDataAccess.executeNsMulti(
      ExternalCaseAuditDataItemDtls.class, extCADataTypeAndCategory, false,
      true, finalBuf.toString());

    // END, CR00290965
    
    for (int i = 0; i < curamValueList.size(); i++) {
      externalCaseAuditDataItemList.add(getEntity(curamValueList.get(i)));
    }
    
    return externalCaseAuditDataItemList;
  }

  // BEGIN, CR00290965, IBM
  /**
   * Retrieves the total number of external case audit data items of a specified 
   * case type that are associated with an external case audit data record.
   *
   * @param externalCaseAuditData the externalCaseAuditData record.
   * @param casetypecodeEntry the type of case.
   * @param casecattypecodeEntry the category of case.
   *
   * @return total number of specified case type that are associated with 
   * an external case audit data record.
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  public Count countExternalCaseAuditDataByCaseType(
    final ExternalCaseAuditData externalCaseAuditData, 
    final CASETYPECODEEntry casetypecodeEntry, 
    final CASECATTYPECODEEntry casecattypecodeEntry) 
    throws AppException, InformationalException {

    ExtCADataTypeAndCategory extCADataTypeAndCategory = new ExtCADataTypeAndCategory();

    extCADataTypeAndCategory.externalCaseAuditDataID = externalCaseAuditData.getID();
    extCADataTypeAndCategory.caseType = casetypecodeEntry.getCode();
    extCADataTypeAndCategory.category = casecattypecodeEntry.getCode();
      
    StringBuffer finalBuf = new StringBuffer();
    StringBuffer selectBuf = new StringBuffer();
    StringBuffer intoBuf = new StringBuffer();
    StringBuffer fromBuf = new StringBuffer();
    StringBuffer whereBuf = new StringBuffer();

    selectBuf.append("SELECT COUNT(*) ");

    intoBuf.append("INTO :numberOfRecords ");

    fromBuf.append("FROM ExternalCaseAuditData ExtCAData,");
    fromBuf.append(" ExternalCaseAuditDataItem ExtCADataItem,");    
    fromBuf.append(" CaseHeader");    

    whereBuf.append(
      " WHERE ExtCAData.externalCaseAuditDataID = :externalCaseAuditDataID");
    whereBuf.append(" AND ExtCADataItem.caseID = CaseHeader.caseID");
    whereBuf.append(" AND CaseHeader.caseTypeCode = :caseType");
      
    if (CASETYPECODE.INVESTIGATIONCASE.equals(casetypecodeEntry.getCode())) {

      fromBuf.append(", InvestigationDelivery InvDel");
      whereBuf.append(" AND CaseHeader.caseID = InvDel.caseID");
      whereBuf.append(" AND InvDel.investigationType = :category");

    } else if (CASETYPECODE.SCREENINGCASE.equals(casetypecodeEntry.getCode())) {

      fromBuf.append(", Screening, ScreeningConfiguration ScreeningConfig");
      whereBuf.append(" AND CaseHeader.caseID = Screening.caseID");
      whereBuf.append(" AND Screening.screeningConfigID =");
      whereBuf.append(" ScreeningConfig.screeningConfigID");
      whereBuf.append(" AND ScreeningConfiguration.name = :category");

    } else if (CASETYPECODE.INTEGRATEDCASE.equals(casetypecodeEntry.getCode())) {
          
      whereBuf.append(" AND CaseHeader.integratedCaseType = :category");
          
    } else if (CASETYPECODE.PRODUCTDELIVERY.equals(casetypecodeEntry.getCode())
      || CASETYPECODE.LIABILITY.equals(casetypecodeEntry)) {
        
      fromBuf.append(", ProductDelivery");
      whereBuf.append(" AND CaseHeader.caseID = ProductDelivery.caseID");
      whereBuf.append(" AND ProductDelivery.productType = :category");
    }

    finalBuf.append(selectBuf);
    finalBuf.append(intoBuf);
    finalBuf.append(fromBuf);
    finalBuf.append(whereBuf);
      
    // Call dynamic SQL API to execute SQL
    Count count = (Count) DynamicDataAccess.executeNs(Count.class, 
      extCADataTypeAndCategory, false, finalBuf.toString());

    return count;
  }
  // END, CR00290965
}
