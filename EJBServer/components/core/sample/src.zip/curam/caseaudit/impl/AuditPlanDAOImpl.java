/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import com.google.inject.Singleton;

import curam.caseaudit.entity.impl.AuditPlanAdapter;
import curam.caseaudit.entity.struct.AuditPlanDtls;
import curam.caseaudit.entity.struct.CaseIDCoordinatorAndStatusKey;
import curam.caseaudit.fact.CaseAuditSecurityManagementFactory;
import curam.caseaudit.struct.CaseAuditSecurityKey;
import curam.codetable.AUDITPLANSTATUS;
import curam.codetable.impl.AUDITPLANSTATUSEntry;
import curam.codetable.impl.CASECATTYPECODEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.facade.struct.AuditPlanSearchKey;
import curam.core.impl.CuramConst;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.message.BPOAUDITPLANDAO;
import curam.message.impl.BPOAUDITPLANDAOExceptionCreator;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.persistence.ValidationHelper;
import curam.util.type.StringHelper;


/**
 * Data access Implementation for {@linkplain curam.caseaudit.impl.AuditPlan}.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditPlanDAO
 */
@Singleton
// BEGIN, CR00183334, PS
public class AuditPlanDAOImpl extends StandardDAOImpl<AuditPlan, AuditPlanDtls>
  implements AuditPlanDAO {
  // END, CR00183334
  protected static final AuditPlanAdapter adapter = new AuditPlanAdapter();
  
  // ___________________________________________________________________________
  /**
   * Default constructor.
   */
  // BEGIN, CR00183334, PS
  protected AuditPlanDAOImpl() {
    // END, CR00183334
    super(adapter, AuditPlan.class);
  }

  // BEGIN, CR00223243, GD
  /**
   * Comparator used to order structs in a list by component from date.
   */
  public class AuditPlanComparator implements Comparator<AuditPlan> {

    /**
     * Default constructor. 
     */
    public AuditPlanComparator() {
      super();
    }

    // _________________________________________________________________________
    /**
     * Compares two AuditPlan, sorted by status descending, then audit 
     * plan reference number ascending.
     *
     * @param o1 the first AuditPlan to be compared.
     * @param o2 the second AuditPlan to be compared.
     * @return a negative integer, zero, or a positive integer as the first 
     * argument is less than, equal to, or greater than the second.   
     */
    public int compare(final AuditPlan o1, final AuditPlan o2) {
      
      String auditPlanStatus1 = CuramConst.gkEmpty;
      String auditPlanStatus2 = CuramConst.gkEmpty;

      try {
        auditPlanStatus1 = curam.util.type.CodeTable.getOneItem(
          AUDITPLANSTATUS.TABLENAME, o1.getLifecycleState().getCode());
        auditPlanStatus2 = curam.util.type.CodeTable.getOneItem(
          AUDITPLANSTATUS.TABLENAME, o2.getLifecycleState().getCode());
      } catch (AppException app) {
        
        AppException ae = new AppException(
          BPOAUDITPLANDAO.ERR_SORTING_AUDIT_PLANS_BY_STATUS, app);

        throw new AppRuntimeException(ae);
         
      } catch (InformationalException inf) {
         
        AppException ae = new AppException(
          BPOAUDITPLANDAO.ERR_SORTING_AUDIT_PLANS_BY_STATUS, inf);

        throw new AppRuntimeException(ae);         
      }

      // if status are the same order by plan reference 
      if (auditPlanStatus1.equals(auditPlanStatus2)) {
        return o1.getAuditPlanReference().compareTo(o2.getAuditPlanReference());
      }

      return auditPlanStatus2.compareTo(auditPlanStatus1);
    }
  }


  // END, CR00223243
  
  // ___________________________________________________________________________
  /**
   * SortByReferenceDesc Comparator.
   */
  protected class SortByReferenceDescComparator implements Comparator<AuditPlan> {

    public SortByReferenceDescComparator() {// None required
    }

    // _________________________________________________________________________
    /**
     * Sort based on audit plan reference descending.
     */
    public int compare(final AuditPlan o1, final AuditPlan o2) {
      return o2.getAuditPlanReference().compareTo(o1.getAuditPlanReference());
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public SortedSet<AuditPlan> searchByRecordStatusAndCoordinator(
    final RECORDSTATUSEntry status, final String coordinator) {
    
    // BEGIN, CR00223243, GD
    AuditPlanComparator comparator = new AuditPlanComparator();
    
    SortedSet<AuditPlan> sortedAuditPlans = new TreeSet<AuditPlan>(comparator);
    // END, CR00223243

    Set<AuditPlan> auditPlans = newSet(
      adapter.searchByRecordStatusAndCoordinator(status.getCode(), coordinator));

    for (AuditPlan auditPlan : auditPlans) {
      
      // BEGIN, CR00210526, GD
      if (checkAuditPlanBySID(auditPlan)) {
        sortedAuditPlans.add(auditPlan);
      }
      // END, CR00210526
    }
    
    return sortedAuditPlans;
  }
  
  // BEGIN, CR00223243, GD
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public SortedSet<AuditPlan> searchByCaseIDRecordStatusAndCoordinator(
    final long caseID, final RECORDSTATUSEntry status, 
    final String coordinator) 
    throws AppException, InformationalException {
    
    AuditPlanComparator comparator = new AuditPlanComparator();
    
    SortedSet<AuditPlan> auditPlanSet = new TreeSet<AuditPlan>(comparator);
    
    CaseIDCoordinatorAndStatusKey key = new CaseIDCoordinatorAndStatusKey();

    key.caseID = caseID;
    key.coordinator = coordinator;
    key.recordStatus = status.getCode(); 
    
    StringBuffer sqlBuf = new StringBuffer();

    sqlBuf.append("SELECT");
    sqlBuf.append("  AuditPlan.auditPlanID,");
    sqlBuf.append("  AuditPlan.auditPlanReference,");
    sqlBuf.append("  AuditPlan.auditPlanStatus,");
    sqlBuf.append("  AuditPlan.recordStatus,");
    sqlBuf.append("  AuditPlan.createdDate,");
    sqlBuf.append("  AuditPlan.createdBy,");
    sqlBuf.append("  AuditPlan.coordinator,");
    sqlBuf.append("  AuditPlan.purpose,");
    sqlBuf.append("  AuditPlan.priority,");
    sqlBuf.append("  AuditPlan.userAccess,");
    sqlBuf.append("  AuditPlan.percentageCases,");
    sqlBuf.append("  AuditPlan.numberCases,");
    sqlBuf.append("  AuditPlan.scheduledStartDate,");
    sqlBuf.append("  AuditPlan.scheduledEndDate,");
    sqlBuf.append("  AuditPlan.scheduleComments,");
    sqlBuf.append("  AuditPlan.casesUserSelected,");
    sqlBuf.append("  AuditPlan.comments,");
    sqlBuf.append("  AuditPlan.auditCaseConfigID,");
    sqlBuf.append("  AuditPlan.findingsText,");
    sqlBuf.append("  AuditPlan.selectionQueryID,");
    sqlBuf.append("  AuditPlan.versionNo ");
    sqlBuf.append("INTO");
    sqlBuf.append("  :auditPlanID,");
    sqlBuf.append("  :auditPlanReference,");
    sqlBuf.append("  :auditPlanStatus,");
    sqlBuf.append("  :recordStatus,");
    sqlBuf.append("  :createdDate,");
    sqlBuf.append("  :createdBy,");
    sqlBuf.append("  :coordinator,");
    sqlBuf.append("  :purpose,");
    sqlBuf.append("  :priority,");
    sqlBuf.append("  :userAccess,");
    sqlBuf.append("  :percentageCases,");
    sqlBuf.append("  :numberCases,");
    sqlBuf.append("  :scheduledStartDate,");
    sqlBuf.append("  :scheduledEndDate,");
    sqlBuf.append("  :scheduleComments,");
    sqlBuf.append("  :casesUserSelected,");
    sqlBuf.append("  :comments,");
    sqlBuf.append("  :auditCaseConfigID,");
    sqlBuf.append("  :findingsText,");
    sqlBuf.append("  :selectionQueryID,");
    sqlBuf.append("  :versionNo ");
    sqlBuf.append("FROM");
    sqlBuf.append("  CaseAudit,");
    sqlBuf.append("  AuditPlan ");
    sqlBuf.append("WHERE");
    sqlBuf.append("  CaseAudit.auditPlanID = AuditPlan.auditPlanID and");
    sqlBuf.append("  CaseAudit.caseID = :caseID and");
    sqlBuf.append("  AuditPlan.coordinator = :coordinator and");
    sqlBuf.append("  AuditPlan.recordStatus = :recordStatus");
    
    // Call dynamic SQL API to execute SQL
    CuramValueList<AuditPlanDtls> curamValueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
      curam.caseaudit.entity.struct.AuditPlanDtls.class, key, false,
      sqlBuf.toString());
  
    for (int i = 0; i < curamValueList.size(); i++) {

      auditPlanSet.add(getEntity(curamValueList.get(i)));
    }
    
    return auditPlanSet;
  }

  // END, CR00223243

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AuditPlan readByAuditPlanReference(final String auditPlanReference) {

    // BEGIN, CR00210526, GD
    AuditPlan returnObj = getEntity(
      adapter.readByAuditPlanReference(auditPlanReference));
    
    if (checkAuditPlanBySID(returnObj)) {
      return returnObj;
    } else {
      return null;
    }
    // END, CR00210526
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public SortedSet<AuditPlan> search(final String coordinator, 
    final CASECATTYPECODEEntry type,
    final AUDITPLANSTATUSEntry status,
    final boolean activeOnlyInd) throws AppException, InformationalException { 

    SortedSet<AuditPlan> auditPlans = new TreeSet<AuditPlan>(
      new AuditPlanComparator());
      
    List<String> criteria = new ArrayList<String>();
    AuditPlanSearchKey key = new AuditPlanSearchKey();
    boolean atleastOneCriteriaEntered = false;

    if (!StringHelper.isEmpty(coordinator)) {
      criteria.add("coordinator = :coordinator");
      key.coordinator = coordinator;
      atleastOneCriteriaEntered = true;
    }

    if (!type.equals(CASECATTYPECODEEntry.NOT_SPECIFIED)) {
      criteria.add(
        "AuditCaseConfig.caseCategory = :type "
          + "AND AuditCaseConfig.auditCaseConfigID = AuditPlan.auditCaseConfigID");
      key.type = type.getCode();
      atleastOneCriteriaEntered = true;
    }

    if (!status.equals(AUDITPLANSTATUSEntry.NOT_SPECIFIED)) {
      criteria.add("auditPlanStatus = :status");
      key.status = status.getCode();
      atleastOneCriteriaEntered = true;
    }

    if (activeOnlyInd) {
      criteria.add("recordStatus = :recordStatus");
      key.recordStatus = RECORDSTATUSEntry.NORMAL.getCode();
      atleastOneCriteriaEntered = true;
    }

    if (!atleastOneCriteriaEntered) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        BPOAUDITPLANDAOExceptionCreator.ERR_AUDIT_PLAN_SEARCH_NO_CRITERIA(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    ValidationHelper.failIfErrorsExist();

    StringBuffer sBuf = new StringBuffer();

    sBuf.append("SELECT auditPlanID, auditPlanReference, auditPlanStatus, ");
    sBuf.append("recordStatus, createdDate, createdBy, coordinator, purpose, ");
    sBuf.append("priority, userAccess, percentageCases, ");    
    sBuf.append("numberCases, scheduledStartDate, scheduledEndDate, ");
    sBuf.append("scheduleComments, casesUserSelected, comments, ");
    sBuf.append("AuditPlan.auditCaseConfigID, AuditPlan.versionNo INTO ");
    sBuf.append(":auditPlanID, :auditPlanReference, :auditPlanStatus, ");
    sBuf.append(":recordStatus, :createdDate, :createdBy, :coordinator, ");
    sBuf.append(":purpose, :priority, :userAccess, ");    
    sBuf.append(":percentageCases, :numberCases, :scheduledStartDate, ");
    sBuf.append(":scheduledEndDate, :scheduleComments, :casesUserSelected, ");    
    sBuf.append(":comments, :auditCaseConfigID, :versionNo ");
    sBuf.append("FROM AUDITPLAN, AUDITCASECONFIG WHERE ");
    for (String condition : criteria) {
      sBuf.append(condition);

      // If this is the last element, just add a space
      if (criteria.indexOf(condition) == (criteria.size() - 1)) {
        sBuf.append(" ");
      } else {
        // Otherwise add AND
        sBuf.append(" AND ");
      }

    }
    
    // BEGIN, CR00290965, IBM
    // Call dynamic SQL API to execute SQL
    CuramValueList<AuditPlanDtls> curamValueList = DynamicDataAccess.executeNsMulti(
      AuditPlanDtls.class, key, false, true, sBuf.toString());

    // END, CR00290965
    
    for (int i = 0; i < curamValueList.size(); i++) {

      AuditPlan auditPlan = getEntity(curamValueList.get(i)); 
      
      // BEGIN, CR00210526, GD
      if (checkAuditPlanBySID(auditPlan)) {
        auditPlans.add(auditPlan);
      }
      // END, CR00210526
    }

    // If no search results are found, alert user
    if (curamValueList.isEmpty()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOAUDITPLANDAO.INF_AUDIT_PLAN_SEARCH_NO_MATCH),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    return auditPlans;
  }
  
  // BEGIN, CR00210526, GD
  // ___________________________________________________________________________
  /**
   * Checks if the current user has access to this audit plan. 
   */
  protected boolean checkAuditPlanBySID(
    final AuditPlan auditPlan) {
    
    boolean returnValue = false;
    
    // if AuditPlan is null return true
    if (auditPlan == null) {
      return true;
    }
    
    String currentUser;
   
    // Get the logged in user
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    
    curam.caseaudit.intf.CaseAuditSecurityManagement securityObj = CaseAuditSecurityManagementFactory.newInstance();
    
    CaseAuditSecurityKey caseAuditSecurityKey = new CaseAuditSecurityKey();
    
    try {
        
      currentUser = userAccessObj.getUserDetails().userName;
      
      caseAuditSecurityKey.auditPlanID = auditPlan.getID();
      caseAuditSecurityKey.userName = currentUser;
      
      securityObj.checkCaseAuditSecurity(caseAuditSecurityKey);
      returnValue = true;
    } catch (AppException e) {// invalid security 
    } catch (InformationalException e) {// invalid security 
    }
    
    return returnValue;
  }
  // BEGIN, CR00210526
}
