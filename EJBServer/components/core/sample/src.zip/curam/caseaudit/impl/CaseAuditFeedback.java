/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import com.google.inject.ImplementedBy;

import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;

/**
 * Service layer class having operations for managing Case Audit Feedback.
 * 
 */
@ImplementedBy(CaseAuditFeedbackImpl.class)
public interface CaseAuditFeedback
  extends Insertable, OptimisticLockModifiable, CaseAuditFeedbackAccessor {

  // ___________________________________________________________________________
  /**
   * Sets the case audit associated with this feedback.
   * 
   * @param caseAudit
   *          The case audit associated with this feedback.
   */
  public void setCaseAudit(final CaseAudit caseAudit);

  // ___________________________________________________________________________
  /**
   * Sets if the feedback is complete or not.
   * 
   * @param feedbackComplete
   *          If the feedback is complete or not.
   */
  public void setFeedbackComplete(final boolean feedbackComplete);

  // BEGIN, CR00221556, GD
  // ___________________________________________________________________________
  /**
   * Sets the feedback text.
   * 
   * @param feedbackText
   *          The feedback text.
   * 
   * @throws AppException
   * @throws InformationalException
   */
  public void setFeedbackText(final String feedbackText)
    throws AppException, InformationalException;
  // END, CR00221556
  
  //___________________________________________________________________________
  /**
   * Sets the user who should complete this feedback.
   * 
   * @param username
   *          The user who should complete this feedback.
   */
  public void setUsername(final String username);

}
