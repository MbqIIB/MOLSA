/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;

import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardEntity;

/**
 * FocusAreaFinding Accessor for 
 * {@linkplain curam.caseaudit.impl.CaseAuditFeedback} .
 * 
 */
public interface CaseAuditFeedbackAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Returns the case audit associated with this feedback record.
   * 
   * @return The case audit associated with this feedback record.
   */
  public CaseAudit getCaseAudit();

  // ___________________________________________________________________________
  /**
   * Returns the user name of the user that provided the feedback.
   * 
   * @return The user name of the user that provided the feedback.
   */
  public String getUsername();

  // BEGIN, CR00221556, GD
  // ___________________________________________________________________________
  /**
   * Returns the feedback text.
   * 
   * @return The feedback text.
   */
  public String getFeedbackText() throws AppException, InformationalException;
  // END, CR00221556

  // ___________________________________________________________________________
  /**
   * Returns true if the feedback is complete.
   * 
   * @return True if the feedback is complete.
   */
  public boolean isFeedbackComplete();
}
