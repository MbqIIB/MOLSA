/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import com.google.inject.Inject;

import curam.caseaudit.entity.struct.AuditCaseFocusAreaDtls;
import curam.codetable.impl.AUDITCASEFOCUSAREAEntry;
import curam.message.impl.ENTAUDITCASEFOCUSAREAExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Implementation for AuditCaseFocusArea.
 *
 * For public method JavaDoc
 *
 * @see curam.caseaudit.impl.AuditCaseFocusArea
 */
// BEGIN, CR00183334, PS
public class AuditCaseFocusAreaImpl extends SingleTableEntityImpl<AuditCaseFocusAreaDtls> implements AuditCaseFocusArea {
  // END, CR00183334
  
  @Inject
  protected AuditCaseConfigDAO auditCaseConfigDAO;

  // ___________________________________________________________________________
  // BEGIN, CR00183334, PS
  /*
   * no-arg constructor for use only by Guice
   */
  protected AuditCaseFocusAreaImpl() {
    // no-arg constructor for use only by Guice
    // END, CR00183334
    super();
  }

  // ___________________________________________________________________________
  /**
   * Creates the audit case focus area. 
   *
   */
  @Override
  public void insert() throws InformationalException {
    super.insert();
  }

  // ___________________________________________________________________________
  /**
   * Removes the audit case focus area. (Note: This is a physical delete).
   *
   */
  @Override
  public void remove() throws InformationalException {
    super.remove();
  }
 
  // ___________________________________________________________________________
  public void mandatoryFieldValidation() {

    if (getDtls().focusAreaCode.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITCASEFOCUSAREAExceptionCreator.ERR_FV_MANDATORY_FOCUS_AREA_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (getDtls().auditCaseConfigID == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        ENTAUDITCASEFOCUSAREAExceptionCreator.ERR_FV_MANDATORY_AUDIT_CASE_CONFIG_NOT_SET(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setAuditCaseConfig(final AuditCaseConfig auditCaseConfig) {
    getDtls().auditCaseConfigID = auditCaseConfig.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setFocusArea(
    final AUDITCASEFOCUSAREAEntry focusArea) {
    getDtls().focusAreaCode = focusArea.getCode();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AuditCaseConfig getAuditCaseConfig() {
    return auditCaseConfigDAO.get(getDtls().auditCaseConfigID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public AUDITCASEFOCUSAREAEntry getFocusArea() {
    return AUDITCASEFOCUSAREAEntry.get(getDtls().focusAreaCode);
  }

  // ___________________________________________________________________________
  public void crossEntityValidation() {// None Required
  }

  // ___________________________________________________________________________
  public void crossFieldValidation() {// None Required
  }

  // ___________________________________________________________________________
  public void setNewInstanceDefaults() {// None Required
  }

}
