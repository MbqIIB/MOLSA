/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.caseaudit.impl;


import java.util.List;
import java.util.SortedSet;

import com.google.inject.ImplementedBy;

import curam.caseaudit.entity.struct.FocusAreaStatsList;
import curam.codetable.impl.AUDITPLANPRIORITYEntry;
import curam.codetable.impl.AUDITPLANPURPOSEEntry;
import curam.codetable.impl.AUDITPLANUSERACCESSEntry;
import curam.message.ENTAUDITPLAN;
import curam.selectionquery.impl.SelectionQuery;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.type.Date;


/**
 * Audit Plan Criteria. 
 *
 */
@ImplementedBy(AuditPlanImpl.class)
public interface AuditPlan extends Insertable, OptimisticLockModifiable,
    AuditPlanAccessor {

  // ___________________________________________________________________________
  /**
   * Cancels the Audit Plan.
   *
   * @param versionNo
   * The version number of the audit plan to be canceled.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.caseaudit.impl.AuditPlanImpl#cancel(int) The default
   * implementation - curam.caseaudit.impl.AuditPlanImpl#cancel(int)
   */
  public void cancel(int versionNo) throws InformationalException;

  // ___________________________________________________________________________
  /**
   * Modifies the audit plan record with a new coordinator and notifies the .
   * new coordinator.
   *
   * @param versionNo
   * The version number of the audit plan record to modify
   * @param coordinator
   * The user name of the new coordinator of this audit plan
   *
   * @throws InformationalException   Generic Exception Signature. 
   * @throws AppException   Generic Exception Signature.
   */
  public void changeCoordinator(final Integer versionNo, String coordinator)
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Sets the user name of the coordinator of this audit plan.
   *
   * @param coordinator
   * The user name of the coordinator of this audit plan
   *
   * @throws InformationalException   Generic Exception Signature. 
   * @throws AppException   Generic Exception Signature.
   */
  public void setCoordinator(final String coordinator) 
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Sets the purpose of this audit plan.
   *
   * <p>
   * It adds the following informational exception to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link ENTAUDITPLAN#ERR_RV_CANNOT_MODIFY_PURPOSE_STATUS_NOT_PENDING} -
   * If you are modifying the audit purpose field but the audit status is not
   * pending. </li>
   * </ul>
   *
   * @param purpose
   * The purpose of this audit plan
   */
  public void setPurpose(final AUDITPLANPURPOSEEntry purpose);

  // ___________________________________________________________________________
  /**
   * Sets the priority of this audit plan.
   *
   * @param priority
   * The priority of this audit plan
   */
  public void setPriority(final AUDITPLANPRIORITYEntry priority);

  // ___________________________________________________________________________
  /**
   * Sets the access granted to case owners/supervisors for audits on this plan.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link ENTAUDITPLAN#ERR_RV_CANNOT_MODIFY_USER_ACCESS_STATUS_NOT_PENDING} -
   * If you are modifying the user access field but the audit status is not
   * pending. </li>
   * </ul>
   *
   * @param userAccess
   * The access granted to case owners/supervisors for audits on this
   * plan
   */
  public void setUserAccess(final AUDITPLANUSERACCESSEntry userAccess);

  // ___________________________________________________________________________
  /**
   * Sets the percentage of cases to be chosen from the original selection.
   *
   * @param percentageCases
   * The percentage of cases to be chosen from the original selection
   */
  public void setPercentageCases(final double percentageCases);

  // ___________________________________________________________________________
  /**
   * Sets the number of cases to be chosen from the original selection.
   *
   * @param numberCases
   * The number of cases to be chosen from the original selection
   */
  public void setNumberCases(final int numberCases);

  // ___________________________________________________________________________
  /**
   * Sets the comments related to scheduling on this audit plan.
   *
   * @param scheduleComments
   * The comments related to scheduling on this audit plan
   */
  public void setScheduleComments(final String scheduleComments);

  // ___________________________________________________________________________
  /**
   * Sets whether or not the case list was manually selected.
   *
   * @param casesUserSelected
   * Whether or not the case list was manually selected
   */
  public void setCasesUserSelected(final boolean casesUserSelected);

  // ___________________________________________________________________________
  /**
   * Sets the the textual description of the case audit.
   *
   * @param comments
   * The textual description of the case audit.
   */
  public void setComments(final String comments);

  // ___________________________________________________________________________
  /**
   * Sets the audit case configuration.
   *
   * @param auditCaseConfig
   * The audit case configuration.
   */
  public void setAuditCaseConfig(final AuditCaseConfig auditCaseConfig);

  // ___________________________________________________________________________
  /**
   * Starts the audit, and sets the status to 'In Progress'.
   *
   * @param versionNo
   * The retrieved version no
   * @throws InformationalException   Generic Exception Signature. 
   */
  // BEGIN, CR00222185, GD
  public void beginAudit(final int versionNo) 
    throws AppException, InformationalException;
  // END, CR00222185

  // ___________________________________________________________________________
  /**
   * Removes the schedule from the audit.
   *
   * @param versionNo
   * The retrieved version no
   * @throws InformationalException   Generic Exception Signature. 
   */
  public void removeSchedule(final int versionNo) throws InformationalException;

  // ___________________________________________________________________________
  /**
   * Sets the schedule start and end dates for the audit.
   *
   * @param scheduleStartDate
   * The start date of the schedule
   * @param scheduleEndDate
   * The end date of the schedule
   *
   * @throws InformationalException   Generic Exception Signature.
   */
  public void setSchedule(final Date scheduleStartDate,
    final Date scheduleEndDate) throws InformationalException;

  // ___________________________________________________________________________
  /**
   * Completes the audit plan.
   *
   * @param versionNo
   * The retrieved version no
   *
   * @throws InformationalException   Generic Exception Signature.
   */
  public void complete(final int versionNo) throws InformationalException;

  // ___________________________________________________________________________
  /**
   * Lists all the Focus Areas on an Audit Plan displaying how many case audits
   * on the audit plan a) met the focus area b) did not meet the focus area c)
   * have not yet been examined.
   *
   * @return the statistics on the focus areas.
   * @throws InformationalException   Generic Exception Signature. 
   * @throws AppException   Generic Exception Signature.
   */
  public FocusAreaStatsList listFocusAreaStats() throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Returns list of the selected focus areas for the audit plan.
   *
   * @return The selected focus areas. 
   */
  public List<AuditPlanFocusArea> getSelectedFocusAreas();

  // ___________________________________________________________________________
  /**
   * Returns the set of selected criteria for a given audit plan. 
   *
   * @return The selected criteria. 
   */
  public SortedSet<AuditPlanCriteria> getSelectedCriteria();

  // ____________________________________________________________________________
  /**
   * Method to set the audit plan summary findings.
   *
   * @param findings
   * The findings for the audit plan.
   *
   * @throws InformationalException   Generic Exception Signature.
   * @throws AppException   Generic Exception Signature.
   */
  public void setSummaryFindings(String findings) throws AppException,
      InformationalException;

  // ___________________________________________________________________________
  /**
   * Sets the selection query used in the generation of the case sample.
   *
   * @param selectionQuery  The selection query used in the generation of the 
   * case sample.
   *
   * @throws InformationalException   Generic Exception Signature.
   * @throws AppException   Generic Exception Signature.
   */
  public void setSelectionQuery(SelectionQuery selectionQuery) 
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Removes all case audits from an audit plan. 
   *
   * @throws InformationalException   Generic Exception Signature. 
   */
  public void clearCaseLoad() throws InformationalException;

  // ___________________________________________________________________________
  /**
   * Removes all selected criteria from an audit plan. 
   *
   * @throws InformationalException   Generic Exception Signature. 
   */
  public void clearSelectionCriteria() throws InformationalException;
  
  // ___________________________________________________________________________
  /**
   * Indicates that the case sample list generation process has completed. 
   *
   * @throws AppException   Generic Exception Signature. 
   * @throws InformationalException   Generic Exception Signature.
   */
  public void caseSampleListGenerated() 
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Sets the audit status to 'Delayed Processing Pending'.
   *
   * @param versionNo
   * The retrieved version no
   *
   * @throws InformationalException   Generic Exception Signature. 
   * @throws AppException   Generic Exception Signature.          
   */
  public void delayedProcessingPending(final int versionNo) 
    throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * Sets the audit plan status back to 'Pending'. This operation can only be 
   * used for the transition of 'Delayed Processing Pending' to 'Pending'.
   *
   * @param versionNo
   * The retrieved version no
   *
   * @throws InformationalException   Generic Exception Signature. 
   * @throws AppException   Generic Exception Signature.          
   */
  public void auditPlanPending(final int versionNo) 
    throws AppException, InformationalException;
  
  // BEGIN, CR00290965, IBM
  /**
   * Retrieves the total number of focus areas on an audit plan list 
   * details count.
   *
   * @return the statistics on the focus areas list details.
   *
   * @throws InformationalException   Generic Exception Signature. 
   * @throws AppException   Generic Exception Signature.
   */
  public FocusAreaStatsList listFocusAreaStatsCount() throws AppException,
      InformationalException;
  // END, CR00290965
}
