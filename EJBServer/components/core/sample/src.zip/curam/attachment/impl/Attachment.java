/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright (c) 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 *
 */

package curam.attachment.impl;


import com.google.inject.ImplementedBy;

import curam.core.struct.AttachmentDtls;
import curam.core.struct.AttachmentKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * An interface manages the attachments of the Curam System.
 */
@ImplementedBy(AttachmentImpl.class)
public interface Attachment {

  /**
   * Add the attachment details.
   * @param details an instance of AttachmentDtls which contains new attachment 
   * details 
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  void insert(AttachmentDtls details) throws AppException, InformationalException;

  /**
   * Modifies the attachment details
   * @param key an instance of AttachmentKey contains the attachment ID
   * @param details an instance of AttachmentDtls which contains modified 
   * attachment details
   * @throws InformationalException   Generic Exception Signature.
   * @throws AppException   Generic Exception Signature.
   */

  void modify(AttachmentKey key, AttachmentDtls details) 
    throws AppException, InformationalException;

  /**
   * Return the attachment details based on the attachment ID
   *
   * @param key an instance of AttachmentKey contains the attachment ID 
   * @param forUpdate boolean value whether optimistic locking is required or not
   *
   * @return AttachmentDtls an instance of attachmentDtls which contains the 
   * attachment details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */

  AttachmentDtls read(AttachmentKey key, boolean forUpdate) 
    throws AppException, InformationalException;

  /**
   * Return the attachment details based on the attachment ID
   *
   * @param key an instance of AttachmentKey contains the attachment ID
   *
   * @return AttachmentDtls an instance of attachmentDtls which contains the 
   * attachment details
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */

  AttachmentDtls read(AttachmentKey key) 
    throws AppException, InformationalException;

  /**
   * Logically deletes the attachment record
   *
   * @throwsInformationalException Generic Exception Signature.
   * @param key an instance of AttachmentKey contains the attachment ID
   *
   * @throws AppException Generic Exception Signature.
   */

  void cancel(AttachmentKey key) throws  InformationalException;

}
