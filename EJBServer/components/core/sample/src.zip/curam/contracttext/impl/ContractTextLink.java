/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracttext.impl;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.CONTRACTTEXTLINKTYPEEntry;
import curam.core.sl.entity.struct.ContractTextDtls;
import curam.core.sl.entity.struct.RelatedReferenceKey;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockRemovable;

/**
 * The Contract Text Link provides link between contract texts and related references.
 * A related reference can be any business entity like Service Offering, Planned
 * Item etc., which associates with contract text.
 */
@ImplementedBy(ContractTextLinkImpl.class)
public interface ContractTextLink extends Insertable, OptimisticLockRemovable,
ContractTextLinkAccessor {

  /**
   * Sets the contract text for the Contract Text Link.
   * 
   * @param contractDtls
   *          Contains the contract text details.
   */
  void setContractText(ContractTextDtls contractDtls);

  /**
   * Sets the related reference for the Contract Text Link.
   * 
   * @param relatedReferenceKey
   *          Contains related reference ID.
   */
  void setRelatedReference(RelatedReferenceKey relatedReferenceKey);

  /**
   * Sets the related type for the Contract Text Link.
   * 
   * @param relatedType
   *          Contains related type code.
   */
  void setRelatedType(CONTRACTTEXTLINKTYPEEntry relatedType);
 

}
