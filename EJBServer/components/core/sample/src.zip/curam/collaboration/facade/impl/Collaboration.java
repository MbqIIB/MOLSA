/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.collaboration.facade.impl;


import com.google.inject.Inject;
import curam.collaboration.facade.struct.CaseCollaborationMemberKey;
import curam.collaboration.facade.struct.CollaborationConfigurationDetails;
import curam.collaboration.facade.struct.ListCaseCollaborationMembersResult;
import curam.collaboration.impl.CaseCollaborationAdminStrategy;
import curam.collaboration.impl.CaseCollaborationStrategy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;


/**
 * Facade layer class for maintaining a Discussion.
 */
public abstract class Collaboration extends curam.collaboration.facade.base.Collaboration {

  @Inject
  protected CaseCollaborationAdminStrategy caseCollaborationAdminStrategy;

  @Inject
  protected CaseCollaborationStrategy caseCollaborationStrategy;

  /**
   * Constructor.
   */
  public Collaboration() {
    // Bootstrap dependency injection for this class
    super();
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public CollaborationConfigurationDetails readCollaborationConfiguration()
    throws AppException, InformationalException {

    CollaborationConfigurationDetails collaborationConfigurationDetails = new CollaborationConfigurationDetails();

    collaborationConfigurationDetails.collaborationEnabledInd = caseCollaborationAdminStrategy.isCollaborationEnabled();
    return collaborationConfigurationDetails;
  }

  /**
   * {@inheritDoc}
   */
  public ListCaseCollaborationMembersResult listCaseCollaborationMembers(
    final CaseCollaborationMemberKey key) throws AppException,
      InformationalException {
    ListCaseCollaborationMembersResult result = caseCollaborationStrategy.listCaseCollaborationMembersForSharing(
      key);

    return result;
  }
}
