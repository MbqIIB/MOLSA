/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.collaboration.impl;


import java.util.Map;
import com.google.inject.Inject;

import curam.core.impl.CuramConst;
import curam.piwrapper.caseheader.impl.CaseHeader;
import curam.piwrapper.caseheader.impl.CaseHeaderDAO;
import curam.util.persistence.GuiceWrapper;
import curam.util.tab.impl.DynamicNavStateLoader;
import curam.util.tab.impl.NavigationState;


/**
 * Dynamic navigation loader that determines if the collaboration tab should be
 * displayed for a case.
 *
 * @since 6.0
 */
public class CaseCollaborationNavigationLoader implements DynamicNavStateLoader {

  /**
   * The caseID page param name.
   */
  protected static final String CASE_ID = CuramConst.gkCaseIDParameter;

  /**
   * The ID of collaboration folder.
   */
  protected static final String COLLABORATION_FOLDER = CuramConst.gkCollaborationFolder;

  @Inject
  protected CaseCollaborationStrategy caseCollaborationStrategy;

  @Inject
  protected CaseHeaderDAO caseHeaderDAO;

  /**
   * {@inheritDoc}
   */
  public NavigationState loadNavState(final NavigationState navigationState,
    final Map<String, String> pageParameters, final String[] idsToUpdate) {

    GuiceWrapper.getInjector().injectMembers(this);

    // Check if the page parameters are passed
    if (pageParameters.size() == 0) {
      return navigationState;
    }

    CaseHeader caseHeader = caseHeaderDAO.get(
      Long.valueOf(pageParameters.get(CASE_ID)));

    for (String id : idsToUpdate) {
      if (id.equals(COLLABORATION_FOLDER)) {
        boolean collaborationEnabled = caseCollaborationStrategy.isCollaborationEnabled(
          caseHeader);

        navigationState.setEnabled(collaborationEnabled, id);
        navigationState.setVisible(collaborationEnabled, id);
      }
    }

    return navigationState;
  }
}
