/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd. All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with Curam Software.
 */
package curam.bihelper.sl.impl;


import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.w3c.dom.Document;

import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.bihelper.administration.sl.impl.BIReportConfiguration;
import curam.bihelper.administration.sl.impl.BIReportConfigurationDAO;
import curam.bihelper.administration.sl.impl.BIReportParameter;
import curam.bihelper.administration.sl.impl.BIViewerConfiguration;
import curam.bihelper.administration.sl.impl.BIViewerConfigurationDAO;
import curam.cefwidgets.docbuilder.impl.BIReportBuilder;
import curam.cefwidgets.docbuilder.impl.WidgetDocumentBuilder;
import curam.codetable.REPORTSCROLLING;
import curam.core.impl.CuramConst;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;


/**
 * This class provides functionality for BI report configuration retrieval in
 * XML form suitable for report renderer.
 */
@Singleton
public class BIHelperImpl implements BIHelper {

  // BIViewerConfigurationDAO class variable
  @Inject
  protected BIViewerConfigurationDAO biViewerConfigurationDAO;

  // BIReportConfigurationDAO class variable
  @Inject
  protected BIReportConfigurationDAO biReportConfigurationDAO;

  // ___________________________________________________________________________
  /**
   * Formats a date object for inclusion on a URL HTTP end point.
   *
   * @param inDate
   * the date for format
   * @return String a date formatted for use as a parameter on a BIRT report
   */

  @Override
  public String formatDateForBIRT(java.util.Calendar inDate) {
    return formatDateForBIRT(new java.util.Date(inDate.getTime().getTime()));
  }

  // ___________________________________________________________________________
  /**
   * Formats a date object for inclusion on a URL HTTP end point.
   *
   * @param inDate
   * the date for format
   * @return String a date formatted for use as a parameter on a BIRT report
   */

  @Override
  public String formatDateForBIRT(java.util.Date inDate) {
    String formattedDate = "1999-01-01";

    try {
      String birtDateFormat = "yyyy-MM-dd";
      java.text.SimpleDateFormat dateFormat = new SimpleDateFormat(
        birtDateFormat);

      formattedDate = dateFormat.format(inDate.getTime());      
    } catch (java.util.IllegalFormatException e) {
      System.out.println("formatted date=" + e.getMessage());
    }
    return formattedDate;
  }

  // ___________________________________________________________________________
  /**
   * Parses parameter maps and merges them giving the priority to custom
   * parameters over the report parameters, and to report parameters over the
   * viewer parameters.
   *
   * @param customParameters
   * Contains custom parameter map
   * @param reportParameters
   * Contains report parameter map
   * @param viewerParameters
   * Contains viewer parameter map
   * @return Merged parameter map
   */
  protected Map<String, String> mergeParameters(
    Map<String, String> customParameters,
    Map<String, String> reportParameters, Map<String, String> viewerParameters) {

    // Return structure
    Map<String, String> returnMap = new HashMap<String, String>();

    boolean fNotEmpty = false;

    // Viewer parameters with the same name are replaced by report
    // parameters, and report parameters with the same name are replaced
    // by custom parameters.
    if (viewerParameters != null) {
      returnMap.putAll(viewerParameters);
      fNotEmpty = true;
    }

    if (reportParameters != null) {
      returnMap.putAll(reportParameters);
      fNotEmpty = true;
    }

    if (customParameters != null) {
      returnMap.putAll(customParameters);
      fNotEmpty = true;
    }

    if (fNotEmpty) {
      return returnMap;
    } else {
      return null;
    }

  }

  // ___________________________________________________________________________
  /**
   * Converts BI report parameter Set to Map of Strings.
   *
   * @param parameterSet
   * Contains Set of BI report parameters
   * @return Converted Map of key (name) and value (value) strings
   */
  protected Map<String, String> convertParameterSetToMap(
    final Set<BIReportParameter> parameterSet) {

    if (parameterSet != null) {
      // Return structure
      Map<String, String> returnMap = new HashMap<String, String>();

      Iterator<BIReportParameter> biReportParameterIterator;

      biReportParameterIterator = parameterSet.iterator();

      BIReportParameter reportParameter;

      while (biReportParameterIterator.hasNext()) {
        reportParameter = biReportParameterIterator.next();
        returnMap.put(reportParameter.getName(), reportParameter.getValue());
      }

      return returnMap;

    } else {
      return null;
    }

  }

  // ___________________________________________________________________________
  /**
   * Converts parameter map to parameter string for URL.
   *
   * @param parameterMap
   * String map containing name and value pairs
   * @return String containing parameter names and values for URL
   */
  protected String convertParameterMapToStringForURL(
    final Map<String, String> parameterMap) {

    // Return value
    String retVal = "";

    if ((parameterMap != null) && (!parameterMap.isEmpty())) {
      Set<Entry<String, String>> entries = parameterMap.entrySet();

      Entry<String, String> parameterEntry;

      Iterator<Entry<String, String>> mapIterator = entries.iterator();

      while (mapIterator.hasNext()) {
        parameterEntry = mapIterator.next();
        retVal = retVal + BIReportConst.gkAndChar + parameterEntry.getKey()
          + CuramConst.gkEqualsNoSpaces + parameterEntry.getValue();
      }

    }

    return retVal;

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public String getReportDataXML(final String reportName) throws AppException,
      InformationalException {
    return getReportDataXML(reportName, null, null);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public Document getReportData(final String reportName) throws AppException,
      InformationalException {
    return getReportData(reportName, null, null);
  }

  // BEGIN, CR00223475, ELG
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public WidgetDocumentBuilder getDocumentBuilder(final String reportName)
    throws AppException, InformationalException {
    return getDocumentBuilder(reportName, null, null);
  }

  // END, CR00223475

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public String getReportDataXML(final String reportName,
    final Map<String, String> parameters) throws AppException,
      InformationalException {
    return getReportDataXML(reportName, parameters, null);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public Document getReportData(final String reportName,
    final Map<String, String> parameters) throws AppException,
      InformationalException {
    return getReportData(reportName, parameters, null);
  }

  // BEGIN, CR00223475, ELG
  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public WidgetDocumentBuilder getDocumentBuilder(final String reportName,
    final Map<String, String> parameters) throws AppException,
      InformationalException {
    return getDocumentBuilder(reportName, parameters, null);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public WidgetDocumentBuilder getDocumentBuilder(final String reportName,
    final Map<String, String> parameters, final String servletName)
    throws AppException, InformationalException {

    // Get BI Viewer configuration. There must be just one record per system.
    Set<BIViewerConfiguration> biViewerConfigurationSet = biViewerConfigurationDAO.searchAllActive();

    Iterator<BIViewerConfiguration> biViewerIterator = biViewerConfigurationSet.iterator();

    BIViewerConfiguration biViewerConfiguration;

    if (biViewerIterator.hasNext()) {
      biViewerConfiguration = biViewerIterator.next();
    } else {
      biViewerConfiguration = null;
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BIHELPER.ERR_BI_VIEWER_CONFIGURATION_NOT_FOUND),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Get report configuration by report name.
    // The system should return just one report configuration record.
    Set<BIReportConfiguration> biReportConfigurationSet = biReportConfigurationDAO.searchActiveByName(
      reportName);

    Iterator<BIReportConfiguration> biReportIterator;

    BIReportConfiguration biReportConfiguration;

    biReportIterator = biReportConfigurationSet.iterator();

    if (!biReportIterator.hasNext()) {

      biReportConfiguration = null;
      AppException ex = new AppException(
        curam.message.BIHELPER.ERR_BI_REPORT_CONFIGURATION_NOT_FOUND);

      ex.arg(reportName);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ex, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    } else {

      biReportConfiguration = biReportIterator.next();

    }

    if (biReportConfigurationSet.size() > 1) {

      AppException ex = new AppException(
        curam.message.BIHELPER.ERR_BI_REPORT_CONFIGURATION_NOT_UNIQUE);

      ex.arg(reportName);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ex, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    // Retrieve viewer configuration related parameters.
    Set<BIReportParameter> biViewerParameterSet = biViewerConfiguration.getParameters();

    // Retrieve report configuration related parameters.
    Set<BIReportParameter> biReportParameterSet = biReportConfiguration.getParameters();

    String reportContext = biViewerConfiguration.getReportContext();
    String reportRoot = biViewerConfiguration.getReportRoot();

    String reportServlet;

    // If servlet is set by the user, then use user's servlet
    // else use report configuration servlet. If report configuration
    // servlet is not set then use system BI viewer configuration default
    // servlet.
    if ((servletName != null) && (servletName.length() > 0)) {
      reportServlet = servletName;
    } else if (biReportConfiguration.getReportServlet().length() > 0) {
      reportServlet = biReportConfiguration.getReportServlet();
    } else {
      reportServlet = biViewerConfiguration.getReportServlet();
    }

    // Create standard string maps from the report parameter sets
    Map<String, String> viewerParameters = convertParameterSetToMap(
      biViewerParameterSet);

    // Append currently connected user locale parameter if
    // it is not specified for the viewer yet.
    // Because of this __locale parameter has the following precedence order:
    // 1. as specified per call to getDocumentBuilder()
    // 2. as specified per report configuration
    // 3. as specified per viewer configuration
    // 4. as retrieved from TransactionInfo.getProgramLocale()
    if (!viewerParameters.containsKey(BIReportConst.gkLocaleParameter)) {
      viewerParameters.put(BIReportConst.gkLocaleParameter,
        TransactionInfo.getProgramLocale());
    }

    Map<String, String> reportConfigurationParameters = convertParameterSetToMap(
      biReportParameterSet);

    // Merge parameters into one map
    Map<String, String> mergedParameters = mergeParameters(parameters,
      reportConfigurationParameters, viewerParameters);
    
    // BEGIN, CR00413069, JAF
    // Sanitize the parameters in the mergedParamters Map to remove any potentially malicious content.
    Map<String, String> sanitizedParameters = new HashMap<String, String>();

    ;
    
    for (Map.Entry<String, String> param : mergedParameters.entrySet()) {
      String sanitisedParamName = curam.util.common.util.JavaScriptEscaper.escapeText(
        param.getKey());
      String sanitisedParamValue = curam.util.common.util.JavaScriptEscaper.escapeText(
        param.getValue());
      
      sanitizedParameters.put(sanitisedParamName, sanitisedParamValue);
    }

    // Convert merged parameter map to string suitable for appending to URL
    String parameterStringForURL = convertParameterMapToStringForURL(
      sanitizedParameters);
    // END, CR00413069, JAF

    // Construct full report URL with parameters
    String reportURL = reportRoot + CuramConst.gkSlashChar + reportContext
      + CuramConst.gkSlashChar + reportServlet + CuramConst.kQuestion
      + biViewerConfiguration.getReportNameParameter()
      + CuramConst.gkEqualsNoSpaces + biReportConfiguration.getReportFileName()
      + parameterStringForURL;

    BIReportBuilder reportBuilder = new BIReportBuilder();

    reportBuilder.setName(reportName);
    reportBuilder.setPath(reportURL);
    reportBuilder.setDescription(biReportConfiguration.getDescription());
    reportBuilder.setWidth(biReportConfiguration.getWidth());
    reportBuilder.setHeight(biReportConfiguration.getHeight());
    reportBuilder.setScrolling(
      curam.util.type.CodeTable.getOneItem(REPORTSCROLLING.TABLENAME,
      biReportConfiguration.getScrolling().getCode()));
    reportBuilder.setFrameborder(biReportConfiguration.getFrameborder());

    return reportBuilder;

  }

  // END, CR00223475

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public Document getReportData(final String reportName,
    final Map<String, String> parameters, final String servletName)
    throws AppException, InformationalException {

    // BEGIN, CR00223475, ELG
    return getDocumentBuilder(reportName, parameters, servletName).getWidgetDocument();
    // END, CR00223475

  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  @Override
  public String getReportDataXML(final String reportName,
    final Map<String, String> parameters, final String servletName)
    throws AppException, InformationalException {

    // BEGIN, CR00223475, ELG
    return getDocumentBuilder(reportName, parameters, servletName).toString();
    // END, CR00223475

  }

}
