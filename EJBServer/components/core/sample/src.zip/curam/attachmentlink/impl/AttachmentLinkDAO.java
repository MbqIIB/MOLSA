/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attachmentlink.impl;

import java.util.List;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.ATTACHMENTOBJECTLINKTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.util.persistence.StandardDAO;

/**
 * Data access for {@linkplain curam.attachmentlink.impl.AttachmentLink}.
 */
@ImplementedBy(AttachmentLinkDAOImpl.class)
public interface AttachmentLinkDAO extends StandardDAO<AttachmentLink> {

  // ___________________________________________________________________________
  /**
   * Searches for all the AttachmentLink records by id and type.
   * 
   * @param relatedObjectID
   *          Related Object ID
   * @param attachmentLinkType
   *          Attachment Link Type
   * @return all the instances which are associated with the id and type.
   */
  public List<AttachmentLink> searchByRelatedIDAndType(
      final long relatedObjectID,
      final ATTACHMENTOBJECTLINKTYPEEntry attachmentLinkType);

  // ___________________________________________________________________________
  /**
   * Searches for all the AttachmentLink records by id, type and status.
   * 
   * @param relatedObjectID
   *          Related Object ID
   * @param attachmentLinkType
   *          Attachment Link Type
   * @param recordStatus
   *          The Record Status
   * @return all the instances which are associated with the id, type and
   *         status.
   */
  public List<AttachmentLink> searchByRelatedIDTypeAndStatus(
      final long relatedObjectID,
      final ATTACHMENTOBJECTLINKTYPEEntry attachmentLinkType,
      RECORDSTATUSEntry recordStatus);
}
