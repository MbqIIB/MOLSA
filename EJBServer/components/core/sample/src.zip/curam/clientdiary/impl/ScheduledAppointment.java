/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.clientdiary.impl;


import curam.clientdiary.codetable.impl.CLIENTDIARYRELATEDTYPEEntry;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.core.impl.CuramConst;
import curam.core.intf.Activity;
import curam.piwrapper.user.impl.User;
import curam.util.exception.LocalisableString;
import curam.util.persistence.StandardEntity;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * Interface for a scheduled appointment for a client. This may be one of
 * several types, e.g calendar activity, action, service or referral, and each
 * entity will provide its own specific implementation for each of the methods
 * below.
 *
 * @since 6.0
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ScheduledAppointment extends StandardEntity {

  /**
   * Returns a description of the scheduled appointment. E.g. if this is a
   * calendar activity, the description may be the subject of the meeting. If
   * this is an action, the description will be the action name.
   *
   * @return The description of the scheduled appointment.
   */
  String getDescription();

  /**
   * Returns the name of the owner of the scheduled appointment.
   *
   * @return The name of the scheduled appointment owner.
   */
  String getOwnerName();

  /**
   * Returns the {@link ORGOBJECTTYPEEntry} of the owner of the
   * {@link ScheduledAppointment}. E.g. for an {@link Activity}, this may be a
   * {@link User} or an {@link curam.piwrapper.organization.impl.Organisation}.
   *
   * @return The type of the owner of the scheduled appointment
   */
  ORGOBJECTTYPEEntry getOwnerOrgObjectType();

  /**
   * Returns the unique identifier of the owner of the
   * {@link ScheduledAppointment}. This should be used in conjunction with
   * {@link ScheduledAppointment#getOwnerOrgObjectType()}. E.g. where the owner
   * is an {@link curam.piwrapper.organization.impl.Organisation}, a
   * {@link Long} is returned.
   *
   * @return The unique identifier of the owner of the scheduled appointment
   */
  Object getOwnerOrgObjectReference();

  /**
   * Returns a {@link LocalisableString} with a textual description of the start
   * date and also the start time if specified. E.g. For a calendar activity
   * this would be dd/mm/yyyy at hh:mm, whereas for an action this would simply
   * be dd/mm/yyyy.
   *
   * @return A localizable string with a textual description of the start date,
   * and time (if given) of the scheduled appointment.
   */
  LocalisableString getStart();

  /**
   * Returns a {@link LocalisableString} with a textual description of the end
   * date and also the end time if specified. E.g. For a calendar activity this
   * would be dd/mm/yyyy at hh:mm, whereas for an action this would simply be
   * dd/mm/yyyy. If no end date or time is specified, an empty string should be
   * returned.
   *
   * @return A localizable textual description of the end date, and time (if
   * given) of the scheduled appointment.
   */
  LocalisableString getEnd();

  /**
   * Returns a description of the frequency of the scheduled appointment to be
   * converted on the client. E.g. for a calendar activity, this may be the
   * occurrence for a recurring meeting. For an action, this may be the
   * frequency pattern and duration of the activity. If the appointment is not
   * recurring, an empty string should be returned.
   * <p>
   * This is intended for use with the FREQUENCY_DURATION_STRING domain
   * definition, which is converted to a textual description of the frequency of
   * the scheduled appointment on the client. The string is made up of the
   * frequency pattern, plus {@link CuramConst#gkPipeDelimiter}, plus duration
   * as a client formatted LocalisableString. The frequency and duration are
   * optional and an empty string is returned if none are set.<br/>
   * E.g. Input string:'000120100|3::curam.clientdiary.message.ScheduledAppointment:INFO_FREQUENCY_DURATION_STRING:(3|17)'
   * is converted to the output string 'Every 1 day(s) for 3 hours 17 minutes'
   * on the client.
   * </p>
   *
   * @return A textual description of the frequency of the scheduled appointment
   */
  String getFrequencyAndDuration();

  /**
   * Get the related type for the scheduled appointment. This may be one of
   * {@link curam.outcomeplanning.outcomeplan.impl.OutcomePlanAction},
   * {@link curam.servicedelivery.impl.ServiceDelivery},
   * {@link curam.referral.impl.Referral} or {@link Activity}.
   *
   * @return The related type for the scheduled appointment.
   */
  CLIENTDIARYRELATEDTYPEEntry getClientDiaryRelatedType();
}
