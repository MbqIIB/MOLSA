/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.clientdiary.impl;

import java.util.List;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.RECORDSTATUSEntry;
import curam.participant.impl.ConcernRole;
import curam.util.persistence.StandardDAO;
import curam.util.type.DateRange;

/**
 * Data retrieval operations for the {@linkplain ClientDiary} entity.
 * 
 * @see curam.clientdiary.entity.intf.ClientDiary
 * @curam.nonimplementable
 * @since 6.0
 */
@ImplementedBy(ClientDiaryDAOImpl.class)
interface ClientDiaryDAO extends StandardDAO<ClientDiary> {

  /**
   * Returns the active {@link ClientDiary} with the given {@link ConcernRole},
   * and {@link ScheduledAppointment}. If none is found, null is returned.
   * 
   * @param concernRole
   *          The concern role to search by
   * @param scheduledAppointment
   *          The scheduled appointment to search by
   * @return The active client diary record with the given concern role and
   *         scheduled appointment.
   */
  public ClientDiary readActiveByConcernRoleAndScheduledAppointment(
      final ConcernRole concernRole,
      final ScheduledAppointment scheduledAppointment);

  /**
   * Returns a list of all {@link ClientDiary} with the given
   * {@link ConcernRole}, {@link ScheduledAppointment} and
   * {@link RECORDSTATUSEntry}. The list is sorted by start date.
   * 
   * @param concernRole
   *          The concern role to search by
   * @param scheduledAppointment
   *          The scheduled appointment to search by
   * @param status
   *          The status to search by
   * @return A list of all active client diary records with the given concern
   *         role, scheduled appointment and status
   */
  public List<ClientDiary> listByConcernRoleScheduledAppointmentAndStatus(
      final ConcernRole concernRole,
      final ScheduledAppointment scheduledAppointment, RECORDSTATUSEntry status);

  /**
   * Returns a list of all active {@link ClientDiary} with the given
   * {@link ConcernRole}, which overlaps with the given {@link DateRange}. The
   * list is sorted by start date.
   * 
   * @param concernRole
   *          The concern role to search by
   * @param dateRange
   *          The start and end date to search by
   * @return A list of all active client diary records with the given concern
   *         role which overlap with the given date range.
   */
  public List<ClientDiary> listActiveByConcernRoleDateRange(
      final ConcernRole concernRole, final DateRange dateRange);

  /**
   * Returns a list of all active {@link ClientDiary} for the given
   * {@link ScheduledAppointment}.
   * 
   * @param scheduledAppointment
   *          The scheduled appointment to search by
   * @return A list of all active client diary records for the given scheduled
   *         appointment
   */
  public List<ClientDiary> listActiveByScheduledAppointment(
      final ScheduledAppointment scheduledAppointment);
}
