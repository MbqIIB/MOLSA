/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2008-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.attendance.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.ABSENCEREASONASSOCIATETYPEEntry;
import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain curam.attendance.impl.AbsenceReasonConfiguration}
 * .
 */
@ImplementedBy(AbsenceReasonConfigurationDAOImpl.class)
public interface AbsenceReasonConfigurationDAO extends
    StandardDAO<AbsenceReasonConfiguration> {

  /**
   * Lists all the absence reason records based on absence reason associate
   * type.
   *
   * @param absenceReasonType
   * Contains absence reason and associate type.
   * @return Set of absence reason configurations.
   */
  Set<AbsenceReasonConfiguration> searchByAbsenceReasonType(
    final String absenceReasonType);

  /**
   * Lists all the absence reason records based on associateID.
   *
   * @param associateID
   * Associate ID.
   * @return Set of absence reason configurations.
   */
  Set<AbsenceReasonConfiguration> searchByAssociateID(final long associateID);

  /**
   * Searches all the active absence reasons based on given absence reason code
   * and associate id.
   *
   * @param absenceReason
   * Absence reason code.
   * @param associateID
   * Associate ID.
   * @return Set of absence reason configurations.
   */
  Set<AbsenceReasonConfiguration> searchByAbsenceReasonAndAssociateID(
    final String absenceReason, final long associateID);

  /**
   * Searches all the active absence reasons based on given absence reason code
   * and type.
   *
   * @param absenceReason
   * Absence reason code.
   * @param absenceReasonType
   * Absence reason type.
   * @return Set of absence reason configurations.
   */
  Set<AbsenceReasonConfiguration> searchByAbsenceReasonAndType(
    final String absenceReason,
    final ABSENCEREASONASSOCIATETYPEEntry absenceReasonType);

  // BEGIN, CR00261800, SK
  /**
   * Returns all the active absence reason configurations on the system.
   *
   * @return The active absence reason configurations.
   */
  Set<AbsenceReasonConfiguration> readAll();
  // END, CR00261800
}
