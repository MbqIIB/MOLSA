/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.appeal.impl;


import java.util.ArrayList;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.APPEALOBJECTTYPEEntry;
import curam.codetable.impl.APPEALTYPEEntry;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Provides information on the appeals configuration for a case type and its
 * objects. This interface should be not used.
 *
 * @Curam .noimplement This interface is not intended to be implemented by clients.
 * @noimplement
 */
@ImplementedBy(AppealsImpl.class)
public interface Appeals {

  /**
   * This method should be not used.
   *
   * @param caseID
   * Case identifier.
   *
   * @return The next stage for a case type.
   */
  APPEALTYPEEntry getNextStageForCaseType(long caseID) throws AppException,
      InformationalException;

  /**
   * This method should be not used.
   *
   * @param appealCaseID The appeal case identifier.
   *
   * @return The current stage for the appeal case.
   */
  APPEALTYPEEntry getCurrentStageForAppealCase(long appealCaseID) throws AppException,
      InformationalException;

  /**
   * This method should be not used.
   *
   * @param caseID
   * Case identifier.
   *
   * @return A list of appeal stages for a given case type.
   */
  ArrayList<APPEALTYPEEntry> listAllStagesForCaseType(long caseID)
    throws AppException, InformationalException;

  /**
   * This method should be not used.
   *
   * @param objectType
   * Object type code.
   * @param objectID
   * Object type identifier.
   * @param appealStageType
   * The appeal stage type.
   * @param caseID
   * Case identifier which the object belongs to.
   * @return Boolean indicating if the object can be added to a hearing review
   * case.
   */
  public boolean isObjectValidForStage(APPEALOBJECTTYPEEntry objectType,
    long objectID, APPEALTYPEEntry appealStageType, long caseID)
    throws AppException, InformationalException;

}
