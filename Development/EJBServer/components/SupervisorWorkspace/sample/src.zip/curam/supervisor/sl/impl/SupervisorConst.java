/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2006-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.supervisor.sl.impl;


/**
 * This class assigns values to the Curam constants
 *
 */
public abstract class SupervisorConst {

  /**
   * Identifier for constant ALL
   */
  public static final String kcode_All = "ALL";

  /**
   * Identifier for constant All
   */
  public static final String kcode_Description = "All";

  /**
   * Identifier for constant 0
   */
  public static final long korhUint_All = 0;

  /**
   * Identifier for constant 7 days
   */
  public static final int kseven_Days = 7;

  // BEGIN, CR00182755, CL
  /**
   * Identifier for constant Yes
   * 
   * @deprecated-since 52. SP3. This constant is replaced by
   * curam.util.exception.LocalisableString
   *   (curam.message.SUPERVISORCONST.INF_SUPERVISORCONST_KCODE_YES)
   *   .getMessage(TransactionInfo.getProgramLocale())
   *   
   * This constant is deprecated because it did not facilitate localization.
   * See release note CR00182755.
   * 
   * @deprecated
   */
  public static final String kcode_Yes = "Yes";

  /**
   * Identifier for constant No
   * 
   * @deprecated-since 5.2 SP3. This constant is replaced by
   * curam.util.exception.LocalisableString
   *   (curam.message.SUPERVISORCONST.INF_SUPERVISORCONST_KCODE_NO)
   *   .getMessage(TransactionInfo.getProgramLocale())
   *   
   * This constant is deprecated because it did not facilitate localization.
   * See release note CR00182755.
   *   
   * @deprecated
   */
  public static final String kcode_No = "No";
  // END, CR00182755

  /**
   * Identifier for constant WorkQueueId
   */
  public static final String kID = "ID";

  /**
   * Used to set the User Full Name for Bar chart creation
   */
  public static final String kFullName = "FULL_NAME";

  /**
   * Used to set the User  Name for Bar chart creation
   */
  public static final String kUserName = "USER_NAME";

  /**
   * Used to set the StartDate for Bar chart creation
   */
  public static final String kStartDate = "START_DATE";

  /**
   * Used to set the OrgUnitID for Bar chart creation
   */
  public static final String kOrgUnitID = "ORGUNIT_ID";

  /**
   * Used to set the OrgStructureID for Bar chart creation
   */

  public static final String kOrgStructureID = "ORG_UNIT_STRUCTURE_ID";

  /**
   * Used to set the OrgUnitName for Bar chart creation
   */

  public static final String kOrgUnitName = "ORG_UNIT_NAME";

  /**
   * Used to set the TaskOptionCode for Bar chart creation
   */

  public static final String kTaskOptionCode = "TASK_OPTION_CODE";

  /**
   * Used to set the StructID in the block element.
   */

  public static final String kStructID = "STRUCT_ID";

  /**
   * Identifier for holding the hyperlink on email id
   */
  // BEGIN CR00098488 , KK 
  // The space in the constant "mail to:" has been deleted
  public static final String kMailLink = "mailto:";
  // END CR00098488 , KK 
  /**
   * Identifier for holding the Number of weeks for task due
   *
   */
  public static final int kNumberOfWeeks = 5;

  /**
   * Identifier for separator
   */
  public static final String kSeparator = " - ";

  /**
   * Identifier for holding the BufSize
   */
  public static final int kBufSize = 256;

  /**
   * Identifier for greater than equal to
   */
  public static final String kGreaterThanEqualTo = ">=";

  /**
   * Identifier to display the tool-tip as 'Assigned' instead of 'Un-Reserved'
   * tool-tip in bar chart
   */
  public static final String kCaptionAssigned = "Assigned";

  /**
   * Identifier for holding the type of chart
   */
  public static final String kBarChart = "BAR_CHART";

  /**
   * Identifier for holding the element type
   */
  public static final String kUnit = "UNIT";

  /**
   * Identifier for holding the element caption
   */
  public static final String kCaption = "CAPTION";

  /**
   * Identifier for holding the element caption text
   */
  public static final String kText = "TEXT";

  /**
   * Identifier for holding the element
   */
  public static final String kBlock = "BLOCK";

  /**
   * Identifier for holding the navigation option
   */
  public static final String kType = "TYPE";

  /**
   * Identifier for holding the due date
   */
  
  public static final String kDueDate = "DUE_DATE";

  /**
   * Identifier for holding the bar graph length
   */
  public static final String kLength = "LENGTH";
  
  /**
   * Identifier for holding the Task Option Code for navigating to different
   * pages.
   */
  public static final String kIssueType = "ISSUE_TYPE";

  // BEGIN, CR00182755, CL
  /**
   * Identifier for holding the Task Option Code for navigating to different
   * pages.
   * 
   * @deprecated-since 5.2 SP3. This constant is replaced by
   * curam.util.exception.LocalisableString
   *   (curam.message.SUPERVISORCONST.TEXT_SUPERVISORCONST_ISSUE_TYPE)
   *   .getMessage(TransactionInfo.getProgramLocale()) instead.
   *   
   * This constant is deprecated because it did not facilitate localization.
   * See release note CR00182755.
   * 
   * @deprecated
   */

  public static final String kIssueTypeDesc = "Issue Type";
  // END, CR00182755
  
  /**
   * Identifier for holding the Organization Unit ID for Bar chart
   */
  public static final String kRegion = "REGION";

  /**
   * Identifier for holding the type of chart
   */
  public static final String kHeatMap = "HEATMAP";

  /**
   * Identifier for holding the element type
   */
  public static final String kRegionId = "REGION_ID";

  /**
   * Identifier for holding the element caption
   */
  public static final String kCaseId = "CASE_ID";

  /**
   * Identifier for holding the element caption text
   */
  public static final String kLabel = "LABEL";

  /**
   * Identifier for holding the element
   */
  public static final String kItem = "ITEM";

  /**
   * Identifier for holding the navigation option
   */
  public static final String kItemId = "ITEM_ID";

  /**
   * Identifier for holding the array which contains the legend information
   */
  public static final String[] kRegionArray =
    { ">25", "21-25", "16-20", "11-15", "6-10", "1-5" };
  
  // BEGIN, CR00190772, CL
  /**
   * Used as the separator in a date format
   * 
   * @deprecated-since 5.2 SP3, This constant is replaced by
   * curam.util.exception.LocalisableString(
   *   curam.message.SUPERVISORCONST.INF_SUPERVISORCONST_KCODE_DATE_SEPARATOR)
   *   .getMessage(TransactionInfo.getProgramLocale()).
   * This constant is deprecated because it did not facilitate localization.
   * See release note CR00183504.
   * 
   * @deprecated
   */
  public static final String kSlash = "/";

  /**
   * Identifier for holding the Date format for the Choose Date widget
   */
  public static final String kChooseDateFormat = "yyyyddmm";  
  // END, CR00190772
  
  /**
   * Identifier for holding the work queue Name
   */
  public static final String kWorkQueueName = "WORKQUEUE_NAME";
  
  // BEGIN, CR00085608 SK
  /**
   * Identifier for holding the Date format
   */
  public static final String kDateFormat = "EEE d MMM";
  
  /**
   * Identifier for holding the value of region ID
   */
  public static final String kRegionIdValue = "Region ";
  
  /**
   * Identifier for holding the plus symbol
   */
  public static final String kPlus = "+";
  
  // END, CR00085608 SK

  //BEGIN, CR00169865, KP
  /**
   * BLOCK XML element's startDate attribute
   */
  public static final String kBlockStartDate = "BLOCK_START_DATE";
  
  /**
   * Date format of BLOCK XML element's startDate 
   */
  public static final String kBlockStartDateFormat = "M/d/yyyy";
  //END, CR00169865
  
}
