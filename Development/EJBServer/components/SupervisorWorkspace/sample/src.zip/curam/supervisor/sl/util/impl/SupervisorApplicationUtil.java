/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * Copyright 2007-2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.supervisor.sl.util.impl;


import curam.codetable.CASEUSERROLETYPE;
import curam.codetable.ORGOBJECTTYPE;
import curam.core.facade.struct.StandardManualTaskDtls;
import curam.core.fact.AdminUserFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.NotificationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.CaseHeader;
import curam.core.intf.Notification;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.PositionFactory;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.intf.Position;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.OrganisationUnitStatus;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.PositionStatus;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseReference;
import curam.core.struct.CaseReferenceAndStatusDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.UserDetails;
import curam.core.struct.UserFullname;
import curam.core.struct.UserKeyStruct;
import curam.core.struct.UsersKey;
import curam.message.BPOSUPERVISORCASE;
import curam.message.BPOSUPERVISORUSER;
import curam.supervisor.sl.struct.ReassignCaseKey;
import curam.supervisor.sl.struct.ReassignCasesForUserKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.internal.codetable.fact.CodeTableFactory;
import curam.util.internal.codetable.intf.CodeTable;
import curam.util.internal.codetable.struct.CTItem;
import curam.util.internal.codetable.struct.CTItemKey;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringList;


/**
 * Contains utility methods for use in the various supervisor application
 * management classes.
 */
public final class SupervisorApplicationUtil {

  // ______________________________________________________________________________
  /**
   * This method validates the functionality of reassigning a case.
   *
   * @param key - ReassignCasesForUserKey
   * @param stringList - StringList
   * @throws AppException
   * @throws InformationalException
   */
  public static void validateReassignCase(ReassignCasesForUserKey key,
    StringList stringList) throws AppException, InformationalException {

    // At least one case must be selected
    if (stringList.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_CASE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (key.newUserID.trim().length() == 0
      && key.supervisorUserID.trim().length() == 0 && !key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() != 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          6);
    }

    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() != 0)
        && !key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          7);
    }

    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() == 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);
    }
    if ((key.newUserID.trim().length() == 0
      && key.supervisorUserID.trim().length() != 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }
  }

  // ______________________________________________________________________________
  /**
   * This method is used to validate the user
   * @param key - ReassignCasesForUserKey
   * @exception AppException
   * @exception InformationalException
   */

  public static void validateReassignCaseUser(ReassignCasesForUserKey key)
    throws AppException, InformationalException {

    // object creation
    curam.core.intf.AdminUser adminUser = AdminUserFactory.newInstance();
    UserKeyStruct userKeyStruct = new UserKeyStruct();

    if (key.supervisorUserID.trim().length() != 0) {
      userKeyStruct.userName = key.supervisorUserID;
    } else {
      userKeyStruct.userName = key.newUserID;
    }
    UserDetails userDetails = adminUser.read(userKeyStruct);

    if (curam.codetable.RECORDSTATUS.CANCELLED.equals(userDetails.statusCode)) {
      AppException ae = new AppException(
        BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USER_INACTIVE);

      ae.arg(userDetails.fullName);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
  }

  // ______________________________________________________________________________
  /**
   * This method is used to validate the organization object other than user
   *
   * @param key - ReassignCasesForUserKey
   * @exception AppException
   * @exception InformationalException
   */
  public static void validateReassignCaseOrgObject(ReassignCasesForUserKey key)
    throws AppException, InformationalException {

    if (ORGOBJECTTYPE.ORGUNIT.equals(key.organisationObject)) {
      curam.core.sl.entity.intf.OrganisationUnit orgUnit = OrganisationUnitFactory.newInstance();
      OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

      organisationUnitKey.organisationUnitID = Long.parseLong(key.newUserID);
      OrganisationUnitStatus organisationUnitStatus = orgUnit.readStatus(
        organisationUnitKey);
      String OrgName = orgUnit.readOrgUnitName(organisationUnitKey).name;

      if (curam.codetable.RECORDSTATUS.CANCELLED.equals(
        organisationUnitStatus.recordStatus)) {
        AppException ae = new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_ORGANIZATIONUNIT_CANCELLED);

        ae.arg(OrgName);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }
    } else if (ORGOBJECTTYPE.POSITION.equals(key.organisationObject)) {
      Position posObj = PositionFactory.newInstance();
      PositionKey positionKey = new PositionKey();

      // BEGIN, CR00148148 , AK
      positionKey.positionID = Long.parseLong(key.newUserID);
      // END, CR00148148 
      PositionStatus positionStatus = posObj.readStatus(positionKey);
      String PositionName = posObj.readPositionName(positionKey).name;

      if (curam.codetable.RECORDSTATUS.CANCELLED.equals(
        positionStatus.recordStatus)) {
        AppException ae = new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_POSITION_CANCELLED);

        ae.arg(PositionName);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      }
    }
  }

  // ______________________________________________________________________________
  /**
   * This method is used to validate the organization object other than user
   * for single case reassign
   *
   * @param key - ReassignCaseKey
   * @exception AppException
   * @exception InformationalException
   */
  public static void validateReassignCaseOrgObject(ReassignCaseKey key)
    throws AppException, InformationalException {

    if (ORGOBJECTTYPE.ORGUNIT.equals(key.organisationObject)) {

      curam.core.sl.entity.intf.OrganisationUnit orgUnit = OrganisationUnitFactory.newInstance();
      OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

      organisationUnitKey.organisationUnitID = Long.parseLong(key.newUserID);
      OrganisationUnitStatus organisationUnitStatus = orgUnit.readStatus(
        organisationUnitKey);
      String OrgName = orgUnit.readOrgUnitName(organisationUnitKey).name;

      if (curam.codetable.RECORDSTATUS.CANCELLED.equals(
        organisationUnitStatus.recordStatus)) {
        AppException ae = new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_ORGANIZATIONUNIT_CANCELLED);

        ae.arg(OrgName);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
      }
    } else if (ORGOBJECTTYPE.POSITION.equals(key.organisationObject)) {
      Position posObj = PositionFactory.newInstance();
      PositionKey positionKey = new PositionKey();

      // CR00093320 - Modified to fix the Number format exception as Position ID
      // is of type long.
      positionKey.positionID = Long.parseLong(key.newUserID);
      PositionStatus positionStatus = posObj.readStatus(positionKey);
      String PositionName = posObj.readPositionName(positionKey).name;

      if (curam.codetable.RECORDSTATUS.CANCELLED.equals(
        positionStatus.recordStatus)) {
        AppException ae = new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_POSITION_CANCELLED);

        ae.arg(PositionName);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
      }
    }
  }

  // ______________________________________________________________________________
  /**
   * This method is used to validate the case which has to be reassigned
   * @param key - ReassignCaseKey
   * @exception AppException
   * @exception InformationalException
   */
  public static void validateReassignCase(ReassignCaseKey key)
    throws AppException, InformationalException {

    if (key.newUserID.trim().length() == 0
      && key.supervisorUserID.trim().length() == 0 && !key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }

    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() != 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_AND_AUTOREASSIGN_SELECTION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          5);
    }

    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() != 0)
        && !key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          5);
    }

    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() == 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_AND_AUTOREASSIGN_SELECTION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);
    }

    if ((key.newUserID.trim().length() == 0
      && key.supervisorUserID.trim().length() != 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_AND_AUTOREASSIGN_SELECTION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          4);
    }
  }

  // ______________________________________________________________________________
  /**
   * This method validates the case reassignment. It checks that case is not
   * closed and user to whom the case will be reassigned, is not inactive. It
   * also checks that only one user either supervisor user or the generic user
   * is selected.
   *
   * @param key - ReassignCaseKey
   * @exception AppException
   * @exception InformationalException
   */
  public static void validateReassignUser(ReassignCaseKey key) throws
      AppException, InformationalException {

    // object creation
    curam.core.intf.AdminUser adminUser = AdminUserFactory.newInstance();
    UserKeyStruct userKeyStruct = new UserKeyStruct();
    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    if ((key.newUserID.trim().length() == 0
      && key.supervisorUserID.trim().length() != 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          4);
    }

    if (key.supervisorUserID.trim().length() != 0) {
      userKeyStruct.userName = key.supervisorUserID;
    } else {
      userKeyStruct.userName = key.newUserID;
    }

    UserDetails userDetails = adminUser.read(userKeyStruct);

    if (curam.codetable.RECORDSTATUS.CANCELLED.equals(userDetails.statusCode)) {
      AppException ae = new AppException(
        BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USER_INACTIVE);

      ae.arg(userDetails.fullName);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 2);
    }

    // BEGIN, CR00279909, SG
    CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = key.caseID;
    CaseReferenceAndStatusDetails caseRefStatusDetails = caseHeaderObj.readCaseReferenceAndStatusByCaseID(
      caseSearchKey);

    if (caseRefStatusDetails.statusCode.equals(
      curam.codetable.CASESTATUS.CLOSED)) {
      AppException ae = new AppException(
        BPOSUPERVISORCASE.INF_SUPERVISOR_REASSIGN_CASE_NOT_BE_CLOSED_TEXT);

      ae.arg(caseRefStatusDetails.caseReference);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 1);
    }
  }

  // ______________________________________________________________________________
  /**
   * This method is called only when the property 'REASSIGNCASEFROMNOTIFICATION'
   * is set to YES. A notification is sent to the user whose case has been
   * reassigned to another user.
   *
   * @param key - ReassignCaseKey
   * @exception AppException
   * @exception InformationalException
   */
  public void sendFromNotificationForSingleCase(ReassignCaseKey key)throws
      AppException, InformationalException {

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    CaseSearchKey caseSearchKey = new CaseSearchKey();

    UserAccess userAccessObj = UserAccessFactory.newInstance();

    UsersKey usersKey = new UsersKey();

    SystemUser systemUser = SystemUserFactory.newInstance();

    caseSearchKey.caseID = key.caseID;
    CaseReference caseReference = caseHeaderObj.readCaseReferenceByCaseID(
      caseSearchKey);
    String loggedInUserName = systemUser.getUserDetails().userName;

    usersKey.userName = loggedInUserName;
    UserFullname userFullname = userAccessObj.getFullName(usersKey);

    OrgObjectLink orgObjectLink = OrgObjectLinkFactory.newInstance();

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    key.OrgObjLinkDtls = orgObjectLink.readOwnerOrgObjectLinkDetailsByCaseID(
      caseHeaderKey);

    LocalisableString communicationSubject = new LocalisableString(
      BPOSUPERVISORCASE.INF_SUPERVISOR_REASSIGN_CASE_NOTIFICATION_SUBJECT);
    LocalisableString communicationText = new LocalisableString(
      BPOSUPERVISORCASE.INF_SUPERVISOR_REASSIGN_CASE_NOTIFICATION_TEXT);

    communicationText.arg(caseReference.caseReference);
    communicationText.arg(userFullname.fullname);

    StandardManualTaskDtls stdManualTaskDtls = new StandardManualTaskDtls();

    // Set Notification details
    stdManualTaskDtls.dtls.concerningDtls.caseID = key.caseID;
    // BEGIN, CR00163659, CL
    stdManualTaskDtls.dtls.taskDtls.comments = communicationText.getMessage(
      TransactionInfo.getProgramLocale());
    stdManualTaskDtls.dtls.taskDtls.subject = communicationSubject.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163659

    Notification notificationObj = NotificationFactory.newInstance();

    notificationObj.createWorkAllocationNotification(stdManualTaskDtls);
  }

  // ______________________________________________________________________________
  /**
   * This method is called only when the property 'REASSIGNCASETONOTIFICATION'
   * is set to YES. A notification is sent to the user to whom the case is
   * reassigned.
   *
   * @param key - ReassignCaseKey
   * @exception AppException
   * @exception InformationalException
   */
  public void sendToNotificationForSingleCase(ReassignCaseKey key) throws
      AppException, InformationalException {

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    CaseSearchKey caseSearchKey = new CaseSearchKey();

    UserAccess userAccessObj = UserAccessFactory.newInstance();

    UsersKey usersKey = new UsersKey();

    SystemUser systemUser = SystemUserFactory.newInstance();

    caseSearchKey.caseID = key.caseID;
    CaseReference caseReference = caseHeaderObj.readCaseReferenceByCaseID(
      caseSearchKey);

    String loggedInUserName = systemUser.getUserDetails().userName;

    usersKey.userName = loggedInUserName;
    UserFullname userFullname = userAccessObj.getFullName(usersKey);

    LocalisableString communicationSubject = new LocalisableString(
      BPOSUPERVISORCASE.INF_SUPERVISOR_ASSIGN_CASE_NOTIFICATION_SUBJECT);
    LocalisableString communicationText = new LocalisableString(
      BPOSUPERVISORCASE.INF_SUPERVISOR_ASSIGN_CASE_NOTIFICATION_TEXT);

    CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    // code table variables
    CodeTable codeTableInterface = CodeTableFactory.newInstance();

    ctitemKey.code = CASEUSERROLETYPE.OWNER;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = CASEUSERROLETYPE.TABLENAME;

    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC
    
    communicationText.arg(ctitem.description);
    communicationText.arg(caseReference.caseReference);
    communicationText.arg(userFullname.fullname);

    StandardManualTaskDtls stdManualTaskDtls = new StandardManualTaskDtls();

    // Set Notification details
    stdManualTaskDtls.dtls.concerningDtls.caseID = key.caseID;
    // BEGIN, CR00163659, CL
    stdManualTaskDtls.dtls.taskDtls.comments = communicationText.getMessage(
      TransactionInfo.getProgramLocale());
    stdManualTaskDtls.dtls.taskDtls.subject = communicationSubject.getMessage(
      TransactionInfo.getProgramLocale());
    // END, CR00163659

    Notification notificationObj = NotificationFactory.newInstance();

    notificationObj.createWorkAllocationNotification(stdManualTaskDtls);
  }

  // ______________________________________________________________________________
  /**
   * This method is called only when the property 'REASSIGNCASESFROMNOTIFICATION'
   * (This property is for Users, Cases With issues, Cases With issues by date)
   * or REASSIGNCASEISSUEFROMNOTIFICATION(Issue case) is set to YES. A
   * notification is sent to the user whose list of cases has been reassigned to
   * another user
   *
   * @param key - ReassignCaseKey
   * @exception AppException
   * @exception InformationalException
   */
  public void sendFromNotificationForListOfCases(ReassignCasesForUserKey key,
    StringList strList, boolean isIssueCase)throws AppException,
      InformationalException {

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    CaseSearchKey caseSearchKey = new CaseSearchKey();
    StringBuffer strBuf = new StringBuffer();

    // All the case reference will be appended to string buffer to display list
    // of cases in the notification message.
    for (int i = 0; i < strList.size(); i++) {

      caseSearchKey.caseID = Long.parseLong(strList.item(i));

      CaseReference caseReference = caseHeaderObj.readCaseReferenceByCaseID(
        caseSearchKey);

      // BEGIN, CR00085608 SK
      strBuf.append(CuramConst.gkNewLine);
      strBuf.append(caseReference.caseReference);
      // END, CR00085608 SK
    }
    UserAccess userAccessObj = UserAccessFactory.newInstance();

    UsersKey usersKey = new UsersKey();

    SystemUser systemUser = SystemUserFactory.newInstance();

    String loggedInUserName = systemUser.getUserDetails().userName;

    usersKey.userName = loggedInUserName;
    UserFullname userFullname = userAccessObj.getFullName(usersKey);

    LocalisableString communicationSubject;
    LocalisableString communicationText;

    // If reassign is done from case issue page a different message will be
    // displayed. This message explains about issue case
    if (isIssueCase) {

      communicationSubject = new LocalisableString(
        BPOSUPERVISORCASE.INF_SUPERVISOR_REASSIGN_ISSUECASE_NOTIFICATION_SUBJECT);
      communicationText = new LocalisableString(
        BPOSUPERVISORCASE.INF_SUPERVISOR_REASSIGN_ISSUECASE_NOTIFICATION_TEXT);

    } else {

      // This message explains about list of cases (It could be users case or
      // cases with issues
      communicationSubject = new LocalisableString(
        BPOSUPERVISORCASE.INF_SUPERVISOR_REASSIGN_CASE_NOTIFICATION_SUBJECT);
      communicationText = new LocalisableString(
        BPOSUPERVISORCASE.INF_SUPERVISOR_REASSIGN_USERCASE_NOTIFICATION_TEXT);
    }

    // StringBuffer strBuf = getUserNameList(key);

    communicationText.arg(strBuf);
    communicationText.arg(userFullname.fullname);

    StandardManualTaskDtls stdManualTaskDtls = new StandardManualTaskDtls();

    // Set Notification details
    for (int i = 0; i < strList.size(); i++) {

      stdManualTaskDtls.dtls.concerningDtls.caseID = Long.parseLong(
        strList.item(i));

      // Only one notification would be displayed listing all the select cases
      // followed by notification message
      if (i == 0) {
        // BEGIN, CR00163659, CL
        stdManualTaskDtls.dtls.taskDtls.comments = communicationText.getMessage(
          TransactionInfo.getProgramLocale());
        stdManualTaskDtls.dtls.taskDtls.subject = communicationSubject.getMessage(
          TransactionInfo.getProgramLocale());
        // END, CR00163659
      } else {
        continue;
      }

      Notification notificationObj = NotificationFactory.newInstance();

      notificationObj.createWorkAllocationNotification(stdManualTaskDtls);
    }
  }

  // ____________________________________________________________________________
  /**
   * This method is called only when the property 'REASSIGNCASESTONOTIFICATION'
   * (This property is for Users, Cases With issues, Cases With issues by date)
   * or REASSIGNCASEISSUETONOTIFICATION(Issue case) is set to YES. A
   * notification is sent to the user to whom the list of cases is reassigned.
   *
   * @param key - ReassignCaseKey
   * @exception AppException
   * @exception InformationalException
   */
  public void sendToNotificationForListOfCases(ReassignCasesForUserKey key,
    StringList strList, boolean isIssueCase)throws AppException,
      InformationalException {

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();
    CaseSearchKey caseSearchKey = new CaseSearchKey();
    StringBuffer strBuf = new StringBuffer();

    // All the case reference will be appended to string buffer to display list
    // of cases in the notification message.
    for (int i = 0; i < strList.size(); i++) {

      caseSearchKey.caseID = Long.parseLong(strList.item(i));

      CaseReference caseReference = caseHeaderObj.readCaseReferenceByCaseID(
        caseSearchKey);

      // BEGIN, CR00085608 SK
      strBuf.append(CuramConst.gkNewLine);
      // END, CR00085608 SK
      strBuf.append(caseReference.caseReference);
    }

    UserAccess userAccessObj = UserAccessFactory.newInstance();
    UsersKey usersKey = new UsersKey();
    SystemUser systemUser = SystemUserFactory.newInstance();

    String loggedInUserName = systemUser.getUserDetails().userName;

    usersKey.userName = loggedInUserName;
    UserFullname userFullname = userAccessObj.getFullName(usersKey);

    LocalisableString communicationSubject;
    LocalisableString communicationText;

    // If reassign is done from case issue page a different message will be
    // displayed. This message explains about issue case
    if (isIssueCase == true) {
      communicationSubject = new LocalisableString(
        BPOSUPERVISORCASE.INF_SUPERVISOR_ASSIGN_ISSUECASE_NOTIFICATION_SUBJECT);
      communicationText = new LocalisableString(
        BPOSUPERVISORCASE.INF_SUPERVISOR_ASSIGN_ISSUECASE_NOTIFICATION_TEXT);
    } else {

      // This message explains about list of cases (It could be users case or
      // cases with issues
      communicationSubject = new LocalisableString(
        BPOSUPERVISORCASE.INF_SUPERVISOR_ASSIGN_CASE_NOTIFICATION_SUBJECT);
      communicationText = new LocalisableString(
        BPOSUPERVISORCASE.INF_SUPERVISOR_ASSIGN_USERCASE_NOTIFICATION_TEXT);
    }

    CTItemKey ctitemKey = new CTItemKey();
    CTItem ctitem = new CTItem();

    // code table variables
    CodeTable codeTableInterface = CodeTableFactory.newInstance();

    ctitemKey.code = CASEUSERROLETYPE.OWNER;
    ctitemKey.locale = TransactionInfo.getProgramLocale();
    ctitemKey.tableName = CASEUSERROLETYPE.TABLENAME;

    // BEGIN, CR00163098, JC
    ctitem = codeTableInterface.getOneItemForUserLocale(ctitemKey);
    // END, CR00163098, JC
    communicationText.arg(ctitem.description);
    communicationText.arg(strBuf);
    communicationText.arg(userFullname.fullname);

    StandardManualTaskDtls stdManualTaskDtls = new StandardManualTaskDtls();

    for (int i = 0; i < strList.size(); i++) {

      stdManualTaskDtls.dtls.concerningDtls.caseID = Long.parseLong(
        strList.item(i));
      // Only one notification would be displayed listing all the select cases
      // followed by notification message
      if (i == 0) {
        // BEGIN, CR00163659, CL
        stdManualTaskDtls.dtls.taskDtls.comments = communicationText.getMessage(
          TransactionInfo.getProgramLocale());
        stdManualTaskDtls.dtls.taskDtls.subject = communicationSubject.getMessage(
          TransactionInfo.getProgramLocale());
        // END, CR00163659
      } else {
        continue;
      }

      Notification notificationObj = NotificationFactory.newInstance();

      notificationObj.createWorkAllocationNotification(stdManualTaskDtls);
    }
  }
}

