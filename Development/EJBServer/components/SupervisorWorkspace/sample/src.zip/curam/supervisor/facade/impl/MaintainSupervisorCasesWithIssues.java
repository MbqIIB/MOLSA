/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * Copyright 2007-2008, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.supervisor.facade.impl;


import curam.core.fact.SystemUserFactory;
import curam.core.intf.SystemUser;
import curam.core.struct.UserNameKey;
import curam.supervisor.facade.struct.CasesByDateRangeKey;
import curam.supervisor.facade.struct.CasesWithIssuesRecievedOnDate;
import curam.supervisor.facade.struct.CasesWithIssuesUICDtlsList;
import curam.supervisor.facade.struct.ReassignCasesForUserKey;
import curam.supervisor.sl.fact.MaintainSupervisorCasesWithIssuesFactory;
import curam.supervisor.sl.fact.SupervisorApplicationPageContextDescriptionFactory;
import curam.supervisor.sl.struct.CasesWithIssuesAndHeatMapDetails;
import curam.supervisor.sl.struct.RegisteredDateOfCasesWithIssues;
import curam.supervisor.sl.struct.SupervisorApplicationPageContextDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Facade layer class having API for operations related to cases having issues.
 *
 */
public abstract class MaintainSupervisorCasesWithIssues extends curam.supervisor.facade.base.MaintainSupervisorCasesWithIssues {

  // _________________________________________________________________________
  /**
   * This method allows supervisor to list the details of cases registered in
   * chosen week that have some issues associated with them.
   *
   * @param key - CasesByDateRangeKey
   * @return CasesWithIssuesUICDtlsList
   * @throws InformationalException
   * @throws AppException
   * @deprecated Since Curam V6.0 SP3, replaced by 
   * {@link #listCasesWithIssue(CasesByDateRangeKey)}.
   * Since this method was accepting a date parameter as a String.
   * See release note: CR00294942.
   */
  @Deprecated 
  public CasesWithIssuesUICDtlsList listCaseWithIssueDetails(
    CasesByDateRangeKey key)
    throws AppException, InformationalException {

    // object creation
    CasesWithIssuesUICDtlsList casesWithIssuesUICDtlsList = new CasesWithIssuesUICDtlsList();
    curam.supervisor.sl.intf.MaintainSupervisorCasesWithIssues maintainSupervisorCasesWithIssues = MaintainSupervisorCasesWithIssuesFactory.newInstance();
    UserNameKey userNameKey = new UserNameKey();
    SystemUser systemUser = SystemUserFactory.newInstance();
   
    // BEGIN CR00107117 ,GM    
    curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // END CR00107117
    
    // call the SL method to list the cases with issues for given date range
    casesWithIssuesUICDtlsList.casesWithIssuesUICDtlsList = maintainSupervisorCasesWithIssues.listCaseWithIssueDetails(
      key.dateRange);

    // get the user name and the page context details for the user
    userNameKey.userName = systemUser.getUserDetails().userName;
    SupervisorApplicationPageContextDetails pageContextDetails = pageContextDescription.readUserNamePageContextDescription(
      userNameKey);

    casesWithIssuesUICDtlsList.pageContextDescription = pageContextDetails;

    return casesWithIssuesUICDtlsList;
  }

  // _________________________________________________________________________
  /**
   * Allows supervisor to list cases with issues registered
   * on a specified date range.
   *
   * @param key - CasesWithIssuesRecievedOnDate
   * @return CasesWithIssuesUICDtlsList
   * @throws InformationalException
   * @throws AppException
   * @deprecated Since Curam V6.0 SP3, replaced by 
   * {@link #listCasesWithIssueByDate(RegisteredDateOfCasesWithIssues)}.
   * Since this method was accepting a date parameter as a String.
   * See release note: CR00294942.
   */
  @Deprecated 
  public CasesWithIssuesUICDtlsList listCaseWithIssueDetailsByDate(
    CasesWithIssuesRecievedOnDate key) throws AppException,
      InformationalException {

    // object creation
    CasesWithIssuesUICDtlsList casesWithIssuesUICDtlsList = new CasesWithIssuesUICDtlsList();
    curam.supervisor.sl.intf.MaintainSupervisorCasesWithIssues maintainSupervisorCasesWithIssues = MaintainSupervisorCasesWithIssuesFactory.newInstance();

    // BEGIN CR00107117 ,GM    
    curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    // END CR00107117
    
    UserNameKey userNameKey = new UserNameKey();
    SystemUser systemUser = SystemUserFactory.newInstance();

    // call the SL method to list the cases with issues for given date range
    casesWithIssuesUICDtlsList.casesWithIssuesUICDtlsList = maintainSupervisorCasesWithIssues.listCaseWithIssueDetailsByDate(
      key.recievedDateDtls);

    // get the user name and the page context details for the user
    userNameKey.userName = systemUser.getUserDetails().userName;
    SupervisorApplicationPageContextDetails pageContextDetails = pageContextDescription.readUserNamePageContextDescription(
      userNameKey);

    casesWithIssuesUICDtlsList.pageContextDescription = pageContextDetails;

    return casesWithIssuesUICDtlsList;
  }

  // _________________________________________________________________________
  /**
   * This method lists a heat map cases and heat map XML String registered on a
   * chosen date, and that have associated issue cases.
   * Also lists the number of issues associated with each case.
   *
   * @param key - CasesWithIssuesRecievedOnDate
   * @return CasesWithIssuesUICDtlsList
   * @throws InformationalException
   * @throws AppException
   * @deprecated Since Curam V6.0 SP3, replaced by 
   * {@link #readCasesWithIssueByDateForHeatMap(RegisteredDateOfCasesWithIssues))}.
   * Since this method was accepting a date parameter as a String.
   * See release note: CR00294942.
   */
  @Deprecated 

  public CasesWithIssuesUICDtlsList readCaseWithIssueDetailsByDateForHeatMap(
    CasesWithIssuesRecievedOnDate key) throws AppException,
      InformationalException {

    // object creation
    curam.supervisor.sl.intf.MaintainSupervisorCasesWithIssues maintainSupervisorCasesWithIssues = MaintainSupervisorCasesWithIssuesFactory.newInstance();
    CasesWithIssuesUICDtlsList casesWithIssuesUICDtlsList = new CasesWithIssuesUICDtlsList();
    UserNameKey userNameKey = new UserNameKey();
    SystemUser systemUser = SystemUserFactory.newInstance();
    
    // BEGIN CR00107117 ,GM    
    curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();

    // END CR00107117
    
    // Calling the SL method to fetch the records and generate Heat Map
    casesWithIssuesUICDtlsList.casesWithIssuesUICDtlsList = maintainSupervisorCasesWithIssues.readCaseWithIssueDetailsByDateForHeatMap(
      key.recievedDateDtls);

    // get the user name and the page context details for the user
    userNameKey.userName = systemUser.getUserDetails().userName;
    SupervisorApplicationPageContextDetails pageContextDetails = pageContextDescription.readUserNamePageContextDescription(
      userNameKey);

    casesWithIssuesUICDtlsList.pageContextDescription = pageContextDetails;

    return casesWithIssuesUICDtlsList;
  }

  // _________________________________________________________________________
  /**
   * This method lists a heat map cases and heat map XML String registered on a
   * chosen week, and that have associated issue cases.
   * Also lists the number of issues associated with each case.
   *
   * @param key - CasesByDateRangeKey
   * @return CasesWithIssuesUICDtlsList
   * @throws InformationalException
   * @throws AppException
   * @deprecated Since Curam V6.0 SP3, replaced by 
   * {@link #readCasesWithIssueForHeatMap(CasesByDateRangeKey)}.
   * Since this method was accepting a date parameter as a String.
   * See release note: CR00294942.
   */
  @Deprecated 
  public CasesWithIssuesUICDtlsList readCaseWithIssueDetailsForHeatMap(
    CasesByDateRangeKey key)
    throws AppException, InformationalException {

    // object creation
    curam.supervisor.sl.intf.MaintainSupervisorCasesWithIssues maintainSupervisorCasesWithIssues = MaintainSupervisorCasesWithIssuesFactory.newInstance();
    
    // BEGIN CR00107117 ,GM
    curam.supervisor.sl.intf.SupervisorApplicationPageContextDescription pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance();
    // END CR00107117
    
    CasesWithIssuesUICDtlsList casesWithIssuesUICDtlsList = new CasesWithIssuesUICDtlsList();
    UserNameKey userNameKey = new UserNameKey();
    SystemUser systemUser = SystemUserFactory.newInstance();

    // Calling the SL method to fetch the records and generate Heat Map
    casesWithIssuesUICDtlsList.casesWithIssuesUICDtlsList = maintainSupervisorCasesWithIssues.readCaseWithIssueDetailsForHeatMap(
      key.dateRange);

    // get the user name and the page context details for the user
    userNameKey.userName = systemUser.getUserDetails().userName;
    SupervisorApplicationPageContextDetails pageContextDetails = pageContextDescription.readUserNamePageContextDescription(
      userNameKey);

    casesWithIssuesUICDtlsList.pageContextDescription = pageContextDetails;

    return casesWithIssuesUICDtlsList;
  }

  // _________________________________________________________________________

  /**
   * This method allows the supervisor to reassign some or all cases that have
   * issues and that were registered in the supervisor's chosen week
   * to another user
   *
   * @param key - ReassignCasesForUserKey
   * @throws InformationalException
   * @throws AppException
   */
  public void reassignCasesWithIssues(ReassignCasesForUserKey key)
    throws AppException, InformationalException {

    // object creation
    curam.supervisor.sl.intf.MaintainSupervisorCasesWithIssues maintainSupervisorCasesWithIssues = MaintainSupervisorCasesWithIssuesFactory.newInstance();

    // calling service layer method to reassign cases with issues.
    maintainSupervisorCasesWithIssues.reassignCasesWithIssues(key.userKey);
  }
  
  // BEGIN, CR00294942, AKr
  /**
   * Reads the details of cases with issues based on the date passed in.
   *
   * @param registeredDateOfCasesWithIssues 
   * The date range to search the cases by their registration date. 
   *
   * @return CasesWithIssuesAndHeatMapDetails  
   * The details of the cases with issues and the constructed heat map 
   * XML string. 
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  public CasesWithIssuesAndHeatMapDetails listCasesWithIssuesByDate(
    final RegisteredDateOfCasesWithIssues registeredDateOfCasesWithIssues)
    throws AppException, InformationalException {
  
    final CasesWithIssuesAndHeatMapDetails casesWithIssuesAndHeatMapDetails = MaintainSupervisorCasesWithIssuesFactory.newInstance().listCasesWithIssuesByDate(
      registeredDateOfCasesWithIssues);
    
    updatePageContextDescription(casesWithIssuesAndHeatMapDetails);
    return casesWithIssuesAndHeatMapDetails;
  
  }

  /**
   * Reads the details of cases with issues .
   *
   * @param registeredDateOfCasesWithIssues 
   * The date range to search the cases by their registration date. 
   *
   * @return CasesWithIssuesAndHeatMapDetails  
   * The details of the cases with issues and the constructed heat map 
   * XML string. 
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  public CasesWithIssuesAndHeatMapDetails listCasesWithIssues(
    final CasesByDateRangeKey casesByDateRangeKey)
    throws AppException, InformationalException {

    final CasesWithIssuesAndHeatMapDetails casesWithIssuesAndHeatMapDetails = MaintainSupervisorCasesWithIssuesFactory.newInstance().listCasesWithIssues(
      casesByDateRangeKey.dateRange);
    
    updatePageContextDescription(casesWithIssuesAndHeatMapDetails);
    return casesWithIssuesAndHeatMapDetails;
  }

  /**
   * Reads the details of cases with issues for constructing the heat map. 
   *
   * @param registeredDateOfCasesWithIssues 
   * The date range to search the cases by their registration date. 
   *
   * @return CasesWithIssuesAndHeatMapDetails  
   * The details of the cases with issues and the constructed heat map 
   * XML string. 
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  public CasesWithIssuesAndHeatMapDetails readCasesWithIssuesByDateForHeatMap(
    final RegisteredDateOfCasesWithIssues registeredDateOfCasesWithIssues)
    throws AppException, InformationalException {

    final CasesWithIssuesAndHeatMapDetails casesWithIssuesAndHeatMapDetails = MaintainSupervisorCasesWithIssuesFactory.newInstance().listCasesWithIssuesByDate(
      registeredDateOfCasesWithIssues);
    curam.supervisor.sl.struct.CasesWithIssuesUICDtlsList casesWithIssuesUICDtlsList = new curam.supervisor.sl.struct.CasesWithIssuesUICDtlsList();
    
    casesWithIssuesUICDtlsList.casesWithIssuesDtlsList.casesWithIssueDetails = casesWithIssuesAndHeatMapDetails.casesListAndHeatMap.casesWithIssueDetails;
    casesWithIssuesAndHeatMapDetails.casesListAndHeatMap.heatMapXMLString = MaintainSupervisorCasesWithIssuesFactory.newInstance().readCasesWithIssuesForHeatMap(
      casesWithIssuesUICDtlsList);

    updatePageContextDescription(casesWithIssuesAndHeatMapDetails);
    return casesWithIssuesAndHeatMapDetails;
  }

  /**
   * Reads the details of cases with issues for constructing the heat map. 
   *
   * @param registeredDateOfCasesWithIssues 
   * The date range to search the cases by their registration date. 
   *
   * @return CasesWithIssuesAndHeatMapDetails  
   * The details of the cases with issues and the constructed heat map 
   * XML string. 
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  public CasesWithIssuesAndHeatMapDetails readCasesWithIssuesForHeatMap(
    final CasesByDateRangeKey casesByDateRangeKey)
    throws AppException, InformationalException {

    final CasesWithIssuesAndHeatMapDetails casesWithIssuesAndHeatMapDetails = MaintainSupervisorCasesWithIssuesFactory.newInstance().listCasesWithIssues(
      casesByDateRangeKey.dateRange);
    curam.supervisor.sl.struct.CasesWithIssuesUICDtlsList casesWithIssuesUICDtlsList = new curam.supervisor.sl.struct.CasesWithIssuesUICDtlsList();

    casesWithIssuesUICDtlsList.casesWithIssuesDtlsList.casesWithIssueDetails = casesWithIssuesAndHeatMapDetails.casesListAndHeatMap.casesWithIssueDetails;

    casesWithIssuesAndHeatMapDetails.casesListAndHeatMap.heatMapXMLString = MaintainSupervisorCasesWithIssuesFactory.newInstance().readCasesWithIssuesForHeatMap(
      casesWithIssuesUICDtlsList);

    updatePageContextDescription(casesWithIssuesAndHeatMapDetails);
    return casesWithIssuesAndHeatMapDetails;
  }
  
  /**
   * Adds the page context description to the passed in object.
   *
   * @param caseswithIssuesHeatMapDetails 
   * The object to which the page context description has to be added. 
   *
   * @return CasesWithIssuesAndHeatMapDetails  
   * The passed in object with the page context description added. 
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  protected void updatePageContextDescription(
    final CasesWithIssuesAndHeatMapDetails caseswithIssuesHeatMapDetails)
    throws AppException, InformationalException {
  
    final UserNameKey userNameKey = new UserNameKey();

    userNameKey.userName = SystemUserFactory.newInstance().getUserDetails().userName;
    caseswithIssuesHeatMapDetails.pageContextDescription = SupervisorApplicationPageContextDescriptionFactory.newInstance().readUserNamePageContextDescription(
      userNameKey);
    
  }
  // END, CR00294942
}
