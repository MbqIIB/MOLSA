/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/**
 * Copyright 2008-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.supervisor.sl.impl;


import curam.codetable.CASESTATUS;
import curam.codetable.ORGOBJECTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.intf.Users;
import curam.core.sl.entity.struct.SupervisorOrgUnitDetails;
import curam.core.sl.entity.struct.SupervisorOrgUnitDetailsList;
import curam.core.struct.EndDateAndAssignTaskTo;
import curam.core.struct.SearchSupervisorCaseDetails;
import curam.core.struct.SearchSupervisorCaseDetailsList;
import curam.core.struct.UserNameKey;
import curam.supervisor.sl.fact.MaintainSupervisorOrgUnitsFactory;
import curam.supervisor.sl.intf.MaintainSupervisorOrgUnits;
import curam.supervisor.sl.struct.OrgObjectCaseSearchKey;
import curam.supervisor.sl.struct.SupervisorOrganisationUnitDetails;
import curam.util.dataaccess.CuramValueList;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.UniqueIDUtil;
import curam.util.transaction.Resources;
import curam.util.type.Date;


/**
 * This process class implements case search functionality for supervisor
 * user.
 */
public class CaseSearch extends curam.supervisor.sl.base.CaseSearch {

  // BEGIN, CR00104524, ELG
  // ___________________________________________________________________________
  /**
   * Retrieves list of cases based on organization object, supervisor, case
   * and product details specified.
   *
   * @param key Contains organization object, case, product details for case
   * searching.
   * @return List of supervisor case details structures.
   */
  public SearchSupervisorCaseDetailsList searchCases(
    OrgObjectCaseSearchKey key) throws AppException, InformationalException {

    // return list
    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();

    // string buffer to hold SQL
    StringBuffer sBuf = new StringBuffer();

    // search key local copy
    OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    orgObjectCaseSearchKey.assign(key);
    // BEGIN, CR00121986, ELG
    orgObjectCaseSearchKey.recordStatusCancelled = RECORDSTATUS.CANCELLED;
    // END, CR00121986

    MaintainSupervisorOrgUnits maintainSupervisorOrgUnitsObj = MaintainSupervisorOrgUnitsFactory.newInstance();

    // retrieve organization units for supervisor
    SupervisorOrganisationUnitDetails supervisorOrganisationUnitDetails = maintainSupervisorOrgUnitsObj.listSupervisorOrgUnits();

    // build SQL set from the organization unit list
    String orgUnits = getOrgUnitSet(
      supervisorOrganisationUnitDetails.orgUnitDetails);

    // selection part
    // BEGIN, CR00232351, ZV
    sBuf.append("SELECT distinct ch.caseID, ch.caseReference, ch.statusCode,");
    sBuf.append(" cr.concernRoleName, ch.startDate, pd.productType, ");
    sBuf.append(" ch.caseTypeCode");

    // into part
    sBuf.append(" INTO :caseID, :caseReference, :status, :primaryClient,");
    sBuf.append(" :startDate, :productType, :caseTypeCode ");
    // END, CR00232351

    // from part
    sBuf.append(" FROM ConcernRole cr, OrgObjectLink cool, CaseUserRole cur,");
    sBuf.append(" CaseHeader ch LEFT OUTER JOIN ProductDelivery pd");
    sBuf.append(" ON pd.caseID = ch.caseID ");

    // variable where condition part
    // if case status was not supplied the search will be performed
    // for all non-closed cases
    if (key.caseStatus.length() == 0) {

      orgObjectCaseSearchKey.caseStatus = CASESTATUS.CLOSED;

      sBuf.append(" WHERE ch.statusCode <> :caseStatus");

      // else search will be performed based on the case status supplied
    } else {

      sBuf.append(" WHERE ch.statusCode = :caseStatus");

    }

    if (key.caseType.length() > 0) {
      sBuf.append(" AND ch.caseTypeCode = :caseType");
    }

    if (key.productType.length() > 0) {
      sBuf.append(" AND pd.productType = :productType");
    }
    // end of variable where condition part

    sBuf.append(" AND cr.concernRoleID = ch.concernRoleID");
    sBuf.append(" AND ch.ownerOrgObjectLinkID = cool.orgObjectLinkID");
    sBuf.append(" AND cool.orgObjectLinkID = cur.orgObjectLinkID");
    sBuf.append(" AND cool.orgObjectType = :organisationObject ");

    if (key.organisationObject.equals(ORGOBJECTTYPE.POSITION)) {

      //
      // position part
      //
      sBuf.append(" AND (cool.orgObjectReference IN (");
      sBuf.append(getPositionSQL(orgUnits));
      sBuf.append("))");

    } else if (key.organisationObject.equals(ORGOBJECTTYPE.ORGUNIT)) {

      //
      // organization unit part
      //
      sBuf.append(" AND (cool.orgObjectReference IN (");
      sBuf.append(getOrgUnitSQL(orgUnits));
      sBuf.append("))");

    } else if (key.organisationObject.equals(ORGOBJECTTYPE.WORKQUEUE)) {

      //
      // work queue part
      //
      sBuf.append(" AND (cool.orgObjectReference IN (");
      sBuf.append(getWorkQueueSQL(orgUnits));
      sBuf.append("))");

    } else {

      //
      // user part
      //
      // BEGIN, CR00121986, ELG
      Users usersObj = UsersFactory.newInstance();
      UserNameKey userNameKey = new UserNameKey();

      userNameKey.userName = key.assignedTo;
      // BEGIN, CR00321607, DJ
      EndDateAndAssignTaskTo endDateAndAssignTaskTo = new EndDateAndAssignTaskTo();
      boolean searchForClosedUserInd = false;

      if (0 != userNameKey.userName.length()) {
        endDateAndAssignTaskTo = usersObj.readEndDateAndAssignTaskTo(
          userNameKey);
      } else {
        searchForClosedUserInd = false;
        // END, CR00321607
        if (!endDateAndAssignTaskTo.endDate.isZero()) {

          Date currentDate = Date.getCurrentDate();

          if (endDateAndAssignTaskTo.endDate.equals(currentDate)
            || endDateAndAssignTaskTo.endDate.before(currentDate)) {
            searchForClosedUserInd = true;
          }

        }
      }

      sBuf.append(" AND (cool.userName IN (");
      sBuf.append(getUserSQL(orgUnits, searchForClosedUserInd));
      // END, CR00121986
      sBuf.append("))");

    }

    // ordering part
    sBuf.append(" ORDER BY pd.productType ASC");

    // Call dynamic SQL API to execute SQL
    CuramValueList curamValueList = curam.util.dataaccess.DynamicDataAccess.executeNsMulti(
      curam.core.struct.SearchSupervisorCaseDetails.class,
      orgObjectCaseSearchKey, false, sBuf.toString());

    int listSize = curamValueList.size();

    searchCaseDetailsList.dtls.ensureCapacity(listSize);

    // Add the search results to the return list
    for (int i = 0; i < listSize; i++) {

      searchCaseDetailsList.dtls.addRef(
        (SearchSupervisorCaseDetails) curamValueList.get(i));

    }

    return searchCaseDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * Builds SQL set of organization unit ID's
   *
   * @param listDetails Contains list of supervisor organization unit details.
   * @return String containing SQL set of organization unit ID's.
   */
  protected String getOrgUnitSet(SupervisorOrgUnitDetailsList listDetails) {

    // string buffer to hold SQL
    StringBuffer sBuf = new StringBuffer();

    int listSize = listDetails.dtls.size();

    // BEGIN, CR00140605, CW
    // Return an empty string if there are no organization units
    if (listSize == 0) {
      return CuramConst.gkEmpty;
    }
    // END, CR00140605

    // reference structure
    SupervisorOrgUnitDetails supervisorOrgUnitDetails;

    sBuf.append("(");

    for (int i = 0; i < listSize; i++) {

      supervisorOrgUnitDetails = listDetails.dtls.item(i);
      
      // BEGIN, CR00348376, IBM
      if (Resources.runningAgainstDB2OnZOS()) {
        sBuf.append(
          UniqueIDUtil.longToString(supervisorOrgUnitDetails.orgUnitID));
      } else {
        sBuf.append(new Long(supervisorOrgUnitDetails.orgUnitID).toString());
      }
      // END, CR00348376
      
      if (i != (listSize - 1)) {
        sBuf.append(",");
      }

    }

    sBuf.append(")");

    return sBuf.toString();

  }

  // ___________________________________________________________________________
  /**
   * Builds Position selection SQL part.
   *
   * @param orgUnits Contains organization unit set.
   * @return String containing Position selection SQL statement.
   */
  protected String getPositionSQL(String orgUnits) {

    // string buffer to hold SQL
    StringBuffer sBuf = new StringBuffer();

    //
    // Selects
    // active position with the reference specified
    // and belonging to the organization unit list
    // which is supervised by the supervisor,
    // or the position which reports to the supervisor.
    //

    // construct position selection SQL
    sBuf.append(" SELECT pos.positionID");
    sBuf.append(" FROM OrgUnitPositionLink ouposlink, Position pos ");

    sBuf.append(" WHERE ouposlink.positionID = pos.positionID");
    sBuf.append(" AND ouposlink.recordStatus <> :recordStatus");
    sBuf.append(" AND pos.positionID = :objectReference");
    // BEGIN, CR00140605, CW
    // Append the Organization Unit string if there are valid Organization Units
    if (orgUnits.trim().length() > 0) {
      sBuf.append(" AND ouposlink.organisationUnitID IN ");
      sBuf.append(orgUnits);
    }
    // END, CR00140605

    sBuf.append(" UNION ");

    // position reporting part
    sBuf.append(getPositionReportingSQL());

    return sBuf.toString();

  }

  // ___________________________________________________________________________
  /**
   * Builds Position reporting selection SQL part.
   *
   * @return String containing Position reporting selection SQL statement.
   */
  protected String getPositionReportingSQL() {

    // string buffer to hold SQL
    StringBuffer sBuf = new StringBuffer();

    //
    // Selects positions which report
    // to the supervisor.
    //

    sBuf.append(" SELECT prl.positionID");
    sBuf.append(" FROM PositionReportingLink prl, PositionHolderLink phl2,");
    sBuf.append(" Position pos2");
    sBuf.append(" WHERE phl2.positionID = prl.reportsToID");
    sBuf.append(" AND phl2.positionID = pos2.positionID");
    sBuf.append(" AND pos2.leadPositionInd = '1'");
    sBuf.append(" AND phl2.userName = :supervisorUserName");
    sBuf.append(" AND phl2.recordStatus <> :recordStatus");
    sBuf.append(" AND prl.recordStatus <> :recordStatus");

    return sBuf.toString();

  }

  // ___________________________________________________________________________
  /**
   * Builds Organization Unit selection SQL part.
   *
   * @param orgUnits Contains organization unit set.
   * @return String containing Organization Unit selection SQL statement.
   */
  protected String getOrgUnitSQL(String orgUnits) {

    // string buffer to hold SQL
    StringBuffer sBuf = new StringBuffer();

    //
    // Selects
    // active organization unit which has the reference specified
    // and belongs to the organization unit list
    // which is supervised by the supervisor.
    //
    sBuf.append("SELECT ou.organisationUnitID");
    sBuf.append(" FROM OrganisationUnit ou");
    sBuf.append(" WHERE ou.organisationUnitID = :objectReference");
    sBuf.append(" AND ou.recordStatus <> :recordStatus");

    // BEGIN, CR00140605, CW
    // Append the Organization Unit string if there are valid Organization Units
    if (orgUnits.trim().length() > 0) {
      sBuf.append(" AND ou.organisationUnitID IN ");
      sBuf.append(orgUnits);
    }
    // END, CR00140605

    return sBuf.toString();

  }

  // ___________________________________________________________________________
  /**
   * Builds Work Queue selection SQL part.
   *
   * @param orgUnits Contains organization unit set.
   * @return String containing Work Queue selection SQL statement.
   */
  protected String getWorkQueueSQL(String orgUnits) {

    // string buffer to hold SQL
    StringBuffer sBuf = new StringBuffer();

    //
    // Selects work queue with the reference specified
    // or subscribed by the user holding position in any of the
    // organization units supervised by the supervisor.
    //

    // work queue part
    sBuf.append(" SELECT wq.workQueueID");
    sBuf.append(" FROM WorkQueue wq");
    sBuf.append(" WHERE wq.workQueueID = :objectReference");
    sBuf.append(" OR ( wq.workQueueID IN (");

    sBuf.append("SELECT wqs.workQueueID");
    sBuf.append(" FROM WorkQueueSubscription wqs");
    sBuf.append(" WHERE wqs.userName IN (");

    // users sub-query
    sBuf.append(" SELECT Users.userName");
    sBuf.append(" FROM Position, PositionHolderLink, OrganisationUnit,");
    sBuf.append(" OrgUnitPositionLink, Users");

    sBuf.append(" WHERE Position.positionID = PositionHolderLink.positionID");
    sBuf.append(
      " AND OrgUnitPositionLink.positionID = PositionHolderLink.positionID");
    sBuf.append(
      " AND OrgUnitPositionLink.organisationUnitID = OrganisationUnit.organisationUnitID");
    sBuf.append(" AND PositionHolderLink.userName = Users.userName");
    sBuf.append(" AND PositionHolderLink.recordStatus <> :recordStatus");
    sBuf.append(" AND OrgUnitPositionLink.recordStatus <> :recordStatus");
    sBuf.append(" AND Position.recordStatus <> :recordStatus");
    sBuf.append(" AND Position.positionID IN (");
    sBuf.append(" SELECT OrgUnitPositionLink.positionID");
    sBuf.append(" FROM OrgUnitPositionLink");
    sBuf.append(" WHERE OrgUnitPositionLink.recordStatus <> :recordStatus");

    // BEGIN, CR00140605, CW
    // Append the Organization Unit string if there are valid Organization Units
    if (orgUnits.trim().length() > 0) {
      sBuf.append(" AND OrgUnitPositionLink.organisationUnitID IN ");
      sBuf.append(orgUnits);
    }
    // END, CR00140605

    sBuf.append(" UNION ");

    sBuf.append(getPositionReportingSQL());

    sBuf.append("))))");

    return sBuf.toString();

  }

  // ___________________________________________________________________________
  /**
   * Builds User selection SQL part.
   *
   * @param orgUnits Contains organization unit set.
   * @param searchForClosedUserInd Flag indicating should constructed SQL
   * include conditions to search for closed users. If it is set to true,
   * then condition for closed users is included in the constructed SQL
   * statement.
   * @return String containing User selection SQL statement.
   */
  // BEGIN, CR00121986, ELG
  protected String getUserSQL(String orgUnits, boolean searchForClosedUserInd) {
    // END, CR00121986

    // string buffer to hold SQL
    StringBuffer sBuf = new StringBuffer();

    //
    // Selects the user with the user name
    // specified and holding a position within any of the organization units
    // supervised by the supervisor.
    //

    sBuf.append("SELECT Users.userName");
    sBuf.append(" FROM Position, PositionHolderLink, Users");
    sBuf.append(" WHERE Position.positionID = PositionHolderLink.positionID");
    sBuf.append(" AND PositionHolderLink.userName = Users.userName");
    sBuf.append(" AND Users.userName = :assignedTo");
    // BEGIN, CR00121986, ELG
    if (searchForClosedUserInd) {
      sBuf.append(
        " AND PositionHolderLink.recordStatus = :recordStatusCancelled");
    } else {
      sBuf.append(" AND PositionHolderLink.recordStatus <> :recordStatus");
    }
    // END, CR00121986

    sBuf.append(" AND Position.recordStatus <> :recordStatus");
    sBuf.append(" AND Position.positionID IN (");

    sBuf.append("SELECT OrgUnitPositionLink.positionID");
    sBuf.append(" FROM OrgUnitPositionLink");
    sBuf.append(" WHERE OrgUnitPositionLink.recordStatus <> :recordStatus");

    // BEGIN, CR00140605, CW
    // Append the Organization Unit string if there are valid Organization Units
    if (orgUnits.trim().length() > 0) {
      sBuf.append(" AND OrgUnitPositionLink.organisationUnitID IN ");
      sBuf.append(orgUnits);
    }
    // END, CR00140605

    sBuf.append(" UNION ");

    sBuf.append(getPositionReportingSQL());
    sBuf.append(")");

    return sBuf.toString();

  }
  // END, CR00104524

}
