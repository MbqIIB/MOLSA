/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * Copyright (c) 2002-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.supervisor.facade.impl;


import java.util.HashSet;
import java.util.Set;

import curam.codetable.TARGETITEMTYPE;
import curam.core.facade.struct.TaskManagementTaskKey;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.EnvVars;
import curam.core.impl.SecurityImplementationFactory;
import curam.core.intf.SystemUser;
import curam.core.sl.entity.fact.TaskAssignmentFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.TaskAssignment;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.TaskAssignmentNameDetailsList;
import curam.core.sl.entity.struct.TaskIDRelatedIDAndTypeKey;
import curam.core.sl.entity.struct.WorkQueueDtls;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.struct.SupervisorUsers;
import curam.core.struct.SupervisorUsersList;
import curam.core.struct.UserAndStatusKey;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOSUPERVISORUSER;
import curam.message.SEPARATOR;
import curam.supervisor.facade.struct.DeferTaskDetails;
import curam.supervisor.facade.struct.ForwardTaskDetails;
import curam.supervisor.facade.struct.ReallocateTaskDetails;
import curam.supervisor.facade.struct.ReserveTaskDetailsForUser;
import curam.supervisor.facade.struct.RestartTaskDetails;
import curam.supervisor.facade.struct.SupervisorUsersListDetails;
import curam.supervisor.facade.struct.TaskIDKey;
import curam.supervisor.facade.struct.UnreserveTaskDetails;
import curam.supervisor.facade.struct.ViewTaskDetails;
import curam.supervisor.sl.fact.MaintainSupervisorTasksFactory;
import curam.supervisor.sl.impl.SupervisorConst;
import curam.supervisor.sl.struct.SupervisorApplicationPageContextDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;
import curam.util.transaction.TransactionInfo;
import curam.util.workflow.impl.LocalizableStringResolver;
import curam.util.workflow.struct.TaskKey;


/**
 * This class provides the functionality for the Supervisor Task Management
 *
 */

public abstract class MaintainSupervisorTasks extends curam.supervisor.facade.base.MaintainSupervisorTasks {

  // BEGIN, CR00222190, ELG
  /**
   * @deprecated Since Curam 5.2 SP4, replaced by
   * {@link SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(TransactionInfo.getProgramLocale())}.
   * Constant for the separator used in the context description.
   * Replacement reason - static variables/constants cannot reference
   * TransactionInfo.getProgramLocale(). See release note <CR00219408>.
   */
  @Deprecated
  protected static final String kSeparator = // BEGIN, CR00163471, JC
    SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText();
  // END, CR00163471, JC
  // END, CR00222190

  // ___________________________________________________________________________
  /**
   * This method allows the supervisor to close only tasks entered by a user.
   * This means that all actions related to the task will be deemed completed.
   * System created tasks may not be closed in this manner. System created tasks
   * is closed automatically by the system after the action associated with the
   * task has been undertaken.
   *
   * @param key - TaskManagementTaskKey -  to be closed
   * @throws InformationalException
   * @throws AppException
   */
  public void closeTask(TaskManagementTaskKey key) throws AppException,
      InformationalException {

    curam.supervisor.sl.intf.MaintainSupervisorTasks maintainSupervisorTasks = MaintainSupervisorTasksFactory.newInstance();

    // Call the service layer closeTask
    maintainSupervisorTasks.closeTask(key.taskKey);
  }

  /**
   * This method allows the supervisor to view the details of the selected task
   *
   * @param key - TaskManagementTaskKey
   * @return ViewTaskDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ViewTaskDetails viewTaskDetails(TaskManagementTaskKey key)
    throws AppException, InformationalException {

    curam.supervisor.sl.intf.MaintainSupervisorTasks maintainSupervisorTasks = MaintainSupervisorTasksFactory.newInstance();

    ViewTaskDetails viewTaskDetails = new ViewTaskDetails();

    // Call the service layer viewDetails
    viewTaskDetails.taskDetails = maintainSupervisorTasks.viewTaskDetails(
      key.taskKey);

    // Create the page title, and set as page context description
    StringBuffer contextDescription = new StringBuffer();

    contextDescription.append(viewTaskDetails.taskDetails.taskID);
    // BEGIN, CR00222190, ELG
    contextDescription.append(
      SEPARATOR.INF_SEPARATOR_CONTEXT_DESCRIPTION.getMessageText(
        TransactionInfo.getProgramLocale()));
    // END, CR00222190
    contextDescription.append(viewTaskDetails.taskDetails.subject);
    SupervisorApplicationPageContextDetails pageContextDetails = new SupervisorApplicationPageContextDetails();

    pageContextDetails.description = contextDescription.toString();
    viewTaskDetails.pageContextDescription = pageContextDetails;

    // Call the service layer for the history text
    viewTaskDetails.historyTextDetails = maintainSupervisorTasks.viewHistoryText(
      key.taskKey);

    return viewTaskDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method returns context description of a specified task.
   *
   * @param taskKey - TaskManagementTaskKey The unique identifier of the task
   *
   * @return SupervisorApplicationPageContextDetails
   * @throws InformationalException
   * @throws AppException
   */
  public SupervisorApplicationPageContextDetails readContextDescription(
    TaskManagementTaskKey taskKey) throws AppException,
      InformationalException {

    // Create return object
    SupervisorApplicationPageContextDetails supervisorApplicationPageContextDetails = new SupervisorApplicationPageContextDetails();

    // Workflow task key
    TaskKey readTaskKey = new TaskKey();

    readTaskKey.taskID = taskKey.taskKey.taskID;

    // Register the security implementation
    SecurityImplementationFactory.register();

    StringBuffer contextDescription = new StringBuffer();

    contextDescription.append(
      LocalizableStringResolver.getTaskStringResolver().getActivityNameForTask(
        readTaskKey));

    contextDescription.append(SupervisorConst.kSeparator);
    contextDescription.append(taskKey.taskKey.taskID);

    supervisorApplicationPageContextDetails.description = contextDescription.toString();
    return supervisorApplicationPageContextDetails;

  }

  // ___________________________________________________________________________
  /**
   * This method allows the supervisor to defer a specified reserved task.
   * The deferred task will still be reserved to the user.
   *
   * @param details -  DeferTaskDetails details of the task to be deferred
   * @throws InformationalException
   * @throws AppException
   */
  public void deferTask(DeferTaskDetails details) throws AppException,
      InformationalException {

    curam.supervisor.sl.intf.MaintainSupervisorTasks maintainSupervisorTasks = MaintainSupervisorTasksFactory.newInstance();

    maintainSupervisorTasks.deferTask(details.details);

  }

  // ___________________________________________________________________________
  /**
   * This method allows the supervisor to forward a task to a job, position,
   * organization unit, user, work-queue or allocation target. This un-reserves
   * the task therefore making the task available to any user to whom the task
   * is now assigned.
   *
   * @param details - ForwardTaskDetails  details of the task to be forwarded
   * @throws InformationalException
   * @throws AppException
   */
  public void forwardTask(ForwardTaskDetails details)
    throws AppException, InformationalException {

    // Task Management service layer object
    curam.supervisor.sl.intf.MaintainSupervisorTasks taskManagementObj = MaintainSupervisorTasksFactory.newInstance();

    // Forward the task
    taskManagementObj.forwardTask(details.taskDetails);
  }

  // ___________________________________________________________________________
  /**
   * This reallocateTask method allows to reallocate a task. Reallocation of a
   * task invokes the tasks initial allocation strategy. This results in the
   * task being reassigned to the item (group of users or work queue) to which
   * it was originally assigned.
   *
   * @param details - ReallocateTaskDetails details of the task to be reallocated
   * @throws InformationalException
   * @throws AppException
   */
  public void reallocateTask(ReallocateTaskDetails details)
    throws AppException, InformationalException {

    // Create MaintainSupervisorTasks object
    curam.supervisor.sl.intf.MaintainSupervisorTasks maintainSupervisorTasks = MaintainSupervisorTasksFactory.newInstance();

    maintainSupervisorTasks.reallocateTask(details.taskDetails);

  }

  // ___________________________________________________________________________
  /**
   * This method allows the supervisor to restart a task manually. Also check
   * task for deferred and reserved before restart.
   *
   * @param details -  RestartTaskDetails details of the task to be restarted
   * @throws InformationalException
   * @throws AppException
   */
  public void restartTask(RestartTaskDetails details) throws AppException,
      InformationalException {

    curam.supervisor.sl.intf.MaintainSupervisorTasks maintainSupervisorTasks = MaintainSupervisorTasksFactory.newInstance();

    maintainSupervisorTasks.restartTask(details.details);

  }

  // ___________________________________________________________________________
  /**
   * This unreserveTask method allows to un-reserve a task. A task can be
   * un-reserved if the task is currently reserved by the current user. Once a
   * task is un-reserved it is once again available to the user, organization
   * unit, position, job, allocation target or work queue to which it was
   * previously assigned. The task is available again for reservation.
   *
   * @param details - UnreserveTaskDetails details of the task to be unreserved
   * @throws InformationalException
   * @throws AppException
   */
  public void unreserveTask(UnreserveTaskDetails details) throws AppException,
      InformationalException {
    curam.supervisor.sl.intf.MaintainSupervisorTasks maintainSupervisorTasks = MaintainSupervisorTasksFactory.newInstance();

    maintainSupervisorTasks.unreserveTask(details.unreserveTaskDetails);

  }

  // ___________________________________________________________________________
  /**
   * This method allows the supervisor to list all the users managed by
   * supervisor.
   *
   * @param key - TaskIDKey
   * @return SupervisorUsersListDetails
   * @throws InformationalException
   * @throws AppException
   */
  public SupervisorUsersListDetails listSupervisorUsers(TaskIDKey key)
    throws AppException, InformationalException {

    // Create Users Object
    curam.core.intf.Users usersObj = UsersFactory.newInstance();

    // BEGIN, CR00161962, BK
    TaskAssignmentNameDetailsList taskAssignmentNameDetailsList = new TaskAssignmentNameDetailsList();

    TaskIDRelatedIDAndTypeKey taskIDRelatedIDAndTypeKey = new TaskIDRelatedIDAndTypeKey();

    // Create TaskAssignment object
    TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();

    taskIDRelatedIDAndTypeKey.taskID = key.taskID;
    taskIDRelatedIDAndTypeKey.assigneeType = TARGETITEMTYPE.WORKQUEUE;
    taskAssignmentNameDetailsList = taskAssignmentObj.searchWQAssignmentsWithNamesByTaskID(
      taskIDRelatedIDAndTypeKey);
    // END, CR00161962

    WorkQueue workQueue = WorkQueueFactory.newInstance();
    WorkQueueKey workQueueKey = new WorkQueueKey();
    UsersKey usersKey = new UsersKey();
    SystemUser systemUser = SystemUserFactory.newInstance();
    String supervisorUserName = systemUser.getUserDetails().userName;

    // BEGIN, CR00161962, BK
    for (int i = 0; i < taskAssignmentNameDetailsList.dtls.size(); i++) {

      workQueueKey.workQueueID = taskAssignmentNameDetailsList.dtls.item(i).relatedID;
      WorkQueueDtls workQueueDtls = workQueue.read(workQueueKey);

      // END, CR00161962

      if (!workQueueDtls.administratorUserName.equals(supervisorUserName)) {

        usersKey.userName = supervisorUserName;

        UsersDtls usersDtls = usersObj.read(usersKey);
        int supervisorSensitivity = Integer.parseInt(usersDtls.sensitivity);
        int workQueueSensitivity = Integer.parseInt(workQueueDtls.sensitivity);

        // If Work queue sensitivity more than supervisor sensitivity throw exception
        if (workQueueSensitivity > supervisorSensitivity) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOSUPERVISORUSER.SUPERVISOR_RESERVE_WORKQUEUE_TASKS_FOR_USER_SENSITIVITY_MISMATCH),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
        // If subscriptions are not allowed to the work queue
        if (!workQueueDtls.allowUserSubscriptionInd) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOSUPERVISORUSER.SUPERVISOR_RESERVE_WORKQUEUE_TASKS_FOR_USER_NO_ALLOW_SUBSCRIPTION_INDICATOR),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }
      }
    }
    SupervisorUsersListDetails supervisorUsersListDetails = new SupervisorUsersListDetails();
    UserAndStatusKey userAndStatusKey = new UserAndStatusKey();

    // set the logged in username and the status to the UserCaseTaskStatus object

    userAndStatusKey.userName = systemUser.getUserDetails().userName;
    userAndStatusKey.status = curam.codetable.RECORDSTATUS.CANCELLED;
    // userCaseTaskStatus.taskStatus = TASKCHANGETYPE.RESERVED;

    String orgUnitSelectDefault = EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT_DEFAULT;
    String orgUnitSelectOption = Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT);

    // BEGIN, CR00161962, BK
    SupervisorUsersList tempSupervisorUsersList = null;
    SupervisorUsersList tempUniqueSupervisorUsersList = new SupervisorUsersList();
    Set<String> tempUniqueUserNameSet = new HashSet<String>();

    if (!orgUnitSelectDefault.equals(orgUnitSelectOption)) {
      tempSupervisorUsersList = usersObj.searchUserNameFullNameBySupervisorIDLeadPos(
        userAndStatusKey);
    } else {
      tempSupervisorUsersList = usersObj.searchUsernameAndFullnameBySupervisorID(
        userAndStatusKey);
    }
    // Remove duplicates
    for (int i = 0; i < tempSupervisorUsersList.dtls.size(); i++) {
      SupervisorUsers user = tempSupervisorUsersList.dtls.item(i);

      if (tempUniqueUserNameSet.add(user.userName)) {
        tempUniqueSupervisorUsersList.dtls.addRef(user);
      }
    }
    supervisorUsersListDetails.usersList = tempUniqueSupervisorUsersList;
    // END, CR00161962
    SupervisorApplicationPageContextDetails supervisorApplicationPageContextDetails = new SupervisorApplicationPageContextDetails();

    TaskManagementTaskKey taskManagementTaskKey = new TaskManagementTaskKey();

    taskManagementTaskKey.taskKey.taskID = key.taskID;
    supervisorApplicationPageContextDetails.description = readContextDescription(taskManagementTaskKey).description;
    supervisorUsersListDetails.pageContext = supervisorApplicationPageContextDetails;
    return supervisorUsersListDetails;
  }

  // ___________________________________________________________________________
  /**
   * This reserveTask method allows to reserve a task. A reserved task may only
   * be active to the user who has reserved the task. For example, a user can
   * reserve a task assigned to a work queue to which they are currently
   * subscribed. Once the work queue task is reserved by the user, it will be
   * removed from the work queue so that other subscribers to the work queue
   * will not be able to reserve the task.
   *
   * @param details - ReserveAssignedTasksToUser details of the task to be reserved
   * @throws InformationalException
   * @throws AppException
   */
  public void reserveTask(ReserveTaskDetailsForUser details) throws AppException, InformationalException {
    // Create MaintainSupervisorTasks object
    curam.supervisor.sl.intf.MaintainSupervisorTasks maintainSupervisorTasks = MaintainSupervisorTasksFactory.newInstance();

    maintainSupervisorTasks.reserveTask(details.reserveDetails);

  }

}
