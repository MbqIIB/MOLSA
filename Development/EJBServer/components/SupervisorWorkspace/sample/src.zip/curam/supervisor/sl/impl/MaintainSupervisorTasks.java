/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.supervisor.sl.impl;


import curam.codetable.TARGETITEMTYPE;
import curam.codetable.TASKSTATUS;
import curam.core.fact.AdminUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.sl.entity.fact.TaskAssignmentFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.TaskAssignment;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.TaskAssignmentNameDetailsList;
import curam.core.sl.entity.struct.TaskIDRelatedIDAndTypeKey;
import curam.core.sl.entity.struct.WorkQueueDtls;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.struct.TaskHistoryTextDetails;
import curam.core.sl.struct.TaskManagementTaskKey;
import curam.core.sl.struct.ViewTaskDetails;
import curam.core.sl.supervisor.fact.TaskManagementFactory;
import curam.core.sl.supervisor.intf.TaskManagement;
import curam.core.struct.UserDetails;
import curam.core.struct.UserKeyStruct;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOSUPERVISORTASKDETAILS;
import curam.supervisor.sl.struct.DeferTaskDetails;
import curam.supervisor.sl.struct.ForwardTaskDetails;
import curam.supervisor.sl.struct.ReallocateTaskDetails;
import curam.supervisor.sl.struct.ReserveTaskDetailsForUser;
import curam.supervisor.sl.struct.RestartTaskDetails;
import curam.supervisor.sl.struct.UnreserveTaskDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.workflow.fact.TaskAdminFactory;
import curam.util.workflow.intf.TaskAdmin;
import curam.util.workflow.struct.TaskDetailsWithoutSnapshot;


/**
 * This process class provides the functionality for the Supervisor Task
 * Management
 *
 */

public abstract class MaintainSupervisorTasks extends curam.supervisor.sl.base.MaintainSupervisorTasks {

  // ___________________________________________________________________________
  /**
   * This closeTask method to close existing task.
   *
   * @param key -
   * TaskManagementTaskKey - to be closed
   * @throws InformationalException
   * @throws AppException
   */
  public void closeTask(TaskManagementTaskKey key) throws AppException,
      InformationalException {

    TaskManagement taskManagement = TaskManagementFactory.newInstance();

    // Delegating the call to the service layer of core TaskManagement
    taskManagement.close(key);
  }

  // ___________________________________________________________________________  
  /**
   * This viewTaskDetails method allows to view the task details
   *
   * @param key -
   * TaskManagementTaskKey
   * @return ViewTaskDetails
   * @throws InformationalException
   * @throws AppException
   */
  public ViewTaskDetails viewTaskDetails(TaskManagementTaskKey key)
    throws AppException, InformationalException {

    // BEGIN CR CR00021631 NP
    curam.core.sl.intf.TaskManagement taskManagement = curam.core.sl.fact.TaskManagementFactory.newInstance();
    // END CR CR00021631 NP
    ViewTaskDetails viewTaskDetails = new ViewTaskDetails();

    // Delegating the call to the service layer of core TaskManagement
    viewTaskDetails = taskManagement.viewTaskHome(key);
    return viewTaskDetails;
  }

  // ___________________________________________________________________________
  /**
   * This viewHistoryText method to display all of the events that have occurred
   * during the task life cycle.
   *
   * @param key -
   * TaskManagementTaskKey
   *
   * @return TaskHistoryTextDetails
   * @throws InformationalException
   * @throws AppException
   */
  public TaskHistoryTextDetails viewHistoryText(TaskManagementTaskKey key)
    throws AppException, InformationalException {

    // BEGIN CR CR00021631 NP
    curam.core.sl.intf.TaskManagement taskManagement = curam.core.sl.fact.TaskManagementFactory.newInstance();
    // END CR CR00021631 NP
    TaskHistoryTextDetails taskHistoryTextDetails = new TaskHistoryTextDetails();

    // Delegating the call to the service layer of core TaskManagement
    taskHistoryTextDetails = taskManagement.viewHistoryTextOrderedByChangeDateTimeLatestFirst(
      key);

    return taskHistoryTextDetails;
  }

  // ___________________________________________________________________________
  /**
   * This deferTask method to defer a reserved task.
   *
   * @param details -
   * DeferTaskDetails details of the task to be deferred
   * @throws InformationalException
   * @throws AppException
   */
  public void deferTask(DeferTaskDetails details) throws AppException,
      InformationalException {

    TaskManagement taskManagement = TaskManagementFactory.newInstance();
    // BEGIN CR CR00021631 NP
    curam.core.sl.intf.TaskManagement taskManagement_co = curam.core.sl.fact.TaskManagementFactory.newInstance();
    // END CR CR00021631 NP
    ViewTaskDetails viewTaskDetails = new ViewTaskDetails();
    TaskManagementTaskKey taskKey = new TaskManagementTaskKey();

    taskKey.taskID = details.deferTaskDtls.taskID;
    // Delegating the call to the service layer of core TaskManagement
    // BEGIN CR CR00021631 NP
    viewTaskDetails = taskManagement_co.viewTaskHome(taskKey);
    // END CR CR00021631 NP

    // The task must not already be deferred.
    if (viewTaskDetails.status.equals(TASKSTATUS.DEFERRED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_DEFERTASK_ALREADY_DEFERRED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // The task must not be closed.
    if (viewTaskDetails.status.equals(TASKSTATUS.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_DEFERTASK_ALREADY_CLOSED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // The task must be reserved.
    if (viewTaskDetails.reservedBy.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_DEFERTASK_NOT_RESERVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Restart date, when populated, must be later than current date.
    // BEGIN, CR00226381, GSP
    if (!details.deferTaskDtls.restartDate.isZero()
      && (details.deferTaskDtls.restartDate.before(Date.getCurrentDate())
        || details.deferTaskDtls.restartDate.equals(Date.getCurrentDate()))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_DEFERTASK_RESTARTDATE_LATER),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // END, CR00226381
    // Restart date, when populated, must be earlier than deadline date.
    // BEGIN, CR00226381, GSP
    if (!viewTaskDetails.dueDateTime.isZero()
      && details.deferTaskDtls.restartDate.getDateTime().after(
        viewTaskDetails.dueDateTime)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          curam.message.BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_DEFERTASK_RESTARTDATE_EARLIER),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    taskManagement.defer(details.deferTaskDtls);
  }

  // ___________________________________________________________________________
  /**
   * This reallocateTask method allows to reallocate a task. Reallocation of a
   * task invokes the tasks initial allocation strategy. This results in the
   * task being reassigned to the item (group of users or work queue) to which
   * it was originally assigned.
   *
   * @param details -
   * ReallocateTaskDetails details of the task to be reallocated
   * @throws InformationalException
   * @throws AppException
   */
  public void reallocateTask(ReallocateTaskDetails details)
    throws AppException, InformationalException {

    // Create TaskManagement object
    curam.core.sl.supervisor.intf.TaskManagement taskManagement = curam.core.sl.supervisor.fact.TaskManagementFactory.newInstance();
    curam.core.sl.struct.ReallocateTaskDetails reallocateTaskDetails = new curam.core.sl.struct.ReallocateTaskDetails();

    reallocateTaskDetails.comments = details.reallocateTaskDetails.comments;
    reallocateTaskDetails.taskID = details.reallocateTaskDetails.taskID;
    // assign values
    taskManagement.reallocate(reallocateTaskDetails);
  }

  // ___________________________________________________________________________
  /**
   * This forwardTask method allows to forwardTask.
   * @param details -  ForwardTaskDetails
   * @throws InformationalException
   * @throws AppException
   */
  public void forwardTask(ForwardTaskDetails details)
    throws AppException, InformationalException {

    // Task Management object
    curam.core.sl.supervisor.intf.TaskManagement taskManagementObj = curam.core.sl.supervisor.fact.TaskManagementFactory.newInstance();

    // To check if either user or organization unit or item to forward the task
    // to is selected.
    validateForward(details);
    // Call the forward method
    taskManagementObj.forward(details.details);

  }

  // ___________________________________________________________________________
  /**
   * This restartTask method to restart a task manually.
   *
   * @param details -
   * RestartTaskDetails details of the task to be restarted
   * @throws InformationalException
   * @throws AppException
   */
  public void restartTask(RestartTaskDetails details) throws AppException,
      InformationalException {
    TaskManagement taskManagement = TaskManagementFactory.newInstance();
    // BEGIN CR CR00021631 NP
    curam.core.sl.intf.TaskManagement taskManagement_co = curam.core.sl.fact.TaskManagementFactory.newInstance();
    // END CR CR00021631 NP
    ViewTaskDetails viewTaskDetails = new ViewTaskDetails();
    TaskManagementTaskKey taskKey = new TaskManagementTaskKey();

    taskKey.taskID = details.restartTaskDetails.taskID;
    // Delegating the call to the service layer of core TaskManagement

    // BEGIN CR CR00021631 NP
    viewTaskDetails = taskManagement_co.viewTaskHome(taskKey);
    // END CR CR00021631 NP

    // The task must be reserved.
    if (viewTaskDetails.reservedBy.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_RESTARTTASK_NOT_RESERVED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    // The task must already be deferred.
    if (!viewTaskDetails.status.equals(TASKSTATUS.DEFERRED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_RESTARTTASK_NOT_DEFERRED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    taskManagement.restart(details.restartTaskDetails);
  }

  // ___________________________________________________________________________
  /**
   * This reserveTask method allows to reserve a task. A reserved task may only
   * be active to the user who has reserved the task. For example, a user can
   * reserve a task assigned to a work queue to which they are currently
   * subscribed. Once the work queue task is reserved by the user, it will be
   * removed from the work queue so that other subscribers to the work queue
   * will not be able to reserve the task.
   *
   * @param details -
   * ReserveAssignedTasksToUser details of the task to be reserved
   * @throws InformationalException
   * @throws AppException
   */
  public void reserveTask(ReserveTaskDetailsForUser details)
    throws AppException, InformationalException {
    // Create TaskManagement obj
    curam.core.sl.supervisor.intf.TaskManagement taskManagement = curam.core.sl.supervisor.fact.TaskManagementFactory.newInstance();

    curam.core.sl.supervisor.struct.ReserveTaskDetailsForUser reserveTaskDetailsForUser = new curam.core.sl.supervisor.struct.ReserveTaskDetailsForUser();

    // validateReserve to do the submit validations.
    validateReserve(details);
    // Assign Key values
    reserveTaskDetailsForUser.taskID = details.taskID;
    reserveTaskDetailsForUser.comments = details.comments;

    if (details.userName.length() == 0 || details.userName == null) {
      reserveTaskDetailsForUser.username = details.supervisorUserName;
    } else {
      reserveTaskDetailsForUser.username = details.userName;
    }

    // Task Management reserve
    taskManagement.reserve(reserveTaskDetailsForUser);
  }

  // ___________________________________________________________________________  
  /**
   * This validateReserve - checks for Submit Validations
   *
   * @param details -
   * ReserveTaskDetailsForUser
   * @throws InformationalException
   * @throws AppException
   */
  public void validateReserve(ReserveTaskDetailsForUser details)
    throws AppException, InformationalException {

    curam.core.intf.Users usersObj = UsersFactory.newInstance();

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    // BEGIN, CR00161962, BK
    TaskAssignmentNameDetailsList taskAssignmentNameDetailsList = new TaskAssignmentNameDetailsList();

    TaskIDRelatedIDAndTypeKey taskIDAssigeeIDAndTypeKey = new TaskIDRelatedIDAndTypeKey();

    TaskAssignment taskAssignmentObj = TaskAssignmentFactory.newInstance();
    // END, CR00161962


    final TaskDetailsWithoutSnapshot taskReservedByDetails = taskAdminObj.readDetails(
      details.taskID);

    // To check the Reserve for User must be selected
    if (((details.userName.length() == 0) || (details.userName == null))
      && ((details.supervisorUserName.length() == 0)
        || (details.supervisorUserName == null))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_RESERVE_DETAILS_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // To check for multiple selection
    if ((details.userName != null && details.userName.length() > 0)
      && (details.supervisorUserName != null
        && details.supervisorUserName.length() > 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_RESERVE_DETAILS_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // BEGIN, CR00161962, BK
    // To check the sensitivity
    taskIDAssigeeIDAndTypeKey.taskID = details.taskID;
    taskIDAssigeeIDAndTypeKey.assigneeType = TARGETITEMTYPE.WORKQUEUE;
    
    taskAssignmentNameDetailsList = taskAssignmentObj.searchWQAssignmentsWithNamesByTaskID(
      taskIDAssigeeIDAndTypeKey);
    // searchAssignmentsWithNamesByTaskID(TaskIDAssigeeIDAndTypeKey)::TaskAssignmentNameDetails
    // END, CR00161962
    WorkQueue workQueue = WorkQueueFactory.newInstance();
    WorkQueueKey workQueueKey = new WorkQueueKey();
    UsersKey usersKey = new UsersKey();
    String supervisorUserName = TransactionInfo.getProgramUser();

    // BEGIN, CR00161962, BK
    for (int i = 0; i < taskAssignmentNameDetailsList.dtls.size(); i++) {

      workQueueKey.workQueueID = taskAssignmentNameDetailsList.dtls.item(i).relatedID;
      // END, CR00161962
      WorkQueueDtls workQueueDtls = workQueue.read(workQueueKey);

      if (!(workQueueDtls.administratorUserName.equals(supervisorUserName))) {

        usersKey.userName = supervisorUserName;

        UsersDtls usersDtls = usersObj.read(usersKey);
        int supervisorSensitivity = Integer.parseInt(usersDtls.sensitivity);
        int workQueueSensitivity = Integer.parseInt(workQueueDtls.sensitivity);

        // If Work queue sensitivity more than supervisor sensitivity throw
        // exception
        if (workQueueSensitivity > supervisorSensitivity) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
            new AppException(
              BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_RESERVE_DETAILS_SENSITIVITY_MISMATCH),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
              0);
        }

      }
    }

    // To check the task already reserved by other user

    if (!(taskReservedByDetails.reservedBy.length() == 0
      || taskReservedByDetails.reservedBy == null)) {
      usersKey.userName = taskReservedByDetails.reservedBy;

      AppException ae = new AppException(
        BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_RESERVE_TASK_ALREADY_RESERVED);

      ae.arg(usersObj.getFullName(usersKey).fullname);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // To check task already closed
    if (taskReservedByDetails.status.equals(TASKSTATUS.CLOSED)) {
      AppException ae = new AppException(
        BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_RESERVE_TASK_ALREADY_CLOSED);

      ae.arg(details.taskID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    // Check whether user active or not
    curam.core.intf.AdminUser adminUser = AdminUserFactory.newInstance();
    UserKeyStruct userKeyStruct = new UserKeyStruct();

    userKeyStruct.userName = details.userName;

    if (details.userName.length() == 0 || details.userName == null) {
      userKeyStruct.userName = details.supervisorUserName;
    } else {
      userKeyStruct.userName = details.userName;
    }

    UserDetails userDetails = adminUser.read(userKeyStruct);

    if (curam.codetable.RECORDSTATUS.CANCELLED.equals(userDetails.statusCode)) {
      AppException ae = new AppException(
        BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASKDETAILS_RESERVE_TASK_USER_NOT_ACTIVE);

      ae.arg(userDetails.fullName);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * This unreserveTask method allows to un-reserve a task. A task can be
   * un-reserved if the task is currently reserved by the current user. Once a
   * task is un-reserved it is once again available to the user, organization
   * unit, position, job, allocation target or work queue to which it was
   * previously assigned. The task is available again for reservation.
   *
   * @param details -
   * UnreserveTaskDetails details of the task to be unreserved
   * @throws InformationalException
   * @throws AppException
   */
  public void unreserveTask(UnreserveTaskDetails details) throws AppException,
      InformationalException {
    // Create TaskManagement object
    curam.core.sl.supervisor.intf.TaskManagement taskManagementObj = curam.core.sl.supervisor.fact.TaskManagementFactory.newInstance();

    // Call the unreserved method
    taskManagementObj.unreserve(details.unreserveTaskDtls);

  }
  
  // ___________________________________________________________________________
  /**
   * Method to validate forward task details.
   *
   * @param details
   * task details to be validated
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  protected void validateForward(ForwardTaskDetails details)
    throws AppException, InformationalException {
    // END, CR00198672
    // To check for empty condition
    if (details.orgUnitID == 0
      && (details.userName.trim().length() == 0 || details.userName == null)
      && details.details.forwardToID.trim().length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASK_FORWARD_DETAILS_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // To check at least one condition
    if (details.orgUnitID != 0
      && (details.userName.trim().length() != 0 || details.userName == null)
        || details.orgUnitID != 0
          && details.details.forwardToID.trim().length() != 0
          || (details.userName.trim().length() != 0 || details.userName == null)
            && details.details.forwardToID.trim().length() != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASK_FORWARD_DETAILS_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // To check both ForwardToType and ForwardToID present or not
    if (details.orgUnitID == 0
      && (details.userName.trim().length() == 0 || details.userName == null)
      && (details.details.forwardToType != null
        && details.details.forwardToType.length() > 0)
        && (details.details.forwardToID == null
          || details.details.forwardToID.length() == 0)
            || details.orgUnitID == 0
              && (details.userName.trim().length() == 0
                || details.userName == null)
                && (details.details.forwardToID != null
                  && details.details.forwardToID.length() > 0)
                  && (details.details.forwardToType == null
                    || details.details.forwardToType.length() == 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORTASKDETAILS.SUPERVISOR_TASK_FORWARD_DETAILS_INCOMPLETESELECTION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Populating the values of OrgUnit and User
    if (details.orgUnitID > 0) {
      details.details.forwardToID = String.valueOf(details.orgUnitID);
      details.details.forwardToType = TARGETITEMTYPE.ORGUNIT;
    }
    if (details.userName != null && details.userName.length() > 0) {
      details.details.forwardToID = details.userName;
      details.details.forwardToType = TARGETITEMTYPE.USER;
    }
  } 
}
