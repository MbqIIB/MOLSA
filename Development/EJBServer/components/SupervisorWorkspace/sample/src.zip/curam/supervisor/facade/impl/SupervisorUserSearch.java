/* 
 * Licensed Materials - Property of IBM
 * 
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/**
 * Copyright 2007, 2009, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.supervisor.facade.impl;


import curam.core.facade.struct.UserSearchKey;
import curam.core.fact.AdminUserFactory;
import curam.core.intf.AdminUser;
import curam.core.struct.InformationalMsgDtls;
import curam.supervisor.facade.struct.SupervisorSearchUserDetails;
import curam.supervisor.facade.struct.SupervisorUserSearchDetails;
import curam.supervisor.facade.struct.SupervisorUserSearchDetailsResults;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.transaction.TransactionInfo;


/**
 * Facade class for Supervisor User search
 *
 */
public abstract class SupervisorUserSearch extends curam.supervisor.facade.base.SupervisorUserSearch {

  // BEGIN, CR00170283, DJ
  // BEGIN, CR00247294, PM
  /**
   * This method allows the supervisor to search for a user, allowing supervisor
   * to provide user name in the filter
   *
   * @param key
   * - UserSearchKey
   * @return SupervisorUserSearchDetails
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 5.2 SP4, is replaced with
   * {@link #userDetailsSearch(UserSearchKey)} This method is
   * deprecated because it was not allowing to do a search based on
   * the start date of a position.The userDetailsSearch method
   * considers the start date of a position also when doing a user
   * search for the active positions.See release note: CR00215472.
   */
  @Deprecated
  // END, CR00247294
  public SupervisorUserSearchDetails userSearch(UserSearchKey key)
    throws AppException, InformationalException {

    // details to be returned
    SupervisorUserSearchDetails supervisorUserSearchDetails = new SupervisorUserSearchDetails();

    // user entity
    curam.core.intf.AdminUser adminUserObj = curam.core.fact.AdminUserFactory.newInstance();

    // search for users
    supervisorUserSearchDetails.userSearchResultsList = adminUserObj.search(
      key.userSearchCriteria);

    // Return user details
    return supervisorUserSearchDetails;
  }

  // END, CR00170283
  // BEGIN, CR00130063, DJ
  // BEGIN, CR00282028, IBM
  /**
   * This method allows the supervisor to search for a user, allowing supervisor
   * to provide user name in the filter
   *
   * @param key  - UserSearchKey
   * @return SupervisorUserSearchDetails
   *
   * @throws InformationalException
   * @throws AppException
   * @deprecated Since Curam 6.0 SP2, replaced with {@link 
   * SupervisorUserSearch#searchUserDetails(UserSearchKey)}.
   *
   * This method is deprecated as informational messages are not returned. This 
   * method is replaced by searchUserDetails(UserSearchKey) which returns 
   * the informational message along with user details as well. 
   * See release note: CS-09152/CR00282028
   */
  @Deprecated
  public SupervisorUserSearchDetailsResults userDetailsSearch(UserSearchKey key)
    throws AppException, InformationalException {
    // END, CR00282028
    // details to be returned
    SupervisorUserSearchDetailsResults supervisorUserSearchDetailsResults = new SupervisorUserSearchDetailsResults();

    // user entity
    curam.core.intf.AdminUser adminUserObj = curam.core.fact.AdminUserFactory.newInstance();

    // search for users
    supervisorUserSearchDetailsResults.userSearchResultsDetails = adminUserObj.searchUserDetails(
      key.userSearchCriteria);
    return  supervisorUserSearchDetailsResults;
  }

  // END, CR00130063
  
  // BEGIN, CR00282028, IBM
  /**
   * Search user details by provided search criteria.
   *
   * @param userSearchKey contains user search criteria.
   *
   * @return user details 
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public SupervisorSearchUserDetails searchUserDetails(final UserSearchKey 
    userSearchKey) throws AppException, InformationalException {

    SupervisorSearchUserDetails supervisorSearchUserDetails = new SupervisorSearchUserDetails();

    AdminUser adminUserObj = AdminUserFactory.newInstance();

    supervisorSearchUserDetails.userSearchResultsDetails = adminUserObj.searchUserDetails(
      userSearchKey.userSearchCriteria);

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    String[] infoMsgs = informationalManager.obtainInformationalAsString();

    for (String infoMsg : infoMsgs) {

      InformationalMsgDtls informationalMsgDtls = new InformationalMsgDtls();

      informationalMsgDtls.informationMsgTxt = infoMsg;
      supervisorSearchUserDetails.informationalMsgDtls.dtls.addRef(
        informationalMsgDtls);
    }
    return supervisorSearchUserDetails;
  }
  // END, CR00282028
}
