/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.supervisor.sl.impl;


import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;

import org.jdom.Element;
import org.jdom.output.XMLOutputter;

import curam.codetable.ASSESSMENTTYPE;
import curam.codetable.BUSINESSOBJECTTYPE;
import curam.codetable.CASEORGOBJECTTYPE;
import curam.codetable.CASESTATUS;
import curam.codetable.CASETYPECODE;
import curam.codetable.ISSUECONFIGURATIONTYPE;
import curam.codetable.ORGSTRUCTURESTATUS;
import curam.codetable.PRODUCTCATEGORY;
import curam.codetable.PRODUCTTYPE;
import curam.codetable.RECORDSTATUS;
import curam.codetable.SCREENINGNAMECODE;
import curam.codetable.SERVICEPLANTYPE;
import curam.codetable.TARGETITEMTYPE;
import curam.codetable.TASKCHANGETYPE;
import curam.codetable.TASKSTATUS;
import curam.codetable.VIEWTASKSOPTION;
import curam.core.fact.ActivityFactory;
import curam.core.fact.AdminUserFactory;
import curam.core.fact.CaseHeaderFactory;
import curam.core.fact.ConcernRoleFactory;
import curam.core.fact.EmailAddressFactory;
import curam.core.fact.MaintainCaseFactory;
import curam.core.fact.ProductDeliveryFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UsersFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.CaseHeader;
import curam.core.intf.ConcernRole;
import curam.core.intf.EmailAddress;
import curam.core.intf.MaintainCase;
import curam.core.intf.SystemUser;
import curam.core.intf.Users;
import curam.core.sl.entity.fact.AssessmentDeliveryFactory;
import curam.core.sl.entity.fact.InvestigationDeliveryFactory;
import curam.core.sl.entity.fact.IssueDeliveryFactory;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.fact.OrganisationStructureFactory;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.PositionFactory;
import curam.core.sl.entity.fact.ScreeningFactory;
import curam.core.sl.entity.fact.WorkQueueFactory;
import curam.core.sl.entity.intf.AssessmentDelivery;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.intf.Position;
import curam.core.sl.entity.intf.Screening;
import curam.core.sl.entity.intf.WorkQueue;
import curam.core.sl.entity.struct.AssessmentDeliveryKey;
import curam.core.sl.entity.struct.AssessmentTypeDetails;
import curam.core.sl.entity.struct.CaseKeyStruct;
import curam.core.sl.entity.struct.InvestigationDeliveryKey;
import curam.core.sl.entity.struct.InvestigationTypeCode;
import curam.core.sl.entity.struct.IssueDeliveryKey;
import curam.core.sl.entity.struct.IssueTypeCode;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgUnitUserNameAndStatusKey;
import curam.core.sl.entity.struct.OrganisationStructureStatus;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.entity.struct.ScreeningName;
import curam.core.sl.entity.struct.SupervisorOrgUnitDetails;
import curam.core.sl.entity.struct.SupervisorOrgUnitDetailsList;
import curam.core.sl.entity.struct.WorkQueueKey;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.struct.CaseIDKey;
import curam.core.sl.struct.CaseOwnerDetails;
import curam.core.sl.struct.ReasonEndDateComments;
import curam.core.sl.struct.SendNotificationInd;
import curam.core.sl.struct.TaskAndUserNameKey;
import curam.core.sl.struct.TaskManagementTaskKey;
import curam.core.sl.struct.UserNameAndFullName;
import curam.core.sl.supervisor.fact.CaseWorkspaceFactory;
import curam.core.sl.supervisor.fact.TaskManagementFactory;
import curam.core.sl.supervisor.intf.CaseWorkspace;
import curam.core.sl.supervisor.intf.TaskManagement;
import curam.core.sl.supervisor.struct.CaseReservedTasksByUserDetails;
import curam.core.sl.supervisor.struct.CaseReservedTasksByUserDetailsList;
import curam.core.sl.supervisor.struct.CaseReservedTasksByUserKey;
import curam.core.sl.supervisor.struct.CaseTasksDueInTheNextMonthKey;
import curam.core.sl.supervisor.struct.CaseTasksDueInTheNextTimePeriodDetails;
import curam.core.sl.supervisor.struct.CaseTasksDueInTheNextTimePeriodDetailsList;
import curam.core.sl.supervisor.struct.CaseTasksDueInTheNextWeekKey;
import curam.core.struct.ActivityCountForUsersDetailsList;
import curam.core.struct.CaseHeaderDtls;
import curam.core.struct.CaseHeaderKey;
import curam.core.struct.CaseIDAndTypeCodeKey;
import curam.core.struct.CaseIDDetailsList;
import curam.core.struct.CaseIDStartEndDateTimeAndStatusKey;
import curam.core.struct.CaseIssueTypeDetails;
import curam.core.struct.CaseIssueTypeDetailsList;
import curam.core.struct.CaseIssuesByAgeDetailsList;
import curam.core.struct.CaseIssuesByAgeKey;
import curam.core.struct.CaseIssuesOfATypeList;
import curam.core.struct.CaseKey;
import curam.core.struct.CaseReferenceAndStatusDetails;
import curam.core.struct.CaseSearchKey;
import curam.core.struct.CaseStatusIDKey;
import curam.core.struct.CaseTypeCode;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.EmailAddressDtls;
import curam.core.struct.EmailAddressKey;
import curam.core.struct.ProductDeliveryKey;
import curam.core.struct.ProductDeliveryTypeDetails;
import curam.core.struct.ReassignCasesByTypeCaseAndUserKey;
import curam.core.struct.SearchSupervisorCaseDetails;
import curam.core.struct.SearchSupervisorCaseDetailsList;
import curam.core.struct.UserDetails;
import curam.core.struct.UserFullname;
import curam.core.struct.UserKeyStruct;
import curam.core.struct.UsersDtls;
import curam.core.struct.UsersKey;
import curam.message.BPOSUPERVISORCASE;
import curam.message.BPOSUPERVISORCASETASKS;
import curam.message.BPOSUPERVISORUSER;
import curam.message.SUPERVISORCONST;
import curam.serviceplans.sl.entity.fact.ServicePlanDeliveryFactory;
import curam.serviceplans.sl.entity.struct.ServicePlanDeliveryKey;
import curam.serviceplans.sl.entity.struct.ServicePlanTypeStruct;
import curam.supervisor.sl.fact.CaseSearchFactory;
import curam.supervisor.sl.intf.CaseSearch;
import curam.supervisor.sl.struct.CaseDetailsList;
import curam.supervisor.sl.struct.CaseIDDateKey;
import curam.supervisor.sl.struct.CaseIdAndIssueTypeKey;
import curam.supervisor.sl.struct.CaseIssuesChartDetails;
import curam.supervisor.sl.struct.CaseIssuesDetailsList;
import curam.supervisor.sl.struct.CaseIssuesOfAType;
import curam.supervisor.sl.struct.CaseReservedTasksDetailsList;
import curam.supervisor.sl.struct.CaseTabDetails;
import curam.supervisor.sl.struct.CaseTaskForwardKey;
import curam.supervisor.sl.struct.CaseUsersScheduleDetails;
import curam.supervisor.sl.struct.CaseWorkspaceDetails;
import curam.supervisor.sl.struct.OrgObjectCaseSearchKey;
import curam.supervisor.sl.struct.OrgUintDetails;
import curam.supervisor.sl.struct.OrgUnitDetailsList;
import curam.supervisor.sl.struct.ProductStatusOrgObjectCaseTypeKey;
import curam.supervisor.sl.struct.ProductStausOrgObjectCaseTypeKey;
import curam.supervisor.sl.struct.ReadCaseDetails;
import curam.supervisor.sl.struct.ReassignCaseKey;
import curam.supervisor.sl.struct.ReassignCasesForUserKey;
import curam.supervisor.sl.struct.UserAndCaseTaskDetailsKey;
import curam.supervisor.sl.util.impl.SupervisorApplicationUtil;
import curam.util.codetable.TASKRESERVEDSEARCHSTATUS;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.LocalisableString;
import curam.util.resources.Configuration;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringList;
import curam.util.workflow.fact.TaskAdminFactory;
import curam.util.workflow.fact.TaskHistoryAdminFactory;
import curam.util.workflow.intf.TaskAdmin;
import curam.util.workflow.intf.TaskHistoryAdmin;
import curam.util.workflow.struct.TaskDetailsWithoutSnapshot;
import curam.util.workflow.struct.TaskOptimisticLockingDetails;


/**
 * Service layer class for Supervisor Cases
 *
 */
public abstract class MaintainSupervisorCase extends curam.supervisor.sl.base.MaintainSupervisorCase {

  /**
   * Identifier for holding the Organization Unit ID for Bar chart
   */
  protected static final String kID = SupervisorConst.kID;

  /**
   * Identifier for holding the User Name for Bar chart creation
   */
  protected static final String kUserName = SupervisorConst.kUserName;

  /**
   * Identifier for holding the Full Name for Bar chart creation
   */
  protected static final String kFullName = SupervisorConst.kFullName;

  /**
   * Identifier for holding the type of chart
   */
  protected static final String kBarChart = SupervisorConst.kBarChart;

  /**
   * Identifier for holding the element type
   */
  protected static final String kUnit = SupervisorConst.kUnit;

  /**
   * Identifier for holding the element caption
   */
  protected static final String kCaption = SupervisorConst.kCaption;

  /**
   * Identifier for holding the element caption text
   */
  protected static final String kText = SupervisorConst.kText;

  /**
   * Identifier for holding the element
   */
  protected static final String kBlock = SupervisorConst.kBlock;

  /**
   * Identifier for holding the navigation option
   */
  protected static final String kType = SupervisorConst.kType;

  /**
   * Identifier for holding the due date
   */
  protected static final String kDueDate = SupervisorConst.kDueDate;

  /**
   * Identifier for holding the start date
   */
  protected static final String kStartDate = SupervisorConst.kStartDate;

  // BEGIN, CR00169865, KP

  /**
   * Identifier for holding the start date inside the Block XML element
   */
  protected static final String kBlockStartDate = SupervisorConst.kBlockStartDate;

  // END, CR00169865


  /**
   * Identifier for holding the bar graph length
   */
  protected static final String kLength = SupervisorConst.kLength;

  /**
   * Identifier for holding the Number of weeks for task due
   *
   */
  protected static final int kNumberOfWeeks = SupervisorConst.kNumberOfWeeks;

  /**
   * Identifier for holding the hyperlink on email identifier
   */

  protected static final String kMailLink = SupervisorConst.kMailLink;

  // BEGIN, CR00021286 PL
  /**
   * Identifier for holding the Task Option Code for navigating to different
   * pages.
   */
  protected static final String kTaskOptionCode = SupervisorConst.kTaskOptionCode;

  /**
   * Identifier for holding the Task Option Code for navigating to different
   * pages.
   */
  protected static final String kIssueType = SupervisorConst.kIssueType;

  // BEGIN, CR00182755, CL
  /**
   * Identifier for holding the Task Option Code for navigating to different
   * pages.
   * @deprecated -since 6.0. This constant is replaced by
   * curam.util.exception.LocalisableString
   * (curam.message.SUPERVISORCONST.TEXT_SUPERVISORCONST_ISSUE_TYPE)
   * .getMessage().
   *
   * This constant is deprecated because it did not facilitate localization.
   * See release note: CR00182755
   *
   * @deprecated
   */
  @Deprecated
  protected static final String kIssueTypeDesc = SupervisorConst.kIssueTypeDesc;
  // END, CR00182755
  // END, CR00021286 MPB

  /**
   * Identifier for holding the value of Date Format to be displayed as the
   * Caption in the bar-chart.
   */
  // BEGIN, CR00085608 SK
  protected static final String kDateFormat = SupervisorConst.kDateFormat;
  // END, CR00085608 SK
  // BEGIN, CR00124642, GSP
  final String kGanttDateFormat = curam.util.resources.Locale.Date_ymd_ext;
  // END, CR00124642


  // BEGIN, CR00169865, KP

  /**
   * Date format to be used by BLOCK XML element's startDate
   */
  protected static final String kBlockStartDateFormat = SupervisorConst.kBlockStartDateFormat;

  // END, CR00169865

  // ___________________________________________________________________________
  /**
   * This getAllOrgUnitBySupervisor method reads OrganizationUnit record.
   *
   * @return Details of OrganizationUnit
   * @throws InformationalException
   * @throws AppException
   */
  public OrgUnitDetailsList getAllOrgUnitBySupervisor() throws AppException,
      InformationalException {

    OrgUnitDetailsList orgUnitDetailsList = new OrgUnitDetailsList();
    
    // BEGIN, CR00291844, SG
    OrganisationUnit organisationUnit = OrganisationUnitFactory.newInstance();
    // END, CR00291844
    
    SupervisorOrgUnitDetailsList unitDetailsList = new SupervisorOrgUnitDetailsList();
    OrgUnitUserNameAndStatusKey nameAndStatusKey = new OrgUnitUserNameAndStatusKey();
    SystemUser systemUser = SystemUserFactory.newInstance();

    nameAndStatusKey.userName = systemUser.getUserDetails().userName;
    nameAndStatusKey.status = RECORDSTATUS.CANCELLED;
    // BEGIN, CR00115371, SAI
    nameAndStatusKey.orgStructStatusCode = ORGSTRUCTURESTATUS.ACTIVE;
    // END, CR00115371

    String orgUnitSelectDefault = EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT_DEFAULT;
    String orgUnitSelectOption = Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_NESTEDORGUNITSELECT);

    if (!orgUnitSelectDefault.equals(orgUnitSelectOption)) {
      unitDetailsList = organisationUnit.listSupervisorOrgUnitLeadPos(
        nameAndStatusKey);
    } else {
      unitDetailsList = organisationUnit.listSupervisorOrgUnit(nameAndStatusKey);
    }

    for (int i = 0; i < unitDetailsList.dtls.size(); i++) {
      SupervisorOrgUnitDetails orgUnitDetails = unitDetailsList.dtls.item(i);
      OrgUintDetails details = new OrgUintDetails();

      details.description = orgUnitDetails.orgUnitName;
      details.orgUnitID = orgUnitDetails.orgUnitID;
      orgUnitDetailsList.dtls.addRef(details);
    }

    return orgUnitDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This reserveCaseTasks method reserve tasks to user
   *
   * @param key -
   * UserAndCaseTaskDetailsKey
   * @throws InformationalException
   * @throws AppException
   */
  public void reserveCaseTasks(UserAndCaseTaskDetailsKey key)
    throws AppException, InformationalException {

    // Get list of task id from the list
    StringList evidenceIDAndTypeStringList = StringUtil.delimitedText2StringList(
      key.TaskIDKeyList, '\t');
    curam.core.sl.struct.TaskAndUserNameKey taskAndUserNameKey = new curam.core.sl.struct.TaskAndUserNameKey();

    // Check both username and supervisorUserName are empty
    if (key.userName.trim().length() == 0
      && key.supervisorUserName.trim().length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASETASKS.SUPERVISOR_REASSIGNTASK_USERNAME_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check both username and supervisorUserName have a value
    if (key.userName.trim().length() != 0
      && key.supervisorUserName.trim().length() != 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASETASKS.SUPERVISOR_REASSIGNTASK_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check task selection is empty
    if (evidenceIDAndTypeStringList.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASETASKS.SUPERVISOR_REASSIGNTASK_SELECTION_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    String taskUserName = null;

    if (key.userName != null
      && !key.userName.equalsIgnoreCase(GeneralConstants.kEmpty)) {
      // Check whether user active or not
      validateUserStatus(key.userName);
      taskUserName = key.userName;
    } else {
      // Check whether user active or not
      validateUserStatus(key.supervisorUserName);
      taskUserName = key.supervisorUserName;

    }
    SystemUser systemUser = SystemUserFactory.newInstance();
    String currentLoggedInUser = systemUser.getUserDetails().userName;

    for (int i = 0; i < evidenceIDAndTypeStringList.size(); i++) {

      long taskID = Long.parseLong(evidenceIDAndTypeStringList.item(i));

      taskAndUserNameKey.taskID = taskID;
      taskAndUserNameKey.userName = taskUserName;
      validateReserveTask(taskAndUserNameKey);

      // Assign the user id to the user name
      final TaskHistoryAdmin taskHistoryAdminObj = TaskHistoryAdminFactory.newInstance();

      taskHistoryAdminObj.create(taskID, DateTime.getCurrentDateTime(),
        TASKCHANGETYPE.RESERVED, CuramConst.gkEmpty, taskUserName,
        CuramConst.gkEmpty, currentLoggedInUser);

      final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
      final TaskOptimisticLockingDetails taskOptimisicLockingDetails = taskAdminObj.readOptimisticLockingVersionNo(
        taskID);

      taskAdminObj.modifyReservedBy(taskID, taskUserName,
        DateTime.getCurrentDateTime(), taskOptimisicLockingDetails.versionNo);
    }

  }

  // ___________________________________________________________________________
  /**
   * This listCaseReservedTasks method reads open and deferred tasks associated
   * with the case.
   *
   * @param key -
   * CaseIDKey
   * @return CaseReservedTasksDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  public CaseReservedTasksDetailsList listCaseReservedTasks(CaseIDKey key)
    throws AppException, InformationalException {

    // Create instance of
    // CaseReservedTasksDetailsList,CaseWorkspace,caseReservedTasksByUserKey
    // and CaseReservedTasksByUserDetailsList
    CaseReservedTasksDetailsList caseReservedTasksDetailsList = new CaseReservedTasksDetailsList();
    curam.core.sl.supervisor.intf.CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();
    CaseReservedTasksByUserKey caseReservedTasksByUserKey = new CaseReservedTasksByUserKey();
    CaseReservedTasksByUserDetailsList caseReservedTasksByUserDetailsList = new CaseReservedTasksByUserDetailsList();

    // Set caseReservedTasksByUserKey to read Case's open and deferred tasks
    caseReservedTasksByUserKey.bizObjectID = key.caseID;
    caseReservedTasksByUserKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    caseReservedTasksByUserDetailsList = caseWorkspace.countCaseReservedTasksByUser(
      caseReservedTasksByUserKey);

    org.jdom.Element barChartElement = new org.jdom.Element(kBarChart);
    XMLOutputter outputter = new XMLOutputter();

    // BEGIN, CR00263925, ZV
    // sort case reserved task details list by username
    Comparator<CaseReservedTasksByUserDetails> reservedTaskDetailsComparator = new CaseReservedTaskDetailsComparator();

    Collections.sort(caseReservedTasksByUserDetailsList.dtls,
      reservedTaskDetailsComparator);
    // END, CR00263925

    for (int i = 0; i < caseReservedTasksByUserDetailsList.dtls.size(); i++) {

      org.jdom.Element unitElement = new org.jdom.Element(kUnit);
      org.jdom.Element captionElement = new org.jdom.Element(kCaption);

      String taskReservedByUser = caseReservedTasksByUserDetailsList.dtls.item(i).taskReservedByUserName;
      // Read User Full Name
      UserFullname fullnameObj = getTaskReservedUserFullName(taskReservedByUser);

      captionElement.setAttribute(kText, fullnameObj.fullname);
      captionElement.setAttribute(kUserName,
        caseReservedTasksByUserDetailsList.dtls.item(i).taskReservedByUserName);
      captionElement.setAttribute(SupervisorConst.kTaskOptionCode,
        VIEWTASKSOPTION.NEXTWEEK);

      unitElement.addContent(captionElement);

      org.jdom.Element blockElement = new org.jdom.Element(kBlock);

      blockElement.setAttribute(kLength,
        caseReservedTasksByUserDetailsList.dtls.item(i).numberOfOpenTasks + "");
      blockElement.setAttribute(kID, Long.toString(key.caseID));
      blockElement.setAttribute(kUserName,
        caseReservedTasksByUserDetailsList.dtls.item(i).taskReservedByUserName);

      blockElement.setAttribute(kFullName, fullnameObj.fullname);
      blockElement.setAttribute(kType, TASKSTATUS.NOTSTARTED);
      blockElement.setAttribute(SupervisorConst.kTaskOptionCode,
        VIEWTASKSOPTION.NEXTWEEK);
      unitElement.addContent(blockElement);

      blockElement = new org.jdom.Element(kBlock);
      blockElement.setAttribute(kLength,
        caseReservedTasksByUserDetailsList.dtls.item(i).numberOfDeferredTasks
        + GeneralConstants.kEmpty);
      blockElement.setAttribute(kID, Long.toString(key.caseID));
      blockElement.setAttribute(kUserName,
        caseReservedTasksByUserDetailsList.dtls.item(i).taskReservedByUserName
        + GeneralConstants.kEmpty);

      blockElement.setAttribute(kFullName, fullnameObj.fullname);
      blockElement.setAttribute(kType, TASKSTATUS.DEFERRED);
      blockElement.setAttribute(SupervisorConst.kTaskOptionCode,
        VIEWTASKSOPTION.NEXTWEEK);
      unitElement.addContent(blockElement);

      barChartElement.addContent(unitElement);
    }

    if (barChartElement.getChildren().isEmpty()) {
      caseReservedTasksDetailsList.chartXMLString = GeneralConstants.kEmpty;
    } else {
      caseReservedTasksDetailsList.chartXMLString = outputter.outputString(
        barChartElement);
    }
    return caseReservedTasksDetailsList;
  }

  // ___________________________________________________________________________
  /**
   * This readCaseWorkspaceDetails is used to read the Case Tasks that are due
   * in current week from the current date along with case details.
   *
   * @param key -
   * CaseIDKey
   * @return CaseWorkspaceDetails
   * @throws InformationalException
   * @throws AppException
   */
  public CaseWorkspaceDetails readCaseWorkspaceDetails(CaseIDKey key)
    throws AppException, InformationalException {
    // Creating CaseWorkspaceDetails object
    CaseWorkspaceDetails caseWorkspaceDetails = new CaseWorkspaceDetails();

    CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();
    CaseTasksDueInTheNextWeekKey weekKey = new CaseTasksDueInTheNextWeekKey();

    // BEGIN, CR00066677, CM
    // CaseUserRole manipulation variables
    curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // END, CR00066677

    // assigning key values
    weekKey.bizObjectID = key.caseID;
    weekKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    // BEGIN, CR00274837 ZV
    weekKey.deadlineDate = Date.getCurrentDate();
    // END, CR00274837
    weekKey.numberOfDays = getNumberOfDaysInWeek();

    CaseTasksDueInTheNextTimePeriodDetailsList detailsList = caseWorkspace.countCaseTasksDueInTheNextWeek(
      weekKey);

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    CaseIDDetailsList caseIDDetailsList = caseHeaderObj.searchListOfCaseIDs(
      caseHeaderKey);

    for (int j = 0; j < caseIDDetailsList.dtls.size(); j++) {
      weekKey = new CaseTasksDueInTheNextWeekKey();

      // assigning key values
      weekKey.bizObjectID = caseIDDetailsList.dtls.item(j).caseID;
      weekKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
      // BEGIN, CR00274837 ZV
      weekKey.deadlineDate = Date.getCurrentDate();
      // END, CR00274837
      weekKey.numberOfDays = getNumberOfDaysInWeek();

      CaseTasksDueInTheNextTimePeriodDetailsList intCaseDetailsList = caseWorkspace.countCaseTasksDueInTheNextWeek(
        weekKey);

      for (int i = 0; i < intCaseDetailsList.dtls.size(); i++) {
        for (int k = 0; k < detailsList.dtls.size(); k++) {
          if (detailsList.dtls.item(k).deadlineDate.equals(
            intCaseDetailsList.dtls.item(i).deadlineDate)) {
            detailsList.dtls.item(k).taskReservedCount += intCaseDetailsList.dtls.item(i).taskReservedCount;
            detailsList.dtls.item(k).taskUnreservedCount += intCaseDetailsList.dtls.item(i).taskUnreservedCount;
            intCaseDetailsList.dtls.remove(i);
            break;
          }
        }
      }
      for (int l = 0; l < intCaseDetailsList.dtls.size(); l++) {
        detailsList.dtls.addRef(intCaseDetailsList.dtls.item(l));
      }
    }
    caseWorkspaceDetails.chartXMLString = constructBarChartFromDetailsList(key,
      detailsList, 0, VIEWTASKSOPTION.NEXTWEEK);
    caseWorkspaceDetails.caseDetails = readCaseDetails(key);

    // BEGIN, CR00066677, CM
    // Read the case owner
    CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(caseHeaderKey);

    // if the type is a user
    // BEGIN, CR00093533, CW
    if (caseOwnerDetails.orgObjectType.equals(CASEORGOBJECTTYPE.USER)) {
      // END, CR00093533

      // Set orgObjectReferenceName
      caseOwnerDetails.orgObjectReferenceName = caseOwnerDetails.userFullName;
    }

    // Set the case owner details
    caseWorkspaceDetails.ownerDetails.assign(caseOwnerDetails);
    // END, CR00066677

    return caseWorkspaceDetails;
  }

  // ___________________________________________________________________________
  /**
   * Reassigns the case to the user. The new case owner is inserted the
   * CaseUser-Role entity Any tasks assigned to or reserved by the current case
   * owner, are forwarded to the new owner. A notification is sent to the user
   * to whom the case is reassigned, with the subject "You have been assigned
   * the <Role> on <Case Ref No> by <Full User Name of supervisor>"
   *
   * @param key
   * Identifies user and case details for reassignment
   * @throws InformationalException
   * @throws AppException
   */
  public void reassignCase(ReassignCaseKey key) throws AppException,
      InformationalException {

    // CaseUserRole manipulation variables
    curam.core.sl.intf.CaseUserRole caseUserRole = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    SupervisorApplicationUtil.validateReassignCase(key);
    // If Auto Reassign field is checked then it is redirected to a method
    // 'autoReassignForUsers'- where it reassigns the case to only Users and not
    // any other organization object
    if (key.autoReassign) {
      CaseReassign.AutoReassign autoReassign = new CaseReassign.AutoReassign();

      autoReassign.autoReassignUser(key);
      return;
    } else if (!key.autoReassign) {
      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {
        // END, CR00093533
        SupervisorApplicationUtil.validateReassignUser(key);
      } else {
        SupervisorApplicationUtil.validateReassignCaseOrgObject(key);
      }
    }
    SupervisorApplicationUtil supervisorApplicationUtil = new SupervisorApplicationUtil();

    // Send a Notification to the current owner
    String reassignCaseFromNotificationEnabled = (curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_REASSIGNCASEFROMNOTIFICATION));

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;

    // if notification to the current owner is enabled then send a notification.
    if (reassignCaseFromNotificationEnabled.equals(EnvVars.ENV_VALUE_YES)) {

      ReassignCaseKey reassignCaseKey = new ReassignCaseKey();

      reassignCaseKey.caseID = key.caseID;

      // Send a Notification to owner
      supervisorApplicationUtil.sendFromNotificationForSingleCase(
        reassignCaseKey);
    }

    // BEGIN, CR00076914, SPD
    ReasonEndDateComments reasonEndDateComments = new ReasonEndDateComments();

    // END, CR00076914

    // If Organization object is user the value in newUserID will be assigned to
    // Username else it will assigned to object reference field
    try {
      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {
        // END, CR00093533
        key.OrgObjLinkDtls.userName = key.newUserID;
        key.OrgObjLinkDtls.orgObjectType = key.organisationObject;
      } else {
        key.OrgObjLinkDtls.orgObjectType = key.organisationObject;
        key.OrgObjLinkDtls.orgObjectReference = Long.parseLong(key.newUserID);
      }
    } catch (NumberFormatException e) {// TODO: Do we need to throw anything here?
    }

    SendNotificationInd sendNotificationInd = new SendNotificationInd();

    sendNotificationInd.sendNotification = false;

    // Call CaseUserRole to create the new case owner
    caseUserRole.modifyCaseOwner(caseHeaderKey, key.OrgObjLinkDtls,
      reasonEndDateComments, sendNotificationInd);

    // Send a Notification to the new owner
    String reassignCaseToNotificationEnabled = (curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_REASSIGNCASETONOTIFICATION));

    if (reassignCaseToNotificationEnabled.equals(EnvVars.ENV_VALUE_YES)) {
      // Send a Notification to new owner
      supervisorApplicationUtil.sendToNotificationForSingleCase(key);
    }
  }

  // ___________________________________________________________________________
  /**
   * This readCaseWorkspaceMonthDetails is used to read the Case Tasks that are
   * due in next 5 weeks from the starting day of the current week along with
   * case details.
   *
   * @param key -
   * CaseIDKey
   * @return CaseWorkspaceDetails
   * @throws InformationalException
   * @throws AppException
   */

  public CaseWorkspaceDetails readCaseWorkspaceMonthDetails(CaseIDKey key)
    throws AppException, InformationalException {

    // Creating CaseWorkspaceDetails object
    CaseWorkspaceDetails caseWorkspaceDetails = new CaseWorkspaceDetails();

    CaseWorkspace caseWorkspace = CaseWorkspaceFactory.newInstance();

    CaseTasksDueInTheNextMonthKey monthKey = new CaseTasksDueInTheNextMonthKey();

    // BEGIN, CR00066677, CM
    // CaseUserRole manipulation variables
    curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // END, CR00066677

    // assigning key values
    monthKey.bizObjectID = key.caseID;
    monthKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
    // BEGIN, CR00274837 ZV
    monthKey.deadlineDate = Date.getCurrentDate();
    // END, CR00274837
    monthKey.numberOfWeeks = kNumberOfWeeks;

    CaseTasksDueInTheNextTimePeriodDetailsList detailsList = caseWorkspace.countCaseTasksDueInTheNextMonth(
      monthKey);

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = key.caseID;
    CaseIDDetailsList caseIDDetailsList = caseHeaderObj.searchListOfCaseIDs(
      caseHeaderKey);

    for (int j = 0; j < caseIDDetailsList.dtls.size(); j++) {
      monthKey = new CaseTasksDueInTheNextMonthKey();

      // assigning key values
      monthKey.bizObjectID = caseIDDetailsList.dtls.item(j).caseID;
      monthKey.bizObjectType = BUSINESSOBJECTTYPE.CASE;
      // BEGIN, CR00274837 ZV
      monthKey.deadlineDate = Date.getCurrentDate();
      // END, CR00274837
      monthKey.numberOfWeeks = kNumberOfWeeks;

      CaseTasksDueInTheNextTimePeriodDetailsList intCaseDetailsList = caseWorkspace.countCaseTasksDueInTheNextMonth(
        monthKey);

      for (int k = 0; k < detailsList.dtls.size(); k++) {
        for (int i = 0; i < intCaseDetailsList.dtls.size(); i++) {
          if (detailsList.dtls.item(k).deadlineDate.equals(
            intCaseDetailsList.dtls.item(i).deadlineDate)) {
            detailsList.dtls.item(k).taskReservedCount += intCaseDetailsList.dtls.item(i).taskReservedCount;
            detailsList.dtls.item(k).taskUnreservedCount += intCaseDetailsList.dtls.item(i).taskUnreservedCount;
            intCaseDetailsList.dtls.remove(i);
            break;
          }
        }
      }
      for (int l = 0; l < intCaseDetailsList.dtls.size(); l++) {
        detailsList.dtls.addRef(intCaseDetailsList.dtls.item(l));
      }
    }

    caseWorkspaceDetails.chartXMLString = constructBarChartFromDetailsList(key,
      detailsList, 7, VIEWTASKSOPTION.NEXTMONTH);
    caseWorkspaceDetails.caseDetails = readCaseDetails(key);

    // BEGIN, CR00066677, CM
    // Read the case owner
    CaseOwnerDetails caseOwnerDetails = caseUserRoleObj.readOwner(caseHeaderKey);

    // if the type is a user
    // BEGIN, CR00093533, CW
    if (caseOwnerDetails.orgObjectType.equals(CASEORGOBJECTTYPE.USER)) {
      // END, CR00093533

      // Set orgObjectReferenceName
      caseOwnerDetails.orgObjectReferenceName = caseOwnerDetails.userFullName;
    }

    // Set the case owner details
    caseWorkspaceDetails.ownerDetails.assign(caseOwnerDetails);
    // END, CR00066677

    return caseWorkspaceDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method validates the case reassignment. It checks that case is not
   * closed and user to whom the case will be reassigned, is not inactive. It
   * also checks that only one user either supervisor user or the generic user
   * is selected.
   *
   * @param key
   * ReassignCaseKey contains reassignment details
   * @throws InformationalException
   * @throws AppException
   */
  public void validateReassignCase(ReassignCaseKey key) throws AppException,
      InformationalException {

    if (key.newUserID.trim().length() == 0
      && key.supervisorUserID.trim().length() == 0 && !key.autoReassign) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);

    }

    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() != 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_AND_AUTOREASSIGN_SELECTION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() != 0)
        && !key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() == 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_AND_AUTOREASSIGN_SELECTION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if ((key.newUserID.trim().length() == 0
      && key.supervisorUserID.trim().length() != 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_AND_AUTOREASSIGN_SELECTION),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

  }

  // ___________________________________________________________________________
  /**
   * This method validates the case reassignment. It checks that case is not
   * closed and user to whom the case will be reassigned, is not inactive. It
   * also checks that only one user either supervisor user or the generic user
   * is selected.
   *
   * @param key -
   * ReassignCaseKey
   * @throws InformationalException
   * @throws AppException
   */
  public void validateReassignUser(ReassignCaseKey key) throws AppException,
      InformationalException {
    if ((key.newUserID.trim().length() == 0
      && key.supervisorUserID.trim().length() != 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    // Check whether user is active or not
    curam.core.intf.AdminUser adminUser = AdminUserFactory.newInstance();

    UserKeyStruct userKeyStruct = new UserKeyStruct();

    if (key.supervisorUserID.trim().length() != 0) {
      userKeyStruct.userName = key.supervisorUserID;
    } else {
      userKeyStruct.userName = key.newUserID;
    }

    UserDetails userDetails = adminUser.read(userKeyStruct);

    if (curam.codetable.RECORDSTATUS.CANCELLED.equals(userDetails.statusCode)) {
      AppException ae = new AppException(
        BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_USER_INACTIVE);

      ae.arg(userDetails.fullName);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    curam.core.intf.CaseHeader caseHeaderObj = curam.core.fact.CaseHeaderFactory.newInstance();

    // BEGIN, CR00279909, SG
    CaseSearchKey caseSearchKey = new CaseSearchKey();

    caseSearchKey.caseID = key.caseID;
    CaseReferenceAndStatusDetails caseRefStatusDetails = caseHeaderObj.readCaseReferenceAndStatusByCaseID(
      caseSearchKey);

    if (caseRefStatusDetails.statusCode.equals(
      curam.codetable.CASESTATUS.CLOSED)) {

      AppException ae = new AppException(
        BPOSUPERVISORCASE.INF_SUPERVISOR_REASSIGN_CASE_NOT_BE_CLOSED_TEXT);

      ae.arg(caseRefStatusDetails.caseReference);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

  }

  // ___________________________________________________________________________
  /**
   * Method to validate reserve task details.
   *
   * @param taskAndUserNameKey
   * task details to be validated
   * @throws InformationalException
   * @throws AppException
   */
  public void validateReserveTask(TaskAndUserNameKey taskAndUserNameKey)
    throws AppException, InformationalException {

    TaskManagementTaskKey taskManagementTaskKey = new TaskManagementTaskKey();

    taskManagementTaskKey.taskID = taskAndUserNameKey.taskID;

    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();
    final TaskDetailsWithoutSnapshot taskDtls = taskAdminObj.readDetails(
      taskAndUserNameKey.taskID);

    // Task cannot be reserved if it is being reserved by either the
    // current user or another user.

    if (taskDtls.reservedBy.length() != 0) {

      AppException ae = new AppException(
        BPOSUPERVISORCASETASKS.SUPERVISOR_REASSIGNTASK_TASK_NOTALLREADY_RESERVED);

      ae.arg(taskAndUserNameKey.taskID);
      ae.arg(taskDtls.reservedBy);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // ___________________________________________________________________________
  /**
   * This forwardCaseTasksReservedByUser forwards the selected case tasks
   * reserved by the user either to another user or to a work queue or to a
   * position or to an organization unit.
   *
   * @param key -
   * SupervisorTaskForwardDetails
   * @throws InformationalException
   * @throws AppException
   */

  public void forwardCaseTasksReservedByUser(CaseTaskForwardKey key)
    throws AppException, InformationalException {

    StringList deferredTaskIDList = StringUtil.delimitedText2StringList(
      key.deferredTaskIDList, '\t');

    StringList openTaskIDList = StringUtil.delimitedText2StringList(
      key.openTaskIDList, '\t');

    if ((key.forwardToOrgUnit == 0)
      && (key.forwardToUser == null || key.forwardToUser.length() == 0)
      && (key.forwardTaskDetails.forwardToType == null
        || key.forwardTaskDetails.forwardToType.length() == 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASE.SUPERVISOR_FORWARD_RESERVED_CASETASKS_SELECTION_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if ((key.forwardTaskDetails.forwardToType != null
      && key.forwardTaskDetails.forwardToType.length() > 0)
        && (key.forwardTaskDetails.forwardToID == null
          || key.forwardTaskDetails.forwardToID.length() == 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASE.SUPERVISOR_FORWARD_RESERVED_CASETASKS_SELECTION_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    if ((key.forwardToOrgUnit > 0)
      && (key.forwardToUser != null && key.forwardToUser.length() > 0)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASE.SUPERVISOR_FORWARD_RESERVED_CASETASKS_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if ((key.forwardToUser != null && key.forwardToUser.length() > 0)
      && ((key.forwardTaskDetails.forwardToType != null
        && key.forwardTaskDetails.forwardToType.length() > 0)
          || (key.forwardTaskDetails.forwardToID != null
            && key.forwardTaskDetails.forwardToID.length() > 0))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASE.SUPERVISOR_FORWARD_RESERVED_CASETASKS_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }

    if ((key.forwardToOrgUnit > 0)
      && ((key.forwardTaskDetails.forwardToType != null
        && key.forwardTaskDetails.forwardToType.length() > 0)
          || (key.forwardTaskDetails.forwardToID != null
            && key.forwardTaskDetails.forwardToID.length() > 0))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASE.SUPERVISOR_FORWARD_RESERVED_CASETASKS_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }

    if (deferredTaskIDList.size() == 0 && openTaskIDList.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASE.SUPERVISOR_FORWARD_RESERVED_CASETASKS_NO_TASK_SELECTED),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }

    if (key.forwardToOrgUnit > 0) {
      key.forwardTaskDetails.forwardToID = String.valueOf(key.forwardToOrgUnit);
      key.forwardTaskDetails.forwardToType = TARGETITEMTYPE.ORGUNIT;
    }
    if (key.forwardToUser != null && key.forwardToUser.length() > 0) {
      key.forwardTaskDetails.forwardToID = key.forwardToUser;
      key.forwardTaskDetails.forwardToType = TARGETITEMTYPE.USER;
    }
    for (int i = 0; i < deferredTaskIDList.size(); i++) {
      key.forwardTaskDetails.taskID = Long.parseLong(deferredTaskIDList.item(i));
      validateAndForwardTask(key);
    }

    for (int j = 0; j < openTaskIDList.size(); j++) {
      key.forwardTaskDetails.taskID = Long.parseLong(openTaskIDList.item(j));
      validateAndForwardTask(key);
    }
  }

  // ___________________________________________________________________________
  /**
   * Lists all the cases issues based on Age.
   *
   * @param arg0 -
   * CaseIDKey
   * @return CaseIssuesDetailsList
   * @throws InformationalException
   * @throws AppException
   */
  public CaseIssuesDetailsList listCaseIssuesByAge(CaseIDKey arg0)
    throws AppException, InformationalException {

    // Creating CaseIssuesByAgeDetailsList object
    CaseIssuesByAgeDetailsList caseIssuesByAgeDetailsList = new CaseIssuesByAgeDetailsList();

    // Creating key object
    CaseIssuesByAgeKey caseIssuesByAgeKey = new CaseIssuesByAgeKey();

    // Creating CaseIssuesDetailsList object
    CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    CaseIssuesDetailsList caseIssuesDetailsList = new CaseIssuesDetailsList();

    // assigning key values to search the Issues of Case By Age
    caseIssuesByAgeKey.caseID = arg0.caseID;
    caseIssuesByAgeKey.caseStatus = CASESTATUS.CLOSED;
    caseIssuesByAgeDetailsList = caseHeader.searchIssuesOfCaseByAge(
      caseIssuesByAgeKey);

    // Iterating through the list to get the value of owner based on the
    // value stored in organization object
    for (int i = 0; i < caseIssuesByAgeDetailsList.dtls.size(); i++) {
      // If the type of organization object is organization unit the owner
      // will have the value organization unit name.
      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.ORGUNIT.equals(
        caseIssuesByAgeDetailsList.dtls.item(i).orgObjectType)) {
        // END, CR00093533
        curam.core.sl.entity.intf.OrganisationUnit orgUnit = OrganisationUnitFactory.newInstance();
        OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = caseIssuesByAgeDetailsList.dtls.item(i).orgObjectReference;
        caseIssuesByAgeDetailsList.dtls.item(i).owner = orgUnit.readOrgUnitName(organisationUnitKey).name;
      } // If the type of organization object is Position the owner will have
      // the value Position name.
      // BEGIN, CR00093533, CW
      else if (CASEORGOBJECTTYPE.POSITION.equals(
        caseIssuesByAgeDetailsList.dtls.item(i).orgObjectType)) {
        // END, CR00093533
        Position posObj = PositionFactory.newInstance();
        PositionKey positionKey = new PositionKey();

        positionKey.positionID = caseIssuesByAgeDetailsList.dtls.item(i).orgObjectReference;
        caseIssuesByAgeDetailsList.dtls.item(i).owner = posObj.readPositionName(positionKey).name;
      } // If the type of organization object is Work Queue the owner will
      // have the value WorkQueue name.
      // BEGIN, CR00093533, CW
      else if (CASEORGOBJECTTYPE.WORKQUEUE.equals(
        caseIssuesByAgeDetailsList.dtls.item(i).orgObjectType)) {
        // END, CR00093533
        WorkQueue wq = WorkQueueFactory.newInstance();
        WorkQueueKey wqIDKey = new WorkQueueKey();

        wqIDKey.workQueueID = caseIssuesByAgeDetailsList.dtls.item(i).orgObjectReference;
        caseIssuesByAgeDetailsList.dtls.item(i).owner = wq.readWorkQueueName(wqIDKey).name;
      } // If the type of organization object is Users the owner will have
      // the value User name.
      else {
        UserAccess userAccessObj = UserAccessFactory.newInstance();
        UsersKey usersKey = new UsersKey();

        usersKey.userName = caseIssuesByAgeDetailsList.dtls.item(i).userName;
        caseIssuesByAgeDetailsList.dtls.item(i).owner = userAccessObj.getFullName(usersKey).fullname;
      }
    }
    caseIssuesDetailsList.caseIssueByAgeDtls = caseIssuesByAgeDetailsList;

    return caseIssuesDetailsList;

  }

  // ___________________________________________________________________________
  /**
   * This method reassigns the cases issues listed based on Age.
   *
   * @param key -
   * ReassignCasesForUserKey
   * @throws InformationalException
   * @throws AppException
   */
  public void reassignCaseIssuesByAge(ReassignCasesForUserKey key)
    throws AppException, InformationalException {

    // CaseHeader manipulation variables
    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    // AdministrationCaseRole manipulation variables
    curam.core.sl.intf.CaseUserRole caseUserRole = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    // parse the Tab-delimited String
    StringList stringList = parseCaseIDList(key);

    SupervisorApplicationUtil.validateReassignCase(key, stringList);
    key.OrgObjLinkDtls.orgObjectType = key.organisationObject;

    // if Auto Reassign field is checked then it is redirected to a method
    // 'autoReassignForUsers'- where it reassigns the case to only Users and not
    // any other organization object
    if (key.autoReassign) {
      CaseReassign.AutoReassign autoReassign = new CaseReassign.AutoReassign();

      // Passing a boolean parameter to display issue case specific messages.
      autoReassign.autoReassignForUsers(key, true);
      return;
    } else if (!key.autoReassign) {
      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.USER.equals(key.OrgObjLinkDtls.orgObjectType)) {
        // END, CR00093533
        SupervisorApplicationUtil.validateReassignCaseUser(key);
      } else {
        // validates the organization object expect Users.
        SupervisorApplicationUtil.validateReassignCaseOrgObject(key);
      }
    }
    String reassignCaseFromNotificationEnabled = (curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_REASSIGNCASEISSUEFROMNOTIFICATION));

    SupervisorApplicationUtil supervisorApplicationUtil = new SupervisorApplicationUtil();

    // If notification to the current owner is enabled then send a notification.
    if (reassignCaseFromNotificationEnabled.equals(EnvVars.ENV_VALUE_YES)) {

      supervisorApplicationUtil.sendFromNotificationForListOfCases(key,
        stringList, true);
    }
    for (int i = 0; i < stringList.size(); i++) {

      ReassignCasesByTypeCaseAndUserKey reassignCasesByTypeCaseAndUserKey = new ReassignCasesByTypeCaseAndUserKey();

      reassignCasesByTypeCaseAndUserKey.currentUserID = key.currentUserID;

      reassignCasesByTypeCaseAndUserKey.newUserID = key.newUserID;

      CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

      caseHeaderKey.caseID = Long.parseLong(stringList.item(i));

      // Read case details that has to be reassigned
      CaseHeaderDtls caseHeaderDtls = caseHeaderObj.read(caseHeaderKey);

      if (CASESTATUS.CLOSED.equals(caseHeaderDtls.statusCode)) {
        AppException ae = new AppException(
          BPOSUPERVISORUSER.SUPERVISOR_REASSIGN_CASESTATUS_CLOSED);

        ae.arg(caseHeaderDtls.caseReference);
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
          ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
      }

      ReasonEndDateComments reasonEndDateComments = new ReasonEndDateComments();

      // If Organization object is user the value in newUserID will be assigned
      // to Username else it will assigned to object reference field
      // BEGIN, CR00093533, CW
      if (key.OrgObjLinkDtls.orgObjectType.equals(CASEORGOBJECTTYPE.USER)) {
        // END, CR00093533
        key.OrgObjLinkDtls.userName = key.newUserID;
      } else {
        key.OrgObjLinkDtls.orgObjectReference = Long.parseLong(key.newUserID);
      }

      SendNotificationInd sendNotificationInd = new SendNotificationInd();

      sendNotificationInd.sendNotification = false;

      // Call CaseUserRole to create the new case owner
      caseUserRole.modifyCaseOwner(caseHeaderKey, key.OrgObjLinkDtls,
        reasonEndDateComments, sendNotificationInd);

    }
    // Send a Notification to the new owner
    String reassignCaseToNotificationEnabled = (curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_REASSIGNCASEISSUETONOTIFICATION));

    if (reassignCaseToNotificationEnabled.equals(EnvVars.ENV_VALUE_YES)) {
      // Send a Notification to new owner
      supervisorApplicationUtil.sendToNotificationForListOfCases(key,
        stringList, true);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method constructs Bar Chart from the Case Issues By Type.
   *
   * @param key -
   * CaseIDKey
   * @return CaseIssuesChartDetails
   * @throws InformationalException
   * @throws AppException
   */
  public CaseIssuesChartDetails chartCaseIssuesByType(
    curam.supervisor.sl.struct.CaseIDKey key) throws AppException,
      InformationalException {

    // Create a Case Header Entity object to read the Case issue details
    CaseHeader caseHeader = CaseHeaderFactory.newInstance();
    CaseIssuesChartDetails listCaseIssuesChartDetails = new CaseIssuesChartDetails();

    CaseStatusIDKey caseStatusIDKey = new CaseStatusIDKey();
    CaseIssueTypeDetailsList listDetails = new CaseIssueTypeDetailsList();

    caseStatusIDKey.caseID = key.key.caseID;
    caseStatusIDKey.caseStatusCode = CASESTATUS.CLOSED;

    // Read Case Issues of a Type
    listDetails = caseHeader.readCaseIssuesType(caseStatusIDKey);

    CaseIDKey caseIDKey = new CaseIDKey();

    caseIDKey.caseID = key.key.caseID;

    // construct the bar chart with the case Issue details and caseID
    listCaseIssuesChartDetails.chartXMLString = constructBarChartFromIssueDetailsList(
      listDetails, caseIDKey);

    return listCaseIssuesChartDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method lists the Case Issues Of A Type.
   *
   * @param key -
   * CaseIdAndIssueTypeKey
   * @return CaseIssuesOfAType
   * @throws InformationalException
   * @throws AppException
   */
  public CaseIssuesOfAType listCaseIssuesOfAType(CaseIdAndIssueTypeKey key)
    throws AppException, InformationalException {

    // Create a Case Header Entity object to read the Case issue details
    CaseHeader caseHeader = CaseHeaderFactory.newInstance();

    // Create a List object to hold the values in SL
    CaseIssuesOfAType caseIssuesOfAType = new CaseIssuesOfAType();

    // Create core struct key to call the entity layer function
    curam.core.struct.CaseIdAndIssueTypeKey caseKey = new curam.core.struct.CaseIdAndIssueTypeKey();

    CaseIssuesOfATypeList caseIssuesOfATypeList = new CaseIssuesOfATypeList();

    // populate the key values which is used to read Case Issues of a Type
    caseKey.caseID = key.caseDtls.caseID;
    caseKey.issueType = key.caseDtls.issueType;
    caseKey.caseStatus = CASESTATUS.CLOSED;
    caseIssuesOfATypeList = caseHeader.readCaseIssuesOfAType(caseKey);

    // Iterating through the list to get the value of owner based on the
    // value stored in organization object
    for (int i = 0; i < caseIssuesOfATypeList.dtls.size(); i++) {

      // If the type of organization object is organization unit the owner
      // will have the value organization unit name.
      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.ORGUNIT.equals(
        caseIssuesOfATypeList.dtls.item(i).orgObjectType)) {
        // END, CR00093533
        curam.core.sl.entity.intf.OrganisationUnit orgUnit = OrganisationUnitFactory.newInstance();
        OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = caseIssuesOfATypeList.dtls.item(i).orgObjectReference;
        caseIssuesOfATypeList.dtls.item(i).owner = orgUnit.readOrgUnitName(organisationUnitKey).name;
      } // If the type of organization object is Position the owner will
      // have the value Position name.
      // BEGIN, CR00093533, CW
      else if (CASEORGOBJECTTYPE.POSITION.equals(
        caseIssuesOfATypeList.dtls.item(i).orgObjectType)) {
        // END, CR00093533
        Position posObj = PositionFactory.newInstance();
        PositionKey positionKey = new PositionKey();

        positionKey.positionID = caseIssuesOfATypeList.dtls.item(i).orgObjectReference;
        caseIssuesOfATypeList.dtls.item(i).owner = posObj.readPositionName(positionKey).name;
      } // If the type of organization object is Work Queue the owner will
      // have the value WorkQueue name.
      // BEGIN, CR00093533, CW
      else if (CASEORGOBJECTTYPE.WORKQUEUE.equals(
        caseIssuesOfATypeList.dtls.item(i).orgObjectType)) {
        // END, CR00093533
        WorkQueue wq = WorkQueueFactory.newInstance();
        WorkQueueKey wqIDKey = new WorkQueueKey();

        wqIDKey.workQueueID = caseIssuesOfATypeList.dtls.item(i).orgObjectReference;
        caseIssuesOfATypeList.dtls.item(i).owner = wq.readWorkQueueName(wqIDKey).name;
      } // If the type of organization object is Users the owner will have
      // the value User name.
      else {

        UserAccess userAccessObj = UserAccessFactory.newInstance();
        UsersKey usersKey = new UsersKey();

        usersKey.userName = caseIssuesOfATypeList.dtls.item(i).userName;
        caseIssuesOfATypeList.dtls.item(i).owner = userAccessObj.getFullName(usersKey).fullname;
      }
    }
    caseIssuesOfAType.dtls = caseIssuesOfATypeList;
    return caseIssuesOfAType;
  }

  // ___________________________________________________________________________
  /**
   * This method reads Case Users Schedule Details and also populates the next
   * ,previous and weekBeginDate information
   *
   * @param arg0 -
   * CaseIDDateKey
   * @return - CaseUsersScheduleDetails
   * @throws InformationalException
   * @throws AppException
   */
  public CaseUsersScheduleDetails readCaseUsersScheduleDetails(
    CaseIDDateKey arg0) throws AppException, InformationalException {

    CaseUsersScheduleDetails caseUsersScheduleDetails = new CaseUsersScheduleDetails();

    ActivityCountForUsersDetailsList activityCountForUsersDetailsList = new ActivityCountForUsersDetailsList();

    CaseIDStartEndDateTimeAndStatusKey caseIDStartEndDateTimeAndStatusKey = new CaseIDStartEndDateTimeAndStatusKey();

    Date startDate = new Date();
    Date endDate = new Date();

    // Check whether the date entered is zero and then appropriately
    // calculate the start date
    if (arg0.weekBeginDate.isZero()) {
      int checkDate = Date.getCurrentDate().getCalendar().get(
        java.util.Calendar.DAY_OF_WEEK);

      if (checkDate == 2) {
        startDate = Date.getCurrentDate();
      } else {
        startDate = Date.getCurrentDate().addDays(2 - checkDate);
      }
    } else {
      startDate = arg0.weekBeginDate;
    }

    // Get the system configuration property value and then add to the start
    // date
    int noOfDaysInAWeek = getNumberOfDaysInWeek();

    // Calculate the end date
    endDate = startDate.addDays(noOfDaysInAWeek);

    // Populate the key information to read Case Users Schedule Details
    caseIDStartEndDateTimeAndStatusKey.caseID = arg0.caseID;
    caseIDStartEndDateTimeAndStatusKey.recordStatus = RECORDSTATUS.NORMAL;
    caseIDStartEndDateTimeAndStatusKey.recordStatusCode = RECORDSTATUS.NORMAL;
    caseIDStartEndDateTimeAndStatusKey.startDateTime = startDate.getDateTime();
    caseIDStartEndDateTimeAndStatusKey.endDateTime = endDate.getDateTime();

    curam.core.intf.Activity activity = ActivityFactory.newInstance();

    // Call the entity method to return the count of Active activities for
    // the User who have a role on the case
    activityCountForUsersDetailsList = activity.countActivityForCaseUsers(
      caseIDStartEndDateTimeAndStatusKey);

    // Calculate the previous, next and weekBeginDate information for the
    // output struct
    Date prevDate = startDate.addDays(-SupervisorConst.kseven_Days);
    Date nextDate = startDate.addDays(SupervisorConst.kseven_Days);
    Date weekBeginDate = startDate;

    // Populate the output struct with additional information along with
    // Case Users schedule Details search results
    caseUsersScheduleDetails.nextDate = nextDate;
    caseUsersScheduleDetails.previousDate = prevDate;
    caseUsersScheduleDetails.weekBeginDate = weekBeginDate;
    caseUsersScheduleDetails.detailsList = activityCountForUsersDetailsList;

    return caseUsersScheduleDetails;
  }

  // ___________________________________________________________________________
  /**
   * This method lists all Case Details depending upon the search criteria
   *
   * @param arg0 - ProductStausOrgObjectCaseTypeKey
   *
   * @return CaseDetailsList
   *
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0 SP3, replaced with {@link 
   * MaintainSupervisorCase#listCasesByProductStatusCaseTypeAndOrganisationObject(
   * ProductStatusOrgObjectCaseTypeKey arg0)}.
   * This method is deprecated as input struct name is spelled wrongly.
   * So replaced with listCasesByProductStatusCaseTypeAndOrganisationObject(
   * ProductStatusOrgObjectCaseTypeKey) and input struct name has been corrected. 
   * See release notes CS-10661/CR00304801.
   */
  @Deprecated
  public CaseDetailsList listCasesByProductStatusCaseTypeAndOrgObject(
    ProductStausOrgObjectCaseTypeKey arg0) throws AppException,
      InformationalException {

    CaseDetailsList caseDetailsList = new CaseDetailsList();    
    
    // BEGIN, CR00098757, CW
    // Blank status code = "ALL"
    // If the product type = "ALL",case type = "ALL"
    if (arg0.productType.equals(SupervisorConst.kcode_All)
      && arg0.statusCode.trim().equals(CuramConst.gkEmpty)
      && arg0.caseType.equals(SupervisorConst.kcode_All)) {
      caseDetailsList = searchCasesByOwner(arg0);
    } // If product type = "ALL", status code = "ALL" and select value for
    // case type from drop down
    else if (arg0.productType.equals(SupervisorConst.kcode_All)
      && arg0.statusCode.trim().equals(CuramConst.gkEmpty)
      && !arg0.caseType.equals(SupervisorConst.kcode_All)) {
      caseDetailsList = searchCasesByOwnerCaseType(arg0);
    } // If product type = "ALL", select status code from drop down, case type =
    // "ALL"
    else if (arg0.productType.equals(SupervisorConst.kcode_All)
      && !(arg0.statusCode.trim().equals(CuramConst.gkEmpty))
      && arg0.caseType.equals(SupervisorConst.kcode_All)) {
      caseDetailsList = searchCasesByOwnerStatus(arg0);
    } // If product type = "ALL", select status code from drop down, select
    // case Type from drop down
    else if ((arg0.productType.equals(SupervisorConst.kcode_All))
      && !(arg0.statusCode.trim().equals(CuramConst.gkEmpty))
      && !arg0.caseType.equals(SupervisorConst.kcode_All)) {
      caseDetailsList = searchCasesByOwnerCaseTypeAndStatus(arg0);
    } // If product type is selected from drop down, status Code = "ALL",
    // case Type = "ALL"
    else if (!(arg0.productType.equals(SupervisorConst.kcode_All))
      && arg0.statusCode.trim().equals(CuramConst.gkEmpty)
      && arg0.caseType.equals(SupervisorConst.kcode_All)) {
      caseDetailsList = searchCasesByOwnerProduct(arg0);
    } // If product type is selected from drop down, status Code = "ALL",
    // case Type is selected from drop down
    else if (!(arg0.productType.equals(SupervisorConst.kcode_All))
      && arg0.statusCode.trim().equals(CuramConst.gkEmpty)
      && !arg0.caseType.equals(SupervisorConst.kcode_All)) {
      caseDetailsList = searchCasesByOwnerProductAndCaseType(arg0);
    } // If product type is selected from drop down, status code is selected
    // from
    // drop down, case Type = "ALL"
    else if (!(arg0.productType.equals(SupervisorConst.kcode_All))
      && !(arg0.statusCode.trim().equals(CuramConst.gkEmpty))
      && arg0.caseType.equals(SupervisorConst.kcode_All)) {
      caseDetailsList = searchCasesByOwnerProductAndStatus(arg0);
    } // If product type is selected from drop down, status code is selected
    // from
    // drop down, case Type is selected from drop down
    else if (!(arg0.productType.equals(SupervisorConst.kcode_All))
      && !(arg0.statusCode.trim().equals(CuramConst.gkEmpty))
      && !arg0.caseType.equals(SupervisorConst.kcode_All)) {
      caseDetailsList = searchCasesByOwnerProductCaseTypeStatus(arg0);
    }
    // END, CR00098757
    
    // BEGIN, CR00291562, KRK
    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey(); 
    
    for (final SearchSupervisorCaseDetails searchSupervisorCaseDetails : caseDetailsList.caseDtls.dtls.items()) {      
      String caseTypeCode = searchSupervisorCaseDetails.caseTypeCode;     
      String productTypeDesc = CuramConst.gkEmpty;      
      
      if ((CASETYPECODE.PRODUCTDELIVERY.equals(caseTypeCode))
        || (CASETYPECODE.LIABILITY.equals(caseTypeCode))) {

        // ProductDelivery manipulation variables.        
        ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
        ProductDeliveryTypeDetails productDeliveryTypeDetails = new ProductDeliveryTypeDetails();
        
        productDeliveryKey.caseID = searchSupervisorCaseDetails.caseID;
        
        productDeliveryTypeDetails = ProductDeliveryFactory.newInstance().readProductType(
          productDeliveryKey);

        productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
          productDeliveryTypeDetails.productType,
          TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.INTEGRATEDCASE.equals(caseTypeCode)) {

        // CaseHeader manipulation variables.
        final CaseHeaderDtls caseHeaderDtls;

        // Set key to read caseHeader.
        caseHeaderKey.caseID = searchSupervisorCaseDetails.caseID;

        caseHeaderDtls = CaseHeaderFactory.newInstance().read(caseHeaderKey);

        productTypeDesc = CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
          caseHeaderDtls.integratedCaseType, TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.SCREENINGCASE.equals(caseTypeCode)) {

        // Screening manipulation variables.
        final Screening screeningObj = curam.core.sl.entity.fact.ScreeningFactory.newInstance();
        final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();
        final ScreeningName screeningName;
       
        caseKeyStruct.caseID = searchSupervisorCaseDetails.caseID;
       
        screeningName = screeningObj.readName(caseKeyStruct);

        productTypeDesc = CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
          screeningName.name, TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.ASSESSMENTDELIVERY.equals(caseTypeCode)) {

        // AssessmentDelivery manipulation variables.        
        AssessmentDeliveryKey assessmentDeliveryKey = new AssessmentDeliveryKey();
        AssessmentTypeDetails assessmentTypeDetails;

        // Set key to read Assessment type.
        assessmentDeliveryKey.caseID = searchSupervisorCaseDetails.caseID;
        
        assessmentTypeDetails = AssessmentDeliveryFactory.newInstance().readAssessmentType(
          assessmentDeliveryKey);

        productTypeDesc = CodeTable.getOneItem(ASSESSMENTTYPE.TABLENAME,
          assessmentTypeDetails.assessmentType,
          TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.SERVICEPLAN.equals(caseTypeCode)) {

        // ServicePlan manipulation variables.        
        final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
        ServicePlanTypeStruct servicePlanTypeStruct = new ServicePlanTypeStruct();
        
        servicePlanDeliveryKey.caseID = searchSupervisorCaseDetails.caseID;
        
        servicePlanTypeStruct = ServicePlanDeliveryFactory.newInstance().readServicePlanType(
          servicePlanDeliveryKey);

        productTypeDesc = CodeTable.getOneItem(SERVICEPLANTYPE.TABLENAME,
          servicePlanTypeStruct.servicePlanType,
          TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.ISSUE.equals(caseTypeCode)) {

        // IssueDelivery manipulation variables.        
        final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();
        
        IssueTypeCode issueTypeCode = new IssueTypeCode();
        
        issueDeliveryKey.caseID = searchSupervisorCaseDetails.caseID;
        
        issueTypeCode = IssueDeliveryFactory.newInstance().readIssueType(
          issueDeliveryKey);

        productTypeDesc = CodeTable.getOneItem(
          curam.codetable.ISSUECONFIGURATIONTYPE.TABLENAME,
          issueTypeCode.issueType, TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.INVESTIGATIONCASE.equals(productTypeDesc)) {
        
        final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();
        
        InvestigationTypeCode investigationTypeCode = new InvestigationTypeCode();
        
        investigationDeliveryKey.caseID = searchSupervisorCaseDetails.caseID;
        
        investigationTypeCode = InvestigationDeliveryFactory.newInstance().readInvestigationType(
          investigationDeliveryKey);

        productTypeDesc = CodeTable.getOneItem(
          curam.codetable.INVESTIGATECONFIGTYPE.TABLENAME,
          investigationTypeCode.investigationType,
          TransactionInfo.getProgramLocale());
      }      
      // Product type description cannot be empty.
      if (null == productTypeDesc
        || productTypeDesc.length() == CuramConst.gkZero) {     
        productTypeDesc = CodeTable.getOneItem(CASETYPECODE.TABLENAME,
          caseTypeCode, TransactionInfo.getProgramLocale());        
      }
      searchSupervisorCaseDetails.productTypeDescOpt = productTypeDesc;
    }
    // END, CR00291562
    return caseDetailsList;
  }
  
  // BEGIN, CR00304801, VT
  /**
   * Lists all case details depending upon the search criteria. 
   *
   * @param key contains product status case type key.
   *
   * @return Case details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  public CaseDetailsList listCasesByProductStatusCaseTypeAndOrganisationObject(
    final ProductStatusOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    CaseDetailsList caseDetailsList = new CaseDetailsList();

    // Blank status code = "ALL"
    // If the product type = "ALL",case type = "ALL"
    if (SupervisorConst.kcode_All.equals(key.productType)
      && CuramConst.gkEmpty.equals(key.statusCode.trim())
      && SupervisorConst.kcode_All.equals(key.caseType)) {
      caseDetailsList = searchCasesBasedOnOwner(key);
    } // If product type = "ALL", status code = "ALL" and select value for
    // case type from drop down
    else if (SupervisorConst.kcode_All.equals(key.productType)
      && CuramConst.gkEmpty.equals(key.statusCode.trim())
      && !SupervisorConst.kcode_All.equals(key.caseType)) {
      caseDetailsList = searchCasesBasedOnOwnerCaseType(key);
    } // If product type = "ALL", select status code from drop down, case type =
    // "ALL"
    else if (SupervisorConst.kcode_All.equals(key.productType)
      && !(CuramConst.gkEmpty.equals(key.statusCode.trim()))
      && SupervisorConst.kcode_All.equals(key.caseType)) {
      caseDetailsList = searchCasesBasedOnOwnerStatus(key);
    } // If product type = "ALL", select status code from drop down, select
    // case Type from drop down
    else if ((SupervisorConst.kcode_All.equals(key.productType))
      && !(CuramConst.gkEmpty.equals(key.statusCode.trim()))
      && !SupervisorConst.kcode_All.equals(key.caseType)) {
      caseDetailsList = searchCasesBasedOnOwnerCaseTypeAndStatus(key);
    } // If product type is selected from drop down, status Code = "ALL",
    // case Type = "ALL"
    else if (!(SupervisorConst.kcode_All.equals(key.productType))
      && CuramConst.gkEmpty.equals(key.statusCode.trim())
      && SupervisorConst.kcode_All.equals(key.caseType)) {
      caseDetailsList = searchCasesBasedOnOwnerProduct(key);
    } // If product type is selected from drop down, status Code = "ALL",
    // case Type is selected from drop down
    else if (!(SupervisorConst.kcode_All.equals(key.productType))
      && CuramConst.gkEmpty.equals(key.statusCode.trim())
      && !SupervisorConst.kcode_All.equals(key.caseType)) {
      caseDetailsList = searchCasesBasedOnOwnerProductAndCaseType(key);
    } // If product type is selected from drop down, status code is selected
    // from drop down, case Type = "ALL"
    else if (!(SupervisorConst.kcode_All.equals(key.productType))
      && !(CuramConst.gkEmpty.equals(key.statusCode.trim()))
      && SupervisorConst.kcode_All.equals(key.caseType)) {
      caseDetailsList = searchCasesBasedOnOwnerProductAndStatus(key);
    } // If product type is selected from drop down, status code is selected
    // from drop down, case Type is selected from drop down
    else if (!(SupervisorConst.kcode_All.equals(key.productType))
      && !(CuramConst.gkEmpty.equals(key.statusCode.trim()))
      && !SupervisorConst.kcode_All.equals(key.caseType)) {
      caseDetailsList = searchCasesBasedOnOwnerProductCaseTypeStatus(key);
    }

    final CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    for (final SearchSupervisorCaseDetails searchSupervisorCaseDetails : caseDetailsList.caseDtls.dtls.items()) {
      String caseTypeCode = searchSupervisorCaseDetails.caseTypeCode;
      String productTypeDesc = CuramConst.gkEmpty;

      if ((CASETYPECODE.PRODUCTDELIVERY.equals(caseTypeCode))
        || (CASETYPECODE.LIABILITY.equals(caseTypeCode))) {

        final ProductDeliveryKey productDeliveryKey = new ProductDeliveryKey();
        ProductDeliveryTypeDetails productDeliveryTypeDetails = new ProductDeliveryTypeDetails();

        productDeliveryKey.caseID = searchSupervisorCaseDetails.caseID;

        productDeliveryTypeDetails = ProductDeliveryFactory.newInstance().readProductType(
          productDeliveryKey);

        productTypeDesc = CodeTable.getOneItem(PRODUCTTYPE.TABLENAME,
          productDeliveryTypeDetails.productType,
          TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.INTEGRATEDCASE.equals(caseTypeCode)) {

        caseHeaderKey.caseID = searchSupervisorCaseDetails.caseID;

        final CaseHeaderDtls caseHeaderDtls = CaseHeaderFactory.newInstance().read(
          caseHeaderKey);

        productTypeDesc = CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
          caseHeaderDtls.integratedCaseType, TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.SCREENINGCASE.equals(caseTypeCode)) {

        final Screening screeningObj = ScreeningFactory.newInstance();
        final CaseKeyStruct caseKeyStruct = new CaseKeyStruct();

        caseKeyStruct.caseID = searchSupervisorCaseDetails.caseID;

        final ScreeningName screeningName = screeningObj.readName(caseKeyStruct);

        productTypeDesc = CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
          screeningName.name, TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.ASSESSMENTDELIVERY.equals(caseTypeCode)) {

        final AssessmentDeliveryKey assessmentDeliveryKey = new AssessmentDeliveryKey();        

        assessmentDeliveryKey.caseID = searchSupervisorCaseDetails.caseID;

        final AssessmentTypeDetails assessmentTypeDetails = AssessmentDeliveryFactory.newInstance().readAssessmentType(
          assessmentDeliveryKey);

        productTypeDesc = CodeTable.getOneItem(ASSESSMENTTYPE.TABLENAME,
          assessmentTypeDetails.assessmentType,
          TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.SERVICEPLAN.equals(caseTypeCode)) {

        final ServicePlanDeliveryKey servicePlanDeliveryKey = new ServicePlanDeliveryKey();
        ServicePlanTypeStruct servicePlanTypeStruct = new ServicePlanTypeStruct();

        servicePlanDeliveryKey.caseID = searchSupervisorCaseDetails.caseID;

        servicePlanTypeStruct = ServicePlanDeliveryFactory.newInstance().readServicePlanType(
          servicePlanDeliveryKey);

        productTypeDesc = CodeTable.getOneItem(SERVICEPLANTYPE.TABLENAME,
          servicePlanTypeStruct.servicePlanType,
          TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.ISSUE.equals(caseTypeCode)) {

        final IssueDeliveryKey issueDeliveryKey = new IssueDeliveryKey();

        IssueTypeCode issueTypeCode = new IssueTypeCode();

        issueDeliveryKey.caseID = searchSupervisorCaseDetails.caseID;

        issueTypeCode = IssueDeliveryFactory.newInstance().readIssueType(
          issueDeliveryKey);

        productTypeDesc = CodeTable.getOneItem(
          curam.codetable.ISSUECONFIGURATIONTYPE.TABLENAME,
          issueTypeCode.issueType, TransactionInfo.getProgramLocale());

      } else if (CASETYPECODE.INVESTIGATIONCASE.equals(productTypeDesc)) {

        final InvestigationDeliveryKey investigationDeliveryKey = new InvestigationDeliveryKey();

        InvestigationTypeCode investigationTypeCode = new InvestigationTypeCode();

        investigationDeliveryKey.caseID = searchSupervisorCaseDetails.caseID;

        investigationTypeCode = InvestigationDeliveryFactory.newInstance().readInvestigationType(
          investigationDeliveryKey);

        productTypeDesc = CodeTable.getOneItem(
          curam.codetable.INVESTIGATECONFIGTYPE.TABLENAME,
          investigationTypeCode.investigationType,
          TransactionInfo.getProgramLocale());
      }
      // Product type description cannot be empty.
      if (null == productTypeDesc
        || CuramConst.gkZero == productTypeDesc.length()) {
        productTypeDesc = CodeTable.getOneItem(CASETYPECODE.TABLENAME,
          caseTypeCode, TransactionInfo.getProgramLocale());
      }
      searchSupervisorCaseDetails.productTypeDescOpt = productTypeDesc;
    }
    return caseDetailsList;

  }

  // END, CR00304801
  
  // BEGIN, CR00304801, VT
  /**
   * Search for cases based on case owner. 
   *
   * @param key contains product status case type key.
   *
   * @return Case details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected CaseDetailsList searchCasesBasedOnOwner(
    final ProductStatusOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    final CaseDetailsList caseDetailsList = new CaseDetailsList();

    final OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUserObj.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;

    try {

      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);
    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }

  // END, CR00304801

  /**
   * This method searches for cases by the case owner.
   *
   * @return Details of cases
   * @throws AppException
   * @throws InformationalException
   *
   * @deprecated Since Curam 6.0 SP3, 
   * replaced with {@link MaintainSupervisorCase#searchCasesBasedOnOwner(ProductStatusOrgObjectCaseTypeKey arg0)}
   * This method is deprecated as input struct name is spelled wrongly.
   * So replaced with searchCasesBasedOnOwner(ProductStatusOrgObjectCaseTypeKey arg0)and input struct name has been corrected.  
   * See release notes CS-10661/CR00304801.
   */
  @Deprecated
  protected CaseDetailsList searchCasesByOwner(
    ProductStausOrgObjectCaseTypeKey arg0) throws AppException,
      InformationalException {

    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    CaseDetailsList caseDetailsList = new CaseDetailsList();

    // BEGIN, CR00104524, ELG
    OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    SystemUser systemUser = SystemUserFactory.newInstance();

    orgObjectCaseSearchKey.organisationObject = arg0.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUser.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;

    try {

      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.USER.equals(arg0.organisationObject)) {
        // END, CR00093533

        orgObjectCaseSearchKey.assignedTo = arg0.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(arg0.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);
    // END, CR00104524

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }

  // BEGIN, CR00304801, VT
  /**
   * Lists the cases based on owner, product and case type as search criteria.
   *
   * @param key contains product status case type key.
   *
   * @return Case details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected CaseDetailsList searchCasesBasedOnOwnerProductAndCaseType(
    final ProductStatusOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();

    final CaseDetailsList caseDetailsList = new CaseDetailsList();
    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    final OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUserObj.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.productType = key.productType;
    orgObjectCaseSearchKey.caseType = key.caseType;

    try {

      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;
  }

  // END, CR00304801

 
  /**
   * This method searches for cases by the owner, product and case type.
   *
   * @param key details of ProductType, Status and OrganizationUnit
   *
   * @return Details of cases
   *
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0 SP3, 
   * replaced with {@link MaintainSupervisorCase#searchCasesBasedOnOwnerProductAndCaseType(ProductStatusOrgObjectCaseTypeKey key)}
   * This method is deprecated as input struct name is spelled wrongly.
   * So replaced with searchCasesBasedOnOwnerProductAndCaseType(
   * ProductStatusOrgObjectCaseTypeKey key)and input struct name has been corrected. 
   * See release notes CS-10661/CR00304801.
   */
  @Deprecated
  protected CaseDetailsList searchCasesByOwnerProductAndCaseType(
    ProductStausOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    // Creating SearchSupervisorCaseDetailsList object
    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();

    CaseDetailsList caseDetailsList = new CaseDetailsList();
    SystemUser systemUser = SystemUserFactory.newInstance();

    // BEGIN, CR00104524, ELG
    OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    // assigning key values
    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUser.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.productType = key.productType;
    orgObjectCaseSearchKey.caseType = key.caseType;

    try {

      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {
        // END, CR00093533

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);
    // END, CR00104524

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }

  // BEGIN, CR00304801, VT
  /**
   * Lists the cases based on owner, product and status as search criteria.
   *
   * @param key contains product status case type key.
   *
   * @return Case details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected CaseDetailsList searchCasesBasedOnOwnerProductAndStatus(
    final ProductStatusOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    final CaseDetailsList caseDetailsList = new CaseDetailsList();
    final SystemUser systemUser = SystemUserFactory.newInstance();

    final OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    orgObjectCaseSearchKey.caseStatus = key.statusCode;
    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUser.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.productType = key.productType;

    try {

      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }

  // END, CR00304801

  /**
   * This method searches for cases by the owner, product and status.
   *
   * @param key
   * details of ProductType, Status and OrganizationUnit
   * @return Details of cases
   *
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0 SP3, 
   * replaced with {@link MaintainSupervisorCase#searchCasesBasedOnOwnerProductAndStatus(ProductStatusOrgObjectCaseTypeKey key)}
   * This method is deprecated as input struct name is spelled wrongly.
   * So replaced with searchCasesBasedOnOwnerProductAndStatus(ProductStatusOrgObjectCaseTypeKey key)and 
   * input struct name has been corrected. 
   * See release notes CS-10661/CR00304801.
   */
  @Deprecated
  protected CaseDetailsList searchCasesByOwnerProductAndStatus(
    ProductStausOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    // Creating SearchSupervisorCaseDetailsList object
    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    CaseDetailsList caseDetailsList = new CaseDetailsList();
    SystemUser systemUser = SystemUserFactory.newInstance();

    // BEGIN, CR00104524, ELG
    OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    // assigning key values
    orgObjectCaseSearchKey.caseStatus = key.statusCode;
    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUser.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.productType = key.productType;

    try {

      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {
        // END, CR00093533

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);
    // END, CR00104524

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;
  }
  
  // BEGIN, CR00304801, VT
  /**
   * Lists the cases based on owner and product type as search criteria.
   *
   * @param key contains product status case type key.
   *
   * @return Case details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected CaseDetailsList searchCasesBasedOnOwnerProduct(
    final ProductStatusOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    final CaseDetailsList caseDetailsList = new CaseDetailsList();
    SystemUser systemUserObj = SystemUserFactory.newInstance();

    final OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUserObj.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.productType = key.productType;

    try {

      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }

  // END, CR00304801

  /**
   * This method searches for cases by the owner and product.
   *
   * @param key
   * details of ProductType, Status and OrganizationUnit
   * @return CaseDetailsList
   * @throws InformationalException
   *
   * @throws AppException
   * @deprecated Since Curam 6.0 SP3, 
   * replaced with {@link MaintainSupervisorCase#searchCasesBasedOnOwnerProduct(ProductStausOrgObjectCaseTypeKey key)}
   * This method is deprecated as input struct name is spelled wrongly.
   * So replaced with searchCasesBasedOnOwnerProduct(ProductStausOrgObjectCaseTypeKey key)
   * and input struct name has been corrected.  
   * See release notes CS-10661/CR00304801.
   */
  @Deprecated
  protected CaseDetailsList searchCasesByOwnerProduct(
    ProductStausOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    // Creating SearchSupervisorCaseDetailsList object
    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    CaseDetailsList caseDetailsList = new CaseDetailsList();
    SystemUser systemUser = SystemUserFactory.newInstance();

    // BEGIN, CR00104524, ELG
    OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    // assigning key values
    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUser.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.productType = key.productType;

    try {

      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {
        // END, CR00093533

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);
    // END, CR00104524

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;
  }

  // BEGIN, CR00304801, VT
  /**
   * Lists the cases based on owner, case type and status as search criteria.
   *
   * @param key contains product status case type key.
   *
   * @return Case details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected CaseDetailsList searchCasesBasedOnOwnerCaseTypeAndStatus(
    ProductStatusOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    final CaseDetailsList caseDetailsList = new CaseDetailsList();
    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    final OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    orgObjectCaseSearchKey.caseStatus = key.statusCode;
    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUserObj.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.caseType = key.caseType;

    try {

      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }

  // END, CR00304801

  /**
   * This method searches for cases by owner, case type and status.
   *
   * @param key
   * details of ProductType, Status and OrganizationUnit
   * @return CaseDetailsList
   *
   * @throws InformationalException
   * @throws AppException
   *
   * @deprecated Since Curam 6.0 SP3, 
   * replaced with {@link MaintainSupervisorCase#searchCasesBasedOnOwnerCaseTypeAndStatus(ProductStatusOrgObjectCaseTypeKey key)}
   * This method is deprecated as input struct name is spelled wrongly.
   * So replaced with searchCasesBasedOnOwnerCaseTypeAndStatus(ProductStatusOrgObjectCaseTypeKey key)
   * and input struct name has been corrected. 
   * See release notes CS-10661/CR00304801.
   */
  @Deprecated
  protected CaseDetailsList searchCasesByOwnerCaseTypeAndStatus(
    ProductStausOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    // Creating SearchSupervisorCaseDetailsList object
    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    CaseDetailsList caseDetailsList = new CaseDetailsList();
    SystemUser systemUser = SystemUserFactory.newInstance();

    // BEGIN, CR00104524, ELG
    OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    // assigning key values
    orgObjectCaseSearchKey.caseStatus = key.statusCode;
    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUser.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.caseType = key.caseType;

    try {

      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {
        // END, CR00093533

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);
    // END, CR00104524

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;
  }
  
  // BEGIN, CR00304801, VT
  /**
   * Lists the cases based on owner and case type as search criteria.
   *
   * @param key contains product status case type key.
   *
   * @return Case details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected CaseDetailsList searchCasesBasedOnOwnerCaseType(
    final ProductStatusOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    final CaseDetailsList caseDetailsList = new CaseDetailsList();
    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    final OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUserObj.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.caseType = key.caseType;

    try {

      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {
      return caseDetailsList;
    }

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }

  // END, CR00304801
   
  /**
   * This method searches for cases by owner and case type.
   *
   * @param key details of ProductType, Status and OrganizationUnit
   *
   * @return Details of cases
   *
   * @throws InformationalException
   * @throws AppException
   *
   * @deprecated Since Curam 6.0 SP3, 
   * replaced with {@link MaintainSupervisorCase#searchCasesBasedOnOwnerCaseType(ProductStatusOrgObjectCaseTypeKey key)}
   * This method is deprecated as input struct name is spelled wrongly.
   * So replaced with searchCasesBasedOnOwnerCaseType(ProductStatusOrgObjectCaseTypeKey key)
   * and input struct name has been corrected. 
   * See release notes CS-10661/CR00304801.
   */
  @Deprecated
  protected CaseDetailsList searchCasesByOwnerCaseType(
    ProductStausOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    // Creating SearchSupervisorCaseDetailsList object
    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    CaseDetailsList caseDetailsList = new CaseDetailsList();
    SystemUser systemUser = SystemUserFactory.newInstance();

    // BEGIN, CR00104524, ELG
    OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    // assigning key values
    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUser.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.caseType = key.caseType;

    try {

      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {
        // END, CR00093533

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {
      return caseDetailsList;
    }

    CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);
    // END, CR00104524

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }

  // BEGIN, CR00304801, VT
  /**
   * Lists the cases based on owner and status as search criteria.
   *
   * @param key contains product status case type key.
   *
   * @return Case details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */

  protected CaseDetailsList searchCasesBasedOnOwnerStatus(
    final ProductStatusOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    final CaseDetailsList caseDetailsList = new CaseDetailsList();
    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    final OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    orgObjectCaseSearchKey.caseStatus = key.statusCode;
    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUserObj.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;

    try {

      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {
      return caseDetailsList;
    }

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }

  // END, CR00304801

  /**
   * This method searches for cases by owner and status.
   *
   * @param key
   * details of ProductType, Status and OrganizationUnit
   * @return Details of cases
   * @throws InformationalException
   *
   * @throws AppException
   *
   * @deprecated Since Curam 6.0 SP3, 
   * replaced with {@link MaintainSupervisorCase#searchCasesBasedOnOwnerStatus(ProductStatusOrgObjectCaseTypeKey key)}
   * This method is deprecated as input struct name is spelled wrongly.
   * So replaced with searchCasesBasedOnOwnerStatus(ProductStatusOrgObjectCaseTypeKey key)
   * and input struct name has been corrected. 
   * See release notes CS-10661/CR00304801.
   */
  @Deprecated
  protected CaseDetailsList searchCasesByOwnerStatus(
    ProductStausOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    // Creating SearchSupervisorCaseDetailsList object
    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    CaseDetailsList caseDetailsList = new CaseDetailsList();
    SystemUser systemUser = SystemUserFactory.newInstance();

    // BEGIN, CR00104524, ELG
    OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    // assigning key values
    orgObjectCaseSearchKey.caseStatus = key.statusCode;
    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUser.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;

    try {

      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {
        // END, CR00093533

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {
      return caseDetailsList;
    }

    CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);
    // END, CR00104524

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }
  
  // BEGIN, CR00304801, VT
  /**
   * Lists the cases based on owner, product, case type and status as search criteria.
   *
   * @param key contains product status case type key.
   *
   * @return Case details list.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected CaseDetailsList searchCasesBasedOnOwnerProductCaseTypeStatus(
    final ProductStatusOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    final CaseDetailsList caseDetailsList = new CaseDetailsList();
    final SystemUser systemUserObj = SystemUserFactory.newInstance();

    final OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    orgObjectCaseSearchKey.caseStatus = key.statusCode;
    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUserObj.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.caseType = key.caseType;
    orgObjectCaseSearchKey.productType = key.productType;

    try {

      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    final CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }

  // END, CR00304801

  /**
   * This method searches for cases by owner, product, case type and status.
   *
   * @param key
   * details of ProductType, Status and OrganizationUnit
   * @return Details of cases
   * @throws InformationalException
   *
   * @throws AppException
   *
   * @deprecated Since Curam 6.0 SP3, 
   * replaced with {@link MaintainSupervisorCase#searchCasesBasedOnOwnerProductCaseTypeStatus(ProductStausOrgObjectCaseTypeKey key)}
   * This method is deprecated as input struct name is spelled wrongly.
   * So replaced with searchCasesBasedOnOwnerProductCaseTypeStatus(ProductStausOrgObjectCaseTypeKey key)
   * and input struct name has been corrected. 
   * See release notes CS-10661/CR00304801.
   */
  protected CaseDetailsList searchCasesByOwnerProductCaseTypeStatus(
    ProductStausOrgObjectCaseTypeKey key) throws AppException,
      InformationalException {

    // Creating SearchSupervisorCaseDetailsList object
    SearchSupervisorCaseDetailsList searchCaseDetailsList = new SearchSupervisorCaseDetailsList();
    CaseDetailsList caseDetailsList = new CaseDetailsList();
    SystemUser systemUser = SystemUserFactory.newInstance();

    // BEGIN, CR00104524, ELG
    OrgObjectCaseSearchKey orgObjectCaseSearchKey = new OrgObjectCaseSearchKey();

    orgObjectCaseSearchKey.caseStatus = key.statusCode;
    orgObjectCaseSearchKey.organisationObject = key.organisationObject;
    orgObjectCaseSearchKey.supervisorUserName = systemUser.getUserDetails().userName;
    orgObjectCaseSearchKey.recordStatus = RECORDSTATUS.CANCELLED;
    orgObjectCaseSearchKey.caseType = key.caseType;
    orgObjectCaseSearchKey.productType = key.productType;

    try {

      // BEGIN, CR00093533, CW
      if (CASEORGOBJECTTYPE.USER.equals(key.organisationObject)) {
        // END, CR00093533

        orgObjectCaseSearchKey.assignedTo = key.assignedTo;

      } else {

        orgObjectCaseSearchKey.objectReference = Long.parseLong(key.assignedTo);

      }

    } catch (NumberFormatException e) {

      return caseDetailsList;

    }

    CaseSearch caseSearchObj = CaseSearchFactory.newInstance();

    searchCaseDetailsList = caseSearchObj.searchCases(orgObjectCaseSearchKey);
    // END, CR00104524

    caseDetailsList.caseDtls = searchCaseDetailsList;

    return caseDetailsList;

  }

  /**
   * This method validates the reassigned cases.
   *
   * @param key -
   * ReassignCasesForUserKey
   * @param stringList -
   * StringList
   * @throws InformationalException
   * @throws AppException
   */
  protected void validateReassignCase(ReassignCasesForUserKey key,
    StringList stringList) throws AppException, InformationalException {
    // At least one case must be selected
    if (stringList.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(BPOSUPERVISORCASE.SUPERVISOR_ISSUE_REASSIGN_CASE_EMPTY),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
    if (key.newUserID.trim().length() == 0
      && key.supervisorUserID.trim().length() == 0 && !key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASE.SUPERVISOR_ISSUE_REASSIGN_USERNAME_EMPTY),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() != 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASE.SUPERVISOR_ISSUE_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          0);
    }
    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() != 0)
        && !key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASE.SUPERVISOR_ISSUE_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          2);
    }
    if ((key.newUserID.trim().length() != 0
      && key.supervisorUserID.trim().length() == 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASE.SUPERVISOR_ISSUE_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          1);
    }
    if ((key.newUserID.trim().length() == 0
      && key.supervisorUserID.trim().length() != 0)
        && key.autoReassign) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        new AppException(
          BPOSUPERVISORCASE.SUPERVISOR_ISSUE_REASSIGN_USERNAME_MULTIPLEVALUES),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne,
          3);
    }
  }

  // ___________________________________________________________________________
  /**
   * This method validates the reassign case User.
   *
   * @param key -
   * ReassignCasesForUserKey
   * @throws InformationalException
   * @throws AppException
   */
  protected void validateReassignCaseUser(ReassignCasesForUserKey key)
    throws AppException, InformationalException {

    // Check whether user active or not
    curam.core.intf.AdminUser adminUser = AdminUserFactory.newInstance();
    UserKeyStruct userKeyStruct = new UserKeyStruct();

    if (key.supervisorUserID.trim().length() != 0) {
      userKeyStruct.userName = key.supervisorUserID;
    } else {
      userKeyStruct.userName = key.newUserID;
    }

    UserDetails userDetails = adminUser.read(userKeyStruct);

    // If the status of the user is Cancelled then throw a exception
    if (curam.codetable.RECORDSTATUS.CANCELLED.equals(userDetails.statusCode)) {
      AppException ae = new AppException(
        BPOSUPERVISORCASE.SUPERVISOR_ISSUE_REASSIGN_USER_INACTIVE);

      ae.arg(userDetails.fullName);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // __________________________________________________________________________
  /**
   * This constructs a BarChart from Issue DetailsList
   *
   * @param listDetails -
   * CaseIssueTypeDetailsList
   * @param caseKey -
   * CaseIDKey
   * @return String - of bar chart xml values
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartFromIssueDetailsList(
    CaseIssueTypeDetailsList listDetails, CaseIDKey caseKey)
    throws AppException, InformationalException {
    // END, CR00198672
    Element barChartElement = new Element(kBarChart);
    XMLOutputter outputter = new XMLOutputter();

    int listSize = listDetails.dtls.size();

    // BEGIN, CR00263925, ZV
    // sort case issue details list by issue type
    Comparator<CaseIssueTypeDetails> issueDetailsComparator = new CaseIssueDetailsComparator();

    Collections.sort(listDetails.dtls, issueDetailsComparator);
    // END, CR00263925

    // Iterate through each Issue Details List and populate the xml
    for (int i = 0; i < listSize; i++) {

      CaseIssueTypeDetails issueDetails = listDetails.dtls.item(i);
      String issueDesc = // BEGIN, CR00163098, JC
        CodeTable.getOneItem(ISSUECONFIGURATIONTYPE.TABLENAME,
        issueDetails.issueType, TransactionInfo.getProgramLocale());
      // END, CR00163098, JC

      Element unitElement = new Element(kUnit);
      Element captionElement = new Element(kCaption);

      captionElement.setAttribute(kText, issueDesc);

      captionElement.setAttribute(kType, issueDetails.issueType);
      captionElement.setAttribute(kID, Long.toString(caseKey.caseID));
      captionElement.setAttribute(kTaskOptionCode, VIEWTASKSOPTION.DEFAULTCODE);

      unitElement.addContent(captionElement);

      Element blockElement = new Element(kBlock);

      blockElement.setAttribute(kID, Long.toString(caseKey.caseID));
      blockElement.setAttribute(kIssueType, issueDetails.issueType);
      blockElement.setAttribute(kLength, issueDetails.count + "");
      // BEGIN, CR00182755, CL
      String issueTypeDesc = new LocalisableString(curam.message.SUPERVISORCONST.TEXT_SUPERVISORCONST_ISSUE_TYPE).getMessage();

      blockElement.setAttribute(kType, issueTypeDesc);
      // END, CR00182755
      blockElement.setAttribute(kTaskOptionCode, VIEWTASKSOPTION.DEFAULTCODE);
      unitElement.addContent(blockElement);
      barChartElement.addContent(unitElement);

    }

    if (barChartElement.getChildren().isEmpty()) {
      return GeneralConstants.kEmpty;
    } else {

      return outputter.outputString(barChartElement);
    }
  }

  // ___________________________________________________________________________
  /**
   * This function parses the Tab-delimited string in to a list of Strings
   *
   * @param key
   * Tab-delimited string list of caseID's
   * @return StringList
   */
  // BEGIN, CR00198672, VK
  protected StringList parseCaseIDList(ReassignCasesForUserKey key) {
    // END, CR00198672
    StringList stringList = new StringList();

    // Convert the tab delimited string to a list of strings
    stringList = StringUtil.tabText2StringList(key.reassignCasesList);
    return stringList;

  }

  // ___________________________________________________________________________
  /**
   * This validateAndForwardTask forwards the selected case tasks reserved by
   * the user either to another user or to a work queue or to a position or to
   * an organization unit.
   *
   * @param key -
   * CaseTaskForwardKey
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  protected void validateAndForwardTask(CaseTaskForwardKey key)
    throws AppException, InformationalException {
    // END, CR00198672
    TaskManagement taskManagement = TaskManagementFactory.newInstance();
    final TaskAdmin taskAdminObj = TaskAdminFactory.newInstance();

    final TaskDetailsWithoutSnapshot taskSummaryDetails = taskAdminObj.readDetails(
      key.forwardTaskDetails.taskID);

    if (taskSummaryDetails.status.equals(curam.codetable.TASKSTATUS.CLOSED)) {
      AppException ae = new AppException(
        BPOSUPERVISORCASE.SUPERVISOR_FORWARD_RESERVED_CASETASKS_CLOSED);

      ae.arg(key.forwardTaskDetails.taskID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    if (!taskSummaryDetails.reservedBy.equals(key.userName)) {
      AppException ae = new AppException(
        BPOSUPERVISORCASE.SUPERVISOR_FORWARD_RESERVED_CASETASKS_NOT_RESERVED);

      ae.arg(key.forwardTaskDetails.taskID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }

    taskManagement.forward(key.forwardTaskDetails);
  }

  // ___________________________________________________________________________
  /**
   * Method to get Number of days in Weeks
   *
   * @return int
   */
  // BEGIN, CR00198672, VK
  protected int getNumberOfDaysInWeek() {
    // END, CR00198672
    String noOfDaysInaWeekString = curam.util.resources.Configuration.getProperty(
      EnvVars.ENV_SUPERVISOR_NO_OF_DAYS_IN_A_WEEK);

    int noOfDaysInaWeek = 0;

    if (noOfDaysInaWeekString == null) {
      noOfDaysInaWeek = EnvVars.ENV_SUPERVISOR_NO_OF_DAYS_IN_A_WEEK_DEFAULT;
    } else {
      noOfDaysInaWeek = Integer.parseInt(noOfDaysInaWeekString);
    }
    return noOfDaysInaWeek;
  }

  // __________________________________________________________________________
  /**
   * This constructBarChartFromDetailsList is used to construct bar chart from
   * the details list.
   *
   * @param caseIDKey -
   * CaseIDKey,
   * @param detailsList -
   * CaseTasksDueInTheNextTimePeriodDetailsList
   * @param dueDays -
   * int due days
   * @param taskOptionCode
   * taskOption code
   * @return String - of bar chart xml values
   */
  // BEGIN, CR00198672, VK
  protected String constructBarChartFromDetailsList(CaseIDKey caseIDKey,
    CaseTasksDueInTheNextTimePeriodDetailsList detailsList, int dueDays,
    String taskOptionCode) {
    // END, CR00198672
    Element barChartElement = new Element(kBarChart);
    XMLOutputter outputter = new XMLOutputter();

    int listSize = detailsList.dtls.size();

    // BEGIN, CR00190772, CL
    // Get the current locale
    String currentLocale = TransactionInfo.getProgramLocale();

    Locale locale;
    SimpleDateFormat simpleDateFormat;

    String localeLanguage = currentLocale.substring(0, 2);
    String localeCountry = new String();

    // Create a Locale object based on the user's locale and format the date
    if (currentLocale.length() > 2) {
      localeCountry = currentLocale.substring(3);
      locale = new Locale(localeLanguage, localeCountry);
      simpleDateFormat = new SimpleDateFormat(kDateFormat, locale);
    } else {
      locale = new Locale(localeLanguage);
      simpleDateFormat = new SimpleDateFormat(kDateFormat, locale);
    }

    // BEGIN, CR00263925, ZV
    // sort case task details list by deadline date
    Comparator<CaseTasksDueInTheNextTimePeriodDetails> taskDetailsComparator = new CaseTaskDetailsComparator();

    Collections.sort(detailsList.dtls, taskDetailsComparator);
    // END, CR00263925
    
    // BEGIN, CR00263925, ZV
    for (int i = 0; i < listSize; i++) {
      // END, CR00263925

      CaseTasksDueInTheNextTimePeriodDetails periodDetails = detailsList.dtls.item(
        i);

      Element unitElement = new Element(kUnit);
      Element captionElement = new Element(kCaption);

      // END, CR00190772

      captionElement.setAttribute(kText,
        simpleDateFormat.format(
        periodDetails.deadlineDate.getCalendar().getTime()));
      // BEGIN, CR00124642, GSP
      captionElement.setAttribute(kStartDate,
        curam.util.resources.Locale.getFormattedDate(periodDetails.deadlineDate, kGanttDateFormat).toString());
      // END, CR00124642
      captionElement.setAttribute(kTaskOptionCode, taskOptionCode);
      captionElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.ALL);
      captionElement.setAttribute(kID, Long.toString(caseIDKey.caseID));
      unitElement.addContent(captionElement);

      Element blockElement = new Element(kBlock);

      blockElement.setAttribute(kID, Long.toString(caseIDKey.caseID));
      // BEGIN, CR00124642, GSP
      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(periodDetails.deadlineDate, kGanttDateFormat).toString());

      // BEGIN, CR00169865, KP
      blockElement.setAttribute(kBlockStartDate,
        curam.util.resources.Locale.getFormattedDate(periodDetails.deadlineDate.addDays(dueDays), kBlockStartDateFormat).toString());
      // END, CR00169865

      // END, CR00124642
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.RESERVED);
      blockElement.setAttribute(kLength, periodDetails.taskReservedCount + "");
      // BEGIN, CR00021286 PL
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      // END, CR00021286
      unitElement.addContent(blockElement);

      blockElement = new Element(kBlock);
      // BEGIN, CR00124642, GSP

      blockElement.setAttribute(kDueDate,
        curam.util.resources.Locale.getFormattedDate(periodDetails.deadlineDate, kGanttDateFormat).toString());

      // BEGIN, CR00169865, KP
      blockElement.setAttribute(kBlockStartDate,
        curam.util.resources.Locale.getFormattedDate(periodDetails.deadlineDate.addDays(dueDays), kBlockStartDateFormat).toString());
      // END, CR00169865

      // END, CR00124642
      blockElement.setAttribute(kID, Long.toString(caseIDKey.caseID));
      // BEGIN, CR00331373, ZV
      blockElement.setAttribute(kType, TASKRESERVEDSEARCHSTATUS.UNRESERVED);
      // END, CR00331373
      blockElement.setAttribute(kLength, periodDetails.taskUnreservedCount + "");
      // BEGIN, CR00021286 PL
      blockElement.setAttribute(kTaskOptionCode, taskOptionCode);
      // END, CR00021286
      unitElement.addContent(blockElement);

      barChartElement.addContent(unitElement);

    }

    if (barChartElement.getChildren().isEmpty()) {
      return GeneralConstants.kEmpty;
    } else {
      return outputter.outputString(barChartElement);
    }
  }

  // __________________________________________________________________________
  /**
   * This readCaseDetails is used to read the Case Details from the CaseId
   *
   * @param caseKey -
   * CaseIDKey
   * @return ReadCaseDetails
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  protected ReadCaseDetails readCaseDetails(CaseIDKey caseKey)
    throws AppException, InformationalException {
    // END, CR00198672
    ReadCaseDetails caseDetails = new ReadCaseDetails();

    curam.core.intf.CaseHeader caseHeader = CaseHeaderFactory.newInstance();

    CaseHeaderKey caseHeaderKey = new CaseHeaderKey();

    caseHeaderKey.caseID = caseKey.caseID;
    CaseHeaderDtls caseHeaderDetails = caseHeader.read(caseHeaderKey);

    ConcernRole concernRole = ConcernRoleFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = caseHeaderDetails.concernRoleID;
    ConcernRoleDtls concernRoleDetails = concernRole.read(concernRoleKey);

    curam.core.sl.intf.CaseUserRole caseUserRoleObj = curam.core.sl.fact.CaseUserRoleFactory.newInstance();

    UsersKey usersKey = new UsersKey();

    OrgObjectLink orgObjectLink = OrgObjectLinkFactory.newInstance();
    OrgObjectLinkDtls orgObjectLinkDtls = new OrgObjectLinkDtls();

    orgObjectLinkDtls = orgObjectLink.readOwnerOrgObjectLinkDetailsByCaseID(
      caseHeaderKey);
    // BEGIN, CR00093533, CW
    if (CASEORGOBJECTTYPE.ORGUNIT.equals(orgObjectLinkDtls.orgObjectType)) {
      // END, CR00093533
      curam.core.sl.entity.intf.OrganisationUnit organisationUnit = OrganisationUnitFactory.newInstance();
      OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

      organisationUnitKey.organisationUnitID = orgObjectLinkDtls.orgObjectReference;
      caseDetails.objectOwnerName = organisationUnit.readOrgUnitName(organisationUnitKey).name;
      // BEGIN, CR00093533, CW
    } else if (CASEORGOBJECTTYPE.POSITION.equals(
      orgObjectLinkDtls.orgObjectType)) {
      // END, CR00093533
      Position position = PositionFactory.newInstance();
      PositionKey positionKey = new PositionKey();

      positionKey.positionID = orgObjectLinkDtls.orgObjectReference;
      caseDetails.objectOwnerName = position.readPositionName(positionKey).name;
      // BEGIN, CR00093533, CW
    } else if (CASEORGOBJECTTYPE.WORKQUEUE.equals(
      orgObjectLinkDtls.orgObjectType)) {
      // END, CR00093533
      WorkQueue workqueue_obj = curam.core.sl.entity.fact.WorkQueueFactory.newInstance();
      WorkQueueKey workQueueKey = new WorkQueueKey();

      workQueueKey.workQueueID = orgObjectLinkDtls.orgObjectReference;
      caseDetails.objectOwnerName = workqueue_obj.readWorkQueueName(workQueueKey).name;
      // BEGIN, CR00093533, CW
    } else if (CASEORGOBJECTTYPE.USER.equals(orgObjectLinkDtls.orgObjectType)) {
      // END, CR00093533
      UserAccess userAccessObj = UserAccessFactory.newInstance();

      usersKey.userName = orgObjectLinkDtls.userName;
      caseDetails.objectOwnerName = userAccessObj.getFullName(usersKey).fullname;
    }
    caseDetails.orgObjectType = orgObjectLinkDtls.orgObjectType;
    caseDetails.orgObjectReference = orgObjectLinkDtls.orgObjectReference;

    curam.core.sl.entity.intf.OrganisationStructure organisationStructure = OrganisationStructureFactory.newInstance();
    OrganisationStructureStatus organisationStructureStatus = new OrganisationStructureStatus();

    organisationStructureStatus.statusCode = ORGSTRUCTURESTATUS.ACTIVE;
    caseDetails.organisationStructureID = organisationStructure.readActiveOrganisationStructureID(organisationStructureStatus).organisationStructureID;

    // BEGIN, CR00093533, CW
    if (CASEORGOBJECTTYPE.USER.equals(orgObjectLinkDtls.orgObjectType)) {
      // END, CR00093533

      // BEGIN, CR00060051, PMD
      // Read the case supervisor
      UserNameAndFullName supervisorUserNameAndFullName = caseUserRoleObj.readSupervisor(
        caseHeaderKey);

      if (!supervisorUserNameAndFullName.userName.equalsIgnoreCase("")) {

        Users usersObj = UsersFactory.newInstance();
        UsersKey supervisorKey = new UsersKey();

        supervisorKey.userName = supervisorUserNameAndFullName.userName;
        // END, CR00060051

        UsersDtls supervisorDtls = usersObj.read(supervisorKey);
        EmailAddressDtls supervisorEmailAddressDtls = new EmailAddressDtls();

        if (supervisorDtls.businessEmailID != 0) {
          EmailAddress emailAddress = EmailAddressFactory.newInstance();
          EmailAddressKey emailAddressKey = new EmailAddressKey();

          emailAddressKey.emailAddressID = supervisorDtls.businessEmailID;
          supervisorEmailAddressDtls = emailAddress.read(emailAddressKey);
        }
        caseDetails.supervisorEmail = supervisorEmailAddressDtls.emailAddress;
        caseDetails.supervisorName = supervisorDtls.fullName;
        // BEGIN, CR00060051, PMD
        caseDetails.supervisorID = supervisorUserNameAndFullName.userName;
        // END, CR00060051
        caseDetails.supervisorEmailActionLink = kMailLink
          + caseDetails.supervisorEmail;
      }
    }

    caseDetails.caseReference = caseHeaderDetails.caseReference;
    caseDetails.caseID = caseHeaderDetails.caseID;
    caseDetails.caseStatus = caseHeaderDetails.statusCode;
    caseDetails.primaryClient = concernRoleDetails.concernRoleName;

    String caseTypeCode = caseHeaderDetails.caseTypeCode;
    String productTypeDesc = "";

    if ((caseTypeCode.equals(CASETYPECODE.PRODUCTDELIVERY))
      || (caseTypeCode.equals(CASETYPECODE.LIABILITY))) {

      productTypeDesc = CodeTable.getOneItem(CASETYPECODE.TABLENAME,
        caseTypeCode);

    } else if (caseTypeCode.equals(CASETYPECODE.INTEGRATEDCASE)) {
      productTypeDesc = CodeTable.getOneItem(PRODUCTCATEGORY.TABLENAME,
        caseHeaderDetails.integratedCaseType);

    } else if (caseTypeCode.equals(CASETYPECODE.SCREENINGCASE)) {

      // Set key to read Screening entity
      CaseKeyStruct caseKeyStruct = new CaseKeyStruct();

      caseKeyStruct.caseID = caseHeaderDetails.caseID;

      Screening screeningObj = ScreeningFactory.newInstance();

      // Read Screening
      ScreeningName screeningName = screeningObj.readName(caseKeyStruct);

      productTypeDesc = CodeTable.getOneItem(SCREENINGNAMECODE.TABLENAME,
        screeningName.name);

    } else if (caseTypeCode.equals(CASETYPECODE.ASSESSMENTDELIVERY)) {

      // Set key to read Assessment type
      AssessmentDeliveryKey assessmentDeliveryKey = new AssessmentDeliveryKey();

      assessmentDeliveryKey.caseID = caseHeaderDetails.caseID;

      // Read AssessmentType
      AssessmentDelivery assessmentDeliveryObj = AssessmentDeliveryFactory.newInstance();
      AssessmentTypeDetails assessmentTypeDetails = assessmentDeliveryObj.readAssessmentType(
        assessmentDeliveryKey);

      productTypeDesc = CodeTable.getOneItem(ASSESSMENTTYPE.TABLENAME,
        assessmentTypeDetails.assessmentType);
    }

    // Product type description cannot be empty
    if (productTypeDesc == null || productTypeDesc.length() == 0) {
      productTypeDesc = CodeTable.getOneItem(CASETYPECODE.TABLENAME,
        caseTypeCode);
    }

    caseDetails.productType = productTypeDesc;

    return caseDetails;
  }

  // ___________________________________________________________________________
  /**
   * This getTaskReservedUserFullName method reads userFullName associated with
   * the case.
   *
   * @param taskReservedByUser
   * userID
   * @return User Full Name
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  protected UserFullname getTaskReservedUserFullName(String taskReservedByUser)
    throws AppException, InformationalException {
    // END, CR00198672
    UserAccess userAccessObj = UserAccessFactory.newInstance();
    UsersKey usersKey = new UsersKey();

    usersKey.userName = taskReservedByUser;
    UserFullname fullnameObj = userAccessObj.getFullName(usersKey);

    return fullnameObj;

  }

  // ___________________________________________________________________________
  /**
   * This method is used to validate whether the user is active or not.
   *
   * @param userName
   * User Name
   * @throws InformationalException
   * @throws AppException
   */
  // BEGIN, CR00198672, VK
  protected void validateUserStatus(String userName) throws AppException,
      InformationalException {
    // END, CR00198672
    curam.core.intf.AdminUser adminUser = AdminUserFactory.newInstance();
    UserKeyStruct userKeyStruct = new UserKeyStruct();

    userKeyStruct.userName = userName;
    UserDetails userDetails = adminUser.read(userKeyStruct);

    // BEGIN CR00099822 ,MR
    if (curam.codetable.RECORDSTATUS.CANCELLED.equals(userDetails.statusCode)
      || userDetails.accountEnabled == false) {
      // END CR00099822
      AppException ae = new AppException(
        BPOSUPERVISORCASETASKS.SUPERVISOR_REASSIGNTASK_USER_INACTIVE);

      ae.arg(userDetails.fullName);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        ae, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetOne, 0);
    }
  }

  // BEGIN, CR00232351, ZV
  // ___________________________________________________________________________
  /**
   * Reads the Case tab display details for supervisor workspace.
   *
   * @param key Key of case to be read
   *
   * @return Case tab display details
   */
  public CaseTabDetails readCaseTabDetails(final CaseIDKey key)
    throws AppException, InformationalException {

    CaseTabDetails caseTabDetails = new CaseTabDetails();

    caseTabDetails.assign(readCaseDetails(key));

    CaseHeader caseHeaderObj = CaseHeaderFactory.newInstance();

    CaseKey caseKey = new CaseKey();

    caseKey.caseID = key.caseID;

    CaseTypeCode caseTypeCode = caseHeaderObj.readCaseTypeCode(caseKey);

    MaintainCase maintainCaseObj = MaintainCaseFactory.newInstance();
    CaseIDAndTypeCodeKey caseIDAndTypeCodeKey = new CaseIDAndTypeCodeKey();

    caseIDAndTypeCodeKey.caseTypeCode = caseTypeCode.caseTypeCode;
    caseIDAndTypeCodeKey.caseID = key.caseID;

    caseTabDetails.caseName = maintainCaseObj.getCaseTypeDescription(caseIDAndTypeCodeKey).caseTypeDesc;

    return caseTabDetails;
  }
  // END, CR00232351

  // BEGIN, CR00263925 ZV
  /**
   * Comparator used to order case task details list by deadline date.
   */
  protected class CaseTaskDetailsComparator implements Comparator<CaseTasksDueInTheNextTimePeriodDetails> {

    /**
     * Default constructor.
     */
    public CaseTaskDetailsComparator() {
      super();
    }

    /**
     * Compare two case task details structs.
     */
    public int compare(CaseTasksDueInTheNextTimePeriodDetails o1, CaseTasksDueInTheNextTimePeriodDetails o2) {
      // BEGIN, CR00264571 ZV
      return o2.deadlineDate.compareTo(o1.deadlineDate);
      // END, CR00264571
    }
  }


  /**
   * Comparator used to order case reserved task details list by username.
   */
  protected class CaseReservedTaskDetailsComparator implements Comparator<CaseReservedTasksByUserDetails> {

    /**
     * Default constructor.
     */
    public CaseReservedTaskDetailsComparator() {
      super();
    }

    /**
     * Compare two case reserved task details structs.
     */
    public int compare(CaseReservedTasksByUserDetails o1, CaseReservedTasksByUserDetails o2) {
      // BEGIN, CR00264571 ZV
      return o2.taskReservedByUserName.compareTo(o1.taskReservedByUserName);
      // END, CR00264571
    }
  }


  /**
   * Comparator used to order case issue details list by issue type.
   */
  protected class CaseIssueDetailsComparator implements Comparator<CaseIssueTypeDetails> {

    /**
     * Default constructor.
     */
    public CaseIssueDetailsComparator() {
      super();
    }

    /**
     * Compare two case issue details structs.
     */
    public int compare(CaseIssueTypeDetails o1, CaseIssueTypeDetails o2) {

      // BEGIN, CR00264571 ZV
      if (o2.issueType.equals(o1.issueType)) {
        return 0;
      } else if (o2.issueType.equals(ISSUECONFIGURATIONTYPE.EARNEDINCOME)) {
        return -1;
      } else if (o2.issueType.equals(ISSUECONFIGURATIONTYPE.HOLIDAYPAY)
        && !o1.issueType.equals(ISSUECONFIGURATIONTYPE.EARNEDINCOME)) {
        return -1;
      } else if (o2.issueType.equals(ISSUECONFIGURATIONTYPE.PENSION)
        && !(o1.issueType.equals(ISSUECONFIGURATIONTYPE.EARNEDINCOME)
          || o1.issueType.equals(ISSUECONFIGURATIONTYPE.HOLIDAYPAY))) {
        return -1;
      } else if (o2.issueType.equals(ISSUECONFIGURATIONTYPE.SEPARATIONINCOME)) {
        return 1;
      } else {
        return 1;
      }
      // END, CR00264571
    }
  }
  // END, CR00263925

}
