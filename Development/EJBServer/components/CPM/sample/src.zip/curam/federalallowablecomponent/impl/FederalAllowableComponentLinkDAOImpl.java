/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.federalallowablecomponent.impl;


import com.google.inject.Singleton;
import curam.codetable.impl.FEDALLOWCOMPRELATEDTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.federalallowablecomponent.entity.impl.FederalAllowableComponentLinkAdapter;
import curam.federalallowablecomponent.entity.struct.FederalAllowableComponentLinkDtls;
import curam.util.persistence.StandardDAOImpl;
import java.util.List;


/**
 * Implementation of the data retrieval operations for the
 * {@link FederalAllowableComponentLink} entity.
 *
 * @since 6.0
 */
@Singleton
class FederalAllowableComponentLinkDAOImpl extends StandardDAOImpl<FederalAllowableComponentLink, FederalAllowableComponentLinkDtls>
  implements FederalAllowableComponentLinkDAO {

  /**
   * Single instance of the entity adapter shared across all DAO
   * implementations.
   */
  protected static final FederalAllowableComponentLinkAdapter adapter = new FederalAllowableComponentLinkAdapter();

  /**
   * Constructor.
   */
  protected FederalAllowableComponentLinkDAOImpl() {
    super(adapter, FederalAllowableComponentLink.class);
  }

  /**
   * {@inheritDoc}
   */
  public List<FederalAllowableComponentLink> searchActiveByFederalAllowableComponent(
    final FederalAllowableComponent federalAllowableComponent) {
    return newList(
      adapter.searchByFederalAllowableComponentAndStatus(
        federalAllowableComponent.getID(), RECORDSTATUSEntry.NORMAL.getCode()));
  }

  /**
   * {@inheritDoc}
   */
  public List<FederalAllowableComponentLink> searchActiveByFederalAllowableComponentAndRelatedRecord(
    final FederalAllowableComponent federalAllowableComponent,
    final FEDALLOWCOMPRELATEDTYPEEntry relatedType) {
    return newList(
      adapter.searchByFederalAllowableComponentRelatedTypeAndStatus(
        federalAllowableComponent.getID(), relatedType.getCode(),
        RECORDSTATUSEntry.NORMAL.getCode()));
  }

  /**
   * {@inheritDoc}
   */
  public List<FederalAllowableComponentLink> searchActiveByRelatedRecord(
    final long relatedID, final FEDALLOWCOMPRELATEDTYPEEntry relatedType) {
    return newList(
      adapter.searchByRelatedRecordAndStatus(relatedID,
      RECORDSTATUSEntry.NORMAL.getCode(), relatedType.getCode()));
  }

  /**
   * {@inheritDoc}
   */
  public FederalAllowableComponentLink readActiveByFederalAllowableComponentAndRelatedRecord(
    final FederalAllowableComponent federalAllowableComponent,
    final long relatedID, final FEDALLOWCOMPRELATEDTYPEEntry relatedType) {
    return getEntity(
      adapter.readByFederalAllowableComponentRelatedRecordAndStatus(relatedID,
      relatedType.getCode(), RECORDSTATUSEntry.NORMAL.getCode(),
      federalAllowableComponent.getID()));
  }
}
