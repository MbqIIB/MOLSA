/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.federalallowablecomponent.impl;


import com.google.inject.Inject;
import curam.codetable.impl.CACLIENTPAIDSTATUSEntry;
import curam.codetable.impl.COUNTABLETYPEEntry;
import curam.codetable.impl.FEDALLOWCOMPRELATEDTYPEEntry;
import curam.federalallowablecomponent.entity.struct.FederalAllowableComponentDtls;
import curam.message.impl.FEDERALALLOWABLECOMPONENTExceptionCreator;
import curam.core.impl.CuramConst;
import curam.piwrapper.caseconfiguration.impl.Product;
import curam.piwrapper.caseconfiguration.impl.ProductDAO;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Date;
import curam.util.type.StringHelper;
import curam.workspaceservices.localization.impl.LocalizableText;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import java.util.ArrayList;
import java.util.List;


/**
 * Implementation class for the {@link FederalAllowableComponent} entity.
 *
 * @since 6.0
 */
public class FederalAllowableComponentImpl extends SingleTableLogicallyDeleteableEntityImpl<FederalAllowableComponentDtls>
  implements FederalAllowableComponent {

  /**
   * The localizable text handler variable for the name text.
   */
  protected LocalizableTextHandler nameLocalizableText;

  /**
   * The localizable text handler variable for the description text.
   */
  protected LocalizableTextHandler descriptionLocalizableText;

  /**
   * Reference to Localizable Text Handler DAO.
   */
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Reference to Federal Allowable Component DAO.
   */
  @Inject
  protected FederalAllowableComponentDAO federalAllowableComponentDAO;

  /**
   * Reference to Federal Allowable Component Link DAO.
   */
  @Inject
  protected FederalAllowableComponentLinkDAO federalAllowableComponentLinkDAO;

  /**
   * Reference to Product DAO.
   */
  @Inject
  protected ProductDAO productDAO;

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {

    // check for mandatory name
    if (StringHelper.isEmpty(getNameLocalizableText().getValue())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_FV_NAME_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // check for duplicate name
    List<FederalAllowableComponent> federalAllowableComponents = federalAllowableComponentDAO.listActive();

    for (FederalAllowableComponent federalAllowableComponent : federalAllowableComponents) {
      if (federalAllowableComponent.getID().longValue() == getID().longValue()) {
        continue; // ignore the current record
      } else {

        // check the name
        if (getName().equals(federalAllowableComponent.getName())) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_XRV_NAME_MUST_BE_UNIQUE(
              getNameLocalizableText().getValue()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }
      }
    }
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {
    if (getDtls().startDate.after(getDtls().endDate)
      && (!getDtls().endDate.isZero())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_XFV_START_DATE_MUST_BE_EARLIER_THAN_END_DATE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if (getDtls().projectionAllowed
      && (!getDtls().cAClientPaidStatus.equals(
        CACLIENTPAIDSTATUSEntry.PAID.getCode()))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_XFV_PROJECTION_AND_CA_CLIENT_PAID_STATUS_NOT_PAID(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {
    if (getDtls().startDate.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_FV_START_DATE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if (StringHelper.isEmpty(getDtls().countableType)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_FV_COUNTABLE_TYPE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {

    // Instantiate the localizable text variables
    nameLocalizableText = localizableTextHandlerDAO.newInstance();
    descriptionLocalizableText = localizableTextHandlerDAO.newInstance();

    super.setNewInstanceDefaults();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {

    storeLocalizableText();
    super.insert();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {
    storeLocalizableText();
    super.modify(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public String getName() {
    return getNameLocalizableText().getValue();
  }

  /**
   * {@inheritDoc}
   */
  public LocalizableText getNameLocalizableText() {

    // If the name text variable is null retrieve it from the database
    if (nameLocalizableText == null) {
      nameLocalizableText = localizableTextHandlerDAO.get(getDtls().nameTextID);
    }
    return nameLocalizableText;
  }

  /**
   * {@inheritDoc}
   */
  public void setName(final String name) {
    // If the name text variable is null retrieve it from the database
    if (nameLocalizableText == null) {
      nameLocalizableText = localizableTextHandlerDAO.get(getDtls().nameTextID);
    }
    nameLocalizableText.setShortTextInd(true);
    // Set the value for the current users locale
    nameLocalizableText.addValue(StringHelper.trim(name));
  }

  /**
   * {@inheritDoc}
   */
  public void setDescription(final String description) {
    // If the description text variable is null retrieve it from the database
    if (descriptionLocalizableText == null) {
      descriptionLocalizableText = localizableTextHandlerDAO.get(
        getDtls().descriptionTextID);
    }
    descriptionLocalizableText.setShortTextInd(true);
    // Set the value for the current users locale
    descriptionLocalizableText.addValue(description);
  }

  /**
   * {@inheritDoc}
   */
  public String getDescription() {
    return getDescriptionLocalizableText().getValue();
  }

  /**
   * {@inheritDoc}
   */
  public LocalizableText getDescriptionLocalizableText() {
    // If the description text variable is null retrieve it from the database
    if (descriptionLocalizableText == null) {
      descriptionLocalizableText = localizableTextHandlerDAO.get(
        getDtls().descriptionTextID);
    }
    return descriptionLocalizableText;
  }

  /**
   * {@inheritDoc}
   */
  public Date getEndDate() {
    return getDtls().endDate;
  }

  /**
   * {@inheritDoc}
   */
  public Date getStartDate() {
    return getDtls().startDate;
  }

  /**
   * {@inheritDoc}
   */
  public void setEndDate(final Date endDate) {
    getDtls().endDate = endDate;
  }

  /**
   * {@inheritDoc}
   */
  public void setStartDate(final Date startDate) {
    getDtls().startDate = startDate;
  }

  /**
   * {@inheritDoc}
   */
  public boolean isProjectionAllowed() {
    return getDtls().projectionAllowed;
  }

  /**
   * {@inheritDoc}
   */
  public void setProjectionAllowed(final boolean projectionAllowedInd) {
    getDtls().projectionAllowed = projectionAllowedInd;
  }

  /**
   * {@inheritDoc}
   */
  public COUNTABLETYPEEntry getCountableType() {
    return COUNTABLETYPEEntry.get(getDtls().countableType);
  }

  /**
   * {@inheritDoc}
   */
  public void setCountableType(final COUNTABLETYPEEntry countableType) {
    getDtls().countableType = countableType.getCode();
  }

  /**
   * Stores any LocalizableText records associated with the Federal Allowable
   * Component.
   *
   * @throws InformationalException
   * Generic Exception Signature
   */
  protected void storeLocalizableText() throws InformationalException {
    // Store the details if there are changes waiting to be written
    if (nameLocalizableText != null) {
      getDtls().nameTextID = nameLocalizableText.store();
    }
    if (descriptionLocalizableText != null) {
      getDtls().descriptionTextID = descriptionLocalizableText.store();
    }
  }

  /**
   * {@inheritDoc}
   */
  public CACLIENTPAIDSTATUSEntry getCAClientPaidStatus() {
    return CACLIENTPAIDSTATUSEntry.get(getDtls().cAClientPaidStatus);
  }

  /**
   * {@inheritDoc}
   */
  public void setCAClientPaidStatus(
    final CACLIENTPAIDSTATUSEntry caClientPaidStatus) {
    getDtls().cAClientPaidStatus = caClientPaidStatus.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void addFederalAllowableComponentLink(final long relatedID,
    final FEDALLOWCOMPRELATEDTYPEEntry relatedType)
    throws InformationalException {
    FederalAllowableComponentLink federalAllowableComponentLink = federalAllowableComponentLinkDAO.newInstance();

    federalAllowableComponentLink.setRelatedType(relatedType);
    federalAllowableComponentLink.setRelatedID(relatedID);
    federalAllowableComponentLink.setFederalAllowableComponent(this);
    federalAllowableComponentLink.insert();
  }

  /**
   * {@inheritDoc}
   */
  public void updateFederalAllowableComponentLinks(
    final String tabbedRelatedIDList,
    final FEDALLOWCOMPRELATEDTYPEEntry relatedType)
    throws InformationalException {

    final String[] relatedIDList = tabbedRelatedIDList.split(
      CuramConst.gkTabDelimiter);

    FederalAllowableComponentLink federalAllowableComponentLink;

    for (String relatedID : relatedIDList) {
      if (!StringHelper.isEmpty(relatedID)) {
        // check if a link already exists, if not create one
        federalAllowableComponentLink = federalAllowableComponentLinkDAO.readActiveByFederalAllowableComponentAndRelatedRecord(
          this, Long.valueOf(relatedID), relatedType);
        if (null == federalAllowableComponentLink) {
          federalAllowableComponentLink = federalAllowableComponentLinkDAO.newInstance();
          federalAllowableComponentLink.setFederalAllowableComponent(this);
          federalAllowableComponentLink.setRelatedID(Long.valueOf(relatedID));
          federalAllowableComponentLink.setRelatedType(relatedType);
          federalAllowableComponentLink.insert();
        }
      }
    }

    // need to remove any program links that are no longer required
    List<FederalAllowableComponentLink> existingFederalAllowableComponentLinks = federalAllowableComponentLinkDAO.searchActiveByFederalAllowableComponentAndRelatedRecord(
      this, relatedType);

    for (FederalAllowableComponentLink link : existingFederalAllowableComponentLinks) {
      boolean removeRelatedRecordLinkInd = true;

      for (String relatedID : relatedIDList) {
        if ((!StringHelper.isEmpty(relatedID))
          && (Long.valueOf(relatedID) == link.getRelatedID())) {
          removeRelatedRecordLinkInd = false;
          break;
        }
      }

      if (removeRelatedRecordLinkInd) {
        int versionNo = link.getVersionNo();

        link.cancel(versionNo);
      }
    }

  }

  /**
   * {@inheritDoc}
   */
  public List<Product> listPrograms() {

    List<Product> products = new ArrayList<Product>();
    List<FederalAllowableComponentLink> programs = federalAllowableComponentLinkDAO.searchActiveByFederalAllowableComponentAndRelatedRecord(
      this, FEDALLOWCOMPRELATEDTYPEEntry.PRODUCT);

    Product product;

    for (FederalAllowableComponentLink program : programs) {
      product = productDAO.get(program.getRelatedID());
      products.add(product);
    }
    return products;
  }

  /**
   * {@inheritDoc}
   */
  public List<FederalAllowableComponentLink> listLinksByRelatedType(
    final FEDALLOWCOMPRELATEDTYPEEntry relatedType) {

    List<FederalAllowableComponentLink> linkedRecords = federalAllowableComponentLinkDAO.searchActiveByFederalAllowableComponentAndRelatedRecord(
      this, relatedType);

    return linkedRecords;
  }

  /**
   * {@inheritDoc}
   */
  public void removeActivityLink(final long relatedID,
    final FEDALLOWCOMPRELATEDTYPEEntry relatedType)
    throws InformationalException {
    FederalAllowableComponentLink activityLink = federalAllowableComponentLinkDAO.readActiveByFederalAllowableComponentAndRelatedRecord(
      this, relatedID, relatedType);

    if (null != activityLink) {
      activityLink.cancel(activityLink.getVersionNo());
    }
  }

  @Override
  public void cancel(int versionNo) throws InformationalException {
    List<FederalAllowableComponentLink> federalAllowableComponentLinks = federalAllowableComponentLinkDAO.searchActiveByFederalAllowableComponent(
      this);

    for (FederalAllowableComponentLink linkToCancel : federalAllowableComponentLinks) {
      linkToCancel.cancel(linkToCancel.getVersionNo());
    }
    super.cancel(versionNo);
  }
  
}
