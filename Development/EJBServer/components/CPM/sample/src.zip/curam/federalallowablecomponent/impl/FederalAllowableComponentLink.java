/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.federalallowablecomponent.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.FEDALLOWCOMPRELATEDTYPEEntry;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.StandardEntity;
import curam.util.persistence.helper.LogicallyDeleteable;


/**
 * Interface to the {@link FederalAllowableComponentLink}. This is a link entity
 * which stores a relationship between a {@link FederalAllowableComponent} and a
 * related record, e.g. a {@link ActionPlanActionAdmin}.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@ImplementedBy(FederalAllowableComponentLinkImpl.class)
public interface FederalAllowableComponentLink extends StandardEntity,
    Insertable, OptimisticLockModifiable, LogicallyDeleteable {

  /**
   * Sets the related record identifier for the federal allowable component
   * link.
   *
   * @param relatedID
   * unique identifier of the related record
   */
  void setRelatedID(long relatedID);

  /**
   * Gets the related record identifier for the federal allowable component
   * link.
   *
   * @return unique identifier of the related record
   */
  long getRelatedID();

  /**
   * Sets the related record type code for the federal allowable component link.
   *
   * @param relatedType
   * the code table code representing the type of the related record
   */
  void setRelatedType(FEDALLOWCOMPRELATEDTYPEEntry relatedType);

  /**
   * Gets the related record type code for the federal allowable component link.
   *
   * @return the code table code representing the type of the related record
   */
  FEDALLOWCOMPRELATEDTYPEEntry getRelatedType();

  /**
   * Sets the {@link FederalAllowableComponent} for the federal allowable
   * component link.
   *
   * @param federalAllowableComponent
   * the {@link FederalAllowableComponent}
   */
  void setFederalAllowableComponent(
    FederalAllowableComponent federalAllowableComponent);

  /**
   * Gets the {@link FederalAllowableComponent} for the federal allowable
   * component link.
   *
   * @return the {@link FederalAllowableComponent}
   */
  FederalAllowableComponent getFederalAllowableComponent();
}
