/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.federalallowablecomponent.impl;


import com.google.inject.Inject;
import curam.codetable.impl.FEDALLOWCOMPRELATEDTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.federalallowablecomponent.entity.struct.FederalAllowableComponentLinkDtls;
import curam.message.impl.FEDERALALLOWABLECOMPONENTExceptionCreator;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.Date;
import curam.util.type.StringHelper;
import java.util.List;


/**
 * Implementation class for the {@link FederalAllowableComponentLink}.
 *
 * @since 6.0
 */
public class FederalAllowableComponentLinkImpl extends SingleTableLogicallyDeleteableEntityImpl<FederalAllowableComponentLinkDtls>
  implements FederalAllowableComponentLink {

  /**
   * Reference to Federal Allowable Component DAO.
   */
  @Inject
  protected FederalAllowableComponentDAO federalAllowableComponentDAO;

  /**
   * Reference to Federal Allowable Component Link DAO.
   */
  @Inject
  protected FederalAllowableComponentLinkDAO federalAllowableComponentLinkDAO;

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {

    // ensure that the record we are creating the link for is not already
    // linked to a federal component, i.e. there should only be one Federal
    // Allowable Component Link
    // for the related record, which is the one just added in the current
    // transaction.
    List<FederalAllowableComponentLink> links = federalAllowableComponentLinkDAO.searchActiveByFederalAllowableComponentAndRelatedRecord(
      getFederalAllowableComponent(),
      FEDALLOWCOMPRELATEDTYPEEntry.get(getDtls().relatedType));

    for (FederalAllowableComponentLink link : links) {
      if (link.getID() == getID()) {
        continue;
      }
      if ((link.getRelatedID() == getRelatedID())
        && (link.getFederalAllowableComponent()
          == getFederalAllowableComponent())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_XRV_ACTIVITY_ALREADY_LINKED_TO_FEDERAL_COMPONENT(
            getFederalAllowableComponent().getName(),
            getRelatedType().getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

    if ((!getFederalAllowableComponent().getEndDate().isZero())
      && (getFederalAllowableComponent().getEndDate().before(
        Date.getCurrentDate()))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_FV_FEDERAL_ALLOWABLE_COMPONENT_END_DATED_CANNOT_LINK(
          getFederalAllowableComponent().getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (getFederalAllowableComponent().getLifecycleState().equals(
      RECORDSTATUSEntry.CANCELLED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_FV_FEDERAL_ALLOWABLE_COMPONENT_CANCELLED_CANNOT_LINK(
          getFederalAllowableComponent().getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none needed
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {
    if (0 == getDtls().federalAllowableComponentID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_FV_FEDERAL_ALLOWABLE_COMPONENT_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if (0 == getDtls().relatedID) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_FV_RELATED_ID_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if (StringHelper.isEmpty(getDtls().relatedType)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        FEDERALALLOWABLECOMPONENTExceptionCreator.ERR_FV_RELATED_TYPE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public FederalAllowableComponent getFederalAllowableComponent() {
    return federalAllowableComponentDAO.get(
      getDtls().federalAllowableComponentID);
  }

  /**
   * {@inheritDoc}
   */
  public long getRelatedID() {
    return getDtls().relatedID;
  }

  /**
   * {@inheritDoc}
   */
  public FEDALLOWCOMPRELATEDTYPEEntry getRelatedType() {
    return FEDALLOWCOMPRELATEDTYPEEntry.get(getDtls().relatedType);
  }

  /**
   * {@inheritDoc}
   */
  public void setFederalAllowableComponent(
    final FederalAllowableComponent federalAllowableComponent) {
    if (null != federalAllowableComponent) {
      getDtls().federalAllowableComponentID = federalAllowableComponent.getID();
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedID(final long relatedID) {
    getDtls().relatedID = relatedID;
  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedType(final FEDALLOWCOMPRELATEDTYPEEntry relatedType) {
    getDtls().relatedType = relatedType.getCode();
  }

}
