/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2010, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.federalallowablecomponent.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.FEDALLOWCOMPRELATEDTYPEEntry;
import curam.util.persistence.StandardDAO;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;

import java.util.List;


/**
 * This interface is used to access the data of federal allowable component.
 */
@ImplementedBy(FederalAllowableComponentDAOImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface FederalAllowableComponentDAO extends
    StandardDAO<FederalAllowableComponent> {

  /**
   * Returns a list of active {@link FederalAllowableComponent}. The list is
   * sorted by the start date on the records.
   *
   * @return a list of active {@link FederalAllowableComponent} records in the
   * system.
   */
  public List<FederalAllowableComponent> listActive();

  /**
   * Returns a list of all active {@link FederalAllowableComponent} that are
   * linked to the given related record.
   *
   * @param relatedID
   * The identifier of the related record to search by
   * @param relatedType
   * The type of related record to search by
   * @return A list of all active federal allowable components for the given
   * related record
   */
  public List<FederalAllowableComponent> listActiveByRelatedRecord(
    final long relatedID, final FEDALLOWCOMPRELATEDTYPEEntry relatedType);
}
