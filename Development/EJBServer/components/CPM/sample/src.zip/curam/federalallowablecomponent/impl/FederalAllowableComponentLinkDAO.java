/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.federalallowablecomponent.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.FEDALLOWCOMPRELATEDTYPEEntry;
import curam.util.persistence.StandardDAO;
import java.util.List;


/**
 * Data retrieval operations for the {@link FederalAllowableComponentLink}
 * entity.
 *
 * @curam .nonimplementable
 * @since 6.0
 */
@ImplementedBy(FederalAllowableComponentLinkDAOImpl.class)
interface FederalAllowableComponentLinkDAO extends
    StandardDAO<FederalAllowableComponentLink> {

  /**
   * Returns a list of active {@link FederalAllowableComponentLink} records for
   * the specified related record.
   *
   * @param relatedID
   * unique identifier of the related record
   * @param relatedType
   * code table code for the type of the related record
   * @return a list of {@link FederalAllowableComponentLink} records for the
   * specified related record
   */
  List<FederalAllowableComponentLink> searchActiveByRelatedRecord(
    long relatedID, FEDALLOWCOMPRELATEDTYPEEntry relatedType);

  /**
   * Returns a list of active {@link FederalAllowableComponentLink} records for
   * the specified {@link FederalAllowableComponent}.
   *
   * @param federalAllowableComponent
   * object instance of the linked {@link FederalAllowableComponent}
   * @return a list of {@link FederalAllowableComponentLink} records for the
   * specified {@link FederalAllowableComponent}
   */
  List<FederalAllowableComponentLink> searchActiveByFederalAllowableComponent(
    FederalAllowableComponent federalAllowableComponent);

  /**
   * Returns a list of active {@link FederalAllowableComponentLink} records for
   * the specified {@link FederalAllowableComponent} and related type.
   *
   * @param federalAllowableComponent
   * object instance of the linked {@link FederalAllowableComponent}
   * @param relatedType
   * code table code for the type of the related record
   * @return a list of {@link FederalAllowableComponentLink} records for the
   * specified {@link FederalAllowableComponent} and related type
   */
  List<FederalAllowableComponentLink> searchActiveByFederalAllowableComponentAndRelatedRecord(
    FederalAllowableComponent federalAllowableComponent,
    FEDALLOWCOMPRELATEDTYPEEntry relatedType);

  /**
   * Returns an active {@link FederalAllowableComponentLink} record for the
   * specified {@link FederalAllowableComponent}, related record and status, if
   * one exists, otherwise null is returned.
   *
   * @param federalAllowableComponent
   * object instance of the linked {@link FederalAllowableComponent}
   * @param relatedID
   * unique identifier of the related record
   * @param relatedType
   * code table code for the type of the related record
   * @return a list of active {@link FederalAllowableComponentLink} records for
   * the specified {@link FederalAllowableComponent} and related record
   */
  FederalAllowableComponentLink readActiveByFederalAllowableComponentAndRelatedRecord(
    final FederalAllowableComponent federalAllowableComponent,
    final long relatedID, FEDALLOWCOMPRELATEDTYPEEntry relatedType);

}
