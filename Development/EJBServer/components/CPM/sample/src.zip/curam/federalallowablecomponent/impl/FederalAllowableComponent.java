/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2010, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.federalallowablecomponent.impl;


import com.google.inject.ImplementedBy;
import curam.codetable.impl.CACLIENTPAIDSTATUSEntry;
import curam.codetable.impl.COUNTABLETYPEEntry;
import curam.codetable.impl.FEDALLOWCOMPRELATEDTYPEEntry;
import curam.piwrapper.caseconfiguration.impl.Product;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.StandardEntity;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Date;
import curam.util.type.StringHelper;
import curam.workspaceservices.localization.impl.LocalizableText;
import java.util.List;


/**
 * This business interface maintains federal allowable component.Federal
 * allowable components are associated with one or more activities (e.g.
 * actions). If a client participates in any of these activities, their hours
 * will be counted under the federal allowable component.
 */
@ImplementedBy(FederalAllowableComponentImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface FederalAllowableComponent extends StandardEntity, Insertable,
    OptimisticLockModifiable, LogicallyDeleteable {

  /**
   * Reads the localizable name of the {@link FederalAllowableComponent} in the
   * current program locale.
   *
   * @return The localizable name of the {@link FederalAllowableComponent} in
   * the current program locale
   */
  String getName();

  /**
   * Reads the localizable name of the {@link FederalAllowableComponent}.
   *
   * @return The localizable name of the {@link FederalAllowableComponent}
   */
  LocalizableText getNameLocalizableText();

  /**
   * Sets the localizable name of the {@link FederalAllowableComponent}.
   * Whitespace is {@link StringHelper#trimExternal(String) trimmed} from the
   * name before it is saved. This is a mandatory field and must be unique.
   *
   * @param name
   * The name of the {@link FederalAllowableComponent}
   */
  void setName(String name);

  /**
   * Reads the localizable description of the {@link FederalAllowableComponent}
   * in the current program locale.
   *
   * @return The localizable description of the
   * {@link FederalAllowableComponent} in the current program locale
   */
  String getDescription();

  /**
   * Reads the localizable description of the {@link FederalAllowableComponent}.
   *
   * @return The localizable description of the
   * {@link FederalAllowableComponent}
   */
  LocalizableText getDescriptionLocalizableText();

  /**
   * Sets the localizable description of the {@link FederalAllowableComponent}.
   * This is an optional field.
   *
   * @param description
   * The description of the federal allowable component
   */
  void setDescription(String description);

  /**
   * Gets the start date of the federal allowable component.
   *
   * @return curam date for the start date of the federal allowable component
   */
  Date getStartDate();

  /**
   * Sets the start date for the federal allowable component.
   *
   * @param startDate
   * curam date for the start date of the federal allowable component
   */
  void setStartDate(Date startDate);

  /**
   * Gets the end date of the federal allowable component.
   *
   * @return curam date for the end date of the federal allowable component
   */
  Date getEndDate();

  /**
   * Sets the end date for the federal allowable component.
   *
   * @param endDate
   * curam date for the end date of the federal allowable component
   */
  void setEndDate(Date endDate);

  /**
   * Gets the boolean property for whether or not projection is allowed for the
   * federal allowable component.
   *
   * @return boolean property for whether or not projection is allowed for the
   * federal allowable component.
   */
  boolean isProjectionAllowed();

  /**
   * Sets the boolean property for whether or not projection is allowed for the
   * federal allowable component.
   *
   * @param projectionAllowedInd
   * boolean property for whether or not projection is allowed for the
   * federal allowable component.
   */
  void setProjectionAllowed(boolean projectionAllowedInd);

  /**
   * Gets the countable type code for the federal allowable component, e.g.Core,
   * Non core.
   *
   * @return the countable type code for the federal allowable component
   */
  COUNTABLETYPEEntry getCountableType();

  /**
   * Sets the countable type code for the federal allowable component, e.g.Core,
   * Non core.
   *
   * @param countableType
   * the countable type code for the federal allowable component
   */
  void setCountableType(COUNTABLETYPEEntry countableType);

  /**
   * Gets the CA client paid status, federal allowable components can be either
   * in a status of paid or unpaid.
   *
   * @return the CA client paid status of the federal allowable component
   */
  CACLIENTPAIDSTATUSEntry getCAClientPaidStatus();

  /**
   * Sets the CA client paid status, federal allowable components can be either
   * in a status of paid or unpaid.
   *
   * @param caClientPaidStatus
   * the CA client paid status of the federal allowable component
   */
  void setCAClientPaidStatus(CACLIENTPAIDSTATUSEntry caClientPaidStatus);

  /**
   * Creates a link between the federal allowable component and the related
   * record.
   *
   * @param relatedID
   * unique identifier of the related record
   * @param relatedType
   * code representing the type of the related record
   * @throws InformationalException
   * Generic Exception Signature
   */
  public void addFederalAllowableComponentLink(long relatedID,
    FEDALLOWCOMPRELATEDTYPEEntry relatedType) throws InformationalException;

  /**
   * Updates the records of the specified type, which are linked to the federal
   * allowable component. Any records in the tab delimited identifier list which
   * are not already linked to the federal allowable component will now be
   * linked, and any existing links of this related type for the federal
   * allowable component which are not in the list, will be canceled.
   *
   * @param tabbedRelatedIDList
   * tab delimited list of the related record identifiers
   * @param relatedType
   * type of the related records
   * @throws InformationalException
   * Generic Exception Signature
   */
  public void updateFederalAllowableComponentLinks(String tabbedRelatedIDList,
    FEDALLOWCOMPRELATEDTYPEEntry relatedType) throws InformationalException;

  /**
   * Returns a list of {@link curam.piwrapper.caseconfiguration.impl.Product}
   * records linked to the federal allowable component.
   *
   * @return a list of product object instances which are linked to the federal
   * allowable component
   */
  public List<Product> listPrograms();

  /**
   * Returns a list of the
   * {@link curam.outcomeplanning.outcomeplan.impl.OutcomePlanActionAdmin}
   * records which are linked to the federal allowable component.
   *
   * @param relatedType
   * TODO
   * @return list of {@link FederalAllowableComponentLink} object instances for
   * the specified related type
   */
  public List<FederalAllowableComponentLink> listLinksByRelatedType(
    final FEDALLOWCOMPRELATEDTYPEEntry relatedType);

  /**
   * Returns a list of the {@link curam.serviceoffering.impl.ServiceOffering}
   * records which are linked to the federal allowable component of the
   * specified link type. i.e. service offering, referral service offering
   *
   * @param relatedType
   * type of the service offering link records to list
   * @return list of {@link curam.serviceoffering.impl.ServiceOffering} object
   * instances
   */
  // public List<ServiceOffering> listLinkedServiceOfferings(
  // FEDALLOWCOMPRELATEDTYPEEntry relatedType);
  /**
   * Removes a link between a federal allowable component and an activity.
   *
   * @param activityID
   * unique identifier of the activity
   * @param relatedType
   * type of the activity
   * @throws InformationalException
   * Generic Exception Signature
   */
  public void removeActivityLink(long activityID,
    FEDALLOWCOMPRELATEDTYPEEntry relatedType) throws InformationalException;
}
