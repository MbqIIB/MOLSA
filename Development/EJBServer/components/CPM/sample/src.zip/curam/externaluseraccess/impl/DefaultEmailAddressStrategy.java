/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.externaluseraccess.impl;


import curam.cpm.impl.CPMConstants;
import curam.util.persistence.GuiceWrapper;


/**
 * A provider, provider group, provider member and provider group
 * members may need an external user account to access information
 * within the system. The system will then send an email to the user.
 *
 * This class implements the email address used to send an email
 * to the new external user and gives the default implementation for email
 */
public class DefaultEmailAddressStrategy implements ExternalUserEmailAddressStrategy {

  /**
   * Constructor
   */
  public DefaultEmailAddressStrategy() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getEmailAddress() {
    return CPMConstants.kDefaultEmail;
  }

}
