/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.externaluseraccess.impl;


import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Random;

import curam.cpm.impl.CPMConstants;
import curam.util.exception.AppRuntimeException;


/**
 * {@inheritDoc} 
 */
// BEGIN, CR00177241, PM
public class DefaultUserPasswordStrategy implements ExternalUserPasswordStrategy {
  // END, CR00177241

  /**
   * {@inheritDoc} 
   */
  public String getPassword() {

    try {
      // Create a secure random number generator
      SecureRandom sr = SecureRandom.getInstance(
        CPMConstants.kSecureAlgorithmName);

      // Create two secure number generators with the same seed
      int seedByteCount = 20;
      byte[] seed = sr.generateSeed(seedByteCount);

      sr.setSeed(seed);
      int passwordInt = Math.abs(sr.nextInt());

      String passwordString = Integer.toString(passwordInt);
      String testString = CPMConstants.kAlphabet;

      String lettersNumbersString = passwordString + testString;

      return randomString(lettersNumbersString, 10);

    } catch (NoSuchAlgorithmException en) {
      // BEGIN CR00093739, RD
      throw new AppRuntimeException(en);
      // END CR00093739
    }

  }

  /**
   * This method generates a random string of a specified length.
   *
   * @param chars Contains string used to generate the new random string
   * @param length Contains the length of the new string.
   *
   * @return the random string
   */
  // BEGIN, CR00177241, PM
  protected String randomString(String chars, int length) {
    // END, CR00177241

    StringBuffer buf = new StringBuffer();
    int charCount = chars.length();
    Random random = new Random();

    for (int count = 0; count < length; count++) {
      int index = random.nextInt(charCount);

      buf.append(chars.charAt(index));
    }
    return buf.toString();
  }
}
