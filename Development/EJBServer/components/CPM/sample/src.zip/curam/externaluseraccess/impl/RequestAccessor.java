/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.externaluseraccess.impl;


import curam.provider.impl.ProviderOrganizationAccessor;
import curam.util.persistence.StandardEntity;
import curam.util.type.Date;


/**
 * Accessor interface for Request 
 * {@linkplain curam.externaluseraccess.impl.Request}.
 *
 */
public interface RequestAccessor extends StandardEntity {
  
  /**
   * Gets the reason why the request was rejected.
   *
   * @return Rejection Reason
   */
  public String getRejectionReason();
  
  /**
   * Gets the type of the request.
   *
   * @return Request Type
   */
  public RequestTypeEntry getRequestType();

  /**
   * Gets the category of the request.
   *
   * @return Request Category
   */
  public RequestCategoryEntry getRequestCategory();

  /**
   * Gets the date when then the request was created.
   *
   * @return Date created
   */
  public Date getDateCreated();

  /**
   * Gets the date when then the request was submitted.
   *
   * @return submitted
   */
  public Date getDateSubmitted();

  /**
   * Gets the name of the person who created the request.
   *
   * @return The person who created this request.
   */
  public String getCreatedBy();
  
  /**
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   * </p>
   *
   * @return The provider organization.
   */
  public ProviderOrganizationAccessor getProviderOrganization();
  
}
