/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2013. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.externaluseraccess.impl;


import com.google.inject.ImplementedBy;

import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Implementable;


// BEGIN, CR00377535, GA
/**
 * A provider, provider group, provider member and provider group
 * members may need an external user account to access information
 * within the system. The system will then send an email to the user.
 * This interface defines the email address used to send an email
 * to the new external user.
 *
 * The default implementation of this interface can be replaced with a new
 * custom implementation by creating a new Guice module class and adding a
 * corresponding entry in the MODULE table. Chapter 5 - Creating a Guice Module
 * - in the Persistence Cookbook explains this in detail.
 *
 * A new implementation of this interface is required to change the mechanism
 * used to define the email address used to send an email
 * to the new external user.
 */
@ImplementedBy (DefaultEmailAddressStrategy.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ExternalUserEmailAddressStrategy {

  /**
   * Returns the email address used to send an email
   * to a new external user.
   *
   * The default implementation returns the email address - cpm@default.com
   *
   * @return The email address.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  public String getEmailAddress();
  // END, CR00377535

}
