/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.externaluseraccess.impl;


import java.util.HashMap;
import java.util.Map;

import com.google.inject.Inject;

import curam.cpm.eua.entity.impl.RequestAdapter;
import curam.cpm.eua.entity.struct.RequestDtls;
import curam.cpm.impl.CPMConstants;
import curam.cpm.message.impl.REQUESTExceptionCreator;
import curam.externaluseraccess.RequestType;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.EntityAdapter;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.BasePlusConcreteTableImpl;
import curam.util.persistence.helper.CodetableState;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.State;
import curam.util.persistence.helper.Transition;
import curam.util.type.CodetableHelper;
import curam.util.type.Date;
import curam.util.type.DeepCloneable;
import curam.util.type.StringHelper;


/**
 * @param <CONCRETE_ENTITY>
 * @param <CONCRETE_CLASS_DTLS_STRUCT>
 *
 * Standard implementation of
 * {@linkplain curam.externaluseraccess.impl.Request}.
 */
public abstract class RequestImpl<CONCRETE_ENTITY extends Request, CONCRETE_CLASS_DTLS_STRUCT extends DeepCloneable> extends BasePlusConcreteTableImpl<Long, CONCRETE_ENTITY, RequestDtls, CONCRETE_CLASS_DTLS_STRUCT>
  implements Request {
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for accept events.
   */
  @Inject
  protected EventDispatcherFactory<RequestAcceptEvents> acceptEventDispatcherFactory;

  /**
   * Event dispatcher for submit events.
   */
  @Inject
  protected EventDispatcherFactory<RequestSubmitEvents> submitEventDispatcherFactory;

  /**
   * Event dispatcher for reject events.
   */
  @Inject
  protected EventDispatcherFactory<RequestRejectEvents> rejectEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<RequestCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<RequestInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<RequestModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  // END, CR00183213
  protected RequestImpl() {// BEGIN, CR00183213, SS
    // The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public ProviderOrganization getProviderOrganization() {
    return providerOrganizationDAO.get(getBaseRowDtls().concernRoleID);
  }

  /**
   * {@inheritDoc}
   */
  public String getRejectionReason() {

    return getBaseRowDtls().rejectionReason;
  }

  /**
   * {@inheritDoc}
   */
  public RequestCategoryEntry getRequestCategory() {

    return RequestCategoryEntry.get(getBaseRowDtls().requestCategory);
  }

  /**
   * {@inheritDoc}
   */
  public RequestTypeEntry getRequestType() {

    return RequestTypeEntry.get(getBaseRowDtls().requestType);
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {

    return getBaseRowDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  public Date getDateCreated() {

    return getBaseRowDtls().dateCreated;
  }

  /**
   * {@inheritDoc}
   */
  public Date getDateSubmitted() {

    return getBaseRowDtls().dateSubmitted;
  }

  /**
   * {@inheritDoc}
   */
  public RequestStatusEntry getLifecycleState() {

    return RequestStatusEntry.get(getBaseRowDtls().requestStatus);
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderOrganization(ProviderOrganization providerOrganization) {

    getBaseRowDtls().concernRoleID = providerOrganization.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setComments(String comments) {

    getBaseRowDtls().comments = StringHelper.trim(comments);

    // Validate string length
    if (getComments().length() > RequestAdapter.kMaxLength_comments) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REQUESTExceptionCreator.ERR_REQUEST_FV_COMMENTS_MUST_BE_LT_OR_EQ(
          getComments().length(), RequestAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected void setDiscriminator(final String value) {

    final RequestCategoryEntry category = RequestCategoryEntry.get(value);

    getBaseRowDtls().requestCategory = category.getCode();

  }

  /**
   * {@inheritDoc}
   */
  // START CR00094326, JSP
  public void setRequestType(final RequestTypeEntry requestType) {

    getBaseRowDtls().requestType = requestType.getCode();
    // END CR00094326
  }

  /**
   * */
  // BEGIN, CR00177241, PM
  protected void transitionTo(final State<RequestStatusEntry> newState,
    final Integer versionNo) throws InformationalException {
    // END, CR00177241
    // get the state validator for the current request status
    final State<RequestStatusEntry> oldState = states.get(getLifecycleState());

    // set the field which stores the status
    getBaseRowDtls().requestStatus = newState.getValue().getCode();

    // do the state transition
    oldState.transitionTo(newState);

    // update the database
    modify(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void submit(int versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre submit request event.
    submitEventDispatcherFactory.get(RequestSubmitEvents.class).preSubmit(this,
      versionNo);
    // END, CR00235789

    getBaseRowDtls().dateSubmitted = Date.getCurrentDate();
    transitionTo(submitted, versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post submit request event.
    submitEventDispatcherFactory.get(RequestSubmitEvents.class).postSubmit(this,
      versionNo);
    // END, CR00235789

  }

  /**
   * {@inheritDoc}
   */
  public void accept(int versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre accept request event.
    acceptEventDispatcherFactory.get(RequestAcceptEvents.class).preAccept(this,
      versionNo);
    // END, CR00235789

    transitionTo(accepted, versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post accept request event.
    acceptEventDispatcherFactory.get(RequestAcceptEvents.class).postAccept(this,
      versionNo);
    // END, CR00235789

  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No validations
  }

  /**
   * {@inheritDoc}
   */
  public void reject(int versionNo, String rejectionReason)
    throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre reject request event.
    rejectEventDispatcherFactory.get(RequestRejectEvents.class).preReject(this,
      versionNo, rejectionReason);
    // END, CR00235789

    if (rejectionReason.length() > RequestAdapter.kMaxLength_rejectionReason) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REQUESTExceptionCreator.ERR_REQUEST_FV_REJECTIONREASON_MUST_BE_LT_OR_EQ(
          rejectionReason.length(), RequestAdapter.kMaxLength_rejectionReason),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

    } else {

      if (rejectionReason.length() == 0) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          REQUESTExceptionCreator.ERR_REQUEST_FV_REASON_EMPTY(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      // Set Rejection Reason
      getBaseRowDtls().rejectionReason = StringHelper.trim(rejectionReason);
      transitionTo(rejected, versionNo);
    }

    // BEGIN, CR00235789, AK
    // Raise the post reject request event.
    rejectEventDispatcherFactory.get(RequestRejectEvents.class).postReject(this,
      versionNo, rejectionReason);
    // END, CR00235789

  }

  /**
   * {@inheritDoc}
   */
  public void cancel(int versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre cancel request event.
    cancelEventDispatcherFactory.get(RequestCancelEvents.class).preCancel(this,
      versionNo);
    // END, CR00235789

    transitionTo(canceled, versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post cancel request event.
    cancelEventDispatcherFactory.get(RequestCancelEvents.class).postCancel(this,
      versionNo);
    // END, CR00235789

  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {
    // set the default values
    getBaseRowDtls().requestStatus = RequestStatusEntry.OPEN.getCode();
    getBaseRowDtls().dateCreated = Date.getCurrentDate();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected EntityAdapter<Long, RequestDtls> getBaseEntityAdapter() {
    return new RequestAdapter();
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {

    // Validate requestType against requestCategory
    CodetableHelper.validateParentCode(RequestType.TABLENAME,
      getRequestType().getCode(), getRequestCategory().getCode());
  }

  /**
   * State for the Request Status Entry
   */
  protected final Map<RequestStatusEntry, State<RequestStatusEntry>> states = new HashMap<RequestStatusEntry, State<RequestStatusEntry>>();

  /**
   * Open status for the Request Status Entry
   */
  protected final State<RequestStatusEntry> open = new CodetableState<RequestStatusEntry>(
    states, RequestStatusEntry.OPEN, true, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      State<RequestStatusEntry> oldState) {
      // Begin CR00096779, ABS
      if (oldState.getValue().equals(RequestStatusEntry.CANCELLED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          REQUESTExceptionCreator.ERR_REQUEST_FV_INVALID_STATUS_CHANGE_TO_SUBMITTED(
            oldState.getValue().getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            1);
      }

    }

  };

  /**
   * Submitted status for the Request Status Entry
   */
  protected final State<RequestStatusEntry> submitted = new CodetableState<RequestStatusEntry>(
    states, RequestStatusEntry.SUBMITTED, true, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      State<RequestStatusEntry> oldState) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REQUESTExceptionCreator.ERR_REQUEST_FV_INVALID_STATUS_CHANGE_TO_SUBMITTED(
          oldState.getValue().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  };

  /**
   * */
  protected final State<RequestStatusEntry> accepted = new CodetableState<RequestStatusEntry>(
    states, RequestStatusEntry.ACCEPTED, true, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      State<RequestStatusEntry> oldState) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REQUESTExceptionCreator.ERR_REQUEST_FV_INVALID_STATUS_CHANGE_TO_ACCEPTED(
          oldState.getValue().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  };

  /**
   * */
  protected final State<RequestStatusEntry> rejected = new CodetableState<RequestStatusEntry>(
    states, RequestStatusEntry.REJECTED, true, false) {

    @Override
    protected void onEnter() {}

    @Override
    protected void onUnsupportedTransitionFrom(
      State<RequestStatusEntry> oldState) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REQUESTExceptionCreator.ERR_REQUEST_FV_INVALID_STATUS_CHANGE_TO_REJECTED(
          oldState.getValue().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  };

  /**
   * */
  protected final State<RequestStatusEntry> canceled = new CodetableState<RequestStatusEntry>(
    states, RequestStatusEntry.CANCELLED, true, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      State<RequestStatusEntry> oldState) {
      
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        REQUESTExceptionCreator.ERR_REQUEST_XRV_INVALID_STATUS_OPEN_CHANGE_TO_CANCELLED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      
    }
  };

  /**
   * */
  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<RequestStatusEntry> open2Submitted = new Transition<RequestStatusEntry>(
    open, submitted) {

    @Override
    protected void onTransition() {

      // call validation method
      submitValidation();

      super.onTransition();
    }

  };

  /**
   * */
  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<RequestStatusEntry> submitted2Accepted = new Transition<RequestStatusEntry>(
    submitted, accepted) {// Uses default implementation
  };

  /**
   * */
  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<RequestStatusEntry> submitted2Rejected = new Transition<RequestStatusEntry>(
    submitted, rejected) {// Uses default implementation
  };

  /**
   * */
  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<RequestStatusEntry> open2Canceled = new Transition<RequestStatusEntry>(
    open, canceled) {// Uses default implementation
  };

  /**
   * {@inheritDoc}
   *
   */
  public void crossEntityValidation() {// none required
  }

  /**
   * Abstract method that must be implemented by the subclass. This method gets
   * called when a request goes from a state of open to Submitted.
   */
  public abstract void submitValidation();

  /**
   * {@inheritDoc}
   *
   */
  public void setCreatedBy(String createdBy) {
    getBaseRowDtls().createdBy = createdBy;
  }

  /**
   * {@inheritDoc}
   */
  public String getCreatedBy() {
    return getBaseRowDtls().createdBy;
  }

  /**
   * Inserts the request and also rises the pre and post insert for request.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert request event.
    insertEventDispatcherFactory.get(RequestInsertEvents.class).preInsert(this);

    super.insert();

    // Raise the post insert request event.
    insertEventDispatcherFactory.get(RequestInsertEvents.class).postInsert(this);
    // END, CR00235789
  }

  /**
   * Modifies the request and also rises the pre and post modification.
   *
   * @param versionNo
   * The version no for existing request data.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre modify request event.
    modifyEventDispatcherFactory.get(RequestModifyEvents.class).preModify(this,
      versionNo);

    super.modify(versionNo);

    // Raise the post modify request event.
    modifyEventDispatcherFactory.get(RequestModifyEvents.class).postModify(this,
      versionNo);
  }
  // END, CR00235789

}
