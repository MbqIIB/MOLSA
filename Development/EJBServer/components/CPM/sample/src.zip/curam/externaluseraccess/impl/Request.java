/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.externaluseraccess.impl;


import com.google.inject.ImplementedBy;

import curam.provider.impl.ProviderOrganization;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.Lifecycle;


/**
 * Details of the request created through external user access. For example, a
 * provider who has an external user account, can create and submit requests to
 * update the address, payment details etc.,. through the external user access.
 */
@ImplementedBy(RequestImpl.class)
public interface Request extends RequestAccessor, Insertable,
    OptimisticLockModifiable, Lifecycle<RequestStatusEntry>, Commented {

  /**
   * Gets the provider organization.
   *
   * @return the Provider Organization details.
   */
  public ProviderOrganization getProviderOrganization();

  /**
   * Set the provider organization
   *
   * @param providerOrganization
   * The provider organization details.
   */
  public void setProviderOrganization(ProviderOrganization providerOrganization);

  // BEGIN, CR00144284, SK
  /**
   * Set the request type.
   *
   * @param requestType
   * The type of request.
   */
  // END, CR00144284
  // START CR00094326, JSP
  public void setRequestType(final RequestTypeEntry requestType);
  // END CR00094326

  // BEGIN, CR00144284, SK
  /**
   * Transitions the state to
   * {@linkplain curam.externaluseraccess.impl.RequestStatusEntry#SUBMITTED},
   * if valid to do so.
   *
   * @param versionNo
   * version number as previously retrieved
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00144284
  public void submit(int versionNo) throws InformationalException;

  // BEGIN, CR00144284, SK
  /**
   * Transitions the state to
   * {@linkplain curam.externaluseraccess.impl.RequestStatusEntry#ACCEPTED}, if
   * valid to do so.
   *
   * @param versionNo
   * The version number as previously retrieved
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  // END, CR00144284
  public void accept(int versionNo) throws InformationalException;

  // BEGIN, CR00144284, SK
  /**
   * Transitions the state to
   * {@linkplain curam.externaluseraccess.impl.RequestStatusEntry#REJECTED}, if
   * valid to do so.
   *
   * @param versionNo
   * version no. as previously retrieved
   * @param rejectionReason
   * Resource Manager's reason for rejecting the request.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @see curam.externaluseraccess.impl.RequestImpl#reject(int, String) The
   * default implementation -
   * curam.externaluseraccess.impl.RequestImpl#reject(int, String)
   */
  // END, CR00144284
  public void reject(int versionNo, String rejectionReason)
    throws InformationalException;

  // BEGIN, CR00144284, SK
  /**
   * Transitions the state to
   * {@linkplain curam.externaluseraccess.impl.RequestStatusEntry#CANCELLED},
   * if valid to do so.
   *
   * @param versionNo
   * The version number as previously retrieved
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.externaluseraccess.impl.RequestImpl#cancel(int) The default
   * implementation - curam.externaluseraccess.impl.RequestImpl#cancel(int)
   */
  // END, CR00144284
  public void cancel(int versionNo) throws InformationalException;

  /**
   * Sets the creator of the request.
   *
   * @param createdBy
   * The concern who created this request.
   */
  public void setCreatedBy(final String createdBy);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the request events functionality surrounding the accept
   * method.
   */
  public interface RequestAcceptEvents {

    /**
     * Event interface invoked before the main body of the accept method.
     * {@linkplain curam.externaluseraccess.impl.Request#accept}
     *
     * @param request
     * The object instance as it was before the main body of the accept
     * method.
     * @param versionNo
     * The parameter as passed to the accept method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preAccept(RequestAccessor request, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the accept method.
     * {@linkplain curam.externaluseraccess.impl.Request#accept}
     *
     * @param request
     * The object instance as it was after the main body of the accept
     * method.
     * @param versionNo
     * The parameter as passed to the accept method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postAccept(RequestAccessor request, int versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the request events functionality surrounding the submit
   * method.
   */
  public interface RequestSubmitEvents {

    /**
     * Event interface invoked before the main body of the submit method.
     * {@linkplain curam.externaluseraccess.impl.Request#submit}
     *
     * @param request
     * The object instance as it was before the main body of the submit
     * method.
     * @param versionNo
     * The parameter as passed to the submit method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preSubmit(RequestAccessor request, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the submit method.
     * {@linkplain curam.externaluseraccess.impl.Request#submit}
     *
     * @param request
     * The object instance as it was after the main body of the submit
     * method.
     * @param versionNo
     * The parameter as passed to the submit method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postSubmit(RequestAccessor request, int versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the request events functionality surrounding the reject
   * method.
   */
  public interface RequestRejectEvents {

    /**
     * Event interface invoked before the main body of the reject method.
     * {@linkplain curam.externaluseraccess.impl.Request#reject}
     *
     * @param request
     * The object instance as it was before the main body of the reject
     * method.
     * @param versionNo
     * The parameter as passed to the reject method.
     * @param rejectionReason
     * The parameter as passed to the reject method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preReject(RequestAccessor request, int versionNo,
      String rejectionReason) throws InformationalException;

    /**
     * Event interface invoked after the main body of the reject method.
     * {@linkplain curam.externaluseraccess.impl.Request#reject}
     *
     * @param request
     * The object instance as it was after the main body of the reject
     * method.
     * @param versionNo
     * The parameter as passed to the reject method.
     * @param rejectionReason
     * The parameter as passed to the reject method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postReject(RequestAccessor request, int versionNo,
      String rejectionReason) throws InformationalException;
  }


  /**
   * Interface to the request events functionality surrounding the cancel
   * method.
   */
  public interface RequestCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.externaluseraccess.impl.Request#cancel}
     *
     * @param request
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(RequestAccessor request, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.externaluseraccess.impl.Request#cancel}
     *
     * @param request
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(RequestAccessor request, int versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the request events functionality surrounding the insert
   * method.
   */
  public interface RequestInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.externaluseraccess.impl.Request#insert}
     *
     * @param request
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(RequestAccessor request)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.externaluseraccess.impl.Request#insert}
     *
     * @param request
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(RequestAccessor request)
      throws InformationalException;
  }


  /**
   * Interface to the request events functionality surrounding the modify
   * method.
   */
  public interface RequestModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.externaluseraccess.impl.Request#modify}
     *
     * @param request
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(RequestAccessor request, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.externaluseraccess.impl.Request#modify}
     *
     * @param request
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(RequestAccessor request, Integer versionNo)
      throws InformationalException;
  }
  // END, CR00144381
}
