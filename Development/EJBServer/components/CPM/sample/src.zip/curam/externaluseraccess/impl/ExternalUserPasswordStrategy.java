/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.externaluseraccess.impl;


import com.google.inject.ImplementedBy;

import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Implementable;


/**
 * A provider or provider group may need an external user
 * account to access information within the system. The provider
 * or provider group will need a password for this user account. The
 * provider or provider group can also request an external user
 * account for a member.
 *
 * This interface defines the method for generating the password
 * for this external user. A default getPassword method is provided,
 * however this can be customized.
 *
 */
@ImplementedBy(DefaultUserPasswordStrategy.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ExternalUserPasswordStrategy {

  /**
   * This method generates a password for an External User account. This
   * password is alphanumeric.
   *
   * @return the generated password.
   *
   * @see curam.externaluseraccess.impl.DefaultUserPasswordStrategy#getPassword()
   * The default implementation -
   * {@link curam.externaluseraccess.impl.DefaultUserPasswordStrategy#getPassword()}.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  public String getPassword();

}
