/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.externaluseraccess.impl;


import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.cpm.eua.entity.impl.RequestAdapter;
import curam.cpm.eua.entity.struct.RequestDtls;
import curam.externaluseraccess.RequestCategory;
import curam.provider.impl.ProviderOrganization;
import curam.util.persistence.BaseDAOImpl;
import curam.util.persistence.ReaderDAO;
import curam.util.persistence.RowManager;
import curam.util.type.Date;


// BEGIN, CR00178057, GP
/**
 * Standard implementation of {@linkplain RequestDAO}.
 */
// END, CR00178057
@Singleton
// BEGIN, CR00183213, SS
public class RequestDAOImpl extends BaseDAOImpl<Long, Request, RequestDtls>
  implements RequestDAO {
  // END, CR00183213

  protected static final RequestAdapter adapter = new RequestAdapter();

  @Inject
  protected ServiceInvoiceRequestDAO serviceInvoiceRequestDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected RequestDAOImpl() {
    // END, CR00183213
    super(adapter, Request.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<Request> searchByRequestTypeOwnerAndCreationDate(
    RequestTypeEntry requestType, final String userName,
    final Date dateCreated) {

    return newSet(
      adapter.searchByRequestTypeOwnerAndCreationDate(requestType.getCode(),
      dateCreated, userName));
  }

  /**
   * {@inheritDoc}
   */
  public Set<Request> searchByRequestTypeAndOwner(RequestTypeEntry requestType,
    final String userName, final Date dateCreated) {

    return newSet(
      adapter.searchByRequestTypeAndOwner(requestType.getCode(), dateCreated,
      userName));
  }

  // BEGIN, CR00216313, RD
  /**
   * {@inheritDoc}
   */
  public Set<Request> searchByOwnerAndDateRange(String userName,
    Date startDate, Date endDate) {
    return newSet(
      adapter.searchByOwnerAndDateRange(startDate, endDate, userName));
  }

  // END, CR00216313


  /**
   * {@inheritDoc}
   */
  public Set<Request> searchByCreationDateAndOwner(
    RequestTypeEntry requestType, final String userName,
    final Date dateCreated) {

    return newSet(
      adapter.searchByCreationDateAndOwner(requestType.getCode(), dateCreated,
      userName));
  }

  /**
   * {@inheritDoc}
   */
  public Set<Request> searchByRequestOwnerAndStatus(final String userName,
    final RequestStatusEntry requestStatus) {

    return newSet(
      adapter.searchByRequestOwnerAndStatus(userName, requestStatus.getCode()));
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected String getDiscriminator(
    final RowManager<Long, RequestDtls> rowManager) {
    return rowManager.getDtls().requestCategory;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected Map<String, ReaderDAO<Long, ? extends Request>> getConcreteReaderDAOs() {
    final Map<String, ReaderDAO<Long, ? extends Request>> concreteReaderDAOs = new HashMap<String, ReaderDAO<Long, ? extends Request>>();

    concreteReaderDAOs.put(RequestCategory.SERVICE_INVOICE_REQUEST,
      serviceInvoiceRequestDAO);

    return concreteReaderDAOs;
  }

  /**
   * {@inheritDoc}
   *
   * @param providerOrganization
   */

  public Set<Request> searchBy(final ProviderOrganization providerOrganization) {

    return newSet(adapter.searchByConcernRoleID(providerOrganization.getID()));
  }

}
