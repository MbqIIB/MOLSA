/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.externaluseraccess.impl;


import curam.cpm.eua.sl.impl.ProviderParticipantRequestAdapter;
import curam.cpm.eua.sl.struct.ProviderParticipantRequestDtls;
import curam.cpm.message.impl.PROVIDERPARTICIPANTREQUESTExceptionCreator;
import curam.externaluseraccess.RequestCategory;
import curam.externaluseraccess.RequestType;
import curam.util.persistence.ValidationHelper;
import curam.util.type.Date;
import curam.util.type.StringHelper;


// BEGIN, CR00183213, SS
public class ProviderParticipantRequestImpl extends RequestImpl<ProviderParticipantRequest, ProviderParticipantRequestDtls>
  implements ProviderParticipantRequest {

  /**
   * Constructor for the class.
   */
  protected ProviderParticipantRequestImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public String getType() {

    return getConcreteRowDtls().type;
  }

  /**
   * {@inheritDoc}
   */
  public long getAddressID() {

    return getConcreteRowDtls().addressID;
  }

  /**
   * {@inheritDoc}
   */
  public long getPhoneNumberID() {

    return getConcreteRowDtls().phoneNumberID;
  }

  /**
   * {@inheritDoc}
   */
  public Date getEndDate() {

    return getConcreteRowDtls().endDate;
  }

  /**
   * {@inheritDoc}
   */
  public Date getStartDate() {

    return getConcreteRowDtls().startDate;
  }

  /**
   * {@inheritDoc}
   */
  public String getName() {

    return getConcreteRowDtls().name;
  }

  /**
   * {@inheritDoc}
   */
  public String getReferenceNumber() {

    return getConcreteRowDtls().referenceNumber;
  }

  /**
   * @param referenceNumber
   * A reference number for the provider participant. This is a
   * reference number assigned by the organization to the
   * participant to uniquely identify them.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.cpm.message.PROVIDERPARTICIPANTREQUEST#ERR_REQUEST_FV_REF_MUST_BE_LT_OR_EQ} -
   * If the reference number entered is too long. </li>
   * </ul>
   */

  public void setReferenceNumber(String referenceNumber) {

    getConcreteRowDtls().referenceNumber = StringHelper.trim(referenceNumber);

    // Validate string length
    if (getReferenceNumber().length()
      > ProviderParticipantRequestAdapter.kMaxLength_referenceNumber) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERPARTICIPANTREQUESTExceptionCreator.ERR_REQUEST_FV_REF_MUST_BE_LT_OR_EQ(
          referenceNumber.length(),
          ProviderParticipantRequestAdapter.kMaxLength_referenceNumber),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setAddressID(long addressID) {

    getConcreteRowDtls().addressID = addressID;

  }

  /**
   * {@inheritDoc}
   */
  public void setPhoneNumberID(long phoneNumberID) {

    getConcreteRowDtls().phoneNumberID = phoneNumberID;

  }

  /**
   * {@inheritDoc}
   */
  public void setStartDate(Date startDate) {

    getConcreteRowDtls().startDate = startDate;

  }

  /**
   * {@inheritDoc}
   */
  public void setEndDate(Date endDate) {

    getConcreteRowDtls().endDate = endDate;

  }

  /**
   * {@inheritDoc}
   */
  public void setType(String type) {

    getConcreteRowDtls().type = type;

  }

  /**
   * @param name
   * Name of the person to be added as provider participant or
   * provider group participant.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.cpm.message.PROVIDERPARTICIPANTREQUEST#ERR_REQUEST_FV_NAME_MUST_BE_LT_OR_EQ} -
   * If the name entered is too long. </li>
   * </ul>
   */
  public void setName(String name) {

    getConcreteRowDtls().name = StringHelper.trim(name);

    // Validate string length
    if (getName().length() > ProviderParticipantRequestAdapter.kMaxLength_name) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERPARTICIPANTREQUESTExceptionCreator.ERR_REQUEST_FV_NAME_MUST_BE_LT_OR_EQ(
          name.length(), ProviderParticipantRequestAdapter.kMaxLength_name),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No validations
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected void mapBaseKeyToConcreteDtls() {
    getConcreteRowDtls().requestID = getBaseRowDtls().requestID;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected String getDiscriminatorValue() {
    return RequestCategory.PROVIDER_PARTICIPANT_REQUEST;
  }

  /**
   * {@inheritDoc} Set requestCategory and requestType
   */
  @Override
  public void setNewInstanceDefaults() {

    super.setNewInstanceDefaults();

    getBaseRowDtls().requestCategory = RequestCategory.PROVIDER_PARTICIPANT_REQUEST;

    getBaseRowDtls().requestType = RequestType.INSERT_PROVIDER_PARTICIPANT;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void submitValidation() {// Uses default implementation
  }

}
