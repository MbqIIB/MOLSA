/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.externaluseraccess.impl;


import curam.codetable.APPLICATION_CODE;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.core.impl.CuramConst;
import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.cpm.impl.CPMConstants;
import curam.message.BPOADMINUSER;
import curam.participant.impl.ConcernRole;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.security.EncryptionAdmin;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;


/**
 * This class provides a default implementation for setting
 * the details for an external user account. This is used for the automatic
 * creation of an External User account through the External User Access
 * application. The request for a new account may be made by a provider or
 * provider group. They can then in turn request an account for a provider member
 * or a provider group member.
 *
 *
 */
final class DefaultExternalUserDetailsStrategy implements ExternalUserDetailsStrategy {

  /**
   * Constructor
   */
  public DefaultExternalUserDetailsStrategy() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   *
   * @param concernRole
   * @param password
   *
   * @return The External User details for the External User account.
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ExternalUserDtls setDefaultDetails(ConcernRole concernRole, String password)
    throws AppException, InformationalException {

    ExternalUserDtls externalUserDtls = new ExternalUserDtls();

    // BEGIN, CR00227515, SK
    // both external provider and external provider group have the same
    // application home page.
    if (concernRole.getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDERGROUP)) {
      externalUserDtls.applicationCode = APPLICATION_CODE.CPM_EXTERNAL_PROVIDER_GROUP_HOME;
    } else {
      externalUserDtls.applicationCode = APPLICATION_CODE.CPM_EXTERNAL_PROVIDER_HOME;
    }
    // END, CR00227515

    // set the concern Role type
    if (concernRole.getConcernRoleType().equals(CONCERNROLETYPEEntry.PROVIDER)) {
      externalUserDtls.type = curam.codetable.EXTERNALUSERTYPE.PROVIDER;
    } else {
      // must be provider group
      externalUserDtls.type = curam.codetable.EXTERNALUSERTYPE.PROVGRP;
    }

    // set the details
    externalUserDtls.accountEnabled = true;
    externalUserDtls.creationDate = Date.getCurrentDate();
    externalUserDtls.defaultLocale = TransactionInfo.getProgramLocale();
    externalUserDtls.sensitivity = concernRole.getSensitivity().getCode();
    externalUserDtls.roleName = CPMConstants.kExternalUserSecure;
    externalUserDtls.loginFailures = 0;
    externalUserDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    // Set the password changed date to the current date
    externalUserDtls.passwordChanged = Date.getCurrentDate();

    String fullName = concernRole.getName();
    String surname;
    String firstname;
    // BEGIN, CR00415367, SS
    int surnameIndex = fullName.indexOf(CuramConst.gkSpace);

    if (surnameIndex > 0) {
      surname = fullName.substring(surnameIndex + 1);
      firstname = fullName.substring(0, surnameIndex);
    } else {
      surname = CuramConst.gkEmpty;
      firstname = fullName;
    }

    if (0 == surname.length()) {
      externalUserDtls.firstname = fullName;
      externalUserDtls.surname = fullName;

    } else {
      externalUserDtls.firstname = firstname;
      externalUserDtls.surname = surname;
    }
    externalUserDtls.fullName = concernRole.getName();

    // Encrypt the database password
    try {
      password = EncryptionAdmin.encryptPassword(password);
    } catch (Exception e) {
      AppException wrappedException = new AppException(
        BPOADMINUSER.ERR_ENCRYPTION_FAILED, e);

      wrappedException.setLoggable(true);
      throw wrappedException;
    }
    // END, CR00415367
    externalUserDtls.password = password;
    return externalUserDtls;
  }

  /**
   * {@inheritDoc}
   *
   * @param concernRole
   * @param password
   *
   * @return The External User details for the External User account.
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ExternalUserDtls setDefaultMemberDetails(
    ConcernRole concernRole, String password) throws AppException, InformationalException {

    ExternalUserDtls externalUserDtls = new ExternalUserDtls();

    // set the application code to be the same as the provider/provider group
    externalUserDtls.applicationCode = APPLICATION_CODE.CPM_EXTERNAL_PROVIDER_HOME;

    // set the details
    externalUserDtls.accountEnabled = true;
    externalUserDtls.creationDate = Date.getCurrentDate();
    externalUserDtls.defaultLocale = TransactionInfo.getProgramLocale();
    externalUserDtls.sensitivity = concernRole.getSensitivity().getCode();
    externalUserDtls.roleName = CPMConstants.kExternalUserSecure;
    externalUserDtls.loginFailures = 0;
    externalUserDtls.statusCode = curam.codetable.RECORDSTATUS.DEFAULTCODE;
    // Set the password changed date to the current date
    externalUserDtls.passwordChanged = Date.getCurrentDate();
    externalUserDtls.type = curam.codetable.EXTERNALUSERTYPE.MEMBER;

    // SR: if the concernRoleName is not split into a FirstName, surname, then
    // set the first name and surname to be the concernRoleName, otherwise
    // set the first name to be the name up to the first space, surname is set
    // to everything after the space. NOTE: This will change in the next release
    // where the user will be asked for their first name and their surname
    String fullName = concernRole.getName();
    String surname;
    String firstname;
    // BEGIN, CR00415367, SS
    int surnameIndex = fullName.indexOf(CuramConst.gkSpace);

    if (surnameIndex > 0) {
      surname = fullName.substring(surnameIndex + 1);
      firstname = fullName.substring(0, surnameIndex);
    } else {
      surname = CuramConst.gkEmpty;
      firstname = fullName;
    }

    if (0 == surname.length()) {
      externalUserDtls.firstname = fullName;
      externalUserDtls.surname = fullName;

    } else {
      externalUserDtls.firstname = firstname;
      externalUserDtls.surname = surname;
    }
    externalUserDtls.fullName = concernRole.getName();

    // Encrypt the database password
    try {
      password = EncryptionAdmin.encryptPassword(password);
    } catch (Exception e) {
      AppException wrappedException = new AppException(
        BPOADMINUSER.ERR_ENCRYPTION_FAILED, e);

      wrappedException.setLoggable(true);
      throw wrappedException;
    }
    // END, CR00415367
    externalUserDtls.password = password;
    return externalUserDtls;
  }
}
