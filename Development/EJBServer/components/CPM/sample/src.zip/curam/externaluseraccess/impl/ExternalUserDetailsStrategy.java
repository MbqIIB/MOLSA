/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.externaluseraccess.impl;


import com.google.inject.ImplementedBy;

import curam.core.sl.entity.struct.ExternalUserDtls;
import curam.participant.impl.ConcernRole;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * Within the External User Access application a provider or
 * provider group may wish to gain access to the system. The provider
 * or provider group can request to become an external user. The
 * provider or provider group may also create a new account for their
 * members. We need to set up default details in order to create the
 * External User records.
 * This class provides default details for external user account
 * being set up.
 */

@ImplementedBy (DefaultExternalUserDetailsStrategy.class)
public interface ExternalUserDetailsStrategy {
  // ___________________________________________________________________________
  /**
   * This method sets a number of default details for the creation
   * of an external user account for a provider or provider group.
   *
   * @param concernRole - The concern Role Object containing information about
   * the Provider or Provider Group.
   * @param password - the password for this user account
   *
   * @return - The details for the external user account
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ExternalUserDtls setDefaultDetails(
    ConcernRole concernRole, String password) throws AppException, InformationalException;

  // ___________________________________________________________________________
  /**
   * This method sets a number of default details for the creation
   * of an external user account for a provider member or a provider group
   * member.
   *
   * @param concernRole - The concern Role Object containing information about
   * the Provider Member or Provider Group Member
   * @param password - the password for this user account
   *
   * @return - The details for the external user account
   *
   * @throws InformationalException
   * @throws AppException
   */
  public ExternalUserDtls setDefaultMemberDetails(
    ConcernRole concernRole, String password) throws AppException, InformationalException;
}
