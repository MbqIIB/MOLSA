/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.externaluseraccess.impl;


import curam.util.type.Date;


/**
 * Request created by the external user to add a provider participant.
 *
 */
@com.google.inject.ImplementedBy(ProviderParticipantRequestImpl.class)
public interface ProviderParticipantRequest extends ProviderParticipantRequestAccessor, Request {

  // ___________________________________________________________________________
  /**
   * @param referenceNumber
   * A reference number for the provider participant. This is a reference number
   * assigned by the organization to the participant to uniquely identify them.
   */
  public void setReferenceNumber(String referenceNumber);

  // ___________________________________________________________________________
  /**
   * @param addressID
   * System generated Unique ID for the Provider Participant's address.
   */
  public void setAddressID(long addressID);

  // ___________________________________________________________________________
  /**
   * @param phoneNumberID
   * System generated Unique ID for the Provider Participant's phone number.
   */
  public void setPhoneNumberID(long phoneNumberID);

  // ___________________________________________________________________________
  /**
   * @param name
   * Name of the person to be added as provider participant or
   * provider group participant.
   */
  public void setName(String name);

  // ___________________________________________________________________________
  /**
   * @param type
   * The type of provider participant e.g. Neighbor, Friend, Attorney or Accountant.
   */
  public void setType(String type);

  // ___________________________________________________________________________
  /**
   * @param startDate
   * The date from which the participant is associated to the provider.
   */
  public void setStartDate(Date startDate);

  // ___________________________________________________________________________
  /**
   * @param endDate
   * The last date on which the participant is related to the provider.
   */
  public void setEndDate(Date endDate);

}
