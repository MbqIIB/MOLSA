/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.externaluseraccess.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.provider.impl.ProviderOrganization;
import curam.util.persistence.ReaderDAO;
import curam.util.type.Date;


/**
 * Data access for
 * {@linkplain curam.externaluseraccess.impl.Request}.
 */
@ImplementedBy(RequestDAOImpl.class)
public interface RequestDAO extends ReaderDAO<Long, Request> {

  /**
   * Search by Request Type, Status and Creation Date
   *
   * @param requestType
   * @param userName
   * @param dateCreated
   *
   * @return Set of Requests
   */
  public Set<Request> searchByRequestTypeOwnerAndCreationDate(
    RequestTypeEntry requestType, final String userName, final Date dateCreated);
  
  /**
   * Search by Request Type, Status and Creation Date
   *
   * @param requestType
   * @param userName
   * @param dateCreated
   *
   * @return Set of Requests
   */
  public Set<Request> searchByRequestTypeAndOwner(
    RequestTypeEntry requestType, final String userName, final Date dateCreated);
  
  /**
   * Search by Request Type, Status and Creation Date
   *
   * @param requestType
   * @param userName
   * @param dateCreated
   *
   * @return Set of Requests
   */
  public Set<Request> searchByCreationDateAndOwner(
    RequestTypeEntry requestType, final String userName, final Date dateCreated);

  /**
   * Search by Request Owner and Status
   *
   * @param userName
   * @param requestStatus
   * @return Set of Requests
   */
  public Set<Request> searchByRequestOwnerAndStatus(final String userName,
    final RequestStatusEntry requestStatus);

  /**
   * Search by Provider Organization, this may be a provider or a provider
   * group/
   *
   * @param providerOrganization
   * @return Set of Requests
   */
  public Set<Request> searchBy(
    final ProviderOrganization providerOrganization);
  
  // BEGIN, CR00216313, RD
  /**
   * Searches by Owner and Date Range.
   *
   * @param userName
   * The user name of the owner.
   * @param startDate
   * The start date of the range.
   * @param endDate
   * The end date of the range.
   *
   * @return Set of Requests
   */
  public Set<Request> searchByOwnerAndDateRange(
    final String userName, final Date startDate, final Date endDate);
  // END, CR00216313

}
