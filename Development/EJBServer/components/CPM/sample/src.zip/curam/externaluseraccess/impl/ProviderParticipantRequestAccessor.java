/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.externaluseraccess.impl;


import curam.util.persistence.StandardEntity;
import curam.util.type.Date;


/**
 * Accessor interface for {@linkplain ProviderParticipantRequest}.
 *
 */
public interface ProviderParticipantRequestAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * @return A reference number for the provider participant. This is a reference number
   * assigned by the organization to the participant to uniquely identify them.
   */
  public String getReferenceNumber();

  // ___________________________________________________________________________
  /**
   * @return System generated Unique ID for the Provider Participant's address.
   */
  public long getAddressID();

  // ___________________________________________________________________________
  /**
   * @return System generated Unique ID for the Provider Participant's phone number.
   */
  public long getPhoneNumberID();

  // ___________________________________________________________________________
  /**
   * @return Name of the person to be added as provider participant or
   * provider group participant.
   */
  public String getName();

  // ___________________________________________________________________________
  /**
   * @return The type of provider participant e.g. Neighbor, Friend, Attorney or Accountant.
   */
  public String getType();

  // ___________________________________________________________________________
  /**
   * @return The date from which the participant is associated to the provider.
   */
  public Date getStartDate();

  // ___________________________________________________________________________
  /**
   * @return The last date on which the participant is related to the provider.
   */
  public Date getEndDate();

}
