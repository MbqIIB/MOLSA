/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.externaluseraccess.impl;


import com.google.inject.Singleton;

import curam.cpm.eua.sl.impl.ProviderParticipantRequestAdapter;
import curam.cpm.eua.sl.struct.ProviderParticipantRequestDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of {@linkplain curam.externaluseraccess.impl.RequestDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ProviderParticipantRequestDAOImpl extends StandardDAOImpl<ProviderParticipantRequest, ProviderParticipantRequestDtls>
  implements ProviderParticipantRequestDAO {
  // END, CR00183213
  protected static final ProviderParticipantRequestAdapter providerParticipantRequestAdapter = new ProviderParticipantRequestAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  // END, CR00183213
  protected ProviderParticipantRequestDAOImpl() {
    super(providerParticipantRequestAdapter, ProviderParticipantRequest.class);

  }

}
