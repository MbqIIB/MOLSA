/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.citizenactivity.impl;


import com.google.inject.ImplementedBy;

import curam.provider.impl.Provider;
import curam.providerservice.impl.ProviderOffering;
import curam.serviceoffering.impl.ServiceOffering;


@ImplementedBy(ProviderOfferingUtilImpl.class)
public interface ProviderOfferingUtil {

  /**
   * Retrieves a provider offering based on the Service Offering and Provider
   * passed on. Fetches the provider offering with a status of Approved that has
   * a start date of today or in the future.
   *
   * If none is found, null is returned.
   *
   * @param serviceOffering
   * @param provider
   * @return
   */
  ProviderOffering getByServiceOfferingAndProvider(
    ServiceOffering serviceOffering, Provider provider);
  
  // BEGIN, CR00305191, ASN
  /**
   * Interface to the Provider Offering Util events functionality
   * surrounding the getByServiceOfferingAndProvider method.
   */
  public interface ProviderOfferingUtilGetByServiceOfferAndProviderEvents {

    /**
     * Event interface invoked before the main body of the
     * getByServiceOfferingAndProvider method.
     * {@linkplain ProviderOfferingUtil#getByServiceOfferingAndProvider}
     *
     * @param providerOfferingUtil
     * The object instance as it was before the main body of the
     * getByServiceOfferingAndProvider method.
     * @param serviceOffering
     * The service offering for which provider offering will be
     * retrieved.
     * @param provider
     * The provider for which provider offering will be retrieved.
     *
     * @return The provider offering base on service offering and provider.
     */
    ProviderOffering preGetByServiceOfferingAndProvider(
      final ProviderOfferingUtil providerOfferingUtil, ServiceOffering serviceOffering, Provider provider);

    /**
     * Event interface invoked after the main body of the
     * getByServiceOfferingAndProvider method.
     * {@linkplain ProviderOfferingUtil#getByServiceOfferingAndProvider}
     *
     * @param providerOfferingUtil
     * The object instance as it was after the main body of the
     * getByServiceOfferingAndProvider method.
     * @param serviceOffering
     * The service offering for which provider offering will be
     * retrieved.
     * @param provider
     * The provider for which provider offering will be retrieved.
     *
     * @return The provider offering base on service offering and provider.
     */
    ProviderOffering postGetByServiceOfferingAndProvider(
      final ProviderOfferingUtil providerOfferingUtil, ServiceOffering serviceOffering, Provider provider);
  }

  // END, CR00305191
}
