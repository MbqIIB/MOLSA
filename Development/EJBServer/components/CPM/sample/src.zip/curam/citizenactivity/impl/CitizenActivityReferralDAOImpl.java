/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.citizenactivity.impl;


import java.util.ArrayList;
import java.util.List;
import com.google.inject.Inject;
import curam.participant.impl.ConcernRole;
import curam.piwrapper.casemanager.impl.CaseParticipantRole;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.piwrapper.outcomeplan.impl.OutcomePlanActivity;
import curam.referral.impl.Referral;
import curam.util.persistence.GuiceWrapper;
import curam.util.type.Date;


/**
 * Referral implementation of the CitizenActivityDAO API. Used to retrieve
 * citizen activities that are Referrals. This Referral implementation is bound
 * into a map of {@link CitizenActivityDAO} classes that are managed by the
 * {@link CitizenActivityRegistry}.
 *
 * @since 6.0
 */
class CitizenActivityReferralDAOImpl implements CitizenActivityReferralDAO {

  @Inject
  protected curam.referral.impl.ReferralDAO referralDAO;

  @Inject
  protected CaseParticipantRoleDAO caseParticipantRoleDAO;

  /**
   * {@inheritDoc}
   */
  public CitizenActivity get(final Long id) {

    final CitizenActivityReferral citizenActivityReferral = GuiceWrapper.getInjector().getInstance(
      CitizenActivityReferral.class);

    citizenActivityReferral.setID(id);

    return citizenActivityReferral;
  }

  /**
   * {@inheritDoc}
   */
  public List<CitizenActivity> searchByConcernRole(
    final ConcernRole concernRole) {

    // get a list of case participant roles for this participant
    List<CaseParticipantRole> caseParticipantRoleList = caseParticipantRoleDAO.listActiveByParticipant(
      concernRole);

    // get a list of referrals
    List<curam.referral.impl.Referral> referralList = new ArrayList<curam.referral.impl.Referral>();

    for (CaseParticipantRole caseParticipantRole : caseParticipantRoleList) {

      List<? extends OutcomePlanActivity> referralOutcomePlanActivityList = referralDAO.searchActiveByCaseParticipantRole(
        caseParticipantRole);

      for (OutcomePlanActivity outcomePlanActivity : referralOutcomePlanActivityList) {
        referralList.add((curam.referral.impl.Referral) outcomePlanActivity);
      }
    }

    List<Referral> filteredReferralList = new ArrayList<Referral>();

    for (Referral referral : referralList) {
      if (isValidReferral(referral)) {
        filteredReferralList.add(referral);
      }
    }

    // create citizen activities for them and return
    return getCitizenActivities(filteredReferralList);
  }

  /**
   * we only display referrals which have a referral date of today or in the
   * future. if this is not the case, remove the referral from the list.
   *
   * @param referral
   * the referral in question
   * @return true if the referral has a referral date of today or in the
   * future.
   */
  protected Boolean isValidReferral(final Referral referral) {
    if (referral.getReferralDate().isZero()
      || referral.getReferralDate().before(Date.getCurrentDate().addDays(-1))) {
      return false;
    }
    return true;
  }

  /**
   * Returns a list of citizen activity objects based on the list of referrals
   * passed in.
   *
   * @param referralList
   * the referrals to be turned in to citizen activities.
   * @return a list of citizen activity objects based on the list of referrals
   * passed in.
   */
  protected List<CitizenActivity> getCitizenActivities(
    final List<Referral> referralList) {

    List<CitizenActivity> citizenActivityList = new ArrayList<CitizenActivity>();

    for (Referral referral : referralList) {

      CitizenActivity citizenActivity = get(referral.getID());

      citizenActivityList.add(citizenActivity);
    }
    return citizenActivityList;
  }
}
