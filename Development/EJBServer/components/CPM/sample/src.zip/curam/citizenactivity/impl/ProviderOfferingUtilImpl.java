/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */
/*
 * Copyright 2011-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.citizenactivity.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.provider.impl.Provider;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.type.Date;


class ProviderOfferingUtilImpl implements ProviderOfferingUtil {
  
  /**
   * Reference to ProviderOffering DAO.
   */
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;
  
  // BEGIN, CR00305191, ASN
  /**
   * Event dispatcher for getByServiceOfferingAndProvider events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderOfferingUtilGetByServiceOfferAndProviderEvents> getByServiceOfferAndProviderEventsDispatcherFactory;

  /**
   * {@inheritDoc}
   */
  public ProviderOffering getByServiceOfferingAndProvider(
    ServiceOffering serviceOffering, Provider provider) {
    
    // Raise the pre getByServiceOfferingAndProvider API event.
    getByServiceOfferAndProviderEventsDispatcherFactory.get(ProviderOfferingUtilGetByServiceOfferAndProviderEvents.class).preGetByServiceOfferingAndProvider(
      this, serviceOffering, provider);
    // END, CR00305191

    // Get the provider offering id for the given provider id and service id.(if
    // there is a provider offering)
    Set<ProviderOffering> providerOfferings = providerOfferingDAO.searchProviderOffering(
      provider.getID(), serviceOffering.getID());

    for (ProviderOffering provdOffering : providerOfferings) {
      if (provdOffering.getDateRange().contains(Date.getCurrentDate())
        && provdOffering.getLifecycleState().equals(
          ProviderOfferingStatusEntry.APPROVED)) {
        return provdOffering;
      }
    }
    // BEGIN, CR00305191, ASN
    // Raise the post getByServiceOfferingAndProvider API event.
    getByServiceOfferAndProviderEventsDispatcherFactory.get(ProviderOfferingUtilGetByServiceOfferAndProviderEvents.class).postGetByServiceOfferingAndProvider(
      this, serviceOffering, provider);
    // END, CR00305191
    // none found
    return null;
  }
}
