/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.citizenactivity.impl;


import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.google.inject.Inject;

import curam.citizenactivity.codetable.impl.CITIZENACTIVITYTYPEEntry;
import curam.codetable.impl.COMMENTRELATEDTYPEEntry;
import curam.codetable.impl.REFERRALNOTIFICATIONTYPEEntry;
import curam.codetable.impl.REFERRALRELATEDROLETYPEEntry;
import curam.core.impl.CuramConst;
import curam.participant.impl.ConcernRole;
import curam.piwrapper.casemanager.impl.CaseParticipantRoleDAO;
import curam.piwrapper.user.impl.User;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.providerservice.impl.ProviderOffering;
import curam.referral.impl.Referral;
import curam.referral.impl.ReferralDAO;
import curam.referral.impl.ReferralRole;
import curam.referral.impl.ReferralRoleDAO;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.DateRange;


/**
 * Implementation of the CitizenActivityReferral interface. Overrides methods in
 * the CitizenActivityImpl class to return values based on a given Referral.
 */
class CitizenActivityReferralImpl extends CitizenActivityImpl implements
  curam.citizenactivity.impl.CitizenActivityReferral {

  /**
   * The unique identifier of the Referral that this citizen activity relates
   * to.
   */
  protected Long id;

  /**
   * The Referral that this citizen activity relates to.
   */
  protected Referral referral;

  @Inject
  protected ReferralDAO referralDAO;

  @Inject
  protected ProviderOfferingUtil providerOfferingUtil;

  @Inject
  protected ReferralRoleDAO referralRoleDAO;

  @Inject
  protected CaseParticipantRoleDAO caseParticipantRoleDAO;

  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  @Inject
  protected ProviderDAO providerDAO;

  /**
   * {@inheritDoc}
   */
  public void setID(final Long anID) {
    this.id = anID;
  }

  protected curam.referral.impl.Referral getReferral() {

    if (referral != null) {
      return referral;
    }
    referral = referralDAO.get(id);
    return referral;
  }
  
  /**
   * {@inheritDoc}
   */
  @Override
  public COMMENTRELATEDTYPEEntry getCommentRelatedType() {
    return COMMENTRELATEDTYPEEntry.REFERRAL;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Long getID() {
    return this.id;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getName() {
    return getReferral().getService().getName();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public User getAgencyContact() {
    return getReferral().getReferredBy();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public CITIZENACTIVITYTYPEEntry getType() {
    return CITIZENACTIVITYTYPEEntry.REFERRAL;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public DateRange getPeriod() {
    return getReferral().getDateRange();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String getProviderName() {

    if (getReferral().getProvider() == null) {
      return CuramConst.gkEmpty;
    }
    return getReferral().getProvider().getName();
  }

  /**
   * This always returns true as a Referral always has a document, if none is
   * specified for the particular service offering, a default template is used.
   *
   * @return always returns true as a Referral always has a document.
   */
  @Override
  public Boolean hasReferralLetter() {
    return true;
  }

  /**
   * Return the referral document related to this referral.
   *
   * @return the referral document related to this referral.
   *
   * @throws AppException
   * Generic Exception Signature
   * @throws InformationalException
   * Generic Exception Signature
   */
  @Override
  public ByteArrayOutputStream getReferralDocument()
    throws InformationalException, AppException {
    return getReferral().getReferralDocument(getConcernRole(),
      REFERRALNOTIFICATIONTYPEEntry.CLIENT);
  }

  /**
   * Retrieve the concern role related to this referral via the
   * {@link ReferralRole} API. There is always only one item in this list
   * because a Referral is only related to one participant.
   *
   * @return the concern role related to this referral.
   */
  @Override
  public List<ConcernRole> listConcernRoles() {

    final List<ConcernRole> oneItemList = new ArrayList<ConcernRole>();

    oneItemList.add(getConcernRole());

    return oneItemList;
  }

  /**
   * Retrieves the ConcernRole related to this Referral.
   *
   * @return the ConcernRole related to this Referral.
   */
  protected ConcernRole getConcernRole() {

    ReferralRole concernReferralRole = referralRoleDAO.readActiveByReferralAndRelatedType(
      getReferral(), REFERRALRELATEDROLETYPEEntry.CLIENT);

    ConcernRole referralRelatedConcernRole = caseParticipantRoleDAO.get(concernReferralRole.getRelatedObjectID()).getConcernRole();

    return referralRelatedConcernRole;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public Long getProviderOfferingID() {

    ReferralRole serviceOfferingReferralRole = referralRoleDAO.readActiveByReferralAndRelatedType(
      getReferral(), REFERRALRELATEDROLETYPEEntry.SERVICEOFFERING);

    ReferralRole providerReferralRole = referralRoleDAO.readActiveByReferralAndRelatedType(
      getReferral(), REFERRALRELATEDROLETYPEEntry.PROVIDER);

    if (serviceOfferingReferralRole == null || providerReferralRole == null) {
      return 0L;
    }

    ServiceOffering serviceOffering = serviceOfferingDAO.get(
      serviceOfferingReferralRole.getRelatedObjectID());

    Provider provider = providerDAO.get(
      providerReferralRole.getRelatedObjectID());

    ProviderOffering providerOffering = providerOfferingUtil.getByServiceOfferingAndProvider(
      serviceOffering, provider);

    if (null != providerOffering) {
      return providerOffering.getID();
    } else {
      return 0L;
    }
  }
}
