/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain curam.contracts.impl.ContractContact}.
 */
@ImplementedBy(ContractContactDAOImpl.class)
public interface ContractContactDAO extends StandardDAO<ContractContact> {

  // ___________________________________________________________________________
  /**
   * Returns a set of contract contact records based on specified search criteria.
   *
   * @param contractVersion the contract version of the search criterion.
   *
   * @return the contract contact record(s) which match the specified criteria.
   */
  public Set<ContractContact> searchBy(final ContractVersion contractVersion);
}
