/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.List;

import com.google.inject.Singleton;

import curam.cpm.sl.entity.impl.ContractStatusHistoryAdapter;
import curam.cpm.sl.entity.struct.ContractStatusHistoryDtls;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of {@linkplain ContractStatusHistoryDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ContractStatusHistoryDAOImpl extends StandardDAOImpl<ContractStatusHistory, ContractStatusHistoryDtls> implements
  ContractStatusHistoryDAO {
  // END, CR00183213
  protected final static ContractStatusHistoryAdapter adapter = new ContractStatusHistoryAdapter();

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ContractStatusHistoryDAOImpl() {
    // END, CR00183213
    super(adapter, ContractStatusHistory.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public List<ContractStatusHistory> searchBy(final ContractVersion contract) {

    return newList(adapter.searchByContractID(contract.getID()));

  }

}
