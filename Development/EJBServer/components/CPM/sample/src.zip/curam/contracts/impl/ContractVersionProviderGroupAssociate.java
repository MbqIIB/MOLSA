/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import com.google.inject.ImplementedBy;

import curam.provider.impl.ProviderGroupAssociate;
import curam.util.persistence.helper.LinkTable;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * The interface is used for maintaining the link information between contract
 * version and provider groups associate.
 *
 */
@ImplementedBy(ContractVersionProviderGroupAssociateImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ContractVersionProviderGroupAssociate extends
    ContractVersionProviderGroupAssociateAccessor,
    LinkTable<ContractVersion, ProviderGroupAssociate> {

  /**
   * Gets the contract version.
   *
   * @return The contract version
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public ContractVersion getContractVersion();

  /**
   * Gets the provider group associate.
   *
   *
   * @return The provider group associate.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public ProviderGroupAssociate getProviderGroupAssociate();

  /**
   * Sets the contract version.
   *
   * @param contractVersion
   * the contract version.
   * @see curam.contracts.impl.ContractVersionProviderGroupAssociateImpl#setContractVersion(ContractVersion)
   * The default implementation -
   * curam.contracts.impl.ContractVersionProviderGroupAssociateImpl#setContractVersion(ContractVersion)
   */
  public void setContractVersion(final ContractVersion contractVersion);

  /**
   * Sets the provider group associate.
   *
   * @param providerGroupAssociate
   * the provider group associate
   * @see curam.contracts.impl.ContractVersionProviderGroupAssociateImpl#setProviderGroupAssociate(ProviderGroupAssociate)
   * The default implementation -
   * curam.contracts.impl.ContractVersionProviderGroupAssociateImpl#setProviderGroupAssociate(ProviderGroupAssociate)
   */
  public void setProviderGroupAssociate(
    final ProviderGroupAssociate providerGroupAssociate);

}
