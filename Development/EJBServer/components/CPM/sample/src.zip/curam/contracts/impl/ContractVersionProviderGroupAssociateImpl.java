/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2010-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import com.google.inject.Inject;

import curam.cpm.sl.entity.struct.ContractPGAssociateLinkDtls;
import curam.provider.impl.ProviderGroupAssociate;
import curam.provider.impl.ProviderGroupAssociateDAO;
import curam.util.persistence.helper.LinkTableImpl;


/**
 * {@inheritDoc}
 */
// BEGIN, CR00183213, SS
public class ContractVersionProviderGroupAssociateImpl extends LinkTableImpl<ContractPGAssociateLinkDtls, ContractVersion, ProviderGroupAssociate>
  implements ContractVersionProviderGroupAssociate {
  // END, CR00183213

  @Inject
  protected ContractVersionDAO contractVersionDAO;

  @Inject
  protected ProviderGroupAssociateDAO providerGroupAssociateDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ContractVersionProviderGroupAssociateImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213 
  /**
   * {@inheritDoc}
   */
  public ContractVersion getContractVersion() {

    return contractVersionDAO.get(getDtls().contractVersionID);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderGroupAssociate getProviderGroupAssociate() {

    return providerGroupAssociateDAO.get(getDtls().providerGroupAssociateID);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setContractVersion(ContractVersion contractVersion) {

    getDtls().contractVersionID = contractVersion.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setProviderGroupAssociate(ProviderGroupAssociate providerGroupAssociate) {

    getDtls().providerGroupAssociateID = providerGroupAssociate.getID();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ContractVersion getLHS() {

    return getContractVersion();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public ProviderGroupAssociate getRHS() {

    return getProviderGroupAssociate();
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// Not required please see CR00087353 and CR00087420 for further information.
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// Not required
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// Not required
  }
}
