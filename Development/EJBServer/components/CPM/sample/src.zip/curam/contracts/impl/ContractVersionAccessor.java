/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.List;
import java.util.Set;

import curam.codetable.impl.CONTRACTTYPEEntry;
import curam.provider.impl.LicenseTypeEntry;
import curam.provider.impl.ProviderAccessor;
import curam.provider.impl.ProviderOrganizationAccessor;
import curam.providerservice.impl.ProviderOfferingAccessor;
import curam.serviceoffering.impl.ServiceOfferingAccessor;
import curam.util.persistence.StandardEntity;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Date;
import curam.util.type.DateTime;


/**
 * This business interface is used for accessing the details of a contract
 * version.Contract version is a version of a formal agreement between the
 * organization and a provider to provide service(s).
 *
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ContractVersionAccessor extends StandardEntity {

  /**
   * Gets the immutable set of contract contact.
   * <p>
   * The returned objects are intentionally accessor-only.
   * Calling code must not attempt to cast any of these objects
   * to its mutator interface, nor use the object's ID to
   * re-retrieve a mutable instance from the database.
   *
   * @return the immutable set of contacts for this contract version
   */
  public Set<? extends ContractContactAccessor> getContacts();

  /**
   * Gets the date of generation.
   *
   * @return the contract generation date.
   */
  public Date getGenerationDate();

  /**
   * Gets the person who created this contract version.
   *
   * @return the person who created this contract version.
   */
  public String getCreatedBy();

  /**
   * Gets the date the contract was signed.
   *
   * @return the date the contract was signed.
   */
  public Date getDateSigned();

  /**
   * Gets the immutable set of provider organization to which this contract version belongs.
   * <p>
   * The returned objects are intentionally accessor-only.
   * Calling code must not attempt to cast any of these objects
   * to its mutator interface, nor use the object's ID to
   * re-retrieve a mutable instance from the database.
   *
   * @return the immutable set of provider organization to which this contract version belongs.
   */
  public Set<? extends ProviderAccessor> getProviders();

  /**
   * Gets the set of provider offerings specified on this contract version.
   *
   * @boread FlatRateContract
   * @boread UtilizationContract
   * @boread ProviderService
   *
   * @return The set of provider offerings.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public Set<? extends ProviderOfferingAccessor> getProviderOfferings();

  /**
   * Gets the immutable set of history of changes to the state of this contract version.
   * <p>
   * The returned objects are intentionally accessor-only.
   * Calling code must not attempt to cast any of these objects
   * to its mutator interface, nor use the object's ID to
   * re-retrieve a mutable instance from the database.
   *
   * <p>
   * The List is returned in ascending date/time order (i.e. earliest first).
   *
   * @return the immutable set of history of changes to the state of this contract version.
   */
  public List<? extends ContractStatusHistoryAccessor> getStatusHistory();

  /**
   * Gets the immutable set of service offerings which are approved to be provided by <i>all</i>
   * the providers on this contract version.
   * <p>
   * The returned objects are intentionally accessor-only.
   * Calling code must not attempt to cast any of these objects
   * to its mutator interface, nor use the object's ID to
   * re-retrieve a mutable instance from the database.
   *
   *
   * @return the immutable set of service offerings which are approved to be provided by <i>all</i>
   * the providers on this contract version.
   */
  public Set<? extends ServiceOfferingAccessor> getCommonApprovedProviderServiceOfferings();

  /**
   * Gets the date time the contract was terminated.
   * <p>
   * Returns null if no termination date was found.
   *
   * @return date time the contract was terminated.
   */
  public DateTime getTerminationDateTime();

  /**
   * Gets the contract version number.
   *
   * @return the contract version number.
   */
  public int getAmendmentVersionNumber();

  // BEGIN, CR00089491, JM

  /**
   * Gets the renewed from contract version.
   *
   * @return boolean to say if contract version is renewed
   */
  public boolean getRenewedContractInd();

  // END, CR00089491


  /**
   * Gets the user name of the last user to change the contract's status.
   *
   * @return user name of the last user to change the contract's status.
   */
  public String getLastTransitionedBy();

  /**
   * Gets the required license type.
   *
   * @return the required license type.
   */
  public LicenseTypeEntry getRequiredLicenseType();

  /**
   * Gets the contract services type.
   *
   * @return the contract service's type.
   */
  public ContractServicesTypeEntry getContractServicesType();

  /**
   * Gets the contract type.
   *
   * @boread FlatRateContract
   * @boread UtilizationContract
   *
   * @return The contract type.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public CONTRACTTYPEEntry getContractType();

  /**
   * Gets the reason for generation.
   *
   * @return the contract generation reason.
   */
  public ContractGenerationReasonEntry getGenerationReason();

  /**
   * Gets the provider organization to which this contract version belongs.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   *
   * @return the provider organization to which this contract version belongs.
   */
  public ProviderOrganizationAccessor getProviderOrganization();

  // BEGIN, CR00144284, SK
  /**
   * Gets the reason why the contract version is currently terminated.
   *
   * Returns
   * {@linkplain curam.contracts.impl.ContractTerminationReasonEntry#NOT_SPECIFIED}
   * if the contract version is not currently terminated.
   *
   * @return the reason why the contract version is currently terminated.
   */
  // END, CR00144284
  public ContractTerminationReasonEntry getTerminationReason();

  /**
   * Gets the related {@linkplain curam.contracts.impl.CPMContract}.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   *
   * @return the related {@linkplain curam.contracts.impl.CPMContract}.
   */
  public CPMContractAccessor getCPMContract();

}
