/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import com.google.inject.Inject;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.cpm.impl.CPMConstants;
import curam.cpm.message.impl.CONTRACTPROVIDEROFFERINGLINKExceptionCreator;
import curam.cpm.sl.entity.struct.ContractPOLinkDtls;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.ProviderStatusEntry;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingPlaceLimit;
import curam.providerservice.impl.ProviderOfferingPlaceLimitDAO;
import curam.providerservice.impl.ProviderOfferingRate;
import curam.providerservice.impl.ProviderOfferingRateDAO;
import curam.providerservice.impl.ProviderOfferingRateTypeEntry;
import curam.serviceoffering.impl.ServiceRate;
import curam.util.exception.AppException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.LinkTableImpl;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateRange;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;


/**
 * {@inheritDoc}
 */
// BEGIN, CR00183213, SS
public class ContractVersionProviderOfferingImpl extends LinkTableImpl<ContractPOLinkDtls, ContractVersion, ProviderOffering>
  implements ContractVersionProviderOffering {
  // END, CR00183213
  @Inject
  protected ContractVersionDAO contractVersionDAO;

  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  @Inject
  protected ContractVersionProviderOfferingDAO contractProviderOfferingLinkDAO;

  @Inject
  protected ProviderOfferingRateDAO providerOfferingRateDAO;

  @Inject
  protected ProviderOfferingPlaceLimitDAO providerOfferingPlaceLimitDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  @Inject
  protected ProviderDAO providerDAO;

  // BEGIN, CR00305191, ASN
  /**
   * Event dispatcher for copyNonContractedPORToContract events.
   */
  @Inject
  protected EventDispatcherFactory<ContractVerProvOfferCopyNonContractPORToContractEvents> copyNonContractedPORToContractEventsDispatcherFactory;

  /**
   * Event dispatcher for createDefaultRate events.
   */
  @Inject
  protected EventDispatcherFactory<ContractVerProvOfferCreateDefaultRateEvents> createDefaultRateEventsDispatcherFactory;

  /**
   * Event dispatcher for checkForDuplicateProviderOfferingOnLiveContract
   * events.
   */
  @Inject
  protected EventDispatcherFactory<ContractVerPOCheckForDuplicatePOOnLiveContractEvents> checkForDuplicatePOOnLiveContractEventsDispatcherFactory;

  /**
   * Event dispatcher for createContractedPORForPeriod events.
   */
  @Inject
  protected EventDispatcherFactory<ContractVerPOCreateContractedPORForPeriodEvents> createContractedPORForPeriodEventsDispatcherFactory;

  // END, CR00305191
  
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ContractVersionProviderOfferingImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public ContractVersion getLHS() {
    return getContractVersion();
  }

  /**
   * {@inheritDoc}
   */
  public ProviderOffering getRHS() {
    return getProviderOffering();
  }

  /**
   * {@inheritDoc}
   */
  public ContractVersion getContractVersion() {
    final long id = getDtls().contractVersionID;

    return id == 0 ? null : contractVersionDAO.get(id);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderOffering getProviderOffering() {
    final long id = getDtls().providerOfferingID;

    return id == 0 ? null : providerOfferingDAO.get(id);
  }

  /**
   * {@inheritDoc}
   */
  public void setContractVersion(final ContractVersion value) {
    getDtls().contractVersionID = value.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderOffering(final ProviderOffering value) {
    getDtls().providerOfferingID = value.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// no mandatory field validation
    // required
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// no cross-field validation required
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// no cross-field validation required
  }

  /**
   * Creates the Provider Offering for a contract.
   *
   * Checks the provider security to remove the provider offering rate.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed
   * @throws InformationalException
   * {@link curam.message.CONTRACTPROVIDEROFFERINGLINK#ERR_CEV_DUPLICATE_PROVIDER_OFFERING_ON_CONTRACT} -
   * If ProviderOffering is already exist on a contract.
   * @throws InformationalException
   * {@link curam.message.CONTRACTPROVIDEROFFERINGLINK#INF_CEV_PROVIDER_AND_PROVIDER_OFFERING_ALREADY_ON_LIVE_CONTRACT} -
   * if the ProviderOffering/Provider pair for this
   * ContractVersionProviderOffering is already on another live
   * contract.
   * @throws InformationalException
   * {@link curam.message.CONTRACTPROVIDEROFFERINGLINK#ERR_CEV_CANNOT_ADD_PROVIDER_OFFERING_TO_LIVE_CONTRACT} -
   * If the contract is live status.
   */
  @Override
  public void insert() throws InformationalException {

    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      this.getContractVersion().getProviderOrganization());
    // if the status of the provider is closed
    if (getContractVersion().getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {
      if (providerDAO.get(getContractVersion().getProviderOrganization().getID()).getLifecycleState().equals(
        ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 3);
        ValidationHelper.failIfErrorsExist();
      }
    }

    // Cannot add a provider Offering if the contract is live
    if (getContractVersion().getLifecycleState().equals(
      CONTRACTSTATUSEntry.LIVE)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTPROVIDEROFFERINGLINKExceptionCreator.ERR_CEV_CANNOT_ADD_PROVIDER_OFFERING_TO_LIVE_CONTRACT(
          getContractVersion().getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
      TransactionInfo.getInformationalManager().failOperation();
    }

    // A ProviderOffering may not be present on a contract more than once
    if (getContractVersion().getProviderOfferings().contains(
      getProviderOffering())) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTPROVIDEROFFERINGLINKExceptionCreator.ERR_CEV_DUPLICATE_PROVIDER_OFFERING_ON_CONTRACT(
          getProviderOffering().getServiceOffering().getName()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
      TransactionInfo.getInformationalManager().failOperation();
    }

    super.insert();
    // Raise informational message if the ProviderOffering/Provider pair for
    // this ContractVersionProviderOffering is already on another live contract
    ContractVersionProviderOffering conflictingContractVersionProviderOffering = checkForDuplicateProviderOfferingOnLiveContract(
      this.getContractVersion().getDateRange());

    if (conflictingContractVersionProviderOffering != null) {

      // Raise informational message
      InformationalManager informationalManager = TransactionInfo.getInformationalManager();

      AppException appException = CONTRACTPROVIDEROFFERINGLINKExceptionCreator.INF_CEV_PROVIDER_AND_PROVIDER_OFFERING_ALREADY_ON_LIVE_CONTRACT(
        getContractVersion().getCPMContract().getReferenceNumber(),
        getProviderOffering().getServiceOffering().getName(),
        getProviderOffering().getProvider().getName(),
        conflictingContractVersionProviderOffering.getContractVersion().getCPMContract().getReferenceNumber());

      informationalManager.addInformationalMsg(appException,
        curam.core.impl.CuramConst.gkEmpty,
        InformationalElement.InformationalType.kWarning);
    }

  }

  /**
   * Removes the Provider Offering rate. Also removes any Contracts Rates that
   * were created and any Contracts Place Limits that exist. Checks the
   *
   * provider security to remove the provider offering rate.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the status of the provider is closed.
   * @throws InformationalException
   * {@link curam.message.CONTRACTPROVIDEROFFERINGLINK#ERR_CEV_CANNOT_DELETE_PROVIDER_OFFERING_FROM_LIVE_CONTRACT} -
   * If the contract is live status.
   */
  @Override
  public void remove() throws InformationalException {

    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      getContractVersion().getProviderOrganization());

    // if the status of the provider is closed
    if (getContractVersion().getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {
      if (providerDAO.get(getContractVersion().getProviderOrganization().getID()).getLifecycleState().equals(
        ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 4);
        ValidationHelper.failIfErrorsExist();
      }
    }

    // Cannot delete a provider Offering if the contract is live
    if (getContractVersion().getLifecycleState().equals(
      CONTRACTSTATUSEntry.LIVE)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTPROVIDEROFFERINGLINKExceptionCreator.ERR_CEV_CANNOT_DELETE_PROVIDER_OFFERING_FROM_LIVE_CONTRACT(
          getContractVersion().getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    TransactionInfo.getInformationalManager().failOperation();

    // Remove any Contracts Rates that were created
    // Search for all Provider offering Rates that are on this contract for this
    // Offering

    Set<ProviderOfferingRate> providerOfferingRates = providerOfferingRateDAO.searchBy(
      getProviderOffering(), getContractVersion());

    // For each rate remove it
    for (ProviderOfferingRate providerOfferingRate : providerOfferingRates) {
      providerOfferingRate.remove(providerOfferingRate.getVersionNo());

    }

    // Remove any Contracts Place Limits that exist
    // Search for all Provider offering Place Limits that are on this contract
    // for this Offering

    Set<ProviderOfferingPlaceLimit> providerOfferingPlaceLimits = providerOfferingPlaceLimitDAO.searchBy(
      getProviderOffering(), getContractVersion());

    // For each place remove it
    for (ProviderOfferingPlaceLimit providerOfferingPlaceLimit : providerOfferingPlaceLimits) {
      providerOfferingPlaceLimit.remove(
        providerOfferingPlaceLimit.getVersionNo());
    }

    super.remove();
  }

  /**
   * {@inheritDoc}
   */
  public ContractVersionProviderOffering checkForDuplicateProviderOfferingOnLiveContract(
    DateRange dateRange) {
    
    // BEGIN, CR00293199, ASN
    // Raise the pre checkForDuplicateProviderOfferingOnLiveContract API event.
    checkForDuplicatePOOnLiveContractEventsDispatcherFactory.get(ContractVerPOCheckForDuplicatePOOnLiveContractEvents.class).preCheckForDuplicateProviderOfferingOnLiveContract(
      this, dateRange);
    // END, CR00305191


    ContractVersionProviderOffering preExistingContractVersionProviderOffering = null;

    // Check all ContractVersionProviderOfferings containing this
    // ContractVersionProviderOffering's ProviderOffering
    for (ContractVersionProviderOffering contractProviderOfferingLink : contractProviderOfferingLinkDAO.searchBy(
      getProviderOffering())) {

      if (!contractProviderOfferingLink.equals(this)
        && !contractProviderOfferingLink.getContractVersion().getCPMContract().equals(
          getContractVersion().getCPMContract())
          && (contractProviderOfferingLink.getContractVersion().getLifecycleState().equals(
            CONTRACTSTATUSEntry.LIVE)
              && contractProviderOfferingLink.getContractVersion().getDateRange().overlapsWith(
                dateRange))) {

        preExistingContractVersionProviderOffering = contractProviderOfferingLink;
        break;
      }
    }
    // BEGIN, CR00305191, ASN
    // Raise the post checkForDuplicateProviderOfferingOnLiveContract API event.
    checkForDuplicatePOOnLiveContractEventsDispatcherFactory.get(ContractVerPOCheckForDuplicatePOOnLiveContractEvents.class).postCheckForDuplicateProviderOfferingOnLiveContract(
      this, dateRange);
    // END, CR00305191
    return preExistingContractVersionProviderOffering;
  }

  /**
   * {@inheritDoc}
   */
  // BEGIN CR00098695, ABS
  public void createDefaultRate() throws InformationalException {
    
    // BEGIN, CR00305191, ASN
    // Raise the pre createDefaultRate  API event.
    createDefaultRateEventsDispatcherFactory.get(ContractVerProvOfferCreateDefaultRateEvents.class).preCreateDefaultRate(
      this);
    // END, CR00305191

    // If this is for a provider get the non-contract provider offering rate
    // which applies on the contract's start date - there should be only one,
    // rate date ranges cannot overlap.
    // If its for a provider group then do not do this.

    if (this.getContractVersion().getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {

      createProviderOfferingRateForProvider();

    } else {
      // If no ProviderOfferingRate can be found or this is for a Provider
      // Group,
      // create a new one based on the ServiceRate for the ProviderOffering's
      // service applicable on the contract's start date.
      createProviderOfferingRate(getContractVersion().getDateRange());
    }

    // BEGIN, CR00305191, ASN
    // Raise the post createDefaultRate  API event.
    createDefaultRateEventsDispatcherFactory.get(ContractVerProvOfferCreateDefaultRateEvents.class).postCreateDefaultRate(
      this);
    // END, CR00305191
  }

  /**
   * Creates provider offering rates for the provider contract period.
   *
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void createProviderOfferingRateForProvider()
    throws InformationalException {
    // END, CR00177241
    Set<ProviderOfferingRate> providerOfferingRates = new HashSet<ProviderOfferingRate>();

    // Iterate through the provider offering rates and find the provider
    // offering rates
    // that overlaps the contract period
    Set<ProviderOfferingRate> unModifiableProviderOfferingRates = getProviderOffering().getProviderOfferingRates();
    Set<ProviderOfferingRate> providerOfferingRateRecords = new HashSet<ProviderOfferingRate>();

    providerOfferingRateRecords.addAll(unModifiableProviderOfferingRates);

    for (ProviderOfferingRate offeringRate : providerOfferingRateRecords) {
      if (offeringRate.getProviderOfferingRateType().equals(
        ProviderOfferingRateTypeEntry.NONCONTRACT)) {
        if (getContractVersion().getDateRange().contains(
          offeringRate.getDateRange())
            || getContractVersion().getDateRange().contains(
              offeringRate.getDateRange().start())
              || getContractVersion().getDateRange().contains(
                offeringRate.getDateRange().end())
                || ((offeringRate.getDateRange().end().equals(Date.kZeroDate)
                  || offeringRate.getDateRange().end().after(
                    getContractVersion().getDateRange().end()))
                      && (offeringRate.getDateRange().start().before(
                        getContractVersion().getDateRange().start())))) {
          providerOfferingRates.add(offeringRate);
        }
      }
    }

    ProviderOfferingRate[] providerOfferingRateArray = new ProviderOfferingRate[providerOfferingRates.size()];

    providerOfferingRateArray = providerOfferingRates.toArray(
      providerOfferingRateArray);

    copyNonContractedPORToContract(providerOfferingRateArray,
      getContractVersion().getDateRange());

    // Retrieve the provider offering rates for the contract
    Set<ProviderOfferingRate> contractProviderOfferingRates = providerOfferingRateDAO.searchBy(
      getProviderOffering(), this.getContractVersion());

    ProviderOfferingRate[] contractProviderOfferingRatesArray = new ProviderOfferingRate[contractProviderOfferingRates.size()];

    providerOfferingRateArray = contractProviderOfferingRates.toArray(
      contractProviderOfferingRatesArray);

    // Sort the provider offering rate by start date
    sortRatesArray(providerOfferingRateArray);

    createContractedPORForPeriod(providerOfferingRateArray,
      getContractVersion().getDateRange());
  }

  /**
   * {@inheritDoc}
   */
  public void createContractedPORForPeriod(
    ProviderOfferingRate[] providerOfferingRateArray,
    DateRange contractVersionPeriod) throws InformationalException {
    
    // BEGIN, CR00305191, ASN
    // Raise the pre createContractedPORForPeriod API event.
    createContractedPORForPeriodEventsDispatcherFactory.get(ContractVerPOCreateContractedPORForPeriodEvents.class).preCreateContractedPORForPeriod(
      this, providerOfferingRateArray, contractVersionPeriod);
    // END, CR00305191


    // If there are no non-contracted provider offering rates for the
    // contract period then create contracted provider offering rate using
    // service offering rate for the contract period
    if (providerOfferingRateArray.length == CPMConstants.kZeroLong) {
      createProviderOfferingRate(contractVersionPeriod);
    }

    for (int i = 0; i < providerOfferingRateArray.length; i++) {
      ProviderOfferingRate providerOfferingRate = providerOfferingRateArray[i];

      if (i == CPMConstants.kZeroLong) {
        // If the contract period contains the start date of the provider
        // offering rate
        // then create provider offering rate with start date as the start date
        // of the contract
        // and end date one day before the provider offering start date
        if (contractVersionPeriod.contains(
          providerOfferingRate.getDateRange().start())
            && !providerOfferingRate.getDateRange().start().equals(
              contractVersionPeriod.start())) {

          createProviderOfferingRate(
            new DateRange(contractVersionPeriod.start(),
            providerOfferingRateArray[i].getDateRange().start().addDays(-1)));
        }
      }

      if (i + 1 < providerOfferingRateArray.length) {
        if (!providerOfferingRateArray[i].getDateRange().end().addDays(1).equals(
          providerOfferingRateArray[i + 1].getDateRange().start())) {
          createProviderOfferingRate(
            new DateRange(
              providerOfferingRateArray[i].getDateRange().end().addDays(1),
              providerOfferingRateArray[i + 1].getDateRange().start().addDays(
                -1)));
        }
      }

      if (i == providerOfferingRateArray.length - 1) {

        if (!providerOfferingRate.getDateRange().end().equals(
          contractVersionPeriod.end())) {
          // If the contract period contains the end date of the provider
          // offering rate
          // then create provider offering rate with start date as the next day
          // after the
          // end date of the contract and end date as the end date of the
          // contract
          createProviderOfferingRate(
            new DateRange(
              providerOfferingRateArray[i].getDateRange().end().addDays(1),
              contractVersionPeriod.end()));
        }
      }
    }
    
    // BEGIN, CR00305191, ASN
    // Raise the post createContractedPORForPeriod API event.
    createContractedPORForPeriodEventsDispatcherFactory.get(ContractVerPOCreateContractedPORForPeriodEvents.class).postCreateContractedPORForPeriod(
      this, providerOfferingRateArray, contractVersionPeriod);
    // END, CR00305191
  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderOfferingRate> copyNonContractedPORToContract(
    ProviderOfferingRate[] providerOfferingRateArray, DateRange contractPeriod)
    throws InformationalException {
    
    // BEGIN, CR00305191, ASN
    // Raise the pre copyNonContractedPORToContract API event.
    copyNonContractedPORToContractEventsDispatcherFactory.get(ContractVerProvOfferCopyNonContractPORToContractEvents.class).preCopyNonContractedPORToContract(
      this, providerOfferingRateArray, contractPeriod);
    // END, CR00305191


    Set<ProviderOfferingRate> contractedProviderOfferingRates = new HashSet<ProviderOfferingRate>();

    // Iterate through the provider offering rates and copy the
    // provider offering rates to contract provider offering rate
    for (ProviderOfferingRate providerOfferingRate : providerOfferingRateArray) {

      ProviderOfferingRate contractedProviderOfferingRate = null;

      // If the provider offering rate period falls within the the contract
      // version period
      if (contractPeriod.contains(providerOfferingRate.getDateRange())) {
        contractedProviderOfferingRate = createProviderOfferingRate(
          providerOfferingRate, providerOfferingRate.getDateRange());

        // If the start date overlaps with the contract version period
      } else if (contractPeriod.contains(
        providerOfferingRate.getDateRange().start())) {
        contractedProviderOfferingRate = createProviderOfferingRate(
          providerOfferingRate,
          new DateRange(providerOfferingRate.getDateRange().start(),
          contractPeriod.end()));

        // If the end date overlaps with the contract version period
      } else if (contractPeriod.contains(
        providerOfferingRate.getDateRange().end())) {
        contractedProviderOfferingRate = createProviderOfferingRate(
          providerOfferingRate,
          new DateRange(contractPeriod.start(),
          providerOfferingRate.getDateRange().end()));

        // If the start date is before the contract start date and end date
        // after the
        // contract end date or there is no end date present for provider
        // offering rate
      } else if ((providerOfferingRate.getDateRange().end().equals(
        Date.kZeroDate)
          || providerOfferingRate.getDateRange().end().after(
            contractPeriod.end()))
              && (providerOfferingRate.getDateRange().start().before(
                contractPeriod.start()))) {
        contractedProviderOfferingRate = createProviderOfferingRate(
          providerOfferingRate,
          new DateRange(contractPeriod.start(), contractPeriod.end()));

      }
      if (contractedProviderOfferingRate != null) {
        contractedProviderOfferingRates.add(contractedProviderOfferingRate);
      }
    }

    // BEGIN, CR00305191, ASN
    // Raise the post copyNonContractedPORToContract API event.
    copyNonContractedPORToContractEventsDispatcherFactory.get(ContractVerProvOfferCopyNonContractPORToContractEvents.class).postCopyNonContractedPORToContract(
      this, providerOfferingRateArray, contractPeriod);
    // END, CR00305191
    return contractedProviderOfferingRates;
  }

  /**
   * Creates contracted provider offering rate for the input period using the
   * service offering rates.
   *
   * @param providerOfferingRateDateRange
   * Date range for which provider offering rate is created.
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected ProviderOfferingRate createProviderOfferingRate(
    DateRange providerOfferingRateDateRange) throws InformationalException {
    // END, CR00177241

    ProviderOfferingRate newRate = providerOfferingRateDAO.newInstance();

    newRate.setDefaultRates();
    ServiceRate serviceRate = getApplicableServiceRate();

    // If fixedAmount is > zero, set it
    if (serviceRate.getFixedAmount().isPositive()) {
      newRate.setFixedAmount(serviceRate.getFixedAmount());
    } // Otherwise set the max/min amounts
    else {
      if (!serviceRate.getMaxAmount().isNegative()) {
        newRate.setMaxAmount(serviceRate.getMaxAmount());
      }
      if (!serviceRate.getMinAmount().isNegative()) {
        newRate.setMinAmount(serviceRate.getMinAmount());
      }
    }

    // Insert the new ProviderOfferingRate
    newRate.setProviderOffering(getProviderOffering());
    newRate.setContractVersion(getContractVersion());
    newRate.setDateRange(providerOfferingRateDateRange);
    newRate.insert();
    return newRate;
  }

  /**
   * Creates contracted provider offering rate for the input period using the
   * non contracted provider offering rate.
   *
   * @param providerOfferingRate
   * Contains provider offering rate details.
   * @param providerOfferingRateDateRange
   * Daterange for which provider offering rate is created.
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected ProviderOfferingRate createProviderOfferingRate(  
    curam.providerservice.impl.ProviderOfferingRate providerOfferingRate,
    DateRange providerOfferingRateDateRange) throws InformationalException {
    // END, CR00177241

    ProviderOfferingRate newRate = providerOfferingRateDAO.newInstance();

    newRate.setDefaultRates();

    // If fixedAmount is > zero, set it
    if (providerOfferingRate.getFixedAmount().isPositive()) {
      newRate.setFixedAmount(providerOfferingRate.getFixedAmount());
    } // Otherwise set the max/min amounts
    else {
      if (!providerOfferingRate.getMaxAmount().isNegative()) {
        newRate.setMaxAmount(providerOfferingRate.getMaxAmount());
      }
      if (!providerOfferingRate.getMinAmount().isNegative()) {
        newRate.setMinAmount(providerOfferingRate.getMinAmount());
      }
    }

    // Insert the new ProviderOfferingRate
    newRate.setProviderOffering(getProviderOffering());
    newRate.setContractVersion(getContractVersion());
    newRate.setDateRange(providerOfferingRateDateRange);
    newRate.insert();
    return newRate;
  }

  /**
   * Sorts the provider offering rate in ascending order
   *
   * @param providerOfferingRateArray
   * contains list of provider offering rates
   */
  // BEGIN, CR00177241, PM
  protected void sortRatesArray(ProviderOfferingRate[] providerOfferingRateArray) {
    // END, CR00177241

    // Sort the rates in the ascending order by start date
    Arrays.sort(providerOfferingRateArray,
      new Comparator<ProviderOfferingRate>() {
      public int compare(final ProviderOfferingRate lhs,
        ProviderOfferingRate rhs) {
        return lhs.getDateRange().start().compareTo(rhs.getDateRange().start());
      }
    });
  }

  // END CR00098695
 
  /**
   * Returns the service rate applicable to the relevant service offering on the
   * contract's start date.
   *
   * @return the ServiceRate applicable to the relevant ServiceOffering on the
   * contract's start Date
   */
  // BEGIN, CR00177241, PM
  protected ServiceRate getApplicableServiceRate() {
    // END, CR00177241

    ServiceRate serviceRate = null;

    Set<ServiceRate> unModifiableServiceRate = getProviderOffering().getServiceOffering().getServiceRates();
    Set<ServiceRate> serviceRates = new HashSet<ServiceRate>();

    serviceRates.addAll(unModifiableServiceRate);

    // Get the ServiceRate which applies on the contract's start date and is not
    // already associated with a contract - should be only one, date ranges
    // should not overlap
    for (ServiceRate rate : serviceRates) {

      if (rate.getDateRange().contains(
        getContractVersion().getDateRange().start())) {

        serviceRate = rate;
        break;
      }
    }
    return serviceRate;
  }

}
