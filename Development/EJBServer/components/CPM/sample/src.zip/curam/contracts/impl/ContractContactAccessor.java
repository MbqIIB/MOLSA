/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import curam.provider.impl.ProviderPartyAccessor;
import curam.util.persistence.StandardEntity;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateRange;


/**
 * Accessor interface for {@linkplain ContractContact}.
 *
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ContractContactAccessor extends StandardEntity {

  // ___________________________________________________________________________
  /**
   * Returns the contract version.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return the contract version.
   * @see ContractVersion
   */
  public ContractVersionAccessor getContractVersion();

  // ___________________________________________________________________________
  /**
   * Returns the provider party.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return the provider party.
   * @see curam.provider.impl.ProviderParty
   */
  public ProviderPartyAccessor getProviderParty();

  /**
   * Returns the period of time for which the {@link curam.provider.impl.ProviderParty provider party}
   * is the contact for the {@link ContractVersion contract version}.
   *
   * @return the period of time for which the provider party is the contact
   * for the contract version.
   */
  public DateRange getContactPeriod();

  // BEGIN, CR00186897, ASN

  /**
   * Gets the utilization contract details.
   *
   * @return The utilization contract.
   */
  public UtilizationContract getUtilizationContract();

  /**
   * Gets the flat rate contract details.
   *
   * @return The flat rate contract.
   */
  public FlatRateContract getFlatRateContract();

  // END, CR00186897
}
