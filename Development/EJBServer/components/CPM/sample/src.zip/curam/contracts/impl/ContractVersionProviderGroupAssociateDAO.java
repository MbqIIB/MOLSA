/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2010 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.provider.impl.ProviderGroupAssociate;
import curam.util.persistence.StandardDAO;


/**
 * Data access for <code>ContractVersionProviderGroupAssociate</code>.
 *
 * @see curam.contracts.impl.ContractVersionProviderGroupAssociate
 */
@ImplementedBy(ContractVersionProviderGroupAssociateDAOImpl.class)
public interface ContractVersionProviderGroupAssociateDAO extends
    StandardDAO<ContractVersionProviderGroupAssociate> {

  // ___________________________________________________________________________
  /**
   * Returns a <code>Set</code> of link records for the contract version specified.
   *
   * @param contractVersion the contract version for which the links are sought
   * @return set of link records for the contract version specified
   *
   * @see curam.contracts.impl.ContractVersion
   */
  public Set<ContractVersionProviderGroupAssociate> searchBy(
    final ContractVersion contractVersion);

  // BEGIN, CR00187814, DRS
  /**
   * Returns a <code>Set</code> of link records for the provider group associate
   * specified.
   *
   * @param providerGroupAssociate
   * the provider group associate for which the links are sought
   * @return set of link records for the provider group associate specified
   *
   * @see curam.provider.impl.ProviderGroupAssociate
   */
  public Set<ContractVersionProviderGroupAssociate> searchBy(
    final ProviderGroupAssociate providerGroupAssociate);
  // END, CR00187814
}
