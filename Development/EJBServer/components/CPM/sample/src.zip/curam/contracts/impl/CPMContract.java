/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import com.google.inject.ImplementedBy;

import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * This business interface maintains CPM contract.
 */
@ImplementedBy(CPMContractImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface CPMContract extends CPMContractAccessor,
    OptimisticLockModifiable, Insertable {

  /**
   * Inserts the CPM Contract. Stores the contract version id and reference
   * number.
   *
   * @param contractVersion
   * Contains the contract version object.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void insert(ContractVersion contractVersion)
    throws InformationalException;

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the CPM contract events functionality surrounding the insert
   * method.
   */
  public interface CPMContractInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.contracts.impl.CPMContract#insert}
     *
     * @param cpmContract
     * The object instance as it was before the main body of the insert
     * method.
     * @param contractVersion
     * The parameter as passed to the insert method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(CPMContractAccessor cpmContract,
      ContractVersion contractVersion) throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.contracts.impl.CPMContract#insert}
     *
     * @param cpmContract
     * The object instance as it was after the main body of the insert
     * method.
     * @param contractVersion
     * The parameter as passed to the insert method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(CPMContractAccessor cpmContract,
      ContractVersion contractVersion) throws InformationalException;
  }


  /**
   * Interface to the CPM contract events functionality surrounding the modify
   * method.
   */
  public interface CPMContractModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.contracts.impl.CPMContract#modify}
     *
     * @param cpmContract
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(CPMContractAccessor cpmContract, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.contracts.impl.CPMContract#modify}
     *
     * @param cpmContract
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(CPMContractAccessor cpmContract, Integer versionNo)
      throws InformationalException;
  }
  // END, CR00144381
}
