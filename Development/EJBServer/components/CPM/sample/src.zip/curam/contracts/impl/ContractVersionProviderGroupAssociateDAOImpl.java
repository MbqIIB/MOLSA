/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.Set;

import com.google.inject.Singleton;

import curam.cpm.sl.entity.impl.ContractPGAssociateLinkAdapter;
import curam.cpm.sl.entity.struct.ContractPGAssociateLinkDtls;
import curam.provider.impl.ProviderGroupAssociate;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of
 * {@linkplain curam.contracts.impl.ContractVersionProviderGroupAssociateDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ContractVersionProviderGroupAssociateDAOImpl extends StandardDAOImpl<ContractVersionProviderGroupAssociate, ContractPGAssociateLinkDtls>
  implements ContractVersionProviderGroupAssociateDAO {
  // END, CR00183213
  protected static final ContractPGAssociateLinkAdapter adapter = new ContractPGAssociateLinkAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ContractVersionProviderGroupAssociateDAOImpl() {
    // END, CR00183213
    super(adapter, ContractVersionProviderGroupAssociate.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<ContractVersionProviderGroupAssociate> searchBy(
    final ContractVersion contractVersion) {
    return newSet(adapter.searchByContract(contractVersion.getID()));
  }

  // BEGIN, CR00187814, DRS
  /**
   * {@inheritDoc}
   */
  public Set<ContractVersionProviderGroupAssociate> searchBy(
    final ProviderGroupAssociate providerGroupAssociate) {
    return newSet(
      adapter.searchByProviderGroupAssociate(providerGroupAssociate.getID()));
  }
  // END, CR00187814
}
