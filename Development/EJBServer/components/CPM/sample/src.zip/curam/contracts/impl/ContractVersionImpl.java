/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.contracts.impl;


import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.codetable.impl.CONTRACTTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.contracts.ContractNotificationEvent;
import curam.core.facade.struct.FileNameAndDataDtls;
import curam.core.impl.CuramConst;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.core.struct.SystemUserDtls;
import curam.cpm.facade.struct.ContractNotificationKey;
import curam.cpm.facade.struct.ContractReturnDocDetails;
import curam.cpm.impl.CPMConstants;
import curam.cpm.message.impl.CONTRACTPROVIDEROFFERINGLINKExceptionCreator;
import curam.cpm.message.impl.CONTRACTVERSIONExceptionCreator;
import curam.cpm.sl.entity.impl.ContractVersionAdapter;
import curam.cpm.sl.entity.struct.ContractVersionDtls;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.message.impl.UTILIZATIONCONTRACTExceptionCreator;
import curam.provider.LicenseType;
import curam.provider.impl.CommunicationCVLink;
import curam.provider.impl.CommunicationCVLinkDAO;
import curam.provider.impl.License;
import curam.provider.impl.LicenseDAO;
import curam.provider.impl.LicenseTypeEntry;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderGroupAssociate;
import curam.provider.impl.ProviderOrganization;
import curam.provider.impl.ProviderOrganizationDAO;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.ProviderStatusEntry;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingPlaceLimit;
import curam.providerservice.impl.ProviderOfferingPlaceLimitDAO;
import curam.providerservice.impl.ProviderOfferingPlaceLimitTypeEntry;
import curam.providerservice.impl.ProviderOfferingRate;
import curam.providerservice.impl.ProviderOfferingRateDAO;
import curam.providerservice.impl.ProviderOfferingRateTypeEntry;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalElement;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.persistence.EntityAdapter;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.BasePlusConcreteTableImpl;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.State;
import curam.util.transaction.TransactionInfo;
import curam.util.type.CodeTableItemIdentifier;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateRange.DateRangeSet;
import curam.util.type.DateTime;
import curam.util.type.DeepCloneable;
import curam.util.type.HistoricalEventHelper;
import curam.util.type.StringHelper;


/**
 * {@inheritDoc}
 */
// BEGIN, CR00183213, SS
public abstract class ContractVersionImpl<CONCRETE_ENTITY extends ContractVersion, CONCRETE_CLASS_DTLS_STRUCT extends DeepCloneable> extends BasePlusConcreteTableImpl<Long, CONCRETE_ENTITY, ContractVersionDtls, CONCRETE_CLASS_DTLS_STRUCT>
  implements ContractVersion {
  // END, CR00183213

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for printContract events.
   */
  @Inject
  protected EventDispatcherFactory<ContractVersionPrintContractEvents> printContractEventDispatcherFactory;

  /**
   * Event dispatcher for previewContract events.
   */
  @Inject
  protected EventDispatcherFactory<ContractVersionPreviewContractEvents> previewContractEventDispatcherFactory;

  /**
   * Event dispatcher for validateContractedProviderOfferingRates events.
   */
  @Inject
  protected EventDispatcherFactory<ContractVersionValidateContractedProviderOfferingRatesEvents> validateContractedProviderOfferingRatesEventDispatcherFactory;

  /**
   * Event dispatcher for validateContractedProviderOfferingPlaceLimits events.
   */
  @Inject
  protected EventDispatcherFactory<ContractVersionValidateContractedProviderOfferingPlaceLimitsEvents> validateContractedProviderOfferingPlaceLimitsEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ContractVersionInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ContractVersionModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789
  
  // BEGIN, CR00292749, MR
  /**
   * Reference to CMIS Access Interface.
   */
  @Inject
  protected CMISAccessInterface cmisAccessInterface;
  
  /**
   * Reference to communication contract version link DAO.
   */
  @Inject
  protected CommunicationCVLinkDAO communicationCVLinkDAO;
  // END, CR00292749

  @Inject
  protected ContractStatusHistoryDAO contractStatusHistoryDAO;

  @Inject
  protected ContractStatusHistoryCreatorDAO contractStatusHistoryCreatorDAO;

  @Inject
  protected ProviderOrganizationDAO providerOrganizationDAO;

  @Inject
  protected ContractVersionProviderOfferingDAO contractPOGroupDAO;

  @Inject
  protected ContractVersionProviderGroupAssociateDAO contractVersionProviderGroupAssociateDAO;

  @Inject
  protected CPMContractDAO cpmContractDAO;

  @Inject
  protected ContractContactDAO contractContactDAO;

  @Inject
  protected LicenseDAO licenseDAO;

  @Inject
  protected ProviderDAO providerDAO;

  @Inject
  protected ProviderOfferingRateDAO providerOfferingRateDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  @Inject
  protected ProviderOfferingPlaceLimitDAO providerOfferingPlaceLimitDAO;

  @Inject
  protected ContractVersionDAO contractVersionDAO;

  @Inject
  protected ContractVersionProviderOfferingDAO contractVersionProviderOfferingDAO;

  /**
   * {@inheritDoc}
   */
  public LicenseTypeEntry getRequiredLicenseType() {
    return LicenseTypeEntry.get(getBaseRowDtls().requiredLicenseType);
  }

  /**
   * {@inheritDoc}
   */
  public List<ContractStatusHistory> getStatusHistory() {
    return Collections.unmodifiableList(contractStatusHistoryDAO.searchBy(this));
  }

  protected ContractStatusHistory getLatestStatusHistory() {
    return HistoricalEventHelper.latest(getStatusHistory());
  }

  /**
   * {@inheritDoc}
   */
  public ContractTerminationReasonEntry getTerminationReason() {
    return ContractTerminationReasonEntry.get(
      getBaseRowDtls().terminationReason);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderOrganization getProviderOrganization() {

    final long providerID = getBaseRowDtls().concernRoleID;

    return providerID == 0 ? null : providerOrganizationDAO.get(providerID);

  }

  /**
   * {@inheritDoc}
   */
  public Set<ProviderOffering> getProviderOfferings() {

    final Set<ContractVersionProviderOffering> contractPOGroups = getContractVersionProviderOfferings();

    final Set<ProviderOffering> providerOfferings = new HashSet<ProviderOffering>(
      contractPOGroups.size());

    for (final ContractVersionProviderOffering contractPOGroup : contractPOGroups) {
      providerOfferings.add(contractPOGroup.getProviderOffering());

    }
    return Collections.unmodifiableSet(providerOfferings);
  }

  /**
   * {@inheritDoc}
   */
  public Set<ContractContact> getContacts() {
    return Collections.unmodifiableSet(contractContactDAO.searchBy(this));
  }

  /**
   * Gets the set of contract version provider offerings based on a specified
   * set of search criteria.
   *
   * @return The set of contract version provider offerings.
   */
  protected Set<ContractVersionProviderOffering> getContractVersionProviderOfferings() {

    return contractPOGroupDAO.searchBy(this);

  }

  /**
   * Gets the set of
   * {@linkplain curam.contracts.impl.ContractVersionProviderGroupAssociate}s
   * associated with the {@linkplain curam.contracts.impl.ContractVersion}.
   *
   * @return set of
   * {@linkplain curam.contracts.impl.ContractVersionProviderGroupAssociate}s
   * associated with the
   * {@linkplain curam.contracts.impl.ContractVersion}.
   */
  protected Set<ContractVersionProviderGroupAssociate> getContractVersionProviderGroupAssociate() {

    return contractVersionProviderGroupAssociateDAO.searchBy(this);

  }

  /**
   * Gets the set of {@linkplain curam.contracts.impl.ContractContact}s
   * associated with the {@linkplain curam.contracts.impl.ContractVersion}.
   *
   * @return set of {@linkplain curam.contracts.impl.ContractContact}s
   * associated with the
   * {@linkplain curam.contracts.impl.ContractVersion}.
   */
  protected Set<ContractContact> getContractContacts() {

    return contractContactDAO.searchBy(this);

  }

  /**
   * {@inheritDoc}
   */
  public int getAmendmentVersionNumber() {

    return getBaseRowDtls().amendmentVersionNumber;
  }

  /**
   * {@inheritDoc}
   */
  public CPMContract getCPMContract() {

    return cpmContractDAO.get(getBaseRowDtls().cpmContractID);
  }

  // BEGIN, CR00089491, JM

  /**
   * {@inheritDoc}
   */
  public boolean getRenewedContractInd() {

    return getBaseRowDtls().renewedContractInd;

  }

  // END, CR00089491

  /**
   * {@inheritDoc}
   */
  public Set<ServiceOffering> getCommonApprovedProviderServiceOfferings() {

    final ProviderOrganization providerOrganization = getProviderOrganization();

    // NB the processing differs depending on the concrete type of
    // ProviderOrganization
    return Collections.unmodifiableSet(
      providerOrganization.getCommonApprovedProviderServiceOfferings(this));

  }

  /**
   * Sets the lifetime of the contract version.
   *
   * @param value
   * the lifetime of the contract version
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_CONTRACT_RENEWED_STARTDATE_MODIFIED} -
   * If the contract has been renewed and Start Date is modified.
   */
  public void setDateRange(DateRange value) {

    getBaseRowDtls().startDate = value.start();
    getBaseRowDtls().endDate = value.end();

    // BEGIN, CR00089491, JM
    // Check to see contract has been renewed
    if (getBaseRowManager().getOriginalDtls().renewedContractInd == true) {

      // if it has check to see that the start date has not been modified
      if (!getBaseRowManager().getOriginalDtls().startDate.equals(
        getBaseRowDtls().startDate)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_XRV_CONTRACT_RENEWED_STARTDATE_MODIFIED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

      }
    }
    // END, CR00089491

    // field validation
    value.validateRange();
    value.validateStarted();

    // BEGIN CR00087407, GP
    value.validateEnded();
    // END CR00087407
  }

  /**
   * {@inheritDoc}
   */
  public void setRequiredLicenseType(final LicenseTypeEntry value) {

    getBaseRowDtls().requiredLicenseType = value.getCode();

  }

  /**
   * Sets the comments for the contract version.
   *
   * @param value
   * the comments for the contract version.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * {@link curam.message.CONTRACTVERSION#ERR_FV_COMMENTS_LONG} - If the length
   * of the comments exceeds 200 characters.
   */
  public void setComments(String value) {

    getBaseRowDtls().comments = value;

    if (getComments().length() > ContractVersionAdapter.kMaxLength_comments) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_FV_COMMENTS_LONG(
          ContractVersionAdapter.kMaxLength_comments),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

    }

  }

  /**
   * Sets the name for the contract version.
   *
   * @param value
   * the name for the contract version.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * {@link curam.message.CONTRACTVERSION#ERR_FV_NAME_LONG} - If the length of
   * the name exceeds 100 characters.
   */
  public void setName(String value) {

    getBaseRowDtls().name = value;

    if (getName().length() > ContractVersionAdapter.kMaxLength_name) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_FV_NAME_LONG(
          ContractVersionAdapter.kMaxLength_name),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
  }

  /**
   * {@inheritDoc}
   */
  public void setDateSigned(Date value) {

    getBaseRowDtls().dateSigned = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setContractServicesType(ContractServicesTypeEntry value) {

    getBaseRowDtls().contractServicesType = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setGenerationReason(ContractGenerationReasonEntry value) {

    getBaseRowDtls().generationReason = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setTerminationReason(ContractTerminationReasonEntry value) {

    getBaseRowDtls().terminationReason = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setGenerationDate(Date value) {

    getBaseRowDtls().generationDate = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderOrganization(final ProviderOrganization value) {

    getBaseRowDtls().concernRoleID = (value == null ? 0 : value.getID());

  }

  /**
   * {@inheritDoc}
   */
  public void setCPMContract(final CPMContract value) {

    getBaseRowDtls().cpmContractID = (value == null ? 0 : value.getID());

  }

  // BEGIN, CR00089491, JM

  /**
   * {@inheritDoc}
   */
  public void setRenewedFromContractVersion(final boolean value) {

    getBaseRowDtls().renewedContractInd = value;

  }

  // END, CR00089491


  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// none required please see CR00087353 and CR00087414 for further
    // information.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none required
  }

  /**
   * Validates that all mandatory fields are populated.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>{@link curam.message.CONTRACTVERSION#ERR_FV_NAME_NOT_ENTERED} - If the
   * name of the contract is not entered. </li>
   * </ul>
   *
   */
  public void mandatoryFieldValidation() {

    getDateRange().validateStarted();

    if (StringHelper.isEmpty(getName())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_FV_NAME_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // BEGIN, CR00280929, DJ
    // Prevents the modification of the start date of the contract to a date
    // which is earlier than the start date of the original version of the
    // contract or today's date, whichever is earlier.
    Date earlierDate = new Date();

    if (Date.getCurrentDate().after(
      getBaseRowManager().getOriginalDtls().startDate)) {
      earlierDate = getBaseRowManager().getOriginalDtls().startDate;
    } else {
      earlierDate = Date.getCurrentDate();
    }

    if (getDateRange().startsBefore(earlierDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_STARTDATE_EARLIER_THAN_EITHER_OF_CONTRACTSTART_AND_TODAY(
          getDateRange().start(),
          getBaseRowManager().getOriginalDtls().startDate,
          Date.getCurrentDate()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END, CR00280929


  }

  /**
   * Inserts the contract and contract status history. Checks the provider
   * organization security to insert.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_STARTDATE_EARLIER_THAN_TODAY} -
   * If the contract starts in the past.
   */
  @Override
  public void insert() throws InformationalException {

    // Check the provider organization Security
    providerSecurity.checkProviderOrganizationSecurity(
      getProviderOrganization());

    // BEGIN, CR00235789, AK
    // Raise the pre insert contract version event.
    insertEventDispatcherFactory.get(ContractVersionInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    boolean amendedContractFlag = false;

    // check if this new contract is of a result of an amendment
    for (curam.contracts.impl.ContractVersion contractVersion : contractVersionDAO.searchBy(
      getProviderOrganization())) {

      if (contractVersion.getCPMContract().getReferenceNumber().equals(
        getCPMContract().getReferenceNumber())) {

        amendedContractFlag = true;
      }
    }

    if (amendedContractFlag == false) {
      if (getDateRange().startsInPast()) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_STARTDATE_EARLIER_THAN_TODAY(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }

    // if the status of the provider is closed
    if (getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {
      if (providerDAO.get(getProviderOrganization().getID()).getLifecycleState().equals(
        ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 5);
        ValidationHelper.failIfErrorsExist();
      }
    }

    curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    try {

      getBaseRowDtls().createdBy = systemUserObj.getUserDetails().userName;
    } catch (final Exception e) {
      // translate any exceptions to a runtime exception
      throw new AppRuntimeException(e);
    }

    super.insert();

    final ContractStatusHistoryCreator contractStatusHistory = contractStatusHistoryCreatorDAO.newInstance();

    contractStatusHistory.setContractVersion(this);

    // Insert contract status history,
    contractStatusHistory.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert contract version event.
    insertEventDispatcherFactory.get(ContractVersionInsertEvents.class).postInsert(
      this);
    // END, CR00235789

  }

  /**
   * Inserts the contract and contract status history. Checks the provider
   * organization security to insert.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   */

  /**
   * Activates this contract version.Checks the provider organization security
   * to activate the contract.
   *
   * @param versionNo
   * the version number of the contract being activated
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_FV_ACTIVATE_NO_DATESIGNED} -
   * If the Date signed is not entered.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XFV_DATE_SIGNED_MUST_BE_AFTER_GENERATION_DATE} -
   * If the Date Signed is before the generation date.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_PROVIDER_GROUP_ASSOCIATE_NOT_APPROVED} -
   * If contract is for the provider group and provider group
   * associates named in the contract are not approved.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_PROVIDER_NOT_APPROVED} -
   * If contract is for the provider and the provider is not approved.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_NO_LICENSE_TYPE_PROVIDERGROUP} -
   * If there is no approved license for the providers named in the
   * provider group contract.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_CONTRACT_NOTCOVERED_BY_LICENSE_GROUP} -
   * If the providers named in the provider group contract, do not
   * have approved licenses covering the entire contract period.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_NO_LICENSE_TYPE} -
   * If a license type is specified on a contract, an approved license
   * of that type is not recorded for the provider.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_CONTRACT_NOTCOVERED_BY_LICENSE} -
   * If a license type is specified on a contract,The provider does
   * not have approved licenses covering the entire contract period.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_PROVIDER_GROUP_ASSOCIATE_START_DATE_AFTER_CONTRACT_START_DATE} -
   * If the start date of any provider group associate in the contract
   * is after the start date of the contract
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_PROVIDER_GROUP_ASSOCIATE_END_DATE_BEFOR_CONTRACT_END_DATE} -
   * If the end date of any provider group associate in the contract
   * is before the end date of the contract.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_PROVIDER_GROUP_ASSOCIATE_REMOVED_FROM_GROUP} -
   * If the provider group associate named in a contract has been
   * directly removed from the provider group.    
   */
  protected void activate(int versionNo) throws InformationalException {

    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      getProviderOrganization());
    // BEGIN, CR00157706, ASN
    for (ProviderOffering providerOffering : getProviderOfferings()) {
      for (ProviderOfferingRate offeringRate : providerOfferingRateDAO.searchBy(
        providerOffering)) {

        if (offeringRate.getContractVersion() != null) {

          ContractVersion contractVersion = offeringRate.getContractVersion();

          if (!CONTRACTSTATUSEntry.LIVE.equals(
            contractVersion.getLifecycleState())) {
            continue;
          }

          if (offeringRate.getDateRange().overlapsWith(getDateRange())) {

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              CONTRACTPROVIDEROFFERINGLINKExceptionCreator.ERR_CONTRACTPROVIDEROFFERINGLINK_XRV_PROVIDER_AND_PROVIDER_OFFERING_ALREADY_ON_LIVE_CONTRACT_CANNOT_ACTIVATE(
                offeringRate.getProviderOffering().getServiceOffering().getName(),
                offeringRate.getProviderOffering().getProvider().getName(),
                offeringRate.getContractVersion().getCPMContract().getReferenceNumber()),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);
            ValidationHelper.failIfErrorsExist();
          }

        }
      }

    }
    // END, CR00157706

    // Business rule: The Date Signed must be entered.
    if (this.getBaseRowDtls().dateSigned.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_FV_ACTIVATE_NO_DATESIGNED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Business Rule: Date signed must be completed later or than or equal to
    // the generation date.
    if (!getBaseRowDtls().dateSigned.isZero()
      && getBaseRowDtls().dateSigned.before(getBaseRowDtls().generationDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XFV_DATE_SIGNED_MUST_BE_AFTER_GENERATION_DATE(
          getBaseRowDtls().dateSigned, getBaseRowDtls().generationDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // BEGIN, CR00090004, JM
    // Check to see that provider or provider group associates are approved
    if (this.getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDERGROUP)) {

      StringBuffer nonApprovedAssociateErrorBuffer = new StringBuffer();

      Boolean nonApprovedAssociateError = false;

      for (ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : this.getContractVersionProviderGroupAssociate()) {

        if (!contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getLifecycleState().equals(
          ProviderStatusEntry.APPROVED)) {

          nonApprovedAssociateError = true;
          String details = contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getName()
            + CuramConst.gkComma + CuramConst.gkSpace;

          nonApprovedAssociateErrorBuffer.append(details);
        }
      }

      if (nonApprovedAssociateError) {

        String nonApprovedAssociateErrorString = nonApprovedAssociateErrorBuffer.toString();

        // Remove trailing comma & space
        nonApprovedAssociateErrorString = nonApprovedAssociateErrorString.substring(
          0, nonApprovedAssociateErrorString.length() - 2);

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_XRV_PROVIDER_GROUP_ASSOCIATE_NOT_APPROVED(
            nonApprovedAssociateErrorString),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

    } else if (this.getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {

      if (!providerDAO.get(this.getProviderOrganization().getID()).getLifecycleState().equals(
        ProviderStatusEntry.APPROVED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_XRV_PROVIDER_NOT_APPROVED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

      }

    }
    // END, CR00090004

    // Check to see if a License has been entered for the Contract
    if (getBaseRowDtls().requiredLicenseType.length() != 0) {

      // Check for contract type
      if (this.getProviderOrganization().getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDERGROUP)) {

        StringBuffer approvedLicenseErrorBuffer = new StringBuffer();
        StringBuffer coverPeriodErrorBuffer = new StringBuffer();

        Boolean approvedLicenseError = false;
        Boolean coverPeriodError = false;

        for (ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : this.getContractVersionProviderGroupAssociate()) {

          // Business Rule For Provider Group Contract: If a license type is
          // specified on a contract
          // an approved license of that type must be recorded for the providers
          // in the provider group
          // in order for the contract to be activated
          List<License> licenses = licenseDAO.searchApprovedLicencesByProviderAndType(
            contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getID(),
            getBaseRowDtls().requiredLicenseType);

          if (licenses.isEmpty()) {

            approvedLicenseError = true;
            String details = contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getName()
              + CuramConst.gkComma + CuramConst.gkSpace;

            approvedLicenseErrorBuffer.append(details);
          }

          if (!licenses.isEmpty()) {

            // Business Rule for Provider Group Contract: If a license type is
            // specified on a contract the license period must cover the full
            // period of the contract for providers in the provider group.
            boolean coverLincensePeriod = false;

            for (DateRange.DateRangeSet<License> dateRange : DateRange.findContiguousDateRanges(
              licenses)) {

              if ((dateRange.getDateRange().start().before(
                this.getBaseRowDtls().startDate)
                  || dateRange.getDateRange().start().equals(
                    this.getBaseRowDtls().startDate))
                      && (dateRange.getDateRange().end().after(
                        this.getBaseRowDtls().endDate)
                          || dateRange.getDateRange().end().equals(
                            this.getBaseRowDtls().endDate))) {

                coverLincensePeriod = true;
              }
            }

            if (!coverLincensePeriod) {

              coverPeriodError = true;
              String details = contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getName()
                + CuramConst.gkComma + CuramConst.gkSpace;

              coverPeriodErrorBuffer.append(details);

            }
          }
        }

        if (approvedLicenseError) {

          String approvedLicenseErrorString = approvedLicenseErrorBuffer.toString();

          // Remove trailing comma & space
          approvedLicenseErrorString = approvedLicenseErrorString.substring(0,
            approvedLicenseErrorString.length() - 2);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            CONTRACTVERSIONExceptionCreator.ERR_XRV_NO_LICENSE_TYPE_PROVIDERGROUP(
              new CodeTableItemIdentifier(LicenseType.TABLENAME,
              getBaseRowDtls().requiredLicenseType),
              approvedLicenseErrorString),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);

        }

        if (coverPeriodError) {

          String coverPeriodErrorString = coverPeriodErrorBuffer.toString();

          // Remove trailing comma & space
          coverPeriodErrorString = coverPeriodErrorString.substring(0,
            coverPeriodErrorString.length() - 2);

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            CONTRACTVERSIONExceptionCreator.ERR_XRV_CONTRACT_NOTCOVERED_BY_LICENSE_GROUP(
              coverPeriodErrorString,
              new CodeTableItemIdentifier(LicenseType.TABLENAME,
              getBaseRowDtls().requiredLicenseType),
              this.getBaseRowDtls().startDate,
              this.getBaseRowDtls().endDate),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);

        }

      } else if (this.getProviderOrganization().getConcernRoleType().equals(
        CONCERNROLETYPEEntry.PROVIDER)) {
        // Provider contract, we only want to validate against this provider

        // Business Rule: If a license type is specified on a contract an
        // approved license of that type must be recorded for the provider in
        // order for the contract to be activated
        List<License> licenses = licenseDAO.searchApprovedLicencesByProviderAndType(
          getBaseRowDtls().concernRoleID, getBaseRowDtls().requiredLicenseType);

        if (licenses.isEmpty()
          && getBaseRowDtls().requiredLicenseType.length() != 0) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            CONTRACTVERSIONExceptionCreator.ERR_XRV_NO_LICENSE_TYPE(
              new CodeTableItemIdentifier(LicenseType.TABLENAME,
              getBaseRowDtls().requiredLicenseType)),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);

        }

        if (!licenses.isEmpty()) {

          // Business Rule: If a license type is specified on a contract the
          // license period must cover the full period of the contract.
          boolean coverLincensePeriod = false;

          for (DateRange.DateRangeSet<License> dateRange : DateRange.findContiguousDateRanges(
            licenses)) {

            if ((dateRange.getDateRange().start().before(
              this.getBaseRowDtls().startDate)
                || dateRange.getDateRange().start().equals(
                  this.getBaseRowDtls().startDate))
                    && (dateRange.getDateRange().end().after(
                      this.getBaseRowDtls().endDate)
                        || dateRange.getDateRange().end().equals(
                          this.getBaseRowDtls().endDate))) {

              coverLincensePeriod = true;
            }
          }

          if (!coverLincensePeriod) {

            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              CONTRACTVERSIONExceptionCreator.ERR_XRV_CONTRACT_NOTCOVERED_BY_LICENSE(
                new CodeTableItemIdentifier(LicenseType.TABLENAME,
                getBaseRowDtls().requiredLicenseType),
                this.getBaseRowDtls().startDate,
                this.getBaseRowDtls().endDate),
                curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
                0);

          }
        }
      }
    }

    // Business Rule: A Contract cannot be activated if the start date of any
    // provider group associate in the
    // contract is after the start date of the contract or if the end date of
    // any provider group associate
    // in the contract is before the end date of the contract.
    // Business Rule: A Contract cannot be activated if, since generation, a
    // provider group associate named in a
    // contract has been directly removed from the provider group
    StringBuffer startDateMessages = new StringBuffer();
    StringBuffer endDateMessages = new StringBuffer();
    StringBuffer providerRemovedMessages = new StringBuffer();

    boolean endDateBeforeContractEndDate = false;
    boolean startDateAfterContractStartDate = false;
    boolean providerRemovedFromGroup = false;

    // Get the client Locale.
    String clientLocale = TransactionInfo.getProgramLocale();

    Set<ContractVersionProviderGroupAssociate> contractVersionProviderGroupAssociates = contractVersionProviderGroupAssociateDAO.searchBy(
      this);

    for (final ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : contractVersionProviderGroupAssociates) {

      ProviderGroupAssociate providerGroupAssociate = contractVersionProviderGroupAssociate.getProviderGroupAssociate();

      DateRange dateRange = providerGroupAssociate.getDateRange();

      // Does the Provider Group Associate end before the Contract
      if (!this.getBaseRowDtls().endDate.isZero() && !dateRange.end().isZero()
        && dateRange.endsBefore(this.getBaseRowDtls().endDate)) {
        endDateBeforeContractEndDate = true;
        String details = providerGroupAssociate.getProvider().getName()
          + curam.cpm.message.CONTRACTVERSION.PROVIDER_GROUP_ASSOCIATE_ENDDATE.getMessageText(
            clientLocale)
            + dateRange.end()
            + CuramConst.gkComma;

        endDateMessages.append(details);

      }
      // Does the Provider Group Associate Start after the Contract
      if (dateRange.startsAfter(this.getBaseRowDtls().startDate)) {
        startDateAfterContractStartDate = true;
        String details = providerGroupAssociate.getProvider().getName()
          + curam.cpm.message.CONTRACTVERSION.PROVIDER_GROUP_ASSOCIATE_STARTDATE.getMessageText(
            clientLocale)
            + dateRange.start()
            + CuramConst.gkComma;

        startDateMessages.append(details);
      }
      // Is the Provider still part of the Group
      if (providerGroupAssociate.getLifecycleState().getCode().compareTo(
        RECORDSTATUS.CANCELLED)
          == 0) {
        providerRemovedFromGroup = true;
        String details = providerGroupAssociate.getProvider().getName()
          + CuramConst.gkComma;

        providerRemovedMessages.append(details);

      }

    }

    if (startDateAfterContractStartDate) {
      startDateMessages = startDateMessages.replace(
        startDateMessages.length() - 1, startDateMessages.length(), "");
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_PROVIDER_GROUP_ASSOCIATE_START_DATE_AFTER_CONTRACT_START_DATE(
          getBaseRowDtls().startDate, startDateMessages.toString()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (endDateBeforeContractEndDate) {
      endDateMessages = endDateMessages.replace(endDateMessages.length() - 1,
        endDateMessages.length(), "");
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_PROVIDER_GROUP_ASSOCIATE_END_DATE_BEFOR_CONTRACT_END_DATE(
          getBaseRowDtls().endDate, endDateMessages.toString()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    if (providerRemovedFromGroup) {
      providerRemovedMessages = providerRemovedMessages.replace(
        providerRemovedMessages.length() - 1, providerRemovedMessages.length(),
        "");
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_PROVIDER_GROUP_ASSOCIATE_REMOVED_FROM_GROUP(
          providerRemovedMessages.toString(), getBaseRowDtls().generationDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  /**
   * Generates a contract.Checks the provider organization security to generate
   * the contract.
   *
   * @param versionNo
   * the version number of the contract to be generated
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_FV_GENERATED_NO_GENERATIONREASON} -
   * If the Generation Reason is not entered .
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_GENERATED_NO_SERVICES} -
   * If there are no services present in the contract.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_GENERATED_NO_GROUPASSOCIATE} -
   * If there are no providers added in the provider group contract.
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_GENERATED_GROUP_ASSOCIATE_STARTDATES} -
   * If the start date of any provider group associate in the contract
   * is after the Start Date of the contract.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_GENERATED_GROUP_ASSOCIATE_ENDDATES} -
   * If the End Date of any provider group associate in the contract
   * is before the End Date of the contract.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_GENERATED_GROUP_PROVIDERS_REMOVED} -
   * If a provider group associate named in a contract has been
   * removed from the provider group outside of the contract
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_GENERATED_GROUP_PROVOFFERINGS_STARTDATES} -
   * if the start date of any provider offering in the contract is
   * after the Start Date of the contract
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_GENERATED_GROUP_PROVOFFERINGS_ENDDATES} -
   * if the End Date of any provider offering in the contract is
   * before the End Date of the contract.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_GENERATED_GROUP_PROVOFFERINGS_REMOVED} -
   * If a provider offering named in a contract has been removed from
   * the provider outside of the contract.
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_CEV_PROVIDER_AND_PROVIDER_OFFERING_ALREADY_ON_LIVE_CONTRACT} -
   * If Provider Offering is present in more than one contract for a
   * Provider, or a Provider Group on which that Provider is named,
   * which is live and has an end date in the future, at any given
   * time.
   */
  protected void generate(int versionNo) throws InformationalException {

    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      getProviderOrganization());

    // Business rule: The Generation Reason must be entered.
    if (this.getBaseRowDtls().generationReason.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_FV_GENERATED_NO_GENERATIONREASON(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Business rule: This contract cannot be generated as no services have been
    // added.
    Set<ContractVersionProviderOffering> contractProviderOfferingLink = contractPOGroupDAO.searchBy(
      this);

    if (contractProviderOfferingLink.size() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_NO_SERVICES(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    ProviderOrganization providerOrganization = providerOrganizationDAO.get(
      this.getBaseRowDtls().concernRoleID);

    // BEGIN, CR00158173, AS
    if (providerOrganization.getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {

      boolean providerOfferingsRemoved = false;
      StringBuilder providerOfferingRemovedString = new StringBuilder();

      for (ContractVersionProviderOffering contractPOLink : contractProviderOfferingLink) {

        if (contractPOLink.getProviderOffering().getLifecycleState().getCode().equals(
          ProviderOfferingStatusEntry.CANCELED.getCode())) {

          if (providerOfferingsRemoved) {
            providerOfferingRemovedString.append(CuramConst.gkComma);
          } else {
            providerOfferingsRemoved = true;
          }

          providerOfferingRemovedString.append(
            CuramConst.gkSpace
              + contractPOLink.getProviderOffering().getProvider().getName()
              + CuramConst.gkSpace + CuramConst.gkDash + CuramConst.gkSpace
              + contractPOLink.getProviderOffering().getServiceOffering().getName());
        }
      }

      // A contract cannot be generated if a provider offering named in a
      // contract has been removed from the provider outside of the contract.
      if (providerOfferingsRemoved) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_XRV_CONTRACT_PROVOFFERINGS_DELETED_CONTRACT_CANNOT_BE_GENERATED(
            providerOfferingRemovedString.toString()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }

    // Validations for Provider Group Contracts
    // END, CR00158173
    if (providerOrganization.getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDERGROUP)) {

      // Business rule: A contract must have at least one 
      // provider group associate added before it can be generated.

      Set<ContractVersionProviderGroupAssociate> contractVersionProviderGroupAssociateList = contractVersionProviderGroupAssociateDAO.searchBy(
        this);
       
      if (contractVersionProviderGroupAssociateList.size() == 0) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_NO_GROUPASSOCIATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      StringBuffer stringStartDatesErrorBuffer = new StringBuffer();
      StringBuffer stringEndDatesErrorBuffer = new StringBuffer();
      StringBuffer providerRemovedMessages = new StringBuffer();

      boolean groupAssociateStartDatesError = false;
      boolean groupAssociateEndDatesError = false;
      boolean providerRemovedFromGroup = false;

      for (ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : contractVersionProviderGroupAssociateList) {

        if (contractVersionProviderGroupAssociate.getProviderGroupAssociate().getDateRange().start().after(
          this.getBaseRowDtls().startDate)) {

          groupAssociateStartDatesError = true;

          // BEGIN, CR00090286, DMC
          stringStartDatesErrorBuffer.append(
            contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getName()
              + CuramConst.gkDash
              + contractVersionProviderGroupAssociate.getProviderGroupAssociate().getDateRange().start().toString()
              + CuramConst.gkComma);
          // END, CR00090286
        }

        if (!contractVersionProviderGroupAssociate.getProviderGroupAssociate().getDateRange().end().isZero()
          && contractVersionProviderGroupAssociate.getProviderGroupAssociate().getDateRange().end().before(
            this.getBaseRowDtls().endDate)) {

          groupAssociateEndDatesError = true;

          // BEGIN, CR00090286, DMC
          stringEndDatesErrorBuffer.append(
            contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getName()
              + CuramConst.kSeparator
              + contractVersionProviderGroupAssociate.getProviderGroupAssociate().getDateRange().end().toString()
              + CuramConst.gkComma);
          // END, CR00090286
        }

        // Is the Provider still part of the Group
        if (contractVersionProviderGroupAssociate.getProviderGroupAssociate().getLifecycleState().getCode().compareTo(
          RECORDSTATUSEntry.CANCELLED.getCode())
            == 0) {

          providerRemovedFromGroup = true;

          // BEGIN, CR00090286, DMC
          providerRemovedMessages.append(
            contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getName()
              + CuramConst.gkComma);
          // END, CR00090286
        }
      }
      
      // Business rule:A contract cannot be generated 
      // is after the Start Date of the contract

      if (groupAssociateStartDatesError) {
        stringStartDatesErrorBuffer.replace(
          stringStartDatesErrorBuffer.length() - 1,
          stringStartDatesErrorBuffer.length(), "");

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_GROUP_ASSOCIATE_STARTDATES(
            this.getBaseRowDtls().startDate,
            stringStartDatesErrorBuffer.toString()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      // Business rule:A contract cannot be generated 
      // the End Date of the contract.
      if (groupAssociateEndDatesError) {
        stringEndDatesErrorBuffer.replace(
          stringEndDatesErrorBuffer.length() - 1,
          stringEndDatesErrorBuffer.length(), "");

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_GROUP_ASSOCIATE_ENDDATES(
            this.getBaseRowDtls().endDate, stringEndDatesErrorBuffer.toString()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      // Business rule: A contract that is not performance based cannot be generated
      // if a provider group associate named in a contract has been removed
      // from the provider group outside of the contract.
      // Provider Group Associate must be removed.
      if (providerRemovedFromGroup) {
        providerRemovedMessages = providerRemovedMessages.replace(
          providerRemovedMessages.length() - 1,
          providerRemovedMessages.length(), "");
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_GROUP_PROVIDERS_REMOVED(
            providerRemovedMessages.toString()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      StringBuffer stringPOStartDatesErrorBuffer = new StringBuffer();
      StringBuffer stringPOEndDatesErrorBuffer = new StringBuffer();
      StringBuffer stringPORemovedErrorBuffer = new StringBuffer();

      boolean providerOfferingsRemovedError = false;
      boolean providerOfferingsStartDatesError = false;
      boolean providerOfferingsEndDatesError = false;

      // Validation on provider offerings
      for (ContractVersionProviderOffering contractPOLink : contractPOGroupDAO.searchBy(
        this)) {

        if (contractPOLink.getProviderOffering().getDateRange().start().after(
          this.getBaseRowDtls().startDate)) {

          providerOfferingsStartDatesError = true;

          // BEGIN, CR00090286, DMC
          stringPOStartDatesErrorBuffer.append(
            contractPOLink.getProviderOffering().getServiceOffering().getName()
              + CuramConst.gkSpace + CuramConst.gkDash + CuramConst.gkSpace
              + contractPOLink.getProviderOffering().getDateRange().start()
              + CuramConst.gkComma);
          // END, CR00090286
        }

        if (!contractPOLink.getProviderOffering().getDateRange().end().isZero()
          && contractPOLink.getProviderOffering().getDateRange().end().before(
            this.getBaseRowDtls().endDate)) {

          providerOfferingsEndDatesError = true;

          // BEGIN, CR00090286, DMC
          stringPOEndDatesErrorBuffer.append(
            contractPOLink.getProviderOffering().getServiceOffering().getName()
              + CuramConst.gkSpace + CuramConst.gkDash + CuramConst.gkSpace
              + contractPOLink.getProviderOffering().getDateRange().end()
              + CuramConst.gkComma);
          // END, CR00090286
        }

        // BEGIN, CR00089991, DMC
        if (contractPOLink.getProviderOffering().getLifecycleState().getCode().compareTo(
          ProviderOfferingStatusEntry.CANCELED.getCode())
            == 0) {

          providerOfferingsRemovedError = true;

          stringPORemovedErrorBuffer.append(
            CuramConst.gkSpace
              + contractPOLink.getProviderOffering().getProvider().getName()
              + CuramConst.gkSpace + CuramConst.gkDash + CuramConst.gkSpace
              + contractPOLink.getProviderOffering().getServiceOffering().getName()
              + CuramConst.gkComma);
          // END, CR00089991
        }

      }

      // Business rule: A contract cannot be generated if the start date of any
      // provider offering in the contract is after the Start Date of the contract
      if (providerOfferingsStartDatesError) {
        stringPOStartDatesErrorBuffer = stringPOStartDatesErrorBuffer.replace(
          stringPOStartDatesErrorBuffer.length() - 1,
          stringPOStartDatesErrorBuffer.length(), "");

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_GROUP_PROVOFFERINGS_STARTDATES(
            stringPOStartDatesErrorBuffer.toString(),
            this.getBaseRowDtls().startDate),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      // Business rule: A contract cannot be generated if the End Date of any
      // provider offering in the contract is before the End Date of the
      // contract.

      if (providerOfferingsEndDatesError) {

        stringPOEndDatesErrorBuffer = stringPOEndDatesErrorBuffer.replace(
          stringPOEndDatesErrorBuffer.length() - 1,
          stringPOEndDatesErrorBuffer.length(), "");

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_GROUP_PROVOFFERINGS_ENDDATES(
            stringPOEndDatesErrorBuffer.toString(),
            this.getBaseRowDtls().endDate),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      // Business rule: A contract cannot be generated if a provider offering
      // named in a contract has been removed from the provider outside of the
      // contract.
      if (providerOfferingsRemovedError) {
        stringPORemovedErrorBuffer = stringPORemovedErrorBuffer.replace(
          stringPORemovedErrorBuffer.length() - 1,
          stringPORemovedErrorBuffer.length(), "");

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTVERSIONExceptionCreator.ERR_XRV_GENERATED_GROUP_PROVOFFERINGS_REMOVED(
            stringPORemovedErrorBuffer.toString()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

      // Business rule: A Provider Offering can not be present in more than one
      // contract for a Provider,
      // or a Provider Group on which that Provider is named, which is live and
      // has an end date in the future,
      // at any given time.
      for (ContractVersionProviderOffering contractPOLink : contractPOGroupDAO.searchBy(
        this)) {

        ContractVersionProviderOffering conflictingContractVersionProviderOffering = contractPOLink.checkForDuplicateProviderOfferingOnLiveContract(
          contractPOLink.getContractVersion().getDateRange());

        if (conflictingContractVersionProviderOffering != null) {

          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            CONTRACTPROVIDEROFFERINGLINKExceptionCreator.ERR_CEV_PROVIDER_AND_PROVIDER_OFFERING_ALREADY_ON_LIVE_CONTRACT(
              contractPOLink.getProviderOffering().getServiceOffering().getName(),
              contractPOLink.getProviderOffering().getProvider().getName(),
              conflictingContractVersionProviderOffering.getContractVersion().getName()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              0);
        }
      }

      // Contracted ProviderOfferingPlaceLimits cannot overlap or contain coverage
      // gaps
      validateContractedProviderOfferingPlaceLimits();
    }
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected EntityAdapter<Long, ContractVersionDtls> getBaseEntityAdapter() {
    return new ContractVersionAdapter();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected void setDiscriminator(final String value) {
    setContractType(CONTRACTTYPEEntry.get(value));
  }

  /**
   * {@inheritDoc}
   */
  public DateTime getTerminationDateTime() {
    final ContractStatusHistory latestStatus = getLatestStatusHistory();

    // Start CR00094039, JSP
    // return zero date time instead of null
    return latestStatus.getStatus().equals(CONTRACTSTATUSEntry.TERMINATED)
      ? latestStatus.getEventDateTime()
      : DateTime.kZeroDateTime;
    // End CR00094039
  }

  /**
   * Transitions the contract from one state to another and inserts the contract
   * status history.
   *
   * @param oldState
   * the state being left
   * @param newState
   * the state being entered
   * @param versionNo
   * version number known to client code from a previous retrieval
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   */
  protected void transition(final State<CONTRACTSTATUSEntry> oldState,
    final State<CONTRACTSTATUSEntry> newState, final Integer versionNo)
    throws InformationalException {

    // if the status of the provider is closed
    if (getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {
      if (providerDAO.get(getProviderOrganization().getID()).getLifecycleState().equals(
        ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 7);
        ValidationHelper.failIfErrorsExist();
      }
    }

    // set the field which stores the status
    setStatus(newState.getValue());

    // do the state transition
    oldState.transitionTo(newState);

    // Set lastTransitionedBy attribute
    getBaseRowDtls().lastTransitionedBy = getCurrentUserDetails().userName;

    // update the database - bypass the pre-modify logic
    super.modify(versionNo);

    // Only if this is a status change then it should update the status
    if (!oldState.equals(newState)) {
      final ContractStatusHistoryCreator contractStatusHistory = contractStatusHistoryCreatorDAO.newInstance();

      contractStatusHistory.setContractVersion(this);

      // Insert contract status history,
      contractStatusHistory.insert();
    }
  }

  /**
   * Helper method to set the contract status.
   *
   * @param status
   * to set the contract
   */
  protected void setStatus(final CONTRACTSTATUSEntry status) {

    getBaseRowDtls().status = status.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public ContractServicesTypeEntry getContractServicesType() {

    return ContractServicesTypeEntry.get(getBaseRowDtls().contractServicesType);
  }

  /**
   * {@inheritDoc}
   */
  public ContractGenerationReasonEntry getGenerationReason() {

    return ContractGenerationReasonEntry.get(getBaseRowDtls().generationReason);
  }

  /**
   * {@inheritDoc}
   */
  public Date getGenerationDate() {

    return getBaseRowDtls().generationDate;
  }

  /**
   * {@inheritDoc}
   */
  public Date getDateSigned() {

    return getBaseRowDtls().dateSigned;
  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getBaseRowDtls().startDate, getBaseRowDtls().endDate);
  }

  /**
   * {@inheritDoc}
   */
  public String getName() {
    return getBaseRowDtls().name;
  }

  /**
   * {@inheritDoc}
   */
  public CONTRACTTYPEEntry getContractType() {
    return CONTRACTTYPEEntry.get(getBaseRowDtls().contractType);
  }

  /**
   * {@inheritDoc}
   */
  public String getComments() {
    return getBaseRowDtls().comments;
  }

  /**
   * {@inheritDoc}
   */
  public String getCreatedBy() {
    return getBaseRowDtls().createdBy;
  }

  /**
   * {@inheritDoc}
   */
  public CONTRACTSTATUSEntry getLifecycleState() {
    return CONTRACTSTATUSEntry.get(getBaseRowDtls().status);
  }

  /**
   * Sets the type of the contract.
   *
   * @param value
   * the type of contract
   */
  // BEGIN, CR00177241, PM
  protected void setContractType(final CONTRACTTYPEEntry value) {
    // END, CR00177241
    getBaseRowDtls().contractType = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public Set<Provider> getProviders() {

    final Set<Provider> providers = new HashSet<Provider>();

    for (final ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : getContractVersionProviderGroupAssociate()) {

      providers.add(
        contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider());

    }
    return Collections.unmodifiableSet(providers);
  }

  /**
   * {@inheritDoc}
   */
  public String getLastTransitionedBy() {
    return getBaseRowDtls().lastTransitionedBy;
  }

  /**
   * Sets the default values for a new instance.
   */
  public void setNewInstanceDefaults() {

    getBaseRowDtls().amendmentVersionNumber = 1;

    // Set lastTransitionedBy attribute
    getBaseRowDtls().lastTransitionedBy = getCurrentUserDetails().userName;
  }

  /**
   * Gets a {@linkplain curam.core.struct.SystemUserDtls} struct for the current
   * user.
   *
   * @return current user details
   */
  // BEGIN, CR00177241, PM
  protected SystemUserDtls getCurrentUserDetails() {
    // END, CR00177241

    curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    try {
      return systemUserObj.getUserDetails();
    } catch (final Exception e) {
      // translate any exceptions to a runtime exception
      throw new AppRuntimeException(e);
    }
  }

  /**
   * Prints the contract.Checks the provider organization security to print the
   * contract.
   *
   * @param key
   * the key that specifies the contract notification details
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_NOT_GENERATED_CANNOT_PRINT} -
   * If the contract has not been generated, it cannot be printed.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_CONTRACT_DELETED_CANNOT_PRINT} -
   * If the contract has been deleted, it cannot be printed.
   * @throws AppException
   * Generic Exception Signature.
   */
  public void printContract(ContractNotificationKey key) throws AppException,
      InformationalException {

    // Checks provider organization security.
    providerSecurity.checkProviderOrganizationSecurity(
      getProviderOrganization());

    // BEGIN, CR00235789, AK
    // Raise the pre printContract contract version event.
    printContractEventDispatcherFactory.get(ContractVersionPrintContractEvents.class).prePrintContract(
      this, key);
    // END, CR00235789

    // Business Rule: A contract cannot be printed before the contract has been
    // generated.
    if (getLifecycleState().equals(CONTRACTSTATUSEntry.INEDIT)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_NOT_GENERATED_CANNOT_PRINT(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if (getLifecycleState().equals(CONTRACTSTATUSEntry.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_CONTRACT_DELETED_CANNOT_PRINT(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else {

      ContractNotification contractNotification = new ContractNotification();

      contractNotification.printContract(key);
    }

    ValidationHelper.failIfErrorsExist();
    TransactionInfo.setInformationalManager();

    // BEGIN, CR00235789, AK
    // Raise the post printContract contract version event.
    printContractEventDispatcherFactory.get(ContractVersionPrintContractEvents.class).postPrintContract(
      this, key);
    // END, CR00235789
  }

  /**
   * Previews the contract.Checks the provider organization security to preview
   * the contract.
   *
   * @param key
   * the key that specifies the contract notification details
   *
   * @return The contract document details.
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_NOT_GENERATED_CANNOT_PREVIEW} -
   * If the contract has not been generated, it cannot be previewed.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_XRV_CONTRACT_DELETED_CANNOT_PREVIEW} -
   * If the contract has been deleted, it cannot be previewed.
   * @throws AppException
   * Generic Exception Signature.
   */
  public ContractReturnDocDetails previewContract(ContractNotificationKey key)
    throws AppException, InformationalException {

    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      getProviderOrganization());

    // BEGIN, CR00235789, AK
    // Raise the pre previewContract contract version event.
    previewContractEventDispatcherFactory.get(ContractVersionPreviewContractEvents.class).prePreviewContract(
      this, key);
    // END, CR00235789

    ContractReturnDocDetails contractReturnDocDetails = new ContractReturnDocDetails();

    // Business Rule: A contract cannot be previewed before the contract has
    // been generated.
    if (getLifecycleState().equals(CONTRACTSTATUSEntry.INEDIT)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_NOT_GENERATED_CANNOT_PREVIEW(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if (getLifecycleState().equals(CONTRACTSTATUSEntry.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_CONTRACT_DELETED_CANNOT_PREVIEW(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else {

      ContractNotification contractNotification = new ContractNotification();
      
      // BEGIN, CR00292749, MR
      final String contractDocumentType = getContractDocumentType(key);

      final ContractVersion contractVersion = contractVersionDAO.get(
        key.contractVersionID);

      final List<CommunicationCVLink> communicationCVLinkList = communicationCVLinkDAO.searchByContractVersion(
        contractVersion, contractDocumentType);

      if (!communicationCVLinkList.isEmpty()) {
        long communicationID = communicationCVLinkList.get(0).getID();

        if (cmisAccessInterface.isCMISEnabledFor(
          CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)
            && cmisAccessInterface.contentExists(communicationID,
            CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {
          final FileNameAndDataDtls fileNameAndDataDtls = cmisAccessInterface.read(
            communicationID,
            CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION);
	
          contractReturnDocDetails.fileName = CPMConstants.kContractNotificationName;
          contractReturnDocDetails.fileData = fileNameAndDataDtls.fileContent;
        } else {
          contractReturnDocDetails = contractNotification.previewContract(key);
        }
      }
	
      // END, CR00292749
    }

    ValidationHelper.failIfErrorsExist();
    TransactionInfo.setInformationalManager();

    // BEGIN, CR00235789, AK
    // Raise the post previewContract contract version event.
    previewContractEventDispatcherFactory.get(ContractVersionPreviewContractEvents.class).postPreviewContract(
      this, key, contractReturnDocDetails);
    // END, CR00235789

    return contractReturnDocDetails;
  }

  /**
   * Modifies the contract version.Checks the provider organization security to
   * modify the contract.Synchronizes the provider offering place limit date
   * ranges.
   * <p>
   * Also synchronizes contract-level
   * {@linkplain curam.providerservice.impl.ProviderOfferingRate} and
   * {@linkplain curam.providerservice.impl.ProviderOfferingPlaceLimit}
   * dateranges
   * {@linkplain curam.providerservice.impl.ProviderOfferingPlaceLimit}
   * date-ranges with the contract date-range.
   *
   * @param versionNo
   * the version of the contract to modify
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_AMENDED_STARTDATE_EARLIER_THAN_EXISTING_STARTDATE} -
   * If the start date of the new contract version which is resulted
   * as a result of amendment of the contract, is before the previous
   * versions start date.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   * @see curam.contracts.impl.ContractVersionImpl#synchronizeContractedProviderOfferingPlaceLimitDateRanges()
   * @see curam.contracts.impl.UtilizationContractImpl#synchronizeContractedProviderOfferingRateDateRanges()
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // BEGIN CR00096690, SS
    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      getProviderOrganization());
    // END CR00096690

    // BEGIN, CR00235789, AK
    // Raise the pre modify contract version event.
    modifyEventDispatcherFactory.get(ContractVersionModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // if the status of the provider is closed
    if (getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {
      if (providerDAO.get(getProviderOrganization().getID()).getLifecycleState().equals(
        ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 6);
        ValidationHelper.failIfErrorsExist();
      }
    }

    // BEGIN CR00090153, PDN

    // Business rule: On amendment of the contract the start date of the new
    // version must be
    // later than the previous versions start date

    // Get the original and any amended versions of this contract
    Set<ContractVersion> cpmContractVersions = contractVersionDAO.searchBy(
      getCPMContract());

    // If there are any amended versions then check that the start date is not
    // too early
    if (cpmContractVersions.size() > 0) {

      for (ContractVersion contractVersion : cpmContractVersions) {
        // Check if the start date is before the original contract start date
        if (this.getDateRange().startsBefore(
          contractVersion.getDateRange().start())
            && contractVersion.getAmendmentVersionNumber() == 1) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            UTILIZATIONCONTRACTExceptionCreator.ERR_AMENDED_STARTDATE_EARLIER_THAN_EXISTING_STARTDATE(
              getDateRange().start(), contractVersion.getDateRange().start()),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              1);
          break;
        }

      }

    }
    // END CR00090153

    synchronizeContractedProviderOfferingPlaceLimitDateRanges();

    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify contract version event.
    modifyEventDispatcherFactory.get(ContractVersionModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Synchronizes all contracted
   * {@linkplain curam.providerservice.impl.ProviderOfferingPlaceLimit} date
   * ranges with the contract's date range for each
   * {@linkplain curam.contracts.impl.ContractVersionProviderOffering} on the
   * contract.
   * <p>
   * If only one contracted ProviderOfferingPlaceLimit exists for the
   * ContractVersionProviderOffering, its daterange will be set to the
   * contract's date range.<br/> If more than one ProviderOfferingPlaceLimit
   * exists for the ContractVersionProviderOffering, the start date of the
   * earliest contract-level ProviderOfferingPlaceLimit within the contract's
   * date range will be set to the contract's start date, and the end date of
   * the latest contract-level ProviderOfferingPlaceLimit within the contract's
   * date range will be set to the contract's end date.<br/> Any contract-level
   * ProviderOfferingPlaceLimit which no longer overlap with the contract's
   * daterange will be deleted.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void synchronizeContractedProviderOfferingPlaceLimitDateRanges()
    throws InformationalException {

    Set<ProviderOfferingPlaceLimit> allproviderOfferingPlaceLimits;
    Set<ProviderOfferingPlaceLimit> providerOfferingPlaceLimits;

    for (ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      getTransactionHelper().lock(contractProviderOfferingLink);

      // Get the set of ProviderOfferingPlaceLimits for the
      // ContractVersionProviderOffering
      providerOfferingPlaceLimits = providerOfferingPlaceLimitDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion());
      allproviderOfferingPlaceLimits = providerOfferingPlaceLimitDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion());

      // Remove any canceled Place Limits from the set
      for (ProviderOfferingPlaceLimit placeLimit : allproviderOfferingPlaceLimits) {
        if (placeLimit.getLifecycleState().equals(RECORDSTATUSEntry.CANCELLED)) {
          providerOfferingPlaceLimits.remove(placeLimit);
        }
      }

      // Delete any contract-level place limits which now fall outside the
      // contract's
      // date range
      for (ProviderOfferingPlaceLimit providerOfferingPlaceLimit : providerOfferingPlaceLimits) {

        if (!providerOfferingPlaceLimit.getDateRange().overlapsWith(
          getDateRange())) {

          providerOfferingPlaceLimit.remove(
            providerOfferingPlaceLimit.getVersionNo());
        }
      }

      // Re-read the set of place limits that still exist for the Contract
      // Provider Offering
      providerOfferingPlaceLimits = providerOfferingPlaceLimitDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion());

      // If more than one PlaceLimit is specified for this
      // Provider Offering
      if (providerOfferingPlaceLimits.size() > 1) {

        // Set the start date of the earliest one to the contract's start date
        // if the start is before the contract start date
        ProviderOfferingPlaceLimit providerOfferingPlaceLimit = DateRange.earliest(
          providerOfferingPlaceLimits);

        if (providerOfferingPlaceLimit.getDateRange().start().before(
          getDateRange().start())) {
          providerOfferingPlaceLimit.setDateRange(
            new DateRange(getDateRange().start(),
            providerOfferingPlaceLimit.getDateRange().end()));
          providerOfferingPlaceLimit.modify(
            providerOfferingPlaceLimit.getVersionNo());
        }

        // Set the end date of the latest one to the contract end date
        // if the end date is after the contract end date
        providerOfferingPlaceLimit = DateRange.latest(
          providerOfferingPlaceLimits);
        if (providerOfferingPlaceLimit.getDateRange().end().after(
          getDateRange().end())) {
          providerOfferingPlaceLimit.setDateRange(
            new DateRange(providerOfferingPlaceLimit.getDateRange().start(),
            getDateRange().end()));
          providerOfferingPlaceLimit.modify(
            providerOfferingPlaceLimit.getVersionNo());
        }

      } else if (providerOfferingPlaceLimits.size() == 1) {
        // Set the date range of the one place limit to the current contract
        // date

        ProviderOfferingPlaceLimit providerOfferingPlaceLimit = DateRange.earliest(
          providerOfferingPlaceLimits);

        // Default to the existing rate
        Date newStartDate = providerOfferingPlaceLimit.getDateRange().start();
        Date newEndDate = providerOfferingPlaceLimit.getDateRange().end();

        // If the start date or end date lies outside the contract set it to the
        // contract date
        if (providerOfferingPlaceLimit.getDateRange().start().before(
          getDateRange().start())) {
          newStartDate = getDateRange().start();
        }
        if (providerOfferingPlaceLimit.getDateRange().end().after(
          getDateRange().end())) {
          newEndDate = getDateRange().end();
        }

        providerOfferingPlaceLimit.setDateRange(
          new DateRange(newStartDate, newEndDate));
        providerOfferingPlaceLimit.modify(
          providerOfferingPlaceLimit.getVersionNo());
      }
    }
  }

  // BEGIN, CR00156751, ABS
  /**
   * Synchronizes all contract-level
   * {@linkplain curam.providerservice.impl.ProviderOfferingPlaceLimit} date ranges
   * with the contract's date range for each
   * {@linkplain curam.contracts.impl.ContractVersionProviderOffering} on the
   * contract.
   * <p>
   * If only one contract-level provider offering place limit exists for the
   * ContractVersionProviderOffering, its daterange will be set to the
   * contract's date range.<br/> If more than one provider offering place limit exists
   * for the contract version provider offering, the start date of the earliest
   * contract-level provider offering place limit within the contract's date range will
   * be set to the contract's start date, and the end date of the latest
   * contract-level provider offering place limit within the contract's date range will
   * be set to the contract's end date.<br/> Any contract-level provider
   * offering place limit which no longer overlap with the contract's date-range will
   * be deleted.
   *
   * @throws InformationalException
   * Generic exception signature.
   */
  protected void synchronizeContractedPlaceLimitDateRanges()
    throws InformationalException {

    Set<ProviderOfferingPlaceLimit> contractProviderOfferingPlaceLimits;

    for (ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      getTransactionHelper().lock(contractProviderOfferingLink);

      // Get the set of ProviderOfferingPlaceLimits for the
      // ContractVersionProviderOffering
      contractProviderOfferingPlaceLimits = providerOfferingPlaceLimitDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion());

      // Delete any contract-level rates which now fall outside the contract's
      // date range
      for (ProviderOfferingPlaceLimit providerOfferingPlaceLimit : contractProviderOfferingPlaceLimits) {

        if (!providerOfferingPlaceLimit.getDateRange().overlapsWith(
          getDateRange())) {

          providerOfferingPlaceLimit.remove(
            providerOfferingPlaceLimit.getVersionNo());
        }
      }

      // Read the set of rates for the ContractVersionProviderOffering
      contractProviderOfferingPlaceLimits = providerOfferingPlaceLimitDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion());

      if (contractProviderOfferingPlaceLimits.size() > 0) {
        // Set the start date of the earliest one to the contract's start date
        // if not already done so
        ProviderOfferingPlaceLimit providerOfferingPlaceLimit = DateRange.earliest(
          contractProviderOfferingPlaceLimits);

        if (providerOfferingPlaceLimit.getDateRange().start().compareTo(
          getDateRange().start())
            != 0) {
          if (providerOfferingPlaceLimit.getDateRange().start().before(
            getDateRange().start())) {

            providerOfferingPlaceLimit.setDateRange(
              new DateRange(getDateRange().start(),
              providerOfferingPlaceLimit.getDateRange().end()));
            providerOfferingPlaceLimit.modify(
              providerOfferingPlaceLimit.getVersionNo());
          }
          if (providerOfferingPlaceLimit.getDateRange().start().after(
            getDateRange().start())) {

            DateRange placeLimitDateRange = new DateRange(
              getDateRange().start(),
              providerOfferingPlaceLimit.getDateRange().start().addDays(-1));

            createProviderOfferingPlaceLimitForPeriod(
              contractProviderOfferingLink, placeLimitDateRange);
          }

        }

        // Set the end date of the latest one to the contract end date
        providerOfferingPlaceLimit = DateRange.latest(
          contractProviderOfferingPlaceLimits);

        if (providerOfferingPlaceLimit.getDateRange().end().compareTo(
          getDateRange().end())
            != 0) {
          if (providerOfferingPlaceLimit.getDateRange().end().after(
            getDateRange().end())) {

            providerOfferingPlaceLimit.setDateRange(
              new DateRange(providerOfferingPlaceLimit.getDateRange().start(),
              getDateRange().end()));
            providerOfferingPlaceLimit.modify(
              providerOfferingPlaceLimit.getVersionNo());
          }
          if (providerOfferingPlaceLimit.getDateRange().end().before(
            getDateRange().end())) {

            DateRange noPORDateRange = new DateRange(
              providerOfferingPlaceLimit.getDateRange().end().addDays(1),
              getDateRange().end());

            createProviderOfferingPlaceLimitForPeriod(
              contractProviderOfferingLink, noPORDateRange);
          }
        }
      }
    }
  }

  // END, CR00156751


  /**
   * Synchronizes all contract-level
   * {@linkplain curam.providerservice.impl.ProviderOfferingRate} date ranges
   * with the contract's date range for each
   * {@linkplain curam.contracts.impl.ContractVersionProviderOffering} on the
   * contract.
   * <p>
   * If only one contract-level provider offering rate exists for the
   * ContractVersionProviderOffering, its daterange will be set to the
   * contract's date range.<br/> If more than one provider offering rate exists
   * for the contract version provider offering, the start date of the earliest
   * contract-level provider offering rate within the contract's date range will
   * be set to the contract's start date, and the end date of the latest
   * contract-level provider offering rate within the contract's date range will
   * be set to the contract's end date.<br/> Any contract-level provider
   * offering rates which no longer overlap with the contract's date-range will
   * be deleted.
   *
   * @throws InformationalException
   */
  protected void synchronizeContractedProviderOfferingRateDateRanges()
    throws InformationalException {

    Set<ProviderOfferingRate> contractProviderOfferingRates;

    for (ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      getTransactionHelper().lock(contractProviderOfferingLink);

      // BEGIN CR00098695, ABS
      // Get the set of ProviderOfferingRates for the
      // ContractVersionProviderOffering
      contractProviderOfferingRates = providerOfferingRateDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion());

      // Delete any contract-level rates which now fall outside the contract's
      // date range
      for (ProviderOfferingRate providerOfferingRate : contractProviderOfferingRates) {

        if (!providerOfferingRate.getDateRange().overlapsWith(getDateRange())) {

          providerOfferingRate.remove(providerOfferingRate.getVersionNo());
        }
      }

      // Read the set of rates for the ContractVersionProviderOffering
      contractProviderOfferingRates = providerOfferingRateDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion());

      // Set the start date of the earliest one to the contract's start date
      // if not already done so
      ProviderOfferingRate providerOfferingRate = DateRange.earliest(
        contractProviderOfferingRates);
      
      // BEGIN, CR00157707, ASN
      // BEGIN, CR00186897, ASN
      if (0 == contractProviderOfferingRates.size()) {
        // END, CR00186897
     
        createProviderOfferingRateForPeriod(contractProviderOfferingLink,
          getDateRange());
      }
      // BEGIN, CR00186897, ASN
      if (null != providerOfferingRate) {
        // END, CR00186897
        
        if (0
          != providerOfferingRate.getDateRange().start().compareTo(
            getDateRange().start())) {
          
          if (providerOfferingRate.getDateRange().start().before(
            getDateRange().start())) {

            providerOfferingRate.setDateRange(
              new DateRange(getDateRange().start(),
              providerOfferingRate.getDateRange().end()));
            
            providerOfferingRate.modify(providerOfferingRate.getVersionNo());
            
          }
          if (providerOfferingRate.getDateRange().start().after(
            getDateRange().start())) {

            DateRange noPORDateRange = new DateRange(getDateRange().start(),
              providerOfferingRate.getDateRange().start().addDays(-1));

            createProviderOfferingRateForPeriod(contractProviderOfferingLink,
              noPORDateRange);
          }

        }
      }
      // END, CR00157707


      
      // Set the end date of the latest one to the contract end date
      providerOfferingRate = DateRange.latest(contractProviderOfferingRates);
      
      // BEGIN, CR00157707, ASN
      // BEGIN, CR00186897, ASN
      if (null != providerOfferingRate) {
      
        if (0 != providerOfferingRate.getDateRange().end().compareTo(// END, CR00186897
          getDateRange().end())) {
          if (providerOfferingRate.getDateRange().end().after(
            getDateRange().end())) {

            providerOfferingRate.setDateRange(
              new DateRange(providerOfferingRate.getDateRange().start(),
              getDateRange().end()));
            providerOfferingRate.modify(providerOfferingRate.getVersionNo());
          }
          if (providerOfferingRate.getDateRange().end().before(
            getDateRange().end())) {

            DateRange noPORDateRange = new DateRange(
              providerOfferingRate.getDateRange().end().addDays(1),
              getDateRange().end());

            createProviderOfferingRateForPeriod(contractProviderOfferingLink,
              noPORDateRange);
          }
        }
      }
      // END, CR00157707

    }
    // END CR00098695, ABS
  }

  /**
   * Creates provider offering rates for the input period
   *
   * @param contractProviderOfferingLink
   * @param noPORDateRange
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void createProviderOfferingRateForPeriod(
    ContractVersionProviderOffering contractProviderOfferingLink,
    DateRange noPORDateRange) throws InformationalException {
    // END, CR00177241
    ContractVersionProviderOffering contractVersionProviderOffering = contractVersionProviderOfferingDAO.get(
      contractProviderOfferingLink.getID());

    Set<ProviderOfferingRate> providerOfferingRatesForProvider = new HashSet<ProviderOfferingRate>();

    // Iterate through the provider offering rates and find the provider
    // offering rates
    // that overlaps the contract period
    Set<ProviderOfferingRate> unModifiableProviderOfferingRates = contractProviderOfferingLink.getProviderOffering().getProviderOfferingRates();
    Set<ProviderOfferingRate> providerOfferingRates = new HashSet<ProviderOfferingRate>();

    providerOfferingRates.addAll(unModifiableProviderOfferingRates);

    for (ProviderOfferingRate offeringRate : providerOfferingRates) {
      if (offeringRate.getProviderOfferingRateType().equals(
        ProviderOfferingRateTypeEntry.NONCONTRACT)) {
        if (noPORDateRange.contains(offeringRate.getDateRange())
          || noPORDateRange.contains(offeringRate.getDateRange().start())
          || noPORDateRange.contains(offeringRate.getDateRange().end())
          || ((offeringRate.getDateRange().end().equals(Date.kZeroDate)
            || offeringRate.getDateRange().end().after(noPORDateRange.end()))
              && (offeringRate.getDateRange().start().before(
                noPORDateRange.start())))) {
          providerOfferingRatesForProvider.add(offeringRate);
        }
      }
    }
    ProviderOfferingRate[] providerOfferingRateArray = new ProviderOfferingRate[providerOfferingRatesForProvider.size()];

    providerOfferingRateArray = providerOfferingRatesForProvider.toArray(
      providerOfferingRateArray);

    contractVersionProviderOffering.copyNonContractedPORToContract(
      providerOfferingRateArray, noPORDateRange);

    // Retrieve the provider offering rates for the contract
    Set<ProviderOfferingRate> contractProviderOfferingRates = providerOfferingRateDAO.searchBy(
      contractProviderOfferingLink.getProviderOffering(), this);

    ProviderOfferingRate[] contractProviderOfferingRatesArray = new ProviderOfferingRate[contractProviderOfferingRates.size()];

    providerOfferingRateArray = contractProviderOfferingRates.toArray(
      contractProviderOfferingRatesArray);

    // Sort the provider offering rate by start date
    sortRatesArray(providerOfferingRateArray);

    contractVersionProviderOffering.createContractedPORForPeriod(
      providerOfferingRateArray, getDateRange());
  }

  // BEGIN, CR00156751, ABS
  /**
   * Creates provider offering place limit for the input period.
   *
   * @param contractProviderOfferingLink
   * Provider offering for which place limit is created.
   * @param dateRange Dates for which the place limit is created.
   *
   * @throws InformationalException
   * Generic exception signature.
   */
  // BEGIN, CR00177241, PM
  protected void createProviderOfferingPlaceLimitForPeriod(
    ContractVersionProviderOffering contractProviderOfferingLink,
    DateRange dateRange) throws InformationalException {
    // END, CR00177241

    Set<ProviderOfferingPlaceLimit> providerOfferingPlaceLimitsForProvider = new HashSet<ProviderOfferingPlaceLimit>();

    // Iterate through the provider offering Place Limits and find the provider
    // offering Place Limits
    // that overlaps the contract period
    Set<ProviderOfferingPlaceLimit> unModifiableProviderOfferingPlaceLimits = contractProviderOfferingLink.getProviderOffering().getProviderOfferingPlaceLimits();
    Set<ProviderOfferingPlaceLimit> providerOfferingPlaceLimits = new HashSet<ProviderOfferingPlaceLimit>();

    providerOfferingPlaceLimits.addAll(unModifiableProviderOfferingPlaceLimits);

    for (ProviderOfferingPlaceLimit offeringPlaceLimit : providerOfferingPlaceLimits) {
      if (offeringPlaceLimit.getProviderOfferingPlaceLimitType().equals(
        ProviderOfferingPlaceLimitTypeEntry.NONCONTRACT)) {
        if (dateRange.contains(offeringPlaceLimit.getDateRange())
          || dateRange.contains(offeringPlaceLimit.getDateRange().start())
          || dateRange.contains(offeringPlaceLimit.getDateRange().end())
          || ((offeringPlaceLimit.getDateRange().end().equals(Date.kZeroDate)
            || offeringPlaceLimit.getDateRange().end().after(dateRange.end()))
              && (offeringPlaceLimit.getDateRange().start().before(
                dateRange.start())))) {
          providerOfferingPlaceLimitsForProvider.add(offeringPlaceLimit);
        }
      }
    }
    ProviderOfferingPlaceLimit[] providerOfferingPlaceLimitArray = new ProviderOfferingPlaceLimit[providerOfferingPlaceLimitsForProvider.size()];

    providerOfferingPlaceLimitArray = providerOfferingPlaceLimitsForProvider.toArray(
      providerOfferingPlaceLimitArray);

    copyNonContractedPOPlaceLimitToContract(providerOfferingPlaceLimitArray,
      dateRange);

  }

  /**
   * Copies the non contracted place limit to the contract.
   *
   * @param providerOfferingPlaceLimitArray
   * Non contracted place limit that falls in the contract period.
   * @param contractPeriod
   * Period of contract.
   *
   * @return Set of provider offering place limit.
   *
   * @throws InformationalException
   * Generic exception signature.
   */
  // BEGIN, CR00177241, PM
  protected Set<curam.providerservice.impl.ProviderOfferingPlaceLimit> copyNonContractedPOPlaceLimitToContract(
    curam.providerservice.impl.ProviderOfferingPlaceLimit[] providerOfferingPlaceLimitArray,
    DateRange contractPeriod)
    throws InformationalException {
    // END, CR00177241

    Set<curam.providerservice.impl.ProviderOfferingPlaceLimit> contractedProviderOfferingPlaceLimits = new HashSet<curam.providerservice.impl.ProviderOfferingPlaceLimit>();

    // Iterate through the provider offering place limit and copy the
    // provider offering place limit to contract provider offering place limit
    for (curam.providerservice.impl.ProviderOfferingPlaceLimit placeLimit : providerOfferingPlaceLimitArray) {

      curam.providerservice.impl.ProviderOfferingPlaceLimit contractedProviderOfferingPlaceLimit = null;

      // If the provider offering place limit period falls within the the contract
      // version period
      if (contractPeriod.contains(placeLimit.getDateRange())) {
        contractedProviderOfferingPlaceLimit = createProviderOfferingPlaceLimit(
          placeLimit, placeLimit.getDateRange());

        // If the start date overlaps with the contract version period
      } else if (contractPeriod.contains(placeLimit.getDateRange().start())) {
        contractedProviderOfferingPlaceLimit = createProviderOfferingPlaceLimit(
          placeLimit,
          new DateRange(placeLimit.getDateRange().start(), contractPeriod.end()));

        // If the end date overlaps with the contract version period
      } else if (contractPeriod.contains(placeLimit.getDateRange().end())) {
        contractedProviderOfferingPlaceLimit = createProviderOfferingPlaceLimit(
          placeLimit,
          new DateRange(contractPeriod.start(), placeLimit.getDateRange().end()));

        // If the start date is before the contract start date and end date
        // after the
        // contract end date or there is no end date present for provider
        // offering rate
      } else if ((placeLimit.getDateRange().end().equals(Date.kZeroDate)
        || placeLimit.getDateRange().end().after(contractPeriod.end()))
          && (placeLimit.getDateRange().start().before(contractPeriod.start()))) {
        contractedProviderOfferingPlaceLimit = createProviderOfferingPlaceLimit(
          placeLimit,
          new DateRange(contractPeriod.start(), contractPeriod.end()));
      }
      if (contractedProviderOfferingPlaceLimit != null) {
        contractedProviderOfferingPlaceLimits.add(
          contractedProviderOfferingPlaceLimit);
      }
    }

    return contractedProviderOfferingPlaceLimits;
  }

  /**
   * Creates a provider offering place limit for the input period.
   *
   * @param placeLimit
   * Place limit object.
   * @param dateRange
   * Date range for which the place limit needs to be created.
   *
   * @return Created place limit.
   *
   * @throws InformationalException
   * Generic exception signature.
   */
  // BEGIN, CR00177241, PM
  protected curam.providerservice.impl.ProviderOfferingPlaceLimit createProviderOfferingPlaceLimit(
    curam.providerservice.impl.ProviderOfferingPlaceLimit placeLimit,
    DateRange dateRange) throws InformationalException {
    // END, CR00177241

    curam.providerservice.impl.ProviderOfferingPlaceLimit contractedPlaceLimit = providerOfferingPlaceLimitDAO.newInstance();

    contractedPlaceLimit.setComments(placeLimit.getComments());
    contractedPlaceLimit.setContract(this);
    contractedPlaceLimit.setPlaceLimit(placeLimit.getPlaceLimit());
    contractedPlaceLimit.setProviderOffering(placeLimit.getProviderOffering());
    contractedPlaceLimit.setDateRange(dateRange);

    contractedPlaceLimit.insert();
    return contractedPlaceLimit;
  }

  // END, CR00156751

  /**
   * Sorts the provider offering rate in ascending order
   *
   * @param providerOfferingRateArray
   * contains list of provider offering rates
   */
  // BEGIN, CR00177241, PM
  protected void sortRatesArray(ProviderOfferingRate[] providerOfferingRateArray) {
    // END, CR00177241

    // Sort the rates in the ascending order by start date
    Arrays.sort(providerOfferingRateArray,
      new Comparator<ProviderOfferingRate>() {
      public int compare(final ProviderOfferingRate lhs,
        ProviderOfferingRate rhs) {
        return lhs.getDateRange().start().compareTo(rhs.getDateRange().start());
      }
    });
  }

  /**
   * Checks for overlapping Provider Offering Rates and gaps in coverage.
   * <p>
   * If the contract is IN EDIT, informational messages are raised. If the
   * contract is in any other state, the messages are treated as errors.
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_OVERLAPPING_RATES_ON_SERVICES} -
   * If the contract service has overlapping service rates.
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_SERVICE_RATE_NOT_COVERING_ENTIRE_CONTRACT_PERIOD} -
   * The Contract Service do not have rate(s) for the entire period.
   */
  public void validateContractedProviderOfferingRates()
    throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre validateContractedProviderOfferingRates contract version
    // event.
    validateContractedProviderOfferingRatesEventDispatcherFactory.get(ContractVersionValidateContractedProviderOfferingRatesEvents.class).preValidateContractedProviderOfferingRates(
      this);
    // END, CR00235789

    checkForOverlappingRates();

    checkForGapsInRates();

    // BEGIN, CR00235789, AK
    // Raise the post validateContractedProviderOfferingRates contract version
    // event.
    validateContractedProviderOfferingRatesEventDispatcherFactory.get(ContractVersionValidateContractedProviderOfferingRatesEvents.class).postValidateContractedProviderOfferingRates(
      this);
    // END, CR00235789
  }

  /**
   * Checks if any rates for a provider offering associated with the contract
   * overlap.
   * <p>
   * If any rates for a provider offering associated with the contract overlap,
   * an error or informational will be raised. Informationals are raised if the
   * contract is IN EDIT, otherwise an error is raised.
   *
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void checkForOverlappingRates() throws InformationalException {
    // END, CR00177241

    StringBuffer stringBuffer = new StringBuffer();
    Set<ServiceOffering> serviceOfferingSet = new HashSet<ServiceOffering>();

    // Check for overlapping rates
    for (ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      if (DateRange.containsOverlaps(
        providerOfferingRateDAO.searchBy(
          contractProviderOfferingLink.getProviderOffering(), this))) {

        // check for duplicates
        if (serviceOfferingSet.add(
          contractProviderOfferingLink.getProviderOffering().getServiceOffering())) {
          // BEGIN, CR00089990, GD
          stringBuffer.append(
            contractProviderOfferingLink.getProviderOffering().getServiceOffering().getName()
              + CuramConst.gkComma + CuramConst.gkSpace);
          // END, CR00089990
        }
      }
    }
    if (stringBuffer.length() > 0) {

      String serviceNames = stringBuffer.toString();

      // Remove trailing comma & space
      serviceNames = serviceNames.substring(0, serviceNames.length() - 2);

      AppException appException = CONTRACTVERSIONExceptionCreator.ERR_OVERLAPPING_RATES_ON_SERVICES(
        serviceNames);

      if (getLifecycleState().equals(CONTRACTSTATUSEntry.INEDIT)) {
        raiseInformational(appException);
      } else {
        ValidationHelper.addValidationError(appException);
      }
    }
  }

  /**
   * Checks the rates for a provider offering associated with the contract do
   * not fully cover the contract's date range.
   * <p>
   * If the rates for a provider offering associated with the contract do not
   * fully cover the contract's date range, an error or informational will be
   * raised. Informationals are raised if the contract is IN EDIT, otherwise a
   * error is raised.
   *
   * @throws InformationalException -
   * if the contract is IN EDIT and the rates for a provider offering
   * associated with the contract do not fully cover the contract's
   * date range.
   */
  // BEGIN, CR00177241, PM
  protected void checkForGapsInRates() throws InformationalException {
    // END, CR00177241

    StringBuffer stringBuffer = new StringBuffer();

    // Check for ProviderOfferingRate coverage gaps
    for (ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      // Get the set of contiguous date ranges covered by the ProviderOffering's
      // set of contracted ProviderOfferingRates
      Set<DateRangeSet<ProviderOfferingRate>> contiguousDateRanges = DateRange.findContiguousDateRanges(
        providerOfferingRateDAO.searchBy(
          contractProviderOfferingLink.getProviderOffering(), this));

      /*
       * If there is more than one element in the set, or the only element's
       * date range ends before the contract's date range, there are coverage
       * gaps
       */
      if (contiguousDateRanges.size() > 1
        || (contiguousDateRanges.size() == 1
          && contiguousDateRanges.iterator().next().getDateRange().endsBefore(
            getDateRange().end()))) {

        // BEGIN, CR00089990, GD
        stringBuffer.append(
          contractProviderOfferingLink.getProviderOffering().getServiceOffering().getName()
            + CuramConst.gkComma + CuramConst.gkSpace);
        // END, CR00089990
      }
    }
    if (stringBuffer.length() > 0) {

      String serviceNames = stringBuffer.toString();

      // Remove trailing comma & space
      serviceNames = serviceNames.substring(0, serviceNames.length() - 2);

      AppException appException = CONTRACTVERSIONExceptionCreator.ERR_SERVICE_RATE_NOT_COVERING_ENTIRE_CONTRACT_PERIOD(
        serviceNames, getDateRange().start(), getDateRange().end());

      if (getLifecycleState().equals(CONTRACTSTATUSEntry.INEDIT)) {
        raiseInformational(appException);
      } else {
        ValidationHelper.addValidationError(appException);
      }
    }
  }

  /**
   * Raises an Informational Message using the specified AppException.
   *
   * @param appException
   * the exception to throw
   *
   * @throws InformationalException -
   * for the exception parameter whenever the method is called.
   */
  // BEGIN, CR00177241, PM
  protected void raiseInformational(AppException appException)
    throws InformationalException {
    // END, CR00177241

    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    informationalManager.addInformationalMsg(appException,
      curam.core.impl.CuramConst.gkEmpty,
      InformationalElement.InformationalType.kWarning);
  }

  /**
   * Activates all contracted provider offering rates for the contract.
   * <p>
   * For all non-contracted ProviderOfferingRates for the specified
   * ProviderOffering:
   * <ul>
   * <li>Any non-contracted ProviderOfferingRates which fall entirely within
   * the contract's date range will be deleted</li>
   * <li>If any non-contracted ProviderOfferingRate is found covering the
   * contract's start date, its end date will be pushed back to the day before
   * the contract's start date</li>
   * <li>If any non-contracted ProviderOfferingRate is found covering the
   * contract's end date, its start date will be pushed out to the day after the
   * contract's end date</li>
   * </ul>
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void activateContractedProviderOfferingRates()
    throws InformationalException {

    // For each ProviderOffering on the contract
    for (ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      reArrangeNonContractedProviderOfferingRateDateRanges(
        contractProviderOfferingLink);
    }
  }

  /**
   * Rearranges non contracted provider offering date ranges.
   * <p>
   * For all non-contracted ProviderOfferingRates for the specified
   * ProviderOffering:
   * <ul>
   * <li>Any non-contracted ProviderOfferingRates which fall entirely within
   * the contract's date range will be deleted</li>
   * <li>If any non-contracted ProviderOfferingRate is found covering the
   * contract's start date, its end date will be pushed back to the day before
   * the contract's start date</li>
   * <li>If any non-contracted ProviderOfferingRate is found covering the
   * contract's end date, its start date will be pushed out to the day after the
   * contract's end date</li>
   * </ul>
   *
   * @param contractProviderOfferingLink
   * the key of the provider offering
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void reArrangeNonContractedProviderOfferingRateDateRanges(
    ContractVersionProviderOffering contractProviderOfferingLink)
    throws InformationalException {
    // END, CR00177241

    // Get all ProviderOfferingRates for the ProviderOffering
    for (ProviderOfferingRate rate : providerOfferingRateDAO.searchBy(
      contractProviderOfferingLink.getProviderOffering())) {

      // If the place rate is not belonging to this contract
      if (!contractProviderOfferingLink.getContractVersion().equals(
        rate.getContractVersion())) {

        /*
         * If the rate falls entirely within the contract's date range, delete
         * it
         */
        if (getDateRange().contains(rate.getDateRange())) {

          rate.remove(rate.getVersionNo());
        } /*
         * If the rate's end date overlaps with the contract's date range,
         * change the rate's end date to the day before the contract start date
         */else if (getDateRange().contains(rate.getDateRange().end())) {

          Date startDate = rate.getDateRange().start();
          Date endDate = getDateRange().start().addDays(-1);

          rate.setDateRange(new DateRange(startDate, endDate));

          rate.modifyForContract(rate.getVersionNo());
        } /*
         * If the rate's start date overlaps with the contract's date range,
         * change the rate's start date to the day after the contract end date
         */else if (getDateRange().contains(rate.getDateRange().start())) {

          Date startDate = getDateRange().end().addDays(1);
          Date endDate = rate.getDateRange().end();

          rate.setDateRange(new DateRange(startDate, endDate));

          rate.modifyForContract(rate.getVersionNo());
        } /*
         * If the contract is fully contained within the rate, change the rate's
         * end date to the day before the contract start date and insert a new
         * non contract rate that has a start date on the day after the contract
         * end date and an end date equal to original rate end date and an end
         * date equal to original rate end date
         */else if (rate.getDateRange().contains(getDateRange())) {

          Date startDate = rate.getDateRange().start();
          Date existingRateEndDate = rate.getDateRange().end();

          rate.setDateRange(
            new DateRange(startDate, getDateRange().start().addDays(-1)));

          rate.modifyForContract(rate.getVersionNo());

          // Create the second PORate
          ProviderOfferingRate newProviderOfferingRate = providerOfferingRateDAO.newInstance();

          newProviderOfferingRate.setComments(rate.getComments());

          newProviderOfferingRate.setDateRange(
            new DateRange(getDateRange().end().addDays(1), existingRateEndDate));
          newProviderOfferingRate.setDefaultRates();
          if (!rate.getFixedAmount().isNegative()) {
            newProviderOfferingRate.setFixedAmount(rate.getFixedAmount());
          }
          if (!rate.getMinAmount().isNegative()) {
            newProviderOfferingRate.setMinAmount(rate.getMinAmount());
          }
          if (!rate.getMaxAmount().isNegative()) {
            newProviderOfferingRate.setMaxAmount(rate.getMaxAmount());
          }
          newProviderOfferingRate.setProviderOffering(
            rate.getProviderOffering());

          newProviderOfferingRate.insert();

        }
      }
    }
  }

  /**
   * Terminates contract provider offering rates.
   * <p>
   * For all contracted ProviderOfferingRates for the contract:
   * <ul>
   * <li>Any contracted ProviderOfferingRates which begin after the contract's
   * termination date will be deleted</li>
   * <li>If any contracted ProviderOfferingRate is found covering the
   * contract's termination date, its end date date will be set to the
   * contract's termination date</li>
   * </ul>
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void terminateContractedProviderOfferingRates()
    throws InformationalException {

    Date terminationDate = new Date(getTerminationDateTime());

    // For each ProviderOffering on the contract
    for (ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      // Get all contracted ProviderOfferingRates for the ProviderOffering
      for (ProviderOfferingRate rate : providerOfferingRateDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion())) {

        if (rate.getDateRange().startsAfter(terminationDate)) {

          rate.remove(rate.getVersionNo());
        } else if (rate.getDateRange().contains(terminationDate)) {

          rate.setDateRange(
            new DateRange(rate.getDateRange().start(), terminationDate));
          rate.modifyForContract(rate.getVersionNo());
        }
      }

    }

  }

  /**
   * Checks for overlapping Place Limits and gaps in coverage.
   * <p>
   * If the contract is IN EDIT, informational messages are raised. If the
   * contract is in any other state, the messages are treated as errors.
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_OVERLAPPING_PLACELIMITS_ON_SERVICES} -
   * If the contract Service(s) has overlapping place limits.
   */
  public void validateContractedProviderOfferingPlaceLimits()
    throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre validateContractedProviderOfferingPlaceLimits contract
    // version event.
    validateContractedProviderOfferingPlaceLimitsEventDispatcherFactory.get(ContractVersionValidateContractedProviderOfferingPlaceLimitsEvents.class).preValidateContractedProviderOfferingPlaceLimits(
      this);
    // END, CR00235789

    StringBuffer stringBuffer = new StringBuffer();

    // Check for overlapping place limits
    for (ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      // BEGIN, CR00090347, PDN
      // Need to filter out non active Provider Offering Place Limits

      Set<ProviderOfferingPlaceLimit> filteredActiveProviderOfferingPlaceLimit = providerOfferingPlaceLimitDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(), this);

      for (ProviderOfferingPlaceLimit providerOfferingPlaceLimit : providerOfferingPlaceLimitDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(), this)) {
        if (providerOfferingPlaceLimit.getLifecycleState().getCode().compareTo(
          RECORDSTATUS.CANCELLED)
            == 0) {
          filteredActiveProviderOfferingPlaceLimit.remove(
            providerOfferingPlaceLimit);
        }
      }

      if (DateRange.containsOverlaps(filteredActiveProviderOfferingPlaceLimit)) {

        // END, CR00090347

        // BEGIN, CR00089990, GD
        stringBuffer.append(
          contractProviderOfferingLink.getProviderOffering().getServiceOffering().getName()
            + CuramConst.gkComma + CuramConst.gkSpace);
        // END, CR00089990

      }
    }
    if (stringBuffer.length() > 0) {

      String serviceNames = stringBuffer.toString();

      // Remove trailing comma & space
      serviceNames = serviceNames.substring(0, serviceNames.length() - 2);

      AppException appException = CONTRACTVERSIONExceptionCreator.ERR_OVERLAPPING_PLACELIMITS_ON_SERVICES(
        serviceNames);

      if (getLifecycleState().equals(CONTRACTSTATUSEntry.INEDIT)) {
        raiseInformational(appException);
      } else {
        ValidationHelper.addValidationError(appException);
      }
    }

    // BEGIN, CR00235789, AK
    // Raise the post validateContractedProviderOfferingPlaceLimits contract
    // version event.
    validateContractedProviderOfferingPlaceLimitsEventDispatcherFactory.get(ContractVersionValidateContractedProviderOfferingPlaceLimitsEvents.class).postValidateContractedProviderOfferingPlaceLimits(
      this);
    // END, CR00235789
  }

  /**
   * Terminates contracted provider offering place limits.
   * <p>
   * For all contracted provider offering place limits for the contract:
   * <ul>
   * <li>Any contracted provider offering place limits which begin after the
   * contract's termination date will be deleted</li>
   * <li>Any contracted provider offering place limit that is found covering
   * the contract's termination date, will have its end date set to the
   * contract's termination date</li>
   * </ul>
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void terminateContractedProviderOfferingPlaceLimits()
    throws InformationalException {

    Date terminationDate = new Date(getTerminationDateTime());

    // For each ProviderOffering on the contract
    for (ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      // Get all contracted ProviderOfferingPlaceLimits for the ProviderOffering
      for (ProviderOfferingPlaceLimit placeLimit : providerOfferingPlaceLimitDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion())) {

        if (placeLimit.getDateRange().startsAfter(terminationDate)) {

          placeLimit.remove(placeLimit.getVersionNo());
        } else if (placeLimit.getDateRange().contains(terminationDate)) {

          placeLimit.setDateRange(
            new DateRange(placeLimit.getDateRange().start(), terminationDate));
          placeLimit.modify(placeLimit.getVersionNo());
        }
      }
    }
  }

  /**
   * Activates all contracted ProviderOfferingPlaceLimits for the contract.
   * <p>
   * For all non-contracted ProviderOfferingPlaceLimits for the specified
   * ProviderOffering:
   * <ul>
   * <li>Any non-contracted ProviderOfferingPlaceLimits which fall entirely
   * within the contract's date range will be deleted</li>
   *
   * <li>If any non-contracted ProviderOfferingPlaceLimit is found covering the
   * contract's start date, its end date will be pushed back to the day before
   * the contract's start date</li>
   * <li>If any non-contracted ProviderOfferingPlaceLimit is found covering the
   * contract's end date, its start date will be pushed out to the day after the
   * contract's end date</li>
   * </ul>
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void activateContractedProviderOfferingPlaceLimits()
    throws InformationalException {

    // For each ProviderOffering on the contract
    for (ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      reArrangeNonContractedProviderOfferingPlaceLimitDateRanges(
        contractProviderOfferingLink);
    }
  }

  /**
   * Rearranges date ranges for non-contracted provider offering place limits.
   * <p>
   * For all non-contracted ProviderOfferingPlaceLimits for the specified
   * ProviderOffering:
   * <ul>
   * <li>Any non-contracted ProviderOfferingPlaceLimits which fall entirely
   * within the contract's date range will be deleted</li>
   * <li>If any non-contracted ProviderOfferingPlaceLimit is found covering the
   * contract's start date, its end date will be pushed back to the day before
   * the contract's start date</li>
   * <li>If any non-contracted ProviderOfferingPlaceLimit is found covering the
   * contract's end date, its start date will be pushed out to the day after the
   * contract's end date</li>
   * </ul>
   *
   * @param contractProviderOfferingLink
   * the key for the provider offering link
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void reArrangeNonContractedProviderOfferingPlaceLimitDateRanges(
    ContractVersionProviderOffering contractProviderOfferingLink)
    throws InformationalException {
    // END, CR00177241

    // Get all ProviderOfferingPlaceLimits for the ProviderOffering
    for (ProviderOfferingPlaceLimit placeLimit : providerOfferingPlaceLimitDAO.searchBy(
      contractProviderOfferingLink.getProviderOffering())) {

      // If the place limit is not belonging to this contract
      if (!contractProviderOfferingLink.getContractVersion().equals(
        placeLimit.getContractVersion())) {

        /*
         * If the place limit falls entirely within the contract's date range,
         * delete it
         */
        if (getDateRange().contains(placeLimit.getDateRange())) {

          placeLimit.remove(placeLimit.getVersionNo());
        } /*
         * If the place limit's end date overlaps with the contract's date
         * range, change the place limit's end date to the day before the
         * contract start date
         */else if (getDateRange().contains(placeLimit.getDateRange().end())) {

          Date startDate = placeLimit.getDateRange().start();
          Date endDate = getDateRange().start().addDays(-1);

          placeLimit.setDateRangeForContract(new DateRange(startDate, endDate));

          placeLimit.modify(placeLimit.getVersionNo());
        } /*
         * If the place limit's start date overlaps with the contract's date
         * range, change the place limit's start date to the day after the
         * contract start date
         */else if (getDateRange().contains(placeLimit.getDateRange().start())) {

          Date startDate = getDateRange().end().addDays(1);
          Date endDate = placeLimit.getDateRange().end();

          placeLimit.setDateRangeForContract(new DateRange(startDate, endDate));

          placeLimit.modify(placeLimit.getVersionNo());
        } /*
         * If the contract is fully contained within the place limit period,
         * change the place limits end date to the day before the contract start
         * date and insert a new non contract place limit that has a start date
         * on the day after the contract end date and an end date equal to
         * original rate end date
         */else if (placeLimit.getDateRange().contains(getDateRange())) {

          Date startDate = placeLimit.getDateRange().start();
          Date existingRateEndDate = placeLimit.getDateRange().end();

          placeLimit.setDateRangeForContract(
            new DateRange(startDate, getDateRange().start().addDays(-1)));

          placeLimit.modify(placeLimit.getVersionNo());

          // Create the second Provider Place Limit
          ProviderOfferingPlaceLimit newProviderOfferingPlaceLimit = providerOfferingPlaceLimitDAO.newInstance();

          newProviderOfferingPlaceLimit.setComments(placeLimit.getComments());
          newProviderOfferingPlaceLimit.setDateRange(
            new DateRange(getDateRange().end().addDays(1), existingRateEndDate));
          newProviderOfferingPlaceLimit.setPlaceLimit(
            placeLimit.getPlaceLimit());
          newProviderOfferingPlaceLimit.setProviderOffering(
            placeLimit.getProviderOffering());

          newProviderOfferingPlaceLimit.insert();

        }
      }
    }
  }

  /**
   * Terminates the contract.Checks the provider organization security to
   * terminate the contract.
   *
   * @param versionNo
   * the version number of the contract
   *
   * @throws InformationalException
   * {@link curam.message.CONTRACTVERSION#ERR_FV_NO_TERMINATION_REASON_SELECTED} -
   * If the contract termination reason is not entered.
   */
  protected void terminate(int versionNo) throws InformationalException {
    // BEGIN CR00096690, SS
    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      getProviderOrganization());
    // END CR00096690

    // Business Rule: Termination reason must be set.
    if (this.getBaseRowDtls().terminationReason.length() == 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_FV_NO_TERMINATION_REASON_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  // BEGIN CR00096690, SS

  /**
   * A map of the states for this entity
   */
  protected final Map<CONTRACTSTATUSEntry, State<CONTRACTSTATUSEntry>> states = new HashMap<CONTRACTSTATUSEntry, State<CONTRACTSTATUSEntry>>();

  /**
   * Change the the lifecycle state of the current record.
   *
   * @param newState
   * the lifecycle state to transition to.
   * @param versionNo
   * the version number of the record to be updated.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void transitionTo(final State<CONTRACTSTATUSEntry> newState,
    final Integer versionNo) throws InformationalException {
    // get the state validator for the current request status
    final State<CONTRACTSTATUSEntry> oldState = states.get(getLifecycleState());

    transition(oldState, newState, versionNo);

  }

  // END CR00096690
  
  // BEGIN, CR00292749, MR
  /**
   * Gets the contract document type based on the contract notification event.
   *
   * @param contractNotificationKey
   * Contains contract notification event for which contract
   * document type is required.
   *
   * @return The contract document type.
   */
  protected String getContractDocumentType(
    final ContractNotificationKey contractNotificationKey) {

    // Provider Flat Rate Contract(Regular).
    if (ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTREG.equals(
      contractNotificationKey.event)) {
      return TEMPLATEIDCODE.PROVIDERFLATRATECONTRACTREG;
    } // Provider Group Flat Rate Contract(Regular).
    else if (ContractNotificationEvent.NEWPGFLATRATECONTRACTREG.equals(
      contractNotificationKey.event)) {
      return TEMPLATEIDCODE.PGFLATRATECONTRACTREG;
    } // Provider Flat Rate Contract(Total).
    else if (ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTTOTAL.equals(
      contractNotificationKey.event)) {
      return TEMPLATEIDCODE.PROVIDERFLATRATECONTRACTTOTAL;
    } // Provider Group Flat Contract(Total).
    else if (ContractNotificationEvent.NEWPGFLATRATECONTRACTTOTAL.equals(
      contractNotificationKey.event)) {
      return TEMPLATEIDCODE.PGFLATRATECONTRACTTOTAL;
    } // Provider Utilization Contract.
    else if (ContractNotificationEvent.NEWPROVIDERUTILIZATIONCONTRACT.equals(
      contractNotificationKey.event)) {
      return TEMPLATEIDCODE.PROVIDERUTILIZATIONCONTRACT;
    } // Provider Group Utilization Contract.
    else {
      return TEMPLATEIDCODE.PGUTILIZATIONCONTRACT;
    }
  }

  // END, CR00292749

}
