/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.CONTRACTTYPE;
import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.impl.CPMConstants;
import curam.cpm.message.impl.CONTRACTVERSIONExceptionCreator;
import curam.cpm.sl.entity.struct.UtilizationContractDtls;
import curam.message.UTILIZATIONCONTRACT;
import curam.message.impl.FLATRATECONTRACTExceptionCreator;
import curam.message.impl.UTILIZATIONCONTRACTExceptionCreator;
import curam.provider.impl.ProviderSecurity;
import curam.providerservice.impl.ProviderOfferingPlaceLimit;
import curam.providerservice.impl.ProviderOfferingPlaceLimitDAO;
import curam.providerservice.impl.ProviderOfferingRate;
import curam.providerservice.impl.ProviderOfferingRateDAO;
import curam.util.events.impl.EventService;
import curam.util.events.struct.Event;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.CodetableState;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.State;
import curam.util.persistence.helper.Transition;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * {@inheritDoc}
 */
// BEGIN, CR00183213, SS
public class UtilizationContractImpl extends ContractVersionImpl<UtilizationContract, UtilizationContractDtls> implements
  UtilizationContract {
  // END, CR00183213

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for delete events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractDeleteEvents> deleteEventDispatcherFactory;

  /**
   * Event dispatcher for generate events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractGenerateEvents> generateEventDispatcherFactory;

  /**
   * Event dispatcher for activate events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractActivateEvents> activateEventDispatcherFactory;

  /**
   * Event dispatcher for terminate events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractTerminateEvents> terminateEventDispatcherFactory;

  /**
   * Event dispatcher for renew events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractRenewEvents> renewEventDispatcherFactory;

  /**
   * Event dispatcher for reEdit events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractReEditEvents> reEditEventDispatcherFactory;

  /**
   * Event dispatcher for cloneUtilizationContract events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractCloneUtilizationContractEvents> cloneUtilizationContractEventDispatcherFactory;

  /**
   * Event dispatcher for cloneUtilizationContractForRenewal events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractCloneUtilizationContractForRenewalEvents> cloneUtilizationContractForRenewalEventDispatcherFactory;

  /**
   * Event dispatcher for amend events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractAmendEvents> amendEventDispatcherFactory;

  /**
   * Event dispatcher for preAmend events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractPreAmendEvents> preAmendEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<UtilizationContractModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  @Inject
  protected UtilizationContractDAO utilizationContractDAO;

  @Inject
  protected ContractVersionProviderOfferingDAO contractProviderOfferingLinkDAO;

  @Inject
  protected CPMContractDAO cpmContractDAO;

  @Inject
  protected ProviderSecurity providerSecurity;

  @Inject
  protected ProviderOfferingRateDAO providerOfferingRateDAO;

  @Inject
  protected ProviderOfferingPlaceLimitDAO providerOfferingPlaceLimitDAO;

  @Inject
  protected ContractVersionDAO contractVersionDAO;

  protected static final int kAMENDMENTVERSIONNUMBERONE = 1;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected UtilizationContractImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * Validates that changes made to utilization contract on the database are
   * consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li> {@link UTILIZATIONCONTRACT#ERR_XRV_CONTRACT_NAME_NOT_UNIQUE} - If the
   * contract with the name is not unique for the given date range and contract
   * type.</li>
   * </ul>
   */
  public void crossEntityValidation() {

    super.crossEntityValidation();

    // Check name is unique for this date range and contract type
    // get the instance of the provider
    for (final ContractVersion contract : this.getProviderOrganization().getContracts()) {

      if (contract.getName().equals(this.getName())
        && (!contract.getID().equals(this.getID()))
        && (!contract.getCPMContract().getReferenceNumber().equals(
          this.getCPMContract().getReferenceNumber()))
          && contract.getDateRange().overlapsWith(this.getDateRange())
          && contract.getContractType().toString().equals(
            CONTRACTTYPE.UTILIZATION)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_XRV_CONTRACT_NAME_NOT_UNIQUE(
            this.getName()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {

    super.crossFieldValidation();
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {

    super.mandatoryFieldValidation();
  }

  /**
   * {@inheritDoc}
   */
  public void reEdit(int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre reEdit utilization contract event.
    reEditEventDispatcherFactory.get(UtilizationContractReEditEvents.class).preReEdit(
      this, versionNo);
    // END, CR00235789

    // BEGIN CR00098718, SK
    // Business Rule: A Contract in the derived 'Expired' state cannot be
    // modified.
    if (Date.getCurrentDate().after(getBaseRowDtls().endDate)
      && getLifecycleState().equals(CONTRACTSTATUSEntry.LIVE)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        UTILIZATIONCONTRACTExceptionCreator.ERR_CONTRACT_NOT_EDITED(
          CONTRACTSTATUSEntry.EXPIRED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    }
    ValidationHelper.failIfErrorsExist();

    // END CR00098718
    transitionTo(inEdit, versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post reEdit utilization contract event.
    reEditEventDispatcherFactory.get(UtilizationContractReEditEvents.class).postReEdit(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre modify utilization contract event.
    modifyEventDispatcherFactory.get(UtilizationContractModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    if (this.getLifecycleState().equals(
      curam.codetable.impl.CONTRACTSTATUSEntry.AMENDED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_AMENDED_CANNOT_MODIFY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    // BEGIN CR00100148, GP
    if (Date.getCurrentDate().after(getDateRange().end())
      && getLifecycleState().equals(CONTRACTSTATUSEntry.LIVE)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        UTILIZATIONCONTRACTExceptionCreator.ERR_CONTRACT_NOT_EDITED(
          CONTRACTSTATUSEntry.EXPIRED.getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          3);
    }
    // END CR00100148
    ValidationHelper.failIfErrorsExist();

    transitionTo(inEdit, versionNo);

    super.modify(getBaseRowDtls().versionNo);

    synchronizeContractedProviderOfferingRateDateRanges();

    validateContractedProviderOfferingRates();

    validateContractedProviderOfferingPlaceLimits();

    // BEGIN, CR00235789, AK
    // Raise the post modify utilization contract event.
    modifyEventDispatcherFactory.get(UtilizationContractModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {

    super.setNewInstanceDefaults();
    setStatus(CONTRACTSTATUSEntry.INEDIT);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected String getDiscriminatorValue() {
    return CONTRACTTYPE.UTILIZATION;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected void mapBaseKeyToConcreteDtls() {
    getConcreteRowDtls().contractVersionID = getBaseRowDtls().contractVersionID;
  }

  /**
   * Deletes the contract and provider offering rates for the contract. Checks
   * the provider organization security to delete the contract. Transitions the
   * state to {@linkplain CONTRACTSTATUSEntry#CANCELED}, if valid to do so.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void delete(int versionNo) throws InformationalException {

    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      getProviderOrganization());

    // BEGIN, CR00235789, AK
    // Raise the pre delete utilization contract event.
    deleteEventDispatcherFactory.get(UtilizationContractDeleteEvents.class).preDelete(
      this, versionNo);
    // END, CR00235789

    transitionTo(canceled, versionNo);

    deleteContractedProviderOfferingRates();

    // BEGIN, CR00235789, AK
    // Raise the post delete utilization contract event.
    deleteEventDispatcherFactory.get(UtilizationContractDeleteEvents.class).postDelete(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * Renews a contract, creates a new in edit version of the contract. Copies
   * the provider offering links, provider group associate links and contract
   * contacts to the newly created contract. Checks the provider organization
   * security to renew the contract.
   *
   * @param versionNo
   * The version number as previously retrieved.
   * @param dateRange
   * The date range used to renew the contract.
   *
   * @throws InformationalException
   * {@link CONTRACTVERSIONExceptionCreator#ERR_XRV_CONTRACTRENEW_CONTRACT_DELTED}
   * - If the contract is not deleted.
   * @throws InformationalException
   * {@link CONTRACTVERSIONExceptionCreator#ERR_XRV_CONTRACTRENEW_CONTRACT_TERMINATED}
   * - If the contract is terminated.
   * @throws InformationalException
   * {@link CONTRACTVERSIONExceptionCreator#ERR_XRV_CONTRACTRENEW_CONTRACT_AMENDED}
   * - If the contract is amended.
   * @throws InformationalException
   * {@link CONTRACTVERSIONExceptionCreator#ERR_XRV_CONTRACTRENEW_CONTRACT_NOTLIVE}
   * - If the contract is live.
   */
  public void renew(int versionNo, DateRange dateRange)
    throws InformationalException {

    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      getProviderOrganization());

    // BEGIN, CR00235789, AK
    // Raise the pre renew utilization contract event.
    renewEventDispatcherFactory.get(UtilizationContractRenewEvents.class).preRenew(
      this, versionNo, dateRange);
    // END, CR00235789

    if (this.getLifecycleState().equals(CONTRACTSTATUSEntry.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_CONTRACTRENEW_CONTRACT_DELTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if (this.getLifecycleState().equals(CONTRACTSTATUSEntry.TERMINATED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_CONTRACTRENEW_CONTRACT_TERMINATED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if (this.getLifecycleState().equals(CONTRACTSTATUSEntry.AMENDED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_CONTRACTRENEW_CONTRACT_AMENDED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if (!this.getLifecycleState().equals(CONTRACTSTATUSEntry.LIVE)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTVERSIONExceptionCreator.ERR_XRV_CONTRACTRENEW_CONTRACT_NOTLIVE(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // Create a new INEDIT version of contract
    UtilizationContract newUtilizationContract = utilizationContractDAO.newInstance();

    newUtilizationContract = newUtilizationContract.cloneUtilizationContractForRenewal(
      this, dateRange);

    // Copy this UtilizationContract's ContractVersionProviderOfferings over to
    // the
    // new UtilizationContract
    cloneContractProviderOfferingLinksForRenewal(newUtilizationContract);

    // Copy this UtilizationContract's ContractPGAssociateLinks over to the
    // new UtilizationContract
    cloneContractPGAssociateLinks(newUtilizationContract);

    // Copy this UtilizationContract's ContractContacts over to the
    // new UtilizationContract
    cloneContractContacts(newUtilizationContract);

    // BEGIN CR00097035, JSP

    final Event event = new Event();

    event.eventKey = curam.events.CONTRACTS.UTILIZATIONCONTRACT_RENEWED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // END CR00097035

    // BEGIN, CR00235789, AK
    // Raise the post renew utilization contract event.
    renewEventDispatcherFactory.get(UtilizationContractRenewEvents.class).postRenew(
      this, versionNo, dateRange);
    // END, CR00235789

  }

  /**
   * <ul>
   * <li>Clones a new instance of the
   * {@linkplain curam.contracts.impl.UtilizationContract}, its related
   * {@linkplain curam.contracts.impl.ContractVersionProviderOffering}s,
   * {@linkplain curam.contracts.impl.ContractVersionProviderGroupAssociate}s
   * and {@linkplain curam.contracts.impl.ContractContactStatusEntry#ACTIVE}
   * {@linkplain curam.contracts.impl.ContractContact}s</li>
   * <li>Sets the new UtilizationContract's state to
   * {@linkplain CONTRACTSTATUSEntry#INEDIT}</li>
   * </ul>
   * Checks the provider organization security to clone the contract.
   *
   * @param startDate
   * The start date for the new contract version.
   *
   * @return The cloned utilization contract.
   *
   * @throws InformationalException
   * {@link UTILIZATIONCONTRACT#ERR_CONTRACT_CANCELED_CANNOT_AMEND} -
   * If the contract is deleted.
   * @throws InformationalException
   * {@link UTILIZATIONCONTRACT#ERR_CONTRACT_ALREADY_AMENDED} - If the
   * contract is already amended.
   * @throws InformationalException
   * {@link UTILIZATIONCONTRACT#ERR_CONTRACT_CANNOT_AMEND} - If the
   * contract is InEdit or Issued or Terminated.
   */
  public UtilizationContract preAmend(final Date startDate)
    throws InformationalException {

    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      getProviderOrganization());

    // BEGIN, CR00235789, AK
    // Raise the pre preAmend utilization contract event.
    preAmendEventDispatcherFactory.get(UtilizationContractPreAmendEvents.class).prePreAmend(
      this, startDate);
    // END, CR00235789

    // Check state transitions for pre-amend
    if (getLifecycleState().equals(
      curam.codetable.impl.CONTRACTSTATUSEntry.CANCELED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        UTILIZATIONCONTRACTExceptionCreator.ERR_CONTRACT_CANCELED_CANNOT_AMEND(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if (getLifecycleState().equals(
      curam.codetable.impl.CONTRACTSTATUSEntry.AMENDED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        UTILIZATIONCONTRACTExceptionCreator.ERR_CONTRACT_ALREADY_AMENDED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    } else if (getLifecycleState().equals(
      curam.codetable.impl.CONTRACTSTATUSEntry.INEDIT)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        UTILIZATIONCONTRACTExceptionCreator.ERR_CONTRACT_CANNOT_AMEND(
          getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          1);
    } else if (getLifecycleState().equals(
      curam.codetable.impl.CONTRACTSTATUSEntry.ISSUED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        UTILIZATIONCONTRACTExceptionCreator.ERR_CONTRACT_CANNOT_AMEND(
          getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          2);
    } else if (getLifecycleState().equals(
      curam.codetable.impl.CONTRACTSTATUSEntry.TERMINATED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        UTILIZATIONCONTRACTExceptionCreator.ERR_CONTRACT_CANNOT_AMEND(
          getLifecycleState().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    ValidationHelper.failIfErrorsExist();

    // Cannot amend if end date has passed
    if (getDateRange().endsBefore(Date.getCurrentDate())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        UTILIZATIONCONTRACTExceptionCreator.ERR_CANNOT_AMEND_IF_END_DATE_IN_PAST(
          getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Start date of new version must be later than start date of previous
    // version

    if (!getDateRange().start().before(startDate)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        UTILIZATIONCONTRACTExceptionCreator.ERR_AMENDED_STARTDATE_EARLIER_THAN_EXISTING_STARTDATE(
          startDate, getDateRange().start()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    ValidationHelper.failIfErrorsExist();

    // Create a new INEDIT version of contract
    UtilizationContract newUtilizationContract = utilizationContractDAO.newInstance();

    newUtilizationContract = newUtilizationContract.cloneUtilizationContract(
      this, startDate);

    // Copy this UtilizationContract's ContractVersionProviderOfferings over to
    // the
    // new UtilizationContract
    cloneContractProviderOfferingLinksForAmend(newUtilizationContract);

    // Copy this UtilizationContract's ContractPGAssociateLinks over to the
    // new UtilizationContract
    cloneContractPGAssociateLinks(newUtilizationContract);

    // Copy this UtilizationContract's ContractContacts over to the
    // new UtilizationContract
    cloneContractContacts(newUtilizationContract);

    // BEGIN, CR00235789, AK
    // Raise the post preAmend utilization contract event.
    preAmendEventDispatcherFactory.get(UtilizationContractPreAmendEvents.class).postPreAmend(
      this, startDate, newUtilizationContract);
    // END, CR00235789

    return newUtilizationContract;
  }

  /**
   * @param newUtilizationContract
   * @throws InformationalException
   *
   * Copy this contract's
   * {@linkplain curam.contracts.impl.ContractVersionProviderOffering}
   * s onto the new contract.
   */
  // BEGIN, CR00177241, PM
  protected void cloneContractProviderOfferingLinksForAmend(
    UtilizationContract newUtilizationContract) throws InformationalException {
    // END, CR00177241

    ContractVersionProviderOffering newContractVersionProviderOffering;

    for (final ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      newContractVersionProviderOffering = contractProviderOfferingLinkDAO.newInstance();
      newContractVersionProviderOffering.setContractVersion(
        newUtilizationContract);
      newContractVersionProviderOffering.setProviderOffering(
        contractProviderOfferingLink.getProviderOffering());

      newContractVersionProviderOffering.insert();

      // Need to copy all the rates for this provider offering that are on the
      // existing Contract
      // to the new Utilization contract

      Set<ProviderOfferingRate> rates = providerOfferingRateDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion());

      for (final ProviderOfferingRate existingRate : rates) {

        // Only Copy Rates whose end date is after the amended contract start
        // date
        if (newUtilizationContract.getDateRange().start().before(
          existingRate.getDateRange().end())) {
          ProviderOfferingRate newRate = providerOfferingRateDAO.newInstance();

          // If the existing rate period is during the new start date then set
          // the start date on the rate to be the contract
          // otherwise use the period on the existing rate
          if (existingRate.getDateRange().contains(
            newUtilizationContract.getDateRange().start())) {
            newRate.setDateRange(
              new DateRange(newUtilizationContract.getDateRange().start(),
              existingRate.getDateRange().end()));
          } else {
            newRate.setDateRange(existingRate.getDateRange());
          }

          newRate.setDefaultRates();
          newRate.setComments(existingRate.getComments());
          if (!existingRate.getFixedAmount().isNegative()) {
            newRate.setFixedAmount(existingRate.getFixedAmount());
          }
          if (!existingRate.getMinAmount().isNegative()) {
            newRate.setMinAmount(existingRate.getMinAmount());
          }
          if (!existingRate.getMaxAmount().isNegative()) {
            newRate.setMaxAmount(existingRate.getMaxAmount());
          }
          newRate.setProviderOffering(existingRate.getProviderOffering());
          newRate.setContractVersion(newUtilizationContract);

          newRate.insert();
        }

      }

      // Need to copy all the place limits for this provider offering that are
      // on the existing Contract
      // to the new Utilization contract

      Set<ProviderOfferingPlaceLimit> existingPlaceLimits = providerOfferingPlaceLimitDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion());

      for (final ProviderOfferingPlaceLimit existingPlaceLimit : existingPlaceLimits) {

        // Only Copy place limits whose end date is after the amended contract
        // start date as any before are
        // not relevant
        // or if this is a renewed contract (new contract Start Date after old
        // contract end date)
        // then copy all the place limits from the old contract
        if (newUtilizationContract.getDateRange().start().before(
          existingPlaceLimit.getDateRange().end())
            || (newUtilizationContract.getDateRange().start().after(
              contractProviderOfferingLink.getContractVersion().getDateRange().end()))) {

          ProviderOfferingPlaceLimit newPlaceLimit = providerOfferingPlaceLimitDAO.newInstance();

          // If the existing place limit period is during the new start date
          // then set the start date on the place limit to be the contract
          // otherwise use the period on the existing place limit
          if (existingPlaceLimit.getDateRange().contains(
            newUtilizationContract.getDateRange().start())) {
            newPlaceLimit.setDateRange(
              new DateRange(newUtilizationContract.getDateRange().start(),
              existingPlaceLimit.getDateRange().end()));
          } else {
            newPlaceLimit.setDateRange(existingPlaceLimit.getDateRange());
          }

          newPlaceLimit.setComments(existingPlaceLimit.getComments());
          newPlaceLimit.setPlaceLimit(existingPlaceLimit.getPlaceLimit());
          newPlaceLimit.setProviderOffering(
            existingPlaceLimit.getProviderOffering());
          newPlaceLimit.setContract(newUtilizationContract);

          newPlaceLimit.insert();

        }

      }

    }
  }

  /**
   * @param newUtilizationContract
   * @throws InformationalException
   *
   * Copy this contract's
   * {@linkplain curam.contracts.impl.ContractProviderOfferingLink}s
   * onto the new renewed contract.
   */
  // BEGIN, CR00177241, PM
  protected void cloneContractProviderOfferingLinksForRenewal(
    UtilizationContract newUtilizationContract) throws InformationalException {
    // END, CR00177241

    ContractVersionProviderOffering newContractVersionProviderOffering;

    for (final ContractVersionProviderOffering contractVersionProviderOffering : getContractVersionProviderOfferings()) {

      newContractVersionProviderOffering = contractProviderOfferingLinkDAO.newInstance();
      newContractVersionProviderOffering.setContractVersion(
        newUtilizationContract);
      newContractVersionProviderOffering.setProviderOffering(
        contractVersionProviderOffering.getProviderOffering());

      newContractVersionProviderOffering.insert();

      // Need to copy the most recent rate for this provider offering that are
      // on the existing Contract
      // to the new Utilization contract

      Set<ProviderOfferingRate> rates = providerOfferingRateDAO.searchBy(
        contractVersionProviderOffering.getProviderOffering(),
        contractVersionProviderOffering.getContractVersion());

      ProviderOfferingRate latestRate = providerOfferingRateDAO.newInstance();

      for (final ProviderOfferingRate existingRate : rates) {

        // Find the most recent rate
        if (latestRate.getDateRange().start().before(
          existingRate.getDateRange().start())) {
          latestRate = existingRate;
        }
      }

      // If there is a latest rate available then copy it for the new contract
      if (latestRate.getProviderOffering() != null) {
        // Create the new rate base on the existing latest rate
        ProviderOfferingRate newRate = providerOfferingRateDAO.newInstance();

        newRate.setDefaultRates();
        newRate.setDateRange(newUtilizationContract.getDateRange());
        if (!latestRate.getFixedAmount().isNegative()) {
          newRate.setFixedAmount(latestRate.getFixedAmount());
        }
        if (!latestRate.getMinAmount().isNegative()) {
          newRate.setMinAmount(latestRate.getMinAmount());
        }
        if (!latestRate.getMaxAmount().isNegative()) {
          newRate.setMaxAmount(latestRate.getMaxAmount());
        }
        newRate.setProviderOffering(latestRate.getProviderOffering());
        newRate.setContractVersion(newUtilizationContract);

        newRate.insert();
      }

      // Need to copy the most recent place limit for this provider offering
      // that are on the existing Contract
      // to the new Utilization contract

      Set<ProviderOfferingPlaceLimit> existingPlaceLimits = providerOfferingPlaceLimitDAO.searchBy(
        contractVersionProviderOffering.getProviderOffering(),
        contractVersionProviderOffering.getContractVersion());

      ProviderOfferingPlaceLimit latestPlaceLimit = providerOfferingPlaceLimitDAO.newInstance();

      for (final ProviderOfferingPlaceLimit existingPlaceLimit : existingPlaceLimits) {

        // Find the most recent place limit
        if (latestPlaceLimit.getDateRange().start().before(
          existingPlaceLimit.getDateRange().start())) {
          latestPlaceLimit = existingPlaceLimit;
        }

      }

      // If there is a latest place limit available then copy it for the new
      // contract
      if (latestPlaceLimit.getProviderOffering() != null) {
        ProviderOfferingPlaceLimit newPlaceLimit = providerOfferingPlaceLimitDAO.newInstance();

        newPlaceLimit.setDateRange(newUtilizationContract.getDateRange());
        newPlaceLimit.setPlaceLimit(latestPlaceLimit.getPlaceLimit());
        newPlaceLimit.setProviderOffering(
          latestPlaceLimit.getProviderOffering());
        newPlaceLimit.setContract(newUtilizationContract);

        newPlaceLimit.insert();
      }

    }
  }

  /**
   * @param newUtilizationContract
   * @throws InformationalException
   *
   * Copy this contract's
   * {@linkplain curam.contracts.impl.ContractPGAssociateLink}s onto
   * the new contract.
   */
  // BEGIN, CR00177241, PM
  protected void cloneContractPGAssociateLinks(
    UtilizationContract newUtilizationContract) throws InformationalException {
    // END, CR00177241

    ContractVersionProviderGroupAssociate newContractPGAssociateLink;

    for (final ContractVersionProviderGroupAssociate contractVersionProviderGroupAssociate : getContractVersionProviderGroupAssociate()) {

      newContractPGAssociateLink = contractVersionProviderGroupAssociateDAO.newInstance();
      newContractPGAssociateLink.setContractVersion(newUtilizationContract);
      newContractPGAssociateLink.setProviderGroupAssociate(
        contractVersionProviderGroupAssociate.getProviderGroupAssociate());
      newContractPGAssociateLink.insert();
    }
  }

  /**
   * @param newUtilizationContract
   * @throws InformationalException
   *
   * Copy this contract's
   * {@linkplain curam.contracts.impl.ContractContact}s onto the new
   * contract.
   */
  // BEGIN, CR00177241, PM
  protected void cloneContractContacts(
    UtilizationContract newUtilizationContract) throws InformationalException {
    // END, CR00177241

    ContractContact newContractContact;

    for (final ContractContact contractContact : getContractContacts()) {

      if (contractContact.getLifecycleState().equals(RECORDSTATUSEntry.NORMAL)) {

        newContractContact = contractContactDAO.newInstance();

        newContractContact.setContractVersion(newUtilizationContract);
        newContractContact.setContactPeriod(
          newUtilizationContract.getDateRange());
        newContractContact.setProviderParty(contractContact.getProviderParty());

        newContractContact.insert();
      }
    }
  }

  /**
   * @param amendmentVersionNumber
   */
  // BEGIN, CR00177241, PM
  protected void setAmendmentVersionNumber(int amendmentVersionNumber) {
    // END, CR00177241
    getBaseRowDtls().amendmentVersionNumber = amendmentVersionNumber;
  }

  /**
   * Copies the existing utilization contract to the new utilization contract
   * for the new date period. The status of the cloned contract will be
   * {@linkplain CONTRACTSTATUSEntry#INEDIT}.
   *
   * @param existingContract
   * The contract whose attributes are to be copied.
   * @param startDate
   * The start date for the new contract version.
   *
   * @return The cloned contract with the new start date and status
   * {@linkplain CONTRACTSTATUSEntry#INEDIT}.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public UtilizationContract cloneUtilizationContract(
    UtilizationContract existingContract, Date startDate)
    throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre cloneUtilizationContract utilization contract event.
    cloneUtilizationContractEventDispatcherFactory.get(UtilizationContractCloneUtilizationContractEvents.class).preCloneUtilizationContract(
      this, existingContract, startDate);
    // END, CR00235789

    // Copy attributes
    setCPMContract(existingContract.getCPMContract());
    setProviderOrganization(existingContract.getProviderOrganization());
    setName(existingContract.getName());
    setGenerationReason(existingContract.getGenerationReason());
    setRequiredLicenseType(existingContract.getRequiredLicenseType());
    setContractServicesType(existingContract.getContractServicesType());
    setAmendmentVersionNumber(existingContract.getAmendmentVersionNumber() + 1);

    // set new start date
    setDateRange(
      new DateRange(startDate, existingContract.getDateRange().end()));

    insert();

    // BEGIN, CR00235789, AK
    // Raise the post cloneUtilizationContract utilization contract event.
    cloneUtilizationContractEventDispatcherFactory.get(UtilizationContractCloneUtilizationContractEvents.class).postCloneUtilizationContract(
      this, existingContract, startDate, this);
    // END, CR00235789

    return this;
  }

  /**
   * Replicates an existing utilization contract in a new date period for
   * renewal, returning the new record in a status of
   * {@linkplain CONTRACTSTATUSEntry#INEDIT}.
   *
   * @param existingContract
   * The contract whose attributes are to be copied.
   * @param dateRange
   * The date range for the new contract version.
   *
   * @return The cloned contract with the new start date and status
   * {@linkplain CONTRACTSTATUSEntry#INEDIT}.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public UtilizationContract cloneUtilizationContractForRenewal(
    UtilizationContract existingContract, DateRange dateRange)
    throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre cloneUtilizationContractForRenewal utilization contract
    // event.
    cloneUtilizationContractForRenewalEventDispatcherFactory.get(UtilizationContractCloneUtilizationContractForRenewalEvents.class).preCloneUtilizationContractForRenewal(
      this, existingContract, dateRange);
    // END, CR00235789

    // Create a new CPMContract Record
    CPMContract cpmContract = cpmContractDAO.newInstance();

    // BEGIN, CR00247132, VR
    cpmContract.insert(existingContract);
    // END, CR00247132
    // Copy attributes
    setCPMContract(cpmContract);
    setProviderOrganization(existingContract.getProviderOrganization());
    setName(existingContract.getName());
    setGenerationReason(existingContract.getGenerationReason());
    setRequiredLicenseType(existingContract.getRequiredLicenseType());
    setContractServicesType(existingContract.getContractServicesType());
    setAmendmentVersionNumber(kAMENDMENTVERSIONNUMBERONE);

    // BEGIN, CR00089491, JM
    setRenewedFromContractVersion(true);
    // END, CR00089491

    // set new start date and blank end date
    setDateRange(dateRange);

    insert();

    // BEGIN, CR00235789, AK
    // Raise the post cloneUtilizationContractForRenewal utilization contract
    // event.
    cloneUtilizationContractForRenewalEventDispatcherFactory.get(UtilizationContractCloneUtilizationContractForRenewalEvents.class).postCloneUtilizationContractForRenewal(
      this, existingContract, dateRange, this);
    // END, CR00235789

    return this;
  }

  /**
   * Generates a contract. Also validates the contracted provider offering
   * rates.
   *
   * Transitions the state to {@linkplain CONTRACTSTATUSEntry#ISSUED}, if valid
   * to do so.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void generate(int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre generate utilization contract event.
    generateEventDispatcherFactory.get(UtilizationContractGenerateEvents.class).preGenerate(
      this, versionNo);
    // END, CR00235789

    transitionTo(issued, versionNo);

    super.generate(versionNo);

    // Contract ProviderOfferingRates cannot overlap or contain coverage gaps
    validateContractedProviderOfferingRates();

    // BEGIN, CR00235789, AK
    // Raise the post generate utilization contract event.
    generateEventDispatcherFactory.get(UtilizationContractGenerateEvents.class).postGenerate(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * Activates the contract, all contracted provider offering rates for the
   * contract and all contracted provider offering place limits for the
   * contract.
   *
   * <ul>
   * <li>Transitions the state to {@linkplain CONTRACTSTATUSEntry#LIVE}, if
   * valid to do so.</li>
   * <li>If a {@linkplain CONTRACTSTATUSEntry#LIVE} contract with the same
   * reference number already exists, that contract will be transitioned to
   * {@linkplain CONTRACTSTATUSEntry#AMENDED}.</li>
   * </ul>
   * Also raises a workflow event.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void activate(int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre activate utilization contract event.
    activateEventDispatcherFactory.get(UtilizationContractActivateEvents.class).preActivate(
      this, versionNo);
    // END, CR00235789

    amendAnyExistingLiveContracts();

    super.activate(versionNo);

    // BEGIN CR00097035, JSP

    final Event event = new Event();

    event.eventKey = curam.events.CONTRACTS.UTILIZATIONCONTRACT_ACTIVATED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // END CR00097035

    transitionTo(live, versionNo);

    activateContractedProviderOfferingRates();

    activateContractedProviderOfferingPlaceLimits();

    // BEGIN, CR00235789, AK
    // Raise the post activate utilization contract event.
    activateEventDispatcherFactory.get(UtilizationContractActivateEvents.class).postActivate(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * Terminates the contract, provider offering rates for the contract and
   * provider offering place limits for the contract. Transitions the state to
   * {@linkplain CONTRACTSTATUSEntry#TERMINATED}, if valid to do so and also
   * raises a workflow event.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void terminate(int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre terminate utilization contract event.
    terminateEventDispatcherFactory.get(UtilizationContractTerminateEvents.class).preTerminate(
      this, versionNo);
    // END, CR00235789

    super.terminate(versionNo);

    transitionTo(terminated, versionNo);

    terminateContractedProviderOfferingRates();

    terminateContractedProviderOfferingPlaceLimits();

    // BEGIN CR00097035, JSP

    final Event event = new Event();

    event.eventKey = curam.events.CONTRACTS.UTILIZATIONCONTRACT_TERMINATED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // END CR00097035

    // BEGIN, CR00235789, AK
    // Raise the post terminate utilization contract event.
    terminateEventDispatcherFactory.get(UtilizationContractTerminateEvents.class).postTerminate(
      this, versionNo);
    // END, CR00235789

  }

  protected final State<CONTRACTSTATUSEntry> inEdit = new CodetableState<CONTRACTSTATUSEntry>(
    states, CONTRACTSTATUSEntry.INEDIT, true, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      State<CONTRACTSTATUSEntry> oldState) {

      if (oldState.getValue().equals(CONTRACTSTATUSEntry.TERMINATED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_TERMINATED_CANNOT_MODIFY(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else if (oldState.getValue().equals(CONTRACTSTATUSEntry.AMENDED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_AMENDED_CANNOT_MODIFY(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }

      if (oldState.getValue().equals(CONTRACTSTATUSEntry.LIVE)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_CONTRACT_NOT_EDITED(
            oldState.getValue().getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            1);
      }

      if (oldState.getValue().equals(CONTRACTSTATUSEntry.CANCELED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_CONTRACT_NOT_EDITED(
            oldState.getValue().getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

    }
  };

  protected final State<CONTRACTSTATUSEntry> terminated = new CodetableState<CONTRACTSTATUSEntry>(
    states, CONTRACTSTATUSEntry.TERMINATED, false, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      State<CONTRACTSTATUSEntry> oldState) {

      if (oldState.getValue().equals(CONTRACTSTATUSEntry.CANCELED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_DELETED_CANNOT_TERMINATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else if (oldState.getValue().equals(CONTRACTSTATUSEntry.TERMINATED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_ALREADY_TERMINATED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else if (oldState.getValue().equals(CONTRACTSTATUSEntry.AMENDED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_AMENDED_CANNOT_TERMINATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_NOT_LIVE_CANNOT_TERMINATED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }

    // BEGIN CR00093675, PDN
    @Override
    @SuppressWarnings(CPMConstants.kSyntheticAccess)
    protected void onEnter() {

      // Business Rule: A Contract in the derived 'Expired' state cannot be
      // Terminated
      if (Date.getCurrentDate().after(getBaseRowDtls().endDate)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          FLATRATECONTRACTExceptionCreator.ERR_FV_CONTRACT_NOT_LIVE_CANNOT_TERMINATED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }
    // END CR00093675

  };

  protected final State<CONTRACTSTATUSEntry> live = new CodetableState<CONTRACTSTATUSEntry>(
    states, CONTRACTSTATUSEntry.LIVE, false, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      State<CONTRACTSTATUSEntry> oldState) {

      if (oldState.getValue().equals(CONTRACTSTATUSEntry.INEDIT)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_NOT_ISSUED_CANNOT_ACTIVATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else if (oldState.getValue().equals(CONTRACTSTATUSEntry.LIVE)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_ALREADY_ACTIVATED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else if (oldState.getValue().equals(CONTRACTSTATUSEntry.CANCELED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_CANCELED_CANNOT_ACTIVATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else if (oldState.getValue().equals(CONTRACTSTATUSEntry.TERMINATED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_TERMINATED_CANNOT_ACTIVATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else if (oldState.getValue().equals(CONTRACTSTATUSEntry.AMENDED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_AMENDED_CANNOT_ACTIVATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_ONLY_ISSUED_CONTRACTS_CAN_BE_ACTIVATED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
    }
  };

  protected final State<CONTRACTSTATUSEntry> issued = new CodetableState<CONTRACTSTATUSEntry>(
    states, CONTRACTSTATUSEntry.ISSUED, true, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      State<CONTRACTSTATUSEntry> oldState) {

      if (oldState.getValue().equals(CONTRACTSTATUSEntry.ISSUED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_ALREADY_GENERATED(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else if (oldState.getValue().equals(CONTRACTSTATUSEntry.TERMINATED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_TERMINATED_CANNOT_GENERATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } // BEGIN, CR00158174, AS
      else if (CONTRACTSTATUSEntry.LIVE.equals(oldState.getValue())) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_ACTIVATED_CANNOT_GENERATE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      }
      // END, CR00158174
    }
  };

  protected final State<CONTRACTSTATUSEntry> amended = new CodetableState<CONTRACTSTATUSEntry>(
    states, CONTRACTSTATUSEntry.AMENDED, false, false) {

    @Override
    @SuppressWarnings(CPMConstants.kUnused)
    protected void onUnsupportedTransitionFrom(
      State<CONTRACTSTATUSEntry> oldState) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        UTILIZATIONCONTRACTExceptionCreator.ERR_CONTRACT_NOT_LIVE_CANNOT_AMEND(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
  };

  protected final State<CONTRACTSTATUSEntry> canceled = new CodetableState<CONTRACTSTATUSEntry>(
    states, CONTRACTSTATUSEntry.CANCELED, false, false) {

    @Override
    protected void onUnsupportedTransitionFrom(
      State<CONTRACTSTATUSEntry> oldState) {

      if (oldState.getValue().equals(CONTRACTSTATUSEntry.AMENDED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_FV_CONTRACT_AMENDED_CANNOT_DELETE(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      } else {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          UTILIZATIONCONTRACTExceptionCreator.ERR_CONTRACT_NOT_DELETED(
            oldState.getValue().getCodeTableItemIdentifier()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }
    }
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<CONTRACTSTATUSEntry> inedit2Issued = new Transition<CONTRACTSTATUSEntry>(
    inEdit, issued) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<CONTRACTSTATUSEntry> inedit2Canceled = new Transition<CONTRACTSTATUSEntry>(
    inEdit, canceled) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<CONTRACTSTATUSEntry> INEDIT2INEDIT = new Transition<CONTRACTSTATUSEntry>(
    inEdit, inEdit) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<CONTRACTSTATUSEntry> issued2Canceled = new Transition<CONTRACTSTATUSEntry>(
    issued, canceled) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<CONTRACTSTATUSEntry> issued2Live = new Transition<CONTRACTSTATUSEntry>(
    issued, live) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<CONTRACTSTATUSEntry> ISSUED2INEDIT = new Transition<CONTRACTSTATUSEntry>(
    issued, inEdit) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<CONTRACTSTATUSEntry> live2Terminated = new Transition<CONTRACTSTATUSEntry>(
    live, terminated) {// Uses default implementation
  };

  @SuppressWarnings(CPMConstants.kUnused)
  // Used by state transition infrastructure
  protected final Transition<CONTRACTSTATUSEntry> live2Amended = new Transition<CONTRACTSTATUSEntry>(
    live, amended) {// Uses default implementation
  };

  /**
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void deleteContractedProviderOfferingRates()
    throws InformationalException {
    // END, CR00177241

    for (ContractVersionProviderOffering contractProviderOfferingLink : getContractVersionProviderOfferings()) {

      for (ProviderOfferingRate contractedProviderOfferingRate : providerOfferingRateDAO.searchBy(
        contractProviderOfferingLink.getProviderOffering(),
        contractProviderOfferingLink.getContractVersion())) {

        contractedProviderOfferingRate.remove(
          contractedProviderOfferingRate.getVersionNo());
      }
    }
  }

  // BEGIN, CR00177241, PM
  protected void amendAnyExistingLiveContracts() throws InformationalException {
    // END, CR00177241

    // Search for an existing live contract
    UtilizationContract utilizationContract;

    for (ContractVersion contract : contractVersionDAO.searchBy(
      getCPMContract())) {

      // If Live, transition it to amended
      if ((!contract.getID().equals(this.getID()))
        && contract.getLifecycleState().equals(CONTRACTSTATUSEntry.LIVE)) {

        utilizationContract = (UtilizationContract) contract;
        utilizationContract.amend(utilizationContract.getVersionNo());
      }
    }
  }

  /**
   * Changes the state of the contract to
   * {@linkplain CONTRACTSTATUSEntry#AMENDED}, if valid to do so. Also raises a
   * workflow event.
   *
   * @param versionNo
   * The version number of the record to amend.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void amend(final int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre amend utilization contract event.
    amendEventDispatcherFactory.get(UtilizationContractAmendEvents.class).preAmend(
      this, versionNo);
    // END, CR00235789

    transitionTo(amended, versionNo);

    // BEGIN CR00097035, JSP

    final Event event = new Event();

    event.eventKey = curam.events.CONTRACTS.UTILIZATIONCONTRACT_AMENDED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // END CR00097035

    // BEGIN, CR00235789, AK
    // Raise the post amend utilization contract event.
    amendEventDispatcherFactory.get(UtilizationContractAmendEvents.class).postAmend(
      this, versionNo);
    // END, CR00235789

  }

  /**
   * Inserts the utilization contract record.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert utilization contract event.
    insertEventDispatcherFactory.get(UtilizationContractInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    super.insert();

    // BEGIN CR00097035, JSP

    final Event event = new Event();

    event.eventKey = curam.events.CONTRACTS.UTILIZATIONCONTRACT_INSERTED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // END CR00097035

    // BEGIN, CR00235789, AK
    // Raise the post insert utilization contract event.
    insertEventDispatcherFactory.get(UtilizationContractInsertEvents.class).postInsert(
      this);
    // END, CR00235789

  }

}
