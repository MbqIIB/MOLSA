/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007-2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import curam.core.struct.UniqueIDKeySet;
import curam.cpm.impl.CPMConstants;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;


/**
 * {@inheritDoc} 
 */
// BEGIN, CR00183213, SS
public class UniqueNumberGeneratorImpl implements ReferenceNumberGenerator {
  // END, CR00183213
  protected String referenceNumber;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  // END, CR00183213
  public UniqueNumberGeneratorImpl() {// BEGIN, CR00183213, SS
    // The no-arg constructor for use only by Guice
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  @SuppressWarnings(CPMConstants.kUnused)
  public String generateReferenceNumber(ContractVersion contractVersion, CPMContract cpmContract) throws AppException, InformationalException {

    // BEGIN, CR00170638, GP
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();
    UniqueIDKeySet uniqueIDKeySet = new UniqueIDKeySet();

    uniqueIDKeySet.keySetName = CPMConstants.kCPMCONTRACTKeySetName;

    referenceNumber = String.valueOf(
      uniqueIDObj.getNextIDFromKeySet(uniqueIDKeySet));
    // END, CR00170638

    return referenceNumber;
  }

}
