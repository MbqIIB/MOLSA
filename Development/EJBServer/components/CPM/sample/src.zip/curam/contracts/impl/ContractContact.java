/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import com.google.inject.ImplementedBy;

import curam.provider.impl.ProviderParty;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;


/**
 * The {@link ProviderParty provider party} who is the contact for a
 * {@link ContractVersion contract version} for a period of time.
 *
 * <p>
 * For any period of time during the lifetime of a contract version, there must
 * be either:
 * <ul>
 * <li>no contact; or</li>
 * <li>a single contact.</li>
 * </ul>
 *
 * <p>
 * A provider party may be the contact for more than one contract version.
 */
@ImplementedBy(ContractContactImpl.class)
public interface ContractContact extends ContractContactAccessor, Insertable,
    LogicallyDeleteable, DateRanged, OptimisticLockModifiable {

  // ___________________________________________________________________________
  /**
   * Gets the contract version details.
   *
   * @return the contract version details.
   *
   * @see curam.contracts.impl.ContractVersion
   */
  public ContractVersion getContractVersion();

  // ___________________________________________________________________________
  /**
   * Gets the provider party details.
   *
   * @return the provider party details.
   *
   * @see curam.provider.impl.ProviderParty
   */
  public ProviderParty getProviderParty();

  // ___________________________________________________________________________
  /**
   * Sets the provider party on the contract.
   *
   * @param value
   * the provider party.
   *
   * @see curam.provider.impl.ProviderParty
   */
  public void setProviderParty(ProviderParty value);

  // ___________________________________________________________________________
  /**
   * Sets the version of the contract.
   *
   * @param value
   * the contract version.
   *
   * @see curam.contracts.impl.ContractVersion
   */
  public void setContractVersion(final ContractVersion value);

  // ___________________________________________________________________________
  /**
   * Sets the period of time for which the
   * {@link curam.provider.impl.ProviderParty provider party} is the contact for
   * the {@link curam.contracts.impl.ContractVersion contract version}.
   * <p>
   * The period of time may be open-ended.
   * <p>
   * For any given period of time, there may be at most one contact for the
   * contract version. Attempts to violate this rule will result in runtime
   * exception messages when this is stored.
   *
   * @param value
   * the period of time for which the provider party is the contact for
   * the contract version.
   */
  public void setContactPeriod(final DateRange value);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the contract contact events functionality surrounding the
   * insert method.
   */
  public interface ContractContactInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.contracts.impl.ContractContact#insert}
     *
     * @param contractContact
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ContractContactAccessor contractContact)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.contracts.impl.ContractContact#insert}
     *
     * @param contractContact
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ContractContactAccessor contractContact)
      throws InformationalException;
  }


  /**
   * Interface to the contract contact events functionality surrounding the
   * cancel method.
   */
  public interface ContractContactCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.contracts.impl.ContractContact#cancel}
     *
     * @param contractContact
     * The object instance as it was before the main body of the cancel
     * method.
     *
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(ContractContactAccessor contractContact)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.contracts.impl.ContractContact#cancel}
     *
     * @param contractContact
     * The object instance as it was after the main body of the cancel
     * method.
     *
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(ContractContactAccessor contractContact)
      throws InformationalException;
  }


  /**
   * Interface to the contract contact events functionality surrounding the
   * modify method.
   */
  public interface ContractContactModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.contracts.impl.ContractContact#modify}
     *
     * @param contractContact
     * The object instance as it was before the main body of the modify
     * method.
     *
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(ContractContactAccessor contractContact)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.contracts.impl.ContractContact#modify}
     *
     * @param contractContact
     * The object instance as it was after the main body of the modify
     * method.
     *
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(ContractContactAccessor contractContact)
      throws InformationalException;
  }
  // END, CR00144381

}
