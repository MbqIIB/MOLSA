/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import com.google.inject.Inject;

import curam.cpm.sl.entity.struct.CPMContractDtls;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * {@inheritDoc}
 */
// BEGIN, CR00183213, SS
public class CPMContractImpl extends SingleTableEntityImpl<CPMContractDtls>
  implements CPMContract {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<CPMContractInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<CPMContractModifyEvents> modifyEventDispatcherFactory;
  // END, CR00235789

  // BEGIN CR00091263, PDN
  @Inject
  protected ReferenceNumberGenerator referenceNumberGenerator;
  // END CR00091263

  // __________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected CPMContractImpl() {// No-arg constructor for use only by the framework
  }

  // END, CR00183213

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// none required
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none required
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// none required
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public String getReferenceNumber() {

    return getDtls().referenceNumber;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// none required
  }

  // __________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public void insert(ContractVersion contractVersion)
    throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert CPM contract event.
    insertEventDispatcherFactory.get(CPMContractInsertEvents.class).preInsert(
      this, contractVersion);
    // END, CR00235789

    try {
      getDtls().referenceNumber = referenceNumberGenerator.generateReferenceNumber(
        contractVersion, this);
    } catch (final Exception e) {
      // translate any exceptions to a runtime exception
      throw new AppRuntimeException(e);
    }

    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert CPM contract event.
    insertEventDispatcherFactory.get(CPMContractInsertEvents.class).postInsert(
      this, contractVersion);
    // END, CR00235789

  }

  // BEGIN, CR00235789, AK
  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // Raise the pre modify CPM contract event.
    modifyEventDispatcherFactory.get(CPMContractModifyEvents.class).preModify(
      this, versionNo);

    super.modify(versionNo);

    // Raise the post modify CPM contract event.
    modifyEventDispatcherFactory.get(CPMContractModifyEvents.class).postModify(
      this, versionNo);
  }
  // END, CR00235789
}
