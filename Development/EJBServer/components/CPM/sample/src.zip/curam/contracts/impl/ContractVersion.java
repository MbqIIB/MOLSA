/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.List;
import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.cpm.facade.struct.ContractNotificationKey;
import curam.cpm.facade.struct.ContractReturnDocDetails;
import curam.provider.impl.LicenseTypeEntry;
import curam.provider.impl.Provider;
import curam.provider.impl.ProviderOrganization;
import curam.providerservice.impl.ProviderOffering;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.Lifecycle;
import curam.util.persistence.helper.Named;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Date;
import curam.util.type.DateRange;
import curam.util.type.DateRanged;


/**
 * This business interface maintains contract version. Contract version is a version 
 * of a formal agreement between the organization and a provider to provide service(s).
 */
@ImplementedBy(ContractVersionImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ContractVersion extends ContractVersionAccessor, Insertable,
    Named, Commented, DateRanged, OptimisticLockModifiable,
    Lifecycle<CONTRACTSTATUSEntry> {

  /**
   * Gets the set of contacts for contract version.
   *
   * @return the set of contacts for contract version.
   */
  public Set<ContractContact> getContacts();

  /**
   * Gets the provider organization to which this contract version belongs.
   *
   * @return the provider organization to which this contract version belongs.
   */
  public ProviderOrganization getProviderOrganization();

  /**
   * Gets the set of providers to which this contract version belongs.
   *
   * @return the set of providers to which this contract version belongs.
   */
  public Set<Provider> getProviders();

  /**
   * Gets the set of provider offerings specified on this contract version.
   *
   * @boread FlatRateContract
   * @boread UtilizationContract
   * @boread ProviderService
   *
   * @return The set of provider offerings.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public Set<ProviderOffering> getProviderOfferings();

  /**
   * Gets the history of changes to the state of this contract version.
   *
   * @return the history of changes to the state of this contract version.
   */
  public List<ContractStatusHistory> getStatusHistory();

  /**
   * Gets the related {@linkplain curam.contracts.impl.CPMContract}.
   *
   * @return the related {@linkplain curam.contracts.impl.CPMContract}.
   */
  public CPMContract getCPMContract();

  /**
   * Sets the date the contract was signed.
   *
   * @param value
   * the date the contract was signed
   */
  public void setDateSigned(final Date value);

  /**
   * Sets the required license type of the contract.
   *
   * @param value
   * the required license type of the contract
   */
  public void setRequiredLicenseType(final LicenseTypeEntry value);

  /**
   * Sets the contract services type of the contract.
   *
   * @param value
   * the contract services type of the contract
   */
  public void setContractServicesType(final ContractServicesTypeEntry value);

  /**
   * Sets the contract generation reason.
   *
   * @param value
   * the contract generation reason
   */
  public void setGenerationReason(final ContractGenerationReasonEntry value);

  /**
   * Sets the contract termination reason.
   *
   * @param value
   * the contract termination reason
   */
  public void setTerminationReason(final ContractTerminationReasonEntry value);

  /**
   * Sets the date the contract was generated.
   *
   * @param value
   * the date the contract was generated
   */
  public void setGenerationDate(final Date value);

  /**
   * Sets the provider organization to which this contract version belongs.
   *
   * @param value
   * the provider organization to which this contract version belongs
   */
  public void setProviderOrganization(final ProviderOrganization value);

  /**
   * Sets the lifetime of the contract version.
   *
   * @param value
   * the lifetime of the contract version
   *
   * @see curam.contracts.impl.ContractVersionImpl#setDateRange(DateRange) The
   * default implementation -
   * curam.contracts.impl.ContractVersionImpl#setDateRange(DateRange).
   */
  public void setDateRange(final DateRange value);

  /**
   * Sets the CPMContract instance.
   *
   * @param value
   * CPMContract instance
   */
  public void setCPMContract(final CPMContract value);

  // BEGIN, CR00089491, JM

  /**
   * Sets the contract renewed indicator of the contract version.
   *
   * @param value
   * boolean value to say if contract version is renewed
   */
  public void setRenewedFromContractVersion(final boolean value);

  // END, CR00089491

  /**
   * Prints the contract.
   *
   * @param key
   * the key that specifies the contract notification details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void printContract(ContractNotificationKey key) throws AppException,
      InformationalException;

  /**
   * Previews the contract that matches the key.
   *
   * @param key
   * contractVersionID and event of the contract
   *
   * @return the file name and file data.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ContractReturnDocDetails previewContract(ContractNotificationKey key)
    throws AppException, InformationalException;

  /**
   * Gets the service offerings which are approved to be provided by <i>all</i>
   * the providers on this contract version.
   *
   * @return the service offerings which are approved to be provided by <i>all</i>
   * the providers on this contract version.
   */
  public Set<ServiceOffering> getCommonApprovedProviderServiceOfferings();

  /**
   * Checks for overlapping Provider Offering Rates and gaps in coverage.
   * <p>
   * If the contract is IN EDIT, informational messages are raised. If the
   * contract is in any other state, the messages are treated as errors.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void validateContractedProviderOfferingRates()
    throws InformationalException;

  /**
   * Checks for overlapping Place Limits and gaps in coverage.
   * <p>
   * If the contract is IN EDIT, informational messages are raised. If the
   * contract is in any other state, the messages are treated as errors.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void validateContractedProviderOfferingPlaceLimits()
    throws InformationalException;

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the contract version events functionality surrounding the
   * printContract method.
   */
  public interface ContractVersionPrintContractEvents {

    /**
     * Event interface invoked before the main body of the printContract method.
     * {@linkplain curam.contracts.impl.ContractVersion#printContract}
     *
     * @param contractVersion
     * The object instance as it was before the main body of the
     * printContract method.
     * @param key
     * The parameter as passed to the printContract method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void prePrintContract(ContractVersionAccessor contractVersion,
      ContractNotificationKey key) throws AppException,
        InformationalException;

    /**
     * Event interface invoked after the main body of the printContract method.
     * {@linkplain curam.contracts.impl.ContractVersion#printContract}
     *
     * @param contractVersion
     * The object instance as it was after the main body of the
     * printContract method.
     * @param key
     * The parameter as passed to the printContract method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void postPrintContract(ContractVersionAccessor contractVersion,
      ContractNotificationKey key) throws AppException,
        InformationalException;
  }


  /**
   * Interface to the contract version events functionality surrounding the
   * previewContract method.
   */
  public interface ContractVersionPreviewContractEvents {

    /**
     * Event interface invoked before the main body of the previewContract
     * method. {@linkplain curam.contracts.impl.ContractVersion#previewContract}
     *
     * @param contractVersion
     * The object instance as it was before the main body of the
     * previewContract method.
     * @param key
     * The parameter as passed to the previewContract method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void prePreviewContract(ContractVersionAccessor contractVersion,
      ContractNotificationKey key) throws AppException,
        InformationalException;

    /**
     * Event interface invoked after the main body of the previewContract
     * method. {@linkplain curam.contracts.impl.ContractVersion#previewContract}
     *
     * @param contractVersion
     * The object instance as it was after the main body of the
     * previewContract method.
     * @param key
     * The parameter as passed to the previewContract method.
     * @param returnValue
     * The return value updated by the Event Handler.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void postPreviewContract(ContractVersionAccessor contractVersion,
      ContractNotificationKey key, ContractReturnDocDetails returnValue)
      throws AppException, InformationalException;
  }


  /**
   * Interface to the contract version events functionality surrounding the
   * validateContractedProviderOfferingRates method.
   */
  public interface ContractVersionValidateContractedProviderOfferingRatesEvents {

    /**
     * Event interface invoked before the main body of the
     * validateContractedProviderOfferingRates method.
     * {@linkplain curam.contracts.impl.ContractVersion#validateContractedProviderOfferingRates}
     *
     * @param contractVersion
     * The object instance as it was before the main body of the
     * validateContractedProviderOfferingRates method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preValidateContractedProviderOfferingRates(
      ContractVersionAccessor contractVersion) throws InformationalException;

    /**
     * Event interface invoked after the main body of the
     * validateContractedProviderOfferingRates method.
     * {@linkplain curam.contracts.impl.ContractVersion#validateContractedProviderOfferingRates}
     *
     * @param contractVersion
     * The object instance as it was after the main body of the
     * validateContractedProviderOfferingRates method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postValidateContractedProviderOfferingRates(
      ContractVersionAccessor contractVersion) throws InformationalException;
  }


  /**
   * Interface to the contract version events functionality surrounding the
   * validateContractedProviderOfferingPlaceLimits method.
   */
  public interface ContractVersionValidateContractedProviderOfferingPlaceLimitsEvents {

    /**
     * Event interface invoked before the main body of the
     * validateContractedProviderOfferingPlaceLimits method.
     * {@linkplain curam.contracts.impl.ContractVersion#validateContractedProviderOfferingPlaceLimits}
     *
     * @param contractVersion
     * The object instance as it was before the main body of the
     * validateContractedProviderOfferingPlaceLimits method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preValidateContractedProviderOfferingPlaceLimits(
      ContractVersionAccessor contractVersion) throws InformationalException;

    /**
     * Event interface invoked after the main body of the
     * validateContractedProviderOfferingPlaceLimits method.
     * {@linkplain curam.contracts.impl.ContractVersion#validateContractedProviderOfferingPlaceLimits}
     *
     * @param contractVersion
     * The object instance as it was after the main body of the
     * validateContractedProviderOfferingPlaceLimits method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postValidateContractedProviderOfferingPlaceLimits(
      ContractVersionAccessor contractVersion) throws InformationalException;
  }


  /**
   * Interface to the contract version events functionality surrounding the
   * insert method.
   */
  public interface ContractVersionInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.contracts.impl.ContractVersion#insert}
     *
     * @param contractVersion
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ContractVersionAccessor contractVersion)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.contracts.impl.ContractVersion#insert}
     *
     * @param contractVersion
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ContractVersionAccessor contractVersion)
      throws InformationalException;
  }


  /**
   * Interface to the contract version events functionality surrounding the
   * modify method.
   */
  public interface ContractVersionModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.contracts.impl.ContractVersion#modify}
     *
     * @param contractVersion
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(ContractVersionAccessor contractVersion,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.contracts.impl.ContractVersion#modify}
     *
     * @param contractVersion
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(ContractVersionAccessor contractVersion,
      Integer versionNo) throws InformationalException;
  }
  // END, CR00144381

}
