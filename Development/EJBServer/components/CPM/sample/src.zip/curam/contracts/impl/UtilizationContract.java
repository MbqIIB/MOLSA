/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import com.google.inject.ImplementedBy;

import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * A formal agreement between the organization and a provider to provide
 * service(s). The flat-rate contract establishes the terms under which the
 * service(s) will be provided. The amount agreed will be paid to the provider
 * on a regular basis regardless of utilization. E.g. a contract to deliver day
 * care places at $500 per month.
 */
@ImplementedBy(UtilizationContractImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface UtilizationContract extends UtilizationContractAccessor,
    ContractVersion {

  /**
   * Generates a contract.
   *
   * Transitions the state to {@linkplain CONTRACTSTATUSEntry#ISSUED}, if valid
   * to do so.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.UtilizationContractImpl#generate(int) The default
   * implementation -
   * curam.contracts.impl.UtilizationContractImpl#generate(int)
   */
  public void generate(int versionNo) throws InformationalException;

  /**
   * Activates the contract.
   *
   * <ul>
   * <li>Transitions the state to {@linkplain CONTRACTSTATUSEntry#LIVE}, if
   * valid to do so.</li>
   * <li>If a {@linkplain CONTRACTSTATUSEntry#LIVE} contract with the same
   * reference number already exists, that contract will be transitioned to
   * {@linkplain CONTRACTSTATUSEntry#AMENDED}.</li>
   * </ul>
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.UtilizationContractImpl#activate(int) The default
   * implementation -
   * curam.contracts.impl.UtilizationContractImpl#activate(int)
   */
  public void activate(int versionNo) throws InformationalException;

  /**
   * Terminates the contract.
   *
   * Transitions the state to {@linkplain CONTRACTSTATUSEntry#TERMINATED}, if
   * valid to do so.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.UtilizationContractImpl#terminate(int) The
   * default implementation -
   * curam.contracts.impl.UtilizationContractImpl#terminate(int)
   */
  public void terminate(int versionNo) throws InformationalException;

  /**
   * Deletes the contract.
   *
   * Transitions the state to {@linkplain CONTRACTSTATUSEntry#CANCELED}, if
   * valid to do so.
   *
   * @param versionNo
   * The version number as previously retrieved.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.UtilizationContractImpl#delete(int) The default
   * implementation -
   * curam.contracts.impl.UtilizationContractImpl#delete(int)
   */
  public void delete(int versionNo) throws InformationalException;

  /**
   * Renews a contract, creates a new in edit version of the contract.
   *
   * @param versionNo
   * The version number as previously retrieved.
   * @param dateRange
   * The date range used to renew the contract.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.UtilizationContractImpl#renew(int, DateRange) The
   * default implementation -
   * curam.contracts.impl.UtilizationContractImpl#renew(int, DateRange)
   */
  public void renew(int versionNo, DateRange dateRange)
    throws InformationalException;

  /**
   * Modifies the flat-rate contract by transitioning to the In Edit state, if
   * valid to do so.
   *
   * @boread FlatRateContract
   * @boread UtilizationContract
   *
   * @param versionNo
   * Version number of the utilization contract.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public void reEdit(int versionNo) throws InformationalException;

  /**
   * Replicates an existing utilization contract in a new date period, returning
   * the new record in a status of {@linkplain CONTRACTSTATUSEntry#INEDIT}.
   *
   * @param existingContract
   * The contract whose attributes are to be copied.
   * @param startDate
   * The start date for the new contract version.
   *
   * @return The cloned contract with the new start date and status
   * {@linkplain CONTRACTSTATUSEntry#INEDIT}.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.UtilizationContractImpl#cloneUtilizationContract(UtilizationContract,
   * Date) The default implementation -
   * curam.contracts.impl.UtilizationContractImpl#cloneUtilizationContract(UtilizationContract,
   * Date)
   */
  public UtilizationContract cloneUtilizationContract(
    UtilizationContract existingContract, Date startDate)
    throws InformationalException;

  /**
   * Replicates an existing utilization contract in a new date period for
   * renewal, returning the new record in a status of
   * {@linkplain CONTRACTSTATUSEntry#INEDIT}.
   *
   * @param existingContract
   * The contract whose attributes are to be copied.
   * @param dateRange
   * The date range for the new contract version.
   *
   * @return The cloned contract with the new start date and status
   * {@linkplain CONTRACTSTATUSEntry#INEDIT}.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.UtilizationContractImpl#cloneUtilizationContractForRenewal(UtilizationContract,
   * DateRange) The default implementation -
   * curam.contracts.impl.UtilizationContractImpl#cloneUtilizationContractForRenewal(UtilizationContract,
   * DateRange)
   */
  public UtilizationContract cloneUtilizationContractForRenewal(
    UtilizationContract existingContract, DateRange dateRange)
    throws InformationalException;

  /**
   * Changes the state of the contract to
   * {@linkplain CONTRACTSTATUSEntry#AMENDED}, if valid to do so.
   *
   * @param versionNo
   * The version number of the record to amend.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.UtilizationContractImpl#amend(int) The default
   * implementation -
   * curam.contracts.impl.UtilizationContractImpl#amend(int)
   */
  public void amend(final int versionNo) throws InformationalException;

  /**
   * <ul>
   * <li>Clones a new instance of the
   * {@linkplain curam.contracts.impl.UtilizationContract}, its related
   * {@linkplain curam.contracts.impl.ContractVersionProviderOffering}s,
   * {@linkplain curam.contracts.impl.ContractVersionProviderGroupAssociate}s
   * and {@linkplain curam.contracts.impl.ContractContactStatusEntry#ACTIVE}
   * {@linkplain curam.contracts.impl.ContractContact}s</li>
   * <li>Sets the new UtilizationContract's state to
   * {@linkplain CONTRACTSTATUSEntry#INEDIT}</li>
   * </ul>
   *
   * @param startDate
   * The start date for the new contract version.
   *
   * @return The cloned utilization contract.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.UtilizationContractImpl#preAmend(Date) The
   * default implementation -
   * curam.contracts.impl.UtilizationContractImpl#preAmend(Date)
   */
  public UtilizationContract preAmend(Date startDate)
    throws InformationalException;

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the utilization contract events functionality surrounding the
   * delete method.
   */
  public interface UtilizationContractDeleteEvents {

    /**
     * Event interface invoked before the main body of the delete method.
     * {@linkplain curam.contracts.impl.UtilizationContract#delete}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the delete
     * method.
     * @param versionNo
     * The parameter as passed to the delete method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preDelete(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the delete method.
     * {@linkplain curam.contracts.impl.UtilizationContract#delete}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the delete
     * method.
     * @param versionNo
     * The parameter as passed to the delete method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postDelete(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the utilization contract events functionality surrounding the
   * generate method.
   */
  public interface UtilizationContractGenerateEvents {

    /**
     * Event interface invoked before the main body of the generate method.
     * {@linkplain curam.contracts.impl.UtilizationContract#generate}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the
     * generate method.
     * @param versionNo
     * The parameter as passed to the generate method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preGenerate(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the generate method.
     * {@linkplain curam.contracts.impl.UtilizationContract#generate}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the
     * generate method.
     * @param versionNo
     * The parameter as passed to the generate method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postGenerate(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the utilization contract events functionality surrounding the
   * activate method.
   */
  public interface UtilizationContractActivateEvents {

    /**
     * Event interface invoked before the main body of the activate method.
     * {@linkplain curam.contracts.impl.UtilizationContract#activate}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the
     * activate method.
     * @param versionNo
     * The parameter as passed to the activate method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preActivate(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the activate method.
     * {@linkplain curam.contracts.impl.UtilizationContract#activate}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the
     * activate method.
     * @param versionNo
     * The parameter as passed to the activate method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postActivate(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the utilization contract events functionality surrounding the
   * terminate method.
   */
  public interface UtilizationContractTerminateEvents {

    /**
     * Event interface invoked before the main body of the terminate method.
     * {@linkplain curam.contracts.impl.UtilizationContract#terminate}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the
     * terminate method.
     * @param versionNo
     * The parameter as passed to the terminate method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preTerminate(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the terminate method.
     * {@linkplain curam.contracts.impl.UtilizationContract#terminate}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the
     * terminate method.
     * @param versionNo
     * The parameter as passed to the terminate method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postTerminate(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the utilization contract events functionality surrounding the
   * renew method.
   */
  public interface UtilizationContractRenewEvents {

    /**
     * Event interface invoked before the main body of the renew method.
     * {@linkplain curam.contracts.impl.UtilizationContract#renew}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the renew
     * method.
     * @param versionNo
     * The parameter as passed to the renew method.
     * @param dateRange
     * The parameter as passed to the renew method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preRenew(UtilizationContractAccessor utilizationContract,
      int versionNo, DateRange dateRange) throws InformationalException;

    /**
     * Event interface invoked after the main body of the renew method.
     * {@linkplain curam.contracts.impl.UtilizationContract#renew}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the renew
     * method.
     * @param versionNo
     * The parameter as passed to the renew method.
     * @param dateRange
     * The parameter as passed to the renew method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postRenew(UtilizationContractAccessor utilizationContract,
      int versionNo, DateRange dateRange) throws InformationalException;
  }


  /**
   * Interface to the utilization contract events functionality surrounding the
   * reEdit method.
   */
  public interface UtilizationContractReEditEvents {

    /**
     * Event interface invoked before the main body of the reEdit method.
     * {@linkplain curam.contracts.impl.UtilizationContract#reEdit}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the reEdit
     * method.
     * @param versionNo
     * The parameter as passed to the reEdit method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preReEdit(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the reEdit method.
     * {@linkplain curam.contracts.impl.UtilizationContract#reEdit}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the reEdit
     * method.
     * @param versionNo
     * The parameter as passed to the reEdit method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postReEdit(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the utilization contract events functionality surrounding the
   * cloneUtilizationContract method.
   */
  public interface UtilizationContractCloneUtilizationContractEvents {

    /**
     * Event interface invoked before the main body of the
     * cloneUtilizationContract method.
     * {@linkplain curam.contracts.impl.UtilizationContract#cloneUtilizationContract}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the
     * cloneUtilizationContract method.
     * @param existingContract
     * The parameter as passed to the cloneUtilizationContract method.
     * @param startDate
     * The parameter as passed to the cloneUtilizationContract method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCloneUtilizationContract(
      UtilizationContractAccessor utilizationContract,
      UtilizationContract existingContract, Date startDate)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the
     * cloneUtilizationContract method.
     * {@linkplain curam.contracts.impl.UtilizationContract#cloneUtilizationContract}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the
     * cloneUtilizationContract method.
     * @param existingContract
     * The parameter as passed to the cloneUtilizationContract method.
     * @param startDate
     * The parameter as passed to the cloneUtilizationContract method.
     * @param returnValue
     * The return value updated by the Event Handler.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCloneUtilizationContract(
      UtilizationContractAccessor utilizationContract,
      UtilizationContract existingContract, Date startDate,
      UtilizationContract returnValue) throws InformationalException;
  }


  /**
   * Interface to the utilization contract events functionality surrounding the
   * cloneUtilizationContractForRenewal method.
   */
  public interface UtilizationContractCloneUtilizationContractForRenewalEvents {

    /**
     * Event interface invoked before the main body of the
     * cloneUtilizationContractForRenewal method.
     * {@linkplain curam.contracts.impl.UtilizationContract#cloneUtilizationContractForRenewal}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the
     * cloneUtilizationContractForRenewal method.
     * @param existingContract
     * The parameter as passed to the
     * cloneUtilizationContractForRenewal method.
     * @param dateRange
     * The parameter as passed to the
     * cloneUtilizationContractForRenewal method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCloneUtilizationContractForRenewal(
      UtilizationContractAccessor utilizationContract,
      UtilizationContract existingContract, DateRange dateRange)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the
     * cloneUtilizationContractForRenewal method.
     * {@linkplain curam.contracts.impl.UtilizationContract#cloneUtilizationContractForRenewal}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the
     * cloneUtilizationContractForRenewal method.
     * @param existingContract
     * The parameter as passed to the
     * cloneUtilizationContractForRenewal method.
     * @param dateRange
     * The parameter as passed to the
     * cloneUtilizationContractForRenewal method.
     * @param returnValue
     * The return value updated by the Event Handler.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCloneUtilizationContractForRenewal(
      UtilizationContractAccessor utilizationContract,
      UtilizationContract existingContract, DateRange dateRange,
      UtilizationContract returnValue) throws InformationalException;
  }


  /**
   * Interface to the utilization contract events functionality surrounding the
   * amend method.
   */
  public interface UtilizationContractAmendEvents {

    /**
     * Event interface invoked before the main body of the amend method.
     * {@linkplain curam.contracts.impl.UtilizationContract#amend}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the amend
     * method.
     * @param versionNo
     * The parameter as passed to the amend method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preAmend(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the amend method.
     * {@linkplain curam.contracts.impl.UtilizationContract#amend}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the amend
     * method.
     * @param versionNo
     * The parameter as passed to the amend method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postAmend(UtilizationContractAccessor utilizationContract,
      int versionNo) throws InformationalException;
  }


  /**
   * Interface to the utilization contract events functionality surrounding the
   * preAmend method.
   */
  public interface UtilizationContractPreAmendEvents {

    /**
     * Event interface invoked before the main body of the preAmend method.
     * {@linkplain curam.contracts.impl.UtilizationContract#preAmend}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the
     * preAmend method.
     * @param startDate
     * The parameter as passed to the preAmend method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void prePreAmend(UtilizationContractAccessor utilizationContract,
      Date startDate) throws InformationalException;

    /**
     * Event interface invoked after the main body of the preAmend method.
     * {@linkplain curam.contracts.impl.UtilizationContract#preAmend}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the
     * preAmend method.
     * @param startDate
     * The parameter as passed to the preAmend method.
     * @param returnValue
     * The return value updated by the Event Handler.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postPreAmend(UtilizationContractAccessor utilizationContract,
      Date startDate, UtilizationContract returnValue)
      throws InformationalException;
  }


  /**
   * Interface to the utilization contract events functionality surrounding the
   * insert method.
   */
  public interface UtilizationContractInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.contracts.impl.UtilizationContract#insert}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(UtilizationContractAccessor utilizationContract)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.contracts.impl.UtilizationContract#insert}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(UtilizationContractAccessor utilizationContract)
      throws InformationalException;
  }


  /**
   * Interface to the  utilization contract events functionality surrounding the modify method.
   */
  public interface UtilizationContractModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.contracts.impl.UtilizationContract#modify}
     *
     * @param utilizationContract
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(UtilizationContractAccessor utilizationContract,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.contracts.impl.UtilizationContract#modify}
     *
     * @param utilizationContract
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(UtilizationContractAccessor utilizationContract,
      Integer versionNo) throws InformationalException;
  }
  // END, CR00144381

}
