/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import com.google.inject.Inject;

import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.CONTRACTTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.entity.struct.ContractContactDtls;
import curam.message.impl.CONTRACTCONTACTExceptionCreator;
import curam.message.impl.PROVIDERExceptionCreator;
import curam.provider.impl.ProviderDAO;
import curam.provider.impl.ProviderParty;
import curam.provider.impl.ProviderPartyDAO;
import curam.provider.impl.ProviderSecurity;
import curam.provider.impl.ProviderStatusEntry;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.DateRange;


/**
 * Standard implementation of {@linkplain curam.contracts.impl.ContractContact}.
 */
// BEGIN, CR00183213, SS
public class ContractContactImpl extends SingleTableLogicallyDeleteableEntityImpl<ContractContactDtls> implements
  ContractContact {
  // END, CR00183213

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ContractContactInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<ContractContactCancelEvents> cancelEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ContractContactModifyEvents> modifyEventDispatcherFactory;

  // END, CR00235789

  /**
   * Reference to provider DAO.
   */
  @Inject
  protected ProviderDAO providerDAO;

  /**
   * Reference to contract version DAO.
   */
  @Inject
  protected ContractVersionDAO contractVersionDAO;

  /**
   * Reference to provider party DAO.
   */
  @Inject
  protected ProviderPartyDAO providerPartyDAO;

  /**
   * Reference to contract contact DAO.
   */
  @Inject
  protected ContractContactDAO contractContactDAO;

  /**
   * Reference to provider security DAO.
   */
  @Inject
  protected ProviderSecurity providerSecurity;

  // BEGIN, CR00157709, ASN

  /**
   * Reference to utilization contract DAO.
   */
  @Inject
  protected UtilizationContractDAO utilizationContractDAO;

  /**
   * Reference to flat rate contract DAO.
   */
  @Inject
  protected FlatRateContractDAO flatRateContractDAO;

  // END, CR00157709
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ContractContactImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {
    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  // BEGIN, CR00157709, ASN
  // BEGIN, CR00157709, ASN
 
  /**
   * {@inheritDoc}
   */
  public UtilizationContract getUtilizationContract() {

    return utilizationContractDAO.get(getDtls().contractVersionID);
  }

  /**
   * {@inheritDoc}
   */
  public FlatRateContract getFlatRateContract() {

    return flatRateContractDAO.get(getDtls().contractVersionID);
  }

  // END, CR00157709

  /**
   * Validates that changes made to Contract Contact entity on the database are
   * consistent with other entities.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>{@link curam.message.CONTRACTCONTACT#ERR_XRV_NO_CONTACT_ENDDATE} - If
   * the contract contact End Date is after the End Date of provider party.</li>
   * <li>{@link curam.message.CONTRACTCONTACT#ERR_XRV_CONTACT_ENDDATE_AFTER_PROPARTY_ENDATE} -
   * If the contract contact End Date is after the End Date of provider party
   * end date.</li>
   * <li>{@link curam.message.CONTRACTCONTACT#ERR_XRV_CONTACT_ENDDATE_AFTER_CONTRACT_ENDATE} -
   * If the contract contact End Date is after the contract End Date.</li>
   * <li>{@link curam.message.CONTRACTCONTACT#ERR_XRV_CONTACT_STARTDATE_BEFORE_PARTY_STARTDATE} -
   * If the Start Date of the contract contact is before the provider
   * member/provider participant Start Date.</li>
   * <li>{@link curam.message.CONTRACTCONTACT#ERR_XRV_CONTACT_STARTDATE_BEFORE_CONTRACT_STARTDATE} -
   * If the Start Date of the contract contact is before the contract Start
   * Date.</li>
   * <li>{@link curam.message.CONTRACTCONTACT#ERR_XRV_CONTACT_ALREADY_EXISTS} -
   * If the contact already exists for the contract.</li>
   * </ul>
   *
   */
  public void crossEntityValidation() {

    if (getDtls().endDate.isZero()
      && !getProviderParty().getDateRange().end().isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTCONTACTExceptionCreator.ERR_XRV_NO_CONTACT_ENDDATE(
          getProviderParty().getParty().getName(),
          getProviderParty().getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

    }

    if (getDtls().endDate.after(getProviderParty().getDateRange().end())
      && !getProviderParty().getDateRange().end().isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTCONTACTExceptionCreator.ERR_XRV_CONTACT_ENDDATE_AFTER_PROPARTY_ENDATE(
          getDtls().endDate, getProviderParty().getParty().getName(),
          getProviderParty().getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

    }

    if (getDtls().endDate.after(getContractVersion().getDateRange().end())
      && !getContractVersion().getDateRange().end().isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTCONTACTExceptionCreator.ERR_XRV_CONTACT_ENDDATE_AFTER_CONTRACT_ENDATE(
          getDtls().endDate, getContractVersion().getDateRange().end()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

    }

    // BEGIN, CR000116901, SG
    // Start date of the contract contact cannot be before the start date of
    // the provider member/party start date.
    if (getDtls().startDate.before(getProviderParty().getDateRange().start())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTCONTACTExceptionCreator.ERR_XRV_CONTACT_STARTDATE_BEFORE_PARTY_STARTDATE(
          getDtls().startDate, getProviderParty().getDateRange().start()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    // Contract contact start date cannot be before the contract start date.
    if (getDtls().startDate.before(getContractVersion().getDateRange().start())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTCONTACTExceptionCreator.ERR_XRV_CONTACT_STARTDATE_BEFORE_CONTRACT_STARTDATE(
          getDtls().startDate, getContractVersion().getDateRange().start()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END, CR000116901

    for (final ContractContact contractContact : contractContactDAO.searchBy(
      getContractVersion())) {

      if ((!contractContact.getID().equals(this.getID()))
        && contractContact.getProviderParty().getID().equals(
          getProviderParty().getID())
          && contractContact.getDateRange().overlapsWith(this.getDateRange())
          && !contractContact.getLifecycleState().equals(
            RECORDSTATUSEntry.CANCELLED)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          CONTRACTCONTACTExceptionCreator.ERR_XRV_CONTACT_ALREADY_EXISTS(
            getProviderParty().getParty().getName()),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);
      }

    }

  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none required
  }

  /**
   * Validates that all mandatory fields are populated.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>{@link curam.message.CONTRACTCONTACT#ERR_FV_CONTRACT_NOT_ENTERED} - If
   * Contract ID is not entered. </li>
   * <li>{@link curam.message.CONTRACTCONTACT#ERR_FV_CONTACT_NOT_ENTERED} - If
   * Contact ID is not entered. </li>
   * </ul>
   *
   */
  public void mandatoryFieldValidation() {

    getDateRange().validateStarted();

    if (getDtls().contractVersionID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTCONTACTExceptionCreator.ERR_FV_CONTRACT_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

    if (getDtls().contactConcernRoleID == 0) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTCONTACTExceptionCreator.ERR_FV_CONTACT_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

  }

  /**
   * {@inheritDoc}
   */
  public ContractVersion getContractVersion() {

    final long contractID = getDtls().contractVersionID;

    return contractID == 0 ? null : contractVersionDAO.get(contractID);
  }

  /**
   * {@inheritDoc}
   */
  public void setContractVersion(ContractVersion value) {

    getDtls().contractVersionID = value.getID();

  }

  /**
   * {@inheritDoc}}
   */
  public DateRange getContactPeriod() {

    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * Sets the period of time for which the
   * {@link curam.provider.impl.ProviderParty provider party} is the contact for
   * the {@link curam.contracts.impl.ContractVersion contract version}.Also
   * date range are validated.
   *
   * <p>
   * The period of time may be open-ended.
   * <p>
   * For any given period of time, there may be at most one contact for the
   * contract version. Attempts to violate this rule will result in runtime
   * exception messages when this is stored.
   *
   * @param value
   * the period of time for which the provider party is the contact for
   * the contract version.
   */
  public void setContactPeriod(DateRange value) {

    getDtls().startDate = value.start();
    getDtls().endDate = value.end();

    // field validation
    value.validateRange();
    value.validateStarted();
  }

  /**
   * {@inheritDoc}
   */
  public ProviderParty getProviderParty() {

    final long id = getDtls().contactConcernRoleID;

    return id == 0 ? null : providerPartyDAO.get(id);

  }

  /**
   * {@inheritDoc}
   */
  public void setProviderParty(ProviderParty providerParty) {

    getDtls().contactConcernRoleID = providerParty.getID();
  }

  /**
   * Modifies the contract contact details.Checks the provider organization
   * security to modify the contact details.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // Check the provider organization security
    providerSecurity.checkProviderOrganizationSecurity(
      this.getProviderParty().getProviderOrganization());

    // BEGIN, CR00235789, AK
    // Raise the pre modify contract contact event.
    modifyEventDispatcherFactory.get(ContractContactModifyEvents.class).preModify(
      this);
    // END CR00235789

    // if the status of the provider is closed
    if (getContractVersion().getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {
      if (providerDAO.get(getContractVersion().getProviderOrganization().getID()).getLifecycleState().equals(
        ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
        ValidationHelper.failIfErrorsExist();
      }
    }
    // BEGIN, CR00157709, ASN
    contractStatusChange();
    // END, CR00157709
    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify contract contact event.
    modifyEventDispatcherFactory.get(ContractContactModifyEvents.class).postModify(
      this);
    // END CR00235789
  }

  /**
   * Inserts the contract contact details.Checks the provider organization
   * security to insert the contact details.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   */
  @Override
  public void insert() throws InformationalException {

    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      this.getProviderParty().getProviderOrganization());

    // BEGIN, CR00235789, AK
    // Raise the pre insert contract contact event.
    insertEventDispatcherFactory.get(ContractContactInsertEvents.class).preInsert(
      this);
    // END CR00235789

    // if the status of the provider is closed
    if (getContractVersion().getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {
      if (providerDAO.get(getContractVersion().getProviderOrganization().getID()).getLifecycleState().equals(
        ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
        ValidationHelper.failIfErrorsExist();
      }
    }
    // BEGIN, CR00157709, ASN
    contractStatusChange();
    // END, CR00157709
    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert contract contact event.
    insertEventDispatcherFactory.get(ContractContactInsertEvents.class).postInsert(
      this);
    // END CR00235789

  }

  /**
   * Cancels the contract contact details.Checks the provider organization
   * security to cancel the contact details.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDER#ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS} -
   * If the provider is closed. Provider Details cannot be updated.
   */
  @Override
  public void cancel(int versionNo) throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre cancel contract contact event.
    cancelEventDispatcherFactory.get(ContractContactCancelEvents.class).preCancel(
      this);
    // END CR00235789

    // Check Security
    providerSecurity.checkProviderOrganizationSecurity(
      this.getProviderParty().getProviderOrganization());

    // if the status of the provider is closed
    if (getContractVersion().getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {
      if (providerDAO.get(getContractVersion().getProviderOrganization().getID()).getLifecycleState().equals(
        ProviderStatusEntry.CLOSED)) {
        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          PROVIDERExceptionCreator.ERR_PROVIDER_XRV_PROVIDER_CLOSED_CANNOT_UPDATE_DETAILS(),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
        ValidationHelper.failIfErrorsExist();
      }
    }
    // BEGIN, CR00157709, ASN
    contractStatusChange();
    // END, CR00157709
    super.cancel(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post cancel contract contact event.
    cancelEventDispatcherFactory.get(ContractContactCancelEvents.class).postCancel(
      this);
    // END CR00235789

  }

  // BEGIN, CR00157709, ASN
  /**
   * Changes the contract status from 'Issued' to 'InEdit'.
   *
   * @throws InformationalException
   * Generic exception signature.
   */
  protected void contractStatusChange() throws InformationalException {

    if (CONTRACTTYPEEntry.UTILIZATION.equals(
      getContractVersion().getContractType())) {

      getUtilizationContract().reEdit(getUtilizationContract().getVersionNo());

    } else if (CONTRACTTYPEEntry.FLATRATE.equals(
      getContractVersion().getContractType())) {

      getFlatRateContract().reEdit(getFlatRateContract().getVersionNo());

    } 
    // END, CR00157709
  }
}
