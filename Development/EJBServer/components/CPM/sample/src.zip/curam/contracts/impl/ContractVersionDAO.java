/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2008, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2008, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.provider.impl.ProviderOrganization;
import curam.util.persistence.ReaderDAO;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * This interface is used to access the data of contract version.
 */
@ImplementedBy(ContractVersionDAOImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ContractVersionDAO extends ReaderDAO<Long, ContractVersion> {

  // ___________________________________________________________________________
  /**
   * Searches for contract versions by provider organization.
   *
   * @param providerOrganization the provider organization whose contracts 
   * are required to be retrieved
   *
   * @return all the contracts belonging to the provider organization.
   */
  public Set<ContractVersion> searchBy(
    final ProviderOrganization providerOrganization);

  // ___________________________________________________________________________
  /**
   * Searches for contract versions by CPM contract.
   *
   * @param cpmContract the {@linkplain curam.contracts.impl.CPMContract} to search by
   *
   * the {@linkplain curam.contracts.impl.CPMContract}.
   * @return a set of contract version records for a contract.
   */
  public Set<ContractVersion> searchBy(final CPMContract cpmContract);

  // ___________________________________________________________________________
  /**
   * Reads all the contract version records.
   *
   * @return all contract version records.
   */
  public Set<ContractVersion> readAll();
}
