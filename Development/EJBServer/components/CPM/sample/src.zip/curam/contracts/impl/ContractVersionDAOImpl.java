/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.codetable.CONTRACTTYPE;
import curam.cpm.sl.entity.impl.ContractVersionAdapter;
import curam.cpm.sl.entity.struct.ContractVersionDtls;
import curam.provider.impl.ProviderOrganization;
import curam.util.persistence.BaseDAOImpl;
import curam.util.persistence.ReaderDAO;
import curam.util.persistence.RowManager;


/**
 * {@inheritDoc}
 */
@Singleton
// BEGIN, CR00183213, SS
public class ContractVersionDAOImpl extends BaseDAOImpl<Long, ContractVersion, ContractVersionDtls> implements
  ContractVersionDAO {
  // END, CR00183213
  protected static final ContractVersionAdapter adapter = new ContractVersionAdapter();

  /**
   * Data access object for flat rate contract.
   */
  @Inject
  protected FlatRateContractDAO flatRateContractDAO;

  /**
   * Data access object for utilization contract.
   */
  @Inject
  protected UtilizationContractDAO utilizationContractDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ContractVersionDAOImpl() {
    // END, CR00183213
    super(adapter, ContractVersion.class);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected String getDiscriminator(
    final RowManager<Long, ContractVersionDtls> rowManager) {
    return rowManager.getDtls().contractType;
  }

  /**
   * {@inheritDoc}
   */
  @Override
  protected Map<String, ReaderDAO<Long, ? extends ContractVersion>> getConcreteReaderDAOs() {
    final Map<String, ReaderDAO<Long, ? extends ContractVersion>> concreteReaderDAOs = new HashMap<String, ReaderDAO<Long, ? extends ContractVersion>>();

    concreteReaderDAOs.put(CONTRACTTYPE.FLATRATE, flatRateContractDAO);
    concreteReaderDAOs.put(CONTRACTTYPE.UTILIZATION, utilizationContractDAO);
    return concreteReaderDAOs;
  }

  /**
   * {@inheritDoc}
   */
  public Set<ContractVersion> searchBy(
    final ProviderOrganization providerOrganization) {

    return newSet(adapter.searchByConcernRole(providerOrganization.getID()));
  }

  /**
   * {@inheritDoc}
   */
  public Set<ContractVersion> searchBy(final CPMContract cpmContract) {

    return newSet(adapter.searchByCPMContract(cpmContract.getID()));
  }

  /**
   * {@inheritDoc}
   */
  public Set<ContractVersion> readAll() {

    return newSet(adapter.readAll());
  }
}
