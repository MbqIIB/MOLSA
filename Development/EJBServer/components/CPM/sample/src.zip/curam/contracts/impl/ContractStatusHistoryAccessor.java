/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.util.persistence.StandardEntity;


/**
 * Accessor interface for {@linkplain ContractStatusHistory}.
 */
public interface ContractStatusHistoryAccessor extends StandardEntity {

  /**
   * Returns the status of the contract.
   *
   * @return The status of the contract.
   */
  public CONTRACTSTATUSEntry getStatus();

  /**
   * Returns the username of last person to modify the contract.
   *
   * @return The username of the last person to modify the contract.
   */
  public String getLastModifiedBy();

  /**
   * Returns the reason the contract was created
   * <p>
   * Possible values are NOT SPECIFIED, INITIAL or REISSUE.
   *
   * @return The status history generation reason.
   *
   * @see curam.contracts.impl.ContractGenerationReasonEntry for the specified
   * code value.
   */
  public ContractGenerationReasonEntry getStatusHistoryGenerationReason();

  /**
   * Gets the immutable contract version details.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return The immutable contract version.
   */
  public ContractVersionAccessor getContractVersion();
}
