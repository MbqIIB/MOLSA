/*
 * Licensed Materials - Property of IBM
 *
 * PID 5725-H26
 *
 * Copyright IBM Corporation 2007, 2014. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.contracts.impl;


import java.io.ByteArrayOutputStream;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.COMMUNICATIONFORMAT;
import curam.codetable.COMMUNICATIONMETHOD;
import curam.codetable.COMMUNICATIONSTATUS;
import curam.codetable.COMMUNICATIONTYPE;
import curam.codetable.CORRESPONDENT;
import curam.codetable.RECORDSTATUS;
import curam.codetable.TEMPLATEIDCODE;
import curam.codetable.impl.CMISNAMINGTYPEEntry;
import curam.codetable.impl.CMSLINKRELATEDTYPEEntry;
import curam.codetable.impl.CONCERNROLETYPEEntry;
import curam.codetable.impl.CONTRACTTYPEEntry;
import curam.contracts.ContractNotificationEvent;
import curam.core.fact.AddressFactory;
import curam.core.fact.AdminUserAssistantFactory;
import curam.core.fact.ConcernRoleCommunicationFactory;
import curam.core.fact.ConcernRoleDocumentsFactory;
import curam.core.fact.OrganisationFactory;
import curam.core.fact.SystemUserFactory;
import curam.core.fact.UniqueIDFactory;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.intf.Address;
import curam.core.intf.AdminUserAssistant;
import curam.core.intf.ConcernRoleCommunication;
import curam.core.intf.ConcernRoleDocuments;
import curam.core.intf.Organisation;
import curam.core.intf.SystemUser;
import curam.core.intf.UniqueID;
import curam.core.sl.infrastructure.cmis.impl.CMISAccessInterface;
import curam.core.sl.struct.DataSetData;
import curam.core.sl.struct.LanguageLocaleMapDetails;
import curam.core.struct.AddressDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.ConcernRoleCommunicationDtls;
import curam.core.struct.ConcernRoleKey;
import curam.core.struct.GetResourcesDetails;
import curam.core.struct.OrganisationID;
import curam.core.struct.OrganisationKey;
import curam.core.struct.OrganisationNameAndAddressDetails;
import curam.core.struct.OtherAddressData;
import curam.core.struct.SystemUserDtls;
import curam.core.struct.UserKeyStruct;
import curam.core.struct.UsersKey;
import curam.cpm.facade.struct.ContractDocumentKey;
import curam.cpm.facade.struct.ContractNotificationDetails;
import curam.cpm.facade.struct.ContractNotificationKey;
import curam.cpm.facade.struct.ContractReturnDocDetails;
import curam.cpm.facade.struct.ProviderNotificationList;
import curam.cpm.facade.struct.ServiceOfferingNotificationList;
import curam.cpm.facade.struct.UtilizationServicePLNotificationList;
import curam.cpm.facade.struct.UtilizationServiceRatesNotificationList;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.impl.LicenseNotification;
import curam.message.BPOPROFORMADOCUMENTGENERATION;
import curam.message.GENERALCONCERN;
import curam.participant.impl.ConcernRole;
import curam.participant.impl.ConcernRoleDAO;
import curam.provider.impl.CommunicationCVLink;
import curam.provider.impl.CommunicationCVLinkDAO;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.providerservice.impl.ProviderOfferingPlaceLimitDAO;
import curam.providerservice.impl.ProviderOfferingRate;
import curam.providerservice.impl.ProviderOfferingRateDAO;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.administration.struct.XSLTemplateInstanceKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.exception.RecordNotFoundException;
import curam.util.internal.xml.fact.XSLTemplateFactory;
import curam.util.internal.xml.impl.XMLPrintStreamConstants;
import curam.util.internal.xml.intf.XSLTemplate;
import curam.util.internal.xml.struct.XSLTemplateDtls;
import curam.util.internal.xml.struct.XSLTemplateKey;
import curam.util.message.CURAMXML;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.Configuration;
import curam.util.resources.Locale;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Blob;
import curam.util.type.CodeTable;
import curam.util.type.Date;
import curam.util.xml.fact.XSLTemplateUtilityFactory;
import curam.util.xml.impl.XMLDocument;
import curam.util.xml.impl.XMLEncodingConstants;
import curam.util.xml.impl.XMLPrintStream;
import curam.util.xml.intf.XSLTemplateUtility;
import curam.util.xml.struct.XSLTemplateIDCodeKey;


/**
 * This class holds the API for sending the provider notifications
 *
 */
public class ContractNotification {

  /**
   * Constructor
   */
  public ContractNotification() {

    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  // BEGIN, CR00292749, MR
  /**
   * Reference to CMIS Access Interface.
   */
  @Inject
  protected CMISAccessInterface cmisAccessInterface;
  // END, CR00292749
  
  // BEGIN, CR00281474, MR
  /**
   * Reference to communication contract version link DAO.
   */
  @Inject
  protected CommunicationCVLinkDAO communicationCVLinkDAO;
  // END, CR00281474
  
  // BEGIN, CR00248550, IBM
  @Inject
  protected ContractVersionDAO contractVersionDAO;
  // END, CR00248550
  @Inject
  protected FlatRateContractDAO flatRateContractDAO;

  @Inject
  protected UtilizationContractDAO utilizationContractDAO;

  @Inject
  protected ContractVersionProviderOfferingDAO contractProviderOfferingLinkDAO;

  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  @Inject
  protected ProviderOfferingRateDAO providerOfferingRateDAO;

  @Inject
  protected ProviderOfferingPlaceLimitDAO providerOfferingPlaceLimitDAO;

  @Inject
  protected ContractVersionProviderGroupAssociateDAO contractVersionProviderGroupAssociateDAO;

  @Inject
  protected ConcernRoleDAO concernRoleDAO;

  // BEGIN, CR00178508, SK
  /**
   * Creates the notifications by either using the XSL or XML templates for an
   * event.
   *
   * @param key
   * Contract Version ID and notification event for this document.
   *
   * @throws AppException
   * {@link GENERALCONCERN#ERR_PROFORMATEMPLATE_RNFE} -
   * if the proforma template is not found.
   * @throws AppException
   * {@link BPOPROFORMADOCUMENTGENERATION#ERR_INVALID_FORMAT_NOT_PRINTABLE}
   * - if the form is not a valid XML document.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void createNotification(ContractNotificationKey key)
    throws AppException, InformationalException {

    DataSetData dataSetData = new DataSetData();
    final ContractDocumentKey contractDocumentKey = new ContractDocumentKey();
    final ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    final ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = contractVersion.getProviderOrganization().getID();

    final ConcernRoleDocuments concernRoleDocumentsObj = ConcernRoleDocumentsFactory.newInstance();
    // Get the locale information.
    final LanguageLocaleMapDetails languageLocaleMapDetails = concernRoleDocumentsObj.getLocaleInfo(
      concernRoleKey);

    // END, CR00178508
    // Create and populate an XML document with retrieved data
    dataSetData = generateDocument(key);

    // ******************************
    // CREATE CONTRACT
    // Provider FR Contract(Regular)
    if (key.event.equals(
      ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTREG)) {

      // Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749


      // Provider Flat-Rate Contract(Regular)
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERFLATRATECONTRACTREG;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749

    } // PG FR Contract(Regular)
    else if (key.event.equals(
      ContractNotificationEvent.NEWPGFLATRATECONTRACTREG)) {

      // Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749

      // Provider Group Flat-Rate Contract(Regular)
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGFLATRATECONTRACTREG;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749
    } // Provider FR Contract(Total)
    else if (key.event.equals(
      ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTTOTAL)) {

      // Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749

      // Provider Group Flat-Rate Contract(Total)
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERFLATRATECONTRACTTOTAL;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749
    } // PG FR Contract(Total)
    else if (key.event.equals(
      ContractNotificationEvent.NEWPGFLATRATECONTRACTTOTAL)) {

      // Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749

      // BEGIN, CR00281474, MR
      // Provider Group Flat-Rate Contract(Total)
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGFLATRATECONTRACTTOTAL;
      // END, CR00281474
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749
    } // ******************************
    // UTILIZATION CONTRACTS
    // Provider Utilization
    else if (key.event.equals(
      ContractNotificationEvent.NEWPROVIDERUTILIZATIONCONTRACT)) {

      // Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749

      // Provider Utilization Contract
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERUTILIZATIONCONTRACT;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749
    } // PG Utilization
    else if (key.event.equals(
      ContractNotificationEvent.NEWPGUTILIZATIONCONTRACT)) {

      // Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749

      // PG Utilization Contract
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGUTILIZATIONCONTRACT;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749
    } // ******************************
    // ACTIVATE CONTRACT
    // Provider Contract
    else if (key.event.equals(
      ContractNotificationEvent.ACTIVATEPROVIDERCONTRACT)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERCONTRACTACTIVATIONNOTIFICATION;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749
    } // PG Contract
    else if (key.event.equals(ContractNotificationEvent.ACTIVATEPGCONTRACT)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGCONTRACTACTIVATIONNOTIFICATION;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749
    } // ******************************
    // TERMINATE CONTRACT
    // Provider Contract
    else if (key.event.equals(
      ContractNotificationEvent.TERMINATEPROVIDERCONTRACT)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERCONTRACTTERMINATIONNOTIFICATION;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749
    } // PG Contract
    else if (key.event.equals(ContractNotificationEvent.TERMINATEPGCONTRACT)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGCONTRACTTERMINATIONNOTIFICATION;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749
    } // ******************************
    // RENEW CONTRACT
    // Provider Contract
    else if (key.event.equals(ContractNotificationEvent.RENEWPROVIDERCONTRACT)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERCONTRACTRENEWALNOTIFICATION;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749
    } // PG Contract
    else if (key.event.equals(ContractNotificationEvent.RENEWPGCONTRACT)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGCONTRACTRENEWALNOTIFICATION;
      
      // BEGIN, CR00292749, MR
      createDocumentAndInsertContractCommunication(key, dataSetData,
        contractDocumentKey, languageLocaleMapDetails);

      // END, CR00292749
    }
  }

  // BEGIN, CR00281474, MR
  /**
   * Retrieves flat-rate contract data.
   *
   * @param key
   * Contains contract VersionID and notification event for this contract.
   *
   * @return Contract details for this contract.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  public ContractNotificationDetails getFlatRateContractDetails(
    final ContractNotificationKey key) throws AppException,
      InformationalException {
    // END, CR00281474
    // END, CR00177241

    final FlatRateContract flatRateContract = flatRateContractDAO.get(
      key.contractVersionID);

    final ContractNotificationDetails contractNotificationDetails = new ContractNotificationDetails();

    // retrieves Organization Details
    final OrganisationNameAndAddressDetails organisationNameAndAddressDetails = getOrganisationDetails();
    final Address addressObj = AddressFactory.newInstance();
    final OtherAddressData orgAddressData = new OtherAddressData();

    orgAddressData.addressData = organisationNameAndAddressDetails.addressData;
    addressObj.getAddressStrings(orgAddressData);

    // retrieves Provider/Provider Group Address Details
    final OtherAddressData providerOrgAddressData = getProviderOrganizationAddress(
      key);

    contractNotificationDetails.contractReferenceNumber = flatRateContract.getCPMContract().getReferenceNumber();
    contractNotificationDetails.providerName = flatRateContract.getProviderOrganization().getName();
    contractNotificationDetails.providerAddress = providerOrgAddressData.addressData;
    contractNotificationDetails.providerGroupName = flatRateContract.getProviderOrganization().getName();
    contractNotificationDetails.providerGroupAddress = providerOrgAddressData.addressData;
    contractNotificationDetails.organizationName = organisationNameAndAddressDetails.name;
    contractNotificationDetails.organizationAddress = orgAddressData.addressData;
    contractNotificationDetails.startDate = Locale.getFormattedDate(
      flatRateContract.getDateRange().start(), Locale.Date_mdy_ext);
    contractNotificationDetails.endDate = Locale.getFormattedDate(
      flatRateContract.getDateRange().end(), Locale.Date_mdy_ext);
    contractNotificationDetails.regularPaymentAmount = flatRateContract.getRegularPaymentAmt();
    contractNotificationDetails.totalContractAmount = flatRateContract.getTotalContractAmt();

    contractNotificationDetails.frequency = curam.util.type.CodeTable.getOneItem(
      ContractFrequencyEntry.TABLENAME,
      flatRateContract.getFrequency().toString());

    contractNotificationDetails.terminationReason = curam.util.type.CodeTable.getOneItem(
      ContractTerminationReasonEntry.TABLENAME,
      flatRateContract.getTerminationReason().toString());

    if (flatRateContract.getTerminationDateTime() == null) {
      contractNotificationDetails.statusHistoryDate = Date.kZeroDate.toString();
    } else {
      contractNotificationDetails.statusHistoryDate = Locale.getFormattedDate(
        new Date(flatRateContract.getTerminationDateTime()),
        Locale.Date_mdy_ext);
    }

    // List structs
    ProviderNotificationList providerNotificationList;
    ServiceOfferingNotificationList serviceOfferingNotificationList;

    // ********************************
    // Get list of Providers for Contract
    for (final ContractVersionProviderGroupAssociate
      contractVersionProviderGroupAssociate :
      contractVersionProviderGroupAssociateDAO.searchBy(flatRateContract)) {

      providerNotificationList = new ProviderNotificationList();

      providerNotificationList.providerName = contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getName();

      // Adding Provider list to return struct
      contractNotificationDetails.providerNotificationListAgg.addRef(
        providerNotificationList);
    }

    // ********************************
    // List of Provider Offerings
    final Set<ServiceOffering> serviceOfferingSet = new HashSet<ServiceOffering>();

    for (final curam.contracts.impl.ContractVersionProviderOffering contractPOLink :
      contractProviderOfferingLinkDAO.searchBy(flatRateContract)) {

      // If the ProviderOffering is approved, and the set of
      // ServiceOfferings
      // does not already contain this ProviderOffering's ServiceOffering

      if ((contractPOLink.getProviderOffering().getLifecycleState().equals(
        ProviderOfferingStatusEntry.APPROVED))
          && (serviceOfferingSet.add(
            contractPOLink.getProviderOffering().getServiceOffering()))) {

        serviceOfferingNotificationList = new ServiceOfferingNotificationList();

        serviceOfferingNotificationList.serviceOfferingName = contractPOLink.getProviderOffering().getServiceOffering().getName();

        // Adding PO list to return struct
        contractNotificationDetails.serviceOfferingNotificationListAgg.addRef(
          serviceOfferingNotificationList);
      }
    }

    return contractNotificationDetails;
  }

  /**
   * Returns the address details of the provider/provider group by reading the
   * relevant concern tables.
   *
   * @param key Contains the contractVersionID of the contract
   *
   * @return address details for the provider/provider group.
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected OtherAddressData getProviderOrganizationAddress(
    ContractNotificationKey key) throws AppException,
      InformationalException {
    // END, CR00177241

    final curam.contracts.impl.ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    // Address
    final Address addressObj = AddressFactory.newInstance();
    final AddressKey addressKey = new AddressKey();

    addressKey.addressID = contractVersion.getProviderOrganization().getPrimaryAddressID();
    ;

    final AddressDtls addressDtls = addressObj.read(addressKey);

    final AddressDetails addressDetails = new AddressDetails();

    addressDetails.addressData = addressDtls.addressData;

    final OtherAddressData formattedAddressData = new OtherAddressData();

    formattedAddressData.addressData = addressDtls.addressData;

    addressObj.getAddressStrings(formattedAddressData);

    return formattedAddressData;
  }

  // BEGIN, CR00281474, MR
  /**
   * Retrieves utilization contract data.
   *
   * @param key Contains contractVersionID and notification event for this
   * contract
   *
   * @return Contract details for this contract.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  public ContractNotificationDetails getUtilizationContractDetails(
    final ContractNotificationKey key) throws AppException,
      InformationalException {
    // END, CR00281474
    // END, CR00177241

    final curam.contracts.impl.UtilizationContract utilizationContract = utilizationContractDAO.get(
      key.contractVersionID);

    final ContractNotificationDetails contractNotificationDetails = new ContractNotificationDetails();

    // retrieves Organization Details
    final OrganisationNameAndAddressDetails organisationNameAndAddressDetails = getOrganisationDetails();
    final Address addressObj = AddressFactory.newInstance();
    final OtherAddressData orgAddressData = new OtherAddressData();

    orgAddressData.addressData = organisationNameAndAddressDetails.addressData;
    addressObj.getAddressStrings(orgAddressData);

    // retrieves Provider/Provider Group Address Details
    final OtherAddressData providerOrgAddressData = getProviderOrganizationAddress(
      key);

    contractNotificationDetails.contractReferenceNumber = utilizationContract.getCPMContract().getReferenceNumber();
    contractNotificationDetails.providerName = utilizationContract.getProviderOrganization().getName();
    contractNotificationDetails.providerAddress = providerOrgAddressData.addressData;
    contractNotificationDetails.providerGroupName = utilizationContract.getProviderOrganization().getName();
    contractNotificationDetails.providerGroupAddress = providerOrgAddressData.addressData;
    contractNotificationDetails.organizationName = organisationNameAndAddressDetails.name;
    contractNotificationDetails.organizationAddress = orgAddressData.addressData;
    contractNotificationDetails.startDate = Locale.getFormattedDate(
      utilizationContract.getDateRange().start(), Locale.Date_mdy_ext);
    contractNotificationDetails.endDate = Locale.getFormattedDate(
      utilizationContract.getDateRange().end(), Locale.Date_mdy_ext);

    contractNotificationDetails.terminationReason = curam.util.type.CodeTable.getOneItem(
      ContractTerminationReasonEntry.TABLENAME,
      utilizationContract.getTerminationReason().toString());

    // Termination DateTime
    if (utilizationContract.getTerminationDateTime() == null) {
      contractNotificationDetails.statusHistoryDate = Date.kZeroDate.toString();
    } else {
      contractNotificationDetails.statusHistoryDate = Locale.getFormattedDate(
        new Date(utilizationContract.getTerminationDateTime()),
        Locale.Date_mdy_ext);
    }

    // List structs
    ProviderNotificationList providerNotificationList;
    ServiceOfferingNotificationList serviceOfferingNotificationList;
    UtilizationServiceRatesNotificationList utilizationServiceRatesNotificationList;

    // ********************************
    // Get list of Providers for Contract
    for (final ContractVersionProviderGroupAssociate
      contractVersionProviderGroupAssociate :
      contractVersionProviderGroupAssociateDAO.searchBy(utilizationContract)) {

      providerNotificationList = new ProviderNotificationList();

      providerNotificationList.providerName = contractVersionProviderGroupAssociate.getProviderGroupAssociate().getProvider().getName();

      // Adding Provider list to return struct
      contractNotificationDetails.providerNotificationListAgg.addRef(
        providerNotificationList);
    }

    // ********************************
    // List of Provider Offerings
    final Set<ServiceOffering> serviceOfferingSet = new HashSet<ServiceOffering>();

    for (final curam.contracts.impl.ContractVersionProviderOffering
      contractPOLink : contractProviderOfferingLinkDAO.searchBy(
      utilizationContract)) {

      // If the ProviderOffering is approved, and the set of
      // ServiceOfferings
      // does not already contain this ProviderOffering's ServiceOffering

      if ((contractPOLink.getProviderOffering().getLifecycleState().equals(
        ProviderOfferingStatusEntry.APPROVED))
          && (serviceOfferingSet.add(
            contractPOLink.getProviderOffering().getServiceOffering()))) {

        serviceOfferingNotificationList = new ServiceOfferingNotificationList();

        serviceOfferingNotificationList.serviceOfferingName = contractPOLink.getProviderOffering().getServiceOffering().getName();

        // Adding PO list to return struct
        contractNotificationDetails.serviceOfferingNotificationListAgg.addRef(
          serviceOfferingNotificationList);
      }
    }

    // *******************************************
    // Populate Services Rates/Limits structs

    // PROVIDER
    if (utilizationContract.getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDER)) {

      for (final curam.contracts.impl.ContractVersionProviderOffering
        contractPOLink : contractProviderOfferingLinkDAO.searchBy(
        utilizationContract)) {

        utilizationServiceRatesNotificationList = new UtilizationServiceRatesNotificationList();

        // Check PO is approved
        if (contractPOLink.getProviderOffering().getLifecycleState().equals(
          ProviderOfferingStatusEntry.APPROVED)) {

          // Provider Offering Object
          final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
            contractPOLink.getProviderOffering().getID());

          // RATES
          // finding all CONTRACTED provider offering rates for this
          // provider
          // offering
          for (final ProviderOfferingRate providerOfferingRate :
            providerOfferingRateDAO.searchBy(providerOffering,
            utilizationContract)) {

            // *********************
            // Set Service Offering Name
            utilizationServiceRatesNotificationList.serviceOfferingName = contractPOLink.getProviderOffering().getServiceOffering().getName();

            // *********************
            // Set PO Rates
            final UtilizationServiceRatesNotificationList poRate = getUtilizationProviderOfferingRate(
              providerOfferingRate);

            utilizationServiceRatesNotificationList.rate = poRate.rate;
            utilizationServiceRatesNotificationList.rateDateRange = poRate.rateDateRange;

            // *********************
            // add to return struct
            contractNotificationDetails.utilizationServiceRatesNotificationListAgg.addRef(
              utilizationServiceRatesNotificationList);
            utilizationServiceRatesNotificationList = new UtilizationServiceRatesNotificationList();

          }

          UtilizationServicePLNotificationList utilizationServicePLNotificationList = new UtilizationServicePLNotificationList();

          // PLACE LIMITS
          // finding all CONTRACTED place limits for this provider
          // offering
          for (final curam.providerservice.impl.ProviderOfferingPlaceLimit providerOfferingPlaceLimit : providerOfferingPlaceLimitDAO.searchBy(
            providerOffering, utilizationContract)) {

            // *********************
            // Set Service Offering Name
            utilizationServicePLNotificationList.serviceOfferingName = contractPOLink.getProviderOffering().getServiceOffering().getName();

            // *********************
            // Set PO Place Limits
            utilizationServicePLNotificationList.placeLimit = providerOfferingPlaceLimit.getPlaceLimit();

            // Begin CR00096779, ABS
            // BEGIN, CR CR00097088, DN
            utilizationServicePLNotificationList.poDateRange = Locale.getFormattedDate(
              providerOfferingPlaceLimit.getDateRange().start(),
              Locale.Date_mdy_ext)
                + CPMConstants.kToField
                + Locale.getFormattedDate(
                  providerOfferingPlaceLimit.getDateRange().end(),
                  Locale.Date_mdy_ext);
            // END, CR CR00097088
            // End CR00096779

            // *********************
            // add to return struct
            contractNotificationDetails.utilizationServicePLNotificationListAgg.addRef(
              utilizationServicePLNotificationList);
            utilizationServicePLNotificationList = new UtilizationServicePLNotificationList();
          }
        }
      }
    } // PROVIDER GROUP
    else if (utilizationContract.getProviderOrganization().getConcernRoleType().equals(
      CONCERNROLETYPEEntry.PROVIDERGROUP)) {

      final Set<ServiceOffering> contractServiceOfferingSet = new HashSet<ServiceOffering>();

      utilizationServiceRatesNotificationList = new UtilizationServiceRatesNotificationList();

      // find all service offerings on the contract
      for (final curam.contracts.impl.ContractVersionProviderOffering
        contractPOLink : contractProviderOfferingLinkDAO.searchBy(
        utilizationContract)) {

        // Check PO is approved
        if (contractPOLink.getProviderOffering().getLifecycleState().equals(
          ProviderOfferingStatusEntry.APPROVED)) {

          // Provider Offering Object
          final curam.providerservice.impl.ProviderOffering providerOffering = providerOfferingDAO.get(
            contractPOLink.getProviderOffering().getID());

          contractServiceOfferingSet.add(providerOffering.getServiceOffering());
        }
      }

      // only one provider needed
      boolean foundFlag = false;

      // find one provider in a contract
      for (final curam.provider.impl.Provider provider : utilizationContract.getProviders()) {

        if (!foundFlag) {

          foundFlag = true;

          // find the Provider Offerings for one provider on the
          // contract
          for (final curam.providerservice.impl.ProviderOffering
            providerOffering : provider.getProviderOfferings()) {

            // determine if the provider offering matches an entry
            // on the Service Offering set
            if (contractServiceOfferingSet.contains(
              providerOffering.getServiceOffering())) {

              // find all the CONTRACTED rates for this provider
              // offering
              for (final ProviderOfferingRate
                providerOfferingRate : providerOfferingRateDAO.searchBy(
                providerOffering, utilizationContract)) {

                // *********************
                // Set Service Offering Name
                utilizationServiceRatesNotificationList.serviceOfferingName = providerOffering.getServiceOffering().getName();

                // *********************
                // Set PO Rates
                final UtilizationServiceRatesNotificationList poRate = getUtilizationProviderOfferingRate(
                  providerOfferingRate);

                utilizationServiceRatesNotificationList.rate = poRate.rate;
                utilizationServiceRatesNotificationList.rateDateRange = poRate.rateDateRange;

                // *********************
                // add to return struct
                contractNotificationDetails.utilizationServiceRatesNotificationListAgg.addRef(
                  utilizationServiceRatesNotificationList);
                utilizationServiceRatesNotificationList = new UtilizationServiceRatesNotificationList();
              }
            }
          }
        }
      }
    }

    return contractNotificationDetails;
  }

  /**
   * Generates the document.
   *
   * @param key Contains Contract Version ID and notification event for this
   * contract.
   *
   * @return XML format document containing all the contract details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected DataSetData generateDocument(ContractNotificationKey key)
    throws AppException, InformationalException {
    // END, CR00177241

    final DataSetData dataSetData = new DataSetData();

    final curam.contracts.impl.ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);

    ContractNotificationDetails contractNotificationDetails = new ContractNotificationDetails();

    // If its a Flat-Rate Contract
    if (contractVersion.getContractType().equals(CONTRACTTYPEEntry.FLATRATE)) {
      contractNotificationDetails = getFlatRateContractDetails(key);
    } else if (contractVersion.getContractType().equals(
      CONTRACTTYPEEntry.UTILIZATION)) {
      contractNotificationDetails = getUtilizationContractDetails(key);

    }

    // Add all the receipt data to XML document object
    final XMLDocument documentObj = new XMLDocument(
      XMLEncodingConstants.kEncodeUTF8);

    documentObj.add(contractNotificationDetails);

    // Retrieve XML stream for data set and return
    dataSetData.dataSetData = documentObj.toString();

    return dataSetData;
  }

  /**
   * Generates an XML document from the specified XSL template and prints that
   * document.
   *
   * @param dataSetData Contains the XML data to be entered into the document
   * @param key Contains details of the document to be used
   *
   * @throws AppException
   * {@link curam.message.BPOPROFORMADOCUMENTGENERATION #ERR_INVALID_FORMAT_NOT_PRINTABLE}
   * - if the form is not a valid XML document.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  // BEGIN, CR00177241, PM
  protected void createDocumentFromDetails(DataSetData dataSetData,
    ContractDocumentKey key,
    LanguageLocaleMapDetails languageLocaleMapDetails)
    throws AppException, InformationalException {
    // END, CR00177241

    // XSLTemplate objects
    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    // Set code key
    xslTemplateIDCodeKey.templateIDCode = key.contractDocumentType;

    // Read template details
    final XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory.newInstance();

    // BEGIN, CR00178508, SK
    xslTemplateIDCodeKey.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;

    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    try {
      xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);
    } catch (final RecordNotFoundException recordNotFoundException) {
      final AppException appException = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);

      final String codeItemDescription = CodeTable.getOneItem(
        TEMPLATEIDCODE.TABLENAME, xslTemplateIDCodeKey.templateIDCode,
        TransactionInfo.getProgramLocale());

      appException.arg(codeItemDescription);

      throw appException;
    }
    // END, CR00178508
    // Generate the specified document.
    final SystemUser systemUserObj = SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // BEGIN, CR00235681, PM
    // Create XMLPrintStream object
    final XMLPrintStream printStreamObj = new XMLPrintStream();

    // END, CR00235681

    // open print stream
    try {
      // BEGIN, CR00235681, PM
      printStreamObj.open(xslTemplateInstanceKey);
      // END, CR00235681
    } catch (final AppException ex) {

      // an error occurred - was the document not in valid XML format?
      if (ex.getCatEntry().equals(CURAMXML.ERR_PRINT_STREAM_BAD_RESPONSE)) {

        // the pro-forma form is not a valid XML document -
        // convert this to a more meaningful message for the user
        throw new AppException(
          BPOPROFORMADOCUMENTGENERATION.ERR_INVALID_FORMAT_NOT_PRINTABLE, ex);

      } else {
        // we can't do anything with it -
        // just pass it on up to the calling method
        throw ex;
      }
    }

    final XMLDocument documentObj = new XMLDocument(printStreamObj.getStream(),
      XMLEncodingConstants.kEncodeUTF8);

    final Date currentDate = Date.getCurrentDate();

    // Set data to print the document
    systemUserDtls = systemUserObj.getUserDetails();
    final String userName = systemUserDtls.userName;
    final String generatedDate = currentDate.toString();
    final String versionNo = String.valueOf(
      xslTemplateInstanceKey.templateVersion);
    final String comments = "";

    // Open document
    documentObj.open(userName, generatedDate, versionNo, comments);

    // Add data to document
    documentObj.addFromXML(dataSetData.dataSetData);

    // Close document and print stream objects
    documentObj.close();
    printStreamObj.close();

  }
  
  // BEGIN, CR00292749, MR
  /**
   * Creates an XML document and inserts contract communication. It also
   * stores the document content to the content management system.
   *
   * @param contractNotificationKey
   * Contains contract version ID and notification event for this
   * contract.
   * @param dataSetData
   * Contains the XML data to be entered into the document.
   * @param contractDocumentKey
   * Contains contract document type to be used.
   * @param languageLocaleMapDetails
   * Contains information of locale for this contract
   * communication.
   *
   * @throws AppException
   * {@link curam.message.GENERALCONCERN#ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE}
   * - if the pro forma template is not found.
   * @throws InformationalException
   * Generic Exception Signature.
   */

  protected void createDocumentAndInsertContractCommunication(
    final ContractNotificationKey contractNotificationKey,
    final DataSetData dataSetData,
    final ContractDocumentKey contractDocumentKey,
    final LanguageLocaleMapDetails languageLocaleMapDetails)
    throws AppException, InformationalException {

    // BEGIN, CR00408986, KRK
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS_DEFAULT))) {
      
      createDocumentFromDetails(dataSetData, contractDocumentKey,
        languageLocaleMapDetails);
    }    
    // END, CR00408986
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls = insertContractCommunication(
      contractNotificationKey, contractDocumentKey, languageLocaleMapDetails);

    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.templateIDCode = contractDocumentKey.contractDocumentType;
    xslTemplateIDCodeKey.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;

    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    try {
      xslTemplateInstanceKey = XSLTemplateUtilityFactory.newInstance().getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);
    } catch (final RecordNotFoundException e) {
      final AppException appException = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);
      final String codeItemDescription = CodeTable.getOneItem(
        TEMPLATEIDCODE.TABLENAME, xslTemplateIDCodeKey.templateIDCode,
        TransactionInfo.getProgramLocale());

      appException.arg(codeItemDescription);
      throw appException;
    }

    final LicenseNotification licenseNotification = new LicenseNotification();

    licenseNotification.storeDocumentContent(concernRoleCommunicationDtls,
      xslTemplateInstanceKey, dataSetData);
  }

  // END, CR00292749

  /**
   * Returns the organization name and address details.
   * <p>
   * By default theres one organization and the function fetches the name of
   * it from database.
   *
   * @return the organization's name and address details.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected OrganisationNameAndAddressDetails getOrganisationDetails()
    throws AppException, InformationalException {
    // END, CR00177241
    final Organisation organisation = OrganisationFactory.newInstance();
    final OrganisationID organisationID = organisation.readOrganisationID();
    final OrganisationKey organisationKey = new OrganisationKey();

    organisationKey.organisationID = organisationID.organisationID;
    final OrganisationNameAndAddressDetails details = organisation.readNameAndAddress(
      organisationKey);

    return details;
  }

  // BEGIN, CR00178508, SK
  
  // BEGIN, CR00292749, MR
  /**
   * Inserts the communication details for a new communication.
   *
   * @param key
   * Contains contractVersionID and event for this contract
   * communication.
   * @param docKey
   * Contains generated document details.
   * @param languageLocaleMapDetails
   * Contains information of locale for this contract
   * communication.
   *
   * @throws AppException
   * {@link curam.message.GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE}
   * - if the proforma template is not found.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @deprecated Since Curam 6.0 SP2, replaced by
   * {@link #insertContractCommunication(ContractNotificationKey, ContractDocumentKey, LanguageLocaleMapDetails)}
   * . This method is deprecated because it is not returning
   * concern role communication details which is required while
   * storing the document content to the content management
   * system. See release note: CR00292749.
   */
  @Deprecated
  
  // END, CR00292749
  // BEGIN, CR00177241, PM
  protected void insertCommunication(ContractNotificationKey key,
    ContractDocumentKey docKey,
    LanguageLocaleMapDetails languageLocaleMapDetails)
    throws AppException, InformationalException {
    // END, CR00177241

    // Retrieve contract object
    final ContractVersion contractVersion = contractVersionDAO.get(
      key.contractVersionID);
    // END, CR00178508
    // based on domain CURAM_DATE
    final Date currentDate = Date.getCurrentDate();

    final UniqueID uniqueIDObj = UniqueIDFactory.newInstance();

    // ConcernRoleComm manipulation variables
    final ConcernRoleCommunication concernRoleCommunicationObj = ConcernRoleCommunicationFactory.newInstance();
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls = new ConcernRoleCommunicationDtls();

    long concernRoleCommunicationID = 0;

    // XSLTemplate manipulation variables
    final XSLTemplate xslTemplateObj = XSLTemplateFactory.newInstance();
    final XSLTemplateKey xslTemplateKey = new XSLTemplateKey();
    XSLTemplateDtls xslTemplateDtls;

    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    final XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory.newInstance();

    // Generate unique id for ConcernRoleCommunication
    concernRoleCommunicationID = uniqueIDObj.getNextID();

    concernRoleCommunicationDtls.attachmentInd = false;

    concernRoleCommunicationDtls.typeCode = COMMUNICATIONTYPE.LETTER;

    concernRoleCommunicationDtls.communicationID = concernRoleCommunicationID;
    concernRoleCommunicationDtls.statusCode = RECORDSTATUS.NORMAL;

    concernRoleCommunicationDtls.proFormaInd = true;

    // BEGIN, CR00178508, SK
    xslTemplateIDCodeKey.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;

    xslTemplateIDCodeKey.templateIDCode = docKey.contractDocumentType;

    try {
      xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);
    } catch (final RecordNotFoundException recordNotFoundException) {
      final AppException appException = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);
      final String codeItemDescription = CodeTable.getOneItem(
        TEMPLATEIDCODE.TABLENAME, xslTemplateIDCodeKey.templateIDCode,
        TransactionInfo.getProgramLocale());

      appException.arg(codeItemDescription);

      throw appException;
    }
    // Copy the proforma document type to the subject
    xslTemplateKey.templateID = xslTemplateInstanceKey.templateID;

    xslTemplateKey.localeIdentifier = xslTemplateInstanceKey.locale;
    // END, CR00178508
    try {
      xslTemplateDtls = xslTemplateObj.read(xslTemplateKey);
    } catch (final RecordNotFoundException e) {
      xslTemplateDtls = null;
    }

    if (xslTemplateDtls != null) {
      concernRoleCommunicationDtls.subjectText = xslTemplateDtls.templateName;
    } else {
      final AppException e = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE);

      e.arg(xslTemplateInstanceKey.templateID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    final SystemUser user = SystemUserFactory.newInstance();

    concernRoleCommunicationDtls.concernRoleID = contractVersion.getProviderOrganization().getID();
    concernRoleCommunicationDtls.proFormaVersionNo = xslTemplateInstanceKey.templateVersion;
    concernRoleCommunicationDtls.proFormaInd = true;
    concernRoleCommunicationDtls.userName = user.getUserDetails().userName;
    concernRoleCommunicationDtls.correspondentConcernRoleID = contractVersion.getProviderOrganization().getID();

    final ConcernRole concernRole = concernRoleDAO.get(
      concernRoleCommunicationDtls.concernRoleID);

    concernRoleCommunicationDtls.addressID = concernRole.getPrimaryAddressID();
    concernRoleCommunicationDtls.correspondentName = concernRole.getName();
    concernRoleCommunicationDtls.communicationDate = currentDate;
    concernRoleCommunicationDtls.communicationStatus = COMMUNICATIONSTATUS.SENT;
    concernRoleCommunicationDtls.communicationFormat = COMMUNICATIONFORMAT.PROFORMA;
    concernRoleCommunicationDtls.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    concernRoleCommunicationDtls.correspondentTypeCode = CORRESPONDENT.CLIENT;
    concernRoleCommunicationDtls.documentTemplateID = xslTemplateIDCodeKey.templateIDCode;
    // BEGIN, CR00178508, SK
    concernRoleCommunicationDtls.localeIdentifier = xslTemplateIDCodeKey.localeIdentifier;
    // END, CR00178508
    // Insert new communication entry
    concernRoleCommunicationObj.insert(concernRoleCommunicationDtls);
    
    // BEGIN, CR00281474, MR
    createCommunicationCVLink(concernRoleCommunicationDtls.communicationID,
      key.contractVersionID);
    // END, CR00281474
  }

  // BEGIN, CR00292749, MR
  /**
   * Inserts the contract communication details for a new communication.
   *
   * @param contractNotificationKey
   * Contains contract version ID and event for this contract
   * communication.
   * @param contractDocumentKey
   * Contains contract document type to be used.
   * @param languageLocaleMapDetails
   * Contains information of locale for this contract
   * communication.
   *
   * @throws AppException
   * {@link curam.message.GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE}
   * - If the pro forma template is not found.
   * @throws AppException
   * {@link curam.message.GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE}
   * - If the pro forma template ID is not found.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected ConcernRoleCommunicationDtls insertContractCommunication(
    final ContractNotificationKey contractNotificationKey,
    final ContractDocumentKey contractDocumentKey,
    final LanguageLocaleMapDetails languageLocaleMapDetails)
    throws AppException, InformationalException {
    final ConcernRoleCommunicationDtls concernRoleCommunicationDtls = new ConcernRoleCommunicationDtls();

    concernRoleCommunicationDtls.attachmentInd = false;
    concernRoleCommunicationDtls.typeCode = COMMUNICATIONTYPE.LETTER;
    concernRoleCommunicationDtls.communicationID = UniqueIDFactory.newInstance().getNextID();
    concernRoleCommunicationDtls.statusCode = RECORDSTATUS.NORMAL;
    concernRoleCommunicationDtls.proFormaInd = true;

    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    xslTemplateIDCodeKey.localeIdentifier = languageLocaleMapDetails.dtls.localeIdentifier;
    xslTemplateIDCodeKey.templateIDCode = contractDocumentKey.contractDocumentType;

    XSLTemplateInstanceKey xslTemplateInstanceKey = new XSLTemplateInstanceKey();

    try {
      xslTemplateInstanceKey = XSLTemplateUtilityFactory.newInstance().getLatestTemplateKeyByIDCode(
        xslTemplateIDCodeKey);
    } catch (final RecordNotFoundException e) {
      final AppException appException = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_WITH_LOCALE_RNFE);
      final String codeItemDescription = CodeTable.getOneItem(
        TEMPLATEIDCODE.TABLENAME, xslTemplateIDCodeKey.templateIDCode,
        TransactionInfo.getProgramLocale());

      appException.arg(codeItemDescription);
      throw appException;
    }

    final XSLTemplateKey xslTemplateKey = new XSLTemplateKey();

    xslTemplateKey.templateID = xslTemplateInstanceKey.templateID;
    xslTemplateKey.localeIdentifier = xslTemplateInstanceKey.locale;

    XSLTemplateDtls xslTemplateDtls = new XSLTemplateDtls();

    try {
      xslTemplateDtls = XSLTemplateFactory.newInstance().read(xslTemplateKey);
    } catch (final RecordNotFoundException e) {
      xslTemplateDtls = null;
    }

    if (null != xslTemplateDtls) {
      concernRoleCommunicationDtls.subjectText = xslTemplateDtls.templateName;
    } else {
      final AppException e = new AppException(
        GENERALCONCERN.ERR_PROFORMATEMPLATE_RNFE);

      e.arg(xslTemplateInstanceKey.templateID);
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().throwWithLookup(
        e, curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    final ContractVersion contractVersion = contractVersionDAO.get(
      contractNotificationKey.contractVersionID);

    concernRoleCommunicationDtls.concernRoleID = contractVersion.getProviderOrganization().getID();
    concernRoleCommunicationDtls.proFormaVersionNo = xslTemplateInstanceKey.templateVersion;
    concernRoleCommunicationDtls.proFormaInd = true;
    concernRoleCommunicationDtls.userName = SystemUserFactory.newInstance().getUserDetails().userName;
    concernRoleCommunicationDtls.correspondentConcernRoleID = contractVersion.getProviderOrganization().getID();

    final ConcernRole concernRole = concernRoleDAO.get(
      concernRoleCommunicationDtls.concernRoleID);

    concernRoleCommunicationDtls.addressID = concernRole.getPrimaryAddressID();
    concernRoleCommunicationDtls.correspondentName = concernRole.getName();
    concernRoleCommunicationDtls.communicationDate = Date.getCurrentDate();
    concernRoleCommunicationDtls.communicationStatus = COMMUNICATIONSTATUS.SENT;
    concernRoleCommunicationDtls.communicationFormat = COMMUNICATIONFORMAT.PROFORMA;
    concernRoleCommunicationDtls.methodTypeCode = COMMUNICATIONMETHOD.HARDCOPY;
    concernRoleCommunicationDtls.correspondentTypeCode = CORRESPONDENT.CLIENT;
    concernRoleCommunicationDtls.documentTemplateID = xslTemplateIDCodeKey.templateIDCode;
    concernRoleCommunicationDtls.localeIdentifier = xslTemplateIDCodeKey.localeIdentifier;

    ConcernRoleCommunicationFactory.newInstance().insert(
      concernRoleCommunicationDtls);

    createCommunicationCVLink(concernRoleCommunicationDtls.communicationID,
      contractNotificationKey.contractVersionID);

    return concernRoleCommunicationDtls;
  }

  // END, CR00292749
  
  /**
   * Prints the latest generated (i.e issued) contract.
   *
   * @param key Contains contractVersionID and event of the contract
   *
   * @throws AppException
   * @throws InformationalException
   */
  public void printContract(ContractNotificationKey key) throws AppException,
      InformationalException {

    final ContractDocumentKey contractDocumentKey = new ContractDocumentKey();

    DataSetData dataSetData = new DataSetData();

    // Retrieve XML stream for data set and return
    dataSetData = generateDocument(key);

    // Provider FR Contract(Reg)
    if (key.event.equals(
      ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTREG)) {

      // Provider Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);
      
      // END, CR00292749
      
      // Provider Flat-Rate Contract(Regular)
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERFLATRATECONTRACTREG;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);
      
      // END, CR00292749
    } // PG FR Contract(Reg)
    else if (key.event.equals(
      ContractNotificationEvent.NEWPGFLATRATECONTRACTREG)) {

      // PG Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);
      
      // END, CR00292749

      // Provider Group Flat-Rate Contract(Regular)
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGFLATRATECONTRACTREG;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);
      
      // END, CR00292749
    } // Provider FR Contract(Total)
    else if (key.event.equals(
      ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTTOTAL)) {

      // Provider Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);
      
      // END, CR00292749

      // Provider Group Flat-Rate Contract(Regular)
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERFLATRATECONTRACTTOTAL;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);
      
      // END, CR00292749
    } // PG FR Contract(Total)
    else if (key.event.equals(
      ContractNotificationEvent.NEWPGFLATRATECONTRACTTOTAL)) {

      // PG Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);

      // END, CR00292749

      // Provider Group Flat-Rate Contract(Regular)
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGFLATRATECONTRACTTOTAL;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);
      
      // END, CR00292749
    } // Provider Utilization Contract
    else if (key.event.equals(
      ContractNotificationEvent.NEWPROVIDERUTILIZATIONCONTRACT)) {
      // BEGIN, CR00156707, ASN
      // Provider Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);
      
      // END, CR00292749
      // END, CR00156707
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGFLATRATECONTRACTREG;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);
      
      // END, CR00292749
    } // PG Utilization Contract
    else if (key.event.equals(
      ContractNotificationEvent.NEWPGUTILIZATIONCONTRACT)) {
      // BEGIN, CR00156707, ASN
      // Provider Cover Letter
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERCONTRACTCOVERLETTER;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);
      
      // END, CR00292749
      // END, CR00156707
      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGFLATRATECONTRACTREG;
      
      // BEGIN, CR00292749, MR
      createPrintAndPreviewContract(key, dataSetData, contractDocumentKey);
      
      // END, CR00292749
    }
  }

  /**
   * Previews the latest generated (i.e issued) contract.
   *
   * @param key  Contains contractVersionID and event of the contract
   *
   * @return The contract document details.
   *
   * @throws AppException
   * @throws InformationalException
   */
  public ContractReturnDocDetails previewContract(ContractNotificationKey key)
    throws AppException, InformationalException {

    final ContractDocumentKey contractDocumentKey = new ContractDocumentKey();

    DataSetData dataSetData = new DataSetData();

    // Retrieve XML stream for data set and return
    dataSetData = generateDocument(key);

    ContractReturnDocDetails contractReturnDocDetails = new ContractReturnDocDetails();

    // Provider FR Contract(Regular)
    if (key.event.equals(
      ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTREG)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERFLATRATECONTRACTREG;
      contractReturnDocDetails = createAndPreviewContract(dataSetData,
        contractDocumentKey);
    } // PG FR Contract(Regular)
    else if (key.event.equals(
      ContractNotificationEvent.NEWPGFLATRATECONTRACTREG)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGFLATRATECONTRACTREG;
      contractReturnDocDetails = createAndPreviewContract(dataSetData,
        contractDocumentKey);
    } // Provider FR Contract(Total)
    else if (key.event.equals(
      ContractNotificationEvent.NEWPROVIDERFLATRATECONTRACTTOTAL)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERFLATRATECONTRACTTOTAL;
      contractReturnDocDetails = createAndPreviewContract(dataSetData,
        contractDocumentKey);
    } // PG FR Contract(Total)
    else if (key.event.equals(
      ContractNotificationEvent.NEWPGFLATRATECONTRACTTOTAL)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGFLATRATECONTRACTTOTAL;
      contractReturnDocDetails = createAndPreviewContract(dataSetData,
        contractDocumentKey);
    } // Provider Utilization Contract
    else if (key.event.equals(
      ContractNotificationEvent.NEWPROVIDERUTILIZATIONCONTRACT)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PROVIDERUTILIZATIONCONTRACT;
      contractReturnDocDetails = createAndPreviewContract(dataSetData,
        contractDocumentKey);
    } // PG Utilization Contract
    else if (key.event.equals(
      ContractNotificationEvent.NEWPGUTILIZATIONCONTRACT)) {

      contractDocumentKey.contractDocumentType = TEMPLATEIDCODE.PGUTILIZATIONCONTRACT;
      contractReturnDocDetails = createAndPreviewContract(dataSetData,
        contractDocumentKey);
    }
    return contractReturnDocDetails;
  }

  /**
   * Generates an XML document from the specified XSL template and previews
   * that document.
   *
   * @param dataSetData
   * the XML data to be entered into the document
   * @param key
   * details of the document to be used
   *
   * @return the file name and file data(blob).
   */
  // BEGIN, CR00177241, PM
  protected ContractReturnDocDetails createAndPreviewContract(
    DataSetData dataSetData, ContractDocumentKey key)
    throws AppException, InformationalException {
    // END, CR00177241

    final ContractReturnDocDetails contractReturnDocDetails = new ContractReturnDocDetails();

    // Create Preview Stream
    final ByteArrayOutputStream previewStream = new java.io.ByteArrayOutputStream();

    // BEGIN, CR00235681, PM
    // Create XMLPrintStream object
    final XMLPrintStream printStreamObj = new XMLPrintStream();
    // END, CR00235681

    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    // Set code key
    xslTemplateIDCodeKey.templateIDCode = key.contractDocumentType;

    // Read template details
    final XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory.newInstance();

    xslTemplateIDCodeKey.localeIdentifier = TransactionInfo.getProgramLocale();

    final XSLTemplateInstanceKey xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
      xslTemplateIDCodeKey);

    // *************************************
    // get the default printer information

    // users object and access structures
    final AdminUserAssistant adminUserAssistantObj = AdminUserAssistantFactory.newInstance();
    final UserKeyStruct userKeyStruct = new UserKeyStruct();
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    userKeyStruct.userName = usersKey.userName;

    final GetResourcesDetails getResourcesDetails = adminUserAssistantObj.getUserDefaultPrinter(
      userKeyStruct);

    // BEGIN, CR00408986, KRK
    if (!Configuration.getBooleanProperty(
      EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS, 
      Configuration.getBooleanProperty(
        EnvVars.ENV_XMLSERVER_DISABLE_METHOD_CALLS_DEFAULT))) {
      
      if (getResourcesDetails.resourceID != 0) {
        printStreamObj.setPrinterName(getResourcesDetails.name);
      }

      printStreamObj.setPreviewStream(previewStream);
      printStreamObj.setJobType(XMLPrintStreamConstants.kJobTypePDF);

      // BEGIN, CR00235681, PM
      // Open print stream
      printStreamObj.open(xslTemplateInstanceKey);
      // END, CR00235681

      final XMLDocument documentObj = new XMLDocument(
        printStreamObj.getStream(), XMLEncodingConstants.kEncodeISOLATIN1);

      final SystemUser systemUserObj = SystemUserFactory.newInstance();
      SystemUserDtls systemUserDtls;

      // Set data to print the document
      systemUserDtls = systemUserObj.getUserDetails();
      final String userName = systemUserDtls.userName;
      final String generatedDate = curam.util.type.DateTime.getCurrentDateTime().toString();
      final String versionNo = String.valueOf(
        xslTemplateInstanceKey.templateVersion);
      final String comments = "";

      // open document
      documentObj.open(userName, generatedDate, versionNo, comments);

      // Add data to document
      documentObj.addFromXML(dataSetData.dataSetData);

      // close document and print stream objects
      documentObj.close();
      printStreamObj.close();      
    }
    // END, CR00408986

    // previewBuffer
    contractReturnDocDetails.fileName = CPMConstants.kContractNotificationName;
    contractReturnDocDetails.fileData = new Blob(previewStream.toByteArray());

    return contractReturnDocDetails;
  }

  /**
   * Generates an XML document from the specified XSL template and previews
   * that document.
   *
   * @param dataSetData Contains contract XML document data to be printed
   * @param key Contains contract document details
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected void createAndPrintContract(DataSetData dataSetData,
    ContractDocumentKey key) throws AppException,
      InformationalException {
    // END, CR00177241

    // BEGIN, CR00235681, PM
    // Create XMLPrintStream object
    final XMLPrintStream printStreamObj = new XMLPrintStream();
    // END, CR00235681

    // *******************************************
    // Set up XSL template instance
    final XSLTemplateUtility xslTemplateUtilityObj = XSLTemplateUtilityFactory.newInstance();

    final XSLTemplateIDCodeKey xslTemplateIDCodeKey = new XSLTemplateIDCodeKey();

    // Set code key
    xslTemplateIDCodeKey.templateIDCode = key.contractDocumentType;

    xslTemplateIDCodeKey.localeIdentifier = TransactionInfo.getProgramLocale();

    final XSLTemplateInstanceKey xslTemplateInstanceKey = xslTemplateUtilityObj.getLatestTemplateKeyByIDCode(
      xslTemplateIDCodeKey);

    // *************************************
    // get the default printer information
    final AdminUserAssistant adminUserAssistantObj = AdminUserAssistantFactory.newInstance();
    final UserKeyStruct userKeyStruct = new UserKeyStruct();
    final UsersKey usersKey = new UsersKey();

    usersKey.userName = curam.util.transaction.TransactionInfo.getProgramUser();

    userKeyStruct.userName = usersKey.userName;

    final GetResourcesDetails getResourcesDetails = adminUserAssistantObj.getUserDefaultPrinter(
      userKeyStruct);

    if (getResourcesDetails.resourceID != 0) {
      printStreamObj.setPrinterName(getResourcesDetails.name);
      printStreamObj.setUserName(usersKey.userName);
    }

    // BEGIN, CR00235681, PM
    // Open print stream
    printStreamObj.open(xslTemplateInstanceKey);
    // END, CR00235681

    final XMLDocument documentObj = new XMLDocument(printStreamObj.getStream(),
      XMLEncodingConstants.kEncodeISOLATIN1);

    final SystemUser systemUserObj = SystemUserFactory.newInstance();
    SystemUserDtls systemUserDtls;

    // Set data to print the document
    systemUserDtls = systemUserObj.getUserDetails();
    final String userName = systemUserDtls.userName;
    final String generatedDate = curam.util.type.DateTime.getCurrentDateTime().toString();
    final String versionNo = String.valueOf(
      xslTemplateInstanceKey.templateVersion);
    final String comments = "";

    // open document
    documentObj.open(userName, generatedDate, versionNo, comments);

    // Add data to document
    documentObj.addFromXML(dataSetData.dataSetData);

    // close document and print stream objects
    documentObj.close();

    printStreamObj.close();
  }

  // BEGIN, CR00292749, MR
  /**
   * Creates an XML document from the specified XSL template and prints and
   * previews that document.
   *
   * @param contractNotificationKey
   * Contains contract version ID and event of the contract.
   * @param dataSetData
   * Contains the XML data to be entered into the document.
   * @param contractDocumentKey
   * Contains contract document type to be used.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   * @throws AppException
   * Generic Exception Signature.
   */
  protected void createPrintAndPreviewContract(
    final ContractNotificationKey contractNotificationKey,
    final DataSetData dataSetData,
    final ContractDocumentKey contractDocumentKey) throws AppException,
      InformationalException {
    createAndPrintContract(dataSetData, contractDocumentKey);

    ContractReturnDocDetails contractReturnDocDetails = createAndPreviewContract(
      dataSetData, contractDocumentKey);

    final ContractVersion contractVersion = contractVersionDAO.get(
      contractNotificationKey.contractVersionID);

    final List<CommunicationCVLink> communicationCVLinkList = communicationCVLinkDAO.searchByContractVersion(
      contractVersion, contractDocumentKey.contractDocumentType);

    if (!communicationCVLinkList.isEmpty()) {
      long communicationID = communicationCVLinkList.get(0).getID();

      if (cmisAccessInterface.isCMISEnabledFor(
        CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {

        if (cmisAccessInterface.contentExists(communicationID,
          CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION)) {

          // Modify the file on the content management system.
          cmisAccessInterface.modify(communicationID,
            CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION,
            contractReturnDocDetails.fileData.copyBytes(), null);
        } else {

          // Save the contents to the content management system.
          cmisAccessInterface.create(communicationID,
            CMSLINKRELATEDTYPEEntry.PROFORMA_CONCERNROLECOMMUNICATION,
            contractReturnDocDetails.fileData.copyBytes(),
            contractReturnDocDetails.fileName,
            CMISNAMINGTYPEEntry.PROFORMA_GENERIC, null);
        }
      }

    }
  }

  // END, CR00292749
  
  /**
   * Set the rate for this provider offering.
   *
   * @param providerOfferingRate
   * Contains the instance of the provider offering rate
   * @return a list of utilization service rate details.
   *
   * @throws AppException
   * @throws InformationalException
   */
  // BEGIN, CR00177241, PM
  protected UtilizationServiceRatesNotificationList getUtilizationProviderOfferingRate(
    ProviderOfferingRate providerOfferingRate) throws AppException,
      InformationalException {
    // END, CR00177241

    final UtilizationServiceRatesNotificationList utilizationServiceRatesNotificationList = new UtilizationServiceRatesNotificationList();

    // *****************************
    // SET PO RATES
    // Rate Amount is Fixed
    if (providerOfferingRate.getFixedAmount().isPositive()) {

      utilizationServiceRatesNotificationList.rate = providerOfferingRate.getFixedAmount()
        + CPMConstants.kFixedString;
      // BEGIN, CR00097088, DN
      utilizationServiceRatesNotificationList.rateDateRange = Locale.getFormattedDate(
        providerOfferingRate.getDateRange().start(), Locale.Date_mdy_ext)
          + CuramConst.gkSpace
          + CPMConstants.kToField
          + CuramConst.gkSpace
          + Locale.getFormattedDate(providerOfferingRate.getDateRange().end(),
          Locale.Date_mdy_ext);
      // END, CR00097088
    } // Rate amount has a Min & Max range
    else if (providerOfferingRate.getMinAmount().isPositive()
      && providerOfferingRate.getMaxAmount().isPositive()) {

      utilizationServiceRatesNotificationList.rate = providerOfferingRate.getMinAmount().toString()
        + CuramConst.gkDash + providerOfferingRate.getMaxAmount().toString()
        + CPMConstants.kMinMax;
      // BEGIN, CR CR00097088, DN
      utilizationServiceRatesNotificationList.rateDateRange = Locale.getFormattedDate(
        providerOfferingRate.getDateRange().start(), Locale.Date_mdy_ext)
          + CuramConst.gkSpace
          + CPMConstants.kToField
          + CuramConst.gkSpace
          + Locale.getFormattedDate(providerOfferingRate.getDateRange().end(),
          Locale.Date_mdy_ext);
      // END, CR CR00097088
    } // Rate amount has a Min value only
    else if (providerOfferingRate.getMinAmount().isPositive()
      && !providerOfferingRate.getMaxAmount().isPositive()) {
      // BEGIN, CR CR00097088, DN
      utilizationServiceRatesNotificationList.rate = providerOfferingRate.getMinAmount().toString()
        + CuramConst.gkSpace + CPMConstants.kToField + CuramConst.gkSpace;
      // END, CR CR00097088
      // Begin CR00096779, ABS
      // BEGIN, CR CR00097088, DN
      utilizationServiceRatesNotificationList.rateDateRange = Locale.getFormattedDate(
        providerOfferingRate.getDateRange().start(), Locale.Date_mdy_ext)
          + CuramConst.gkSpace
          + CPMConstants.kToField
          + CuramConst.gkSpace
          + Locale.getFormattedDate(providerOfferingRate.getDateRange().end(),
          Locale.Date_mdy_ext);
      // END, CR CR00097088
      // End CR00096779
    } // Rate amount has a Max value only
    else if (!providerOfferingRate.getMinAmount().isPositive()
      && providerOfferingRate.getMaxAmount().isPositive()) {
      // BEGIN, CR CR00097088, DN
      utilizationServiceRatesNotificationList.rate = providerOfferingRate.getMaxAmount().toString()
        + CPMConstants.kMax;

      // END, CR CR00097088
      // Begin CR00096779, ABS
      // BEGIN, CR CR00097088, DN
      utilizationServiceRatesNotificationList.rateDateRange = Locale.getFormattedDate(
        providerOfferingRate.getDateRange().start(), Locale.Date_mdy_ext)
          + CuramConst.gkSpace
          + CPMConstants.kToField
          + CuramConst.gkSpace
          + Locale.getFormattedDate(providerOfferingRate.getDateRange().end(),
          Locale.Date_mdy_ext);
      // END, CR CR00097088
    }
    // End CR00096779
    return utilizationServiceRatesNotificationList;
  }
  
  // BEGIN, CR00281474, MR
  /**
   * Creates an association between communication and contract version.
   *
   * @param communicationID
   * Contains concern role communication ID for which notification
   * is created.
   * @param contractVersionID
   * Contains contract version associated with communication.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void createCommunicationCVLink(final long communicationID,
    final long contractVersionID) throws AppException,
      InformationalException {
    final CommunicationCVLink communicationCVLink = communicationCVLinkDAO.newInstance();

    communicationCVLink.setCommunicationID(communicationID);
    final ContractVersion contractVersion = contractVersionDAO.get(
      contractVersionID);

    communicationCVLink.setContractVersion(contractVersion);
    communicationCVLink.insert();
  }
  // END, CR00281474
}
