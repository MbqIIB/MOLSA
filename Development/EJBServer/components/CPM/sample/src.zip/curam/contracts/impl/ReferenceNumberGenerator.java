/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.Implementable;


/**
 * A ReferenceNumberGenerator class is used for generating a reference number
 * for a contract. The default implementation of this interface is provided by
 * UniqueNumberGeneratorImpl.
 *
 * The default implementation of this interface can be replaced with a new
 * custom implementation by creating a new Guice module class and adding a
 * corresponding entry in the MODULE table. Chapter 5 - Creating a Guice Module
 * - in the Persistence Cookbook explains this in detail.
 *
 * A new implementation of this interface is required to change the strategy to
 * generate a reference number.
 */

@ImplementedBy(UniqueNumberGeneratorImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ReferenceNumberGenerator {

  /**
   * Generates a reference number for a contract.
   *
   * To generate a reference number, the default implementation generates a
   * unique number with the maximum length of 18 digit assigned by the
   * organization to the contract.
   *
   * @param contractVersion
   * contract version details
   * @param cpmContract
   * CPM contract details
   *
   * @return the generated reference number.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.UniqueNumberGeneratorImpl#generateReferenceNumber(ContractVersion,
   * CPMContract) The default implementation -
   * {@link curam.contracts.impl.UniqueNumberGeneratorImpl#generateReferenceNumber(ContractVersion, CPMContract)}
   * .
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  @Implementable
  String generateReferenceNumber(ContractVersion contractVersion, CPMContract cpmContract) throws AppException, InformationalException;

}
