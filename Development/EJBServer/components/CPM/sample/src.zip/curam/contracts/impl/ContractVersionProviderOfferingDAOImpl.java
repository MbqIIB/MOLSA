/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.Set;

import com.google.inject.Singleton;

import curam.cpm.sl.entity.impl.ContractPOLinkAdapter;
import curam.cpm.sl.entity.struct.ContractPOLinkDtls;
import curam.providerservice.impl.ProviderOffering;
import curam.util.persistence.StandardDAOImpl;


/**
 * {@inheritDoc}
 */
@Singleton
// BEGIN, CR00183213, SS
public class ContractVersionProviderOfferingDAOImpl extends StandardDAOImpl<ContractVersionProviderOffering, ContractPOLinkDtls>
  implements ContractVersionProviderOfferingDAO {
  // END, CR00183213
  protected static final ContractPOLinkAdapter adapter = new ContractPOLinkAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ContractVersionProviderOfferingDAOImpl() {
    // END, CR00183213
    super(adapter, ContractVersionProviderOffering.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<ContractVersionProviderOffering> searchBy(
    final ContractVersion contractVersion) {
    return newSet(adapter.searchByContract(contractVersion.getID()));
  }

  /**
   * {@inheritDoc}
   */
  public Set<ContractVersionProviderOffering> searchBy(ProviderOffering providerOffering) {
    return newSet(adapter.searchByProviderOffering(providerOffering.getID()));
  }

}
