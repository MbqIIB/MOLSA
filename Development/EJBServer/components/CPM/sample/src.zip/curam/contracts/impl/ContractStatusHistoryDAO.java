/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.util.persistence.ReaderDAO;


/**
 * Data access for
 * {@linkplain curam.contracts.impl.ContractStatusHistory}.
 */
@ImplementedBy(ContractStatusHistoryDAOImpl.class)
// BEGIN, CR00274320, AC
public interface ContractStatusHistoryDAO extends
    ReaderDAO<Long, ContractStatusHistory> {
  // END, CR00274320

  // ___________________________________________________________________________
  /**
   * Returns a list of {@link ContractStatusHistory contract status histories} based in a specified set of search criteria.
   * <p>
   * List is returned in ascending date/time order with the earliest first.
   *
   * @param contract the license for which history records are required.
   * @return status history records for a contract.
   */
  public List<ContractStatusHistory> searchBy(final ContractVersion contract);

}
