/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingRate;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.LinkTable;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;
import curam.util.type.DateRange;


/**
 * This interface is used for maintaining the link information between contract
 * version and provider offering.
 */
@ImplementedBy(ContractVersionProviderOfferingImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ContractVersionProviderOffering extends
    ContractVersionProviderOfferingAccessor,
    LinkTable<ContractVersion, ProviderOffering> {

  /**
   * Gets the contract version.
   *
   * @boread FlatRateContract
   * @boread UtilizationContract
   *
   * @return The contract version.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public ContractVersion getContractVersion();

  /**
   * Gets the provider offering.
   *
   * @boread ProviderService
   *
   * @return The provider offering.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public ProviderOffering getProviderOffering();

  /**
   * Sets the contract version.
   *
   * @param value
   * the contract version.
   *
   * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#setContractVersion(ContractVersion)
   * The default implementation -
   * curam.contracts.impl.ContractVersionProviderOfferingImpl#setContractVersion(ContractVersion)
   */
  public void setContractVersion(final ContractVersion value);

  /**
   * Sets the provider offering.
   *
   * @param value
   * the provider offering.
   * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#setProviderOffering(ProviderOffering)
   * The default implementation -
   * curam.contracts.impl.ContractVersionProviderOfferingImpl#setProviderOffering(ProviderOffering)
   */
  public void setProviderOffering(final ProviderOffering value);

  /**
   * Creates a default
   * {@link curam.providerservice.impl.ProviderOfferingRate provider offering rate}
   * for this {@link curam.provider.impl.Provider provider} based on the
   * {@link curam.serviceoffering.impl.ServiceRate service rate}.
   * <p>
   * The provider offering rate's date range will be the same as the contract.
   * <p>
   * The rate value(s) will be based on the non-contracted provider offering
   * rate for the
   * {@link curam.providerservice.impl.ProviderOffering provider offering} which
   * applies on the contract's start date.
   * <p>
   * If no applicable provider offering rate exists, the service rate for the
   * provider offering's service, applicable on the contract's start date, will
   * be used to get value(s) for the ProviderOfferingRate.
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#createDefaultRate()
   * The default implementation -
   * curam.contracts.impl.ContractVersionProviderOfferingImpl#createDefaultRate()
   */
  public void createDefaultRate() throws InformationalException;

  /**
   * Checks if the
   * {@link curam.providerservice.impl.ProviderOffering provider offering}/
   * {@link curam.provider.impl.Provider provider} pairs for the contract
   * version provider offering already exists on another live contract for a
   * specified period of time.
   * <p>
   * If a duplicate exists it is returned, otherwise a null value is returned.
   *
   * @param dateRange
   * the date range.
   *
   * @return the duplicate of this link (if one exists), otherwise null.
   *
   * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#checkForDuplicateProviderOfferingOnLiveContract(DateRange)
   * The default implementation -
   * curam.contracts.impl.ContractVersionProviderOfferingImpl#checkForDuplicateProviderOfferingOnLiveContract(DateRange)
   */
  public ContractVersionProviderOffering checkForDuplicateProviderOfferingOnLiveContract(
    DateRange dateRange);

  // BEGIN CR00098695, ABS
  /**
   * Copies the non contracted provider offering rates to contract.
   *
   * @param providerOfferingRateArray
   * Provider offering rate array needs to be copied to contract
   * @param contractPeriod
   * Contract period
   *
   * @return Set of contracted provider offering rates copied from non
   * contracted provider offering rate
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#copyNonContractedPORToContract(ProviderOfferingRate[],DateRange)
   * The default implementation -
   * curam.contracts.impl.ContractVersionProviderOfferingImpl#copyNonContractedPORToContract(ProviderOfferingRate[],DateRange)
   */
  public Set<ProviderOfferingRate> copyNonContractedPORToContract(
    ProviderOfferingRate[] providerOfferingRateArray, DateRange contractPeriod)
    throws InformationalException;

  /**
   * Creates contracted provider offering rate when non contracted provider
   * offering rate does not exist.
   *
   * @param providerOfferingRateArray
   * contains non contracted provider offering rate list.
   * @param contractVersionPeriod
   * contract period
   *
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#createContractedPORForPeriod(ProviderOfferingRate[],DateRange)
   * The default implementation -
   * curam.contracts.impl.ContractVersionProviderOfferingImpl#createContractedPORForPeriod(ProviderOfferingRate[],DateRange)
   */
  public void createContractedPORForPeriod(
    ProviderOfferingRate[] providerOfferingRateArray,
    DateRange contractVersionPeriod) throws InformationalException;
  // END CR00098695
  
  
  // BEGIN, CR00305191, ASN
  /**
   * Interface to the Contract Version Provider Offering events functionality
   * surrounding the copyNonContractedPORToContract method.
   */
  public interface ContractVerProvOfferCopyNonContractPORToContractEvents {

    /**
     * Event interface invoked before the main body of the
     * copyNonContractedPORToContract method.
     * {@linkplain ContractVersionProviderOffering#copyNonContractedPORToContract}
     *
     * @param contractVersionProviderOfferingAccessor
     * The object instance as it was before the main body of the
     * copyNonContractedPORToContract method.
     * @param providerOfferingRateArray
     * Provider offering rate array needs to be copied to contract
     * @param contractPeriod
     * Contract period
     *
     * @return Set of contracted provider offering rates copied from non
     * contracted provider offering rate
     *
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#copyNonContractedPORToContract(ProviderOfferingRate[],DateRange)
     * The default implementation -
     * curam.contracts.impl.ContractVersionProviderOfferingImpl
     * #copyNonContractedPORToContract(ProviderOfferingRate[],DateRange)
     */
    public Set<ProviderOfferingRate> preCopyNonContractedPORToContract(
      final ContractVersionProviderOfferingAccessor contractVersionProviderOfferingAccessor, ProviderOfferingRate[] providerOfferingRateArray,
      DateRange contractPeriod) throws InformationalException;

    /**
     * Event interface invoked after the main body of the
     * copyNonContractedPORToContract method.
     * {@linkplain ContractVersionProviderOffering#copyNonContractedPORToContract}
     *
     * @param contractVersionProviderOfferingAccessor
     * The object instance as it was after the main body of the
     * copyNonContractedPORToContract method.
     * @param providerOfferingRateArray
     * Provider offering rate array needs to be copied to contract
     * @param contractPeriod
     * Contract period
     *
     * @return Set of contracted provider offering rates copied from non
     * contracted provider offering rate
     *
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#copyNonContractedPORToContract(ProviderOfferingRate[],DateRange)
     * The default implementation -
     * curam.contracts.impl.ContractVersionProviderOfferingImpl
     * #copyNonContractedPORToContract(ProviderOfferingRate[],DateRange)
     */
    public Set<ProviderOfferingRate> postCopyNonContractedPORToContract(
      final ContractVersionProviderOfferingAccessor contractVersionProviderOfferingAccessor, ProviderOfferingRate[] providerOfferingRateArray,
      DateRange contractPeriod) throws InformationalException;
  }


  /**
   * Interface to the Contract Version Provider Offering events functionality
   * surrounding the createDefaultRate method.
   */
  public interface ContractVerProvOfferCreateDefaultRateEvents {

    /**
     * Event interface invoked before the main body of the createDefaultRate
     * method. {@linkplain ContractVersionProviderOffering#createDefaultRate}
     *
     * @param contractVersionProviderOfferingAccessor
     * The object instance as it was before the main body of the
     * createDefaultRate method.
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#createDefaultRate()
     * The default implementation -
     * curam.contracts.impl.ContractVersionProviderOfferingImpl
     * #createDefaultRate()
     */
    public void preCreateDefaultRate(final ContractVersionProviderOfferingAccessor contractVersionProviderOfferingAccessor) throws InformationalException;

    /**
     * Event interface invoked after the main body of the createDefaultRate
     * method. {@linkplain ContractVersionProviderOffering#createDefaultRate}
     *
     * @param contractVersionProviderOfferingAccessor
     * The object instance as it was after the main body of the
     * createDefaultRate method.
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#createDefaultRate()
     * The default implementation -
     * curam.contracts.impl.ContractVersionProviderOfferingImpl
     * #createDefaultRate()
     */
    public void postCreateDefaultRate(final ContractVersionProviderOfferingAccessor contractVersionProviderOfferingAccessor) throws InformationalException;
  }


  /**
   * Interface to the Contract Version Provider Offering events functionality
   * surrounding the checkForDuplicateProviderOfferingOnLiveContract method.
   */
  public interface ContractVerPOCheckForDuplicatePOOnLiveContractEvents {

    /**
     * Event interface invoked before the main body of the
     * checkForDuplicateProviderOfferingOnLiveContract method.
     * {@linkplain ContractVersionProviderOffering#checkForDuplicateProviderOfferingOnLiveContract}
     *
     * @param contractVersionProviderOfferingAccessor
     * The object instance as it was before the main body of the
     * checkForDuplicateProviderOfferingOnLiveContract method.
     * @param dateRange
     * The date range.
     *
     * @return the duplicate of this link (if one exists), otherwise null.
     *
     * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#checkForDuplicateProviderOfferingOnLiveContract(DateRange)
     * The default implementation -
     * curam.contracts.impl.ContractVersionProviderOfferingImpl
     * #checkForDuplicateProviderOfferingOnLiveContract(DateRange)
     */
    public ContractVersionProviderOffering preCheckForDuplicateProviderOfferingOnLiveContract(
      final ContractVersionProviderOfferingAccessor contractVersionProviderOfferingAccessor, DateRange dateRange);

    /**
     * Event interface invoked after the main body of the
     * checkForDuplicateProviderOfferingOnLiveContract method.
     * {@linkplain ContractVersionProviderOffering#checkForDuplicateProviderOfferingOnLiveContract}
     *
     * @param contractVersionProviderOfferingAccessor
     * The object instance as it was after the main body of the
     * checkForDuplicateProviderOfferingOnLiveContract method.
     * @param dateRange
     * The date range.
     *
     * @return the duplicate of this link (if one exists), otherwise null.
     *
     * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#checkForDuplicateProviderOfferingOnLiveContract(DateRange)
     * The default implementation -
     * curam.contracts.impl.ContractVersionProviderOfferingImpl
     * #checkForDuplicateProviderOfferingOnLiveContract(DateRange)
     */
    public ContractVersionProviderOffering postCheckForDuplicateProviderOfferingOnLiveContract(
      final ContractVersionProviderOfferingAccessor contractVersionProviderOfferingAccessor, DateRange dateRange);

  }


  /**
   * Interface to the Contract Version Provider Offering events functionality
   * surrounding the createContractedPORForPeriod method.
   */
  public interface ContractVerPOCreateContractedPORForPeriodEvents {

    /**
     * Event interface invoked before the main body of the
     * checkForDuplicateProviderOfferingOnLiveContract method.
     * {@linkplain ContractVersionProviderOffering#createContractedPORForPeriod}
     *
     * @param contractVersionProviderOfferingAccessor
     * The object instance as it was before the main body of the
     * createContractedPORForPeriod method.
     * @param providerOfferingRateArray
     * contains non contracted provider offering rate list.
     * @param contractVersionPeriod
     * contract period
     *
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#createContractedPORForPeriod(ProviderOfferingRate[],DateRange)
     * The default implementation -
     * curam.contracts.impl.ContractVersionProviderOfferingImpl
     * #createContractedPORForPeriod(ProviderOfferingRate[],DateRange)
     */
    public void preCreateContractedPORForPeriod(
      final ContractVersionProviderOfferingAccessor contractVersionProviderOfferingAccessor, ProviderOfferingRate[] providerOfferingRateArray,
      DateRange contractVersionPeriod) throws InformationalException;

    /**
     * Event interface invoked after the main body of the
     * createContractedPORForPeriod method.
     * {@linkplain ContractVersionProviderOffering#createContractedPORForPeriod}
     *
     * @param contractVersionProviderOfferingAccessor
     * The object instance as it was after the main body of the
     * createContractedPORForPeriod method.
     * @param providerOfferingRateArray
     * contains non contracted provider offering rate list.
     * @param contractVersionPeriod
     * contract period
     *
     * @throws InformationalException
     * Generic Exception Signature.
     *
     * @see curam.contracts.impl.ContractVersionProviderOfferingImpl#createContractedPORForPeriod(ProviderOfferingRate[],DateRange)
     * The default implementation -
     * curam.contracts.impl.ContractVersionProviderOfferingImpl
     * #createContractedPORForPeriod(ProviderOfferingRate[],DateRange)
     */
    public void postCreateContractedPORForPeriod(
      final ContractVersionProviderOfferingAccessor contractVersionProviderOfferingAccessor, ProviderOfferingRate[] providerOfferingRateArray,
      DateRange contractVersionPeriod) throws InformationalException;

  }
  // END, CR00305191
}
