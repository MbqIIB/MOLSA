/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import com.google.inject.Inject;

import curam.codetable.impl.CONTRACTSTATUSEntry;
import curam.cpm.sl.entity.struct.ContractStatusHistoryDtls;
import curam.message.impl.CONTRACTSTATUSHISTORYExceptionCreator;
import curam.util.exception.AppRuntimeException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;


/**
 * Standard implementation of {@linkplain curam.contracts.impl.ContractStatusHistory}.
 */
// BEGIN, CR00183213, SS
public class ContractStatusHistoryImpl extends SingleTableEntityImpl<ContractStatusHistoryDtls> implements
  ContractStatusHistory, ContractStatusHistoryCreator {
  // END, CR00183213
  /**
   * DAO
   */
  @Inject
  protected ContractVersionDAO contractversionDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ContractStatusHistoryImpl() {// The no-arg constructor for use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// none required
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// none required
  }

  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.ContractStatusHistory#ERR_FV_STATUS_NOT_ENTERED} -
   * If the Status is empty. </li>
   * <li>
   * {@link curam.message.ContractStatusHistory#ERR_FV_STATUS_DATE_NOT_ENTERED} -
   * If the Date is not entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    // Status cannot be empty (Should be internally managed by this entity)
    if (StringHelper.isEmpty(getDtls().status)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTSTATUSHISTORYExceptionCreator.ERR_FV_STATUS_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }

    // Status Date/Time cannot be empty (Should be internally managed by this entity)
    if (getEventDateTime().isZero()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CONTRACTSTATUSHISTORYExceptionCreator.ERR_FV_STATUS_DATE_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }
  }

  /**
   * {@inheritDoc}
   */
  public ContractVersion getContractVersion() {

    return contractversionDAO.get(getDtls().contractVersionID);
  }

  /**
   * {@inheritDoc}
   */
  public CONTRACTSTATUSEntry getStatus() {

    return CONTRACTSTATUSEntry.get(getDtls().status);
  }

  /**
   * {@inheritDoc}
   */
  public String getLastModifiedBy() {

    return getDtls().lastModifiedBy;
  }

  /**
   * {@inheritDoc}
   */
  public ContractGenerationReasonEntry getStatusHistoryGenerationReason() {

    return ContractGenerationReasonEntry.get(
      getDtls().statusHistoryGenerationReason);

  }

  /**
   * {@inheritDoc}
   */
  public DateTime getEventDateTime() {
    return getDtls().statusDateTime;
  }

  /**
   * {@inheritDoc}
   */
  public void setContractVersion(final ContractVersion value) {

    getDtls().contractVersionID = value.getID();
    getDtls().status = value.getLifecycleState().getCode();
    getDtls().statusHistoryGenerationReason = value.getGenerationReason().getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {

    getDtls().statusDateTime = DateTime.getCurrentDateTime();

    curam.core.intf.SystemUser systemUserObj = curam.core.fact.SystemUserFactory.newInstance();

    try {

      getDtls().lastModifiedBy = systemUserObj.getUserDetails().userName;
    } catch (final Exception e) {
      // translate any exceptions to a runtime exception
      throw new AppRuntimeException(e);
    }

  }

}
