/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import com.google.inject.ImplementedBy;
import curam.util.type.HistoricalEvent;


/**
 * A change in the status of a {@link ContractVersion contract version}.
 * <p>
 * The status of a contract version will change through its lifecycle for
 * example, the status for a contract version is set to 'In Edit' upon initial
 * creation, and then changed to 'Live' once activated.
 *
 * @see curam.codetable.impl.CONTRACTSTATUSEntry for status codes.
 */

@ImplementedBy(ContractStatusHistoryImpl.class)
public interface ContractStatusHistory extends HistoricalEvent,
    ContractStatusHistoryAccessor {

  /**
   * Gets the contract version details.
   *
   * @return The contract version.
   */
  public ContractVersion getContractVersion();

}
