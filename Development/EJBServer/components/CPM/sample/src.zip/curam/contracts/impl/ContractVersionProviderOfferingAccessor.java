/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.contracts.impl;


import curam.providerservice.impl.ProviderOfferingAccessor;
import curam.util.persistence.StandardEntity;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * This interface is used for accessing the link information between contract
 * version and provider offering.
 */
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ContractVersionProviderOfferingAccessor extends StandardEntity {

  /**
   * Gets the contract version.
   *
   * @boread FlatRateContract
   * @boread UtilizationContract
   *
   * @return The contract version.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public ContractVersionAccessor getContractVersion();

  /**
   * Gets the provider offering.
   *
   * @boread ProviderService
   *
   * @return The provider offering.
   */
  @AccessLevel(AccessLevelType.EXTERNAL)
  public ProviderOfferingAccessor getProviderOffering();
}
