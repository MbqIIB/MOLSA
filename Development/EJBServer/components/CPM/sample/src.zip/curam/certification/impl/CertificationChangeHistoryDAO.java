/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.certification.impl;


import java.util.List;

import com.google.inject.ImplementedBy;

import curam.cpm.sl.entity.struct.CertificationKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain curam.certification.impl.CertificationChangeHistory}.
 *
 */
@ImplementedBy(CertificationChangeHistoryDAOImpl.class)
public interface CertificationChangeHistoryDAO extends
    StandardDAO<CertificationChangeHistory> {

  /**
   * Searches the list of of active certification change history details
   * for the agency.
   *
   * @param key
   * Contains the certification id.
   * @return Lists the Certification Change History records.
   * details that are active for a agency.
   * @throws InformationalException Generic Exception Signature.
   *
   * @throws AppException Generic Exception Signature.
   */
  public List<CertificationChangeHistory> getCertificationHistory
    (CertificationKey key)
    throws AppException, InformationalException;

}
