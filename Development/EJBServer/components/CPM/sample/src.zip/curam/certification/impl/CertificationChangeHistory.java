/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008,2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.certification.impl;


import com.google.inject.ImplementedBy;

import curam.codetable.impl.CERTIFICATIONCATEGORYEntry;
import curam.codetable.impl.CERTIFICATIONTYPEEntry;
import curam.codetable.impl.CREDITTYPEEntry;
import curam.codetable.impl.EXTERNALISSUEREntry;
import curam.codetable.impl.VALIDITYPERIODUNITSEntry;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateTime;


/**
 * Service layer class having API for managing Certification Change History.
 * Certification Change History are maintained at agency level.
 */
@ImplementedBy(CertificationChangeHistoryImpl.class)
public interface CertificationChangeHistory extends CertificationChangeHistoryAccessor, Insertable,
    OptimisticLockModifiable, LogicallyDeleteable {

  /**
   * Gets the certification details.
   *
   * @return The certification details.
   */

  public Certification getCertification();

  /**
   * Sets the certification details.
   *
   * @param certification
   * The certification details.
   */
  public void setCertification(final Certification certification);

  /**
   * Sets the date time when the certification record was created or modified.
   *
   * @param dateTime
   * The date time details.
   */
  public void setDateTime(final DateTime dateTime);

  /**
   * Sets the category of the certification.
   *
   * @param certificationCategoryentry
   * The category of the certification.
   */
  public void setCategory(final CERTIFICATIONCATEGORYEntry
    certificationCategoryentry);

  /**
   * Sets the type of the certification.
   *
   * @param certificationTypeentry
   * The type of the certification.
   */

  public void setCertificationType(final CERTIFICATIONTYPEEntry
    certificationTypeentry);

  /**
   * Sets the user who created the certification.
   *
   * @param user
   * The name of the user.
   */
  public void setUser(final String user);

  /**
   * Sets the credits required to be certified.
   *
   * @param creditsRequired
   * The required credits.
   */
  public void setCreditsRequired(final short creditsRequired);

  /**
   * Sets the type of the credit required to obtain the certification.
   *
   * @param creditTypeentry
   * The type of the credit required.
   */
  public void setCreditType(final CREDITTYPEEntry creditTypeentry);

  /**
   * Sets the External Issuer, through whom the certification is being issued.
   *
   * @param externalIssuerEntry
   * The External Issuer.
   */
  public void setExternalIssuer(final EXTERNALISSUEREntry
    externalIssuerEntry);

  /**
   * Denotes whether the certification is issued by the agency.
   *
   * @return The boolean value for the certification issued by agency.
   */
  public boolean isIssuedByAgency();

  /**
   * Sets the Indicator, which denotes whether the certification is issued by
   * the agency.
   *
   * @param issuedByAgencyInd
   * The boolean value for the certification issued by agency.
   */
  public void setIssuedByAgency(final boolean issuedByAgencyInd);

  /**
   * Sets the Organization Unit Id, through whom the certification is being
   * issued.
   *
   * @param organisationunitId
   * The system identifier for the Organization Unit.
   */
  public void setOrganisationUnitId(final long organisationunitId);

  /**
   * Sets the Validity Period for the certification.
   *
   * @param validityPeriod
   * The validity period.
   */
  public void setValidityPeriod(final short validityPeriod);

  /**
   * Sets the Validity Period Units for the validity period of the
   * certification.
   *
   * @param VALIDITYPERIODUNITSEntry
   * The validity period units.
   */
  public void setValidityPeriodUnits(final VALIDITYPERIODUNITSEntry
    VALIDITYPERIODUNITSEntry);
}
