/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.certification.impl;


import curam.codetable.impl.CERTIFICATIONCATEGORYEntry;
import curam.codetable.impl.CERTIFICATIONTYPEEntry;
import curam.codetable.impl.CREDITTYPEEntry;
import curam.codetable.impl.EXTERNALISSUEREntry;
import curam.codetable.impl.VALIDITYPERIODUNITSEntry;
import curam.util.persistence.StandardEntity;
import curam.util.type.DateTime;


/**
 * Accessor interface for
 * {@linkplain curam.certification.impl.CertificationChangeHistory}.
 *
 */
public interface CertificationChangeHistoryAccessor extends StandardEntity {

  /**
   * Gets the date time when the certification record was created or
   * modified.
   *
   * @return Contains the date time.
   */
  public DateTime getDateTime();

  /**
   * Gets the user who created the certification.
   *
   * @return Contains the userName.
   */
  public String getUser();

  /**
   * Gets the credits required for obtaining a certification.
   *
   * @return Contains the number of credits Required.
   */
  public short getCreditsRequired();

  /**
   * Gets the Organization Unit Id, through whom the
   * certification
   * is being issued.
   *
   * @return contains the Organization Unit Id.
   */
  public long getOrganisationUnitId();

  /**
   * Gets the Validity Period for the certification.
   *
   * @return Contains the validity period.
   */
  public short getValidityPeriod();

  /**
   * Gets the certification for which the history is being stored.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return Contains the certification.
   */
  public CertificationAccessor getCertification();

  /**
   * Gets the category of the certification.
   *
   * @return Contains the category.
   */
  public CERTIFICATIONCATEGORYEntry getCategory();

  /**
   * Gets the type of the certification.
   *
   * @return Contains the type of the certification.
   */
  public CERTIFICATIONTYPEEntry getCertificationType();

  /**
   * Gets the type of the credit required to obtain the certification.
   *
   * @return Contains the type of the credit required.
   */

  public CREDITTYPEEntry getCreditType();

  /**
   * Gets the External Issuer, through whom the certification
   * is being issued.
   *
   * @return Contains the External Issuer.
   */
  public EXTERNALISSUEREntry getExternalIssuer();

  /**
   * Gets the Validity Period Units Units for the validity period of
   * the certification.
   *
   * @return Contains the validity period units.
   */
  public VALIDITYPERIODUNITSEntry getValidityPeriodUnits();

}
