/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.certification.impl;


import com.google.inject.Inject;

import curam.codetable.RECORDSTATUS;
import curam.codetable.impl.CERTIFICATIONCATEGORYEntry;
import curam.codetable.impl.CERTIFICATIONTYPEEntry;
import curam.codetable.impl.CREDITTYPEEntry;
import curam.codetable.impl.EXTERNALISSUEREntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.VALIDITYPERIODUNITSEntry;
import curam.core.fact.SystemUserFactory;
import curam.core.intf.SystemUser;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.CertificationDtls;
import curam.events.PROVIDERMANAGEMENT;
import curam.message.impl.CERTIFICATIONExceptionCreator;
import curam.provider.impl.MemberCertificationDAO;
import curam.util.events.impl.EventService;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.DateTime;


/**
 * Standard implementation of
 * {@linkplain curam.certification.impl.Certification}.
 */
// BEGIN, CR00183213, SS
public class CertificationImpl extends SingleTableLogicallyDeleteableEntityImpl<CertificationDtls> implements
  Certification {
  // END, CR00183213

  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<CertificationInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<CertificationModifyEvents> modifyEventDispatcherFactory;

  /**
   * Event dispatcher for cancel events.
   */
  @Inject
  protected EventDispatcherFactory<CertificationCancelEvents> cancelEventDispatcherFactory;

  // END, CR00235789

  /**
   * Certification DAO
   */
  @Inject
  protected CertificationDAO certificationDAO;

  /**
   * Certification Change History DAO
   */
  @Inject
  protected CertificationChangeHistoryDAO certificationChangeHistoryDAO;

  /**
   * Member Certification DAO
   */
  @Inject
  protected MemberCertificationDAO memberCertificationDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected CertificationImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213

  /**
   * {@inheritDoc}
   */
  public CERTIFICATIONCATEGORYEntry getCategory() {

    return CERTIFICATIONCATEGORYEntry.get(getDtls().category);
  }

  /**
   * {@inheritDoc}
   */
  public CERTIFICATIONTYPEEntry getCertificationType() {
    return CERTIFICATIONTYPEEntry.get(getDtls().certificationType);
  }

  /**
   * {@inheritDoc}
   */
  public short getCreditsRequired() {
    return getDtls().creditsRequired;
  }

  /**
   * {@inheritDoc}
   */
  public CREDITTYPEEntry getCreditType() {
    return CREDITTYPEEntry.get(getDtls().creditType);
  }

  /**
   * {@inheritDoc}
   */
  public EXTERNALISSUEREntry getExternalIssuer() {
    return EXTERNALISSUEREntry.get(getDtls().externalIssuer);
  }

  /**
   * {@inheritDoc}
   */
  public String getUser() {
    return getDtls().userName;
  }

  /**
   * {@inheritDoc}
   */
  public boolean isIssuedByAgency() {

    return getDtls().issuedByAgencyInd;
  }

  /**
   * {@inheritDoc}
   */
  public void setCategory(CERTIFICATIONCATEGORYEntry value) {
    getDtls().category = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setCertificationType(CERTIFICATIONTYPEEntry value) {
    getDtls().certificationType = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setCreditsRequired(short value) {
    getDtls().creditsRequired = value;

  }

  /**
   * {@inheritDoc}
   */
  public void setCreditType(CREDITTYPEEntry value) {
    getDtls().creditType = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setExternalIssuer(EXTERNALISSUEREntry value) {
    getDtls().externalIssuer = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setIssuedByAgency(boolean value) {
    getDtls().issuedByAgencyInd = value;

  }

  /**
   * {@inheritDoc}
   */
  public void setUser(String value) {
    getDtls().userName = value;

  }

  /**
   * {@inheritDoc}
   */
  public long getOrganisationUnitId() {

    return getDtls().organisationUnitID;
  }

  /**
   * {@inheritDoc}
   */
  public void setOrganisationUnitId(long value) {
    getDtls().organisationUnitID = value;

  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No such validations required currently
  }

  /**
   * Validates that all the field values held are valid with respect to each
   * other.
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XRV_ISSUER_MUST_BE_ENTERED}
   * - If the issuer is not entered.</li>
   * <li>
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XFV_ONLY_ONE_ISSUER_MUST_BE_ENTERED}
   * - If multiple issuers are entered.</li>
   * <li>
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XFV_VALIDITY_PERIOD_UNITS_MUST_BE_ENTERED_IF_VALIDITY_PERIOD_IS_ENTERED}
   * - If validity units are not entered and validity period is entered.</li>
   * <li>
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XFV_VALIDITY_PERIOD_MUST_BE_ENTERED_IF_VALIDITY_PERIOD_UNITS_IS_ENTERED}
   * - If validity period is not entered and validity period units are entered.</li>
   * </ul>
   */
  public void crossFieldValidation() {
    if ((!isIssuedByAgency())
      && (getExternalIssuer().getCode().length() == CPMConstants.kZeroLong)
      && (getOrganisationUnitId() == CPMConstants.kZeroLong)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_ISSUER_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if ((isIssuedByAgency())
      && !(getExternalIssuer().getCode().length() == CPMConstants.kZeroLong)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XFV_ONLY_ONE_ISSUER_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }
    if ((isIssuedByAgency())
      && (getOrganisationUnitId() != CPMConstants.kZeroLong)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XFV_ONLY_ONE_ISSUER_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

    }
    if ((getOrganisationUnitId() != CPMConstants.kZeroLong)
      && (getExternalIssuer().getCode().length() != CPMConstants.kZeroLong)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XFV_ONLY_ONE_ISSUER_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    }

    if ((getValidityPeriod() != CPMConstants.kZeroLong)
      && (getValidityPeriodUnits().getCode().length() == CPMConstants.kZeroLong)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XFV_VALIDITY_PERIOD_UNITS_MUST_BE_ENTERED_IF_VALIDITY_PERIOD_IS_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if ((getValidityPeriodUnits().getCode().length() != CPMConstants.kZeroLong)
      && (getValidityPeriod() == CPMConstants.kZeroLong)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XFV_VALIDITY_PERIOD_MUST_BE_ENTERED_IF_VALIDITY_PERIOD_UNITS_IS_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XRV_CERTIFICATION_TYPE_MUST_BE_ENTERED}
   * - If the certification type is not entered.</li>
   * <li>
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XRV_CERTIFICATION_CATEGORY_MUST_BE_ENTERED}
   * - If the certification category is not entered.</li>
   * </ul>
   */
  public void mandatoryFieldValidation() {
    if (getCertificationType().getCode().length() == CPMConstants.kZeroLong) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_CERTIFICATION_TYPE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }
    if (getCategory().getCode().length() == CPMConstants.kZeroLong) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_CERTIFICATION_CATEGORY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

  }

  /**
   * Cancels the certification record.
   *
   * @throws InformationalException
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XRV_ONLY_ACTIVE_RECORDS_CAN_BE_DELETED}
   * - If non active records are canceled.
   * @throws InformationalException
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XRV_ACTIVE_MEMBER_EXISTS}
   * - If deleting the certificate which has been issued to a member
   * which has not yet expired.
   */
  @Override
  public void cancel(int versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre cancel certification event.
    cancelEventDispatcherFactory.get(CertificationCancelEvents.class).preCancel(
      this, versionNo);
    // END, CR00235789

    if (RECORDSTATUS.CANCELLED.equals(getDtls().recordStatus)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_ONLY_ACTIVE_RECORDS_CAN_BE_DELETED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

    }
    if (memberCertificationDAO.searchActiveMemberCertificationByCertification(getDtls().certificationID).size()
      > 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_ACTIVE_MEMBER_EXISTS(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();
    super.cancel(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post cancel certification event.
    cancelEventDispatcherFactory.get(CertificationCancelEvents.class).postCancel(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RECORDSTATUSEntry getLifecycleState() {

    return super.getLifecycleState();
  }

  /**
   * Modifies a certification record details and inserts a record in change
   * history details. Also raises a workflow event after modification.
   *
   * @throws InformationalException
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XRV_ONLY_ACTIVE_RECORDS_CAN_BE_MODIFIED}
   * If the certification record is canceled.
   * @throws InformationalException
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XRV_CERTIFICATE_ALREADY_EXISTS}
   * - If an active certification record already exists for the same
   * combination of certification type, category & issuer already
   * exists for same category.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre modify certification event.
    modifyEventDispatcherFactory.get(CertificationModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    SystemUser systemUserObj = SystemUserFactory.newInstance();

    // BEGIN, CR00137968, AK
    try {
      for (final Certification certification : certificationDAO.getActiveCertifications()) {

        if (certification.getID() != getDtls().certificationID) {
          if (((certification.getCertificationType().getCode().equals(
            getDtls().certificationType))
              && (certification.getCategory().getCode().equals(
                getDtls().category))
                && (certification.isIssuedByAgency()
                  && (getDtls().issuedByAgencyInd)))
                    || ((certification.getCertificationType().getCode().equals(
                      getDtls().certificationType))
                        && (certification.getCategory().getCode().equals(
                          getDtls().category))
                          && (certification.getOrganisationUnitId() != 0)
                          && (certification.getOrganisationUnitId()
                            == getDtls().organisationUnitID))
                            || ((certification.getCertificationType().getCode().equals(
                              getDtls().certificationType))
                                && (certification.getCategory().getCode().equals(
                                  getDtls().category))
                                  && (certification.getExternalIssuer().getCode().equals(
                                    getDtls().externalIssuer)))) {
            curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
              CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_CERTIFICATE_ALREADY_EXISTS(),
              curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
              1);
          }

        }
      }
    } catch (AppException e) {
      ValidationHelper.addValidationError(e);
    }
    // END, CR00137968
    if (RECORDSTATUS.CANCELLED.equals(getDtls().recordStatus)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_ONLY_ACTIVE_RECORDS_CAN_BE_MODIFIED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);

      ValidationHelper.failIfErrorsExist();
    }
    super.modify(versionNo);

    Certification certification = certificationDAO.get(
      getDtls().certificationID);
    CertificationChangeHistory certificationChangeHistory = certificationChangeHistoryDAO.newInstance();

    certificationChangeHistory.setCertification(certification);

    certificationChangeHistory.setCertificationType(
      CERTIFICATIONTYPEEntry.get(getDtls().certificationType));

    certificationChangeHistory.setCategory(
      CERTIFICATIONCATEGORYEntry.get(getDtls().category));
    certificationChangeHistory.setCreditsRequired(getDtls().creditsRequired);
    certificationChangeHistory.setCreditType(
      CREDITTYPEEntry.get(getDtls().creditType));
    certificationChangeHistory.setIssuedByAgency(getDtls().issuedByAgencyInd);
    certificationChangeHistory.setExternalIssuer(
      EXTERNALISSUEREntry.get(getDtls().externalIssuer));
    certificationChangeHistory.setOrganisationUnitId(
      getDtls().organisationUnitID);
    certificationChangeHistory.setValidityPeriod(getDtls().validityPeriod);
    certificationChangeHistory.setValidityPeriodUnits(
      VALIDITYPERIODUNITSEntry.get(getDtls().validityPeriodUnit));
    certificationChangeHistory.setDateTime(DateTime.getCurrentDateTime());
    try {
      certificationChangeHistory.setUser(
        systemUserObj.getUserDetails().userName);
    } catch (AppException e) {
      ValidationHelper.addValidationError(e);
    }
    certificationChangeHistory.insert();
    eventForCertificationUpdate();

    // BEGIN, CR00235789, AK
    // Raise the post modify certification event.
    modifyEventDispatcherFactory.get(CertificationModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {
    super.setNewInstanceDefaults();
  }

  /**
   * Inserts a certification record along with the certification change history.
   *
   * @throws InformationalException
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XRV_CERTIFICATE_ALREADY_EXISTS}
   * - If an active certification record already exists for the same
   * combination of certification type, category & issuer already
   * exists for same category.
   */
  @Override
  public void insert() throws InformationalException {
    // BEGIN, CR00235789, AK
    // Raise the pre insert certification event.
    insertEventDispatcherFactory.get(CertificationInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    SystemUser systemUserObj = SystemUserFactory.newInstance();

    try {
      for (final Certification certification : certificationDAO.getActiveCertifications()) {

        if (((certification.getCertificationType().getCode().equals(
          getDtls().certificationType))
            && (certification.getCategory().getCode().equals(getDtls().category))
            && (certification.isIssuedByAgency()
              && (getDtls().issuedByAgencyInd)))
                || ((certification.getCertificationType().getCode().equals(
                  getDtls().certificationType))
                    && (certification.getCategory().getCode().equals(
                      getDtls().category))
                      && (certification.getOrganisationUnitId() != 0)
                      && (certification.getOrganisationUnitId()
                        == getDtls().organisationUnitID))
                        || ((certification.getCertificationType().getCode().equals(
                          getDtls().certificationType))
                            && (certification.getCategory().getCode().equals(
                              getDtls().category))
                              && (certification.getExternalIssuer().getCode().equals(
                                getDtls().externalIssuer)))) {
          curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
            CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_CERTIFICATE_ALREADY_EXISTS(),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
          ValidationHelper.failIfErrorsExist();
        }

      }
    } catch (AppException e) {
      ValidationHelper.addValidationError(e);
    }
    super.insert();

    Certification certification = certificationDAO.get(
      getDtls().certificationID);
    CertificationChangeHistory certificationChangeHistory = certificationChangeHistoryDAO.newInstance();

    certificationChangeHistory.setCertification(certification);
    certificationChangeHistory.setCertificationType(
      CERTIFICATIONTYPEEntry.get(getDtls().certificationType));

    certificationChangeHistory.setCategory(
      CERTIFICATIONCATEGORYEntry.get(getDtls().category));
    certificationChangeHistory.setCreditsRequired(getDtls().creditsRequired);
    certificationChangeHistory.setCreditType(
      CREDITTYPEEntry.get(getDtls().creditType));
    certificationChangeHistory.setIssuedByAgency(getDtls().issuedByAgencyInd);
    certificationChangeHistory.setExternalIssuer(
      EXTERNALISSUEREntry.get(getDtls().externalIssuer));
    certificationChangeHistory.setOrganisationUnitId(
      getDtls().organisationUnitID);
    certificationChangeHistory.setValidityPeriod(getDtls().validityPeriod);
    certificationChangeHistory.setValidityPeriodUnits(
      VALIDITYPERIODUNITSEntry.get(getDtls().validityPeriodUnit));
    certificationChangeHistory.setDateTime(DateTime.getCurrentDateTime());

    try {
      certificationChangeHistory.setUser(
        systemUserObj.getUserDetails().userName);
    } catch (AppException e) {
      ValidationHelper.addValidationError(e);
    }

    certificationChangeHistory.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert certification event.
    insertEventDispatcherFactory.get(CertificationInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  public short getValidityPeriod() {
    return getDtls().validityPeriod;
  }

  /**
   * {@inheritDoc}
   */
  public void setValidityPeriod(short value) {
    getDtls().validityPeriod = value;
  }

  /**
   * {@inheritDoc}
   */
  public VALIDITYPERIODUNITSEntry getValidityPeriodUnits() {
    return VALIDITYPERIODUNITSEntry.get(getDtls().validityPeriodUnit);
  }

  /**
   * {@inheritDoc}
   */
  public void setValidityPeriodUnits(VALIDITYPERIODUNITSEntry value) {
    getDtls().validityPeriodUnit = value.getCode();

  }

  /**
   * Raises an event to impact the modification of the certification record
   *
   * @throws InformationalException
   * Generic Exception Signature.
   */
  // BEGIN, CR00177241, PM
  protected void eventForCertificationUpdate() throws InformationalException {
    // END, CR00177241

    final curam.util.events.struct.Event event = new curam.util.events.struct.Event();

    event.eventKey = PROVIDERMANAGEMENT.CERTIFICATIONUPDATED;
    event.primaryEventData = getID();

    try {
      EventService.raiseEvent(event);

    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }
  }

}
