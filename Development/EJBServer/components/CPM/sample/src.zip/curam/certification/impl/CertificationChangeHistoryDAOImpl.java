/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.certification.impl;


import java.util.ArrayList;
import java.util.List;

import com.google.inject.Singleton;

import curam.cpm.sl.entity.impl.CertificationChangeHistoryAdapter;
import curam.cpm.sl.entity.struct.CertificationChangeHistoryDtls;
import curam.cpm.sl.entity.struct.CertificationKey;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;


/**
 * Standard implementation of
 * {@linkplain curam.certification.impl.CertificationDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class CertificationChangeHistoryDAOImpl extends StandardDAOImpl<CertificationChangeHistory, CertificationChangeHistoryDtls>
  implements CertificationChangeHistoryDAO {
  // END, CR00183213

  /**
   * Single instance of the Certification Change History entity adapter shared
   * across all DAO implementations.
   */

  protected static final CertificationChangeHistoryAdapter adapter = new
    CertificationChangeHistoryAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected CertificationChangeHistoryDAOImpl() {
    // END, CR00183213
    super(adapter, CertificationChangeHistory.class);

  }

  /**
   * {@inheritDoc}
   */
  public List<CertificationChangeHistory> getCertificationHistory
    (CertificationKey key)
    throws AppException, InformationalException {

    List<CertificationChangeHistory> filteredList = new ArrayList<CertificationChangeHistory>();

    filteredList = newList(adapter.searchByCertificationID(key.certificationID));

    return filteredList;
  }

}

