/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.certification.impl;


import java.util.List;

import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain curam.certification.impl.Certification}.
 *
 */
@ImplementedBy(CertificationDAOImpl.class)
public interface CertificationDAO extends StandardDAO<Certification> {

  /**
   * Searches the list of of all the certifications for a agency.
   *
   * @return List<Certification> The Set of Certification details
   * that are active for a agency.
   *
   * @throws InformationalException Generic Exception Signature
   * @throws AppException Generic Exception Signature
   */
  public List<Certification> getCertifications()
    throws AppException, InformationalException;

  // BEGIN CR00121465 KR
  /**
   * Searches the list of of active certifications for a agency.
   *
   * @return Lists the Certification details
   * that are active for a agency.
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  public List<Certification> getActiveCertifications()
    throws AppException, InformationalException;
  // END CR00121465
}
