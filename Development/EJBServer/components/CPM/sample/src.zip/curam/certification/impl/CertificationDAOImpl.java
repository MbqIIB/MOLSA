/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.certification.impl;


import java.util.ArrayList;
import java.util.List;

import com.google.inject.Singleton;

import curam.cpm.sl.entity.impl.CertificationAdapter;
import curam.cpm.sl.entity.struct.CertificationDtls;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.persistence.helper.LifecycleHelper;
import curam.codetable.impl.RECORDSTATUSEntry;


/**
 * Standard implementation of
 * {@linkplain curam.certification.impl.CertificationDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class CertificationDAOImpl extends StandardDAOImpl<Certification, CertificationDtls> implements
  CertificationDAO {
  // END, CR00183213

  /**
   * Single instance of the Certification entity adapter shared across all DAO
   * implementations.
   */

  protected static final CertificationAdapter adapter = new
    CertificationAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected CertificationDAOImpl() {
    // END, CR00183213
    super(adapter, Certification.class);

  }

  // BEGIN CR00121465 KR
  /**
   * {@inheritDoc}
   */
  public List<Certification> getCertifications()
    throws AppException, InformationalException {

    List<Certification> filteredList = new ArrayList<Certification>();

    filteredList = newList(adapter.readAll());

    return filteredList;
  }

  /**
   * {@inheritDoc}
   */
  public List<Certification> getActiveCertifications()
    throws AppException, InformationalException {

    List<Certification> filteredList = new ArrayList<Certification>();

    LifecycleHelper.filter(newList(adapter.readAll()), RECORDSTATUSEntry.NORMAL,
      filteredList);

    return filteredList;
  }

  // END CR00121465
}
