/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.certification.impl;


import com.google.inject.ImplementedBy;

import curam.codetable.impl.CERTIFICATIONCATEGORYEntry;
import curam.codetable.impl.CERTIFICATIONTYPEEntry;
import curam.codetable.impl.CREDITTYPEEntry;
import curam.codetable.impl.EXTERNALISSUEREntry;
import curam.codetable.impl.VALIDITYPERIODUNITSEntry;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;


/**
 * Information about a certification that may be issued to provider
 * members/provider group members/unassigned provider members For example: level 1 Child
 * Care Certification is issued by the Alberta Child Care Services agency.
 */
@ImplementedBy(CertificationImpl.class)
public interface Certification extends CertificationAccessor, Insertable,
    OptimisticLockModifiable, LogicallyDeleteable {

  /**
   * Sets the category of the certification.
   *
   * @param certificationCategoryEntry
   * Contains the certification category.
   */
  public void setCategory(final CERTIFICATIONCATEGORYEntry
    certificationCategoryEntry);

  /**
   * Sets the type of the certification.
   *
   * @param certificationTypEntry
   * Contains the certification type.
   */
  public void setCertificationType(final CERTIFICATIONTYPEEntry
    certificationTypEntry);

  /**
   * Sets the user who created the certification.
   *
   * @param user
   * Contains the userName.
   */
  public void setUser(final String user);

  /**
   * Sets the credits required to be certified.
   *
   * @param creditsRequired
   * Contains the number of creditsRequired.
   */
  public void setCreditsRequired(final short creditsRequired);

  /**
   * Sets the type of the credit required to obtain the certification.
   *
   * @param creditTypEntry
   * Contains the type of the credit required.
   */
  public void setCreditType(final CREDITTYPEEntry creditTypEntry);

  /**
   * Sets the External Issuer, through whom the certification is being issued.
   *
   * @param externalIssuerEntry
   * Contains the External Issuer.
   */
  public void setExternalIssuer(final EXTERNALISSUEREntry externalIssuerEntry
    );

  /**
   * Sets the Indicator, which denotes whether the certification is issued by
   * the agency.
   *
   * @param issuedByAgencyInd
   * Contains the boolean value of indicator.
   */
  public void setIssuedByAgency(final boolean issuedByAgencyInd);

  /**
   * Sets the Organization Unit Id, through whom the certification is being
   * issued to the member.
   *
   * @param organisationunitId
   * Contains the Organization Unit Id.
   */
  public void setOrganisationUnitId(final long organisationunitId);

  /**
   * Sets the Validity Period for the certification.
   *
   * @param validityPeriod
   * Contains the validity period.
   */
  public void setValidityPeriod(final short validityPeriod);

  /**
   * Sets the Validity Period Units for the validity period of the
   * certification.
   *
   * @param validityPeriodUnitsEntry
   * Contains the validity period units
   */
  public void setValidityPeriodUnits(final VALIDITYPERIODUNITSEntry
    validityPeriodUnitsEntry);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the certification events functionality surrounding the insert
   * method.
   */
  public interface CertificationInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.certification.impl.Certification#insert}
     *
     * @param certification
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(CertificationAccessor certification)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.certification.impl.Certification#insert}
     *
     * @param certification
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(CertificationAccessor certification)
      throws InformationalException;
  }


  /**
   * Interface to the certification events functionality surrounding the modify
   * method.
   */
  public interface CertificationModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.certification.impl.Certification#modify}
     *
     * @param certification
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(CertificationAccessor certification, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.certification.impl.Certification#modify}
     *
     * @param certification
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(CertificationAccessor certification, Integer versionNo)
      throws InformationalException;
  }


  /**
   * Interface to the certification events functionality surrounding the cancel
   * method.
   */
  public interface CertificationCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.certification.impl.Certification#cancel}
     *
     * @param certification
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(CertificationAccessor certification, int versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.certification.impl.Certification#cancel}
     *
     * @param certification
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(CertificationAccessor certification, int versionNo)
      throws InformationalException;
  }
  // END, CR00144381
}
