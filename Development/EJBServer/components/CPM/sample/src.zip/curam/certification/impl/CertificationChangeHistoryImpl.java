/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.certification.impl;


import com.google.inject.Inject;
import curam.codetable.impl.CERTIFICATIONCATEGORYEntry;
import curam.codetable.impl.CERTIFICATIONTYPEEntry;
import curam.codetable.impl.CREDITTYPEEntry;
import curam.codetable.impl.EXTERNALISSUEREntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.codetable.impl.VALIDITYPERIODUNITSEntry;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.struct.CertificationChangeHistoryDtls;
import curam.message.impl.CERTIFICATIONExceptionCreator;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.DateTime;


/**
 * Standard implementation of
 * {@linkplain curam.certification.impl.CertificationChangeHistory}.
 */
// BEGIN, CR00183213, SS
public class CertificationChangeHistoryImpl extends SingleTableLogicallyDeleteableEntityImpl<CertificationChangeHistoryDtls>
  implements CertificationChangeHistory {
  // END, CR00183213
  /**
   * Certification DAO
   */

  @Inject
  protected CertificationDAO certificationDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected CertificationChangeHistoryImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213
  /**
   * {@inheritDoc}
   */
  public Certification getCertification() {

    final long certificationID = getDtls().certificationID;

    return certificationID == 0 ? null : certificationDAO.get(certificationID);
  }

  /**
   * {@inheritDoc}
   */
  public void setCertification(Certification value) {

    if (value != null) {
      getDtls().certificationID = value.getID();
    }

  }

  /**
   * {@inheritDoc}
   */
  public CERTIFICATIONCATEGORYEntry getCategory() {

    return CERTIFICATIONCATEGORYEntry.get(getDtls().category);
  }

  /**
   * {@inheritDoc}
   */
  public CERTIFICATIONTYPEEntry getCertificationType() {
    return CERTIFICATIONTYPEEntry.get(getDtls().certificationType);
  }

  /**
   * {@inheritDoc}
   */
  public short getCreditsRequired() {
    return getDtls().creditsRequired;
  }

  /**
   * {@inheritDoc}
   */
  public CREDITTYPEEntry getCreditType() {
    return CREDITTYPEEntry.get(getDtls().creditType);
  }

  /**
   * {@inheritDoc}
   */
  public EXTERNALISSUEREntry getExternalIssuer() {
    return EXTERNALISSUEREntry.get(getDtls().externalIssuer);
  }

  /**
   * {@inheritDoc}
   */
  public String getUser() {
    return getDtls().userName;
  }

  /**
   * {@inheritDoc}
   */
  public boolean isIssuedByAgency() {

    return getDtls().issuedByAgencyInd;
  }

  /**
   * {@inheritDoc}
   */
  public void setCategory(CERTIFICATIONCATEGORYEntry value) {
    getDtls().category = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setCertificationType(CERTIFICATIONTYPEEntry value) {
    getDtls().certificationType = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setCreditsRequired(short value) {
    getDtls().creditsRequired = value;

  }

  /**
   * {@inheritDoc}
   */
  public void setCreditType(CREDITTYPEEntry value) {
    getDtls().creditType = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setExternalIssuer(EXTERNALISSUEREntry value) {
    getDtls().externalIssuer = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setIssuedByAgency(boolean value) {
    getDtls().issuedByAgencyInd = value;

  }

  /**
   * {@inheritDoc}
   */
  public void setUser(String value) {
    getDtls().userName = value;

  }

  /**
   * {@inheritDoc}
   */
  public long getOrganisationUnitId() {

    return getDtls().organisationUnitID;
  }

  /**
   * {@inheritDoc}
   */
  public void setOrganisationUnitId(long value) {
    getDtls().organisationUnitID = value;

  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No such validations required currently
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No such validations required currently.
  }

  /**
   * Validates that all mandatory fields (as presented by the API) are
   * "populated".
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XRV_CERTIFICATION_TYPE_MUST_BE_ENTERED} -
   * If the certification type is not entered. </li>
   * <li>
   * {@link curam.message.CERTIFICATION#ERR_CERTIFICATION_XRV_CERTIFICATION_CATEGORY_MUST_BE_ENTERED} -
   * If the certification category is not entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {
    if (CPMConstants.kEmptyString.equals(getCertificationType())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_CERTIFICATION_TYPE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    if (CPMConstants.kEmptyString.equals(getCategory())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        CERTIFICATIONExceptionCreator.ERR_CERTIFICATION_XRV_CERTIFICATION_CATEGORY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancel(int versionNo) throws InformationalException {

    super.cancel(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public RECORDSTATUSEntry getLifecycleState() {

    return super.getLifecycleState();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    super.modify(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void setNewInstanceDefaults() {

    super.setNewInstanceDefaults();
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {

    super.insert();
  }

  /**
   * {@inheritDoc}
   */
  public short getValidityPeriod() {
    return getDtls().validityPeriod;
  }

  /**
   * {@inheritDoc}
   */
  public void setValidityPeriod(short value) {
    getDtls().validityPeriod = value;
  }

  /**
   * {@inheritDoc}
   */
  public VALIDITYPERIODUNITSEntry getValidityPeriodUnits() {
    return VALIDITYPERIODUNITSEntry.get(getDtls().validityPeriodUnit);
  }

  /**
   * {@inheritDoc}
   */
  public void setValidityPeriodUnits(VALIDITYPERIODUNITSEntry value) {
    getDtls().validityPeriodUnit = value.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public DateTime getDateTime() {
    return getDtls().dateTime;
  }

  /**
   * {@inheritDoc}
   */
  public void setDateTime(DateTime dateTime) {
    getDtls().dateTime = dateTime;
  }

}

