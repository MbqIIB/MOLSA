/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.characteristic.impl;


import java.util.Set;

import com.google.inject.Inject;

import curam.codetable.impl.CHARACTERISTICAPPLYTYPEEntry;
import curam.codetable.impl.CHARACTERISTICCATEGORYEntry;
import curam.codetable.impl.CHARACTERISTICTYPEEntry;
import curam.codetable.impl.CHARRELATEDTYPEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.struct.CharacteristicDtls;
import curam.util.exception.InformationalException;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;
import curam.util.type.DateRange;


/**
 * Standard implementation of
 * {@linkplain Characteristic}.
 */
public class CharacteristicImpl extends SingleTableLogicallyDeleteableEntityImpl<CharacteristicDtls> implements
  Characteristic {

  /**
   * Constructor for the class.
   */
  protected CharacteristicImpl() {// no-arg constructor for use only by Guice
  }

  /**
   * Reference to Characteristic Data Set;
   */
  protected Set<CharacteristicData> characteristicDataSet;

  /**
   * Reference to Characteristic Data DAO;
   */
  @Inject
  protected CharacteristicDataDAO characteristicDataDAO;

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancel(final int versionNo) throws InformationalException {
    setRecordStatus(RECORDSTATUSEntry.CANCELLED);
    super.cancel(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// no implementation required.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// no implementation required.
  }

  /**
   * {@inheritDoc}
   */
  public CHARACTERISTICAPPLYTYPEEntry getCharacteristicApplyType() {

    return CHARACTERISTICAPPLYTYPEEntry.get(getDtls().applyType);
  }

  /**
   * {@inheritDoc}
   */
  public CHARACTERISTICCATEGORYEntry getCharacteristicCategory() {

    return CHARACTERISTICCATEGORYEntry.get(getDtls().categoryCode);
  }

  /**
   * {@inheritDoc}
   */
  public CHARACTERISTICTYPEEntry getCharacteristicType() {

    return CHARACTERISTICTYPEEntry.get(getDtls().typeCode);
  }

  /**
   * {@inheritDoc}
   */
  public DateRange getDateRange() {

    return new DateRange(getDtls().startDate, getDtls().endDate);
  }

  /**
   * {@inheritDoc}
   */
  public Long getRelatedID() {
    return getDtls().relatedID;
  }

  /**
   * {@inheritDoc}
   */
  public CHARRELATEDTYPEEntry getRelatedType() {

    return CHARRELATEDTYPEEntry.get(getDtls().relatedType);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {
    setRecordStatus(RECORDSTATUSEntry.NORMAL);
    super.insert();
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// no implementation required.
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {
    super.modify(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void setCharacteristicApplyType(
    final CHARACTERISTICAPPLYTYPEEntry characteristicApplyType) {
    getDtls().applyType = characteristicApplyType.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setCharacteristicCategory(
    final CHARACTERISTICCATEGORYEntry characteristicCategoryType) {
    getDtls().categoryCode = characteristicCategoryType.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setCharacteristicType(
    final CHARACTERISTICTYPEEntry characteristicType) {
    getDtls().typeCode = characteristicType.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setDateRange(final DateRange dateRange) {
    getDtls().startDate = dateRange.start();
    getDtls().endDate = dateRange.end();
  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedID(final Long relatedID) {
    getDtls().relatedID = relatedID;

  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedType(
    final CHARRELATEDTYPEEntry characteristicRelatedType) {
    getDtls().relatedType = characteristicRelatedType.getCode();

  }

  /**
   * Sets the record status to of the Characteristic.
   *
   * @param recordStatus
   * Record Status value like NORMAL, CANCELLED etc.
   */
  protected void setRecordStatus(final RECORDSTATUSEntry recordStatus) {
    getDtls().recordStatus = recordStatus.getCode();
  }

  /**
   * Lists the characteristic data for given characteristic.
   *
   * @return List of characteristic data.
   */
  public Set<CharacteristicData> listCharacteristicData() {

    if (null == characteristicDataSet) {
      return characteristicDataDAO.searchByCharacteristic(this);
    }
    return characteristicDataSet;
  }
}
