/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.characteristic.impl;


import curam.codetable.impl.CHARACTERISTICCATEGORYEntry;
import curam.codetable.impl.CHARACTERISTICTYPEEntry;
import curam.codetable.impl.CHARRELATEDTYPEEntry;
import curam.place.impl.CompartmentAccessor;
import curam.util.persistence.StandardEntity;


/**
 * Accessor interface for
 * {@linkplain DerivedComponentCharacteristic}.
 *
 */
public interface DerivedComponentCharacteristicAccessor extends StandardEntity {

  /**
   * Gets the Characteristic Category type. Characteristic Category type contains
   * values of code table names like Gender, Religion etc.
   *
   * @return The Characteristic Category type.
   */
  CHARACTERISTICCATEGORYEntry getCharacteristicCategory();

  /**
   * Gets the Characteristic code of the Derived Compartment Characteristic.
   * <p>
   * For a "Religion" code table, values like "Christian", "Hindu". For a
   * "Gender" code table, values like "Male", "Female".
   *
   * @return Characteristic code of the Derived Compartment Characteristic.
   */
  String getCharacteristicCode();

  /**
   * Gets the Characteristic Type.
   * <P>
   * Characteristic Type can have values like Code Table, Range, Numeric, etc.
   * Again each Characteristic Type can have following values
   * <li> Code Table: Gender, Race, Bed Type (of a Place) etc. Range: Age Range
   * (numeric)</li>
   * <li> Numeric: Rating of the compartment by the Agency or by external
   * agencies.</li>
   * <li> ID: ID of the related record, where the category references another
   * database table, such as Service (Provider Offering).</li>
   * </P>
   *
   * @return The Characteristic Type.
   */
  CHARACTERISTICTYPEEntry getCharacteristicType();

  // BEGIN, CR00273068, SS
  /**
   * Gets the Characteristic Value of the Derived Compartment Characteristic.
   * <p>
   * For example,numeric value associated with that compartment like rating by
   * the agency.
   *
   * @return Characteristic Value of the Derived Compartment Characteristic.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link #getCharacteristicValue()}
   * As part of including search on characteristic,
   * and correcting spelling on methods for characteristic. See
   * release note: CR00273068.
   */
  @Deprecated
  Double getCharactersticValue();
  // END, CR00273068

  /**
   * Gets the accessor of Compartment to which the Characteristic is associated
   * to.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return Compartment ID of Compartment.
   */
  CompartmentAccessor getCompartment();

  /**
   * Gets the ID of related Object.For example ID of a Placement or a
   * Reservation.
   *
   * @return ID of related Object.
   */

  Long getRelatedID();

  /**
   * Gets the Characteristic Related Type.
   * <P>
   * Characteristic Related Type can have values like Compartment, Place etc.
   * </P>
   *
   * @return Characteristic Related Type value.
   */
  CHARRELATEDTYPEEntry getRelatedType();

  /**
   * Gets the Characteristic Value of the Derived Compartment Characteristic.
   * <p>
   * For example,numeric value associated with that compartment like rating by
   * the agency.
   *
   * @return Characteristic Value of the Derived Compartment Characteristic.
   */
  Double getCharacteristicValue();

}
