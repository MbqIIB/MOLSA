/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.characteristic.impl;


import com.google.inject.Inject;

import curam.cpm.sl.struct.CharacteristicDataDtls;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.SingleTableLogicallyDeleteableEntityImpl;


/**
 * Standard implementation of
 * {@linkplain CharacteristicData}.
 */
 
public class CharacteristicDataImpl extends SingleTableLogicallyDeleteableEntityImpl<CharacteristicDataDtls> implements  
  CharacteristicData {

  /**
   * Reference to the CharacteristicDAO instance.
   */
  @Inject
  protected CharacteristicDAO characteristicDAO;

  /**
   * Constructor for this class.
   */
  protected CharacteristicDataImpl() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void cancel(final int versionNo) throws InformationalException {
    super.cancel(versionNo);
  }

  /**
   * {@inheritDoc}
   */

  public void crossEntityValidation() {// no implementation required.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// no implementation required.
  }

  // BEGIN, CR00273068, SS
  /**
   * {@inheritDoc}
   */
  public CharacteristicAccessor getCharacteristic() {
    final long characteristicID = getDtls().characteristicID;

    if (0 == characteristicID) {
      return null;
    }

    return characteristicDAO.get(characteristicID);

  }

  /**
   * {@inheritDoc}
   */
   
  @Deprecated
  public Double getCharactersticDataMaximumValue() {

    return getDtls().maxValue;
  }

  /**
   * {@inheritDoc}
   */
  @Deprecated
  public Double getCharactersticDataMinumumValue() {

    return getDtls().minValue;
  }

  /**
   * {@inheritDoc}
   */
  @Deprecated
  public String getCharactesticDataValue() {

    return getDtls().value;
  }

  // END, CR00273068

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {
    super.insert();
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// no implementation required.
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {
    super.modify(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void setCharacteristic(final Characteristic characteristic) {
    getDtls().characteristicID = characteristic.getID();

  }

  /**
   * {@inheritDoc}
   */
  @Deprecated
  public void setCharactersticDataMaximumValue(
    final Double charDataMaximumValue) {

    getDtls().maxValue = charDataMaximumValue;
  }

  /**
   * {@inheritDoc}
   */
  @Deprecated
  public void setCharactersticDataMinumumValue(
    final Double charDataMinimumValue) {

    getDtls().minValue = charDataMinimumValue;
  }

  /**
   * {@inheritDoc}
   */
  @Deprecated
  public void setCharactesticDataValue(final String charDataValue) {
    getDtls().value = charDataValue;

  }

  /**
   * {@inheritDoc}
   */
  public Double getCharacteristicDataMaximumValue() {

    return getDtls().maxValue;
  }

  /**
   * {@inheritDoc}
   */
  public Double getCharacteristicDataMinumumValue() {

    return getDtls().minValue;
  }

  /**
   * {@inheritDoc}
   */
  public String getCharacteristicDataValue() {

    return getDtls().value;
  }

  /**
   * {@inheritDoc}
   */
  public void setCharacteristicDataMaximumValue(
    final Double charDataMaximumValue) {

    getDtls().maxValue = charDataMaximumValue;
  }

  /**
   * {@inheritDoc}
   */
  public void setCharacteristicDataMinumumValue(
    final Double charDataMinimumValue) {

    getDtls().minValue = charDataMinimumValue;
  }

  /**
   * {@inheritDoc}
   */
  public void setCharacteristicDataValue(final String charDataValue) {
    getDtls().value = charDataValue;
  }

}
