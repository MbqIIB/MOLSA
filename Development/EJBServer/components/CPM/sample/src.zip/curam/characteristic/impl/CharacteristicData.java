/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.characteristic.impl;


import com.google.inject.ImplementedBy;

import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.OptimisticLockRemovable;
import curam.util.persistence.helper.LogicallyDeleteable;


/**
 * Service layer class having API for managing Characteristics Data which are
 * manually administered with explicit configuration.
 *
 * For example, for a category "code-table" there could be multiple values for
 * language characteristic such as English, Spanish, French etc. This language
 * characteristic can, then, be associated to a compartment with the applicable
 * value, A compartment may have one or more languages associated to it to say,
 * for example, only English and Spanish speaking people must be placed in that
 * compartment.
 */
@ImplementedBy(CharacteristicDataImpl.class)
public interface CharacteristicData extends CharacteristicDataAccessor,
    Insertable, LogicallyDeleteable, OptimisticLockModifiable,
    OptimisticLockRemovable {

  /**
   * Sets the Characteristic reference to the CharactersticData.
   *
   * @param characteristic
   * Reference to the Characteristic instance.
   */
  void setCharacteristic(final Characteristic characteristic);

  /**
   * Sets the CharactersticData Value based on the Characteristic.typeCode
   * value.
   * <p>
   * If Characteristic.typeCode is "CodeTable" then the value will be the Code
   * from the sub category code. For example, if the code selected is "Gender",
   * then the values will be "Male" or "Female".
   * <p>
   * If Characteristics.typeCode is "Numeric", then the value will be numeric,
   * but converted into string.
   * <p>
   * If Characteristics.typeCode is "Range" then the value will be null
   *
   * @param charDataValue
   * Value of the CharactersticData.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link CharacteristicData#setCharacteristicDataValue(String)}. As part
   * of including search on characteristic, characteristic and
   * correcting spelling on methods for characteristic. See release
   * note: CR00236659.
   */
  @Deprecated
  void setCharactesticDataValue(final String charDataValue);

  /**
   * Sets the End value of the range for a CharactersticData.
   *
   * For example, maximum age of a client that can be placed in this
   * compartment.
   *
   * @param charDataMaximumValue
   * CharactersticData End value range.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link CharacteristicData#setCharacteristicDataMaximumValue(Double)}.
   * As part of including search on characteristic, characteristic
   * and correcting spelling on methods for characteristic. See
   * release note: CR00236659.
   */
  @Deprecated
  void setCharactersticDataMaximumValue(final Double charDataMaximumValue);

  /**
   * Sets the start value of the range for a CharactersticData.
   *
   * For example, minimum age of a client that can be placed in this
   * compartment.
   *
   * @param charDataMinimumValue
   * CharactersticData start value range.
   *
   * @deprecated Since Curam 6.0, replaced with
   * {@link CharacteristicData#setCharacteristicDataMinumumValue(Double)}.
   * As part of including search on characteristic, characteristic
   * and correcting spelling on methods for characteristic. See
   * release note: CR00236659.
   */
  @Deprecated
  void setCharactersticDataMinumumValue(final Double charDataMinimumValue);

  /**
   * Sets the CharactersticData Value based on the Characteristic.typeCode
   * value.
   * <p>
   * If Characteristic.typeCode is "CodeTable" then the value will be the Code
   * from the sub category code. For example, if the code selected is "Gender",
   * then the values will be "Male" or "Female".
   * <p>
   * If Characteristics.typeCode is "Numeric", then the value will be numeric,
   * but converted into string.
   * <p>
   * If Characteristics.typeCode is "Range" then the value will be null
   *
   * @param charDataValue
   * Value of the CharactersticData.
   */
  void setCharacteristicDataValue(final String charDataValue);

  /**
   * Sets the End value of the range for a CharactersticData.
   *
   * For example, maximum age of a client that can be placed in this
   * compartment.
   *
   * @param charDataMaximumValue
   * CharacteristicData End value range.
   */
  void setCharacteristicDataMaximumValue(final Double charDataMaximumValue);

  /**
   * Sets the start value of the range for a CharactersticData.
   *
   * For example, minimum age of a client that can be placed in this
   * compartment.
   *
   * @param charDataMinimumValue
   * CharacteristicData start value range.
   */
  void setCharacteristicDataMinumumValue(final Double charDataMinimumValue);

}
