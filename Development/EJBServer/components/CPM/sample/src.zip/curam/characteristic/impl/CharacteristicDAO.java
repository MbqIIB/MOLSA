/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.characteristic.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.cpm.sl.struct.RelatedIDAndType;
import curam.util.persistence.StandardDAO;


/**
 * Data access for {@linkplain Characteristic}.
 */
@ImplementedBy(CharacteristicDAOImpl.class)
public interface CharacteristicDAO extends StandardDAO<Characteristic> {

  /**
   * Searches the list of characteristic for given related id and related type.
   *
   * @param relatedIDAndType
   * Related id and related type details.
   *
   * @return List of characteristic.
   */
  public Set<Characteristic> searchByRelatedIDAndType(
    final RelatedIDAndType relatedIDAndType);

}
