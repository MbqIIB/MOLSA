/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.characteristic.impl;


import com.google.inject.ImplementedBy;

import curam.codetable.impl.CHARACTERISTICAPPLYTYPEEntry;
import curam.codetable.impl.CHARACTERISTICCATEGORYEntry;
import curam.codetable.impl.CHARACTERISTICTYPEEntry;
import curam.codetable.impl.CHARRELATEDTYPEEntry;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.OptimisticLockRemovable;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateRange;


/**
 * Service layer class having API for managing Characteristics which are
 * manually administered with explicit configuration.
 * <p>
 * For example, A placement service involves placing a client physically with
 * the provider for a period of time. Depending on the placement service the
 * placement may be to a bed in a foster home, a room in a women's shelter or a
 * cell in a juvenile detention unit. Within a provider facility, the smaller
 * units such as beds may be logically grouped into compartments. This allows
 * more accurate tracking of placements and allows for setting up
 * characteristics for these units. Thus a compartment may contain child
 * compartments and/or a group of places for a provider.
 * <p>
 * When an explicit characteristic is added to a compartment by a User, a record
 * is created in the Characteristics table.
 */
@ImplementedBy(CharacteristicImpl.class)
public interface Characteristic extends CharacteristicAccessor, Insertable,
    LogicallyDeleteable, OptimisticLockModifiable, OptimisticLockRemovable {

  /**
   * Sets the Characteristic apply type.
   * <p>
   * By default, it have values like "Same Type Only", "Different Type Only".
   * "Different Type Only" should be interpreted as e.g. "Not in this age
   * range", "Not this numeric value", "Not this gender", etc.
   *
   *
   * @param characteristicApplyType
   * Characteristic apply type.
   */
  void setCharacteristicApplyType(
    final CHARACTERISTICAPPLYTYPEEntry characteristicApplyType);

  /**
   * Sets the Characteristic category. Category depends upon the value of
   * Characteristic type.
   * <li>If Characteristic type is code table, the category corresponds to code
   * table names</li>
   * <li>if Characteristic type is ID, the category corresponds to table name</li>
   * By default, it have Gender, Religion,Service, Gang Affiliation etc.
   *
   * @param characteristicCategoryType
   * The Characteristic category code table value.
   */
  void setCharacteristicCategory(
    final CHARACTERISTICCATEGORYEntry characteristicCategoryType);

  /**
   * Sets the Characteristic Type.By default, it have values like Code Table,
   * Range, Numeric, etc.
   *
   * @param characteristicType
   * Characteristic Type code table value.
   */
  void setCharacteristicType(final CHARACTERISTICTYPEEntry characteristicType);

  /**
   * Sets the the Start Date from when the Placement Characteristic can be used
   * to allocate places to clients within a compartment and Last date until when
   * the placement characteristics can be used to allocate places to clients
   * within a compartment.
   *
   * @param dateRange
   * The Start Date and End Date of Characteristics.
   */
  void setDateRange(final DateRange dateRange);

  /**
   * Sets the ID of the related object like Compartment or the Place for which
   * this characteristic is configured.
   *
   * @param relatedID
   * ID of the related object like Compartment or the Place.
   */
  void setRelatedID(final Long relatedID);

  /**
   * Sets the Characteristic Related Type.By default, the Characteristic Related
   * Type have values like Compartment, Place etc.
   *
   * @param characteristicRelatedType
   * Characteristic Related Type code table value.
   */
  void setRelatedType(final CHARRELATEDTYPEEntry characteristicRelatedType);

}
