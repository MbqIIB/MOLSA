/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.characteristic.impl;


import com.google.inject.ImplementedBy;

import curam.codetable.impl.CHARACTERISTICCATEGORYEntry;
import curam.codetable.impl.CHARACTERISTICTYPEEntry;
import curam.codetable.impl.CHARRELATEDTYPEEntry;
import curam.place.impl.Compartment;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.OptimisticLockRemovable;
import curam.util.persistence.helper.LogicallyDeleteable;


/**
 * Service layer class having API for managing characteristics which are
 * implicitly derived based on the current occupant.
 * <p>
 * For example, A placement service involves placing a client physically with
 * the provider for a period of time. Depending on the placement service the
 * placement may be to a bed in a foster home, a room in a women's shelter or a
 * cell in a juvenile detention unit. Within a provider facility, the smaller
 * units such as beds may be logically grouped into compartments. This allows
 * more accurate tracking of placements and allows for setting up
 * characteristics for these units. Thus a compartment may contain child
 * compartments and/or a group of places for a provider.
 * <p>
 * When an implicitly derived characteristic is added to a compartment by a
 * Resource Manager, a record is created at that point in the Characteristic
 * table only, for the relevant characteristic category, e.g. Gender, Religion.
 * This record will have an Apply Type to indicate the desired behavior when a
 * second client is to be placed in the compartment.
 * <p>
 * When a client is placed into an empty compartment with such a record
 * associated with it, a record is at that point created in the
 * DerivedCompartmentCharacteristic table. This record will store the value for
 * the client of the relevant characteristic category. For example, if the
 * category for the compartment is Gender, and the client being placed is male,
 * then a record will be created with a characteristic code of "Male".
 */
// BEGIN, CR00273068,SS
@ImplementedBy(DerivedComponentCharacteristicImpl.class)
public interface DerivedComponentCharacteristic extends
    DerivedComponentCharacteristicAccessor, Insertable, 
    OptimisticLockModifiable, OptimisticLockRemovable {
  // END ,CR00273068

  /**
   * Sets the Characteristic Category type.
   * <p>
   * Characteristic Category type contains values of code table names like
   * Gender, Religion etc.
   *
   * @param charCategoryType
   * The Characteristic Category type.
   */
  void setCharacteristicCategory(
    final CHARACTERISTICCATEGORYEntry charCategoryType);

  /**
   * Sets the Characteristic code of the Derived Compartment Characteristic.
   * <p>
   * For a "Religion" code table, values like "Christian", "Hindu". For a
   * "Gender" code table, values like "Male", "Female".
   *
   * @param characteristicCode
   * The Derived Compartment Characteristic.
   */

  void setCharacteristicCode(final String characteristicCode);

  /**
   * Sets the Characteristic Type.
   * <p>
   * Characteristic Type can have values like Code Table, Numeric, etc. For
   * example
   * <li> Code Table: Gender, Race etc.</li>
   * <li> Numeric: Age etc.</li>
   *
   * @param charType
   * The Characteristic Type.
   */
  void setCharacteristicType(final CHARACTERISTICTYPEEntry charType);

  /**
   * Sets the Characteristic Value of the Derived Compartment Characteristic.
   * <p>
   * For example,numeric value associated with that compartment like age of the
   * client.
   *
   * @param charactersticValue
   * Characteristic Value of the Derived Compartment Characteristic.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link DerivedComponentCharacteristic#setCharacteristicValue(Double)}.
   * As part of correcting spelling on methods for characteristic. See
   * release note: CR00273068.
   */
  @Deprecated
  void setCharactersticValue(final Double charactersticValue);

  /**
   * Sets the Compartment associated to the Compartment.
   *
   * @param compartment
   * The Reference to the Compartment.
   */
  void setCompartment(final Compartment compartment);

  /**
   * Sets the ID of related Object.For example ID of a Placement or a
   * Reservation.
   *
   * @param relatedID
   * ID of related Object.
   */

  void setRelatedID(final Long relatedID);

  /**
   * Sets the Characteristic Related Type.
   * <p>
   * Characteristic Related Type can have values like Compartment, Place etc.
   *
   * @param charReletedType
   * Characteristic Related Type value.
   */
  void setRelatedType(final CHARRELATEDTYPEEntry charReletedType);

  /**
   * Sets the Characteristic Value of the Derived Compartment Characteristic.
   * <p>
   * For example,numeric value associated with that compartment like age of
   * the client.
   *
   * @param characteristicValue
   * Characteristic Value of the Derived Compartment
   * Characteristic.
   */
  void setCharacteristicValue(final Double characteristicValue);

}
