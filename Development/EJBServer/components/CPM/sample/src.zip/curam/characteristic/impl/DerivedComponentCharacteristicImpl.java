/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.characteristic.impl;


import com.google.inject.Inject;

import curam.codetable.impl.CHARACTERISTICCATEGORYEntry;
import curam.codetable.impl.CHARACTERISTICTYPEEntry;
import curam.codetable.impl.CHARRELATEDTYPEEntry;
import curam.cpm.sl.struct.DerivedCompCharacteristicDtls;
import curam.place.impl.Compartment;
import curam.place.impl.CompartmentAccessor;
import curam.place.impl.CompartmentDAO;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Standard implementation of {@linkplain DerivedComponentCharacteristic}.
 */
// BEGIN, CR00273068, SS
public class DerivedComponentCharacteristicImpl extends SingleTableEntityImpl<DerivedCompCharacteristicDtls> implements
  DerivedComponentCharacteristic {
  // END, CR00273068
  
  /**
   * Reference to the CompartmentDAO instance.
   */
  @Inject
  protected CompartmentDAO compartmentDAO;

  /**
   * Constructor for the class.
   */
  protected DerivedComponentCharacteristicImpl() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// no implementation required.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// no implementation required.
  }

  /**
   * {@inheritDoc}
   */
  public CHARACTERISTICCATEGORYEntry getCharacteristicCategory() {

    return CHARACTERISTICCATEGORYEntry.get(getDtls().characteristicCategory);
  }

  /**
   * {@inheritDoc}
   */
  public String getCharacteristicCode() {

    return getDtls().characteristicCode;
  }

  /**
   * {@inheritDoc}
   */
  public CHARACTERISTICTYPEEntry getCharacteristicType() {

    return CHARACTERISTICTYPEEntry.get(getDtls().typeCode);
  }

  // BEGIN, CR00273068, SS
  /**
   * {@inheritDoc}
   */
  @Deprecated
  public Double getCharactersticValue() {

    return getDtls().value;
  }

  // END, CR00273068

  /**
   * {@inheritDoc}
   */
  public CompartmentAccessor getCompartment() {
    final long compartmentID = getDtls().compartmentID;

    if (compartmentID == 0) {
      return null;
    }
    return compartmentDAO.get(compartmentID);

  }

  /**
   * {@inheritDoc}
   */
  public Long getRelatedID() {

    return getDtls().relatedID;
  }

  /**
   * {@inheritDoc}
   */
  public CHARRELATEDTYPEEntry getRelatedType() {

    return CHARRELATEDTYPEEntry.get(getDtls().relatedType);
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void insert() throws InformationalException {
    super.insert();
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// no implementation required.
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void modify(final Integer versionNo) throws InformationalException {
    super.modify(versionNo);
  }

  /**
   * {@inheritDoc}
   */
  public void setCharacteristicCategory(
    final CHARACTERISTICCATEGORYEntry charCategoryType) {
    getDtls().characteristicCategory = charCategoryType.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public void setCharacteristicCode(final String characteristicCode) {
    getDtls().characteristicCode = characteristicCode;

  }

  /**
   * {@inheritDoc}
   */
  public void setCharacteristicType(final CHARACTERISTICTYPEEntry charType) {
    getDtls().typeCode = charType.getCode();

  }

  /**
   * {@inheritDoc}
   */
  @Deprecated
  public void setCharactersticValue(final Double charactersticValue) {
    getDtls().value = charactersticValue;

  }

  /**
   * {@inheritDoc}
   */
  public void setCompartment(final Compartment compartment) {
    getDtls().compartmentID = compartment.getID();

  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedID(final Long relatedID) {

    getDtls().relatedID = relatedID;
  }

  /**
   * {@inheritDoc}
   */
  public void setRelatedType(final CHARRELATEDTYPEEntry charReletedType) {
    getDtls().relatedType = charReletedType.getCode();

  }

  /**
   * {@inheritDoc}
   */
  public Double getCharacteristicValue() {
    return getDtls().value;
  }

  /**
   * {@inheritDoc}
   */
  public void setCharacteristicValue(final Double characteristicValue) {
    getDtls().value = characteristicValue;

  }
  
  // BEGIN, CR00273068, SS
  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// No default values are required to be set.
  }
  // END, CR00273068

}
