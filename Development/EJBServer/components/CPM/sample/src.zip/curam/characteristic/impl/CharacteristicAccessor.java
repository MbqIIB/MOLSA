/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.characteristic.impl;


import java.util.Set;

import curam.codetable.impl.CHARACTERISTICAPPLYTYPEEntry;
import curam.codetable.impl.CHARACTERISTICCATEGORYEntry;
import curam.codetable.impl.CHARACTERISTICTYPEEntry;
import curam.codetable.impl.CHARRELATEDTYPEEntry;
import curam.util.persistence.StandardEntity;
import curam.util.type.DateRange;


/**
 * Accessor interface for {@linkplain Characteristic}.
 *
 */
public interface CharacteristicAccessor extends StandardEntity {

  /**
   * Gets the Characteristic apply type.
   * <p>
   * By default, it have values like "Same Type Only", "Different Type Only".
   * "Different Type Only" should be interpreted as e.g. "Not in this age
   * range", "Not this numeric value", "Not this gender", etc. This attribute is
   * only relevant for implicitly derived characteristics.
   *
   *
   * @return The Characteristic apply type.
   */
  CHARACTERISTICAPPLYTYPEEntry getCharacteristicApplyType();

  /**
   * Gets the Characteristic Category type.Characteristic category. Category
   * depends upon the value of Characteristic type.
   * <li>If Characteristic type is code table, the category corresponds to code
   * table names</li>
   * <li>if Characteristic type is ID, the category corresponds to table name</li>
   * By default, it have Gender, Religion,Service, Gang Affiliation etc.
   *
   * @return The Characteristic Category type.
   */
  CHARACTERISTICCATEGORYEntry getCharacteristicCategory();

  /**
   * Gets the Characteristic Type.
   * <p>
   * Characteristic Type can have values like Code Table, Range, Numeric, etc.
   * For example:
   * <li> Code Table: Gender, Race, Bed Type (of a Place) etc. </li>
   * <li> Range: Age Range (numeric value pair)</li>
   * <li> Numeric: Rating of the compartment by the Agency or by external
   * agencies.</li>
   * <li> ID: ID of the related record, where the category references another
   * database table, such as Service (Provider Offering).</li>
   *
   * @return The Characteristic Type.
   */
  CHARACTERISTICTYPEEntry getCharacteristicType();

  /**
   * Gets the Start Date from when the Placement Characteristics can be used to
   * allocate places to clients within a compartment and Last date until when the
   * placement characteristics can be used to allocate places to clients within
   * a compartment.
   *
   * @return The Start Date and End Date of Characteristics.
   */

  DateRange getDateRange();

  /**
   * Gets the ID of the related object like Compartment or the Place for which
   * this characteristic is configured.
   *
   * @return ID of the Compartment or the Place
   */
  Long getRelatedID();

  /**
   * Gets the Characteristic Related Type.
   * <p>
   * Characteristic Related Type can have values like Compartment, Place etc.
   *
   * @return Characteristic Related Type value.
   */
  CHARRELATEDTYPEEntry getRelatedType();

  /**
   * Lists the characteristic data for given characteristic.
   *
   * @return List of characteristic data.
   */
  Set<CharacteristicData> listCharacteristicData();

}
