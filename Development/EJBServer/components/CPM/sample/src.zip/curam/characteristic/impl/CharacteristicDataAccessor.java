/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.characteristic.impl;


import curam.util.persistence.StandardEntity;


/**
 * Accessor interface for {@linkplain CharacteristicDataAccessor}.
 *
 */
public interface CharacteristicDataAccessor extends StandardEntity {

  /**
   * Gets the accessor of Characteristic to which the CharacteristicData is
   * associated to.
   * <p>
   * The returned objects are intentionally accessor-only. Calling code must not
   * attempt to cast any of these objects to its mutator interface, nor use the
   * object's ID to re-retrieve a mutable instance from the database.
   *
   * @return Characteristic ID of Characteristic.
   */
  CharacteristicAccessor getCharacteristic();

  // BEGIN, CR00273068, SS
  /**
   * Gets the CharactersticData Value based on the Characteristic.typeCodes.
   * <p>
   * If Characteristic.typeCode is "CodeTable" then the value will be the Code
   * from the sub category code. For example, if the code selected is "Gender",
   * then the values will be "Male" or "Female".
   * <p>
   * If Characteristics.typeCode is "Numeric", then the value will be numeric,
   * but converted into string.
   * <p>
   * If Characteristics.typeCode is "Range" then the value will be null
   *
   * @return CharactersticData Value associated with Characteristic.
   *
   * @deprecated Since Curam 6.0 SP2, This method is replaced by
   * {@link #getCharacteristicDataValue()} As part of correcting
   * spelling on methods for characteristic. See release note:
   * CR00273068.
   */
  @Deprecated
  String getCharactesticDataValue();

  /**
   * Gets the start value of the range for a CharactersticData.
   *
   * For example, minimum age of a client that can be placed in this
   * compartment.
   *
   * @return CharactersticData start value range.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link #getCharacteristicDataMinumumValue()} As part of
   * correcting spelling on methods for characteristic. See release
   * note: CR00273068.
   */
  @Deprecated
  Double getCharactersticDataMinumumValue();

  /**
   * Gets the End value of the range for a CharactersticData.
   *
   * For example, maximum age of a client that can be placed in this
   * compartment.
   *
   * @return CharactersticData End value range.
   *
   * @deprecated Since Curam 6.0 SP2, replaced with
   * {@link #getCharacteristicDataMaximumValue()} As part of
   * correcting spelling on methods for characteristic. See release
   * note: CR00273068.
   */
  @Deprecated
  Double getCharactersticDataMaximumValue();

  // END, CR00273068

  /**
   * Gets the CharactersticData Value based on the Characteristic.typeCodes.
   * <p>
   * If Characteristic.typeCode is "CodeTable" then the value will be the Code
   * from the sub category code. For example, if the code selected is "Gender",
   * then the values will be "Male" or "Female".
   * <p>
   * If Characteristics.typeCode is "Numeric", then the value will be numeric,
   * but converted into string.
   * <p>
   * If Characteristics.typeCode is "Range" then the value will be null
   *
   * @return CharactersticData Value associated with Characteristic.
   */
  String getCharacteristicDataValue();

  /**
   * Gets the start value of the range for a CharactersticData.
   *
   * For example, minimum age of a client that can be placed in this
   * compartment.
   *
   * @return CharactersticData start value range.
   */
  Double getCharacteristicDataMinumumValue();

  /**
   * Gets the End value of the range for a CharactersticData.
   *
   * For example, maximum age of a client that can be placed in this
   * compartment.
   *
   * @return CharactersticData End value range.
   */
  Double getCharacteristicDataMaximumValue();

}
