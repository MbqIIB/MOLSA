/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.localization.translation.facade.impl;


import java.util.List;

import com.google.inject.Inject;

import curam.codetable.impl.LOCALEEntry;
import curam.localization.translation.facade.struct.LocalizableTextTranslationDetails;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.ValidationHelper;
import curam.util.resources.StringUtil;
import curam.util.type.StringHelper;
import curam.workspaceservices.facade.struct.TextTranslationDetails;
import curam.workspaceservices.facade.struct.ViewLocalizableTextDetails;
import curam.workspaceservices.localization.impl.LocalizableTextHandler;
import curam.workspaceservices.localization.impl.LocalizableTextHandlerDAO;
import curam.workspaceservices.localization.impl.TextTranslation;
import curam.workspaceservices.localization.impl.TextTranslationDAO;
import curam.workspaceservices.message.impl.LOCALIZABLETEXTExceptionCreator;


/**
 * Facade layer class having API's for managing generic text translation and
 * related functionality.
 */
public abstract class MaintainSearchableTextTranslation extends curam.localization.translation.facade.base.MaintainSearchableTextTranslation {

  /**
   * Reference to localizable text handler DAO.
   */
  @Inject
  protected LocalizableTextHandlerDAO localizableTextHandlerDAO;

  /**
   * Reference to text translation DAO.
   */
  @Inject
  protected TextTranslationDAO textTranslationDAO;

  /**
   * Constructor to be used by Guice.
   */
  public MaintainSearchableTextTranslation() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * Creates a text translation for the service offering attribute, description.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details.
   *
   * @return The localisable text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public LocalizableTextTranslationDetails addTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    LocalizableTextTranslationDetails result = new LocalizableTextTranslationDetails();
    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
      localizableTextTranslationDetails.localizableTextID);
    String text;

    text = localizableTextTranslationDetails.text;

    validateTextEntered(text);
    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.addValue(text,
      LOCALEEntry.get(localizableTextTranslationDetails.localeCode));

    validateNoTranslationsForLocale(localizableTextHandler,
      localizableTextTranslationDetails.localeCode);

    result.localizableTextID = localizableTextHandler.store();

    return result;
  }

  /**
   * Modifies the text translation for the localizable text.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public void modifyTextTranslation(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
      localizableTextTranslationDetails.localizableTextID);

    String text;

    text = localizableTextTranslationDetails.text;

    validateTextEntered(text);
    localizableTextHandler.setShortTextInd(true);
    localizableTextHandler.addValue(text,
      LOCALEEntry.get(localizableTextTranslationDetails.localeCode));

    localizableTextHandler.store();

  }

  /**
   * Reads the text translation details.
   *
   * @param localizableNameTextTranslationDetails
   * The localizable text translation details.
   *
   * @return The text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public TextTranslationDetails readTextTranslation(
    final LocalizableTextTranslationDetails localizableNameTextTranslationDetails)
    throws AppException, InformationalException {
    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    TextTranslation textTranslation = textTranslationDAO.get(
      localizableNameTextTranslationDetails.textTranslationID);

    textTranslationDetails = assignTextTranslationDetails(textTranslation);

    return textTranslationDetails;

  }

  /**
   * Views the text translation for the localizable text.
   *
   * @param localizableTextTranslationDetails
   * The localizable text translation details.
   *
   * @return The text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  public ViewLocalizableTextDetails viewLocalizableText(
    final LocalizableTextTranslationDetails localizableTextTranslationDetails)
    throws AppException, InformationalException {

    LocalizableTextHandler localizableTextHandler = localizableTextHandlerDAO.get(
      localizableTextTranslationDetails.localizableTextID);
    ViewLocalizableTextDetails viewLocalizableTextDetails = new ViewLocalizableTextDetails();

    viewLocalizableTextDetails.defaultText = localizableTextHandler.getValue();
    viewLocalizableTextDetails.dtls.localizableTextID = localizableTextHandler.getID();
    viewLocalizableTextDetails.dtls.versionNo = localizableTextHandler.getVersionNo();

    for (curam.workspaceservices.localization.impl.TextTranslation textTranslation : localizableTextHandler.listTranslations()) {

      TextTranslationDetails textTranslationDetails = assignTextTranslationDetails(
        textTranslation);

      viewLocalizableTextDetails.translations.dtls.addRef(
        textTranslationDetails);
    }

    return viewLocalizableTextDetails;
  }

  /**
   * Assigns the details of text translation.
   *
   * @param textTranslation
   * The text translation details.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected TextTranslationDetails assignTextTranslationDetails(
    final TextTranslation textTranslation) throws AppException,
      InformationalException {

    TextTranslationDetails textTranslationDetails = new TextTranslationDetails();

    textTranslationDetails.dtls.localeCode = textTranslation.getLocale().getCode();
    textTranslationDetails.dtls.localizableTextID = textTranslation.getLocalizableTextID();
    if (StringUtil.isNullOrEmpty(textTranslation.getText())) {
      textTranslationDetails.dtls.text = textTranslation.getShortText();
    } else {
      textTranslationDetails.dtls.text = textTranslation.getText();
    }
    textTranslationDetails.dtls.textTranslationID = textTranslation.getID();
    return textTranslationDetails;
  }

  /**
   * Ensures that no duplicate text is present for the same locale. If it is, a
   * validation is thrown.
   *
   * @param localizableTextHandler
   * The localizable text handler to store localizable text.
   *
   * @param locale
   * The locale for which localizable text will be entered.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateNoTranslationsForLocale(
    final LocalizableTextHandler localizableTextHandler, final String locale)
    throws AppException, InformationalException {

    List<TextTranslation> list = localizableTextHandler.listTranslations();

    for (TextTranslation tt : list) {
      if (tt.getLocale().getCode().equals(locale)) {

        curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
          LOCALIZABLETEXTExceptionCreator.ERR_TRANSLATION_EXISTS_FOR_LOCALE(
            locale),
            curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
            0);

        ValidationHelper.failIfErrorsExist();
      }
    }
  }

  /**
   * Ensures that the input text is not empty. If it is, a
   * validation is thrown.
   *
   * @param text
   * The text entered.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   */
  protected void validateTextEntered(final String text) throws AppException,
      InformationalException {
    if (StringHelper.isEmpty(text)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        LOCALIZABLETEXTExceptionCreator.ERR_TEXT_IS_MANDATORY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 6);
      ValidationHelper.failIfErrorsExist();

    }
  }
}
