/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.Inject;

import curam.attendance.impl.ProviderRosterLineItem;
import curam.attendance.impl.ProviderRosterLineItemDAO;
import curam.cpm.sl.struct.CommunicationPRLILinkDtls;
import curam.financial.impl.FinancialNotificationEventEntry;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.type.Money;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.CommunicationPRLILink}.
 */
public class CommunicationPRLILinkImpl extends SingleTableEntityImpl<CommunicationPRLILinkDtls> implements
  CommunicationPRLILink {

  /**
   * Reference to provider roster line item DAO.
   */
  @Inject
  protected ProviderRosterLineItemDAO providerRosterLineItemDAO;

  /**
   * Default constructor.
   */
  protected CommunicationPRLILinkImpl() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public Money getAmount() {
    return getDtls().amount;
  }

  /**
   * {@inheritDoc}
   */
  public FinancialNotificationEventEntry getFinancialEvent() {
    return FinancialNotificationEventEntry.get(getDtls().financialEvent);
  }

  /**
   * {@inheritDoc}
   */
  public ProviderRosterLineItem getProviderRosterLineItem() {
    if (0 != getDtls().providerRosterLineItemID) {
      return providerRosterLineItemDAO.get(getDtls().providerRosterLineItemID);
    }
    return null;
  }

  /**
   * {@inheritDoc}
   */
  public RosterNotificationEventEntry getRosterEvent() {
    return RosterNotificationEventEntry.get(getDtls().rosterEvent);
  }

  /**
   * {@inheritDoc}
   */
  public void setAmount(final Money amount) {
    getDtls().amount = amount;
  }

  /**
   * {@inheritDoc}
   */
  public void setCommunicationID(final long communictionID) {
    getDtls().communicationID = communictionID;
  }

  /**
   * {@inheritDoc}
   */
  public void setFinancialEvent(final FinancialNotificationEventEntry event) {
    getDtls().financialEvent = event.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderRosterLineItem(
    final ProviderRosterLineItem providerRosterLineItem) {
    getDtls().providerRosterLineItemID = providerRosterLineItem.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setRosterEvent(final RosterNotificationEventEntry event) {
    getDtls().rosterEvent = event.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No validation required.
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No validation required.
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No validation required.
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// No new instance defaults.
  }
}
