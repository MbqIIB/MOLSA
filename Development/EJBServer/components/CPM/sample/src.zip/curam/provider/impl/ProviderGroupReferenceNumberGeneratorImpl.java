/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2009, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.core.impl.EnvVars;
import curam.core.struct.AlternateIDSearchKey;
import curam.core.struct.Count;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.fact.ProviderFactory;
import curam.cpm.util.impl.ReferenceNumberUtility;
import curam.cpm.util.impl.SequentialContinuousRefNumberDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;


/**
 * Standard implementation of {@linkplain ProviderGroupReferenceNumberGenerator}
 * .
 */
@Singleton
public class ProviderGroupReferenceNumberGeneratorImpl implements
  ProviderGroupReferenceNumberGenerator {

  /**
   * Reference to Sequential Continuous Reference Number DAO.
   */
  @Inject
  SequentialContinuousRefNumberDAO sequentialContinuousRefNumberDAO;

  // BEGIN, CR00314817, GYH
  /**
   * Reference to reference number generation utility class.
   */
  @Inject
  protected ReferenceNumberUtility referenceNumberUtility;

  // END, CR00314817

  /**
   * Constructor for the class.
   */
  protected ProviderGroupReferenceNumberGeneratorImpl() {// The no-arg constructor for use only by Guice.
  }

  /**
   * {@inheritDoc}
   */
  public String generateReferenceNumber() throws AppException,
      InformationalException {

    // BEGIN, CR00314817, GYH
    String referenceNumber = null;
    curam.cpm.sl.entity.intf.Provider providerObj = ProviderFactory.newInstance();
    AlternateIDSearchKey alternateIDSearchKey = new AlternateIDSearchKey();
    Count count;

    while (true) {

      if (Configuration.getBooleanProperty(
        EnvVars.ENV_REFERENCENUMBER_GENERATEPROVIDERGROUPREFERENCENUMBERFROMKEYSET)) {
        referenceNumber = referenceNumberUtility.generateReferenceNumber(
          CPMConstants.kProviderGroupKeySetName);
      } else {
        referenceNumber = String.valueOf(
          sequentialContinuousRefNumberDAO.generateSequentialContinuousReferenceNumber(
            CPMConstants.kProviderGroupCodeName));
      }

      alternateIDSearchKey.alternateID = referenceNumber;
      count = providerObj.countConcernRolesByAlternateID(alternateIDSearchKey);

      if (0 < count.numberOfRecords) {
        // Continue to generate the next reference number as the reference
        // number in process is already a reference for the existing concern
        // role.
        continue;
      } else {
        // The reference number in process (generated) is not used before,
        // return this reference number.
        break;
      }
    }
    // END, CR00314817

    return referenceNumber;
  }

}
