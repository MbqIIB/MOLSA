/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import curam.providerservice.impl.ProviderOfferingAccessor;
import curam.util.persistence.StandardEntity;
import curam.util.type.DateRange;


/**
 * Accessor interface for {@linkplain ProviderMemberOffering}.
 *
 */
public interface ProviderMemberOfferingAccessor extends StandardEntity {

  /**
   * Gets the provider party associated with the provider offering.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return Provider party.
   */
  public ProviderPartyAccessor getProviderParty();

  /**
   * Gets the provider offering associated with the provider party.
   * <p>
   * The returned object is intentionally accessor-only. Calling code must not
   * attempt to cast the object to its mutator interface, nor use the object's
   * ID to re-retrieve a mutable instance from the database.
   *
   * @return Provider offering.
   */
  public ProviderOfferingAccessor getProviderOffering();

  /**
   * Gets the date range for which the provider party offers the service.
   *
   * @return Date range for which the provider party offers the service.
   */
  public DateRange getDateRange();

  /**
   * Gets the comments for provider member offering.
   *
   * @return Comments for provider member offering.
   */
  public String getComments();

}
