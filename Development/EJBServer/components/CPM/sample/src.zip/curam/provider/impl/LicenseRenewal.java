/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007, 2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.helper.Commented;
import curam.util.type.Date;


/**
 * Information relating to a license which has been renewed.
 * <p>
 * For example, a provider holds a license which is about to expire. If following
 * checks carried out by the agency the provider is seen to be compliant, the agency
 * issues a renewed license for a year, recording the date of renewal along
 * with the fact that the provider is compliant.
 */
@ImplementedBy(LicenseRenewalImpl.class)
public interface LicenseRenewal extends LicenseRenewalAccessor, Insertable,
    Commented {
  
  /**
   * Returns the license that this renewal is related to.
   *
   * @return the license that this renewal is related to.
   */
  public License getLicense();
  
  /**
   * Sets the license that this renewal is related to.
   *
   * @param value
   * the license
   */
  public void setLicense(final License value);
  
  /**
   * Sets whether the renewal is compliant.
   *
   * @param value
   * true if the renewal is compliant, otherwise false.
   */
  public void setRenewalCompliant(final boolean value);
  
  /**
   * Sets the renewal date.
   *
   * @param value
   * the renewal date.
   */
  public void setRenewalDate(final Date value);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the license renewal events functionality surrounding the
   * insert method.
   */
  public interface LicenseRenewalInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.LicenseRenewal#insert}
     *
     * @param licenseRenewal
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(LicenseRenewalAccessor licenseRenewal)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.LicenseRenewal#insert}
     *
     * @param licenseRenewal
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(LicenseRenewalAccessor licenseRenewal)
      throws InformationalException;
  }
  // END, CR00144381
}
