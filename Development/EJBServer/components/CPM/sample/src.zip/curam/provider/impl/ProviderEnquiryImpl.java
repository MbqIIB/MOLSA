/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.Inject;

import curam.codetable.USERTYPE;
import curam.codetable.impl.COMMUNICATIONMETHODEntry;
import curam.codetable.impl.LANGUAGEEntry;
import curam.codetable.impl.ORGOBJECTTYPEEntry;
import curam.core.fact.AddressDataFactory;
import curam.core.fact.PhoneNumberFactory;
import curam.core.impl.AddressUtil;
import curam.core.impl.CuramConst;
import curam.core.impl.TimeZoneUtility;
import curam.core.intf.AddressData;
import curam.core.intf.PhoneNumber;
import curam.core.sl.entity.fact.OrgObjectLinkFactory;
import curam.core.sl.entity.fact.OrganisationUnitFactory;
import curam.core.sl.entity.fact.PositionFactory;
import curam.core.sl.entity.intf.OrgObjectLink;
import curam.core.sl.entity.intf.OrganisationUnit;
import curam.core.sl.entity.intf.Position;
import curam.core.sl.entity.struct.OrgObjectLinkDtls;
import curam.core.sl.entity.struct.OrgObjectLinkKey;
import curam.core.sl.entity.struct.OrganisationUnitDtls;
import curam.core.sl.entity.struct.OrganisationUnitKey;
import curam.core.sl.entity.struct.PositionDtls;
import curam.core.sl.entity.struct.PositionKey;
import curam.core.sl.fact.UserAccessFactory;
import curam.core.sl.fact.WorkQueueFactory;
import curam.core.sl.intf.UserAccess;
import curam.core.sl.intf.WorkQueue;
import curam.core.sl.struct.ReadWorkQueueDetails;
import curam.core.sl.struct.ReadWorkQueueKey;
import curam.core.struct.AddressDtls;
import curam.core.struct.AddressKey;
import curam.core.struct.AddressLine;
import curam.core.struct.AddressLineList;
import curam.core.struct.EmptyIndStruct;
import curam.core.struct.OtherAddressData;
import curam.core.struct.PhoneNumberDtls;
import curam.core.struct.PhoneNumberKey;
import curam.core.struct.UserFullname;
import curam.core.struct.UsersKey;
import curam.cpm.sl.entity.impl.ProviderEnquiryAdapter;
import curam.cpm.sl.entity.struct.ProviderEnquiryDtls;
import curam.message.PROVIDERENQUIRY;
import curam.message.impl.PROVIDERENQUIRYExceptionCreator;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.ValidationHelper;
import curam.util.persistence.helper.EventDispatcherFactory;
import curam.util.persistence.helper.SingleTableEntityImpl;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.Date;
import curam.util.type.DateTime;
import curam.util.type.StringHelper;


/**
 * Standard implementation of {@linkplain curam.provider.impl.ProviderEnquiry}.
 */
// BEGIN, CR00183213, SS
public class ProviderEnquiryImpl extends SingleTableEntityImpl<ProviderEnquiryDtls> implements ProviderEnquiry {
  // END, CR00183213
  // BEGIN, CR00235789, AK
  /**
   * Event dispatcher for close events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderEnquiryCloseEvents> closeEventDispatcherFactory;

  /**
   * Event dispatcher for transferEnquiryToProvider events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderEnquiryTransferEnquiryToProviderEvents> transferEnquiryToProviderEventDispatcherFactory;

  /**
   * Event dispatcher for insert events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderEnquiryInsertEvents> insertEventDispatcherFactory;

  /**
   * Event dispatcher for modify events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderEnquiryModifyEvents> modifyEventDispatcherFactory;

  /**
   * Event dispatcher for set provider enquiry details events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderEnquirySetProviderEnquiryDetailsEvents> setProviderEnquiryDetailsEventDispatcherFactory;

  /**
   * Event dispatcher for set provider enquiry update details events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderEnquirySetProviderEnquiryUpdateDetailsEvents> setProviderEnquiryUpdateDetailsEventDispatcherFactory;

  /**
   * Event dispatcher for external user check events.
   */
  @Inject
  protected EventDispatcherFactory<ProviderEnquiryIsExternalUserEvents> isExternalUserEventDispatcherFactory;

  // END, CR00235789

  /**
   * Instance of provider category period DAO.
   */
  @Inject
  protected ProviderCategoryPeriodDAO providerCategoryPeriodDAO;

  /**
   * instance of provider enquiry security check
   */
  @Inject
  protected ProviderEnquirySecurityCheck providerEnquirySecurityCheck;

  /**
   * homeAdressDtls of type AddressDtls
   */
  protected AddressDtls homeAdressDtls;

  /**
   * workAdressDtls of type AddressDtls
   */
  protected AddressDtls workAdressDtls;

  /**
   * workPhoneNumberDtls of type PhoneNumberDtls
   */
  protected PhoneNumberDtls workPhoneNumberDtls;

  /**
   * homePhoneNumberDtls of type PhoneNumberDtls
   */
  protected PhoneNumberDtls homePhoneNumberDtls;

  /**
   * mobilePhoneNumberDtls of type PhoneNumberDtls
   */
  protected PhoneNumberDtls mobilePhoneNumberDtls;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderEnquiryImpl() {// The no-arg constructor for use only by Guice.
  }

  // END, CR00183213


  /**
   * {@inheritDoc}
   */
  public String getName() {
    return getDtls().name;
  }

  /**
   * Sets the enquiry name.The name of the person or company enquiring about
   * becoming a provider.
   *
   * @param value
   * Contains the provider enquiry name.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_NAME_MUST_BE_ENTERED}
   * -If enquiry name not entered. </li>
   * <li>{@link curam.message.PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_NAME_IS_TOO_LONG}
   * -If enquiry name value greater than maximum length. </li>
   * </ul>
   */
  public void setName(String value) {
    // name not empty
    
    // BEGIN, CR00274149, GP
    if ((null == value) || (0 == value.length())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_NAME_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);

      // Begin CR00096779, ABS
    }
    if (ProviderEnquiryAdapter.kMaxLength_name < value.length()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_NAME_IS_TOO_LONG(
          ProviderEnquiryAdapter.kMaxLength_name),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    if (ProviderEnquiryAdapter.kMaxLength_name < value.toUpperCase().length()) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_NAME_EXCEEDS_MAXLIMIT(
          value.toUpperCase().length(), ProviderEnquiryAdapter.kMaxLength_name),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    // END, CR00274149

    getDtls().name = value;
    // BEGIN, CR00170625, KR
    getDtls().nameUpper = value.toUpperCase();
    // END, CR00170625
  }

  /**
   * {@inheritDoc}
   */
  public String getAdditionalInformation() {
    return getDtls().additionalInformation;
  }

  /**
   * Sets the additional information about the enquiry.
   *
   * @param value
   * Contains the provider enquiry additional information.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_ADDITIONAL_INFORMATION_ENTERED_TOO_LONG}
   * -If additional information value greater than maximum length. </li>
   * </ul>
   */
  public void setAdditionalInformation(String value) {

    if (value.length()
      > ProviderEnquiryAdapter.kMaxLength_additionalInformation) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_ADDITIONAL_INFORMATION_ENTERED_TOO_LONG(
          ProviderEnquiryAdapter.kMaxLength_additionalInformation),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }
    getDtls().additionalInformation = value;
  }

  /**
   * {@inheritDoc}
   */
  public String getAdditionalName() {

    return getDtls().additionalName;
  }

  /**
   * {@inheritDoc}
   */
  public boolean hasAttendedMeeting() {
    return getDtls().attendedMeeting;
  }

  /**
   * {@inheritDoc}
   */
  public String getAvailabilityForContact() {
    return getDtls().availabilityForContact;
  }

  /**
   * Sets the details of when the organization can contact this provider.
   *
   * @param value
   * the details of when the organization can contact this provider.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.impl.PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_AVAILABILITY_FOR_CONTACT_ENTERED_TOO_LONG}
   * -If Availability For Contract value greater than maximum length. </li>
   * </ul>
   */
  public void setAvailabilityForContact(String value) {

    if (value.length()
      > ProviderEnquiryAdapter.kMaxLength_availabilityForContact) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_AVAILABILITY_FOR_CONTACT_ENTERED_TOO_LONG(
          ProviderEnquiryAdapter.kMaxLength_availabilityForContact),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    getDtls().availabilityForContact = value;
  }

  /**
   * {@inheritDoc}
   */
  public boolean isMeetingConfirmed() {

    return getDtls().confirmedMeetingDetails;
  }

  /**
   * {@inheritDoc}
   */
  public short getNumberOfChildren() {

    return getDtls().noOfChildren;
  }

  /**
   * Sets the number of children currently in the household of the person of
   * this enquiry.
   *
   * @param value
   * the number of children currently in the household of the person of
   * this enquiry.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.impl.PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_NO_OF_CHILDREN_MUST_BE_GREATER_THAN_OR_EQUAL_TO_ZERO}
   * -If number of children value is negative. </li>
   * </ul>
   */
  public void setNumberOfChildren(short value) {

    if (value < 0) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_NO_OF_CHILDREN_MUST_BE_GREATER_THAN_OR_EQUAL_TO_ZERO(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    getDtls().noOfChildren = value;

  }

  /**
   * {@inheritDoc}
   */
  public boolean hasObtainedApplicationForm() {
    return getDtls().obtainedApplicationForm;
  }

  /**
   * {@inheritDoc}
   */
  public void setObtainedApplicationForm(boolean value) {

    getDtls().obtainedApplicationForm = value;
  }

  /**
   * {@inheritDoc}
   */
  public String getPreferredSession() {
    return getDtls().preferredSession;
  }

  /**
   * {@inheritDoc}
   */
  public ReasonForEnquiryEntry getReasonForEnquiry() {
    return ReasonForEnquiryEntry.get(getDtls().reasonForEnquiry);
  }

  /**
   * {@inheritDoc}
   */
  public String getReferenceNumber() {
    return getDtls().referenceNumber;
  }

  /**
   * {@inheritDoc}
   */
  public String getScheduledMeeting() {
    return getDtls().scheduledMeeting;
  }

  /**
   * {@inheritDoc}
   */
  public long getHomeAddressID() {
    return getDtls().homeAddressID;
  }

  /**
   * {@inheritDoc}
   */
  public long getHomePhoneNumberID() {
    return getDtls().homePhoneNumberID;
  }

  /**
   * {@inheritDoc}
   */
  public long getMobilePhoneNumberID() {
    return getDtls().mobilePhoneNumberID;
  }

  /**
   * {@inheritDoc}
   */
  public long getWorkAddressID() {
    return getDtls().workAddressID;
  }

  /**
   * {@inheritDoc}
   */
  public long getWorkPhoneNumberID() {
    return getDtls().workPhoneNumberID;
  }

  /**
   * Sets date and time of the meeting that this enquiry has been scheduled to
   * attend.
   *
   * @param value
   * date and time of the meeting that this enquiry has been scheduled
   * to attend.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.impl.PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_SCHEDULED_MEETING_ENTERED_TOO_LONG}
   * -If Scheduled Meeting value greater than maximum length. </li>
   * </ul>
   */
  public void setScheduledMeeting(String value) {

    if (value.length() > ProviderEnquiryAdapter.kMaxLength_scheduledMeeting) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_SCHEDULED_MEETING_ENTERED_TOO_LONG(
          ProviderEnquiryAdapter.kMaxLength_scheduledMeeting),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    getDtls().scheduledMeeting = value;
  }

  /**
   * Sets the additional name for this provider enquiry. Where the interested
   * party is a couple the name of the other person in the couple.
   *
   * @param name
   * the additional name for this provider enquiry.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.impl.PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_ADDITIONAL_NAME_IS_TOO_LONG}
   * -If additional name value greater than maximum length. </li>
   * </ul>
   */
  public void setAdditionalName(String name) {
    // if value greater than maximum length, then throw exception
    if (name.length() > ProviderEnquiryAdapter.kMaxLength_additionalName) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_ADDITIONAL_NAME_IS_TOO_LONG(
          ProviderEnquiryAdapter.kMaxLength_additionalName),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    getDtls().additionalName = name;
  }

  /**
   * {@inheritDoc}
   */
  public void setAttendedMeeting(boolean value) {
    getDtls().attendedMeeting = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setConfirmedMeetingDetails(boolean value) {

    getDtls().confirmedMeetingDetails = value;
  }

  /**
   * Sets the preferred information or training session that this provider
   * enquiry would like to attend.
   *
   * @param value
   * the preferred information or training session.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link curam.message.impl.PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_PREFERRED_SESSION_ENTERED_TOO_LONG}
   * -If preferred session value greater than maximum length. </li>
   * </ul>
   */
  public void setPreferredSession(String value) {

    if (value.length() > ProviderEnquiryAdapter.kMaxLength_preferredSession) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_PREFERRED_SESSION_ENTERED_TOO_LONG(
          ProviderEnquiryAdapter.kMaxLength_preferredSession),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    getDtls().preferredSession = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setReasonForEnquiry(String value) {

    getDtls().reasonForEnquiry = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setHomeAddressID(final long value) {

    getDtls().homeAddressID = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setHomePhoneNumberID(final long value) {

    getDtls().homePhoneNumberID = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setMobilePhoneNumberID(final long value) {

    getDtls().mobilePhoneNumberID = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setWorkAddressID(final long value) {

    getDtls().workAddressID = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setWorkPhoneNumberID(final long value) {

    getDtls().workPhoneNumberID = value;
  }

  /**
   * {@inheritDoc}
   */
  public Date getEndDate() {
    return getDtls().endDate;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderCategoryPeriod getProviderCategoryPeriod() {

    return providerCategoryPeriodDAO.get(getDtls().providerCategoryPeriodID);
  }

  /**
   * {@inheritDoc}
   */
  public void setProviderCategoryPeriod(
    ProviderCategoryPeriod providerCategoryPeriod) {

    getDtls().providerCategoryPeriodID = providerCategoryPeriod.getID();
  }

  // BEGIN, CR00100280, GYH

  /**
   * {@inheritDoc}
   */
  public void setPreferredLanguage(
    final LANGUAGEEntry value) {

    getDtls().preferredLanguage = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public LANGUAGEEntry getPreferredLanguage() {

    return LANGUAGEEntry.get(getDtls().preferredLanguage);
  }

  /**
   * {@inheritDoc}
   */
  public void setPreferredCommunication(
    final COMMUNICATIONMETHODEntry value) {

    getDtls().preferredCommunication = value.getCode();
  }

  /**
   * {@inheritDoc}
   */
  public COMMUNICATIONMETHODEntry getPreferredCommunication() {

    return COMMUNICATIONMETHODEntry.get(getDtls().preferredCommunication);
  }

  // END, CR00100280


  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No Cross Entity Validation
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No Cross field validation
  }

  /**
   * Validates that all mandatory fields are "populated".
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_NAME_MUST_BE_ENTERED} -
   * If the provider enquiry name is not entered. </li>
   * <li>
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_ENQUIRY_DATE_MUST_BE_ENTERED} -
   * If the enquiry date is not entered. </li>
   * <li>
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_REASON_FOR_ENQUIRY_MUST_BE_ENTERED} -
   * If the enquiry reason is not entered. </li>
   * <li>
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_PREFFERED_LANGUAGE_MUST_BE_SELECTED} -
   * If the enquiry preferred language is not entered. </li>
   * <li>
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_PREFFERED_COMMUNICATION_METHOD_MUST_BE_SELECTED} -
   * If the enquiry preferred communication is not entered. </li>
   * </ul>
   */
  public void mandatoryFieldValidation() {

    // if name is empty, throw exception
    if (StringHelper.isEmpty(getDtls().name)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_NAME_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // if enquiryDate (Time of Contact) is null or if DateTime.isZero()
    // returns
    // true
    // then throw exception
    if ((getDtls().enquiryDate == null) || (getDtls().enquiryDate.isZero())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_ENQUIRY_DATE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    }

    // reason for enquiry
    if ((getDtls().reasonForEnquiry == null)
      || (0 == getDtls().reasonForEnquiry.length())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_REASON_FOR_ENQUIRY_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // BEGIN, CR00100280, GYH
    if ((getDtls().preferredLanguage == null)
      || (getDtls().preferredLanguage.equals(LANGUAGEEntry.NOT_SPECIFIED))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_PREFFERED_LANGUAGE_MUST_BE_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    if ((getDtls().preferredCommunication == null)
      || (getDtls().preferredCommunication.equals(
        COMMUNICATIONMETHODEntry.NOT_SPECIFIED))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_PREFFERED_COMMUNICATION_METHOD_MUST_BE_SELECTED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    // END, CR00100280

  }

  /**
   * This method checks for empty address data and phone number.
   *
   */
  // BEGIN, CR00177241, PM
  protected void validateContactDetails() throws AppException,
      // END, CR00177241
      InformationalException {

    // set the default value to 'true', indicating contact details not entered
    // If contact details is entered, emptyInd is set to false
    boolean emptyInd = true;

    // if emptyInd is true and home address entered, set emptyInd to false
    if (emptyInd && (!(getWorkAddressDtls() == null))
      && checkAddressNotEmpty(getHomeAddressDtls().addressData)) {
      emptyInd = false;
    }

    // if emptyInd is true and work address entered, set emptyInd to false
    if (emptyInd && (!(getWorkAddressDtls() == null))
      && checkAddressNotEmpty(getWorkAddressDtls().addressData)) {
      emptyInd = false;
    }

    // if emptyInd is true and home phone number entered, set emptyInd to false
    if (emptyInd && (!(getHomePhoneNumberDtls() == null))
      && (getHomePhoneNumberDtls().phoneNumber != null)
      && (getHomePhoneNumberDtls().phoneNumber.length() > 0)) {
      emptyInd = false;
    }

    // if emptyInd is true and work phone number entered, set emptyInd to false
    if (emptyInd && (!(getWorkPhoneNumberDtls() == null))
      && (getWorkPhoneNumberDtls().phoneNumber != null)
      && (getWorkPhoneNumberDtls().phoneNumber.length() > 0)) {
      emptyInd = false;
    }

    // if emptyInd is true and mobile phone number entered, set emptyInd to
    // false
    if (emptyInd && (!(getMobilePhoneNumberDtls() == null))
      && (getMobilePhoneNumberDtls().phoneNumber != null)
      && (getMobilePhoneNumberDtls().phoneNumber.length() > 0)) {
      emptyInd = false;
    }

    if (emptyInd) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XFV_CONTACT_DETAILS_NOT_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {
    // BEGIN, CR00097355, NRV
    setRecordStatus(EnquiryStatusEntry.OPEN);
    // END, CR00097355
  }

  /**
   * Sets the phone numbers and address details for this provider enquiry at the
   * time of provider enquiry creation.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_XFV_CONTACT_DETAILS_NOT_ENTERED} -
   * If provider enquiry contact details not entered.
   */
  public void setProviderEnquiryDetails() throws AppException,
      InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre setProviderEnquiryDetails provider enquiry event.
    setProviderEnquiryDetailsEventDispatcherFactory.get(ProviderEnquirySetProviderEnquiryDetailsEvents.class).preSetProviderEnquiryDetails(
      this);
    // END, CR00235789

    // unique ID generator
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // check user security privileges
    checkSecurityPrivileges();

    // Any one of the address or one of the phone number is mandatory
    validateContactDetails();

    // create home address
    if (!(getHomeAddressDtls() == null)
      && checkAddressNotEmpty(getHomeAddressDtls().addressData)) {
      // run time object creation
      // variables for creating home address
      curam.core.intf.Address homeAddressObj = curam.core.fact.AddressFactory.newInstance();

      homeAddressObj.insert(getHomeAddressDtls());
      // details.homeAddressID = homeAddressDtls.addressID;
      setHomeAddressID(getHomeAddressDtls().addressID);
    }

    // create work address
    if (!(getWorkAddressDtls() == null)
      && checkAddressNotEmpty(getWorkAddressDtls().addressData)) {
      // run time object creation
      // variables for creating work address
      curam.core.intf.Address workAddressObj = curam.core.fact.AddressFactory.newInstance();

      workAddressObj.insert(getWorkAddressDtls());
      // details.workAddressID = workAddressDtls.addressID;
      setWorkAddressID(getWorkAddressDtls().addressID);
    }

    // create home phone
    if (!(getHomePhoneNumberDtls() == null)
      && (getHomePhoneNumberDtls().phoneNumber != null)
      && (getHomePhoneNumberDtls().phoneNumber.length() > 0)) {
      // run time object creation
      // variables for creating home phone number
      PhoneNumber homePhoneNumberObj = PhoneNumberFactory.newInstance();

      getHomePhoneNumberDtls().phoneNumberID = uniqueIDObj.getNextID();
      homePhoneNumberObj.insert(getHomePhoneNumberDtls());
      // details.homePhoneNumberID = homePhoneNumberDtls.phoneNumberID;
      setHomePhoneNumberID(getHomePhoneNumberDtls().phoneNumberID);
    }

    // create work phone
    if (!(getWorkPhoneNumberDtls() == null)
      && (getWorkPhoneNumberDtls().phoneNumber != null)
      && (getWorkPhoneNumberDtls().phoneNumber.length() > 0)) {
      // run time object creation
      // variables for creating home phone number
      PhoneNumber workPhoneNumberObj = PhoneNumberFactory.newInstance();

      getWorkPhoneNumberDtls().phoneNumberID = uniqueIDObj.getNextID();
      workPhoneNumberObj.insert(getWorkPhoneNumberDtls());
      setWorkPhoneNumberID(getWorkPhoneNumberDtls().phoneNumberID);
    }

    // create mobile phone
    if (!(getMobilePhoneNumberDtls() == null)
      && (getMobilePhoneNumberDtls().phoneNumber != null)
      && (getMobilePhoneNumberDtls().phoneNumber.length() > 0)) {
      // run time object creation
      // variables for creating home phone number
      PhoneNumber mobilePhoneNumberObj = PhoneNumberFactory.newInstance();

      getMobilePhoneNumberDtls().phoneNumberID = uniqueIDObj.getNextID();
      mobilePhoneNumberObj.insert(getMobilePhoneNumberDtls());
      setMobilePhoneNumberID(getMobilePhoneNumberDtls().phoneNumberID);
    }

    // BEGIN, CR00235789, AK
    // Raise the post setProviderEnquiryDetails provider enquiry event.
    setProviderEnquiryDetailsEventDispatcherFactory.get(ProviderEnquirySetProviderEnquiryDetailsEvents.class).postSetProviderEnquiryDetails(
      this);
    // END, CR00235789
  }

  // __________________________________________________________________________
  /**
   * This method checks security privileges of the user, whether the user has
   * enough privileges to modify/create the record.
   *
   * @throws AppException
   * and InformationException
   */
  // BEGIN, CR00177241, PM
  protected void checkSecurityPrivileges() throws AppException,
      // END, CR00177241
      InformationalException {// AppException e;
    //
    // // check if the user is a part of resource manager organizational object
    //
    // e = PROVIDERENQUIRYExceptionCreator
    // .ERR_PROVIDERENQUIRY_XRV_USER_MUST_BE_MEMBER_OF_RESOURCE_MANAGER_ORG_OBJECT("<resource
    // manager organizational object>");
    // // throw e;
  }

  /**
   * This method checks for empty address.
   *
   * @param addressData
   * address data
   *
   * @return boolean value indicating if address is entered or not
   */
  // BEGIN, CR00177241, PM
  protected boolean checkAddressNotEmpty(String addressData) throws AppException,
      // END, CR00177241
      InformationalException {

    curam.core.intf.Address addressObj = curam.core.fact.AddressFactory.newInstance();

    // check to see if mailing address has been entered
    OtherAddressData otherAddressData = new OtherAddressData();
    EmptyIndStruct emptyIndStruct;

    otherAddressData.addressData = addressData;

    // BEGIN, CR00186119, PS
    if (addressData.length() > 0) {

      // String buffer for containing address data without country.
      StringBuffer tmpAddressData = new StringBuffer();
      String country = addressObj.getCountry(otherAddressData).addressElementString;

      AddressData addressDataObj = AddressDataFactory.newInstance();

      // Parse address data into list of address lines.
      AddressLineList addressLineList = addressDataObj.newlineText2List(
        otherAddressData);

      // Construct the header information back.
      for (int i = 0; i < AddressUtil.AddressDataLineIndex.I_ADDRESS_LINE_1; i++) {

        tmpAddressData.append(addressLineList.dtls.item(i).addressString);
        tmpAddressData.append(CuramConst.gkNewLine);

      }

      // Loop through the remaining address details.
      // Find the country information and remove it.
      for (int j = AddressUtil.AddressDataLineIndex.I_ADDRESS_LINE_1; j
        < addressLineList.dtls.size(); j++) {

        AddressLine addressLine = addressLineList.dtls.item(j);

        // If address line has country information in it then
        // replace it with the empty string.
        if (addressLine.addressString.contains(country)) {
          tmpAddressData.append(
            addressLine.addressString.replaceFirst(country, CuramConst.gkEmpty));
        } else {
          tmpAddressData.append(addressLine.addressString);
        }

        tmpAddressData.append(CuramConst.gkNewLine);

      }

      otherAddressData.addressData = tmpAddressData.toString();

    }
    // END, CR00186119

    emptyIndStruct = addressObj.isEmpty(otherAddressData);

    // emptyInd is set to 'true' if the address is not entered; else is set
    // to
    // false
    // so, if address is entered, then the return value from this method
    // would
    // be true
    return !emptyIndStruct.emptyInd;

  }

  /**
   * Closes the enquiry by setting its End Date to the current business date and
   * updates the enquiry status.
   *
   * Checks the provider enquiry security to close the provider enquiry.
   *
   * @param versionNo
   * version number to be closed.
   *
   * @throws InformationalException
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_CLOSE_TRANSFERED_ENQUIRY} -
   * If the provider enquiry status is Closed.
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_MODIFY_CLOSED_ENQUIRY} -
   * If the provider enquiry status is Closed.
   */
  public void close(int versionNo) throws InformationalException, AppException {

    // perform a security check
    providerEnquirySecurityCheck.checkEnquirySecurity(this);

    // BEGIN, CR00235789, AK
    // Raise the pre close provider enquiry event.
    closeEventDispatcherFactory.get(ProviderEnquiryCloseEvents.class).preClose(
      this, versionNo);
    // END, CR00235789

    // Begin CR00096779, ABS
    // Check the status of the enquiry
    // BEGIN, CR00097355, NRV
    if (getRecordStatus().equals(EnquiryStatusEntry.CLOSED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_MODIFY_CLOSED_ENQUIRY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 2);
    } else if (getRecordStatus().equals(EnquiryStatusEntry.TRANSFERRED)) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_CLOSE_TRANSFERED_ENQUIRY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();
    setEndDate(Date.getCurrentDate());
    setRecordStatus(EnquiryStatusEntry.CLOSED);
    // END, CR00097355
    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post close provider enquiry event.
    closeEventDispatcherFactory.get(ProviderEnquiryCloseEvents.class).postClose(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * {@inheritDoc}
   */
  public String getOwnerName() {
    return getDtls().ownerName;
  }

  /**
   * {@inheritDoc}
   */
  public DateTime getEnquiryDate() {
    return getDtls().enquiryDate;
  }

  /**
   * Sets the enquiry date for this provider enquiry.
   *
   * @param value
   * the provider enquiry date.
   *
   * <p>
   * It adds the following informational exceptions to the validation helper
   * when validation fails.
   * </p>
   * <ul>
   * <li>
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_FV_ENQUIRY_DATE_MUST_BE_ENTERED} -
   * If enquiry date time is not entered. </li>
   * </ul>
   */
  public void setEnquiryDate(DateTime value) {

    if (value != null && value.isZero()) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_FV_ENQUIRY_DATE_MUST_BE_ENTERED(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    getDtls().enquiryDate = value;
  }

  /**
   * {@inheritDoc}
   */
  public void setReferenceNumber(String value) {
    getDtls().referenceNumber = StringHelper.trim(value);
  }

  /**
   * {@inheritDoc}
   */
  public void setOwnerName(String value) {
    getDtls().ownerName = StringHelper.trim(value);
  }

  /**
   * Sets the phone numbers and address details for this provider enquiry at the
   * time of provider enquiry modification.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_XFV_CONTACT_DETAILS_NOT_ENTERED} -
   * If provider enquiry contact details not entered.
   */
  public void setProviderEnquiryUpdateDetails() throws AppException,
      InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre setProviderEnquiryUpdateDetails provider enquiry event.
    setProviderEnquiryUpdateDetailsEventDispatcherFactory.get(ProviderEnquirySetProviderEnquiryUpdateDetailsEvents.class).preSetProviderEnquiryUpdateDetails(
      this);
    // END, CR00235789

    // Check the status of the enquiry
    // BEGIN, CR00097355, NRV
    if (getDtls().recordStatus.equals(EnquiryStatusEntry.CLOSED.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_MODIFY_CLOSED_ENQUIRY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }

    // unique ID generator
    curam.core.intf.UniqueID uniqueIDObj = curam.core.fact.UniqueIDFactory.newInstance();

    // check user security privileges
    checkSecurityPrivileges();

    // Any one of the address or one of the phone number is mandatory
    validateContactDetails();

    // update home address
    // variables for updating home address
    curam.core.intf.Address homeAddressObj = curam.core.fact.AddressFactory.newInstance();
    AddressKey homeAddressKey = new AddressKey();

    if (getHomeAddressID() != 0) {
      // if home address key already exists
      // i.e home address already entered during creation
      homeAddressKey.addressID = getHomeAddressID();

      // if home address is emptied, then delete the old home address
      if ((getHomeAddressDtls() == null)
        && !(checkAddressNotEmpty(getHomeAddressDtls().addressData))) {
        homeAddressObj.remove(homeAddressKey);
        setHomeAddressID(0);
      } else {
        homeAddressObj.modify(homeAddressKey, getHomeAddressDtls());
      }
    } else if (!(getHomeAddressDtls() == null)
      && checkAddressNotEmpty(getHomeAddressDtls().addressData)) {
      // create new home address only if home address detail is entered
      homeAddressObj.insert(getHomeAddressDtls());
      setHomeAddressID(getHomeAddressDtls().addressID);
    }

    // update work address
    // variables for updating work address
    curam.core.intf.Address workAddressObj = curam.core.fact.AddressFactory.newInstance();
    AddressKey workAddressKey = new AddressKey();

    if (getWorkAddressID() != 0) {

      workAddressKey.addressID = getWorkAddressID();

      // if work address is emptied, then delete the old work address
      if ((getWorkAddressDtls() == null)
        && !(checkAddressNotEmpty(getWorkAddressDtls().addressData))) {
        workAddressObj.remove(workAddressKey);
        setWorkAddressID(0);
      } else {
        // modify existing work address
        workAddressObj.modify(workAddressKey, getWorkAddressDtls());
      }
    } else if (!(getWorkAddressDtls() == null)
      && checkAddressNotEmpty(getWorkAddressDtls().addressData)) {
      // create new work address only if work address detail is entered
      workAddressObj.insert(getWorkAddressDtls());
      setWorkAddressID(getWorkAddressDtls().addressID);
    }

    // update home phone
    // variables for updating home phone number
    curam.core.intf.PhoneNumber homePhoneNumberObj = curam.core.fact.PhoneNumberFactory.newInstance();
    PhoneNumberKey homePhoneNumberKey = new PhoneNumberKey();

    if (getHomePhoneNumberID() != 0) {
      // update existing home phone details
      homePhoneNumberKey.phoneNumberID = getHomePhoneNumberID();
      getHomePhoneNumberDtls().phoneNumberID = getHomePhoneNumberID();
      getHomePhoneNumberDtls().versionNo = homePhoneNumberObj.read(homePhoneNumberKey).versionNo;
      homePhoneNumberObj.modify(homePhoneNumberKey, getHomePhoneNumberDtls());
    } else if (!(getHomePhoneNumberDtls() == null)
      && (getHomePhoneNumberDtls().phoneNumber != null)
      && (getHomePhoneNumberDtls().phoneNumber.length() > 0)) {
      // create a new home phone number
      getHomePhoneNumberDtls().phoneNumberID = uniqueIDObj.getNextID();
      homePhoneNumberObj.insert(getHomePhoneNumberDtls());
    }

    setHomePhoneNumberID(getHomePhoneNumberDtls().phoneNumberID);

    // update work phone
    // variables for updating home phone number
    PhoneNumber workPhoneNumberObj = PhoneNumberFactory.newInstance();
    PhoneNumberKey workPhoneNumberKey = new PhoneNumberKey();

    if (getWorkPhoneNumberID() != 0) {
      workPhoneNumberKey.phoneNumberID = getWorkPhoneNumberID();
      getWorkPhoneNumberDtls().phoneNumberID = getWorkPhoneNumberID();
      getWorkPhoneNumberDtls().versionNo = workPhoneNumberObj.read(workPhoneNumberKey).versionNo;
      // update existing work phone details
      workPhoneNumberObj.modify(workPhoneNumberKey, getWorkPhoneNumberDtls());
    } else if (!(getWorkPhoneNumberDtls() == null)
      && (getWorkPhoneNumberDtls().phoneNumber != null)
      && (getWorkPhoneNumberDtls().phoneNumber.length() > 0)) {
      // create a new work phone number
      getWorkPhoneNumberDtls().phoneNumberID = uniqueIDObj.getNextID();
      workPhoneNumberObj.insert(getWorkPhoneNumberDtls());
    }

    setWorkPhoneNumberID(getWorkPhoneNumberDtls().phoneNumberID);

    // update mobile phone
    // variables for updating home phone number
    PhoneNumber mobilePhoneNumberObj = PhoneNumberFactory.newInstance();
    PhoneNumberKey mobilePhoneNumberKey = new PhoneNumberKey();

    if (getMobilePhoneNumberID() != 0) {
      // update existing mobile phone details
      getMobilePhoneNumberDtls().phoneNumberID = getMobilePhoneNumberID();
      mobilePhoneNumberKey.phoneNumberID = getMobilePhoneNumberID();
      getMobilePhoneNumberDtls().versionNo = mobilePhoneNumberObj.read(mobilePhoneNumberKey).versionNo;
      mobilePhoneNumberObj.modify(mobilePhoneNumberKey,
        getMobilePhoneNumberDtls());
    } else if (!(getMobilePhoneNumberDtls() == null)
      && (getMobilePhoneNumberDtls().phoneNumber != null)
      && (getMobilePhoneNumberDtls().phoneNumber.length() > 0)) {
      // create a new mobile phone number
      getMobilePhoneNumberDtls().phoneNumberID = uniqueIDObj.getNextID();
      mobilePhoneNumberObj.insert(getMobilePhoneNumberDtls());
    }

    setMobilePhoneNumberID(getMobilePhoneNumberDtls().phoneNumberID);

    // BEGIN, CR00235789, AK
    // Raise the post setProviderEnquiryUpdateDetails provider enquiry event.
    setProviderEnquiryUpdateDetailsEventDispatcherFactory.get(ProviderEnquirySetProviderEnquiryUpdateDetailsEvents.class).postSetProviderEnquiryUpdateDetails(
      this);
    // END, CR00235789

  }

  /**
   * Sets the end date for this provider enquiry.
   *
   * @param value
   * the end date value
   */
  // BEGIN, CR00177241, PM
  protected void setEndDate(Date value) {
    // END, CR00177241
    getDtls().endDate = value;
  }

  // BEGIN, CR00097355, NRV

  /**
   * {@inheritDoc}
   */
  public EnquiryStatusEntry getRecordStatus() {

    return EnquiryStatusEntry.get(getDtls().recordStatus);
  }

  /**
   * Sets the record status for this provider enquiry.
   *
   * @param value
   * provider enquiry status value
   */
  // BEGIN, CR00177241, PM
  protected void setRecordStatus(final EnquiryStatusEntry value) {
    // END, CR00177241
    getDtls().recordStatus = value.getCode();
  }

  // END, CR00097355

  /**
   * {@inheritDoc}
   */
  public AddressDtls getHomeAddressDtls() {
    return this.homeAdressDtls;
  }

  /**
   * {@inheritDoc}
   */
  public PhoneNumberDtls getHomePhoneNumberDtls() {
    return this.homePhoneNumberDtls;
  }

  /**
   * {@inheritDoc}
   */
  public PhoneNumberDtls getMobilePhoneNumberDtls() {
    return this.mobilePhoneNumberDtls;
  }

  /**
   * {@inheritDoc}
   */
  public AddressDtls getWorkAddressDtls() {
    return this.workAdressDtls;
  }

  /**
   * {@inheritDoc}
   */
  public PhoneNumberDtls getWorkPhoneNumberDtls() {
    return this.workPhoneNumberDtls;
  }

  /**
   * {@inheritDoc}
   */
  public void setHomeAddressDtls(AddressDtls value) {
    this.homeAdressDtls = value;

  }

  /**
   * {@inheritDoc}
   */
  public void setHomePhoneNumberDtls(PhoneNumberDtls value) {
    this.homePhoneNumberDtls = value;

  }

  /**
   * {@inheritDoc}
   */
  public void setWorkAddressDtls(AddressDtls value) {
    this.workAdressDtls = value;

  }

  /**
   * {@inheritDoc}
   */
  public void setWorkPhoneNumberDtls(PhoneNumberDtls value) {
    this.workPhoneNumberDtls = value;

  }

  /**
   * {@inheritDoc}
   */
  public void setMobilePhoneNumberDtls(PhoneNumberDtls value) {
    this.mobilePhoneNumberDtls = value;

  }

  /**
   * Modifies the provider enquiry.
   *
   * Checks the provider enquiry security to modify the provider enquiry.
   *
   * @throws InformationalException
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_MODIFY_CLOSED_ENQUIRY} -
   * If provider enquiry status is CLOSED.
   * @throws InformationalException
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_MODIFY_TRANSFERED_ENQUIRY} -
   * If provider enquiry status is TRANSFERRED.
   */
  @Override
  public void modify(Integer versionNo) throws InformationalException {

    // perform a security check
    try {
      providerEnquirySecurityCheck.checkEnquirySecurity(this);
    } catch (AppException ex) {
      ValidationHelper.addValidationError(ex);
    }

    // BEGIN, CR00235789, AK
    // Raise the pre modify provider enquiry event.
    modifyEventDispatcherFactory.get(ProviderEnquiryModifyEvents.class).preModify(
      this, versionNo);
    // END, CR00235789

    // Begin CR00096779, ABS
    // Check the status of the enquiry
    // BEGIN, CR00097355, NRV
    if (getDtls().recordStatus.equals(EnquiryStatusEntry.CLOSED.toString())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_MODIFY_CLOSED_ENQUIRY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 1);
    } else if (getDtls().recordStatus.equals(
      EnquiryStatusEntry.TRANSFERRED.getCode())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_MODIFY_TRANSFERED_ENQUIRY(
          getRecordStatus().getCodeTableItemIdentifier()),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

    ValidationHelper.failIfErrorsExist();

    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post modify provider enquiry event.
    modifyEventDispatcherFactory.get(ProviderEnquiryModifyEvents.class).postModify(
      this, versionNo);
    // END, CR00235789
  }

  /**
   * Creates the provider enquiry.
   *
   * @throws InformationalException
   * {@link PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_XFV_ENDDATE_MUST_NOT_BE_EARLIER_THAN_ENQUIRY_DATE} -
   * If provider enquiry start date is later than end date.
   */
  @Override
  public void insert() throws InformationalException {

    // BEGIN, CR00235789, AK
    // Raise the pre insert provider enquiry event.
    insertEventDispatcherFactory.get(ProviderEnquiryInsertEvents.class).preInsert(
      this);
    // END, CR00235789

    try {
      validateDate();
    } catch (AppException ap) {
      ValidationHelper.addValidationError(ap);
    }

    super.insert();

    // BEGIN, CR00235789, AK
    // Raise the post insert provider enquiry event.
    insertEventDispatcherFactory.get(ProviderEnquiryInsertEvents.class).postInsert(
      this);
    // END, CR00235789
  }

  /**
   * This method validates the enquiry dates.
   */
  // BEGIN, CR00177241, PM
  protected void validateDate() throws InformationalException, AppException {
    // END, CR00177241
    // validate end date
    // Date enquiryDate = new Date(getDtls().enquiryDate);
    Date enquiryDate = new Date(
      TimeZoneUtility.getTimeZoneAdjustedDateTime(getEnquiryDate(),
      TransactionInfo.getUserTimeZone()));

    if ((!getDtls().endDate.isZero()) && (enquiryDate.after(getDtls().endDate))) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XFV_ENDDATE_MUST_NOT_BE_EARLIER_THAN_ENQUIRY_DATE(
          getDtls().endDate, enquiryDate),
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);
    }

  }

  // BEGIN, CR00097355, NRV
  /**
   * Closes the enquiry by setting its End Date to the current business date and
   * updates the enquiry status.
   *
   * Checks the provider enquiry security to transfer the provider enquiry.
   *
   * @param versionNo
   * version number to be transfered.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * {@link curam.message.PROVIDERENQUIRY#ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_TRANSFER_TRANSFERED_ENQUIRY} -
   * If provider enquiry status is TRANSFERRED.
   */
  public void transferEnquiryToProvider(int versionNo) throws
      InformationalException, AppException {

    // perform a security check
    providerEnquirySecurityCheck.checkEnquirySecurity(this);

    // BEGIN, CR00235789, AK
    // Raise the pre transferEnquiryToProvider provider enquiry event.
    transferEnquiryToProviderEventDispatcherFactory.get(ProviderEnquiryTransferEnquiryToProviderEvents.class).preTransferEnquiryToProvider(
      this, versionNo);
    // END, CR00235789

    // Check the status of the enquiry
    if (getDtls().recordStatus.equals(EnquiryStatusEntry.TRANSFERRED)) {

      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDERENQUIRY_XRV_USER_CANNOT_TRANSFER_TRANSFERED_ENQUIRY(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
    }
    ValidationHelper.failIfErrorsExist();
    setEndDate(Date.getCurrentDate());
    setRecordStatus(EnquiryStatusEntry.TRANSFERRED);
    super.modify(versionNo);

    // BEGIN, CR00235789, AK
    // Raise the post transferEnquiryToProvider provider enquiry event.
    transferEnquiryToProviderEventDispatcherFactory.get(ProviderEnquiryTransferEnquiryToProviderEvents.class).postTransferEnquiryToProvider(
      this, versionNo);
    // END, CR00235789
  }

  // END, CR00097355

  // BEGIN CR00113233 KR
  /**
   * {@inheritDoc}
   */
  public boolean isExternalUser(String userName) throws InformationalException,
      AppException {

    // BEGIN, CR00235789, AK
    // Raise the pre isExternalUser provider enquiry event.
    isExternalUserEventDispatcherFactory.get(ProviderEnquiryIsExternalUserEvents.class).preIsExternalUser(
      this, userName);
    // END, CR00235789

    boolean isExternalUser = false;
    UsersKey usersKey = new UsersKey();

    usersKey.userName = userName;

    if (USERTYPE.EXTERNAL.equals(
      UserAccessFactory.newInstance().getUserType(usersKey))) {
      isExternalUser = true;
    }

    // BEGIN, CR00235789, AK
    // Raise the post isExternalUser provider enquiry event.
    isExternalUserEventDispatcherFactory.get(ProviderEnquiryIsExternalUserEvents.class).postIsExternalUser(
      this, userName, isExternalUser);
    // END, CR00235789

    return isExternalUser;
  }

  // END CR00113233


  // BEGIN, CR00095292, RPB
  /**
   * {@inheritDoc}
   */
  public long getOrgObjectLinkID() {
    return getDtls().orgObjectLinkID;
  }

  /**
   * {@inheritDoc}
   */
  public void setOrgObjectLink(final long orgObjectLinkID) {
    getDtls().orgObjectLinkID = orgObjectLinkID;
  }

  /**
   * Gets the name of the organization object which is the owner for the
   * provider enquiry. This facilitates the provider enquiry to be owned not
   * only by the user but by other organization objects such as
   * position,organization unit and work queue by setting the organization
   * object link id.
   *
   * @return The name of the owner organization object.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERENQUIRY#ERR_PROVIDER_ENQUIRY_XRV_OWNER_IS_NOT_A_VALID_ORGOBJECT}
   * - If organization object link id is not a valid one and does not
   * correspond to any entry in the organization object link entity.
   * @see ProviderEnquiry#setOrgObjectLink(long)
   * @see ProviderEnquiryAccessor#getOrgObjectLinkID
   */
  public String getOwnerOrgObjectName() throws InformationalException {

    String ownerName = CuramConst.gkEmpty;

    // If organization object link id is present, get the value for the same.
    if (getDtls().orgObjectLinkID != 0) {
      ownerName = readOrgObject(getDtls().orgObjectLinkID);
    } // Otherwise, if the owner name is specified, the same is used.
    else if (!StringUtil.isNullOrEmpty(getDtls().ownerName)) {
      ownerName = getDtls().ownerName;
    }
    return ownerName;
  }

  /**
   * This gives the name of the organization object for the given organization
   * object link id.
   *
   * @param orgObjectLinkID
   * Organization object link id.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERENQUIRY#ERR_PROVIDER_ENQUIRY_XRV_OWNER_IS_NOT_A_VALID_ORGOBJECT}
   * - If organization object link id is not a valid one and does not
   * correspond to any entry in the organization object link entity.
   */

  protected String readOrgObject(final long orgObjectLinkID) throws InformationalException {

    String ownerName = CuramConst.gkEmpty;

    try {
      OrgObjectLink orgObjectLink = OrgObjectLinkFactory.newInstance();
      OrgObjectLinkKey orgObjectLinkKey = new OrgObjectLinkKey();

      orgObjectLinkKey.orgObjectLinkID = orgObjectLinkID;
      OrgObjectLinkDtls orgObjectLinkDtls = orgObjectLink.read(orgObjectLinkKey);

      if (ORGOBJECTTYPEEntry.USER.getCode().equalsIgnoreCase(
        orgObjectLinkDtls.orgObjectType)) {

        UserAccess userAccessObj = UserAccessFactory.newInstance();
        UsersKey usersKey = new UsersKey();
        UserFullname userFullName;

        usersKey.userName = orgObjectLinkDtls.userName;
        userFullName = userAccessObj.getFullName(usersKey);
        ownerName = userFullName.fullname;
      }

      if (ORGOBJECTTYPEEntry.ORGUNIT.getCode().equalsIgnoreCase(
        orgObjectLinkDtls.orgObjectType)) {

        OrganisationUnit organisationUnitObj = OrganisationUnitFactory.newInstance();
        OrganisationUnitDtls organisationUnitDtls = new OrganisationUnitDtls();
        OrganisationUnitKey organisationUnitKey = new OrganisationUnitKey();

        organisationUnitKey.organisationUnitID = orgObjectLinkDtls.orgObjectReference;
        organisationUnitDtls = organisationUnitObj.read(organisationUnitKey);
        ownerName = organisationUnitDtls.name;
      }

      if (ORGOBJECTTYPEEntry.WORKQUEUE.getCode().equalsIgnoreCase(
        orgObjectLinkDtls.orgObjectType)) {

        WorkQueue workQueue = WorkQueueFactory.newInstance();
        ReadWorkQueueKey readWorkQueueKey = new ReadWorkQueueKey();

        readWorkQueueKey.key.workQueueID = orgObjectLinkDtls.orgObjectReference;
        ReadWorkQueueDetails readWorkQueueDetails = workQueue.read(
          readWorkQueueKey);

        ownerName = readWorkQueueDetails.dtls.name;
      }

      if (ORGOBJECTTYPEEntry.POSITION.getCode().equalsIgnoreCase(
        orgObjectLinkDtls.orgObjectType)) {

        Position position = PositionFactory.newInstance();
        PositionKey positionKey = new PositionKey();

        positionKey.positionID = orgObjectLinkDtls.orgObjectReference;
        PositionDtls positionDtls = position.read(positionKey);

        ownerName = positionDtls.name;
      }
    } catch (Exception e) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addValidationHelperExceptionWithLookup(
        PROVIDERENQUIRYExceptionCreator.ERR_PROVIDER_ENQUIRY_XRV_OWNER_IS_NOT_A_VALID_ORGOBJECT(),
        curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo, 0);
      ValidationHelper.failIfErrorsExist();
    }
    return ownerName;
  }
  // END, CR00095292
}
