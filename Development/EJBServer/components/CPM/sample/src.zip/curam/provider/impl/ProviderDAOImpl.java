/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.google.inject.Singleton;

import curam.codetable.ADDRESSELEMENTTYPE;
import curam.codetable.impl.ADDRESSELEMENTTYPEEntry;
import curam.codetable.impl.ADMINCASEROLESTATUSEntry;
import curam.codetable.impl.ADMINCONCERNROLETYPEEntry;
import curam.codetable.impl.CASEPARTICIPANTROLETYPEEntry;
import curam.codetable.impl.CASETYPECODEEntry;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.core.impl.CuramConst;
import curam.core.impl.EnvVars;
import curam.core.struct.ConcernRoleKey;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.fact.ProviderFactory;
import curam.cpm.sl.entity.impl.ProviderAdapter;
import curam.cpm.sl.entity.struct.FinancialInstructionDetailList;
import curam.cpm.sl.entity.struct.ProviderAndServiceSearchResult;
import curam.cpm.sl.entity.struct.ProviderAndServiceSearchResultList;
import curam.cpm.sl.entity.struct.ProviderDtls;
import curam.cpm.sl.entity.struct.ProviderFinancialDetailList;
import curam.cpm.sl.entity.struct.ProviderInvestigationCriteria;
import curam.cpm.sl.entity.struct.ProviderInvestigationDetailsList;
import curam.cpm.sl.entity.struct.ProviderMembersBackgroundCheckDetailsList;
import curam.cpm.sl.entity.struct.ProviderSearchDetails;
import curam.cpm.sl.entity.struct.ProviderSearchDetailsKey;
import curam.cpm.sl.entity.struct.ProviderSearchDetailsList;
import curam.cpm.sl.entity.struct.ProviderSearchKey;
import curam.cpm.sl.entity.struct.SearchByFIAndILITypeKey;
import curam.cpm.sl.entity.struct.SearchByProviderDetails;
import curam.cpm.sl.entity.struct.SearchProviderEnrollmentKey;
import curam.cpm.sl.entity.struct.SearchProviderKey;
import curam.cpm.sl.struct.RetrieveFacilityInformationKey;
import curam.provider.ProviderTypeName;
import curam.providerservice.impl.ProviderOfferingStatusEntry;
import curam.util.dataaccess.CuramValueList;
import curam.util.dataaccess.DynamicDataAccess;
import curam.util.exception.AppException;
import curam.util.exception.AppRuntimeException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.resources.Configuration;
import curam.util.type.Date;
import curam.util.type.StringHelper;


/**
 * Standard implementation of {@linkplain curam.provider.impl.ProviderDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ProviderDAOImpl extends StandardDAOImpl<Provider, ProviderDtls>
  implements ProviderDAO {
  // END, CR00183213
  /**
   * adapter instance of ProviderAdapter.
   */
  protected static final ProviderAdapter adapter = new ProviderAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderDAOImpl() {
    // END, CR00183213
    super(adapter, Provider.class);
  }

  /**
   * {@inheritDoc}
   */
  public Set<Provider> searchProvidersByUserName(final String userName) {
    final String userNameKey = StringHelper.trim(userName);
    final String statusCode = ADMINCASEROLESTATUSEntry.ACTIVE.getCode();

    return newSet(adapter.searchProvidersByUserName(statusCode, userNameKey));
  }

  /**
   * {@inheritDoc}
   */
  public Set<Provider> searchBy(String name, String referenceNumber,
    @SuppressWarnings(CPMConstants.kUnused) Boolean searchByName,
    @SuppressWarnings(CPMConstants.kUnused) Boolean searchByReferenceNumber,
    String category, String providerCategoryType, Boolean searchByCategory,
    @SuppressWarnings(CPMConstants.kUnused) Boolean searchByType,
    @SuppressWarnings(CPMConstants.kUnused) Boolean primaryCategoryInd) {

    // Manipulation variable
    final String referenceNumberTrim = referenceNumber.trim();
    final String nameTrim = name.trim();
    // final String categoryTrim = category.trim();
    final String providerCategoryTypeTrim = providerCategoryType.trim();

    // Initialize the search Criteria
    final boolean searchByReferenceNumberTerm = referenceNumberTrim.length()
      > 0;
    final boolean searchByNameTerm = nameTrim.length() > 0;
    // final boolean searchByCategoryTerm = categoryTrim.length() > 0;
    final boolean searchByTypeTerm = providerCategoryTypeTrim.length() > 0;

    // check for category and provider type.
    if (providerCategoryTypeTrim.length() > 0) {
      try {
        category = curam.util.type.CodeTable.getParentCode(
          ProviderTypeName.TABLENAME, providerCategoryTypeTrim);
      } catch (Exception e) {
        throw new AppRuntimeException(e);
      }
      searchByCategory = true;
    }

    final boolean primaryCategoryIndTerm = true;

    final String nameTerm = CuramConst.gkSqlWildcard + nameTrim.toUpperCase()
      + CuramConst.gkSqlWildcard;

    // BEGIN, CR00170625, KR
    Set<Provider> providerSet = new HashSet<Provider>();

    if (Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {
      try {
        providerSet = searchByDynamicSql(nameTerm, referenceNumberTrim,
          searchByNameTerm, searchByReferenceNumberTerm, category,
          providerCategoryTypeTrim, searchByCategory, searchByTypeTerm,
          primaryCategoryIndTerm);
      } catch (AppException appException) {
        throw new AppRuntimeException(appException);
      } catch (InformationalException infExp) {
        throw new AppRuntimeException(infExp);
      }
    } else {
      providerSet = newSet(
        adapter.searchBy(nameTerm, referenceNumberTrim, searchByNameTerm,
        searchByReferenceNumberTerm, category, providerCategoryTypeTrim,
        searchByCategory, searchByTypeTerm, primaryCategoryIndTerm));
    }
    return providerSet;
    // END, CR00170625
  }

  /**
   * {@inheritDoc}
   */
  public Set<Provider> searchByProviderEnrollment(String name,
    String referenceNumber,
    @SuppressWarnings(CPMConstants.kUnused) Boolean searchByName,
    @SuppressWarnings(CPMConstants.kUnused) Boolean searchByReferenceNumber,
    String street1, String city,
    @SuppressWarnings(CPMConstants.kUnused) Boolean searchByStreet1,
    @SuppressWarnings(CPMConstants.kUnused) Boolean searchByCity,
    @SuppressWarnings(CPMConstants.kUnused) String addressTypeCode,
    @SuppressWarnings(CPMConstants.kUnused) String cityTypeCode) {

    // Manipulation variable
    final String referenceNumberTrim = referenceNumber.trim();
    final String nameTrim = name.trim();
    final String street1Trim = street1.trim();
    String cityTrim = city.trim();

    // Initialize the search Criteria
    final boolean searchByReferenceNumberTerm = referenceNumberTrim.length()
      > 0;
    final boolean searchByNameTerm = nameTrim.length() > 0;
    final boolean searchByStreet1Term = street1Trim.length() > 0;
    final boolean searchByCityTerm = cityTrim.length() > 0;
    final String addressLine1TypeTerm = ADDRESSELEMENTTYPE.LINE1;
    final String cityTypeCodeTerm = ADDRESSELEMENTTYPE.CITY;

    final String nameTerm = CuramConst.gkSqlWildcard + nameTrim.toUpperCase()
      + CuramConst.gkSqlWildcard;

    final String street1Term = CuramConst.gkSqlWildcard
      + street1Trim.toUpperCase() + CuramConst.gkSqlWildcard;

    final String cityTerm = CuramConst.gkSqlWildcard + cityTrim.toUpperCase()
      + CuramConst.gkSqlWildcard;

    // BEGIN, CR00170625, KR
    Set<Provider> providerSet = new HashSet<Provider>();

    if (Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {
      try {

        providerSet = searchByProviderEnrollmentDynamicSql(nameTerm,
          referenceNumberTrim, searchByNameTerm, searchByReferenceNumberTerm,
          street1Term, cityTerm, searchByStreet1Term, searchByCityTerm,
          addressLine1TypeTerm, cityTypeCodeTerm);
      } catch (AppException appException) {
        throw new AppRuntimeException(appException);
      } catch (InformationalException infExp) {
        throw new AppRuntimeException(infExp);
      }

    } else {

      providerSet = newSet(
        adapter.searchByProviderEnrollment(nameTerm, referenceNumberTrim,
        searchByNameTerm, searchByReferenceNumberTerm, street1Term, cityTerm,
        searchByStreet1Term, searchByCityTerm, addressLine1TypeTerm,
        cityTypeCodeTerm));
    }

    return providerSet;
    // END, CR00170625
  }
  
  // BEGIN, CR00304588, GA
  /**
   * {@inheritDoc}
   */
  public ProviderAndServiceSearchResultList searchProvider(final String name,
    final String street1, final String city, final long serviceID, final Date fromDate,
    final Date toDate) throws AppException, InformationalException {

    final String nameTrim = name.trim();
    final String street1Trim = street1.trim();
    final String cityTrim = city.trim();

    final boolean searchByNameTerm = !nameTrim.isEmpty();
    final boolean searchByStreet1Term = !street1Trim.isEmpty();
    final boolean searchByCityTerm = !cityTrim.isEmpty();
    final String addressLine1TypeTerm = ADDRESSELEMENTTYPEEntry.LINE2.getCode();
    final String cityTypeCodeTerm = ADDRESSELEMENTTYPEEntry.CITY.getCode();
  
    final StringBuilder nameTerm = new StringBuilder();

    nameTerm.append(CuramConst.gkSqlWildcard);
    nameTerm.append(nameTrim.toUpperCase());
    nameTerm.append(CuramConst.gkSqlWildcard);

    final StringBuilder street1Term = new StringBuilder(); 

    street1Term.append(CuramConst.gkSqlWildcard);
    street1Term.append(street1Trim.toUpperCase());
    street1Term.append(CuramConst.gkSqlWildcard);

    final StringBuilder cityTerm = new StringBuilder();

    cityTerm.append(CuramConst.gkSqlWildcard);
    cityTerm.append(cityTrim.toUpperCase());
    cityTerm.append(CuramConst.gkSqlWildcard);
   
    ProviderAndServiceSearchResultList providerAndServiceSearchResultList;

    if (Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {

      providerAndServiceSearchResultList = searchByProviderDynamicSql(nameTerm,
        searchByNameTerm, street1Term, searchByStreet1Term, cityTerm,
        searchByCityTerm, addressLine1TypeTerm, cityTypeCodeTerm, serviceID,
        fromDate, toDate);        
    } else {
      final curam.cpm.sl.entity.intf.Provider providerObj = curam.cpm.sl.entity.fact.ProviderFactory.newInstance();
      final ProviderSearchDetailsKey providerSearchDetailsKey = new ProviderSearchDetailsKey();

      populateProviderSearchData(nameTerm, searchByNameTerm, street1Term,
        searchByStreet1Term, cityTerm, searchByCityTerm, addressLine1TypeTerm,
        cityTypeCodeTerm, serviceID,
        ProviderOfferingStatusEntry.APPROVED.getCode(), fromDate, toDate,
        providerSearchDetailsKey);   
        
      providerAndServiceSearchResultList = providerObj.searchProviderByServiceAndAddressDetails(
        providerSearchDetailsKey);	
      
    }

    return providerAndServiceSearchResultList;
  }

  // END, CR00304588
  
  /**
   * {@inheritDoc}
   */
  // BEGIN, CR00106777, SG
  public ProviderSearchDetailsList searchProvider(String providerName,
    String referenceNumber, String providerCategoryType, String ownerName)
    throws AppException, InformationalException {

    // Provider entity object initialization.
    curam.cpm.sl.entity.intf.Provider providerObj = curam.cpm.sl.entity.fact.ProviderFactory.newInstance();

    // Key struct for Provider search.
    ProviderSearchKey providerSearchKey = new ProviderSearchKey();

    // Setting input criteria for search.
    final String providerNameValue = providerName.trim().toUpperCase();
    final String ownerNameValue = ownerName.trim().toUpperCase();

    if (providerNameValue.length() > 0) {
      providerSearchKey.name = CuramConst.gkSqlWildcard + providerNameValue
        + CuramConst.gkSqlWildcard;
      providerSearchKey.searchByName = true;
    }

    if (ownerNameValue.length() > 0) {
      providerSearchKey.ownerName = CuramConst.gkSqlWildcard + ownerNameValue
        + CuramConst.gkSqlWildcard;
      providerSearchKey.searchByOwner = true;
    }
    providerSearchKey.userType = ADMINCONCERNROLETYPEEntry.OWNER.getCode();

    providerSearchKey.referenceNumber = referenceNumber;
    providerSearchKey.searchByReferenceNumber = referenceNumber.length() > 0;

    providerSearchKey.searchByType = providerCategoryType.length() > 0;
    providerSearchKey.primaryCategoryInd = true;
    if (providerSearchKey.searchByType) {

      providerSearchKey.providerCategoryType = providerCategoryType;
      providerSearchKey.searchByCategory = true;
      providerSearchKey.category = curam.util.type.CodeTable.getParentCode(
        ProviderTypeName.TABLENAME, providerCategoryType);
    }

    // BEGIN, CR00170625, KR
    ProviderSearchDetailsList providerSearchDetailsList = new ProviderSearchDetailsList();

    if (Configuration.getBooleanProperty(EnvVars.ENV_DYNAMIC_SQL_ENABLED)) {
      providerSearchDetailsList = searchProviderDynamicSql(providerSearchKey);
    } else {

      providerSearchDetailsList = providerObj.searchProvider(providerSearchKey);
    }

    return providerSearchDetailsList;
    // END, CR00170625
  }

  // END, CR00106777

  /**
   * {@inheritDoc}
   */
  public Set<Provider> readAll() {
    return newSet(adapter.readAll());
  }

  /**
   * {@inheritDoc}
   */
  public Provider readByEnquiry(long enquiryID) {
    return getEntity(adapter.readByEnquiry(enquiryID));
  }

  // BEGIN, CR00158121, JSP
  /**
   * {@inheritDoc}
   */
  public List<Provider> searchProvidersForFacilityInformation(
    RetrieveFacilityInformationKey retrieveFacilityInformationKey)
    throws AppException, InformationalException {

    return newList(
      adapter.searchProvidersForFacilityInformation(
        retrieveFacilityInformationKey.searchByProvider,
        retrieveFacilityInformationKey.searchByServiceOffering,
        retrieveFacilityInformationKey.searchByProviderType,
        retrieveFacilityInformationKey.providerConcernRoleID,
        retrieveFacilityInformationKey.serviceOfferingID,
        retrieveFacilityInformationKey.providerType,
        retrieveFacilityInformationKey.searchDate,
        retrieveFacilityInformationKey.startDateTime,
        retrieveFacilityInformationKey.endDateTime,
        retrieveFacilityInformationKey.compartmentStatus,
        retrieveFacilityInformationKey.placeType,
        retrieveFacilityInformationKey.cancelledStatus,
        retrieveFacilityInformationKey.providerStatus,
        retrieveFacilityInformationKey.activeStatus,
        retrieveFacilityInformationKey.providerOfferingStatus,
        retrieveFacilityInformationKey.reservationStatus));
  }

  // END, CR00158121

  // BEGIN, CR00170625, KR
  protected Set<Provider> searchByProviderEnrollmentDynamicSql(String name,
    String referenceNumber, Boolean searchByName,
    Boolean searchByReferenceNumber, String street1, String city,
    Boolean searchByStreet1, Boolean searchByCity, String addressTypeCode,
    String cityTypeCode) throws AppException, InformationalException {

    ProviderDtls[] providerDtlsList = new ProviderDtls[0];

    if (isAnyProviderEnrollmentSearchCriteriaEntered(searchByName,
      searchByReferenceNumber, searchByStreet1, searchByCity)) {

      StringBuilder providerSearchQuery = new StringBuilder();
      StringBuilder selectBuilder = new StringBuilder();
      StringBuilder intoBuilder = new StringBuilder();
      StringBuilder fromBuilder = new StringBuilder();
      StringBuilder whereBuilder = new StringBuilder();

      selectFromProvider(selectBuilder, intoBuilder);

      SearchProviderEnrollmentKey searchProviderEnrollmentKey = new SearchProviderEnrollmentKey();

      populateProviderEnrollmentSearchData(name, referenceNumber, street1, city,
        addressTypeCode, cityTypeCode, searchProviderEnrollmentKey);
      fromBuilder.append(" FROM Provider, ConcernRole");
      whereBuilder.append(" WHERE");
      whereBuilder.append(
        " ConcernRole.concernRoleID = Provider.providerConcernRoleID");
     
      searchByReferenceNumber(searchByReferenceNumber, whereBuilder);
      searchByName(searchByName, whereBuilder);
      searchByStreet1(searchByStreet1, fromBuilder, whereBuilder);
      searchByCity(searchByCity, fromBuilder, whereBuilder);

      whereBuilder.append(" ORDER BY ConcernRole.primaryAlternateID");

      buildFinalQuery(providerSearchQuery, selectBuilder, intoBuilder,
        fromBuilder, whereBuilder);
      
      // BEGIN, CR00292696, IBM
      CuramValueList curamValueList = DynamicDataAccess.executeNsMulti(
        ProviderDtls.class, searchProviderEnrollmentKey, false, true,
        providerSearchQuery.toString());

      // END, CR00292696

      providerDtlsList = new ProviderDtls[curamValueList.size()];

      for (int i = 0; i < curamValueList.size(); i++) {
        providerDtlsList[i] = (ProviderDtls) curamValueList.get(i);
      }
    }
    return newSet(providerDtlsList);
  }
  
  // BEGIN, CR00304588, GA
  /**
   * Creates and executes the dynamic query for searching providers with address, service and date details.
   *
   * @param name
   * Contains the name of the Provider.
   * @param searchByName
   * Contains the searchByName indicator.
   * @param street1
   * Contains the street1 in the address of the Provider.
   * @param searchByStreet1
   * Contains the searchByStreet1 indicator.
   * @param city
   * Contains the city in the address of the Provider.
   * @param searchByCity
   * Contains the searchByCity indicator.
   * @param cityTypeCode
   * Contains the cityTypeCode in the address of the Provider.
   * @param serviceID
   * Contains the service ID.
   * @param fromDate
   * Contains the fromDate to start the search.
   * @param toDate
   * Contains the toDate to end the search.
   *
   * @return The list of provider details(ProviderConcernRoleID,PrimaryAlternateID,ProviderName,PrimaryAddressID) matching the
   * search criteria.
   *
   * @throws InformationalException Generic Exception Signature.
   * @throws AppException Generic Exception Signature.
   */
  protected ProviderAndServiceSearchResultList searchByProviderDynamicSql(final StringBuilder name,
    final Boolean searchByName,
    final StringBuilder street1, final Boolean searchByStreet1, final StringBuilder city,
    final Boolean searchByCity, final String addressTypeCode,
    final String cityTypeCode, final long serviceID, final Date fromDate, final Date toDate) throws AppException, InformationalException {

    final ProviderAndServiceSearchResultList providerAndServiceSearchResults = new ProviderAndServiceSearchResultList();
    
    final String poStatus = ProviderOfferingStatusEntry.APPROVED.getCode();    

    if (searchByName || searchByStreet1 || searchByCity) {

      StringBuilder providerSearchQuery = new StringBuilder();
      StringBuilder selectBuilder = new StringBuilder();
      StringBuilder intoBuilder = new StringBuilder();
      StringBuilder fromBuilder = new StringBuilder();
      StringBuilder whereBuilder = new StringBuilder();

      selectFromProviderAndConcernRoleAndProviderOffering(selectBuilder,
        intoBuilder);

      final ProviderSearchDetailsKey providerSearchDetailsKey = new ProviderSearchDetailsKey();

      populateProviderSearchData(name, searchByName, street1, searchByStreet1,
        city, searchByCity, addressTypeCode, cityTypeCode, serviceID, poStatus,
        fromDate, toDate, providerSearchDetailsKey);      
      
      fromBuilder.append(" FROM Provider, ConcernRole, ProviderOffering");
      whereBuilder.append(" WHERE");
      whereBuilder.append(
        " Provider.providerConcernRoleID = ConcernRole.concernRoleID");
      whereBuilder.append(
        " AND Provider.providerConcernRoleID = ProviderOffering.providerconcernroleID");
      whereBuilder.append(
        " AND ProviderOffering.serviceOfferingID = :serviceID");    
      whereBuilder.append(" AND ProviderOffering.recordStatus = :poStatus");      
      
      searchByName(searchByName, whereBuilder);
      searchByStreet1(searchByStreet1, fromBuilder, whereBuilder);
      searchByCity(searchByCity, fromBuilder, whereBuilder);
      searchByFromDate(fromDate, whereBuilder);
      searchByToDate(toDate, whereBuilder);

      whereBuilder.append(" ORDER BY Provider.name");

      buildFinalQuery(providerSearchQuery, selectBuilder, intoBuilder,
        fromBuilder, whereBuilder);      

      final CuramValueList<ProviderAndServiceSearchResult> curamValueList = DynamicDataAccess.executeNsMulti(
        ProviderAndServiceSearchResult.class, providerSearchDetailsKey, false,
        true, providerSearchQuery.toString());

      for (final ProviderAndServiceSearchResult providerAndServiceSearchResult : curamValueList.items()) {
        providerAndServiceSearchResults.dtls.add(providerAndServiceSearchResult);
      }
    }
    return providerAndServiceSearchResults;
  }

  // END, CR00304588


  protected void buildFinalQuery(StringBuilder providerSearchQuery,
    StringBuilder selectBuilder, StringBuilder intoBuilder,
    StringBuilder fromBuilder, StringBuilder whereBuilder) {
    providerSearchQuery.append(selectBuilder);
    providerSearchQuery.append(intoBuilder);
    providerSearchQuery.append(fromBuilder);
    providerSearchQuery.append(whereBuilder);
  }

  protected void searchByName(Boolean searchByName, StringBuilder whereBuilder) {
    if (searchByName) {
      whereBuilder.append(" AND Provider.nameUpper like :name ");
    }
  }

  protected void searchByReferenceNumber(Boolean searchByReferenceNumber,
    StringBuilder whereBuilder) {
    if (searchByReferenceNumber) {
      whereBuilder.append(
        " AND ConcernRole.primaryAlternateID = :referenceNumber ");
    }
  }

  protected void searchByCity(Boolean searchByCity, StringBuilder fromBuilder,
    StringBuilder whereBuilder) {
    if (searchByCity) {
      fromBuilder.append(" ,AddressElement city ");
      whereBuilder.append(" AND city.upperElementValue like :city ");
      whereBuilder.append(" AND city.addressID = ConcernRole.primaryAddressID");
      whereBuilder.append(" AND city.elementType = :cityTypeCode ");
    }
  }

  protected void searchByStreet1(Boolean searchByStreet1,
    StringBuilder fromBuilder, StringBuilder whereBuilder) {
    if (searchByStreet1) {
      fromBuilder.append("  ,AddressElement addressLine1 ");
      whereBuilder.append(" AND addressLine1.upperElementValue like :street1 ");
      whereBuilder.append(
        " AND addressLine1.addressID = ConcernRole.primaryAddressID");
      whereBuilder.append(" AND addressLine1.elementType = :addressTypeCode ");
    }
  }
  
  // BEGIN, CR00304588, GA
  /**
   * Adds the search by given from date condition to the where clause of the dynamic query.
   *
   * @param fromDate 
   * Contains fromDate of search criteria.
   * @param whereBuilder 
   * Contains reference to whereBuilder clause of the dynamic query.
   */
  protected void searchByFromDate(Date fromDate, StringBuilder whereBuilder) {
	  
    if (!fromDate.isZero()) {		
      whereBuilder.append("  AND ProviderOffering.startDate <= :fromDate");
    }
  }
  
  /**
   * Adds the search by given to date condition to the where clause of the dynamic query.
   *
   * @param fromDate 
   * Contains toDate of search criteria.
   * @param whereBuilder 
   * Contains reference to whereBuilder clause of the dynamic query.
   */
  protected void searchByToDate(Date toDate, StringBuilder whereBuilder) {
	  
    if (!toDate.isZero()) {		
      whereBuilder.append(
        "  AND (ProviderOffering.endDate IS NULL OR ProviderOffering.endDate >= :toDate)");
    }
  }

  // END, CR00304588

  protected void populateProviderEnrollmentSearchData(String name,
    String referenceNumber, String street1, String city,
    String addressTypeCode, String cityTypeCode,
    SearchProviderEnrollmentKey searchProviderEnrollmentKey) {
    searchProviderEnrollmentKey.referenceNumber = referenceNumber;
    searchProviderEnrollmentKey.name = name;
    searchProviderEnrollmentKey.street1 = street1;
    searchProviderEnrollmentKey.city = city;
    searchProviderEnrollmentKey.addressTypeCode = addressTypeCode;
    searchProviderEnrollmentKey.cityTypeCode = cityTypeCode;
  }
  
  // BEGIN, CR00304588, GA
  /**
   * Populates the input data to input struct of the dynamic query for the searching providers.
   *
   * @param name
   * Contains the name of the Provider.
   * @param searchByName
   * Contains the searchByName indicator.
   * @param street1
   * Contains the street1 in the address of the Provider.
   * @param searchByStreet1
   * Contains the searchByStreet1 indicator.
   * @param city
   * Contains the city in the address of the Provider.
   * @param searchByCity
   * Contains the searchByCity indicator.
   * @param addressTypeCode
   * Contains the addressTypeCode in the address of the Provider.
   * @param cityTypeCode
   * Contains the cityTypeCode in the address of the Provider.
   * @param serviceID
   * Contains the service ID.
   * @param poStatus
   * Contains the provider offering status.
   * @param fromDate
   * Contains the fromDate.
   * @param toDate
   * Contains the toDate.
   * @param providerSearchDetailsKey
   * The input struct used to populate the data.
   */
  protected void populateProviderSearchData(final StringBuilder name, final Boolean searchByName,
    final StringBuilder street1, final Boolean searchByStreet1, final StringBuilder city, final Boolean searchByCity,
    final String addressTypeCode, final String cityTypeCode, final Long serviceID, final String poStatus, final Date fromDate, final Date toDate,
    final ProviderSearchDetailsKey providerSearchDetailsKey) {
	  
    providerSearchDetailsKey.name = name.toString();
    providerSearchDetailsKey.searchByName = searchByName;	  
    providerSearchDetailsKey.street1 = street1.toString();
    providerSearchDetailsKey.searchByStreet1 = searchByStreet1;
    providerSearchDetailsKey.city = city.toString();
    providerSearchDetailsKey.searchByCity = searchByCity;
    providerSearchDetailsKey.addressTypeCode = addressTypeCode;
    providerSearchDetailsKey.cityTypeCode = cityTypeCode;
    providerSearchDetailsKey.serviceID = serviceID;
    providerSearchDetailsKey.poStatus = poStatus;
	  
    if (!fromDate.isZero()) {
      providerSearchDetailsKey.searchByFromDate = true; 
      providerSearchDetailsKey.fromDate = fromDate;
    }
    if (!toDate.isZero()) {	    
      providerSearchDetailsKey.searchByToDate = true;
      providerSearchDetailsKey.toDate = toDate;
    }
  }

  // END, CR00304588
  
  protected boolean isAnyProviderEnrollmentSearchCriteriaEntered(
    Boolean searchByName, Boolean searchByReferenceNumber,
    Boolean searchByStreet1, Boolean searchByCity) {
    return isAnySearchByProviderCriteriaEntered(searchByCity,
      searchByReferenceNumber, searchByStreet1, searchByName);
  }

  // BEGIN, CR00178548, AK
  protected void selectFromProvider(StringBuilder selectBuilder,
    StringBuilder intoBuilder) {
    selectBuilder.append(" SELECT");
    selectBuilder.append(" Provider.providerConcernRoleID,");
    selectBuilder.append(" Provider.providerEnquiryID,");
    selectBuilder.append(" Provider.physicalCapacity,");
    selectBuilder.append(" Provider.paymentFrequency,");
    selectBuilder.append(" Provider.methodOfPayment,");
    selectBuilder.append(" Provider.currencyType,");
    selectBuilder.append(" Provider.reservationGracePeriod,");
    selectBuilder.append(" Provider.recordStatus,");
    selectBuilder.append(" Provider.overrideMDRInd,");
    selectBuilder.append(" Provider.preferredSEMethod,");
    selectBuilder.append(" Provider.areasSvdInfoTxtID,");
    selectBuilder.append(" Provider.clientInfoTextID,");
    selectBuilder.append(" Provider.name,");
    selectBuilder.append(" Provider.nameUpper,");
    selectBuilder.append(" Provider.versionNo,");

    // BEGIN, CR00198774, RPB
    selectBuilder.append(" Provider.enrollmentDateTime,");
    selectBuilder.append(" Provider.endDateTime,");
    // END, CR00198774

    // BEGIN, CR00248700, RPB
    selectBuilder.append(" Provider.acceptCWReferral");
    // END, CR00248700

    intoBuilder.append(" INTO ");
    intoBuilder.append(" :providerConcernRoleID,");
    intoBuilder.append(" :providerEnquiryID,");
    intoBuilder.append(" :physicalCapacity,");
    intoBuilder.append(" :paymentFrequency,");
    intoBuilder.append(" :methodOfPayment,");
    intoBuilder.append(" :currencyType,");
    intoBuilder.append(" :reservationGracePeriod,");
    intoBuilder.append(" :recordStatus,");
    intoBuilder.append(" :overrideMDRInd,");
    intoBuilder.append(" :preferredSEMethod,");
    intoBuilder.append(" :areasSvdInfoTxtID,");
    intoBuilder.append(" :clientInfoTextID,");
    intoBuilder.append(" :name,");
    intoBuilder.append(" :nameUpper,");
    intoBuilder.append(" :versionNo,");

    // BEGIN, CR00198774, RPB
    intoBuilder.append(" :enrollmentDateTime,");
    intoBuilder.append(" :endDateTime,");
    // BEGIN, CR00248700, RPB
    intoBuilder.append(" :acceptCWReferral");
    // END, CR00248700

    // END, CR00198774

  }

  // END, CR00178548
  
  // BEGIN, CR00304588, GA
  /**
   * Creates the select and into clauses of the dynamic query for the searching providers.
   *
   * @param selectBuilder
   * Contains the reference to the select clause.
   * @param intoBuilder
   * Contains the reference to the into clause.   
   */
  protected void selectFromProviderAndConcernRoleAndProviderOffering(final StringBuilder selectBuilder,
    final StringBuilder intoBuilder) {
    
    selectBuilder.append(" SELECT");
    selectBuilder.append(" DISTINCT Provider.providerConcernRoleID,");
    selectBuilder.append(" Provider.name,");
    selectBuilder.append(" ConcernRole.primaryAlternateID,");
    selectBuilder.append(" ConcernRole.primaryAddressID");        		
    
    intoBuilder.append(" INTO ");
    intoBuilder.append(" :providerConcernRoleID,");
    intoBuilder.append(" :providerName,");
    intoBuilder.append(" :primaryAlternateID,");
    intoBuilder.append(" :primaryAddressID");      

  }

  // END, CR00304588

  protected ProviderSearchDetailsList searchProviderDynamicSql(
    ProviderSearchKey providerSearchKey) throws AppException,
      InformationalException {

    ProviderSearchDetailsList providerSearchDetailsList = new ProviderSearchDetailsList();

    if (providerSearchKey.searchByReferenceNumber
      || providerSearchKey.searchByName || providerSearchKey.searchByCategory
      || providerSearchKey.searchByOwner || providerSearchKey.searchByType) {

      StringBuilder providerSearchQuery = new StringBuilder();
      StringBuilder selectBuilder = new StringBuilder();
      StringBuilder intoBuilder = new StringBuilder();
      StringBuilder fromBuilder = new StringBuilder();
      StringBuilder whereBuilder = new StringBuilder();

      selectBuilder.append(" SELECT");
      selectBuilder.append(" DISTINCT(Provider.providerConcernRoleID),");
      selectBuilder.append(" AdministrationRole.userName");
      intoBuilder.append(" INTO ");
      intoBuilder.append(" :providerConcernRoleID,");
      intoBuilder.append(" :owner");

      fromBuilder.append(
        " FROM Provider, ConcernRole, AdministrationConcernRole, AdministrationRole, Users");
      whereBuilder.append(" WHERE");

      whereBuilder.append(
        " ConcernRole.concernRoleID = Provider.providerConcernRoleID");

      searchByReferenceNumber(providerSearchKey.searchByReferenceNumber,
        whereBuilder);
      searchByName(providerSearchKey.searchByName, whereBuilder);
      searchByProviderCategoryAndType(providerSearchKey.searchByCategory,
        providerSearchKey.searchByType, fromBuilder, whereBuilder);

      if (providerSearchKey.searchByOwner) {
        whereBuilder.append(" AND Users.upperUserName like :ownerName ");
      } // BEGIN, CR00261066, SSK
      else {
        whereBuilder.append(" AND AdministrationConcernRole.enddate IS NULL ");
      }
      // END, CR00261066
      whereBuilder.append(
        " AND AdministrationRole.administrationRoleID = AdministrationConcernRole.administrationRoleID");
      whereBuilder.append(
        " AND AdministrationConcernRole.concernRoleID = Provider.providerConcernRoleID");
      whereBuilder.append(" AND AdministrationRole.userName = Users.userName");
      whereBuilder.append(
        " AND AdministrationConcernRole.typeCode = :userType ");
      
      buildFinalQuery(providerSearchQuery, selectBuilder, intoBuilder,
        fromBuilder, whereBuilder);
      
      // BEGIN, CR00292696, IBM 
      CuramValueList curamValueList = DynamicDataAccess.executeNsMulti(
        ProviderSearchDetails.class, providerSearchKey, false, true, 
        providerSearchQuery.toString());

      // END, CR00292696

      for (int i = 0; i < curamValueList.size(); i++) {
        providerSearchDetailsList.dtls.addRef(
          (ProviderSearchDetails) curamValueList.get(i));
      }
    }
    return providerSearchDetailsList;
  }

  protected void searchByProviderCategoryAndType(boolean searchByCategory,
    boolean searchByType, StringBuilder fromBuilder,
    StringBuilder whereBuilder) {
    if (searchByCategory) {
      whereBuilder.append(" AND ProviderCategoryPeriod.category = :category ");
    }
    if (searchByType) {
      whereBuilder.append(" AND ProviderType.type = :providerCategoryType ");
    }

    if (searchByCategory || searchByType) {
      fromBuilder.append(" , ProviderCategoryPeriod, ProviderType");
      whereBuilder.append(
        " AND Provider.providerConcernRoleID = ProviderCategoryPeriod.providerConcernRoleID");
      whereBuilder.append(
        " AND ProviderCategoryPeriod.providerCategoryID = ProviderType.providerCategoryID");
    }
  }

  protected Set<Provider> searchByDynamicSql(String name, String referenceNumber,
    Boolean searchByName, Boolean searchByReferenceNumber, String category,
    String providerCategoryType, Boolean searchByCategory,
    Boolean searchByType, Boolean primaryCategoryInd) throws AppException,
      InformationalException {

    ProviderDtls[] providerDtlsList = new ProviderDtls[0];

    if (isAnySearchByProviderCriteriaEntered(searchByName,
      searchByReferenceNumber, searchByCategory, searchByType)) {

      StringBuilder providerSearchQuery = new StringBuilder();
      StringBuilder selectBuilder = new StringBuilder();
      StringBuilder intoBuilder = new StringBuilder();
      StringBuilder fromBuilder = new StringBuilder();
      StringBuilder whereBuilder = new StringBuilder();

      selectFromProvider(selectBuilder, intoBuilder);
      SearchProviderKey searchProviderKey = new SearchProviderKey();

      populateSearchProviderKey(name, referenceNumber, category,
        providerCategoryType, searchProviderKey, primaryCategoryInd);

      fromBuilder.append(" FROM Provider, ConcernRole");
      whereBuilder.append(" WHERE");
      whereBuilder.append(
        " ConcernRole.concernRoleID = Provider.providerConcernRoleID");
      searchByReferenceNumber(searchByReferenceNumber, whereBuilder);
      searchByName(searchByName, whereBuilder);
      searchByProviderCategoryAndType(searchByCategory, searchByType,
        fromBuilder, whereBuilder);
      selectPrimaryCategory(searchByCategory, searchByType, fromBuilder,
        whereBuilder);

      whereBuilder.append(" ORDER BY ConcernRole.primaryAlternateID");
      buildFinalQuery(providerSearchQuery, selectBuilder, intoBuilder,
        fromBuilder, whereBuilder);
      
      // BEGIN, CR00292696, IBM 
      CuramValueList curamValueList = DynamicDataAccess.executeNsMulti(
        ProviderDtls.class, searchProviderKey, false, true, 
        providerSearchQuery.toString());

      // END, CR00292696
      
      providerDtlsList = new ProviderDtls[curamValueList.size()];

      for (int i = 0; i < curamValueList.size(); i++) {
        providerDtlsList[i] = (ProviderDtls) curamValueList.get(i);
      }
    }

    return newSet(providerDtlsList);
  }

  protected void selectPrimaryCategory(Boolean searchByCategory,
    Boolean searchByType, StringBuilder fromBuilder,
    StringBuilder whereBuilder) {
    if (searchByCategory || searchByType) {
      fromBuilder.append(" , ProviderCategoryPeriod PrimaryCategory");
      whereBuilder.append(
        " AND PrimaryCategory.primaryInd = :primaryCategoryInd ");
    }
  }

  protected void populateSearchProviderKey(String name, String referenceNumber,
    String category, String providerCategoryType,
    SearchProviderKey searchProviderKey, boolean primaryCategoryInd) {
    searchProviderKey.referenceNumber = referenceNumber;
    searchProviderKey.name = name;
    searchProviderKey.category = category;
    searchProviderKey.primaryCategoryInd = primaryCategoryInd;
    searchProviderKey.providerCategoryType = providerCategoryType;
  }

  protected boolean isAnySearchByProviderCriteriaEntered(Boolean searchByName,
    Boolean searchByReferenceNumber, Boolean searchByCategory,
    Boolean searchByType) {
    return searchByReferenceNumber || searchByType || searchByCategory
      || searchByName;
  }

  // END, CR00170625

  // BEGIN, CR00197073, ASN
  /**
   * {@inheritDoc}
   */
  public ProviderMembersBackgroundCheckDetailsList searchProviderMembersBackgroundCheckDetails(
    final Provider provider) throws AppException, InformationalException {

    curam.cpm.sl.entity.intf.Provider providerObj = ProviderFactory.newInstance();
    SearchByProviderDetails searchByProviderDetails = new SearchByProviderDetails();

    searchByProviderDetails.providerConcernRoleID = provider.getID();
    searchByProviderDetails.category = ProviderPartyCategoryEntry.MEMBER.getCode();
    searchByProviderDetails.recordStatus = RECORDSTATUSEntry.NORMAL.getCode();

    return providerObj.searchProviderMembersBackGroundCheckDetails(
      searchByProviderDetails);
  }

  // END, CR00197073

  // BEGIN, CR00229264, VR
  /**
   * {@inheritDoc}
   */
  public FinancialInstructionDetailList searchByFinancialInstructionAndILIType(
    SearchByFIAndILITypeKey searchByFIAndILITypeKey) throws AppException,
      InformationalException {
    curam.cpm.sl.entity.intf.Provider providerObj = ProviderFactory.newInstance();
    FinancialInstructionDetailList detailList = providerObj.searchByFinancialInstructionAndILIType(
      searchByFIAndILITypeKey);

    return detailList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderFinancialDetailList searchFinancialsByConcernRole(
    final long concernRoleID) throws AppException, InformationalException {

    curam.cpm.sl.entity.intf.Provider providerObj = ProviderFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleID;
    ProviderFinancialDetailList providerFinancialDetailList = providerObj.searchFinancialsByConcernRole(
      concernRoleKey);

    return providerFinancialDetailList;
  }

  /**
   * {@inheritDoc}
   */
  public ProviderFinancialDetailList searchLiabilitiesByConcernRole(
    final long concernRoleID) throws AppException, InformationalException {
    curam.cpm.sl.entity.intf.Provider providerObj = ProviderFactory.newInstance();
    ConcernRoleKey concernRoleKey = new ConcernRoleKey();

    concernRoleKey.concernRoleID = concernRoleID;
    ProviderFinancialDetailList providerFinancialDetailList = providerObj.searchLiabilitiesByConcernRole(
      concernRoleKey);

    return providerFinancialDetailList;
  }

  // END, CR00229264
  

  // BEGIN, CR00291801, ASN
  /**
   * {@inheritDoc}
   */
  public ProviderInvestigationDetailsList readProviderInvestigations(
    final long concernRoleID, final CASETYPECODEEntry caseTypeCode,
    final RECORDSTATUSEntry recordStatus,
    final CASEPARTICIPANTROLETYPEEntry caseParticipantRoleType)
    throws AppException, InformationalException {

    curam.cpm.sl.entity.intf.Provider providerObj = ProviderFactory.newInstance();
    ProviderInvestigationCriteria providerInvestigationCriteria = new ProviderInvestigationCriteria();

    providerInvestigationCriteria.providerConcernRoleID = concernRoleID;
    providerInvestigationCriteria.caseTypeCode = caseTypeCode.getCode();
    providerInvestigationCriteria.recordStatus = recordStatus.getCode();
    providerInvestigationCriteria.typeCode = caseParticipantRoleType.getCode();
    return providerObj.searchProviderInvestigations(
      providerInvestigationCriteria);
  }
  // END, CR00291801

  
}
