/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Commented;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.Date;
import curam.util.type.DateRange;


/**
 * Background checks undertaken on employees or household members of a provider.
 *
 * For example, an SEM agency may wish to conduct both a Criminal Investigation
 * check and a Child Protective Service check on all employees of each of their
 * Day Care Centers. The actual background check may be conducted by the agency
 * itself (e.g. in the case of a Child Protective Service check) or may be
 * conducted by an outside body.
 */
@ImplementedBy(BackgroundCheckImpl.class)
public interface BackgroundCheck extends BackgroundCheckAccessor, Insertable,
    LogicallyDeleteable, Commented, OptimisticLockModifiable {

  /**
   * Sets the type of the provider Background Check.
   *
   * @param type
   * The type of the provider background check to be set.
   */
  public void setType(final BackgroundCheckTypeEntry type);

  /**
   * Sets the Result of the provider Background Check.
   *
   * @param result The result of the provider background check to be set.
   */
  public void setResult(final BackgroundCheckResultEntry result);

  /**
   * Sets the daterange(request date and receipt date) of the provider
   * Background Check.
   *
   * @param value
   * The daterange of the background check to be set.
   *
   * @see curam.provider.impl.BackgroundCheck#setDateRange(DateRange) The default
   * implementation -
   * curam.provider.impl.BackgroundCheckImpl#setDateRange(DateRange).
   */
  public void setDateRange(final DateRange value);

  /**
   * Sets the expiry date of the provider Background Check.
   *
   * @param value
   * The expiry date of the background check to be set.
   *
   * @see curam.provider.impl.BackgroundCheck#setExpiryDate(Date) The default
   * implementation -
   * curam.provider.impl.BackgroundCheckImpl#setExpiryDate(Date).
   */
  public void setExpiryDate(final Date value);

  /**
   * Gets the immutable provider member for whom Background Check to be done.
   *
   * @return Immutable Provider Member for whom background check to be done.
   */
  public ProviderMember getProviderMember();

}

