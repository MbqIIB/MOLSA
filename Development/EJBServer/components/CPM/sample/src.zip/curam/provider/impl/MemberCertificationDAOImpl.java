/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.ArrayList;
import java.util.List;
import com.google.inject.Singleton;
import curam.codetable.impl.RECORDSTATUSEntry;
import curam.cpm.sl.impl.MemberCertificationAdapter;
import curam.cpm.sl.struct.MemberCertificationDtls;
import curam.util.persistence.StandardDAOImpl;
import curam.util.persistence.helper.LifecycleHelper;


/**
 * Standard implementation of {@linkplain curam.provider.impl.MemberCertificationDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class MemberCertificationDAOImpl extends StandardDAOImpl<MemberCertification, MemberCertificationDtls> implements
  MemberCertificationDAO {
  // END, CR00183213
  /**
   * Adapter initialization
   */
  protected static final MemberCertificationAdapter adapter = new MemberCertificationAdapter();

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  // END, CR00183213
  protected MemberCertificationDAOImpl() {
    super(adapter, MemberCertification.class);
  }

  // BEGIN, CR00121578, NRV
  /**
   * {@inheritDoc}
   */
  public List<MemberCertification> searchActiveMemberCertificationByParty(
    final long providerConcernRoleID) {

    List<MemberCertification> filteredList = new ArrayList<MemberCertification>();

    LifecycleHelper.filter(
      newList(adapter.searchByPartyConcernRoleID(providerConcernRoleID)),
      RECORDSTATUSEntry.NORMAL, filteredList);
    return filteredList;
  }

  // END, CR00121578
  /**
   * {@inheritDoc}
   */
  public List<MemberCertification> searchActiveMemberCertificationByCertification(
    final long certificationId) {

    List<MemberCertification> filteredList = new ArrayList<MemberCertification>();

    LifecycleHelper.filter(
      newList(adapter.searchByCertificationID(certificationId)),
      RECORDSTATUSEntry.NORMAL, filteredList);
    return filteredList;
  }

}
