/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2010, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.Inject;
import com.google.inject.Singleton;

import curam.core.impl.EnvVars;
import curam.core.struct.AlternateIDSearchKey;
import curam.core.struct.Count;
import curam.cpm.impl.CPMConstants;
import curam.cpm.sl.entity.fact.ProviderFactory;
import curam.cpm.util.impl.ReferenceNumberUtility;
import curam.cpm.util.impl.SequentialContinuousRefNumberDAO;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.resources.Configuration;


/**
 * This class Provides the default implementation for ReferenceNumber
 * generation.
 */
@Singleton
// BEGIN, CR00183213, SS
public class ProviderReferenceNumberStrategyImpl implements
  ProviderReferenceNumberStrategy {
  // END, CR00183213
  // BEGIN, CR00170638, GP
  /**
   * Reference to Sequential Continuous Reference Number.
   */
  @Inject
  SequentialContinuousRefNumberDAO sequentialContinuousRefNumberDAO;

  // BEGIN, CR00314817, GYH
  /**
   * Reference to reference number generation utility class.
   */
  @Inject
  protected ReferenceNumberUtility referenceNumberUtility;
  // END, CR00314817

  // END, CR00170638
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected ProviderReferenceNumberStrategyImpl() {// The no-arg constructor for
    // use only by Guice.
    // END, CR00183213
  }

  /**
   * {@inheritDoc}
   */
  public String generateReferenceNumber() throws AppException,
      InformationalException {

    // BEGIN, CR00185107, GP
    // BEGIN, CR00314817, GYH
    String referenceNumber = null;
    curam.cpm.sl.entity.intf.Provider providerObj = ProviderFactory.newInstance();
    AlternateIDSearchKey alternateIDSearchKey = new AlternateIDSearchKey();
    Count count;

    while (true) {

      if (Configuration.getBooleanProperty(
        EnvVars.ENV_REFERENCENUMBER_GENERATEPROVIDERREFERENCENUMBERFROMKEYSET)) {
        referenceNumber = referenceNumberUtility.generateReferenceNumber(
          CPMConstants.kProviderKeySetName);
      } else {
        referenceNumber = String.valueOf(
          sequentialContinuousRefNumberDAO.generateSequentialContinuousReferenceNumber(
            CPMConstants.kProviderCodeName));
      }

      alternateIDSearchKey.alternateID = referenceNumber;
      count = providerObj.countConcernRolesByAlternateID(alternateIDSearchKey);

      if (0 < count.numberOfRecords) {
        // Continue to generate the next reference number as the reference
        // number in process is already a reference for the existing concern
        // role.
        continue;
      } else {
        // The reference number in process (generated) is not used before, return this reference number.
        break;
      }
    }
    // END, CR00314817
    // END, CR00185107

    return referenceNumber;
  }

}
