/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2007, 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2007-2009, 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import java.util.Set;

import com.google.inject.ImplementedBy;

import curam.contracts.impl.ContractVersion;
import curam.core.intf.ConcernRole;
import curam.core.sl.struct.RepresentativeRegistrationDetails;
import curam.core.struct.AddressDtls;
import curam.core.struct.BankAccountDetails;
import curam.core.struct.ConcernRoleAddressDtls;
import curam.core.struct.ConcernRoleContactDtls;
import curam.core.struct.ConcernRoleDtls;
import curam.core.struct.ConcernRolePhoneNumberDtls;
import curam.core.struct.PhoneNumberDtls;
import curam.cpm.sl.entity.struct.ProviderGroupKey;
import curam.serviceoffering.impl.ServiceOffering;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Lifecycle;
import curam.util.type.AccessLevel;
import curam.util.type.AccessLevelType;


/**
 * An organization to which a cluster of providers are related.
 *
 * For example Catholic Charities is an umbrella organization which encompasses
 * many providers who deliver many different services such as counseling, day
 * care and foster care.
 */
@ImplementedBy(ProviderGroupImpl.class)
@AccessLevel(AccessLevelType.EXTERNAL)
public interface ProviderGroup extends ProviderOrganization,
    OptimisticLockModifiable, Lifecycle<ProviderGroupStatusEntry>,
    ProviderGroupAccessor {

  /**
   * Inserts provider group enrollment details.
   * Also notifies the provider group enrollment and raises a workflow
   * event.
   *
   * @param addressDtls
   * Contains address related values.
   * @param phoneNumberDtls
   * Contains phone number related values.
   * @param concernRolePhoneNumberDtls
   * Contains concern role phone details.
   * @param concernRoleDtls
   * Contains concern role details values.
   * @param concernRoleAddressDtls
   * Contains concern role address related values.
   * @param bankAccountDetails
   * Contains bank account related values.
   * @param representativeRegistrationDetails
   * Contains representative registration related values.
   * @param concernRoleContactDtls
   * Contains concern role contact related values.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderGroupImpl#enroll(AddressDtls,
   * PhoneNumberDtls, ConcernRolePhoneNumberDtls, ConcernRoleDtls,
   * ConcernRoleAddressDtls, BankAccountDetails,
   * RepresentativeRegistrationDetails, ConcernRoleContactDtls) The default
   * implementation -
   * {@link curam.provider.impl.ProviderGroupImpl#enroll(AddressDtls, PhoneNumberDtls, ConcernRolePhoneNumberDtls, ConcernRoleDtls, ConcernRoleAddressDtls, BankAccountDetails, RepresentativeRegistrationDetails, ConcernRoleContactDtls)}.
   */
  void enroll(AddressDtls addressDtls, PhoneNumberDtls phoneNumberDtls,
    ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls,
    ConcernRoleDtls concernRoleDtls,
    ConcernRoleAddressDtls concernRoleAddressDtls,
    BankAccountDetails bankAccountDetails,
    RepresentativeRegistrationDetails representativeRegistrationDetails,
    ConcernRoleContactDtls concernRoleContactDtls) throws AppException,
      InformationalException;

  /**
   * Modifies the provider group details. Validates and updates the provider
   * Group details.
   * Also notifies the provider group modification and raises a workflow
   * event.
   *
   * @param concernRoleObj
   * Contains ConcernRole object.
   * @param concernRoleDtls
   * Contains concern role related values.
   * @param versionNo
   * versionNo for modify the Provider group.
   *
   * @return ProviderGroupKey the provider group key.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderGroupImpl#modify(ConcernRole,
   * ConcernRoleDtls, int) The default implementation -
   * {@link curam.provider.impl.ProviderGroupImpl#modify(ConcernRole, ConcernRoleDtls, int)}.
   */
  ProviderGroupKey modify(ConcernRole concernRoleObj,
    ConcernRoleDtls concernRoleDtls, int versionNo) throws AppException,
      InformationalException;

  // BEGIN, CR00144284, SK
  /**
   * Reopen the provider Group for the providing the services to an
   * organization's clients. Also notifies the provider group reopen and raises
   * a workflow event.
   *
   * Transitions the state to
   * {@linkplain curam.provider.impl.ProviderGroupStatusEntry#ACTIVE}, if it is
   * valid to reopen the provider Group.
   *
   * @param versionNo
   * the version number as previously retrieved.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderGroupImpl#reopen(int) The default
   * implementation -
   * {@link curam.provider.impl.ProviderGroupImpl#reopen(int)}.
   */
  // END, CR00144284
  void reopen(final int versionNo) throws InformationalException,
      AppException;

  // BEGIN, CR00144284, SK
  /**
   * Ceases the provider group business with the agency and raises a workflow
   * event.
   *
   * Transitions the state to
   * {@linkplain curam.provider.impl.ProviderGroupStatusEntry#CLOSED}, if it is
   * valid to cease conducting business.
   *
   * @param versionNo
   * the version number as previously retrieved.
   *
   * @throws AppException
   * Generic Exception Signature.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.ProviderGroupImpl#close(int) The default
   * implementation -
   * {@link curam.provider.impl.ProviderGroupImpl#close(int)}.
   */
  // END, CR00144284
  void close(final int versionNo) throws InformationalException, AppException;

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider group events functionality surrounding the close
   * method.
   */
  public interface ProviderGroupCloseEvents {

    /**
     * Event interface invoked before the main body of the close method.
     * {@linkplain curam.provider.impl.ProviderGroup#close}
     *
     * @param providerGroup
     * The object instance as it was before the main body of the close
     * method.
     * @param versionNo
     * The parameter as passed to the close method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void preClose(ProviderGroupAccessor providerGroup, int versionNo)
      throws InformationalException, AppException;

    /**
     * Event interface invoked after the main body of the close method.
     * {@linkplain curam.provider.impl.ProviderGroup#close}
     *
     * @param providerGroup
     * The object instance as it was after the main body of the close
     * method.
     * @param versionNo
     * The parameter as passed to the close method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void postClose(ProviderGroupAccessor providerGroup, int versionNo)
      throws InformationalException, AppException;
  }


  /**
   * Interface to the provider group events functionality surrounding the enroll
   * method.
   */
  public interface ProviderGroupEnrollEvents {

    /**
     * Event interface invoked before the main body of the enroll method.
     * {@linkplain curam.provider.impl.ProviderGroup#enroll}
     *
     * @param providerGroup
     * The object instance as it was before the main body of the enroll
     * method.
     * @param addressDtls
     * The parameter as passed to the enroll method.
     * @param phoneNumberDtls
     * The parameter as passed to the enroll method.
     * @param concernRolePhoneNumberDtls
     * The parameter as passed to the enroll method.
     * @param concernRoleDtls
     * The parameter as passed to the enroll method.
     * @param concernRoleAddressDtls
     * The parameter as passed to the enroll method.
     * @param bankAccountDetails
     * The parameter as passed to the enroll method.
     * @param representativeRegistrationDetails
     * The parameter as passed to the enroll method.
     * @param concernRoleContactDtls
     * The parameter as passed to the enroll method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preEnroll(ProviderGroupAccessor providerGroup,
      AddressDtls addressDtls, PhoneNumberDtls phoneNumberDtls,
      ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls,
      ConcernRoleDtls concernRoleDtls,
      ConcernRoleAddressDtls concernRoleAddressDtls,
      BankAccountDetails bankAccountDetails,
      RepresentativeRegistrationDetails representativeRegistrationDetails,
      ConcernRoleContactDtls concernRoleContactDtls) throws AppException,
        InformationalException;

    /**
     * Event interface invoked after the main body of the enroll method.
     * {@linkplain curam.provider.impl.ProviderGroup#enroll}
     *
     * @param providerGroup
     * The object instance as it was after the main body of the enroll
     * method.
     * @param addressDtls
     * The parameter as passed to the enroll method.
     * @param phoneNumberDtls
     * The parameter as passed to the enroll method.
     * @param concernRolePhoneNumberDtls
     * The parameter as passed to the enroll method.
     * @param concernRoleDtls
     * The parameter as passed to the enroll method.
     * @param concernRoleAddressDtls
     * The parameter as passed to the enroll method.
     * @param bankAccountDetails
     * The parameter as passed to the enroll method.
     * @param representativeRegistrationDetails
     * The parameter as passed to the enroll method.
     * @param concernRoleContactDtls
     * The parameter as passed to the enroll method.
     *
     * @throws AppException
     * Generic Exception Signature.
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postEnroll(ProviderGroupAccessor providerGroup,
      AddressDtls addressDtls, PhoneNumberDtls phoneNumberDtls,
      ConcernRolePhoneNumberDtls concernRolePhoneNumberDtls,
      ConcernRoleDtls concernRoleDtls,
      ConcernRoleAddressDtls concernRoleAddressDtls,
      BankAccountDetails bankAccountDetails,
      RepresentativeRegistrationDetails representativeRegistrationDetails,
      ConcernRoleContactDtls concernRoleContactDtls) throws AppException,
        InformationalException;
  }


  /**
   * Interface to the provider group events functionality surrounding the reopen
   * method.
   */
  public interface ProviderGroupReopenEvents {

    /**
     * Event interface invoked before the main body of the reopen method.
     * {@linkplain curam.provider.impl.ProviderGroup#reopen}
     *
     * @param providerGroup
     * The object instance as it was before the main body of the reopen
     * method.
     * @param versionNo
     * The parameter as passed to the reopen method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void preReopen(ProviderGroupAccessor providerGroup, int versionNo)
      throws InformationalException, AppException;

    /**
     * Event interface invoked after the main body of the reopen method.
     * {@linkplain curam.provider.impl.ProviderGroup#reopen}
     *
     * @param providerGroup
     * The object instance as it was after the main body of the reopen
     * method.
     * @param versionNo
     * The parameter as passed to the reopen method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     * @throws AppException
     * Generic Exception Signature.
     */
    public void postReopen(ProviderGroupAccessor providerGroup, int versionNo)
      throws InformationalException, AppException;
  }


  /**
   * Interface to the provider group events functionality surrounding the modify
   * method.
   */
  public interface ProviderGroupModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderGroup#modify}
     *
     * @param providerGroup
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(ProviderGroupAccessor providerGroup, Integer versionNo)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderGroup#modify}
     *
     * @param providerGroup
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(ProviderGroupAccessor providerGroup,
      Integer versionNo) throws InformationalException;
  }


  // END, CR00144381

  // BEGIN, CR00145043, CPM
  /**
   * Interface to the provider group events functionality surrounding the
   * getCommonApprovedProviderServiceOfferings method.
   */
  public interface ProviderGroupGetCommonApprovedProviderServiceOfferingsEvents {

    /**
     * Event interface invoked before the main body of the
     * getCommonApprovedProviderServiceOfferings method.
     * {@linkplain curam.provider.impl.ProviderOrganization#getCommonApprovedProviderServiceOfferings}
     *
     * @param providerGroup
     * The object instance as it was before the main body of the
     * getCommonApprovedProviderServiceOfferings method.
     * @param contractVersion
     * The parameter as passed to the
     * getCommonApprovedProviderServiceOfferings method.
     */
    public void preGetCommonApprovedProviderServiceOfferings(
      ProviderGroupAccessor providerGroup, ContractVersion contractVersion);

    /**
     * Event interface invoked after the main body of the
     * getCommonApprovedProviderServiceOfferings method.
     * {@linkplain curam.provider.impl.ProviderOrganization#getCommonApprovedProviderServiceOfferings}
     *
     * @param providerGroup
     * The object instance as it was after the main body of the
     * getCommonApprovedProviderServiceOfferings method.
     * @param contractVersion
     * The parameter as passed to the
     * getCommonApprovedProviderServiceOfferings method.
     * @param serviceOfferings
     * The parameter as returned by the
     * getCommonApprovedProviderServiceOfferings method.
     */
    public void postGetCommonApprovedProviderServiceOfferings(
      ProviderGroupAccessor providerGroup, ContractVersion contractVersion,
      Set<ServiceOffering> serviceOfferings);
  }
  // END, CR00145043
}
