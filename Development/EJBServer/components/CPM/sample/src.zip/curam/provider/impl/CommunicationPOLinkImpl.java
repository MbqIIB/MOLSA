/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.Inject;

import curam.cpm.sl.struct.CommunicationPOLinkDtls;
import curam.serviceoffering.impl.ServiceOffering;
import curam.serviceoffering.impl.ServiceOfferingDAO;
import curam.util.exception.InformationalException;
import curam.util.persistence.GuiceWrapper;
import curam.util.persistence.helper.SingleTableEntityImpl;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.CommunicationPOLink}.
 */
public class CommunicationPOLinkImpl extends SingleTableEntityImpl<CommunicationPOLinkDtls> implements
  CommunicationPOLink {

  /**
   * Reference to service offering DAO.
   */
  @Inject
  protected ServiceOfferingDAO serviceOfferingDAO;

  /**
   * Constructor for the class.
   */
  protected CommunicationPOLinkImpl() {
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * {@inheritDoc}
   */
  public void crossEntityValidation() {// No validation required
  }

  /**
   * {@inheritDoc}
   */
  public void crossFieldValidation() {// No validation required
  }

  /**
   * {@inheritDoc}
   */
  public void mandatoryFieldValidation() {// No validation required
  }

  /**
   * {@inheritDoc}
   */
  public void setNewInstanceDefaults() {// No new instance defaults.
  }

  /**
   * {@inheritDoc}
   */
  public ServiceOffering getServiceOffering() {

    if (0 != getDtls().serviceOfferingID) {
      return serviceOfferingDAO.get(getDtls().serviceOfferingID);
    }
    return null;
  }

  /**
   * Inserts the communication and provider offering association.
   */
  @Override
  public void insert() throws InformationalException {
    super.insert();
  }

  /**
   * {@inheritDoc}
   */
  public void setServiceOffering(final ServiceOffering serviceOffering) {

    getDtls().serviceOfferingID = serviceOffering.getID();
  }

  /**
   * {@inheritDoc}
   */
  public void setCommunicationID(final long communictionID) {

    getDtls().communicationID = communictionID;
  }
}
