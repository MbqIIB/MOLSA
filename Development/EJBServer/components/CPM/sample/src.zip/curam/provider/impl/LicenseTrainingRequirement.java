/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.training.impl.Training;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.Lifecycle;


/**
 * Training Requirements for a License Type. Training to be completed by the
 * provider in order to be licensed. For example, a child care provider must
 * have completed Child abuse and neglect prevention, detection, and reporting
 * policies and procedures training in order to be licensed.
 *
 */
@ImplementedBy(LicenseTrainingRequirementImpl.class)
public interface LicenseTrainingRequirement extends
    LicenseTrainingRequirementAccessor, Insertable, OptimisticLockModifiable,
    Lifecycle<TrainingRequirementStatusEntry> {

  /**
   * Sets the training as the training requirement for a license type.
   *
   * @param value
   * The training which is added as training requirement to a license
   * type.
   * @throws InformationalException
   * Generic Exception Signature.
   * @see curam.provider.impl.LicenseTrainingRequirementImpl#setTraining(Training)
   * The default implementation -
   * curam.provider.impl.LicenseTrainingRequirementImpl#setTraining(Training)
   */
  void setTraining(final Training value) throws InformationalException;

  /**
   * Gets the immutable training details associated with license type.
   *
   * @return The associated immutable training details.
   */
  Training getTraining();

  /**
   * Sets the training completion.Indicates whether completion of the training
   * is required in order to get licensed.
   *
   * @param value
   * The training completion code.
   * @throws InformationalException
   * Generic Exception Signature.
   * @see curam.provider.impl.LicenseTrainingRequirementImpl#setCompletion(TrainingCompletionEntry)
   * The default implementation -
   * curam.provider.impl.LicenseTrainingRequirementImpl#setCompletion(TrainingCompletionEntry)
   */
  void setCompletion(final TrainingCompletionEntry value)
    throws InformationalException;

  /**
   * Sets the removal reason for removing the training requirement from a
   * license type.
   *
   * @param value
   * The removal reason for removing the training requirement from a
   * license type.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.LicenseTrainingRequirementImpl#setRemovalReason(TrainingRemovalReasonEntry)
   * The default implementation -
   * curam.provider.impl.LicenseTrainingRequirementImpl#setRemovalReason(TrainingRemovalReasonEntry)
   */
  void setRemovalReason(final TrainingRemovalReasonEntry value)
    throws InformationalException;

  /**
   * Sets the type of the license.
   *
   * @param value
   * The type of the license
   *
   * @see curam.provider.impl.LicenseTrainingRequirementImpl#setLicenseType(LicenseTypeEntry)
   * The default implementation -
   * curam.provider.impl.LicenseTrainingRequirementImpl#setLicenseType(LicenseTypeEntry)
   */
  public void setLicenseType(final LicenseTypeEntry value);

  /**
   * Sets record status of training requirement for a license type.
   *
   * @param value
   * The license training requirement record status.
   */
  void setRecordStatus(final TrainingRequirementStatusEntry value);

  /**
   * Removes the training requirement from a license type.The status is set to
   * 'Removed' when the training requirement is removed from a license type.
   *
   * @param versionNo
   * The version number of the Training Requirement record to be
   * removed.
   * @throws InformationalException
   * Generic Exception Signature.
   *
   * @see curam.provider.impl.LicenseTrainingRequirementImpl#remove(Integer) The
   * default implementation -
   * curam.provider.impl.LicenseTrainingRequirementImpl#remove(Integer)
   */
  void remove(final Integer versionNo) throws InformationalException;

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the license training requirement events functionality
   * surrounding the remove method.
   */
  public interface LicenseTrainingRequirementRemoveEvents {

    /**
     * Event interface invoked before the main body of the remove method.
     * {@linkplain curam.provider.impl.LicenseTrainingRequirement#remove}
     *
     * @param licenseTrainingRequirement
     * The object instance as it was before the main body of the remove
     * method.
     * @param versionNo
     * The parameter as passed to the remove method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preRemove(
      LicenseTrainingRequirementAccessor licenseTrainingRequirement,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the remove method.
     * {@linkplain curam.provider.impl.LicenseTrainingRequirement#remove}
     *
     * @param licenseTrainingRequirement
     * The object instance as it was after the main body of the remove
     * method.
     * @param versionNo
     * The parameter as passed to the remove method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postRemove(
      LicenseTrainingRequirementAccessor licenseTrainingRequirement,
      Integer versionNo) throws InformationalException;
  }


  /**
   * Interface to the license training requirement events functionality
   * surrounding the insert method.
   */
  public interface LicenseTrainingRequirementInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.LicenseTrainingRequirement#insert}
     *
     * @param licenseTrainingRequirement
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(
      LicenseTrainingRequirementAccessor licenseTrainingRequirement)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.LicenseTrainingRequirement#insert}
     *
     * @param licenseTrainingRequirement
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(
      LicenseTrainingRequirementAccessor licenseTrainingRequirement)
      throws InformationalException;
  }


  /**
   * Interface to the license training requirement events functionality
   * surrounding the modify method.
   */
  public interface LicenseTrainingRequirementModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.LicenseTrainingRequirement#modify}
     *
     * @param licenseTrainingRequirement
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(
      LicenseTrainingRequirementAccessor licenseTrainingRequirement,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.LicenseTrainingRequirement#modify}
     *
     * @param licenseTrainingRequirement
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(
      LicenseTrainingRequirementAccessor licenseTrainingRequirement,
      Integer versionNo) throws InformationalException;
  }
  // END, CR00144381

}
