/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2012 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.attendance.impl.ProviderRosterLineItem;
import curam.financial.impl.FinancialNotificationEventEntry;
import curam.util.persistence.Insertable;
import curam.util.type.Money;


/**
 * Interface for associating a concern role communication to provider roster
 * line item.
 *
 */
@ImplementedBy(CommunicationPRLILinkImpl.class)
public interface CommunicationPRLILink extends Insertable,
    CommunicationPRLILinkAccessor {

  /**
   * Gets the provider roster line associated with communication.
   *
   * @return The provider roster line item associated with communication.
   */
  public ProviderRosterLineItem getProviderRosterLineItem();

  /**
   * Sets an overpayment or under payment amount generated as part of provider
   * roster line item correction.
   *
   * @param value
   * An overpayment or under payment amount generated as part of
   * provider roster line item correction.
   */
  public void setAmount(final Money value);

  /**
   * Sets the communication.
   *
   * @param communictionID
   * The unique system generated identifier for the communication
   * record.
   */
  public void setCommunicationID(final long communictionID);

  /**
   * Sets the financial notification event.
   *
   * @param event
   * Contains financial notification event.
   */
  public void setFinancialEvent(final FinancialNotificationEventEntry event);

  /**
   * Sets the provider roster line item associated with communication.
   *
   * @param providerRosterLineItem
   * Contains provider roster line item associated with communication.
   */
  public void setProviderRosterLineItem(
    final ProviderRosterLineItem providerRosterLineItem);

  /**
   * Sets the roster notification event.
   *
   * @param event
   * Contains roster notification event.
   */
  public void setRosterEvent(final RosterNotificationEventEntry event);
}
