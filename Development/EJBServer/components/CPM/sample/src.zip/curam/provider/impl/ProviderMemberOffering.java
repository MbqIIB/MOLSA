/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008-2009 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.providerservice.impl.ProviderOffering;
import curam.util.exception.InformationalException;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.DateRange;


/**
 * The link information between provider member offering and provider member.
 */
@ImplementedBy(ProviderMemberOfferingImpl.class)
public interface ProviderMemberOffering extends ProviderMemberOfferingAccessor, Insertable, 
    OptimisticLockModifiable, LogicallyDeleteable {
  
  /**
   * Gets the provider party associated with the provider offering.
   *
   * @return Provider party.
   */
  public ProviderParty getProviderParty();
  
  /**
   * Gets the provider offering associated with the provider party.
   *
   * @return Provider offering.
   */
  public ProviderOffering getProviderOffering();
 
  /**
   * Sets the provider party associated with the provider offering.
   *
   * @param value
   * Provider Party
   */
  public void setProviderParty(ProviderParty value);
  
  /**
   * Sets the provider offering associated with the provider party.
   *
   * @param value
   * Provider Offering
   */
  public void setProviderOffering(ProviderOffering value);
  
  /**
   * Set the date range for which the provider party offers the service.
   *
   * @param value
   * Date range for which the provider party offers the service.
   */
  public void setDateRange(DateRange value);
  
  /**
   * Set the date range and adjust the date range to fall within the date range 
   * of provider membership and provider offering.
   *
   * @param value
   * Date range for which the provider member offers the service.
   */
  public void setDateRangeAndAdjustForValidRange(DateRange value);  
  
  // BEGIN, CR00121367, ABS
  /**
   * Sets the comments for provider member offering.
   *
   * @param value
   * Comments for provider member offering.
   */
  // END, CR00121367
  public void setComments(String value);

  // BEGIN, CR00144381, CPM
  /**
   * Interface to the provider member offering events functionality surrounding
   * the insert method.
   */
  public interface ProviderMemberOfferingInsertEvents {

    /**
     * Event interface invoked before the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderMemberOffering#insert}
     *
     * @param providerMemberOffering
     * The object instance as it was before the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preInsert(ProviderMemberOfferingAccessor providerMemberOffering)
      throws InformationalException;

    /**
     * Event interface invoked after the main body of the insert method.
     * {@linkplain curam.provider.impl.ProviderMemberOffering#insert}
     *
     * @param providerMemberOffering
     * The object instance as it was after the main body of the insert
     * method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postInsert(ProviderMemberOfferingAccessor providerMemberOffering)
      throws InformationalException;
  }


  /**
   * Interface to the provider member offering events functionality surrounding
   * the modify method.
   */
  public interface ProviderMemberOfferingModifyEvents {

    /**
     * Event interface invoked before the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderMemberOffering#modify}
     *
     * @param providerMemberOffering
     * The object instance as it was before the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preModify(ProviderMemberOfferingAccessor providerMemberOffering,
      Integer versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the modify method.
     * {@linkplain curam.provider.impl.ProviderMemberOffering#modify}
     *
     * @param providerMemberOffering
     * The object instance as it was after the main body of the modify
     * method.
     * @param versionNo
     * The parameter as passed to the modify method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postModify(ProviderMemberOfferingAccessor providerMemberOffering,
      Integer versionNo) throws InformationalException;
  }


  /**
   * Interface to the provider member offering events functionality surrounding
   * the cancel method.
   */
  public interface ProviderMemberOfferingCancelEvents {

    /**
     * Event interface invoked before the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderMemberOffering#cancel}
     *
     * @param providerMemberOffering
     * The object instance as it was before the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void preCancel(ProviderMemberOfferingAccessor providerMemberOffering,
      int versionNo) throws InformationalException;

    /**
     * Event interface invoked after the main body of the cancel method.
     * {@linkplain curam.provider.impl.ProviderMemberOffering#cancel}
     *
     * @param providerMemberOffering
     * The object instance as it was after the main body of the cancel
     * method.
     * @param versionNo
     * The parameter as passed to the cancel method.
     *
     * @throws InformationalException
     * Generic Exception Signature.
     */
    public void postCancel(ProviderMemberOfferingAccessor providerMemberOffering,
      int versionNo) throws InformationalException;
  }


  // END, CR00144381
  
  // BEGIN, CR00145043, CPM
  /**
   * Interface to the provider member offering events functionality surrounding
   * the set date range and adjust for valid range method.
   */
  public interface ProviderMemberOfferingSetDateRangeAndAdjustForValidRangeEvents {

    /**
     * Event interface invoked before the main body of the set date range and
     * adjust for valid range method.
     * {@linkplain curam.provider.impl.ProviderMemberOffering#setDateRangeAndAdjustForValidRange}
     *
     * @param providerMemberOffering
     * The object instance as it was before the main body of the set
     * date range and adjust for valid range method.
     * @param dateRange
     * The parameter as passed to the set date range and adjust for
     * valid range method.
     */
    public void preSetDateRangeAndAdjustForValidRange(
      ProviderMemberOfferingAccessor providerMemberOffering, DateRange dateRange);

    /**
     * Event interface invoked after the main body of the set date range and
     * adjust for valid range method.
     * {@linkplain curam.provider.impl.ProviderMemberOffering#setDateRangeAndAdjustForValidRange}
     *
     * @param providerMemberOffering
     * The object instance as it was after the main body of the set
     * date range and adjust for valid range method.
     * @param dateRange
     * The parameter as passed to the set date range and adjust for
     * valid range method.
     */
    public void postSetDateRangeAndAdjustForValidRange(
      ProviderMemberOfferingAccessor providerMemberOffering, DateRange dateRange);
  }
  // END, CR00145043
}
