/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import java.util.Set;

import com.google.inject.Singleton;

import curam.cpm.sl.entity.fact.LicenseTrainingRequirementFactory;
import curam.cpm.sl.entity.impl.LicenseTrainingRequirementAdapter;
import curam.cpm.sl.entity.struct.LicenseTrainingRequirementDtls;
import curam.cpm.sl.entity.struct.LicenseTrainingRequirementSearchDetailsList;
import curam.cpm.sl.entity.struct.LicenseTrainingRequirementSearchKey;
import curam.training.impl.Training;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import curam.util.persistence.StandardDAOImpl;
import curam.util.persistence.helper.LifecycleHelper;
import curam.util.type.StringHelper;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.LicenseTrainingRequirementDAO}.
 */
@Singleton
// BEGIN, CR00183213, SS
public class LicenseTrainingRequirementDAOImpl extends StandardDAOImpl<LicenseTrainingRequirement, LicenseTrainingRequirementDtls>
  implements LicenseTrainingRequirementDAO {
  // END, CR00183213
  /**
   * License Training Requirement Adapter initialization.
   */
  protected static final LicenseTrainingRequirementAdapter adapter = new LicenseTrainingRequirementAdapter();

  // ___________________________________________________________________________
  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  protected LicenseTrainingRequirementDAOImpl() {
    // END, CR00183213
    super(adapter, LicenseTrainingRequirement.class);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<LicenseTrainingRequirement> searchByLicenseType(String licenseType) {
    // Trim the inputs.
    licenseType = StringHelper.trim(licenseType);

    // Call the searchByLicenceType method on LicenseTrainingRequirement entity.
    return newSet(adapter.searchByLicenceType(licenseType));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<LicenseTrainingRequirement> getActiveLicenseTrainingRequirementsByTraining(Training training) {
    return LifecycleHelper.filter(
      newSet(adapter.searchByTraining(training.getID())),
      TrainingRequirementStatusEntry.ACTIVE);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public Set<LicenseTrainingRequirement> searchByTraining(Training training) {
    return newSet(adapter.searchByTraining(training.getID()));
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public LicenseTrainingRequirementSearchDetailsList retrieveForProvider(
    LicenseTrainingRequirementSearchKey key) throws AppException,
      InformationalException {

    curam.cpm.sl.entity.intf.LicenseTrainingRequirement trainingRequirement = LicenseTrainingRequirementFactory.newInstance();

    LicenseTrainingRequirementSearchDetailsList detailsList = trainingRequirement.searchByProvider(
      key);

    return detailsList;
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public LicenseTrainingRequirementSearchDetailsList retrieveForProviderGroup(
    LicenseTrainingRequirementSearchKey key) throws AppException,
      InformationalException {

    curam.cpm.sl.entity.intf.LicenseTrainingRequirement trainingRequirement = LicenseTrainingRequirementFactory.newInstance();

    return trainingRequirement.searchByProviderGroup(key);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public LicenseTrainingRequirementSearchDetailsList retrieveForProviderGroupMember(
    LicenseTrainingRequirementSearchKey key) throws AppException,
      InformationalException {
    curam.cpm.sl.entity.intf.LicenseTrainingRequirement trainingRequirement = LicenseTrainingRequirementFactory.newInstance();

    return trainingRequirement.searchByProviderGroupMember(key);
  }

  // ___________________________________________________________________________
  /**
   * {@inheritDoc}
   */
  public LicenseTrainingRequirementSearchDetailsList retrieveForProviderMember(
    LicenseTrainingRequirementSearchKey key) throws AppException,
      InformationalException {
    curam.cpm.sl.entity.intf.LicenseTrainingRequirement trainingRequirement = LicenseTrainingRequirementFactory.newInstance();

    return trainingRequirement.searchByProviderMember(key);
  }

}
