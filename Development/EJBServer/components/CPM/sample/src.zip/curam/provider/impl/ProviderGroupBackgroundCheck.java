/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */

package curam.provider.impl;


import com.google.inject.ImplementedBy;
import curam.util.exception.AppException;
import curam.util.exception.InformationalException;
import java.util.Set;


/**
 * Background checks undertaken on employees or household members of a provider
 * group.
 *
 * For example, an SEM agency may wish to conduct both a Criminal Investigation
 * check and a Child Protective Service check on all employees of each of their
 * Day Care Centers. The actual background check may be conducted by the agency
 * itself (e.g. in the case of a Child Protective Service check) or may be
 * conducted by an outside body.
 */
@ImplementedBy(ProviderGroupBackgroundCheckImpl.class)
public interface ProviderGroupBackgroundCheck extends BackgroundCheck {

  /**
   * Gets the provider Group associated with the Background Check.
   *
   * @return Provider Group associated with the background check.
   */
  public ProviderGroup getProviderGroup();

  /**
   * Sets the provider Group associated with the Background Check.
   *
   * @param value
   * The Provider Group to be set for the background check.
   */
  public void setProviderGroup(final ProviderGroup value);
  
  /**
   * Sets the provider group member for whom background check is to be done.
   *
   * @param value
   * The Provider group member for whom background check is to be done.
   *
   * @throws AppException Generic Exception Signature.
   * @throws InformationalException Generic Exception Signature.
   */
  public void setProviderMember(final ProviderMember value)
    throws AppException, InformationalException;  
  
  /**
   * Gets the BackgroundCheckFailureReasons for a provider Background Check.
   *
   * @return Set<BackgroundCheckFailureReason> the
   * BackgroundCheckFailureReasons for a provider Background Check.
   */
  public Set<PGBackgroundCheckFailureReason> getProviderGroupBackgroundCheckFailureReasons();

}

