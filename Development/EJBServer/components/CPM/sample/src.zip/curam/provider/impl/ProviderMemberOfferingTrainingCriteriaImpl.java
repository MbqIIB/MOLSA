/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008, 2010-2011 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.Inject;
import curam.codetable.impl.TRAININGPROGRAMPARTYSTATUSEntry;
import curam.core.impl.CuramConst;
import curam.cpm.facade.struct.InformationalMessage;
import curam.cpm.facade.struct.InformationalMessageList;
import curam.message.impl.PROVIDERMEMBEROFFERINGExceptionCreator;
import curam.providerservice.impl.ProviderOffering;
import curam.providerservice.impl.ProviderOfferingDAO;
import curam.serviceoffering.impl.SOTrainingRequirement;
import curam.serviceoffering.impl.SOTrainingRequirementDAO;
import curam.training.impl.TrainingProgramMember;
import curam.training.impl.TrainingProgramMemberDAO;
import curam.util.exception.InformationalException;
import curam.util.exception.InformationalManager;
import curam.util.exception.InformationalElement.InformationalType;
import curam.util.persistence.GuiceWrapper;
import curam.util.resources.GeneralConstants;
import curam.util.resources.StringUtil;
import curam.util.transaction.TransactionInfo;
import curam.util.type.StringHelper;
import java.util.Set;


/**
 * Standard implementation of
 * {@linkplain curam.provider.impl.ProviderMemberOfferingTrainingCriteria}.
 */
// BEGIN, CR00183213, SS
public class ProviderMemberOfferingTrainingCriteriaImpl implements
  ProviderMemberOfferingTrainingCriteria {
  // END, CR00183213
  @Inject
  protected ProviderOfferingDAO providerOfferingDAO;

  @Inject
  protected SOTrainingRequirementDAO soTrainingRequirementDAO;

  @Inject
  protected TrainingProgramMemberDAO trainingProgramMemberDAO;

  // BEGIN, CR00183213, SS
  /**
   * Constructor for the class.
   */
  // END, CR00183213
  public ProviderMemberOfferingTrainingCriteriaImpl() {
    // Bootstrap dependency injection for this class
    GuiceWrapper.getInjector().injectMembers(this);
  }

  /**
   * If training requirements are specified for the Provider Offering, then all
   * trainings marked as 'Required' must be 'Completed' or 'Waived' for the
   * provider members.
   *
   * @param providerOfferings
   * Provider Offerings that is to be linked with the Provider Member.
   * @param providerMember
   * Provider Member entity.
   *
   * @return List of informational message.
   *
   * @throws InformationalException
   * {@link curam.message.PROVIDERMEMBEROFFERING#ERR_PROVIDERMEMBEROFFERING_XRV_PROVIDERMEMBER_HAS_TO_MEET_TRAINING_REQUIREMENTS} -
   * If the provider member does not meet the training requirements.
   */
  public InformationalMessageList checkProviderMemberTrainingProgram(
    String providerOfferings, ProviderMember providerMember)
    throws InformationalException {

    InformationalMessageList informationalMessageList = new InformationalMessageList();
    InformationalManager informationalManager = TransactionInfo.getInformationalManager();

    final String[] providerOfferingIDs = StringUtil.tabText2StringList(providerOfferings).items();

    StringBuffer servicesRequiredTraining = new StringBuffer();

    boolean trainingRequired = false;

    // For each provider offering create a provider member offering record
    for (final String providerOfferingString : providerOfferingIDs) {

      ProviderOffering providerOffering = providerOfferingDAO.get(
        Long.parseLong(providerOfferingString));

      trainingRequired = false;

      // Loop through all the training requirements for the service offering and
      // check whether the provider member has member training program of status
      // COMPLETE or WAIVED.
      for (SOTrainingRequirement soTrainingRequirement : soTrainingRequirementDAO.searchBy(
        providerOffering.getServiceOffering())) {

        Set<TrainingProgramMember> trainingProgramMembers = null;

        // BEGIN CR00125992, MST
        if (!soTrainingRequirement.getCompletion().equals(
          TrainingCompletionEntry.REQUIRED)
            || !soTrainingRequirement.getLifecycleState().equals(
              TrainingRequirementStatusEntry.ACTIVE)) {
          continue;
        }
        // END CR00125992

        if (providerMember.getParty() != null) {
          trainingProgramMembers = trainingProgramMemberDAO.getTrainingProgramsForParty(
            soTrainingRequirement.getTraining().getID(),
            providerMember.getParty().getID());
        }

        if (trainingProgramMembers == null || trainingProgramMembers.isEmpty()) {

          trainingRequired = true;
          break;
        }

        for (TrainingProgramMember trainingProgramMember :
          trainingProgramMembers) {

          if (!(trainingProgramMember.getLifecycleState().equals(
            TRAININGPROGRAMPARTYSTATUSEntry.COMPLETE)
              || trainingProgramMember.getLifecycleState().equals(
                TRAININGPROGRAMPARTYSTATUSEntry.WAIVED))) {

            trainingRequired = true;
            break;
          }
        }
      }

      if (trainingRequired) {

        if (StringHelper.isEmpty(servicesRequiredTraining.toString())) {
          servicesRequiredTraining.append(
            providerOffering.getServiceOffering().getName());

        } else {
          servicesRequiredTraining.append(GeneralConstants.kComma);
          servicesRequiredTraining.append(GeneralConstants.kSpace);
          servicesRequiredTraining.append(
            providerOffering.getServiceOffering().getName());
        }
      }

    }

    if (!StringHelper.isEmpty(servicesRequiredTraining.toString())) {
      curam.core.sl.infrastructure.impl.ValidationManagerFactory.getManager().addInfoMgrExceptionWithLookup(
        PROVIDERMEMBEROFFERINGExceptionCreator.ERR_PROVIDERMEMBEROFFERING_XRV_PROVIDERMEMBER_HAS_TO_MEET_TRAINING_REQUIREMENTS(
          providerMember.getParty().getName(),
          servicesRequiredTraining.toString()),
          CuramConst.gkEmpty,
          InformationalType.kWarning,
          curam.core.sl.infrastructure.impl.ValidationManagerConst.kSetTwo,
          0);

    }

    // Assign informational messages to return struct
    String warnings[] = informationalManager.obtainInformationalAsString();

    for (int i = 0; i < warnings.length; i++) {
      InformationalMessage infoMessage = new InformationalMessage();

      infoMessage.messageTest = warnings[i];
      informationalMessageList.dtls.addRef(infoMessage);
    }

    return informationalMessageList;
  }

}
