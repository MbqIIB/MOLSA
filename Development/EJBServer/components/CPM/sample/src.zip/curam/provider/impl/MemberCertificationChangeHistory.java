/*
 * Licensed Materials - Property of IBM
 *
 * Copyright IBM Corporation 2012. All Rights Reserved.
 *
 * US Government Users Restricted Rights - Use, duplication or disclosure 
 * restricted by GSA ADP Schedule Contract with IBM Corp.
 */

/*
 * Copyright 2008 Curam Software Ltd.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Curam
 * Software, Ltd. ("Confidential Information").  You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with Curam Software.
 */
package curam.provider.impl;


import com.google.inject.ImplementedBy;

import curam.certification.impl.Certification;
import curam.util.persistence.Insertable;
import curam.util.persistence.OptimisticLockModifiable;
import curam.util.persistence.helper.LogicallyDeleteable;
import curam.util.type.Date;
import curam.util.type.DateTime;


/**
 * The Member Certification Change History manages the history of the
 * certification which are provided to the provider, provider group and the
 * unassigned user.
 */
@ImplementedBy(MemberCertificationChangeHistoryImpl.class)
public interface MemberCertificationChangeHistory extends MemberCertificationChangeHistoryAccessor,
    Insertable, OptimisticLockModifiable, LogicallyDeleteable {

  /**
   * Sets the certification
   *
   * @param certification contains the details of the certification
   */
  void setCertification(final Certification certification);

  /**
   * Sets the user name for the member certification
   *
   * @param userName contains the user who enters or modifies the certification
   */
  void setUserName(final String userName);

  /**
   * Sets the member certificationID
   *
   * @param memberCertificationID contains system generated identifier for
   * the member certification
   */
  void setMemberCertificationID(final long memberCertificationID);

  /**
   * Sets the partyConcernRoleID
   *
   * @param partyconcernRoleID system generated identifier for the party
   */
  void setPartyconcernRoleID(final long partyconcernRoleID);

  /**
   * Sets the date and time the member certification is
   * modified or created
   *
   * @param dateTime contains the current date time
   */
  void setDateTime(final DateTime dateTime);

  /**
   * Sets the date of issue
   *
   * @param dateOfIssue contains the date the certification is issued.
   */
  void setDateOfIssue(final Date dateOfIssue);

  /**
   * Sets the date of expiry
   *
   * @param dateOfExpiry contains the date the certification is expired.
   */
  void setDateOfExpiry(final Date dateOfExpiry);

  /**
   * @return Contains the instance of certification
   */
  Certification getCertification();

}
